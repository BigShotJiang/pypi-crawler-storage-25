"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_apify")
class IntegrationApifyNode(Node):
    """
    Apify

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'run_actor'
        actor_id: Actor ID or a tilde-separated username and Actor name
        build: Actor build tag to run. Defaults to latest
        input: JSON input for the Actor run. If empty, uses default run configuration
        memory: Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)
        timeout: Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)
        wait_for_finish: Whether to wait for the run to finish before continuing
    ### When action = 'run_actor_and_list_dataset'
        actor_id: Actor ID or a tilde-separated username and Actor name
        build: Actor build tag to run. Defaults to latest
        input: JSON input for the Actor run. If empty, uses default run configuration
        memory: Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)
        timeout: Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)
    ### When action = 'get_last_run'
        actor_id: Actor ID or a tilde-separated username and Actor name
    ### When action = 'get_run'
        actor_id: Actor ID or a tilde-separated username and Actor name
        run_id: The ID of the run to retrieve
    ### When action = 'list_actor_runs'
        actor_id: Actor ID or a tilde-separated username and Actor name
        desc: Whether to sort by startedAt in descending order
        offset: Number of items to skip at the start
        status: Filter by run status
        use_date: Toggle to use dates
    ### When action = 'run_task'
        build: Actor build tag to run. Defaults to latest
        input: JSON input for the Actor run. If empty, uses default run configuration
        memory: Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)
        task_id: Task ID or a tilde-separated username and task name
        timeout: Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)
        wait_for_finish: Whether to wait for the run to finish before continuing
    ### When action = 'run_task_and_list_dataset'
        build: Actor build tag to run. Defaults to latest
        input: JSON input for the Actor run. If empty, uses default run configuration
        memory: Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)
        task_id: Task ID or a tilde-separated username and task name
        timeout: Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)
    ### When action = 'list_dataset_items'
        dataset_id: Dataset ID or username~dataset-name
        offset: Number of items to skip at the start
        use_date: Toggle to use dates
    ### When action = 'list_user_runs' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_actor_runs' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_dataset_items' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_user_runs'
        desc: Whether to sort by startedAt in descending order
        offset: Number of items to skip at the start
        status: Filter by run status
        use_date: Toggle to use dates
    ### When action = 'list_user_runs' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_actor_runs' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_dataset_items' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_key_value_store_record'
        key: The key of the record to be retrieved
        store_id: The ID of the Key-Value Store
    ### When action = 'list_user_runs' and use_date = False
        num_messages: Max number of results to return
    ### When action = 'list_actor_runs' and use_date = False
        num_messages: Max number of results to return
    ### When action = 'list_dataset_items' and use_date = False
        num_messages: Max number of results to return
    ### When action = 'scrape_single_url'
        url: URL to be scraped. Must start with http:// or https://
    ### When action = 'list_user_runs' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_actor_runs' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_dataset_items' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'run_actor'
        actor_id: ID of the Actor that was run
        default_dataset_id: ID of the default dataset created by the run
        default_key_value_store_id: ID of the default key-value store
        default_request_queue_id: ID of the default request queue
        exit_code: Exit code of the run
        finished_at: When the run finished (if completed)
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        started_at: When the run started
        status: Status of the run
        stopped_at: When the run was stopped (if stopped)
    ### When action = 'run_actor_and_list_dataset'
        actor_id: ID of the Actor that was run
        dataset_id: ID of the dataset containing results
        dataset_items: Items from the dataset
        dataset_raw_data: Raw dataset response data
        finished_at: When the run finished
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        started_at: When the run started
        status: Status of the run
        total_items: Total number of items in the dataset
    ### When action = 'get_last_run'
        actor_id: ID of the Actor
        default_dataset_id: ID of the default dataset
        default_key_value_store_id: ID of the default key-value store
        default_request_queue_id: ID of the default request queue
        exit_code: Exit code of the run
        finished_at: When the run finished (if completed)
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        started_at: When the run started
        status: Status of the run
        stopped_at: When the run was stopped (if stopped)
    ### When action = 'get_run'
        actor_id: ID of the Actor
        default_dataset_id: ID of the default dataset
        default_key_value_store_id: ID of the default key-value store
        default_request_queue_id: ID of the default request queue
        exit_code: Exit code of the run
        finished_at: When the run finished (if completed)
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        started_at: When the run started
        status: Status of the run
        stopped_at: When the run was stopped (if stopped)
    ### When action = 'list_actor_runs'
        actor_id: ID of the Actor
        actor_ids: List of actor IDs
        count: Number of runs in this response
        dataset_ids: List of dataset IDs
        exit_codes: List of exit codes
        finished_ats: List of finish timestamps
        limit: Limit used for pagination
        offset: Offset used for pagination
        raw_data: Raw API response data
        run_ids: List of run IDs
        runs: List of run objects
        started_ats: List of start timestamps
        statuses: List of run statuses
        total: Total number of runs
    ### When action = 'list_user_runs'
        actor_ids: List of actor IDs
        count: Number of runs in this response
        dataset_ids: List of dataset IDs
        exit_codes: List of exit codes
        finished_ats: List of finish timestamps
        limit: Limit used for pagination
        offset: Offset used for pagination
        raw_data: Raw API response data
        run_ids: List of run IDs
        runs: List of run objects
        started_ats: List of start timestamps
        statuses: List of run statuses
        total: Total number of runs
    ### When action = 'list_dataset_items'
        count: Number of items in this response
        dataset_id: ID of the dataset
        items: List of dataset items
        limit: Limit used for pagination
        offset: Offset used for pagination
        raw_data: Raw API response data
        total: Total number of items in the dataset
    ### When action = 'run_task_and_list_dataset'
        dataset_id: ID of the dataset containing results
        dataset_items: Items from the dataset
        dataset_raw_data: Raw dataset response data
        finished_at: When the run finished
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        started_at: When the run started
        status: Status of the run
        task_id: ID of the task that was run
        total_items: Total number of items in the dataset
    ### When action = 'scrape_single_url'
        dataset_items: All dataset items from the scrape
        dataset_raw_data: Raw dataset response data
        finished_at: When the scraping finished
        html_content: HTML content extracted from the URL
        markdown_content: Markdown content extracted from the URL
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        status: Status of the scraping run
        text_content: Text content extracted from the URL
        total_items: Total number of items scraped
        url: The URL that was scraped
    ### When action = 'run_task'
        default_dataset_id: ID of the default dataset created by the run
        default_key_value_store_id: ID of the default key-value store
        default_request_queue_id: ID of the default request queue
        exit_code: Exit code of the run
        finished_at: When the run finished (if completed)
        raw_data: Raw API response data
        run_id: Unique identifier of the run
        started_at: When the run started
        status: Status of the run
        stopped_at: When the run was stopped (if stopped)
        task_id: ID of the task that was run
    ### When action = 'list_key_value_store_record'
        key: The key of the record
        raw_data: Raw API response data
        store_id: ID of the key-value store
        value: The value of the record
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Apify>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "run_actor**(*)**(*)": {
            "inputs": [
                {
                    "field": "actor_id",
                    "type": "string",
                    "value": "",
                    "label": "Actor ID",
                    "placeholder": "Select actor",
                    "helper_text": "Actor ID or a tilde-separated username and Actor name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=actor_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "input",
                    "type": "string",
                    "value": "{}",
                    "label": "Input JSON",
                    "placeholder": '{"startUrls":[{"url": "https://example.com"}]}',
                    "helper_text": "JSON input for the Actor run. If empty, uses default run configuration",
                },
                {
                    "field": "wait_for_finish",
                    "type": "bool",
                    "value": False,
                    "label": "Wait for Finish",
                    "helper_text": "Whether to wait for the run to finish before continuing",
                },
                {
                    "field": "timeout",
                    "type": "int32",
                    "value": 0,
                    "label": "Timeout",
                    "placeholder": "3600",
                    "helper_text": "Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)",
                },
                {
                    "field": "memory",
                    "type": "int32",
                    "value": 1024,
                    "label": "Memory",
                    "placeholder": "1024",
                    "helper_text": "Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)",
                },
                {
                    "field": "build",
                    "type": "string",
                    "value": "",
                    "label": "Build Tag",
                    "placeholder": "latest",
                    "helper_text": "Actor build tag to run. Defaults to latest",
                },
            ],
            "outputs": [
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "actor_id",
                    "type": "string",
                    "helper_text": "ID of the Actor that was run",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the run",
                },
                {
                    "field": "started_at",
                    "type": "timestamp",
                    "helper_text": "When the run started",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the run finished (if completed)",
                },
                {
                    "field": "stopped_at",
                    "type": "timestamp",
                    "helper_text": "When the run was stopped (if stopped)",
                },
                {
                    "field": "exit_code",
                    "type": "int32",
                    "helper_text": "Exit code of the run",
                },
                {
                    "field": "default_dataset_id",
                    "type": "string",
                    "helper_text": "ID of the default dataset created by the run",
                },
                {
                    "field": "default_key_value_store_id",
                    "type": "string",
                    "helper_text": "ID of the default key-value store",
                },
                {
                    "field": "default_request_queue_id",
                    "type": "string",
                    "helper_text": "ID of the default request queue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "run_actor",
            "task_name": "tasks.apify.run_actor",
            "description": "Execute an Actor with optional input parameters",
            "label": "Run Actor",
            "input_sort_order": [
                "integration",
                "action",
                "actor_id",
                "input",
                "wait_for_finish",
                "timeout",
                "memory",
                "build",
            ],
            "required": ["actor_id"],
        },
        "run_actor_and_list_dataset**(*)**(*)": {
            "inputs": [
                {
                    "field": "actor_id",
                    "type": "string",
                    "value": "",
                    "label": "Actor ID",
                    "placeholder": "Select actor",
                    "helper_text": "Actor ID or a tilde-separated username and Actor name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=actor_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "input",
                    "type": "string",
                    "value": "{}",
                    "label": "Input JSON",
                    "placeholder": '{"startUrls":[{"url": "https://example.com"}]}',
                    "helper_text": "JSON input for the Actor run. If empty, uses default run configuration",
                },
                {
                    "field": "timeout",
                    "type": "int32",
                    "value": 0,
                    "label": "Timeout",
                    "placeholder": "3600",
                    "helper_text": "Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)",
                },
                {
                    "field": "memory",
                    "type": "int32",
                    "value": 1024,
                    "label": "Memory",
                    "placeholder": "1024",
                    "helper_text": "Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)",
                },
                {
                    "field": "build",
                    "type": "string",
                    "value": "",
                    "label": "Build Tag",
                    "placeholder": "latest",
                    "helper_text": "Actor build tag to run. Defaults to latest",
                },
            ],
            "outputs": [
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "actor_id",
                    "type": "string",
                    "helper_text": "ID of the Actor that was run",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the run",
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "helper_text": "ID of the dataset containing results",
                },
                {
                    "field": "dataset_items",
                    "type": "vec<string>",
                    "helper_text": "Items from the dataset",
                },
                {
                    "field": "total_items",
                    "type": "int32",
                    "helper_text": "Total number of items in the dataset",
                },
                {
                    "field": "started_at",
                    "type": "timestamp",
                    "helper_text": "When the run started",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the run finished",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
                {
                    "field": "dataset_raw_data",
                    "type": "string",
                    "helper_text": "Raw dataset response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "run_actor_and_list_dataset",
            "task_name": "tasks.apify.run_actor_and_list_dataset",
            "description": "Execute an Actor, wait for completion, and retrieve the dataset items",
            "label": "Run Actor and List Dataset",
            "input_sort_order": [
                "integration",
                "action",
                "actor_id",
                "input",
                "timeout",
                "memory",
                "build",
            ],
            "required": ["actor_id"],
        },
        "scrape_single_url**(*)**(*)": {
            "inputs": [
                {
                    "field": "url",
                    "type": "string",
                    "value": "",
                    "label": "URL",
                    "placeholder": "https://example.com",
                    "helper_text": "URL to be scraped. Must start with http:// or https://",
                }
            ],
            "outputs": [
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "The URL that was scraped",
                },
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the scraping run",
                },
                {
                    "field": "text_content",
                    "type": "string",
                    "helper_text": "Text content extracted from the URL",
                },
                {
                    "field": "markdown_content",
                    "type": "string",
                    "helper_text": "Markdown content extracted from the URL",
                },
                {
                    "field": "html_content",
                    "type": "string",
                    "helper_text": "HTML content extracted from the URL",
                },
                {
                    "field": "dataset_items",
                    "type": "vec<string>",
                    "helper_text": "All dataset items from the scrape",
                },
                {
                    "field": "total_items",
                    "type": "int32",
                    "helper_text": "Total number of items scraped",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the scraping finished",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
                {
                    "field": "dataset_raw_data",
                    "type": "string",
                    "helper_text": "Raw dataset response data",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "scrape_single_url",
            "task_name": "tasks.apify.scrape_single_url",
            "description": "Quick scraping of a single URL using Apify Website Content Crawler",
            "label": "Scrape Single URL",
            "input_sort_order": ["integration", "action", "url"],
            "required": ["url"],
        },
        "get_last_run**(*)**(*)": {
            "inputs": [
                {
                    "field": "actor_id",
                    "type": "string",
                    "value": "",
                    "label": "Actor ID",
                    "placeholder": "Select actor",
                    "helper_text": "Actor ID or a tilde-separated username and Actor name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=actor_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "actor_id",
                    "type": "string",
                    "helper_text": "ID of the Actor",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the run",
                },
                {
                    "field": "started_at",
                    "type": "timestamp",
                    "helper_text": "When the run started",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the run finished (if completed)",
                },
                {
                    "field": "stopped_at",
                    "type": "timestamp",
                    "helper_text": "When the run was stopped (if stopped)",
                },
                {
                    "field": "exit_code",
                    "type": "int32",
                    "helper_text": "Exit code of the run",
                },
                {
                    "field": "default_dataset_id",
                    "type": "string",
                    "helper_text": "ID of the default dataset",
                },
                {
                    "field": "default_key_value_store_id",
                    "type": "string",
                    "helper_text": "ID of the default key-value store",
                },
                {
                    "field": "default_request_queue_id",
                    "type": "string",
                    "helper_text": "ID of the default request queue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_last_run",
            "task_name": "tasks.apify.get_last_run",
            "description": "Retrieve information about the most recent Actor run",
            "label": "List Last Run",
            "input_sort_order": ["integration", "action", "actor_id"],
            "required": ["actor_id"],
        },
        "get_run**(*)**(*)": {
            "inputs": [
                {
                    "field": "actor_id",
                    "type": "string",
                    "value": "",
                    "label": "Actor ID",
                    "placeholder": "Select actor",
                    "helper_text": "Actor ID or a tilde-separated username and Actor name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=actor_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "run_id",
                    "type": "string",
                    "value": "",
                    "label": "Run ID",
                    "placeholder": "Select run",
                    "helper_text": "The ID of the run to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=run_id&actor_id={inputs.actor_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "actor_id",
                    "type": "string",
                    "helper_text": "ID of the Actor",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the run",
                },
                {
                    "field": "started_at",
                    "type": "timestamp",
                    "helper_text": "When the run started",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the run finished (if completed)",
                },
                {
                    "field": "stopped_at",
                    "type": "timestamp",
                    "helper_text": "When the run was stopped (if stopped)",
                },
                {
                    "field": "exit_code",
                    "type": "int32",
                    "helper_text": "Exit code of the run",
                },
                {
                    "field": "default_dataset_id",
                    "type": "string",
                    "helper_text": "ID of the default dataset",
                },
                {
                    "field": "default_key_value_store_id",
                    "type": "string",
                    "helper_text": "ID of the default key-value store",
                },
                {
                    "field": "default_request_queue_id",
                    "type": "string",
                    "helper_text": "ID of the default request queue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_run",
            "task_name": "tasks.apify.get_run",
            "description": "Retrieve detailed information about a specific run",
            "label": "List Run",
            "input_sort_order": ["integration", "action", "actor_id", "run_id"],
            "required": ["actor_id", "run_id"],
        },
        "list_user_runs**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "value": 0,
                    "label": "Offset",
                    "helper_text": "Number of items to skip at the start",
                },
                {
                    "field": "desc",
                    "type": "bool",
                    "value": True,
                    "label": "Descending",
                    "helper_text": "Whether to sort by startedAt in descending order",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "SUCCEEDED",
                    "label": "Status",
                    "helper_text": "Filter by run status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "SUCCEEDED", "value": "SUCCEEDED"},
                            {"label": "FAILED", "value": "FAILED"},
                            {"label": "TIMED-OUT", "value": "TIMED-OUT"},
                            {"label": "ABORTED", "value": "ABORTED"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "runs",
                    "type": "vec<string>",
                    "helper_text": "List of run objects",
                },
                {
                    "field": "run_ids",
                    "type": "vec<string>",
                    "helper_text": "List of run IDs",
                },
                {
                    "field": "actor_ids",
                    "type": "vec<string>",
                    "helper_text": "List of actor IDs",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of run statuses",
                },
                {
                    "field": "started_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of start timestamps",
                },
                {
                    "field": "finished_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of finish timestamps",
                },
                {
                    "field": "dataset_ids",
                    "type": "vec<string>",
                    "helper_text": "List of dataset IDs",
                },
                {
                    "field": "exit_codes",
                    "type": "vec<string>",
                    "helper_text": "List of exit codes",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of runs",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of runs in this response",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "helper_text": "Offset used for pagination",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "helper_text": "Limit used for pagination",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_user_runs",
            "task_name": "tasks.apify.list_user_runs",
            "description": "List multiple runs for the authenticated user",
            "label": "List User Runs",
            "input_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "offset",
                "desc",
                "status",
            ],
            "required": [],
        },
        "list_user_runs**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 0,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Max number of results to return",
                }
            ],
            "outputs": [],
        },
        "list_user_runs**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_user_runs**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Days",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_user_runs**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_actor_runs**(*)**(*)": {
            "inputs": [
                {
                    "field": "actor_id",
                    "type": "string",
                    "value": "",
                    "label": "Actor ID",
                    "placeholder": "Select actor",
                    "helper_text": "Actor ID or a tilde-separated username and Actor name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=actor_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "value": 0,
                    "label": "Offset",
                    "helper_text": "Number of items to skip at the start",
                },
                {
                    "field": "desc",
                    "type": "bool",
                    "value": True,
                    "label": "Descending",
                    "helper_text": "Whether to sort by startedAt in descending order",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "helper_text": "Filter by run status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": ""},
                            {"label": "ABORTED", "value": "ABORTED"},
                            {"label": "ABORTING", "value": "ABORTING"},
                            {"label": "FAILED", "value": "FAILED"},
                            {"label": "READY", "value": "READY"},
                            {"label": "RUNNING", "value": "RUNNING"},
                            {"label": "SUCCEEDED", "value": "SUCCEEDED"},
                            {"label": "TIMED-OUT", "value": "TIMED-OUT"},
                            {"label": "TIMING-OUT", "value": "TIMING-OUT"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "actor_id",
                    "type": "string",
                    "helper_text": "ID of the Actor",
                },
                {
                    "field": "runs",
                    "type": "vec<string>",
                    "helper_text": "List of run objects",
                },
                {
                    "field": "run_ids",
                    "type": "vec<string>",
                    "helper_text": "List of run IDs",
                },
                {
                    "field": "actor_ids",
                    "type": "vec<string>",
                    "helper_text": "List of actor IDs",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of run statuses",
                },
                {
                    "field": "started_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of start timestamps",
                },
                {
                    "field": "finished_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of finish timestamps",
                },
                {
                    "field": "dataset_ids",
                    "type": "vec<string>",
                    "helper_text": "List of dataset IDs",
                },
                {
                    "field": "exit_codes",
                    "type": "vec<string>",
                    "helper_text": "List of exit codes",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of runs",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of runs in this response",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "helper_text": "Offset used for pagination",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "helper_text": "Limit used for pagination",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_actor_runs",
            "task_name": "tasks.apify.list_actor_runs",
            "description": "List all runs for a specific Actor",
            "label": "List Actor Runs",
            "input_sort_order": [
                "integration",
                "action",
                "actor_id",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "offset",
                "desc",
                "status",
            ],
            "required": ["actor_id"],
        },
        "list_actor_runs**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Max number of results to return",
                }
            ],
            "outputs": [],
        },
        "list_actor_runs**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_actor_runs**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Days",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_actor_runs**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "run_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "Select task",
                    "helper_text": "Task ID or a tilde-separated username and task name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "input",
                    "type": "string",
                    "value": "{}",
                    "label": "Input JSON",
                    "placeholder": '{"startUrls":[{"url": "https://example.com"}]}',
                    "helper_text": "Custom input JSON. If empty, uses task-defined input",
                },
                {
                    "field": "wait_for_finish",
                    "type": "bool",
                    "value": True,
                    "label": "Wait for Finish",
                    "helper_text": "Whether to wait for the run to finish before continuing",
                },
                {
                    "field": "timeout",
                    "type": "int32",
                    "value": 0,
                    "label": "Timeout",
                    "placeholder": "3600",
                    "helper_text": "Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)",
                },
                {
                    "field": "memory",
                    "type": "int32",
                    "value": 1024,
                    "label": "Memory",
                    "placeholder": "1024",
                    "helper_text": "Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)",
                },
                {
                    "field": "build",
                    "type": "string",
                    "value": "",
                    "label": "Build Tag",
                    "placeholder": "latest",
                    "helper_text": "Actor build to run. Defaults to task settings",
                },
            ],
            "outputs": [
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the task that was run",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the run",
                },
                {
                    "field": "started_at",
                    "type": "timestamp",
                    "helper_text": "When the run started",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the run finished (if completed)",
                },
                {
                    "field": "stopped_at",
                    "type": "timestamp",
                    "helper_text": "When the run was stopped (if stopped)",
                },
                {
                    "field": "exit_code",
                    "type": "int32",
                    "helper_text": "Exit code of the run",
                },
                {
                    "field": "default_dataset_id",
                    "type": "string",
                    "helper_text": "ID of the default dataset created by the run",
                },
                {
                    "field": "default_key_value_store_id",
                    "type": "string",
                    "helper_text": "ID of the default key-value store",
                },
                {
                    "field": "default_request_queue_id",
                    "type": "string",
                    "helper_text": "ID of the default request queue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "run_task",
            "task_name": "tasks.apify.run_task",
            "description": "Execute a predefined Actor task",
            "label": "Run Task",
            "input_sort_order": [
                "integration",
                "action",
                "task_id",
                "input",
                "wait_for_finish",
                "timeout",
                "memory",
                "build",
            ],
            "required": ["task_id"],
        },
        "run_task_and_list_dataset**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "Select task",
                    "helper_text": "Task ID or a tilde-separated username and task name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "input",
                    "type": "string",
                    "value": "{}",
                    "label": "Input JSON",
                    "placeholder": '{"startUrls":[{"url": "https://example.com"}]}',
                    "helper_text": "Custom input JSON. If empty, uses task-defined input",
                },
                {
                    "field": "timeout",
                    "type": "int32",
                    "value": 0,
                    "label": "Timeout",
                    "placeholder": "3600",
                    "helper_text": "Optional timeout for the run, in seconds. Example: 3600 (1 hour). Set to 0 or leave empty for no timeout (only sent to API if value > 0)",
                },
                {
                    "field": "memory",
                    "type": "int32",
                    "value": 1024,
                    "label": "Memory",
                    "placeholder": "1024",
                    "helper_text": "Memory limit for the run, in megabytes. Example: 1024 (1GB), 2048 (2GB), 4096 (4GB)",
                },
                {
                    "field": "build",
                    "type": "string",
                    "value": "",
                    "label": "Build Tag",
                    "placeholder": "latest",
                    "helper_text": "Actor build to run. Defaults to task settings",
                },
            ],
            "outputs": [
                {
                    "field": "run_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the run",
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the task that was run",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the run",
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "helper_text": "ID of the dataset containing results",
                },
                {
                    "field": "dataset_items",
                    "type": "vec<string>",
                    "helper_text": "Items from the dataset",
                },
                {
                    "field": "total_items",
                    "type": "int32",
                    "helper_text": "Total number of items in the dataset",
                },
                {
                    "field": "started_at",
                    "type": "timestamp",
                    "helper_text": "When the run started",
                },
                {
                    "field": "finished_at",
                    "type": "timestamp",
                    "helper_text": "When the run finished",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
                {
                    "field": "dataset_raw_data",
                    "type": "string",
                    "helper_text": "Raw dataset response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "run_task_and_list_dataset",
            "task_name": "tasks.apify.run_task_and_list_dataset",
            "description": "Execute a task, wait for completion, and retrieve the dataset items",
            "label": "Run Task and List Dataset",
            "input_sort_order": [
                "integration",
                "action",
                "task_id",
                "input",
                "timeout",
                "memory",
                "build",
            ],
            "required": ["task_id"],
        },
        "list_dataset_items**(*)**(*)": {
            "inputs": [
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset ID",
                    "placeholder": "Select dataset",
                    "helper_text": "Dataset ID or username~dataset-name",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter items by creation date",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "value": 0,
                    "label": "Offset",
                    "helper_text": "Number of items to skip at the start",
                },
            ],
            "outputs": [
                {
                    "field": "dataset_id",
                    "type": "string",
                    "helper_text": "ID of the dataset",
                },
                {
                    "field": "items",
                    "type": "vec<string>",
                    "helper_text": "List of dataset items",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of items in the dataset",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of items in this response",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "helper_text": "Offset used for pagination",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "helper_text": "Limit used for pagination",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_dataset_items",
            "task_name": "tasks.apify.list_dataset_items",
            "description": "List items from a dataset",
            "label": "List Dataset Items",
            "input_sort_order": [
                "integration",
                "action",
                "dataset_id",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "offset",
            ],
            "required": ["dataset_id"],
        },
        "list_dataset_items**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Max number of results to return",
                }
            ],
            "outputs": [],
        },
        "list_dataset_items**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_dataset_items**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Days",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_dataset_items**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_key_value_store_record**(*)**(*)": {
            "inputs": [
                {
                    "field": "store_id",
                    "type": "string",
                    "value": "",
                    "label": "Store ID",
                    "placeholder": "Select store",
                    "helper_text": "The ID of the Key-Value Store",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=store_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "key",
                    "type": "string",
                    "value": "",
                    "label": "Record Key",
                    "placeholder": "Select key",
                    "helper_text": "The key of the record to be retrieved",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=key&store_id={inputs.store_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "store_id",
                    "type": "string",
                    "helper_text": "ID of the key-value store",
                },
                {
                    "field": "key",
                    "type": "string",
                    "helper_text": "The key of the record",
                },
                {
                    "field": "value",
                    "type": "string",
                    "helper_text": "The value of the record",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_key_value_store_record",
            "task_name": "tasks.apify.list_key_value_store_record",
            "description": "Retrieve a specific record by key from a Key-Value Store",
            "label": "List Key-Value Store Record",
            "input_sort_order": ["integration", "action", "store_id", "key"],
            "required": ["store_id", "key"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        actor_id: str = "",
        build: str = "",
        dataset_id: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Days",
        },
        desc: bool = True,
        exact_date: TimeRange = {"start": "", "end": ""},
        input: str = "{}",
        key: str = "",
        memory: int = 1024,
        num_messages: int = 0,
        offset: int = 0,
        run_id: str = "",
        status: str = "SUCCEEDED",
        store_id: str = "",
        task_id: str = "",
        timeout: int = 0,
        url: str = "",
        wait_for_finish: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_apify",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if actor_id is not None:
            self.inputs["actor_id"] = actor_id
        if input is not None:
            self.inputs["input"] = input
        if wait_for_finish is not None:
            self.inputs["wait_for_finish"] = wait_for_finish
        if timeout is not None:
            self.inputs["timeout"] = timeout
        if memory is not None:
            self.inputs["memory"] = memory
        if build is not None:
            self.inputs["build"] = build
        if url is not None:
            self.inputs["url"] = url
        if run_id is not None:
            self.inputs["run_id"] = run_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if offset is not None:
            self.inputs["offset"] = offset
        if desc is not None:
            self.inputs["desc"] = desc
        if status is not None:
            self.inputs["status"] = status
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if task_id is not None:
            self.inputs["task_id"] = task_id
        if dataset_id is not None:
            self.inputs["dataset_id"] = dataset_id
        if store_id is not None:
            self.inputs["store_id"] = store_id
        if key is not None:
            self.inputs["key"] = key
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationApifyNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
