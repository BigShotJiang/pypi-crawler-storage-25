"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import ColumnItem


@Node.register_node_type("csv_reader")
class CsvReaderNode(Node):
    """
    Read the contents from a CSV file and output a list of the data for each column.

    ## Inputs
    ### Common Inputs
        file_type: The type of file to read.
        is_file_variable: The is_file_variable input
        processed_outputs: The processed_outputs input
        selected_file: The file to read.
    ### When file_type = 'CSV' and is_file_variable = False
        columns: Define the name(s) of the columns that you want to read
    ### When file_type = 'CSV' and is_file_variable = True
        manual_columns: Define the name(s) of the columns that you want to read
    ### When file_type = 'EXCEL' and is_file_variable = True
        manual_columns: Define the name(s) of the columns that you want to read
        sheet: The Excel sheet to read from.
    ### When file_type = 'EXCEL' and is_file_variable = False
        sheet: The Excel sheet to read from.
        sheets: The sheets input

    ## Outputs
    ### Common Outputs
        [processed_outputs]: The [processed_outputs] output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "file_type",
            "helper_text": "The type of file to read.",
            "value": "CSV",
            "type": "string",
        },
        {
            "field": "is_file_variable",
            "helper_text": "The is_file_variable input",
            "value": True,
            "type": "bool",
        },
        {
            "field": "processed_outputs",
            "helper_text": "The processed_outputs input",
            "value": {},
            "type": "map<string, string>",
        },
        {
            "field": "selected_file",
            "helper_text": "The file to read.",
            "value": "",
            "type": "file",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "[processed_outputs]",
            "helper_text": "The [processed_outputs] output",
            "type": "",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "CSV**false": {
            "inputs": [
                {
                    "field": "columns",
                    "type": "vec<interface{id: string, column: string}>",
                    "value": [],
                    "label": "Columns to read",
                    "helper_text": "Define the name(s) of the columns that you want to read",
                    "component": {
                        "hide_general_input_label": True,
                        "list_item_label": "Column $i to read",
                        "type": "dropdown",
                        "source": "endpoint",
                        "endpoint_config": {
                            "url": "/files/function-specific-params/csv-reader/read-columns",
                            "depends_on": ["selected_file"],
                            "params": {
                                "file_id": "{{selected_file.id}}",
                                "sheet_name": "{{selected_file.metadata.name}}",
                            },
                            "response_key": "outputs",
                            "option_value_key": "name",
                        },
                        "processed_field": "processed_outputs",
                        "processed_key_field": "name",
                        "processed_value_field": "type",
                        "processed_value_default": "vec<string>",
                        "hidden_from_ui": True,
                    },
                }
            ],
            "outputs": [],
        },
        "CSV**true": {
            "inputs": [
                {
                    "field": "manual_columns",
                    "type": "vec<interface{id: string, column: string}>",
                    "value": [{"id": "column_1", "column": ""}],
                    "label": "Columns to read",
                    "helper_text": "Define the name(s) of the columns that you want to read",
                    "component": {
                        "type": "table",
                        "decorators": {"hide": ["general_input_label", "variable_type"]},
                        "vertical_table_layout": True,
                        "processed_field": "processed_outputs",
                        "processed_key_field": "column",
                        "processed_value_default": "vec<string>",
                        "list_button_label": "Add Column",
                        "table": {"column": {"label": "Column name"}},
                    },
                }
            ],
            "outputs": [],
        },
        "EXCEL**false": {
            "inputs": [
                {
                    "field": "sheet",
                    "type": "string",
                    "label": "Sheet",
                    "helper_text": "The Excel sheet to read from.",
                    "component": {
                        "type": "dropdown",
                        "source": "endpoint",
                        "endpoint_config": {
                            "url": "/files/function-specific-params/excel-reader/read-sheets",
                            "depends_on": ["selected_file"],
                            "params": {"file_id": "{{selected_file.id}}"},
                            "response_key": "sheets",
                        },
                    },
                },
                {
                    "field": "sheets",
                    "type": "vec<string>",
                    "value": [],
                    "visibility": False,
                    "component": {"type": "text", "default_itemize": False},
                },
            ],
            "outputs": [],
        },
        "EXCEL**true": {
            "inputs": [
                {
                    "field": "sheet",
                    "type": "string",
                    "label": "Sheet",
                    "helper_text": "The Excel sheet to read from.",
                },
                {
                    "field": "manual_columns",
                    "type": "vec<interface{id: string, column: string}>",
                    "value": [{"id": "column_1", "column": ""}],
                    "label": "Columns to read",
                    "helper_text": "Define the name(s) of the columns that you want to read",
                    "component": {
                        "type": "table",
                        "decorators": {"hide": ["general_input_label", "variable_type"]},
                        "vertical_table_layout": True,
                        "processed_field": "processed_outputs",
                        "processed_key_field": "column",
                        "processed_value_default": "vec<string>",
                        "list_button_label": "Add Column",
                        "table": {"column": {"label": "Column name"}},
                    },
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["file_type", "is_file_variable"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["selected_file", "sheet"]

    def __init__(
        self,
        file_type: str = "CSV",
        is_file_variable: bool = True,
        columns: List[ColumnItem] = [],
        manual_columns: List[ColumnItem] = [{"id": "column_1", "column": ""}],
        processed_outputs: Dict[str, str] = {},
        selected_file: str = "",
        sheet: Optional[str] = None,
        sheets: List[str] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["file_type"] = file_type
        params["is_file_variable"] = is_file_variable

        super().__init__(
            node_type="csv_reader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file_type is not None:
            self.inputs["file_type"] = file_type
        if is_file_variable is not None:
            self.inputs["is_file_variable"] = is_file_variable
        if selected_file is not None:
            self.inputs["selected_file"] = selected_file
        if processed_outputs is not None:
            self.inputs["processed_outputs"] = processed_outputs
        if columns is not None:
            self.inputs["columns"] = columns
        if manual_columns is not None:
            self.inputs["manual_columns"] = manual_columns
        if sheet is not None:
            self.inputs["sheet"] = sheet
        if sheets is not None:
            self.inputs["sheets"] = sheets
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CsvReaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
