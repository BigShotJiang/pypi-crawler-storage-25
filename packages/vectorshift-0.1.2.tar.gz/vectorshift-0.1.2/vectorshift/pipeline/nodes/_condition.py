"""
Manually written ConditionNode with type-safe condition building.

This file is NOT auto-generated. It provides:
- Operator enum matching frontend OPERATOR_MAP
- Clause and ConditionGroup data classes
- ConditionNode with dynamic path outputs
"""

from enum import Enum
from typing import Any, Dict, List, Optional, Union

from ..node import Node, NodeOutputs
from ..node_output import NodeOutput


class Operator(str, Enum):
    """Comparison operators for condition clauses.

    Values match the frontend ConditionNode.tsx OPERATOR_MAP.
    """

    # Comparison operators
    EQUAL = "Equal"
    NOT_EQUAL = "NotEqual"
    GREATER_THAN = "GreaterThan"
    LESS_THAN = "LessThan"
    GREATER_THAN_EQUAL = "GreaterThanEqual"
    LESS_THAN_EQUAL = "LessThanEqual"

    # Text operators
    TEXT_CONTAINS = "TextContains"
    TEXT_DOES_NOT_CONTAIN = "TextDoesNotContains"
    TEXT_STARTS_WITH = "TextStartsWith"
    TEXT_DOES_NOT_START_WITH = "TextDoesNotStartWith"
    TEXT_ENDS_WITH = "TextEndsWith"
    TEXT_DOES_NOT_END_WITH = "TextDoesNotEndWith"
    TEXT_GREATER_THAN_N_CHARS = "TextGreaterThanNCharacters"
    TEXT_LESS_THAN_N_CHARS = "TextLessThanNCharacters"

    # Unary operators (no second operand)
    IS_EMPTY = "IsEmpty"
    IS_NOT_EMPTY = "IsNotEmpty"
    IS_TRUE = "IsTrue"
    IS_FALSE = "IsFalse"

    # List operators
    VEC_CONTAINS = "VecContainsItem"
    VEC_DOES_NOT_CONTAIN = "VecDoesNotContainsItem"

    # Map operators
    MAP_CONTAINS_KEY = "MapContainsKey"

    # Expression operator (unary)
    EXPRESSION = "Expression"


UNARY_OPERATORS = frozenset(
    {
        Operator.IS_EMPTY,
        Operator.IS_NOT_EMPTY,
        Operator.IS_TRUE,
        Operator.IS_FALSE,
        Operator.EXPRESSION,
    }
)


class LogicalOp(str, Enum):
    """Logical operators for joining clauses within a group."""

    AND = "AND"
    OR = "OR"


class Clause:
    """A single condition clause with an operator and one or two operands.

    For binary operators, both operand1 and operand2 are required.
    For unary operators (IsEmpty, IsNotEmpty, IsTrue, IsFalse, Expression),
    only operand1 is used.
    """

    def __init__(
        self,
        operator: Operator,
        operand1: Union[str, int, float, NodeOutput],
        operand2: Union[str, int, float, NodeOutput, None] = None,
    ):
        if operator not in UNARY_OPERATORS and operand2 is None:
            raise ValueError(f"Operator {operator.value} requires operand2")
        self.operator = operator
        self.operand1 = operand1
        self.operand2 = operand2 if operator not in UNARY_OPERATORS else None

    def to_dict(self) -> dict:
        d = {
            "operand1": self.operand1,
            "operator": self.operator.value,
            "termType": "Clause",
        }
        if self.operator not in UNARY_OPERATORS:
            d["operand2"] = f"{self.operand2}"
        return d

    def __repr__(self) -> str:
        if self.operator in UNARY_OPERATORS:
            return f"Clause({self.operator.value}, {self.operand1!r})"
        return f"Clause({self.operator.value}, " f"{self.operand1!r}, {self.operand2!r})"


class ConditionGroup:
    """A group of clauses joined by AND/OR logical operators.

    Each group represents one "If" or "Else If" branch.
    The number of operators must be exactly len(clauses) - 1.
    """

    def __init__(
        self,
        clauses: List[Clause],
        operators: Optional[List[LogicalOp]] = None,
    ):
        if not clauses:
            raise ValueError("ConditionGroup must have at least one clause")
        if operators is None:
            operators = [LogicalOp.AND] * (len(clauses) - 1)
        if len(operators) != len(clauses) - 1:
            raise ValueError(
                f"Expected {len(clauses) - 1} operators, " f"got {len(operators)}"
            )
        self.clauses = clauses
        self.operators = operators

    def to_dict(self) -> dict:
        return {
            "terms": [c.to_dict() for c in self.clauses],
            "operators": [op.value for op in self.operators],
        }

    def __repr__(self) -> str:
        return (
            f"ConditionGroup(clauses={self.clauses!r}, " f"operators={self.operators!r})"
        )


@Node.register_node_type("condition")
class ConditionNode(Node):
    """Condition node for branching pipeline execution.

    Each ConditionGroup defines a path (If / Else If). An implicit
    "Else" path (path_else) is always present.

    Outputs are automatically named path_0, path_1, ..., path_else,
    plus 'complete', matching the frontend behaviour.

    Example::

        cond = ConditionNode(
            node_name='check',
            conditions=[
                ConditionGroup([
                    Clause(Operator.GREATER_THAN, input_node.output, 10),
                ]),
                ConditionGroup([
                    Clause(Operator.IS_EMPTY, input_node.output),
                ]),
            ],
        )
        # Access outputs:
        cond.path_0       # NodeOutput for first condition path (If)
        cond.path_1       # NodeOutput for second condition path (Else If)
        cond.path_else    # NodeOutput for else path
        cond.complete     # NodeOutput for completion
    """

    _COMMON_INPUTS = [
        {
            "field": "conditions",
            "type": (
                "vec<interface{operators: vec<string>, " "terms: vec<map<string, any>>}>"
            ),
            "value": [],
        },
        {
            "field": "outputs",
            "type": "map<string, string>",
            "value": {},
        },
    ]
    _COMMON_OUTPUTS = [
        {"field": "complete", "type": "any"},
    ]
    _CONFIGS = {}
    _PARAMS = []
    _advanced_inputs = True
    _batch_mode_allowed = False

    def __init__(
        self,
        id: Optional[str] = None,
        node_name: Optional[str] = None,
        conditions: Optional[List[ConditionGroup]] = None,
        outputs: Optional[Dict[str, str]] = None,
        dependencies: Optional[List[str]] = None,
        **kwargs,
    ):
        super().__init__(
            node_type="condition",
            params={},
            id=id,
            node_name=node_name,
            execution_mode="normal",
        )

        groups = conditions or []

        # Serialize conditions
        self.inputs["conditions"] = [g.to_dict() for g in groups]

        # Build outputs map: path_0, path_1, ..., path_else
        # (matches frontend ConditionNode.tsx behaviour)
        if outputs is not None:
            outputs_map = outputs
        else:
            outputs_map = {f"path_{i}": "path" for i in range(len(groups))}
            outputs_map["path_else"] = "path"
        self.inputs["outputs"] = outputs_map

        # Register dynamic outputs
        self._dynamic_outputs = dict(outputs_map)
        self.outputs = list(self._dynamic_outputs.keys()) + ["complete"]

        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        if kwargs:
            self.update_inputs(**kwargs)

        self.set_node_task_name()

    def __getattr__(self, name: str):
        if name.startswith('_'):
            raise AttributeError(name)
        if hasattr(self, '_dynamic_outputs') and name in self._dynamic_outputs:
            return NodeOutput(
                f"{{{{ {self.id}.{name} }}}}",
                source_type="path",
                source_node_id=self.id,
                source_field=name,
            )
        return super().__getattr__(name)

    @classmethod
    def from_dict(cls, data: dict) -> "ConditionNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        node = cls(
            id=id,
            node_name=name,
            outputs=inputs.get("outputs"),
            conditions=None,
            dependencies=inputs.get("dependencies"),
        )
        # Restore raw conditions from serialized data since
        # conditions=None would set self.inputs["conditions"] = []
        if "conditions" in inputs:
            node.inputs["conditions"] = inputs["conditions"]
        return node
