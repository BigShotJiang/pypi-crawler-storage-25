"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("post_message")
class PostMessageNode(Node):
    """
    Post a message to a session

    ## Inputs
    ### Common Inputs
        message: The message content to post
        session_id: The session ID to post to

    ## Outputs
    ### Common Outputs
        status: Status of the post operation
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "message",
            "helper_text": "The message content to post",
            "value": "",
            "type": "string",
        },
        {
            "field": "session_id",
            "helper_text": "The session ID to post to",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "status",
            "helper_text": "Status of the post operation",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["session_id", "message"]

    def __init__(
        self,
        message: str = "",
        session_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="post_message",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if session_id is not None:
            self.inputs["session_id"] = session_id
        if message is not None:
            self.inputs["message"] = message
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "PostMessageNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
