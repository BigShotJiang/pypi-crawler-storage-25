"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("arxiv")
class ArxivNode(Node):
    """
    Query ARXIV to return relevant articles

    ## Inputs
    ### Common Inputs
        query: The ARXIV query
        chunk_text: Whether to chunk the text
    ### When chunk_text = True
        chunk_overlap: The overlap of the chunks
        chunk_size: The size of the chunks to create

    ## Outputs
    ### When chunk_text = True
        output: List of raw text from the ARXIV article
    ### When chunk_text = False
        output: The raw text from the ARXIV article
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "The ARXIV query",
            "value": "",
            "type": "string",
        },
        {
            "field": "chunk_text",
            "helper_text": "Whether to chunk the text",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true": {
            "inputs": [
                {
                    "field": "chunk_size",
                    "type": "int32",
                    "value": 512,
                    "helper_text": "The size of the chunks to create",
                    "label": "Chunk Size",
                    "component": {
                        "type": "int32",
                        "slider": True,
                        "min": 1,
                        "max": 4096,
                        "step": 1,
                        "is_advanced_setting": True,
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                },
                {
                    "field": "chunk_overlap",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "The overlap of the chunks",
                    "label": "Chunk Overlap",
                    "component": {
                        "type": "int32",
                        "slider": True,
                        "min": 0,
                        "max": 4095,
                        "step": 1,
                        "is_advanced_setting": True,
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<string>",
                    "helper_text": "List of raw text from the ARXIV article",
                }
            ],
        },
        "false": {
            "inputs": [],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "The raw text from the ARXIV article",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["chunk_text"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["query"]

    def __init__(
        self,
        chunk_text: bool = False,
        query: str = "",
        chunk_overlap: int = 0,
        chunk_size: int = 512,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["chunk_text"] = chunk_text

        super().__init__(
            node_type="arxiv",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if query is not None:
            self.inputs["query"] = query
        if chunk_text is not None:
            self.inputs["chunk_text"] = chunk_text
        if chunk_size is not None:
            self.inputs["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            self.inputs["chunk_overlap"] = chunk_overlap
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ArxivNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
