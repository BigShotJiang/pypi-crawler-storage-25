"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_pager_duty")
class IntegrationPagerDutyNode(Node):
    """
    Pager Duty

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Pager Duty account
    ### When action = 'create_incident'
        assignees: User to assign to the incident. Note: Ignored if Escalation Policy is set (PagerDuty API constraint)
        conference_number: Conference bridge phone number (optional)
        conference_url: Conference bridge URL (optional)
        details: Additional details about the incident (optional)
        escalation_policy_id: The escalation policy for the incident. Note: If set, assignees will be ignored (PagerDuty API constraint)
        incident_key: A unique identifier for the incident (optional)
        priority_id: The priority of the incident (optional)
        service_id: The service the incident is associated with
        title: A brief description of the incident
        urgency: The urgency of the incident
    ### When action = 'update_incident'
        assignees: User to assign to the incident. Note: Ignored if Escalation Policy is set (PagerDuty API constraint)
        escalation_policy_id: The escalation policy for the incident. Note: If set, assignees will be ignored (PagerDuty API constraint)
        incident_id: Select the incident to retrieve
        priority_id: The priority of the incident (optional)
        resolution: Resolution notes (when resolving)
        status: New status for the incident
        title: A brief description of the incident
        urgency: The urgency of the incident
    ### When action = 'create_incident_note'
        content: The content of the note
        incident_id: Select the incident to retrieve
    ### When action = 'list_incidents' and use_date = True and use_exact_date = False
        date_range: Pick the relative date range
    ### When action = 'list_log_entries' and use_date = True and use_exact_date = False
        date_range: Pick the relative date range
    ### When action = 'list_incidents' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'list_log_entries' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_incident'
        incident_id: Select the incident to retrieve
    ### When action = 'list_incident_notes'
        incident_id: Select the incident to retrieve
    ### When action = 'get_log_entry'
        include: Additional resources to include
        log_entry_id: The ID of the log entry to retrieve
        time_zone: Time zone for timestamps
    ### When action = 'list_log_entries'
        include: Additional resources to include
        is_overview: Return only overview log entries
        return_all: Fetch all incidents matching the criteria (ignores limit)
        time_zone: Time zone for timestamps
        use_date: Toggle to use dates
    ### When action = 'get_user'
        include: Additional resources to include
        user_id: The ID of the user to retrieve
    ### When action = 'list_incidents' and use_date = False
        limit: Maximum number of incidents to return (default: 10)
    ### When action = 'list_log_entries' and use_date = False
        limit: Maximum number of incidents to return (default: 10)
    ### When action = 'list_incidents'
        return_all: Fetch all incidents matching the criteria (ignores limit)
        service_ids: Filter by service IDs (comma-separated, optional)
        sort_by: Field to sort by (created_at, incident_number, resolved_at, urgency)
        sort_order: Sort order (asc/desc)
        statuses: Filter by incident statuses (comma-separated: triggered, acknowledged, resolved)
        urgencies: Filter by urgency (comma-separated: high, low)
        use_date: Toggle to use dates
        user_ids: Filter by assigned user IDs (comma-separated, optional)
    ### When action = 'list_incidents' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_log_entries' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'create_incident'
        acknowledgement_ids: IDs of users who acknowledged
        acknowledgement_names: Names of users who acknowledged
        alert_count_all: Total count of alerts
        alert_count_resolved: Count of resolved alerts
        alert_count_triggered: Count of triggered alerts
        assignee_ids: IDs of assigned users
        assignee_names: Names of assigned users
        conference_number: Conference bridge phone number
        conference_url: Conference bridge URL
        created_at: When the incident was created
        description: Detailed description/body of the incident
        escalation_policy_id: ID of the escalation policy
        escalation_policy_name: Name of the escalation policy
        html_url: URL to the incident in PagerDuty
        incident_id: The ID of the created incident
        incident_key: The unique incident key
        incident_number: The incident number
        is_mergeable: Whether the incident can be merged
        last_status_change_at: When the status was last changed
        last_status_change_by_id: ID of user who last changed the status
        last_status_change_by_name: Name of user who last changed the status
        priority_id: ID of the priority
        priority_name: Name of the priority
        raw_data: Raw API response data
        self: API URL of the incident
        service_id: ID of the associated service
        service_name: Name of the associated service
        service_url: URL to the service in PagerDuty
        status: The status of the incident (triggered, acknowledged, resolved)
        summary: A short summary of the incident
        team_ids: IDs of associated teams
        team_names: Names of associated teams
        title: The title of the incident
        updated_at: When the incident was last updated
        urgency: The urgency level of the incident (high, low)
    ### When action = 'get_incident'
        acknowledgement_ids: IDs of users who acknowledged
        acknowledgement_names: Names of users who acknowledged
        alert_count_all: Total count of alerts
        alert_count_resolved: Count of resolved alerts
        alert_count_triggered: Count of triggered alerts
        assignee_ids: IDs of assigned users
        assignee_names: Names of assigned users
        conference_number: Conference bridge phone number
        conference_url: Conference bridge URL
        created_at: When the incident was created
        description: Detailed description/body of the incident
        escalation_policy_id: ID of the escalation policy
        escalation_policy_name: Name of the escalation policy
        html_url: URL to the incident in PagerDuty
        incident_id: The ID of the incident
        incident_key: The unique incident key
        incident_number: The incident number
        is_mergeable: Whether the incident can be merged
        last_status_change_at: When the status was last changed
        last_status_change_by_id: ID of user who last changed the status
        last_status_change_by_name: Name of user who last changed the status
        priority_id: ID of the priority
        priority_name: Name of the priority
        raw_data: Raw API response data
        self: API URL of the incident
        service_id: ID of the associated service
        service_name: Name of the associated service
        service_url: URL to the service in PagerDuty
        status: The status of the incident (triggered, acknowledged, resolved)
        summary: A short summary of the incident
        team_ids: IDs of associated teams
        team_names: Names of associated teams
        title: The title of the incident
        updated_at: When the incident was last updated
        urgency: The urgency level of the incident (high, low)
    ### When action = 'update_incident'
        acknowledgement_ids: IDs of users who acknowledged
        acknowledgement_names: Names of users who acknowledged
        alert_count_all: Total count of alerts
        alert_count_resolved: Count of resolved alerts
        alert_count_triggered: Count of triggered alerts
        assignee_ids: IDs of assigned users
        assignee_names: Names of assigned users
        conference_number: Conference bridge phone number
        conference_url: Conference bridge URL
        created_at: When the incident was created
        description: Detailed description/body of the incident
        escalation_policy_id: ID of the escalation policy
        escalation_policy_name: Name of the escalation policy
        html_url: URL to the incident in PagerDuty
        incident_id: The ID of the updated incident
        incident_key: The unique incident key
        incident_number: The incident number
        is_mergeable: Whether the incident can be merged
        last_status_change_at: When the status was last changed
        last_status_change_by_id: ID of user who last changed the status
        last_status_change_by_name: Name of user who last changed the status
        priority_id: ID of the priority
        priority_name: Name of the priority
        raw_data: Raw API response data
        self: API URL of the incident
        service_id: ID of the associated service
        service_name: Name of the associated service
        service_url: URL to the service in PagerDuty
        status: The status of the incident (triggered, acknowledged, resolved)
        summary: A short summary of the incident
        team_ids: IDs of associated teams
        team_names: Names of associated teams
        title: The title of the incident
        updated_at: When the incident was last updated
        urgency: The urgency level of the incident (high, low)
    ### When action = 'get_log_entry'
        agent_html_url: URL to the agent in PagerDuty
        agent_id: ID of the agent (user/service) that created the entry
        agent_name: Name of the agent
        agent_type: Type of agent (user_reference, service_reference)
        channel: Channel information (JSON)
        contexts: Contextual information (JSON string)
        created_at: When the log entry was created
        event_details: Event details description
        html_url: URL to the log entry in PagerDuty
        incident_html_url: URL to the associated incident
        incident_id: ID of the associated incident
        incident_summary: Summary of the associated incident
        log_entry_id: The ID of the log entry
        raw_data: Raw API response data
        self: API URL of the log entry
        service_html_url: URL to the associated service
        service_id: ID of the associated service
        service_name: Name of the associated service
        summary: Summary of the log entry
        team_ids: IDs of associated teams
        team_names: Names of associated teams
        type: The type of log entry (e.g., trigger, acknowledge, resolve)
    ### When action = 'list_log_entries'
        agent_ids: List of agent IDs
        agent_names: List of agent names
        agent_types: List of agent types
        created_at_list: List of creation timestamps
        has_more: Whether more log entries are available
        html_urls: List of PagerDuty URLs
        incident_ids: List of associated incident IDs
        incident_summaries: List of associated incident summaries
        log_entries: List of log entries (JSON objects)
        log_entry_ids: List of log entry IDs
        log_entry_summaries: List of log entry summaries
        log_entry_types: List of log entry types
        raw_data: Raw API response data
        service_ids: List of associated service IDs
        service_names: List of associated service names
        total_count: Total number of log entries returned
    ### When action = 'get_user'
        avatar_url: URL to the user's avatar image
        color: The color associated with the user
        contact_methods: User's contact methods (JSON string)
        description: Description of the user
        email: The email address of the user
        html_url: URL to the user profile in PagerDuty
        invitation_sent: Whether an invitation has been sent
        job_title: The user's job title
        name: The full name of the user
        notification_rules: User's notification rules (JSON string)
        raw_data: Raw API response data
        role: The role of the user (admin, user, limited_user, observer, owner, read_only_user, read_only_limited_user, restricted_access)
        self: API URL of the user
        summary: A short summary of the user
        team_ids: IDs of teams the user belongs to
        team_names: Names of teams the user belongs to
        time_zone: The user's time zone
        type: The type of user (user, bot_user)
        user_id: The ID of the user
    ### When action = 'create_incident_note'
        content: The content of the note
        created_at: When the note was created
        note_id: The ID of the created note
        raw_data: Raw API response data
        user_html_url: URL to the user profile in PagerDuty
        user_id: ID of the user who created the note
        user_name: Name of the user who created the note
    ### When action = 'list_incidents'
        created_at_list: List of creation timestamps
        escalation_policy_ids: List of escalation policy IDs
        escalation_policy_names: List of escalation policy names
        has_more: Whether more incidents are available
        html_urls: List of PagerDuty URLs
        incident_ids: List of incident IDs
        incident_keys: List of incident keys
        incident_numbers: List of incident numbers
        incident_statuses: List of incident statuses
        incident_summaries: List of incident summaries
        incident_titles: List of incident titles
        incident_urgencies: List of incident urgencies
        incidents: List of incidents (JSON objects)
        last_status_change_at_list: List of last status change timestamps
        priority_ids: List of priority IDs
        priority_names: List of priority names
        raw_data: Raw API response data
        service_ids: List of service IDs
        service_names: List of service names
        total_count: Total number of incidents returned
        updated_at_list: List of last update timestamps
    ### When action = 'list_incident_notes'
        created_at_list: List of creation timestamps
        note_contents: List of note contents
        note_ids: List of note IDs
        notes: List of notes (JSON objects)
        raw_data: Raw API response data
        total_count: Total number of notes
        user_ids: List of user IDs who created the notes
        user_names: List of user names who created the notes
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Pager Duty account",
            "value": None,
            "type": "integration<Pager Duty>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "create_incident**(*)**(*)": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Server is down",
                    "helper_text": "A brief description of the incident",
                },
                {
                    "field": "service_id",
                    "type": "string",
                    "value": "",
                    "label": "Service",
                    "helper_text": "The service the incident is associated with",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=service_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "value": "high",
                    "label": "Urgency",
                    "helper_text": "The urgency of the incident",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High", "value": "high"},
                            {"label": "Low", "value": "low"},
                        ],
                    },
                },
                {
                    "field": "incident_key",
                    "type": "string",
                    "value": "",
                    "label": "Incident Key",
                    "placeholder": "unique-incident-key",
                    "helper_text": "A unique identifier for the incident (optional)",
                },
                {
                    "field": "details",
                    "type": "string",
                    "value": "",
                    "label": "Details",
                    "placeholder": "Additional details about the incident...",
                    "helper_text": "Additional details about the incident (optional)",
                    "multiline": True,
                },
                {
                    "field": "escalation_policy_id",
                    "type": "string",
                    "value": "",
                    "label": "Escalation Policy",
                    "helper_text": "The escalation policy for the incident. Note: If set, assignees will be ignored (PagerDuty API constraint)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=escalation_policy_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "priority_id",
                    "type": "string",
                    "value": "",
                    "label": "Priority",
                    "helper_text": "The priority of the incident (optional)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=priority_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignees",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "helper_text": "User to assign to the incident. Note: Ignored if Escalation Policy is set (PagerDuty API constraint)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=assignees&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "conference_number",
                    "type": "string",
                    "value": "",
                    "label": "Conference Number",
                    "placeholder": "+1-555-555-5555",
                    "helper_text": "Conference bridge phone number (optional)",
                },
                {
                    "field": "conference_url",
                    "type": "string",
                    "value": "",
                    "label": "Conference URL",
                    "placeholder": "https://meet.example.com/incident",
                    "helper_text": "Conference bridge URL (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The ID of the created incident",
                },
                {
                    "field": "incident_number",
                    "type": "int32",
                    "helper_text": "The incident number",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "The title of the incident",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "A short summary of the incident",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Detailed description/body of the incident",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the incident (triggered, acknowledged, resolved)",
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "helper_text": "The urgency level of the incident (high, low)",
                },
                {
                    "field": "incident_key",
                    "type": "string",
                    "helper_text": "The unique incident key",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the incident was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the incident was last updated",
                },
                {
                    "field": "last_status_change_at",
                    "type": "timestamp",
                    "helper_text": "When the status was last changed",
                },
                {
                    "field": "last_status_change_by_id",
                    "type": "string",
                    "helper_text": "ID of user who last changed the status",
                },
                {
                    "field": "last_status_change_by_name",
                    "type": "string",
                    "helper_text": "Name of user who last changed the status",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "URL to the incident in PagerDuty",
                },
                {
                    "field": "self",
                    "type": "string",
                    "helper_text": "API URL of the incident",
                },
                {
                    "field": "service_id",
                    "type": "string",
                    "helper_text": "ID of the associated service",
                },
                {
                    "field": "service_name",
                    "type": "string",
                    "helper_text": "Name of the associated service",
                },
                {
                    "field": "service_url",
                    "type": "string",
                    "helper_text": "URL to the service in PagerDuty",
                },
                {
                    "field": "escalation_policy_id",
                    "type": "string",
                    "helper_text": "ID of the escalation policy",
                },
                {
                    "field": "escalation_policy_name",
                    "type": "string",
                    "helper_text": "Name of the escalation policy",
                },
                {
                    "field": "priority_id",
                    "type": "string",
                    "helper_text": "ID of the priority",
                },
                {
                    "field": "priority_name",
                    "type": "string",
                    "helper_text": "Name of the priority",
                },
                {
                    "field": "assignee_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of assigned users",
                },
                {
                    "field": "assignee_names",
                    "type": "vec<string>",
                    "helper_text": "Names of assigned users",
                },
                {
                    "field": "acknowledgement_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of users who acknowledged",
                },
                {
                    "field": "acknowledgement_names",
                    "type": "vec<string>",
                    "helper_text": "Names of users who acknowledged",
                },
                {
                    "field": "team_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of associated teams",
                },
                {
                    "field": "team_names",
                    "type": "vec<string>",
                    "helper_text": "Names of associated teams",
                },
                {
                    "field": "alert_count_all",
                    "type": "int32",
                    "helper_text": "Total count of alerts",
                },
                {
                    "field": "alert_count_triggered",
                    "type": "int32",
                    "helper_text": "Count of triggered alerts",
                },
                {
                    "field": "alert_count_resolved",
                    "type": "int32",
                    "helper_text": "Count of resolved alerts",
                },
                {
                    "field": "is_mergeable",
                    "type": "bool",
                    "helper_text": "Whether the incident can be merged",
                },
                {
                    "field": "conference_number",
                    "type": "string",
                    "helper_text": "Conference bridge phone number",
                },
                {
                    "field": "conference_url",
                    "type": "string",
                    "helper_text": "Conference bridge URL",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_incident",
            "task_name": "tasks.pager_duty.create_incident",
            "description": "Create a new incident in PagerDuty",
            "label": "Create Incident",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "title",
                "service_id",
                "urgency",
                "incident_key",
                "details",
                "escalation_policy_id",
                "priority_id",
                "assignees",
                "conference_number",
                "conference_url",
            ],
            "required": ["title", "service_id"],
        },
        "get_incident**(*)**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident",
                    "helper_text": "Select the incident to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=incident_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The ID of the incident",
                },
                {
                    "field": "incident_number",
                    "type": "int32",
                    "helper_text": "The incident number",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "The title of the incident",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "A short summary of the incident",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Detailed description/body of the incident",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the incident (triggered, acknowledged, resolved)",
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "helper_text": "The urgency level of the incident (high, low)",
                },
                {
                    "field": "incident_key",
                    "type": "string",
                    "helper_text": "The unique incident key",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the incident was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the incident was last updated",
                },
                {
                    "field": "last_status_change_at",
                    "type": "timestamp",
                    "helper_text": "When the status was last changed",
                },
                {
                    "field": "last_status_change_by_id",
                    "type": "string",
                    "helper_text": "ID of user who last changed the status",
                },
                {
                    "field": "last_status_change_by_name",
                    "type": "string",
                    "helper_text": "Name of user who last changed the status",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "URL to the incident in PagerDuty",
                },
                {
                    "field": "self",
                    "type": "string",
                    "helper_text": "API URL of the incident",
                },
                {
                    "field": "service_id",
                    "type": "string",
                    "helper_text": "ID of the associated service",
                },
                {
                    "field": "service_name",
                    "type": "string",
                    "helper_text": "Name of the associated service",
                },
                {
                    "field": "service_url",
                    "type": "string",
                    "helper_text": "URL to the service in PagerDuty",
                },
                {
                    "field": "escalation_policy_id",
                    "type": "string",
                    "helper_text": "ID of the escalation policy",
                },
                {
                    "field": "escalation_policy_name",
                    "type": "string",
                    "helper_text": "Name of the escalation policy",
                },
                {
                    "field": "priority_id",
                    "type": "string",
                    "helper_text": "ID of the priority",
                },
                {
                    "field": "priority_name",
                    "type": "string",
                    "helper_text": "Name of the priority",
                },
                {
                    "field": "assignee_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of assigned users",
                },
                {
                    "field": "assignee_names",
                    "type": "vec<string>",
                    "helper_text": "Names of assigned users",
                },
                {
                    "field": "acknowledgement_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of users who acknowledged",
                },
                {
                    "field": "acknowledgement_names",
                    "type": "vec<string>",
                    "helper_text": "Names of users who acknowledged",
                },
                {
                    "field": "team_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of associated teams",
                },
                {
                    "field": "team_names",
                    "type": "vec<string>",
                    "helper_text": "Names of associated teams",
                },
                {
                    "field": "alert_count_all",
                    "type": "int32",
                    "helper_text": "Total count of alerts",
                },
                {
                    "field": "alert_count_triggered",
                    "type": "int32",
                    "helper_text": "Count of triggered alerts",
                },
                {
                    "field": "alert_count_resolved",
                    "type": "int32",
                    "helper_text": "Count of resolved alerts",
                },
                {
                    "field": "is_mergeable",
                    "type": "bool",
                    "helper_text": "Whether the incident can be merged",
                },
                {
                    "field": "conference_number",
                    "type": "string",
                    "helper_text": "Conference bridge phone number",
                },
                {
                    "field": "conference_url",
                    "type": "string",
                    "helper_text": "Conference bridge URL",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_incident",
            "task_name": "tasks.pager_duty.get_incident",
            "description": "Retrieve details of a specific incident from PagerDuty",
            "label": "Get Incident",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "incident_id"],
            "required": ["incident_id"],
        },
        "list_incidents**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "statuses",
                    "type": "string",
                    "value": "",
                    "label": "Statuses",
                    "helper_text": "Filter by incident statuses (comma-separated: triggered, acknowledged, resolved)",
                    "hidden": True,
                },
                {
                    "field": "service_ids",
                    "type": "string",
                    "value": "",
                    "label": "Service IDs",
                    "helper_text": "Filter by service IDs (comma-separated, optional)",
                    "hidden": True,
                },
                {
                    "field": "user_ids",
                    "type": "string",
                    "value": "",
                    "label": "User IDs",
                    "helper_text": "Filter by assigned user IDs (comma-separated, optional)",
                    "hidden": True,
                },
                {
                    "field": "urgencies",
                    "type": "string",
                    "value": "",
                    "label": "Urgencies",
                    "helper_text": "Filter by urgency (comma-separated: high, low)",
                    "hidden": True,
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "created_at",
                    "label": "Sort By",
                    "placeholder": "created_at",
                    "helper_text": "Field to sort by (created_at, incident_number, resolved_at, urgency)",
                    "hidden": True,
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order (asc/desc)",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Descending", "value": "desc"},
                            {"label": "Ascending", "value": "asc"},
                        ],
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Fetch all incidents matching the criteria (ignores limit)",
                    "hidden": True,
                },
            ],
            "outputs": [
                {
                    "field": "incidents",
                    "type": "vec<string>",
                    "helper_text": "List of incidents (JSON objects)",
                },
                {
                    "field": "incident_ids",
                    "type": "vec<string>",
                    "helper_text": "List of incident IDs",
                },
                {
                    "field": "incident_numbers",
                    "type": "vec<int32>",
                    "helper_text": "List of incident numbers",
                },
                {
                    "field": "incident_titles",
                    "type": "vec<string>",
                    "helper_text": "List of incident titles",
                },
                {
                    "field": "incident_summaries",
                    "type": "vec<string>",
                    "helper_text": "List of incident summaries",
                },
                {
                    "field": "incident_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of incident statuses",
                },
                {
                    "field": "incident_urgencies",
                    "type": "vec<string>",
                    "helper_text": "List of incident urgencies",
                },
                {
                    "field": "incident_keys",
                    "type": "vec<string>",
                    "helper_text": "List of incident keys",
                },
                {
                    "field": "created_at_list",
                    "type": "vec<string>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "updated_at_list",
                    "type": "vec<string>",
                    "helper_text": "List of last update timestamps",
                },
                {
                    "field": "last_status_change_at_list",
                    "type": "vec<string>",
                    "helper_text": "List of last status change timestamps",
                },
                {
                    "field": "html_urls",
                    "type": "vec<string>",
                    "helper_text": "List of PagerDuty URLs",
                },
                {
                    "field": "service_ids",
                    "type": "vec<string>",
                    "helper_text": "List of service IDs",
                },
                {
                    "field": "service_names",
                    "type": "vec<string>",
                    "helper_text": "List of service names",
                },
                {
                    "field": "escalation_policy_ids",
                    "type": "vec<string>",
                    "helper_text": "List of escalation policy IDs",
                },
                {
                    "field": "escalation_policy_names",
                    "type": "vec<string>",
                    "helper_text": "List of escalation policy names",
                },
                {
                    "field": "priority_ids",
                    "type": "vec<string>",
                    "helper_text": "List of priority IDs",
                },
                {
                    "field": "priority_names",
                    "type": "vec<string>",
                    "helper_text": "List of priority names",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of incidents returned",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether more incidents are available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_incidents",
            "task_name": "tasks.pager_duty.list_incidents",
            "description": "Retrieve a list of incidents from PagerDuty with optional filters",
            "label": "List Incidents",
            "input_sort_order": [
                "action",
                "integration",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "limit",
                "statuses",
                "service_ids",
                "user_ids",
                "urgencies",
                "sort_by",
                "sort_order",
                "return_all",
            ],
            "required": ["limit"],
        },
        "list_incidents**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Maximum number of incidents to return (default: 10)",
                }
            ],
            "outputs": [],
        },
        "list_incidents**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_incidents**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "Pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_incidents**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "update_incident**(*)**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident",
                    "helper_text": "Select the incident to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=incident_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "helper_text": "New status for the incident",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Triggered", "value": "triggered"},
                            {"label": "Acknowledged", "value": "acknowledged"},
                            {"label": "Resolved", "value": "resolved"},
                        ],
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Updated incident title",
                    "helper_text": "New title for the incident (optional)",
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "value": "",
                    "label": "Urgency",
                    "helper_text": "New urgency level (optional)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High", "value": "high"},
                            {"label": "Low", "value": "low"},
                        ],
                    },
                },
                {
                    "field": "resolution",
                    "type": "string",
                    "value": "",
                    "label": "Resolution",
                    "placeholder": "Issue was resolved by...",
                    "helper_text": "Resolution notes (when resolving)",
                },
                {
                    "field": "escalation_policy_id",
                    "type": "string",
                    "value": "",
                    "label": "Escalation Policy",
                    "helper_text": "New escalation policy. Note: If set, assignees will be ignored (PagerDuty API constraint)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=escalation_policy_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "priority_id",
                    "type": "string",
                    "value": "",
                    "label": "Priority",
                    "helper_text": "New priority (optional)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=priority_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignees",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "helper_text": "New user to assign. Note: Ignored if Escalation Policy is set (PagerDuty API constraint)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=assignees&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The ID of the updated incident",
                },
                {
                    "field": "incident_number",
                    "type": "int32",
                    "helper_text": "The incident number",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "The title of the incident",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "A short summary of the incident",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Detailed description/body of the incident",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the incident (triggered, acknowledged, resolved)",
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "helper_text": "The urgency level of the incident (high, low)",
                },
                {
                    "field": "incident_key",
                    "type": "string",
                    "helper_text": "The unique incident key",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the incident was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the incident was last updated",
                },
                {
                    "field": "last_status_change_at",
                    "type": "timestamp",
                    "helper_text": "When the status was last changed",
                },
                {
                    "field": "last_status_change_by_id",
                    "type": "string",
                    "helper_text": "ID of user who last changed the status",
                },
                {
                    "field": "last_status_change_by_name",
                    "type": "string",
                    "helper_text": "Name of user who last changed the status",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "URL to the incident in PagerDuty",
                },
                {
                    "field": "self",
                    "type": "string",
                    "helper_text": "API URL of the incident",
                },
                {
                    "field": "service_id",
                    "type": "string",
                    "helper_text": "ID of the associated service",
                },
                {
                    "field": "service_name",
                    "type": "string",
                    "helper_text": "Name of the associated service",
                },
                {
                    "field": "service_url",
                    "type": "string",
                    "helper_text": "URL to the service in PagerDuty",
                },
                {
                    "field": "escalation_policy_id",
                    "type": "string",
                    "helper_text": "ID of the escalation policy",
                },
                {
                    "field": "escalation_policy_name",
                    "type": "string",
                    "helper_text": "Name of the escalation policy",
                },
                {
                    "field": "priority_id",
                    "type": "string",
                    "helper_text": "ID of the priority",
                },
                {
                    "field": "priority_name",
                    "type": "string",
                    "helper_text": "Name of the priority",
                },
                {
                    "field": "assignee_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of assigned users",
                },
                {
                    "field": "assignee_names",
                    "type": "vec<string>",
                    "helper_text": "Names of assigned users",
                },
                {
                    "field": "acknowledgement_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of users who acknowledged",
                },
                {
                    "field": "acknowledgement_names",
                    "type": "vec<string>",
                    "helper_text": "Names of users who acknowledged",
                },
                {
                    "field": "team_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of associated teams",
                },
                {
                    "field": "team_names",
                    "type": "vec<string>",
                    "helper_text": "Names of associated teams",
                },
                {
                    "field": "alert_count_all",
                    "type": "int32",
                    "helper_text": "Total count of alerts",
                },
                {
                    "field": "alert_count_triggered",
                    "type": "int32",
                    "helper_text": "Count of triggered alerts",
                },
                {
                    "field": "alert_count_resolved",
                    "type": "int32",
                    "helper_text": "Count of resolved alerts",
                },
                {
                    "field": "is_mergeable",
                    "type": "bool",
                    "helper_text": "Whether the incident can be merged",
                },
                {
                    "field": "conference_number",
                    "type": "string",
                    "helper_text": "Conference bridge phone number",
                },
                {
                    "field": "conference_url",
                    "type": "string",
                    "helper_text": "Conference bridge URL",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_incident",
            "task_name": "tasks.pager_duty.update_incident",
            "description": "Update an existing incident in PagerDuty",
            "label": "Update Incident",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "incident_id",
                "status",
                "title",
                "urgency",
                "resolution",
                "escalation_policy_id",
                "priority_id",
                "assignees",
            ],
            "required": ["incident_id"],
        },
        "create_incident_note**(*)**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident",
                    "helper_text": "Select the incident to add a note to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=incident_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "content",
                    "type": "string",
                    "value": "",
                    "label": "Note Content",
                    "placeholder": "Investigation notes...",
                    "helper_text": "The content of the note",
                    "multiline": True,
                },
            ],
            "outputs": [
                {
                    "field": "note_id",
                    "type": "string",
                    "helper_text": "The ID of the created note",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "The content of the note",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the note was created",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "ID of the user who created the note",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the note",
                },
                {
                    "field": "user_html_url",
                    "type": "string",
                    "helper_text": "URL to the user profile in PagerDuty",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_incident_note",
            "task_name": "tasks.pager_duty.create_incident_note",
            "description": "Add a note to an incident in PagerDuty",
            "label": "Create Incident Note",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "incident_id", "content"],
            "required": ["incident_id", "content"],
        },
        "list_incident_notes**(*)**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident",
                    "helper_text": "Select the incident to list notes for",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=incident_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of notes (JSON objects)",
                },
                {
                    "field": "note_ids",
                    "type": "vec<string>",
                    "helper_text": "List of note IDs",
                },
                {
                    "field": "note_contents",
                    "type": "vec<string>",
                    "helper_text": "List of note contents",
                },
                {
                    "field": "created_at_list",
                    "type": "vec<string>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs who created the notes",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user names who created the notes",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of notes",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_incident_notes",
            "task_name": "tasks.pager_duty.list_incident_notes",
            "description": "Retrieve all notes for an incident from PagerDuty",
            "label": "List Incident Notes",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "incident_id"],
            "required": ["incident_id"],
        },
        "get_log_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "log_entry_id",
                    "type": "string",
                    "value": "",
                    "label": "Log Entry ID",
                    "placeholder": "PXXXXXX",
                    "helper_text": "The ID of the log entry to retrieve",
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "helper_text": "Additional resources to include",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Incidents", "value": "incidents"},
                            {"label": "Services", "value": "services"},
                            {"label": "Channels", "value": "channels"},
                            {"label": "Teams", "value": "teams"},
                        ],
                    },
                },
                {
                    "field": "time_zone",
                    "type": "string",
                    "value": "",
                    "label": "Time Zone",
                    "helper_text": "Time zone for timestamps",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
            ],
            "outputs": [
                {
                    "field": "log_entry_id",
                    "type": "string",
                    "helper_text": "The ID of the log entry",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "The type of log entry (e.g., trigger, acknowledge, resolve)",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "Summary of the log entry",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the log entry was created",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "URL to the log entry in PagerDuty",
                },
                {
                    "field": "self",
                    "type": "string",
                    "helper_text": "API URL of the log entry",
                },
                {
                    "field": "agent_id",
                    "type": "string",
                    "helper_text": "ID of the agent (user/service) that created the entry",
                },
                {
                    "field": "agent_type",
                    "type": "string",
                    "helper_text": "Type of agent (user_reference, service_reference)",
                },
                {
                    "field": "agent_name",
                    "type": "string",
                    "helper_text": "Name of the agent",
                },
                {
                    "field": "agent_html_url",
                    "type": "string",
                    "helper_text": "URL to the agent in PagerDuty",
                },
                {
                    "field": "channel",
                    "type": "string",
                    "helper_text": "Channel information (JSON)",
                },
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "ID of the associated incident",
                },
                {
                    "field": "incident_summary",
                    "type": "string",
                    "helper_text": "Summary of the associated incident",
                },
                {
                    "field": "incident_html_url",
                    "type": "string",
                    "helper_text": "URL to the associated incident",
                },
                {
                    "field": "service_id",
                    "type": "string",
                    "helper_text": "ID of the associated service",
                },
                {
                    "field": "service_name",
                    "type": "string",
                    "helper_text": "Name of the associated service",
                },
                {
                    "field": "service_html_url",
                    "type": "string",
                    "helper_text": "URL to the associated service",
                },
                {
                    "field": "team_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of associated teams",
                },
                {
                    "field": "team_names",
                    "type": "vec<string>",
                    "helper_text": "Names of associated teams",
                },
                {
                    "field": "event_details",
                    "type": "string",
                    "helper_text": "Event details description",
                },
                {
                    "field": "contexts",
                    "type": "string",
                    "helper_text": "Contextual information (JSON string)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_log_entry",
            "task_name": "tasks.pager_duty.get_log_entry",
            "description": "Retrieve details of a specific log entry from PagerDuty",
            "label": "Get Log Entry",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "log_entry_id",
                "include",
                "time_zone",
            ],
            "required": ["log_entry_id"],
        },
        "list_log_entries**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "is_overview",
                    "type": "bool",
                    "value": False,
                    "label": "Overview Only",
                    "helper_text": "Return only overview log entries",
                    "hidden": True,
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "helper_text": "Additional resources to include",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Incidents", "value": "incidents"},
                            {"label": "Services", "value": "services"},
                            {"label": "Channels", "value": "channels"},
                            {"label": "Teams", "value": "teams"},
                        ],
                    },
                },
                {
                    "field": "time_zone",
                    "type": "string",
                    "value": "",
                    "label": "Time Zone",
                    "helper_text": "Time zone for timestamps",
                    "hidden": True,
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Fetch all log entries matching the criteria (ignores limit)",
                    "hidden": True,
                },
            ],
            "outputs": [
                {
                    "field": "log_entries",
                    "type": "vec<string>",
                    "helper_text": "List of log entries (JSON objects)",
                },
                {
                    "field": "log_entry_ids",
                    "type": "vec<string>",
                    "helper_text": "List of log entry IDs",
                },
                {
                    "field": "log_entry_types",
                    "type": "vec<string>",
                    "helper_text": "List of log entry types",
                },
                {
                    "field": "log_entry_summaries",
                    "type": "vec<string>",
                    "helper_text": "List of log entry summaries",
                },
                {
                    "field": "created_at_list",
                    "type": "vec<string>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "html_urls",
                    "type": "vec<string>",
                    "helper_text": "List of PagerDuty URLs",
                },
                {
                    "field": "agent_ids",
                    "type": "vec<string>",
                    "helper_text": "List of agent IDs",
                },
                {
                    "field": "agent_types",
                    "type": "vec<string>",
                    "helper_text": "List of agent types",
                },
                {
                    "field": "agent_names",
                    "type": "vec<string>",
                    "helper_text": "List of agent names",
                },
                {
                    "field": "incident_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated incident IDs",
                },
                {
                    "field": "incident_summaries",
                    "type": "vec<string>",
                    "helper_text": "List of associated incident summaries",
                },
                {
                    "field": "service_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated service IDs",
                },
                {
                    "field": "service_names",
                    "type": "vec<string>",
                    "helper_text": "List of associated service names",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of log entries returned",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether more log entries are available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_log_entries",
            "task_name": "tasks.pager_duty.list_log_entries",
            "description": "Retrieve a list of log entries from PagerDuty with optional filters",
            "label": "List Log Entries",
            "input_sort_order": [
                "action",
                "integration",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "limit",
                "is_overview",
                "include",
                "time_zone",
                "return_all",
            ],
            "required": ["limit"],
        },
        "list_log_entries**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Maximum number of log entries to return (default: 10)",
                }
            ],
            "outputs": [],
        },
        "list_log_entries**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_log_entries**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "Pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_log_entries**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "PXXXXXX",
                    "helper_text": "The ID of the user to retrieve",
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "helper_text": "Additional resources to include",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Contact Methods", "value": "contact_methods"},
                            {
                                "label": "Notification Rules",
                                "value": "notification_rules",
                            },
                            {"label": "Teams", "value": "teams"},
                            {"label": "Subdomains", "value": "subdomains"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The ID of the user",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "The type of user (user, bot_user)",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The full name of the user",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "A short summary of the user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "The email address of the user",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "The role of the user (admin, user, limited_user, observer, owner, read_only_user, read_only_limited_user, restricted_access)",
                },
                {
                    "field": "time_zone",
                    "type": "string",
                    "helper_text": "The user's time zone",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "The color associated with the user",
                },
                {
                    "field": "avatar_url",
                    "type": "string",
                    "helper_text": "URL to the user's avatar image",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the user",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "helper_text": "The user's job title",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "URL to the user profile in PagerDuty",
                },
                {
                    "field": "self",
                    "type": "string",
                    "helper_text": "API URL of the user",
                },
                {
                    "field": "invitation_sent",
                    "type": "bool",
                    "helper_text": "Whether an invitation has been sent",
                },
                {
                    "field": "team_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of teams the user belongs to",
                },
                {
                    "field": "team_names",
                    "type": "vec<string>",
                    "helper_text": "Names of teams the user belongs to",
                },
                {
                    "field": "contact_methods",
                    "type": "string",
                    "helper_text": "User's contact methods (JSON string)",
                },
                {
                    "field": "notification_rules",
                    "type": "string",
                    "helper_text": "User's notification rules (JSON string)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.pager_duty.get_user",
            "description": "Retrieve details of a specific user from PagerDuty",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "user_id", "include"],
            "required": ["user_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        assignees: str = "",
        conference_number: str = "",
        conference_url: str = "",
        content: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        details: str = "",
        escalation_policy_id: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        incident_id: str = "",
        incident_key: str = "",
        include: str = "",
        is_overview: bool = False,
        limit: int = 10,
        log_entry_id: str = "",
        priority_id: str = "",
        resolution: str = "",
        return_all: bool = False,
        service_id: str = "",
        service_ids: str = "",
        sort_by: str = "created_at",
        sort_order: str = "desc",
        status: str = "",
        statuses: str = "",
        time_zone: str = "",
        title: str = "",
        urgencies: str = "",
        urgency: str = "high",
        user_id: str = "",
        user_ids: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_pager_duty",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if title is not None:
            self.inputs["title"] = title
        if service_id is not None:
            self.inputs["service_id"] = service_id
        if urgency is not None:
            self.inputs["urgency"] = urgency
        if incident_key is not None:
            self.inputs["incident_key"] = incident_key
        if details is not None:
            self.inputs["details"] = details
        if escalation_policy_id is not None:
            self.inputs["escalation_policy_id"] = escalation_policy_id
        if priority_id is not None:
            self.inputs["priority_id"] = priority_id
        if assignees is not None:
            self.inputs["assignees"] = assignees
        if conference_number is not None:
            self.inputs["conference_number"] = conference_number
        if conference_url is not None:
            self.inputs["conference_url"] = conference_url
        if incident_id is not None:
            self.inputs["incident_id"] = incident_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if statuses is not None:
            self.inputs["statuses"] = statuses
        if service_ids is not None:
            self.inputs["service_ids"] = service_ids
        if user_ids is not None:
            self.inputs["user_ids"] = user_ids
        if urgencies is not None:
            self.inputs["urgencies"] = urgencies
        if sort_by is not None:
            self.inputs["sort_by"] = sort_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if status is not None:
            self.inputs["status"] = status
        if resolution is not None:
            self.inputs["resolution"] = resolution
        if content is not None:
            self.inputs["content"] = content
        if log_entry_id is not None:
            self.inputs["log_entry_id"] = log_entry_id
        if include is not None:
            self.inputs["include"] = include
        if time_zone is not None:
            self.inputs["time_zone"] = time_zone
        if is_overview is not None:
            self.inputs["is_overview"] = is_overview
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationPagerDutyNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
