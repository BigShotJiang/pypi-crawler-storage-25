"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_docusign")
class IntegrationDocusignNode(Node):
    """
    DocuSign

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Docusign account
    ### When action = 'update_envelope'
        add_cc_email: Add a new CC recipient
        add_cc_name: Name of the new CC recipient
        add_documents: Add more documents to a draft envelope
        add_signer_email: Add a new signer to a draft envelope
        add_signer_name: Name of the new signer
        email_blurb: Body text of the envelope email
        email_subject: Subject line of the envelope email
        envelope_id: The envelope ID (UUID format) - get this from List Envelopes or Docusign
        purge_state: Purge documents from the envelope
        resend_envelope: Resend email notifications to recipients
        status: Send immediately or save as draft
        voided_reason: Reason for voiding (required when status is voided)
    ### When action = 'create_envelope'
        add_date_signed: Add a date signed field next to signature
        add_signature: Add a signature field for the first signer
        cc_emails: Email(s) to receive a copy (comma-separated)
        cc_names: Name(s) of CC recipients (comma-separated, same order as emails)
        documents: Files to be signed (PDF, Word, etc.)
        email_blurb: Body text of the envelope email
        email_subject: Subject line of the envelope email
        expire_after: Number of days until envelope expires (0 = use account default)
        expire_enabled: Enable envelope expiration
        expire_warn: Days before expiration to warn signers (0 = use account default)
        reminder_delay: Days to wait before sending first reminder (0 = use account default)
        reminder_enabled: Send automatic reminders to signers
        reminder_frequency: Days between reminder emails (0 = use account default)
        signature_anchor: Text in document to place signature near (overrides position)
        signature_position: Where to place the signature on the first page
        signer_can_sign_on_mobile: Allow signers to sign on mobile devices
        signer_emails: Email address(es) of signers (comma-separated for multiple)
        signer_names: Full name(s) of signers (comma-separated, same order as emails)
        status: Send immediately or save as draft
        template_id: Use a Docusign template instead of uploading documents
        template_role_name: Role name from the template (e.g., Signer, Approver)
    ### When action = 'list_envelopes' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_envelope'
        envelope_id: The envelope ID (UUID format) - get this from List Envelopes or Docusign
        include: Additional data to include (comma-separated: recipients, documents, custom_fields)
    ### When action = 'send_envelope'
        envelope_id: The envelope ID (UUID format) - get this from List Envelopes or Docusign
    ### When action = 'list_envelopes' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_envelopes'
        folder_ids: Filter by folder IDs (comma-separated)
        include: Additional data to include (comma-separated: recipients, documents, custom_fields)
        order: Sort order
        order_by: Field to sort by (e.g., created, sent, completed)
        search_text: Search text to filter envelopes
        status: Send immediately or save as draft
        use_date: Toggle to use date filtering
    ### When action = 'list_envelopes' and use_date = False
        limit: Maximum number of envelopes to return (default: 10)
    ### When action = 'list_envelopes' and use_date = True
        limit: Maximum number of envelopes to return (default: 10)
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'get_envelope'
        completed_date_time: When the envelope was completed
        created_date_time: When the envelope was created
        declined_date_time: When the envelope was declined
        delivered_date_time: When the envelope was delivered
        email_blurb: Body text of the envelope email
        email_subject: Subject line of the envelope
        envelope_id: Unique identifier of the envelope
        raw_data: Raw API response data
        recipients: JSON array of recipients with their status
        sender_email: Email of the sender
        sender_name: Name of the sender
        sent_date_time: When the envelope was sent
        signers_completed: Number of signers who have signed
        signers_count: Number of signers
        status: Current status of the envelope
        voided_date_time: When the envelope was voided
        voided_reason: Reason for voiding the envelope
    ### When action = 'list_envelopes'
        completed_date_times: List of completion timestamps
        created_date_times: List of creation timestamps
        email_subjects: List of envelope subjects
        envelope_ids: List of envelope IDs
        envelopes: List of envelope details (JSON strings)
        raw_data: Raw API response data
        sender_emails: List of sender emails
        sender_names: List of sender names
        sent_date_times: List of sent timestamps
        statuses: List of envelope statuses
        total_count: Total number of envelopes returned
    ### When action = 'update_envelope'
        documents_added: Number of documents added
        email_subject: Subject line of the envelope
        envelope_id: Unique identifier of the updated envelope
        raw_data: Raw API response data
        recipients_added: Number of recipients added
        status: Updated status of the envelope
    ### When action = 'create_envelope'
        documents_count: Number of documents attached
        email_subject: Subject line that was set
        envelope_id: Unique identifier of the created envelope
        raw_data: Raw API response data
        signers_count: Number of signers added
        status: Status of the envelope (created, sent)
        status_date_time: When the status was last updated
        uri: Relative URI of the envelope
    ### When action = 'send_envelope'
        envelope_id: Unique identifier of the sent envelope
        raw_data: Raw API response data
        status: Status of the envelope (will be 'sent')
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Docusign account",
            "value": None,
            "type": "integration<Docusign>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "create_envelope**(*)**(*)": {
            "inputs": [
                {
                    "field": "email_subject",
                    "type": "string",
                    "value": "",
                    "label": "Email Subject",
                    "placeholder": "Please sign this document",
                    "helper_text": "Subject line of the envelope email",
                },
                {
                    "field": "email_blurb",
                    "type": "string",
                    "value": "",
                    "multiline": True,
                    "label": "Email Message",
                    "placeholder": "Please review and sign the attached document",
                    "helper_text": "Body text of the envelope email",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "created",
                    "label": "Status",
                    "helper_text": "Send immediately or save as draft",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "created", "label": "Draft"},
                            {"value": "sent", "label": "Send Immediately"},
                        ],
                    },
                },
                {
                    "field": "signer_emails",
                    "type": "string",
                    "value": "",
                    "label": "Signer Email(s)",
                    "placeholder": "signer@example.com, signer2@example.com",
                    "helper_text": "Email address(es) of signers (comma-separated for multiple)",
                },
                {
                    "field": "signer_names",
                    "type": "string",
                    "value": "",
                    "label": "Signer Name(s)",
                    "placeholder": "John Doe, Jane Smith",
                    "helper_text": "Full name(s) of signers (comma-separated, same order as emails)",
                },
                {
                    "field": "documents",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Documents",
                    "helper_text": "Files to be signed (PDF, Word, etc.)",
                },
                {
                    "field": "add_signature",
                    "type": "bool",
                    "value": True,
                    "label": "Add Signature Field",
                    "helper_text": "Add a signature field for the first signer",
                },
                {
                    "field": "signature_position",
                    "type": "string",
                    "value": "bottom_left",
                    "label": "Signature Position",
                    "helper_text": "Where to place the signature on the first page",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "bottom_left", "label": "Bottom Left"},
                            {"value": "bottom_center", "label": "Bottom Center"},
                            {"value": "bottom_right", "label": "Bottom Right"},
                            {"value": "top_left", "label": "Top Left"},
                            {"value": "top_center", "label": "Top Center"},
                            {"value": "top_right", "label": "Top Right"},
                        ],
                    },
                },
                {
                    "field": "signature_anchor",
                    "type": "string",
                    "value": "",
                    "label": "Signature Anchor Text",
                    "placeholder": "/sig1/",
                    "helper_text": "Text in document to place signature near (overrides position)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "add_date_signed",
                    "type": "bool",
                    "value": False,
                    "label": "Add Date Signed Field",
                    "helper_text": "Add a date signed field next to signature",
                    "is_advanced_setting": True,
                },
                {
                    "field": "cc_emails",
                    "type": "string",
                    "value": "",
                    "label": "CC Email(s)",
                    "placeholder": "manager@example.com, team@example.com",
                    "helper_text": "Email(s) to receive a copy (comma-separated)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "cc_names",
                    "type": "string",
                    "value": "",
                    "label": "CC Name(s)",
                    "placeholder": "Manager Name, Team Lead",
                    "helper_text": "Name(s) of CC recipients (comma-separated, same order as emails)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "template_id",
                    "type": "string",
                    "value": "",
                    "label": "Template",
                    "helper_text": "Use a Docusign template instead of uploading documents",
                    "is_advanced_setting": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=template_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "template_role_name",
                    "type": "string",
                    "value": "",
                    "label": "Template Role",
                    "placeholder": "Signer",
                    "helper_text": "Role name from the template (e.g., Signer, Approver)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "expire_enabled",
                    "type": "bool",
                    "value": False,
                    "label": "Enable Expiration",
                    "helper_text": "Enable envelope expiration",
                    "is_advanced_setting": True,
                },
                {
                    "field": "expire_after",
                    "type": "int32",
                    "value": 0,
                    "label": "Expire After (days)",
                    "placeholder": "120",
                    "helper_text": "Number of days until envelope expires (0 = use account default)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "expire_warn",
                    "type": "int32",
                    "value": 0,
                    "label": "Expiration Warning (days)",
                    "placeholder": "3",
                    "helper_text": "Days before expiration to warn signers (0 = use account default)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "reminder_enabled",
                    "type": "bool",
                    "value": False,
                    "label": "Enable Reminders",
                    "helper_text": "Send automatic reminders to signers",
                    "is_advanced_setting": True,
                },
                {
                    "field": "reminder_delay",
                    "type": "int32",
                    "value": 0,
                    "label": "Reminder Delay (days)",
                    "placeholder": "1",
                    "helper_text": "Days to wait before sending first reminder (0 = use account default)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "reminder_frequency",
                    "type": "int32",
                    "value": 0,
                    "label": "Reminder Frequency (days)",
                    "placeholder": "1",
                    "helper_text": "Days between reminder emails (0 = use account default)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "signer_can_sign_on_mobile",
                    "type": "bool",
                    "value": False,
                    "label": "Allow Mobile Signing",
                    "helper_text": "Allow signers to sign on mobile devices",
                    "is_advanced_setting": True,
                },
            ],
            "outputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created envelope",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the envelope (created, sent)",
                },
                {
                    "field": "uri",
                    "type": "string",
                    "helper_text": "Relative URI of the envelope",
                },
                {
                    "field": "status_date_time",
                    "type": "timestamp",
                    "helper_text": "When the status was last updated",
                },
                {
                    "field": "email_subject",
                    "type": "string",
                    "helper_text": "Subject line that was set",
                },
                {
                    "field": "signers_count",
                    "type": "int32",
                    "helper_text": "Number of signers added",
                },
                {
                    "field": "documents_count",
                    "type": "int32",
                    "helper_text": "Number of documents attached",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_envelope",
            "task_name": "tasks.docusign.create_envelope",
            "description": "Create a new envelope",
            "label": "Create Envelope",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "email_subject",
                "email_blurb",
                "status",
                "signer_emails",
                "signer_names",
                "documents",
                "add_signature",
                "signature_position",
                "signature_anchor",
                "add_date_signed",
                "cc_emails",
                "cc_names",
                "template_id",
                "template_role_name",
                "expire_enabled",
                "expire_after",
                "expire_warn",
                "reminder_enabled",
                "reminder_delay",
                "reminder_frequency",
                "signer_can_sign_on_mobile",
            ],
            "required": ["email_subject"],
        },
        "get_envelope**(*)**(*)": {
            "inputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "value": "",
                    "label": "Envelope ID",
                    "placeholder": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                    "helper_text": "The envelope ID (UUID format) - get this from List Envelopes or Docusign",
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "placeholder": "recipients,documents",
                    "helper_text": "Additional data to include (comma-separated: recipients, documents, custom_fields)",
                },
            ],
            "outputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the envelope",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Current status of the envelope",
                },
                {
                    "field": "email_subject",
                    "type": "string",
                    "helper_text": "Subject line of the envelope",
                },
                {
                    "field": "email_blurb",
                    "type": "string",
                    "helper_text": "Body text of the envelope email",
                },
                {
                    "field": "sender_name",
                    "type": "string",
                    "helper_text": "Name of the sender",
                },
                {
                    "field": "sender_email",
                    "type": "string",
                    "helper_text": "Email of the sender",
                },
                {
                    "field": "created_date_time",
                    "type": "timestamp",
                    "helper_text": "When the envelope was created",
                },
                {
                    "field": "sent_date_time",
                    "type": "timestamp",
                    "helper_text": "When the envelope was sent",
                },
                {
                    "field": "delivered_date_time",
                    "type": "timestamp",
                    "helper_text": "When the envelope was delivered",
                },
                {
                    "field": "completed_date_time",
                    "type": "timestamp",
                    "helper_text": "When the envelope was completed",
                },
                {
                    "field": "declined_date_time",
                    "type": "timestamp",
                    "helper_text": "When the envelope was declined",
                },
                {
                    "field": "voided_date_time",
                    "type": "timestamp",
                    "helper_text": "When the envelope was voided",
                },
                {
                    "field": "voided_reason",
                    "type": "string",
                    "helper_text": "Reason for voiding the envelope",
                },
                {
                    "field": "signers_count",
                    "type": "int32",
                    "helper_text": "Number of signers",
                },
                {
                    "field": "signers_completed",
                    "type": "int32",
                    "helper_text": "Number of signers who have signed",
                },
                {
                    "field": "recipients",
                    "type": "string",
                    "helper_text": "JSON array of recipients with their status",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_envelope",
            "task_name": "tasks.docusign.get_envelope",
            "description": "Read details of an envelope",
            "label": "Get Envelope",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "envelope_id", "include"],
            "required": ["envelope_id"],
        },
        "list_envelopes**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use date filtering",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "helper_text": "Filter by envelope status",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "Any"},
                            {"value": "created", "label": "Created"},
                            {"value": "sent", "label": "Sent"},
                            {"value": "delivered", "label": "Delivered"},
                            {"value": "completed", "label": "Completed"},
                            {"value": "declined", "label": "Declined"},
                            {"value": "voided", "label": "Voided"},
                        ],
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "contract",
                    "helper_text": "Search text to filter envelopes",
                },
                {
                    "field": "order",
                    "type": "string",
                    "value": "desc",
                    "label": "Order",
                    "helper_text": "Sort order",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "desc", "label": "Descending"},
                            {"value": "asc", "label": "Ascending"},
                        ],
                    },
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "placeholder": "created",
                    "helper_text": "Field to sort by (e.g., created, sent, completed)",
                },
                {
                    "field": "folder_ids",
                    "type": "string",
                    "value": "",
                    "label": "Folder IDs",
                    "placeholder": "folder1,folder2",
                    "helper_text": "Filter by folder IDs (comma-separated)",
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "placeholder": "recipients",
                    "helper_text": "Additional data to include (recipients, documents, custom_fields)",
                },
            ],
            "outputs": [
                {
                    "field": "envelope_ids",
                    "type": "vec<string>",
                    "helper_text": "List of envelope IDs",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of envelope statuses",
                },
                {
                    "field": "email_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of envelope subjects",
                },
                {
                    "field": "sender_names",
                    "type": "vec<string>",
                    "helper_text": "List of sender names",
                },
                {
                    "field": "sender_emails",
                    "type": "vec<string>",
                    "helper_text": "List of sender emails",
                },
                {
                    "field": "created_date_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "sent_date_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of sent timestamps",
                },
                {
                    "field": "completed_date_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of completion timestamps",
                },
                {
                    "field": "envelopes",
                    "type": "vec<string>",
                    "helper_text": "List of envelope details (JSON strings)",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of envelopes returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_envelopes",
            "task_name": "tasks.docusign.list_envelopes",
            "description": "Get multiple envelopes",
            "label": "List Envelopes",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "limit",
                "status",
                "search_text",
                "order",
                "order_by",
                "folder_ids",
                "include",
            ],
            "required": ["limit"],
        },
        "list_envelopes**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Maximum number of envelopes to return (default: 10)",
                }
            ],
            "outputs": [],
        },
        "list_envelopes**true**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Limit",
                    "helper_text": "Maximum number of envelopes to return (default: 10)",
                },
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                },
            ],
            "outputs": [],
        },
        "list_envelopes**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_envelopes**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "update_envelope**(*)**(*)": {
            "inputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "value": "",
                    "label": "Envelope ID",
                    "placeholder": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                    "helper_text": "The envelope ID (UUID format) - get this from List Envelopes or Docusign",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "helper_text": "New status for the envelope",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "No Change"},
                            {"value": "sent", "label": "Sent"},
                            {"value": "voided", "label": "Voided"},
                            {"value": "deleted", "label": "Deleted"},
                        ],
                    },
                },
                {
                    "field": "email_subject",
                    "type": "string",
                    "value": "",
                    "label": "Email Subject",
                    "placeholder": "Updated subject",
                    "helper_text": "Update the subject line (optional)",
                },
                {
                    "field": "email_blurb",
                    "type": "string",
                    "value": "",
                    "multiline": True,
                    "label": "Email Message",
                    "placeholder": "Updated message",
                    "helper_text": "Update the email body text (optional)",
                },
                {
                    "field": "add_documents",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Add Documents",
                    "helper_text": "Add more documents to a draft envelope",
                },
                {
                    "field": "add_signer_email",
                    "type": "string",
                    "value": "",
                    "label": "Add Signer Email",
                    "placeholder": "newsigner@example.com",
                    "helper_text": "Add a new signer to a draft envelope",
                },
                {
                    "field": "add_signer_name",
                    "type": "string",
                    "value": "",
                    "label": "Add Signer Name",
                    "placeholder": "New Signer",
                    "helper_text": "Name of the new signer",
                },
                {
                    "field": "add_cc_email",
                    "type": "string",
                    "value": "",
                    "label": "Add CC Email",
                    "placeholder": "newcc@example.com",
                    "helper_text": "Add a new CC recipient",
                    "is_advanced_setting": True,
                },
                {
                    "field": "add_cc_name",
                    "type": "string",
                    "value": "",
                    "label": "Add CC Name",
                    "placeholder": "New CC",
                    "helper_text": "Name of the new CC recipient",
                    "is_advanced_setting": True,
                },
                {
                    "field": "voided_reason",
                    "type": "string",
                    "value": "",
                    "label": "Voided Reason",
                    "placeholder": "Document no longer needed",
                    "helper_text": "Reason for voiding (required when status is voided)",
                    "is_advanced_setting": True,
                },
                {
                    "field": "resend_envelope",
                    "type": "bool",
                    "value": False,
                    "label": "Resend Notifications",
                    "helper_text": "Resend email notifications to recipients",
                    "is_advanced_setting": True,
                },
                {
                    "field": "purge_state",
                    "type": "string",
                    "value": "",
                    "label": "Purge State",
                    "helper_text": "Purge documents from the envelope",
                    "is_advanced_setting": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "None"},
                            {"value": "documents_only", "label": "Documents Only"},
                            {
                                "value": "documents_and_metadata",
                                "label": "Documents and Metadata",
                            },
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated envelope",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Updated status of the envelope",
                },
                {
                    "field": "email_subject",
                    "type": "string",
                    "helper_text": "Subject line of the envelope",
                },
                {
                    "field": "documents_added",
                    "type": "int32",
                    "helper_text": "Number of documents added",
                },
                {
                    "field": "recipients_added",
                    "type": "int32",
                    "helper_text": "Number of recipients added",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_envelope",
            "task_name": "tasks.docusign.update_envelope",
            "description": "Update an existing envelope",
            "label": "Update Envelope",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "envelope_id",
                "status",
                "email_subject",
                "email_blurb",
                "add_documents",
                "add_signer_email",
                "add_signer_name",
                "add_cc_email",
                "add_cc_name",
                "voided_reason",
                "resend_envelope",
                "purge_state",
            ],
            "required": ["envelope_id"],
        },
        "send_envelope**(*)**(*)": {
            "inputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "value": "",
                    "label": "Envelope ID",
                    "placeholder": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                    "helper_text": "The envelope ID (UUID format) - get this from List Envelopes or Create Envelope",
                }
            ],
            "outputs": [
                {
                    "field": "envelope_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the sent envelope",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the envelope (will be 'sent')",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_envelope",
            "task_name": "tasks.docusign.send_envelope",
            "description": "Send a draft envelope",
            "label": "Send Envelope",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "envelope_id"],
            "required": ["envelope_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        add_cc_email: str = "",
        add_cc_name: str = "",
        add_date_signed: bool = False,
        add_documents: List[str] = [],
        add_signature: bool = True,
        add_signer_email: str = "",
        add_signer_name: str = "",
        cc_emails: str = "",
        cc_names: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        documents: List[str] = [],
        email_blurb: str = "",
        email_subject: str = "",
        envelope_id: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        expire_after: int = 0,
        expire_enabled: bool = False,
        expire_warn: int = 0,
        folder_ids: str = "",
        include: str = "",
        limit: int = 10,
        order: str = "desc",
        order_by: str = "",
        purge_state: str = "",
        reminder_delay: int = 0,
        reminder_enabled: bool = False,
        reminder_frequency: int = 0,
        resend_envelope: bool = False,
        search_text: str = "",
        signature_anchor: str = "",
        signature_position: str = "bottom_left",
        signer_can_sign_on_mobile: bool = False,
        signer_emails: str = "",
        signer_names: str = "",
        status: str = "created",
        template_id: str = "",
        template_role_name: str = "",
        voided_reason: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_docusign",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if integration is not None:
            self.inputs["integration"] = integration
        if action is not None:
            self.inputs["action"] = action
        if email_subject is not None:
            self.inputs["email_subject"] = email_subject
        if email_blurb is not None:
            self.inputs["email_blurb"] = email_blurb
        if status is not None:
            self.inputs["status"] = status
        if signer_emails is not None:
            self.inputs["signer_emails"] = signer_emails
        if signer_names is not None:
            self.inputs["signer_names"] = signer_names
        if documents is not None:
            self.inputs["documents"] = documents
        if add_signature is not None:
            self.inputs["add_signature"] = add_signature
        if signature_position is not None:
            self.inputs["signature_position"] = signature_position
        if signature_anchor is not None:
            self.inputs["signature_anchor"] = signature_anchor
        if add_date_signed is not None:
            self.inputs["add_date_signed"] = add_date_signed
        if cc_emails is not None:
            self.inputs["cc_emails"] = cc_emails
        if cc_names is not None:
            self.inputs["cc_names"] = cc_names
        if template_id is not None:
            self.inputs["template_id"] = template_id
        if template_role_name is not None:
            self.inputs["template_role_name"] = template_role_name
        if expire_enabled is not None:
            self.inputs["expire_enabled"] = expire_enabled
        if expire_after is not None:
            self.inputs["expire_after"] = expire_after
        if expire_warn is not None:
            self.inputs["expire_warn"] = expire_warn
        if reminder_enabled is not None:
            self.inputs["reminder_enabled"] = reminder_enabled
        if reminder_delay is not None:
            self.inputs["reminder_delay"] = reminder_delay
        if reminder_frequency is not None:
            self.inputs["reminder_frequency"] = reminder_frequency
        if signer_can_sign_on_mobile is not None:
            self.inputs["signer_can_sign_on_mobile"] = signer_can_sign_on_mobile
        if envelope_id is not None:
            self.inputs["envelope_id"] = envelope_id
        if include is not None:
            self.inputs["include"] = include
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if search_text is not None:
            self.inputs["search_text"] = search_text
        if order is not None:
            self.inputs["order"] = order
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if folder_ids is not None:
            self.inputs["folder_ids"] = folder_ids
        if limit is not None:
            self.inputs["limit"] = limit
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if add_documents is not None:
            self.inputs["add_documents"] = add_documents
        if add_signer_email is not None:
            self.inputs["add_signer_email"] = add_signer_email
        if add_signer_name is not None:
            self.inputs["add_signer_name"] = add_signer_name
        if add_cc_email is not None:
            self.inputs["add_cc_email"] = add_cc_email
        if add_cc_name is not None:
            self.inputs["add_cc_name"] = add_cc_name
        if voided_reason is not None:
            self.inputs["voided_reason"] = voided_reason
        if resend_envelope is not None:
            self.inputs["resend_envelope"] = resend_envelope
        if purge_state is not None:
            self.inputs["purge_state"] = purge_state
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationDocusignNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
