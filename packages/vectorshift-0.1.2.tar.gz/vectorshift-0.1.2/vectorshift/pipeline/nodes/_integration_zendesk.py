"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_zendesk")
class IntegrationZendeskNode(Node):
    """
    Zendesk

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'get_tickets'
        assignee: Assignee of the ticket
        body: Search in the full ticket content
        brand: Filter by brand
        comment: Search in ticket comments
        comment_exact: Match comment exactly
        description: Search in the ticket description
        due: Tickets due on this date
        external_id: Search by external ID
        group: Filter by assigned group
        include: Include related data (e.g. users)
        organization: Organization of the ticket
        priority: Priority of the ticket
        requester: Requester of the ticket
        satisfaction: Customer satisfaction rating
        solved: Tickets solved on this date
        sort_by: Field to sort results by
        sort_order: Order of sorting (asc/desc)
        status: Status of the ticket
        subject: Search tickets by subject
        subject_exact: Match subject exactly
        ticket_form: Filter by ticket form
        ticket_type: Type of the ticket
        updated: Tickets updated on this date
        use_date: Toggle to use dates
    ### When action = 'get_tickets' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'search_users'
        email: Email of the user to search for
        external_id: Search by external ID
        limit: Maximum number of ticket fields to retrieve
        name: Name of the user to search for
        phone: Phone number of the user to search for
        role: Filter users by role
        search_query: Search query for users
    ### When action = 'get_tickets' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'list_ticket_fields'
        limit: Maximum number of ticket fields to retrieve
    ### When action = 'list_users'
        limit: Maximum number of ticket fields to retrieve
        role: Filter users by role
    ### When action = 'list_organizations'
        limit: Maximum number of ticket fields to retrieve
        return_all: Whether to return all organizations
    ### When action = 'get_tickets' and use_date = False
        num_messages: Specify the number of tickets to fetch
    ### When action = 'create_organization'
        organization_details: Additional details about the organization
        organization_domain_names: Domain names for the organization (comma-separated)
        organization_external_id: External ID for the organization
        organization_group_id: Group ID for the organization
        organization_name: Name of the organization
        organization_notes: Notes about the organization
        organization_shared_comments: Whether the organization has shared comments
        organization_shared_tickets: Whether the organization has shared tickets
        organization_tags: Tags for the organization
    ### When action = 'update_organization'
        organization_details: Additional details about the organization
        organization_domain_names: Domain names for the organization (comma-separated)
        organization_external_id: External ID for the organization
        organization_group_id: Group ID for the organization
        organization_id: Select the Zendesk organization to delete
        organization_name: Name of the organization
        organization_notes: Notes about the organization
        organization_shared_comments: Whether the organization has shared comments
        organization_shared_tickets: Whether the organization has shared tickets
        organization_tags: Tags for the organization
    ### When action = 'delete_organization'
        organization_id: Select the Zendesk organization to delete
    ### When action = 'get_organization'
        organization_id: Select the Zendesk organization to delete
    ### When action = 'get_organization_related_data'
        organization_id: Select the Zendesk organization to delete
    ### When action = 'create_comment'
        public: Whether the comment should be public
        ticket_body: Body content of the ticket
        ticket_id: Select the Zendesk ticket to update
    ### When action = 'create_ticket'
        requester_email: Email of the requester
        requester_name: Name of the requester (Required if requester email is not already registered)
        ticket_body: Body content of the ticket
        ticket_group_id: Select the group to assign the ticket to
        ticket_priority: Priority of the ticket
        ticket_status: Status of the ticket
        ticket_subject: Subject content of the ticket
        ticket_type: Type of the ticket
    ### When action = 'get_ticket_field'
        ticket_field_id: ID of the ticket field to retrieve
    ### When action = 'update_ticket'
        ticket_id: Select the Zendesk ticket to update
        ticket_priority: Priority of the ticket
        ticket_status: Status of the ticket
        ticket_type: Type of the ticket
        update_ticket_assignee_id: The ID of the assignee to update the ticket to (only staff members can be assigned to tickets)
        update_ticket_body: Body content of the ticket
        update_ticket_group_id: Select the group to assign the ticket to
        update_ticket_subject: Subject content of the ticket
    ### When action = 'read_ticket'
        ticket_id: Select the Zendesk ticket to update
    ### When action = 'delete_ticket'
        ticket_id: Select the Zendesk ticket to update
    ### When action = 'recover_ticket'
        ticket_id: Select the Zendesk ticket to update
    ### When action = 'read_ticket_comments'
        ticket_id: Select the Zendesk ticket to update
    ### When action = 'get_tickets' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'create_user'
        user_alias: Alias for the user
        user_custom_role_id: Custom role ID for the user
        user_details: Details for the user
        user_email: Email address of the user
        user_external_id: External ID for the user
        user_locale: Locale for the user
        user_moderator: Whether the user is a moderator
        user_name: Name of the user
        user_notes: Notes for the user
        user_only_private_comments: Whether the user only has private comments
        user_organization_id: Organization ID for the user
        user_phone: Phone number of the user
        user_report_csv: Whether the user can generate reports in CSV format
        user_restricted_agent: Whether the user is a restricted agent
        user_role: Role of the user
        user_signature: Signature for the user
        user_suspended: Whether the user is suspended
        user_tags: Tags for the user
        user_ticket_restriction: Ticket restriction for the user
        user_timezone: Timezone for the user
    ### When action = 'update_user'
        user_alias: Alias for the user
        user_custom_role_id: Custom role ID for the user
        user_details: Details for the user
        user_email: Email address of the user
        user_id: Select the Zendesk user to delete
        user_locale: Locale for the user
        user_moderator: Whether the user is a moderator
        user_name: Name of the user
        user_notes: Notes for the user
        user_only_private_comments: Whether the user only has private comments
        user_organization_id: Organization ID for the user
        user_phone: Phone number of the user
        user_report_csv: Whether the user can generate reports in CSV format
        user_restricted_agent: Whether the user is a restricted agent
        user_role: Role of the user
        user_signature: Signature for the user
        user_suspended: Whether the user is suspended
        user_tags: Tags for the user
        user_ticket_restriction: Ticket restriction for the user
        user_timezone: Timezone for the user
    ### When action = 'delete_user'
        user_id: Select the Zendesk user to delete
    ### When action = 'get_user'
        user_id: Select the Zendesk user to delete
    ### When action = 'get_user_organizations'
        user_id: Select the Zendesk user to delete
    ### When action = 'get_user_related_data'
        user_id: Select the Zendesk user to delete

    ## Outputs
    ### When action = 'get_ticket_field'
        active: Whether the ticket field is active
        created_at: Date and time the ticket field was created
        custom_field_options: Custom field options in JSON format
        position: Position of the ticket field
        raw_data: Raw API response in JSON format
        required: Whether the ticket field is required
        tag: Tag of the ticket field
        ticket_field_description: Description of the ticket field
        ticket_field_details: Ticket field details in JSON format
        ticket_field_id: ID of the ticket field
        ticket_field_title: Title of the ticket field
        ticket_field_type: Type of the ticket field
        ticket_field_url: URL of the ticket field
        updated_at: Date and time the ticket field was last updated
    ### When action = 'get_user_related_data'
        assigned_tickets: Tickets assigned to the user in JSON format
        ccd_tickets: Tickets where user is CC'd in JSON format
        organizations: User's organizations in JSON format
        raw_data: Raw API response in JSON format
        related_data: All user related data in JSON format
        requested_tickets: Tickets requested by the user in JSON format
    ### When action = 'create_ticket'
        created_at: Date and time the ticket was created
        raw_data: Raw API response in JSON format
        ticket_assignee_id: ID of the ticket assignee
        ticket_body: Body of the created ticket
        ticket_details: Ticket details in JSON format
        ticket_id: Ticket ID of the created ticket
        ticket_priority: Priority of the created ticket
        ticket_requester_id: ID of the ticket requester
        ticket_status: Status of the created ticket
        ticket_subject: Subject of the created ticket
        ticket_type: Type of the created ticket
        ticket_url: URL of the created ticket
        updated_at: Date and time the ticket was last updated
    ### When action = 'read_ticket'
        created_at: Date and time the ticket was created
        raw_data: Raw API response in JSON format
        ticket_assignee_id: ID of ticket assignee
        ticket_attachments: Attachments of the ticket
        ticket_body: Body of the ticket
        ticket_details: Ticket details in JSON format
        ticket_priority: Priority of the ticket
        ticket_requester_id: ID of ticket requester
        ticket_status: Status of the ticket
        ticket_subject: Subject of the ticket
        ticket_type: Type of the ticket
        ticket_url: URL of the ticket
        updated_at: Date and time the ticket was last updated
    ### When action = 'get_tickets'
        created_at: Date and time the tickets was created
        raw_data: Raw API response in JSON format
        ticket_assignee_id: ID of tickets assignee
        ticket_attachments: Attachments of the tickets
        ticket_body: Body of the tickets
        ticket_details: Tickets details in JSON format
        ticket_id: ID of the tickets
        ticket_priority: Priority of the tickets
        ticket_requester_id: ID of tickets requester
        ticket_status: Status of the tickets
        ticket_subject: Subject of the tickets
        ticket_type: Type of the tickets
        ticket_url: URL of the tickets
        updated_at: Date and time the tickets was last updated
    ### When action = 'list_ticket_fields'
        created_at: Creation dates of the ticket fields
        raw_data: Raw API response in JSON format
        ticket_field_active: Active status of the ticket fields
        ticket_field_descriptions: Descriptions of the ticket fields
        ticket_field_ids: IDs of the ticket fields
        ticket_field_positions: Positions of the ticket fields
        ticket_field_required: Required status of the ticket fields
        ticket_field_tags: Tags of the ticket fields
        ticket_field_titles: Titles of the ticket fields
        ticket_field_types: Types of the ticket fields
        ticket_field_urls: URLs of the ticket fields
        ticket_fields_details: Ticket fields details in JSON format
        total_count: Total number of ticket fields
        updated_at: Last update dates of the ticket fields
    ### When action = 'create_user'
        created_at: Date and time the user was created
        external_id: External ID of the user
        raw_data: Raw API response in JSON format
        updated_at: Date and time the user was last updated
        user_active: Whether the user is active
        user_details: User details in JSON format
        user_email: Email of the user
        user_id: ID of the created user
        user_locale: Locale of the user
        user_name: Name of the user
        user_organization_id: Organization ID of the user
        user_phone: Phone number of the user
        user_role: Role of the user
        user_tags: Tags associated with the user
        user_timezone: Timezone of the user
        user_url: URL of the user
        user_verified: Whether the user is verified
    ### When action = 'get_user'
        created_at: Date and time the user was created
        external_id: External ID of the user
        raw_data: Raw API response in JSON format
        updated_at: Date and time the user was last updated
        user_active: Whether the user is active
        user_details: User details in JSON format
        user_email: Email of the user
        user_id: ID of the user
        user_locale: Locale of the user
        user_name: Name of the user
        user_organization_id: Organization ID of the user
        user_phone: Phone number of the user
        user_role: Role of the user
        user_tags: Tags associated with the user
        user_timezone: Timezone of the user
        user_url: URL of the user
        user_verified: Whether the user is verified
    ### When action = 'list_users'
        created_at: Creation dates of the users
        organization_ids: Organization IDs of the users
        raw_data: Raw API response in JSON format
        updated_at: Last update dates of the users
        user_active: Active status of the users
        user_emails: Emails of the users
        user_ids: IDs of the users
        user_names: Names of the users
        user_phones: Phone numbers of the users
        user_roles: Roles of the users
        user_urls: URLs of the users
        users_details: Users details in JSON format
    ### When action = 'update_user'
        created_at: Date and time the user was created
        raw_data: Raw API response in JSON format
        updated_at: Date and time the user was last updated
        user_details: Updated user details in JSON format
        user_email: Updated email of the user
        user_id: ID of the updated user
        user_name: Updated name of the user
        user_organization_id: Updated organization ID of the user
        user_role: Updated role of the user
        user_url: URL of the user
    ### When action = 'create_organization'
        created_at: Date and time the organization was created
        organization_details: Organization details in JSON format
        organization_domain_names: Domain names of the organization
        organization_external_id: External ID of the organization
        organization_group_id: Group ID of the organization
        organization_id: ID of the created organization
        organization_name: Name of the organization
        organization_shared_comments: Whether the organization has shared comments
        organization_shared_tickets: Whether the organization has shared tickets
        organization_tags: Tags associated with the organization
        organization_url: URL of the organization
        raw_data: Raw API response in JSON format
        updated_at: Date and time the organization was last updated
    ### When action = 'get_organization'
        created_at: Date and time the organization was created
        organization_details: Organization details in JSON format
        organization_domain_names: Domain names of the organization
        organization_external_id: External ID of the organization
        organization_group_id: Group ID of the organization
        organization_id: ID of the organization
        organization_name: Name of the organization
        organization_shared_comments: Whether the organization has shared comments
        organization_shared_tickets: Whether the organization has shared tickets
        organization_tags: Tags associated with the organization
        organization_url: URL of the organization
        raw_data: Raw API response in JSON format
        updated_at: Date and time the organization was last updated
    ### When action = 'list_organizations'
        created_at: Creation dates of the organizations
        organization_domain_names: Domain names of the organizations
        organization_ids: IDs of the organizations
        organization_names: Names of the organizations
        organization_tags: Tags of the organizations
        organization_urls: URLs of the organizations
        organizations_details: Organizations details in JSON format
        raw_data: Raw API response in JSON format
        total_count: Total number of organizations
        updated_at: Last update dates of the organizations
    ### When action = 'update_organization'
        created_at: Date and time the organization was created
        organization_details: Updated organization details in JSON format
        organization_domain_names: Updated domain names of the organization
        organization_id: ID of the updated organization
        organization_name: Updated name of the organization
        organization_tags: Updated tags of the organization
        organization_url: URL of the organization
        raw_data: Raw API response in JSON format
        updated_at: Date and time the organization was last updated
    ### When action = 'delete_organization'
        organization_id: ID of the deleted organization
        raw_data: Raw API response in JSON format
    ### When action = 'get_organization_related_data'
        organization_id: ID of the organization
        raw_data: Raw API response in JSON format
        tickets_count: Number of tickets in the organization
        users_count: Number of users in the organization
    ### When action = 'get_user_organizations'
        organization_ids: IDs of the user's organizations
        organization_names: Names of the user's organizations
        organization_urls: URLs of the user's organizations
        organizations_details: Organizations details in JSON format
        raw_data: Raw API response in JSON format
        total_count: Total number of organizations
    ### When action = 'update_ticket'
        raw_data: Raw API response in JSON format
        ticket_body: Body of the updated ticket
        ticket_details: Ticket details in JSON format
        ticket_id: ID of the updated ticket
        ticket_priority: Priority of the updated ticket
        ticket_status: Status of the updated ticket
        ticket_subject: Subject of the updated ticket
        ticket_type: Type of the updated ticket
        updated_at: Date and time the ticket was last updated
    ### When action = 'delete_ticket'
        raw_data: Raw API response in JSON format
        ticket_id: ID of the deleted ticket
    ### When action = 'recover_ticket'
        raw_data: Raw API response in JSON format
        ticket_details: Recovered ticket details in JSON format
        ticket_id: ID of the recovered ticket
    ### When action = 'create_comment'
        raw_data: Raw API response in JSON format
        ticket_details: Ticket details in JSON format
    ### When action = 'read_ticket_comments'
        raw_data: Raw API response in JSON format
        ticket_attachments: Attachments of the ticket
        ticket_comments: Ticket comments in JSON format
        ticket_details: Ticket details in JSON format
    ### When action = 'delete_user'
        raw_data: Raw API response in JSON format
        user_details: User details in JSON format
        user_id: ID of the deleted user
    ### When action = 'search_users'
        raw_data: Raw API response in JSON format
        search_query: The search query used
        total_count: Total number of matching users
        user_emails: Emails of the matching users
        user_ids: IDs of the matching users
        user_names: Names of the matching users
        user_roles: Roles of the matching users
        users_details: Users details in JSON format
    ### When action = 'count_organizations'
        raw_data: Raw API response in JSON format
        result: Total number of organizations in Zendesk
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Zendesk>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subject content of the ticket",
                    "label": "Subject",
                    "placeholder": "Incident report",
                },
                {
                    "field": "ticket_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Body content of the ticket",
                    "label": "Body",
                    "placeholder": "Clicking on submit button doens’t work",
                },
                {
                    "field": "requester_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the requester",
                    "label": "Requester Email",
                    "placeholder": "john@company.com",
                },
                {
                    "field": "requester_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the requester (Required if requester email is not already registered)",
                    "label": "Requester Name",
                    "placeholder": "John Smith",
                },
                {
                    "field": "ticket_priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the ticket",
                    "label": "Priority",
                    "placeholder": "High",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "Low"},
                            {"label": "Normal", "value": "Normal"},
                            {"label": "High", "value": "High"},
                            {"label": "Urgent", "value": "Urgent"},
                        ],
                    },
                },
                {
                    "field": "ticket_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of the ticket",
                    "label": "Type",
                    "placeholder": "Incident",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "Question", "value": "Question"},
                            {"label": "Incident", "value": "Incident"},
                            {"label": "Problem", "value": "Problem"},
                            {"label": "Task", "value": "Task"},
                        ],
                    },
                },
                {
                    "field": "ticket_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the ticket",
                    "label": "Status",
                    "placeholder": "Open",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "New", "value": "New"},
                            {"label": "Open", "value": "Open"},
                            {"label": "Pending", "value": "Pending"},
                            {"label": "Hold", "value": "Hold"},
                            {"label": "Solved", "value": "Solved"},
                            {"label": "Closed", "value": "Closed"},
                        ],
                    },
                },
                {
                    "field": "ticket_group_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the group to assign the ticket to",
                    "label": "Group",
                    "placeholder": "Select Group",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=group_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "Ticket ID of the created ticket",
                },
                {
                    "field": "ticket_subject",
                    "type": "string",
                    "helper_text": "Subject of the created ticket",
                },
                {
                    "field": "ticket_body",
                    "type": "string",
                    "helper_text": "Body of the created ticket",
                },
                {
                    "field": "ticket_status",
                    "type": "string",
                    "helper_text": "Status of the created ticket",
                },
                {
                    "field": "ticket_priority",
                    "type": "string",
                    "helper_text": "Priority of the created ticket",
                },
                {
                    "field": "ticket_type",
                    "type": "string",
                    "helper_text": "Type of the created ticket",
                },
                {
                    "field": "ticket_url",
                    "type": "string",
                    "helper_text": "URL of the created ticket",
                },
                {
                    "field": "ticket_requester_id",
                    "type": "string",
                    "helper_text": "ID of the ticket requester",
                },
                {
                    "field": "ticket_assignee_id",
                    "type": "string",
                    "helper_text": "ID of the ticket assignee",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the ticket was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the ticket was last updated",
                },
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Ticket details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_ticket",
            "task_name": "tasks.zendesk.create_ticket",
            "description": "Create a new ticket on Zendesk",
            "label": "Create Ticket",
            "ui_sort_order": [
                "integration",
                "action",
                "ticket_priority",
                "ticket_type",
                "ticket_status",
                "ticket_subject",
                "ticket_body",
                "requester_email",
                "requester_name",
                "ticket_group_id",
            ],
            "required": [
                "ticket_id",
                "ticket_subject",
                "ticket_body",
                "requester_email",
                "ticket_priority",
                "ticket_type",
                "ticket_status",
            ],
        },
        "update_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk ticket to update",
                    "label": "Select Ticket",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=ticket_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_ticket_subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subject content of the ticket",
                    "label": "Subject",
                    "placeholder": "Incident report",
                },
                {
                    "field": "update_ticket_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Body content of the ticket",
                    "label": "Body",
                    "placeholder": "Clicking on submit button not working",
                },
                {
                    "field": "update_ticket_assignee_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the assignee to update the ticket to (only staff members can be assigned to tickets)",
                    "label": "Assignee ID",
                    "placeholder": "1234",
                },
                {
                    "field": "update_ticket_group_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the group to assign the ticket to",
                    "label": "Group",
                    "placeholder": "Select Group",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=group_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "ticket_priority",
                    "type": "enum<string>",
                    "value": "",
                    "helper_text": "Priority of the ticket",
                    "label": "Priority",
                    "placeholder": "High",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "Low"},
                            {"label": "Normal", "value": "Normal"},
                            {"label": "High", "value": "High"},
                            {"label": "Urgent", "value": "Urgent"},
                        ],
                    },
                },
                {
                    "field": "ticket_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of the ticket",
                    "label": "Type",
                    "placeholder": "Incident",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "Question", "value": "Question"},
                            {"label": "Incident", "value": "Incident"},
                            {"label": "Problem", "value": "Problem"},
                            {"label": "Task", "value": "Task"},
                        ],
                    },
                },
                {
                    "field": "ticket_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the ticket",
                    "label": "Status",
                    "placeholder": "Open",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "New", "value": "New"},
                            {"label": "Open", "value": "Open"},
                            {"label": "Pending", "value": "Pending"},
                            {"label": "Hold", "value": "Hold"},
                            {"label": "Solved", "value": "Solved"},
                            {"label": "Closed", "value": "Closed"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "ID of the updated ticket",
                },
                {
                    "field": "ticket_subject",
                    "type": "string",
                    "helper_text": "Subject of the updated ticket",
                },
                {
                    "field": "ticket_body",
                    "type": "string",
                    "helper_text": "Body of the updated ticket",
                },
                {
                    "field": "ticket_status",
                    "type": "string",
                    "helper_text": "Status of the updated ticket",
                },
                {
                    "field": "ticket_priority",
                    "type": "string",
                    "helper_text": "Priority of the updated ticket",
                },
                {
                    "field": "ticket_type",
                    "type": "string",
                    "helper_text": "Type of the updated ticket",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the ticket was last updated",
                },
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Ticket details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_ticket",
            "task_name": "tasks.zendesk.update_ticket",
            "description": "Update an existing ticket on Zendesk",
            "label": "Update Ticket",
            "ui_sort_order": [
                "integration",
                "action",
                "ticket_priority",
                "ticket_type",
                "ticket_status",
                "ticket_id",
                "update_ticket_subject",
                "update_ticket_body",
                "update_ticket_assignee_id",
                "update_ticket_group_id",
            ],
            "required": ["ticket_id"],
        },
        "read_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk ticket to read",
                    "label": "Select Ticket",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=ticket_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "ticket_subject",
                    "type": "string",
                    "helper_text": "Subject of the ticket",
                },
                {
                    "field": "ticket_body",
                    "type": "vec<string>",
                    "helper_text": "Body of the ticket",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Date and time the ticket was created",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Date and time the ticket was last updated",
                },
                {
                    "field": "ticket_priority",
                    "type": "string",
                    "helper_text": "Priority of the ticket",
                },
                {
                    "field": "ticket_type",
                    "type": "string",
                    "helper_text": "Type of the ticket",
                },
                {
                    "field": "ticket_status",
                    "type": "string",
                    "helper_text": "Status of the ticket",
                },
                {
                    "field": "ticket_url",
                    "type": "string",
                    "helper_text": "URL of the ticket",
                },
                {
                    "field": "ticket_attachments",
                    "type": "vec<file>",
                    "helper_text": "Attachments of the ticket",
                },
                {
                    "field": "ticket_assignee_id",
                    "type": "string",
                    "helper_text": "ID of ticket assignee",
                },
                {
                    "field": "ticket_requester_id",
                    "type": "string",
                    "helper_text": "ID of ticket requester",
                },
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Ticket details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "name": "read_ticket",
            "task_name": "tasks.zendesk.read_ticket",
            "description": "Read details of a specific ticket",
            "label": "Get Ticket",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "ticket_id"],
            "required": ["ticket_id"],
        },
        "get_tickets**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "helper_text": "Assignee of the ticket",
                    "placeholder": "John Smith",
                },
                {
                    "field": "requester",
                    "type": "string",
                    "value": "",
                    "label": "Requester",
                    "helper_text": "Requester of the ticket",
                    "placeholder": "John Smith",
                },
                {
                    "field": "organization",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "Organization of the ticket",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the ticket",
                    "label": "Priority",
                    "placeholder": "High",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "Low"},
                            {"label": "Normal", "value": "Normal"},
                            {"label": "High", "value": "High"},
                            {"label": "Urgent", "value": "Urgent"},
                        ],
                    },
                },
                {
                    "field": "ticket_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of the ticket",
                    "label": "Type",
                    "placeholder": "Incident",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "Question", "value": "Question"},
                            {"label": "Incident", "value": "Incident"},
                            {"label": "Problem", "value": "Problem"},
                            {"label": "Task", "value": "Task"},
                        ],
                    },
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the ticket",
                    "label": "Status",
                    "placeholder": "Open",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "New", "value": "New"},
                            {"label": "Open", "value": "Open"},
                            {"label": "Pending", "value": "Pending"},
                            {"label": "Hold", "value": "Hold"},
                            {"label": "Solved", "value": "Solved"},
                            {"label": "Closed", "value": "Closed"},
                        ],
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "helper_text": "Search tickets by subject",
                    "placeholder": "Incident report",
                },
                {
                    "field": "subject_exact",
                    "type": "string",
                    "value": "",
                    "label": "Subject Exact",
                    "helper_text": "Match subject exactly",
                    "placeholder": "Incident report",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Search in the ticket description",
                    "placeholder": "Clicking on submit button doesn't work",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "helper_text": "Search in the full ticket content",
                    "placeholder": "Clicking on submit button doesn't work",
                },
                {
                    "field": "comment",
                    "type": "string",
                    "value": "",
                    "label": "Comment",
                    "helper_text": "Search in ticket comments",
                    "placeholder": "Clicking on submit button doesn't work",
                },
                {
                    "field": "comment_exact",
                    "type": "string",
                    "value": "",
                    "label": "Comment Exact",
                    "helper_text": "Match comment exactly",
                    "placeholder": "Clicking on submit button doesn't work",
                },
                {
                    "field": "updated",
                    "type": "string",
                    "value": "",
                    "label": "Updated Date",
                    "helper_text": "Tickets updated on this date",
                    "placeholder": "YYYY-MM-DD",
                },
                {
                    "field": "solved",
                    "type": "string",
                    "value": "",
                    "label": "Solved Date",
                    "helper_text": "Tickets solved on this date",
                    "placeholder": "YYYY-MM-DD",
                },
                {
                    "field": "due",
                    "type": "string",
                    "value": "",
                    "label": "Due Date",
                    "helper_text": "Tickets due on this date",
                    "placeholder": "YYYY-MM-DD",
                },
                {
                    "field": "brand",
                    "type": "string",
                    "value": "",
                    "label": "Brand",
                    "helper_text": "Filter by brand",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "satisfaction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer satisfaction rating",
                    "label": "Satisfaction",
                    "placeholder": "Good",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "Good", "value": "good"},
                            {"label": "Bad", "value": "bad"},
                            {"label": "Offered", "value": "offered"},
                        ],
                    },
                },
                {
                    "field": "ticket_form",
                    "type": "string",
                    "value": "",
                    "label": "Ticket Form",
                    "helper_text": "Filter by ticket form",
                    "placeholder": "Support",
                },
                {
                    "field": "group",
                    "type": "string",
                    "value": "",
                    "label": "Group",
                    "helper_text": "Filter by assigned group",
                    "placeholder": "Support",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "helper_text": "Field to sort results by",
                    "placeholder": "created_at",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "helper_text": "Order of sorting (asc/desc)",
                    "placeholder": "desc",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "label": "External ID",
                    "helper_text": "Search by external ID",
                    "placeholder": "123",
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "helper_text": "Include related data (e.g. users)",
                    "placeholder": "users,groups,organizations",
                },
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "vec<string>",
                    "helper_text": "ID of the tickets",
                },
                {
                    "field": "ticket_subject",
                    "type": "vec<string>",
                    "helper_text": "Subject of the tickets",
                },
                {
                    "field": "ticket_body",
                    "type": "vec<string>",
                    "helper_text": "Body of the tickets",
                },
                {
                    "field": "created_at",
                    "type": "vec<string>",
                    "helper_text": "Date and time the tickets was created",
                },
                {
                    "field": "updated_at",
                    "type": "vec<string>",
                    "helper_text": "Date and time the tickets was last updated",
                },
                {
                    "field": "ticket_priority",
                    "type": "vec<string>",
                    "helper_text": "Priority of the tickets",
                },
                {
                    "field": "ticket_type",
                    "type": "vec<string>",
                    "helper_text": "Type of the tickets",
                },
                {
                    "field": "ticket_status",
                    "type": "vec<string>",
                    "helper_text": "Status of the tickets",
                },
                {
                    "field": "ticket_url",
                    "type": "vec<string>",
                    "helper_text": "URL of the tickets",
                },
                {
                    "field": "ticket_attachments",
                    "type": "vec<vec<file>>",
                    "helper_text": "Attachments of the tickets",
                },
                {
                    "field": "ticket_assignee_id",
                    "type": "vec<string>",
                    "helper_text": "ID of tickets assignee",
                },
                {
                    "field": "ticket_requester_id",
                    "type": "vec<string>",
                    "helper_text": "ID of tickets requester",
                },
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Tickets details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_tickets",
            "task_name": "tasks.zendesk.get_tickets",
            "description": "Get multiple tickets",
            "label": "List Tickets",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "ticket_subject",
                "ticket_body",
                "requester_email",
                "requester_name",
                "ticket_priority",
                "ticket_type",
                "ticket_status",
                "assignee",
                "requester",
                "organization",
                "subject",
                "subject_exact",
                "description",
                "body",
                "comment",
                "comment_exact",
                "updated",
                "solved",
                "due",
                "brand",
                "satisfaction",
                "ticket_form",
                "group",
                "sort_by",
                "sort_order",
                "external_id",
                "include",
            ],
            "required": ["num_messages"],
        },
        "get_tickets**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Tickets",
                    "helper_text": "Specify the number of tickets to fetch",
                }
            ],
            "outputs": [],
        },
        "get_tickets**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_tickets**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_tickets**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk ticket to delete",
                    "label": "Select Ticket",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=ticket_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "ID of the deleted ticket",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_ticket",
            "task_name": "tasks.zendesk.delete_ticket",
            "description": "Delete a ticket on Zendesk",
            "label": "Delete Ticket",
            "ui_sort_order": ["integration", "action", "ticket_id"],
            "required": ["ticket_id"],
        },
        "recover_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Enter the Suspended Zendesk ticket to recover",
                    "label": "Suspended Ticket ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "ID of the recovered ticket",
                },
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Recovered ticket details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "recover_ticket",
            "task_name": "tasks.zendesk.recover_ticket",
            "description": "Recover a deleted ticket on Zendesk",
            "label": "Recover Ticket",
            "ui_sort_order": ["integration", "action", "ticket_id"],
            "required": ["ticket_id"],
        },
        "create_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk ticket to add comment to",
                    "label": "Select Ticket",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=ticket_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "ticket_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the comment",
                    "label": "Comment Body",
                    "placeholder": "Clicking on submit button not working",
                },
                {
                    "field": "public",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the comment should be public",
                    "label": "Public",
                },
            ],
            "outputs": [
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Ticket details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "name": "create_comment",
            "task_name": "tasks.zendesk.create_comment",
            "description": "Create a new comment on a Zendesk ticket",
            "label": "Create Comment",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "ticket_id",
                "ticket_body",
                "public",
            ],
            "required": ["ticket_id", "ticket_body"],
        },
        "read_ticket_comments**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk ticket to read comments from",
                    "label": "Select Ticket",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=ticket_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "ticket_comments",
                    "type": "vec<string>",
                    "helper_text": "Ticket comments in JSON format",
                },
                {
                    "field": "ticket_attachments",
                    "type": "vec<file>",
                    "helper_text": "Attachments of the ticket",
                },
                {
                    "field": "ticket_details",
                    "type": "string",
                    "helper_text": "Ticket details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "name": "read_ticket_comments",
            "task_name": "tasks.zendesk.read_ticket_comments",
            "description": "Get multiple ticket comments",
            "label": "List Ticket Comments",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "ticket_id"],
            "required": ["ticket_id"],
        },
        "get_ticket_field**(*)**(*)": {
            "inputs": [
                {
                    "field": "ticket_field_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the ticket field to retrieve",
                    "label": "Ticket Field ID",
                    "placeholder": "123456789",
                }
            ],
            "outputs": [
                {
                    "field": "ticket_field_id",
                    "type": "string",
                    "helper_text": "ID of the ticket field",
                },
                {
                    "field": "ticket_field_title",
                    "type": "string",
                    "helper_text": "Title of the ticket field",
                },
                {
                    "field": "ticket_field_type",
                    "type": "string",
                    "helper_text": "Type of the ticket field",
                },
                {
                    "field": "ticket_field_description",
                    "type": "string",
                    "helper_text": "Description of the ticket field",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position of the ticket field",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether the ticket field is active",
                },
                {
                    "field": "required",
                    "type": "bool",
                    "helper_text": "Whether the ticket field is required",
                },
                {
                    "field": "tag",
                    "type": "string",
                    "helper_text": "Tag of the ticket field",
                },
                {
                    "field": "ticket_field_url",
                    "type": "string",
                    "helper_text": "URL of the ticket field",
                },
                {
                    "field": "custom_field_options",
                    "type": "string",
                    "helper_text": "Custom field options in JSON format",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the ticket field was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the ticket field was last updated",
                },
                {
                    "field": "ticket_field_details",
                    "type": "string",
                    "helper_text": "Ticket field details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_ticket_field",
            "task_name": "tasks.zendesk.get_ticket_field",
            "description": "Read details of a specific ticket field",
            "label": "Get Ticket Field",
            "inputs_sort_order": ["integration", "action", "ticket_field_id"],
            "required": ["ticket_field_id"],
        },
        "list_ticket_fields**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of ticket fields to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [
                {
                    "field": "ticket_field_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the ticket fields",
                },
                {
                    "field": "ticket_field_titles",
                    "type": "vec<string>",
                    "helper_text": "Titles of the ticket fields",
                },
                {
                    "field": "ticket_field_types",
                    "type": "vec<string>",
                    "helper_text": "Types of the ticket fields",
                },
                {
                    "field": "ticket_field_descriptions",
                    "type": "vec<string>",
                    "helper_text": "Descriptions of the ticket fields",
                },
                {
                    "field": "ticket_field_positions",
                    "type": "vec<int32>",
                    "helper_text": "Positions of the ticket fields",
                },
                {
                    "field": "ticket_field_active",
                    "type": "vec<bool>",
                    "helper_text": "Active status of the ticket fields",
                },
                {
                    "field": "ticket_field_required",
                    "type": "vec<bool>",
                    "helper_text": "Required status of the ticket fields",
                },
                {
                    "field": "ticket_field_tags",
                    "type": "vec<string>",
                    "helper_text": "Tags of the ticket fields",
                },
                {
                    "field": "ticket_field_urls",
                    "type": "vec<string>",
                    "helper_text": "URLs of the ticket fields",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of ticket fields",
                },
                {
                    "field": "created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation dates of the ticket fields",
                },
                {
                    "field": "updated_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Last update dates of the ticket fields",
                },
                {
                    "field": "ticket_fields_details",
                    "type": "string",
                    "helper_text": "Ticket fields details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_ticket_fields",
            "task_name": "tasks.zendesk.list_ticket_fields",
            "description": "Get multiple ticket fields",
            "label": "List Ticket Fields",
            "inputs_sort_order": ["integration", "action", "limit"],
            "required": [],
        },
        "create_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the user",
                    "label": "User Name",
                    "placeholder": "John Smith",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the user",
                    "label": "User Email",
                    "placeholder": "john.smith@company.com",
                },
                {
                    "field": "user_role",
                    "type": "string",
                    "value": "end-user",
                    "helper_text": "Role of the user",
                    "label": "User Role",
                    "placeholder": "end-user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "End User", "value": "end-user"},
                            {"label": "Agent", "value": "agent"},
                            {"label": "Admin", "value": "admin"},
                        ],
                    },
                },
                {
                    "field": "user_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the user",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                },
                {
                    "field": "user_organization_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Organization ID for the user",
                    "label": "Organization",
                    "placeholder": "Select organization",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID for the user",
                    "label": "External ID",
                    "placeholder": "external123",
                },
                {
                    "field": "user_alias",
                    "type": "string",
                    "value": "",
                    "helper_text": "Alias for the user",
                    "label": "Alias",
                    "placeholder": "john.smith",
                },
                {
                    "field": "user_details",
                    "type": "string",
                    "value": "",
                    "helper_text": "Details for the user",
                    "label": "Details",
                    "placeholder": "Internal notes",
                },
                {
                    "field": "user_notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Notes for the user",
                    "label": "Notes",
                    "placeholder": "Internal notes",
                },
                {
                    "field": "user_locale",
                    "type": "string",
                    "value": "",
                    "helper_text": "Locale for the user",
                    "label": "Locale",
                    "placeholder": "en-US",
                },
                {
                    "field": "user_timezone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timezone for the user",
                    "label": "Timezone",
                    "placeholder": "America/New_York",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "user_signature",
                    "type": "string",
                    "value": "",
                    "helper_text": "Signature for the user",
                    "label": "Signature",
                    "placeholder": "Best regards, John Smith",
                },
                {
                    "field": "user_moderator",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user is a moderator",
                    "label": "Moderator",
                },
                {
                    "field": "user_custom_role_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom role ID for the user",
                    "label": "Custom Role ID",
                    "placeholder": "123456789",
                },
                {
                    "field": "user_only_private_comments",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user only has private comments",
                    "label": "Only Private Comments",
                },
                {
                    "field": "user_restricted_agent",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user is a restricted agent",
                    "label": "Restricted Agent",
                },
                {
                    "field": "user_suspended",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user is suspended",
                    "label": "Suspended",
                },
                {
                    "field": "user_report_csv",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user can generate reports in CSV format",
                    "label": "Report CSV",
                },
                {
                    "field": "user_ticket_restriction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Ticket restriction for the user",
                    "label": "Ticket Restriction",
                    "placeholder": "All",
                },
                {
                    "field": "user_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tags for the user",
                    "label": "Tags",
                    "placeholder": "tag1,tag2,tag3",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "ID of the created user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "user_role",
                    "type": "string",
                    "helper_text": "Role of the user",
                },
                {
                    "field": "user_phone",
                    "type": "string",
                    "helper_text": "Phone number of the user",
                },
                {
                    "field": "user_organization_id",
                    "type": "string",
                    "helper_text": "Organization ID of the user",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the user",
                },
                {
                    "field": "user_timezone",
                    "type": "string",
                    "helper_text": "Timezone of the user",
                },
                {
                    "field": "user_tags",
                    "type": "vec<string>",
                    "helper_text": "Tags associated with the user",
                },
                {
                    "field": "user_active",
                    "type": "bool",
                    "helper_text": "Whether the user is active",
                },
                {
                    "field": "user_verified",
                    "type": "bool",
                    "helper_text": "Whether the user is verified",
                },
                {
                    "field": "user_locale",
                    "type": "string",
                    "helper_text": "Locale of the user",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the user was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the user was last updated",
                },
                {
                    "field": "user_url",
                    "type": "string",
                    "helper_text": "URL of the user",
                },
                {
                    "field": "user_details",
                    "type": "string",
                    "helper_text": "User details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_user",
            "task_name": "tasks.zendesk.create_user",
            "description": "Create a new user on Zendesk",
            "label": "Create User",
            "ui_sort_order": [
                "integration",
                "action",
                "user_name",
                "user_email",
                "user_role",
                "user_phone",
                "user_organization_id",
                "user_external_id",
                "user_alias",
                "user_details",
                "user_notes",
                "user_locale",
                "user_timezone",
                "user_signature",
                "user_moderator",
                "user_custom_role_id",
                "user_only_private_comments",
                "user_restricted_agent",
                "user_suspended",
                "user_report_csv",
                "user_ticket_restriction",
                "user_tags",
            ],
            "required": ["user_name", "user_email"],
        },
        "delete_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk user to delete",
                    "label": "Select User",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "ID of the deleted user",
                },
                {
                    "field": "user_details",
                    "type": "string",
                    "helper_text": "User details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_user",
            "task_name": "tasks.zendesk.delete_user",
            "description": "Delete a user on Zendesk",
            "label": "Delete User",
            "ui_sort_order": ["integration", "action", "user_id"],
            "required": ["user_id"],
        },
        "get_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk user to retrieve",
                    "label": "Select User",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "user_role",
                    "type": "string",
                    "helper_text": "Role of the user",
                },
                {
                    "field": "user_phone",
                    "type": "string",
                    "helper_text": "Phone number of the user",
                },
                {
                    "field": "user_organization_id",
                    "type": "string",
                    "helper_text": "Organization ID of the user",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the user",
                },
                {
                    "field": "user_timezone",
                    "type": "string",
                    "helper_text": "Timezone of the user",
                },
                {
                    "field": "user_tags",
                    "type": "vec<string>",
                    "helper_text": "Tags associated with the user",
                },
                {
                    "field": "user_active",
                    "type": "bool",
                    "helper_text": "Whether the user is active",
                },
                {
                    "field": "user_verified",
                    "type": "bool",
                    "helper_text": "Whether the user is verified",
                },
                {
                    "field": "user_locale",
                    "type": "string",
                    "helper_text": "Locale of the user",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the user was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the user was last updated",
                },
                {
                    "field": "user_url",
                    "type": "string",
                    "helper_text": "URL of the user",
                },
                {
                    "field": "user_details",
                    "type": "string",
                    "helper_text": "User details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_user",
            "task_name": "tasks.zendesk.get_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "inputs_sort_order": ["integration", "action", "user_id"],
            "required": ["user_id"],
        },
        "list_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of users to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                },
                {
                    "field": "role",
                    "type": "enum<string>",
                    "value": "",
                    "helper_text": "Filter users by role",
                    "label": "Role Filter",
                    "placeholder": "All",
                    "disable_conversion": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "all"},
                            {"label": "End User", "value": "end-user"},
                            {"label": "Agent", "value": "agent"},
                            {"label": "Admin", "value": "admin"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the users",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the users",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "Emails of the users",
                },
                {
                    "field": "user_roles",
                    "type": "vec<string>",
                    "helper_text": "Roles of the users",
                },
                {
                    "field": "user_phones",
                    "type": "vec<string>",
                    "helper_text": "Phone numbers of the users",
                },
                {
                    "field": "user_active",
                    "type": "vec<bool>",
                    "helper_text": "Active status of the users",
                },
                {
                    "field": "user_urls",
                    "type": "vec<string>",
                    "helper_text": "URLs of the users",
                },
                {
                    "field": "organization_ids",
                    "type": "vec<string>",
                    "helper_text": "Organization IDs of the users",
                },
                {
                    "field": "created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation dates of the users",
                },
                {
                    "field": "updated_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Last update dates of the users",
                },
                {
                    "field": "users_details",
                    "type": "string",
                    "helper_text": "Users details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_users",
            "task_name": "tasks.zendesk.list_users",
            "description": "Get multiple users",
            "label": "List Users",
            "inputs_sort_order": ["integration", "action", "limit", "role"],
            "required": [],
        },
        "search_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "search_query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query for users",
                    "label": "Search Query",
                    "placeholder": "name:john",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the user to search for",
                    "label": "Email",
                    "placeholder": "john@company.com",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the user to search for",
                    "label": "Name",
                    "placeholder": "John Smith",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the user to search for",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                },
                {
                    "field": "role",
                    "type": "enum<string>",
                    "value": "",
                    "helper_text": "Role of the user to search for",
                    "label": "Role",
                    "placeholder": "All",
                    "disable_conversion": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "all"},
                            {"label": "End User", "value": "end-user"},
                            {"label": "Agent", "value": "agent"},
                            {"label": "Admin", "value": "admin"},
                        ],
                    },
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID of the user to search for",
                    "label": "External ID",
                    "placeholder": "external123",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of users to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the matching users",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the matching users",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "Emails of the matching users",
                },
                {
                    "field": "user_roles",
                    "type": "vec<string>",
                    "helper_text": "Roles of the matching users",
                },
                {
                    "field": "search_query",
                    "type": "string",
                    "helper_text": "The search query used",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of matching users",
                },
                {
                    "field": "users_details",
                    "type": "string",
                    "helper_text": "Users details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "search_users",
            "task_name": "tasks.zendesk.search_users",
            "description": "Search users on Zendesk",
            "label": "Search Users",
            "ui_sort_order": [
                "integration",
                "action",
                "search_query",
                "email",
                "name",
                "phone",
                "role",
                "external_id",
                "limit",
            ],
            "required": ["limit"],
        },
        "get_user_organizations**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk user",
                    "label": "Select User",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "organization_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the user's organizations",
                },
                {
                    "field": "organization_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the user's organizations",
                },
                {
                    "field": "organization_urls",
                    "type": "vec<string>",
                    "helper_text": "URLs of the user's organizations",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of organizations",
                },
                {
                    "field": "organizations_details",
                    "type": "string",
                    "helper_text": "Organizations details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_user_organizations",
            "task_name": "tasks.zendesk.get_user_organizations",
            "description": "Get multiple organizations for a user",
            "label": "List User Organizations",
            "inputs_sort_order": ["integration", "action", "user_id"],
            "required": ["user_id"],
        },
        "get_user_related_data**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk user",
                    "label": "Select User",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "requested_tickets",
                    "type": "string",
                    "helper_text": "Tickets requested by the user in JSON format",
                },
                {
                    "field": "ccd_tickets",
                    "type": "string",
                    "helper_text": "Tickets where user is CC'd in JSON format",
                },
                {
                    "field": "assigned_tickets",
                    "type": "string",
                    "helper_text": "Tickets assigned to the user in JSON format",
                },
                {
                    "field": "organizations",
                    "type": "string",
                    "helper_text": "User's organizations in JSON format",
                },
                {
                    "field": "related_data",
                    "type": "string",
                    "helper_text": "All user related data in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_user_related_data",
            "task_name": "tasks.zendesk.get_user_related_data",
            "description": "Read details of a specific user's related data",
            "label": "Get User Related Data",
            "inputs_sort_order": ["integration", "action", "user_id"],
            "required": ["user_id"],
        },
        "update_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk user to update",
                    "label": "Select User",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated name of the user",
                    "label": "User Name",
                    "placeholder": "John Smith",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated email address of the user",
                    "label": "User Email",
                    "placeholder": "john.smith@company.com",
                },
                {
                    "field": "user_role",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated role of the user",
                    "label": "User Role",
                    "placeholder": "end-user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "End User", "value": "end-user"},
                            {"label": "Agent", "value": "agent"},
                            {"label": "Admin", "value": "admin"},
                        ],
                    },
                },
                {
                    "field": "user_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated phone number of the user",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                },
                {
                    "field": "user_organization_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated organization ID for the user",
                    "label": "Organization",
                    "placeholder": "Select organization",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_alias",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated alias for the user",
                    "label": "Alias",
                    "placeholder": "john.smith",
                },
                {
                    "field": "user_details",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated details for the user",
                    "label": "Details",
                    "placeholder": "Internal notes",
                },
                {
                    "field": "user_notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated notes for the user",
                    "label": "Notes",
                    "placeholder": "Internal notes",
                },
                {
                    "field": "user_locale",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated locale for the user",
                    "label": "Locale",
                    "placeholder": "en-US",
                },
                {
                    "field": "user_timezone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated timezone for the user",
                    "label": "Timezone",
                    "placeholder": "America/New_York",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "user_signature",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated signature for the user",
                    "label": "Signature",
                    "placeholder": "Best regards, John Smith",
                },
                {
                    "field": "user_moderator",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user is a moderator",
                    "label": "Moderator",
                },
                {
                    "field": "user_custom_role_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated custom role ID for the user",
                    "label": "Custom Role ID",
                    "placeholder": "123456789",
                },
                {
                    "field": "user_only_private_comments",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user only has private comments",
                    "label": "Only Private Comments",
                },
                {
                    "field": "user_restricted_agent",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user is a restricted agent",
                    "label": "Restricted Agent",
                },
                {
                    "field": "user_suspended",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user is suspended",
                    "label": "Suspended",
                },
                {
                    "field": "user_report_csv",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the user can generate reports in CSV format",
                    "label": "Report CSV",
                },
                {
                    "field": "user_ticket_restriction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated ticket restriction for the user",
                    "label": "Ticket Restriction",
                    "placeholder": "All",
                },
                {
                    "field": "user_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated tags for the user",
                    "label": "Tags",
                    "placeholder": "tag1,tag2,tag3",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "ID of the updated user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Updated name of the user",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Updated email of the user",
                },
                {
                    "field": "user_role",
                    "type": "string",
                    "helper_text": "Updated role of the user",
                },
                {
                    "field": "user_organization_id",
                    "type": "string",
                    "helper_text": "Updated organization ID of the user",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the user was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the user was last updated",
                },
                {
                    "field": "user_url",
                    "type": "string",
                    "helper_text": "URL of the user",
                },
                {
                    "field": "user_details",
                    "type": "string",
                    "helper_text": "Updated user details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_user",
            "task_name": "tasks.zendesk.update_user",
            "description": "Update a user on Zendesk",
            "label": "Update User",
            "ui_sort_order": [
                "integration",
                "action",
                "user_id",
                "user_name",
                "user_email",
                "user_role",
                "user_phone",
                "user_organization_id",
                "user_alias",
                "user_details",
                "user_notes",
                "user_locale",
                "user_timezone",
                "user_signature",
                "user_moderator",
                "user_custom_role_id",
                "user_only_private_comments",
                "user_restricted_agent",
                "user_suspended",
                "user_report_csv",
                "user_ticket_restriction",
                "user_tags",
            ],
            "required": ["user_id"],
        },
        "create_organization**(*)**(*)": {
            "inputs": [
                {
                    "field": "organization_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the organization",
                    "label": "Organization Name",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "organization_domain_names",
                    "type": "string",
                    "value": "",
                    "helper_text": "Domain names for the organization (comma-separated)",
                    "label": "Domain Names",
                    "placeholder": "acme.com,acmecorp.com",
                },
                {
                    "field": "organization_details",
                    "type": "string",
                    "value": "",
                    "helper_text": "Additional details about the organization",
                    "label": "Details",
                    "placeholder": "Customer organization details",
                },
                {
                    "field": "organization_notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Notes about the organization",
                    "label": "Notes",
                    "placeholder": "Internal notes",
                },
                {
                    "field": "organization_external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID for the organization",
                    "label": "External ID",
                    "placeholder": "external123",
                },
                {
                    "field": "organization_group_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Group ID for the organization",
                    "label": "Group ID",
                    "placeholder": "123456789",
                },
                {
                    "field": "organization_shared_tickets",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the organization has shared tickets",
                    "label": "Shared Tickets",
                },
                {
                    "field": "organization_shared_comments",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the organization has shared comments",
                    "label": "Shared Comments",
                },
                {
                    "field": "organization_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tags for the organization",
                    "label": "Tags",
                    "placeholder": "tag1,tag2,tag3",
                },
            ],
            "outputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "helper_text": "ID of the created organization",
                },
                {
                    "field": "organization_name",
                    "type": "string",
                    "helper_text": "Name of the organization",
                },
                {
                    "field": "organization_domain_names",
                    "type": "vec<string>",
                    "helper_text": "Domain names of the organization",
                },
                {
                    "field": "organization_external_id",
                    "type": "string",
                    "helper_text": "External ID of the organization",
                },
                {
                    "field": "organization_shared_tickets",
                    "type": "bool",
                    "helper_text": "Whether the organization has shared tickets",
                },
                {
                    "field": "organization_shared_comments",
                    "type": "bool",
                    "helper_text": "Whether the organization has shared comments",
                },
                {
                    "field": "organization_tags",
                    "type": "vec<string>",
                    "helper_text": "Tags associated with the organization",
                },
                {
                    "field": "organization_group_id",
                    "type": "string",
                    "helper_text": "Group ID of the organization",
                },
                {
                    "field": "organization_url",
                    "type": "string",
                    "helper_text": "URL of the organization",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the organization was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the organization was last updated",
                },
                {
                    "field": "organization_details",
                    "type": "string",
                    "helper_text": "Organization details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_organization",
            "task_name": "tasks.zendesk.create_organization",
            "description": "Create a new organization on Zendesk",
            "label": "Create Organization",
            "ui_sort_order": [
                "integration",
                "action",
                "organization_name",
                "organization_domain_names",
                "organization_details",
                "organization_notes",
                "organization_external_id",
                "organization_group_id",
                "organization_shared_tickets",
                "organization_shared_comments",
                "organization_tags",
            ],
            "required": ["organization_name"],
        },
        "delete_organization**(*)**(*)": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk organization to delete",
                    "label": "Select Organization",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "helper_text": "ID of the deleted organization",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_organization",
            "task_name": "tasks.zendesk.delete_organization",
            "description": "Delete an organization on Zendesk",
            "label": "Delete Organization",
            "ui_sort_order": ["integration", "action", "organization_id"],
            "required": ["organization_id"],
        },
        "get_organization**(*)**(*)": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk organization to retrieve",
                    "label": "Select Organization",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "helper_text": "ID of the organization",
                },
                {
                    "field": "organization_name",
                    "type": "string",
                    "helper_text": "Name of the organization",
                },
                {
                    "field": "organization_domain_names",
                    "type": "vec<string>",
                    "helper_text": "Domain names of the organization",
                },
                {
                    "field": "organization_external_id",
                    "type": "string",
                    "helper_text": "External ID of the organization",
                },
                {
                    "field": "organization_shared_tickets",
                    "type": "bool",
                    "helper_text": "Whether the organization has shared tickets",
                },
                {
                    "field": "organization_shared_comments",
                    "type": "bool",
                    "helper_text": "Whether the organization has shared comments",
                },
                {
                    "field": "organization_tags",
                    "type": "vec<string>",
                    "helper_text": "Tags associated with the organization",
                },
                {
                    "field": "organization_group_id",
                    "type": "string",
                    "helper_text": "Group ID of the organization",
                },
                {
                    "field": "organization_url",
                    "type": "string",
                    "helper_text": "URL of the organization",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the organization was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the organization was last updated",
                },
                {
                    "field": "organization_details",
                    "type": "string",
                    "helper_text": "Organization details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_organization",
            "task_name": "tasks.zendesk.get_organization",
            "description": "Read details of a specific organization",
            "label": "Get Organization",
            "inputs_sort_order": ["integration", "action", "organization_id"],
            "required": ["organization_id"],
        },
        "list_organizations**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of organizations to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return all organizations",
                    "label": "Return All",
                },
            ],
            "outputs": [
                {
                    "field": "organization_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the organizations",
                },
                {
                    "field": "organization_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the organizations",
                },
                {
                    "field": "organization_domain_names",
                    "type": "vec<vec<string>>",
                    "helper_text": "Domain names of the organizations",
                },
                {
                    "field": "organization_urls",
                    "type": "vec<string>",
                    "helper_text": "URLs of the organizations",
                },
                {
                    "field": "organization_tags",
                    "type": "vec<vec<string>>",
                    "helper_text": "Tags of the organizations",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of organizations",
                },
                {
                    "field": "created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation dates of the organizations",
                },
                {
                    "field": "updated_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Last update dates of the organizations",
                },
                {
                    "field": "organizations_details",
                    "type": "string",
                    "helper_text": "Organizations details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_organizations",
            "task_name": "tasks.zendesk.list_organizations",
            "description": "Get multiple organizations",
            "label": "List Organizations",
            "inputs_sort_order": ["integration", "action", "limit", "return_all"],
            "required": [],
        },
        "count_organizations**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "result",
                    "type": "int32",
                    "helper_text": "Total number of organizations in Zendesk",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "count_organizations",
            "task_name": "tasks.zendesk.count_organizations",
            "description": "Get the total count of organizations",
            "label": "Count Organizations",
            "inputs_sort_order": ["integration", "action"],
            "required": [],
        },
        "get_organization_related_data**(*)**(*)": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk organization",
                    "label": "Select Organization",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "helper_text": "ID of the organization",
                },
                {
                    "field": "tickets_count",
                    "type": "int32",
                    "helper_text": "Number of tickets in the organization",
                },
                {
                    "field": "users_count",
                    "type": "int32",
                    "helper_text": "Number of users in the organization",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_organization_related_data",
            "task_name": "tasks.zendesk.get_organization_related_data",
            "description": "Read details of a specific organization's related data",
            "label": "Get Organization Related Data",
            "inputs_sort_order": ["integration", "action", "organization_id"],
            "required": ["organization_id"],
        },
        "update_organization**(*)**(*)": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the Zendesk organization to update",
                    "label": "Select Organization",
                    "placeholder": "123",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "organization_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated name of the organization",
                    "label": "Organization Name",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "organization_domain_names",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated domain names for the organization (comma-separated)",
                    "label": "Domain Names",
                    "placeholder": "acme.com,acmecorp.com",
                },
                {
                    "field": "organization_details",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated details about the organization",
                    "label": "Details",
                    "placeholder": "Customer organization details",
                },
                {
                    "field": "organization_notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated notes about the organization",
                    "label": "Notes",
                    "placeholder": "Internal notes",
                },
                {
                    "field": "organization_external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated external ID for the organization",
                    "label": "External ID",
                    "placeholder": "external123",
                },
                {
                    "field": "organization_group_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated group ID for the organization",
                    "label": "Group ID",
                    "placeholder": "123456789",
                },
                {
                    "field": "organization_shared_tickets",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the organization has shared tickets",
                    "label": "Shared Tickets",
                },
                {
                    "field": "organization_shared_comments",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the organization has shared comments",
                    "label": "Shared Comments",
                },
                {
                    "field": "organization_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Updated tags for the organization",
                    "label": "Tags",
                    "placeholder": "tag1,tag2,tag3",
                },
            ],
            "outputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "helper_text": "ID of the updated organization",
                },
                {
                    "field": "organization_name",
                    "type": "string",
                    "helper_text": "Updated name of the organization",
                },
                {
                    "field": "organization_domain_names",
                    "type": "vec<string>",
                    "helper_text": "Updated domain names of the organization",
                },
                {
                    "field": "organization_url",
                    "type": "string",
                    "helper_text": "URL of the organization",
                },
                {
                    "field": "organization_tags",
                    "type": "vec<string>",
                    "helper_text": "Updated tags of the organization",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the organization was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Date and time the organization was last updated",
                },
                {
                    "field": "organization_details",
                    "type": "string",
                    "helper_text": "Updated organization details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_organization",
            "task_name": "tasks.zendesk.update_organization",
            "description": "Update an organization on Zendesk",
            "label": "Update Organization",
            "ui_sort_order": [
                "integration",
                "action",
                "organization_id",
                "organization_name",
                "organization_domain_names",
                "organization_details",
                "organization_notes",
                "organization_external_id",
                "organization_group_id",
                "organization_shared_tickets",
                "organization_shared_comments",
                "organization_tags",
            ],
            "required": ["organization_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "limit"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        assignee: str = "",
        body: str = "",
        brand: str = "",
        comment: str = "",
        comment_exact: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        description: str = "",
        due: str = "",
        email: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        external_id: str = "",
        group: str = "",
        include: str = "",
        limit: int = 10,
        name: str = "",
        num_messages: int = 10,
        organization: str = "",
        organization_details: str = "",
        organization_domain_names: str = "",
        organization_external_id: str = "",
        organization_group_id: str = "",
        organization_id: str = "",
        organization_name: str = "",
        organization_notes: str = "",
        organization_shared_comments: bool = False,
        organization_shared_tickets: bool = False,
        organization_tags: str = "",
        phone: str = "",
        priority: str = "",
        public: bool = True,
        requester: str = "",
        requester_email: str = "",
        requester_name: str = "",
        return_all: bool = False,
        role: str = "",
        satisfaction: str = "",
        search_query: str = "",
        solved: str = "",
        sort_by: str = "",
        sort_order: str = "",
        status: str = "",
        subject: str = "",
        subject_exact: str = "",
        ticket_body: str = "",
        ticket_field_id: str = "",
        ticket_form: str = "",
        ticket_group_id: str = "",
        ticket_id: str = "",
        ticket_priority: str = "",
        ticket_status: str = "",
        ticket_subject: str = "",
        ticket_type: str = "",
        update_ticket_assignee_id: str = "",
        update_ticket_body: str = "",
        update_ticket_group_id: str = "",
        update_ticket_subject: str = "",
        updated: str = "",
        user_alias: str = "",
        user_custom_role_id: str = "",
        user_details: str = "",
        user_email: str = "",
        user_external_id: str = "",
        user_id: str = "",
        user_locale: str = "",
        user_moderator: bool = False,
        user_name: str = "",
        user_notes: str = "",
        user_only_private_comments: bool = False,
        user_organization_id: str = "",
        user_phone: str = "",
        user_report_csv: bool = False,
        user_restricted_agent: bool = False,
        user_role: str = "end-user",
        user_signature: str = "",
        user_suspended: bool = False,
        user_tags: str = "",
        user_ticket_restriction: str = "",
        user_timezone: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_zendesk",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if ticket_subject is not None:
            self.inputs["ticket_subject"] = ticket_subject
        if ticket_body is not None:
            self.inputs["ticket_body"] = ticket_body
        if requester_email is not None:
            self.inputs["requester_email"] = requester_email
        if requester_name is not None:
            self.inputs["requester_name"] = requester_name
        if ticket_priority is not None:
            self.inputs["ticket_priority"] = ticket_priority
        if ticket_type is not None:
            self.inputs["ticket_type"] = ticket_type
        if ticket_status is not None:
            self.inputs["ticket_status"] = ticket_status
        if ticket_group_id is not None:
            self.inputs["ticket_group_id"] = ticket_group_id
        if ticket_id is not None:
            self.inputs["ticket_id"] = ticket_id
        if update_ticket_subject is not None:
            self.inputs["update_ticket_subject"] = update_ticket_subject
        if update_ticket_body is not None:
            self.inputs["update_ticket_body"] = update_ticket_body
        if update_ticket_assignee_id is not None:
            self.inputs["update_ticket_assignee_id"] = update_ticket_assignee_id
        if update_ticket_group_id is not None:
            self.inputs["update_ticket_group_id"] = update_ticket_group_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if assignee is not None:
            self.inputs["assignee"] = assignee
        if requester is not None:
            self.inputs["requester"] = requester
        if organization is not None:
            self.inputs["organization"] = organization
        if priority is not None:
            self.inputs["priority"] = priority
        if status is not None:
            self.inputs["status"] = status
        if subject is not None:
            self.inputs["subject"] = subject
        if subject_exact is not None:
            self.inputs["subject_exact"] = subject_exact
        if description is not None:
            self.inputs["description"] = description
        if body is not None:
            self.inputs["body"] = body
        if comment is not None:
            self.inputs["comment"] = comment
        if comment_exact is not None:
            self.inputs["comment_exact"] = comment_exact
        if updated is not None:
            self.inputs["updated"] = updated
        if solved is not None:
            self.inputs["solved"] = solved
        if due is not None:
            self.inputs["due"] = due
        if brand is not None:
            self.inputs["brand"] = brand
        if satisfaction is not None:
            self.inputs["satisfaction"] = satisfaction
        if ticket_form is not None:
            self.inputs["ticket_form"] = ticket_form
        if group is not None:
            self.inputs["group"] = group
        if sort_by is not None:
            self.inputs["sort_by"] = sort_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if external_id is not None:
            self.inputs["external_id"] = external_id
        if include is not None:
            self.inputs["include"] = include
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if public is not None:
            self.inputs["public"] = public
        if ticket_field_id is not None:
            self.inputs["ticket_field_id"] = ticket_field_id
        if limit is not None:
            self.inputs["limit"] = limit
        if user_name is not None:
            self.inputs["user_name"] = user_name
        if user_email is not None:
            self.inputs["user_email"] = user_email
        if user_role is not None:
            self.inputs["user_role"] = user_role
        if user_phone is not None:
            self.inputs["user_phone"] = user_phone
        if user_organization_id is not None:
            self.inputs["user_organization_id"] = user_organization_id
        if user_external_id is not None:
            self.inputs["user_external_id"] = user_external_id
        if user_alias is not None:
            self.inputs["user_alias"] = user_alias
        if user_details is not None:
            self.inputs["user_details"] = user_details
        if user_notes is not None:
            self.inputs["user_notes"] = user_notes
        if user_locale is not None:
            self.inputs["user_locale"] = user_locale
        if user_timezone is not None:
            self.inputs["user_timezone"] = user_timezone
        if user_signature is not None:
            self.inputs["user_signature"] = user_signature
        if user_moderator is not None:
            self.inputs["user_moderator"] = user_moderator
        if user_custom_role_id is not None:
            self.inputs["user_custom_role_id"] = user_custom_role_id
        if user_only_private_comments is not None:
            self.inputs["user_only_private_comments"] = user_only_private_comments
        if user_restricted_agent is not None:
            self.inputs["user_restricted_agent"] = user_restricted_agent
        if user_suspended is not None:
            self.inputs["user_suspended"] = user_suspended
        if user_report_csv is not None:
            self.inputs["user_report_csv"] = user_report_csv
        if user_ticket_restriction is not None:
            self.inputs["user_ticket_restriction"] = user_ticket_restriction
        if user_tags is not None:
            self.inputs["user_tags"] = user_tags
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if role is not None:
            self.inputs["role"] = role
        if search_query is not None:
            self.inputs["search_query"] = search_query
        if email is not None:
            self.inputs["email"] = email
        if name is not None:
            self.inputs["name"] = name
        if phone is not None:
            self.inputs["phone"] = phone
        if organization_name is not None:
            self.inputs["organization_name"] = organization_name
        if organization_domain_names is not None:
            self.inputs["organization_domain_names"] = organization_domain_names
        if organization_details is not None:
            self.inputs["organization_details"] = organization_details
        if organization_notes is not None:
            self.inputs["organization_notes"] = organization_notes
        if organization_external_id is not None:
            self.inputs["organization_external_id"] = organization_external_id
        if organization_group_id is not None:
            self.inputs["organization_group_id"] = organization_group_id
        if organization_shared_tickets is not None:
            self.inputs["organization_shared_tickets"] = organization_shared_tickets
        if organization_shared_comments is not None:
            self.inputs["organization_shared_comments"] = organization_shared_comments
        if organization_tags is not None:
            self.inputs["organization_tags"] = organization_tags
        if organization_id is not None:
            self.inputs["organization_id"] = organization_id
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationZendeskNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
