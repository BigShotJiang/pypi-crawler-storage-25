"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_trello")
class IntegrationTrelloNode(Node):
    """
    Trello

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### create_card_comment
        text: The text content of the comment
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### update_card_comment
        text: The text content of the comment
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        comment_id: The ID of the comment to update
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### get_board
        actions: Optional: Include board activity/actions. Options: all, createCard, updateCard, commentCard, etc. Leave empty to exclude
        board_id: The ID of the board to retrieve
        board_stars: Optional: Include board stars. Use 'mine' for current user's stars or 'none' to exclude
        card_plugin_data: Optional: Include plugin data for cards (requires cards to be included)
        cards: Optional: Include cards from the board. Options: all, open, closed, visible. Leave empty to exclude cards
        checklists: Optional: Include checklists. Options: all, none. Leave empty to exclude
        custom_fields: Optional: Include custom field definitions for the board
        fields: Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned
        labels: Optional: Include labels from the board. Options: all, none. Leave empty to exclude
        lists: Optional: Include lists from the board. Options: all, open, closed. Leave empty to exclude
        members: Optional: Include board members. Options: all, admins, normal, owners. Leave empty to exclude
        memberships: Optional: Include membership details. Options: all, active, admin, deactivated, me, normal. Leave empty to exclude
        organization: Optional: Include organization details that owns this board
        organization_id: The organization to create the board in
        organization_plugin_data: Optional: Include Power-Up/plugin data for the organization
        plugin_data: Optional: Include Power-Up/plugin data for the board
        tags: Optional: Include board tags
    ### get_card
        actions: Optional: Include board activity/actions. Options: all, createCard, updateCard, commentCard, etc. Leave empty to exclude
        attachment_fields: Optional: Specify which attachment properties to include (e.g., name, url, mimeType). Only applies when attachments are included
        attachments: Optional: Include attachments from this card
        board: Optional: Include parent board information in the response
        board_fields: Optional: Specify which board properties to include (e.g., name, desc, url). Only applies when board is included
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        check_item_states: Optional: Include the state of all checklist items (complete/incomplete counts)
        checklists: Optional: Include checklists. Options: all, none. Leave empty to exclude
        custom_field_items: Optional: Include custom field values for this card
        fields: Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned
        list: Optional: Include parent list information for this card
        list_id: The ID of the list to retrieve
        member_fields: Optional: Specify which member properties to include (e.g., fullName, username). Only applies when members are included
        member_voted_fields: Optional: Specify which properties to include for voting members. Only applies when members_voted is enabled
        members: Optional: Include board members. Options: all, admins, normal, owners. Leave empty to exclude
        members_voted: Optional: Include members who voted on this card
        organization_id: The organization to create the board in
        plugin_data: Optional: Include Power-Up/plugin data for the board
        sticker_fields: Optional: Specify which sticker properties to include. Only applies when stickers are included
        stickers: Optional: Include stickers attached to this card
    ### create_card
        address: Physical address for the card location (optional)
        board_id: The ID of the board to retrieve
        coordinates: Coordinates in latitude,longitude format (optional)
        description: Optional description for the board
        due_complete: Mark the due date as complete (optional)
        due_date: Due date in ISO format (optional)
        id_card_source: Copy details from an existing card (optional)
        id_labels: Add labels to the card - comma-separated IDs or use dropdown (optional)
        id_members: Assign members to the card - comma-separated IDs or use dropdown (optional)
        keep_from_source: Comma-separated list of items to keep from source board (optional)
        list_id: The ID of the list to retrieve
        location_name: Name of the location (optional)
        name: The name of the new board
        organization_id: The organization to create the board in
        position: Position of the list on the board
        start_date: Start date in ISO format (optional)
        url_source: Create card from URL - Trello will fetch details from this URL (optional)
    ### update_card
        address: Physical address for the card location (optional)
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        closed: Whether the board should be closed (archived)
        coordinates: Coordinates in latitude,longitude format (optional)
        description: Optional description for the board
        due_complete: Mark the due date as complete (optional)
        due_date: Due date in ISO format (optional)
        id_attachment_cover: ID of attachment to use as card cover (optional)
        id_labels: Add labels to the card - comma-separated IDs or use dropdown (optional)
        id_members: Assign members to the card - comma-separated IDs or use dropdown (optional)
        list_id: The ID of the list to retrieve
        location_name: Name of the location (optional)
        name: The name of the new board
        new_list_id: Move card to this list (optional)
        organization_id: The organization to create the board in
        pos: Change the position of the list on the board (optional)
        start_date: Start date in ISO format (optional)
        subscribed: Subscribe/unsubscribe to list notifications (optional)
    ### add_board_member
        allow_billable_guest: Allow adding this member as a billable guest (important for billing control - prevents accidental charges)
        board_id: The ID of the board to retrieve
        member_id: The ID of the member to add
        member_type: Type of membership. Normal: Standard board member. Admin: Board administrator (restricted - only available if you have permission to assign admin roles). Observer: View-only access (requires Trello Premium/Enterprise). Note: Changing an admin to normal cannot be reversed. Warning: Adding an existing member will update their role.
        organization_id: The organization to create the board in
    ### get_attachment
        attachment_id: The ID of the attachment to retrieve
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        download_file: Whether to download the attachment file
        fields: Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### delete_attachment
        attachment_id: The ID of the attachment to retrieve
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### get_list
        board: Optional: Include parent board information in the response
        board_fields: Optional: Specify which board properties to include (e.g., name, desc, url). Only applies when board is included
        board_id: The ID of the board to retrieve
        card_fields: Optional: Specify which card properties to include (e.g., name, due, labels). Only applies when cards are included
        cards: Optional: Include cards from the board. Options: all, open, closed, visible. Leave empty to exclude cards
        fields: Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### list_lists
        board: Optional: Include parent board information in the response
        board_fields: Optional: Specify which board properties to include (e.g., name, desc, url). Only applies when board is included
        board_id: The ID of the board to retrieve
        card_fields: Optional: Specify which card properties to include (e.g., name, due, labels). Only applies when cards are included
        cards: Optional: Include cards from the board. Options: all, open, closed, visible. Leave empty to exclude cards
        fields: Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned
        organization_id: The organization to create the board in
    ### update_board
        board_id: The ID of the board to retrieve
        closed: Whether the board should be closed (archived)
        description: Optional description for the board
        id_organization: Move board to a different organization (optional)
        label_names_blue: Name for blue label
        label_names_green: Name for green label
        label_names_orange: Name for orange label
        label_names_purple: Name for purple label
        label_names_red: Name for red label
        label_names_yellow: Name for yellow label
        name: The name of the new board
        organization_id: The organization to create the board in
        prefs_background: Background color or image for the board
        prefs_card_aging: Card aging visual style
        prefs_card_covers: Whether card covers are enabled
        prefs_comments: Who can comment on cards
        prefs_hide_votes: Whether to hide voting results
        prefs_invitations: Who can invite members to the board
        prefs_permission_level: Permission level for the board
        prefs_self_join: Whether members can join the board themselves
        prefs_voting: Who can vote on cards
    ### delete_board
        board_id: The ID of the board to retrieve
        organization_id: The organization to create the board in
    ### list_board_members
        board_id: The ID of the board to retrieve
        organization_id: The organization to create the board in
    ### invite_board_member
        board_id: The ID of the board to retrieve
        email: Email address of the person to invite
        full_name: Full name of the person to invite
        member_type: Type of membership. Normal: Standard board member. Admin: Board administrator (restricted - only available if you have permission to assign admin roles). Observer: View-only access (requires Trello Premium/Enterprise). Note: Changing an admin to normal cannot be reversed. Warning: Adding an existing member will update their role.
        organization_id: The organization to create the board in
    ### remove_board_member
        board_id: The ID of the board to retrieve
        member_id: The ID of the member to add
        organization_id: The organization to create the board in
    ### create_list
        board_id: The ID of the board to retrieve
        name: The name of the new board
        organization_id: The organization to create the board in
        position: Position of the list on the board
    ### update_list
        board_id: The ID of the board to retrieve
        closed: Whether the board should be closed (archived)
        list_id: The ID of the list to retrieve
        name: The name of the new board
        new_board_id: Move this list to a different board (optional)
        organization_id: The organization to create the board in
        pos: Change the position of the list on the board (optional)
        subscribed: Subscribe/unsubscribe to list notifications (optional)
    ### archive_unarchive_list
        board_id: The ID of the board to retrieve
        closed: Whether the board should be closed (archived)
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### list_cards_in_list
        board_id: The ID of the board to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### delete_card
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### delete_card_comment
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        comment_id: The ID of the comment to update
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### create_attachment
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        list_id: The ID of the list to retrieve
        mime_type: The MIME type of the attachment
        name: The name of the new board
        organization_id: The organization to create the board in
        set_cover: Set the attachment as the cover of the card
        url: The URL of the attachment
    ### list_attachments
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        fields: Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned
        filter: Filter attachments
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### create_checklist
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        id_checklist_source: Copy items from an existing checklist (optional - leave blank to create empty checklist)
        list_id: The ID of the list to retrieve
        name: The name of the new board
        organization_id: The organization to create the board in
        pos: Change the position of the list on the board (optional)
    ### get_checklist
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checklist_id: The ID of the checklist to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### list_checklists
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### delete_checklist
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checklist_id: The ID of the checklist to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### create_checklist_item
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checked: Whether the item is checked
        checklist_id: The ID of the checklist to retrieve
        due: Due date for the checklist item in ISO format (optional)
        id_member: ID of the member to assign to this checklist item (optional)
        list_id: The ID of the list to retrieve
        name: The name of the new board
        organization_id: The organization to create the board in
        pos: Change the position of the list on the board (optional)
    ### get_checklist_item
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checklist_id: The ID of the checklist to retrieve
        checklist_item_id: The ID of the checklist item to get
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### get_completed_checklist_items
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checklist_id: The ID of the checklist to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### update_checklist_item
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checked: Whether the item is checked
        checklist_id: The ID of the checklist to retrieve
        checklist_item_id: The ID of the checklist item to get
        due: Due date for the checklist item in ISO format (optional)
        id_member: ID of the member to assign to this checklist item (optional)
        list_id: The ID of the list to retrieve
        name: The name of the new board
        organization_id: The organization to create the board in
        pos: Change the position of the list on the board (optional)
    ### delete_checklist_item
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        checklist_id: The ID of the checklist to retrieve
        checklist_item_id: The ID of the checklist item to get
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### create_label
        board_id: The ID of the board to retrieve
        color: The color of the label (e.g., blue, green, yellow, etc)
        name: The name of the new board
        organization_id: The organization to create the board in
    ### get_label
        board_id: The ID of the board to retrieve
        label_id: The ID of the label to retrieve
        organization_id: The organization to create the board in
    ### list_labels
        board_id: The ID of the board to retrieve
        organization_id: The organization to create the board in
    ### update_label
        board_id: The ID of the board to retrieve
        color: The color of the label (e.g., blue, green, yellow, etc)
        label_id: The ID of the label to retrieve
        name: The name of the new board
        organization_id: The organization to create the board in
    ### delete_label
        board_id: The ID of the board to retrieve
        label_id: The ID of the label to retrieve
        organization_id: The organization to create the board in
    ### add_label_to_card
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        label_id: The ID of the label to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### remove_label_from_card
        board_id: The ID of the board to retrieve
        card_id: The ID of the card to retrieve
        label_id: The ID of the label to retrieve
        list_id: The ID of the list to retrieve
        organization_id: The organization to create the board in
    ### create_board
        default_labels: Whether to create default labels for the board
        default_lists: Whether to create default lists (To Do, Doing, Done) for the board
        description: Optional description for the board
        id_board_source: ID of an existing board to copy settings from (optional)
        keep_from_source: Comma-separated list of items to keep from source board (optional)
        name: The name of the new board
        organization_id: The organization to create the board in
        power_ups: Comma-separated list of power-ups to enable (optional)
        prefs_background: Background color or image for the board
        prefs_card_aging: Card aging visual style
        prefs_comments: Who can comment on cards
        prefs_invitations: Who can invite members to the board
        prefs_permission_level: Permission level for the board
        prefs_voting: Who can vote on cards

    ## Outputs
    ### list_attachments
        attachment_dates: List of attachment creation dates on the card
        attachment_ids: List of attachment IDs on the card
        attachment_mime_types: List of attachment MIME types on the card
        attachment_names: List of attachment names on the card
        attachment_sizes: List of attachment sizes in bytes on the card
        attachment_urls: List of attachment URLs on the card
        raw_data: Raw response data from Trello API
        total_count: Total number of attachments on the card
    ### create_attachment
        attachment_id: Unique identifier of the created attachment
        attachment_name: Name of the created attachment
        attachment_url: URL of the created attachment
        bytes: Size of the attachment in bytes
        date: When the attachment was created
        is_upload: Whether the attachment is uploaded or not
        mime_type: MIME type of the created attachment
        raw_data: Raw response data from Trello API
    ### get_attachment
        attachment_id: Unique identifier of the attachment
        attachment_name: Name of the attachment
        attachment_url: URL of the attachment
        bytes: Size of the attachment in bytes
        date: When the attachment was created
        download_error: Error message if file download failed (if requested)
        file: Downloaded file data (if download_file is requested)
        file_name: File name of the attachment
        is_upload: Whether the attachment is uploaded
        mime_type: MIME type of the attachment
        raw_data: Raw response data from Trello API
    ### get_card
        attachments_count: Number of attachments on the card
        board_id: ID of the board containing the card
        card_description: Description of the card
        card_id: Unique identifier of the card
        card_name: Name of the card
        card_short_url: Short URL of the card
        card_url: URL of the card
        checklist_items_checked_count: Number of checked checklist items on the card
        checklist_items_count: Number of checklist items on the card
        comments_count: Number of comments on the card
        date_last_activity: Date of last activity on the card
        due_complete: Whether the due date is marked as complete
        due_date: Due date of the card (if set)
        has_description: Whether the card has a description
        is_closed: Whether the card is closed
        is_subscribed: Whether the user is subscribed to the card
        label_colors: List of label colors on the card (if any)
        label_ids: List of label IDs on the card (if any)
        label_names: List of label names on the card (if any)
        list_id: ID of the list containing the card
        member_ids: List of member IDs assigned to the card (if any)
        member_names: List of member names assigned to the card (if any)
        member_usernames: List of member usernames assigned to the card (if any)
        position: Position of the card in the list
        raw_data: Raw response data from Trello API
        start_date: Start date of the card (if set)
        votes_count: Number of votes on the card
    ### create_card_comment
        author_name: Name of the comment author
        board_id: ID of the board containing the card
        card_id: ID of the card the comment was created on
        comment_id: Unique identifier of the created comment
        comment_text: Text content of the comment
        date: When the comment was created
        list_id: ID of the list containing the card
        organization_id: ID of the organization containing the board
        raw_data: Raw response data from Trello API
    ### create_board
        board_description: Description of the created board
        board_id: Unique identifier of the created board
        board_name: Name of the created board
        board_short_url: Short URL of the created board
        board_url: URL of the created board
        date_last_activity: Date of last activity on the board
        id_organization: ID of the organization containing the board
        is_closed: Whether the board is closed
        raw_data: Raw response data from Trello API
    ### get_board
        board_description: Description of the board
        board_id: Unique identifier of the board
        board_name: Name of the board
        board_short_url: Short URL of the board
        board_url: URL of the board
        id_organization: ID of the organization containing the board
        is_closed: Whether the board is closed
        label_colors: List of label colors on the board (if requested)
        label_ids: List of label IDs on the board (if requested)
        label_names: List of label names on the board (if requested)
        list_ids: List of list IDs on the board (if requested)
        list_names: List of list names on the board (if requested)
        member_ids: List of member IDs on the board (if requested)
        member_names: List of member names on the board (if requested)
        member_usernames: List of member usernames on the board (if requested)
        raw_data: Raw response data from Trello API
    ### update_board
        board_description: Updated description of the board
        board_id: Unique identifier of the updated board
        board_name: Updated name of the board
        board_short_url: Short URL of the board
        board_url: URL of the board
        date_last_activity: Date of last activity on the board
        id_organization: ID of the organization containing the board
        is_closed: Whether the board is closed
        raw_data: Raw response data from Trello API
    ### create_list
        board_id: ID of the board containing the list
        is_closed: Whether the list is closed
        list_id: Unique identifier of the created list
        list_name: Name of the created list
        position: Position of the list on the board
        raw_data: Raw response data from Trello API
        subscribed: Whether the user is subscribed to the list
    ### get_list
        board_id: ID of the board containing the list
        card_descriptions: List of card descriptions in the list (if requested)
        card_ids: List of card IDs in the list (if requested)
        card_names: List of card names in the list (if requested)
        cards_count: Number of cards in the list (if requested)
        is_closed: Whether the list is closed
        list_id: Unique identifier of the list
        list_name: Name of the list
        position: Position of the list on the board
        raw_data: Raw response data from Trello API
        subscribed: Whether the user is subscribed to the list
    ### update_list
        board_id: ID of the board containing the list
        is_closed: Whether the list is closed
        list_id: Unique identifier of the updated list
        list_name: Updated name of the list
        position: Position of the list on the board
        raw_data: Raw response data from Trello API
        subscribed: Whether the user is subscribed to the list
    ### create_card
        board_id: ID of the board containing the card
        card_description: Description of the created card
        card_id: Unique identifier of the created card
        card_name: Name of the created card
        card_short_url: Short URL of the created card
        card_url: URL of the created card
        date_last_activity: Date of last activity on the card
        due_date: Due date of the card (if set)
        is_closed: Whether the card is closed
        list_id: ID of the list containing the card
        member_ids: List of member IDs assigned to the card (if any)
        position: Position of the card in the list
        raw_data: Raw response data from Trello API
    ### update_card
        board_id: ID of the board containing the card
        card_description: Updated description of the card
        card_id: Unique identifier of the updated card
        card_name: Updated name of the card
        card_short_url: Short URL of the card
        card_url: URL of the card
        date_last_activity: Date of last activity on the card
        due_date: Due date of the card (if set)
        is_closed: Whether the card is closed
        label_ids: List of label IDs on the card (if any)
        list_id: ID of the list containing the card
        member_ids: List of member IDs assigned to the card (if any)
        position: Position of the card in the list
        raw_data: Raw response data from Trello API
    ### create_label
        board_id: ID of the board containing the label
        color: Color of the created label
        label_id: Unique identifier of the created label
        label_name: Name of the created label
        raw_data: Raw response data from Trello API
    ### get_label
        board_id: ID of the board containing the label
        label_color: Color of the label
        label_id: Unique identifier of the label
        label_name: Name of the label
        raw_data: Raw response data from Trello API
        uses: Number of times the label is used
    ### list_cards_in_list
        card_closed_statuses: List of card closed statuses in the list
        card_date_last_activities: List of card last activity dates in the list
        card_descriptions: List of card descriptions in the list
        card_due_complete_statuses: List of card due complete statuses in the list
        card_due_dates: List of card due dates in the list
        card_ids: List of card IDs in the list
        card_names: List of card names in the list
        card_positions: List of card positions in the list
        card_urls: List of card URLs in the list
        raw_data: Raw response data from Trello API
        total_count: Total number of cards in the list
    ### create_checklist
        card_id: ID of the card containing the checklist
        check_item_ids: List of check item IDs in the checklist (if any)
        check_item_names: List of check item names in the checklist (if any)
        check_item_states: List of check item states in the checklist (if any)
        check_items_count: Number of items in the checklist (if any)
        checklist_id: Unique identifier of the created checklist
        checklist_name: Name of the created checklist
        position: Position of the checklist
        raw_data: Raw response data from Trello API
    ### get_checklist
        card_id: ID of the card containing the checklist
        check_item_due_dates: List of check item due dates in the checklist
        check_item_ids: List of check item IDs in the checklist
        check_item_names: List of check item names in the checklist
        check_item_positions: List of check item positions in the checklist
        check_item_states: List of check item states in the checklist
        check_items_count: Total number of items in the checklist
        checklist_id: Unique identifier of the checklist
        checklist_name: Name of the checklist
        completed_items_count: Number of completed items in the checklist
        incomplete_items_count: Number of incomplete items in the checklist
        position: Position of the checklist
        raw_data: Raw response data from Trello API
    ### add_label_to_card
        card_id: The ID of the card the label was added to
        label_id: The ID of the label that was added
        message: Message indicating the result of the operation
        raw_data: Raw response data from Trello API
    ### remove_label_from_card
        card_id: The ID of the card the label was removed from
        label_id: The ID of the label that was removed
        message: Message indicating the result of the operation
        raw_data: Descriptive message about the operation performed
    ### create_checklist_item
        checked: Whether the item is checked
        checklist_id: ID of the checklist containing the item
        item_id: Unique identifier of the created checklist item
        item_name: Name of the created checklist item
        raw_data: Raw response data from Trello API
    ### update_checklist_item
        checked: Whether the item is checked
        due_date: Due date of the checklist item
        id_member: ID of the member assigned to the checklist item
        item_id: Unique identifier of the updated checklist item
        name: Updated name of the checklist item
        position: Position of the checklist item
        raw_data: Raw response data from Trello API
    ### list_checklists
        checklist_completed_counts: Number of completed items in each checklist
        checklist_ids: List of checklist IDs on the card
        checklist_item_counts: Number of items in each checklist
        checklist_names: List of checklist names on the card
        raw_data: Raw response data from Trello API
        total_count: Total number of checklists on the card
    ### get_checklist_item
        checklist_item_id: Unique identifier of the checklist item
        checklist_item_name: Name of the checklist item
        due_date: Due date of the checklist item
        id_member: ID of the member assigned to the checklist item
        position: Position of the checklist item
        raw_data: Raw response data from Trello API
        state: State of the checklist item
    ### archive_unarchive_list
        closed: Whether the list is now closed (archived)
        list_id: ID of the list
        raw_data: Raw response data from Trello API
    ### update_label
        color: Updated color of the label
        label_id: Unique identifier of the updated label
        name: Updated name of the label
        raw_data: Raw response data from Trello API
    ### update_card_comment
        comment_id: Unique identifier of the updated comment
        comment_text: Updated text content of the comment
        date: When the comment was last updated
        raw_data: Raw response data from Trello API
    ### get_completed_checklist_items
        completed_count: Number of completed items
        completed_item_ids: List of completed checklist item IDs
        completed_item_states: List of completed checklist item states
        raw_data: Raw response data from Trello API
    ### list_labels
        label_colors: List of label colors on the board
        label_ids: List of label IDs on the board
        label_names: List of label names on the board
        label_uses: List of label usage counts on the board
        raw_data: Raw response data from Trello API
        total_count: Total number of labels on the board
    ### list_lists
        list_board_ids: List of board IDs for each list
        list_closed_statuses: List of list closed statuses on the board
        list_ids: List of list IDs on the board
        list_names: List of list names on the board
        list_positions: List of list positions on the board
        list_subscribed_statuses: List of list subscribed statuses on the board
        raw_data: Raw response data from Trello API
        total_count: Total number of lists on the board
    ### list_board_members
        member_avatar_urls: List of member avatar URLs on the board
        member_emails: List of member emails on the board
        member_full_names: List of member full names on the board
        member_ids: List of member IDs on the board
        member_usernames: List of member usernames on the board
        raw_data: Raw response data from Trello API
        total_count: Total number of members on the board
    ### add_board_member
        member_id: ID of the added member
        raw_data: Raw response data from Trello API
    ### invite_board_member
        member_id: ID of the invited member
        raw_data: Raw response data from Trello API
    ### delete_board
        message: Success message
        raw_data: Descriptive message about the deletion operation
    ### delete_card
        message: Success message
        raw_data: Descriptive message about the deletion operation
    ### delete_attachment
        message: Success message describing the deletion
        raw_data: Descriptive message about the deletion operation
    ### remove_board_member
        raw_data: Descriptive message about the removal operation
    ### delete_card_comment
        raw_data: Raw response data from Trello API
    ### delete_checklist
        raw_data: Descriptive message about the deletion operation
    ### delete_checklist_item
        raw_data: Descriptive message about the deletion operation
    ### delete_label
        raw_data: Descriptive message about the deletion operation
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Trello>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_board": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Board Name",
                    "placeholder": "My Project Board",
                    "helper_text": "The name of the new board",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Board for managing project tasks",
                    "helper_text": "Optional description for the board",
                },
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization to create the board in",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "default_labels",
                    "type": "bool",
                    "value": True,
                    "label": "Default Labels",
                    "helper_text": "Whether to create default labels for the board",
                },
                {
                    "field": "default_lists",
                    "type": "bool",
                    "value": True,
                    "label": "Default Lists",
                    "helper_text": "Whether to create default lists (To Do, Doing, Done) for the board",
                },
                {
                    "field": "id_board_source",
                    "type": "string",
                    "value": "",
                    "label": "Source Board ID",
                    "placeholder": "Board ID to copy from",
                    "helper_text": "ID of an existing board to copy settings from (optional)",
                },
                {
                    "field": "keep_from_source",
                    "type": "string",
                    "value": "",
                    "label": "Keep From Source",
                    "placeholder": "cards,lists",
                    "helper_text": "Comma-separated list of items to keep from source board (optional)",
                },
                {
                    "field": "power_ups",
                    "type": "string",
                    "value": "",
                    "label": "Power Ups",
                    "placeholder": "calendar,voting",
                    "helper_text": "Comma-separated list of power-ups to enable (optional)",
                },
                {
                    "field": "prefs_permission_level",
                    "type": "string",
                    "value": "",
                    "label": "Permission Level",
                    "helper_text": "Permission level for the board",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "No Change"},
                            {"value": "private", "label": "Private"},
                            {"value": "org", "label": "Organization"},
                            {"value": "public", "label": "Public"},
                        ],
                    },
                },
                {
                    "field": "prefs_voting",
                    "type": "string",
                    "value": "",
                    "label": "Voting",
                    "helper_text": "Who can vote on cards",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "No Change"},
                            {"value": "disabled", "label": "Disabled"},
                            {"value": "members", "label": "Members"},
                            {"value": "observers", "label": "Observers"},
                            {"value": "org", "label": "Organization"},
                            {"value": "public", "label": "Public"},
                        ],
                    },
                },
                {
                    "field": "prefs_comments",
                    "type": "string",
                    "value": "",
                    "label": "Comments",
                    "helper_text": "Who can comment on cards",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "No Change"},
                            {"value": "disabled", "label": "Disabled"},
                            {"value": "members", "label": "Members"},
                            {"value": "observers", "label": "Observers"},
                            {"value": "org", "label": "Organization"},
                            {"value": "public", "label": "Public"},
                        ],
                    },
                },
                {
                    "field": "prefs_invitations",
                    "type": "string",
                    "value": "",
                    "label": "Invitations",
                    "helper_text": "Who can invite members to the board",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "No Change"},
                            {"value": "members", "label": "Members"},
                            {"value": "admins", "label": "Admins Only"},
                        ],
                    },
                },
                {
                    "field": "prefs_background",
                    "type": "string",
                    "value": "",
                    "label": "Background",
                    "placeholder": "blue",
                    "helper_text": "Background color or image for the board",
                },
                {
                    "field": "prefs_card_aging",
                    "type": "string",
                    "value": "",
                    "label": "Card Aging",
                    "helper_text": "Card aging visual style",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "", "label": "No Change"},
                            {"value": "regular", "label": "Regular"},
                            {"value": "pirate", "label": "Pirate"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created board",
                },
                {
                    "field": "board_name",
                    "type": "string",
                    "helper_text": "Name of the created board",
                },
                {
                    "field": "board_description",
                    "type": "string",
                    "helper_text": "Description of the created board",
                },
                {
                    "field": "board_url",
                    "type": "string",
                    "helper_text": "URL of the created board",
                },
                {
                    "field": "board_short_url",
                    "type": "string",
                    "helper_text": "Short URL of the created board",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the board is closed",
                },
                {
                    "field": "id_organization",
                    "type": "string",
                    "helper_text": "ID of the organization containing the board",
                },
                {
                    "field": "date_last_activity",
                    "type": "timestamp",
                    "helper_text": "Date of last activity on the board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_board",
            "task_name": "tasks.trello.create_board",
            "description": "Create a new board",
            "label": "Create Board",
            "input_sort_order": [
                "action",
                "integration",
                "name",
                "description",
                "organization_id",
            ],
            "required": ["name"],
        },
        "get_board": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "organization_id",
                    "helper_text": "The ID of the board to retrieve",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields",
                    "placeholder": "prefs,labelNames,powerUps",
                    "helper_text": "Optional: Additional board properties to include (e.g., prefs, labelNames, powerUps). Basic fields (id, name, desc, url, etc.) are always returned",
                },
                {
                    "field": "actions",
                    "type": "string",
                    "value": "",
                    "label": "Include Actions",
                    "placeholder": "all",
                    "helper_text": "Optional: Include board activity/actions. Options: all, createCard, updateCard, commentCard, etc. Leave empty to exclude",
                },
                {
                    "field": "board_stars",
                    "type": "string",
                    "value": "",
                    "label": "Board Stars",
                    "placeholder": "mine",
                    "helper_text": "Optional: Include board stars. Use 'mine' for current user's stars or 'none' to exclude",
                },
                {
                    "field": "cards",
                    "type": "string",
                    "value": "",
                    "label": "Include Cards",
                    "placeholder": "open",
                    "helper_text": "Optional: Include cards from the board. Options: all, open, closed, visible. Leave empty to exclude cards",
                },
                {
                    "field": "card_plugin_data",
                    "type": "bool",
                    "value": False,
                    "label": "Card Plugin Data",
                    "helper_text": "Optional: Include plugin data for cards (requires cards to be included)",
                },
                {
                    "field": "checklists",
                    "type": "string",
                    "value": "",
                    "label": "Include Checklists",
                    "placeholder": "all",
                    "helper_text": "Optional: Include checklists. Options: all, none. Leave empty to exclude",
                },
                {
                    "field": "custom_fields",
                    "type": "bool",
                    "value": False,
                    "label": "Custom Fields",
                    "helper_text": "Optional: Include custom field definitions for the board",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "label": "Include Labels",
                    "placeholder": "all",
                    "helper_text": "Optional: Include labels from the board. Options: all, none. Leave empty to exclude",
                },
                {
                    "field": "lists",
                    "type": "string",
                    "value": "",
                    "label": "Include Lists",
                    "placeholder": "open",
                    "helper_text": "Optional: Include lists from the board. Options: all, open, closed. Leave empty to exclude",
                },
                {
                    "field": "members",
                    "type": "string",
                    "value": "",
                    "label": "Include Members",
                    "placeholder": "all",
                    "helper_text": "Optional: Include board members. Options: all, admins, normal, owners. Leave empty to exclude",
                },
                {
                    "field": "memberships",
                    "type": "string",
                    "value": "",
                    "label": "Include Memberships",
                    "placeholder": "all",
                    "helper_text": "Optional: Include membership details. Options: all, active, admin, deactivated, me, normal. Leave empty to exclude",
                },
                {
                    "field": "plugin_data",
                    "type": "bool",
                    "value": False,
                    "label": "Plugin Data",
                    "helper_text": "Optional: Include Power-Up/plugin data for the board",
                },
                {
                    "field": "organization",
                    "type": "bool",
                    "value": False,
                    "label": "Include Organization",
                    "helper_text": "Optional: Include organization details that owns this board",
                },
                {
                    "field": "organization_plugin_data",
                    "type": "bool",
                    "value": False,
                    "label": "Organization Plugin Data",
                    "helper_text": "Optional: Include Power-Up/plugin data for the organization",
                },
                {
                    "field": "tags",
                    "type": "bool",
                    "value": False,
                    "label": "Tags",
                    "helper_text": "Optional: Include board tags",
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the board",
                },
                {
                    "field": "board_name",
                    "type": "string",
                    "helper_text": "Name of the board",
                },
                {
                    "field": "board_description",
                    "type": "string",
                    "helper_text": "Description of the board",
                },
                {
                    "field": "board_url",
                    "type": "string",
                    "helper_text": "URL of the board",
                },
                {
                    "field": "board_short_url",
                    "type": "string",
                    "helper_text": "Short URL of the board",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the board is closed",
                },
                {
                    "field": "id_organization",
                    "type": "string",
                    "helper_text": "ID of the organization containing the board",
                },
                {
                    "field": "list_ids",
                    "type": "vec<string>",
                    "helper_text": "List of list IDs on the board (if requested)",
                },
                {
                    "field": "list_names",
                    "type": "vec<string>",
                    "helper_text": "List of list names on the board (if requested)",
                },
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs on the board (if requested)",
                },
                {
                    "field": "member_names",
                    "type": "vec<string>",
                    "helper_text": "List of member names on the board (if requested)",
                },
                {
                    "field": "member_usernames",
                    "type": "vec<string>",
                    "helper_text": "List of member usernames on the board (if requested)",
                },
                {
                    "field": "label_ids",
                    "type": "vec<string>",
                    "helper_text": "List of label IDs on the board (if requested)",
                },
                {
                    "field": "label_names",
                    "type": "vec<string>",
                    "helper_text": "List of label names on the board (if requested)",
                },
                {
                    "field": "label_colors",
                    "type": "vec<string>",
                    "helper_text": "List of label colors on the board (if requested)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_board",
            "task_name": "tasks.trello.get_board",
            "description": "Read details of a specific board",
            "label": "Get Board",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
            ],
            "required": ["board_id"],
        },
        "update_board": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to update",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Board Name",
                    "placeholder": "Updated Board Name",
                    "helper_text": "The new name for the board",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Updated description",
                    "helper_text": "The new description for the board",
                },
                {
                    "field": "closed",
                    "type": "bool",
                    "value": False,
                    "label": "Closed",
                    "helper_text": "Whether the board should be closed (archived)",
                },
                {
                    "field": "id_organization",
                    "type": "string",
                    "value": "",
                    "label": "Organization ID",
                    "placeholder": "Organization ID",
                    "helper_text": "Move board to a different organization (optional)",
                },
                {
                    "field": "prefs_permission_level",
                    "type": "string",
                    "value": "no-change",
                    "label": "Permission Level",
                    "helper_text": "Permission level for the board",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "no-change", "label": "No Change"},
                            {"value": "private", "label": "Private"},
                            {"value": "org", "label": "Organization"},
                            {"value": "public", "label": "Public"},
                        ],
                    },
                },
                {
                    "field": "prefs_voting",
                    "type": "string",
                    "value": "no-change",
                    "label": "Voting",
                    "helper_text": "Who can vote on cards",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "no-change", "label": "No Change"},
                            {"value": "disabled", "label": "Disabled"},
                            {"value": "members", "label": "Members"},
                            {"value": "observers", "label": "Observers"},
                            {"value": "org", "label": "Organization"},
                            {"value": "public", "label": "Public"},
                        ],
                    },
                },
                {
                    "field": "prefs_comments",
                    "type": "string",
                    "value": "no-change",
                    "label": "Comments",
                    "helper_text": "Who can comment on cards",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "no-change", "label": "No Change"},
                            {"value": "disabled", "label": "Disabled"},
                            {"value": "members", "label": "Members"},
                            {"value": "observers", "label": "Observers"},
                            {"value": "org", "label": "Organization"},
                            {"value": "public", "label": "Public"},
                        ],
                    },
                },
                {
                    "field": "prefs_invitations",
                    "type": "string",
                    "value": "no-change",
                    "label": "Invitations",
                    "helper_text": "Who can invite members to the board",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "no-change", "label": "No Change"},
                            {"value": "members", "label": "Members"},
                            {"value": "admins", "label": "Admins Only"},
                        ],
                    },
                },
                {
                    "field": "prefs_self_join",
                    "type": "bool",
                    "value": False,
                    "label": "Self Join",
                    "helper_text": "Whether members can join the board themselves",
                },
                {
                    "field": "prefs_card_covers",
                    "type": "bool",
                    "value": True,
                    "label": "Card Covers",
                    "helper_text": "Whether card covers are enabled",
                },
                {
                    "field": "prefs_hide_votes",
                    "type": "bool",
                    "value": False,
                    "label": "Hide Votes",
                    "helper_text": "Whether to hide voting results",
                },
                {
                    "field": "prefs_background",
                    "type": "string",
                    "value": "",
                    "label": "Background",
                    "placeholder": "blue",
                    "helper_text": "Background color or image",
                },
                {
                    "field": "prefs_card_aging",
                    "type": "string",
                    "value": "no-change",
                    "label": "Card Aging",
                    "helper_text": "Card aging visual style",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "no-change", "label": "No Change"},
                            {"value": "regular", "label": "Regular"},
                            {"value": "pirate", "label": "Pirate"},
                        ],
                    },
                },
                {
                    "field": "label_names_green",
                    "type": "string",
                    "value": "",
                    "label": "Green Label Name",
                    "placeholder": "Priority",
                    "helper_text": "Name for green label",
                },
                {
                    "field": "label_names_yellow",
                    "type": "string",
                    "value": "",
                    "label": "Yellow Label Name",
                    "placeholder": "In Progress",
                    "helper_text": "Name for yellow label",
                },
                {
                    "field": "label_names_orange",
                    "type": "string",
                    "value": "",
                    "label": "Orange Label Name",
                    "placeholder": "Warning",
                    "helper_text": "Name for orange label",
                },
                {
                    "field": "label_names_red",
                    "type": "string",
                    "value": "",
                    "label": "Red Label Name",
                    "placeholder": "Urgent",
                    "helper_text": "Name for red label",
                },
                {
                    "field": "label_names_purple",
                    "type": "string",
                    "value": "",
                    "label": "Purple Label Name",
                    "placeholder": "Feature",
                    "helper_text": "Name for purple label",
                },
                {
                    "field": "label_names_blue",
                    "type": "string",
                    "value": "",
                    "label": "Blue Label Name",
                    "placeholder": "Bug",
                    "helper_text": "Name for blue label",
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated board",
                },
                {
                    "field": "board_name",
                    "type": "string",
                    "helper_text": "Updated name of the board",
                },
                {
                    "field": "board_description",
                    "type": "string",
                    "helper_text": "Updated description of the board",
                },
                {
                    "field": "board_url",
                    "type": "string",
                    "helper_text": "URL of the board",
                },
                {
                    "field": "board_short_url",
                    "type": "string",
                    "helper_text": "Short URL of the board",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the board is closed",
                },
                {
                    "field": "id_organization",
                    "type": "string",
                    "helper_text": "ID of the organization containing the board",
                },
                {
                    "field": "date_last_activity",
                    "type": "timestamp",
                    "helper_text": "Date of last activity on the board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_board",
            "task_name": "tasks.trello.update_board",
            "description": "Update a board's details",
            "label": "Update Board",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "name",
                "description",
            ],
            "required": ["board_id"],
        },
        "delete_board": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the deletion operation",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_board",
            "task_name": "tasks.trello.delete_board",
            "description": "Delete a board",
            "label": "Delete Board",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
            ],
            "required": ["board_id"],
        },
        "add_board_member": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member ID",
                    "helper_text": "The ID of the member to add",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_type",
                    "type": "string",
                    "value": "normal",
                    "label": "Member Type",
                    "helper_text": "Type of membership. Normal: Standard board member. Admin: Board administrator (restricted - only available if you have permission to assign admin roles). Observer: View-only access (requires Trello Premium/Enterprise). Note: Changing an admin to normal cannot be reversed. Warning: Adding an existing member will update their role.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Normal", "value": "normal"},
                            {"label": "Admin", "value": "admin"},
                            {"label": "Observer", "value": "observer"},
                        ],
                    },
                },
                {
                    "field": "allow_billable_guest",
                    "type": "bool",
                    "value": False,
                    "label": "Allow Billable Guest",
                    "helper_text": "Allow adding this member as a billable guest (important for billing control - prevents accidental charges)",
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the added member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_board_member",
            "task_name": "tasks.trello.add_board_member",
            "description": "Add a member to a board",
            "label": "Add Board Member",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "member_id",
                "member_type",
                "allow_billable_guest",
            ],
            "required": ["board_id", "member_id"],
        },
        "list_board_members": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to get members from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs on the board",
                },
                {
                    "field": "member_usernames",
                    "type": "vec<string>",
                    "helper_text": "List of member usernames on the board",
                },
                {
                    "field": "member_full_names",
                    "type": "vec<string>",
                    "helper_text": "List of member full names on the board",
                },
                {
                    "field": "member_emails",
                    "type": "vec<string>",
                    "helper_text": "List of member emails on the board",
                },
                {
                    "field": "member_avatar_urls",
                    "type": "vec<string>",
                    "helper_text": "List of member avatar URLs on the board",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of members on the board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_board_members",
            "task_name": "tasks.trello.list_board_members",
            "description": "Get multiple members of a board",
            "label": "List Board Members",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
            ],
            "required": ["board_id"],
        },
        "invite_board_member": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "user@example.com",
                    "helper_text": "Email address of the person to invite",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "John Doe",
                    "helper_text": "Full name of the person to invite",
                },
                {
                    "field": "member_type",
                    "type": "string",
                    "value": "normal",
                    "label": "Member Type",
                    "helper_text": "Type of membership (Note: Trello API does not support inviting as Admin. Observer can only be added on paid plans)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Normal", "value": "normal"},
                            {"label": "Observer", "value": "observer"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the invited member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "invite_board_member",
            "task_name": "tasks.trello.invite_board_member",
            "description": "Invite a member to a board via email",
            "label": "Invite Board Member",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "email",
                "full_name",
                "member_type",
            ],
            "required": ["board_id", "email"],
        },
        "remove_board_member": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board ID",
                    "helper_text": "The ID of the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member ID",
                    "helper_text": "The ID of the member to remove",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the removal operation",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "remove_board_member",
            "task_name": "tasks.trello.remove_board_member",
            "description": "Remove a member from a board",
            "label": "Remove Board Member",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "member_id",
            ],
            "required": ["board_id", "member_id"],
        },
        "create_list": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to create the list in",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "List Name",
                    "placeholder": "To Do",
                    "helper_text": "The name of the new list",
                },
                {
                    "field": "position",
                    "type": "string",
                    "value": "bottom",
                    "label": "Position",
                    "helper_text": "Position of the list on the board",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "top", "label": "Top"},
                            {"value": "bottom", "label": "Bottom"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created list",
                },
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Name of the created list",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the list",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the list is closed",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position of the list on the board",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "helper_text": "Whether the user is subscribed to the list",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_list",
            "task_name": "tasks.trello.create_list",
            "description": "Create a new list on a board",
            "label": "Create List",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "name",
                "position",
            ],
            "required": ["board_id", "name"],
        },
        "get_list": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the list",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "label": "List ID",
                    "helper_text": "The ID of the list to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "placeholder": "softLimit,creationMethod",
                    "label": "Additional Fields",
                    "helper_text": "Optional: Additional list properties to include (e.g., softLimit, creationMethod). Basic fields (id, name, closed, pos, subscribed) are always returned",
                },
                {
                    "field": "cards",
                    "type": "string",
                    "value": "",
                    "placeholder": "open",
                    "label": "Include Cards",
                    "helper_text": "Optional: Include cards from this list. Options: all, open, closed, visible. Leave empty to exclude cards",
                },
                {
                    "field": "card_fields",
                    "type": "string",
                    "value": "",
                    "placeholder": "name,due,labels",
                    "label": "Card Fields",
                    "helper_text": "Optional: Specify which card properties to include (e.g., name, due, labels). Only applies when cards are included",
                },
                {
                    "field": "board",
                    "type": "bool",
                    "value": False,
                    "label": "Include Board",
                    "helper_text": "Optional: Include parent board information in the response",
                },
                {
                    "field": "board_fields",
                    "type": "string",
                    "value": "",
                    "label": "Board Fields",
                    "helper_text": "Optional: Specify which board properties to include (e.g., name, desc, url). Only applies when board is included",
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the list",
                },
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Name of the list",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the list",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the list is closed",
                },
                {
                    "field": "position",
                    "type": "float",
                    "helper_text": "Position of the list on the board",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "helper_text": "Whether the user is subscribed to the list",
                },
                {
                    "field": "card_ids",
                    "type": "vec<string>",
                    "helper_text": "List of card IDs in the list (if requested)",
                },
                {
                    "field": "card_names",
                    "type": "vec<string>",
                    "helper_text": "List of card names in the list (if requested)",
                },
                {
                    "field": "card_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of card descriptions in the list (if requested)",
                },
                {
                    "field": "cards_count",
                    "type": "int32",
                    "helper_text": "Number of cards in the list (if requested)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_list",
            "task_name": "tasks.trello.get_list",
            "description": "Read details of a specific list",
            "label": "Get List",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "fields",
                "cards",
                "card_fields",
                "board",
                "board_fields",
            ],
            "required": ["list_id"],
        },
        "list_lists": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to get lists from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "placeholder": "softLimit,creationMethod",
                    "label": "Additional Fields",
                    "helper_text": "Optional: Additional list properties to include (e.g., softLimit, creationMethod). Basic fields (id, name, closed, pos, subscribed) are always returned",
                },
                {
                    "field": "cards",
                    "type": "string",
                    "value": "",
                    "placeholder": "open",
                    "label": "Include Cards",
                    "helper_text": "Optional: Include cards from each list. Options: all, open, closed, visible, none. Leave empty to exclude cards",
                },
                {
                    "field": "card_fields",
                    "type": "string",
                    "value": "",
                    "placeholder": "name,due,labels",
                    "label": "Card Fields",
                    "helper_text": "Optional: Specify which card properties to include (e.g., name, due, labels). Only applies when cards are included",
                },
                {
                    "field": "board",
                    "type": "bool",
                    "value": False,
                    "label": "Include Board",
                    "helper_text": "Optional: Include parent board information for each list",
                },
                {
                    "field": "board_fields",
                    "type": "string",
                    "value": "",
                    "placeholder": "name,url",
                    "label": "Board Fields",
                    "helper_text": "Optional: Specify which board properties to include (e.g., name, url). Only applies when board is included",
                },
            ],
            "outputs": [
                {
                    "field": "list_ids",
                    "type": "vec<string>",
                    "helper_text": "List of list IDs on the board",
                },
                {
                    "field": "list_names",
                    "type": "vec<string>",
                    "helper_text": "List of list names on the board",
                },
                {
                    "field": "list_positions",
                    "type": "vec<float>",
                    "helper_text": "List of list positions on the board",
                },
                {
                    "field": "list_closed_statuses",
                    "type": "vec<bool>",
                    "helper_text": "List of list closed statuses on the board",
                },
                {
                    "field": "list_subscribed_statuses",
                    "type": "vec<bool>",
                    "helper_text": "List of list subscribed statuses on the board",
                },
                {
                    "field": "list_board_ids",
                    "type": "vec<string>",
                    "helper_text": "List of board IDs for each list",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of lists on the board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_lists",
            "task_name": "tasks.trello.list_lists",
            "description": "Get multiple lists from a board",
            "label": "List Lists",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "fields",
                "cards",
                "card_fields",
                "board",
                "board_fields",
            ],
            "required": ["board_id"],
        },
        "update_list": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the list",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "label": "List ID",
                    "helper_text": "The ID of the list to update",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "List Name",
                    "placeholder": "Updated List Name",
                    "helper_text": "The new name for the list (optional)",
                },
                {
                    "field": "closed",
                    "type": "bool",
                    "value": False,
                    "label": "Closed",
                    "helper_text": "Archive/unarchive the list (optional)",
                },
                {
                    "field": "new_board_id",
                    "type": "string",
                    "value": "",
                    "label": "Move to Board",
                    "helper_text": "Move this list to a different board (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "pos",
                    "type": "int32",
                    "value": "",
                    "label": "Position",
                    "placeholder": "0",
                    "helper_text": "Change the position of the list on the board (optional)",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "value": False,
                    "label": "Subscribed",
                    "helper_text": "Subscribe/unsubscribe to list notifications (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated list",
                },
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Updated name of the list",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the list",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the list is closed",
                },
                {
                    "field": "position",
                    "type": "float",
                    "helper_text": "Position of the list on the board",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "helper_text": "Whether the user is subscribed to the list",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_list",
            "task_name": "tasks.trello.update_list",
            "description": "Update a list's details",
            "label": "Update List",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "name",
                "closed",
                "new_board_id",
                "pos",
                "subscribed",
            ],
            "required": ["list_id"],
        },
        "archive_unarchive_list": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the list",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "label": "List ID",
                    "helper_text": "The ID of the list to archive/unarchive",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&include_archived=true&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "closed",
                    "type": "bool",
                    "value": True,
                    "label": "Archive",
                    "helper_text": "Set to true to archive the list, false to unarchive",
                },
            ],
            "outputs": [
                {"field": "list_id", "type": "string", "helper_text": "ID of the list"},
                {
                    "field": "closed",
                    "type": "bool",
                    "helper_text": "Whether the list is now closed (archived)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "archive_unarchive_list",
            "task_name": "tasks.trello.archive_unarchive_list",
            "description": "Archive or unarchive a list",
            "label": "Archive/Unarchive List",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "closed",
            ],
            "required": ["board_id", "list_id"],
        },
        "list_cards_in_list": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the list",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "label": "List ID",
                    "helper_text": "The ID of the list to get cards from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "card_ids",
                    "type": "vec<string>",
                    "helper_text": "List of card IDs in the list",
                },
                {
                    "field": "card_names",
                    "type": "vec<string>",
                    "helper_text": "List of card names in the list",
                },
                {
                    "field": "card_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of card descriptions in the list",
                },
                {
                    "field": "card_urls",
                    "type": "vec<string>",
                    "helper_text": "List of card URLs in the list",
                },
                {
                    "field": "card_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of card due dates in the list",
                },
                {
                    "field": "card_due_complete_statuses",
                    "type": "vec<bool>",
                    "helper_text": "List of card due complete statuses in the list",
                },
                {
                    "field": "card_closed_statuses",
                    "type": "vec<bool>",
                    "helper_text": "List of card closed statuses in the list",
                },
                {
                    "field": "card_positions",
                    "type": "vec<float>",
                    "helper_text": "List of card positions in the list",
                },
                {
                    "field": "card_date_last_activities",
                    "type": "vec<timestamp>",
                    "helper_text": "List of card last activity dates in the list",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of cards in the list",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_cards_in_list",
            "task_name": "tasks.trello.list_cards_in_list",
            "description": "Get multiple cards",
            "label": "List Cards in List",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
            ],
            "required": ["list_id"],
        },
        "create_card": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the list",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List ID",
                    "helper_text": "The ID of the list to create the card in",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Card Name",
                    "placeholder": "Task Title",
                    "helper_text": "The name of the new card",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Task description...",
                    "helper_text": "The description of the card",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31T23:59:59.000Z",
                    "helper_text": "Due date in ISO format (optional)",
                },
                {
                    "field": "due_complete",
                    "type": "bool",
                    "value": False,
                    "label": "Due Complete",
                    "helper_text": "Mark the due date as complete (optional)",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Start Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Start date in ISO format (optional)",
                },
                {
                    "field": "position",
                    "type": "string",
                    "value": "bottom",
                    "label": "Position",
                    "helper_text": "Position of the card in the list",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "top", "label": "Top"},
                            {"value": "bottom", "label": "Bottom"},
                        ],
                    },
                },
                {
                    "field": "id_members",
                    "type": "string",
                    "value": "",
                    "label": "Members",
                    "placeholder": "member1,member2",
                    "helper_text": "Assign members to the card - comma-separated IDs or use dropdown (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                        "multi_select": True,
                    },
                },
                {
                    "field": "id_labels",
                    "type": "string",
                    "value": "",
                    "label": "Labels",
                    "placeholder": "label1,label2",
                    "helper_text": "Add labels to the card - comma-separated IDs or use dropdown (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                        "multi_select": True,
                    },
                },
                {
                    "field": "url_source",
                    "type": "string",
                    "value": "",
                    "label": "URL Source",
                    "placeholder": "https://example.com",
                    "helper_text": "Create card from URL - Trello will fetch details from this URL (optional)",
                },
                {
                    "field": "id_card_source",
                    "type": "string",
                    "value": "",
                    "label": "Copy From Card",
                    "helper_text": "Copy details from an existing card (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "keep_from_source",
                    "type": "string",
                    "value": "all",
                    "label": "Keep From Source",
                    "helper_text": "When copying from source card, specify what to keep (optional)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "all", "label": "All"},
                            {"value": "attachments", "label": "Attachments Only"},
                            {"value": "checklists", "label": "Checklists Only"},
                            {"value": "comments", "label": "Comments Only"},
                            {"value": "due", "label": "Due Date Only"},
                            {"value": "labels", "label": "Labels Only"},
                            {"value": "members", "label": "Members Only"},
                            {"value": "stickers", "label": "Stickers Only"},
                        ],
                    },
                },
                {
                    "field": "address",
                    "type": "string",
                    "value": "",
                    "label": "Address",
                    "placeholder": "123 Main St, City, State",
                    "helper_text": "Physical address for the card location (optional)",
                },
                {
                    "field": "location_name",
                    "type": "string",
                    "value": "",
                    "label": "Location Name",
                    "placeholder": "Conference Room A",
                    "helper_text": "Name of the location (optional)",
                },
                {
                    "field": "coordinates",
                    "type": "string",
                    "value": "",
                    "label": "Coordinates",
                    "placeholder": "40.7128,-74.0060",
                    "helper_text": "Coordinates in latitude,longitude format (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created card",
                },
                {
                    "field": "card_name",
                    "type": "string",
                    "helper_text": "Name of the created card",
                },
                {
                    "field": "card_description",
                    "type": "string",
                    "helper_text": "Description of the created card",
                },
                {
                    "field": "card_url",
                    "type": "string",
                    "helper_text": "URL of the created card",
                },
                {
                    "field": "card_short_url",
                    "type": "string",
                    "helper_text": "Short URL of the created card",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the list containing the card",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the card",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the card is closed",
                },
                {
                    "field": "position",
                    "type": "float",
                    "helper_text": "Position of the card in the list",
                },
                {
                    "field": "date_last_activity",
                    "type": "timestamp",
                    "helper_text": "Date of last activity on the card",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the card (if set)",
                },
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs assigned to the card (if any)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_card",
            "task_name": "tasks.trello.create_card",
            "description": "Create a new card in a list",
            "label": "Create Card",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "name",
                "description",
                "due_date",
                "due_complete",
                "start_date",
                "position",
                "id_members",
                "id_labels",
                "url_source",
                "id_card_source",
                "keep_from_source",
                "address",
                "location_name",
                "coordinates",
            ],
            "required": ["board_id", "list_id", "name"],
        },
        "get_card": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields",
                    "placeholder": "badges,subscribed,cover",
                    "helper_text": "Optional: Additional card properties to include (e.g., badges, subscribed, cover). Basic fields (id, name, desc, url, due, etc.) are always returned",
                },
                {
                    "field": "actions",
                    "type": "string",
                    "value": "",
                    "label": "Include Actions",
                    "placeholder": "commentCard",
                    "helper_text": "Optional: Include card activity/actions. Options: all, commentCard, updateCard, createCard. Leave empty to exclude",
                },
                {
                    "field": "attachments",
                    "type": "bool",
                    "value": False,
                    "label": "Include Attachments",
                    "helper_text": "Optional: Include attachments from this card",
                },
                {
                    "field": "attachment_fields",
                    "type": "string",
                    "value": "",
                    "label": "Attachment Fields",
                    "placeholder": "name,url,mimeType",
                    "helper_text": "Optional: Specify which attachment properties to include (e.g., name, url, mimeType). Only applies when attachments are included",
                },
                {
                    "field": "members",
                    "type": "bool",
                    "value": False,
                    "label": "Include Members",
                    "helper_text": "Optional: Include members assigned to this card",
                },
                {
                    "field": "member_fields",
                    "type": "string",
                    "value": "",
                    "label": "Member Fields",
                    "placeholder": "fullName,username",
                    "helper_text": "Optional: Specify which member properties to include (e.g., fullName, username). Only applies when members are included",
                },
                {
                    "field": "members_voted",
                    "type": "bool",
                    "value": False,
                    "label": "Include Members Voted",
                    "helper_text": "Optional: Include members who voted on this card",
                },
                {
                    "field": "member_voted_fields",
                    "type": "string",
                    "value": "",
                    "label": "Member Voted Fields",
                    "placeholder": "fullName",
                    "helper_text": "Optional: Specify which properties to include for voting members. Only applies when members_voted is enabled",
                },
                {
                    "field": "check_item_states",
                    "type": "bool",
                    "value": False,
                    "label": "Include Check Item States",
                    "helper_text": "Optional: Include the state of all checklist items (complete/incomplete counts)",
                },
                {
                    "field": "checklists",
                    "type": "string",
                    "value": "",
                    "label": "Include Checklists",
                    "placeholder": "all",
                    "helper_text": "Optional: Include checklists from this card. Options: all, none. Leave empty to exclude",
                },
                {
                    "field": "board",
                    "type": "bool",
                    "value": False,
                    "label": "Include Board",
                    "helper_text": "Optional: Include parent board information for this card",
                },
                {
                    "field": "board_fields",
                    "type": "string",
                    "value": "",
                    "label": "Board Fields",
                    "placeholder": "name,url",
                    "helper_text": "Optional: Specify which board properties to include (e.g., name, url). Only applies when board is included",
                },
                {
                    "field": "list",
                    "type": "bool",
                    "value": False,
                    "label": "Include List",
                    "helper_text": "Optional: Include parent list information for this card",
                },
                {
                    "field": "plugin_data",
                    "type": "bool",
                    "value": False,
                    "label": "Include Plugin Data",
                    "helper_text": "Optional: Include Power-Up/plugin data for this card",
                },
                {
                    "field": "stickers",
                    "type": "bool",
                    "value": False,
                    "label": "Include Stickers",
                    "helper_text": "Optional: Include stickers attached to this card",
                },
                {
                    "field": "sticker_fields",
                    "type": "string",
                    "value": "",
                    "label": "Sticker Fields",
                    "placeholder": "image,imageUrl",
                    "helper_text": "Optional: Specify which sticker properties to include. Only applies when stickers are included",
                },
                {
                    "field": "custom_field_items",
                    "type": "bool",
                    "value": False,
                    "label": "Include Custom Field Items",
                    "helper_text": "Optional: Include custom field values for this card",
                },
            ],
            "outputs": [
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the card",
                },
                {
                    "field": "card_name",
                    "type": "string",
                    "helper_text": "Name of the card",
                },
                {
                    "field": "card_description",
                    "type": "string",
                    "helper_text": "Description of the card",
                },
                {
                    "field": "card_url",
                    "type": "string",
                    "helper_text": "URL of the card",
                },
                {
                    "field": "card_short_url",
                    "type": "string",
                    "helper_text": "Short URL of the card",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the list containing the card",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the card",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the card is closed",
                },
                {
                    "field": "position",
                    "type": "float",
                    "helper_text": "Position of the card in the list",
                },
                {
                    "field": "date_last_activity",
                    "type": "timestamp",
                    "helper_text": "Date of last activity on the card",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the card (if set)",
                },
                {
                    "field": "due_complete",
                    "type": "bool",
                    "helper_text": "Whether the due date is marked as complete",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "Start date of the card (if set)",
                },
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs assigned to the card (if any)",
                },
                {
                    "field": "member_names",
                    "type": "vec<string>",
                    "helper_text": "List of member names assigned to the card (if any)",
                },
                {
                    "field": "member_usernames",
                    "type": "vec<string>",
                    "helper_text": "List of member usernames assigned to the card (if any)",
                },
                {
                    "field": "label_ids",
                    "type": "vec<string>",
                    "helper_text": "List of label IDs on the card (if any)",
                },
                {
                    "field": "label_names",
                    "type": "vec<string>",
                    "helper_text": "List of label names on the card (if any)",
                },
                {
                    "field": "label_colors",
                    "type": "vec<string>",
                    "helper_text": "List of label colors on the card (if any)",
                },
                {
                    "field": "comments_count",
                    "type": "int32",
                    "helper_text": "Number of comments on the card",
                },
                {
                    "field": "attachments_count",
                    "type": "int32",
                    "helper_text": "Number of attachments on the card",
                },
                {
                    "field": "checklist_items_count",
                    "type": "int32",
                    "helper_text": "Number of checklist items on the card",
                },
                {
                    "field": "checklist_items_checked_count",
                    "type": "int32",
                    "helper_text": "Number of checked checklist items on the card",
                },
                {
                    "field": "has_description",
                    "type": "bool",
                    "helper_text": "Whether the card has a description",
                },
                {
                    "field": "votes_count",
                    "type": "int32",
                    "helper_text": "Number of votes on the card",
                },
                {
                    "field": "is_subscribed",
                    "type": "bool",
                    "helper_text": "Whether the user is subscribed to the card",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_card",
            "task_name": "tasks.trello.get_card",
            "description": "Read details of a specific card",
            "label": "Get Card",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
            ],
            "required": ["organization_id", "board_id", "list_id", "card_id"],
        },
        "update_card": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to update",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Card Name",
                    "placeholder": "Updated Card Name",
                    "helper_text": "The new name for the card (optional)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Updated description",
                    "helper_text": "The new description for the card (optional)",
                },
                {
                    "field": "closed",
                    "type": "bool",
                    "value": False,
                    "label": "Closed",
                    "helper_text": "Archive/close the card (optional)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31T23:59:59.000Z",
                    "helper_text": "Due date in ISO format (optional, set to empty string to remove)",
                },
                {
                    "field": "due_complete",
                    "type": "bool",
                    "value": False,
                    "label": "Due Complete",
                    "helper_text": "Mark the due date as complete (optional)",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Start Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Start date in ISO format (optional, set to empty string to remove)",
                },
                {
                    "field": "pos",
                    "type": "int32",
                    "value": "",
                    "label": "Position",
                    "placeholder": "0",
                    "helper_text": "Position of the card in the list (optional)",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "value": False,
                    "label": "Subscribed",
                    "helper_text": "Subscribe to card notifications (optional)",
                },
                {
                    "field": "new_list_id",
                    "type": "string",
                    "value": "",
                    "label": "New List ID",
                    "helper_text": "Move card to this list (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "id_members",
                    "type": "string",
                    "value": "",
                    "label": "Members",
                    "placeholder": "member1,member2",
                    "helper_text": "Update assigned members - comma-separated IDs or use dropdown (optional - replaces existing members)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                        "multi_select": True,
                    },
                },
                {
                    "field": "id_labels",
                    "type": "string",
                    "value": "",
                    "label": "Labels",
                    "placeholder": "label1,label2",
                    "helper_text": "Update labels - comma-separated IDs or use dropdown (optional - replaces existing labels)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                        "multi_select": True,
                    },
                },
                {
                    "field": "address",
                    "type": "string",
                    "value": "",
                    "label": "Address",
                    "placeholder": "123 Main St, City, State",
                    "helper_text": "Physical address for the card location (optional)",
                },
                {
                    "field": "location_name",
                    "type": "string",
                    "value": "",
                    "label": "Location Name",
                    "placeholder": "Conference Room A",
                    "helper_text": "Name of the location (optional)",
                },
                {
                    "field": "coordinates",
                    "type": "string",
                    "value": "",
                    "label": "Coordinates",
                    "placeholder": "40.7128,-74.0060",
                    "helper_text": "Coordinates in latitude,longitude format (optional)",
                },
                {
                    "field": "id_attachment_cover",
                    "type": "string",
                    "value": "",
                    "label": "Cover Attachment ID",
                    "placeholder": "Attachment ID",
                    "helper_text": "ID of attachment to use as card cover (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated card",
                },
                {
                    "field": "card_name",
                    "type": "string",
                    "helper_text": "Updated name of the card",
                },
                {
                    "field": "card_description",
                    "type": "string",
                    "helper_text": "Updated description of the card",
                },
                {
                    "field": "card_url",
                    "type": "string",
                    "helper_text": "URL of the card",
                },
                {
                    "field": "card_short_url",
                    "type": "string",
                    "helper_text": "Short URL of the card",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the list containing the card",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the card",
                },
                {
                    "field": "is_closed",
                    "type": "bool",
                    "helper_text": "Whether the card is closed",
                },
                {
                    "field": "position",
                    "type": "float",
                    "helper_text": "Position of the card in the list",
                },
                {
                    "field": "date_last_activity",
                    "type": "timestamp",
                    "helper_text": "Date of last activity on the card",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the card (if set)",
                },
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs assigned to the card (if any)",
                },
                {
                    "field": "label_ids",
                    "type": "vec<string>",
                    "helper_text": "List of label IDs on the card (if any)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_card",
            "task_name": "tasks.trello.update_card",
            "description": "Update a card's details",
            "label": "Update Card",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "name",
                "description",
                "closed",
                "due_date",
                "due_complete",
                "start_date",
                "pos",
                "subscribed",
                "new_list_id",
                "id_members",
                "id_labels",
                "address",
                "location_name",
                "coordinates",
                "id_attachment_cover",
            ],
            "required": ["organization_id", "board_id", "list_id", "card_id"],
        },
        "delete_card": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the deletion operation",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_card",
            "task_name": "tasks.trello.delete_card",
            "description": "Delete a card",
            "label": "Delete Card",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
            ],
            "required": ["card_id"],
        },
        "create_card_comment": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to comment on",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Comment Text",
                    "placeholder": "This is a comment...",
                    "helper_text": "The text content of the comment",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "Text content of the comment",
                },
                {
                    "field": "date",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "helper_text": "Name of the comment author",
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "ID of the card the comment was created on",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the list containing the card",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the card",
                },
                {
                    "field": "organization_id",
                    "type": "string",
                    "helper_text": "ID of the organization containing the board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_card_comment",
            "task_name": "tasks.trello.create_card_comment",
            "description": "Create a comment on a card",
            "label": "Create Card Comment",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "text",
            ],
            "required": ["card_id", "text"],
        },
        "update_card_comment": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "helper_text": "The ID of the comment to update",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=comment_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Comment Text",
                    "placeholder": "Updated comment text...",
                    "helper_text": "The new text content of the comment",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "Updated text content of the comment",
                },
                {
                    "field": "date",
                    "type": "timestamp",
                    "helper_text": "When the comment was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_card_comment",
            "task_name": "tasks.trello.update_card_comment",
            "description": "Update a comment on a card",
            "label": "Update Card Comment",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "comment_id",
                "text",
            ],
            "required": ["card_id", "comment_id", "text"],
        },
        "delete_card_comment": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "helper_text": "The ID of the comment to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=comment_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_card_comment",
            "task_name": "tasks.trello.delete_card_comment",
            "description": "Delete a comment from a card",
            "label": "Delete Card Comment",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "comment_id",
            ],
            "required": ["card_id", "comment_id"],
        },
        "create_attachment": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to add the attachment to",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "url",
                    "type": "string",
                    "value": "",
                    "label": "URL",
                    "placeholder": "https://example.com/file.pdf",
                    "helper_text": "The URL of the attachment",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "Document Name",
                    "helper_text": "The name of the attachment",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "value": "",
                    "label": "MIME Type",
                    "placeholder": "application/pdf",
                    "helper_text": "The MIME type of the attachment",
                },
                {
                    "field": "set_cover",
                    "type": "bool",
                    "value": False,
                    "label": "Set as Cover",
                    "helper_text": "Set the attachment as the cover of the card",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created attachment",
                },
                {
                    "field": "attachment_name",
                    "type": "string",
                    "helper_text": "Name of the created attachment",
                },
                {
                    "field": "attachment_url",
                    "type": "string",
                    "helper_text": "URL of the created attachment",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the created attachment",
                },
                {
                    "field": "is_upload",
                    "type": "bool",
                    "helper_text": "Whether the attachment is uploaded or not",
                },
                {
                    "field": "date",
                    "type": "timestamp",
                    "helper_text": "When the attachment was created",
                },
                {
                    "field": "bytes",
                    "type": "int32",
                    "helper_text": "Size of the attachment in bytes",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_attachment",
            "task_name": "tasks.trello.create_attachment",
            "description": "Create a new attachment on a card",
            "label": "Create Attachment",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "card_id",
                "url",
                "name",
                "mime_type",
                "set_cover",
            ],
            "required": [
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "url",
                "name",
            ],
        },
        "get_attachment": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "helper_text": "The ID of the attachment to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=attachment_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "id,name,url,mimeType",
                    "helper_text": "Comma-separated list of fields to return (optional)",
                },
                {
                    "field": "download_file",
                    "type": "bool",
                    "value": False,
                    "label": "Download File",
                    "helper_text": "Whether to download the attachment file",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the attachment",
                },
                {
                    "field": "attachment_name",
                    "type": "string",
                    "helper_text": "Name of the attachment",
                },
                {
                    "field": "attachment_url",
                    "type": "string",
                    "helper_text": "URL of the attachment",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the attachment",
                },
                {
                    "field": "is_upload",
                    "type": "bool",
                    "helper_text": "Whether the attachment is uploaded",
                },
                {
                    "field": "date",
                    "type": "timestamp",
                    "helper_text": "When the attachment was created",
                },
                {
                    "field": "bytes",
                    "type": "int32",
                    "helper_text": "Size of the attachment in bytes",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "File name of the attachment",
                },
                {
                    "field": "download_error",
                    "type": "string",
                    "helper_text": "Error message if file download failed (if requested)",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "Downloaded file data (if download_file is requested)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_attachment",
            "task_name": "tasks.trello.get_attachment",
            "description": "Read details of a specific attachment",
            "label": "Get Attachment",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "attachment_id",
            ],
            "required": ["card_id", "attachment_id"],
        },
        "list_attachments": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to get attachments from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "id,name,url,mimeType",
                    "helper_text": "Comma-separated list of fields to return (optional)",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "helper_text": "Filter attachments",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "all", "label": "All Attachments"},
                            {"value": "cover", "label": "Cover Only"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of attachment IDs on the card",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names on the card",
                },
                {
                    "field": "attachment_urls",
                    "type": "vec<string>",
                    "helper_text": "List of attachment URLs on the card",
                },
                {
                    "field": "attachment_mime_types",
                    "type": "vec<string>",
                    "helper_text": "List of attachment MIME types on the card",
                },
                {
                    "field": "attachment_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of attachment creation dates on the card",
                },
                {
                    "field": "attachment_sizes",
                    "type": "vec<int32>",
                    "helper_text": "List of attachment sizes in bytes on the card",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of attachments on the card",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_attachments",
            "task_name": "tasks.trello.list_attachments",
            "description": "Get multiple attachments from a card",
            "label": "List Attachments",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
            ],
            "required": ["card_id"],
        },
        "delete_attachment": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "helper_text": "The ID of the attachment to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=attachment_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message describing the deletion",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the deletion operation",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_attachment",
            "task_name": "tasks.trello.delete_attachment",
            "description": "Delete an attachment from a card",
            "label": "Delete Attachment",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "attachment_id",
            ],
            "required": ["card_id", "attachment_id"],
        },
        "create_checklist": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to add the checklist to",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Checklist Name",
                    "placeholder": "My Checklist",
                    "helper_text": "The name of the new checklist",
                },
                {
                    "field": "id_checklist_source",
                    "type": "string",
                    "value": "",
                    "label": "Source Checklist ID",
                    "placeholder": "checklist123",
                    "helper_text": "Copy items from an existing checklist (optional - leave blank to create empty checklist)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "pos",
                    "type": "int32",
                    "value": "",
                    "label": "Position",
                    "placeholder": "0",
                    "helper_text": "Position of the checklist on the card (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created checklist",
                },
                {
                    "field": "checklist_name",
                    "type": "string",
                    "helper_text": "Name of the created checklist",
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "ID of the card containing the checklist",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position of the checklist",
                },
                {
                    "field": "check_item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of check item IDs in the checklist (if any)",
                },
                {
                    "field": "check_item_names",
                    "type": "vec<string>",
                    "helper_text": "List of check item names in the checklist (if any)",
                },
                {
                    "field": "check_item_states",
                    "type": "vec<string>",
                    "helper_text": "List of check item states in the checklist (if any)",
                },
                {
                    "field": "check_items_count",
                    "type": "int32",
                    "helper_text": "Number of items in the checklist (if any)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_checklist",
            "task_name": "tasks.trello.create_checklist",
            "description": "Create a new checklist on a card",
            "label": "Create Checklist",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "name",
                "id_checklist_source",
                "pos",
            ],
            "required": ["card_id", "name"],
        },
        "get_checklist": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card",
                    "helper_text": "The card containing the checklist",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "label": "Checklist ID",
                    "helper_text": "The ID of the checklist to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the checklist",
                },
                {
                    "field": "checklist_name",
                    "type": "string",
                    "helper_text": "Name of the checklist",
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "ID of the card containing the checklist",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position of the checklist",
                },
                {
                    "field": "check_item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of check item IDs in the checklist",
                },
                {
                    "field": "check_item_names",
                    "type": "vec<string>",
                    "helper_text": "List of check item names in the checklist",
                },
                {
                    "field": "check_item_states",
                    "type": "vec<string>",
                    "helper_text": "List of check item states in the checklist",
                },
                {
                    "field": "check_item_positions",
                    "type": "vec<int32>",
                    "helper_text": "List of check item positions in the checklist",
                },
                {
                    "field": "check_item_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of check item due dates in the checklist",
                },
                {
                    "field": "check_items_count",
                    "type": "int32",
                    "helper_text": "Total number of items in the checklist",
                },
                {
                    "field": "completed_items_count",
                    "type": "int32",
                    "helper_text": "Number of completed items in the checklist",
                },
                {
                    "field": "incomplete_items_count",
                    "type": "int32",
                    "helper_text": "Number of incomplete items in the checklist",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_checklist",
            "task_name": "tasks.trello.get_checklist",
            "description": "Read details of a specific checklist",
            "label": "Get Checklist",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
            ],
            "required": ["checklist_id"],
        },
        "list_checklists": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to get checklists from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "checklist_ids",
                    "type": "vec<string>",
                    "helper_text": "List of checklist IDs on the card",
                },
                {
                    "field": "checklist_names",
                    "type": "vec<string>",
                    "helper_text": "List of checklist names on the card",
                },
                {
                    "field": "checklist_item_counts",
                    "type": "vec<int32>",
                    "helper_text": "Number of items in each checklist",
                },
                {
                    "field": "checklist_completed_counts",
                    "type": "vec<int32>",
                    "helper_text": "Number of completed items in each checklist",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of checklists on the card",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_checklists",
            "task_name": "tasks.trello.list_checklists",
            "description": "Get multiple checklists from a card",
            "label": "List Checklists",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
            ],
            "required": ["card_id"],
        },
        "delete_checklist": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card",
                    "helper_text": "The card containing the checklist",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "label": "Checklist ID",
                    "helper_text": "The ID of the checklist to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the deletion operation",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_checklist",
            "task_name": "tasks.trello.delete_checklist",
            "description": "Delete a checklist",
            "label": "Delete Checklist",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
            ],
            "required": ["card_id", "checklist_id"],
        },
        "create_checklist_item": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card",
                    "helper_text": "The card containing the checklist",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "label": "Checklist ID",
                    "helper_text": "The ID of the checklist to add the item to",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Item Name",
                    "placeholder": "Task to complete",
                    "helper_text": "The name of the checklist item",
                },
                {
                    "field": "checked",
                    "type": "bool",
                    "value": False,
                    "label": "Checked",
                    "helper_text": "Whether the item is checked",
                },
                {
                    "field": "due",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31T23:59:59.000Z",
                    "helper_text": "Due date for the checklist item in ISO format (optional)",
                },
                {
                    "field": "pos",
                    "type": "int32",
                    "value": "",
                    "placeholder": "0",
                    "label": "Position",
                    "helper_text": "Position of the checklist item",
                },
                {
                    "field": "id_member",
                    "type": "string",
                    "value": "",
                    "label": "Assigned Member",
                    "placeholder": "Member ID",
                    "helper_text": "ID of the member to assign to this checklist item (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created checklist item",
                },
                {
                    "field": "item_name",
                    "type": "string",
                    "helper_text": "Name of the created checklist item",
                },
                {
                    "field": "checked",
                    "type": "bool",
                    "helper_text": "Whether the item is checked",
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the checklist containing the item",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_checklist_item",
            "task_name": "tasks.trello.create_checklist_item",
            "description": "Create a new item in a checklist",
            "label": "Create Checklist Item",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
                "name",
                "checked",
                "due",
                "pos",
                "id_member",
            ],
            "required": ["checklist_id", "name"],
        },
        "get_checklist_item": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to get checklists from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "label": "Checklist",
                    "helper_text": "The checklist containing the item",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "label": "Checklist Item ID",
                    "helper_text": "The ID of the checklist item to get",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_item_id&checklist_id={inputs.checklist_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the checklist item",
                },
                {
                    "field": "checklist_item_name",
                    "type": "string",
                    "helper_text": "Name of the checklist item",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "State of the checklist item",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position of the checklist item",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the checklist item",
                },
                {
                    "field": "id_member",
                    "type": "string",
                    "helper_text": "ID of the member assigned to the checklist item",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_checklist_item",
            "task_name": "tasks.trello.get_checklist_item",
            "description": "Read details of a specific checklist item",
            "label": "Get Checklist Item",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
                "checklist_item_id",
            ],
            "required": ["card_id", "checklist_item_id"],
        },
        "get_completed_checklist_items": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card",
                    "helper_text": "The card containing the checklist",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "label": "Checklist ID",
                    "helper_text": "The ID of the checklist to get completed items from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "completed_item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of completed checklist item IDs",
                },
                {
                    "field": "completed_item_states",
                    "type": "vec<string>",
                    "helper_text": "List of completed checklist item states",
                },
                {
                    "field": "completed_count",
                    "type": "int32",
                    "helper_text": "Number of completed items",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_completed_checklist_items",
            "task_name": "tasks.trello.get_completed_checklist_items",
            "description": "Get multiple checklist items",
            "label": "List Completed Checklist Items",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
            ],
            "required": ["checklist_id"],
        },
        "update_checklist_item": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card ID",
                    "helper_text": "The ID of the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "label": "Checklist ID",
                    "placeholder": "checklist123",
                    "helper_text": "The checklist to move this item to (optional - leave blank to keep in current checklist)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "helper_text": "The ID of the checklist item to update",
                    "placeholder": "1345abc67890",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Item Name",
                    "placeholder": "Updated item name",
                    "helper_text": "The new name for the checklist item",
                },
                {
                    "field": "checked",
                    "type": "bool",
                    "value": False,
                    "label": "Checked",
                    "helper_text": "Whether the item should be checked",
                },
                {
                    "field": "due",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31T23:59:59.000Z",
                    "helper_text": "Due date for the checklist item in ISO format (optional)",
                },
                {
                    "field": "pos",
                    "type": "int32",
                    "value": "",
                    "placeholder": "0",
                    "label": "Position",
                    "helper_text": "Position of the checklist item",
                },
                {
                    "field": "id_member",
                    "type": "string",
                    "value": "",
                    "label": "Assigned Member",
                    "placeholder": "Member ID",
                    "helper_text": "ID of the member to assign to this checklist item (optional)",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated checklist item",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Updated name of the checklist item",
                },
                {
                    "field": "checked",
                    "type": "bool",
                    "helper_text": "Whether the item is checked",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the checklist item",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position of the checklist item",
                },
                {
                    "field": "id_member",
                    "type": "string",
                    "helper_text": "ID of the member assigned to the checklist item",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_checklist_item",
            "task_name": "tasks.trello.update_checklist_item",
            "description": "Update a checklist item",
            "label": "Update Checklist Item",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
                "checklist_item_id",
                "name",
                "checked",
                "due",
                "pos",
                "id_member",
            ],
            "required": ["card_id", "checklist_item_id"],
        },
        "delete_checklist_item": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "value": "",
                    "label": "Card",
                    "helper_text": "The card containing the checklist",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "label": "Checklist ID",
                    "helper_text": "The ID of the checklist",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=checklist_id&card_id={inputs.card_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "value": "",
                    "label": "Item ID",
                    "helper_text": "The ID of the checklist item to delete",
                    "placeholder": "1345abc67890",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the deletion operation",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_checklist_item",
            "task_name": "tasks.trello.delete_checklist_item",
            "description": "Delete an item from a checklist",
            "label": "Delete Checklist Item",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "checklist_id",
                "checklist_item_id",
            ],
            "required": ["checklist_id", "checklist_item_id"],
        },
        "create_label": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to create the label on",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Label Name",
                    "placeholder": "Priority",
                    "helper_text": "The name of the new label",
                },
                {
                    "field": "color",
                    "type": "string",
                    "value": "blue",
                    "label": "Color",
                    "helper_text": "The color of the label (e.g., blue, green, yellow, etc)",
                },
            ],
            "outputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created label",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "Name of the created label",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the created label",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the label",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_label",
            "task_name": "tasks.trello.create_label",
            "description": "Create a new label on a board",
            "label": "Create Label",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "name",
                "color",
            ],
            "required": ["board_id", "name"],
        },
        "get_label": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board",
                    "helper_text": "The board containing the label",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "label": "Label ID",
                    "helper_text": "The ID of the label to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the label",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "Name of the label",
                },
                {
                    "field": "label_color",
                    "type": "string",
                    "helper_text": "Color of the label",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the label",
                },
                {
                    "field": "uses",
                    "type": "int32",
                    "helper_text": "Number of times the label is used",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_label",
            "task_name": "tasks.trello.get_label",
            "description": "Get details of a specific label",
            "label": "Get Label",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "label_id",
            ],
            "required": ["label_id"],
        },
        "list_labels": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board ID",
                    "helper_text": "The ID of the board to get labels from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "label_ids",
                    "type": "vec<string>",
                    "helper_text": "List of label IDs on the board",
                },
                {
                    "field": "label_names",
                    "type": "vec<string>",
                    "helper_text": "List of label names on the board",
                },
                {
                    "field": "label_colors",
                    "type": "vec<string>",
                    "helper_text": "List of label colors on the board",
                },
                {
                    "field": "label_uses",
                    "type": "vec<int32>",
                    "helper_text": "List of label usage counts on the board",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of labels on the board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_labels",
            "task_name": "tasks.trello.list_labels",
            "description": "Get multiple labels from a board",
            "label": "List Labels",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
            ],
            "required": ["board_id"],
        },
        "update_label": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board",
                    "helper_text": "The board containing the label",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "label": "Label ID",
                    "helper_text": "The ID of the label to update",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Label Name",
                    "placeholder": "Updated Priority",
                    "helper_text": "The new name for the label",
                },
                {
                    "field": "color",
                    "type": "string",
                    "value": "",
                    "label": "Color",
                    "helper_text": "The new color for the label (e.g., blue, green, yellow, etc)",
                },
            ],
            "outputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated label",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Updated name of the label",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Updated color of the label",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_label",
            "task_name": "tasks.trello.update_label",
            "description": "Update a label's details",
            "label": "Update Label",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "label_id",
                "name",
                "color",
            ],
            "required": ["label_id"],
        },
        "delete_label": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board",
                    "helper_text": "The board containing the label",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "label": "Label ID",
                    "helper_text": "The ID of the label to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the deletion operation",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_label",
            "task_name": "tasks.trello.delete_label",
            "description": "Delete a label",
            "label": "Delete Label",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "label_id",
            ],
            "required": ["label_id"],
        },
        "add_label_to_card": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Board",
                    "helper_text": "The board containing the card and label",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to add the label to",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "label": "Label ID",
                    "helper_text": "The ID of the label to add",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message indicating the result of the operation",
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "The ID of the card the label was added to",
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "The ID of the label that was added",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Trello API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_label_to_card",
            "task_name": "tasks.trello.add_label_to_card",
            "description": "Add a label to a card",
            "label": "Add Label to Card",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "label_id",
            ],
            "required": ["card_id", "label_id"],
        },
        "remove_label_from_card": {
            "inputs": [
                {
                    "field": "organization_id",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "helper_text": "The organization containing the board",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=organization_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "value": "",
                    "label": "Board",
                    "helper_text": "The board containing the card",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&organization_id={inputs.organization_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "helper_text": "The list containing the card",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "label": "Card ID",
                    "helper_text": "The ID of the card to remove the label from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=card_id&list_id={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "label": "Label ID",
                    "helper_text": "The ID of the label to remove",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=label_id&card_id={inputs.card_id}&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message indicating the result of the operation",
                },
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "The ID of the card the label was removed from",
                },
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "The ID of the label that was removed",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Descriptive message about the operation performed",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "remove_label_from_card",
            "task_name": "tasks.trello.remove_label_from_card",
            "description": "Remove a label from a card",
            "label": "Remove Label from Card",
            "input_sort_order": [
                "action",
                "integration",
                "organization_id",
                "board_id",
                "list_id",
                "card_id",
                "label_id",
            ],
            "required": ["card_id", "label_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        text: str = "",
        actions: str = "",
        address: str = "",
        allow_billable_guest: bool = False,
        attachment_fields: str = "",
        attachment_id: str = "",
        attachments: bool = False,
        board: bool = False,
        board_fields: str = "",
        board_id: str = "",
        board_stars: str = "",
        card_fields: str = "",
        card_id: str = "",
        card_plugin_data: bool = False,
        cards: str = "",
        check_item_states: bool = False,
        checked: bool = False,
        checklist_id: str = "",
        checklist_item_id: Optional[str] = None,
        checklists: str = "",
        closed: bool = False,
        color: str = "blue",
        comment_id: str = "",
        coordinates: str = "",
        custom_field_items: bool = False,
        custom_fields: bool = False,
        default_labels: bool = True,
        default_lists: bool = True,
        description: str = "",
        download_file: bool = False,
        due: Any = None,
        due_complete: bool = False,
        due_date: Any = None,
        email: str = "",
        fields: str = "",
        filter: str = "",
        full_name: str = "",
        id_attachment_cover: str = "",
        id_board_source: str = "",
        id_card_source: str = "",
        id_checklist_source: str = "",
        id_labels: str = "",
        id_member: str = "",
        id_members: str = "",
        id_organization: str = "",
        keep_from_source: str = "",
        label_id: Optional[str] = None,
        label_names_blue: str = "",
        label_names_green: str = "",
        label_names_orange: str = "",
        label_names_purple: str = "",
        label_names_red: str = "",
        label_names_yellow: str = "",
        labels: str = "",
        list: bool = False,
        list_id: Optional[str] = None,
        lists: str = "",
        location_name: str = "",
        member_fields: str = "",
        member_id: str = "",
        member_type: str = "normal",
        member_voted_fields: str = "",
        members: str = "",
        members_voted: bool = False,
        memberships: str = "",
        mime_type: str = "",
        name: str = "",
        new_board_id: str = "",
        new_list_id: str = "",
        organization: bool = False,
        organization_id: str = "",
        organization_plugin_data: bool = False,
        plugin_data: bool = False,
        pos: int = None,
        position: str = "bottom",
        power_ups: str = "",
        prefs_background: str = "",
        prefs_card_aging: str = "",
        prefs_card_covers: bool = True,
        prefs_comments: str = "",
        prefs_hide_votes: bool = False,
        prefs_invitations: str = "",
        prefs_permission_level: str = "",
        prefs_self_join: bool = False,
        prefs_voting: str = "",
        set_cover: bool = False,
        start_date: Any = None,
        sticker_fields: str = "",
        stickers: bool = False,
        subscribed: bool = False,
        tags: bool = False,
        url: str = "",
        url_source: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_trello",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if name is not None:
            self.inputs["name"] = name
        if description is not None:
            self.inputs["description"] = description
        if organization_id is not None:
            self.inputs["organization_id"] = organization_id
        if default_labels is not None:
            self.inputs["default_labels"] = default_labels
        if default_lists is not None:
            self.inputs["default_lists"] = default_lists
        if id_board_source is not None:
            self.inputs["id_board_source"] = id_board_source
        if keep_from_source is not None:
            self.inputs["keep_from_source"] = keep_from_source
        if power_ups is not None:
            self.inputs["power_ups"] = power_ups
        if prefs_permission_level is not None:
            self.inputs["prefs_permission_level"] = prefs_permission_level
        if prefs_voting is not None:
            self.inputs["prefs_voting"] = prefs_voting
        if prefs_comments is not None:
            self.inputs["prefs_comments"] = prefs_comments
        if prefs_invitations is not None:
            self.inputs["prefs_invitations"] = prefs_invitations
        if prefs_background is not None:
            self.inputs["prefs_background"] = prefs_background
        if prefs_card_aging is not None:
            self.inputs["prefs_card_aging"] = prefs_card_aging
        if board_id is not None:
            self.inputs["board_id"] = board_id
        if fields is not None:
            self.inputs["fields"] = fields
        if actions is not None:
            self.inputs["actions"] = actions
        if board_stars is not None:
            self.inputs["board_stars"] = board_stars
        if cards is not None:
            self.inputs["cards"] = cards
        if card_plugin_data is not None:
            self.inputs["card_plugin_data"] = card_plugin_data
        if checklists is not None:
            self.inputs["checklists"] = checklists
        if custom_fields is not None:
            self.inputs["custom_fields"] = custom_fields
        if labels is not None:
            self.inputs["labels"] = labels
        if lists is not None:
            self.inputs["lists"] = lists
        if members is not None:
            self.inputs["members"] = members
        if memberships is not None:
            self.inputs["memberships"] = memberships
        if plugin_data is not None:
            self.inputs["plugin_data"] = plugin_data
        if organization is not None:
            self.inputs["organization"] = organization
        if organization_plugin_data is not None:
            self.inputs["organization_plugin_data"] = organization_plugin_data
        if tags is not None:
            self.inputs["tags"] = tags
        if closed is not None:
            self.inputs["closed"] = closed
        if id_organization is not None:
            self.inputs["id_organization"] = id_organization
        if prefs_self_join is not None:
            self.inputs["prefs_self_join"] = prefs_self_join
        if prefs_card_covers is not None:
            self.inputs["prefs_card_covers"] = prefs_card_covers
        if prefs_hide_votes is not None:
            self.inputs["prefs_hide_votes"] = prefs_hide_votes
        if label_names_green is not None:
            self.inputs["label_names_green"] = label_names_green
        if label_names_yellow is not None:
            self.inputs["label_names_yellow"] = label_names_yellow
        if label_names_orange is not None:
            self.inputs["label_names_orange"] = label_names_orange
        if label_names_red is not None:
            self.inputs["label_names_red"] = label_names_red
        if label_names_purple is not None:
            self.inputs["label_names_purple"] = label_names_purple
        if label_names_blue is not None:
            self.inputs["label_names_blue"] = label_names_blue
        if member_id is not None:
            self.inputs["member_id"] = member_id
        if member_type is not None:
            self.inputs["member_type"] = member_type
        if allow_billable_guest is not None:
            self.inputs["allow_billable_guest"] = allow_billable_guest
        if email is not None:
            self.inputs["email"] = email
        if full_name is not None:
            self.inputs["full_name"] = full_name
        if position is not None:
            self.inputs["position"] = position
        if list_id is not None:
            self.inputs["list_id"] = list_id
        if card_fields is not None:
            self.inputs["card_fields"] = card_fields
        if board is not None:
            self.inputs["board"] = board
        if board_fields is not None:
            self.inputs["board_fields"] = board_fields
        if new_board_id is not None:
            self.inputs["new_board_id"] = new_board_id
        if pos is not None:
            self.inputs["pos"] = pos
        if subscribed is not None:
            self.inputs["subscribed"] = subscribed
        if due_date is not None:
            self.inputs["due_date"] = due_date
        if due_complete is not None:
            self.inputs["due_complete"] = due_complete
        if start_date is not None:
            self.inputs["start_date"] = start_date
        if id_members is not None:
            self.inputs["id_members"] = id_members
        if id_labels is not None:
            self.inputs["id_labels"] = id_labels
        if url_source is not None:
            self.inputs["url_source"] = url_source
        if id_card_source is not None:
            self.inputs["id_card_source"] = id_card_source
        if address is not None:
            self.inputs["address"] = address
        if location_name is not None:
            self.inputs["location_name"] = location_name
        if coordinates is not None:
            self.inputs["coordinates"] = coordinates
        if card_id is not None:
            self.inputs["card_id"] = card_id
        if attachments is not None:
            self.inputs["attachments"] = attachments
        if attachment_fields is not None:
            self.inputs["attachment_fields"] = attachment_fields
        if member_fields is not None:
            self.inputs["member_fields"] = member_fields
        if members_voted is not None:
            self.inputs["members_voted"] = members_voted
        if member_voted_fields is not None:
            self.inputs["member_voted_fields"] = member_voted_fields
        if check_item_states is not None:
            self.inputs["check_item_states"] = check_item_states
        if list is not None:
            self.inputs["list"] = list
        if stickers is not None:
            self.inputs["stickers"] = stickers
        if sticker_fields is not None:
            self.inputs["sticker_fields"] = sticker_fields
        if custom_field_items is not None:
            self.inputs["custom_field_items"] = custom_field_items
        if new_list_id is not None:
            self.inputs["new_list_id"] = new_list_id
        if id_attachment_cover is not None:
            self.inputs["id_attachment_cover"] = id_attachment_cover
        if text is not None:
            self.inputs["text"] = text
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if url is not None:
            self.inputs["url"] = url
        if mime_type is not None:
            self.inputs["mime_type"] = mime_type
        if set_cover is not None:
            self.inputs["set_cover"] = set_cover
        if attachment_id is not None:
            self.inputs["attachment_id"] = attachment_id
        if download_file is not None:
            self.inputs["download_file"] = download_file
        if filter is not None:
            self.inputs["filter"] = filter
        if id_checklist_source is not None:
            self.inputs["id_checklist_source"] = id_checklist_source
        if checklist_id is not None:
            self.inputs["checklist_id"] = checklist_id
        if checked is not None:
            self.inputs["checked"] = checked
        if due is not None:
            self.inputs["due"] = due
        if id_member is not None:
            self.inputs["id_member"] = id_member
        if checklist_item_id is not None:
            self.inputs["checklist_item_id"] = checklist_item_id
        if color is not None:
            self.inputs["color"] = color
        if label_id is not None:
            self.inputs["label_id"] = label_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationTrelloNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
