"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_datadog")
class IntegrationDatadogNode(Node):
    """
    Datadog

    ## Inputs
    ### Common Inputs
        action: Select the HTTP method to use
        integration: Connect to your Datadog account
    ### post
        body: Request body as JSON
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)
        headers: Additional headers as JSON object (optional)
        query_params: Query parameters as JSON object (optional)
    ### put
        body: Request body as JSON
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)
        headers: Additional headers as JSON object (optional)
        query_params: Query parameters as JSON object (optional)
    ### patch
        body: Request body as JSON
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)
        headers: Additional headers as JSON object (optional)
        query_params: Query parameters as JSON object (optional)
    ### get
        data_path: JSON path to the array of results in the response (e.g., 'data', 'monitors', 'dashboards')
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)
        headers: Additional headers as JSON object (optional)
        max_pages: Maximum number of pages to fetch (default: 10, set to 0 for unlimited)
        page_size: Number of items per page (default: 100)
        paginate: Enable automatic pagination to fetch all results
        pagination_type: Type of pagination: 'offset' (page[offset]/page[limit]) or 'cursor' (page[cursor])
        query_params: Query parameters as JSON object (optional)
    ### delete
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)
        headers: Additional headers as JSON object (optional)
        query_params: Query parameters as JSON object (optional)
    ### head
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)
        query_params: Query parameters as JSON object (optional)
    ### options
        endpoint: The API endpoint path (e.g., /api/v1/dashboard)

    ## Outputs
    ### get
        data: Parsed response data (combined if paginated)
        raw_data: Raw API response data
        response_headers: Response headers as JSON
        status_code: HTTP status code of the response
        total_pages_fetched: Number of pages fetched (when pagination is enabled)
    ### post
        data: Parsed response data
        raw_data: Raw API response data
        response_headers: Response headers as JSON
        status_code: HTTP status code of the response
    ### put
        data: Parsed response data
        raw_data: Raw API response data
        response_headers: Response headers as JSON
        status_code: HTTP status code of the response
    ### patch
        data: Parsed response data
        raw_data: Raw API response data
        response_headers: Response headers as JSON
        status_code: HTTP status code of the response
    ### delete
        data: Parsed response data
        raw_data: Raw API response data
        response_headers: Response headers as JSON
        status_code: HTTP status code of the response
    ### head
        response_headers: Response headers as JSON
        status_code: HTTP status code of the response
    ### options
        response_headers: Response headers as JSON (includes Allow header with permitted methods)
        status_code: HTTP status code of the response
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the HTTP method to use",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Datadog account",
            "value": None,
            "type": "integration<Datadog>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard",
                    "helper_text": "The API endpoint path (e.g., /api/v1/dashboard)",
                },
                {
                    "field": "query_params",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": '{"key": "value"}',
                    "helper_text": "Query parameters as JSON object (optional)",
                    "multiline": True,
                },
                {
                    "field": "headers",
                    "type": "string",
                    "value": "",
                    "label": "Additional Headers",
                    "placeholder": '{"X-Custom-Header": "value"}',
                    "helper_text": "Additional headers as JSON object (optional)",
                    "multiline": True,
                },
                {
                    "field": "paginate",
                    "type": "bool",
                    "value": False,
                    "label": "Enable Pagination",
                    "helper_text": "Enable automatic pagination to fetch all results",
                },
                {
                    "field": "pagination_type",
                    "type": "string",
                    "value": "offset",
                    "label": "Pagination Type",
                    "helper_text": "Type of pagination: 'offset' (page[offset]/page[limit]) or 'cursor' (page[cursor])",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Offset", "value": "offset"},
                            {"label": "Cursor", "value": "cursor"},
                        ],
                    },
                },
                {
                    "field": "page_size",
                    "type": "int32",
                    "value": 100,
                    "label": "Page Size",
                    "helper_text": "Number of items per page (default: 100)",
                },
                {
                    "field": "max_pages",
                    "type": "int32",
                    "value": 10,
                    "label": "Max Pages",
                    "helper_text": "Maximum number of pages to fetch (default: 10, set to 0 for unlimited)",
                },
                {
                    "field": "data_path",
                    "type": "string",
                    "value": "data",
                    "label": "Data Path",
                    "placeholder": "data",
                    "helper_text": "JSON path to the array of results in the response (e.g., 'data', 'monitors', 'dashboards')",
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "Parsed response data (combined if paginated)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
                {
                    "field": "total_pages_fetched",
                    "type": "int32",
                    "helper_text": "Number of pages fetched (when pagination is enabled)",
                },
            ],
            "name": "get",
            "task_name": "tasks.datadog.get",
            "description": "Make a GET request to Datadog API",
            "label": "GET Request",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "endpoint",
                "query_params",
                "headers",
                "paginate",
                "pagination_type",
                "page_size",
                "max_pages",
                "data_path",
            ],
            "required": ["endpoint"],
        },
        "post": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard",
                    "helper_text": "The API endpoint path (e.g., /api/v1/dashboard)",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Request Body",
                    "placeholder": '{"title": "My Dashboard"}',
                    "helper_text": "Request body as JSON",
                    "multiline": True,
                },
                {
                    "field": "query_params",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": '{"key": "value"}',
                    "helper_text": "Query parameters as JSON object (optional)",
                    "multiline": True,
                },
                {
                    "field": "headers",
                    "type": "string",
                    "value": "",
                    "label": "Additional Headers",
                    "placeholder": '{"X-Custom-Header": "value"}',
                    "helper_text": "Additional headers as JSON object (optional)",
                    "multiline": True,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "Parsed response data",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "post",
            "task_name": "tasks.datadog.post",
            "description": "Make a POST request to Datadog API",
            "label": "POST Request",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "endpoint",
                "body",
                "query_params",
                "headers",
            ],
            "required": ["endpoint", "body"],
        },
        "put": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard/{dashboard_id}",
                    "helper_text": "The API endpoint path (e.g., /api/v1/dashboard/{dashboard_id})",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Request Body",
                    "placeholder": '{"title": "Updated Dashboard"}',
                    "helper_text": "Request body as JSON",
                    "multiline": True,
                },
                {
                    "field": "query_params",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": '{"key": "value"}',
                    "helper_text": "Query parameters as JSON object (optional)",
                    "multiline": True,
                },
                {
                    "field": "headers",
                    "type": "string",
                    "value": "",
                    "label": "Additional Headers",
                    "placeholder": '{"X-Custom-Header": "value"}',
                    "helper_text": "Additional headers as JSON object (optional)",
                    "multiline": True,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "Parsed response data",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "put",
            "task_name": "tasks.datadog.put",
            "description": "Make a PUT request to Datadog API",
            "label": "PUT Request",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "endpoint",
                "body",
                "query_params",
                "headers",
            ],
            "required": ["endpoint", "body"],
        },
        "patch": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard/{dashboard_id}",
                    "helper_text": "The API endpoint path (e.g., /api/v1/dashboard/{dashboard_id})",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Request Body",
                    "placeholder": '{"title": "Patched Dashboard"}',
                    "helper_text": "Request body as JSON (partial update)",
                    "multiline": True,
                },
                {
                    "field": "query_params",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": '{"key": "value"}',
                    "helper_text": "Query parameters as JSON object (optional)",
                    "multiline": True,
                },
                {
                    "field": "headers",
                    "type": "string",
                    "value": "",
                    "label": "Additional Headers",
                    "placeholder": '{"X-Custom-Header": "value"}',
                    "helper_text": "Additional headers as JSON object (optional)",
                    "multiline": True,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "Parsed response data",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "patch",
            "task_name": "tasks.datadog.patch",
            "description": "Make a PATCH request to Datadog API",
            "label": "PATCH Request",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "endpoint",
                "body",
                "query_params",
                "headers",
            ],
            "required": ["endpoint", "body"],
        },
        "delete": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard/{dashboard_id}",
                    "helper_text": "The API endpoint path to the resource to delete",
                },
                {
                    "field": "query_params",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": '{"force": "true"}',
                    "helper_text": "Query parameters as JSON object (optional)",
                    "multiline": True,
                },
                {
                    "field": "headers",
                    "type": "string",
                    "value": "",
                    "label": "Additional Headers",
                    "placeholder": '{"X-Custom-Header": "value"}',
                    "helper_text": "Additional headers as JSON object (optional)",
                    "multiline": True,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "Parsed response data",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete",
            "task_name": "tasks.datadog.delete",
            "description": "Make a DELETE request to Datadog API",
            "label": "DELETE Request",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "endpoint",
                "query_params",
                "headers",
            ],
            "required": ["endpoint"],
        },
        "head": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard",
                    "helper_text": "The API endpoint path to check headers",
                },
                {
                    "field": "query_params",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": '{"key": "value"}',
                    "helper_text": "Query parameters as JSON object (optional)",
                    "multiline": True,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON",
                },
            ],
            "name": "head",
            "task_name": "tasks.datadog.head",
            "description": "Make a HEAD request to Datadog API (returns headers only)",
            "label": "HEAD Request",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "endpoint", "query_params"],
            "required": ["endpoint"],
        },
        "options": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "placeholder": "/api/v1/dashboard",
                    "helper_text": "The API endpoint path to check allowed methods",
                }
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "int32",
                    "helper_text": "HTTP status code of the response",
                },
                {
                    "field": "response_headers",
                    "type": "string",
                    "helper_text": "Response headers as JSON (includes Allow header with permitted methods)",
                },
            ],
            "name": "options",
            "task_name": "tasks.datadog.options",
            "description": "Make an OPTIONS request to check allowed HTTP methods",
            "label": "OPTIONS Request",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "endpoint"],
            "required": ["endpoint"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        body: str = "",
        data_path: str = "data",
        endpoint: str = "",
        headers: str = "",
        max_pages: int = 10,
        page_size: int = 100,
        paginate: bool = False,
        pagination_type: str = "offset",
        query_params: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_datadog",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if endpoint is not None:
            self.inputs["endpoint"] = endpoint
        if query_params is not None:
            self.inputs["query_params"] = query_params
        if headers is not None:
            self.inputs["headers"] = headers
        if paginate is not None:
            self.inputs["paginate"] = paginate
        if pagination_type is not None:
            self.inputs["pagination_type"] = pagination_type
        if page_size is not None:
            self.inputs["page_size"] = page_size
        if max_pages is not None:
            self.inputs["max_pages"] = max_pages
        if data_path is not None:
            self.inputs["data_path"] = data_path
        if body is not None:
            self.inputs["body"] = body
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationDatadogNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
