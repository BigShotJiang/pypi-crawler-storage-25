"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_cron")
class TriggerCronNode(Node):
    """
    Cron Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        item_id: Custom cron expression
        timezone: Timezone for the cron trigger
        trigger_enabled: Enable/Disable Automation
    ### monthly
        day_of_month: Day of the month to trigger
        time_of_day: Time of day to trigger (HH:MM)
    ### weekly
        day_of_week: Day of the week to trigger
        time_of_day: Time of day to trigger (HH:MM)
    ### daily
        time_of_day: Time of day to trigger (HH:MM)
        trigger_on_weekends: Trigger on weekends

    ## Outputs
    ### Common Outputs
        timestamp: The timestamp output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": {
                "object_type": ObjectType.INTEGRATION,
                "object_id": "6809a715ad4615eeb652a551",
            },
            "type": "integration<Cron>",
        },
        {
            "field": "item_id",
            "helper_text": "Custom cron expression",
            "value": "0 0 * * *",
            "type": "string",
        },
        {
            "field": "timezone",
            "helper_text": "Timezone for the cron trigger",
            "value": "UTC",
            "type": "string",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "timestamp", "helper_text": "The timestamp output", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "daily": {
            "inputs": [
                {
                    "field": "time_of_day",
                    "type": "string",
                    "value": "00:00",
                    "label": "Time of day",
                    "placeholder": "HH:MM",
                    "helper_text": "Time of day to trigger (HH:MM)",
                },
                {
                    "field": "trigger_on_weekends",
                    "type": "bool",
                    "value": False,
                    "label": "Trigger on weekends",
                    "helper_text": "Trigger on weekends",
                },
            ],
            "outputs": [],
            "variant": "cron",
            "name": "daily",
            "task_name": "tasks.cron.daily",
            "description": "Triggers once a day at a specified time",
            "label": "Daily",
        },
        "weekly": {
            "inputs": [
                {
                    "field": "day_of_week",
                    "type": "string",
                    "value": "Monday",
                    "label": "Day of the week",
                    "placeholder": "Select a day",
                    "helper_text": "Day of the week to trigger",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sunday", "value": "Sunday"},
                            {"label": "Monday", "value": "Monday"},
                            {"label": "Tuesday", "value": "Tuesday"},
                            {"label": "Wednesday", "value": "Wednesday"},
                            {"label": "Thursday", "value": "Thursday"},
                            {"label": "Friday", "value": "Friday"},
                            {"label": "Saturday", "value": "Saturday"},
                        ],
                    },
                },
                {
                    "field": "time_of_day",
                    "type": "string",
                    "value": "00:00",
                    "label": "Time of day",
                    "placeholder": "HH:MM",
                    "helper_text": "Time of day to trigger (HH:MM)",
                },
            ],
            "outputs": [],
            "variant": "cron",
            "name": "weekly",
            "task_name": "tasks.cron.weekly",
            "description": "Triggers once a week on a specified day and time",
            "label": "Weekly",
        },
        "monthly": {
            "inputs": [
                {
                    "field": "day_of_month",
                    "type": "int32",
                    "value": 1,
                    "label": "Day of the month",
                    "placeholder": "Select a day",
                    "helper_text": "Day of the month to trigger",
                },
                {
                    "field": "time_of_day",
                    "type": "string",
                    "value": "00:00",
                    "label": "Time of day",
                    "placeholder": "HH:MM",
                    "helper_text": "Time of day to trigger (HH:MM)",
                },
            ],
            "outputs": [],
            "variant": "cron",
            "name": "monthly",
            "task_name": "tasks.cron.monthly",
            "description": "Triggers once a month on a specified day and time",
            "label": "Monthly",
        },
        "custom": {
            "inputs": [],
            "outputs": [],
            "variant": "cron",
            "name": "custom",
            "task_name": "tasks.cron.custom",
            "description": "Triggers based on a custom cron expression",
            "label": "Custom Cron Expression",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Item ID"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        day_of_month: int = 1,
        day_of_week: str = "Monday",
        item_id: str = "0 0 * * *",
        time_of_day: str = "00:00",
        timezone: str = "UTC",
        trigger_enabled: bool = True,
        trigger_on_weekends: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_cron",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if timezone is not None:
            self.inputs["timezone"] = timezone
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if time_of_day is not None:
            self.inputs["time_of_day"] = time_of_day
        if trigger_on_weekends is not None:
            self.inputs["trigger_on_weekends"] = trigger_on_weekends
        if day_of_week is not None:
            self.inputs["day_of_week"] = day_of_week
        if day_of_month is not None:
            self.inputs["day_of_month"] = day_of_month
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerCronNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
