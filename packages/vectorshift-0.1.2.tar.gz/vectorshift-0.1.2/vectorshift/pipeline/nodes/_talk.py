"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import CardButton, CarouselCard


@Node.register_node_type("talk")
class TalkNode(Node):
    """
    Send a given message at a stage in a conversation.

    ## Inputs
    ### Common Inputs
        is_iframe: The is_iframe input
        variant: The variant input
    ### When variant = 'card'
        button: The button input
        description: The card's description.
        image_url: The image to be sent at this step in the conversation.
        title: The card's title.
    ### When variant = 'carousel'
        cards: The cards input
    ### When variant = 'message' and is_iframe = False
        content: The text to send to the user.
    ### When variant = 'message' and is_iframe = True
        content: The text to send to the user.
    ### When variant = 'image'
        image_url: The image to be sent at this step in the conversation.

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "is_iframe",
            "helper_text": "The is_iframe input",
            "value": False,
            "type": "bool",
        },
        {
            "field": "variant",
            "helper_text": "The variant input",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "message**false": {
            "title": "Message",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/talk/message",
            "helper_text": "Send a given message at a stage in a conversation.",
            "short_description": "Send a given message at a stage in a conversation.",
            "inputs": [
                {
                    "field": "content",
                    "type": "string",
                    "value": "",
                    "helper_text": "The text to send to the user.",
                    "placeholder": "Enter your message here",
                    "label": "Message",
                    "component": {"type": "text", "multiline": True, "default": ""},
                },
                {
                    "field": "variant",
                    "type": "string",
                    "value": "message",
                    "visibility": False,
                },
            ],
            "outputs": [],
        },
        "message**true": {
            "title": "Message",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/talk/message",
            "helper_text": "Send a given message at a stage in a conversation.",
            "short_description": "Send a given iframe at a stage in a conversation.",
            "inputs": [
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "The text to send to the user.",
                    "value": "<iframe src='ENTER_URL_HERE' width='320px' height='400px'></iframe>",
                    "label": "Message",
                    "component": {"type": "text", "multiline": True},
                },
                {
                    "field": "variant",
                    "type": "string",
                    "value": "message",
                    "visibility": False,
                },
            ],
            "outputs": [],
            "banner_text": "Please add your url in 'ENTER_URL_HERE'. Iframe width should be 320px",
        },
        "image**(*)": {
            "title": "Image",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/talk/image",
            "helper_text": "Send an image in chat at this step in the conversation.",
            "short_description": "Send an image in chat at this step in the conversation.",
            "inputs": [
                {
                    "field": "variant",
                    "type": "string",
                    "value": "image",
                    "visibility": False,
                },
                {
                    "field": "image_url",
                    "label": "Image",
                    "value": {},
                    "type": "image",
                    "helper_text": "The image to be sent at this step in the conversation.",
                },
            ],
            "outputs": [],
        },
        "card**(*)": {
            "title": "Card",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/talk/card",
            "helper_text": "Send a card (a component with image, title, description, and button) in chat at this step in the conversation.",
            "short_description": "Send a card (a component with image, title, description, and button) in chat at this step in the conversation.",
            "inputs": [
                {
                    "field": "variant",
                    "type": "string",
                    "value": "card",
                    "visibility": False,
                },
                {
                    "field": "title",
                    "label": "Title",
                    "type": "string",
                    "value": "",
                    "helper_text": "The card's title.",
                },
                {
                    "field": "description",
                    "label": "Description",
                    "type": "string",
                    "value": "",
                    "helper_text": "The card's description.",
                },
                {
                    "field": "button",
                    "label": "Button",
                    "type": "interface{id:string, name: string, actionType: string, url: string}",
                    "value": {
                        "id": "asfkwewkfmdke",
                        "name": "Submit",
                        "url": "https://vectorshift.ai/",
                        "actionType": "Link",
                    },
                    "component": {
                        "type": "table",
                        "vertical_table_layout": True,
                        "hide_add_button": True,
                        "decorators": {"hide": ["general_input_label"]},
                        "table": {
                            "name": {
                                "label": "Button Name",
                                "helper_text": "The name of the button.",
                            },
                            "actionType": {
                                "label": "Button Action Type",
                                "helper_text": "Select the action to occur when the button is clicked.",
                                "dropdown_options": [{"label": "Link", "value": "Link"}],
                                "default_value": "Link",
                            },
                            "url": {
                                "label": "Button URL",
                                "helper_text": "The URL to navigate to when the button is clicked.",
                            },
                        },
                    },
                },
                {
                    "field": "image_url",
                    "label": "Image",
                    "value": {},
                    "type": "image",
                    "helper_text": "The card's image.",
                },
            ],
            "outputs": [],
        },
        "carousel**(*)": {
            "title": "Carousel",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/talk/carousel",
            "helper_text": "Send a carousel (a gallery of multiple cards) in chat at this step in the conversation.",
            "short_description": "Send a carousel (a gallery of multiple cards) in chat at this step in the conversation.",
            "inputs": [
                {
                    "field": "variant",
                    "type": "string",
                    "value": "carousel",
                    "visibility": False,
                },
                {
                    "field": "cards",
                    "label": "Cards",
                    "type": "vec<interface{id:string, title: string, description: string, image_url: image, button:interface{id:string, name:string, actionType: string, url:string} }>",
                    "value": [
                        {
                            "id": "afgj3rf4fmo3i4jrf43rgfm",
                            "title": "Card 1",
                            "description": "This is a description",
                            "image_url": {},
                            "button": {
                                "id": "fref43jrfn",
                                "name": "Submit",
                                "url": "https://vectorshift.ai/",
                                "actionType": "Link",
                            },
                        }
                    ],
                    "table": {
                        "title": {"helper_text": "The card's title."},
                        "description": {"helper_text": "The card's description."},
                        "image_url": {"helper_text": "The card's image URL."},
                        "button": {
                            "name": {"helper_text": "The name of the button."},
                            "actionType": {
                                "helper_text": "Select the action to occur when the button is clicked."
                            },
                            "url": {
                                "helper_text": "The URL to navigate to when the button is clicked."
                            },
                        },
                    },
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["variant", "is_iframe"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["content", "title", "description", "image_url"]

    def __init__(
        self,
        variant: str = "",
        is_iframe: bool = False,
        button: CardButton = {
            "id": "asfkwewkfmdke",
            "name": "Submit",
            "url": "https://vectorshift.ai/",
            "actionType": "Link",
        },
        cards: List[CarouselCard] = [
            {
                "id": "afgj3rf4fmo3i4jrf43rgfm",
                "title": "Card 1",
                "description": "This is a description",
                "image_url": {},
                "button": {
                    "id": "fref43jrfn",
                    "name": "Submit",
                    "url": "https://vectorshift.ai/",
                    "actionType": "Link",
                },
            }
        ],
        content: str = "",
        description: str = "",
        image_url: Any = {},
        title: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["variant"] = variant
        params["is_iframe"] = is_iframe

        super().__init__(
            node_type="talk",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if variant is not None:
            self.inputs["variant"] = variant
        if is_iframe is not None:
            self.inputs["is_iframe"] = is_iframe
        if content is not None:
            self.inputs["content"] = content
        if image_url is not None:
            self.inputs["image_url"] = image_url
        if title is not None:
            self.inputs["title"] = title
        if description is not None:
            self.inputs["description"] = description
        if button is not None:
            self.inputs["button"] = button
        if cards is not None:
            self.inputs["cards"] = cards
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TalkNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
