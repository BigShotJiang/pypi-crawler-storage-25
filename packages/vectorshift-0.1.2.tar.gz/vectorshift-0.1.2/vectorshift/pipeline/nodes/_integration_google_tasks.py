"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_tasks")
class IntegrationGoogleTasksNode(Node):
    """
    Google Tasks

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Google Tasks account
    ### get_tasks
        completed_max: Maximum completion time
        completed_min: Minimum completion time
        due_max: Maximum due date
        due_min: Minimum due date
        max_results: Maximum number of tasks to return
        show_completed: Include completed tasks
        show_deleted: Include deleted tasks
        show_hidden: Include hidden tasks
        task_list_id: Select the task list
        updated_min: Minimum update time
    ### add_task
        due: Due date
        notes: Task notes
        task_list_id: Select the task list
        title: Task title
    ### update_task
        due: Due date
        notes: Task notes
        status: Task status
        task_id: Select the task to delete
        task_list_id: Select the task list
        title: Task title
    ### delete_task
        task_id: Select the task to delete
        task_list_id: Select the task list
    ### read_task
        task_id: Select the task to delete
        task_list_id: Select the task list

    ## Outputs
    ### delete_task
        message: Deletion status message
    ### add_task
        success: Whether the task was created successfully
        task_data: Created task data in JSON format
        task_id: ID of the created task
        task_title: Title of the created task
        task_url: URL of the created task
    ### update_task
        success: Whether the task was updated successfully
        task_data: Updated task data in JSON format
        task_id: ID of the updated task
        task_status: Status of the updated task
        task_title: Title of the updated task
        task_updated: Last updated date of the task
    ### read_task
        task_completed: Completion date of the retrieved task
        task_data: Retrieved task data in JSON format
        task_due: Due date of the retrieved task
        task_id: ID of the retrieved task
        task_notes: Notes of the retrieved task
        task_status: Status of the retrieved task
        task_title: Title of the retrieved task
        task_updated: Last updated date of the retrieved task
    ### get_tasks
        task_count: Number of tasks returned
        task_due_dates: List of task due dates
        task_ids: List of task IDs
        task_statuses: List of task statuses
        task_titles: List of task titles
        tasks: All tasks data in JSON format
        total_count: Total number of tasks matching filters
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Google Tasks account",
            "value": None,
            "type": "integration<Google Tasks>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "add_task": {
            "inputs": [
                {
                    "field": "task_list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task list",
                    "label": "Task List",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Task title",
                    "label": "Task Title",
                    "placeholder": "Enter task title",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Task notes",
                    "label": "Task Notes",
                    "placeholder": "Enter task notes",
                },
                {
                    "field": "due",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date",
                    "label": "Due Date",
                    "placeholder": "2024-01-15T10:00:00Z",
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the created task",
                },
                {
                    "field": "task_title",
                    "type": "string",
                    "helper_text": "Title of the created task",
                },
                {
                    "field": "task_url",
                    "type": "string",
                    "helper_text": "URL of the created task",
                },
                {
                    "field": "task_data",
                    "type": "string",
                    "helper_text": "Created task data in JSON format",
                },
                {
                    "field": "success",
                    "type": "bool",
                    "helper_text": "Whether the task was created successfully",
                },
            ],
            "name": "add_task",
            "task_name": "tasks.google_tasks.add_task",
            "description": "Add a new task to a Google Tasks list",
            "label": "Add Task",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "task_list_id",
                "title",
                "notes",
                "due",
            ],
            "required": ["task_list_id", "title"],
        },
        "delete_task": {
            "inputs": [
                {
                    "field": "task_list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task list",
                    "label": "Task List",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task to delete",
                    "label": "Task ID",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_id&task_list_id={inputs.task_list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion status message",
                }
            ],
            "name": "delete_task",
            "task_name": "tasks.google_tasks.delete_task",
            "description": "Delete a task from a Google Tasks list",
            "label": "Delete Task",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "task_list_id", "task_id"],
            "required": ["task_list_id", "task_id"],
        },
        "read_task": {
            "inputs": [
                {
                    "field": "task_list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task list",
                    "label": "Task List",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task to retrieve",
                    "label": "Task ID",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_id&task_list_id={inputs.task_list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the retrieved task",
                },
                {
                    "field": "task_title",
                    "type": "string",
                    "helper_text": "Title of the retrieved task",
                },
                {
                    "field": "task_notes",
                    "type": "string",
                    "helper_text": "Notes of the retrieved task",
                },
                {
                    "field": "task_status",
                    "type": "string",
                    "helper_text": "Status of the retrieved task",
                },
                {
                    "field": "task_due",
                    "type": "timestamp",
                    "helper_text": "Due date of the retrieved task",
                },
                {
                    "field": "task_completed",
                    "type": "timestamp",
                    "helper_text": "Completion date of the retrieved task",
                },
                {
                    "field": "task_updated",
                    "type": "timestamp",
                    "helper_text": "Last updated date of the retrieved task",
                },
                {
                    "field": "task_data",
                    "type": "string",
                    "helper_text": "Retrieved task data in JSON format",
                },
            ],
            "name": "read_task",
            "task_name": "tasks.google_tasks.read_task",
            "description": "Read details of a specific task",
            "label": "Get Task",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "task_list_id", "task_id"],
            "required": ["task_list_id", "task_id"],
        },
        "get_tasks": {
            "inputs": [
                {
                    "field": "task_list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task list",
                    "label": "Task List",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "completed_min",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Minimum completion time",
                    "label": "Completed Min",
                    "placeholder": "2024-01-01T00:00:00Z",
                },
                {
                    "field": "completed_max",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Maximum completion time",
                    "label": "Completed Max",
                    "placeholder": "2024-12-31T23:59:59Z",
                },
                {
                    "field": "due_min",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Minimum due date",
                    "label": "Due Min",
                    "placeholder": "2024-01-01T00:00:00Z",
                },
                {
                    "field": "due_max",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Maximum due date",
                    "label": "Due Max",
                    "placeholder": "2024-12-31T23:59:59Z",
                },
                {
                    "field": "show_completed",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include completed tasks",
                    "label": "Show Completed",
                },
                {
                    "field": "show_deleted",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include deleted tasks",
                    "label": "Show Deleted",
                },
                {
                    "field": "show_hidden",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include hidden tasks",
                    "label": "Show Hidden",
                },
                {
                    "field": "updated_min",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Minimum update time",
                    "label": "Updated Min",
                    "placeholder": "2024-01-01T00:00:00Z",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 100,
                    "helper_text": "Maximum number of tasks to return",
                    "label": "Max Results",
                    "component": {
                        "type": "int32",
                        "slider": True,
                        "min": 1,
                        "max": 1000,
                        "step": 1,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "tasks",
                    "type": "string",
                    "helper_text": "All tasks data in JSON format",
                },
                {
                    "field": "task_count",
                    "type": "int32",
                    "helper_text": "Number of tasks returned",
                },
                {
                    "field": "task_ids",
                    "type": "vec<string>",
                    "helper_text": "List of task IDs",
                },
                {
                    "field": "task_titles",
                    "type": "vec<string>",
                    "helper_text": "List of task titles",
                },
                {
                    "field": "task_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of task statuses",
                },
                {
                    "field": "task_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of task due dates",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of tasks matching filters",
                },
            ],
            "name": "get_tasks",
            "task_name": "tasks.google_tasks.get_tasks",
            "description": "Get multiple tasks",
            "label": "List Tasks",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "task_list_id",
                "completed_min",
                "completed_max",
                "due_min",
                "due_max",
                "show_completed",
                "show_deleted",
                "show_hidden",
                "updated_min",
                "max_results",
            ],
            "required": ["task_list_id"],
        },
        "update_task": {
            "inputs": [
                {
                    "field": "task_list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task list",
                    "label": "Task List",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the task to update",
                    "label": "Task ID",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=task_id&task_list_id={inputs.task_list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New task title",
                    "label": "Task Title",
                    "placeholder": "Enter new task title",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "New task notes",
                    "label": "Task Notes",
                    "placeholder": "Enter new task notes",
                },
                {
                    "field": "due",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "New due date",
                    "label": "Due Date",
                    "placeholder": "2024-01-15T10:00:00Z",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "needsAction",
                    "helper_text": "Task status",
                    "label": "Status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Needs Action", "value": "needsAction"},
                            {"label": "Completed", "value": "completed"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the updated task",
                },
                {
                    "field": "task_title",
                    "type": "string",
                    "helper_text": "Title of the updated task",
                },
                {
                    "field": "task_status",
                    "type": "string",
                    "helper_text": "Status of the updated task",
                },
                {
                    "field": "task_updated",
                    "type": "timestamp",
                    "helper_text": "Last updated date of the task",
                },
                {
                    "field": "task_data",
                    "type": "string",
                    "helper_text": "Updated task data in JSON format",
                },
                {
                    "field": "success",
                    "type": "bool",
                    "helper_text": "Whether the task was updated successfully",
                },
            ],
            "name": "update_task",
            "task_name": "tasks.google_tasks.update_task",
            "description": "Update an existing task in a Google Tasks list",
            "label": "Update Task",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "task_list_id",
                "task_id",
                "title",
                "notes",
                "due",
                "status",
            ],
            "required": ["task_list_id", "task_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        completed_max: Any = None,
        completed_min: Any = None,
        due: Any = None,
        due_max: Any = None,
        due_min: Any = None,
        max_results: int = 100,
        notes: str = "",
        show_completed: bool = False,
        show_deleted: bool = False,
        show_hidden: bool = False,
        status: str = "needsAction",
        task_id: str = "",
        task_list_id: str = "",
        title: str = "",
        updated_min: Any = None,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_tasks",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if task_list_id is not None:
            self.inputs["task_list_id"] = task_list_id
        if title is not None:
            self.inputs["title"] = title
        if notes is not None:
            self.inputs["notes"] = notes
        if due is not None:
            self.inputs["due"] = due
        if task_id is not None:
            self.inputs["task_id"] = task_id
        if completed_min is not None:
            self.inputs["completed_min"] = completed_min
        if completed_max is not None:
            self.inputs["completed_max"] = completed_max
        if due_min is not None:
            self.inputs["due_min"] = due_min
        if due_max is not None:
            self.inputs["due_max"] = due_max
        if show_completed is not None:
            self.inputs["show_completed"] = show_completed
        if show_deleted is not None:
            self.inputs["show_deleted"] = show_deleted
        if show_hidden is not None:
            self.inputs["show_hidden"] = show_hidden
        if updated_min is not None:
            self.inputs["updated_min"] = updated_min
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if status is not None:
            self.inputs["status"] = status
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleTasksNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
