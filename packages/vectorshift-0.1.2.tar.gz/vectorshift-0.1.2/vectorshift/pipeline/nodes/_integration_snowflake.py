"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_snowflake")
class IntegrationSnowflakeNode(Node):
    """
    Snowflake

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Snowflake account
    ### nl
        query: SQL Query to execute
        database: Select the Database on which to perform the query
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        schema: Select the schema to be used in the query
        sql_generation_model: The sql_generation_model input
        warehouse: Select the SQL Warehouse which will perform the operation
    ### raw_sql
        query: SQL Query to execute
        database: Select the Database on which to perform the query
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        schema: Select the schema to be used in the query
        sql_generation_model: The sql_generation_model input
        warehouse: Select the SQL Warehouse which will perform the operation
    ### nl_agent
        query: SQL Query to execute
        database: Select the Database on which to perform the query
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        schema: Select the schema to be used in the query
        sql_generation_model: The sql_generation_model input
        warehouse: Select the SQL Warehouse which will perform the operation
    ### insert
        data: JSON object with column-value pairs to insert
        database: Select the Database on which to perform the query
        return_id: Return the ID of the inserted record (if available)
        schema: Select the schema to be used in the query
        table_name: Choose the table to insert into
        warehouse: Select the SQL Warehouse which will perform the operation
    ### update
        data: JSON object with column-value pairs to insert
        database: Select the Database on which to perform the query
        limit: Maximum number of rows to update (0 for no limit)
        schema: Select the schema to be used in the query
        table_name: Choose the table to insert into
        warehouse: Select the SQL Warehouse which will perform the operation
        where_clause: WHERE condition to identify records to update

    ## Outputs
    ### Common Outputs
        output: Results of the query or operation. Example: [{"name": "John", "age": 29, "department": "Engineering"}]
    ### insert
        affected_rows: Number of rows inserted
        raw_data: Raw response from Snowflake
        sql_query: Generated SQL query
    ### update
        affected_rows: Number of rows updated
        raw_data: Raw response from Snowflake
        sql_query: Generated SQL query
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Snowflake account",
            "value": None,
            "type": "integration<Snowflake>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": 'Results of the query or operation. Example: [{"name": "John", "age": 29, "department": "Engineering"}]',
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "nl": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "SQL Query to execute",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "warehouse",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "helper_text": "Select the SQL Warehouse which will perform the operation",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=warehouse&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "",
                    "label": "Database",
                    "helper_text": "Select the Database on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "helper_text": "Select the schema to be used in the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema&database={inputs.database}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "nl",
            "task_name": "tasks.tables.integrations.snowflake.query",
            "description": "Generate and execute a SQL query",
            "label": "Natural Language Query",
        },
        "raw_sql": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "SQL Query to execute",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "warehouse",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "helper_text": "Select the SQL Warehouse which will perform the operation",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=warehouse&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "",
                    "label": "Database",
                    "helper_text": "Select the Database on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "helper_text": "Select the schema to be used in the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=schema&database={inputs.database}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "raw_sql",
            "task_name": "tasks.snowflake.query",
            "description": "Execute a SQL query",
            "label": "Raw SQL Query",
        },
        "nl_agent": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "SQL Query to execute",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "warehouse",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "helper_text": "Select the SQL Warehouse which will perform the operation",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=warehouse&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "",
                    "label": "Database",
                    "helper_text": "Select the Database on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "helper_text": "Select the schema to be used in the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=schema&database={inputs.database}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "nl_agent",
            "task_name": "tasks.tables.integrations.snowflake.query",
            "description": "Let an LLM agent query the database",
            "label": "Natural Language Agent",
        },
        "insert": {
            "inputs": [
                {
                    "field": "warehouse",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "helper_text": "Select the Warehouse to use for the operation",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=warehouse&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "",
                    "label": "Database",
                    "helper_text": "Select the Database on which to perform the query",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "helper_text": "Select the schema to be used in the query",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=schema&database={inputs.database}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert into",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&database={inputs.database}&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"column1": "value1", "column2": "value2"}',
                    "helper_text": "JSON object with column-value pairs to insert",
                },
                {
                    "field": "return_id",
                    "type": "bool",
                    "value": False,
                    "label": "Return ID",
                    "helper_text": "Return the ID of the inserted record (if available)",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows inserted",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Snowflake",
                },
            ],
            "name": "insert",
            "task_name": "tasks.snowflake.insert",
            "description": "Insert new data into a Snowflake table",
            "label": "Insert Data",
            "variant": "common_integration_nodes",
            "required": ["warehouse", "table_name", "data"],
            "ui_sort_order": [
                "integration",
                "action",
                "warehouse",
                "database",
                "schema",
                "table_name",
                "data",
                "return_id",
            ],
        },
        "update": {
            "inputs": [
                {
                    "field": "warehouse",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "helper_text": "Select the Warehouse to use for the operation",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=warehouse&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "",
                    "label": "Database",
                    "helper_text": "Select the Database on which to perform the query",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "helper_text": "Select the schema to be used in the query",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=schema&database={inputs.database}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&database={inputs.database}&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Update Data",
                    "placeholder": '{"column1": "new_value1", "column2": "new_value2"}',
                    "helper_text": "JSON object with column-value pairs to update",
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "id = 123",
                    "helper_text": "WHERE condition to identify records to update",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 0,
                    "label": "Update Limit",
                    "helper_text": "Maximum number of rows to update (0 for no limit)",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows updated",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Snowflake",
                },
            ],
            "name": "update",
            "task_name": "tasks.snowflake.update",
            "description": "Update existing data in a Snowflake table",
            "label": "Update Data",
            "variant": "common_integration_nodes",
            "required": ["warehouse", "table_name", "data", "where_clause"],
            "ui_sort_order": [
                "integration",
                "action",
                "warehouse",
                "database",
                "schema",
                "table_name",
                "data",
                "where_clause",
                "limit",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        data: str = "",
        database: str = "",
        limit: int = 0,
        query_agent_model: str = "gpt-4-turbo-preview",
        query_type: str = "Raw SQL",
        return_id: bool = False,
        schema: str = "",
        sql_generation_model: str = "gpt-4-turbo-preview",
        table_name: str = "",
        warehouse: str = "",
        where_clause: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_snowflake",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if query is not None:
            self.inputs["query"] = query
        if query_type is not None:
            self.inputs["query_type"] = query_type
        if warehouse is not None:
            self.inputs["warehouse"] = warehouse
        if database is not None:
            self.inputs["database"] = database
        if schema is not None:
            self.inputs["schema"] = schema
        if sql_generation_model is not None:
            self.inputs["sql_generation_model"] = sql_generation_model
        if query_agent_model is not None:
            self.inputs["query_agent_model"] = query_agent_model
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if data is not None:
            self.inputs["data"] = data
        if return_id is not None:
            self.inputs["return_id"] = return_id
        if where_clause is not None:
            self.inputs["where_clause"] = where_clause
        if limit is not None:
            self.inputs["limit"] = limit
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSnowflakeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
