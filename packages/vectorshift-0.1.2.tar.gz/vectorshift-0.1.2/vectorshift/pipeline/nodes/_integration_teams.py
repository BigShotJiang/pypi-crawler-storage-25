"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_teams")
class IntegrationTeamsNode(Node):
    """
    Teams

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### create_task
        assigned_to: Select a user to assign the task to
        bucket_id: Select the bucket to create the task in
        due_date: Due date for the task (YYYY-MM-DD format)
        percent_complete: Completion percentage (0-100)
        plan_id: Select the planner plan to create the task in
        task_title: Title of the task
        team_id: Select the team where you want to create the channel
    ### update_task
        assigned_to: Select a user to assign the task to
        bucket_id: Select the bucket to create the task in
        due_date: Due date for the task (YYYY-MM-DD format)
        new_bucket_id: New bucket ID to move task to
        percent_complete: Completion percentage (0-100)
        plan_id: Select the planner plan to create the task in
        task_id: Select the task to delete
        task_title: Title of the task
        team_id: Select the team where you want to create the channel
    ### delete_task
        bucket_id: Select the bucket to create the task in
        plan_id: Select the planner plan to create the task in
        task_id: Select the task to delete
        team_id: Select the team where you want to create the channel
    ### get_task
        bucket_id: Select the bucket to create the task in
        plan_id: Select the planner plan to create the task in
        task_id: Select the task to delete
        team_id: Select the team where you want to create the channel
    ### create_channel
        channel_description: Optional description for the channel
        channel_name: Name of the channel to create
        channel_type: Type of channel (standard or private)
        team_id: Select the team where you want to create the channel
    ### update_channel
        channel_description: Optional description for the channel
        channel_id: Select the channel to delete
        channel_name: Name of the channel to create
        team_id: Select the team where you want to create the channel
    ### delete_channel
        channel_id: Select the channel to delete
        team_id: Select the team where you want to create the channel
    ### get_channel
        channel_id: Select the channel to delete
        team_id: Select the team where you want to create the channel
    ### send_message
        channel_id: Select the channel to delete
        content_type: Type of message content
        message_content: The message content to post
        reply_to_message_id: ID of message to reply to (optional)
        team_id: Select the team where you want to create the channel
    ### list_channel_messages
        channel_id: Select the channel to delete
        limit: Maximum number of messages to retrieve
        team_id: Select the team where you want to create the channel
    ### list_channels
        channel_type: Type of channel (standard or private)
        select_fields: Comma-separated list of fields to return. Leave empty for all fields
        team_id: Select the team where you want to create the channel
    ### create_chat_message
        chat_id: Select the chat to send message to
        content_type: Type of message content
        message_content: The message content to post
    ### get_chat_message
        chat_id: Select the chat to send message to
        message_id: ID of the message to retrieve
    ### list_chat_messages
        chat_id: Select the chat to send message to
        limit: Maximum number of messages to retrieve
    ### list_tasks
        limit: Maximum number of messages to retrieve
        plan_id: Select the planner plan to create the task in
        team_id: Select the team where you want to create the channel
    ### list_users
        limit: Maximum number of messages to retrieve
    ### get_user
        user_identifier: Choose a user to fetch their profile

    ## Outputs
    ### create_task
        bucket_id: Bucket ID of the task
        created_at: Creation timestamp
        due_date: Due date of the task
        has_description: Whether the task has a description
        percent_complete: Completion percentage
        plan_id: Plan ID of the task
        raw_data: Raw response data from Teams API
        task_id: ID of the created task
        task_title: Title of the created task
    ### get_task
        bucket_id: Bucket ID of the task
        completed_at: Completion timestamp
        conversation_thread_id: Conversation thread ID
        created_at: Creation timestamp
        due_date: Due date of the task
        has_description: Whether the task has a description
        percent_complete: Completion percentage
        plan_id: Plan ID of the task
        raw_data: Raw response data from Teams API
        task_id: ID of the task
        task_title: Title of the task
    ### create_channel
        channel_description: Description of the created channel
        channel_email: Email address of the created channel
        channel_id: ID of the created channel
        channel_name: Name of the created channel
        channel_type: Type of the created channel
        channel_web_url: Web URL of the created channel
        created_at: Creation timestamp
        raw_data: Raw response data from Teams API
    ### get_channel
        channel_description: Description of the channel
        channel_email: Email address of the channel
        channel_id: ID of the channel
        channel_name: Name of the channel
        channel_type: Type of the channel
        channel_web_url: Web URL of the channel
        created_at: Creation timestamp
        raw_data: Raw response data from Teams API
    ### update_channel
        channel_id: ID of the updated channel
    ### list_channels
        channel_ids: List of channel IDs
        channel_names: List of channel names
        raw_data: Raw response data from Teams API
        total_count: Total number of channels found
    ### send_message
        content_type: Content type of the message
        created_at: Creation timestamp
        from_user: Display name of the message sender
        from_user_email: Email of the message sender
        message_content: Content of the message
        message_id: ID of the created message
        message_type: Type of the message
        raw_data: Raw response data from Teams API
        web_url: Web URL of the message
    ### create_chat_message
        content_type: Content type of the message
        created_at: Creation timestamp
        from_user: Display name of the message sender
        from_user_email: Email of the message sender
        message_content: Content of the message
        message_id: ID of the created message
        message_type: Type of the message
        raw_data: Raw response data from Teams API
        web_url: Web URL of the message
    ### get_chat_message
        content_type: Content type of the message
        created_at: Creation timestamp
        from_user: Display name of the message sender
        from_user_email: Email of the message sender
        last_modified_at: Last modification timestamp
        message_content: Content of the message
        message_id: ID of the message
        message_type: Type of the message
        raw_data: Raw response data from Teams API
        web_url: Web URL of the message
    ### get_user
        display_name: The user's display name
        id: The unique ID of the user
        job_title: The user's job title
        mail: The user's email address
        mobile_phone: The user's mobile phone number
        office_location: The user's office location
        raw_data: Complete response from Microsoft Graph API
        user_principal_name: The primary sign-in name for the user
    ### list_channel_messages
        has_next_page: Whether there are more messages available
        message_ids: List of message IDs
        message_summaries: List of message summaries
        raw_data: Raw response data from Teams API
        total_count: Total number of messages found
    ### list_chat_messages
        has_next_page: Whether there are more messages available
        message_ids: List of message IDs
        message_summaries: List of message summaries
        raw_data: Raw response data from Teams API
        total_count: Total number of messages found
    ### list_tasks
        has_next_page: Whether there are more tasks available
        raw_data: Raw response data from Teams API
        task_ids: List of task IDs
        task_titles: List of task titles
        total_count: Total number of tasks found
    ### delete_channel
        message: Confirmation message
    ### delete_task
        message: Confirmation message
        task_id: ID of the deleted task
    ### update_task
        message: Message indicating the result of the update
        task_id: ID of the updated task
    ### list_users
        raw_data: Complete response from Microsoft Graph API
        total_count: Total number of users returned
        user_emails: List of user email addresses
        user_ids: List of user IDs
        user_names: List of user display names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Teams>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_channel": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team where you want to create the channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "value": "",
                    "label": "Channel Name",
                    "placeholder": "General",
                    "helper_text": "Name of the channel to create",
                },
                {
                    "field": "channel_description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Channel description",
                    "helper_text": "Optional description for the channel",
                },
                {
                    "field": "channel_type",
                    "type": "string",
                    "value": "standard",
                    "label": "Channel Type",
                    "helper_text": "Type of channel (standard or private)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Standard", "value": "standard"},
                            {"label": "Private", "value": "private"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the created channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the created channel",
                },
                {
                    "field": "channel_description",
                    "type": "string",
                    "helper_text": "Description of the created channel",
                },
                {
                    "field": "channel_web_url",
                    "type": "string",
                    "helper_text": "Web URL of the created channel",
                },
                {
                    "field": "channel_email",
                    "type": "string",
                    "helper_text": "Email address of the created channel",
                },
                {
                    "field": "channel_type",
                    "type": "string",
                    "helper_text": "Type of the created channel",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "create_channel",
            "task_name": "tasks.teams.create_channel",
            "description": "Create a new channel in a Microsoft Teams team",
            "label": "Create Channel",
            "variant": "common_integration_nodes",
            "required": ["team_id", "channel_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "channel_name",
                "channel_description",
                "channel_type",
            ],
        },
        "delete_channel": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team containing the channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "helper_text": "Select the channel to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Confirmation message",
                }
            ],
            "name": "delete_channel",
            "task_name": "tasks.teams.delete_channel",
            "description": "Delete a channel from a Microsoft Teams team",
            "label": "Delete Channel",
            "variant": "common_integration_nodes",
            "required": ["team_id", "channel_id"],
            "ui_sort_order": ["integration", "action", "team_id", "channel_id"],
        },
        "get_channel": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team containing the channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "helper_text": "Select the channel to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel",
                },
                {
                    "field": "channel_description",
                    "type": "string",
                    "helper_text": "Description of the channel",
                },
                {
                    "field": "channel_web_url",
                    "type": "string",
                    "helper_text": "Web URL of the channel",
                },
                {
                    "field": "channel_email",
                    "type": "string",
                    "helper_text": "Email address of the channel",
                },
                {
                    "field": "channel_type",
                    "type": "string",
                    "helper_text": "Type of the channel",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "get_channel",
            "task_name": "tasks.teams.get_channel",
            "description": "Get details of a specific channel in a Microsoft Teams team",
            "label": "Get Channel",
            "variant": "common_integration_nodes",
            "required": ["team_id", "channel_id"],
            "ui_sort_order": ["integration", "action", "team_id", "channel_id"],
        },
        "list_channels": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team to list channels from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_type",
                    "type": "string",
                    "value": "",
                    "label": "Channel Type",
                    "helper_text": "Filter by channel type",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All Types", "value": "all"},
                            {"label": "Standard", "value": "standard"},
                            {"label": "Private", "value": "private"},
                            {"label": "Shared", "value": "shared"},
                        ],
                    },
                },
                {
                    "field": "select_fields",
                    "type": "string",
                    "value": "",
                    "label": "Select Fields",
                    "helper_text": "Comma-separated list of fields to return. Leave empty for all fields",
                    "placeholder": "id,displayName,description",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of channels found",
                },
                {
                    "field": "channel_names",
                    "type": "vec<string>",
                    "helper_text": "List of channel names",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "list_channels",
            "task_name": "tasks.teams.list_channels",
            "description": "Get multiple channels",
            "label": "List Channels",
            "variant": "common_integration_nodes",
            "required": ["team_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "channel_type",
                "select_fields",
            ],
        },
        "update_channel": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team containing the channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "helper_text": "Select the channel to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "value": "",
                    "label": "New Channel Name",
                    "placeholder": "Updated channel name",
                    "helper_text": "New name for the channel",
                },
                {
                    "field": "channel_description",
                    "type": "string",
                    "value": "",
                    "label": "New Description",
                    "placeholder": "Updated description",
                    "helper_text": "New description for the channel",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the updated channel",
                }
            ],
            "name": "update_channel",
            "task_name": "tasks.teams.update_channel",
            "description": "Update a channel in a Microsoft Teams team",
            "label": "Update Channel",
            "variant": "common_integration_nodes",
            "required": ["team_id", "channel_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "channel_id",
                "channel_name",
                "channel_description",
            ],
        },
        "send_message": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team containing the channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "helper_text": "Select the channel to post message to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "value": "",
                    "label": "Message",
                    "placeholder": "Hello World!",
                    "helper_text": "The message content to post",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "text",
                    "label": "Content Type",
                    "helper_text": "Type of message content",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                    },
                },
                {
                    "field": "reply_to_message_id",
                    "type": "string",
                    "value": "",
                    "label": "Reply To Message ID",
                    "placeholder": "Optional reply message ID",
                    "helper_text": "ID of message to reply to (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the created message",
                },
                {
                    "field": "message_type",
                    "type": "string",
                    "helper_text": "Type of the message",
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "helper_text": "Content of the message",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "Content type of the message",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the message",
                },
                {
                    "field": "from_user",
                    "type": "string",
                    "helper_text": "Display name of the message sender",
                },
                {
                    "field": "from_user_email",
                    "type": "string",
                    "helper_text": "Email of the message sender",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "send_message",
            "task_name": "tasks.teams.create_channel_message",
            "description": "Post a new message to a specific Teams channel",
            "label": "Create Channel Message",
            "variant": "common_integration_nodes",
            "required": ["team_id", "channel_id", "message_content"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "channel_id",
                "message_content",
                "content_type",
                "reply_to_message_id",
            ],
        },
        "list_channel_messages": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "helper_text": "Select the team containing the channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "helper_text": "Select the channel to list messages from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of messages to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of messages found",
                },
                {
                    "field": "message_ids",
                    "type": "vec<string>",
                    "helper_text": "List of message IDs",
                },
                {
                    "field": "message_summaries",
                    "type": "vec<string>",
                    "helper_text": "List of message summaries",
                },
                {
                    "field": "has_next_page",
                    "type": "bool",
                    "helper_text": "Whether there are more messages available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "list_channel_messages",
            "task_name": "tasks.teams.list_channel_messages",
            "description": "Get multiple messages from a specific Teams channel",
            "label": "List Channel Messages",
            "variant": "common_integration_nodes",
            "required": ["team_id", "channel_id", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "channel_id",
                "limit",
            ],
        },
        "create_chat_message": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "19:meeting_...",
                    "helper_text": "Select the chat to send message to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=chat&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "value": "",
                    "label": "Message",
                    "placeholder": "Hello World!",
                    "helper_text": "The message content to send",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "text",
                    "label": "Content Type",
                    "helper_text": "Type of message content",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the created message",
                },
                {
                    "field": "message_type",
                    "type": "string",
                    "helper_text": "Type of the message",
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "helper_text": "Content of the message",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "Content type of the message",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the message",
                },
                {
                    "field": "from_user",
                    "type": "string",
                    "helper_text": "Display name of the message sender",
                },
                {
                    "field": "from_user_email",
                    "type": "string",
                    "helper_text": "Email of the message sender",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "create_chat_message",
            "task_name": "tasks.teams.create_chat_message",
            "description": "Send a new message to a specific Teams chat",
            "label": "Create Chat Message",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "message_content"],
            "ui_sort_order": [
                "integration",
                "action",
                "chat_id",
                "message_content",
                "content_type",
            ],
        },
        "get_chat_message": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "19:meeting_...",
                    "helper_text": "Select the chat containing the message",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=chat&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the message to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the message",
                },
                {
                    "field": "message_type",
                    "type": "string",
                    "helper_text": "Type of the message",
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "helper_text": "Content of the message",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "Content type of the message",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "last_modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the message",
                },
                {
                    "field": "from_user",
                    "type": "string",
                    "helper_text": "Display name of the message sender",
                },
                {
                    "field": "from_user_email",
                    "type": "string",
                    "helper_text": "Email of the message sender",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "get_chat_message",
            "task_name": "tasks.teams.get_chat_message",
            "description": "Get details of a specific message in a Teams chat",
            "label": "Get Chat Message",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "message_id"],
            "ui_sort_order": ["integration", "action", "chat_id", "message_id"],
        },
        "list_chat_messages": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "19:meeting_...",
                    "helper_text": "Select the chat to list messages from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=chat&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of messages to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of messages found",
                },
                {
                    "field": "message_ids",
                    "type": "vec<string>",
                    "helper_text": "List of message IDs",
                },
                {
                    "field": "message_summaries",
                    "type": "vec<string>",
                    "helper_text": "List of message summaries",
                },
                {
                    "field": "has_next_page",
                    "type": "bool",
                    "helper_text": "Whether there are more messages available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "list_chat_messages",
            "task_name": "tasks.teams.list_chat_messages",
            "description": "Get multiple messages from a specific Teams chat",
            "label": "List Chat Messages",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "limit"],
            "ui_sort_order": ["integration", "action", "chat_id", "limit"],
        },
        "create_task": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team ID",
                    "placeholder": "team123",
                    "helper_text": "Select the team to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "value": "",
                    "label": "Plan ID",
                    "placeholder": "plan123",
                    "helper_text": "Select the planner plan to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=plan&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_id",
                    "type": "string",
                    "value": "",
                    "label": "Bucket ID",
                    "placeholder": "bucket123",
                    "helper_text": "Select the bucket to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&plan_id={inputs.plan_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_title",
                    "type": "string",
                    "value": "",
                    "label": "Task Title",
                    "placeholder": "Complete project",
                    "helper_text": "Title of the task",
                },
                {
                    "field": "due_date",
                    "type": "string",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date for the task (YYYY-MM-DD format)",
                },
                {
                    "field": "percent_complete",
                    "type": "int32",
                    "value": 0,
                    "label": "Percent Complete",
                    "helper_text": "Completion percentage (0-100)",
                },
                {
                    "field": "assigned_to",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "user123",
                    "helper_text": "Select a user to assign the task to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the created task",
                },
                {
                    "field": "task_title",
                    "type": "string",
                    "helper_text": "Title of the created task",
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "helper_text": "Plan ID of the task",
                },
                {
                    "field": "bucket_id",
                    "type": "string",
                    "helper_text": "Bucket ID of the task",
                },
                {
                    "field": "percent_complete",
                    "type": "int32",
                    "helper_text": "Completion percentage",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the task",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "has_description",
                    "type": "bool",
                    "helper_text": "Whether the task has a description",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "create_task",
            "task_name": "tasks.teams.create_task",
            "description": "Create a new task in Microsoft Planner",
            "label": "Create Task",
            "variant": "common_integration_nodes",
            "required": ["team_id", "plan_id", "bucket_id", "task_title"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "plan_id",
                "bucket_id",
                "task_title",
                "due_date",
                "percent_complete",
                "assigned_to",
            ],
        },
        "delete_task": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team ID",
                    "placeholder": "team123",
                    "helper_text": "Select the team to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "value": "",
                    "label": "Plan ID",
                    "placeholder": "plan123",
                    "helper_text": "Select the planner plan to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=plan&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_id",
                    "type": "string",
                    "value": "",
                    "label": "Bucket ID",
                    "placeholder": "bucket123",
                    "helper_text": "Select the bucket to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&plan_id={inputs.plan_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "task123",
                    "helper_text": "Select the task to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&plan_id={inputs.plan_id}&bucket_id={inputs.bucket_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the deleted task",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Confirmation message",
                },
            ],
            "name": "delete_task",
            "task_name": "tasks.teams.delete_task",
            "description": "Delete a task from Microsoft Planner",
            "label": "Delete Task",
            "variant": "common_integration_nodes",
            "required": ["team_id", "plan_id", "bucket_id", "task_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "plan_id",
                "bucket_id",
                "task_id",
            ],
        },
        "get_task": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team ID",
                    "placeholder": "team123",
                    "helper_text": "Select the team to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "value": "",
                    "label": "Plan ID",
                    "placeholder": "plan123",
                    "helper_text": "Select the planner plan to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=plan&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_id",
                    "type": "string",
                    "value": "",
                    "label": "Bucket ID",
                    "placeholder": "bucket123",
                    "helper_text": "Select the bucket to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&plan_id={inputs.plan_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "task123",
                    "helper_text": "Select the task to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&plan_id={inputs.plan_id}&bucket_id={inputs.bucket_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {
                    "field": "task_title",
                    "type": "string",
                    "helper_text": "Title of the task",
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "helper_text": "Plan ID of the task",
                },
                {
                    "field": "bucket_id",
                    "type": "string",
                    "helper_text": "Bucket ID of the task",
                },
                {
                    "field": "percent_complete",
                    "type": "int32",
                    "helper_text": "Completion percentage",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the task",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "completed_at",
                    "type": "timestamp",
                    "helper_text": "Completion timestamp",
                },
                {
                    "field": "has_description",
                    "type": "bool",
                    "helper_text": "Whether the task has a description",
                },
                {
                    "field": "conversation_thread_id",
                    "type": "string",
                    "helper_text": "Conversation thread ID",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "get_task",
            "task_name": "tasks.teams.get_task",
            "description": "Get details of a specific task in Microsoft Planner",
            "label": "Get Task",
            "variant": "common_integration_nodes",
            "required": ["team_id", "plan_id", "bucket_id", "task_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "plan_id",
                "bucket_id",
                "task_id",
            ],
        },
        "list_tasks": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team ID",
                    "placeholder": "team123",
                    "helper_text": "Select the team to list tasks from (optional - leave blank for user's tasks)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "value": "",
                    "label": "Plan ID",
                    "placeholder": "plan123",
                    "helper_text": "Select the plan to list tasks from (optional - leave blank for user's tasks)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=plan&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of tasks to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of tasks found",
                },
                {
                    "field": "task_ids",
                    "type": "vec<string>",
                    "helper_text": "List of task IDs",
                },
                {
                    "field": "task_titles",
                    "type": "vec<string>",
                    "helper_text": "List of task titles",
                },
                {
                    "field": "has_next_page",
                    "type": "bool",
                    "helper_text": "Whether there are more tasks available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Teams API",
                },
            ],
            "name": "list_tasks",
            "task_name": "tasks.teams.list_tasks",
            "description": "List tasks from Microsoft Planner",
            "label": "List Tasks",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "ui_sort_order": ["integration", "action", "team_id", "plan_id", "limit"],
        },
        "update_task": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Team ID",
                    "placeholder": "team123",
                    "helper_text": "Select the team to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "plan_id",
                    "type": "string",
                    "value": "",
                    "label": "Plan ID",
                    "placeholder": "plan123",
                    "helper_text": "Select the planner plan to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=plan&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_id",
                    "type": "string",
                    "value": "",
                    "label": "Bucket ID",
                    "placeholder": "bucket123",
                    "helper_text": "Select the bucket to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&plan_id={inputs.plan_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "task123",
                    "helper_text": "Select the task to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&plan_id={inputs.plan_id}&bucket_id={inputs.bucket_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_title",
                    "type": "string",
                    "value": "",
                    "label": "New Task Title",
                    "placeholder": "Updated task title",
                    "helper_text": "New title for the task",
                },
                {
                    "field": "due_date",
                    "type": "string",
                    "value": "",
                    "label": "New Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "New due date for the task (YYYY-MM-DD format)",
                },
                {
                    "field": "percent_complete",
                    "type": "int32",
                    "value": 0,
                    "label": "Percent Complete",
                    "helper_text": "New completion percentage (0-100)",
                },
                {
                    "field": "new_bucket_id",
                    "type": "string",
                    "value": "",
                    "label": "New Bucket ID",
                    "placeholder": "bucket123",
                    "helper_text": "New bucket ID to move task to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&plan_id={inputs.plan_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assigned_to",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "user123",
                    "helper_text": "Select a user to assign the task to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the updated task",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message indicating the result of the update",
                },
            ],
            "name": "update_task",
            "task_name": "tasks.teams.update_task",
            "description": "Update a task in Microsoft Planner",
            "label": "Update Task",
            "variant": "common_integration_nodes",
            "required": ["team_id", "plan_id", "bucket_id", "task_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "plan_id",
                "bucket_id",
                "task_id",
                "task_title",
                "due_date",
                "percent_complete",
                "new_bucket_id",
                "assigned_to",
            ],
        },
        "get_user": {
            "inputs": [
                {
                    "field": "user_identifier",
                    "type": "string",
                    "value": "",
                    "label": "Select User",
                    "placeholder": "Select user",
                    "helper_text": "Choose a user to fetch their profile",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "The unique ID of the user",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The user's display name",
                },
                {
                    "field": "mail",
                    "type": "string",
                    "helper_text": "The user's email address",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "helper_text": "The user's job title",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "helper_text": "The user's mobile phone number",
                },
                {
                    "field": "office_location",
                    "type": "string",
                    "helper_text": "The user's office location",
                },
                {
                    "field": "user_principal_name",
                    "type": "string",
                    "helper_text": "The primary sign-in name for the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.teams.get_user",
            "description": "Read details of a user",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "required": ["user_identifier"],
            "inputs_sort_order": ["integration", "action", "user_identifier"],
        },
        "list_users": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of users to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user display names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user email addresses",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of users returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "list_users",
            "task_name": "tasks.teams.list_users",
            "description": "Get multiple users",
            "label": "List Users",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": ["integration", "action", "limit"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        assigned_to: str = "",
        bucket_id: str = "",
        channel_description: str = "",
        channel_id: str = "",
        channel_name: str = "",
        channel_type: str = "standard",
        chat_id: str = "",
        content_type: str = "text",
        due_date: str = "",
        limit: int = 10,
        message_content: str = "",
        message_id: str = "",
        new_bucket_id: str = "",
        percent_complete: int = 0,
        plan_id: str = "",
        reply_to_message_id: str = "",
        select_fields: str = "",
        task_id: str = "",
        task_title: str = "",
        team_id: str = "",
        user_identifier: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_teams",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if team_id is not None:
            self.inputs["team_id"] = team_id
        if channel_name is not None:
            self.inputs["channel_name"] = channel_name
        if channel_description is not None:
            self.inputs["channel_description"] = channel_description
        if channel_type is not None:
            self.inputs["channel_type"] = channel_type
        if channel_id is not None:
            self.inputs["channel_id"] = channel_id
        if select_fields is not None:
            self.inputs["select_fields"] = select_fields
        if message_content is not None:
            self.inputs["message_content"] = message_content
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if reply_to_message_id is not None:
            self.inputs["reply_to_message_id"] = reply_to_message_id
        if limit is not None:
            self.inputs["limit"] = limit
        if chat_id is not None:
            self.inputs["chat_id"] = chat_id
        if message_id is not None:
            self.inputs["message_id"] = message_id
        if plan_id is not None:
            self.inputs["plan_id"] = plan_id
        if bucket_id is not None:
            self.inputs["bucket_id"] = bucket_id
        if task_title is not None:
            self.inputs["task_title"] = task_title
        if due_date is not None:
            self.inputs["due_date"] = due_date
        if percent_complete is not None:
            self.inputs["percent_complete"] = percent_complete
        if assigned_to is not None:
            self.inputs["assigned_to"] = assigned_to
        if task_id is not None:
            self.inputs["task_id"] = task_id
        if new_bucket_id is not None:
            self.inputs["new_bucket_id"] = new_bucket_id
        if user_identifier is not None:
            self.inputs["user_identifier"] = user_identifier
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationTeamsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
