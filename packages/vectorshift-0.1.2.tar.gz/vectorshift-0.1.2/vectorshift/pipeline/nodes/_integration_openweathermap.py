"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_openweathermap")
class IntegrationOpenweathermapNode(Node):
    """
    Open Weather Map

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your OpenWeatherMap account
    ### When action = 'get_current_weather' and location_type = 'city_id'
        city_id: OpenWeatherMap city ID
    ### When action = 'get_5_day_forecast' and location_type = 'city_id'
        city_id: OpenWeatherMap city ID
    ### When action = 'get_current_weather' and location_type = 'city_name'
        city_name: City name, optionally with country code (e.g., 'London,UK')
    ### When action = 'get_5_day_forecast' and location_type = 'city_name'
        city_name: City name, optionally with country code (e.g., 'London,UK')
    ### When action = 'get_5_day_forecast'
        count: Number of forecast entries to return (max 40, each represents 3 hours)
        language: Language code for weather descriptions (e.g., 'en', 'es', 'fr')
        location_type: How to specify the location
        units: Temperature units
    ### When action = 'get_current_weather'
        language: Language code for weather descriptions (e.g., 'en', 'es', 'fr')
        location_type: How to specify the location
        units: Temperature units
    ### When action = 'get_current_weather' and location_type = 'coordinates'
        latitude: Latitude coordinate
        longitude: Longitude coordinate
    ### When action = 'get_5_day_forecast' and location_type = 'coordinates'
        latitude: Latitude coordinate
        longitude: Longitude coordinate
    ### When action = 'get_current_weather' and location_type = 'zip_code'
        zip_code: ZIP code with country code (e.g., '10001,US')
    ### When action = 'get_5_day_forecast' and location_type = 'zip_code'
        zip_code: ZIP code with country code (e.g., '10001,US')

    ## Outputs
    ### When action = 'get_current_weather'
        city_name: City name
        cloudiness: Cloudiness percentage
        country: Country code
        feels_like: Feels like temperature
        humidity: Humidity percentage
        pressure: Atmospheric pressure (hPa)
        raw_data: Raw API response data
        sunrise_time: Sunrise time (ISO format)
        sunset_time: Sunset time (ISO format)
        temp_max: Maximum temperature
        temp_min: Minimum temperature
        temperature: Current temperature
        timezone: Timezone offset in seconds
        visibility: Visibility in meters
        weather_description: Weather description
        weather_icon: Weather icon code
        weather_main: Main weather condition
        wind_direction: Wind direction in degrees
        wind_speed: Wind speed
    ### When action = 'get_5_day_forecast'
        city_name: City name
        cloudiness: Array of cloudiness percentages
        country: Country code
        datetimes: Array of forecast datetime strings
        feels_like: Array of feels-like temperatures
        forecast_count: Number of forecast entries
        humidity: Array of humidity percentages
        pop: Array of precipitation probabilities (0-1)
        pressure: Array of atmospheric pressure values (hPa)
        rain_3h: Array of rain amounts in 3-hour periods (mm)
        raw_data: Raw API response data
        snow_3h: Array of snow amounts in 3-hour periods (mm)
        sunrise_time: Sunrise time (ISO format)
        sunset_time: Sunset time (ISO format)
        temp_max: Array of maximum temperatures
        temp_min: Array of minimum temperatures
        temperatures: Array of temperatures for each forecast period
        timezone: Timezone offset in seconds
        visibility: Array of visibility values in meters
        weather_description: Array of weather descriptions
        weather_main: Array of main weather conditions
        wind_direction: Array of wind directions in degrees
        wind_speed: Array of wind speeds
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your OpenWeatherMap account",
            "value": None,
            "type": "integration<Openweathermap>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_current_weather**(*)": {
            "inputs": [
                {
                    "field": "location_type",
                    "type": "string",
                    "value": "city_name",
                    "label": "Location Type",
                    "helper_text": "How to specify the location",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "City Name", "value": "city_name"},
                            {"label": "City ID", "value": "city_id"},
                            {"label": "Coordinates", "value": "coordinates"},
                            {"label": "ZIP Code", "value": "zip_code"},
                        ],
                    },
                },
                {
                    "field": "units",
                    "type": "string",
                    "value": "metric",
                    "label": "Units",
                    "helper_text": "Temperature units",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Metric (Celsius)", "value": "metric"},
                            {"label": "Imperial (Fahrenheit)", "value": "imperial"},
                            {"label": "Standard (Kelvin)", "value": "standard"},
                        ],
                    },
                },
                {
                    "field": "language",
                    "type": "string",
                    "value": "en",
                    "label": "Language",
                    "placeholder": "en",
                    "helper_text": "Language code for weather descriptions (e.g., 'en', 'es', 'fr')",
                },
            ],
            "outputs": [
                {
                    "field": "temperature",
                    "type": "float",
                    "helper_text": "Current temperature",
                },
                {
                    "field": "feels_like",
                    "type": "float",
                    "helper_text": "Feels like temperature",
                },
                {
                    "field": "temp_min",
                    "type": "float",
                    "helper_text": "Minimum temperature",
                },
                {
                    "field": "temp_max",
                    "type": "float",
                    "helper_text": "Maximum temperature",
                },
                {
                    "field": "pressure",
                    "type": "int32",
                    "helper_text": "Atmospheric pressure (hPa)",
                },
                {
                    "field": "humidity",
                    "type": "int32",
                    "helper_text": "Humidity percentage",
                },
                {"field": "wind_speed", "type": "float", "helper_text": "Wind speed"},
                {
                    "field": "wind_direction",
                    "type": "int32",
                    "helper_text": "Wind direction in degrees",
                },
                {
                    "field": "cloudiness",
                    "type": "int32",
                    "helper_text": "Cloudiness percentage",
                },
                {
                    "field": "visibility",
                    "type": "int32",
                    "helper_text": "Visibility in meters",
                },
                {
                    "field": "weather_main",
                    "type": "string",
                    "helper_text": "Main weather condition",
                },
                {
                    "field": "weather_description",
                    "type": "string",
                    "helper_text": "Weather description",
                },
                {
                    "field": "weather_icon",
                    "type": "string",
                    "helper_text": "Weather icon code",
                },
                {"field": "city_name", "type": "string", "helper_text": "City name"},
                {"field": "country", "type": "string", "helper_text": "Country code"},
                {
                    "field": "sunrise_time",
                    "type": "string",
                    "helper_text": "Sunrise time (ISO format)",
                },
                {
                    "field": "sunset_time",
                    "type": "string",
                    "helper_text": "Sunset time (ISO format)",
                },
                {
                    "field": "timezone",
                    "type": "int32",
                    "helper_text": "Timezone offset in seconds",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_current_weather",
            "task_name": "tasks.openweathermap.get_current_weather",
            "description": "Get current weather data for a location",
            "label": "Get Current Weather",
            "variant": "common_integration_nodes",
            "required": ["location_type", "units"],
            "input_sort_order": [
                "integration",
                "action",
                "location_type",
                "city_name",
                "city_id",
                "latitude",
                "longitude",
                "zip_code",
                "units",
                "language",
            ],
        },
        "get_current_weather**city_name": {
            "inputs": [
                {
                    "field": "city_name",
                    "type": "string",
                    "value": "",
                    "label": "City Name",
                    "placeholder": "London,UK",
                    "helper_text": "City name, optionally with country code (e.g., 'London,UK')",
                }
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_current_weather**city_id": {
            "inputs": [
                {
                    "field": "city_id",
                    "type": "string",
                    "value": "",
                    "label": "City ID",
                    "placeholder": "2172797",
                    "helper_text": "OpenWeatherMap city ID",
                }
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_current_weather**coordinates": {
            "inputs": [
                {
                    "field": "latitude",
                    "type": "string",
                    "value": "",
                    "label": "Latitude",
                    "placeholder": "51.5074",
                    "helper_text": "Latitude coordinate",
                },
                {
                    "field": "longitude",
                    "type": "string",
                    "value": "",
                    "label": "Longitude",
                    "placeholder": "-0.1278",
                    "helper_text": "Longitude coordinate",
                },
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_current_weather**zip_code": {
            "inputs": [
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "ZIP Code",
                    "placeholder": "10001,US",
                    "helper_text": "ZIP code with country code (e.g., '10001,US')",
                }
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_5_day_forecast**(*)": {
            "inputs": [
                {
                    "field": "location_type",
                    "type": "string",
                    "value": "city_name",
                    "label": "Location Type",
                    "helper_text": "How to specify the location",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "City Name", "value": "city_name"},
                            {"label": "City ID", "value": "city_id"},
                            {"label": "Coordinates", "value": "coordinates"},
                            {"label": "ZIP Code", "value": "zip_code"},
                        ],
                    },
                },
                {
                    "field": "units",
                    "type": "string",
                    "value": "metric",
                    "label": "Units",
                    "helper_text": "Temperature units",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Metric (Celsius)", "value": "metric"},
                            {"label": "Imperial (Fahrenheit)", "value": "imperial"},
                            {"label": "Standard (Kelvin)", "value": "standard"},
                        ],
                    },
                },
                {
                    "field": "language",
                    "type": "string",
                    "value": "en",
                    "label": "Language",
                    "placeholder": "en",
                    "helper_text": "Language code for weather descriptions (e.g., 'en', 'es', 'fr')",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "value": 10,
                    "label": "Forecast Count",
                    "placeholder": "10",
                    "helper_text": "Number of forecast entries to return (max 40, each represents 3 hours)",
                },
            ],
            "outputs": [
                {"field": "city_name", "type": "string", "helper_text": "City name"},
                {"field": "country", "type": "string", "helper_text": "Country code"},
                {
                    "field": "timezone",
                    "type": "int32",
                    "helper_text": "Timezone offset in seconds",
                },
                {
                    "field": "sunrise_time",
                    "type": "string",
                    "helper_text": "Sunrise time (ISO format)",
                },
                {
                    "field": "sunset_time",
                    "type": "string",
                    "helper_text": "Sunset time (ISO format)",
                },
                {
                    "field": "forecast_count",
                    "type": "int32",
                    "helper_text": "Number of forecast entries",
                },
                {
                    "field": "temperatures",
                    "type": "vec<float>",
                    "helper_text": "Array of temperatures for each forecast period",
                },
                {
                    "field": "feels_like",
                    "type": "vec<float>",
                    "helper_text": "Array of feels-like temperatures",
                },
                {
                    "field": "temp_min",
                    "type": "vec<float>",
                    "helper_text": "Array of minimum temperatures",
                },
                {
                    "field": "temp_max",
                    "type": "vec<float>",
                    "helper_text": "Array of maximum temperatures",
                },
                {
                    "field": "pressure",
                    "type": "vec<int32>",
                    "helper_text": "Array of atmospheric pressure values (hPa)",
                },
                {
                    "field": "humidity",
                    "type": "vec<int32>",
                    "helper_text": "Array of humidity percentages",
                },
                {
                    "field": "wind_speed",
                    "type": "vec<float>",
                    "helper_text": "Array of wind speeds",
                },
                {
                    "field": "wind_direction",
                    "type": "vec<int32>",
                    "helper_text": "Array of wind directions in degrees",
                },
                {
                    "field": "cloudiness",
                    "type": "vec<int32>",
                    "helper_text": "Array of cloudiness percentages",
                },
                {
                    "field": "visibility",
                    "type": "vec<int32>",
                    "helper_text": "Array of visibility values in meters",
                },
                {
                    "field": "pop",
                    "type": "vec<float>",
                    "helper_text": "Array of precipitation probabilities (0-1)",
                },
                {
                    "field": "datetimes",
                    "type": "vec<string>",
                    "helper_text": "Array of forecast datetime strings",
                },
                {
                    "field": "weather_main",
                    "type": "vec<string>",
                    "helper_text": "Array of main weather conditions",
                },
                {
                    "field": "weather_description",
                    "type": "vec<string>",
                    "helper_text": "Array of weather descriptions",
                },
                {
                    "field": "rain_3h",
                    "type": "vec<float>",
                    "helper_text": "Array of rain amounts in 3-hour periods (mm)",
                },
                {
                    "field": "snow_3h",
                    "type": "vec<float>",
                    "helper_text": "Array of snow amounts in 3-hour periods (mm)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_5_day_forecast",
            "task_name": "tasks.openweathermap.get_5_day_forecast",
            "description": "Get 5-day weather forecast with 3-hour intervals",
            "label": "Get 5 Day Forecast",
            "variant": "common_integration_nodes",
            "required": ["location_type", "units"],
            "input_sort_order": [
                "integration",
                "action",
                "location_type",
                "city_name",
                "city_id",
                "latitude",
                "longitude",
                "zip_code",
                "units",
                "language",
                "count",
            ],
        },
        "get_5_day_forecast**city_name": {
            "inputs": [
                {
                    "field": "city_name",
                    "type": "string",
                    "value": "",
                    "label": "City Name",
                    "placeholder": "London,UK",
                    "helper_text": "City name, optionally with country code (e.g., 'London,UK')",
                }
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_5_day_forecast**city_id": {
            "inputs": [
                {
                    "field": "city_id",
                    "type": "string",
                    "value": "",
                    "label": "City ID",
                    "placeholder": "2172797",
                    "helper_text": "OpenWeatherMap city ID",
                }
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_5_day_forecast**coordinates": {
            "inputs": [
                {
                    "field": "latitude",
                    "type": "string",
                    "value": "",
                    "label": "Latitude",
                    "placeholder": "51.5074",
                    "helper_text": "Latitude coordinate",
                },
                {
                    "field": "longitude",
                    "type": "string",
                    "value": "",
                    "label": "Longitude",
                    "placeholder": "-0.1278",
                    "helper_text": "Longitude coordinate",
                },
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "get_5_day_forecast**zip_code": {
            "inputs": [
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "ZIP Code",
                    "placeholder": "10001,US",
                    "helper_text": "ZIP code with country code (e.g., '10001,US')",
                }
            ],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "location_type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        location_type: str = "city_name",
        city_id: str = "",
        city_name: str = "",
        count: int = 10,
        language: str = "en",
        latitude: str = "",
        longitude: str = "",
        units: str = "metric",
        zip_code: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["location_type"] = location_type

        super().__init__(
            node_type="integration_openweathermap",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if location_type is not None:
            self.inputs["location_type"] = location_type
        if units is not None:
            self.inputs["units"] = units
        if language is not None:
            self.inputs["language"] = language
        if city_name is not None:
            self.inputs["city_name"] = city_name
        if city_id is not None:
            self.inputs["city_id"] = city_id
        if latitude is not None:
            self.inputs["latitude"] = latitude
        if longitude is not None:
            self.inputs["longitude"] = longitude
        if zip_code is not None:
            self.inputs["zip_code"] = zip_code
        if count is not None:
            self.inputs["count"] = count
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationOpenweathermapNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
