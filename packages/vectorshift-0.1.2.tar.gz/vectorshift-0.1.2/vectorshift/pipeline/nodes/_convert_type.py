"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("convert_type")
class ConvertTypeNode(Node):
    """
    Convert value from source type to target type.

    ## Inputs
    ### Common Inputs
        source_type: The type of the value to convert.
        target_type: The type to convert the value to.
        value: The value to convert

    ## Outputs
    ### int32
        converted_value: The converted value in Integer type
    ### float
        converted_value: The converted value in Decimal type
    ### bool
        converted_value: The converted value in Boolean type
    ### timestamp
        converted_value: The converted value in Timestamp type
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "source_type",
            "helper_text": "The type of the value to convert.",
            "value": "string",
            "type": "string",
        },
        {
            "field": "target_type",
            "helper_text": "The type to convert the value to.",
            "value": "int32",
            "type": "string",
        },
        {
            "field": "value",
            "helper_text": "The value to convert",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "int32": {
            "inputs": [
                {
                    "field": "target_type",
                    "type": "string",
                    "value": "int32",
                    "helper_text": "The type to convert the value to.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Integer", "value": "int32"},
                            {"label": "Decimal", "value": "float"},
                            {"label": "Boolean", "value": "bool"},
                            {"label": "Timestamp", "value": "timestamp"},
                        ],
                    },
                    "label": "Target Type",
                }
            ],
            "outputs": [
                {
                    "field": "converted_value",
                    "type": "int32",
                    "helper_text": "The converted value in Integer type",
                }
            ],
        },
        "float": {
            "inputs": [
                {
                    "field": "target_type",
                    "type": "string",
                    "value": "float",
                    "helper_text": "The type to convert the value to.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Integer", "value": "int32"},
                            {"label": "Decimal", "value": "float"},
                            {"label": "Boolean", "value": "bool"},
                            {"label": "Timestamp", "value": "timestamp"},
                        ],
                    },
                    "label": "Target Type",
                }
            ],
            "outputs": [
                {
                    "field": "converted_value",
                    "type": "float",
                    "helper_text": "The converted value in Decimal type",
                }
            ],
        },
        "bool": {
            "inputs": [
                {
                    "field": "target_type",
                    "type": "string",
                    "value": "bool",
                    "helper_text": "The type to convert the value to.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Integer", "value": "int32"},
                            {"label": "Decimal", "value": "float"},
                            {"label": "Boolean", "value": "bool"},
                            {"label": "Timestamp", "value": "timestamp"},
                        ],
                    },
                    "label": "Target Type",
                }
            ],
            "outputs": [
                {
                    "field": "converted_value",
                    "type": "bool",
                    "helper_text": "The converted value in Boolean type",
                }
            ],
        },
        "timestamp": {
            "inputs": [
                {
                    "field": "target_type",
                    "type": "string",
                    "value": "timestamp",
                    "helper_text": "The type to convert the value to.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Integer", "value": "int32"},
                            {"label": "Decimal", "value": "float"},
                            {"label": "Boolean", "value": "bool"},
                            {"label": "Timestamp", "value": "timestamp"},
                        ],
                    },
                    "label": "Target Type",
                }
            ],
            "outputs": [
                {
                    "field": "converted_value",
                    "type": "timestamp",
                    "helper_text": "The converted value in Timestamp type",
                }
            ],
            "banner_text": "Timestamp format: YYYY-MM-DDTHH:MM:SS",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["target_type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["value", "source_type", "target_type"]

    def __init__(
        self,
        target_type: str = "int32",
        source_type: str = "string",
        value: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["target_type"] = target_type

        super().__init__(
            node_type="convert_type",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if value is not None:
            self.inputs["value"] = value
        if source_type is not None:
            self.inputs["source_type"] = source_type
        if target_type is not None:
            self.inputs["target_type"] = target_type
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ConvertTypeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
