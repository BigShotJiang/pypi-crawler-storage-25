"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("filter_list")
class FilterListNode(Node):
    """
    Filter items in a list given a specific condition. Example, Filter (Red, White, Blue) by (100, 95, 80)>90 is (Red, White)

    ## Inputs
    ### Common Inputs
        condition_type: The type of condition to apply
        condition_value: The value to compare the list items against
        filter_mode: Choose whether to filter a single list or filter by another list
        output_blank_value: If true, output a blank value for values that do not meet the filter condition. If false, nothing will be outputted
        type: The type of the list
    ### When filter_mode = 'another' and type = '<T>'
        filter_by: The items to filter the list by
    ### When type = '<T>'
        list_to_filter: The list to filter

    ## Outputs
    ### When type = '<T>'
        output: The filtered list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "condition_type",
            "helper_text": "The type of condition to apply",
            "value": "Equal",
            "type": "string",
        },
        {
            "field": "condition_value",
            "helper_text": "The value to compare the list items against",
            "value": "",
            "type": "string",
        },
        {
            "field": "filter_mode",
            "helper_text": "Choose whether to filter a single list or filter by another list",
            "value": "single",
            "type": "string",
        },
        {
            "field": "output_blank_value",
            "helper_text": "If true, output a blank value for values that do not meet the filter condition. If false, nothing will be outputted",
            "value": False,
            "type": "bool",
        },
        {
            "field": "type",
            "helper_text": "The type of the list",
            "value": "string",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**<T>": {
            "inputs": [
                {
                    "field": "list_to_filter",
                    "label": "List to Filter",
                    "type": "vec<<T>>",
                    "value": "",
                    "helper_text": "The list to filter",
                }
            ],
            "outputs": [
                {
                    "field": "output",
                    "label": "Output",
                    "type": "vec<<T>>",
                    "helper_text": "The filtered list",
                }
            ],
        },
        "another**<T>": {
            "inputs": [
                {
                    "field": "filter_by",
                    "label": "Filter By",
                    "type": "vec<<T>>",
                    "value": "",
                    "helper_text": "The items to filter the list by",
                }
            ],
            "outputs": [],
            "required": ["filter_by"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["filter_mode", "type"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "condition_value", "label": "Condition Value"},
        {"field": "filter_by", "label": "Filter By"},
        {"field": "list_to_filter", "label": "List to Filter"},
    ]

    _REQUIRED_FIELDS = ["list_to_filter", "condition_type", "output_blank_value"]

    def __init__(
        self,
        filter_mode: str = "single",
        type: str = "string",
        condition_type: str = "Equal",
        condition_value: str = "",
        filter_by: List[Any] = [],
        list_to_filter: List[Any] = [],
        output_blank_value: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["filter_mode"] = filter_mode
        params["type"] = type

        super().__init__(
            node_type="filter_list",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if filter_mode is not None:
            self.inputs["filter_mode"] = filter_mode
        if type is not None:
            self.inputs["type"] = type
        if condition_type is not None:
            self.inputs["condition_type"] = condition_type
        if condition_value is not None:
            self.inputs["condition_value"] = condition_value
        if output_blank_value is not None:
            self.inputs["output_blank_value"] = output_blank_value
        if list_to_filter is not None:
            self.inputs["list_to_filter"] = list_to_filter
        if filter_by is not None:
            self.inputs["filter_by"] = filter_by
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "FilterListNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
