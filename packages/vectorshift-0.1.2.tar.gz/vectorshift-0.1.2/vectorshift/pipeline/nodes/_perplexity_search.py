"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("perplexity_search")
class PerplexitySearchNode(Node):
    """
    Query the Perplexity search API

    ## Inputs
    ### Common Inputs
        query: The search query
        last_updated_after_filter: Filter results last updated after this date
        last_updated_before_filter: Filter results last updated before this date
        max_results: The maximum number of results to return
        max_tokens_per_page: Maximum tokens per page
        query_list: Additional queries to search for
        return_images: Whether to return images in results
        return_snippets: Whether to return snippets in results
        search_after_date_filter: Filter results published after this date
        search_before_date_filter: Filter results published before this date
        search_domain_filter: Filter results to specific domains
        search_mode: The search mode to use
        search_recency_filter: Filter results by recency
        user_location_latitude: The latitude of the user's location
        user_location_longitude: The longitude of the user's location
        user_location_name: The name of the user's location
        user_location_radius_km: The radius in kilometers for location-based search

    ## Outputs
    ### Common Outputs
        formatted_text: Perplexity search results formatted for LLM consumption
        output: The search results from Perplexity
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "The search query",
            "value": "",
            "type": "string",
        },
        {
            "field": "last_updated_after_filter",
            "helper_text": "Filter results last updated after this date",
            "value": "",
            "type": "string",
        },
        {
            "field": "last_updated_before_filter",
            "helper_text": "Filter results last updated before this date",
            "value": "",
            "type": "string",
        },
        {
            "field": "max_results",
            "helper_text": "The maximum number of results to return",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "max_tokens_per_page",
            "helper_text": "Maximum tokens per page",
            "value": 1000,
            "type": "int32",
        },
        {
            "field": "query_list",
            "helper_text": "Additional queries to search for",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "return_images",
            "helper_text": "Whether to return images in results",
            "value": False,
            "type": "bool",
        },
        {
            "field": "return_snippets",
            "helper_text": "Whether to return snippets in results",
            "value": True,
            "type": "bool",
        },
        {
            "field": "search_after_date_filter",
            "helper_text": "Filter results published after this date",
            "value": "",
            "type": "string",
        },
        {
            "field": "search_before_date_filter",
            "helper_text": "Filter results published before this date",
            "value": "",
            "type": "string",
        },
        {
            "field": "search_domain_filter",
            "helper_text": "Filter results to specific domains",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "search_mode",
            "helper_text": "The search mode to use",
            "value": "",
            "type": "string",
        },
        {
            "field": "search_recency_filter",
            "helper_text": "Filter results by recency",
            "value": "",
            "type": "string",
        },
        {
            "field": "user_location_latitude",
            "helper_text": "The latitude of the user's location",
            "value": "",
            "type": "string",
        },
        {
            "field": "user_location_longitude",
            "helper_text": "The longitude of the user's location",
            "value": "",
            "type": "string",
        },
        {
            "field": "user_location_name",
            "helper_text": "The name of the user's location",
            "value": "",
            "type": "string",
        },
        {
            "field": "user_location_radius_km",
            "helper_text": "The radius in kilometers for location-based search",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "formatted_text",
            "helper_text": "Perplexity search results formatted for LLM consumption",
            "type": "string",
        },
        {
            "field": "output",
            "helper_text": "The search results from Perplexity",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "last_updated_after_filter"},
        {"field": "last_updated_before_filter"},
        {"field": "query"},
        {"field": "query_list"},
        {"field": "search_after_date_filter"},
        {"field": "search_before_date_filter"},
        {"field": "search_domain_filter"},
        {"field": "search_mode"},
        {"field": "search_recency_filter"},
        {"field": "user_location_latitude"},
        {"field": "user_location_longitude"},
        {"field": "user_location_name"},
        {"field": "user_location_radius_km"},
    ]

    _REQUIRED_FIELDS = ["query"]

    def __init__(
        self,
        query: str = "",
        last_updated_after_filter: str = "",
        last_updated_before_filter: str = "",
        max_results: int = 10,
        max_tokens_per_page: int = 1000,
        query_list: List[str] = [],
        return_images: bool = False,
        return_snippets: bool = True,
        search_after_date_filter: str = "",
        search_before_date_filter: str = "",
        search_domain_filter: List[str] = [],
        search_mode: str = "",
        search_recency_filter: str = "",
        user_location_latitude: str = "",
        user_location_longitude: str = "",
        user_location_name: str = "",
        user_location_radius_km: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="perplexity_search",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if query is not None:
            self.inputs["query"] = query
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if query_list is not None:
            self.inputs["query_list"] = query_list
        if max_tokens_per_page is not None:
            self.inputs["max_tokens_per_page"] = max_tokens_per_page
        if search_mode is not None:
            self.inputs["search_mode"] = search_mode
        if search_recency_filter is not None:
            self.inputs["search_recency_filter"] = search_recency_filter
        if search_before_date_filter is not None:
            self.inputs["search_before_date_filter"] = search_before_date_filter
        if search_after_date_filter is not None:
            self.inputs["search_after_date_filter"] = search_after_date_filter
        if last_updated_before_filter is not None:
            self.inputs["last_updated_before_filter"] = last_updated_before_filter
        if last_updated_after_filter is not None:
            self.inputs["last_updated_after_filter"] = last_updated_after_filter
        if search_domain_filter is not None:
            self.inputs["search_domain_filter"] = search_domain_filter
        if return_images is not None:
            self.inputs["return_images"] = return_images
        if return_snippets is not None:
            self.inputs["return_snippets"] = return_snippets
        if user_location_name is not None:
            self.inputs["user_location_name"] = user_location_name
        if user_location_latitude is not None:
            self.inputs["user_location_latitude"] = user_location_latitude
        if user_location_longitude is not None:
            self.inputs["user_location_longitude"] = user_location_longitude
        if user_location_radius_km is not None:
            self.inputs["user_location_radius_km"] = user_location_radius_km
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "PerplexitySearchNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
