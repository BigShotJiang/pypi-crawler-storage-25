"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("sort_csv")
class SortCsvNode(Node):
    """
    Sort a CSV based on a column

    ## Inputs
    ### Common Inputs
        file: The CSV file to sort.
        has_headers: Whether the CSV has headers.
        is_file_variable: Whether the file is a variable.
        reverse_sort: Whether to reverse the sort.
    ### When is_file_variable = True
        column_index: The index of the column to sort by.
    ### When is_file_variable = False and has_headers = False
        column_index: The index of the column to sort by.
    ### When is_file_variable = False and has_headers = True
        column_to_sort_by: The column to sort by.

    ## Outputs
    ### Common Outputs
        output: The output output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "file",
            "helper_text": "The CSV file to sort.",
            "value": "",
            "type": "file",
        },
        {
            "field": "has_headers",
            "helper_text": "Whether the CSV has headers.",
            "value": True,
            "type": "bool",
        },
        {
            "field": "is_file_variable",
            "helper_text": "Whether the file is a variable.",
            "value": True,
            "type": "bool",
        },
        {
            "field": "reverse_sort",
            "helper_text": "Whether to reverse the sort.",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "output", "helper_text": "The output output", "type": "file"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [
                {
                    "field": "column_index",
                    "type": "int32",
                    "value": 0,
                    "label": "Column Index",
                    "helper_text": "The index of the column to sort by.",
                    "component": {"type": "number"},
                }
            ],
            "outputs": [],
        },
        "false**true": {
            "inputs": [
                {
                    "field": "column_to_sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Column to sort By",
                    "helper_text": "The column to sort by.",
                    "component": {
                        "type": "dropdown",
                        "source": "endpoint",
                        "endpoint_config": {
                            "url": "/files/function-specific-params/csv-reader/read-columns",
                            "depends_on": ["file"],
                            "params": {
                                "file_id": "{{file.id}}",
                                "sheet_name": "{{file.metadata.name}}",
                            },
                            "response_key": "outputs",
                            "option_value_key": "name",
                        },
                    },
                }
            ],
            "outputs": [],
        },
        "false**false": {
            "inputs": [
                {
                    "field": "column_index",
                    "type": "int32",
                    "value": 0,
                    "label": "Column Index",
                    "helper_text": "The index of the column to sort by.",
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["is_file_variable", "has_headers"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["file"]

    def __init__(
        self,
        is_file_variable: bool = True,
        has_headers: bool = True,
        column_index: int = 0,
        column_to_sort_by: str = "",
        file: str = "",
        reverse_sort: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["is_file_variable"] = is_file_variable
        params["has_headers"] = has_headers

        super().__init__(
            node_type="sort_csv",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if is_file_variable is not None:
            self.inputs["is_file_variable"] = is_file_variable
        if file is not None:
            self.inputs["file"] = file
        if has_headers is not None:
            self.inputs["has_headers"] = has_headers
        if reverse_sort is not None:
            self.inputs["reverse_sort"] = reverse_sort
        if column_index is not None:
            self.inputs["column_index"] = column_index
        if column_to_sort_by is not None:
            self.inputs["column_to_sort_by"] = column_to_sort_by
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "SortCsvNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
