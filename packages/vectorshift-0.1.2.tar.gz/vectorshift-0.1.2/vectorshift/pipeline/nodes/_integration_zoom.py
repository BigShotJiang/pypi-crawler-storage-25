"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_zoom")
class IntegrationZoomNode(Node):
    """
    Zoom

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Zoom account
    ### create_meeting
        agenda: Meeting agenda
        alternative_hosts: Alternative hosts email IDs (comma separated)
        audio: How participants can join the audio portion of the meeting
        auto_recording: Automatic recording setting
        cn_meeting: Host this meeting in China
        duration: Meeting duration in minutes
        host_video: Start video when host joins the meeting
        in_meeting: Host this meeting in India
        join_before_host: Allow participants to join the meeting before host starts it
        mute_upon_entry: Mute participants upon entry
        participant_video: Start video when participants join the meeting
        password: Meeting password (max 10 characters)
        registration_type: Registration type for recurring meetings with fixed time
        schedule_for: Schedule meeting for another user's email
        start_time: Start time for the meeting
        timezone: Timezone for the meeting
        topic: Topic of the meeting
        type: Meeting type
        waiting_room: Enable waiting room
        watermark: Add watermark when viewing a shared screen
    ### update_meeting
        agenda: Meeting agenda
        alternative_hosts: Alternative hosts email IDs (comma separated)
        audio: How participants can join the audio portion of the meeting
        auto_recording: Automatic recording setting
        cn_meeting: Host this meeting in China
        duration: Meeting duration in minutes
        host_video: Start video when host joins the meeting
        in_meeting: Host this meeting in India
        join_before_host: Allow participants to join the meeting before host starts it
        meeting_id: Meeting ID to retrieve
        mute_upon_entry: Mute participants upon entry
        occurrence_id: Occurrence ID for recurring meetings
        participant_video: Start video when participants join the meeting
        password: Meeting password (max 10 characters)
        registration_type: Registration type for recurring meetings with fixed time
        schedule_for: Schedule meeting for another user's email
        start_time: Start time for the meeting
        timezone: Timezone for the meeting
        topic: Topic of the meeting
        type: Meeting type
        waiting_room: Enable waiting room
        watermark: Add watermark when viewing a shared screen
    ### list_meetings
        limit: Number of meetings to return (1-300)
        return_all: Return all meetings
        type: Meeting type
    ### get_meeting
        meeting_id: Meeting ID to retrieve
        occurrence_id: Occurrence ID for recurring meetings
        show_previous_occurrences: Show past occurrences of recurring meetings
    ### delete_meeting
        meeting_id: Meeting ID to retrieve
        occurrence_id: Occurrence ID for recurring meetings
        schedule_for_reminder: Send cancellation email to host and alternative hosts

    ## Outputs
    ### create_meeting
        agenda: Meeting agenda
        assistant_id: ID of user who scheduled meeting on behalf of host
        chat_join_url: URL to join the chat
        created_at: Creation timestamp
        creation_source: Platform through which meeting was created
        duration: Duration in minutes
        dynamic_host_key: Meeting dynamic host key
        encrypted_password: Encrypted password
        h323_password: H.323/SIP room system password
        host_email: Host email address
        host_id: Host user ID
        join_url: URL for participants to join
        meeting_id: Meeting ID
        occurrences: Meeting occurrences for recurring meetings (JSON array)
        password: Meeting password
        pmi: Personal Meeting ID
        pre_schedule: Whether meeting is pre-scheduled
        pstn_password: PSTN password
        raw_data: Complete API response
        recurrence: Recurrence settings (JSON format)
        registration_url: Registration URL (if registration enabled)
        settings: Meeting settings (JSON format)
        start_time: Start time of the meeting
        start_url: URL for host to start meeting
        status: Meeting status
        timezone: Timezone
        topic: Meeting topic
        tracking_fields: Tracking fields (JSON array)
        type: Meeting type
        uuid: Meeting UUID
    ### get_meeting
        agenda: Meeting agenda
        assistant_id: ID of user who scheduled meeting on behalf of host
        chat_join_url: URL to join the chat
        created_at: Creation timestamp
        creation_source: Platform through which meeting was created
        duration: Duration in minutes
        dynamic_host_key: Meeting dynamic host key
        encrypted_password: Encrypted password
        h323_password: H.323/SIP room system password
        host_email: Host email address
        host_id: Host user ID
        join_url: URL for participants to join
        meeting_id: Meeting ID
        occurrences: Meeting occurrences for recurring meetings (JSON array)
        password: Meeting password
        pmi: Personal Meeting ID
        pre_schedule: Whether meeting is pre-scheduled
        pstn_password: PSTN password
        raw_data: Complete API response
        recurrence: Recurrence settings (JSON format)
        registration_url: Registration URL (if registration enabled)
        settings: Meeting settings (JSON format)
        start_time: Start time of the meeting
        start_url: URL for host to start meeting
        status: Meeting status
        timezone: Timezone
        topic: Meeting topic
        tracking_fields: Tracking fields (JSON array)
        type: Meeting type
        uuid: Meeting UUID
    ### list_meetings
        created_dates: List of creation dates
        durations: List of meeting durations
        host_emails: List of host emails
        join_urls: List of join URLs
        meeting_ids: List of meeting IDs
        raw_data: Compiled list of meetings (JSON array)
        start_times: List of meeting start times
        start_urls: List of start URLs
        statuses: List of meeting statuses
        timezones: List of timezones
        topics: List of meeting topics
        total_count: Total number of meetings
        types: List of meeting types
    ### update_meeting
        meeting_id: Meeting ID
        raw_data: Complete API response (empty for 204 No Content)
    ### delete_meeting
        meeting_id: ID of the deleted meeting
        raw_data: Complete API response
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Zoom account",
            "value": None,
            "type": "integration<Zoom>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_meeting": {
            "inputs": [
                {
                    "field": "topic",
                    "type": "string",
                    "value": "",
                    "label": "Topic",
                    "placeholder": "My Meeting",
                    "helper_text": "Topic of the meeting",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "2",
                    "label": "Type",
                    "helper_text": "Meeting type",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Instant Meeting", "value": "1"},
                            {"label": "Scheduled Meeting", "value": "2"},
                            {
                                "label": "Recurring Meeting with No Fixed Time",
                                "value": "3",
                            },
                            {
                                "label": "Recurring Meeting with Fixed Time",
                                "value": "8",
                            },
                        ],
                    },
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start Time",
                    "placeholder": "2024-12-25T10:00:00",
                    "helper_text": "Start time for the meeting",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "value": 60,
                    "label": "Duration",
                    "helper_text": "Meeting duration in minutes",
                },
                {
                    "field": "timezone",
                    "type": "string",
                    "value": "",
                    "label": "Timezone",
                    "placeholder": "America/New_York",
                    "helper_text": "Timezone for the meeting",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "helper_text": "Meeting password (max 10 characters)",
                },
                {
                    "field": "agenda",
                    "type": "string",
                    "value": "",
                    "label": "Agenda",
                    "helper_text": "Meeting agenda",
                },
                {
                    "field": "schedule_for",
                    "type": "string",
                    "value": "",
                    "label": "Schedule For",
                    "placeholder": "user@example.com",
                    "helper_text": "Schedule meeting for another user's email",
                },
                {
                    "field": "host_video",
                    "type": "bool",
                    "value": False,
                    "label": "Host Video",
                    "helper_text": "Start video when host joins the meeting",
                },
                {
                    "field": "participant_video",
                    "type": "bool",
                    "value": False,
                    "label": "Participant Video",
                    "helper_text": "Start video when participants join the meeting",
                },
                {
                    "field": "join_before_host",
                    "type": "bool",
                    "value": False,
                    "label": "Join Before Host",
                    "helper_text": "Allow participants to join the meeting before host starts it",
                },
                {
                    "field": "mute_upon_entry",
                    "type": "bool",
                    "value": False,
                    "label": "Mute Upon Entry",
                    "helper_text": "Mute participants upon entry",
                },
                {
                    "field": "watermark",
                    "type": "bool",
                    "value": False,
                    "label": "Watermark",
                    "helper_text": "Add watermark when viewing a shared screen",
                },
                {
                    "field": "waiting_room",
                    "type": "bool",
                    "value": False,
                    "label": "Waiting Room",
                    "helper_text": "Enable waiting room",
                },
                {
                    "field": "audio",
                    "type": "string",
                    "value": "both",
                    "label": "Audio",
                    "helper_text": "How participants can join the audio portion of the meeting",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Both Telephony and VoIP", "value": "both"},
                            {"label": "Telephony", "value": "telephony"},
                            {"label": "VoIP", "value": "voip"},
                        ],
                    },
                },
                {
                    "field": "auto_recording",
                    "type": "string",
                    "value": "none",
                    "label": "Auto Recording",
                    "helper_text": "Automatic recording setting",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "None", "value": "none"},
                            {"label": "Record on Local", "value": "local"},
                            {"label": "Record on Cloud", "value": "cloud"},
                        ],
                    },
                },
                {
                    "field": "alternative_hosts",
                    "type": "string",
                    "value": "",
                    "label": "Alternative Hosts",
                    "placeholder": "user1@example.com,user2@example.com",
                    "helper_text": "Alternative hosts email IDs (comma separated)",
                },
                {
                    "field": "cn_meeting",
                    "type": "bool",
                    "value": False,
                    "label": "Host Meeting in China",
                    "helper_text": "Host this meeting in China",
                },
                {
                    "field": "in_meeting",
                    "type": "bool",
                    "value": False,
                    "label": "Host Meeting in India",
                    "helper_text": "Host this meeting in India",
                },
                {
                    "field": "registration_type",
                    "type": "string",
                    "value": "1",
                    "label": "Registration Type",
                    "helper_text": "Registration type for recurring meetings with fixed time",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {
                                "label": "Attendees register once and can attend any occurrence",
                                "value": "1",
                            },
                            {
                                "label": "Attendees need to register for every occurrence",
                                "value": "2",
                            },
                            {
                                "label": "Attendees register once and choose occurrences",
                                "value": "3",
                            },
                        ],
                    },
                },
            ],
            "outputs": [
                {"field": "meeting_id", "type": "string", "helper_text": "Meeting ID"},
                {"field": "uuid", "type": "string", "helper_text": "Meeting UUID"},
                {
                    "field": "assistant_id",
                    "type": "string",
                    "helper_text": "ID of user who scheduled meeting on behalf of host",
                },
                {"field": "host_id", "type": "string", "helper_text": "Host user ID"},
                {
                    "field": "host_email",
                    "type": "string",
                    "helper_text": "Host email address",
                },
                {"field": "topic", "type": "string", "helper_text": "Meeting topic"},
                {"field": "type", "type": "int32", "helper_text": "Meeting type"},
                {"field": "status", "type": "string", "helper_text": "Meeting status"},
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "helper_text": "Start time of the meeting",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "helper_text": "Duration in minutes",
                },
                {"field": "timezone", "type": "string", "helper_text": "Timezone"},
                {"field": "agenda", "type": "string", "helper_text": "Meeting agenda"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "start_url",
                    "type": "string",
                    "helper_text": "URL for host to start meeting",
                },
                {
                    "field": "join_url",
                    "type": "string",
                    "helper_text": "URL for participants to join",
                },
                {
                    "field": "chat_join_url",
                    "type": "string",
                    "helper_text": "URL to join the chat",
                },
                {
                    "field": "registration_url",
                    "type": "string",
                    "helper_text": "Registration URL (if registration enabled)",
                },
                {
                    "field": "password",
                    "type": "string",
                    "helper_text": "Meeting password",
                },
                {
                    "field": "h323_password",
                    "type": "string",
                    "helper_text": "H.323/SIP room system password",
                },
                {
                    "field": "pstn_password",
                    "type": "string",
                    "helper_text": "PSTN password",
                },
                {
                    "field": "encrypted_password",
                    "type": "string",
                    "helper_text": "Encrypted password",
                },
                {
                    "field": "pmi",
                    "type": "string",
                    "helper_text": "Personal Meeting ID",
                },
                {
                    "field": "pre_schedule",
                    "type": "bool",
                    "helper_text": "Whether meeting is pre-scheduled",
                },
                {
                    "field": "settings",
                    "type": "string",
                    "helper_text": "Meeting settings (JSON format)",
                },
                {
                    "field": "recurrence",
                    "type": "string",
                    "helper_text": "Recurrence settings (JSON format)",
                },
                {
                    "field": "occurrences",
                    "type": "string",
                    "helper_text": "Meeting occurrences for recurring meetings (JSON array)",
                },
                {
                    "field": "tracking_fields",
                    "type": "string",
                    "helper_text": "Tracking fields (JSON array)",
                },
                {
                    "field": "dynamic_host_key",
                    "type": "string",
                    "helper_text": "Meeting dynamic host key",
                },
                {
                    "field": "creation_source",
                    "type": "string",
                    "helper_text": "Platform through which meeting was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_meeting",
            "task_name": "tasks.zoom.create_meeting",
            "description": "Create a new Zoom meeting",
            "label": "Create Meeting",
            "required": ["topic"],
            "inputs_sort_order": [
                "integration",
                "action",
                "topic",
                "type",
                "start_time",
                "duration",
                "timezone",
                "password",
                "agenda",
                "schedule_for",
                "host_video",
                "participant_video",
                "join_before_host",
                "mute_upon_entry",
                "watermark",
                "waiting_room",
                "audio",
                "auto_recording",
                "alternative_hosts",
                "cn_meeting",
                "in_meeting",
                "registration_type",
            ],
        },
        "get_meeting": {
            "inputs": [
                {
                    "field": "meeting_id",
                    "type": "string",
                    "value": "",
                    "label": "Meeting ID",
                    "placeholder": "85746065217",
                    "helper_text": "Meeting ID to retrieve",
                },
                {
                    "field": "occurrence_id",
                    "type": "string",
                    "value": "",
                    "label": "Occurrence ID",
                    "helper_text": "Occurrence ID for recurring meetings",
                },
                {
                    "field": "show_previous_occurrences",
                    "type": "bool",
                    "value": False,
                    "label": "Show Previous Occurrences",
                    "helper_text": "Show past occurrences of recurring meetings",
                },
            ],
            "outputs": [
                {"field": "meeting_id", "type": "string", "helper_text": "Meeting ID"},
                {"field": "uuid", "type": "string", "helper_text": "Meeting UUID"},
                {
                    "field": "assistant_id",
                    "type": "string",
                    "helper_text": "ID of user who scheduled meeting on behalf of host",
                },
                {"field": "host_id", "type": "string", "helper_text": "Host user ID"},
                {
                    "field": "host_email",
                    "type": "string",
                    "helper_text": "Host email address",
                },
                {"field": "topic", "type": "string", "helper_text": "Meeting topic"},
                {"field": "type", "type": "int32", "helper_text": "Meeting type"},
                {"field": "status", "type": "string", "helper_text": "Meeting status"},
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "helper_text": "Start time of the meeting",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "helper_text": "Duration in minutes",
                },
                {"field": "timezone", "type": "string", "helper_text": "Timezone"},
                {"field": "agenda", "type": "string", "helper_text": "Meeting agenda"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "start_url",
                    "type": "string",
                    "helper_text": "URL for host to start meeting",
                },
                {
                    "field": "join_url",
                    "type": "string",
                    "helper_text": "URL for participants to join",
                },
                {
                    "field": "chat_join_url",
                    "type": "string",
                    "helper_text": "URL to join the chat",
                },
                {
                    "field": "registration_url",
                    "type": "string",
                    "helper_text": "Registration URL (if registration enabled)",
                },
                {
                    "field": "password",
                    "type": "string",
                    "helper_text": "Meeting password",
                },
                {
                    "field": "h323_password",
                    "type": "string",
                    "helper_text": "H.323/SIP room system password",
                },
                {
                    "field": "pstn_password",
                    "type": "string",
                    "helper_text": "PSTN password",
                },
                {
                    "field": "encrypted_password",
                    "type": "string",
                    "helper_text": "Encrypted password",
                },
                {
                    "field": "pmi",
                    "type": "string",
                    "helper_text": "Personal Meeting ID",
                },
                {
                    "field": "pre_schedule",
                    "type": "bool",
                    "helper_text": "Whether meeting is pre-scheduled",
                },
                {
                    "field": "settings",
                    "type": "string",
                    "helper_text": "Meeting settings (JSON format)",
                },
                {
                    "field": "occurrences",
                    "type": "string",
                    "helper_text": "Meeting occurrences for recurring meetings (JSON array)",
                },
                {
                    "field": "recurrence",
                    "type": "string",
                    "helper_text": "Recurrence settings (JSON format)",
                },
                {
                    "field": "tracking_fields",
                    "type": "string",
                    "helper_text": "Tracking fields (JSON array)",
                },
                {
                    "field": "dynamic_host_key",
                    "type": "string",
                    "helper_text": "Meeting dynamic host key",
                },
                {
                    "field": "creation_source",
                    "type": "string",
                    "helper_text": "Platform through which meeting was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_meeting",
            "task_name": "tasks.zoom.get_meeting",
            "description": "Retrieve a specific Zoom meeting",
            "label": "Get Meeting",
            "required": ["meeting_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "meeting_id",
                "occurrence_id",
                "show_previous_occurrences",
            ],
        },
        "list_meetings": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all meetings",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Number of meetings to return (1-300)",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "scheduled",
                    "label": "Type",
                    "helper_text": "Filter meetings by type",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Scheduled", "value": "scheduled"},
                            {"label": "Live", "value": "live"},
                            {"label": "Upcoming", "value": "upcoming"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "meeting_ids",
                    "type": "vec<string>",
                    "helper_text": "List of meeting IDs",
                },
                {
                    "field": "topics",
                    "type": "vec<string>",
                    "helper_text": "List of meeting topics",
                },
                {
                    "field": "start_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of meeting start times",
                },
                {
                    "field": "durations",
                    "type": "vec<int32>",
                    "helper_text": "List of meeting durations",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of meeting statuses",
                },
                {
                    "field": "types",
                    "type": "vec<int32>",
                    "helper_text": "List of meeting types",
                },
                {
                    "field": "join_urls",
                    "type": "vec<string>",
                    "helper_text": "List of join URLs",
                },
                {
                    "field": "start_urls",
                    "type": "vec<string>",
                    "helper_text": "List of start URLs",
                },
                {
                    "field": "host_emails",
                    "type": "vec<string>",
                    "helper_text": "List of host emails",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "timezones",
                    "type": "vec<string>",
                    "helper_text": "List of timezones",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of meetings",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Compiled list of meetings (JSON array)",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_meetings",
            "task_name": "tasks.zoom.list_meetings",
            "description": "List all Zoom meetings",
            "label": "List Meetings",
            "required": ["limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "type",
            ],
        },
        "update_meeting": {
            "inputs": [
                {
                    "field": "meeting_id",
                    "type": "string",
                    "value": "",
                    "label": "Meeting ID",
                    "placeholder": "85746065217",
                    "helper_text": "Meeting ID to update",
                },
                {
                    "field": "topic",
                    "type": "string",
                    "value": "",
                    "label": "Topic",
                    "placeholder": "Updated Meeting",
                    "helper_text": "Meeting topic",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "label": "Type",
                    "helper_text": "Meeting type",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Change", "value": ""},
                            {"label": "Instant Meeting", "value": "1"},
                            {"label": "Scheduled Meeting", "value": "2"},
                            {
                                "label": "Recurring Meeting with No Fixed Time",
                                "value": "3",
                            },
                            {
                                "label": "Recurring Meeting with Fixed Time",
                                "value": "8",
                            },
                        ],
                    },
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start Time",
                    "placeholder": "2024-12-25T10:00:00",
                    "helper_text": "Start time for the meeting",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "value": -1,
                    "label": "Duration",
                    "helper_text": "Meeting duration in minutes (-1 for no change)",
                },
                {
                    "field": "timezone",
                    "type": "string",
                    "value": "",
                    "label": "Timezone",
                    "placeholder": "America/New_York",
                    "helper_text": "Timezone for the meeting",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "helper_text": "Meeting password (max 10 characters)",
                },
                {
                    "field": "agenda",
                    "type": "string",
                    "value": "",
                    "label": "Agenda",
                    "helper_text": "Meeting agenda",
                },
                {
                    "field": "schedule_for",
                    "type": "string",
                    "value": "",
                    "label": "Schedule For",
                    "placeholder": "user@example.com",
                    "helper_text": "Schedule meeting for another user's email",
                },
                {
                    "field": "occurrence_id",
                    "type": "string",
                    "value": "",
                    "label": "Occurrence ID",
                    "helper_text": "Occurrence ID for recurring meetings",
                },
                {
                    "field": "host_video",
                    "type": "bool",
                    "value": False,
                    "label": "Host Video",
                    "helper_text": "Start video when host joins the meeting",
                },
                {
                    "field": "participant_video",
                    "type": "bool",
                    "value": False,
                    "label": "Participant Video",
                    "helper_text": "Start video when participants join the meeting",
                },
                {
                    "field": "join_before_host",
                    "type": "bool",
                    "value": False,
                    "label": "Join Before Host",
                    "helper_text": "Allow participants to join the meeting before host starts it",
                },
                {
                    "field": "mute_upon_entry",
                    "type": "bool",
                    "value": False,
                    "label": "Mute Upon Entry",
                    "helper_text": "Mute participants upon entry",
                },
                {
                    "field": "watermark",
                    "type": "bool",
                    "value": False,
                    "label": "Watermark",
                    "helper_text": "Add watermark when viewing a shared screen",
                },
                {
                    "field": "waiting_room",
                    "type": "bool",
                    "value": False,
                    "label": "Waiting Room",
                    "helper_text": "Enable waiting room",
                },
                {
                    "field": "audio",
                    "type": "string",
                    "value": "",
                    "label": "Audio",
                    "helper_text": "How participants can join the audio portion of the meeting",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Change", "value": ""},
                            {"label": "Both Telephony and VoIP", "value": "both"},
                            {"label": "Telephony", "value": "telephony"},
                            {"label": "VoIP", "value": "voip"},
                        ],
                    },
                },
                {
                    "field": "auto_recording",
                    "type": "string",
                    "value": "",
                    "label": "Auto Recording",
                    "helper_text": "Automatic recording setting",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Change", "value": ""},
                            {"label": "None", "value": "none"},
                            {"label": "Record on Local", "value": "local"},
                            {"label": "Record on Cloud", "value": "cloud"},
                        ],
                    },
                },
                {
                    "field": "alternative_hosts",
                    "type": "string",
                    "value": "",
                    "label": "Alternative Hosts",
                    "placeholder": "user1@example.com,user2@example.com",
                    "helper_text": "Alternative hosts email IDs (comma separated)",
                },
                {
                    "field": "cn_meeting",
                    "type": "bool",
                    "value": False,
                    "label": "Host Meeting in China",
                    "helper_text": "Host this meeting in China",
                },
                {
                    "field": "in_meeting",
                    "type": "bool",
                    "value": False,
                    "label": "Host Meeting in India",
                    "helper_text": "Host this meeting in India",
                },
                {
                    "field": "registration_type",
                    "type": "string",
                    "value": "",
                    "label": "Registration Type",
                    "helper_text": "Registration type for recurring meetings with fixed time",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Change", "value": ""},
                            {
                                "label": "Attendees register once and can attend any occurrence",
                                "value": "1",
                            },
                            {
                                "label": "Attendees need to register for every occurrence",
                                "value": "2",
                            },
                            {
                                "label": "Attendees register once and choose occurrences",
                                "value": "3",
                            },
                        ],
                    },
                },
            ],
            "outputs": [
                {"field": "meeting_id", "type": "string", "helper_text": "Meeting ID"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response (empty for 204 No Content)",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_meeting",
            "task_name": "tasks.zoom.update_meeting",
            "description": "Update an existing Zoom meeting",
            "label": "Update Meeting",
            "required": ["meeting_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "meeting_id",
                "topic",
                "type",
                "start_time",
                "duration",
                "timezone",
                "password",
                "agenda",
                "schedule_for",
                "occurrence_id",
                "host_video",
                "participant_video",
                "join_before_host",
                "mute_upon_entry",
                "watermark",
                "waiting_room",
                "audio",
                "auto_recording",
                "alternative_hosts",
                "cn_meeting",
                "in_meeting",
                "registration_type",
            ],
        },
        "delete_meeting": {
            "inputs": [
                {
                    "field": "meeting_id",
                    "type": "string",
                    "value": "",
                    "label": "Meeting ID",
                    "placeholder": "85746065217",
                    "helper_text": "Meeting ID to delete",
                },
                {
                    "field": "occurrence_id",
                    "type": "string",
                    "value": "",
                    "label": "Occurrence ID",
                    "helper_text": "Occurrence ID for recurring meetings",
                },
                {
                    "field": "schedule_for_reminder",
                    "type": "bool",
                    "value": False,
                    "label": "Schedule For Reminder",
                    "helper_text": "Send cancellation email to host and alternative hosts",
                },
            ],
            "outputs": [
                {
                    "field": "meeting_id",
                    "type": "string",
                    "helper_text": "ID of the deleted meeting",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_meeting",
            "task_name": "tasks.zoom.delete_meeting",
            "description": "Delete a Zoom meeting",
            "label": "Delete Meeting",
            "required": ["meeting_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "meeting_id",
                "occurrence_id",
                "schedule_for_reminder",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        agenda: str = "",
        alternative_hosts: str = "",
        audio: str = "both",
        auto_recording: str = "none",
        cn_meeting: bool = False,
        duration: int = 60,
        host_video: bool = False,
        in_meeting: bool = False,
        join_before_host: bool = False,
        limit: int = 10,
        meeting_id: str = "",
        mute_upon_entry: bool = False,
        occurrence_id: str = "",
        participant_video: bool = False,
        password: str = "",
        registration_type: str = "1",
        return_all: bool = False,
        schedule_for: str = "",
        schedule_for_reminder: bool = False,
        show_previous_occurrences: bool = False,
        start_time: Any = -1,
        timezone: str = "",
        topic: str = "",
        type: str = "2",
        waiting_room: bool = False,
        watermark: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_zoom",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if topic is not None:
            self.inputs["topic"] = topic
        if type is not None:
            self.inputs["type"] = type
        if start_time is not None:
            self.inputs["start_time"] = start_time
        if duration is not None:
            self.inputs["duration"] = duration
        if timezone is not None:
            self.inputs["timezone"] = timezone
        if password is not None:
            self.inputs["password"] = password
        if agenda is not None:
            self.inputs["agenda"] = agenda
        if schedule_for is not None:
            self.inputs["schedule_for"] = schedule_for
        if host_video is not None:
            self.inputs["host_video"] = host_video
        if participant_video is not None:
            self.inputs["participant_video"] = participant_video
        if join_before_host is not None:
            self.inputs["join_before_host"] = join_before_host
        if mute_upon_entry is not None:
            self.inputs["mute_upon_entry"] = mute_upon_entry
        if watermark is not None:
            self.inputs["watermark"] = watermark
        if waiting_room is not None:
            self.inputs["waiting_room"] = waiting_room
        if audio is not None:
            self.inputs["audio"] = audio
        if auto_recording is not None:
            self.inputs["auto_recording"] = auto_recording
        if alternative_hosts is not None:
            self.inputs["alternative_hosts"] = alternative_hosts
        if cn_meeting is not None:
            self.inputs["cn_meeting"] = cn_meeting
        if in_meeting is not None:
            self.inputs["in_meeting"] = in_meeting
        if registration_type is not None:
            self.inputs["registration_type"] = registration_type
        if meeting_id is not None:
            self.inputs["meeting_id"] = meeting_id
        if occurrence_id is not None:
            self.inputs["occurrence_id"] = occurrence_id
        if show_previous_occurrences is not None:
            self.inputs["show_previous_occurrences"] = show_previous_occurrences
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if schedule_for_reminder is not None:
            self.inputs["schedule_for_reminder"] = schedule_for_reminder
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationZoomNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
