"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("email_validator")
class EmailValidatorNode(Node):
    """
    Validate an email address

    ## Inputs
    ### Common Inputs
        model: The validation model to use
        email_to_validate: The email you want to validate
    ### custom-validator
        api_key: The API key to use
        provider: The validation provider to use

    ## Outputs
    ### Common Outputs
        status: Whether the email is valid
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The validation model to use",
            "value": "regex",
            "type": "string",
        },
        {
            "field": "email_to_validate",
            "helper_text": "The email you want to validate",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "status", "helper_text": "Whether the email is valid", "type": "bool"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "custom-validator": {
            "inputs": [
                {
                    "field": "provider",
                    "label": "Provider",
                    "type": "string",
                    "value": "hunter",
                    "helper_text": "The validation provider to use",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Debounce", "value": "debounce"},
                            {"label": "Hunter", "value": "hunter"},
                        ],
                    },
                },
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "The API key to use",
                    "component": {"type": "password"},
                    "visibility": {
                        "field": "provider",
                        "operator": "!=",
                        "value": "debounce",
                    },
                },
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["model"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["email_to_validate", "model", "api_key"]

    def __init__(
        self,
        model: str = "regex",
        api_key: str = "",
        email_to_validate: str = "",
        provider: str = "hunter",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["model"] = model

        super().__init__(
            node_type="email_validator",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if email_to_validate is not None:
            self.inputs["email_to_validate"] = email_to_validate
        if model is not None:
            self.inputs["model"] = model
        if provider is not None:
            self.inputs["provider"] = provider
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "EmailValidatorNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
