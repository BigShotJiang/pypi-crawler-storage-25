"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_outlook")
class IntegrationOutlookNode(Node):
    """
    Outlook

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'read_email'
        query: Search using KQL syntax. Examples: 'xyz@email.com' (searches everywhere), 'from:xyz@email.com' (specific field). Supported fields: subject:, body:, from:, to:, cc:, bcc:. Use AND/OR to combine.
        from: Filter emails from this sender address
        has_attachment: Filter by attachment presence
        importance: Filter by importance level
        is_read: Filter by read/unread status
        item_id: Select a mailbox to read emails from (optional - searches all messages if not specified)
        subject: The subject of the email
        to: Filter emails sent to this address
        use_date: Toggle to use dates
    ### When action = 'add_message_attachment'
        attachment: The file to attach to the message
        message_id: Select the message to get
    ### When action = 'get_message_attachment'
        attachment_id: The ID of the attachment to retrieve
        fields: Comma-separated list of additional fields to return
        message_id: Select the message to get
    ### When action = 'download_message_attachment'
        attachment_id: The ID of the attachment to retrieve
        message_id: Select the message to get
    ### When action = 'send_email'
        attachments: Attachments to be appended.
        bcc_recipients: A single email or a comma-separated list of the BCC recipients' emails
        body: The body of the email
        cc_recipients: A single email or a comma-separated list of the CC recipients' emails
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails
        subject: The subject of the email
    ### When action = 'send_reply'
        attachments: Attachments to be appended.
        bcc_recipients: A single email or a comma-separated list of the BCC recipients' emails
        body: The body of the email
        cc_recipients: A single email or a comma-separated list of the CC recipients' emails
        email_id: The ID of the email to reply to
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails
        reply_to: Alternative email address where replies should be sent instead of the sender's address
        reply_to_sender_only: When enabled, ensures that replies go only to the sender, excluding CC or group recipients
        sender_name: Custom name to display as the sender in the recipient's inbox
    ### When action = 'create_draft'
        attachments: Attachments to be appended.
        bcc_recipients: A single email or a comma-separated list of the BCC recipients' emails
        body: The body of the email
        cc_recipients: A single email or a comma-separated list of the CC recipients' emails
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails
        subject: The subject of the email
    ### When action = 'draft_reply'
        attachments: Attachments to be appended.
        bcc_recipients: A single email or a comma-separated list of the BCC recipients' emails
        body: The body of the email
        cc_recipients: A single email or a comma-separated list of the CC recipients' emails
        email_id: The ID of the email to reply to
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails
    ### When action = 'update_draft'
        bcc_recipients: A single email or a comma-separated list of the BCC recipients' emails
        body: The body of the email
        body_content_type: Content type for the body
        cc_recipients: A single email or a comma-separated list of the CC recipients' emails
        importance: Filter by importance level
        is_read: Filter by read/unread status
        is_read_receipt_requested: Request a read receipt for this message
        message_id: Select the message to get
        subject: The subject of the email
        to_recipients: Comma-separated list of recipient emails
    ### When action = 'send_draft'
        bcc_recipients: A single email or a comma-separated list of the BCC recipients' emails
        cc_recipients: A single email or a comma-separated list of the CC recipients' emails
        message_id: Select the message to get
        to: Filter emails sent to this address
    ### When action = 'create_contact'
        birthday: Birthday date
        business_address_city: Business address city
        business_address_country: Business address country
        business_address_postal_code: Business address postal/ZIP code
        business_address_state: Business address state/province
        business_address_street: Business street address
        business_home_page: Company or business website URL
        business_phones: Comma-separated list of business phone numbers
        categories: Comma-separated list of categories
        children: Comma-separated list of children's names
        company_name: The company name
        department: The department
        display_name: The name of the folder to create
        email_addresses: Comma-separated list of email addresses
        file_as: How to file the contact
        first_name: The first name of the contact
        home_address_city: Home address city
        home_address_country: Home address country
        home_address_postal_code: Home address postal/ZIP code
        home_address_state: Home address state/province
        home_address_street: Home street address
        home_phones: Comma-separated list of home phone numbers
        im_addresses: Comma-separated list of instant messaging addresses
        initials: Initials of the contact
        job_title: The job title
        last_name: The last name of the contact
        manager: Manager's name
        middle_name: The middle name of the contact
        mobile_phone: The mobile phone number
        nickname: Nickname of the contact
        notes: Personal notes about the contact
        office_location: The office location
        other_address_city: Other address city
        other_address_country: Other address country
        other_address_postal_code: Other address postal/ZIP code
        other_address_state: Other address state/province
        other_address_street: Other street address
        profession: The profession
        spouse_name: Name of the spouse
        title: Title of the contact (e.g., Mr., Mrs., Dr.)
    ### When action = 'update_contact'
        birthday: Birthday date
        business_address_city: Business address city
        business_address_country: Business address country
        business_address_postal_code: Business address postal/ZIP code
        business_address_state: Business address state/province
        business_address_street: Business street address
        business_home_page: Company or business website URL
        business_phones: Comma-separated list of business phone numbers
        categories: Comma-separated list of categories
        children: Comma-separated list of children's names
        company_name: The company name
        contact_id: Select the contact to retrieve
        department: The department
        display_name: The name of the folder to create
        email_addresses: Comma-separated list of email addresses
        file_as: How to file the contact
        home_address_city: Home address city
        home_address_country: Home address country
        home_address_postal_code: Home address postal/ZIP code
        home_address_state: Home address state/province
        home_address_street: Home street address
        home_phones: Comma-separated list of home phone numbers
        im_addresses: Comma-separated list of instant messaging addresses
        initials: Initials of the contact
        job_title: The job title
        manager: Manager's name
        middle_name: The middle name of the contact
        mobile_phone: The mobile phone number
        nickname: Nickname of the contact
        notes: Personal notes about the contact
        office_location: The office location
        other_address_city: Other address city
        other_address_country: Other address country
        other_address_postal_code: Other address postal/ZIP code
        other_address_state: Other address state/province
        other_address_street: Other street address
        profession: The profession
        spouse_name: Name of the spouse
        title: Title of the contact (e.g., Mr., Mrs., Dr.)
    ### When action = 'read_email' and use_date = False
        body: The body of the email
        num_messages: Specify the last n number of emails
    ### When action = 'get_contact'
        contact_id: Select the contact to retrieve
    ### When action = 'delete_contact'
        contact_id: Select the contact to retrieve
    ### When action = 'list_contacts'
        contact_limit: Maximum number of contacts to return
        email_address: Filter by specific email address
        filter_query: OData filter expression to filter contacts (e.g., startswith(displayName,'John'))
        return_all: Whether to return all folders (ignores limit)
    ### When action = 'read_email' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'update_message'
        destination_folder_id: ID of the folder to move the message to (leave empty to keep in current folder)
        importance: Filter by importance level
        is_read: Filter by read/unread status
        message_id: Select the message to get
    ### When action = 'move_message'
        destination_folder_id: ID of the folder to move the message to (leave empty to keep in current folder)
        message_id: Select the message to get
    ### When action = 'create_folder'
        display_name: The name of the folder to create
        parent_folder_id: ID of the parent folder (optional, creates in root if not provided)
    ### When action = 'update_folder'
        display_name: The name of the folder to create
        folder_id: Select a mailbox to read
    ### When action = 'read_email' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_folder'
        fields: Comma-separated list of additional fields to return
        folder_id: Select a mailbox to read
    ### When action = 'list_folders'
        fields: Comma-separated list of additional fields to return
        filter: OData filter expression
        limit: Maximum number of folders to return (0 for no limit)
        parent_folder_id: ID of the parent folder (optional, creates in root if not provided)
        return_all: Whether to return all folders (ignores limit)
    ### When action = 'list_folder_messages'
        fields: Comma-separated list of additional fields to return
        filter: OData filter expression
        folder_id: Select a mailbox to read
        limit: Maximum number of folders to return (0 for no limit)
        output: Output format for the message data
        return_all: Whether to return all folders (ignores limit)
        search: Search term to filter messages
    ### When action = 'list_message_attachments'
        fields: Comma-separated list of additional fields to return
        limit: Maximum number of folders to return (0 for no limit)
        message_id: Select the message to get
        return_all: Whether to return all folders (ignores limit)
    ### When action = 'list_people'
        filter_query: OData filter expression to filter contacts (e.g., startswith(displayName,'John'))
        limit: Maximum number of folders to return (0 for no limit)
        order_by: Field to sort results by (e.g. displayName). By default results are sorted by relevance.
        search: Search term to filter messages
    ### When action = 'delete_folder'
        folder_id: Select a mailbox to read
    ### When action = 'list_users'
        limit: Maximum number of folders to return (0 for no limit)
        search: Search term to filter messages
    ### When action = 'get_message'
        message_id: Select the message to get
        output: Output format for the message data
    ### When action = 'delete_message'
        message_id: Select the message to get
    ### When action = 'get_draft'
        message_id: Select the message to get
        output: Output format for the message data
    ### When action = 'delete_draft'
        message_id: Select the message to get
    ### When action = 'read_email' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_user'
        user_identifier: The user's ID or organizational email (work/school accounts only, not personal @outlook.com/@hotmail.com)

    ## Outputs
    ### When action = 'add_message_attachment'
        attachment_id: The ID of the added attachment
        name: The name of the attachment
        raw_data: Raw API response data
    ### When action = 'get_message_attachment'
        attachment_id: The ID of the attachment
        content_type: The MIME type of the attachment
        is_inline: Whether the attachment is inline
        last_modified_date_time: Last modified date and time
        name: The name of the attachment
        raw_data: Raw API response data
        size: The size of the attachment in bytes
    ### When action = 'download_message_attachment'
        attachment_id: The ID of the downloaded attachment
        content_size: The size of the downloaded content in bytes
        content_type: The MIME type of the file
        file_data: The downloaded file data
        file_name: The name of the downloaded file
        raw_data: Raw API response data
    ### When action = 'list_message_attachments'
        attachment_ids: List of attachment IDs
        attachment_names: List of attachment names
        attachments_count: Total number of attachments returned
        content_types: List of attachment MIME types
        is_inline_list: List indicating which attachments are inline
        last_modified_date_times: List of last modified date times
        raw_data: Raw API response data
        sizes: List of attachment sizes in bytes
    ### When action = 'read_email'
        attachments: The attachments for each email
        bcc_addresses: The email addresses of the BCC recipients
        cc_addresses: The email addresses of the CC recipients
        email_bodies: The content of the retrieved emails
        email_dates: The sent dates of the retrieved emails
        email_display_names: The display names of the senders
        email_ids: The IDs of the retrieved emails
        email_subjects: The subjects of the retrieved emails
        raw_data: Raw API response data
        recipient_addresses: The email addresses of the recipients
        sender_addresses: The email addresses of the senders
    ### When action = 'get_message'
        attachments: The attachments for the message (Full output only)
        bcc_emails: List of BCC recipient email addresses
        bcc_names: List of BCC recipient display names
        body_preview: Preview of the body content
        categories: List of categories assigned to the message
        cc_emails: List of CC recipient email addresses
        cc_names: List of CC recipient display names
        conversation_id: The conversation ID
        from_email: Sender email address
        from_name: Sender display name
        has_attachments: Whether the message has attachments
        message_id: The ID of the message
        raw_data: Raw API response data
        subject: The subject of the message
        to_emails: List of recipient email addresses
        to_names: List of recipient display names
    ### When action = 'get_draft'
        attachments: The attachments for the draft (Full output only)
        body_preview: Preview of the body content
        from_email: Sender email address
        from_name: Sender display name
        has_attachments: Whether the draft has attachments
        message_id: The ID of the draft
        raw_data: Raw API response data
        subject: The subject of the draft
        to_emails: List of recipient email addresses
        to_names: List of recipient display names
    ### When action = 'list_folder_messages'
        bcc_emails: List of BCC recipient email addresses
        cc_emails: List of CC recipient email addresses
        from_emails: List of sender email addresses
        from_names: List of sender display names
        has_attachments: List indicating which messages have attachments
        message_ids: List of message IDs
        messages_count: Total number of messages returned
        raw_data: Raw API response data
        subjects: List of message subjects
        to_emails: List of recipient email addresses
    ### When action = 'get_folder'
        child_folder_count: Number of child folders
        display_name: The display name of the folder
        folder_id: The ID of the folder
        parent_folder_id: The ID of the parent folder
        raw_data: Raw API response data
        total_item_count: Total number of items in the folder
        unread_item_count: Number of unread items in the folder
    ### When action = 'list_folders'
        child_folder_counts: List of child folder counts
        folder_ids: List of folder IDs
        folder_names: List of folder display names
        folders_count: Total number of folders returned
        parent_folder_ids: List of parent folder IDs
        raw_data: Raw API response data
        total_item_counts: List of total item counts
        unread_item_counts: List of unread item counts
    ### When action = 'create_contact'
        contact_id: The ID of the created contact
        display_name: The display name of the contact
        raw_data: Raw API response data
    ### When action = 'get_contact'
        contact_id: The ID of the contact
        display_name: The display name of the contact
        given_name: The first name of the contact
        raw_data: Raw API response data
        surname: The last name of the contact
    ### When action = 'update_contact'
        contact_id: The ID of the updated contact
        display_name: The display name of the contact
        raw_data: Raw API response data
    ### When action = 'delete_contact'
        contact_id: The ID of the deleted contact
        raw_data: Raw API response data
    ### When action = 'list_contacts'
        contact_ids: List of contact IDs
        display_names: List of display names
        email_addresses: List of email addresses
        raw_data: Raw API response data
    ### When action = 'create_folder'
        display_name: The display name of the created folder
        folder_id: The ID of the created folder
        raw_data: Raw API response data
    ### When action = 'update_folder'
        display_name: The updated display name of the folder
        folder_id: The ID of the updated folder
        raw_data: Raw API response data
    ### When action = 'get_user'
        display_name: The user's display name
        email: The user's email address
        id: The unique ID of the user
        job_title: The user's job title
        mobile_phone: The user's mobile phone number
        office_location: The user's office location
        raw_data: Complete response from Microsoft Graph API
        user_principal_name: The primary sign-in name for the user
    ### When action = 'create_draft'
        draft_id: The ID of the created draft
        output: Success message
        raw_data: Raw API response data
    ### When action = 'draft_reply'
        draft_id: The ID of the created draft reply
        output: Success message
        raw_data: Raw API response data
    ### When action = 'update_draft'
        draft_id: The ID of the updated draft
        raw_data: Raw API response data
    ### When action = 'update_message'
        message_id: The ID of the updated message
        raw_data: Raw API response data
    ### When action = 'move_message'
        message_id: The ID of the moved message
        raw_data: Raw API response data
    ### When action = 'send_email'
        output: Success message
        raw_data: Raw API response data
    ### When action = 'send_reply'
        output: Success message
        raw_data: Raw API response data
    ### When action = 'list_people'
        person_departments: List of person departments
        person_emails: List of person email addresses
        person_ids: List of person IDs
        person_job_titles: List of person job titles
        person_names: List of person display names
        raw_data: Complete response from Microsoft Graph API
        total_count: Total number of people returned
    ### When action = 'delete_message'
        raw_data: Raw API response data
    ### When action = 'send_draft'
        raw_data: Raw API response data
    ### When action = 'delete_draft'
        raw_data: Raw API response data
    ### When action = 'delete_folder'
        raw_data: Raw API response data
    ### When action = 'list_users'
        raw_data: Complete response from Microsoft Graph API
        total_count: Total number of users returned
        user_emails: List of user email addresses
        user_ids: List of user IDs
        user_names: List of user display names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Outlook>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "send_email**(*)**(*)": {
            "inputs": [
                {
                    "field": "recipients",
                    "type": "string",
                    "value": "",
                    "label": "Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails",
                },
                {
                    "field": "cc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "CC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the CC recipients' emails",
                },
                {
                    "field": "bcc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "BCC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the BCC recipients' emails",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Introduction to John",
                    "helper_text": "The subject of the email",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                },
            ],
            "outputs": [
                {"field": "output", "type": "string", "helper_text": "Success message"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_email",
            "task_name": "tasks.outlook.send_email",
            "description": "Create and send a new email",
            "label": "Send Email",
            "ui_sort_order": [
                "integration",
                "action",
                "recipients",
                "cc_recipients",
                "bcc_recipients",
                "subject",
                "format",
                "body",
                "attachments",
            ],
            "required": ["recipients", "subject", "body"],
        },
        "send_reply**(*)**(*)": {
            "inputs": [
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "email_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "AAMkAGI2TG93AAA=",
                    "helper_text": "The ID of the email to reply to",
                },
                {
                    "field": "cc_recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Cc recipients",
                    "placeholder": "cc1@company.com, cc2@company.com",
                    "helper_text": "Carbon copy recipients who will receive a visible copy of the email (comma-separated)",
                },
                {
                    "field": "bcc_recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Bcc recipients",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)",
                },
                {
                    "field": "sender_name",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Name",
                    "placeholder": "John Doe",
                    "helper_text": "Custom name to display as the sender in the recipient's inbox",
                },
                {
                    "field": "reply_to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Reply To",
                    "placeholder": "replies@company.com",
                    "helper_text": "Alternative email address where replies should be sent instead of the sender's address",
                },
                {
                    "field": "reply_to_sender_only",
                    "type": "bool",
                    "value": False,
                    "label": "Reply to Sender Only",
                    "helper_text": "When enabled, ensures that replies go only to the sender, excluding CC or group recipients",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                },
            ],
            "outputs": [
                {"field": "output", "type": "string", "helper_text": "Success message"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "send_reply",
            "task_name": "tasks.outlook.send_reply",
            "description": "Create and send a new reply to an existing email",
            "label": "Send Reply",
            "component_config": {
                "components": [{"type": "file", "show_input_fields_by_default": True}]
            },
            "inputs_sort_order": [
                "integration",
                "action",
                "format",
                "recipients",
                "body",
                "email_id",
                "cc_recipients",
                "bcc_recipients",
                "sender_name",
                "reply_to",
                "reply_to_sender_only",
                "attachments",
            ],
            "required": ["email_id", "recipients", "body", "format"],
        },
        "read_email**(*)**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Mailbox",
                    "helper_text": "Select a mailbox to read emails from (optional - searches all messages if not specified)",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "order": 1,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                    "order": 2,
                },
                {
                    "field": "from",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Email",
                    "placeholder": "john@company.com",
                    "helper_text": "Filter emails from this sender address",
                },
                {
                    "field": "to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Recipient Email",
                    "placeholder": "alex@company.com",
                    "helper_text": "Filter emails sent to this address",
                },
                {
                    "field": "subject",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "urgent meeting",
                    "helper_text": "Search keywords in the subject",
                },
                {
                    "field": "has_attachment",
                    "type": "string",
                    "value": "Ignore",
                    "hidden": True,
                    "helper_text": "Filter by attachment presence",
                    "label": "Has Attachment",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Emails With Attachments", "value": "True"},
                            {"label": "Emails Without Attachments", "value": "False"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                },
                {
                    "field": "is_read",
                    "type": "string",
                    "value": "Ignore",
                    "hidden": True,
                    "helper_text": "Filter by read/unread status",
                    "label": "Is Read",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Read Emails", "value": "True"},
                            {"label": "Unread Emails", "value": "False"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                },
                {
                    "field": "importance",
                    "type": "string",
                    "value": "Ignore",
                    "hidden": True,
                    "helper_text": "Filter by importance level",
                    "label": "Importance",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High Importance", "value": "high"},
                            {"label": "Normal Importance", "value": "normal"},
                            {"label": "Low Importance", "value": "low"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                },
                {
                    "field": "query",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "placeholder": "from:xyz@email.com",
                    "helper_text": "Search using KQL syntax. Examples: 'xyz@email.com' (searches everywhere), 'from:xyz@email.com' (specific field). Supported fields: subject:, body:, from:, to:, cc:, bcc:. Use AND/OR to combine.",
                },
            ],
            "outputs": [
                {
                    "field": "email_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of the retrieved emails",
                },
                {
                    "field": "email_subjects",
                    "type": "vec<string>",
                    "helper_text": "The subjects of the retrieved emails",
                },
                {
                    "field": "email_dates",
                    "type": "vec<string>",
                    "helper_text": "The sent dates of the retrieved emails",
                },
                {
                    "field": "email_bodies",
                    "type": "vec<string>",
                    "helper_text": "The content of the retrieved emails",
                },
                {
                    "field": "sender_addresses",
                    "type": "vec<string>",
                    "helper_text": "The email addresses of the senders",
                },
                {
                    "field": "email_display_names",
                    "type": "vec<string>",
                    "helper_text": "The display names of the senders",
                },
                {
                    "field": "recipient_addresses",
                    "type": "vec<string>",
                    "helper_text": "The email addresses of the recipients",
                },
                {
                    "field": "cc_addresses",
                    "type": "vec<vec<string>>",
                    "helper_text": "The email addresses of the CC recipients",
                },
                {
                    "field": "bcc_addresses",
                    "type": "vec<vec<string>>",
                    "helper_text": "The email addresses of the BCC recipients",
                },
                {
                    "field": "attachments",
                    "type": "vec<vec<file>>",
                    "helper_text": "The attachments for each email",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "read_email",
            "task_name": "tasks.outlook.read_email",
            "description": "Get multiple emails",
            "label": "List Emails",
            "inputs_sort_order": [
                "integration",
                "action",
                "item_id",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "from",
                "to",
                "subject",
                "body",
                "has_attachment",
                "is_read",
                "importance",
                "query",
            ],
        },
        "read_email**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Emails",
                    "helper_text": "Specify the last n number of emails",
                    "hidden": True,
                    "order": 5,
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "project update",
                    "helper_text": "Search text in the email body. Note: Does not work when date filter is enabled.",
                },
            ],
            "outputs": [],
        },
        "read_email**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "hidden": True,
                    "order": 3,
                }
            ],
            "outputs": [],
        },
        "read_email**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                    "order": 4,
                }
            ],
            "outputs": [],
        },
        "read_email**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                    "order": 4,
                }
            ],
            "outputs": [],
        },
        "get_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to get",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "output",
                    "type": "string",
                    "value": "simple",
                    "label": "Output Format",
                    "helper_text": "Output format for the message data",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Simple", "value": "simple"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the message",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "The subject of the message",
                },
                {
                    "field": "body_preview",
                    "type": "string",
                    "helper_text": "Preview of the body content",
                },
                {
                    "field": "conversation_id",
                    "type": "string",
                    "helper_text": "The conversation ID",
                },
                {
                    "field": "from_email",
                    "type": "string",
                    "helper_text": "Sender email address",
                },
                {
                    "field": "from_name",
                    "type": "string",
                    "helper_text": "Sender display name",
                },
                {
                    "field": "to_emails",
                    "type": "vec<string>",
                    "helper_text": "List of recipient email addresses",
                },
                {
                    "field": "to_names",
                    "type": "vec<string>",
                    "helper_text": "List of recipient display names",
                },
                {
                    "field": "cc_emails",
                    "type": "vec<string>",
                    "helper_text": "List of CC recipient email addresses",
                },
                {
                    "field": "cc_names",
                    "type": "vec<string>",
                    "helper_text": "List of CC recipient display names",
                },
                {
                    "field": "bcc_emails",
                    "type": "vec<string>",
                    "helper_text": "List of BCC recipient email addresses",
                },
                {
                    "field": "bcc_names",
                    "type": "vec<string>",
                    "helper_text": "List of BCC recipient display names",
                },
                {
                    "field": "has_attachments",
                    "type": "bool",
                    "helper_text": "Whether the message has attachments",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "helper_text": "The attachments for the message (Full output only)",
                },
                {
                    "field": "categories",
                    "type": "vec<string>",
                    "helper_text": "List of categories assigned to the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_message",
            "task_name": "tasks.outlook.get_message",
            "description": "Read details of a specific message",
            "label": "Get Message",
            "inputs_sort_order": ["integration", "action", "message_id", "output"],
            "required": ["message_id", "output"],
        },
        "update_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to update",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "importance",
                    "type": "string",
                    "value": "",
                    "label": "Importance",
                    "helper_text": "Change the message importance level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "low"},
                            {"label": "Normal", "value": "normal"},
                            {"label": "High", "value": "high"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "is_read",
                    "type": "bool",
                    "value": False,
                    "label": "Mark as Read",
                    "helper_text": "Mark the message as read or unread",
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "label": "Move to Folder",
                    "placeholder": "Optional folder ID",
                    "helper_text": "ID of the folder to move the message to (leave empty to keep in current folder)",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the updated message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_message",
            "task_name": "tasks.outlook.update_message",
            "description": "Update message properties",
            "label": "Update Message Properties",
            "ui_sort_order": [
                "integration",
                "action",
                "message_id",
                "importance",
                "is_read",
                "destination_folder_id",
            ],
            "required": ["message_id"],
        },
        "move_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "label": "Destination Folder ID",
                    "helper_text": "Select the destination folder",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to move",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the moved message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "move_message",
            "task_name": "tasks.outlook.move_message",
            "description": "Move a message to a different folder",
            "label": "Move Message",
            "ui_sort_order": [
                "integration",
                "action",
                "message_id",
                "destination_folder_id",
            ],
            "required": ["message_id", "destination_folder_id"],
        },
        "delete_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to delete",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_message",
            "task_name": "tasks.outlook.delete_message",
            "description": "Delete a message",
            "label": "Delete Message",
            "ui_sort_order": ["integration", "action", "message_id"],
            "required": ["message_id"],
        },
        "create_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "recipients",
                    "type": "string",
                    "value": "",
                    "label": "Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails",
                },
                {
                    "field": "cc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "CC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the CC recipients' emails",
                },
                {
                    "field": "bcc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "BCC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the BCC recipients' emails",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Introduction to John",
                    "helper_text": "The subject of the email",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                },
            ],
            "outputs": [
                {"field": "output", "type": "string", "helper_text": "Success message"},
                {
                    "field": "draft_id",
                    "type": "string",
                    "helper_text": "The ID of the created draft",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_draft",
            "task_name": "tasks.outlook.create_email_draft",
            "description": "Create (but do not send) a new email draft",
            "label": "Create Email Draft",
            "ui_sort_order": [
                "integration",
                "action",
                "recipients",
                "cc_recipients",
                "bcc_recipients",
                "subject",
                "format",
                "body",
                "attachments",
            ],
            "required": ["recipients", "subject", "body"],
        },
        "draft_reply**(*)**(*)": {
            "inputs": [
                {
                    "field": "email_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the email to reply to (often used in conjunction with a trigger where the email ID is received from the trigger)",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "recipients",
                    "type": "string",
                    "value": "",
                    "label": "Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails",
                },
                {
                    "field": "cc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "CC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the CC recipients' emails",
                },
                {
                    "field": "bcc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "BCC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the BCC recipients' emails",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                },
            ],
            "outputs": [
                {"field": "output", "type": "string", "helper_text": "Success message"},
                {
                    "field": "draft_id",
                    "type": "string",
                    "helper_text": "The ID of the created draft reply",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "draft_reply",
            "task_name": "tasks.outlook.draft_reply",
            "description": "Create (but do not send) a draft of a reply to an existing email",
            "label": "Draft Reply",
            "ui_sort_order": [
                "integration",
                "action",
                "email_id",
                "recipients",
                "cc_recipients",
                "bcc_recipients",
                "format",
                "body",
                "attachments",
            ],
            "required": ["email_id", "recipients", "body"],
        },
        "get_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the draft message to get",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "output",
                    "type": "string",
                    "value": "simple",
                    "label": "Output Format",
                    "helper_text": "Output format for the draft data",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Simple", "value": "simple"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the draft",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "The subject of the draft",
                },
                {
                    "field": "body_preview",
                    "type": "string",
                    "helper_text": "Preview of the body content",
                },
                {
                    "field": "from_email",
                    "type": "string",
                    "helper_text": "Sender email address",
                },
                {
                    "field": "from_name",
                    "type": "string",
                    "helper_text": "Sender display name",
                },
                {
                    "field": "to_emails",
                    "type": "vec<string>",
                    "helper_text": "List of recipient email addresses",
                },
                {
                    "field": "to_names",
                    "type": "vec<string>",
                    "helper_text": "List of recipient display names",
                },
                {
                    "field": "has_attachments",
                    "type": "bool",
                    "helper_text": "Whether the draft has attachments",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "helper_text": "The attachments for the draft (Full output only)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_draft",
            "task_name": "tasks.outlook.get_draft",
            "description": "Read details of a specific draft",
            "label": "Get Draft",
            "inputs_sort_order": ["integration", "action", "message_id", "output"],
            "required": ["message_id", "output"],
        },
        "update_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the draft message to update",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Updated subject",
                    "helper_text": "New subject for the draft",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Updated body content",
                    "helper_text": "New body content for the draft",
                },
                {
                    "field": "body_content_type",
                    "type": "string",
                    "value": "html",
                    "label": "Body Content Type",
                    "helper_text": "Content type for the body",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "HTML", "value": "html"},
                            {"label": "Text", "value": "text"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "to_recipients",
                    "type": "string",
                    "value": "",
                    "label": "To Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "Comma-separated list of recipient emails",
                },
                {
                    "field": "cc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "CC Recipients",
                    "placeholder": "cc@company.com",
                    "helper_text": "Comma-separated list of CC recipient emails",
                },
                {
                    "field": "bcc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "BCC Recipients",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Comma-separated list of BCC recipient emails",
                },
                {
                    "field": "importance",
                    "type": "string",
                    "value": "",
                    "label": "Importance",
                    "helper_text": "Message importance level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "low"},
                            {"label": "Normal", "value": "normal"},
                            {"label": "High", "value": "high"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "is_read",
                    "type": "bool",
                    "value": False,
                    "label": "Is Read",
                    "helper_text": "Mark the draft as read/unread",
                },
                {
                    "field": "is_read_receipt_requested",
                    "type": "bool",
                    "value": False,
                    "label": "Request Read Receipt",
                    "helper_text": "Request a read receipt for this message",
                },
            ],
            "outputs": [
                {
                    "field": "draft_id",
                    "type": "string",
                    "helper_text": "The ID of the updated draft",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_draft",
            "task_name": "tasks.outlook.update_draft",
            "description": "Update an existing draft message",
            "label": "Update Draft",
            "ui_sort_order": [
                "integration",
                "action",
                "message_id",
                "subject",
                "body",
                "body_content_type",
                "to_recipients",
                "cc_recipients",
                "bcc_recipients",
                "importance",
                "is_read",
                "is_read_receipt_requested",
            ],
            "required": ["message_id"],
        },
        "send_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the draft message to send",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "to",
                    "type": "string",
                    "value": "",
                    "label": "To Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "Optional: Update recipients before sending",
                },
                {
                    "field": "cc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "CC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "Optional: Update recipients before sending",
                },
                {
                    "field": "bcc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "BCC Recipients",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "Optional: Update recipients before sending",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_file_nodes",
            "name": "send_draft",
            "task_name": "tasks.outlook.send_draft",
            "description": "Send an existing draft message",
            "label": "Send Draft",
            "ui_sort_order": [
                "integration",
                "action",
                "message_id",
                "to",
                "cc_recipients",
                "bcc_recipients",
            ],
            "required": ["message_id"],
        },
        "delete_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the draft message to delete",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_draft",
            "task_name": "tasks.outlook.delete_draft",
            "description": "Delete a draft message",
            "label": "Delete Draft",
            "ui_sort_order": ["integration", "action", "message_id"],
            "required": ["message_id"],
        },
        "create_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "label": "Display Name",
                    "placeholder": "My New Folder",
                    "helper_text": "The name of the folder to create",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "label": "Parent Folder ID",
                    "placeholder": "Optional parent folder ID",
                    "helper_text": "ID of the parent folder (optional, creates in root if not provided)",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "The ID of the created folder",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name of the created folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.outlook.create_folder",
            "description": "Create a new mail folder",
            "label": "Create Folder",
            "ui_sort_order": [
                "integration",
                "action",
                "display_name",
                "parent_folder_id",
            ],
            "required": ["display_name"],
        },
        "get_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "label": "Mailbox",
                    "helper_text": "Select a mailbox to read",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "order": 1,
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields",
                    "placeholder": "Additional fields to return",
                    "helper_text": "Comma-separated list of additional fields to return",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "The ID of the folder",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name of the folder",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "The ID of the parent folder",
                },
                {
                    "field": "child_folder_count",
                    "type": "int32",
                    "helper_text": "Number of child folders",
                },
                {
                    "field": "unread_item_count",
                    "type": "int32",
                    "helper_text": "Number of unread items in the folder",
                },
                {
                    "field": "total_item_count",
                    "type": "int32",
                    "helper_text": "Total number of items in the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_folder",
            "task_name": "tasks.outlook.get_folder",
            "description": "Read details of a specific mail folder",
            "label": "Get Folder",
            "inputs_sort_order": ["integration", "action", "folder_id", "fields"],
            "required": ["folder_id"],
        },
        "list_folders**(*)**(*)": {
            "inputs": [
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "label": "Parent Folder ID",
                    "placeholder": "Optional parent folder ID",
                    "helper_text": "ID of the parent folder to list children from (optional, lists root folders if not provided)",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields",
                    "placeholder": "Additional fields to return",
                    "helper_text": "Comma-separated list of additional fields to return",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "displayName eq 'Inbox'",
                    "helper_text": "OData filter expression",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of folders to return (0 for no limit)",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all folders (ignores limit)",
                },
            ],
            "outputs": [
                {
                    "field": "folder_ids",
                    "type": "vec<string>",
                    "helper_text": "List of folder IDs",
                },
                {
                    "field": "folder_names",
                    "type": "vec<string>",
                    "helper_text": "List of folder display names",
                },
                {
                    "field": "parent_folder_ids",
                    "type": "vec<string>",
                    "helper_text": "List of parent folder IDs",
                },
                {
                    "field": "child_folder_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of child folder counts",
                },
                {
                    "field": "unread_item_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of unread item counts",
                },
                {
                    "field": "total_item_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of total item counts",
                },
                {
                    "field": "folders_count",
                    "type": "int32",
                    "helper_text": "Total number of folders returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_folders",
            "task_name": "tasks.outlook.list_folders",
            "description": "Get multiple mail folders",
            "label": "List Folders",
            "inputs_sort_order": [
                "integration",
                "action",
                "parent_folder_id",
                "fields",
                "filter",
                "limit",
                "return_all",
            ],
        },
        "list_folder_messages**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "label": "Mailbox",
                    "helper_text": "Select a mailbox to read messages from",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "order": 1,
                },
                {
                    "field": "output",
                    "type": "string",
                    "value": "simple",
                    "label": "Output Format",
                    "helper_text": "Output format for the message data",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Simple", "value": "simple"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields",
                    "placeholder": "Additional fields to return",
                    "helper_text": "Comma-separated list of additional fields to return (when output is 'full')",
                },
                {
                    "field": "search",
                    "type": "string",
                    "value": "",
                    "label": "Search",
                    "placeholder": "search term",
                    "helper_text": "Search term to filter messages",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "isRead eq false",
                    "helper_text": "OData filter expression",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of messages to return (0 for no limit)",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all messages (ignores limit)",
                },
            ],
            "outputs": [
                {
                    "field": "message_ids",
                    "type": "vec<string>",
                    "helper_text": "List of message IDs",
                },
                {
                    "field": "subjects",
                    "type": "vec<string>",
                    "helper_text": "List of message subjects",
                },
                {
                    "field": "from_emails",
                    "type": "vec<string>",
                    "helper_text": "List of sender email addresses",
                },
                {
                    "field": "from_names",
                    "type": "vec<string>",
                    "helper_text": "List of sender display names",
                },
                {
                    "field": "to_emails",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of recipient email addresses",
                },
                {
                    "field": "cc_emails",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of CC recipient email addresses",
                },
                {
                    "field": "bcc_emails",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of BCC recipient email addresses",
                },
                {
                    "field": "has_attachments",
                    "type": "vec<bool>",
                    "helper_text": "List indicating which messages have attachments",
                },
                {
                    "field": "messages_count",
                    "type": "int32",
                    "helper_text": "Total number of messages returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "list_folder_messages",
            "task_name": "tasks.outlook.list_folder_messages",
            "description": "Get multiple messages in a specific folder",
            "label": "List Folder Messages",
            "inputs_sort_order": [
                "integration",
                "action",
                "folder_id",
                "output",
                "fields",
                "search",
                "filter",
                "limit",
                "return_all",
            ],
            "required": ["folder_id"],
        },
        "update_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "label": "Mailbox",
                    "helper_text": "Select a mailbox to update",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "order": 1,
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "label": "Display Name",
                    "placeholder": "New folder name",
                    "helper_text": "The new name for the folder",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "The ID of the updated folder",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The updated display name of the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_folder",
            "task_name": "tasks.outlook.update_folder",
            "description": "Update a mail folder",
            "label": "Update Folder",
            "ui_sort_order": ["integration", "action", "folder_id", "display_name"],
            "required": ["folder_id", "display_name"],
        },
        "delete_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "label": "Mailbox",
                    "helper_text": "Select a mailbox to delete",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "order": 1,
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_folder",
            "task_name": "tasks.outlook.delete_folder",
            "description": "Delete a mail folder",
            "label": "Delete Folder",
            "ui_sort_order": ["integration", "action", "folder_id"],
            "required": ["folder_id"],
        },
        "add_message_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to add attachment to",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "attachment",
                    "type": "file",
                    "value": "",
                    "label": "Attachment",
                    "helper_text": "The file to attach to the message",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "The ID of the added attachment",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "add_message_attachment",
            "task_name": "tasks.outlook.add_message_attachment",
            "description": "Add an attachment to a message",
            "label": "Add Attachment to Email",
            "inputs_sort_order": ["integration", "action", "message_id", "attachment"],
            "required": ["message_id", "attachment"],
        },
        "get_message_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to get attachment from",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "placeholder": "Attachment ID",
                    "helper_text": "The ID of the attachment to retrieve",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "id,name,contentType",
                    "helper_text": "Comma-separated list of specific fields to return",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "The ID of the attachment",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the attachment",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "The MIME type of the attachment",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "The size of the attachment in bytes",
                },
                {
                    "field": "is_inline",
                    "type": "bool",
                    "helper_text": "Whether the attachment is inline",
                },
                {
                    "field": "last_modified_date_time",
                    "type": "string",
                    "helper_text": "Last modified date and time",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_message_attachment",
            "task_name": "tasks.outlook.get_message_attachment",
            "description": "Read details of a specific attachment",
            "label": "Get Message Attachment",
            "inputs_sort_order": [
                "integration",
                "action",
                "message_id",
                "attachment_id",
                "fields",
            ],
            "required": ["message_id", "attachment_id"],
        },
        "list_message_attachments**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to get attachments from",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "id,name,contentType",
                    "helper_text": "Comma-separated list of specific fields to return",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of attachments to return (0 for no limit)",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all attachments (ignores limit)",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of attachment IDs",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names",
                },
                {
                    "field": "content_types",
                    "type": "vec<string>",
                    "helper_text": "List of attachment MIME types",
                },
                {
                    "field": "sizes",
                    "type": "vec<int32>",
                    "helper_text": "List of attachment sizes in bytes",
                },
                {
                    "field": "is_inline_list",
                    "type": "vec<bool>",
                    "helper_text": "List indicating which attachments are inline",
                },
                {
                    "field": "last_modified_date_times",
                    "type": "vec<string>",
                    "helper_text": "List of last modified date times",
                },
                {
                    "field": "attachments_count",
                    "type": "int32",
                    "helper_text": "Total number of attachments returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "list_message_attachments",
            "task_name": "tasks.outlook.list_message_attachments",
            "description": "Get multiple message attachments",
            "label": "List Message Attachments",
            "inputs_sort_order": [
                "integration",
                "action",
                "message_id",
                "fields",
                "limit",
                "return_all",
            ],
            "required": ["message_id"],
        },
        "download_message_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "label": "Message",
                    "helper_text": "Select the message to download attachment from",
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "placeholder": "Attachment ID",
                    "helper_text": "The ID of the attachment to download",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "The ID of the downloaded attachment",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "The name of the downloaded file",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "The MIME type of the file",
                },
                {
                    "field": "file_data",
                    "type": "file",
                    "helper_text": "The downloaded file data",
                },
                {
                    "field": "content_size",
                    "type": "int32",
                    "helper_text": "The size of the downloaded content in bytes",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "download_message_attachment",
            "task_name": "tasks.outlook.download_message_attachment",
            "description": "Download an attachment from a message",
            "label": "Download Message Attachment",
            "ui_sort_order": ["integration", "action", "message_id", "attachment_id"],
            "required": ["message_id", "attachment_id"],
        },
        "create_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "The first name of the contact",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "The last name of the contact",
                },
                {
                    "field": "middle_name",
                    "type": "string",
                    "value": "",
                    "label": "Middle Name",
                    "placeholder": "Michael",
                    "helper_text": "The middle name of the contact",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "label": "Display Name",
                    "placeholder": "John Doe",
                    "helper_text": "The display name of the contact (auto-generated if not provided)",
                },
                {
                    "field": "nickname",
                    "type": "string",
                    "value": "",
                    "label": "Nickname",
                    "placeholder": "Johnny",
                    "helper_text": "Nickname of the contact",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Mr.",
                    "helper_text": "Title of the contact (e.g., Mr., Mrs., Dr.)",
                },
                {
                    "field": "initials",
                    "type": "string",
                    "value": "",
                    "label": "Initials",
                    "placeholder": "J.D.",
                    "helper_text": "Initials of the contact",
                },
                {
                    "field": "file_as",
                    "type": "string",
                    "value": "",
                    "label": "File As",
                    "placeholder": "Doe, John",
                    "helper_text": "How to file the contact",
                },
                {
                    "field": "email_addresses",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "placeholder": "john@example.com, john.doe@work.com",
                    "helper_text": "Comma-separated list of email addresses",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "label": "Mobile Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "The mobile phone number",
                },
                {
                    "field": "business_phones",
                    "type": "string",
                    "value": "",
                    "label": "Business Phone",
                    "placeholder": "+1234567890, +0987654321",
                    "helper_text": "Comma-separated list of business phone numbers",
                },
                {
                    "field": "home_phones",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "Comma-separated list of home phone numbers",
                },
                {
                    "field": "im_addresses",
                    "type": "string",
                    "value": "",
                    "label": "Instant Messaging Addresses",
                    "placeholder": "john@skype, john.doe@teams",
                    "helper_text": "Comma-separated list of instant messaging addresses",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Software Engineer",
                    "helper_text": "The job title",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Corp",
                    "helper_text": "The company name",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Engineering",
                    "helper_text": "The department",
                },
                {
                    "field": "office_location",
                    "type": "string",
                    "value": "",
                    "label": "Office Location",
                    "placeholder": "Building 1, Floor 3",
                    "helper_text": "The office location",
                },
                {
                    "field": "profession",
                    "type": "string",
                    "value": "",
                    "label": "Profession",
                    "placeholder": "Engineer",
                    "helper_text": "The profession",
                },
                {
                    "field": "manager",
                    "type": "string",
                    "value": "",
                    "label": "Manager",
                    "placeholder": "Jane Smith",
                    "helper_text": "Manager's name",
                },
                {
                    "field": "birthday",
                    "type": "timestamp",
                    "value": "",
                    "label": "Birthday",
                    "placeholder": "1990-01-15",
                    "helper_text": "Birthday date",
                },
                {
                    "field": "spouse_name",
                    "type": "string",
                    "value": "",
                    "label": "Spouse Name",
                    "placeholder": "Jane Doe",
                    "helper_text": "Name of the spouse",
                },
                {
                    "field": "children",
                    "type": "string",
                    "value": "",
                    "label": "Children",
                    "placeholder": "Alice, Bob",
                    "helper_text": "Comma-separated list of children's names",
                },
                {
                    "field": "business_home_page",
                    "type": "string",
                    "value": "",
                    "label": "Business Home Page",
                    "placeholder": "https://www.example.com",
                    "helper_text": "Company or business website URL",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Notes",
                    "placeholder": "Additional notes about the contact",
                    "helper_text": "Personal notes about the contact",
                },
                {
                    "field": "categories",
                    "type": "string",
                    "value": "",
                    "label": "Categories",
                    "placeholder": "Client, VIP",
                    "helper_text": "Comma-separated list of categories",
                },
                {
                    "field": "business_address_street",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Business street address",
                },
                {
                    "field": "business_address_city",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - City",
                    "placeholder": "San Francisco",
                    "helper_text": "Business address city",
                },
                {
                    "field": "business_address_state",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - State",
                    "placeholder": "CA",
                    "helper_text": "Business address state/province",
                },
                {
                    "field": "business_address_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - Postal Code",
                    "placeholder": "94102",
                    "helper_text": "Business address postal/ZIP code",
                },
                {
                    "field": "business_address_country",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Business address country",
                },
                {
                    "field": "home_address_street",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Home street address",
                },
                {
                    "field": "home_address_city",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - City",
                    "placeholder": "Berkeley",
                    "helper_text": "Home address city",
                },
                {
                    "field": "home_address_state",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - State",
                    "placeholder": "CA",
                    "helper_text": "Home address state/province",
                },
                {
                    "field": "home_address_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - Postal Code",
                    "placeholder": "94704",
                    "helper_text": "Home address postal/ZIP code",
                },
                {
                    "field": "home_address_country",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Home address country",
                },
                {
                    "field": "other_address_street",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - Street",
                    "placeholder": "789 Pine Rd",
                    "helper_text": "Other street address",
                },
                {
                    "field": "other_address_city",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - City",
                    "placeholder": "Palo Alto",
                    "helper_text": "Other address city",
                },
                {
                    "field": "other_address_state",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - State",
                    "placeholder": "CA",
                    "helper_text": "Other address state/province",
                },
                {
                    "field": "other_address_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - Postal Code",
                    "placeholder": "94301",
                    "helper_text": "Other address postal/ZIP code",
                },
                {
                    "field": "other_address_country",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Other address country",
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "The ID of the created contact",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name of the contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_contact",
            "task_name": "tasks.outlook.create_contact",
            "description": "Create a new contact in Outlook",
            "label": "Create Contact",
            "inputs_sort_order": [
                "integration",
                "action",
                "first_name",
                "last_name",
                "middle_name",
                "display_name",
                "nickname",
                "title",
                "initials",
                "file_as",
                "email_addresses",
                "mobile_phone",
                "business_phones",
                "home_phones",
                "im_addresses",
                "job_title",
                "company_name",
                "department",
                "office_location",
                "profession",
                "manager",
                "birthday",
                "spouse_name",
                "children",
                "business_home_page",
                "notes",
                "categories",
                "business_address_street",
                "business_address_city",
                "business_address_state",
                "business_address_postal_code",
                "business_address_country",
                "home_address_street",
                "home_address_city",
                "home_address_state",
                "home_address_postal_code",
                "home_address_country",
                "other_address_street",
                "other_address_city",
                "other_address_state",
                "other_address_postal_code",
                "other_address_country",
            ],
            "required": ["first_name", "last_name"],
        },
        "get_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact",
                    "placeholder": "Select contact",
                    "helper_text": "Select the contact to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "The ID of the contact",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name of the contact",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "helper_text": "The first name of the contact",
                },
                {
                    "field": "surname",
                    "type": "string",
                    "helper_text": "The last name of the contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_contact",
            "task_name": "tasks.outlook.get_contact",
            "description": "Read details of a contact",
            "label": "Get Contact",
            "inputs_sort_order": ["integration", "action", "contact_id"],
            "required": ["contact_id"],
        },
        "list_contacts**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all contacts (ignore limit)",
                },
                {
                    "field": "contact_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of contacts to return",
                },
                {
                    "field": "filter_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter Query",
                    "placeholder": "displayName eq 'John Doe'",
                    "helper_text": "OData filter expression to filter contacts (e.g., startswith(displayName,'John'))",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "placeholder": "user@example.com",
                    "helper_text": "Filter by specific email address",
                },
            ],
            "outputs": [
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "List of contact IDs",
                },
                {
                    "field": "display_names",
                    "type": "vec<string>",
                    "helper_text": "List of display names",
                },
                {
                    "field": "email_addresses",
                    "type": "vec<string>",
                    "helper_text": "List of email addresses",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_contacts",
            "task_name": "tasks.outlook.list_contacts",
            "description": "Get multiple contacts",
            "label": "List Contacts",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "contact_limit",
                "filter_query",
                "email_address",
            ],
        },
        "update_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact",
                    "placeholder": "Select contact",
                    "helper_text": "Select the contact to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "middle_name",
                    "type": "string",
                    "value": "",
                    "label": "Middle Name",
                    "placeholder": "Michael",
                    "helper_text": "The middle name of the contact",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "label": "Display Name",
                    "placeholder": "John Doe",
                    "helper_text": "The display name of the contact",
                },
                {
                    "field": "nickname",
                    "type": "string",
                    "value": "",
                    "label": "Nickname",
                    "placeholder": "Johnny",
                    "helper_text": "Nickname of the contact",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Mr.",
                    "helper_text": "Title of the contact (e.g., Mr., Mrs., Dr.)",
                },
                {
                    "field": "initials",
                    "type": "string",
                    "value": "",
                    "label": "Initials",
                    "placeholder": "J.D.",
                    "helper_text": "Initials of the contact",
                },
                {
                    "field": "file_as",
                    "type": "string",
                    "value": "",
                    "label": "File As",
                    "placeholder": "Doe, John",
                    "helper_text": "How to file the contact",
                },
                {
                    "field": "email_addresses",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "placeholder": "john@example.com, john.doe@work.com",
                    "helper_text": "Comma-separated list of email addresses",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "label": "Mobile Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "The mobile phone number",
                },
                {
                    "field": "business_phones",
                    "type": "string",
                    "value": "",
                    "label": "Business Phone",
                    "placeholder": "+1234567890, +0987654321",
                    "helper_text": "Comma-separated list of business phone numbers",
                },
                {
                    "field": "home_phones",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "Comma-separated list of home phone numbers",
                },
                {
                    "field": "im_addresses",
                    "type": "string",
                    "value": "",
                    "label": "Instant Messaging Addresses",
                    "placeholder": "john@skype, john.doe@teams",
                    "helper_text": "Comma-separated list of instant messaging addresses",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Software Engineer",
                    "helper_text": "The job title",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Corp",
                    "helper_text": "The company name",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Engineering",
                    "helper_text": "The department",
                },
                {
                    "field": "office_location",
                    "type": "string",
                    "value": "",
                    "label": "Office Location",
                    "placeholder": "Building 1, Floor 3",
                    "helper_text": "The office location",
                },
                {
                    "field": "profession",
                    "type": "string",
                    "value": "",
                    "label": "Profession",
                    "placeholder": "Engineer",
                    "helper_text": "The profession",
                },
                {
                    "field": "manager",
                    "type": "string",
                    "value": "",
                    "label": "Manager",
                    "placeholder": "Jane Smith",
                    "helper_text": "Manager's name",
                },
                {
                    "field": "birthday",
                    "type": "timestamp",
                    "value": "",
                    "label": "Birthday",
                    "placeholder": "1990-01-15",
                    "helper_text": "Birthday date",
                },
                {
                    "field": "spouse_name",
                    "type": "string",
                    "value": "",
                    "label": "Spouse Name",
                    "placeholder": "Jane Doe",
                    "helper_text": "Name of the spouse",
                },
                {
                    "field": "children",
                    "type": "string",
                    "value": "",
                    "label": "Children",
                    "placeholder": "Alice, Bob",
                    "helper_text": "Comma-separated list of children's names",
                },
                {
                    "field": "business_home_page",
                    "type": "string",
                    "value": "",
                    "label": "Business Home Page",
                    "placeholder": "https://www.example.com",
                    "helper_text": "Company or business website URL",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Notes",
                    "placeholder": "Additional notes about the contact",
                    "helper_text": "Personal notes about the contact",
                },
                {
                    "field": "categories",
                    "type": "string",
                    "value": "",
                    "label": "Categories",
                    "placeholder": "Client, VIP",
                    "helper_text": "Comma-separated list of categories",
                },
                {
                    "field": "business_address_street",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Business street address",
                },
                {
                    "field": "business_address_city",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - City",
                    "placeholder": "San Francisco",
                    "helper_text": "Business address city",
                },
                {
                    "field": "business_address_state",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - State",
                    "placeholder": "CA",
                    "helper_text": "Business address state/province",
                },
                {
                    "field": "business_address_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - Postal Code",
                    "placeholder": "94102",
                    "helper_text": "Business address postal/ZIP code",
                },
                {
                    "field": "business_address_country",
                    "type": "string",
                    "value": "",
                    "label": "Business Address - Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Business address country",
                },
                {
                    "field": "home_address_street",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Home street address",
                },
                {
                    "field": "home_address_city",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - City",
                    "placeholder": "Berkeley",
                    "helper_text": "Home address city",
                },
                {
                    "field": "home_address_state",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - State",
                    "placeholder": "CA",
                    "helper_text": "Home address state/province",
                },
                {
                    "field": "home_address_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - Postal Code",
                    "placeholder": "94704",
                    "helper_text": "Home address postal/ZIP code",
                },
                {
                    "field": "home_address_country",
                    "type": "string",
                    "value": "",
                    "label": "Home Address - Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Home address country",
                },
                {
                    "field": "other_address_street",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - Street",
                    "placeholder": "789 Pine Rd",
                    "helper_text": "Other street address",
                },
                {
                    "field": "other_address_city",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - City",
                    "placeholder": "Palo Alto",
                    "helper_text": "Other address city",
                },
                {
                    "field": "other_address_state",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - State",
                    "placeholder": "CA",
                    "helper_text": "Other address state/province",
                },
                {
                    "field": "other_address_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - Postal Code",
                    "placeholder": "94301",
                    "helper_text": "Other address postal/ZIP code",
                },
                {
                    "field": "other_address_country",
                    "type": "string",
                    "value": "",
                    "label": "Other Address - Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Other address country",
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "The ID of the updated contact",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name of the contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_contact",
            "task_name": "tasks.outlook.update_contact",
            "description": "Update a contact in Outlook",
            "label": "Update Contact",
            "inputs_sort_order": [
                "integration",
                "action",
                "contact_id",
                "middle_name",
                "display_name",
                "nickname",
                "title",
                "initials",
                "file_as",
                "email_addresses",
                "mobile_phone",
                "business_phones",
                "home_phones",
                "im_addresses",
                "job_title",
                "company_name",
                "department",
                "office_location",
                "profession",
                "manager",
                "birthday",
                "spouse_name",
                "children",
                "business_home_page",
                "notes",
                "categories",
                "business_address_street",
                "business_address_city",
                "business_address_state",
                "business_address_postal_code",
                "business_address_country",
                "home_address_street",
                "home_address_city",
                "home_address_state",
                "home_address_postal_code",
                "home_address_country",
                "other_address_street",
                "other_address_city",
                "other_address_state",
                "other_address_postal_code",
                "other_address_country",
            ],
            "required": ["contact_id"],
        },
        "delete_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact",
                    "placeholder": "Select contact",
                    "helper_text": "Select the contact to delete",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "The ID of the deleted contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_contact",
            "task_name": "tasks.outlook.delete_contact",
            "description": "Delete a contact from Outlook",
            "label": "Delete Contact",
            "inputs_sort_order": ["integration", "action", "contact_id"],
            "required": ["contact_id"],
        },
        "get_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_identifier",
                    "type": "string",
                    "value": "",
                    "label": "User ID or Email",
                    "placeholder": "user@company.com or user-id",
                    "helper_text": "The user's ID or organizational email (work/school accounts only, not personal @outlook.com/@hotmail.com)",
                }
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "The unique ID of the user",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The user's display name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "The user's email address",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "helper_text": "The user's job title",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "helper_text": "The user's mobile phone number",
                },
                {
                    "field": "office_location",
                    "type": "string",
                    "helper_text": "The user's office location",
                },
                {
                    "field": "user_principal_name",
                    "type": "string",
                    "helper_text": "The primary sign-in name for the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.outlook.get_user",
            "description": "Get details of a user from the organization directory",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "required": ["user_identifier"],
            "inputs_sort_order": ["integration", "action", "user_identifier"],
        },
        "list_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of users to retrieve",
                },
                {
                    "field": "search",
                    "type": "string",
                    "value": "",
                    "label": "Search",
                    "placeholder": "John",
                    "helper_text": "Search users by display name or email",
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user display names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user email addresses",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of users returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "list_users",
            "task_name": "tasks.outlook.list_users",
            "description": "List users from the organization directory",
            "label": "List Users",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": ["integration", "action", "limit", "search"],
        },
        "list_people**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of people to retrieve",
                },
                {
                    "field": "search",
                    "type": "string",
                    "value": "",
                    "label": "Search",
                    "placeholder": "John",
                    "helper_text": "Fuzzy search people by name or email (e.g. a name or email address).",
                },
                {
                    "field": "filter_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "personType/class eq 'Person'",
                    "helper_text": "Filter by person type. Examples: personType/class eq 'Person' (individuals), personType/class eq 'Group' (groups), personType/subclass eq 'OrganizationUser' (org members), personType/subclass eq 'PersonalContact' (personal contacts).",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "placeholder": "displayName",
                    "helper_text": "Field to sort results by (e.g. displayName). By default results are sorted by relevance.",
                },
            ],
            "outputs": [
                {
                    "field": "person_ids",
                    "type": "vec<string>",
                    "helper_text": "List of person IDs",
                },
                {
                    "field": "person_names",
                    "type": "vec<string>",
                    "helper_text": "List of person display names",
                },
                {
                    "field": "person_emails",
                    "type": "vec<string>",
                    "helper_text": "List of person email addresses",
                },
                {
                    "field": "person_departments",
                    "type": "vec<string>",
                    "helper_text": "List of person departments",
                },
                {
                    "field": "person_job_titles",
                    "type": "vec<string>",
                    "helper_text": "List of person job titles",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of people returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "list_people",
            "task_name": "tasks.outlook.list_people",
            "description": "List people relevant to the signed-in user based on communication patterns",
            "label": "List People",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "limit",
                "search",
                "filter_query",
                "order_by",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "limit"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        attachment: str = "",
        attachment_id: str = "",
        attachments: List[str] = [],
        bcc_recipients: str = "",
        birthday: Any = None,
        body: str = "",
        body_content_type: str = "html",
        business_address_city: str = "",
        business_address_country: str = "",
        business_address_postal_code: str = "",
        business_address_state: str = "",
        business_address_street: str = "",
        business_home_page: str = "",
        business_phones: str = "",
        categories: str = "",
        cc_recipients: str = "",
        children: str = "",
        company_name: str = "",
        contact_id: str = "",
        contact_limit: int = 10,
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        department: str = "",
        destination_folder_id: str = "",
        display_name: str = "",
        email_address: str = "",
        email_addresses: str = "",
        email_id: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        fields: str = "",
        file_as: str = "",
        filter: str = "",
        filter_query: str = "",
        first_name: str = "",
        folder_id: Optional[str] = None,
        format: str = "text",
        from_: str = "",
        has_attachment: str = "Ignore",
        home_address_city: str = "",
        home_address_country: str = "",
        home_address_postal_code: str = "",
        home_address_state: str = "",
        home_address_street: str = "",
        home_phones: str = "",
        im_addresses: str = "",
        importance: str = "Ignore",
        initials: str = "",
        is_read: str = "Ignore",
        is_read_receipt_requested: bool = False,
        item_id: str = "",
        job_title: str = "",
        last_name: str = "",
        limit: int = 10,
        manager: str = "",
        message_id: Optional[str] = None,
        middle_name: str = "",
        mobile_phone: str = "",
        nickname: str = "",
        notes: str = "",
        num_messages: int = 10,
        office_location: str = "",
        order_by: str = "",
        other_address_city: str = "",
        other_address_country: str = "",
        other_address_postal_code: str = "",
        other_address_state: str = "",
        other_address_street: str = "",
        output: str = "simple",
        parent_folder_id: str = "",
        profession: str = "",
        recipients: str = "",
        reply_to: str = "",
        reply_to_sender_only: bool = False,
        return_all: bool = False,
        search: str = "",
        sender_name: str = "",
        spouse_name: str = "",
        subject: str = "",
        title: str = "",
        to: str = "",
        to_recipients: str = "",
        user_identifier: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_outlook",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if recipients is not None:
            self.inputs["recipients"] = recipients
        if cc_recipients is not None:
            self.inputs["cc_recipients"] = cc_recipients
        if bcc_recipients is not None:
            self.inputs["bcc_recipients"] = bcc_recipients
        if subject is not None:
            self.inputs["subject"] = subject
        if body is not None:
            self.inputs["body"] = body
        if format is not None:
            self.inputs["format"] = format
        if attachments is not None:
            self.inputs["attachments"] = attachments
        if email_id is not None:
            self.inputs["email_id"] = email_id
        if sender_name is not None:
            self.inputs["sender_name"] = sender_name
        if reply_to is not None:
            self.inputs["reply_to"] = reply_to
        if reply_to_sender_only is not None:
            self.inputs["reply_to_sender_only"] = reply_to_sender_only
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if from_ is not None:
            self.inputs["from"] = from_
        if to is not None:
            self.inputs["to"] = to
        if has_attachment is not None:
            self.inputs["has_attachment"] = has_attachment
        if is_read is not None:
            self.inputs["is_read"] = is_read
        if importance is not None:
            self.inputs["importance"] = importance
        if query is not None:
            self.inputs["query"] = query
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if message_id is not None:
            self.inputs["message_id"] = message_id
        if output is not None:
            self.inputs["output"] = output
        if destination_folder_id is not None:
            self.inputs["destination_folder_id"] = destination_folder_id
        if body_content_type is not None:
            self.inputs["body_content_type"] = body_content_type
        if to_recipients is not None:
            self.inputs["to_recipients"] = to_recipients
        if is_read_receipt_requested is not None:
            self.inputs["is_read_receipt_requested"] = is_read_receipt_requested
        if display_name is not None:
            self.inputs["display_name"] = display_name
        if parent_folder_id is not None:
            self.inputs["parent_folder_id"] = parent_folder_id
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if fields is not None:
            self.inputs["fields"] = fields
        if filter is not None:
            self.inputs["filter"] = filter
        if limit is not None:
            self.inputs["limit"] = limit
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if search is not None:
            self.inputs["search"] = search
        if attachment is not None:
            self.inputs["attachment"] = attachment
        if attachment_id is not None:
            self.inputs["attachment_id"] = attachment_id
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if middle_name is not None:
            self.inputs["middle_name"] = middle_name
        if nickname is not None:
            self.inputs["nickname"] = nickname
        if title is not None:
            self.inputs["title"] = title
        if initials is not None:
            self.inputs["initials"] = initials
        if file_as is not None:
            self.inputs["file_as"] = file_as
        if email_addresses is not None:
            self.inputs["email_addresses"] = email_addresses
        if mobile_phone is not None:
            self.inputs["mobile_phone"] = mobile_phone
        if business_phones is not None:
            self.inputs["business_phones"] = business_phones
        if home_phones is not None:
            self.inputs["home_phones"] = home_phones
        if im_addresses is not None:
            self.inputs["im_addresses"] = im_addresses
        if job_title is not None:
            self.inputs["job_title"] = job_title
        if company_name is not None:
            self.inputs["company_name"] = company_name
        if department is not None:
            self.inputs["department"] = department
        if office_location is not None:
            self.inputs["office_location"] = office_location
        if profession is not None:
            self.inputs["profession"] = profession
        if manager is not None:
            self.inputs["manager"] = manager
        if birthday is not None:
            self.inputs["birthday"] = birthday
        if spouse_name is not None:
            self.inputs["spouse_name"] = spouse_name
        if children is not None:
            self.inputs["children"] = children
        if business_home_page is not None:
            self.inputs["business_home_page"] = business_home_page
        if notes is not None:
            self.inputs["notes"] = notes
        if categories is not None:
            self.inputs["categories"] = categories
        if business_address_street is not None:
            self.inputs["business_address_street"] = business_address_street
        if business_address_city is not None:
            self.inputs["business_address_city"] = business_address_city
        if business_address_state is not None:
            self.inputs["business_address_state"] = business_address_state
        if business_address_postal_code is not None:
            self.inputs["business_address_postal_code"] = business_address_postal_code
        if business_address_country is not None:
            self.inputs["business_address_country"] = business_address_country
        if home_address_street is not None:
            self.inputs["home_address_street"] = home_address_street
        if home_address_city is not None:
            self.inputs["home_address_city"] = home_address_city
        if home_address_state is not None:
            self.inputs["home_address_state"] = home_address_state
        if home_address_postal_code is not None:
            self.inputs["home_address_postal_code"] = home_address_postal_code
        if home_address_country is not None:
            self.inputs["home_address_country"] = home_address_country
        if other_address_street is not None:
            self.inputs["other_address_street"] = other_address_street
        if other_address_city is not None:
            self.inputs["other_address_city"] = other_address_city
        if other_address_state is not None:
            self.inputs["other_address_state"] = other_address_state
        if other_address_postal_code is not None:
            self.inputs["other_address_postal_code"] = other_address_postal_code
        if other_address_country is not None:
            self.inputs["other_address_country"] = other_address_country
        if contact_id is not None:
            self.inputs["contact_id"] = contact_id
        if contact_limit is not None:
            self.inputs["contact_limit"] = contact_limit
        if filter_query is not None:
            self.inputs["filter_query"] = filter_query
        if email_address is not None:
            self.inputs["email_address"] = email_address
        if user_identifier is not None:
            self.inputs["user_identifier"] = user_identifier
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if from_ is not None:
            self.inputs["from"] = from_
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationOutlookNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
