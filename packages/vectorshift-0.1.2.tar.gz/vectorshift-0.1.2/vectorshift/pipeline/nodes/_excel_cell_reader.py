"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("excel_cell_reader")
class ExcelCellReaderNode(Node):
    """
    Read data from an Excel cell.

    ## Inputs
    ### Common Inputs
        cell_index: The cell to read from.
        read_formatting: Whether to read the formatting of the cell.
        selected_file: The file to read from.
        sheet: The sheet to read from.

    ## Outputs
    ### Common Outputs
        cell_value: The value of the cell
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "cell_index",
            "helper_text": "The cell to read from.",
            "value": "",
            "type": "string",
        },
        {
            "field": "read_formatting",
            "helper_text": "Whether to read the formatting of the cell.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "selected_file",
            "helper_text": "The file to read from.",
            "value": None,
            "type": "file",
        },
        {
            "field": "sheet",
            "helper_text": "The sheet to read from.",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "cell_value",
            "helper_text": "The value of the cell",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["selected_file", "sheet", "cell_index"]

    def __init__(
        self,
        cell_index: str = "",
        read_formatting: bool = False,
        selected_file: Optional[str] = None,
        sheet: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="excel_cell_reader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if selected_file is not None:
            self.inputs["selected_file"] = selected_file
        if sheet is not None:
            self.inputs["sheet"] = sheet
        if cell_index is not None:
            self.inputs["cell_index"] = cell_index
        if read_formatting is not None:
            self.inputs["read_formatting"] = read_formatting
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ExcelCellReaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
