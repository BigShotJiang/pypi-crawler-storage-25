"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_supabase")
class IntegrationSupabaseNode(Node):
    """
    Supabase

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
        table_name: The name or ID of the table
    ### When action = 'insert_row' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'get_row' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'update_row' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'delete_row' and endpoint_0 = '[endpoint_0.<A>]' and build_manually = True
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'delete_row'
        build_manually: The build_manually input
    ### When action = 'list_rows'
        filter: PostgREST filter string. Use '&' for multiple conditions. Example: id=eq.1&name=like.*test*
        return_all: Return All will return all the rows
    ### When action = 'update_row'
        filter: PostgREST filter string. Use '&' for multiple conditions. Example: id=eq.1&name=like.*test*
    ### When action = 'delete_row' and build_manually = False
        filter: PostgREST filter string. Use '&' for multiple conditions. Example: id=eq.1&name=like.*test*
    ### When action = 'list_rows' and return_all = False
        limit: Maximum number of rows to return (default: 10)

    ## Outputs
    ### When action = 'insert_row'
        raw_data: Raw API response
    ### When action = 'get_row'
        raw_data: Raw API response
    ### When action = 'list_rows'
        raw_data: Raw API response
    ### When action = 'list_rows' and return_all = False
        raw_data: Raw API response
    ### When action = 'update_row'
        raw_data: Raw API response
    ### When action = 'delete_row'
        raw_data: Raw API response
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Supabase>",
        },
        {
            "field": "table_name",
            "helper_text": "The name or ID of the table",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "insert_row**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "insert_row",
            "task_name": "tasks.supabase.insert_row",
            "description": "Create a new row in a Supabase table",
            "label": "Create a row",
            "variant": "common_integration_nodes",
            "required": ["table_name"],
            "inputs_sort_order": ["integration", "action", "table_name"],
        },
        "insert_row**[endpoint_0.<A>]**(*)**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "get_row**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "get_row",
            "task_name": "tasks.supabase.get_row",
            "description": "Get row associated with matching filters",
            "label": "Get a row",
            "variant": "common_integration_nodes",
            "required": ["table_name"],
            "inputs_sort_order": ["integration", "action", "table_name"],
        },
        "get_row**[endpoint_0.<A>]**(*)**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "list_rows**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filters",
                    "placeholder": "id=eq.1&name=like.*test*",
                    "helper_text": "PostgREST filter string. Use '&' for multiple conditions. Example: id=eq.1&name=like.*test*",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "label": "Return all",
                    "helper_text": "Return All will return all the rows",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "list_rows",
            "task_name": "tasks.supabase.list_rows",
            "description": "List rows from a Supabase table using row fields for filtering",
            "label": "List Rows",
            "variant": "common_integration_nodes",
            "required": ["table_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "return_all",
                "limit",
                "filter",
            ],
        },
        "list_rows**(*)**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return (default: 10)",
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
        },
        "update_row**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Select Conditions",
                    "placeholder": "id=eq.1&name=like.*test*",
                    "helper_text": "PostgREST filter string. Use '&' for AND, and or=(...) for OR. Example: id=eq.1&name=like.*test*",
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "update_row",
            "task_name": "tasks.supabase.update_row",
            "description": "Update row in a Supabase table",
            "label": "Update a row",
            "variant": "common_integration_nodes",
            "required": ["table_name", "filter"],
            "inputs_sort_order": ["integration", "action", "table_name", "filter"],
        },
        "update_row**[endpoint_0.<A>]**(*)**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "delete_row**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "build_manually",
                    "type": "bool",
                    "value": "false",
                    "label": "Build Manually",
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "delete_row",
            "task_name": "tasks.supabase.delete_row",
            "description": "Delete rows from a Supabase table",
            "label": "Delete Row",
            "variant": "common_integration_nodes",
            "required": ["table_name", "filter"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "build_manually",
                "filter",
            ],
        },
        "delete_row**[endpoint_0.<A>]**(*)**true": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "delete_row**(*)**(*)**false": {
            "inputs": [
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Select Conditions",
                    "placeholder": "id=eq.1&name=eq.test",
                    "helper_text": "PostgREST filter string. Use '&' to combine conditions (e.g., id=eq.1&name=eq.test).",
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0", "return_all", "build_manually"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "table_name"]

    def __init__(
        self,
        action: str = "",
        return_all: bool = True,
        build_manually: bool = True,
        filter: str = "",
        limit: int = 10,
        table_name: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["return_all"] = return_all
        params["build_manually"] = build_manually

        super().__init__(
            node_type="integration_supabase",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if filter is not None:
            self.inputs["filter"] = filter
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if build_manually is not None:
            self.inputs["build_manually"] = build_manually
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSupabaseNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
