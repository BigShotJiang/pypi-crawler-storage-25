"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_sharepoint")
class IntegrationSharepointNode(Node):
    """
    SharePoint

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your SharePoint account
    ### When action = 'update_file'
        description: New description for the file (optional)
        file: New file content (optional if renaming or updating description only)
        new_name: New name for the file including extension (optional)
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'copy_file' and use_file_picker = False
        dest_drive_id: ID of the destination document library drive (optional, defaults to source drive)
        dest_folder_id: Item ID of the destination folder in the target drive (required)
        drive_id: ID of the SharePoint document library drive to create the file in
        file_item_id: Unique item ID of the file in the drive
    ### When action = 'move_file' and use_file_picker = False
        dest_drive_id: ID of the destination document library drive (optional, defaults to source drive)
        dest_folder_id: Item ID of the destination folder in the target drive (required)
        drive_id: ID of the SharePoint document library drive to create the file in
        file_item_id: Unique item ID of the file in the drive
    ### When action = 'move_folder' and use_file_picker = False
        dest_drive_id: ID of the destination document library drive (optional, defaults to source drive)
        dest_folder_id: Item ID of the destination folder in the target drive (required)
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_item_id: Unique item ID of the folder in the drive
    ### When action = 'copy_file' and use_file_picker = True
        destination_id: Select the destination folder
        file_id: Select the folder to create the file in
    ### When action = 'move_file' and use_file_picker = True
        destination_id: Select the destination folder
        file_id: Select the folder to create the file in
    ### When action = 'move_folder' and use_file_picker = True
        destination_id: Select the destination folder
        file_id: Select the folder to create the file in
    ### When action = 'get_file'
        download_file: If enabled, fetches downloadable file object along with metadata
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'create_file' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_path: Path of the parent folder (optional, defaults to root)
    ### When action = 'get_file' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        file_item_id: Unique item ID of the file in the drive
    ### When action = 'get_files' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_path: Path of the parent folder (optional, defaults to root)
    ### When action = 'update_file' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        file_item_id: Unique item ID of the file in the drive
    ### When action = 'delete_file' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        file_item_id: Unique item ID of the file in the drive
    ### When action = 'upload_file' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_path: Path of the parent folder (optional, defaults to root)
    ### When action = 'search' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
    ### When action = 'create_folder' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_path: Path of the parent folder (optional, defaults to root)
    ### When action = 'get_folder' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_item_id: Unique item ID of the folder in the drive
    ### When action = 'list_folders' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_path: Path of the parent folder (optional, defaults to root)
    ### When action = 'rename_folder' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_item_id: Unique item ID of the folder in the drive
    ### When action = 'delete_folder' and use_file_picker = False
        drive_id: ID of the SharePoint document library drive to create the file in
        folder_item_id: Unique item ID of the folder in the drive
    ### When action = 'get_list'
        expand_columns: Whether to expand list columns
        list_id: SharePoint list ID
        site_id: SharePoint site ID
    ### When action = 'get_item'
        expand_fields: Whether to expand item fields
        list_id: SharePoint list ID
        list_item_id: ID of the item to retrieve
        site_id: SharePoint site ID
    ### When action = 'create_item'
        fields: JSON string of field values
        list_id: SharePoint list ID
        site_id: SharePoint site ID
    ### When action = 'create_or_update_item'
        fields: JSON string of field values
        list_id: SharePoint list ID
        matching_fields: JSON string of fields to match for existing items
        site_id: SharePoint site ID
    ### When action = 'update_item'
        fields: JSON string of field values
        list_id: SharePoint list ID
        list_item_id: ID of the item to retrieve
        site_id: SharePoint site ID
    ### When action = 'upload_file'
        file: New file content (optional if renaming or updating description only)
        file_name: Name of the file to create (e.g. notes.txt)
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'create_file'
        file_content: Text content for the new file
        file_name: Name of the file to create (e.g. notes.txt)
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'create_file' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'get_file' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'get_files' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'update_file' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'delete_file' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'upload_file' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'search' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'create_folder' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'get_folder' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'list_folders' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'rename_folder' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'delete_folder' and use_file_picker = True
        file_id: Select the folder to create the file in
    ### When action = 'list_items'
        filter: OData filter expression
        limit: Maximum number of files to return
        list_id: SharePoint list ID
        order_by: Field to order results by
        select_fields: Comma-separated list of fields to select
        site_id: SharePoint site ID
        skip_token: Skip token for pagination
    ### When action = 'list_lists'
        filter: OData filter expression
        limit: Maximum number of files to return
        order_by: Field to order results by
        select_fields: Comma-separated list of fields to select
        site_id: SharePoint site ID
    ### When action = 'create_folder'
        folder_name: Name of the new folder
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'get_files'
        limit: Maximum number of files to return
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'search'
        limit: Maximum number of files to return
        search_query: Search query to find files and folders
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'list_folders'
        limit: Maximum number of files to return
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'delete_item'
        list_id: SharePoint list ID
        list_item_id: ID of the item to retrieve
        site_id: SharePoint site ID
    ### When action = 'copy_file'
        new_name: New name for the file including extension (optional)
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'rename_folder'
        new_name: New name for the file including extension (optional)
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'delete_file'
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'move_file'
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'get_folder'
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'delete_folder'
        use_file_picker: Toggle off to manually enter drive ID and folder path
    ### When action = 'move_folder'
        use_file_picker: Toggle off to manually enter drive ID and folder path

    ## Outputs
    ### When action = 'create_or_update_item'
        action: Action performed: 'created' or 'updated'
        fields: Item fields as JSON
        item_id: ID of the created or updated item
        modified_at: Last modified timestamp
        raw_data: Raw response data
        web_url: Web URL of the item
    ### When action = 'get_folder'
        child_count: Number of children in the folder
        created_at: When the folder was created
        created_by: User who created the folder
        drive_id: ID of the document library drive containing the folder
        folder_id: Unique item ID of the folder in the drive
        folder_name: Name of the folder
        folder_path: Path of the folder
        modified_at: When the folder was last modified
        modified_by: User who last modified the folder
        parent_id: Item ID of the parent folder
        raw_data: Raw response data
        size: Size of the folder in bytes
        web_url: Web URL of the folder
    ### When action = 'list_folders'
        child_counts: Number of children in each folder
        created_dates: Creation dates of the folders
        folder_ids: Unique item IDs of the folders in the drive
        folder_names: Names of the folders
        folder_paths: Paths of the folders
        folder_urls: Web URLs of the folders
        modified_dates: Last modified dates of the folders
        raw_data: Raw response data
        total_count: Total number of folders returned
    ### When action = 'get_list'
        columns: List columns as JSON strings
        created_at: Creation timestamp
        description: Description of the list
        display_name: Display name of the list
        item_count: Number of items in the list
        list_id: ID of the list
        list_name: Name of the list
        modified_at: Last modified timestamp
        raw_data: Raw response data
        template: Template type of the list
        title: Title of the list
        web_url: Web URL of the list
    ### When action = 'get_item'
        content_type: Content type of the item
        created_at: Creation timestamp
        created_by: Name of the user who created the item
        fields: Item fields as JSON
        item_id: ID of the retrieved item
        modified_at: Last modified timestamp
        modified_by: Name of the user who last modified the item
        raw_data: Raw response data
        title: Title of the item
        web_url: Web URL of the item
    ### When action = 'create_file'
        created_at: Creation timestamp
        drive_id: ID of the document library drive the file was created in
        file_id: Unique item ID of the created file in the drive
        file_name: Name of the created file
        file_path: Path of the created file
        folder_id: Item ID of the parent folder containing the created file
        raw_data: Raw response data
        size: Size of the created file in bytes
        web_url: Web URL of the created file
    ### When action = 'get_file'
        created_at: When the file was created
        created_by: User who created the file
        drive_id: ID of the document library drive containing the file
        file: Downloaded file object (when Download File Content is enabled)
        file_id: Unique item ID of the file in the drive
        file_name: Name of the file
        file_path: Path of the file in SharePoint
        folder_id: Item ID of the parent folder containing the file
        mime_type: MIME type of the file
        modified_at: When the file was last modified
        modified_by: User who last modified the file
        raw_data: Raw response data
        size: Size of the file in bytes
        web_url: Web URL to access the file
    ### When action = 'upload_file'
        created_at: Creation timestamp
        drive_id: ID of the document library drive the file was uploaded to
        file_id: Unique item ID of the uploaded file in the drive
        file_name: Name of the uploaded file
        file_path: Path of the uploaded file
        folder_id: Item ID of the parent folder containing the uploaded file
        raw_data: Raw response data
        size: Size of the uploaded file
        web_url: Web URL of the uploaded file
    ### When action = 'create_folder'
        created_at: When the folder was created
        drive_id: ID of the document library drive the folder was created in
        folder_id: Unique item ID of the created folder in the drive
        folder_name: Name of the created folder
        folder_path: Path of the created folder
        parent_id: Item ID of the parent folder
        raw_data: Raw response data
        web_url: Web URL of the created folder
    ### When action = 'create_item'
        created_at: Creation timestamp
        fields: Created item fields as JSON
        item_id: ID of the created item
        raw_data: Raw response data
        web_url: Web URL of the created item
    ### When action = 'get_files'
        created_dates: Creation dates
        file_ids: Unique item IDs of the files in the drive
        file_names: Names of the files
        file_paths: Paths of the files
        file_sizes: Sizes of the files in bytes
        file_urls: Web URLs of the files
        folder_ids: Item IDs of the parent folders for each file
        mime_types: MIME types of the files
        modified_dates: Last modified dates
        raw_data: Raw response data
        total_count: Number of files returned
    ### When action = 'search'
        created_dates: Creation dates
        item_ids: Unique item IDs of the results
        item_names: Names of the items
        item_paths: Paths of the items
        item_sizes: Sizes of the items in bytes
        item_types: Type of each item (file or folder)
        item_urls: Web URLs of the items
        mime_types: MIME types of the items (empty for folders)
        modified_dates: Last modified dates
        raw_data: Raw response data
        total_count: Number of results returned
    ### When action = 'update_file'
        drive_id: ID of the document library drive containing the updated file
        file_id: Unique item ID of the updated file in the drive
        file_name: Name of the updated file
        file_path: Path of the updated file
        folder_id: Item ID of the parent folder containing the updated file
        modified_at: Last modified timestamp
        raw_data: Raw response data
        size: Size of the updated file
        web_url: Web URL of the updated file
    ### When action = 'delete_file'
        drive_id: ID of the document library drive the file was deleted from
        folder_id: Item ID of the parent folder the file was in
        message: Status message
        raw_data: Raw response data
    ### When action = 'move_file'
        drive_id: ID of the document library drive the file was moved to
        file_id: Unique item ID of the moved file in the drive
        file_name: Name of the moved file
        file_path: New path of the file
        folder_id: Item ID of the destination folder
        modified_at: Last modified timestamp
        raw_data: Raw response data
        web_url: Web URL of the moved file
    ### When action = 'rename_folder'
        drive_id: ID of the document library drive containing the renamed folder
        folder_id: Unique item ID of the renamed folder in the drive
        folder_name: Updated name of the folder
        folder_path: Updated path of the folder
        modified_at: When the folder was last modified
        raw_data: Raw response data
        web_url: Web URL of the folder
    ### When action = 'delete_folder'
        drive_id: ID of the document library drive the folder was deleted from
        message: Status message
        parent_id: Item ID of the parent folder the deleted folder was in
        raw_data: Raw response data
    ### When action = 'move_folder'
        drive_id: ID of the document library drive the folder was moved to
        folder_id: Unique item ID of the moved folder in the drive
        folder_name: Name of the moved folder
        folder_path: New path of the moved folder
        modified_at: When the folder was last modified
        parent_id: Item ID of the new parent folder
        raw_data: Raw response data
        web_url: Web URL of the moved folder
    ### When action = 'update_item'
        fields: Updated item fields as JSON
        item_id: ID of the updated item
        modified_at: Last modified timestamp
        raw_data: Raw response data
        web_url: Web URL of the updated item
    ### When action = 'list_items'
        has_more: Whether more items are available
        item_count: Number of items returned
        item_fields: List of item fields as JSON strings
        item_ids: List of item IDs
        items: List of items as JSON strings
        next_link: URL for next page of results
        raw_data: Raw response data
        total_count: Total number of items
    ### When action = 'list_lists'
        has_more: Whether more lists are available
        list_count: Number of lists returned
        list_display_names: List of list display names
        list_ids: List of list IDs
        list_names: List of list names
        list_templates: List of list templates
        list_web_urls: List of list web URLs
        lists: List of lists as JSON strings
        next_link: URL for next page of results
        raw_data: Raw response data
        total_count: Total number of lists
    ### When action = 'delete_item'
        item_id: ID of the deleted item
        message: Success or error message
        status: Status of the operation
    ### When action = 'copy_file'
        message: Status message
        raw_data: Raw response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your SharePoint account",
            "value": None,
            "type": "integration<Sharepoint>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder path",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the file to create (e.g. notes.txt)",
                    "label": "File Name",
                    "placeholder": "document.txt",
                },
                {
                    "field": "file_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Text content for the new file",
                    "label": "File Content",
                    "placeholder": "Hello world",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the created file in the drive",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the created file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the created file",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the created file",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the created file in bytes",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the file was created in",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder containing the created file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "create_file",
            "task_name": "tasks.sharepoint.create_file",
            "description": "Create a new file in SharePoint with text content",
            "label": "Create File",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_path",
                "file_name",
                "file_content",
            ],
            "required": ["file_name", "file_content", "use_file_picker", "drive_id"],
        },
        "create_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to create the file in",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "create_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive to create the file in",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the parent folder (optional, defaults to root)",
                    "label": "Folder Path",
                    "placeholder": "/Documents/",
                },
            ],
            "outputs": [],
        },
        "get_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and file item ID",
                },
                {
                    "field": "download_file",
                    "type": "bool",
                    "value": False,
                    "label": "Download File Content",
                    "helper_text": "If enabled, fetches downloadable file object along with metadata",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the file in the drive",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the file in SharePoint",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL to access the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive containing the file",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder containing the file",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "created_by",
                    "type": "string",
                    "helper_text": "User who created the file",
                },
                {
                    "field": "modified_at",
                    "type": "string",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "modified_by",
                    "type": "string",
                    "helper_text": "User who last modified the file",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "Downloaded file object (when Download File Content is enabled)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_file",
            "task_name": "tasks.sharepoint.get_file",
            "description": "Get details of a specific file in SharePoint",
            "label": "Get File",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "download_file",
                "file_id",
                "drive_id",
                "file_item_id",
            ],
            "required": [
                "use_file_picker",
                "drive_id",
                "file_item_id",
                "download_file",
            ],
        },
        "get_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to get details for",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [],
        },
        "get_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive containing the file",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "file_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the file in the drive",
                    "label": "File ID",
                    "placeholder": "01ABCDEF",
                },
            ],
            "outputs": [],
        },
        "get_files**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder path",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of files to return",
                    "label": "Limit",
                },
            ],
            "outputs": [
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "Unique item IDs of the files in the drive",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the files",
                },
                {
                    "field": "file_urls",
                    "type": "vec<string>",
                    "helper_text": "Web URLs of the files",
                },
                {
                    "field": "file_sizes",
                    "type": "vec<string>",
                    "helper_text": "Sizes of the files in bytes",
                },
                {
                    "field": "mime_types",
                    "type": "vec<string>",
                    "helper_text": "MIME types of the files",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation dates",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Last modified dates",
                },
                {
                    "field": "file_paths",
                    "type": "vec<string>",
                    "helper_text": "Paths of the files",
                },
                {
                    "field": "folder_ids",
                    "type": "vec<string>",
                    "helper_text": "Item IDs of the parent folders for each file",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Number of files returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_files",
            "task_name": "tasks.sharepoint.get_files",
            "description": "List files in a folder in SharePoint",
            "label": "List Files",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_path",
                "limit",
            ],
            "required": ["use_file_picker", "drive_id", "limit"],
        },
        "get_files**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to list files from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "get_files**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive to list files from",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the folder to list (optional, defaults to root)",
                    "label": "Folder Path",
                    "placeholder": "/Documents/",
                },
            ],
            "outputs": [],
        },
        "update_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and file item ID",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "New file content (optional if renaming or updating description only)",
                    "label": "File",
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the file including extension (optional)",
                    "label": "New Name",
                    "placeholder": "renamed-document.docx",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the file (optional)",
                    "label": "Description",
                    "placeholder": "Updated project report",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the updated file in the drive",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the updated file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the updated file",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the updated file",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the updated file",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive containing the updated file",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder containing the updated file",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modified timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_file",
            "task_name": "tasks.sharepoint.update_file",
            "description": "Update a file in SharePoint (content, name, or description)",
            "label": "Update File",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "file_item_id",
                "file",
                "new_name",
                "description",
            ],
            "required": ["use_file_picker", "drive_id", "file_item_id"],
        },
        "update_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to update in SharePoint",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [],
        },
        "update_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive containing the file to update",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "file_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the file to update in the drive",
                    "label": "File ID",
                    "placeholder": "01ABCDEF",
                },
            ],
            "outputs": [],
        },
        "delete_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and file item ID",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the file was deleted from",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder the file was in",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_file",
            "task_name": "tasks.sharepoint.delete_file",
            "description": "Delete a file from SharePoint",
            "label": "Delete File",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "file_item_id",
            ],
            "required": ["use_file_picker", "drive_id", "file_item_id"],
        },
        "delete_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [],
        },
        "delete_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive containing the file to delete",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "file_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the file to delete from the drive",
                    "label": "File ID",
                    "placeholder": "01ABCDEF",
                },
            ],
            "outputs": [],
        },
        "upload_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder path",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the file to upload",
                    "label": "File Name",
                    "placeholder": "document.pdf",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "File content to upload",
                    "label": "File",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the uploaded file in the drive",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the uploaded file",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the uploaded file",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the uploaded file",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the file was uploaded to",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder containing the uploaded file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "upload_file",
            "task_name": "tasks.sharepoint.upload_file",
            "description": "Upload a file to SharePoint",
            "label": "Upload File",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_path",
                "file_name",
                "file",
            ],
            "required": ["file", "file_name", "use_file_picker", "drive_id"],
        },
        "upload_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to upload the file to",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "upload_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive to upload the file to",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path where to upload the file (optional, defaults to root)",
                    "label": "Folder Path",
                    "placeholder": "/Documents/",
                },
            ],
            "outputs": [],
        },
        "search**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID",
                },
                {
                    "field": "search_query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to find files and folders",
                    "label": "Search Query",
                    "placeholder": "budget report",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of results to return",
                    "label": "Limit",
                },
            ],
            "outputs": [
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "Unique item IDs of the results",
                },
                {
                    "field": "item_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the items",
                },
                {
                    "field": "item_urls",
                    "type": "vec<string>",
                    "helper_text": "Web URLs of the items",
                },
                {
                    "field": "item_types",
                    "type": "vec<string>",
                    "helper_text": "Type of each item (file or folder)",
                },
                {
                    "field": "item_sizes",
                    "type": "vec<string>",
                    "helper_text": "Sizes of the items in bytes",
                },
                {
                    "field": "mime_types",
                    "type": "vec<string>",
                    "helper_text": "MIME types of the items (empty for folders)",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation dates",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Last modified dates",
                },
                {
                    "field": "item_paths",
                    "type": "vec<string>",
                    "helper_text": "Paths of the items",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Number of results returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "search",
            "task_name": "tasks.sharepoint.search",
            "description": "Search files and folders by name/content in a SharePoint drive",
            "label": "Search Files/Folders",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "search_query",
                "limit",
            ],
            "required": ["use_file_picker", "drive_id", "search_query", "limit"],
        },
        "search**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Drive",
                    "helper_text": "Select any folder in the drive to search",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "search**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive to search in",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                }
            ],
            "outputs": [],
        },
        "copy_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive IDs and item IDs",
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional new name for the copied file",
                    "label": "New Name (Optional)",
                    "placeholder": "copy-of-document.docx",
                },
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "copy_file",
            "task_name": "tasks.sharepoint.copy_file",
            "description": "Copy a file to another location in SharePoint",
            "label": "Copy File",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "destination_id",
                "drive_id",
                "file_item_id",
                "dest_drive_id",
                "dest_folder_id",
                "new_name",
            ],
            "required": [
                "use_file_picker",
                "drive_id",
                "file_item_id",
                "dest_folder_id",
            ],
        },
        "copy_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Source File",
                    "helper_text": "Select the file to copy",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination Folder",
                    "helper_text": "Select the destination folder",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [],
        },
        "copy_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the document library drive containing the source file",
                    "label": "Source Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "file_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the source file to copy",
                    "label": "Source File ID",
                    "placeholder": "01ABCDEF",
                },
                {
                    "field": "dest_drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the destination document library drive (optional, defaults to source drive)",
                    "label": "Destination Drive ID",
                    "placeholder": "b!xyz789",
                },
                {
                    "field": "dest_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Item ID of the destination folder in the target drive (required)",
                    "label": "Destination Folder ID",
                    "placeholder": "01XYZDEF",
                },
            ],
            "outputs": [],
        },
        "move_file**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive IDs and item IDs",
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the moved file in the drive",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the moved file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "New path of the file",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the moved file",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the file was moved to",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Item ID of the destination folder",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modified timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "move_file",
            "task_name": "tasks.sharepoint.move_file",
            "description": "Move a file to another location in SharePoint",
            "label": "Move File",
            "banner_text": "Note: Cross-drive moves are asynchronous; file_path and modified_at may be empty until completion.",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "destination_id",
                "drive_id",
                "file_item_id",
                "dest_drive_id",
                "dest_folder_id",
            ],
            "required": [
                "use_file_picker",
                "drive_id",
                "file_item_id",
                "dest_folder_id",
            ],
        },
        "move_file**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Source File",
                    "helper_text": "Select the file to move",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination Folder",
                    "helper_text": "Select the destination folder",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [],
        },
        "move_file**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the document library drive containing the file to move",
                    "label": "Source Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "file_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the file to move",
                    "label": "Source File ID",
                    "placeholder": "01ABCDEF",
                },
                {
                    "field": "dest_drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the destination document library drive (optional, defaults to source drive)",
                    "label": "Destination Drive ID",
                    "placeholder": "b!xyz789",
                },
                {
                    "field": "dest_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Item ID of the destination folder in the target drive (required)",
                    "label": "Destination Folder ID",
                    "placeholder": "01XYZDEF",
                },
            ],
            "outputs": [],
        },
        "create_folder**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder path",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the new folder",
                    "label": "Folder Name",
                    "placeholder": "My Folder",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the created folder in the drive",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the created folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Path of the created folder",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the created folder",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the folder was created in",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "create_folder",
            "task_name": "tasks.sharepoint.create_folder",
            "description": "Create a new folder in SharePoint",
            "label": "Create Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_path",
                "folder_name",
            ],
            "required": ["use_file_picker", "drive_id", "folder_name"],
        },
        "create_folder**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Folder",
                    "helper_text": "Select the parent folder where the new folder will be created",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "create_folder**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive to create the folder in",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the parent folder (empty for root)",
                    "label": "Parent Folder Path",
                    "placeholder": "General/Subfolder",
                },
            ],
            "outputs": [],
        },
        "get_folder**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder item ID",
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the folder in the drive",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Path of the folder",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the folder",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive containing the folder",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder",
                },
                {
                    "field": "child_count",
                    "type": "int32",
                    "helper_text": "Number of children in the folder",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the folder in bytes",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "created_by",
                    "type": "string",
                    "helper_text": "User who created the folder",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "modified_by",
                    "type": "string",
                    "helper_text": "User who last modified the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_folder",
            "task_name": "tasks.sharepoint.get_folder",
            "description": "Get details of a specific folder in SharePoint",
            "label": "Get Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_item_id",
            ],
            "required": ["use_file_picker", "drive_id", "folder_item_id"],
        },
        "get_folder**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to get details for",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "get_folder**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive containing the folder",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the folder in the drive",
                    "label": "Folder ID",
                    "placeholder": "01ABCDEF",
                },
            ],
            "outputs": [],
        },
        "list_folders**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder path",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of folders to return",
                    "label": "Limit",
                },
            ],
            "outputs": [
                {
                    "field": "folder_ids",
                    "type": "vec<string>",
                    "helper_text": "Unique item IDs of the folders in the drive",
                },
                {
                    "field": "folder_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the folders",
                },
                {
                    "field": "folder_paths",
                    "type": "vec<string>",
                    "helper_text": "Paths of the folders",
                },
                {
                    "field": "folder_urls",
                    "type": "vec<string>",
                    "helper_text": "Web URLs of the folders",
                },
                {
                    "field": "child_counts",
                    "type": "vec<int32>",
                    "helper_text": "Number of children in each folder",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation dates of the folders",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Last modified dates of the folders",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of folders returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "list_folders",
            "task_name": "tasks.sharepoint.list_folders",
            "description": "List folders in a SharePoint folder",
            "label": "List Folders",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_path",
                "limit",
            ],
            "required": ["use_file_picker", "drive_id", "limit"],
        },
        "list_folders**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Folder",
                    "helper_text": "Select the parent folder to list subfolders from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "list_folders**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive to list folders from",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the parent folder (empty for root)",
                    "label": "Parent Folder Path",
                    "placeholder": "General/Subfolder",
                },
            ],
            "outputs": [],
        },
        "rename_folder**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder item ID",
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the folder",
                    "label": "New Name",
                    "placeholder": "Renamed Folder",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the renamed folder in the drive",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Updated name of the folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Updated path of the folder",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the folder",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive containing the renamed folder",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "rename_folder",
            "task_name": "tasks.sharepoint.rename_folder",
            "description": "Rename a folder in SharePoint",
            "label": "Rename Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_item_id",
                "new_name",
            ],
            "required": ["use_file_picker", "drive_id", "folder_item_id", "new_name"],
        },
        "rename_folder**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to rename",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "rename_folder**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive containing the folder to rename",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the folder to rename in the drive",
                    "label": "Folder ID",
                    "placeholder": "01ABCDEF",
                },
            ],
            "outputs": [],
        },
        "delete_folder**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive ID and folder item ID",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the folder was deleted from",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Item ID of the parent folder the deleted folder was in",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_folder",
            "task_name": "tasks.sharepoint.delete_folder",
            "description": "Delete a folder and its contents from SharePoint",
            "label": "Delete Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "drive_id",
                "folder_item_id",
            ],
            "required": ["use_file_picker", "drive_id", "folder_item_id"],
        },
        "delete_folder**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [],
        },
        "delete_folder**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the SharePoint document library drive containing the folder to delete",
                    "label": "Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the folder to delete from the drive",
                    "label": "Folder ID",
                    "placeholder": "01ABCDEF",
                },
            ],
            "outputs": [],
        },
        "move_folder**(*)": {
            "inputs": [
                {
                    "field": "use_file_picker",
                    "type": "bool",
                    "value": True,
                    "label": "Use File Picker",
                    "helper_text": "Toggle off to manually enter drive and folder IDs",
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique item ID of the moved folder in the drive",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the moved folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "New path of the moved folder",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the moved folder",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the document library drive the folder was moved to",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Item ID of the new parent folder",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "move_folder",
            "task_name": "tasks.sharepoint.move_folder",
            "description": "Move a folder to a different location in SharePoint",
            "label": "Move Folder",
            "banner_text": "Note: Cross-drive moves are asynchronous; folder_path and modified_at may be empty until completion.",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_file_picker",
                "file_id",
                "destination_id",
                "drive_id",
                "folder_item_id",
                "dest_drive_id",
                "dest_folder_id",
            ],
            "required": [
                "use_file_picker",
                "drive_id",
                "folder_item_id",
                "dest_folder_id",
            ],
        },
        "move_folder**true": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Source Folder",
                    "helper_text": "Select the folder to move",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination Folder",
                    "helper_text": "Select the destination folder",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [],
        },
        "move_folder**false": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the document library drive containing the folder to move",
                    "label": "Source Drive ID",
                    "placeholder": "b!abc123",
                },
                {
                    "field": "folder_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unique item ID of the source folder to move",
                    "label": "Source Folder ID",
                    "placeholder": "01ABCDEF",
                },
                {
                    "field": "dest_drive_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the destination document library drive (optional, defaults to source drive)",
                    "label": "Destination Drive ID",
                    "placeholder": "b!xyz789",
                },
                {
                    "field": "dest_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Item ID of the destination folder in the target drive (required)",
                    "label": "Destination Folder ID",
                    "placeholder": "01XYZDEF",
                },
            ],
            "outputs": [],
        },
        "create_item**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "JSON string of field values",
                    "label": "Fields",
                    "placeholder": '{"Title": "My Item", "Description": "Item"}',
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the created item",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the created item",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Created item fields as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "create_item",
            "task_name": "tasks.sharepoint.create_item",
            "description": "Create a new item in a SharePoint list",
            "label": "Create Item",
            "ui_sort_order": ["integration", "action", "site_id", "list_id", "fields"],
            "required": ["site_id", "list_id", "fields"],
        },
        "create_or_update_item**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "matching_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "JSON string of fields to match for existing items",
                    "label": "Matching Fields",
                    "placeholder": '{"Title": "Existing Item"}',
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "JSON string of field values to create or update",
                    "label": "Fields",
                    "placeholder": '{"Title": "Update Item"}',
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the created or updated item",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed: 'created' or 'updated'",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modified timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the item",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Item fields as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "create_or_update_item",
            "task_name": "tasks.sharepoint.create_or_update_item",
            "description": "Create or update an item in a SharePoint list",
            "label": "Create or Update Item",
            "ui_sort_order": [
                "integration",
                "action",
                "site_id",
                "list_id",
                "matching_fields",
                "fields",
            ],
            "required": ["site_id", "list_id", "fields", "matching_fields"],
        },
        "get_item**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "list_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the item to retrieve",
                    "label": "Item ID",
                    "placeholder": "1",
                },
                {
                    "field": "expand_fields",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to expand item fields",
                    "label": "Expand Fields",
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the retrieved item",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the item",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "Content type of the item",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "created_by",
                    "type": "string",
                    "helper_text": "Name of the user who created the item",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modified timestamp",
                },
                {
                    "field": "modified_by",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the item",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the item",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Item fields as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_item",
            "task_name": "tasks.sharepoint.get_item",
            "description": "Get a specific item from a SharePoint list",
            "label": "Get Item",
            "ui_sort_order": [
                "integration",
                "action",
                "site_id",
                "list_id",
                "list_item_id",
                "expand_fields",
            ],
            "required": ["site_id", "list_id", "list_item_id"],
        },
        "list_items**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "select_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of fields to select",
                    "label": "Select Fields",
                    "placeholder": "Title,Description,CreatedBy",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "OData filter expression",
                    "label": "Filter",
                    "placeholder": "fields/Title eq 'My Item'",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "helper_text": "Field to order results by",
                    "label": "Order By",
                    "placeholder": "Created desc",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of items to return",
                    "label": "Limit",
                },
                {
                    "field": "skip_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Skip token for pagination",
                    "label": "Skip Token",
                },
            ],
            "outputs": [
                {
                    "field": "items",
                    "type": "vec<string>",
                    "helper_text": "List of items as JSON strings",
                },
                {
                    "field": "item_count",
                    "type": "int32",
                    "helper_text": "Number of items returned",
                },
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of item IDs",
                },
                {
                    "field": "item_fields",
                    "type": "vec<string>",
                    "helper_text": "List of item fields as JSON strings",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of items",
                },
                {
                    "field": "next_link",
                    "type": "string",
                    "helper_text": "URL for next page of results",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether more items are available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "list_items",
            "task_name": "tasks.sharepoint.list_items",
            "description": "List items from a SharePoint list",
            "label": "List Items",
            "ui_sort_order": [
                "integration",
                "action",
                "site_id",
                "list_id",
                "select_fields",
                "filter",
                "order_by",
                "limit",
                "skip_token",
            ],
            "required": ["site_id", "list_id", "limit"],
        },
        "update_item**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "list_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the item to update",
                    "label": "Item ID",
                    "placeholder": "1",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "JSON string of field values to update",
                    "label": "Fields",
                    "placeholder": '{"Title": "Updated", "Description": "description"}',
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the updated item",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modified timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the updated item",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Updated item fields as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_item",
            "task_name": "tasks.sharepoint.update_item",
            "description": "Update an existing item in a SharePoint list",
            "label": "Update Item",
            "ui_sort_order": [
                "integration",
                "action",
                "site_id",
                "list_id",
                "list_item_id",
                "fields",
            ],
            "required": ["site_id", "list_id", "list_item_id", "fields"],
        },
        "delete_item**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "list_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the item to delete",
                    "label": "Item ID",
                    "placeholder": "1",
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the deleted item",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_item",
            "task_name": "tasks.sharepoint.delete_item",
            "description": "Delete an item from a SharePoint list",
            "label": "Delete Item",
            "ui_sort_order": [
                "integration",
                "action",
                "site_id",
                "list_id",
                "list_item_id",
            ],
            "required": ["site_id", "list_id", "list_item_id"],
        },
        "get_list**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint list ID",
                    "label": "List ID",
                    "placeholder": "dec3457d2-1234-4ae9-abcd-13cxt85trece",
                },
                {
                    "field": "expand_columns",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to expand list columns",
                    "label": "Expand Columns",
                },
            ],
            "outputs": [
                {"field": "list_id", "type": "string", "helper_text": "ID of the list"},
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Name of the list",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Display name of the list",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the list",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the list",
                },
                {
                    "field": "template",
                    "type": "string",
                    "helper_text": "Template type of the list",
                },
                {
                    "field": "item_count",
                    "type": "int32",
                    "helper_text": "Number of items in the list",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modified timestamp",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the list",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "List columns as JSON strings",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_list",
            "task_name": "tasks.sharepoint.get_list",
            "description": "Get metadata for a specific SharePoint list",
            "label": "Get List",
            "ui_sort_order": [
                "integration",
                "action",
                "site_id",
                "list_id",
                "expand_columns",
            ],
            "required": ["site_id", "list_id"],
        },
        "list_lists**(*)": {
            "inputs": [
                {
                    "field": "site_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "SharePoint site ID",
                    "label": "Site ID",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "hidden": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=Site",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "select_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of fields to select",
                    "label": "Select Fields",
                    "placeholder": "id,name,displayName",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "OData filter expression",
                    "label": "Filter",
                    "placeholder": "name eq 'Documents'",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "helper_text": "Field to order results by",
                    "label": "Order By",
                    "placeholder": "displayName asc",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of lists to return",
                    "label": "Limit",
                },
            ],
            "outputs": [
                {
                    "field": "lists",
                    "type": "vec<string>",
                    "helper_text": "List of lists as JSON strings",
                },
                {
                    "field": "list_count",
                    "type": "int32",
                    "helper_text": "Number of lists returned",
                },
                {
                    "field": "list_ids",
                    "type": "vec<string>",
                    "helper_text": "List of list IDs",
                },
                {
                    "field": "list_names",
                    "type": "vec<string>",
                    "helper_text": "List of list names",
                },
                {
                    "field": "list_display_names",
                    "type": "vec<string>",
                    "helper_text": "List of list display names",
                },
                {
                    "field": "list_templates",
                    "type": "vec<string>",
                    "helper_text": "List of list templates",
                },
                {
                    "field": "list_web_urls",
                    "type": "vec<string>",
                    "helper_text": "List of list web URLs",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of lists",
                },
                {
                    "field": "next_link",
                    "type": "string",
                    "helper_text": "URL for next page of results",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether more lists are available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "list_lists",
            "task_name": "tasks.sharepoint.list_lists",
            "description": "Get multiple lists",
            "label": "List Lists",
            "inputs_sort_order": [
                "integration",
                "action",
                "site_id",
                "select_fields",
                "filter",
                "order_by",
                "limit",
            ],
            "required": ["site_id", "limit"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_file_picker"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_file_picker: bool = True,
        description: str = "",
        dest_drive_id: str = "",
        dest_folder_id: str = "",
        destination_id: str = "",
        download_file: bool = False,
        drive_id: str = "",
        expand_columns: bool = False,
        expand_fields: bool = False,
        fields: str = "",
        file: str = "",
        file_content: str = "",
        file_id: str = "",
        file_item_id: str = "",
        file_name: str = "",
        filter: str = "",
        folder_item_id: str = "",
        folder_name: str = "",
        folder_path: str = "",
        limit: int = 10,
        list_id: str = "",
        list_item_id: str = "",
        matching_fields: str = "",
        new_name: str = "",
        order_by: str = "",
        search_query: str = "",
        select_fields: str = "",
        site_id: str = "",
        skip_token: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_file_picker"] = use_file_picker

        super().__init__(
            node_type="integration_sharepoint",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if use_file_picker is not None:
            self.inputs["use_file_picker"] = use_file_picker
        if file_name is not None:
            self.inputs["file_name"] = file_name
        if file_content is not None:
            self.inputs["file_content"] = file_content
        if file_id is not None:
            self.inputs["file_id"] = file_id
        if drive_id is not None:
            self.inputs["drive_id"] = drive_id
        if folder_path is not None:
            self.inputs["folder_path"] = folder_path
        if download_file is not None:
            self.inputs["download_file"] = download_file
        if file_item_id is not None:
            self.inputs["file_item_id"] = file_item_id
        if limit is not None:
            self.inputs["limit"] = limit
        if file is not None:
            self.inputs["file"] = file
        if new_name is not None:
            self.inputs["new_name"] = new_name
        if description is not None:
            self.inputs["description"] = description
        if search_query is not None:
            self.inputs["search_query"] = search_query
        if destination_id is not None:
            self.inputs["destination_id"] = destination_id
        if dest_drive_id is not None:
            self.inputs["dest_drive_id"] = dest_drive_id
        if dest_folder_id is not None:
            self.inputs["dest_folder_id"] = dest_folder_id
        if folder_name is not None:
            self.inputs["folder_name"] = folder_name
        if folder_item_id is not None:
            self.inputs["folder_item_id"] = folder_item_id
        if site_id is not None:
            self.inputs["site_id"] = site_id
        if list_id is not None:
            self.inputs["list_id"] = list_id
        if fields is not None:
            self.inputs["fields"] = fields
        if matching_fields is not None:
            self.inputs["matching_fields"] = matching_fields
        if list_item_id is not None:
            self.inputs["list_item_id"] = list_item_id
        if expand_fields is not None:
            self.inputs["expand_fields"] = expand_fields
        if select_fields is not None:
            self.inputs["select_fields"] = select_fields
        if filter is not None:
            self.inputs["filter"] = filter
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if skip_token is not None:
            self.inputs["skip_token"] = skip_token
        if expand_columns is not None:
            self.inputs["expand_columns"] = expand_columns
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSharepointNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
