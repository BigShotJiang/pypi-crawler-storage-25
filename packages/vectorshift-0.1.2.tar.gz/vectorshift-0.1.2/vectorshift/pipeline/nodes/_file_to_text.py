"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("file_to_text")
class FileToTextNode(Node):
    """
    Convert data from type File to type Text

    ## Inputs
    ### Common Inputs
        chunk_text: Whether to chunk the text into smaller pieces.
        decrypt: Use a password to decrypt the file.
        file: The file to convert to text.
        file_parser: The type of file parser to use.
    ### When chunk_text = True
        chunk_overlap: The overlap of each chunk of text.
        chunk_size: The size of each chunk of text.
    ### When decrypt = True
        password: The password to decrypt the file.

    ## Outputs
    ### When chunk_text = True
        processed_text: The text as a list of chunks.
    ### When chunk_text = False
        processed_text: The text as a string.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "chunk_text",
            "helper_text": "Whether to chunk the text into smaller pieces.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "decrypt",
            "helper_text": "Use a password to decrypt the file.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "file",
            "helper_text": "The file to convert to text.",
            "value": "",
            "type": "file",
        },
        {
            "field": "file_parser",
            "helper_text": "The type of file parser to use.",
            "value": "default",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [
                {
                    "field": "chunk_size",
                    "type": "int32",
                    "value": 1024,
                    "label": "Chunk Size",
                    "helper_text": "The size of each chunk of text.",
                    "is_advanced_setting": True,
                    "section": "advanced_settings",
                    "component": {"type": "int32", "max": 4096, "min": 1, "step": 5},
                },
                {
                    "field": "chunk_overlap",
                    "type": "int32",
                    "value": 400,
                    "label": "Chunk Overlap",
                    "helper_text": "The overlap of each chunk of text.",
                    "is_advanced_setting": True,
                    "section": "advanced_settings",
                    "component": {
                        "type": "int32",
                        "max": "{{chunk_size}}",
                        "max_offset": "-1",
                        "min": 0,
                        "step": 5,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "processed_text",
                    "type": "vec<string>",
                    "label": "Processed Text",
                    "helper_text": "The text as a list of chunks.",
                }
            ],
        },
        "false**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "processed_text",
                    "type": "string",
                    "label": "Processed Text",
                    "helper_text": "The text as a string.",
                }
            ],
        },
        "(*)**true": {
            "inputs": [
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "helper_text": "The password to decrypt the file.",
                    "is_advanced_setting": True,
                    "section": "advanced_settings",
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["chunk_text", "decrypt"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["file"]

    def __init__(
        self,
        chunk_text: bool = False,
        decrypt: bool = False,
        chunk_overlap: int = 400,
        chunk_size: int = 1024,
        file: str = "",
        file_parser: str = "default",
        password: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["chunk_text"] = chunk_text
        params["decrypt"] = decrypt

        super().__init__(
            node_type="file_to_text",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file is not None:
            self.inputs["file"] = file
        if chunk_text is not None:
            self.inputs["chunk_text"] = chunk_text
        if file_parser is not None:
            self.inputs["file_parser"] = file_parser
        if decrypt is not None:
            self.inputs["decrypt"] = decrypt
        if chunk_size is not None:
            self.inputs["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            self.inputs["chunk_overlap"] = chunk_overlap
        if password is not None:
            self.inputs["password"] = password
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "FileToTextNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
