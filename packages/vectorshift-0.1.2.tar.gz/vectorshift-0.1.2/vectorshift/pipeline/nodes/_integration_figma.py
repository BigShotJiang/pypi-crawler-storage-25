"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_figma")
class IntegrationFigmaNode(Node):
    """
    Figma

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Figma account
    ### get_comments
        as_md: Return comment messages as markdown
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
    ### get_file_details
        branch_data: Include branch metadata if the file is a branch
        depth: How deep to traverse the document tree (1 = Pages only, 2 = Pages + top-level objects, leave empty for full depth)
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
        geometry: Set to 'paths' to include vector path data (leave empty to exclude)
        ids: Comma-separated list of node IDs to retrieve (optional, auto-extracted from URL if provided)
        plugin_data: Comma-separated list of plugin IDs to include data for (optional)
        version: Specific version ID to retrieve (optional, defaults to latest)
    ### create_comment
        comment_id: Optional: Enter an existing comment ID to reply to it. Leave empty to create a new comment thread
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
        message: The text content of your comment
        node_id: Optional: Node ID to attach comment to (auto-extracted from URL if provided)
        x: Optional: Horizontal position on the canvas (in pixels). Only used if no Node ID is provided
        y: Optional: Vertical position on the canvas (in pixels). Only used if no Node ID is provided
    ### delete_comment
        comment_id: Optional: Enter an existing comment ID to reply to it. Leave empty to create a new comment thread
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
    ### create_comment_reaction
        comment_id: Optional: Enter an existing comment ID to reply to it. Leave empty to create a new comment thread
        emoji: The emoji shortcode to use as a reaction
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
    ### get_comment_reactions
        comment_id: Optional: Enter an existing comment ID to reply to it. Leave empty to create a new comment thread
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
    ### delete_comment_reaction
        comment_id: Optional: Enter an existing comment ID to reply to it. Leave empty to create a new comment thread
        emoji: The emoji shortcode to use as a reaction
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
    ### get_images
        contents_only: For PDF, omit surrounding empty space
        download_images: Download and return actual image files instead of just URLs
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
        format: Image output format
        node_ids: Comma-separated node IDs to retrieve (e.g., 0:1,1:2)
        scale: Scale factor for the image (0.01 to 4.0)
        svg_include_id: Include ID attributes in SVG output
        svg_outline_text: Convert text to outlines in SVG output
        svg_simplify_stroke: Simplify strokes in SVG output
        use_absolute_bounds: Use full dimensions of the node regardless of cropping
        version: Specific version ID to retrieve (optional, defaults to latest)
    ### get_file_node_details
        depth: How deep to traverse the document tree (1 = Pages only, 2 = Pages + top-level objects, leave empty for full depth)
        file_key: Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL
        geometry: Set to 'paths' to include vector path data (leave empty to exclude)
        node_ids: Comma-separated node IDs to retrieve (e.g., 0:1,1:2)
        plugin_data: Comma-separated list of plugin IDs to include data for (optional)
        version: Specific version ID to retrieve (optional, defaults to latest)

    ## Outputs
    ### get_file_details
        branch_keys: List of branch file keys
        branch_names: List of branch names
        component_count: Number of components in the file
        document_id: The document root node ID
        document_name: The document root node name
        document_type: The document root node type
        editor_type: The type of editor (figma, figjam)
        last_modified: When the file was last modified
        main_file_key: Key of the main file (if this is a branch)
        name: The name of the file
        page_ids: List of page node IDs
        page_names: List of page names
        raw_data: Raw API response data
        role: User's role for this file (owner, editor, viewer)
        schema_version: The schema version of the file
        style_count: Number of styles in the file
        thumbnail_url: URL to the file thumbnail
        version: The version ID of the file
    ### get_comments
        comment_authors: List of comment author handles
        comment_created_dates: List of comment creation dates
        comment_ids: List of comment IDs
        comment_messages: List of comment messages
        parent_ids: List of parent comment IDs (for replies)
        raw_data: Raw API response data
        total_count: Total number of comments
    ### create_comment
        comment_id: The ID of the created comment
        created_at: When the comment was created
        file_key: The file key the comment belongs to
        message: The comment message
        node_id: The node ID the comment is attached to
        parent_id: The parent comment ID (if a reply)
        position_x: X position of the comment
        position_y: Y position of the comment
        raw_data: Raw API response data
        resolved_at: When the comment was resolved (if resolved)
        user_email: Email of the user who created the comment
        user_handle: Handle of the user who created the comment
        user_id: ID of the user who created the comment
    ### delete_comment
        comment_id: The ID of the deleted comment
        deleted: Whether the comment was deleted
        file_key: The file key
        raw_data: Raw API response data
    ### create_comment_reaction
        comment_id: The comment ID
        created: Whether the reaction was created
        emoji: The emoji used
        file_key: The file key
        raw_data: Raw API response data
    ### get_comment_reactions
        comment_id: The comment ID
        created_dates: List of reaction creation dates
        emojis: List of reaction emojis
        file_key: The file key
        raw_data: Raw API response data
        total_count: Total number of reactions
        user_handles: List of user handles who reacted
    ### delete_comment_reaction
        comment_id: The comment ID
        deleted: Whether the reaction was deleted
        emoji: The emoji that was removed
        file_key: The file key
        raw_data: Raw API response data
    ### get_images
        image_count: Number of images rendered
        image_files: Downloaded image files (when download enabled)
        image_node_ids: List of node IDs that were rendered
        image_url: URL of the rendered image (if single node)
        image_urls: List of image URLs corresponding to node IDs
        images_map: JSON mapping of node IDs to image URLs
        raw_data: Raw API response data
    ### get_file_node_details
        last_modified: When the file was last modified
        name: The name of the file
        node_count: Number of nodes retrieved
        node_ids: List of retrieved node IDs
        node_names: List of node names
        node_types: List of node types
        raw_data: Raw API response data
        role: User's role for this file
        thumbnail_url: URL to the file thumbnail
        version: The version ID of the file
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Figma account",
            "value": None,
            "type": "integration<Figma>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_file_details": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key. Node IDs will be auto-extracted from URL",
                },
                {
                    "field": "version",
                    "type": "string",
                    "value": "",
                    "label": "Version",
                    "placeholder": "",
                    "helper_text": "Specific version ID to retrieve (optional, defaults to latest)",
                },
                {
                    "field": "ids",
                    "type": "string",
                    "value": "",
                    "label": "Node IDs",
                    "placeholder": "1:2,3:4",
                    "helper_text": "Comma-separated list of node IDs to retrieve (optional, auto-extracted from URL if provided)",
                },
                {
                    "field": "depth",
                    "type": "int32",
                    "value": 1,
                    "label": "Depth",
                    "helper_text": "How deep to traverse the document tree (1 = Pages only, 2 = Pages + top-level objects, leave empty for full depth)",
                },
                {
                    "field": "geometry",
                    "type": "string",
                    "value": "",
                    "label": "Geometry",
                    "placeholder": "paths",
                    "helper_text": "Set to 'paths' to include vector path data (leave empty to exclude)",
                },
                {
                    "field": "plugin_data",
                    "type": "string",
                    "value": "",
                    "label": "Plugin Data",
                    "placeholder": "plugin_id1,plugin_id2",
                    "helper_text": "Comma-separated list of plugin IDs to include data for (optional)",
                },
                {
                    "field": "branch_data",
                    "type": "bool",
                    "value": False,
                    "label": "Include Branch Data",
                    "helper_text": "Include branch metadata if the file is a branch",
                },
            ],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the file",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "User's role for this file (owner, editor, viewer)",
                },
                {
                    "field": "last_modified",
                    "type": "string",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "editor_type",
                    "type": "string",
                    "helper_text": "The type of editor (figma, figjam)",
                },
                {
                    "field": "thumbnail_url",
                    "type": "string",
                    "helper_text": "URL to the file thumbnail",
                },
                {
                    "field": "version",
                    "type": "string",
                    "helper_text": "The version ID of the file",
                },
                {
                    "field": "schema_version",
                    "type": "int32",
                    "helper_text": "The schema version of the file",
                },
                {
                    "field": "main_file_key",
                    "type": "string",
                    "helper_text": "Key of the main file (if this is a branch)",
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "The document root node ID",
                },
                {
                    "field": "document_name",
                    "type": "string",
                    "helper_text": "The document root node name",
                },
                {
                    "field": "document_type",
                    "type": "string",
                    "helper_text": "The document root node type",
                },
                {
                    "field": "page_ids",
                    "type": "vec<string>",
                    "helper_text": "List of page node IDs",
                },
                {
                    "field": "page_names",
                    "type": "vec<string>",
                    "helper_text": "List of page names",
                },
                {
                    "field": "branch_keys",
                    "type": "vec<string>",
                    "helper_text": "List of branch file keys",
                },
                {
                    "field": "branch_names",
                    "type": "vec<string>",
                    "helper_text": "List of branch names",
                },
                {
                    "field": "component_count",
                    "type": "int32",
                    "helper_text": "Number of components in the file",
                },
                {
                    "field": "style_count",
                    "type": "int32",
                    "helper_text": "Number of styles in the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_file_details",
            "task_name": "tasks.figma.get_file_details",
            "description": "Get metadata and structure of a Figma file",
            "label": "Get File Details",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "file_key",
                "version",
                "ids",
                "depth",
                "geometry",
                "plugin_data",
                "branch_data",
            ],
            "required": ["file_key"],
        },
        "get_file_node_details": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "node_ids",
                    "type": "string",
                    "value": "",
                    "label": "Node IDs",
                    "placeholder": "0:1,1:2",
                    "helper_text": "Comma-separated node IDs to retrieve (e.g., 0:1,1:2)",
                },
                {
                    "field": "version",
                    "type": "string",
                    "value": "",
                    "label": "Version",
                    "placeholder": "",
                    "helper_text": "Specific version ID to retrieve (optional)",
                },
                {
                    "field": "depth",
                    "type": "int32",
                    "value": 1,
                    "label": "Depth",
                    "helper_text": "How deep to traverse from each node (1 = direct children only, leave empty for full depth)",
                },
                {
                    "field": "geometry",
                    "type": "string",
                    "value": "",
                    "label": "Geometry",
                    "placeholder": "paths",
                    "helper_text": "Set to 'paths' to include vector path data (leave empty to exclude)",
                },
                {
                    "field": "plugin_data",
                    "type": "string",
                    "value": "",
                    "label": "Plugin Data",
                    "placeholder": "plugin_id1,plugin_id2",
                    "helper_text": "Comma-separated list of plugin IDs to include data for (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the file",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "User's role for this file",
                },
                {
                    "field": "last_modified",
                    "type": "string",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "thumbnail_url",
                    "type": "string",
                    "helper_text": "URL to the file thumbnail",
                },
                {
                    "field": "version",
                    "type": "string",
                    "helper_text": "The version ID of the file",
                },
                {
                    "field": "node_ids",
                    "type": "vec<string>",
                    "helper_text": "List of retrieved node IDs",
                },
                {
                    "field": "node_names",
                    "type": "vec<string>",
                    "helper_text": "List of node names",
                },
                {
                    "field": "node_types",
                    "type": "vec<string>",
                    "helper_text": "List of node types",
                },
                {
                    "field": "node_count",
                    "type": "int32",
                    "helper_text": "Number of nodes retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_file_node_details",
            "task_name": "tasks.figma.get_file_node_details",
            "description": "Get metadata for specific nodes in a Figma file",
            "label": "Get File Node Details",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "file_key",
                "node_ids",
                "version",
                "depth",
                "geometry",
                "plugin_data",
            ],
            "required": ["file_key", "node_ids"],
        },
        "get_images": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "node_ids",
                    "type": "string",
                    "value": "",
                    "label": "Node IDs",
                    "placeholder": "0:1,1:2",
                    "helper_text": "Comma-separated node IDs to render as images (e.g., 0:1,1:2)",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "png",
                    "label": "Format",
                    "helper_text": "Image output format",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "PNG", "value": "png"},
                            {"label": "JPG", "value": "jpg"},
                            {"label": "SVG", "value": "svg"},
                            {"label": "PDF", "value": "pdf"},
                        ],
                    },
                },
                {
                    "field": "scale",
                    "type": "float",
                    "value": 1.0,
                    "label": "Scale",
                    "placeholder": "1.0",
                    "helper_text": "Scale factor for the image (0.01 to 4.0)",
                },
                {
                    "field": "download_images",
                    "type": "bool",
                    "value": False,
                    "label": "Download Images",
                    "helper_text": "Download and return actual image files instead of just URLs",
                },
                {
                    "field": "svg_include_id",
                    "type": "bool",
                    "value": False,
                    "label": "SVG Include ID",
                    "helper_text": "Include ID attributes in SVG output",
                },
                {
                    "field": "svg_simplify_stroke",
                    "type": "bool",
                    "value": False,
                    "label": "SVG Simplify Stroke",
                    "helper_text": "Simplify strokes in SVG output",
                },
                {
                    "field": "svg_outline_text",
                    "type": "bool",
                    "value": False,
                    "label": "SVG Outline Text",
                    "helper_text": "Convert text to outlines in SVG output",
                },
                {
                    "field": "contents_only",
                    "type": "bool",
                    "value": False,
                    "label": "Contents Only",
                    "helper_text": "For PDF, omit surrounding empty space",
                },
                {
                    "field": "use_absolute_bounds",
                    "type": "bool",
                    "value": False,
                    "label": "Use Absolute Bounds",
                    "helper_text": "Use full dimensions of the node regardless of cropping",
                },
                {
                    "field": "version",
                    "type": "string",
                    "value": "",
                    "label": "Version",
                    "placeholder": "",
                    "helper_text": "Specific version ID to render (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "image_url",
                    "type": "string",
                    "helper_text": "URL of the rendered image (if single node)",
                },
                {
                    "field": "image_node_ids",
                    "type": "vec<string>",
                    "helper_text": "List of node IDs that were rendered",
                },
                {
                    "field": "image_urls",
                    "type": "vec<string>",
                    "helper_text": "List of image URLs corresponding to node IDs",
                },
                {
                    "field": "image_files",
                    "type": "vec<file>",
                    "helper_text": "Downloaded image files (when download enabled)",
                },
                {
                    "field": "image_count",
                    "type": "int32",
                    "helper_text": "Number of images rendered",
                },
                {
                    "field": "images_map",
                    "type": "string",
                    "helper_text": "JSON mapping of node IDs to image URLs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_images",
            "task_name": "tasks.figma.get_images",
            "description": "Render nodes from a Figma file as images",
            "label": "Get Images",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "file_key",
                "node_ids",
                "format",
                "scale",
                "download_images",
                "svg_include_id",
                "svg_simplify_stroke",
                "svg_outline_text",
                "contents_only",
                "use_absolute_bounds",
                "version",
            ],
            "required": ["file_key", "node_ids"],
        },
        "create_comment": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or file key. Node ID from URL will attach comment to that element",
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "label": "Comment Message",
                    "placeholder": "This looks great!",
                    "helper_text": "The text content of your comment",
                    "multiline": True,
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Reply To (Comment ID)",
                    "placeholder": "123456",
                    "helper_text": "Optional: Enter an existing comment ID to reply to it. Leave empty to create a new comment thread",
                },
                {
                    "field": "node_id",
                    "type": "string",
                    "value": "",
                    "label": "Attach to Element (Node ID)",
                    "placeholder": "1:2",
                    "helper_text": "Optional: Node ID to attach comment to (auto-extracted from URL if provided)",
                },
                {
                    "field": "x",
                    "type": "float",
                    "value": 0,
                    "label": "Canvas X Position",
                    "helper_text": "Optional: Horizontal position on the canvas (in pixels). Only used if no Node ID is provided",
                },
                {
                    "field": "y",
                    "type": "float",
                    "value": 0,
                    "label": "Canvas Y Position",
                    "helper_text": "Optional: Vertical position on the canvas (in pixels). Only used if no Node ID is provided",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The ID of the created comment",
                },
                {
                    "field": "file_key",
                    "type": "string",
                    "helper_text": "The file key the comment belongs to",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "The parent comment ID (if a reply)",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "The comment message",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "resolved_at",
                    "type": "string",
                    "helper_text": "When the comment was resolved (if resolved)",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "ID of the user who created the comment",
                },
                {
                    "field": "user_handle",
                    "type": "string",
                    "helper_text": "Handle of the user who created the comment",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the comment",
                },
                {
                    "field": "node_id",
                    "type": "string",
                    "helper_text": "The node ID the comment is attached to",
                },
                {
                    "field": "position_x",
                    "type": "float",
                    "helper_text": "X position of the comment",
                },
                {
                    "field": "position_y",
                    "type": "float",
                    "helper_text": "Y position of the comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_comment",
            "task_name": "tasks.figma.create_comment",
            "description": "Create a comment on a Figma file",
            "label": "Create Comment",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "file_key",
                "message",
                "comment_id",
                "node_id",
                "x",
                "y",
            ],
            "required": ["file_key", "message"],
        },
        "get_comments": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "as_md",
                    "type": "bool",
                    "value": False,
                    "label": "Format as Markdown",
                    "helper_text": "Return comment messages as markdown",
                },
            ],
            "outputs": [
                {
                    "field": "comment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of comment IDs",
                },
                {
                    "field": "comment_messages",
                    "type": "vec<string>",
                    "helper_text": "List of comment messages",
                },
                {
                    "field": "comment_authors",
                    "type": "vec<string>",
                    "helper_text": "List of comment author handles",
                },
                {
                    "field": "comment_created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of comment creation dates",
                },
                {
                    "field": "parent_ids",
                    "type": "vec<string>",
                    "helper_text": "List of parent comment IDs (for replies)",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of comments",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_comments",
            "task_name": "tasks.figma.get_comments",
            "description": "Get all comments on a Figma file",
            "label": "Get Comments",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "file_key", "as_md"],
            "required": ["file_key"],
        },
        "delete_comment": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "123456",
                    "helper_text": "The ID of the comment to delete",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The ID of the deleted comment",
                },
                {"field": "file_key", "type": "string", "helper_text": "The file key"},
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the comment was deleted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_comment",
            "task_name": "tasks.figma.delete_comment",
            "description": "Delete a comment from a Figma file",
            "label": "Delete Comment",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "file_key", "comment_id"],
            "required": ["file_key", "comment_id"],
        },
        "create_comment_reaction": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "123456",
                    "helper_text": "The ID of the comment to react to",
                },
                {
                    "field": "emoji",
                    "type": "string",
                    "value": ":+1:",
                    "label": "Emoji",
                    "helper_text": "The emoji shortcode to use as a reaction",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "figma_emoji_options",
                    },
                },
            ],
            "outputs": [
                {"field": "file_key", "type": "string", "helper_text": "The file key"},
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The comment ID",
                },
                {"field": "emoji", "type": "string", "helper_text": "The emoji used"},
                {
                    "field": "created",
                    "type": "bool",
                    "helper_text": "Whether the reaction was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_comment_reaction",
            "task_name": "tasks.figma.create_comment_reaction",
            "description": "Add a reaction to a comment",
            "label": "Create Comment Reaction",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "file_key",
                "comment_id",
                "emoji",
            ],
            "required": ["file_key", "comment_id", "emoji"],
        },
        "get_comment_reactions": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "123456",
                    "helper_text": "The ID of the comment to get reactions for",
                },
            ],
            "outputs": [
                {"field": "file_key", "type": "string", "helper_text": "The file key"},
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The comment ID",
                },
                {
                    "field": "emojis",
                    "type": "vec<string>",
                    "helper_text": "List of reaction emojis",
                },
                {
                    "field": "user_handles",
                    "type": "vec<string>",
                    "helper_text": "List of user handles who reacted",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of reaction creation dates",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of reactions",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_comment_reactions",
            "task_name": "tasks.figma.get_comment_reactions",
            "description": "Get all reactions on a comment",
            "label": "Get Comment Reactions",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "file_key", "comment_id"],
            "required": ["file_key", "comment_id"],
        },
        "delete_comment_reaction": {
            "inputs": [
                {
                    "field": "file_key",
                    "type": "string",
                    "value": "",
                    "label": "File Key or URL",
                    "placeholder": "Paste Figma URL or file key",
                    "helper_text": "Paste the full Figma URL or just the file key",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "123456",
                    "helper_text": "The ID of the comment",
                },
                {
                    "field": "emoji",
                    "type": "string",
                    "value": ":+1:",
                    "label": "Emoji",
                    "helper_text": "The emoji shortcode to remove",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "figma_emoji_options",
                    },
                },
            ],
            "outputs": [
                {"field": "file_key", "type": "string", "helper_text": "The file key"},
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The comment ID",
                },
                {
                    "field": "emoji",
                    "type": "string",
                    "helper_text": "The emoji that was removed",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the reaction was deleted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_comment_reaction",
            "task_name": "tasks.figma.delete_comment_reaction",
            "description": "Remove a reaction from a comment",
            "label": "Delete Comment Reaction",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "file_key",
                "comment_id",
                "emoji",
            ],
            "required": ["file_key", "comment_id", "emoji"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        as_md: bool = False,
        branch_data: bool = False,
        comment_id: str = "",
        contents_only: bool = False,
        depth: int = 1,
        download_images: bool = False,
        emoji: str = ":+1:",
        file_key: str = "",
        format: str = "png",
        geometry: str = "",
        ids: str = "",
        message: str = "",
        node_id: str = "",
        node_ids: str = "",
        plugin_data: str = "",
        scale: Any = 1.0,
        svg_include_id: bool = False,
        svg_outline_text: bool = False,
        svg_simplify_stroke: bool = False,
        use_absolute_bounds: bool = False,
        version: str = "",
        x: Any = 0,
        y: Any = 0,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_figma",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if file_key is not None:
            self.inputs["file_key"] = file_key
        if version is not None:
            self.inputs["version"] = version
        if ids is not None:
            self.inputs["ids"] = ids
        if depth is not None:
            self.inputs["depth"] = depth
        if geometry is not None:
            self.inputs["geometry"] = geometry
        if plugin_data is not None:
            self.inputs["plugin_data"] = plugin_data
        if branch_data is not None:
            self.inputs["branch_data"] = branch_data
        if node_ids is not None:
            self.inputs["node_ids"] = node_ids
        if format is not None:
            self.inputs["format"] = format
        if scale is not None:
            self.inputs["scale"] = scale
        if download_images is not None:
            self.inputs["download_images"] = download_images
        if svg_include_id is not None:
            self.inputs["svg_include_id"] = svg_include_id
        if svg_simplify_stroke is not None:
            self.inputs["svg_simplify_stroke"] = svg_simplify_stroke
        if svg_outline_text is not None:
            self.inputs["svg_outline_text"] = svg_outline_text
        if contents_only is not None:
            self.inputs["contents_only"] = contents_only
        if use_absolute_bounds is not None:
            self.inputs["use_absolute_bounds"] = use_absolute_bounds
        if message is not None:
            self.inputs["message"] = message
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if node_id is not None:
            self.inputs["node_id"] = node_id
        if x is not None:
            self.inputs["x"] = x
        if y is not None:
            self.inputs["y"] = y
        if as_md is not None:
            self.inputs["as_md"] = as_md
        if emoji is not None:
            self.inputs["emoji"] = emoji
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationFigmaNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
