"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_sugar_crm")
class IntegrationSugarCrmNode(Node):
    """
    SugarCRM

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### get_records
        filter: To filter records within module
        module: Your existing module on SugarCRM

    ## Outputs
    ### get_records
        output: The retrieved output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<SugarCRM>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_records": {
            "inputs": [
                {
                    "field": "module",
                    "type": "string",
                    "value": "",
                    "label": "Module",
                    "placeholder": "customer_support",
                    "helper_text": "Your existing module on SugarCRM",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "Name = 'John'",
                    "helper_text": "To filter records within module",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "any",
                    "helper_text": "The retrieved output",
                }
            ],
            "name": "get_records",
            "task_name": "tasks.sugar_crm.get_records",
            "description": "Get multiple records",
            "label": "List Records",
            "variant": "default_integration_nodes",
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        filter: str = "",
        module: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_sugar_crm",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if module is not None:
            self.inputs["module"] = module
        if filter is not None:
            self.inputs["filter"] = filter
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSugarCrmNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
