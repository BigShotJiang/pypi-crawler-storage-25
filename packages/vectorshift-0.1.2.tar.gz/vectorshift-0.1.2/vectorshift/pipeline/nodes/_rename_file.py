"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("rename_file")
class RenameFileNode(Node):
    """
    Rename an existing file, assigning a new name along with the file extension.

    ## Inputs
    ### Common Inputs
        file: The file to rename.
        new_name: The new name of the file, including its extension (e.g., file.txt, file.pdf, file.csv)

    ## Outputs
    ### Common Outputs
        renamed_file: The renamed file
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "file",
            "helper_text": "The file to rename.",
            "value": None,
            "type": "file",
        },
        {
            "field": "new_name",
            "helper_text": "The new name of the file, including its extension (e.g., file.txt, file.pdf, file.csv)",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "renamed_file", "helper_text": "The renamed file", "type": "file"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["file", "new_name"]

    def __init__(
        self,
        file: Optional[str] = None,
        new_name: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="rename_file",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file is not None:
            self.inputs["file"] = file
        if new_name is not None:
            self.inputs["new_name"] = new_name
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "RenameFileNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
