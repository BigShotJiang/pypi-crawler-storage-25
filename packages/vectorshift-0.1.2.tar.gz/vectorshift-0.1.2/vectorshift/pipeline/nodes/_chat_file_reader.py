"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("chat_file_reader")
class ChatFileReaderNode(Node):
    """
    Allows for document upload within chatbots (often connected to the LLM node).

    ## Inputs
    ### Common Inputs
        chunk_overlap: The number of tokens of overlap between chunks (1 token = 4 characters)
        chunk_size: The number of tokens per chunk (1 token = 4 characters)
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.
        max_docs_per_query: Sets the maximum number of chunks to retrieve for each query
        retrieval_unit: Return the most relevant Chunks (text content), Documents (will return the document metadata as well as most relevant snippets from the document), or Pages (will return complete pages with all chunks from pages containing relevant content)

    ## Outputs
    ### Common Outputs
        documents: The uploaded file (in the chat interface) is processed into text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "chunk_overlap",
            "helper_text": "The number of tokens of overlap between chunks (1 token = 4 characters)",
            "value": 200,
            "type": "int32",
        },
        {
            "field": "chunk_size",
            "helper_text": "The number of tokens per chunk (1 token = 4 characters)",
            "value": 1000,
            "type": "int32",
        },
        {
            "field": "file_parser",
            "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
            "value": "default",
            "type": "string",
        },
        {
            "field": "max_docs_per_query",
            "helper_text": "Sets the maximum number of chunks to retrieve for each query",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "retrieval_unit",
            "helper_text": "Return the most relevant Chunks (text content), Documents (will return the document metadata as well as most relevant snippets from the document), or Pages (will return complete pages with all chunks from pages containing relevant content)",
            "value": "chunks",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "documents",
            "helper_text": "The uploaded file (in the chat interface) is processed into text",
            "type": "vec<string>",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = False

    def __init__(
        self,
        chunk_overlap: int = 200,
        chunk_size: int = 1000,
        file_parser: str = "default",
        max_docs_per_query: int = 10,
        retrieval_unit: str = "chunks",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="chat_file_reader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file_parser is not None:
            self.inputs["file_parser"] = file_parser
        if max_docs_per_query is not None:
            self.inputs["max_docs_per_query"] = max_docs_per_query
        if retrieval_unit is not None:
            self.inputs["retrieval_unit"] = retrieval_unit
        if chunk_size is not None:
            self.inputs["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            self.inputs["chunk_overlap"] = chunk_overlap
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ChatFileReaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
