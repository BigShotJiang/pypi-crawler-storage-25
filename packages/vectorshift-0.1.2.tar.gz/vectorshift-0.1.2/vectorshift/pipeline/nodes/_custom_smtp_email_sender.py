"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("custom_smtp_email_sender")
class CustomSmtpEmailSenderNode(Node):
    """
    Send emails using a custom SMTP server configuration

    ## Inputs
    ### Common Inputs
        connection_type: Security type: SSL, TLS, or STARTTLS
        email_body: Email content
        email_subject: Subject line of the email
        recipient_email: Recipient email address(es), comma-separated
        send_as_html: Send email in HTML format
        sender_email: Sender email address
        sender_name: Display name for sender (optional)
        sender_password: SMTP server password
        smtp_server: SMTP server hostname or IP
        smtp_server_port: SMTP server port (25, 465, 587)

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "connection_type",
            "helper_text": "Security type: SSL, TLS, or STARTTLS",
            "value": "SSL",
            "type": "string",
        },
        {
            "field": "email_body",
            "helper_text": "Email content",
            "value": "",
            "type": "string",
        },
        {
            "field": "email_subject",
            "helper_text": "Subject line of the email",
            "value": "",
            "type": "string",
        },
        {
            "field": "recipient_email",
            "helper_text": "Recipient email address(es), comma-separated",
            "value": "",
            "type": "string",
        },
        {
            "field": "send_as_html",
            "helper_text": "Send email in HTML format",
            "value": "",
            "type": "bool",
        },
        {
            "field": "sender_email",
            "helper_text": "Sender email address",
            "value": "",
            "type": "string",
        },
        {
            "field": "sender_name",
            "helper_text": "Display name for sender (optional)",
            "value": "",
            "type": "string",
        },
        {
            "field": "sender_password",
            "helper_text": "SMTP server password",
            "value": "",
            "type": "string",
        },
        {
            "field": "smtp_server",
            "helper_text": "SMTP server hostname or IP",
            "value": "",
            "type": "string",
        },
        {
            "field": "smtp_server_port",
            "helper_text": "SMTP server port (25, 465, 587)",
            "value": 465,
            "type": "int32",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "recipient_email",
        "email_subject",
        "smtp_server",
        "sender_email",
        "sender_password",
    ]

    def __init__(
        self,
        connection_type: str = "SSL",
        email_body: str = "",
        email_subject: str = "",
        recipient_email: str = "",
        send_as_html: bool = False,
        sender_email: str = "",
        sender_name: str = "",
        sender_password: str = "",
        smtp_server: str = "",
        smtp_server_port: int = 465,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="custom_smtp_email_sender",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if recipient_email is not None:
            self.inputs["recipient_email"] = recipient_email
        if email_subject is not None:
            self.inputs["email_subject"] = email_subject
        if email_body is not None:
            self.inputs["email_body"] = email_body
        if send_as_html is not None:
            self.inputs["send_as_html"] = send_as_html
        if smtp_server is not None:
            self.inputs["smtp_server"] = smtp_server
        if smtp_server_port is not None:
            self.inputs["smtp_server_port"] = smtp_server_port
        if sender_email is not None:
            self.inputs["sender_email"] = sender_email
        if sender_password is not None:
            self.inputs["sender_password"] = sender_password
        if sender_name is not None:
            self.inputs["sender_name"] = sender_name
        if connection_type is not None:
            self.inputs["connection_type"] = connection_type
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CustomSmtpEmailSenderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
