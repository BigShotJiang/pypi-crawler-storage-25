"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_zoho")
class IntegrationZohoNode(Node):
    """
    Zoho CRM

    ## Inputs
    ### Common Inputs
        action: Select the Zoho CRM operation to perform
        integration: Connect to your Zoho CRM account
    ### get_account
        account_id: The ID of the account to retrieve (required)
    ### update_account
        account_id: The ID of the account to retrieve (required)
        account_name: Name of the account (required)
        account_number: Account number/identifier
        account_site: Account site or location name
        account_type: Type of account (e.g., Customer, Partner, Prospect, Distributor, or custom type)
        annual_revenue: Annual revenue of the account
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        contact_details: Additional contact details
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        employees: Number of employees
        exchange_rate: Exchange rate for currency conversion
        fax: Account fax number
        industry: Industry of the account
        phone: Account phone number
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        ticker_symbol: Stock ticker symbol
        website: Account website URL
    ### delete_account
        account_id: The ID of the account to retrieve (required)
    ### create_invoice
        account_id: The ID of the account to retrieve (required)
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        invoice_date: Invoice date (YYYY-MM-DD)
        invoice_number: Invoice number
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
    ### update_invoice
        account_id: The ID of the account to retrieve (required)
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        invoice_date: Invoice date (YYYY-MM-DD)
        invoice_id: The ID of the invoice to retrieve
        invoice_number: Invoice number
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
    ### upsert_invoice
        account_id: The ID of the account to retrieve (required)
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        invoice_date: Invoice date (YYYY-MM-DD)
        invoice_number: Invoice number
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
    ### create_sales_order
        account_id: The ID of the account to retrieve (required)
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        contact_id: The ID of the contact to retrieve
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        deal_id: The ID of the deal to retrieve
        description: Description of the account
        discount: Discount amount (actual monetary value, not percentage)
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        so_number: Sales order number
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
    ### update_sales_order
        account_id: The ID of the account to retrieve (required)
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        contact_id: The ID of the contact to retrieve
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        deal_id: The ID of the deal to retrieve
        description: Description of the account
        discount: Discount amount (actual monetary value, not percentage)
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        sales_order_id: The ID of the sales order to retrieve
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
    ### upsert_sales_order
        account_id: The ID of the account to retrieve (required)
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        contact_id: The ID of the contact to retrieve
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        deal_id: The ID of the deal to retrieve
        description: Description of the account
        discount: Discount amount (actual monetary value, not percentage)
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
    ### create_account
        account_name: Name of the account (required)
        account_number: Account number/identifier
        account_site: Account site or location name
        account_type: Type of account (e.g., Customer, Partner, Prospect, Distributor, or custom type)
        annual_revenue: Annual revenue of the account
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        contact_details: Additional contact details
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        employees: Number of employees
        exchange_rate: Exchange rate for currency conversion
        fax: Account fax number
        industry: Industry of the account
        phone: Account phone number
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        ticker_symbol: Stock ticker symbol
        website: Account website URL
    ### upsert_account
        account_name: Name of the account (required)
        account_number: Account number/identifier
        account_site: Account site or location name
        account_type: Type of account (e.g., Customer, Partner, Prospect, Distributor, or custom type)
        annual_revenue: Annual revenue of the account
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        contact_details: Additional contact details
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        employees: Number of employees
        exchange_rate: Exchange rate for currency conversion
        fax: Account fax number
        industry: Industry of the account
        phone: Account phone number
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        ticker_symbol: Stock ticker symbol
        website: Account website URL
    ### create_purchase_order
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        discount: Discount amount (actual monetary value, not percentage)
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        po_date: Purchase order date (YYYY-MM-DD)
        po_number: Purchase order number
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
        tracking_number: Tracking number
        vendor_id: Associated vendor (required)
    ### update_purchase_order
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        discount: Discount amount (actual monetary value, not percentage)
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        po_date: Purchase order date (YYYY-MM-DD)
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        purchase_order_id: The ID of the purchase order to retrieve
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
        tracking_number: Tracking number
    ### upsert_purchase_order
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        discount: Discount amount (actual monetary value, not percentage)
        due_date: Payment due date (YYYY-MM-DD)
        exchange_rate: Exchange rate for currency conversion
        po_date: Purchase order date (YYYY-MM-DD)
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        sales_commission: Sales commission amount (actual monetary value, not percentage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        status: Invoice status
        subject: Subject of the invoice (required)
        terms_and_conditions: Terms and conditions
        tracking_number: Tracking number
        vendor_id: Associated vendor (required)
    ### create_quote
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        exchange_rate: Exchange rate for currency conversion
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        quote_stage: Quote stage (e.g., Draft, Negotiation, Delivered, On Hold, Confirmed, Closed Won, Closed Lost, or custom stage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        subject: Subject of the invoice (required)
        team: Team for the quote
        terms_and_conditions: Terms and conditions
        valid_till: Quote validity date (YYYY-MM-DD)
    ### update_quote
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        exchange_rate: Exchange rate for currency conversion
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        quote_id: The ID of the quote to retrieve
        quote_stage: Quote stage (e.g., Draft, Negotiation, Delivered, On Hold, Confirmed, Closed Won, Closed Lost, or custom stage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        subject: Subject of the invoice (required)
        team: Team for the quote
        terms_and_conditions: Terms and conditions
        valid_till: Quote validity date (YYYY-MM-DD)
    ### upsert_quote
        adjustment: Adjustment in grand total
        billing_city: Billing city
        billing_code: Billing postal/zip code
        billing_country: Billing country
        billing_state: Billing state/province
        billing_street: Billing street address
        carrier: Carrier name
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        exchange_rate: Exchange rate for currency conversion
        product_descriptions: Comma-separated list of product descriptions (one per product)
        product_ids: Comma-separated list of product IDs (required, one per product)
        product_list_prices: Comma-separated list of list prices (one per product)
        product_quantities: Comma-separated list of quantities (one per product, default: 1)
        product_taxes: Comma-separated list of tax amounts (one per product)
        quote_stage: Quote stage (e.g., Draft, Negotiation, Delivered, On Hold, Confirmed, Closed Won, Closed Lost, or custom stage)
        shipping_city: Shipping city
        shipping_code: Shipping postal/zip code
        shipping_country: Shipping country
        shipping_state: Shipping state/province
        shipping_street: Shipping street address
        subject: Subject of the invoice (required)
        team: Team for the quote
        terms_and_conditions: Terms and conditions
        valid_till: Quote validity date (YYYY-MM-DD)
    ### create_deal
        amount: Monetary amount of the deal
        closing_date: Expected closing date (YYYY-MM-DD format)
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        deal_name: Name of the deal (required)
        description: Description of the account
        lead_conversion_time: Days to convert lead to deal
        next_step: Next step in the sales process
        overall_sales_duration: Total days from lead to closed deal
        probability: Probability of deal closure (0-100)
        sales_cycle_duration: Days to win the deal
        stage: Deal stage (e.g., Qualification, Needs Analysis, Value Proposition, Identify Decision Makers, Proposal/Price Quote, Negotiation/Review, Closed Won, Closed Lost, or custom stage) (required)
    ### update_deal
        amount: Monetary amount of the deal
        closing_date: Expected closing date (YYYY-MM-DD format)
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        deal_id: The ID of the deal to retrieve
        deal_name: Name of the deal (required)
        description: Description of the account
        lead_conversion_time: Days to convert lead to deal
        next_step: Next step in the sales process
        overall_sales_duration: Total days from lead to closed deal
        probability: Probability of deal closure (0-100)
        sales_cycle_duration: Days to win the deal
        stage: Deal stage (e.g., Qualification, Needs Analysis, Value Proposition, Identify Decision Makers, Proposal/Price Quote, Negotiation/Review, Closed Won, Closed Lost, or custom stage) (required)
    ### upsert_deal
        amount: Monetary amount of the deal
        closing_date: Expected closing date (YYYY-MM-DD format)
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        deal_name: Name of the deal (required)
        description: Description of the account
        lead_conversion_time: Days to convert lead to deal
        next_step: Next step in the sales process
        overall_sales_duration: Total days from lead to closed deal
        probability: Probability of deal closure (0-100)
        sales_cycle_duration: Days to win the deal
        stage: Deal stage (e.g., Qualification, Needs Analysis, Value Proposition, Identify Decision Makers, Proposal/Price Quote, Negotiation/Review, Closed Won, Closed Lost, or custom stage) (required)
    ### create_lead
        annual_revenue: Annual revenue of the account
        city: City
        company: Company name (required)
        country: Country
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        designation: Job title/designation
        email: Primary email address
        email_opt_out: Whether the lead has opted out of emails
        fax: Account fax number
        first_name: First name
        full_name: Full name of the contact
        industry: Industry of the account
        industry_type: Type of industry
        last_name: Last name of the contact (required)
        lead_source: Source of the lead
        lead_status: Status of the lead
        mobile: Mobile number
        no_of_employees: Number of employees in the lead's company
        phone: Account phone number
        salutation: Salutation (Mr., Mrs., Ms., Dr., etc.)
        secondary_email: Secondary email address
        skype_id: Skype ID
        state: State
        street: Street address
        twitter: Twitter handle
        website: Account website URL
        zip_code: Postal code
    ### update_lead
        annual_revenue: Annual revenue of the account
        city: City
        company: Company name (required)
        country: Country
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        designation: Job title/designation
        email: Primary email address
        email_opt_out: Whether the lead has opted out of emails
        fax: Account fax number
        first_name: First name
        full_name: Full name of the contact
        industry: Industry of the account
        industry_type: Type of industry
        last_name: Last name of the contact (required)
        lead_id: The ID of the lead to retrieve
        lead_source: Source of the lead
        lead_status: Status of the lead
        mobile: Mobile number
        no_of_employees: Number of employees in the lead's company
        phone: Account phone number
        salutation: Salutation (Mr., Mrs., Ms., Dr., etc.)
        secondary_email: Secondary email address
        skype_id: Skype ID
        state: State
        street: Street address
        twitter: Twitter handle
        website: Account website URL
        zip_code: Postal code
    ### upsert_lead
        annual_revenue: Annual revenue of the account
        city: City
        company: Company name (required)
        country: Country
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        designation: Job title/designation
        email: Primary email address
        email_opt_out: Whether the lead has opted out of emails
        fax: Account fax number
        first_name: First name
        full_name: Full name of the contact
        industry: Industry of the account
        industry_type: Type of industry
        last_name: Last name of the contact (required)
        lead_source: Source of the lead
        lead_status: Status of the lead
        mobile: Mobile number
        no_of_employees: Number of employees in the lead's company
        phone: Account phone number
        salutation: Salutation (Mr., Mrs., Ms., Dr., etc.)
        secondary_email: Secondary email address
        skype_id: Skype ID
        state: State
        street: Street address
        twitter: Twitter handle
        website: Account website URL
        zip_code: Postal code
    ### list_accounts
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_contacts
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_deals
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_leads
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_invoices
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_products
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_purchase_orders
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_quotes
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_sales_orders
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### list_vendors
        approved: Whether to retrieve only approved records
        converted: Whether to retrieve only converted records
        fields: Comma-separated list of specific fields to return
        include_child: Whether to retrieve records from child territories
        limit: Maximum number of accounts to return (max 200 per page)
        return_all: Whether to return all accounts or only up to a given limit
        sort_by: Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)
        sort_order: Sort order: ascending or descending
        territory_id: Filter by territory ID
    ### create_contact
        assistant: Name of the contact's assistant
        asst_phone: Assistant's phone number
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        date_of_birth: Date of birth (YYYY-MM-DD format)
        department: Department the contact belongs to
        description: Description of the account
        email: Primary email address
        fax: Account fax number
        first_name: First name
        full_name: Full name of the contact
        home_phone: Home phone number
        last_name: Last name of the contact (required)
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_state: Mailing state/province
        mailing_street: Mailing street address
        mailing_zip: Mailing postal/zip code
        mobile: Mobile number
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number
        other_state: Other state/province
        other_street: Other street address
        other_zip: Other postal/zip code
        phone: Account phone number
        salutation: Salutation (Mr., Mrs., Ms., Dr., etc.)
        secondary_email: Secondary email address
        skype_id: Skype ID
        title: Job title
        twitter: Twitter handle
    ### update_contact
        assistant: Name of the contact's assistant
        asst_phone: Assistant's phone number
        contact_id: The ID of the contact to retrieve
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        date_of_birth: Date of birth (YYYY-MM-DD format)
        department: Department the contact belongs to
        description: Description of the account
        email: Primary email address
        fax: Account fax number
        first_name: First name
        full_name: Full name of the contact
        home_phone: Home phone number
        last_name: Last name of the contact (required)
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_state: Mailing state/province
        mailing_street: Mailing street address
        mailing_zip: Mailing postal/zip code
        mobile: Mobile number
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number
        other_state: Other state/province
        other_street: Other street address
        other_zip: Other postal/zip code
        phone: Account phone number
        salutation: Salutation (Mr., Mrs., Ms., Dr., etc.)
        secondary_email: Secondary email address
        skype_id: Skype ID
        title: Job title
        twitter: Twitter handle
    ### upsert_contact
        assistant: Name of the contact's assistant
        asst_phone: Assistant's phone number
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        date_of_birth: Date of birth (YYYY-MM-DD format)
        department: Department the contact belongs to
        description: Description of the account
        email: Primary email address
        fax: Account fax number
        first_name: First name
        full_name: Full name of the contact
        home_phone: Home phone number
        last_name: Last name of the contact (required)
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_state: Mailing state/province
        mailing_street: Mailing street address
        mailing_zip: Mailing postal/zip code
        mobile: Mobile number
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number
        other_state: Other state/province
        other_street: Other street address
        other_zip: Other postal/zip code
        phone: Account phone number
        salutation: Salutation (Mr., Mrs., Ms., Dr., etc.)
        secondary_email: Secondary email address
        skype_id: Skype ID
        title: Job title
        twitter: Twitter handle
    ### create_vendor
        category: Vendor category
        city: City
        country: Country
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        email: Primary email address
        phone: Account phone number
        state: State
        street: Street address
        vendor_name: Name of the vendor (required)
        website: Account website URL
        zip_code: Postal code
    ### update_vendor
        category: Vendor category
        city: City
        country: Country
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        email: Primary email address
        phone: Account phone number
        state: State
        street: Street address
        vendor_id: Associated vendor (required)
        vendor_name: Name of the vendor (required)
        website: Account website URL
        zip_code: Postal code
    ### upsert_vendor
        category: Vendor category
        city: City
        country: Country
        currency: ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        email: Primary email address
        phone: Account phone number
        state: State
        street: Street address
        vendor_name: Name of the vendor (required)
        website: Account website URL
        zip_code: Postal code
    ### create_product
        commission_rate: Commission rate amount (actual monetary value, not percentage)
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        manufacturer: Manufacturer name
        product_active: Whether the product is active
        product_category: Category of the product
        product_name: Name of the product (required)
        qty_in_demand: Quantity in demand
        qty_in_stock: Quantity available in stock
        taxable: Whether the product is taxable
        unit_price: Unit price of the product
    ### update_product
        commission_rate: Commission rate amount (actual monetary value, not percentage)
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        manufacturer: Manufacturer name
        product_active: Whether the product is active
        product_category: Category of the product
        product_id: The ID of the product to retrieve
        qty_in_demand: Quantity in demand
        qty_in_stock: Quantity available in stock
        taxable: Whether the product is taxable
        unit_price: Unit price of the product
    ### upsert_product
        commission_rate: Commission rate amount (actual monetary value, not percentage)
        custom_fields: Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})
        description: Description of the account
        manufacturer: Manufacturer name
        product_active: Whether the product is active
        product_category: Category of the product
        product_name: Name of the product (required)
        qty_in_demand: Quantity in demand
        qty_in_stock: Quantity available in stock
        taxable: Whether the product is taxable
        unit_price: Unit price of the product
    ### get_contact
        contact_id: The ID of the contact to retrieve
    ### delete_contact
        contact_id: The ID of the contact to retrieve
    ### get_deal
        deal_id: The ID of the deal to retrieve
    ### delete_deal
        deal_id: The ID of the deal to retrieve
    ### get_invoice
        invoice_id: The ID of the invoice to retrieve
    ### delete_invoice
        invoice_id: The ID of the invoice to retrieve
    ### get_lead
        lead_id: The ID of the lead to retrieve
    ### delete_lead
        lead_id: The ID of the lead to retrieve
    ### get_product
        product_id: The ID of the product to retrieve
    ### delete_product
        product_id: The ID of the product to retrieve
    ### get_purchase_order
        purchase_order_id: The ID of the purchase order to retrieve
    ### delete_purchase_order
        purchase_order_id: The ID of the purchase order to retrieve
    ### get_quote
        quote_id: The ID of the quote to retrieve
    ### delete_quote
        quote_id: The ID of the quote to retrieve
    ### get_sales_order
        sales_order_id: The ID of the sales order to retrieve
    ### delete_sales_order
        sales_order_id: The ID of the sales order to retrieve
    ### get_vendor
        vendor_id: Associated vendor (required)
    ### delete_vendor
        vendor_id: Associated vendor (required)

    ## Outputs
    ### get_account
        account_details: Full account details in JSON format
        account_id: Unique identifier of the account
        account_name: Name of the account
        account_number: Account number
        account_site: Account site/location
        account_type: Type of account
        annual_revenue: Annual revenue
        billing_city: Billing city
        billing_code: Billing postal code
        billing_country: Billing country
        billing_state: Billing state
        billing_street: Billing street address
        created_by_id: ID of the user who created the account
        created_by_name: Name of the user who created the account
        created_time: When the account was created
        currency: Currency
        description: Description
        employees: Number of employees
        exchange_rate: Exchange rate
        fax: Fax number
        industry: Industry type
        modified_by_id: ID of the user who last modified the account
        modified_by_name: Name of the user who last modified the account
        modified_time: When the account was last modified
        owner_email: Email of the account owner
        owner_id: ID of the account owner
        owner_name: Name of the account owner
        phone: Phone number
        raw_data: Raw API response data
        shipping_city: Shipping city
        shipping_code: Shipping postal code
        shipping_country: Shipping country
        shipping_state: Shipping state
        shipping_street: Shipping street address
        ticker_symbol: Stock ticker symbol
        website: Website URL
    ### list_accounts
        account_details: List of account details in JSON format
        account_ids: List of account IDs
        account_industries: List of industries
        account_names: List of account names
        account_phones: List of phone numbers
        account_types: List of account types
        account_websites: List of websites
        raw_data: Raw API response data
        total_count: Total number of accounts returned
    ### create_account
        account_id: Unique identifier of the created account
        account_name: Name of the created account
        created_time: When the account was created
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### upsert_account
        account_id: ID of the account
        account_name: Name of the account
        action: Action taken (created or updated)
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### update_account
        account_id: ID of the updated account
        message: Message from API
        modified_time: When the account was modified
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_account
        account_id: ID of the deleted account
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### get_contact
        account_id: Associated account ID
        account_name: Associated account name
        assistant: Assistant name
        asst_phone: Assistant's phone number
        contact_details: Full contact details in JSON format
        contact_id: Unique identifier of the contact
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the contact was created
        date_of_birth: Date of birth
        department: Department
        description: Description
        email: Primary email address
        fax: Fax number
        first_name: First name
        full_name: Full name
        home_phone: Home phone number
        last_name: Last name
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_state: Mailing state
        mailing_street: Mailing street address
        mailing_zip: Mailing zip code
        mobile: Mobile number
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the contact was last modified
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number
        other_state: Other state
        other_street: Other street address
        other_zip: Other zip code
        owner_email: Email of the contact owner
        owner_id: ID of the contact owner
        owner_name: Name of the contact owner
        phone: Phone number
        raw_data: Raw API response data
        salutation: Salutation
        secondary_email: Secondary email address
        skype_id: Skype ID
        title: Job title
        twitter: Twitter handle
    ### get_deal
        account_id: Associated account ID
        account_name: Associated account name
        amount: Deal amount
        campaign_id: Associated campaign ID
        campaign_name: Associated campaign name
        closing_date: Expected closing date
        contact_id: Associated contact ID
        contact_name: Associated contact name
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the deal was created
        currency: Currency code
        deal_details: Full deal details in JSON format
        deal_id: Unique identifier of the deal
        deal_name: Name of the deal
        description: Deal description
        exchange_rate: Exchange rate
        lead_conversion_time: Days to convert lead
        lead_source: Source of the lead
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the deal was last modified
        next_step: Next step in sales process
        overall_sales_duration: Total days from lead to close
        owner_email: Email of the deal owner
        owner_id: ID of the deal owner
        owner_name: Name of the deal owner
        probability: Probability percentage
        raw_data: Raw API response data
        sales_cycle_duration: Days to win deal
        stage: Current stage
        type: Deal type
    ### get_invoice
        account_id: Associated account ID
        account_name: Associated account name
        adjustment: Adjustment amount
        billing_city: Billing city
        billing_code: Billing postal code
        billing_country: Billing country
        billing_state: Billing state
        billing_street: Billing street
        carrier: Carrier
        contact_id: Associated contact ID
        contact_name: Associated contact name
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the invoice was created
        currency: Currency code
        deal_id: Associated deal ID
        deal_name: Associated deal name
        description: Description
        due_date: Due date
        exchange_rate: Exchange rate
        excise_duty: Excise duty
        grand_total: Grand total amount
        invoice_date: Invoice date
        invoice_details: Full invoice details in JSON format
        invoice_id: Unique identifier of the invoice
        invoice_number: Invoice number
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the invoice was last modified
        owner_email: Email of the invoice owner
        owner_id: ID of the invoice owner
        owner_name: Name of the invoice owner
        product_details: Product details JSON
        raw_data: Raw API response data
        sales_commission: Sales commission
        sales_order_id: Associated sales order ID
        sales_order_name: Associated sales order name
        shipping_city: Shipping city
        shipping_code: Shipping postal code
        shipping_country: Shipping country
        shipping_state: Shipping state
        shipping_street: Shipping street
        status: Invoice status
        sub_total: Subtotal amount
        subject: Invoice subject
        tax: Tax amount
        terms_and_conditions: Terms and conditions
    ### get_quote
        account_id: Account ID
        account_name: Account name
        adjustment: Adjustment
        billing_city: Billing city
        billing_code: Billing postal code
        billing_country: Billing country
        billing_state: Billing state
        billing_street: Billing street
        carrier: Carrier
        contact_id: Contact ID
        contact_name: Contact name
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the quote was created
        currency: Currency code
        deal_id: Deal ID
        deal_name: Deal name
        description: Description
        exchange_rate: Exchange rate
        grand_total: Grand total amount
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the quote was last modified
        owner_email: Owner email
        owner_id: Owner ID
        owner_name: Owner name
        product_details: Product details JSON
        quote_details: Full quote details in JSON format
        quote_id: Unique identifier of the quote
        quote_number: Quote number
        quote_stage: Quote stage
        raw_data: Raw API response data
        shipping_city: Shipping city
        shipping_code: Shipping postal code
        shipping_country: Shipping country
        shipping_state: Shipping state
        shipping_street: Shipping street
        sub_total: Subtotal
        subject: Quote subject
        tax: Tax amount
        team: Team
        terms_and_conditions: Terms and conditions
        valid_till: Valid till date
    ### create_sales_order
        account_id: Account ID
        created_time: When the sales order was created
        message: Message from API
        raw_data: Raw API response data
        sales_order_id: Unique identifier of the created sales order
        status: Status of the operation
        subject: Sales order subject
    ### get_sales_order
        account_id: Account ID
        account_name: Account name
        adjustment: Adjustment
        billing_city: Billing city
        billing_code: Billing postal code
        billing_country: Billing country
        billing_state: Billing state
        billing_street: Billing street
        carrier: Carrier
        contact_id: Contact ID
        contact_name: Contact name
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the sales order was created
        currency: Currency code
        deal_id: Deal ID
        deal_name: Deal name
        description: Description
        discount: Discount
        due_date: Due date
        exchange_rate: Exchange rate
        excise_duty: Excise duty
        grand_total: Grand total amount
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the sales order was last modified
        owner_email: Owner email
        owner_id: Owner ID
        owner_name: Owner name
        pending: Pending status
        product_details: Product details JSON
        quote_id: Quote ID
        quote_name: Quote name
        raw_data: Raw API response data
        sales_commission: Sales commission
        sales_order_details: Full sales order details in JSON format
        sales_order_id: Unique identifier
        shipping_city: Shipping city
        shipping_code: Shipping postal code
        shipping_country: Shipping country
        shipping_state: Shipping state
        shipping_street: Shipping street
        so_number: SO number
        status: Status
        sub_total: Subtotal
        subject: Subject
        tax: Tax amount
        terms_and_conditions: Terms and conditions
    ### upsert_sales_order
        account_id: Account ID
        action: Action taken (created or updated)
        message: Message from API
        raw_data: Raw API response data
        sales_order_id: ID of the sales order
        status: Status of the operation
        subject: Subject
    ### upsert_contact
        action: Action taken (created or updated)
        contact_id: ID of the contact
        last_name: Last name
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### upsert_deal
        action: Action taken (created or updated)
        deal_id: ID of the deal
        deal_name: Name of the deal
        message: Message from API
        raw_data: Raw API response data
        stage: Deal stage
        status: Status of the operation
    ### upsert_lead
        action: Action taken (created or updated)
        company: Company name
        last_name: Last name
        lead_id: ID of the lead
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### upsert_invoice
        action: Action taken (created or updated)
        invoice_id: ID of the invoice
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
        subject: Invoice subject
    ### upsert_product
        action: Action taken (created or updated)
        message: Message from API
        product_id: ID of the product
        product_name: Product name
        raw_data: Raw API response data
        status: Status of the operation
    ### upsert_purchase_order
        action: Action taken (created or updated)
        message: Message from API
        purchase_order_id: ID of the purchase order
        raw_data: Raw API response data
        status: Status of the operation
        subject: Subject
        vendor_id: Vendor ID
    ### upsert_quote
        action: Action taken (created or updated)
        message: Message from API
        quote_id: ID of the quote
        raw_data: Raw API response data
        status: Status of the operation
        subject: Quote subject
    ### upsert_vendor
        action: Action taken (created or updated)
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
        vendor_id: ID of the vendor
        vendor_name: Vendor name
    ### get_purchase_order
        adjustment: Adjustment
        billing_city: Billing city
        billing_code: Billing postal code
        billing_country: Billing country
        billing_state: Billing state
        billing_street: Billing street
        carrier: Carrier
        contact_id: Contact ID
        contact_name: Contact name
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the purchase order was created
        currency: Currency code
        description: Description
        discount: Discount
        due_date: Due date
        exchange_rate: Exchange rate
        excise_duty: Excise duty
        grand_total: Grand total
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the purchase order was last modified
        owner_email: Owner email
        owner_id: Owner ID
        owner_name: Owner name
        po_date: PO date
        po_number: PO number
        product_details: Product details JSON
        purchase_order_details: Full purchase order details in JSON format
        purchase_order_id: Unique identifier
        raw_data: Raw API response data
        requisition_no: Requisition number
        sales_commission: Sales commission
        shipping_city: Shipping city
        shipping_code: Shipping postal code
        shipping_country: Shipping country
        shipping_state: Shipping state
        shipping_street: Shipping street
        status: Status
        sub_total: Subtotal
        subject: Subject
        tax: Tax amount
        terms_and_conditions: Terms and conditions
        tracking_number: Tracking number
        vendor_id: Vendor ID
        vendor_name: Vendor name
    ### get_lead
        annual_revenue: Annual revenue
        city: City
        company: Company name
        country: Country
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the lead was created
        description: Description
        designation: Designation
        email: Email address
        email_opt_out: Email opt out status
        fax: Fax number
        first_name: First name
        full_name: Full name
        industry: Industry
        industry_type: Industry type
        last_name: Last name
        lead_details: Full lead details in JSON format
        lead_id: Unique identifier of the lead
        lead_source: Source of the lead
        lead_status: Status of the lead
        mobile: Mobile number
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the lead was last modified
        no_of_employees: Number of employees
        owner_email: Email of the lead owner
        owner_id: ID of the lead owner
        owner_name: Name of the lead owner
        phone: Phone number
        raw_data: Raw API response data
        salutation: Salutation
        secondary_email: Secondary email
        skype_id: Skype ID
        state: State
        street: Street address
        twitter: Twitter handle
        website: Website URL
        zip_code: Postal code
    ### get_vendor
        category: Category
        city: City
        country: Country
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the vendor was created
        currency: Currency code
        description: Description
        email: Email address
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the vendor was last modified
        owner_email: Owner email
        owner_id: Owner ID
        owner_name: Owner name
        phone: Phone number
        raw_data: Raw API response data
        state: State
        street: Street address
        vendor_details: Full vendor details in JSON format
        vendor_id: Unique identifier of the vendor
        vendor_name: Vendor name
        website: Website URL
        zip_code: Postal code
    ### get_product
        commission_rate: Commission rate percentage
        created_by_id: ID of creator
        created_by_name: Name of creator
        created_time: When the product was created
        description: Product description
        handler: Handler name
        manufacturer: Manufacturer
        modified_by_id: ID of last modifier
        modified_by_name: Name of last modifier
        modified_time: When the product was last modified
        owner_email: Email of the product owner
        owner_id: ID of the product owner
        owner_name: Name of the product owner
        product_active: Whether product is active
        product_category: Product category
        product_code: Product code
        product_details: Full product details in JSON format
        product_id: Unique identifier of the product
        product_name: Product name
        qty_in_demand: Quantity in demand
        qty_in_stock: Quantity in stock
        qty_ordered: Quantity ordered
        raw_data: Raw API response data
        reorder_level: Reorder level
        sales_end_date: Sales end date
        sales_start_date: Sales start date
        support_expiry_date: Support expiry date
        support_start_date: Support start date
        taxable: Whether product is taxable
        unit_price: Unit price
        usage_unit: Usage unit
        vendor_id: Vendor ID
        vendor_name: Vendor name
    ### create_lead
        company: Company name
        created_time: When the lead was created
        last_name: Last name of the lead
        lead_id: Unique identifier of the created lead
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### list_contacts
        contact_departments: List of departments
        contact_details: List of contact details in JSON format
        contact_emails: List of email addresses
        contact_first_names: List of first names
        contact_full_names: List of full names
        contact_ids: List of contact IDs
        contact_last_names: List of last names
        contact_mobiles: List of mobile numbers
        contact_phones: List of phone numbers
        contact_titles: List of job titles
        raw_data: Raw API response data
        total_count: Total number of contacts returned
    ### create_contact
        contact_id: Unique identifier of the created contact
        created_time: When the contact was created
        last_name: Last name of the contact
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### update_contact
        contact_id: ID of the updated contact
        message: Message from API
        modified_time: When the contact was modified
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_contact
        contact_id: ID of the deleted contact
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### create_deal
        created_time: When the deal was created
        deal_id: Unique identifier of the created deal
        deal_name: Name of the deal
        message: Message from API
        raw_data: Raw API response data
        stage: Deal stage
        status: Status of the operation
    ### create_invoice
        created_time: When the invoice was created
        invoice_id: Unique identifier of the created invoice
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
        subject: Invoice subject
    ### create_product
        created_time: When the product was created
        message: Message from API
        product_id: Unique identifier of the created product
        product_name: Name of the product
        raw_data: Raw API response data
        status: Status of the operation
    ### create_purchase_order
        created_time: When the purchase order was created
        message: Message from API
        purchase_order_id: Unique identifier of the created purchase order
        raw_data: Raw API response data
        status: Status of the operation
        subject: Purchase order subject
        vendor_id: Vendor ID
    ### create_quote
        created_time: When the quote was created
        message: Message from API
        quote_id: Unique identifier of the created quote
        raw_data: Raw API response data
        status: Status of the operation
        subject: Quote subject
    ### create_vendor
        created_time: When the vendor was created
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
        vendor_id: Unique identifier of the created vendor
        vendor_name: Name of the vendor
    ### list_deals
        deal_amounts: List of amounts
        deal_closing_dates: List of closing dates
        deal_details: List of deal details in JSON format
        deal_ids: List of deal IDs
        deal_names: List of deal names
        deal_probabilities: List of probabilities
        deal_stages: List of stages
        raw_data: Raw API response data
        total_count: Total number of deals returned
    ### update_deal
        deal_id: ID of the updated deal
        message: Message from API
        modified_time: When the deal was modified
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_deal
        deal_id: ID of the deleted deal
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### get_lead_fields
        field_api_names: List of field API names
        field_custom: List indicating if fields are custom
        field_details: List of full field details in JSON format
        field_names: List of field display labels
        field_read_only: List indicating if fields are read-only
        field_required: List indicating if fields are required
        field_types: List of field data types
        raw_data: Raw API response data
    ### list_invoices
        invoice_dates: List of invoice dates
        invoice_details: List of invoice details in JSON format
        invoice_due_dates: List of due dates
        invoice_grand_totals: List of grand totals
        invoice_ids: List of invoice IDs
        invoice_numbers: List of invoice numbers
        invoice_statuses: List of statuses
        invoice_subjects: List of subjects
        raw_data: Raw API response data
        total_count: Total number of invoices returned
    ### update_invoice
        invoice_id: ID of the updated invoice
        message: Message from API
        modified_time: When the invoice was modified
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_invoice
        invoice_id: ID of the deleted invoice
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### list_leads
        lead_companies: List of companies
        lead_details: List of lead details in JSON format
        lead_emails: List of email addresses
        lead_first_names: List of first names
        lead_full_names: List of full names
        lead_ids: List of lead IDs
        lead_last_names: List of last names
        lead_phones: List of phone numbers
        lead_sources: List of lead sources
        lead_statuses: List of lead statuses
        raw_data: Raw API response data
        total_count: Total number of leads returned
    ### update_lead
        lead_id: ID of the updated lead
        message: Message from API
        modified_time: When the lead was modified
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_lead
        lead_id: ID of the deleted lead
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
    ### update_product
        message: Message from API
        modified_time: When the product was modified
        product_id: ID of the updated product
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_product
        message: Message from API
        product_id: ID of the deleted product
        raw_data: Raw API response data
        status: Status of the operation
    ### update_purchase_order
        message: Message from API
        modified_time: When the purchase order was modified
        purchase_order_id: ID of the updated purchase order
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_purchase_order
        message: Message from API
        purchase_order_id: ID of the deleted purchase order
        raw_data: Raw API response data
        status: Status of the operation
    ### update_quote
        message: Message from API
        modified_time: When the quote was modified
        quote_id: ID of the updated quote
        raw_data: Raw API response data
        status: Status of the operation
    ### delete_quote
        message: Message from API
        quote_id: ID of the deleted quote
        raw_data: Raw API response data
        status: Status of the operation
    ### update_sales_order
        message: Message from API
        modified_time: When the sales order was modified
        raw_data: Raw API response data
        sales_order_id: ID of the updated sales order
        status: Status of the operation
    ### delete_sales_order
        message: Message from API
        raw_data: Raw API response data
        sales_order_id: ID of the deleted sales order
        status: Status of the operation
    ### update_vendor
        message: Message from API
        modified_time: When the vendor was modified
        raw_data: Raw API response data
        status: Status of the operation
        vendor_id: ID of the updated vendor
    ### delete_vendor
        message: Message from API
        raw_data: Raw API response data
        status: Status of the operation
        vendor_id: ID of the deleted vendor
    ### list_products
        product_active: List of active statuses
        product_categories: List of product categories
        product_codes: List of product codes
        product_details: List of product details in JSON format
        product_ids: List of product IDs
        product_names: List of product names
        product_taxable: List of taxable statuses
        product_unit_prices: List of unit prices
        raw_data: Raw API response data
        total_count: Total number of products returned
    ### list_purchase_orders
        purchase_order_dates: List of PO dates
        purchase_order_details: List of purchase order details in JSON format
        purchase_order_due_dates: List of due dates
        purchase_order_grand_totals: List of grand totals
        purchase_order_ids: List of purchase order IDs
        purchase_order_numbers: List of PO numbers
        purchase_order_statuses: List of statuses
        purchase_order_subjects: List of subjects
        raw_data: Raw API response data
        total_count: Total number of purchase orders returned
    ### list_quotes
        quote_details: List of quote details in JSON format
        quote_grand_totals: List of grand totals
        quote_ids: List of quote IDs
        quote_numbers: List of quote numbers
        quote_stages: List of quote stages
        quote_subjects: List of subjects
        quote_valid_tills: List of valid till dates
        raw_data: Raw API response data
        total_count: Total number of quotes returned
    ### list_sales_orders
        raw_data: Raw API response data
        sales_order_details: List of sales order details in JSON format
        sales_order_due_dates: List of due dates
        sales_order_grand_totals: List of grand totals
        sales_order_ids: List of sales order IDs
        sales_order_numbers: List of SO numbers
        sales_order_statuses: List of statuses
        sales_order_subjects: List of subjects
        total_count: Total number of sales orders returned
    ### list_vendors
        raw_data: Raw API response data
        total_count: Total number of vendors returned
        vendor_categories: List of categories
        vendor_details: List of vendor details in JSON format
        vendor_emails: List of email addresses
        vendor_ids: List of vendor IDs
        vendor_names: List of vendor names
        vendor_phones: List of phone numbers
        vendor_websites: List of website URLs
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the Zoho CRM operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Zoho CRM account",
            "value": None,
            "type": "integration<Zoho>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_account": {
            "inputs": [
                {
                    "field": "account_name",
                    "type": "string",
                    "value": "",
                    "label": "Account Name",
                    "placeholder": "Acme Corporation",
                    "helper_text": "Name of the account (required)",
                },
                {
                    "field": "account_type",
                    "type": "string",
                    "value": "",
                    "label": "Account Type",
                    "placeholder": "Customer",
                    "helper_text": "Type of account (e.g., Customer, Partner, Prospect, Distributor, or custom type)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Industry of the account",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Account phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://example.com",
                    "helper_text": "Account website URL",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-0000",
                    "helper_text": "Account fax number",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "value": "",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Annual revenue of the account",
                },
                {
                    "field": "employees",
                    "type": "int32",
                    "value": "",
                    "label": "Employees",
                    "placeholder": "100",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "label": "Account Number",
                    "placeholder": "ACC-001",
                    "helper_text": "Account number/identifier",
                },
                {
                    "field": "account_site",
                    "type": "string",
                    "value": "",
                    "label": "Account Site",
                    "placeholder": "Headquarters",
                    "helper_text": "Account site or location name",
                },
                {
                    "field": "ticker_symbol",
                    "type": "string",
                    "value": "",
                    "label": "Ticker Symbol",
                    "placeholder": "ACME",
                    "helper_text": "Stock ticker symbol",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": "",
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate for currency conversion",
                },
                {
                    "field": "contact_details",
                    "type": "string",
                    "value": "",
                    "label": "Contact Details",
                    "placeholder": "Primary contact info",
                    "helper_text": "Additional contact details",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Account description",
                    "helper_text": "Description of the account",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "New York",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "NY",
                    "helper_text": "Billing state/province",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Postal Code",
                    "placeholder": "10001",
                    "helper_text": "Billing postal/zip code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state/province",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Postal Code",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal/zip code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the created account",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the account was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_account",
            "task_name": "tasks.zoho.create_account",
            "description": "Create a new account in Zoho CRM",
            "label": "Create Account",
            "required": ["account_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "account_name",
                "account_type",
                "industry",
                "phone",
                "website",
                "fax",
                "annual_revenue",
                "employees",
                "account_number",
                "account_site",
                "ticker_symbol",
                "currency",
                "exchange_rate",
                "contact_details",
                "description",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "custom_fields",
            ],
        },
        "get_account": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the account to retrieve (required)",
                }
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the account",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "helper_text": "Account number",
                },
                {
                    "field": "account_site",
                    "type": "string",
                    "helper_text": "Account site/location",
                },
                {
                    "field": "account_type",
                    "type": "string",
                    "helper_text": "Type of account",
                },
                {
                    "field": "annual_revenue",
                    "type": "string",
                    "helper_text": "Annual revenue",
                },
                {"field": "currency", "type": "string", "helper_text": "Currency"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {
                    "field": "employees",
                    "type": "int32",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "exchange_rate",
                    "type": "string",
                    "helper_text": "Exchange rate",
                },
                {"field": "fax", "type": "string", "helper_text": "Fax number"},
                {"field": "industry", "type": "string", "helper_text": "Industry type"},
                {"field": "phone", "type": "string", "helper_text": "Phone number"},
                {
                    "field": "ticker_symbol",
                    "type": "string",
                    "helper_text": "Stock ticker symbol",
                },
                {"field": "website", "type": "string", "helper_text": "Website URL"},
                {
                    "field": "billing_street",
                    "type": "string",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the account owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the account owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the account owner",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of the user who created the account",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the account",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of the user who last modified the account",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the account",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the account was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the account was last modified",
                },
                {
                    "field": "account_details",
                    "type": "string",
                    "helper_text": "Full account details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_account",
            "task_name": "tasks.zoho.get_account",
            "description": "Read details of an account",
            "label": "Get Account",
            "required": ["account_id"],
            "inputs_sort_order": ["integration", "action", "account_id"],
        },
        "list_accounts": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all accounts or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of accounts to return (max 200 per page)",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Account_Name",
                    "helper_text": "Field to sort records by (e.g., Account_Name, Created_Time, Modified_Time)",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order: ascending or descending",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_sort_order",
                    },
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Account_Name,Phone,Website,Industry",
                    "helper_text": "Comma-separated list of specific fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of account IDs",
                },
                {
                    "field": "account_names",
                    "type": "vec<string>",
                    "helper_text": "List of account names",
                },
                {
                    "field": "account_types",
                    "type": "vec<string>",
                    "helper_text": "List of account types",
                },
                {
                    "field": "account_phones",
                    "type": "vec<string>",
                    "helper_text": "List of phone numbers",
                },
                {
                    "field": "account_websites",
                    "type": "vec<string>",
                    "helper_text": "List of websites",
                },
                {
                    "field": "account_industries",
                    "type": "vec<string>",
                    "helper_text": "List of industries",
                },
                {
                    "field": "account_details",
                    "type": "vec<string>",
                    "helper_text": "List of account details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of accounts returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_accounts",
            "task_name": "tasks.zoho.list_accounts",
            "description": "Get multiple accounts",
            "label": "List Accounts",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "upsert_account": {
            "inputs": [
                {
                    "field": "account_name",
                    "type": "string",
                    "value": "",
                    "label": "Account Name",
                    "placeholder": "Acme Corporation",
                    "helper_text": "Name of the account (required, used for matching existing records)",
                },
                {
                    "field": "account_type",
                    "type": "string",
                    "value": "",
                    "label": "Account Type",
                    "placeholder": "Customer",
                    "helper_text": "Type of account (e.g., Customer, Partner, Prospect, Distributor, or custom type)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Industry of the account",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Account phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://example.com",
                    "helper_text": "Account website URL",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-0000",
                    "helper_text": "Account fax number",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "value": "",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Annual revenue of the account",
                },
                {
                    "field": "employees",
                    "type": "int32",
                    "value": "",
                    "label": "Employees",
                    "placeholder": "100",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "label": "Account Number",
                    "placeholder": "ACC-001",
                    "helper_text": "Account number/identifier",
                },
                {
                    "field": "account_site",
                    "type": "string",
                    "value": "",
                    "label": "Account Site",
                    "placeholder": "Headquarters",
                    "helper_text": "Account site or location name",
                },
                {
                    "field": "ticker_symbol",
                    "type": "string",
                    "value": "",
                    "label": "Ticker Symbol",
                    "placeholder": "ACME",
                    "helper_text": "Stock ticker symbol",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": "",
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate for currency conversion",
                },
                {
                    "field": "contact_details",
                    "type": "string",
                    "value": "",
                    "label": "Contact Details",
                    "placeholder": "Primary contact info",
                    "helper_text": "Additional contact details",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Account description",
                    "helper_text": "Description of the account",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "New York",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "NY",
                    "helper_text": "Billing state/province",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Postal Code",
                    "placeholder": "10001",
                    "helper_text": "Billing postal/zip code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state/province",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Postal Code",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal/zip code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the account",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_account",
            "task_name": "tasks.zoho.upsert_account",
            "description": "Create or update an account in Zoho CRM",
            "label": "Create or Update Account",
            "required": ["account_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "account_name",
                "account_type",
                "industry",
                "phone",
                "website",
                "fax",
                "annual_revenue",
                "employees",
                "account_number",
                "account_site",
                "ticker_symbol",
                "currency",
                "exchange_rate",
                "contact_details",
                "description",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "custom_fields",
            ],
        },
        "update_account": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the account to update (required)",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "value": "",
                    "label": "Account Name",
                    "placeholder": "Acme Corporation",
                    "helper_text": "New name for the account",
                },
                {
                    "field": "account_type",
                    "type": "string",
                    "value": "",
                    "label": "Account Type",
                    "placeholder": "Customer",
                    "helper_text": "Type of account (e.g., Customer, Partner, Prospect, Distributor, or custom type)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Industry of the account",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Account phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://example.com",
                    "helper_text": "Account website URL",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-0000",
                    "helper_text": "Account fax number",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "value": "",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Annual revenue of the account",
                },
                {
                    "field": "employees",
                    "type": "int32",
                    "value": "",
                    "label": "Employees",
                    "placeholder": "100",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "label": "Account Number",
                    "placeholder": "ACC-001",
                    "helper_text": "Account number/identifier",
                },
                {
                    "field": "account_site",
                    "type": "string",
                    "value": "",
                    "label": "Account Site",
                    "placeholder": "Headquarters",
                    "helper_text": "Account site or location name",
                },
                {
                    "field": "ticker_symbol",
                    "type": "string",
                    "value": "",
                    "label": "Ticker Symbol",
                    "placeholder": "ACME",
                    "helper_text": "Stock ticker symbol",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": "",
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate for currency conversion",
                },
                {
                    "field": "contact_details",
                    "type": "string",
                    "value": "",
                    "label": "Contact Details",
                    "placeholder": "Primary contact info",
                    "helper_text": "Additional contact details",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Account description",
                    "helper_text": "Description of the account",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "New York",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "NY",
                    "helper_text": "Billing state/province",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Postal Code",
                    "placeholder": "10001",
                    "helper_text": "Billing postal/zip code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state/province",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Postal Code",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal/zip code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the updated account",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the account was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_account",
            "task_name": "tasks.zoho.update_account",
            "description": "Update an existing account in Zoho CRM",
            "label": "Update Account",
            "required": ["account_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "account_id",
                "account_name",
                "account_type",
                "industry",
                "phone",
                "website",
                "fax",
                "annual_revenue",
                "employees",
                "account_number",
                "account_site",
                "ticker_symbol",
                "currency",
                "exchange_rate",
                "contact_details",
                "description",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "custom_fields",
            ],
        },
        "delete_account": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the account to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the deleted account",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_account",
            "task_name": "tasks.zoho.delete_account",
            "description": "Delete an account from Zoho CRM",
            "label": "Delete Account",
            "required": ["account_id"],
            "inputs_sort_order": ["integration", "action", "account_id"],
        },
        "create_contact": {
            "inputs": [
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name of the contact (required)",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "First name",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "John Doe",
                    "helper_text": "Full name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email (Primary)",
                    "placeholder": "john.doe@example.com",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "value": "",
                    "label": "Email (Secondary)",
                    "placeholder": "john.backup@example.com",
                    "helper_text": "Secondary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "mobile",
                    "type": "string",
                    "value": "",
                    "label": "Mobile",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1-555-9012",
                    "helper_text": "Home phone number",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "value": "",
                    "label": "Other Phone",
                    "placeholder": "+1-555-3456",
                    "helper_text": "Other phone number",
                },
                {
                    "field": "asst_phone",
                    "type": "string",
                    "value": "",
                    "label": "Assistant Phone",
                    "placeholder": "+1-555-7890",
                    "helper_text": "Assistant's phone number",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-1111",
                    "helper_text": "Fax number",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Sales",
                    "helper_text": "Department the contact belongs to",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title",
                },
                {
                    "field": "assistant",
                    "type": "string",
                    "value": "",
                    "label": "Assistant",
                    "placeholder": "Jane Smith",
                    "helper_text": "Name of the contact's assistant",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Key contact for enterprise deals",
                    "helper_text": "Description of the contact",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "helper_text": "Salutation (Mr., Mrs., Ms., Dr., etc.)",
                },
                {
                    "field": "date_of_birth",
                    "type": "timestamp",
                    "value": "",
                    "label": "Date of Birth",
                    "placeholder": "1990-05-15",
                    "helper_text": "Date of birth (YYYY-MM-DD format)",
                },
                {
                    "field": "skype_id",
                    "type": "string",
                    "value": "",
                    "label": "Skype ID",
                    "placeholder": "john.doe.skype",
                    "helper_text": "Skype ID",
                },
                {
                    "field": "twitter",
                    "type": "string",
                    "value": "",
                    "label": "Twitter",
                    "placeholder": "@johndoe",
                    "helper_text": "Twitter handle",
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Mailing street address",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Mailing city",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "label": "Mailing State",
                    "placeholder": "CA",
                    "helper_text": "Mailing state/province",
                },
                {
                    "field": "mailing_zip",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Zip",
                    "placeholder": "94102",
                    "helper_text": "Mailing postal/zip code",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                    "helper_text": "Mailing country",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Other street address",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "label": "Other City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Other city",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "label": "Other State",
                    "placeholder": "CA",
                    "helper_text": "Other state/province",
                },
                {
                    "field": "other_zip",
                    "type": "string",
                    "value": "",
                    "label": "Other Zip",
                    "placeholder": "90001",
                    "helper_text": "Other postal/zip code",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "label": "Other Country",
                    "placeholder": "USA",
                    "helper_text": "Other country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created contact",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Last name of the contact",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the contact was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_contact",
            "task_name": "tasks.zoho.create_contact",
            "description": "Create a new contact in Zoho CRM",
            "label": "Create Contact",
            "required": ["last_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "last_name",
                "first_name",
                "full_name",
                "email",
                "secondary_email",
                "phone",
                "mobile",
                "home_phone",
                "other_phone",
                "asst_phone",
                "fax",
                "department",
                "title",
                "assistant",
                "description",
                "salutation",
                "date_of_birth",
                "skype_id",
                "twitter",
                "mailing_street",
                "mailing_city",
                "mailing_state",
                "mailing_zip",
                "mailing_country",
                "other_street",
                "other_city",
                "other_state",
                "other_zip",
                "other_country",
                "custom_fields",
            ],
        },
        "get_contact": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the contact to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the contact",
                },
                {"field": "first_name", "type": "string", "helper_text": "First name"},
                {"field": "last_name", "type": "string", "helper_text": "Last name"},
                {"field": "full_name", "type": "string", "helper_text": "Full name"},
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "helper_text": "Secondary email address",
                },
                {"field": "phone", "type": "string", "helper_text": "Phone number"},
                {"field": "mobile", "type": "string", "helper_text": "Mobile number"},
                {
                    "field": "home_phone",
                    "type": "string",
                    "helper_text": "Home phone number",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "helper_text": "Other phone number",
                },
                {
                    "field": "asst_phone",
                    "type": "string",
                    "helper_text": "Assistant's phone number",
                },
                {"field": "fax", "type": "string", "helper_text": "Fax number"},
                {"field": "department", "type": "string", "helper_text": "Department"},
                {"field": "title", "type": "string", "helper_text": "Job title"},
                {
                    "field": "assistant",
                    "type": "string",
                    "helper_text": "Assistant name",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {"field": "salutation", "type": "string", "helper_text": "Salutation"},
                {
                    "field": "date_of_birth",
                    "type": "timestamp",
                    "helper_text": "Date of birth",
                },
                {"field": "skype_id", "type": "string", "helper_text": "Skype ID"},
                {"field": "twitter", "type": "string", "helper_text": "Twitter handle"},
                {
                    "field": "mailing_street",
                    "type": "string",
                    "helper_text": "Mailing street address",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "helper_text": "Mailing city",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "helper_text": "Mailing state",
                },
                {
                    "field": "mailing_zip",
                    "type": "string",
                    "helper_text": "Mailing zip code",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "helper_text": "Mailing country",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "helper_text": "Other street address",
                },
                {"field": "other_city", "type": "string", "helper_text": "Other city"},
                {
                    "field": "other_state",
                    "type": "string",
                    "helper_text": "Other state",
                },
                {
                    "field": "other_zip",
                    "type": "string",
                    "helper_text": "Other zip code",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "helper_text": "Other country",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Associated account ID",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Associated account name",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the contact owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the contact owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the contact owner",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the contact was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the contact was last modified",
                },
                {
                    "field": "contact_details",
                    "type": "string",
                    "helper_text": "Full contact details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_contact",
            "task_name": "tasks.zoho.get_contact",
            "description": "Read details of a contact",
            "label": "Get Contact",
            "required": ["contact_id"],
            "inputs_sort_order": ["integration", "action", "contact_id"],
        },
        "list_contacts": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all contacts or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of contacts to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Last_Name",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "First_Name,Last_Name,Email",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "List of contact IDs",
                },
                {
                    "field": "contact_first_names",
                    "type": "vec<string>",
                    "helper_text": "List of first names",
                },
                {
                    "field": "contact_last_names",
                    "type": "vec<string>",
                    "helper_text": "List of last names",
                },
                {
                    "field": "contact_full_names",
                    "type": "vec<string>",
                    "helper_text": "List of full names",
                },
                {
                    "field": "contact_emails",
                    "type": "vec<string>",
                    "helper_text": "List of email addresses",
                },
                {
                    "field": "contact_phones",
                    "type": "vec<string>",
                    "helper_text": "List of phone numbers",
                },
                {
                    "field": "contact_mobiles",
                    "type": "vec<string>",
                    "helper_text": "List of mobile numbers",
                },
                {
                    "field": "contact_departments",
                    "type": "vec<string>",
                    "helper_text": "List of departments",
                },
                {
                    "field": "contact_titles",
                    "type": "vec<string>",
                    "helper_text": "List of job titles",
                },
                {
                    "field": "contact_details",
                    "type": "vec<string>",
                    "helper_text": "List of contact details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of contacts returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_contacts",
            "task_name": "tasks.zoho.list_contacts",
            "description": "Get multiple contacts",
            "label": "List Contacts",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_contact": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the contact to update (required)",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "First name",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "John Doe",
                    "helper_text": "Full name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email (Primary)",
                    "placeholder": "john.doe@example.com",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "value": "",
                    "label": "Email (Secondary)",
                    "placeholder": "john.backup@example.com",
                    "helper_text": "Secondary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "mobile",
                    "type": "string",
                    "value": "",
                    "label": "Mobile",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1-555-9012",
                    "helper_text": "Home phone number",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "value": "",
                    "label": "Other Phone",
                    "placeholder": "+1-555-3456",
                    "helper_text": "Other phone number",
                },
                {
                    "field": "asst_phone",
                    "type": "string",
                    "value": "",
                    "label": "Assistant Phone",
                    "placeholder": "+1-555-7890",
                    "helper_text": "Assistant's phone number",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-1111",
                    "helper_text": "Fax number",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Sales",
                    "helper_text": "Department the contact belongs to",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title",
                },
                {
                    "field": "assistant",
                    "type": "string",
                    "value": "",
                    "label": "Assistant",
                    "placeholder": "Jane Smith",
                    "helper_text": "Name of the contact's assistant",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Key contact for enterprise deals",
                    "helper_text": "Description of the contact",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "helper_text": "Salutation (Mr., Mrs., Ms., Dr., etc.)",
                },
                {
                    "field": "date_of_birth",
                    "type": "timestamp",
                    "value": "",
                    "label": "Date of Birth",
                    "placeholder": "1990-05-15",
                    "helper_text": "Date of birth (YYYY-MM-DD format)",
                },
                {
                    "field": "skype_id",
                    "type": "string",
                    "value": "",
                    "label": "Skype ID",
                    "placeholder": "john.doe.skype",
                    "helper_text": "Skype ID",
                },
                {
                    "field": "twitter",
                    "type": "string",
                    "value": "",
                    "label": "Twitter",
                    "placeholder": "@johndoe",
                    "helper_text": "Twitter handle",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Mailing street address",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Mailing city",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "label": "Mailing State",
                    "placeholder": "CA",
                    "helper_text": "Mailing state/province",
                },
                {
                    "field": "mailing_zip",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Zip",
                    "placeholder": "94102",
                    "helper_text": "Mailing postal/zip code",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                    "helper_text": "Mailing country",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Other street address",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "label": "Other City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Other city",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "label": "Other State",
                    "placeholder": "CA",
                    "helper_text": "Other state/province",
                },
                {
                    "field": "other_zip",
                    "type": "string",
                    "value": "",
                    "label": "Other Zip",
                    "placeholder": "90001",
                    "helper_text": "Other postal/zip code",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "label": "Other Country",
                    "placeholder": "USA",
                    "helper_text": "Other country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the updated contact",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the contact was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_contact",
            "task_name": "tasks.zoho.update_contact",
            "description": "Update an existing contact in Zoho CRM",
            "label": "Update Contact",
            "required": ["contact_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "contact_id",
                "last_name",
                "first_name",
                "full_name",
                "email",
                "secondary_email",
                "phone",
                "mobile",
                "home_phone",
                "other_phone",
                "asst_phone",
                "fax",
                "department",
                "title",
                "assistant",
                "description",
                "salutation",
                "date_of_birth",
                "skype_id",
                "twitter",
                "currency",
                "mailing_street",
                "mailing_city",
                "mailing_state",
                "mailing_zip",
                "mailing_country",
                "other_street",
                "other_city",
                "other_state",
                "other_zip",
                "other_country",
                "custom_fields",
            ],
        },
        "delete_contact": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the contact to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the deleted contact",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_contact",
            "task_name": "tasks.zoho.delete_contact",
            "description": "Delete a contact from Zoho CRM",
            "label": "Delete Contact",
            "required": ["contact_id"],
            "inputs_sort_order": ["integration", "action", "contact_id"],
        },
        "upsert_contact": {
            "inputs": [
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name of the contact (required)",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "First name",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "John Doe",
                    "helper_text": "Full name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email (Primary)",
                    "placeholder": "john.doe@example.com",
                    "helper_text": "Primary email address (used for matching existing records)",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "value": "",
                    "label": "Email (Secondary)",
                    "placeholder": "john.backup@example.com",
                    "helper_text": "Secondary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "mobile",
                    "type": "string",
                    "value": "",
                    "label": "Mobile",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1-555-9012",
                    "helper_text": "Home phone number",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "value": "",
                    "label": "Other Phone",
                    "placeholder": "+1-555-3456",
                    "helper_text": "Other phone number",
                },
                {
                    "field": "asst_phone",
                    "type": "string",
                    "value": "",
                    "label": "Assistant Phone",
                    "placeholder": "+1-555-7890",
                    "helper_text": "Assistant's phone number",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-1111",
                    "helper_text": "Fax number",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Sales",
                    "helper_text": "Department the contact belongs to",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title",
                },
                {
                    "field": "assistant",
                    "type": "string",
                    "value": "",
                    "label": "Assistant",
                    "placeholder": "Jane Smith",
                    "helper_text": "Name of the contact's assistant",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Key contact for enterprise deals",
                    "helper_text": "Description of the contact",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "helper_text": "Salutation (Mr., Mrs., Ms., Dr., etc.)",
                },
                {
                    "field": "date_of_birth",
                    "type": "timestamp",
                    "value": "",
                    "label": "Date of Birth",
                    "placeholder": "1990-05-15",
                    "helper_text": "Date of birth (YYYY-MM-DD format)",
                },
                {
                    "field": "skype_id",
                    "type": "string",
                    "value": "",
                    "label": "Skype ID",
                    "placeholder": "john.doe.skype",
                    "helper_text": "Skype ID",
                },
                {
                    "field": "twitter",
                    "type": "string",
                    "value": "",
                    "label": "Twitter",
                    "placeholder": "@johndoe",
                    "helper_text": "Twitter handle",
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Mailing street address",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Mailing city",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "label": "Mailing State",
                    "placeholder": "CA",
                    "helper_text": "Mailing state/province",
                },
                {
                    "field": "mailing_zip",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Zip",
                    "placeholder": "94102",
                    "helper_text": "Mailing postal/zip code",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                    "helper_text": "Mailing country",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Other street address",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "label": "Other City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Other city",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "label": "Other State",
                    "placeholder": "CA",
                    "helper_text": "Other state/province",
                },
                {
                    "field": "other_zip",
                    "type": "string",
                    "value": "",
                    "label": "Other Zip",
                    "placeholder": "90001",
                    "helper_text": "Other postal/zip code",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "label": "Other Country",
                    "placeholder": "USA",
                    "helper_text": "Other country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the contact",
                },
                {"field": "last_name", "type": "string", "helper_text": "Last name"},
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_contact",
            "task_name": "tasks.zoho.upsert_contact",
            "description": "Create or update a contact in Zoho CRM",
            "label": "Create or Update Contact",
            "required": ["last_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "last_name",
                "first_name",
                "full_name",
                "email",
                "secondary_email",
                "phone",
                "mobile",
                "home_phone",
                "other_phone",
                "asst_phone",
                "fax",
                "department",
                "title",
                "assistant",
                "description",
                "salutation",
                "date_of_birth",
                "skype_id",
                "twitter",
                "mailing_street",
                "mailing_city",
                "mailing_state",
                "mailing_zip",
                "mailing_country",
                "other_street",
                "other_city",
                "other_state",
                "other_zip",
                "other_country",
                "custom_fields",
            ],
        },
        "create_deal": {
            "inputs": [
                {
                    "field": "deal_name",
                    "type": "string",
                    "value": "",
                    "label": "Deal Name",
                    "placeholder": "Q4 Enterprise Deal",
                    "helper_text": "Name of the deal (required)",
                },
                {
                    "field": "stage",
                    "type": "string",
                    "value": "",
                    "label": "Stage",
                    "placeholder": "Qualification",
                    "helper_text": "Deal stage (e.g., Qualification, Needs Analysis, Value Proposition, Identify Decision Makers, Proposal/Price Quote, Negotiation/Review, Closed Won, Closed Lost, or custom stage) (required)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_deal_stage",
                    },
                },
                {
                    "field": "amount",
                    "type": "float",
                    "value": 0,
                    "label": "Amount",
                    "placeholder": "50000",
                    "helper_text": "Monetary amount of the deal",
                },
                {
                    "field": "closing_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Closing Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Expected closing date (YYYY-MM-DD format)",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Enterprise software solution deal",
                    "helper_text": "Description of the deal",
                },
                {
                    "field": "lead_conversion_time",
                    "type": "int32",
                    "value": 0,
                    "label": "Lead Conversion Time",
                    "placeholder": "30",
                    "helper_text": "Days to convert lead to deal",
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "label": "Next Step",
                    "placeholder": "Schedule demo with stakeholders",
                    "helper_text": "Next step in the sales process",
                },
                {
                    "field": "overall_sales_duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Overall Sales Duration",
                    "placeholder": "90",
                    "helper_text": "Total days from lead to closed deal",
                },
                {
                    "field": "probability",
                    "type": "int32",
                    "value": 0,
                    "label": "Probability (%)",
                    "placeholder": "75",
                    "helper_text": "Probability of deal closure (0-100)",
                },
                {
                    "field": "sales_cycle_duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Sales Cycle Duration",
                    "placeholder": "60",
                    "helper_text": "Days to win the deal",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created deal",
                },
                {
                    "field": "deal_name",
                    "type": "string",
                    "helper_text": "Name of the deal",
                },
                {"field": "stage", "type": "string", "helper_text": "Deal stage"},
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the deal was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_deal",
            "task_name": "tasks.zoho.create_deal",
            "description": "Create a new deal in Zoho CRM",
            "label": "Create Deal",
            "required": ["deal_name", "stage"],
            "inputs_sort_order": [
                "integration",
                "action",
                "deal_name",
                "stage",
                "amount",
                "closing_date",
                "currency",
                "description",
                "lead_conversion_time",
                "next_step",
                "overall_sales_duration",
                "probability",
                "sales_cycle_duration",
                "custom_fields",
            ],
        },
        "get_deal": {
            "inputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the deal to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the deal",
                },
                {
                    "field": "deal_name",
                    "type": "string",
                    "helper_text": "Name of the deal",
                },
                {"field": "stage", "type": "string", "helper_text": "Current stage"},
                {"field": "amount", "type": "string", "helper_text": "Deal amount"},
                {
                    "field": "closing_date",
                    "type": "timestamp",
                    "helper_text": "Expected closing date",
                },
                {
                    "field": "probability",
                    "type": "string",
                    "helper_text": "Probability percentage",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Deal description",
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "helper_text": "Next step in sales process",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "helper_text": "Source of the lead",
                },
                {"field": "type", "type": "string", "helper_text": "Deal type"},
                {"field": "currency", "type": "string", "helper_text": "Currency code"},
                {
                    "field": "exchange_rate",
                    "type": "string",
                    "helper_text": "Exchange rate",
                },
                {
                    "field": "lead_conversion_time",
                    "type": "string",
                    "helper_text": "Days to convert lead",
                },
                {
                    "field": "overall_sales_duration",
                    "type": "string",
                    "helper_text": "Total days from lead to close",
                },
                {
                    "field": "sales_cycle_duration",
                    "type": "string",
                    "helper_text": "Days to win deal",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Associated account ID",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Associated account name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Associated contact ID",
                },
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Associated contact name",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the deal owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the deal owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the deal owner",
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "helper_text": "Associated campaign ID",
                },
                {
                    "field": "campaign_name",
                    "type": "string",
                    "helper_text": "Associated campaign name",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the deal was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the deal was last modified",
                },
                {
                    "field": "deal_details",
                    "type": "string",
                    "helper_text": "Full deal details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_deal",
            "task_name": "tasks.zoho.get_deal",
            "description": "Read details of a deal",
            "label": "Get Deal",
            "required": ["deal_id"],
            "inputs_sort_order": ["integration", "action", "deal_id"],
        },
        "list_deals": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all deals or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of deals to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Closing_Date",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Deal_Name,Stage,Amount",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "deal_ids",
                    "type": "vec<string>",
                    "helper_text": "List of deal IDs",
                },
                {
                    "field": "deal_names",
                    "type": "vec<string>",
                    "helper_text": "List of deal names",
                },
                {
                    "field": "deal_stages",
                    "type": "vec<string>",
                    "helper_text": "List of stages",
                },
                {
                    "field": "deal_amounts",
                    "type": "vec<string>",
                    "helper_text": "List of amounts",
                },
                {
                    "field": "deal_closing_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of closing dates",
                },
                {
                    "field": "deal_probabilities",
                    "type": "vec<string>",
                    "helper_text": "List of probabilities",
                },
                {
                    "field": "deal_details",
                    "type": "vec<string>",
                    "helper_text": "List of deal details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of deals returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_deals",
            "task_name": "tasks.zoho.list_deals",
            "description": "Get multiple deals",
            "label": "List Deals",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_deal": {
            "inputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the deal to update (required)",
                },
                {
                    "field": "amount",
                    "type": "float",
                    "value": 0,
                    "label": "Amount",
                    "placeholder": "50000",
                    "helper_text": "Monetary amount of the deal",
                },
                {
                    "field": "closing_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Closing Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Expected closing date (YYYY-MM-DD format)",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "placeholder": "USD",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "deal_name",
                    "type": "string",
                    "value": "",
                    "label": "Deal Name",
                    "placeholder": "Q4 Enterprise Deal",
                    "helper_text": "Name of the deal",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Enterprise software solution deal",
                    "helper_text": "Description of the deal",
                },
                {
                    "field": "lead_conversion_time",
                    "type": "int32",
                    "value": 0,
                    "label": "Lead Conversion Time",
                    "placeholder": "30",
                    "helper_text": "Days to convert lead to deal",
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "label": "Next Step",
                    "placeholder": "Schedule demo with stakeholders",
                    "helper_text": "Next step in the sales process",
                },
                {
                    "field": "overall_sales_duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Overall Sales Duration",
                    "placeholder": "90",
                    "helper_text": "Total days from lead to closed deal",
                },
                {
                    "field": "probability",
                    "type": "int32",
                    "value": 0,
                    "label": "Probability (%)",
                    "placeholder": "75",
                    "helper_text": "Probability of deal closure (0-100)",
                },
                {
                    "field": "sales_cycle_duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Sales Cycle Duration",
                    "placeholder": "60",
                    "helper_text": "Days to win the deal",
                },
                {
                    "field": "stage",
                    "type": "string",
                    "value": "",
                    "label": "Stage",
                    "placeholder": "Qualification",
                    "helper_text": "Deal stage (e.g., Qualification, Needs Analysis, Value Proposition, Identify Decision Makers, Proposal/Price Quote, Negotiation/Review, Closed Won, Closed Lost, or custom stage)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_deal_stage",
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "ID of the updated deal",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the deal was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_deal",
            "task_name": "tasks.zoho.update_deal",
            "description": "Update an existing deal in Zoho CRM",
            "label": "Update Deal",
            "required": ["deal_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "deal_id",
                "amount",
                "closing_date",
                "currency",
                "deal_name",
                "description",
                "lead_conversion_time",
                "next_step",
                "overall_sales_duration",
                "probability",
                "sales_cycle_duration",
                "stage",
                "custom_fields",
            ],
        },
        "delete_deal": {
            "inputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the deal to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "ID of the deleted deal",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_deal",
            "task_name": "tasks.zoho.delete_deal",
            "description": "Delete a deal from Zoho CRM",
            "label": "Delete Deal",
            "required": ["deal_id"],
            "inputs_sort_order": ["integration", "action", "deal_id"],
        },
        "upsert_deal": {
            "inputs": [
                {
                    "field": "deal_name",
                    "type": "string",
                    "value": "",
                    "label": "Deal Name",
                    "placeholder": "Q4 Enterprise Deal",
                    "helper_text": "Name of the deal (required, used for matching)",
                },
                {
                    "field": "stage",
                    "type": "string",
                    "value": "",
                    "label": "Stage",
                    "placeholder": "Qualification",
                    "helper_text": "Deal stage (e.g., Qualification, Needs Analysis, Value Proposition, Identify Decision Makers, Proposal/Price Quote, Negotiation/Review, Closed Won, Closed Lost, or custom stage) (required)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_deal_stage",
                    },
                },
                {
                    "field": "amount",
                    "type": "float",
                    "value": 0,
                    "label": "Amount",
                    "placeholder": "50000",
                    "helper_text": "Monetary amount of the deal",
                },
                {
                    "field": "closing_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Closing Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Expected closing date (YYYY-MM-DD format)",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Enterprise software solution deal",
                    "helper_text": "Description of the deal",
                },
                {
                    "field": "lead_conversion_time",
                    "type": "int32",
                    "value": 0,
                    "label": "Lead Conversion Time",
                    "placeholder": "30",
                    "helper_text": "Days to convert lead to deal",
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "label": "Next Step",
                    "placeholder": "Schedule demo with stakeholders",
                    "helper_text": "Next step in the sales process",
                },
                {
                    "field": "overall_sales_duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Overall Sales Duration",
                    "placeholder": "90",
                    "helper_text": "Total days from lead to closed deal",
                },
                {
                    "field": "probability",
                    "type": "int32",
                    "value": 0,
                    "label": "Probability (%)",
                    "placeholder": "75",
                    "helper_text": "Probability of deal closure (0-100)",
                },
                {
                    "field": "sales_cycle_duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Sales Cycle Duration",
                    "placeholder": "60",
                    "helper_text": "Days to win the deal",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {"field": "deal_id", "type": "string", "helper_text": "ID of the deal"},
                {
                    "field": "deal_name",
                    "type": "string",
                    "helper_text": "Name of the deal",
                },
                {"field": "stage", "type": "string", "helper_text": "Deal stage"},
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_deal",
            "task_name": "tasks.zoho.upsert_deal",
            "description": "Create or update a deal in Zoho CRM",
            "label": "Create or Update Deal",
            "required": ["deal_name", "stage"],
            "inputs_sort_order": [
                "integration",
                "action",
                "deal_name",
                "stage",
                "amount",
                "closing_date",
                "currency",
                "description",
                "lead_conversion_time",
                "next_step",
                "overall_sales_duration",
                "probability",
                "sales_cycle_duration",
                "custom_fields",
            ],
        },
        "create_lead": {
            "inputs": [
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Smith",
                    "helper_text": "Last name of the lead (required)",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Inc",
                    "helper_text": "Company name (required)",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "value": 0,
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Annual revenue of the lead's company",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "San Francisco",
                    "helper_text": "City",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description of the lead",
                },
                {
                    "field": "designation",
                    "type": "string",
                    "value": "",
                    "label": "Designation",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title/designation",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "jane.smith@example.com",
                    "helper_text": "Email address",
                },
                {
                    "field": "email_opt_out",
                    "type": "bool",
                    "value": False,
                    "label": "Email Opt Out",
                    "helper_text": "Whether the lead has opted out of emails",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-9999",
                    "helper_text": "Fax number",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "Jane",
                    "helper_text": "First name of the lead",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "Jane Smith",
                    "helper_text": "Full name of the lead",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Industry the lead belongs to",
                },
                {
                    "field": "industry_type",
                    "type": "string",
                    "value": "",
                    "label": "Industry Type",
                    "placeholder": "SaaS",
                    "helper_text": "Type of industry",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "label": "Lead Source",
                    "placeholder": "Website",
                    "helper_text": "Source of the lead",
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "value": "",
                    "label": "Lead Status",
                    "placeholder": "Contacted",
                    "helper_text": "Status of the lead",
                },
                {
                    "field": "mobile",
                    "type": "string",
                    "value": "",
                    "label": "Mobile",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "no_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "placeholder": "50",
                    "helper_text": "Number of employees in the lead's company",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "helper_text": "Salutation (Mr., Ms., etc.)",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "value": "",
                    "label": "Secondary Email",
                    "placeholder": "jane.backup@example.com",
                    "helper_text": "Secondary email address",
                },
                {
                    "field": "skype_id",
                    "type": "string",
                    "value": "",
                    "label": "Skype ID",
                    "placeholder": "jane.smith",
                    "helper_text": "Skype ID",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "CA",
                    "helper_text": "State",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "twitter",
                    "type": "string",
                    "value": "",
                    "label": "Twitter",
                    "placeholder": "@janesmith",
                    "helper_text": "Twitter handle",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://example.com",
                    "helper_text": "Website URL",
                },
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "94102",
                    "helper_text": "Postal code",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created lead",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Last name of the lead",
                },
                {"field": "company", "type": "string", "helper_text": "Company name"},
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the lead was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_lead",
            "task_name": "tasks.zoho.create_lead",
            "description": "Create a new lead in Zoho CRM",
            "label": "Create Lead",
            "required": ["last_name", "company"],
            "inputs_sort_order": [
                "integration",
                "action",
                "last_name",
                "company",
                "annual_revenue",
                "city",
                "country",
                "currency",
                "description",
                "designation",
                "email",
                "email_opt_out",
                "fax",
                "first_name",
                "full_name",
                "industry",
                "industry_type",
                "lead_source",
                "lead_status",
                "mobile",
                "no_of_employees",
                "phone",
                "salutation",
                "secondary_email",
                "skype_id",
                "state",
                "street",
                "twitter",
                "website",
                "zip_code",
                "custom_fields",
            ],
        },
        "get_lead": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "label": "Lead ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the lead to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the lead",
                },
                {"field": "company", "type": "string", "helper_text": "Company name"},
                {"field": "first_name", "type": "string", "helper_text": "First name"},
                {"field": "last_name", "type": "string", "helper_text": "Last name"},
                {"field": "full_name", "type": "string", "helper_text": "Full name"},
                {"field": "salutation", "type": "string", "helper_text": "Salutation"},
                {"field": "email", "type": "string", "helper_text": "Email address"},
                {
                    "field": "secondary_email",
                    "type": "string",
                    "helper_text": "Secondary email",
                },
                {"field": "phone", "type": "string", "helper_text": "Phone number"},
                {"field": "mobile", "type": "string", "helper_text": "Mobile number"},
                {"field": "fax", "type": "string", "helper_text": "Fax number"},
                {"field": "website", "type": "string", "helper_text": "Website URL"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {
                    "field": "designation",
                    "type": "string",
                    "helper_text": "Designation",
                },
                {"field": "industry", "type": "string", "helper_text": "Industry"},
                {
                    "field": "industry_type",
                    "type": "string",
                    "helper_text": "Industry type",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "helper_text": "Annual revenue",
                },
                {
                    "field": "no_of_employees",
                    "type": "int32",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "helper_text": "Source of the lead",
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "helper_text": "Status of the lead",
                },
                {
                    "field": "email_opt_out",
                    "type": "bool",
                    "helper_text": "Email opt out status",
                },
                {"field": "skype_id", "type": "string", "helper_text": "Skype ID"},
                {"field": "twitter", "type": "string", "helper_text": "Twitter handle"},
                {"field": "street", "type": "string", "helper_text": "Street address"},
                {"field": "city", "type": "string", "helper_text": "City"},
                {"field": "state", "type": "string", "helper_text": "State"},
                {"field": "zip_code", "type": "string", "helper_text": "Postal code"},
                {"field": "country", "type": "string", "helper_text": "Country"},
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the lead owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the lead owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the lead owner",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the lead was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the lead was last modified",
                },
                {
                    "field": "lead_details",
                    "type": "string",
                    "helper_text": "Full lead details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_lead",
            "task_name": "tasks.zoho.get_lead",
            "description": "Read details of a lead",
            "label": "Get Lead",
            "required": ["lead_id"],
            "inputs_sort_order": ["integration", "action", "lead_id"],
        },
        "list_leads": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all leads or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of leads to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Last_Name",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "First_Name,Last_Name,Email,Company",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "lead_ids",
                    "type": "vec<string>",
                    "helper_text": "List of lead IDs",
                },
                {
                    "field": "lead_companies",
                    "type": "vec<string>",
                    "helper_text": "List of companies",
                },
                {
                    "field": "lead_first_names",
                    "type": "vec<string>",
                    "helper_text": "List of first names",
                },
                {
                    "field": "lead_last_names",
                    "type": "vec<string>",
                    "helper_text": "List of last names",
                },
                {
                    "field": "lead_full_names",
                    "type": "vec<string>",
                    "helper_text": "List of full names",
                },
                {
                    "field": "lead_emails",
                    "type": "vec<string>",
                    "helper_text": "List of email addresses",
                },
                {
                    "field": "lead_phones",
                    "type": "vec<string>",
                    "helper_text": "List of phone numbers",
                },
                {
                    "field": "lead_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of lead statuses",
                },
                {
                    "field": "lead_sources",
                    "type": "vec<string>",
                    "helper_text": "List of lead sources",
                },
                {
                    "field": "lead_details",
                    "type": "vec<string>",
                    "helper_text": "List of lead details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of leads returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_leads",
            "task_name": "tasks.zoho.list_leads",
            "description": "Get multiple leads",
            "label": "List Leads",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_lead": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "label": "Lead ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the lead to update (required)",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "value": 0,
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Annual revenue of the lead's company",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "San Francisco",
                    "helper_text": "City",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Inc",
                    "helper_text": "Company name",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "placeholder": "USD",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description of the lead",
                },
                {
                    "field": "designation",
                    "type": "string",
                    "value": "",
                    "label": "Designation",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title/designation",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "jane.smith@example.com",
                    "helper_text": "Email address",
                },
                {
                    "field": "email_opt_out",
                    "type": "bool",
                    "value": False,
                    "label": "Email Opt Out",
                    "helper_text": "Whether the lead has opted out of emails",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-9999",
                    "helper_text": "Fax number",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "Jane",
                    "helper_text": "First name of the lead",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "Jane Smith",
                    "helper_text": "Full name of the lead",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Industry the lead belongs to",
                },
                {
                    "field": "industry_type",
                    "type": "string",
                    "value": "",
                    "label": "Industry Type",
                    "placeholder": "SaaS",
                    "helper_text": "Type of industry",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Smith",
                    "helper_text": "Last name of the lead",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "label": "Lead Source",
                    "placeholder": "Website",
                    "helper_text": "Source of the lead",
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "value": "",
                    "label": "Lead Status",
                    "placeholder": "Contacted",
                    "helper_text": "Status of the lead",
                },
                {
                    "field": "mobile",
                    "type": "string",
                    "value": "",
                    "label": "Mobile",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "no_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "placeholder": "50",
                    "helper_text": "Number of employees in the lead's company",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "helper_text": "Salutation (Mr., Ms., etc.)",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "value": "",
                    "label": "Secondary Email",
                    "placeholder": "jane.backup@example.com",
                    "helper_text": "Secondary email address",
                },
                {
                    "field": "skype_id",
                    "type": "string",
                    "value": "",
                    "label": "Skype ID",
                    "placeholder": "jane.smith",
                    "helper_text": "Skype ID",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "CA",
                    "helper_text": "State",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "twitter",
                    "type": "string",
                    "value": "",
                    "label": "Twitter",
                    "placeholder": "@janesmith",
                    "helper_text": "Twitter handle",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://example.com",
                    "helper_text": "Website URL",
                },
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "94102",
                    "helper_text": "Postal code",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "ID of the updated lead",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the lead was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_lead",
            "task_name": "tasks.zoho.update_lead",
            "description": "Update an existing lead in Zoho CRM",
            "label": "Update Lead",
            "required": ["lead_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "lead_id",
                "annual_revenue",
                "city",
                "company",
                "country",
                "currency",
                "description",
                "designation",
                "email",
                "email_opt_out",
                "fax",
                "first_name",
                "full_name",
                "industry",
                "industry_type",
                "last_name",
                "lead_source",
                "lead_status",
                "mobile",
                "no_of_employees",
                "phone",
                "salutation",
                "secondary_email",
                "skype_id",
                "state",
                "street",
                "twitter",
                "website",
                "zip_code",
                "custom_fields",
            ],
        },
        "delete_lead": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "label": "Lead ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the lead to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "ID of the deleted lead",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_lead",
            "task_name": "tasks.zoho.delete_lead",
            "description": "Delete a lead from Zoho CRM",
            "label": "Delete Lead",
            "required": ["lead_id"],
            "inputs_sort_order": ["integration", "action", "lead_id"],
        },
        "upsert_lead": {
            "inputs": [
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Smith",
                    "helper_text": "Last name (required)",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Inc",
                    "helper_text": "Company name (required)",
                },
                {
                    "field": "annual_revenue",
                    "type": "float",
                    "value": 0,
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Annual revenue of the lead's company",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "San Francisco",
                    "helper_text": "City",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description of the lead",
                },
                {
                    "field": "designation",
                    "type": "string",
                    "value": "",
                    "label": "Designation",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title/designation",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "jane.smith@example.com",
                    "helper_text": "Email address (used for matching)",
                },
                {
                    "field": "email_opt_out",
                    "type": "bool",
                    "value": False,
                    "label": "Email Opt Out",
                    "helper_text": "Whether the lead has opted out of emails",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "label": "Fax",
                    "placeholder": "+1-555-9999",
                    "helper_text": "Fax number",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "Jane",
                    "helper_text": "First name of the lead",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "value": "",
                    "label": "Full Name",
                    "placeholder": "Jane Smith",
                    "helper_text": "Full name of the lead",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Industry the lead belongs to",
                },
                {
                    "field": "industry_type",
                    "type": "string",
                    "value": "",
                    "label": "Industry Type",
                    "placeholder": "SaaS",
                    "helper_text": "Type of industry",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "label": "Lead Source",
                    "placeholder": "Website",
                    "helper_text": "Source of the lead",
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "value": "",
                    "label": "Lead Status",
                    "placeholder": "Contacted",
                    "helper_text": "Status of the lead",
                },
                {
                    "field": "mobile",
                    "type": "string",
                    "value": "",
                    "label": "Mobile",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "no_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "placeholder": "50",
                    "helper_text": "Number of employees in the lead's company",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "helper_text": "Salutation (Mr., Ms., etc.)",
                },
                {
                    "field": "secondary_email",
                    "type": "string",
                    "value": "",
                    "label": "Secondary Email",
                    "placeholder": "jane.backup@example.com",
                    "helper_text": "Secondary email address",
                },
                {
                    "field": "skype_id",
                    "type": "string",
                    "value": "",
                    "label": "Skype ID",
                    "placeholder": "jane.smith",
                    "helper_text": "Skype ID",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "CA",
                    "helper_text": "State",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "twitter",
                    "type": "string",
                    "value": "",
                    "label": "Twitter",
                    "placeholder": "@janesmith",
                    "helper_text": "Twitter handle",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://example.com",
                    "helper_text": "Website URL",
                },
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "94102",
                    "helper_text": "Postal code",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {"field": "lead_id", "type": "string", "helper_text": "ID of the lead"},
                {"field": "last_name", "type": "string", "helper_text": "Last name"},
                {"field": "company", "type": "string", "helper_text": "Company name"},
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_lead",
            "task_name": "tasks.zoho.upsert_lead",
            "description": "Create or update a lead in Zoho CRM",
            "label": "Create or Update Lead",
            "required": ["last_name", "company"],
            "inputs_sort_order": [
                "integration",
                "action",
                "last_name",
                "company",
                "annual_revenue",
                "city",
                "country",
                "currency",
                "description",
                "designation",
                "email",
                "email_opt_out",
                "fax",
                "first_name",
                "full_name",
                "industry",
                "industry_type",
                "lead_source",
                "lead_status",
                "mobile",
                "no_of_employees",
                "phone",
                "salutation",
                "secondary_email",
                "skype_id",
                "state",
                "street",
                "twitter",
                "website",
                "zip_code",
                "custom_fields",
            ],
        },
        "get_lead_fields": {
            "inputs": [],
            "outputs": [
                {
                    "field": "field_names",
                    "type": "vec<string>",
                    "helper_text": "List of field display labels",
                },
                {
                    "field": "field_api_names",
                    "type": "vec<string>",
                    "helper_text": "List of field API names",
                },
                {
                    "field": "field_types",
                    "type": "vec<string>",
                    "helper_text": "List of field data types",
                },
                {
                    "field": "field_required",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if fields are required",
                },
                {
                    "field": "field_read_only",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if fields are read-only",
                },
                {
                    "field": "field_custom",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if fields are custom",
                },
                {
                    "field": "field_details",
                    "type": "vec<string>",
                    "helper_text": "List of full field details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_lead_fields",
            "task_name": "tasks.zoho.get_lead_fields",
            "description": "Read details of lead fields",
            "label": "Get Lead Fields",
            "required": [],
            "inputs_sort_order": ["integration", "action"],
        },
        "create_invoice": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 2024 Invoice",
                    "helper_text": "Subject of the invoice (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": [],
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Associated account",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Invoice description",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Payment due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "invoice_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Invoice Date",
                    "placeholder": "2024-12-01",
                    "helper_text": "Invoice date (YYYY-MM-DD)",
                },
                {
                    "field": "invoice_number",
                    "type": "string",
                    "value": "",
                    "label": "Invoice Number",
                    "placeholder": "INV-001",
                    "helper_text": "Invoice number",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Draft",
                    "helper_text": "Invoice status",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created invoice",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Invoice subject",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the invoice was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_invoice",
            "task_name": "tasks.zoho.create_invoice",
            "description": "Create a new invoice in Zoho CRM",
            "label": "Create Invoice",
            "required": ["subject", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "subject",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "account_id",
                "adjustment",
                "billing_city",
                "billing_code",
                "billing_country",
                "billing_state",
                "billing_street",
                "currency",
                "description",
                "due_date",
                "exchange_rate",
                "invoice_date",
                "invoice_number",
                "sales_commission",
                "shipping_city",
                "shipping_code",
                "shipping_country",
                "shipping_state",
                "shipping_street",
                "status",
                "terms_and_conditions",
                "custom_fields",
            ],
        },
        "get_invoice": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "label": "Invoice ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the invoice to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the invoice",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Invoice subject",
                },
                {
                    "field": "invoice_number",
                    "type": "string",
                    "helper_text": "Invoice number",
                },
                {"field": "status", "type": "string", "helper_text": "Invoice status"},
                {
                    "field": "invoice_date",
                    "type": "timestamp",
                    "helper_text": "Invoice date",
                },
                {"field": "due_date", "type": "timestamp", "helper_text": "Due date"},
                {
                    "field": "sub_total",
                    "type": "string",
                    "helper_text": "Subtotal amount",
                },
                {"field": "tax", "type": "string", "helper_text": "Tax amount"},
                {
                    "field": "adjustment",
                    "type": "string",
                    "helper_text": "Adjustment amount",
                },
                {
                    "field": "grand_total",
                    "type": "string",
                    "helper_text": "Grand total amount",
                },
                {
                    "field": "sales_commission",
                    "type": "string",
                    "helper_text": "Sales commission",
                },
                {
                    "field": "excise_duty",
                    "type": "string",
                    "helper_text": "Excise duty",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "helper_text": "Terms and conditions",
                },
                {"field": "currency", "type": "string", "helper_text": "Currency code"},
                {
                    "field": "exchange_rate",
                    "type": "string",
                    "helper_text": "Exchange rate",
                },
                {"field": "carrier", "type": "string", "helper_text": "Carrier"},
                {
                    "field": "billing_street",
                    "type": "string",
                    "helper_text": "Billing street",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "helper_text": "Shipping street",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Associated account ID",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Associated account name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Associated contact ID",
                },
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Associated contact name",
                },
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "Associated deal ID",
                },
                {
                    "field": "deal_name",
                    "type": "string",
                    "helper_text": "Associated deal name",
                },
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "helper_text": "Associated sales order ID",
                },
                {
                    "field": "sales_order_name",
                    "type": "string",
                    "helper_text": "Associated sales order name",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the invoice owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the invoice owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the invoice owner",
                },
                {
                    "field": "product_details",
                    "type": "string",
                    "helper_text": "Product details JSON",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the invoice was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the invoice was last modified",
                },
                {
                    "field": "invoice_details",
                    "type": "string",
                    "helper_text": "Full invoice details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_invoice",
            "task_name": "tasks.zoho.get_invoice",
            "description": "Read details of an invoice",
            "label": "Get Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": ["integration", "action", "invoice_id"],
        },
        "list_invoices": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all invoices or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of invoices to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Invoice_Date",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Subject,Invoice_Number,Status",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "invoice_ids",
                    "type": "vec<string>",
                    "helper_text": "List of invoice IDs",
                },
                {
                    "field": "invoice_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of subjects",
                },
                {
                    "field": "invoice_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of invoice numbers",
                },
                {
                    "field": "invoice_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of statuses",
                },
                {
                    "field": "invoice_grand_totals",
                    "type": "vec<string>",
                    "helper_text": "List of grand totals",
                },
                {
                    "field": "invoice_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of invoice dates",
                },
                {
                    "field": "invoice_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of due dates",
                },
                {
                    "field": "invoice_details",
                    "type": "vec<string>",
                    "helper_text": "List of invoice details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of invoices returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_invoices",
            "task_name": "tasks.zoho.list_invoices",
            "description": "Get multiple invoices",
            "label": "List Invoices",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_invoice": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "label": "Invoice ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the invoice to update (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": [],
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Associated account",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Invoice description",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Payment due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "invoice_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Invoice Date",
                    "placeholder": "2024-12-01",
                    "helper_text": "Invoice date (YYYY-MM-DD)",
                },
                {
                    "field": "invoice_number",
                    "type": "string",
                    "value": "",
                    "label": "Invoice Number",
                    "placeholder": "INV-001",
                    "helper_text": "Invoice number",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Draft",
                    "helper_text": "Invoice status",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Updated Invoice",
                    "helper_text": "Invoice subject",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "ID of the updated invoice",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the invoice was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_invoice",
            "task_name": "tasks.zoho.update_invoice",
            "description": "Update an existing invoice in Zoho CRM",
            "label": "Update Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "invoice_id",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "account_id",
                "adjustment",
                "billing_city",
                "billing_code",
                "billing_country",
                "billing_state",
                "billing_street",
                "currency",
                "description",
                "due_date",
                "exchange_rate",
                "invoice_date",
                "invoice_number",
                "sales_commission",
                "shipping_city",
                "shipping_code",
                "shipping_country",
                "shipping_state",
                "shipping_street",
                "status",
                "subject",
                "terms_and_conditions",
                "custom_fields",
            ],
        },
        "delete_invoice": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "label": "Invoice ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the invoice to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "ID of the deleted invoice",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_invoice",
            "task_name": "tasks.zoho.delete_invoice",
            "description": "Delete an invoice from Zoho CRM",
            "label": "Delete Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": ["integration", "action", "invoice_id"],
        },
        "upsert_invoice": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 2024 Invoice",
                    "helper_text": "Subject of the invoice (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": [],
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Associated account",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Invoice description",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Payment due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "invoice_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Invoice Date",
                    "placeholder": "2024-12-01",
                    "helper_text": "Invoice date (YYYY-MM-DD)",
                },
                {
                    "field": "invoice_number",
                    "type": "string",
                    "value": "",
                    "label": "Invoice Number",
                    "placeholder": "INV-001",
                    "helper_text": "Invoice number",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Draft",
                    "helper_text": "Invoice status",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "ID of the invoice",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Invoice subject",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_invoice",
            "task_name": "tasks.zoho.upsert_invoice",
            "description": "Create or update an invoice in Zoho CRM",
            "label": "Create or Update Invoice",
            "required": ["subject", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "subject",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "account_id",
                "adjustment",
                "billing_city",
                "billing_code",
                "billing_country",
                "billing_state",
                "billing_street",
                "currency",
                "description",
                "due_date",
                "exchange_rate",
                "invoice_date",
                "invoice_number",
                "sales_commission",
                "shipping_city",
                "shipping_code",
                "shipping_country",
                "shipping_state",
                "shipping_street",
                "status",
                "terms_and_conditions",
                "custom_fields",
            ],
        },
        "create_product": {
            "inputs": [
                {
                    "field": "product_name",
                    "type": "string",
                    "value": "",
                    "label": "Product Name",
                    "placeholder": "Premium Widget",
                    "helper_text": "Name of the product (required)",
                },
                {
                    "field": "commission_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Commission Rate",
                    "placeholder": "50.00",
                    "helper_text": "Commission rate amount (actual monetary value, not percentage)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Product description",
                },
                {
                    "field": "manufacturer",
                    "type": "string",
                    "value": "",
                    "label": "Manufacturer",
                    "placeholder": "Acme Manufacturing",
                    "helper_text": "Manufacturer name",
                },
                {
                    "field": "product_active",
                    "type": "bool",
                    "value": False,
                    "label": "Product Active",
                    "helper_text": "Whether the product is active",
                },
                {
                    "field": "product_category",
                    "type": "string",
                    "value": "",
                    "label": "Product Category",
                    "placeholder": "Hardware",
                    "helper_text": "Category of the product",
                },
                {
                    "field": "qty_in_demand",
                    "type": "float",
                    "value": 0,
                    "label": "Quantity in Demand",
                    "placeholder": "50",
                    "helper_text": "Quantity in demand",
                },
                {
                    "field": "qty_in_stock",
                    "type": "float",
                    "value": 0,
                    "label": "Quantity in Stock",
                    "placeholder": "100",
                    "helper_text": "Quantity available in stock",
                },
                {
                    "field": "taxable",
                    "type": "bool",
                    "value": False,
                    "label": "Taxable",
                    "helper_text": "Whether the product is taxable",
                },
                {
                    "field": "unit_price",
                    "type": "float",
                    "value": 0,
                    "label": "Unit Price",
                    "placeholder": "99.99",
                    "helper_text": "Unit price of the product",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created product",
                },
                {
                    "field": "product_name",
                    "type": "string",
                    "helper_text": "Name of the product",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the product was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_product",
            "task_name": "tasks.zoho.create_product",
            "description": "Create a new product in Zoho CRM",
            "label": "Create Product",
            "required": ["product_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "product_name",
                "commission_rate",
                "description",
                "manufacturer",
                "product_active",
                "product_category",
                "qty_in_demand",
                "qty_in_stock",
                "taxable",
                "unit_price",
                "custom_fields",
            ],
        },
        "get_product": {
            "inputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "value": "",
                    "label": "Product ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the product to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the product",
                },
                {
                    "field": "product_name",
                    "type": "string",
                    "helper_text": "Product name",
                },
                {
                    "field": "product_code",
                    "type": "string",
                    "helper_text": "Product code",
                },
                {
                    "field": "product_category",
                    "type": "string",
                    "helper_text": "Product category",
                },
                {
                    "field": "manufacturer",
                    "type": "string",
                    "helper_text": "Manufacturer",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Product description",
                },
                {"field": "unit_price", "type": "string", "helper_text": "Unit price"},
                {
                    "field": "commission_rate",
                    "type": "string",
                    "helper_text": "Commission rate percentage",
                },
                {
                    "field": "qty_in_stock",
                    "type": "string",
                    "helper_text": "Quantity in stock",
                },
                {
                    "field": "qty_in_demand",
                    "type": "string",
                    "helper_text": "Quantity in demand",
                },
                {
                    "field": "qty_ordered",
                    "type": "string",
                    "helper_text": "Quantity ordered",
                },
                {
                    "field": "reorder_level",
                    "type": "string",
                    "helper_text": "Reorder level",
                },
                {
                    "field": "product_active",
                    "type": "bool",
                    "helper_text": "Whether product is active",
                },
                {
                    "field": "taxable",
                    "type": "bool",
                    "helper_text": "Whether product is taxable",
                },
                {
                    "field": "sales_start_date",
                    "type": "timestamp",
                    "helper_text": "Sales start date",
                },
                {
                    "field": "sales_end_date",
                    "type": "timestamp",
                    "helper_text": "Sales end date",
                },
                {
                    "field": "support_start_date",
                    "type": "timestamp",
                    "helper_text": "Support start date",
                },
                {
                    "field": "support_expiry_date",
                    "type": "timestamp",
                    "helper_text": "Support expiry date",
                },
                {"field": "handler", "type": "string", "helper_text": "Handler name"},
                {"field": "usage_unit", "type": "string", "helper_text": "Usage unit"},
                {"field": "vendor_id", "type": "string", "helper_text": "Vendor ID"},
                {
                    "field": "vendor_name",
                    "type": "string",
                    "helper_text": "Vendor name",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the product owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the product owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the product owner",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the product was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the product was last modified",
                },
                {
                    "field": "product_details",
                    "type": "string",
                    "helper_text": "Full product details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_product",
            "task_name": "tasks.zoho.get_product",
            "description": "Read details of a product",
            "label": "Get Product",
            "required": ["product_id"],
            "inputs_sort_order": ["integration", "action", "product_id"],
        },
        "list_products": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all products or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of products to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Product_Name",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Product_Name,Unit_Price,Product_Code",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "helper_text": "List of product IDs",
                },
                {
                    "field": "product_names",
                    "type": "vec<string>",
                    "helper_text": "List of product names",
                },
                {
                    "field": "product_codes",
                    "type": "vec<string>",
                    "helper_text": "List of product codes",
                },
                {
                    "field": "product_categories",
                    "type": "vec<string>",
                    "helper_text": "List of product categories",
                },
                {
                    "field": "product_unit_prices",
                    "type": "vec<string>",
                    "helper_text": "List of unit prices",
                },
                {
                    "field": "product_active",
                    "type": "vec<bool>",
                    "helper_text": "List of active statuses",
                },
                {
                    "field": "product_taxable",
                    "type": "vec<bool>",
                    "helper_text": "List of taxable statuses",
                },
                {
                    "field": "product_details",
                    "type": "vec<string>",
                    "helper_text": "List of product details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of products returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_products",
            "task_name": "tasks.zoho.list_products",
            "description": "Get multiple products",
            "label": "List Products",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_product": {
            "inputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "value": "",
                    "label": "Product ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the product to update (required)",
                },
                {
                    "field": "commission_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Commission Rate",
                    "placeholder": "50.00",
                    "helper_text": "Commission rate amount (actual monetary value, not percentage)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Product description",
                },
                {
                    "field": "manufacturer",
                    "type": "string",
                    "value": "",
                    "label": "Manufacturer",
                    "placeholder": "Acme Manufacturing",
                    "helper_text": "Manufacturer name",
                },
                {
                    "field": "product_active",
                    "type": "bool",
                    "value": False,
                    "label": "Product Active",
                    "helper_text": "Whether the product is active",
                },
                {
                    "field": "product_category",
                    "type": "string",
                    "value": "",
                    "label": "Product Category",
                    "placeholder": "Hardware",
                    "helper_text": "Product category",
                },
                {
                    "field": "qty_in_demand",
                    "type": "float",
                    "value": 0,
                    "label": "Quantity in Demand",
                    "placeholder": "50",
                    "helper_text": "Quantity in demand",
                },
                {
                    "field": "qty_in_stock",
                    "type": "float",
                    "value": 0,
                    "label": "Quantity in Stock",
                    "placeholder": "100",
                    "helper_text": "Quantity available in stock",
                },
                {
                    "field": "taxable",
                    "type": "bool",
                    "value": False,
                    "label": "Taxable",
                    "helper_text": "Whether the product is taxable",
                },
                {
                    "field": "unit_price",
                    "type": "float",
                    "value": 0,
                    "label": "Unit Price",
                    "placeholder": "109.99",
                    "helper_text": "Unit price",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "helper_text": "ID of the updated product",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the product was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_product",
            "task_name": "tasks.zoho.update_product",
            "description": "Update an existing product in Zoho CRM",
            "label": "Update Product",
            "required": ["product_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "product_id",
                "commission_rate",
                "description",
                "manufacturer",
                "product_active",
                "product_category",
                "qty_in_demand",
                "qty_in_stock",
                "taxable",
                "unit_price",
                "custom_fields",
            ],
        },
        "delete_product": {
            "inputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "value": "",
                    "label": "Product ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the product to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "helper_text": "ID of the deleted product",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_product",
            "task_name": "tasks.zoho.delete_product",
            "description": "Delete a product from Zoho CRM",
            "label": "Delete Product",
            "required": ["product_id"],
            "inputs_sort_order": ["integration", "action", "product_id"],
        },
        "upsert_product": {
            "inputs": [
                {
                    "field": "product_name",
                    "type": "string",
                    "value": "",
                    "label": "Product Name",
                    "placeholder": "Premium Widget",
                    "helper_text": "Name of the product (required)",
                },
                {
                    "field": "commission_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Commission Rate",
                    "placeholder": "50.00",
                    "helper_text": "Commission rate amount (actual monetary value, not percentage)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Product description",
                },
                {
                    "field": "manufacturer",
                    "type": "string",
                    "value": "",
                    "label": "Manufacturer",
                    "placeholder": "Acme Manufacturing",
                    "helper_text": "Manufacturer name",
                },
                {
                    "field": "product_active",
                    "type": "bool",
                    "value": False,
                    "label": "Product Active",
                    "helper_text": "Whether the product is active",
                },
                {
                    "field": "product_category",
                    "type": "string",
                    "value": "",
                    "label": "Product Category",
                    "placeholder": "Hardware",
                    "helper_text": "Category of the product",
                },
                {
                    "field": "qty_in_demand",
                    "type": "float",
                    "value": 0,
                    "label": "Quantity in Demand",
                    "placeholder": "50",
                    "helper_text": "Quantity in demand",
                },
                {
                    "field": "qty_in_stock",
                    "type": "float",
                    "value": 0,
                    "label": "Quantity in Stock",
                    "placeholder": "100",
                    "helper_text": "Quantity available in stock",
                },
                {
                    "field": "taxable",
                    "type": "bool",
                    "value": False,
                    "label": "Taxable",
                    "helper_text": "Whether the product is taxable",
                },
                {
                    "field": "unit_price",
                    "type": "float",
                    "value": 0,
                    "label": "Unit Price",
                    "placeholder": "99.99",
                    "helper_text": "Unit price of the product",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "product_id",
                    "type": "string",
                    "helper_text": "ID of the product",
                },
                {
                    "field": "product_name",
                    "type": "string",
                    "helper_text": "Product name",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_product",
            "task_name": "tasks.zoho.upsert_product",
            "description": "Create or update a product in Zoho CRM",
            "label": "Create or Update Product",
            "required": ["product_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "product_name",
                "commission_rate",
                "description",
                "manufacturer",
                "product_active",
                "product_category",
                "qty_in_demand",
                "qty_in_stock",
                "taxable",
                "unit_price",
                "custom_fields",
            ],
        },
        "create_purchase_order": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 Purchase Order",
                    "helper_text": "Subject of the purchase order (required)",
                },
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "label": "Vendor",
                    "helper_text": "Associated vendor (required)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=vendor_id&parent_id=vendors&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Purchase order description",
                },
                {
                    "field": "discount",
                    "type": "float",
                    "value": 0,
                    "label": "Discount",
                    "placeholder": "100.00",
                    "helper_text": "Discount amount (actual monetary value, not percentage)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "po_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "PO Date",
                    "placeholder": "2024-12-01",
                    "helper_text": "Purchase order date (YYYY-MM-DD)",
                },
                {
                    "field": "po_number",
                    "type": "string",
                    "value": "",
                    "label": "PO Number",
                    "placeholder": "PO-001",
                    "helper_text": "Purchase order number",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Created",
                    "helper_text": "Purchase order status (e.g., Created, Approved, Delivered, Cancelled, or custom status)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_purchase_order_status",
                    },
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "tracking_number",
                    "type": "string",
                    "value": "",
                    "label": "Tracking Number",
                    "placeholder": "1234567890",
                    "helper_text": "Tracking number",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created purchase order",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Purchase order subject",
                },
                {"field": "vendor_id", "type": "string", "helper_text": "Vendor ID"},
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the purchase order was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_purchase_order",
            "task_name": "tasks.zoho.create_purchase_order",
            "description": "Create a new purchase order in Zoho CRM",
            "label": "Create Purchase Order",
            "required": ["subject", "vendor_id", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "subject",
                "vendor_id",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "currency",
                "description",
                "discount",
                "due_date",
                "exchange_rate",
                "po_date",
                "po_number",
                "sales_commission",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "status",
                "terms_and_conditions",
                "tracking_number",
                "custom_fields",
            ],
        },
        "get_purchase_order": {
            "inputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "value": "",
                    "label": "Purchase Order ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the purchase order to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "helper_text": "Unique identifier",
                },
                {"field": "subject", "type": "string", "helper_text": "Subject"},
                {"field": "po_number", "type": "string", "helper_text": "PO number"},
                {"field": "status", "type": "string", "helper_text": "Status"},
                {"field": "po_date", "type": "timestamp", "helper_text": "PO date"},
                {"field": "due_date", "type": "timestamp", "helper_text": "Due date"},
                {"field": "sub_total", "type": "string", "helper_text": "Subtotal"},
                {"field": "tax", "type": "string", "helper_text": "Tax amount"},
                {"field": "adjustment", "type": "string", "helper_text": "Adjustment"},
                {"field": "discount", "type": "string", "helper_text": "Discount"},
                {
                    "field": "grand_total",
                    "type": "string",
                    "helper_text": "Grand total",
                },
                {
                    "field": "sales_commission",
                    "type": "string",
                    "helper_text": "Sales commission",
                },
                {
                    "field": "excise_duty",
                    "type": "string",
                    "helper_text": "Excise duty",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "helper_text": "Terms and conditions",
                },
                {"field": "currency", "type": "string", "helper_text": "Currency code"},
                {
                    "field": "exchange_rate",
                    "type": "string",
                    "helper_text": "Exchange rate",
                },
                {"field": "carrier", "type": "string", "helper_text": "Carrier"},
                {
                    "field": "tracking_number",
                    "type": "string",
                    "helper_text": "Tracking number",
                },
                {
                    "field": "requisition_no",
                    "type": "string",
                    "helper_text": "Requisition number",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "helper_text": "Billing street",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "helper_text": "Shipping street",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "helper_text": "Shipping country",
                },
                {"field": "vendor_id", "type": "string", "helper_text": "Vendor ID"},
                {
                    "field": "vendor_name",
                    "type": "string",
                    "helper_text": "Vendor name",
                },
                {"field": "contact_id", "type": "string", "helper_text": "Contact ID"},
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Contact name",
                },
                {"field": "owner_id", "type": "string", "helper_text": "Owner ID"},
                {"field": "owner_name", "type": "string", "helper_text": "Owner name"},
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Owner email",
                },
                {
                    "field": "product_details",
                    "type": "string",
                    "helper_text": "Product details JSON",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the purchase order was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the purchase order was last modified",
                },
                {
                    "field": "purchase_order_details",
                    "type": "string",
                    "helper_text": "Full purchase order details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_purchase_order",
            "task_name": "tasks.zoho.get_purchase_order",
            "description": "Read details of a purchase order",
            "label": "Get Purchase Order",
            "required": ["purchase_order_id"],
            "inputs_sort_order": ["integration", "action", "purchase_order_id"],
        },
        "list_purchase_orders": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all purchase orders or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of purchase orders to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "PO_Date",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Subject,PO_Number,Status",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "purchase_order_ids",
                    "type": "vec<string>",
                    "helper_text": "List of purchase order IDs",
                },
                {
                    "field": "purchase_order_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of subjects",
                },
                {
                    "field": "purchase_order_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of PO numbers",
                },
                {
                    "field": "purchase_order_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of statuses",
                },
                {
                    "field": "purchase_order_grand_totals",
                    "type": "vec<string>",
                    "helper_text": "List of grand totals",
                },
                {
                    "field": "purchase_order_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of PO dates",
                },
                {
                    "field": "purchase_order_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of due dates",
                },
                {
                    "field": "purchase_order_details",
                    "type": "vec<string>",
                    "helper_text": "List of purchase order details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of purchase orders returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_purchase_orders",
            "task_name": "tasks.zoho.list_purchase_orders",
            "description": "Get multiple purchase orders",
            "label": "List Purchase Orders",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_purchase_order": {
            "inputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "value": "",
                    "label": "Purchase Order ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the purchase order to update (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Purchase order description",
                },
                {
                    "field": "discount",
                    "type": "float",
                    "value": 0,
                    "label": "Discount",
                    "placeholder": "100.00",
                    "helper_text": "Discount amount (actual monetary value, not percentage)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "po_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "PO Date",
                    "placeholder": "2024-12-01",
                    "helper_text": "Purchase order date (YYYY-MM-DD)",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Created",
                    "helper_text": "Purchase order status (e.g., Created, Approved, Delivered, Cancelled, or custom status)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_purchase_order_status",
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Updated PO",
                    "helper_text": "Purchase order subject",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "tracking_number",
                    "type": "string",
                    "value": "",
                    "label": "Tracking Number",
                    "placeholder": "1234567890",
                    "helper_text": "Tracking number",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "helper_text": "ID of the updated purchase order",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the purchase order was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_purchase_order",
            "task_name": "tasks.zoho.update_purchase_order",
            "description": "Update an existing purchase order in Zoho CRM",
            "label": "Update Purchase Order",
            "required": ["purchase_order_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "purchase_order_id",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "currency",
                "description",
                "discount",
                "due_date",
                "exchange_rate",
                "po_date",
                "po_number",
                "sales_commission",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "status",
                "subject",
                "terms_and_conditions",
                "tracking_number",
                "custom_fields",
            ],
        },
        "delete_purchase_order": {
            "inputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "value": "",
                    "label": "Purchase Order ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the purchase order to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "helper_text": "ID of the deleted purchase order",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_purchase_order",
            "task_name": "tasks.zoho.delete_purchase_order",
            "description": "Delete a purchase order from Zoho CRM",
            "label": "Delete Purchase Order",
            "required": ["purchase_order_id"],
            "inputs_sort_order": ["integration", "action", "purchase_order_id"],
        },
        "upsert_purchase_order": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 Purchase Order",
                    "helper_text": "Subject of the purchase order (required)",
                },
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "label": "Vendor",
                    "helper_text": "Associated vendor (required)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=vendor_id&parent_id=vendors&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Purchase order description",
                },
                {
                    "field": "discount",
                    "type": "float",
                    "value": 0,
                    "label": "Discount",
                    "placeholder": "100.00",
                    "helper_text": "Discount amount (actual monetary value, not percentage)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "po_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "PO Date",
                    "placeholder": "2024-12-01",
                    "helper_text": "Purchase order date (YYYY-MM-DD)",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Created",
                    "helper_text": "Purchase order status (e.g., Created, Approved, Delivered, Cancelled, or custom status)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_purchase_order_status",
                    },
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "tracking_number",
                    "type": "string",
                    "value": "",
                    "label": "Tracking Number",
                    "placeholder": "1234567890",
                    "helper_text": "Tracking number",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "purchase_order_id",
                    "type": "string",
                    "helper_text": "ID of the purchase order",
                },
                {"field": "subject", "type": "string", "helper_text": "Subject"},
                {"field": "vendor_id", "type": "string", "helper_text": "Vendor ID"},
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_purchase_order",
            "task_name": "tasks.zoho.upsert_purchase_order",
            "description": "Create or update a purchase order in Zoho CRM",
            "label": "Create or Update Purchase Order",
            "required": ["subject", "vendor_id", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "subject",
                "vendor_id",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "currency",
                "description",
                "discount",
                "due_date",
                "exchange_rate",
                "po_date",
                "po_number",
                "sales_commission",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "status",
                "terms_and_conditions",
                "tracking_number",
                "custom_fields",
            ],
        },
        "create_quote": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 2024 Quote",
                    "helper_text": "Subject of the quote (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Quote description",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "quote_stage",
                    "type": "string",
                    "value": "",
                    "label": "Quote Stage",
                    "placeholder": "Draft",
                    "helper_text": "Quote stage (e.g., Draft, Negotiation, Delivered, On Hold, Confirmed, Closed Won, Closed Lost, or custom stage)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_quote_stage",
                    },
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Sales Team",
                    "helper_text": "Team for the quote",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "valid_till",
                    "type": "timestamp",
                    "value": "",
                    "label": "Valid Till",
                    "placeholder": "2024-12-31",
                    "helper_text": "Quote validity date (YYYY-MM-DD)",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created quote",
                },
                {"field": "subject", "type": "string", "helper_text": "Quote subject"},
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the quote was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_quote",
            "task_name": "tasks.zoho.create_quote",
            "description": "Create a new quote in Zoho CRM",
            "label": "Create Quote",
            "required": ["subject", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "subject",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "currency",
                "description",
                "exchange_rate",
                "quote_stage",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "team",
                "terms_and_conditions",
                "valid_till",
                "custom_fields",
            ],
        },
        "get_quote": {
            "inputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "value": "",
                    "label": "Quote ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the quote to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the quote",
                },
                {"field": "subject", "type": "string", "helper_text": "Quote subject"},
                {
                    "field": "quote_number",
                    "type": "string",
                    "helper_text": "Quote number",
                },
                {
                    "field": "quote_stage",
                    "type": "string",
                    "helper_text": "Quote stage",
                },
                {
                    "field": "valid_till",
                    "type": "timestamp",
                    "helper_text": "Valid till date",
                },
                {"field": "sub_total", "type": "string", "helper_text": "Subtotal"},
                {"field": "tax", "type": "string", "helper_text": "Tax amount"},
                {"field": "adjustment", "type": "string", "helper_text": "Adjustment"},
                {
                    "field": "grand_total",
                    "type": "string",
                    "helper_text": "Grand total amount",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "helper_text": "Terms and conditions",
                },
                {"field": "currency", "type": "string", "helper_text": "Currency code"},
                {
                    "field": "exchange_rate",
                    "type": "string",
                    "helper_text": "Exchange rate",
                },
                {"field": "carrier", "type": "string", "helper_text": "Carrier"},
                {"field": "team", "type": "string", "helper_text": "Team"},
                {
                    "field": "billing_street",
                    "type": "string",
                    "helper_text": "Billing street",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "helper_text": "Shipping street",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "helper_text": "Shipping country",
                },
                {"field": "account_id", "type": "string", "helper_text": "Account ID"},
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Account name",
                },
                {"field": "contact_id", "type": "string", "helper_text": "Contact ID"},
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Contact name",
                },
                {"field": "deal_id", "type": "string", "helper_text": "Deal ID"},
                {"field": "deal_name", "type": "string", "helper_text": "Deal name"},
                {"field": "owner_id", "type": "string", "helper_text": "Owner ID"},
                {"field": "owner_name", "type": "string", "helper_text": "Owner name"},
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Owner email",
                },
                {
                    "field": "product_details",
                    "type": "string",
                    "helper_text": "Product details JSON",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the quote was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the quote was last modified",
                },
                {
                    "field": "quote_details",
                    "type": "string",
                    "helper_text": "Full quote details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_quote",
            "task_name": "tasks.zoho.get_quote",
            "description": "Read details of a quote",
            "label": "Get Quote",
            "required": ["quote_id"],
            "inputs_sort_order": ["integration", "action", "quote_id"],
        },
        "list_quotes": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all quotes or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of quotes to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Valid_Till",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Subject,Quote_Stage,Valid_Till",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "quote_ids",
                    "type": "vec<string>",
                    "helper_text": "List of quote IDs",
                },
                {
                    "field": "quote_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of subjects",
                },
                {
                    "field": "quote_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of quote numbers",
                },
                {
                    "field": "quote_stages",
                    "type": "vec<string>",
                    "helper_text": "List of quote stages",
                },
                {
                    "field": "quote_grand_totals",
                    "type": "vec<string>",
                    "helper_text": "List of grand totals",
                },
                {
                    "field": "quote_valid_tills",
                    "type": "vec<timestamp>",
                    "helper_text": "List of valid till dates",
                },
                {
                    "field": "quote_details",
                    "type": "vec<string>",
                    "helper_text": "List of quote details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of quotes returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_quotes",
            "task_name": "tasks.zoho.list_quotes",
            "description": "Get multiple quotes",
            "label": "List Quotes",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_quote": {
            "inputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "value": "",
                    "label": "Quote ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the quote to update (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Quote description",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "quote_stage",
                    "type": "string",
                    "value": "",
                    "label": "Quote Stage",
                    "placeholder": "Draft",
                    "helper_text": "Quote stage (e.g., Draft, Negotiation, Delivered, On Hold, Confirmed, Closed Won, Closed Lost, or custom stage)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_quote_stage",
                    },
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Updated Quote",
                    "helper_text": "Quote subject",
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Sales Team",
                    "helper_text": "Team for the quote",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "valid_till",
                    "type": "timestamp",
                    "value": "",
                    "label": "Valid Till",
                    "placeholder": "2024-12-31",
                    "helper_text": "Quote validity date (YYYY-MM-DD)",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "helper_text": "ID of the updated quote",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the quote was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_quote",
            "task_name": "tasks.zoho.update_quote",
            "description": "Update an existing quote in Zoho CRM",
            "label": "Update Quote",
            "required": ["quote_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "quote_id",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "currency",
                "description",
                "exchange_rate",
                "quote_stage",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "subject",
                "team",
                "terms_and_conditions",
                "valid_till",
                "custom_fields",
            ],
        },
        "delete_quote": {
            "inputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "value": "",
                    "label": "Quote ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the quote to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "helper_text": "ID of the deleted quote",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_quote",
            "task_name": "tasks.zoho.delete_quote",
            "description": "Delete a quote from Zoho CRM",
            "label": "Delete Quote",
            "required": ["quote_id"],
            "inputs_sort_order": ["integration", "action", "quote_id"],
        },
        "upsert_quote": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 2024 Quote",
                    "helper_text": "Subject of the quote (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Quote description",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "quote_stage",
                    "type": "string",
                    "value": "",
                    "label": "Quote Stage",
                    "placeholder": "Draft",
                    "helper_text": "Quote stage (e.g., Draft, Negotiation, Delivered, On Hold, Confirmed, Closed Won, Closed Lost, or custom stage)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_quote_stage",
                    },
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Sales Team",
                    "helper_text": "Team for the quote",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "valid_till",
                    "type": "timestamp",
                    "value": "",
                    "label": "Valid Till",
                    "placeholder": "2024-12-31",
                    "helper_text": "Quote validity date (YYYY-MM-DD)",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "quote_id",
                    "type": "string",
                    "helper_text": "ID of the quote",
                },
                {"field": "subject", "type": "string", "helper_text": "Quote subject"},
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_quote",
            "task_name": "tasks.zoho.upsert_quote",
            "description": "Create or update a quote in Zoho CRM",
            "label": "Create or Update Quote",
            "required": ["subject", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "subject",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "currency",
                "description",
                "exchange_rate",
                "quote_stage",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "team",
                "terms_and_conditions",
                "valid_till",
                "custom_fields",
            ],
        },
        "create_sales_order": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Associated account (required)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 Sales Order",
                    "helper_text": "Subject of the sales order (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "ID of the associated contact (optional)",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "ID of the associated deal (optional)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Sales order description",
                },
                {
                    "field": "discount",
                    "type": "float",
                    "value": 0,
                    "label": "Discount",
                    "placeholder": "100.00",
                    "helper_text": "Discount amount (actual monetary value, not percentage)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "so_number",
                    "type": "string",
                    "value": "",
                    "label": "SO Number",
                    "placeholder": "SO-001",
                    "helper_text": "Sales order number",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Created",
                    "helper_text": "Sales order status (e.g., Created, Approved, Delivered, Cancelled, or custom status)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_sales_order_status",
                    },
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created sales order",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Sales order subject",
                },
                {"field": "account_id", "type": "string", "helper_text": "Account ID"},
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the sales order was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_sales_order",
            "task_name": "tasks.zoho.create_sales_order",
            "description": "Create a new sales order in Zoho CRM",
            "label": "Create Sales Order",
            "required": ["subject", "account_id", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "account_id",
                "subject",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "contact_id",
                "currency",
                "deal_id",
                "description",
                "discount",
                "due_date",
                "exchange_rate",
                "so_number",
                "sales_commission",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "status",
                "terms_and_conditions",
                "custom_fields",
            ],
        },
        "get_sales_order": {
            "inputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "value": "",
                    "label": "Sales Order ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the sales order to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "helper_text": "Unique identifier",
                },
                {"field": "subject", "type": "string", "helper_text": "Subject"},
                {"field": "so_number", "type": "string", "helper_text": "SO number"},
                {"field": "status", "type": "string", "helper_text": "Status"},
                {"field": "due_date", "type": "timestamp", "helper_text": "Due date"},
                {"field": "sub_total", "type": "string", "helper_text": "Subtotal"},
                {"field": "tax", "type": "string", "helper_text": "Tax amount"},
                {"field": "adjustment", "type": "string", "helper_text": "Adjustment"},
                {"field": "discount", "type": "string", "helper_text": "Discount"},
                {
                    "field": "grand_total",
                    "type": "string",
                    "helper_text": "Grand total amount",
                },
                {
                    "field": "sales_commission",
                    "type": "string",
                    "helper_text": "Sales commission",
                },
                {
                    "field": "excise_duty",
                    "type": "string",
                    "helper_text": "Excise duty",
                },
                {"field": "pending", "type": "string", "helper_text": "Pending status"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "helper_text": "Terms and conditions",
                },
                {"field": "currency", "type": "string", "helper_text": "Currency code"},
                {
                    "field": "exchange_rate",
                    "type": "string",
                    "helper_text": "Exchange rate",
                },
                {"field": "carrier", "type": "string", "helper_text": "Carrier"},
                {
                    "field": "billing_street",
                    "type": "string",
                    "helper_text": "Billing street",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "helper_text": "Billing country",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "helper_text": "Shipping street",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "helper_text": "Shipping country",
                },
                {"field": "account_id", "type": "string", "helper_text": "Account ID"},
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Account name",
                },
                {"field": "contact_id", "type": "string", "helper_text": "Contact ID"},
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Contact name",
                },
                {"field": "deal_id", "type": "string", "helper_text": "Deal ID"},
                {"field": "deal_name", "type": "string", "helper_text": "Deal name"},
                {"field": "quote_id", "type": "string", "helper_text": "Quote ID"},
                {"field": "quote_name", "type": "string", "helper_text": "Quote name"},
                {"field": "owner_id", "type": "string", "helper_text": "Owner ID"},
                {"field": "owner_name", "type": "string", "helper_text": "Owner name"},
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Owner email",
                },
                {
                    "field": "product_details",
                    "type": "string",
                    "helper_text": "Product details JSON",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the sales order was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the sales order was last modified",
                },
                {
                    "field": "sales_order_details",
                    "type": "string",
                    "helper_text": "Full sales order details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_sales_order",
            "task_name": "tasks.zoho.get_sales_order",
            "description": "Read details of a sales order",
            "label": "Get Sales Order",
            "required": ["sales_order_id"],
            "inputs_sort_order": ["integration", "action", "sales_order_id"],
        },
        "list_sales_orders": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all sales orders or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of sales orders to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Due_Date",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Subject,SO_Number,Status",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "sales_order_ids",
                    "type": "vec<string>",
                    "helper_text": "List of sales order IDs",
                },
                {
                    "field": "sales_order_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of subjects",
                },
                {
                    "field": "sales_order_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of SO numbers",
                },
                {
                    "field": "sales_order_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of statuses",
                },
                {
                    "field": "sales_order_grand_totals",
                    "type": "vec<string>",
                    "helper_text": "List of grand totals",
                },
                {
                    "field": "sales_order_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of due dates",
                },
                {
                    "field": "sales_order_details",
                    "type": "vec<string>",
                    "helper_text": "List of sales order details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of sales orders returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_sales_orders",
            "task_name": "tasks.zoho.list_sales_orders",
            "description": "Get multiple sales orders",
            "label": "List Sales Orders",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_sales_order": {
            "inputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "value": "",
                    "label": "Sales Order ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the sales order to update (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Associated account",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "ID of the associated contact (optional)",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "ID of the associated deal (optional)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Sales order description",
                },
                {
                    "field": "discount",
                    "type": "float",
                    "value": 0,
                    "label": "Discount",
                    "placeholder": "100.00",
                    "helper_text": "Discount amount (actual monetary value, not percentage)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Created",
                    "helper_text": "Sales order status (e.g., Created, Approved, Delivered, Cancelled, or custom status)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_sales_order_status",
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Updated SO",
                    "helper_text": "Sales order subject",
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "helper_text": "ID of the updated sales order",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the sales order was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_sales_order",
            "task_name": "tasks.zoho.update_sales_order",
            "description": "Update an existing sales order in Zoho CRM",
            "label": "Update Sales Order",
            "required": ["sales_order_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "sales_order_id",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "account_id",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "contact_id",
                "currency",
                "deal_id",
                "description",
                "discount",
                "due_date",
                "exchange_rate",
                "so_number",
                "sales_commission",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "status",
                "subject",
                "terms_and_conditions",
                "custom_fields",
            ],
        },
        "delete_sales_order": {
            "inputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "value": "",
                    "label": "Sales Order ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the sales order to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "helper_text": "ID of the deleted sales order",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_sales_order",
            "task_name": "tasks.zoho.delete_sales_order",
            "description": "Delete a sales order from Zoho CRM",
            "label": "Delete Sales Order",
            "required": ["sales_order_id"],
            "inputs_sort_order": ["integration", "action", "sales_order_id"],
        },
        "upsert_sales_order": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Associated account (required)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Q4 Sales Order",
                    "helper_text": "Subject of the sales order (required)",
                },
                {
                    "field": "product_ids",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product IDs",
                    "placeholder": "123,456,789",
                    "helper_text": "Comma-separated list of product IDs (required, one per product)",
                },
                {
                    "field": "product_quantities",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Quantities",
                    "placeholder": "2,1,3",
                    "helper_text": "Comma-separated list of quantities (one per product, default: 1)",
                },
                {
                    "field": "product_list_prices",
                    "type": "vec<string>",
                    "value": "",
                    "label": "List Prices",
                    "placeholder": "100,200,150",
                    "helper_text": "Comma-separated list of list prices (one per product)",
                },
                {
                    "field": "product_descriptions",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Product Descriptions",
                    "placeholder": "Item 1,Item 2,Item 3",
                    "helper_text": "Comma-separated list of product descriptions (one per product)",
                },
                {
                    "field": "product_taxes",
                    "type": "vec<string>",
                    "value": "",
                    "label": "Taxes",
                    "placeholder": "10,20,15",
                    "helper_text": "Comma-separated list of tax amounts (one per product)",
                },
                {
                    "field": "adjustment",
                    "type": "float",
                    "value": 0,
                    "label": "Adjustment",
                    "placeholder": "0",
                    "helper_text": "Adjustment in grand total",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Billing street address",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                    "helper_text": "Billing city",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "label": "Billing State",
                    "placeholder": "CA",
                    "helper_text": "Billing state",
                },
                {
                    "field": "billing_code",
                    "type": "string",
                    "value": "",
                    "label": "Billing Zip",
                    "placeholder": "94102",
                    "helper_text": "Billing postal code",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "label": "Billing Country",
                    "placeholder": "USA",
                    "helper_text": "Billing country",
                },
                {
                    "field": "carrier",
                    "type": "string",
                    "value": "",
                    "label": "Carrier",
                    "placeholder": "FedEx",
                    "helper_text": "Carrier name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "ID of the associated contact (optional)",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "ID of the associated deal (optional)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Sales order description",
                },
                {
                    "field": "discount",
                    "type": "float",
                    "value": 0,
                    "label": "Discount",
                    "placeholder": "100.00",
                    "helper_text": "Discount amount (actual monetary value, not percentage)",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date (YYYY-MM-DD)",
                },
                {
                    "field": "exchange_rate",
                    "type": "float",
                    "value": 0,
                    "label": "Exchange Rate",
                    "placeholder": "1.0",
                    "helper_text": "Exchange rate to home currency",
                },
                {
                    "field": "sales_commission",
                    "type": "float",
                    "value": 0,
                    "label": "Sales Commission",
                    "placeholder": "500.00",
                    "helper_text": "Sales commission amount (actual monetary value, not percentage)",
                },
                {
                    "field": "shipping_street",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Street",
                    "placeholder": "456 Oak Ave",
                    "helper_text": "Shipping street address",
                },
                {
                    "field": "shipping_city",
                    "type": "string",
                    "value": "",
                    "label": "Shipping City",
                    "placeholder": "Los Angeles",
                    "helper_text": "Shipping city",
                },
                {
                    "field": "shipping_state",
                    "type": "string",
                    "value": "",
                    "label": "Shipping State",
                    "placeholder": "CA",
                    "helper_text": "Shipping state",
                },
                {
                    "field": "shipping_code",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Zip",
                    "placeholder": "90001",
                    "helper_text": "Shipping postal code",
                },
                {
                    "field": "shipping_country",
                    "type": "string",
                    "value": "",
                    "label": "Shipping Country",
                    "placeholder": "USA",
                    "helper_text": "Shipping country",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Created",
                    "helper_text": "Sales order status (e.g., Created, Approved, Delivered, Cancelled, or custom status)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_sales_order_status",
                    },
                },
                {
                    "field": "terms_and_conditions",
                    "type": "string",
                    "value": "",
                    "label": "Terms and Conditions",
                    "helper_text": "Terms and conditions",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": "Custom fields as JSON using API names",
                },
            ],
            "outputs": [
                {
                    "field": "sales_order_id",
                    "type": "string",
                    "helper_text": "ID of the sales order",
                },
                {"field": "subject", "type": "string", "helper_text": "Subject"},
                {"field": "account_id", "type": "string", "helper_text": "Account ID"},
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_sales_order",
            "task_name": "tasks.zoho.upsert_sales_order",
            "description": "Create or update a sales order in Zoho CRM",
            "label": "Create or Update Sales Order",
            "required": ["subject", "account_id", "product_ids"],
            "inputs_sort_order": [
                "integration",
                "action",
                "account_id",
                "subject",
                "product_ids",
                "product_quantities",
                "product_list_prices",
                "product_descriptions",
                "product_taxes",
                "adjustment",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_code",
                "billing_country",
                "carrier",
                "contact_id",
                "currency",
                "deal_id",
                "description",
                "discount",
                "due_date",
                "exchange_rate",
                "so_number",
                "sales_commission",
                "shipping_street",
                "shipping_city",
                "shipping_state",
                "shipping_code",
                "shipping_country",
                "status",
                "terms_and_conditions",
                "custom_fields",
            ],
        },
        "create_vendor": {
            "inputs": [
                {
                    "field": "vendor_name",
                    "type": "string",
                    "value": "",
                    "label": "Vendor Name",
                    "placeholder": "ABC Supplies Inc",
                    "helper_text": "Name of the vendor (required)",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "vendor@example.com",
                    "helper_text": "Vendor email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://vendor.com",
                    "helper_text": "Website URL",
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "Office Supplies",
                    "helper_text": "Vendor category",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Vendor description",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "San Francisco",
                    "helper_text": "City",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "CA",
                    "helper_text": "State",
                },
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "94102",
                    "helper_text": "Postal code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created vendor",
                },
                {
                    "field": "vendor_name",
                    "type": "string",
                    "helper_text": "Name of the vendor",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the vendor was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_vendor",
            "task_name": "tasks.zoho.create_vendor",
            "description": "Create a new vendor in Zoho CRM",
            "label": "Create Vendor",
            "required": ["vendor_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "vendor_name",
                "email",
                "phone",
                "website",
                "category",
                "description",
                "currency",
                "street",
                "city",
                "state",
                "zip_code",
                "country",
                "custom_fields",
            ],
        },
        "get_vendor": {
            "inputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "label": "Vendor ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the vendor to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the vendor",
                },
                {
                    "field": "vendor_name",
                    "type": "string",
                    "helper_text": "Vendor name",
                },
                {"field": "email", "type": "string", "helper_text": "Email address"},
                {"field": "phone", "type": "string", "helper_text": "Phone number"},
                {"field": "website", "type": "string", "helper_text": "Website URL"},
                {"field": "category", "type": "string", "helper_text": "Category"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description",
                },
                {"field": "currency", "type": "string", "helper_text": "Currency code"},
                {"field": "street", "type": "string", "helper_text": "Street address"},
                {"field": "city", "type": "string", "helper_text": "City"},
                {"field": "state", "type": "string", "helper_text": "State"},
                {"field": "zip_code", "type": "string", "helper_text": "Postal code"},
                {"field": "country", "type": "string", "helper_text": "Country"},
                {"field": "owner_id", "type": "string", "helper_text": "Owner ID"},
                {"field": "owner_name", "type": "string", "helper_text": "Owner name"},
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Owner email",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "helper_text": "ID of creator",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of creator",
                },
                {
                    "field": "modified_by_id",
                    "type": "string",
                    "helper_text": "ID of last modifier",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of last modifier",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the vendor was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the vendor was last modified",
                },
                {
                    "field": "vendor_details",
                    "type": "string",
                    "helper_text": "Full vendor details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_vendor",
            "task_name": "tasks.zoho.get_vendor",
            "description": "Read details of a vendor",
            "label": "Get Vendor",
            "required": ["vendor_id"],
            "inputs_sort_order": ["integration", "action", "vendor_id"],
        },
        "list_vendors": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all vendors or only up to a given limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of vendors to return",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "Vendor_Name",
                    "helper_text": "Field to sort records by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "placeholder": "asc",
                    "helper_text": "Sort order: asc or desc",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "placeholder": "Vendor_Name,Email,Phone",
                    "helper_text": "Comma-separated list of fields to return",
                },
                {
                    "field": "approved",
                    "type": "bool",
                    "value": True,
                    "label": "Approved Only",
                    "helper_text": "Whether to retrieve only approved records",
                },
                {
                    "field": "converted",
                    "type": "bool",
                    "value": False,
                    "label": "Converted Only",
                    "helper_text": "Whether to retrieve only converted records",
                },
                {
                    "field": "include_child",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child",
                    "helper_text": "Whether to retrieve records from child territories",
                },
                {
                    "field": "territory_id",
                    "type": "string",
                    "value": "",
                    "label": "Territory ID",
                    "placeholder": "123456789",
                    "helper_text": "Filter by territory ID",
                },
            ],
            "outputs": [
                {
                    "field": "vendor_ids",
                    "type": "vec<string>",
                    "helper_text": "List of vendor IDs",
                },
                {
                    "field": "vendor_names",
                    "type": "vec<string>",
                    "helper_text": "List of vendor names",
                },
                {
                    "field": "vendor_emails",
                    "type": "vec<string>",
                    "helper_text": "List of email addresses",
                },
                {
                    "field": "vendor_phones",
                    "type": "vec<string>",
                    "helper_text": "List of phone numbers",
                },
                {
                    "field": "vendor_websites",
                    "type": "vec<string>",
                    "helper_text": "List of website URLs",
                },
                {
                    "field": "vendor_categories",
                    "type": "vec<string>",
                    "helper_text": "List of categories",
                },
                {
                    "field": "vendor_details",
                    "type": "vec<string>",
                    "helper_text": "List of vendor details in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of vendors returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_vendors",
            "task_name": "tasks.zoho.list_vendors",
            "description": "Get multiple vendors",
            "label": "List Vendors",
            "required": [],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "sort_by",
                "sort_order",
                "fields",
                "approved",
                "converted",
                "include_child",
                "territory_id",
            ],
        },
        "update_vendor": {
            "inputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "label": "Vendor ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the vendor to update (required)",
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "Office Supplies",
                    "helper_text": "Vendor category",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "San Francisco",
                    "helper_text": "City",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "placeholder": "USD",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Vendor description",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "vendor@example.com",
                    "helper_text": "Email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "CA",
                    "helper_text": "State",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "vendor_name",
                    "type": "string",
                    "value": "",
                    "label": "Vendor Name",
                    "placeholder": "ABC Supplies Inc",
                    "helper_text": "Vendor name",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://vendor.com",
                    "helper_text": "Website URL",
                },
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "94102",
                    "helper_text": "Postal code",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "helper_text": "ID of the updated vendor",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the vendor was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_vendor",
            "task_name": "tasks.zoho.update_vendor",
            "description": "Update an existing vendor in Zoho CRM",
            "label": "Update Vendor",
            "required": ["vendor_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "vendor_id",
                "category",
                "city",
                "country",
                "currency",
                "description",
                "email",
                "phone",
                "state",
                "street",
                "vendor_name",
                "website",
                "zip_code",
                "custom_fields",
            ],
        },
        "delete_vendor": {
            "inputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "label": "Vendor ID",
                    "placeholder": "123456789012345678",
                    "helper_text": "The ID of the vendor to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "helper_text": "ID of the deleted vendor",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_vendor",
            "task_name": "tasks.zoho.delete_vendor",
            "description": "Delete a vendor from Zoho CRM",
            "label": "Delete Vendor",
            "required": ["vendor_id"],
            "inputs_sort_order": ["integration", "action", "vendor_id"],
        },
        "upsert_vendor": {
            "inputs": [
                {
                    "field": "vendor_name",
                    "type": "string",
                    "value": "",
                    "label": "Vendor Name",
                    "placeholder": "ABC Supplies Inc",
                    "helper_text": "Name of the vendor (required)",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "vendor@example.com",
                    "helper_text": "Email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://vendor.com",
                    "helper_text": "Website URL",
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "Office Supplies",
                    "helper_text": "Vendor category",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Vendor description",
                },
                {
                    "field": "currency",
                    "type": "string",
                    "value": "",
                    "label": "Currency",
                    "helper_text": "ISO 4217 currency code (e.g., USD, EUR, GBP). Note: Only use currencies that are enabled in your Zoho CRM Settings → Company Details → Currencies",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "zoho_currency",
                    },
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "San Francisco",
                    "helper_text": "City",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "CA",
                    "helper_text": "State",
                },
                {
                    "field": "zip_code",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "94102",
                    "helper_text": "Postal code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "label": "Custom Fields (JSON)",
                    "placeholder": '{"API_Field_Name": "value"}',
                    "helper_text": 'Custom fields as JSON using API names, not display names (e.g., {"Custom_Rating__c": "Hot", "Account_Source": "Web"})',
                },
            ],
            "outputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "helper_text": "ID of the vendor",
                },
                {
                    "field": "vendor_name",
                    "type": "string",
                    "helper_text": "Vendor name",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action taken (created or updated)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the operation",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Message from API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_vendor",
            "task_name": "tasks.zoho.upsert_vendor",
            "description": "Create or update a vendor in Zoho CRM",
            "label": "Create or Update Vendor",
            "required": ["vendor_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "vendor_name",
                "email",
                "phone",
                "website",
                "category",
                "description",
                "currency",
                "street",
                "city",
                "state",
                "zip_code",
                "country",
                "custom_fields",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        account_id: str = "",
        account_name: str = "",
        account_number: str = "",
        account_site: str = "",
        account_type: str = "",
        adjustment: Any = 0,
        amount: Any = 0,
        annual_revenue: Any = None,
        approved: bool = True,
        assistant: str = "",
        asst_phone: str = "",
        billing_city: str = "",
        billing_code: str = "",
        billing_country: str = "",
        billing_state: str = "",
        billing_street: str = "",
        carrier: str = "",
        category: str = "",
        city: str = "",
        closing_date: Any = None,
        commission_rate: Any = 0,
        company: str = "",
        contact_details: str = "",
        contact_id: str = "",
        converted: bool = False,
        country: str = "",
        currency: str = "",
        custom_fields: str = "",
        date_of_birth: Any = None,
        deal_id: str = "",
        deal_name: str = "",
        department: str = "",
        description: str = "",
        designation: str = "",
        discount: Any = 0,
        due_date: Any = None,
        email: str = "",
        email_opt_out: bool = False,
        employees: int = None,
        exchange_rate: Any = None,
        fax: str = "",
        fields: str = "",
        first_name: str = "",
        full_name: str = "",
        home_phone: str = "",
        include_child: bool = False,
        industry: str = "",
        industry_type: str = "",
        invoice_date: Any = None,
        invoice_id: str = "",
        invoice_number: str = "",
        last_name: str = "",
        lead_conversion_time: int = 0,
        lead_id: str = "",
        lead_source: str = "",
        lead_status: str = "",
        limit: int = 10,
        mailing_city: str = "",
        mailing_country: str = "",
        mailing_state: str = "",
        mailing_street: str = "",
        mailing_zip: str = "",
        manufacturer: str = "",
        mobile: str = "",
        next_step: str = "",
        no_of_employees: int = 0,
        other_city: str = "",
        other_country: str = "",
        other_phone: str = "",
        other_state: str = "",
        other_street: str = "",
        other_zip: str = "",
        overall_sales_duration: int = 0,
        phone: str = "",
        po_date: Any = None,
        po_number: str = "",
        probability: int = 0,
        product_active: bool = False,
        product_category: str = "",
        product_descriptions: List[str] = [],
        product_id: str = "",
        product_ids: List[str] = [],
        product_list_prices: List[str] = [],
        product_name: str = "",
        product_quantities: List[str] = [],
        product_taxes: List[str] = [],
        purchase_order_id: str = "",
        qty_in_demand: Any = 0,
        qty_in_stock: Any = 0,
        quote_id: str = "",
        quote_stage: str = "",
        return_all: bool = False,
        sales_commission: Any = 0,
        sales_cycle_duration: int = 0,
        sales_order_id: str = "",
        salutation: str = "",
        secondary_email: str = "",
        shipping_city: str = "",
        shipping_code: str = "",
        shipping_country: str = "",
        shipping_state: str = "",
        shipping_street: str = "",
        skype_id: str = "",
        so_number: str = "",
        sort_by: str = "",
        sort_order: str = "desc",
        stage: str = "",
        state: str = "",
        status: str = "",
        street: str = "",
        subject: str = "",
        taxable: bool = False,
        team: str = "",
        terms_and_conditions: str = "",
        territory_id: str = "",
        ticker_symbol: str = "",
        title: str = "",
        tracking_number: str = "",
        twitter: str = "",
        unit_price: Any = 0,
        valid_till: Any = None,
        vendor_id: str = "",
        vendor_name: str = "",
        website: str = "",
        zip_code: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_zoho",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if account_name is not None:
            self.inputs["account_name"] = account_name
        if account_type is not None:
            self.inputs["account_type"] = account_type
        if industry is not None:
            self.inputs["industry"] = industry
        if phone is not None:
            self.inputs["phone"] = phone
        if website is not None:
            self.inputs["website"] = website
        if fax is not None:
            self.inputs["fax"] = fax
        if annual_revenue is not None:
            self.inputs["annual_revenue"] = annual_revenue
        if employees is not None:
            self.inputs["employees"] = employees
        if account_number is not None:
            self.inputs["account_number"] = account_number
        if account_site is not None:
            self.inputs["account_site"] = account_site
        if ticker_symbol is not None:
            self.inputs["ticker_symbol"] = ticker_symbol
        if currency is not None:
            self.inputs["currency"] = currency
        if exchange_rate is not None:
            self.inputs["exchange_rate"] = exchange_rate
        if contact_details is not None:
            self.inputs["contact_details"] = contact_details
        if description is not None:
            self.inputs["description"] = description
        if billing_street is not None:
            self.inputs["billing_street"] = billing_street
        if billing_city is not None:
            self.inputs["billing_city"] = billing_city
        if billing_state is not None:
            self.inputs["billing_state"] = billing_state
        if billing_code is not None:
            self.inputs["billing_code"] = billing_code
        if billing_country is not None:
            self.inputs["billing_country"] = billing_country
        if shipping_street is not None:
            self.inputs["shipping_street"] = shipping_street
        if shipping_city is not None:
            self.inputs["shipping_city"] = shipping_city
        if shipping_state is not None:
            self.inputs["shipping_state"] = shipping_state
        if shipping_code is not None:
            self.inputs["shipping_code"] = shipping_code
        if shipping_country is not None:
            self.inputs["shipping_country"] = shipping_country
        if custom_fields is not None:
            self.inputs["custom_fields"] = custom_fields
        if account_id is not None:
            self.inputs["account_id"] = account_id
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if sort_by is not None:
            self.inputs["sort_by"] = sort_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if fields is not None:
            self.inputs["fields"] = fields
        if approved is not None:
            self.inputs["approved"] = approved
        if converted is not None:
            self.inputs["converted"] = converted
        if include_child is not None:
            self.inputs["include_child"] = include_child
        if territory_id is not None:
            self.inputs["territory_id"] = territory_id
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if full_name is not None:
            self.inputs["full_name"] = full_name
        if email is not None:
            self.inputs["email"] = email
        if secondary_email is not None:
            self.inputs["secondary_email"] = secondary_email
        if mobile is not None:
            self.inputs["mobile"] = mobile
        if home_phone is not None:
            self.inputs["home_phone"] = home_phone
        if other_phone is not None:
            self.inputs["other_phone"] = other_phone
        if asst_phone is not None:
            self.inputs["asst_phone"] = asst_phone
        if department is not None:
            self.inputs["department"] = department
        if title is not None:
            self.inputs["title"] = title
        if assistant is not None:
            self.inputs["assistant"] = assistant
        if salutation is not None:
            self.inputs["salutation"] = salutation
        if date_of_birth is not None:
            self.inputs["date_of_birth"] = date_of_birth
        if skype_id is not None:
            self.inputs["skype_id"] = skype_id
        if twitter is not None:
            self.inputs["twitter"] = twitter
        if mailing_street is not None:
            self.inputs["mailing_street"] = mailing_street
        if mailing_city is not None:
            self.inputs["mailing_city"] = mailing_city
        if mailing_state is not None:
            self.inputs["mailing_state"] = mailing_state
        if mailing_zip is not None:
            self.inputs["mailing_zip"] = mailing_zip
        if mailing_country is not None:
            self.inputs["mailing_country"] = mailing_country
        if other_street is not None:
            self.inputs["other_street"] = other_street
        if other_city is not None:
            self.inputs["other_city"] = other_city
        if other_state is not None:
            self.inputs["other_state"] = other_state
        if other_zip is not None:
            self.inputs["other_zip"] = other_zip
        if other_country is not None:
            self.inputs["other_country"] = other_country
        if contact_id is not None:
            self.inputs["contact_id"] = contact_id
        if deal_name is not None:
            self.inputs["deal_name"] = deal_name
        if stage is not None:
            self.inputs["stage"] = stage
        if amount is not None:
            self.inputs["amount"] = amount
        if closing_date is not None:
            self.inputs["closing_date"] = closing_date
        if lead_conversion_time is not None:
            self.inputs["lead_conversion_time"] = lead_conversion_time
        if next_step is not None:
            self.inputs["next_step"] = next_step
        if overall_sales_duration is not None:
            self.inputs["overall_sales_duration"] = overall_sales_duration
        if probability is not None:
            self.inputs["probability"] = probability
        if sales_cycle_duration is not None:
            self.inputs["sales_cycle_duration"] = sales_cycle_duration
        if deal_id is not None:
            self.inputs["deal_id"] = deal_id
        if company is not None:
            self.inputs["company"] = company
        if city is not None:
            self.inputs["city"] = city
        if country is not None:
            self.inputs["country"] = country
        if designation is not None:
            self.inputs["designation"] = designation
        if email_opt_out is not None:
            self.inputs["email_opt_out"] = email_opt_out
        if industry_type is not None:
            self.inputs["industry_type"] = industry_type
        if lead_source is not None:
            self.inputs["lead_source"] = lead_source
        if lead_status is not None:
            self.inputs["lead_status"] = lead_status
        if no_of_employees is not None:
            self.inputs["no_of_employees"] = no_of_employees
        if state is not None:
            self.inputs["state"] = state
        if street is not None:
            self.inputs["street"] = street
        if zip_code is not None:
            self.inputs["zip_code"] = zip_code
        if lead_id is not None:
            self.inputs["lead_id"] = lead_id
        if subject is not None:
            self.inputs["subject"] = subject
        if product_ids is not None:
            self.inputs["product_ids"] = product_ids
        if product_quantities is not None:
            self.inputs["product_quantities"] = product_quantities
        if product_list_prices is not None:
            self.inputs["product_list_prices"] = product_list_prices
        if product_descriptions is not None:
            self.inputs["product_descriptions"] = product_descriptions
        if product_taxes is not None:
            self.inputs["product_taxes"] = product_taxes
        if adjustment is not None:
            self.inputs["adjustment"] = adjustment
        if due_date is not None:
            self.inputs["due_date"] = due_date
        if invoice_date is not None:
            self.inputs["invoice_date"] = invoice_date
        if invoice_number is not None:
            self.inputs["invoice_number"] = invoice_number
        if sales_commission is not None:
            self.inputs["sales_commission"] = sales_commission
        if status is not None:
            self.inputs["status"] = status
        if terms_and_conditions is not None:
            self.inputs["terms_and_conditions"] = terms_and_conditions
        if invoice_id is not None:
            self.inputs["invoice_id"] = invoice_id
        if product_name is not None:
            self.inputs["product_name"] = product_name
        if commission_rate is not None:
            self.inputs["commission_rate"] = commission_rate
        if manufacturer is not None:
            self.inputs["manufacturer"] = manufacturer
        if product_active is not None:
            self.inputs["product_active"] = product_active
        if product_category is not None:
            self.inputs["product_category"] = product_category
        if qty_in_demand is not None:
            self.inputs["qty_in_demand"] = qty_in_demand
        if qty_in_stock is not None:
            self.inputs["qty_in_stock"] = qty_in_stock
        if taxable is not None:
            self.inputs["taxable"] = taxable
        if unit_price is not None:
            self.inputs["unit_price"] = unit_price
        if product_id is not None:
            self.inputs["product_id"] = product_id
        if vendor_id is not None:
            self.inputs["vendor_id"] = vendor_id
        if carrier is not None:
            self.inputs["carrier"] = carrier
        if discount is not None:
            self.inputs["discount"] = discount
        if po_date is not None:
            self.inputs["po_date"] = po_date
        if po_number is not None:
            self.inputs["po_number"] = po_number
        if tracking_number is not None:
            self.inputs["tracking_number"] = tracking_number
        if purchase_order_id is not None:
            self.inputs["purchase_order_id"] = purchase_order_id
        if quote_stage is not None:
            self.inputs["quote_stage"] = quote_stage
        if team is not None:
            self.inputs["team"] = team
        if valid_till is not None:
            self.inputs["valid_till"] = valid_till
        if quote_id is not None:
            self.inputs["quote_id"] = quote_id
        if so_number is not None:
            self.inputs["so_number"] = so_number
        if sales_order_id is not None:
            self.inputs["sales_order_id"] = sales_order_id
        if vendor_name is not None:
            self.inputs["vendor_name"] = vendor_name
        if category is not None:
            self.inputs["category"] = category
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationZohoNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
