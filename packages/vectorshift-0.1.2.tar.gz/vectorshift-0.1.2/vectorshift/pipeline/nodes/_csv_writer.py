"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import ListNameTypeValue


@Node.register_node_type("csv_writer")
class CsvWriterNode(Node):
    """
    Create a CSV from data.

    ## Inputs
    ### Common Inputs
        load_option: Whether to load the CSV from a file or a string.
        selected_option: Whether to create a new CSV or update an existing one.
    ### When selected_option = 'new'
        columns: The columns to write to the CSV.
    ### When selected_option = 'old' and load_option = 'file'
        columns: The columns to write to the CSV.
        selected_file: The file to update.
    ### When selected_option = 'old' and load_option = 'text'
        csv_string: The CSV string to write.

    ## Outputs
    ### Common Outputs
        file: The CSV file created or updated.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "load_option",
            "helper_text": "Whether to load the CSV from a file or a string.",
            "value": "file",
            "type": "string",
        },
        {
            "field": "selected_option",
            "helper_text": "Whether to create a new CSV or update an existing one.",
            "value": "new",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "file",
            "helper_text": "The CSV file created or updated.",
            "type": "file",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new**(*)": {
            "inputs": [
                {
                    "field": "columns",
                    "type": "vec<interface{id: string, name: string, type: string, value: vec<string>}>",
                    "value": [
                        {"id": "abcd1234", "name": "", "value": "", "type": "string"}
                    ],
                    "helper_text": "The columns to write to the CSV.",
                    "component": {
                        "type": "table",
                        "table": {
                            "name": {
                                "helper_text": "The name of the column",
                                "label": "Column names",
                            },
                            "value": {
                                "helper_text": "The value of the column",
                                "label": "Column values",
                            },
                            "type": {"default_value": "vec<string>"},
                            "hidden_columns": ["type"],
                        },
                        "decorators": {"hide": ["general_input_label"]},
                    },
                }
            ],
            "outputs": [],
        },
        "old**file": {
            "inputs": [
                {
                    "field": "selected_file",
                    "type": "file",
                    "label": "File",
                    "helper_text": "The file to update.",
                    "component": {
                        "type": "file",
                        "decorators": {"hide": ["variable_switch"]},
                    },
                },
                {
                    "field": "columns",
                    "type": "vec<interface{id: string, name: string, type: string, value: vec<string>}>",
                    "value": [
                        {
                            "id": "abcdefghij1234",
                            "name": "",
                            "value": "",
                            "type": "string",
                        }
                    ],
                    "helper_text": "The columns to write to the CSV.",
                    "component": {
                        "type": "table",
                        "decorators": {"hide": ["general_input_label"]},
                        "table": {
                            "name": {"helper_text": "The name of the column"},
                            "value": {
                                "helper_text": "The value of the column",
                                "label": "Column values",
                            },
                            "type": {"default_value": "vec<string>"},
                            "hidden_columns": ["type", "name"],
                        },
                    },
                    "visibility": {"field": "selected_file", "operator": "!is_empty"},
                },
            ],
            "outputs": [],
        },
        "old**text": {
            "inputs": [
                {
                    "field": "csv_string",
                    "type": "string",
                    "value": "",
                    "label": "CSV String",
                    "helper_text": "The CSV string to write.",
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["selected_option", "load_option"]

    _batch_mode_allowed = True

    def __init__(
        self,
        selected_option: str = "new",
        load_option: str = "file",
        columns: List[ListNameTypeValue] = [
            {"id": "abcd1234", "name": "", "value": "", "type": "string"}
        ],
        csv_string: str = "",
        selected_file: Optional[str] = None,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["selected_option"] = selected_option
        params["load_option"] = load_option

        super().__init__(
            node_type="csv_writer",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if selected_option is not None:
            self.inputs["selected_option"] = selected_option
        if load_option is not None:
            self.inputs["load_option"] = load_option
        if columns is not None:
            self.inputs["columns"] = columns
        if selected_file is not None:
            self.inputs["selected_file"] = selected_file
        if csv_string is not None:
            self.inputs["csv_string"] = csv_string
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CsvWriterNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
