"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_fred")
class IntegrationFredNode(Node):
    """
    Fred

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your FRED API account
    ### When action = 'list_series_observations'
        aggregation_method: Method for frequency aggregation
        frequency: Frequency aggregation
        observation_end: End date for observations (format: YYYY-MM-DD)
        observation_start: Start date for observations (format: YYYY-MM-DD)
        output_type: Output type for observations
        series_id: The ID of the series to retrieve
        sort_order: Sort order for results
        units: Data transformation
        use_date: Toggle to filter by date range
        vintage_dates: Comma-separated vintage dates
    ### When action = 'get_category'
        category_id: The ID of the category to retrieve. Use 0 for root category
    ### When action = 'list_category_children'
        category_id: The ID of the category to retrieve. Use 0 for root category
        use_date: Toggle to filter by date range
    ### When action = 'list_category_related'
        category_id: The ID of the category to retrieve. Use 0 for root category
        use_date: Toggle to filter by date range
    ### When action = 'list_category_series'
        category_id: The ID of the category to retrieve. Use 0 for root category
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        filter_value: Value to filter by
        filter_variable: Filter by attribute
        order_by: Order results by attribute
        sort_order: Sort order for results
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_category_tags'
        category_id: The ID of the category to retrieve. Use 0 for root category
        order_by: Order results by attribute
        search_text: Search for tags containing this text
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_category_related_tags'
        category_id: The ID of the category to retrieve. Use 0 for root category
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        order_by: Order results by attribute
        search_text: Search for tags containing this text
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_category_children' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_category_related' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_category_series' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_category_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_category_related_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_releases' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_release_info' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_release_dates' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_release_series' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_release_sources' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_release_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_release_related_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_series' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_categories' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_observations' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_series_release' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_series_search' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_search_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_search_related_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_updates' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_series_vintagedates' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_sources' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_source' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_source_releases' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_related_tags' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_tags_series' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'list_release_tables'
        element_id: The element ID to filter tables (0 for all)
        include_observation_values: Include observation values in the response
        observation_date: Date for observation values (format: YYYY-MM-DD)
        release_id: The ID of the release to retrieve
    ### When action = 'list_series_updates'
        end_time: End time for updates (format: HH:MM)
        filter_value: Value to filter by
        start_time: Start time for updates (format: HH:MM)
        use_date: Toggle to filter by date range
    ### When action = 'list_category_children' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_category_related' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_category_series' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_category_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_category_related_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_releases' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_release_info' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_release_dates' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_release_series' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_release_sources' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_release_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_release_related_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_series' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_categories' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_observations' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_series_release' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_series_search' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_search_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_search_related_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_updates' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_series_vintagedates' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_sources' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_source' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_source_releases' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_related_tags' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_tags_series' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'list_release_series'
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        filter_value: Value to filter by
        filter_variable: Filter by attribute
        order_by: Order results by attribute
        release_id: The ID of the release to retrieve
        sort_order: Sort order for results
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_release_related_tags'
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        order_by: Order results by attribute
        release_id: The ID of the release to retrieve
        search_text: Search for tags containing this text
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'get_series_search'
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        filter_value: Value to filter by
        filter_variable: Filter by attribute
        order_by: Order results by attribute
        search_text: Search for tags containing this text
        search_type: Type of search to perform
        sort_order: Sort order for results
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_series_search_related_tags'
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        order_by: Order results by attribute
        series_search_text: Text to search for in series (required)
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        tag_search_text: Search for tags containing this text
        use_date: Toggle to filter by date range
    ### When action = 'list_related_tags'
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        order_by: Order results by attribute
        search_text: Search for tags containing this text
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_tags_series'
        exclude_tag_names: Exclude series with these tags (semicolon-separated)
        order_by: Order results by attribute
        sort_order: Sort order for results
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_release_dates'
        include_release_dates_with_no_data: Include release dates with no data available
        release_id: The ID of the release to retrieve
        sort_order: Sort order for results
        use_date: Toggle to filter by date range
    ### When action = 'list_category_children' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_category_related' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_category_series' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_category_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_category_related_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_releases' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'get_release_info' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_release_dates' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_release_series' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_release_sources' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_release_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_release_related_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'get_series' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_categories' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_observations' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'get_series_release' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'get_series_search' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_search_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_search_related_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_updates' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_series_vintagedates' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_sources' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'get_source' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_source_releases' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_related_tags' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_tags_series' and use_date = False and return_all = False
        limit: Maximum number of results to return
    ### When action = 'list_releases'
        order_by: Order results by attribute
        sort_order: Sort order for results
        use_date: Toggle to filter by date range
    ### When action = 'list_release_tags'
        order_by: Order results by attribute
        release_id: The ID of the release to retrieve
        search_text: Search for tags containing this text
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'list_series_search_tags'
        order_by: Order results by attribute
        series_search_text: Text to search for in series (required)
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        tag_search_text: Search for tags containing this text
        use_date: Toggle to filter by date range
    ### When action = 'list_series_tags'
        order_by: Order results by attribute
        series_id: The ID of the series to retrieve
        sort_order: Sort order for results
        use_date: Toggle to filter by date range
    ### When action = 'list_sources'
        order_by: Order results by attribute
        sort_order: Sort order for results
        use_date: Toggle to filter by date range
    ### When action = 'list_source_releases'
        order_by: Order results by attribute
        sort_order: Sort order for results
        source_id: The ID of the source to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'list_tags'
        order_by: Order results by attribute
        search_text: Search for tags containing this text
        sort_order: Sort order for results
        tag_group_id: Filter by tag group
        tag_names: Filter by tag names (semicolon-separated)
        use_date: Toggle to filter by date range
    ### When action = 'get_release_info'
        release_id: The ID of the release to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'list_release_sources'
        release_id: The ID of the release to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'list_category_children' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_category_related' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_category_series' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_category_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_category_related_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_releases' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'get_release_info' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_release_dates' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_release_series' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_release_sources' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_release_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_release_related_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'get_series' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_categories' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_observations' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'get_series_release' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'get_series_search' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_search_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_search_related_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_updates' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_series_vintagedates' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_sources' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'get_source' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_source_releases' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_related_tags' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'list_tags_series' and use_date = False
        return_all: Return all results (ignores limit)
    ### When action = 'get_series'
        series_id: The ID of the series to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'list_series_categories'
        series_id: The ID of the series to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'get_series_release'
        series_id: The ID of the series to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'list_series_vintagedates'
        series_id: The ID of the series to retrieve
        sort_order: Sort order for results
        use_date: Toggle to filter by date range
    ### When action = 'get_source'
        source_id: The ID of the source to retrieve
        use_date: Toggle to filter by date range
    ### When action = 'list_category_children' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_category_related' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_category_series' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_category_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_category_related_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_releases' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_release_info' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_release_dates' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_release_series' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_release_sources' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_release_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_release_related_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_series' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_categories' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_observations' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_series_release' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_series_search' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_search_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_search_related_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_updates' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_series_vintagedates' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_sources' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_source' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_source_releases' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_related_tags' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'list_tags_series' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'list_category_children'
        category_ids: List of child category IDs
        category_names: List of child category names
        count: Total number of child categories
        parent_ids: List of parent category IDs
        raw_data: Raw API response data
    ### When action = 'list_category_related'
        category_ids: List of related category IDs
        category_names: List of related category names
        count: Total number of related categories
        parent_ids: List of parent category IDs
        raw_data: Raw API response data
    ### When action = 'list_series_categories'
        category_ids: List of category IDs
        category_names: List of category names
        count: Total number of categories
        parent_ids: List of parent category IDs
        raw_data: Raw API response data
    ### When action = 'list_category_series'
        count: Total number of series
        frequencies: List of data frequencies
        observation_ends: List of observation end dates
        observation_starts: List of observation start dates
        popularities: List of popularity scores
        raw_data: Raw API response data
        seasonal_adjustments: List of seasonal adjustment types
        series_ids: List of series IDs
        titles: List of series titles
        units: List of units
    ### When action = 'list_category_tags'
        count: Total number of tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of tag names
    ### When action = 'list_category_related_tags'
        count: Total number of related tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of related tag names
    ### When action = 'list_releases'
        count: Total number of releases
        links: List of release links
        notes: List of release notes
        press_releases: List indicating if releases are press releases
        raw_data: Raw API response data
        release_ids: List of release IDs
        release_names: List of release names
    ### When action = 'list_release_dates'
        count: Total number of release dates
        raw_data: Raw API response data
        release_dates: List of release dates
    ### When action = 'list_release_series'
        count: Total number of series
        frequencies: List of data frequencies
        observation_ends: List of observation end dates
        observation_starts: List of observation start dates
        popularities: List of popularity scores
        raw_data: Raw API response data
        seasonal_adjustments: List of seasonal adjustment types
        series_ids: List of series IDs
        titles: List of series titles
        units: List of units
    ### When action = 'list_release_sources'
        count: Total number of sources
        links: List of source links
        notes: List of source notes
        raw_data: Raw API response data
        source_ids: List of source IDs
        source_names: List of source names
    ### When action = 'list_release_tags'
        count: Total number of tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of tag names
    ### When action = 'list_release_related_tags'
        count: Total number of related tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of related tag names
    ### When action = 'list_series_observations'
        count: Total number of observations
        dates: List of observation dates
        raw_data: Raw API response data
        realtime_ends: List of real-time end dates
        realtime_starts: List of real-time start dates
        values: List of observation values
    ### When action = 'get_series_search'
        count: Total number of series found
        frequencies: List of data frequencies
        observation_ends: List of observation end dates
        observation_starts: List of observation start dates
        popularities: List of popularity scores
        raw_data: Raw API response data
        seasonal_adjustments: List of seasonal adjustment types
        series_ids: List of series IDs
        titles: List of series titles
        units: List of units
    ### When action = 'list_series_search_tags'
        count: Total number of tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of tag names
    ### When action = 'list_series_search_related_tags'
        count: Total number of related tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of related tag names
    ### When action = 'list_series_tags'
        count: Total number of tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of tag names
    ### When action = 'list_series_updates'
        count: Total number of updated series
        frequencies: List of data frequencies
        last_updated: List of last update timestamps
        popularities: List of popularity scores
        raw_data: Raw API response data
        seasonal_adjustments: List of seasonal adjustment types
        series_ids: List of series IDs
        titles: List of series titles
        units: List of units
    ### When action = 'list_series_vintagedates'
        count: Total number of vintage dates
        raw_data: Raw API response data
        vintage_dates: List of vintage dates
    ### When action = 'list_sources'
        count: Total number of sources
        links: List of source links
        notes: List of source notes
        raw_data: Raw API response data
        source_ids: List of source IDs
        source_names: List of source names
    ### When action = 'list_source_releases'
        count: Total number of releases
        links: List of release links
        notes: List of release notes
        press_releases: List indicating if releases are press releases
        raw_data: Raw API response data
        release_ids: List of release IDs
        release_names: List of release names
    ### When action = 'list_tags'
        count: Total number of tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of tag names
    ### When action = 'list_related_tags'
        count: Total number of related tags
        created_dates: List of creation dates
        group_ids: List of tag group IDs
        notes: List of tag notes
        popularities: List of popularity scores
        raw_data: Raw API response data
        series_counts: List of series counts
        tag_names: List of related tag names
    ### When action = 'list_tags_series'
        count: Total number of series
        frequencies: List of data frequencies
        observation_ends: List of observation end dates
        observation_starts: List of observation start dates
        popularities: List of popularity scores
        raw_data: Raw API response data
        seasonal_adjustments: List of seasonal adjustment types
        series_ids: List of series IDs
        titles: List of series titles
        units: List of units
    ### When action = 'list_release_tables'
        element_id: The element ID
        name: The name of the release table
        raw_data: Raw API response data
    ### When action = 'get_series'
        frequency: The data frequency
        frequency_short: Short frequency code
        group_popularity: Group popularity score
        id: The unique identifier of the series
        notes: Additional notes
        observation_end: Last observation date
        observation_start: First observation date
        popularity: Popularity score
        raw_data: Raw API response data
        seasonal_adjustment: Seasonal adjustment type
        seasonal_adjustment_short: Short seasonal adjustment code
        title: The title of the series
        units: The units of the data
        units_short: Short units code
    ### When action = 'get_category'
        id: The unique identifier of the category
        name: The name of the category
        notes: Additional notes about the category
        parent_id: The ID of the parent category
        raw_data: Raw API response data
    ### When action = 'get_release_info'
        id: The unique identifier of the release
        link: URL link to the release
        name: The name of the release
        notes: Additional notes about the release
        press_release: Whether this is a press release
        raw_data: Raw API response data
        realtime_end: Real-time period end date
        realtime_start: Real-time period start date
    ### When action = 'get_source'
        id: The unique identifier of the source
        link: URL link to the source
        name: The name of the source
        notes: Additional notes about the source
        raw_data: Raw API response data
    ### When action = 'get_series_release'
        link: URL link to the release
        press_release: Whether this is a press release
        raw_data: Raw API response data
        release_id: The release ID
        release_name: The release name
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your FRED API account",
            "value": None,
            "type": "integration<Fred>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)**(*)": {"inputs": [], "outputs": []},
        "get_category**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "label": "Category ID",
                    "placeholder": "125",
                    "helper_text": "The ID of the category to retrieve. Use 0 for root category",
                }
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "int32",
                    "helper_text": "The unique identifier of the category",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the category",
                },
                {
                    "field": "parent_id",
                    "type": "int32",
                    "helper_text": "The ID of the parent category",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "helper_text": "Additional notes about the category",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_category",
            "task_name": "tasks.fred.get_category",
            "description": "Get details of a specific FRED category",
            "label": "Get Category",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["action", "integration", "category_id"],
            "required": ["category_id"],
        },
        "list_category_children**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "label": "Category ID",
                    "placeholder": "125",
                    "helper_text": "The ID of the parent category. Use 0 for root-level categories",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "category_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of child category IDs",
                },
                {
                    "field": "category_names",
                    "type": "vec<string>",
                    "helper_text": "List of child category names",
                },
                {
                    "field": "parent_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of parent category IDs",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of child categories",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_category_children",
            "task_name": "tasks.fred.list_category_children",
            "description": "List child categories for a specified parent category",
            "label": "List Category Children",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "category_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["category_id", "limit", "return_all"],
        },
        "list_category_children**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_category_children**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_category_children**false**(*)**true": {"inputs": [], "outputs": []},
        "list_category_children**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_category_children**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_children**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_related**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "label": "Category ID",
                    "placeholder": "125",
                    "helper_text": "The ID of the category to find related categories for",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "category_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of related category IDs",
                },
                {
                    "field": "category_names",
                    "type": "vec<string>",
                    "helper_text": "List of related category names",
                },
                {
                    "field": "parent_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of parent category IDs",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of related categories",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_category_related",
            "task_name": "tasks.fred.list_category_related",
            "description": "Get related categories for a specified category",
            "label": "List Category Related",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "category_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["category_id", "limit", "return_all"],
        },
        "list_category_related**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_category_related**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_category_related**false**(*)**true": {"inputs": [], "outputs": []},
        "list_category_related**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_category_related**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_related**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_series**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "label": "Category ID",
                    "placeholder": "125",
                    "helper_text": "The ID of the category to get series from",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_id",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_series_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "filter_variable",
                    "type": "string",
                    "value": "frequency",
                    "label": "Filter Variable",
                    "helper_text": "Filter by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_filter_variable",
                    },
                },
                {
                    "field": "filter_value",
                    "type": "string",
                    "value": "",
                    "label": "Filter Value",
                    "placeholder": "all",
                    "helper_text": "Value to filter by",
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Exclude series with these tags (semicolon-separated)",
                },
            ],
            "outputs": [
                {
                    "field": "series_ids",
                    "type": "vec<string>",
                    "helper_text": "List of series IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of series titles",
                },
                {
                    "field": "frequencies",
                    "type": "vec<string>",
                    "helper_text": "List of data frequencies",
                },
                {
                    "field": "units",
                    "type": "vec<string>",
                    "helper_text": "List of units",
                },
                {
                    "field": "seasonal_adjustments",
                    "type": "vec<string>",
                    "helper_text": "List of seasonal adjustment types",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "observation_starts",
                    "type": "vec<string>",
                    "helper_text": "List of observation start dates",
                },
                {
                    "field": "observation_ends",
                    "type": "vec<string>",
                    "helper_text": "List of observation end dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of series",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_category_series",
            "task_name": "tasks.fred.list_category_series",
            "description": "Get series within a specified category",
            "label": "List Category Series",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "category_id",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "filter_variable",
                "filter_value",
                "tag_names",
                "exclude_tag_names",
            ],
            "required": ["category_id", "limit", "return_all"],
        },
        "list_category_series**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_category_series**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_category_series**false**(*)**true": {"inputs": [], "outputs": []},
        "list_category_series**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_category_series**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_series**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "label": "Category ID",
                    "placeholder": "125",
                    "helper_text": "The ID of the category to get tags for",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_category_tags",
            "task_name": "tasks.fred.list_category_tags",
            "description": "Get tags for a specific category",
            "label": "List Category Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "category_id",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "tag_names",
                "tag_group_id",
                "search_text",
            ],
            "required": ["category_id", "limit", "return_all"],
        },
        "list_category_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_category_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_category_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_category_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_category_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_related_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "label": "Category ID",
                    "placeholder": "125",
                    "helper_text": "The ID of the category",
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Tags to find related tags for (semicolon-separated, required)",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Tags to exclude (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of related tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of related tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_category_related_tags",
            "task_name": "tasks.fred.list_category_related_tags",
            "description": "Get related tags for a category",
            "label": "List Category Related Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "category_id",
                "tag_names",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "exclude_tag_names",
                "tag_group_id",
                "search_text",
            ],
            "required": ["category_id", "tag_names", "limit", "return_all"],
        },
        "list_category_related_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_category_related_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_category_related_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_category_related_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_category_related_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_category_related_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_releases**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "release_id",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_releases_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "release_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of release IDs",
                },
                {
                    "field": "release_names",
                    "type": "vec<string>",
                    "helper_text": "List of release names",
                },
                {
                    "field": "links",
                    "type": "vec<string>",
                    "helper_text": "List of release links",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of release notes",
                },
                {
                    "field": "press_releases",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if releases are press releases",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of releases",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_releases",
            "task_name": "tasks.fred.list_releases",
            "description": "Get all releases of economic data",
            "label": "List Releases",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
            ],
            "required": ["limit", "return_all"],
        },
        "list_releases**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_releases**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_releases**false**(*)**true": {"inputs": [], "outputs": []},
        "list_releases**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_releases**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_releases**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_release_info**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "int32",
                    "helper_text": "The unique identifier of the release",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the release",
                },
                {
                    "field": "link",
                    "type": "string",
                    "helper_text": "URL link to the release",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "helper_text": "Additional notes about the release",
                },
                {
                    "field": "press_release",
                    "type": "bool",
                    "helper_text": "Whether this is a press release",
                },
                {
                    "field": "realtime_start",
                    "type": "string",
                    "helper_text": "Real-time period start date",
                },
                {
                    "field": "realtime_end",
                    "type": "string",
                    "helper_text": "Real-time period end date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_release_info",
            "task_name": "tasks.fred.get_release_info",
            "description": "Get information for a specific economic data release",
            "label": "Get Release Info",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["release_id", "limit", "return_all"],
        },
        "get_release_info**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "get_release_info**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "get_release_info**false**(*)**true": {"inputs": [], "outputs": []},
        "get_release_info**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_release_info**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_release_info**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_dates**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "include_release_dates_with_no_data",
                    "type": "bool",
                    "value": False,
                    "label": "Include Empty Dates",
                    "helper_text": "Include release dates with no data available",
                },
            ],
            "outputs": [
                {
                    "field": "release_dates",
                    "type": "vec<string>",
                    "helper_text": "List of release dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of release dates",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_release_dates",
            "task_name": "tasks.fred.list_release_dates",
            "description": "Get release dates for a specific economic data release",
            "label": "List Release Dates",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "use_date",
                "limit",
                "return_all",
                "sort_order",
                "include_release_dates_with_no_data",
            ],
            "required": ["release_id", "limit", "return_all"],
        },
        "list_release_dates**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_release_dates**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_release_dates**false**(*)**true": {"inputs": [], "outputs": []},
        "list_release_dates**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_release_dates**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_dates**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_series**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_id",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_series_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "filter_variable",
                    "type": "string",
                    "value": "frequency",
                    "label": "Filter Variable",
                    "helper_text": "Filter by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_filter_variable",
                    },
                },
                {
                    "field": "filter_value",
                    "type": "string",
                    "value": "",
                    "label": "Filter Value",
                    "placeholder": "all",
                    "helper_text": "Value to filter by",
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Exclude series with these tags (semicolon-separated)",
                },
            ],
            "outputs": [
                {
                    "field": "series_ids",
                    "type": "vec<string>",
                    "helper_text": "List of series IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of series titles",
                },
                {
                    "field": "frequencies",
                    "type": "vec<string>",
                    "helper_text": "List of data frequencies",
                },
                {
                    "field": "units",
                    "type": "vec<string>",
                    "helper_text": "List of units",
                },
                {
                    "field": "seasonal_adjustments",
                    "type": "vec<string>",
                    "helper_text": "List of seasonal adjustment types",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "observation_starts",
                    "type": "vec<string>",
                    "helper_text": "List of observation start dates",
                },
                {
                    "field": "observation_ends",
                    "type": "vec<string>",
                    "helper_text": "List of observation end dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of series",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_release_series",
            "task_name": "tasks.fred.list_release_series",
            "description": "Get series for a specific economic data release",
            "label": "List Release Series",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "filter_variable",
                "filter_value",
                "tag_names",
                "exclude_tag_names",
            ],
            "required": ["release_id", "limit", "return_all"],
        },
        "list_release_series**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_release_series**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_release_series**false**(*)**true": {"inputs": [], "outputs": []},
        "list_release_series**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_release_series**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_series**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_sources**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "source_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of source IDs",
                },
                {
                    "field": "source_names",
                    "type": "vec<string>",
                    "helper_text": "List of source names",
                },
                {
                    "field": "links",
                    "type": "vec<string>",
                    "helper_text": "List of source links",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of source notes",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of sources",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_release_sources",
            "task_name": "tasks.fred.list_release_sources",
            "description": "Get sources for a specific economic data release",
            "label": "List Release Sources",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["release_id", "limit", "return_all"],
        },
        "list_release_sources**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_release_sources**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_release_sources**false**(*)**true": {"inputs": [], "outputs": []},
        "list_release_sources**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_release_sources**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_sources**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_release_tags",
            "task_name": "tasks.fred.list_release_tags",
            "description": "Get tags for a specific release",
            "label": "List Release Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "tag_names",
                "tag_group_id",
                "search_text",
            ],
            "required": ["release_id", "limit", "return_all"],
        },
        "list_release_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_release_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_release_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_release_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_release_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_related_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Tags to find related tags for (semicolon-separated, required)",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Tags to exclude (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of related tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of related tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_release_related_tags",
            "task_name": "tasks.fred.list_release_related_tags",
            "description": "Get related tags for a release",
            "label": "List Release Related Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "tag_names",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "exclude_tag_names",
                "tag_group_id",
                "search_text",
            ],
            "required": ["release_id", "tag_names", "limit", "return_all"],
        },
        "list_release_related_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_release_related_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_release_related_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_release_related_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_release_related_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_related_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_release_tables**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "value": "",
                    "label": "Release ID",
                    "placeholder": "53",
                    "helper_text": "The ID of the release",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=release&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "element_id",
                    "type": "int32",
                    "value": 0,
                    "label": "Element ID",
                    "placeholder": "0",
                    "helper_text": "The element ID to filter tables (0 for all)",
                },
                {
                    "field": "include_observation_values",
                    "type": "bool",
                    "value": False,
                    "label": "Include Observation Values",
                    "helper_text": "Include observation values in the response",
                },
                {
                    "field": "observation_date",
                    "type": "string",
                    "value": "",
                    "label": "Observation Date",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "Date for observation values (format: YYYY-MM-DD)",
                },
            ],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the release table",
                },
                {
                    "field": "element_id",
                    "type": "int32",
                    "helper_text": "The element ID",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_release_tables",
            "task_name": "tasks.fred.list_release_tables",
            "description": "Get data tables for a specific economic data release",
            "label": "List Release Tables",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "release_id",
                "element_id",
                "include_observation_values",
                "observation_date",
            ],
            "required": ["release_id"],
        },
        "get_series**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_id",
                    "type": "string",
                    "value": "",
                    "label": "Series ID",
                    "placeholder": "GNPCA",
                    "helper_text": "The ID of the series to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=series&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "The unique identifier of the series",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "The title of the series",
                },
                {
                    "field": "frequency",
                    "type": "string",
                    "helper_text": "The data frequency",
                },
                {
                    "field": "frequency_short",
                    "type": "string",
                    "helper_text": "Short frequency code",
                },
                {
                    "field": "units",
                    "type": "string",
                    "helper_text": "The units of the data",
                },
                {
                    "field": "units_short",
                    "type": "string",
                    "helper_text": "Short units code",
                },
                {
                    "field": "seasonal_adjustment",
                    "type": "string",
                    "helper_text": "Seasonal adjustment type",
                },
                {
                    "field": "seasonal_adjustment_short",
                    "type": "string",
                    "helper_text": "Short seasonal adjustment code",
                },
                {
                    "field": "observation_start",
                    "type": "string",
                    "helper_text": "First observation date",
                },
                {
                    "field": "observation_end",
                    "type": "string",
                    "helper_text": "Last observation date",
                },
                {
                    "field": "popularity",
                    "type": "int32",
                    "helper_text": "Popularity score",
                },
                {
                    "field": "group_popularity",
                    "type": "int32",
                    "helper_text": "Group popularity score",
                },
                {"field": "notes", "type": "string", "helper_text": "Additional notes"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_series",
            "task_name": "tasks.fred.get_series",
            "description": "Get an economic data series",
            "label": "Get Series",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["series_id", "limit", "return_all"],
        },
        "get_series**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "get_series**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "get_series**false**(*)**true": {"inputs": [], "outputs": []},
        "get_series**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_series**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_series**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_categories**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_id",
                    "type": "string",
                    "value": "",
                    "label": "Series ID",
                    "placeholder": "GNPCA",
                    "helper_text": "The ID of the series",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=series&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "category_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of category IDs",
                },
                {
                    "field": "category_names",
                    "type": "vec<string>",
                    "helper_text": "List of category names",
                },
                {
                    "field": "parent_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of parent category IDs",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of categories",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_categories",
            "task_name": "tasks.fred.list_series_categories",
            "description": "Get categories for an economic data series",
            "label": "List Series Categories",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["series_id", "limit", "return_all"],
        },
        "list_series_categories**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_categories**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_categories**false**(*)**true": {"inputs": [], "outputs": []},
        "list_series_categories**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_categories**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_categories**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_observations**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_id",
                    "type": "string",
                    "value": "",
                    "label": "Series ID",
                    "placeholder": "GNPCA",
                    "helper_text": "The ID of the series",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=series&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "observation_start",
                    "type": "string",
                    "value": "",
                    "label": "Observation Start",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "Start date for observations (format: YYYY-MM-DD)",
                },
                {
                    "field": "observation_end",
                    "type": "string",
                    "value": "",
                    "label": "Observation End",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "End date for observations (format: YYYY-MM-DD)",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "units",
                    "type": "string",
                    "value": "lin",
                    "label": "Units",
                    "helper_text": "Data transformation",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_units",
                    },
                },
                {
                    "field": "frequency",
                    "type": "string",
                    "value": "m",
                    "label": "Frequency",
                    "helper_text": "Frequency aggregation",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_frequency",
                    },
                },
                {
                    "field": "aggregation_method",
                    "type": "string",
                    "value": "avg",
                    "label": "Aggregation Method",
                    "helper_text": "Method for frequency aggregation",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_aggregation_method",
                    },
                },
                {
                    "field": "output_type",
                    "type": "string",
                    "value": "1",
                    "label": "Output Type",
                    "helper_text": "Output type for observations",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_output_type",
                    },
                },
                {
                    "field": "vintage_dates",
                    "type": "string",
                    "value": "",
                    "label": "Vintage Dates",
                    "placeholder": "2020-01-01,2021-01-01",
                    "helper_text": "Comma-separated vintage dates",
                },
            ],
            "outputs": [
                {
                    "field": "dates",
                    "type": "vec<string>",
                    "helper_text": "List of observation dates",
                },
                {
                    "field": "values",
                    "type": "vec<string>",
                    "helper_text": "List of observation values",
                },
                {
                    "field": "realtime_starts",
                    "type": "vec<string>",
                    "helper_text": "List of real-time start dates",
                },
                {
                    "field": "realtime_ends",
                    "type": "vec<string>",
                    "helper_text": "List of real-time end dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of observations",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_observations",
            "task_name": "tasks.fred.list_series_observations",
            "description": "Get observations or data values for an economic data series",
            "label": "List Series Observations",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_id",
                "use_date",
                "limit",
                "return_all",
                "observation_start",
                "observation_end",
                "sort_order",
                "units",
                "frequency",
                "aggregation_method",
                "output_type",
                "vintage_dates",
            ],
            "required": ["series_id", "limit", "return_all"],
        },
        "list_series_observations**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_observations**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_observations**false**(*)**true": {"inputs": [], "outputs": []},
        "list_series_observations**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_observations**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_observations**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_series_release**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_id",
                    "type": "string",
                    "value": "",
                    "label": "Series ID",
                    "placeholder": "GNPCA",
                    "helper_text": "The ID of the series",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=series&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "release_id",
                    "type": "int32",
                    "helper_text": "The release ID",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "The release name",
                },
                {
                    "field": "link",
                    "type": "string",
                    "helper_text": "URL link to the release",
                },
                {
                    "field": "press_release",
                    "type": "bool",
                    "helper_text": "Whether this is a press release",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_series_release",
            "task_name": "tasks.fred.get_series_release",
            "description": "Get the release for an economic data series",
            "label": "Get Series Release",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["series_id", "limit", "return_all"],
        },
        "get_series_release**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "get_series_release**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "get_series_release**false**(*)**true": {"inputs": [], "outputs": []},
        "get_series_release**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_series_release**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_series_release**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_series_search**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary service index",
                    "helper_text": "Text to search for in series (required)",
                },
                {
                    "field": "search_type",
                    "type": "string",
                    "value": "full_text",
                    "label": "Search Type",
                    "helper_text": "Type of search to perform",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_search_type",
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "search_rank",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_series_search_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "filter_variable",
                    "type": "string",
                    "value": "frequency",
                    "label": "Filter Variable",
                    "helper_text": "Filter by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_filter_variable",
                    },
                },
                {
                    "field": "filter_value",
                    "type": "string",
                    "value": "",
                    "label": "Filter Value",
                    "placeholder": "all",
                    "helper_text": "Value to filter by",
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Exclude series with these tags (semicolon-separated)",
                },
            ],
            "outputs": [
                {
                    "field": "series_ids",
                    "type": "vec<string>",
                    "helper_text": "List of series IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of series titles",
                },
                {
                    "field": "frequencies",
                    "type": "vec<string>",
                    "helper_text": "List of data frequencies",
                },
                {
                    "field": "units",
                    "type": "vec<string>",
                    "helper_text": "List of units",
                },
                {
                    "field": "seasonal_adjustments",
                    "type": "vec<string>",
                    "helper_text": "List of seasonal adjustment types",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "observation_starts",
                    "type": "vec<string>",
                    "helper_text": "List of observation start dates",
                },
                {
                    "field": "observation_ends",
                    "type": "vec<string>",
                    "helper_text": "List of observation end dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of series found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_series_search",
            "task_name": "tasks.fred.get_series_search",
            "description": "Search for economic data series that match keywords",
            "label": "Search Series",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "search_text",
                "search_type",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "filter_variable",
                "filter_value",
                "tag_names",
                "exclude_tag_names",
            ],
            "required": ["search_text", "limit", "return_all"],
        },
        "get_series_search**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "get_series_search**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "get_series_search**false**(*)**true": {"inputs": [], "outputs": []},
        "get_series_search**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_series_search**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_series_search**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_search_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_search_text",
                    "type": "string",
                    "value": "",
                    "label": "Series Search Text",
                    "placeholder": "monetary service index",
                    "helper_text": "Text to search for in series (required)",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "tag_search_text",
                    "type": "string",
                    "value": "",
                    "label": "Tag Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_search_tags",
            "task_name": "tasks.fred.list_series_search_tags",
            "description": "Get tags for series search results",
            "label": "List Series Search Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_search_text",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "tag_names",
                "tag_group_id",
                "tag_search_text",
            ],
            "required": ["series_search_text", "limit", "return_all"],
        },
        "list_series_search_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_search_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_search_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_series_search_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_search_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_search_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_search_related_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_search_text",
                    "type": "string",
                    "value": "",
                    "label": "Series Search Text",
                    "placeholder": "monetary service index",
                    "helper_text": "Text to search for in series (required)",
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Tags to find related tags for (semicolon-separated, required)",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Tags to exclude (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "tag_search_text",
                    "type": "string",
                    "value": "",
                    "label": "Tag Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of related tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of related tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_search_related_tags",
            "task_name": "tasks.fred.list_series_search_related_tags",
            "description": "Get related tags for series search results",
            "label": "List Series Search Related Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_search_text",
                "tag_names",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "exclude_tag_names",
                "tag_group_id",
                "tag_search_text",
            ],
            "required": ["series_search_text", "tag_names", "limit", "return_all"],
        },
        "list_series_search_related_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_search_related_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_search_related_tags**false**(*)**true": {
            "inputs": [],
            "outputs": [],
        },
        "list_series_search_related_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_search_related_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_search_related_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_id",
                    "type": "string",
                    "value": "",
                    "label": "Series ID",
                    "placeholder": "GNPCA",
                    "helper_text": "The ID of the series",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=series&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_tags",
            "task_name": "tasks.fred.list_series_tags",
            "description": "Get tags for an economic data series",
            "label": "List Series Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_id",
                "use_date",
                "order_by",
                "sort_order",
            ],
            "required": ["series_id", "limit", "return_all"],
        },
        "list_series_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_series_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_updates**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "filter_value",
                    "type": "string",
                    "value": "all",
                    "label": "Filter Value",
                    "helper_text": "Filter by data type",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_filter_value",
                    },
                },
                {
                    "field": "start_time",
                    "type": "string",
                    "value": "",
                    "label": "Start Time",
                    "placeholder": "00:00",
                    "helper_text": "Start time for updates (format: HH:MM)",
                },
                {
                    "field": "end_time",
                    "type": "string",
                    "value": "",
                    "label": "End Time",
                    "placeholder": "23:59",
                    "helper_text": "End time for updates (format: HH:MM)",
                },
            ],
            "outputs": [
                {
                    "field": "series_ids",
                    "type": "vec<string>",
                    "helper_text": "List of series IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of series titles",
                },
                {
                    "field": "frequencies",
                    "type": "vec<string>",
                    "helper_text": "List of data frequencies",
                },
                {
                    "field": "units",
                    "type": "vec<string>",
                    "helper_text": "List of units",
                },
                {
                    "field": "seasonal_adjustments",
                    "type": "vec<string>",
                    "helper_text": "List of seasonal adjustment types",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "last_updated",
                    "type": "vec<string>",
                    "helper_text": "List of last update timestamps",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of updated series",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_updates",
            "task_name": "tasks.fred.list_series_updates",
            "description": "Get economic data series sorted by when observations were updated",
            "label": "List Series Updates",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "use_date",
                "limit",
                "return_all",
                "filter_value",
                "start_time",
                "end_time",
            ],
            "required": ["limit", "return_all"],
        },
        "list_series_updates**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_updates**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_updates**false**(*)**true": {"inputs": [], "outputs": []},
        "list_series_updates**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_updates**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_updates**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_vintagedates**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "series_id",
                    "type": "string",
                    "value": "",
                    "label": "Series ID",
                    "placeholder": "GNPCA",
                    "helper_text": "The ID of the series",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=series&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "vintage_dates",
                    "type": "vec<string>",
                    "helper_text": "List of vintage dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of vintage dates",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_series_vintagedates",
            "task_name": "tasks.fred.list_series_vintagedates",
            "description": "List dates when a series' data values were revised or released",
            "label": "List Series Vintage Dates",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "series_id",
                "use_date",
                "limit",
                "return_all",
                "sort_order",
            ],
            "required": ["series_id", "limit", "return_all"],
        },
        "list_series_vintagedates**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_series_vintagedates**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_series_vintagedates**false**(*)**true": {"inputs": [], "outputs": []},
        "list_series_vintagedates**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_series_vintagedates**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_series_vintagedates**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_sources**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "source_id",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sources_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "source_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of source IDs",
                },
                {
                    "field": "source_names",
                    "type": "vec<string>",
                    "helper_text": "List of source names",
                },
                {
                    "field": "links",
                    "type": "vec<string>",
                    "helper_text": "List of source links",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of source notes",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of sources",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_sources",
            "task_name": "tasks.fred.list_sources",
            "description": "Get all sources of economic data",
            "label": "List Sources",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
            ],
            "required": ["limit", "return_all"],
        },
        "list_sources**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_sources**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_sources**false**(*)**true": {"inputs": [], "outputs": []},
        "list_sources**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_sources**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_sources**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_source**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "source_id",
                    "type": "string",
                    "value": "",
                    "label": "Source ID",
                    "placeholder": "1",
                    "helper_text": "The ID of the source to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=source&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "int32",
                    "helper_text": "The unique identifier of the source",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "The name of the source",
                },
                {
                    "field": "link",
                    "type": "string",
                    "helper_text": "URL link to the source",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "helper_text": "Additional notes about the source",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_source",
            "task_name": "tasks.fred.get_source",
            "description": "Get a specific source of economic data",
            "label": "Get Source",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "source_id",
                "use_date",
                "limit",
                "return_all",
            ],
            "required": ["source_id", "limit", "return_all"],
        },
        "get_source**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "get_source**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "get_source**false**(*)**true": {"inputs": [], "outputs": []},
        "get_source**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_source**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_source**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_source_releases**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "source_id",
                    "type": "string",
                    "value": "",
                    "label": "Source ID",
                    "placeholder": "1",
                    "helper_text": "The ID of the source",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=source&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "release_id",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_releases_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "release_ids",
                    "type": "vec<int32>",
                    "helper_text": "List of release IDs",
                },
                {
                    "field": "release_names",
                    "type": "vec<string>",
                    "helper_text": "List of release names",
                },
                {
                    "field": "links",
                    "type": "vec<string>",
                    "helper_text": "List of release links",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of release notes",
                },
                {
                    "field": "press_releases",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if releases are press releases",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of releases",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_source_releases",
            "task_name": "tasks.fred.list_source_releases",
            "description": "Get releases for a source",
            "label": "List Source Releases",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "source_id",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
            ],
            "required": ["source_id", "limit", "return_all"],
        },
        "list_source_releases**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_source_releases**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_source_releases**false**(*)**true": {"inputs": [], "outputs": []},
        "list_source_releases**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_source_releases**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_source_releases**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Filter by tag names (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_tags",
            "task_name": "tasks.fred.list_tags",
            "description": "Get all tags, search for tags, or get tags by name",
            "label": "List Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "tag_names",
                "tag_group_id",
                "search_text",
            ],
            "required": ["limit", "return_all"],
        },
        "list_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_related_tags**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Tags to find related tags for (semicolon-separated, required)",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_count",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tags_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "desc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Tags to exclude (semicolon-separated)",
                },
                {
                    "field": "tag_group_id",
                    "type": "string",
                    "value": "freq",
                    "label": "Tag Group",
                    "helper_text": "Filter by tag group",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_tag_group_id",
                    },
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "monetary",
                    "helper_text": "Search for tags containing this text",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of related tag names",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tag group IDs",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of tag notes",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "series_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of series counts",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of related tags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_related_tags",
            "task_name": "tasks.fred.list_related_tags",
            "description": "Get related tags for one or more tags",
            "label": "List Related Tags",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "tag_names",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "exclude_tag_names",
                "tag_group_id",
                "search_text",
            ],
            "required": ["tag_names", "limit", "return_all"],
        },
        "list_related_tags**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_related_tags**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_related_tags**false**(*)**true": {"inputs": [], "outputs": []},
        "list_related_tags**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_related_tags**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_related_tags**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_tags_series**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Tag Names",
                    "placeholder": "gdp;inflation",
                    "helper_text": "Tags to get series for (semicolon-separated, required)",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter by date range",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "series_id",
                    "label": "Order By",
                    "helper_text": "Order results by attribute",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_series_order_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "asc",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "fred_sort_order",
                    },
                },
                {
                    "field": "exclude_tag_names",
                    "type": "string",
                    "value": "",
                    "label": "Exclude Tag Names",
                    "placeholder": "discontinued",
                    "helper_text": "Tags to exclude (semicolon-separated)",
                },
            ],
            "outputs": [
                {
                    "field": "series_ids",
                    "type": "vec<string>",
                    "helper_text": "List of series IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of series titles",
                },
                {
                    "field": "frequencies",
                    "type": "vec<string>",
                    "helper_text": "List of data frequencies",
                },
                {
                    "field": "units",
                    "type": "vec<string>",
                    "helper_text": "List of units",
                },
                {
                    "field": "seasonal_adjustments",
                    "type": "vec<string>",
                    "helper_text": "List of seasonal adjustment types",
                },
                {
                    "field": "popularities",
                    "type": "vec<int32>",
                    "helper_text": "List of popularity scores",
                },
                {
                    "field": "observation_starts",
                    "type": "vec<string>",
                    "helper_text": "List of observation start dates",
                },
                {
                    "field": "observation_ends",
                    "type": "vec<string>",
                    "helper_text": "List of observation end dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of series",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_tags_series",
            "task_name": "tasks.fred.list_tags_series",
            "description": "Get series matching tags",
            "label": "List Tags Series",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "tag_names",
                "use_date",
                "limit",
                "return_all",
                "order_by",
                "sort_order",
                "exclude_tag_names",
            ],
            "required": ["tag_names", "limit", "return_all"],
        },
        "list_tags_series**false**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all results (ignores limit)",
                }
            ],
            "outputs": [],
        },
        "list_tags_series**false**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "list_tags_series**false**(*)**true": {"inputs": [], "outputs": []},
        "list_tags_series**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_tags_series**true**false**(*)": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_tags_series**true**true**(*)": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact Date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date", "return_all"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        return_all: bool = False,
        aggregation_method: str = "avg",
        category_id: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        element_id: int = 0,
        end_time: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        exclude_tag_names: str = "",
        filter_value: str = "",
        filter_variable: str = "frequency",
        frequency: str = "m",
        include_observation_values: bool = False,
        include_release_dates_with_no_data: bool = False,
        limit: int = 10,
        observation_date: str = "",
        observation_end: str = "",
        observation_start: str = "",
        order_by: str = "series_id",
        output_type: str = "1",
        release_id: str = "",
        search_text: str = "",
        search_type: str = "full_text",
        series_id: str = "",
        series_search_text: str = "",
        sort_order: str = "asc",
        source_id: str = "",
        start_time: str = "",
        tag_group_id: str = "freq",
        tag_names: str = "",
        tag_search_text: str = "",
        units: str = "lin",
        vintage_dates: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date
        params["return_all"] = return_all

        super().__init__(
            node_type="integration_fred",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if category_id is not None:
            self.inputs["category_id"] = category_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if filter_variable is not None:
            self.inputs["filter_variable"] = filter_variable
        if filter_value is not None:
            self.inputs["filter_value"] = filter_value
        if tag_names is not None:
            self.inputs["tag_names"] = tag_names
        if exclude_tag_names is not None:
            self.inputs["exclude_tag_names"] = exclude_tag_names
        if tag_group_id is not None:
            self.inputs["tag_group_id"] = tag_group_id
        if search_text is not None:
            self.inputs["search_text"] = search_text
        if release_id is not None:
            self.inputs["release_id"] = release_id
        if include_release_dates_with_no_data is not None:
            self.inputs["include_release_dates_with_no_data"] = (
                include_release_dates_with_no_data
            )
        if element_id is not None:
            self.inputs["element_id"] = element_id
        if include_observation_values is not None:
            self.inputs["include_observation_values"] = include_observation_values
        if observation_date is not None:
            self.inputs["observation_date"] = observation_date
        if series_id is not None:
            self.inputs["series_id"] = series_id
        if observation_start is not None:
            self.inputs["observation_start"] = observation_start
        if observation_end is not None:
            self.inputs["observation_end"] = observation_end
        if units is not None:
            self.inputs["units"] = units
        if frequency is not None:
            self.inputs["frequency"] = frequency
        if aggregation_method is not None:
            self.inputs["aggregation_method"] = aggregation_method
        if output_type is not None:
            self.inputs["output_type"] = output_type
        if vintage_dates is not None:
            self.inputs["vintage_dates"] = vintage_dates
        if search_type is not None:
            self.inputs["search_type"] = search_type
        if series_search_text is not None:
            self.inputs["series_search_text"] = series_search_text
        if tag_search_text is not None:
            self.inputs["tag_search_text"] = tag_search_text
        if start_time is not None:
            self.inputs["start_time"] = start_time
        if end_time is not None:
            self.inputs["end_time"] = end_time
        if source_id is not None:
            self.inputs["source_id"] = source_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationFredNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
