"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_jira")
class IntegrationJiraNode(Node):
    """
    Jira

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: The integration input
    ### When action = 'get_issues'
        text: Search in all text fields
        query: The query to filter issues
        affected_version: Filter by affected version
        assignee_name: Account Name of the user to assign the issue to
        comment: Search in issue comments
        comment_exact: Match comment exactly
        component: Filter by issue component
        created: Issue creation (YYYY-MM-DD)
        description: Detailed description of the issue
        description_exact: Match description exactly
        due: Due (YYYY-MM-DD)
        fix_version: Filter by fix version
        issue_summary: Search by issue summary
        issue_type: Type of issue (e.g. Task, Bug, Story)
        labels: Filter by issue labels
        project: The name of the project
        reporter_name: Account Name of the user who reported the issue
        resolution: Filter by resolution status
        resolved: Resolution (YYYY-MM-DD)
        site: The name of the Jira site
        status: The status of the issue (e.g. Open, Closed, In Progress)
        summary_exact: Match summary exactly
        text_exact: Match text exactly across fields
        updated: Last update (YYYY-MM-DD)
        use_date: Toggle to use dates
    ### When action = 'read_user'
        account_id: The account ID of the user to retrieve
        expand: Additional information to include
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'remove_user'
        account_id: The account ID of the user to retrieve
        site: The name of the Jira site
    ### When action = 'create_issue'
        assignee_name: Account Name of the user to assign the issue to
        description: Detailed description of the issue
        issue_type: Type of issue (e.g. Task, Bug, Story)
        parent_issue_key: Parent Issue Key (for subtasks)
        project: The name of the project
        site: The name of the Jira site
        summary: A brief title or summary of the issue
    ### When action = 'read_attachment'
        attachment_id: The ID of the attachment to retrieve
        download: Whether to download the attachment content
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'remove_attachment'
        attachment_id: The ID of the attachment to retrieve
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'add_issue_comment'
        comment: Search in issue comments
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
        visibility_role: Restrict comment visibility to a project role (leave empty for public comment)
    ### When action = 'update_comment'
        comment: Search in issue comments
        comment_id: The ID of the comment to remove
        expand: Additional information to include
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
        use_wiki_markup: Enable wiki markup parsing
    ### When action = 'remove_comment'
        comment_id: The ID of the comment to remove
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'get_issues' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'delete_issue'
        delete_subtasks: Whether to delete subtasks along with the issue
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'get_attachments'
        download: Whether to download the attachment content
        issue_key: The key of the issue to get changelog for
        limit: Maximum number of changelog entries to return
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'create_user'
        email_address: Email address of the user
        notification: If enabled, sends an invitation email to the user
        site: The name of the Jira site
    ### When action = 'get_issues' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'status_transitions'
        expand: Additional information to include
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
        skip_remote_only_condition: Include transitions with remote-only conditions
        transition_id: ID of specific transition to get
    ### When action = 'add_attachment'
        file: File to attach to the issue
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'notify_issue'
        group_names: Comma-separated list of group names to notify
        html_body: HTML body of the notification
        issue_key: The key of the issue to get changelog for
        notify_assignee: Send notification to the issue assignee (note: Jira prevents self-notification, so this will fail if you are the assignee)
        notify_reporter: Send notification to the issue reporter (note: Jira prevents self-notification, so this will fail if you are the reporter)
        notify_voters: Send notification to issue voters (note: Jira prevents self-notification, so this will fail if you are the only voter)
        notify_watchers: Send notification to issue watchers (note: Jira prevents self-notification, so this will fail if you are the only watcher)
        project: The name of the project
        site: The name of the Jira site
        subject: Subject of the email notification
        text_body: Plain text body of the notification
        user_account_ids: Comma-separated list of user account IDs to notify
    ### When action = 'changelog'
        issue_key: The key of the issue to get changelog for
        limit: Maximum number of changelog entries to return
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'update_issue'
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
        update_assignee_name: Account Name of the user to assign the issue to
        update_description: The new description for the issue
        update_issue_type: Type of issue (e.g. Task, Bug, Story)
        update_summary: The new summary for the issue
    ### When action = 'read_issue'
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'read_issue_comments'
        issue_key: The key of the issue to get changelog for
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'get_issues' and use_date = False
        num_messages: Specify the number of issues to fetch
    ### When action = 'get_users'
        project: The name of the project
        site: The name of the Jira site
    ### When action = 'get_issues' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'create_user'
        account_id: The account ID of the user
        active: Whether the user is active
        display_name: The display name from the user's Atlassian account
        email_address: The email address of the user
        raw_data: The raw response data from Jira API
        self: The API URL for the user
    ### When action = 'read_user'
        account_id: The account ID of the user
        account_type: The account type of the user
        active: Whether the user is active
        application_roles: The application roles of the user (when expanded)
        display_name: The display name of the user
        email_address: The email address of the user
        groups: The groups the user belongs to (when expanded)
        locale: The locale of the user
        raw_data: The raw response data from Jira API
        timezone: The timezone of the user
    ### When action = 'get_users'
        account_id: The account IDs of the users in the project
        active: The active status of the users in the project
        display_name: The display names of the users in the project
        email: The email addresses of the users in the project
        raw_data: The raw response data from Jira API
    ### When action = 'remove_user'
        account_id: The account ID of the removed user
        raw_data: The raw response data from Jira API
    ### When action = 'read_issue'
        assignee_email: The email address of the assignees
        assignee_id: The account ID of the assignees
        assignee_name: The display name of the assignees
        browser_url: The URL to view the issues in browser
        comments: The comments of the issues
        created_date: The date and time when the issues was created
        description: The description of the issues
        issue_attachments: The attachments of the issues
        issue_id: The unique identifier of the issues
        issue_key: The key of the issues (e.g. PROJ-123)
        issue_type: The type of the issues
        raw_data: The raw response data from Jira API
        reporter_email: The email address of the reporters
        reporter_id: The account ID of the reporters
        reporter_name: The display name of the reporters
        status: The current status of the issues
        summary: The summary/title of the issues
        updated_date: The date and time when the issues was last updated
    ### When action = 'get_issues'
        assignee_emails: The email address of the assignee
        assignee_ids: The account ID of the assignee
        assignee_names: The display name of the assignee
        browser_urls: The URL to view the issue in browser
        comments: The comments of the issue
        created_dates: The date and time when the issue was created
        descriptions: The description of the issue
        issue_attachments: The attachments of the issue
        issue_ids: The unique identifier of the issue
        issue_keys: The key of the issue (e.g. PROJ-123)
        issue_types: The type of the issue
        raw_data: The raw response data from Jira API
        reporter_emails: The email address of the reporter
        reporter_ids: The account ID of the reporter
        reporter_names: The display name of the reporter
        statuses: The current status of the issue
        summaries: The summary/title of the issue
        updated_dates: The date and time when the issue was last updated
    ### When action = 'read_attachment'
        attachment_id: The ID of the attachment
        author: The author of the attachment
        created_date: The creation date of the attachment
        file: The downloaded file content (when download=true)
        filename: The filename of the attachment
        mime_type: The MIME type of the attachment
        raw_data: The raw response data from Jira API
        size: The size of the attachment
    ### When action = 'remove_attachment'
        attachment_id: The ID of the removed attachment
        message: Success message
        raw_data: The raw response data from Jira API
    ### When action = 'add_attachment'
        attachment_ids: List of attachment IDs
        attachment_names: List of attachment names
        attachment_sizes: List of attachment sizes
        attachment_urls: List of attachment URLs
        issue_key: The key of the issue
        message: Success message
        raw_data: The raw response data from Jira API
    ### When action = 'get_attachments'
        attachment_ids: List of attachment IDs
        attachment_names: List of attachment names
        attachment_sizes: List of attachment sizes
        attachment_urls: List of attachment URLs
        authors: List of attachment authors
        created_dates: List of attachment creation dates
        files: List of downloaded files (when download=true)
        issue_key: The key of the issue
        mime_types: List of attachment MIME types
        raw_data: The raw response data from Jira API
        total: Total number of attachments
    ### When action = 'update_comment'
        author: The author of the comment
        comment_id: The ID of the updated comment
        comment_text: The updated comment text
        created_date: The creation date of the comment
        issue_key: The key of the issue
        message: Success message
        raw_data: The raw response data from Jira API
        updated_date: The update date of the comment
    ### When action = 'read_issue_comments'
        author_email: List of comment author email addresses
        author_id: List of comment author account IDs
        author_name: List of comment author display names
        body: List of comment bodies
        comment_id: List of comment IDs
        created_date: List of comment creation dates
        raw_data: The raw response data from Jira API
        total: Total number of comments
        updated_date: List of comment update dates
    ### When action = 'changelog'
        author_emails: List of change author email addresses
        author_ids: List of change author account IDs
        author_names: List of change author display names
        change_descriptions: List of change descriptions
        change_ids: List of change IDs
        changelog_entries: List of complete changelog entries (for detailed access)
        created_dates: List of change creation dates
        issue_key: The key of the issue
        raw_data: The raw response data from Jira API
        total: Total number of changelog entries
    ### When action = 'add_issue_comment'
        comment_id: ID of the newly created comment
        created_date: Creation date of the comment
        message: Success message
        raw_data: The raw response data from Jira API
        updated_date: Last update date of the comment
    ### When action = 'remove_comment'
        comment_id: The ID of the removed comment
        issue_key: The key of the issue
        message: Success message
        raw_data: The raw response data from Jira API
    ### When action = 'delete_issue'
        deleted_subtasks: Whether subtasks were deleted
        issue_key: The key of the deleted issue
        message: Success message
        raw_data: The raw response data from Jira API
    ### When action = 'create_issue'
        issue_id: The ID of the created issue
        issue_key: The key of the created issue
        raw_data: The raw response data from Jira API
        url: The URL of the created issue
    ### When action = 'update_issue'
        issue_key: The key of the updated issue
        message: Success message confirming the update
        raw_data: The raw response data from Jira API
    ### When action = 'notify_issue'
        issue_key: The key of the issue
        message: Success message
        raw_data: The raw response data from Jira API
    ### When action = 'status_transitions'
        issue_key: The key of the issue
        raw_data: The raw response data from Jira API
        to_status_ids: List of target status IDs
        to_status_names: List of target status names
        total: Total number of transitions
        transition_ids: List of transition IDs
        transition_names: List of transition names
        transitions: List of complete transition objects (for detailed access)
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Jira>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "changelog**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to get changelog for",
                },
                {
                    "field": "limit",
                    "label": "Limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of changelog entries to return",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "changelog_entries",
                    "type": "vec<string>",
                    "helper_text": "List of complete changelog entries (for detailed access)",
                },
                {
                    "field": "change_ids",
                    "type": "vec<string>",
                    "helper_text": "List of change IDs",
                },
                {
                    "field": "change_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of change descriptions",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of change creation dates",
                },
                {
                    "field": "author_ids",
                    "type": "vec<string>",
                    "helper_text": "List of change author account IDs",
                },
                {
                    "field": "author_names",
                    "type": "vec<string>",
                    "helper_text": "List of change author display names",
                },
                {
                    "field": "author_emails",
                    "type": "vec<string>",
                    "helper_text": "List of change author email addresses",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of changelog entries",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "changelog",
            "task_name": "tasks.jira.changelog",
            "description": "Get multiple changelog entries",
            "label": "List Issue Changelog",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "limit",
            ],
            "required": ["site", "project", "issue_key", "limit"],
        },
        "create_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "parent_issue_key",
                    "label": "Parent Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "Parent Issue Key (for subtasks)",
                },
                {
                    "field": "summary",
                    "label": "Summary",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue summary",
                    "helper_text": "A brief title or summary of the issue",
                },
                {
                    "field": "description",
                    "label": "Description",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter detailed description",
                    "helper_text": "Detailed description of the issue",
                },
                {
                    "field": "issue_type",
                    "label": "Issue Type",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select issue type",
                    "helper_text": "Type of issue (e.g. Task, Bug, Story)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_type&project={inputs.project}&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignee_name",
                    "label": "Assignee Name",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select assignee",
                    "helper_text": "Account Name of the user to assign the issue to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee_name&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "The ID of the created issue",
                },
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the created issue",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "The URL of the created issue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_issue",
            "task_name": "tasks.jira.create_issue",
            "description": "Create a issue",
            "label": "Create Issue",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_type",
                "assignee_name",
                "parent_issue_key",
                "summary",
                "description",
            ],
            "required": ["site", "project", "issue_type", "summary"],
        },
        "update_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to update (e.g. PROJ-123)",
                },
                {
                    "field": "update_summary",
                    "label": "Summary",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter new summary",
                    "helper_text": "The new summary for the issue",
                },
                {
                    "field": "update_description",
                    "label": "Description",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter new description",
                    "helper_text": "The new description for the issue",
                },
                {
                    "field": "update_issue_type",
                    "label": "Issue Type",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select issue type",
                    "helper_text": "Type of issue (e.g. Task, Bug, Story)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_type&project={inputs.project}&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_assignee_name",
                    "label": "Assignee Name",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select assignee",
                    "helper_text": "Account Name of the user to assign the issue to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee_name&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the updated issue",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message confirming the update",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_issue",
            "task_name": "tasks.jira.update_issue",
            "description": "Update an existing Jira issue",
            "label": "Update Issue",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "update_issue_type",
                "update_assignee_name",
                "issue_key",
                "update_summary",
                "update_description",
            ],
            "required": ["site", "project", "issue_key"],
        },
        "read_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to retrieve (e.g. PROJ-123)",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the issues",
                },
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issues (e.g. PROJ-123)",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "The summary/title of the issues",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The description of the issues",
                },
                {
                    "field": "comments",
                    "type": "vec<string>",
                    "helper_text": "The comments of the issues",
                },
                {
                    "field": "issue_attachments",
                    "type": "vec<file>",
                    "helper_text": "The attachments of the issues",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "helper_text": "The date and time when the issues was created",
                },
                {
                    "field": "updated_date",
                    "type": "string",
                    "helper_text": "The date and time when the issues was last updated",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The current status of the issues",
                },
                {
                    "field": "browser_url",
                    "type": "string",
                    "helper_text": "The URL to view the issues in browser",
                },
                {
                    "field": "issue_type",
                    "type": "string",
                    "helper_text": "The type of the issues",
                },
                {
                    "field": "assignee_id",
                    "type": "string",
                    "helper_text": "The account ID of the assignees",
                },
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "The display name of the assignees",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "The email address of the assignees",
                },
                {
                    "field": "reporter_id",
                    "type": "string",
                    "helper_text": "The account ID of the reporters",
                },
                {
                    "field": "reporter_name",
                    "type": "string",
                    "helper_text": "The display name of the reporters",
                },
                {
                    "field": "reporter_email",
                    "type": "string",
                    "helper_text": "The email address of the reporters",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_issue",
            "task_name": "tasks.jira.read_issue",
            "description": "Read details of a specific issue",
            "label": "Get Issue",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
            ],
            "required": ["site", "project", "issue_key"],
        },
        "get_issues**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_type",
                    "label": "Issue Type",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select issue type",
                    "helper_text": "Type of issue (e.g. Task, Bug, Story)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_type&project={inputs.project}&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignee_name",
                    "label": "Assignee Name",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select assignee",
                    "helper_text": "Account Name of the user to assign the issue to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee_name&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "Open",
                    "helper_text": "The status of the issue (e.g. Open, Closed, In Progress)",
                },
                {
                    "field": "reporter_name",
                    "label": "Reporter Name",
                    "type": "string",
                    "value": "",
                    "placeholder": "Select reporter",
                    "helper_text": "Account Name of the user who reported the issue",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "Query",
                    "helper_text": "The query to filter issues",
                },
                {
                    "field": "issue_summary",
                    "type": "string",
                    "value": "",
                    "label": "Summary",
                    "placeholder": "Summary",
                    "helper_text": "Search by issue summary",
                },
                {
                    "field": "summary_exact",
                    "type": "string",
                    "value": "",
                    "label": "Summary Exact",
                    "placeholder": "Summary Exact",
                    "helper_text": "Match summary exactly",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Description",
                    "helper_text": "Search in issue description",
                },
                {
                    "field": "description_exact",
                    "type": "string",
                    "value": "",
                    "label": "Description Exact",
                    "placeholder": "Description Exact",
                    "helper_text": "Match description exactly",
                },
                {
                    "field": "comment",
                    "type": "string",
                    "value": "",
                    "label": "Comment",
                    "placeholder": "Comment",
                    "helper_text": "Search in issue comments",
                },
                {
                    "field": "comment_exact",
                    "type": "string",
                    "value": "",
                    "label": "Comment Exact",
                    "placeholder": "Comment Exact",
                    "helper_text": "Match comment exactly",
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Text",
                    "placeholder": "Text",
                    "helper_text": "Search in all text fields",
                },
                {
                    "field": "text_exact",
                    "type": "string",
                    "value": "",
                    "label": "Text Exact",
                    "placeholder": "Text Exact",
                    "helper_text": "Match text exactly across fields",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "label": "Labels",
                    "placeholder": "Labels",
                    "helper_text": "Filter by issue labels",
                },
                {
                    "field": "fix_version",
                    "type": "string",
                    "value": "",
                    "label": "Fix Version",
                    "placeholder": "Fix Version",
                    "helper_text": "Filter by fix version",
                },
                {
                    "field": "affected_version",
                    "type": "string",
                    "value": "",
                    "label": "Affected Version",
                    "placeholder": "Affected Version",
                    "helper_text": "Filter by affected version",
                },
                {
                    "field": "component",
                    "type": "string",
                    "value": "",
                    "label": "Component",
                    "placeholder": "Component",
                    "helper_text": "Filter by issue component",
                },
                {
                    "field": "resolution",
                    "type": "string",
                    "value": "",
                    "label": "Resolution",
                    "placeholder": "Resolution",
                    "helper_text": "Filter by resolution status",
                },
                {
                    "field": "created",
                    "type": "string",
                    "value": "",
                    "label": "Created",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "Issue creation (YYYY-MM-DD)",
                },
                {
                    "field": "updated",
                    "type": "string",
                    "value": "",
                    "label": "Updated",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "Last update (YYYY-MM-DD)",
                },
                {
                    "field": "resolved",
                    "type": "string",
                    "value": "",
                    "label": "Resolved",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "Resolution (YYYY-MM-DD)",
                },
                {
                    "field": "due",
                    "type": "string",
                    "value": "",
                    "label": "Due",
                    "placeholder": "YYYY-MM-DD",
                    "helper_text": "Due (YYYY-MM-DD)",
                },
            ],
            "outputs": [
                {
                    "field": "issue_ids",
                    "type": "vec<string>",
                    "helper_text": "The unique identifier of the issue",
                },
                {
                    "field": "issue_keys",
                    "type": "vec<string>",
                    "helper_text": "The key of the issue (e.g. PROJ-123)",
                },
                {
                    "field": "summaries",
                    "type": "vec<string>",
                    "helper_text": "The summary/title of the issue",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "The description of the issue",
                },
                {
                    "field": "comments",
                    "type": "vec<vec<string>>",
                    "helper_text": "The comments of the issue",
                },
                {
                    "field": "issue_attachments",
                    "type": "vec<file>",
                    "helper_text": "The attachments of the issue",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "The date and time when the issue was created",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "The date and time when the issue was last updated",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "The current status of the issue",
                },
                {
                    "field": "browser_urls",
                    "type": "vec<string>",
                    "helper_text": "The URL to view the issue in browser",
                },
                {
                    "field": "issue_types",
                    "type": "vec<string>",
                    "helper_text": "The type of the issue",
                },
                {
                    "field": "assignee_ids",
                    "type": "vec<string>",
                    "helper_text": "The account ID of the assignee",
                },
                {
                    "field": "assignee_names",
                    "type": "vec<string>",
                    "helper_text": "The display name of the assignee",
                },
                {
                    "field": "assignee_emails",
                    "type": "vec<string>",
                    "helper_text": "The email address of the assignee",
                },
                {
                    "field": "reporter_ids",
                    "type": "vec<string>",
                    "helper_text": "The account ID of the reporter",
                },
                {
                    "field": "reporter_names",
                    "type": "vec<string>",
                    "helper_text": "The display name of the reporter",
                },
                {
                    "field": "reporter_emails",
                    "type": "vec<string>",
                    "helper_text": "The email address of the reporter",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_issues",
            "task_name": "tasks.jira.get_issues",
            "description": "Get multiple issues",
            "label": "List Issues",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_type",
                "status",
                "assignee_name",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "reporter_name",
                "query",
                "issue_summary",
                "summary_exact",
                "description",
                "description_exact",
                "comment",
                "comment_exact",
                "text",
                "text_exact",
                "labels",
                "fix_version",
                "affected_version",
                "component",
                "resolution",
                "created",
                "updated",
                "resolved",
                "due",
            ],
            "required": ["site", "project"],
        },
        "get_issues**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Issues",
                    "helper_text": "Specify the number of issues to fetch",
                }
            ],
            "outputs": [],
        },
        "get_issues**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_issues**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "label": "Date Range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                }
            ],
            "outputs": [],
        },
        "get_issues**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "label": "Exact date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                }
            ],
            "outputs": [],
        },
        "delete_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to delete",
                },
                {
                    "field": "delete_subtasks",
                    "label": "Delete Subtasks",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to delete subtasks along with the issue",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the deleted issue",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "deleted_subtasks",
                    "type": "bool",
                    "helper_text": "Whether subtasks were deleted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_issue",
            "task_name": "tasks.jira.delete_issue",
            "description": "Delete an issue",
            "label": "Delete Issue",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "delete_subtasks",
            ],
            "required": ["site", "project", "issue_key"],
        },
        "notify_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to notify about",
                },
                {
                    "field": "text_body",
                    "label": "Text Body",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter notification text",
                    "helper_text": "Plain text body of the notification",
                },
                {
                    "field": "html_body",
                    "label": "HTML Body",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter HTML content",
                    "helper_text": "HTML body of the notification",
                },
                {
                    "field": "subject",
                    "label": "Subject",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter subject",
                    "helper_text": "Subject of the email notification",
                },
                {
                    "field": "notify_reporter",
                    "label": "Notify Reporter",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Send notification to the issue reporter (note: Jira prevents self-notification, so this will fail if you are the reporter)",
                },
                {
                    "field": "notify_assignee",
                    "label": "Notify Assignee",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Send notification to the issue assignee (note: Jira prevents self-notification, so this will fail if you are the assignee)",
                },
                {
                    "field": "notify_watchers",
                    "label": "Notify Watchers",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Send notification to issue watchers (note: Jira prevents self-notification, so this will fail if you are the only watcher)",
                },
                {
                    "field": "notify_voters",
                    "label": "Notify Voters",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Send notification to issue voters (note: Jira prevents self-notification, so this will fail if you are the only voter)",
                },
                {
                    "field": "user_account_ids",
                    "label": "User Account IDs",
                    "type": "string",
                    "value": "",
                    "placeholder": "accountId1,accountId2",
                    "helper_text": "Comma-separated list of user account IDs to notify",
                },
                {
                    "field": "group_names",
                    "label": "Group Names",
                    "type": "string",
                    "value": "",
                    "placeholder": "group1,group2",
                    "helper_text": "Comma-separated list of group names to notify",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "notify_issue",
            "task_name": "tasks.jira.notify_issue",
            "description": "Create an email notification for an issue",
            "label": "Send Notification About Issue",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "subject",
                "text_body",
                "html_body",
                "notify_reporter",
                "notify_assignee",
                "notify_watchers",
                "notify_voters",
                "user_account_ids",
                "group_names",
            ],
            "required": ["site", "project", "issue_key"],
        },
        "status_transitions**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to get transitions for",
                },
                {
                    "field": "transition_id",
                    "label": "Transition ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter transition ID",
                    "helper_text": "ID of specific transition to get",
                },
                {
                    "field": "expand",
                    "label": "Expand",
                    "type": "string",
                    "value": "",
                    "placeholder": "transitions.fields",
                    "helper_text": "Additional information to include",
                },
                {
                    "field": "skip_remote_only_condition",
                    "label": "Skip Remote Only",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include transitions with remote-only conditions",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "transitions",
                    "type": "vec<string>",
                    "helper_text": "List of complete transition objects (for detailed access)",
                },
                {
                    "field": "transition_names",
                    "type": "vec<string>",
                    "helper_text": "List of transition names",
                },
                {
                    "field": "transition_ids",
                    "type": "vec<string>",
                    "helper_text": "List of transition IDs",
                },
                {
                    "field": "to_status_names",
                    "type": "vec<string>",
                    "helper_text": "List of target status names",
                },
                {
                    "field": "to_status_ids",
                    "type": "vec<string>",
                    "helper_text": "List of target status IDs",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of transitions",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "status_transitions",
            "task_name": "tasks.jira.status_transitions",
            "description": "Get multiple issue status transitions",
            "label": "List Status Transitions",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "transition_id",
                "expand",
                "skip_remote_only_condition",
            ],
            "required": ["site", "project", "issue_key"],
        },
        "add_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to add attachment to",
                },
                {
                    "field": "file",
                    "label": "File",
                    "type": "file",
                    "value": "",
                    "helper_text": "File to attach to the issue",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of attachment IDs",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names",
                },
                {
                    "field": "attachment_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of attachment sizes",
                },
                {
                    "field": "attachment_urls",
                    "type": "vec<string>",
                    "helper_text": "List of attachment URLs",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_attachment",
            "task_name": "tasks.jira.add_attachment",
            "description": "Add attachment to issue",
            "label": "Add Attachment",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "file",
            ],
            "required": ["site", "project", "issue_key", "file"],
        },
        "read_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "label": "Attachment ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter attachment ID",
                    "helper_text": "The ID of the attachment to retrieve",
                },
                {
                    "field": "download",
                    "label": "Download",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to download the attachment content",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "The ID of the attachment",
                },
                {
                    "field": "filename",
                    "type": "string",
                    "helper_text": "The filename of the attachment",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "The size of the attachment",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "The MIME type of the attachment",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "The author of the attachment",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "helper_text": "The creation date of the attachment",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "The downloaded file content (when download=true)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_attachment",
            "task_name": "tasks.jira.read_attachment",
            "description": "Read details of a specific attachment",
            "label": "Get Attachment",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "attachment_id",
                "download",
            ],
            "required": ["site", "attachment_id"],
        },
        "get_attachments**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to get attachments for",
                },
                {
                    "field": "limit",
                    "label": "Limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of attachments to return",
                },
                {
                    "field": "download",
                    "label": "Download",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to download attachment contents",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of attachment IDs",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names",
                },
                {
                    "field": "attachment_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of attachment sizes",
                },
                {
                    "field": "attachment_urls",
                    "type": "vec<string>",
                    "helper_text": "List of attachment URLs",
                },
                {
                    "field": "authors",
                    "type": "vec<string>",
                    "helper_text": "List of attachment authors",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of attachment creation dates",
                },
                {
                    "field": "mime_types",
                    "type": "vec<string>",
                    "helper_text": "List of attachment MIME types",
                },
                {
                    "field": "files",
                    "type": "vec<file>",
                    "helper_text": "List of downloaded files (when download=true)",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of attachments",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_attachments",
            "task_name": "tasks.jira.get_attachments",
            "description": "Get multiple attachments",
            "label": "List Attachments",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "limit",
                "download",
            ],
            "required": ["site", "project", "issue_key", "limit"],
        },
        "remove_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "label": "Attachment ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter attachment ID",
                    "helper_text": "The ID of the attachment to remove",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "The ID of the removed attachment",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "remove_attachment",
            "task_name": "tasks.jira.remove_attachment",
            "description": "Remove an attachment",
            "label": "Remove Attachment",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "attachment_id",
            ],
            "required": ["site", "attachment_id"],
        },
        "add_issue_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to add comment to (e.g. PROJ-123)",
                },
                {
                    "field": "comment",
                    "label": "Comment",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter your comment",
                    "helper_text": "The comment text to add",
                },
                {
                    "field": "visibility_role",
                    "label": "Visibility Role",
                    "type": "string",
                    "value": "",
                    "placeholder": "Public (No Restriction)",
                    "helper_text": "Restrict comment visibility to a project role (leave empty for public comment)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_role&site={inputs.site}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "label": "Comment Id",
                    "type": "string",
                    "helper_text": "ID of the newly created comment",
                },
                {
                    "field": "created_date",
                    "label": "Created Dates",
                    "type": "timestamp",
                    "helper_text": "Creation date of the comment",
                },
                {
                    "field": "updated_date",
                    "type": "timestamp",
                    "helper_text": "Last update date of the comment",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_issue_comment",
            "task_name": "tasks.jira.add_issue_comment",
            "description": "Add a comment to a Jira issue",
            "label": "Add Issue Comment",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "comment",
                "visibility_role",
            ],
            "required": ["site", "project", "issue_key", "comment"],
        },
        "read_issue_comments**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue to get comments for (e.g. PROJ-123)",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "vec<string>",
                    "helper_text": "List of comment IDs",
                },
                {
                    "field": "body",
                    "type": "vec<string>",
                    "helper_text": "List of comment bodies",
                },
                {
                    "field": "created_date",
                    "type": "vec<timestamp>",
                    "helper_text": "List of comment creation dates",
                },
                {
                    "field": "updated_date",
                    "type": "vec<timestamp>",
                    "helper_text": "List of comment update dates",
                },
                {
                    "field": "author_id",
                    "type": "vec<string>",
                    "helper_text": "List of comment author account IDs",
                },
                {
                    "field": "author_email",
                    "type": "vec<string>",
                    "helper_text": "List of comment author email addresses",
                },
                {
                    "field": "author_name",
                    "type": "vec<string>",
                    "helper_text": "List of comment author display names",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of comments",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_issue_comments",
            "task_name": "tasks.jira.read_issue_comments",
            "description": "Get multiple comments for an issue",
            "label": "List Issue Comments",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
            ],
            "required": ["site", "project", "issue_key"],
        },
        "remove_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "comment_id",
                    "label": "Comment ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter comment ID",
                    "helper_text": "The ID of the comment to remove",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The ID of the removed comment",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "remove_comment",
            "task_name": "tasks.jira.remove_comment",
            "description": "Remove a comment",
            "label": "Remove Comment",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "comment_id",
            ],
            "required": ["site", "project", "issue_key", "comment_id"],
        },
        "update_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_key",
                    "label": "Issue Key",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter issue key (e.g. PROJ-123)",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "comment_id",
                    "label": "Comment ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter comment ID",
                    "helper_text": "The ID of the comment to update",
                },
                {
                    "field": "comment",
                    "label": "Comment",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter updated comment text",
                    "helper_text": "The new comment text",
                },
                {
                    "field": "expand",
                    "label": "Expand",
                    "type": "string",
                    "value": "",
                    "placeholder": "renderedBody",
                    "helper_text": "Additional information to include",
                },
                {
                    "field": "use_wiki_markup",
                    "label": "Use Wiki Markup",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Enable wiki markup parsing",
                },
            ],
            "outputs": [
                {
                    "field": "issue_key",
                    "type": "string",
                    "helper_text": "The key of the issue",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "The ID of the updated comment",
                },
                {
                    "field": "created_date",
                    "type": "timestamp",
                    "helper_text": "The creation date of the comment",
                },
                {
                    "field": "updated_date",
                    "type": "timestamp",
                    "helper_text": "The update date of the comment",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "The author of the comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "The updated comment text",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_comment",
            "task_name": "tasks.jira.update_comment",
            "description": "Update a comment",
            "label": "Update Comment",
            "ui_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "issue_key",
                "comment_id",
                "comment",
                "expand",
                "use_wiki_markup",
            ],
            "required": ["site", "project", "issue_key", "comment_id", "comment"],
        },
        "create_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "email_address",
                    "label": "Email Address",
                    "type": "string",
                    "value": "",
                    "placeholder": "user@example.com",
                    "helper_text": "Email address of the user",
                },
                {
                    "field": "notification",
                    "label": "Send Notification",
                    "type": "bool",
                    "value": True,
                    "helper_text": "If enabled, sends an invitation email to the user",
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "The account ID of the user",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "The email address of the user",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name from the user's Atlassian account",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether the user is active",
                },
                {
                    "field": "self",
                    "type": "string",
                    "helper_text": "The API URL for the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_user",
            "task_name": "tasks.jira.create_user",
            "description": "Create a user in Jira",
            "label": "Create User",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "email_address",
                "notification",
            ],
            "required": ["site", "email_address"],
        },
        "read_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "account_id",
                    "label": "Account ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter account ID",
                    "helper_text": "The account ID of the user to retrieve",
                },
                {
                    "field": "expand",
                    "label": "Expand",
                    "type": "string",
                    "value": "",
                    "placeholder": "groups,applicationRoles",
                    "helper_text": "Additional user information to include (comma-separated)",
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "The account ID of the user",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "The email address of the user",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The display name of the user",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether the user is active",
                },
                {
                    "field": "account_type",
                    "type": "string",
                    "helper_text": "The account type of the user",
                },
                {
                    "field": "timezone",
                    "type": "string",
                    "helper_text": "The timezone of the user",
                },
                {
                    "field": "locale",
                    "type": "string",
                    "helper_text": "The locale of the user",
                },
                {
                    "field": "groups",
                    "type": "vec<string>",
                    "helper_text": "The groups the user belongs to (when expanded)",
                },
                {
                    "field": "application_roles",
                    "type": "vec<string>",
                    "helper_text": "The application roles of the user (when expanded)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_user",
            "task_name": "tasks.jira.read_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "inputs_sort_order": [
                "integration",
                "action",
                "site",
                "project",
                "account_id",
                "expand",
            ],
            "required": ["site", "account_id"],
        },
        "get_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "Project name",
                    "helper_text": "The name of the project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&site={inputs.site}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "vec<string>",
                    "helper_text": "The account IDs of the users in the project",
                },
                {
                    "field": "email",
                    "type": "vec<string>",
                    "helper_text": "The email addresses of the users in the project",
                },
                {
                    "field": "display_name",
                    "type": "vec<string>",
                    "helper_text": "The display names of the users in the project",
                },
                {
                    "field": "active",
                    "type": "vec<bool>",
                    "helper_text": "The active status of the users in the project",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_users",
            "task_name": "tasks.jira.get_users",
            "description": "Get multiple users from a project",
            "label": "List Users",
            "inputs_sort_order": ["integration", "action", "site", "project"],
            "required": ["site", "project"],
        },
        "remove_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "site",
                    "type": "string",
                    "value": "",
                    "label": "Site",
                    "placeholder": "Vectorshift",
                    "helper_text": "The name of the Jira site",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=site_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "account_id",
                    "label": "Account ID",
                    "type": "string",
                    "value": "",
                    "placeholder": "Enter account ID",
                    "helper_text": "The account ID of the user to remove from Jira. NOTE: User must not have any reported or assigned issues. Manually reassign/unassign issues via Jira's admin interface before deletion.",
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "The account ID of the removed user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Jira API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "remove_user",
            "task_name": "tasks.jira.remove_user",
            "description": "Remove a user account from Jira",
            "label": "Remove User",
            "inputs_sort_order": ["integration", "action", "site", "account_id"],
            "required": ["site", "account_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        text: str = "",
        query: str = "",
        account_id: str = "",
        affected_version: str = "",
        assignee_name: str = "",
        attachment_id: str = "",
        comment: str = "",
        comment_exact: str = "",
        comment_id: str = "",
        component: str = "",
        created: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        delete_subtasks: bool = False,
        description: str = "",
        description_exact: str = "",
        download: bool = False,
        due: str = "",
        email_address: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        expand: str = "",
        file: str = "",
        fix_version: str = "",
        group_names: str = "",
        html_body: str = "",
        issue_key: str = "",
        issue_summary: str = "",
        issue_type: str = "",
        labels: str = "",
        limit: int = 10,
        notification: bool = True,
        notify_assignee: bool = False,
        notify_reporter: bool = False,
        notify_voters: bool = False,
        notify_watchers: bool = False,
        num_messages: int = 10,
        parent_issue_key: str = "",
        project: str = "",
        reporter_name: str = "",
        resolution: str = "",
        resolved: str = "",
        site: str = "",
        skip_remote_only_condition: bool = False,
        status: str = "",
        subject: str = "",
        summary: str = "",
        summary_exact: str = "",
        text_body: str = "",
        text_exact: str = "",
        transition_id: str = "",
        update_assignee_name: str = "",
        update_description: str = "",
        update_issue_type: str = "",
        update_summary: str = "",
        updated: str = "",
        use_wiki_markup: bool = False,
        user_account_ids: str = "",
        visibility_role: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_jira",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if integration is not None:
            self.inputs["integration"] = integration
        if action is not None:
            self.inputs["action"] = action
        if site is not None:
            self.inputs["site"] = site
        if project is not None:
            self.inputs["project"] = project
        if issue_key is not None:
            self.inputs["issue_key"] = issue_key
        if limit is not None:
            self.inputs["limit"] = limit
        if parent_issue_key is not None:
            self.inputs["parent_issue_key"] = parent_issue_key
        if summary is not None:
            self.inputs["summary"] = summary
        if description is not None:
            self.inputs["description"] = description
        if issue_type is not None:
            self.inputs["issue_type"] = issue_type
        if assignee_name is not None:
            self.inputs["assignee_name"] = assignee_name
        if update_summary is not None:
            self.inputs["update_summary"] = update_summary
        if update_description is not None:
            self.inputs["update_description"] = update_description
        if update_issue_type is not None:
            self.inputs["update_issue_type"] = update_issue_type
        if update_assignee_name is not None:
            self.inputs["update_assignee_name"] = update_assignee_name
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if status is not None:
            self.inputs["status"] = status
        if reporter_name is not None:
            self.inputs["reporter_name"] = reporter_name
        if query is not None:
            self.inputs["query"] = query
        if issue_summary is not None:
            self.inputs["issue_summary"] = issue_summary
        if summary_exact is not None:
            self.inputs["summary_exact"] = summary_exact
        if description_exact is not None:
            self.inputs["description_exact"] = description_exact
        if comment is not None:
            self.inputs["comment"] = comment
        if comment_exact is not None:
            self.inputs["comment_exact"] = comment_exact
        if text is not None:
            self.inputs["text"] = text
        if text_exact is not None:
            self.inputs["text_exact"] = text_exact
        if labels is not None:
            self.inputs["labels"] = labels
        if fix_version is not None:
            self.inputs["fix_version"] = fix_version
        if affected_version is not None:
            self.inputs["affected_version"] = affected_version
        if component is not None:
            self.inputs["component"] = component
        if resolution is not None:
            self.inputs["resolution"] = resolution
        if created is not None:
            self.inputs["created"] = created
        if updated is not None:
            self.inputs["updated"] = updated
        if resolved is not None:
            self.inputs["resolved"] = resolved
        if due is not None:
            self.inputs["due"] = due
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if delete_subtasks is not None:
            self.inputs["delete_subtasks"] = delete_subtasks
        if text_body is not None:
            self.inputs["text_body"] = text_body
        if html_body is not None:
            self.inputs["html_body"] = html_body
        if subject is not None:
            self.inputs["subject"] = subject
        if notify_reporter is not None:
            self.inputs["notify_reporter"] = notify_reporter
        if notify_assignee is not None:
            self.inputs["notify_assignee"] = notify_assignee
        if notify_watchers is not None:
            self.inputs["notify_watchers"] = notify_watchers
        if notify_voters is not None:
            self.inputs["notify_voters"] = notify_voters
        if user_account_ids is not None:
            self.inputs["user_account_ids"] = user_account_ids
        if group_names is not None:
            self.inputs["group_names"] = group_names
        if transition_id is not None:
            self.inputs["transition_id"] = transition_id
        if expand is not None:
            self.inputs["expand"] = expand
        if skip_remote_only_condition is not None:
            self.inputs["skip_remote_only_condition"] = skip_remote_only_condition
        if file is not None:
            self.inputs["file"] = file
        if attachment_id is not None:
            self.inputs["attachment_id"] = attachment_id
        if download is not None:
            self.inputs["download"] = download
        if visibility_role is not None:
            self.inputs["visibility_role"] = visibility_role
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if use_wiki_markup is not None:
            self.inputs["use_wiki_markup"] = use_wiki_markup
        if email_address is not None:
            self.inputs["email_address"] = email_address
        if notification is not None:
            self.inputs["notification"] = notification
        if account_id is not None:
            self.inputs["account_id"] = account_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationJiraNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
