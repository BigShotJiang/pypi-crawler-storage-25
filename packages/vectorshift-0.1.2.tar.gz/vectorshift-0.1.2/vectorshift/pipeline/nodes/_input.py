"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("input")
class InputNode(Node):
    """
    Pass data of different types into your workflow

    ## Inputs
    ### Common Inputs
        description: The input description. If pipeline is used as a tool in an agent, the description will be passed to the agent to help the agent know how to fill this input.
        input_type: Raw Text
        use_default_value: Set default value to be used if no value is provided
    ### When input_type = 'dataframe' and use_default_value = True
        dataframe_type: The type of dataframe to be used
        default_value: The default value to be used if no value is provided
    ### When input_type = 'string' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'file' and use_default_value = True
        default_value: The default value to be used if no value is provided
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.
    ### When input_type = 'audio' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'image' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'knowledge_base' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'pipeline' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'agent' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'vec<file>' and use_default_value = True
        default_value: The default value to be used if no value is provided
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.
    ### When input_type = 'int32' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'float' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'bool' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'timestamp' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'vec<string>' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'vec<vec<file>>' and use_default_value = True
        default_value: The default value to be used if no value is provided
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.
    ### When input_type = 'vec<vec<string>>' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'table' and use_default_value = True
        default_value: The default value to be used if no value is provided
    ### When input_type = 'file' and use_default_value = False
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.
    ### When input_type = 'vec<file>' and use_default_value = False
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.
    ### When input_type = 'vec<vec<file>>' and use_default_value = False
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.

    ## Outputs
    ### When input_type = 'agent' and use_default_value = False
        agent: The agent output
    ### When input_type = 'agent' and use_default_value = True
        agent: The agent output
    ### When input_type = 'audio' and use_default_value = False
        audio: The audio that was passed in
    ### When input_type = 'audio' and use_default_value = True
        audio: The audio that was passed in
    ### When input_type = 'dataframe' and use_default_value = False
        dataframe: The dataframe that was passed in
    ### When input_type = 'dataframe' and use_default_value = True
        dataframe: The dataframe that was passed in
    ### When input_type = 'file' and use_default_value = False
        file: The file that was passed in
        file_name: The name of the file
        processed_text: The processed text of the file.
    ### When input_type = 'file' and use_default_value = True
        file: The file that was passed in
        file_name: The name of the file
        processed_text: The processed text of the file.
    ### When input_type = 'vec<file>' and use_default_value = False
        file_names: The names of the files
        files: The files that were passed in
        processed_texts: The processed text of the files
    ### When input_type = 'vec<file>' and use_default_value = True
        file_names: The names of the files
        files: The files that were passed in
        processed_texts: The processed text of the files
    ### When input_type = 'vec<vec<file>>' and use_default_value = False
        file_names: The names of the files in each group
        files: The file groups that were passed in
        processed_texts: The processed text of the file groups
    ### When input_type = 'vec<vec<file>>' and use_default_value = True
        file_names: The names of the files in each group
        files: The file groups that were passed in
        processed_texts: The processed text of the file groups
    ### When input_type = 'image' and use_default_value = False
        image: The image that was passed in
    ### When input_type = 'image' and use_default_value = True
        image: The image that was passed in
    ### When input_type = 'knowledge_base' and use_default_value = False
        knowledge_base: The Knowledge Base that was passed in
    ### When input_type = 'knowledge_base' and use_default_value = True
        knowledge_base: The Knowledge Base that was passed in
    ### When input_type = 'pipeline' and use_default_value = False
        pipeline: The pipeline output
    ### When input_type = 'pipeline' and use_default_value = True
        pipeline: The pipeline output
    ### When input_type = 'table' and use_default_value = False
        table: The table that was passed in
    ### When input_type = 'table' and use_default_value = True
        table: The table that was passed in
    ### When input_type = 'string' and use_default_value = False
        text: The text that was passed in
    ### When input_type = 'string' and use_default_value = True
        text: The text that was passed in
    ### When input_type = 'int32' and use_default_value = False
        value: The integer that was passed in
    ### When input_type = 'int32' and use_default_value = True
        value: The integer that was passed in
    ### When input_type = 'float' and use_default_value = False
        value: The float that was passed in
    ### When input_type = 'float' and use_default_value = True
        value: The float that was passed in
    ### When input_type = 'bool' and use_default_value = False
        value: The boolean that was passed in
    ### When input_type = 'bool' and use_default_value = True
        value: The boolean that was passed in
    ### When input_type = 'timestamp' and use_default_value = False
        value: The timestamp that was passed in
    ### When input_type = 'timestamp' and use_default_value = True
        value: The timestamp that was passed in
    ### When input_type = 'vec<string>' and use_default_value = False
        value: The list of strings that was passed in
    ### When input_type = 'vec<string>' and use_default_value = True
        value: The list of strings that was passed in
    ### When input_type = 'vec<vec<string>>' and use_default_value = False
        value: The list of lists of strings that was passed in
    ### When input_type = 'vec<vec<string>>' and use_default_value = True
        value: The list of lists of strings that was passed in
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "description",
            "helper_text": "The input description. If pipeline is used as a tool in an agent, the description will be passed to the agent to help the agent know how to fill this input.",
            "value": "",
            "type": "string",
        },
        {
            "field": "input_type",
            "helper_text": "Raw Text",
            "value": "string",
            "type": "string",
        },
        {
            "field": "use_default_value",
            "helper_text": "Set default value to be used if no value is provided",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "string**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "string",
                    "helper_text": "Raw Text",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "The text that was passed in",
                }
            ],
        },
        "string**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "string",
                    "helper_text": "Raw Text",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "string",
                    "label": "Default Value",
                    "value": "",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "placeholder": "Enter default value",
                },
            ],
            "outputs": [
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "The text that was passed in",
                }
            ],
        },
        "file**false": {
            "inputs": [
                {
                    "field": "file_parser",
                    "type": "string",
                    "value": "default",
                    "label": "Processing Model",
                    "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page. Reducto enables rich structured parsing.",
                    "component": {
                        "type": "dropdown",
                        "source": "dropdown_options",
                        "source_key": "input_file_parser",
                    },
                    "section": "advanced_settings",
                },
                {
                    "field": "input_type",
                    "type": "string",
                    "value": "file",
                    "label": "Type",
                    "helper_text": "File of any type: PDF, Word, MP3, JPEG, etc.",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "processed_text",
                    "type": "string",
                    "helper_text": "The processed text of the file.",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "The file that was passed in",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "The name of the file",
                },
            ],
        },
        "file**true": {
            "inputs": [
                {
                    "field": "default_value",
                    "type": "file",
                    "label": "Default Value",
                    "value": {},
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
                {
                    "field": "file_parser",
                    "type": "string",
                    "value": "default",
                    "label": "Processing model",
                    "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
                    "component": {
                        "type": "dropdown",
                        "source": "dropdown_options",
                        "source_key": "input_file_parser",
                    },
                    "section": "advanced_settings",
                },
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "file",
                    "helper_text": "File of any type: PDF, Word, MP3, JPEG, etc.",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "processed_text",
                    "type": "string",
                    "helper_text": "The processed text of the file.",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "The file that was passed in",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "The name of the file",
                },
            ],
        },
        "audio**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "audio",
                    "helper_text": "Allows you to record audio through the VectorShift platform. To convert the audio to text, connect the input node to a Speech to Text node",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "audio",
                    "type": "audio",
                    "helper_text": "The audio that was passed in",
                }
            ],
        },
        "audio**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "audio",
                    "helper_text": "Allows you to record audio through the VectorShift platform. To convert the audio to text, connect the input node to a Speech to Text node",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "audio",
                    "label": "Default Value",
                    "value": {},
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [
                {
                    "field": "audio",
                    "type": "audio",
                    "helper_text": "The audio that was passed in",
                }
            ],
        },
        "image**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "image",
                    "helper_text": "Image of any type: JPEG, PNG, etc.",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "image",
                    "type": "image",
                    "helper_text": "The image that was passed in",
                }
            ],
        },
        "image**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "image",
                    "helper_text": "Image of any type: JPEG, PNG, etc.",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "image",
                    "label": "Default Value",
                    "value": {},
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [
                {
                    "field": "image",
                    "type": "image",
                    "helper_text": "The image that was passed in",
                }
            ],
        },
        "knowledge_base**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "knowledge_base",
                    "helper_text": "Allows you to pass a Knowledge Base as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "knowledge_base",
                    "type": "knowledge_base",
                    "helper_text": "The Knowledge Base that was passed in",
                }
            ],
        },
        "knowledge_base**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "knowledge_base",
                    "helper_text": "Allows you to pass a Knowledge Base as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "knowledge_base",
                    "value": {"object_id": "", "object_type": ObjectType.KNOWLEDGE_BASE},
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {
                        "type": "vs_object",
                        "decorators": {
                            "dropdown_helper": {
                                "value": "kb_summary",
                                "position": "end",
                            }
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "knowledge_base",
                    "type": "knowledge_base",
                    "helper_text": "The Knowledge Base that was passed in",
                }
            ],
        },
        "pipeline**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "pipeline",
                    "helper_text": "Allows you to pass a Pipeline as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [{"field": "pipeline", "type": "pipeline"}],
        },
        "pipeline**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "pipeline",
                    "helper_text": "Allows you to pass a Pipeline as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "pipeline",
                    "value": {"object_id": "", "object_type": ObjectType.PIPELINE},
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [{"field": "pipeline", "type": "pipeline"}],
        },
        "agent**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "type": "enum<string>",
                    "label": "Type",
                    "value": "agent",
                    "helper_text": "Allows you to pass an Agent as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [{"field": "agent", "type": "agent"}],
        },
        "agent**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "type": "enum<string>",
                    "label": "Type",
                    "value": "agent",
                    "helper_text": "Allows you to pass an Agent as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "agent",
                    "value": {"object_id": "", "object_type": ObjectType.AGENT},
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [{"field": "agent", "type": "agent"}],
        },
        "vec<file>**false": {
            "inputs": [
                {
                    "field": "file_parser",
                    "type": "string",
                    "value": "default",
                    "label": "Processing Model",
                    "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
                    "component": {
                        "type": "dropdown",
                        "source": "dropdown_options",
                        "source_key": "input_file_parser",
                    },
                    "section": "advanced_settings",
                },
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<file>",
                    "helper_text": "Allows you to pass a list of files as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "processed_texts",
                    "type": "vec<string>",
                    "helper_text": "The processed text of the files",
                },
                {
                    "field": "files",
                    "type": "vec<file>",
                    "helper_text": "The files that were passed in",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "The names of the files",
                },
            ],
        },
        "vec<file>**true": {
            "inputs": [
                {
                    "field": "file_parser",
                    "type": "string",
                    "value": "default",
                    "label": "Processing Model",
                    "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
                    "component": {
                        "type": "dropdown",
                        "source": "dropdown_options",
                        "source_key": "input_file_parser",
                    },
                    "section": "advanced_settings",
                },
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<file>",
                    "helper_text": "Allows you to pass a list of files as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "text", "default_itemize": False},
                },
            ],
            "outputs": [
                {
                    "field": "processed_texts",
                    "type": "vec<string>",
                    "helper_text": "The processed text of the files",
                },
                {
                    "field": "files",
                    "type": "vec<file>",
                    "helper_text": "The files that were passed in",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "The names of the files",
                },
            ],
        },
        "int32**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "int32",
                    "helper_text": "Allows you to pass an integer as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "int32",
                    "helper_text": "The integer that was passed in",
                }
            ],
        },
        "int32**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "int32",
                    "helper_text": "Allows you to pass an integer as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "int32",
                    "value": 0,
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "number"},
                },
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "int32",
                    "helper_text": "The integer that was passed in",
                }
            ],
        },
        "float**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "float",
                    "helper_text": "Allows you to pass a float as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "float",
                    "helper_text": "The float that was passed in",
                }
            ],
        },
        "float**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "float",
                    "helper_text": "Allows you to pass a float as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "float",
                    "value": 0,
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "number"},
                },
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "float",
                    "helper_text": "The float that was passed in",
                }
            ],
        },
        "bool**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "bool",
                    "helper_text": "Allows you to pass a boolean as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "bool",
                    "helper_text": "The boolean that was passed in",
                }
            ],
        },
        "bool**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "bool",
                    "helper_text": "Allows you to pass a boolean as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "bool",
                    "value": False,
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "component_field": True},
                },
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "bool",
                    "helper_text": "The boolean that was passed in",
                }
            ],
        },
        "timestamp**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "timestamp",
                    "helper_text": "Allows you to pass a timestamp as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "timestamp",
                    "helper_text": "The timestamp that was passed in",
                }
            ],
        },
        "timestamp**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "timestamp",
                    "helper_text": "Allows you to pass a timestamp as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "timestamp",
                    "value": {},
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "timestamp",
                    "helper_text": "The timestamp that was passed in",
                }
            ],
        },
        "vec<string>**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<string>",
                    "helper_text": "Allows you to pass a list of strings as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "vec<string>",
                    "helper_text": "The list of strings that was passed in",
                }
            ],
        },
        "vec<string>**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<string>",
                    "helper_text": "Allows you to pass a list of strings as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "text", "default_itemize": False},
                },
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "vec<string>",
                    "helper_text": "The list of strings that was passed in",
                }
            ],
        },
        "vec<vec<file>>**false": {
            "inputs": [
                {
                    "field": "file_parser",
                    "type": "string",
                    "value": "default",
                    "label": "Processing Model",
                    "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
                    "component": {"type": "dropdown"},
                    "section": "advanced_settings",
                },
                {
                    "field": "input_type",
                    "type": "string",
                    "label": "Type",
                    "value": "vec<vec<file>>",
                    "helper_text": "Allows you to pass a list of lists of files as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "processed_texts",
                    "type": "vec<vec<string>>",
                    "helper_text": "The processed text of the file groups",
                },
                {
                    "field": "files",
                    "type": "vec<vec<file>>",
                    "helper_text": "The file groups that were passed in",
                },
                {
                    "field": "file_names",
                    "type": "vec<vec<string>>",
                    "helper_text": "The names of the files in each group",
                },
            ],
        },
        "vec<vec<file>>**true": {
            "inputs": [
                {
                    "field": "file_parser",
                    "type": "string",
                    "value": "default",
                    "label": "Processing Model",
                    "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
                    "component": {
                        "type": "dropdown",
                        "source": "dropdown_options",
                        "source_key": "input_file_parser",
                    },
                    "section": "advanced_settings",
                },
                {
                    "field": "input_type",
                    "type": "string",
                    "label": "Type",
                    "value": "vec<vec<file>>",
                    "helper_text": "Allows you to pass a list of lists of files as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "vec<vec<file>>",
                    "value": [],
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "text", "default_itemize": False},
                },
            ],
            "outputs": [
                {
                    "field": "processed_texts",
                    "type": "vec<vec<string>>",
                    "helper_text": "The processed text of the file groups",
                },
                {
                    "field": "files",
                    "type": "vec<vec<file>>",
                    "helper_text": "The file groups that were passed in",
                },
                {
                    "field": "file_names",
                    "type": "vec<vec<string>>",
                    "helper_text": "The names of the files in each group",
                },
            ],
        },
        "vec<vec<string>>**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<vec<string>>",
                    "helper_text": "Allows you to pass a list of lists of strings as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "vec<vec<string>>",
                    "helper_text": "The list of lists of strings that was passed in",
                }
            ],
        },
        "vec<vec<string>>**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<vec<string>>",
                    "helper_text": "Allows you to pass a list of lists of strings as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "vec<vec<string>>",
                    "value": [],
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {"type": "text", "default_itemize": False},
                },
            ],
            "outputs": [
                {
                    "field": "value",
                    "type": "vec<vec<string>>",
                    "helper_text": "The list of lists of strings that was passed in",
                }
            ],
        },
        "table**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "type": "string",
                    "value": "table",
                    "label": "Type",
                    "helper_text": "Allows you to pass a table as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "table",
                    "type": "table",
                    "helper_text": "The table that was passed in",
                }
            ],
        },
        "table**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "type": "string",
                    "value": "table",
                    "label": "Type",
                    "helper_text": "Allows you to pass a table as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "default_value",
                    "type": "table",
                    "value": {"object_id": "", "object_type": ObjectType.TABLE},
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [
                {
                    "field": "table",
                    "type": "table",
                    "helper_text": "The table that was passed in",
                }
            ],
        },
        "dataframe**false": {
            "inputs": [
                {
                    "field": "input_type",
                    "type": "string",
                    "value": "dataframe",
                    "label": "Type",
                    "helper_text": "Allows you to pass a dataframe as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "dataframe",
                    "type": "dataframe",
                    "helper_text": "The dataframe that was passed in",
                }
            ],
        },
        "dataframe**true": {
            "inputs": [
                {
                    "field": "input_type",
                    "type": "string",
                    "value": "dataframe",
                    "label": "Type",
                    "helper_text": "Allows you to pass a dataframe as an input",
                    "component": {
                        "type": "dropdown",
                        "source_key": "input_node_input_type",
                    },
                },
                {
                    "field": "dataframe_type",
                    "type": "string",
                    "value": "table",
                    "label": "Dataframe Type",
                    "helper_text": "The type of dataframe to be used",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Table", "value": "table"},
                            {"label": "SQL", "value": "sql"},
                            {"label": "CSV", "value": "csv"},
                            {"label": "JSON", "value": "json"},
                            {"label": "MD", "value": "md"},
                            {"label": "File", "value": "dataframe_file"},
                        ],
                    },
                    "visibility": False,
                },
                {
                    "field": "default_value",
                    "type": "dataframe",
                    "value": {
                        "object_info": {"object_id": "", "object_type": ObjectType.TABLE}
                    },
                    "label": "Default Value",
                    "helper_text": "The default value to be used if no value is provided",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dataframe",
                        "decorators": {"hide": ["create_button", "edit_button"]},
                        "source": "dataframe_options",
                        "source_key": "dataframe_type",
                        "source_sub_key": "component.options",
                        "access_value_sub_key": "objectInfo",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "dataframe",
                    "type": "dataframe",
                    "helper_text": "The dataframe that was passed in",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["input_type", "use_default_value"]

    _advanced_inputs = False

    _batch_mode_allowed = False

    def __init__(
        self,
        input_type: str = "string",
        use_default_value: bool = False,
        dataframe_type: str = "table",
        default_value: str = "",
        description: str = "",
        file_parser: str = "default",
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["input_type"] = input_type
        params["use_default_value"] = use_default_value

        super().__init__(
            node_type="input",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if input_type is not None:
            self.inputs["input_type"] = input_type
        if description is not None:
            self.inputs["description"] = description
        if use_default_value is not None:
            self.inputs["use_default_value"] = use_default_value
        if default_value is not None:
            self.inputs["default_value"] = default_value
        if file_parser is not None:
            self.inputs["file_parser"] = file_parser
        if dataframe_type is not None:
            self.inputs["dataframe_type"] = dataframe_type

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "InputNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
