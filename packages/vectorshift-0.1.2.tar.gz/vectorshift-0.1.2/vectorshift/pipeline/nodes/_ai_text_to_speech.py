"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("ai_text_to_speech")
class AiTextToSpeechNode(Node):
    """
    Generate Audio from text using AI

    ## Inputs
    ### Common Inputs
        model: Select the text-to-speech model
        text: The string input for conversion.
        provider: Select the model provider.
        use_personal_api_key: Use your personal API key
        voice: Select the voice
    ### When use_personal_api_key = True
        api_key: Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run

    ## Outputs
    ### Common Outputs
        audio: The Text as converted to Audio.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the text-to-speech model",
            "value": "tts-1-hd",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The string input for conversion.",
            "value": "",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "Select the model provider.",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "Use your personal API key",
            "value": False,
            "type": "bool",
        },
        {
            "field": "voice",
            "helper_text": "Select the voice",
            "value": "alloy",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "audio",
            "helper_text": "The Text as converted to Audio.",
            "type": "audio",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "false**(*)": {"inputs": [], "outputs": []},
        "true**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run",
                    "component": {
                        "type": "password",
                        "agent_field_type": "dynamic",
                        "disable_conversion": True,
                    },
                }
            ],
            "outputs": [],
        },
        "(*)**openai": {"inputs": [], "outputs": [], "title": "OpenAI Text to Speech"},
        "(*)**eleven_labs": {
            "inputs": [],
            "outputs": [],
            "title": "Eleven Labs Text to Speech",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_personal_api_key", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text", "api_key"]

    def __init__(
        self,
        use_personal_api_key: bool = False,
        provider: str = "openai",
        model: str = "tts-1-hd",
        text: str = "",
        api_key: str = "",
        voice: str = "alloy",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["use_personal_api_key"] = use_personal_api_key
        params["provider"] = provider

        super().__init__(
            node_type="ai_text_to_speech",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if voice is not None:
            self.inputs["voice"] = voice
        if text is not None:
            self.inputs["text"] = text
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiTextToSpeechNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
