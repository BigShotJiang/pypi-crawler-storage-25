"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import RetryConfig, SafetyConfig, SamplingConfig


@Node.register_node_type("llm")
class LlmNode(Node):
    """
    LLM

    ## Inputs
    ### Common Inputs
        model: Select the LLM model to be used
        prompt: The data that is sent to the LLM. Add data from other nodes with double curly braces e.g., {{input_0.text}}
        system: The system prompt to be used
        temperature: The "creativity" of the response - increase the temperature for more creative responses.
        max_tokens: The maximum amount of input + output tokens the model will take in and generate per run (1 token = 4 characters). Note: different models have different token limits and the workflow will error if the max token is reached.
        top_p: The "randomness" of the output - higher Top P values increase the randomness
        baseUrl: The baseUrl input
        citation_metadata: The metadata of the sources used to generate the response
        enable_moderation: Whether to enable moderation
        enable_pii_address: Whether to enable PII address
        enable_pii_cc: Whether to enable PII cc
        enable_pii_email: Whether to enable PII email
        enable_pii_name: Whether to enable PII name
        enable_pii_phone: Whether to enable PII phone
        enable_pii_ssn: Whether to enable PII ssn
        jsonSchema: The jsonSchema input
        provider: Select the LLM provider to be used
        reasoning_effort: Controls the depth of reasoning for GPT-5 models ("none" is only supported on GPT-5.1 variants).
        retry_on_failure: Enable retrying when the node execution fails
        safe_context_token_window: If enabled, the context window will be reduced to fit the model's maximum context window.
        show_sources: Whether to show the sources used to generate the response
        stream: Whether to stream the response
        use_personal_api_key: The use_personal_api_key input
        verbosity: Controls the verbosity of GPT-5 responses.
    ### When provider = 'custom'
        api_key: Your API key
        base_url: The base URL of the custom LLM provider
        finetuned_model: Use your finetuned model for response generation. Make sure to select the matching base model from the dropdown.
        use_finetuned_model: The use_finetuned_model input
    ### When provider = 'openai' and use_personal_api_key = True
        api_key: Your API key
        finetuned_model: Use your finetuned model for response generation. Make sure to select the matching base model from the dropdown.
        use_finetuned_model: The use_finetuned_model input
    ### When provider = 'anthropic' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'perplexity' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'google' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'cohere' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'together' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'azure' and use_personal_api_key = True
        api_key: Your API key
        deployment_id: The deployment ID for the Azure OpenAI model. This is required when using Azure OpenAI services.
        endpoint: The Azure OpenAI endpoint URL (e.g., https://your-resource-name.openai.azure.com)
    ### When provider = 'xai' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'groq' and use_personal_api_key = True
        api_key: Your API key
    ### When provider = 'bedrock' and use_personal_api_key = True
        aws_access_key_id: Your AWS Access Key ID
        aws_region: AWS region where Bedrock models are enabled
        aws_secret_access_key: Your AWS Secret Access Key
    ### When provider = 'anthropic'
        enable_web_search: Enable Claude's built-in web search tool to search the web during response generation
        json_response: Whether to return the response as a JSON object
    ### When show_sources = True
        json_response: Whether to return the response as a JSON object
    ### When provider = 'openai'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'perplexity'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'google'
        json_response: Whether to return the response as a JSON object
        thinking_token_limit: The maximum number of tokens the model can use for thinking
    ### When provider = 'cohere'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'together'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'bedrock'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'azure'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'xai'
        json_response: Whether to return the response as a JSON object
    ### When provider = 'groq'
        json_response: Whether to return the response as a JSON object
    ### When json_response = True
        json_schema: The schema of the JSON response
    ### When retry_on_failure = True
        max_retries: The maximum number of retries
        retry_interval_ms: The interval between retries in milliseconds

    ## Outputs
    ### Common Outputs
        credits_used: The number of credits used
        input_tokens: The number of input tokens
        output_tokens: The number of output tokens
        tokens_used: The number of tokens used
    ### When stream = True
        response: The response as a stream of text
    ### When stream = False
        response: The response as a single string
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the LLM model to be used",
            "value": "gpt-4o",
            "type": "string",
        },
        {
            "field": "prompt",
            "helper_text": "The data that is sent to the LLM. Add data from other nodes with double curly braces e.g., {{input_0.text}}",
            "value": "",
            "type": "string",
        },
        {
            "field": "system",
            "helper_text": "The system prompt to be used",
            "value": "",
            "type": "string",
        },
        {
            "field": "temperature",
            "helper_text": 'The "creativity" of the response - increase the temperature for more creative responses.',
            "value": 0.5,
            "type": "float",
        },
        {
            "field": "max_tokens",
            "helper_text": "The maximum amount of input + output tokens the model will take in and generate per run (1 token = 4 characters). Note: different models have different token limits and the workflow will error if the max token is reached.",
            "value": 128000,
            "type": "int64",
        },
        {
            "field": "top_p",
            "helper_text": 'The "randomness" of the output - higher Top P values increase the randomness',
            "value": 0.5,
            "type": "float",
        },
        {
            "field": "baseUrl",
            "helper_text": "The baseUrl input",
            "value": "",
            "type": "string",
        },
        {
            "field": "citation_metadata",
            "helper_text": "The metadata of the sources used to generate the response",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "enable_moderation",
            "helper_text": "Whether to enable moderation",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_pii_address",
            "helper_text": "Whether to enable PII address",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_pii_cc",
            "helper_text": "Whether to enable PII cc",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_pii_email",
            "helper_text": "Whether to enable PII email",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_pii_name",
            "helper_text": "Whether to enable PII name",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_pii_phone",
            "helper_text": "Whether to enable PII phone",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_pii_ssn",
            "helper_text": "Whether to enable PII ssn",
            "value": False,
            "type": "bool",
        },
        {
            "field": "jsonSchema",
            "helper_text": "The jsonSchema input",
            "value": "",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "Select the LLM provider to be used",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "reasoning_effort",
            "helper_text": 'Controls the depth of reasoning for GPT-5 models ("none" is only supported on GPT-5.1 variants).',
            "value": "default",
            "type": "string",
        },
        {
            "field": "retry_on_failure",
            "helper_text": "Enable retrying when the node execution fails",
            "value": True,
            "type": "bool",
        },
        {
            "field": "safe_context_token_window",
            "helper_text": "If enabled, the context window will be reduced to fit the model's maximum context window.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "show_sources",
            "helper_text": "Whether to show the sources used to generate the response",
            "value": False,
            "type": "bool",
        },
        {
            "field": "stream",
            "helper_text": "Whether to stream the response",
            "value": False,
            "type": "bool",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "The use_personal_api_key input",
            "value": False,
            "type": "bool",
        },
        {
            "field": "verbosity",
            "helper_text": "Controls the verbosity of GPT-5 responses.",
            "value": "default",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "credits_used",
            "helper_text": "The number of credits used",
            "type": "float",
        },
        {
            "field": "input_tokens",
            "helper_text": "The number of input tokens",
            "type": "int64",
        },
        {
            "field": "output_tokens",
            "helper_text": "The number of output tokens",
            "type": "int64",
        },
        {
            "field": "tokens_used",
            "helper_text": "The number of tokens used",
            "type": "int64",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**true**(*)**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "response",
                    "type": "stream<string>",
                    "helper_text": "The response as a stream of text",
                }
            ],
        },
        "(*)**false**(*)**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "response",
                    "type": "string",
                    "helper_text": "The response as a single string",
                }
            ],
        },
        "(*)**(*)**(*)**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "json_schema",
                    "type": "string",
                    "value": "",
                    "helper_text": "The schema of the JSON response",
                    "placeholder": "JSON Schema",
                    "label": "JSON Schema",
                    "component": {"type": "text", "is_advanced_setting": True},
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**(*)**(*)**true**(*)": {
            "inputs": [
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "value": "",
                    "helper_text": "The metadata of the sources used to generate the response",
                    "is_advanced_setting": True,
                    "placeholder": "Citation Metadata",
                    "label": "Citation Metadata",
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "is_advanced_setting": True,
                    "placeholder": "JSON Response",
                    "label": "JSON Response",
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                },
            ],
            "outputs": [],
        },
        "(*)**(*)**(*)**(*)**(*)**true": {
            "inputs": [
                {
                    "field": "max_retries",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "The maximum number of retries",
                    "placeholder": "Max Retries",
                    "label": "Max Retries",
                    "section": "advanced_settings",
                },
                {
                    "field": "retry_interval_ms",
                    "type": "int32",
                    "value": 1000,
                    "helper_text": "The interval between retries in milliseconds",
                    "placeholder": "Retry Interval in ms",
                    "label": "Retry Interval in ms",
                    "section": "advanced_settings",
                },
            ],
            "outputs": [],
        },
        "custom**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "base_url",
                    "label": "Base URL",
                    "type": "string",
                    "value": "",
                    "helper_text": "The base URL of the custom LLM provider",
                },
                {
                    "field": "model",
                    "label": "Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The model to be used",
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                },
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your API key",
                    "component": {"type": "password"},
                    "visibility": {
                        "field": "use_personal_api_key",
                        "operator": "==",
                        "value": True,
                    },
                },
                {
                    "field": "use_finetuned_model",
                    "type": "bool",
                    "value": False,
                    "label": "Use Finetuned Model ID",
                    "helper_text": "",
                    "visibility": {
                        "field": "use_personal_api_key",
                        "operator": "==",
                        "value": True,
                    },
                    "component": {"type": "bool"},
                },
                {
                    "field": "finetuned_model",
                    "type": "string",
                    "value": "",
                    "label": "Finetuned Model ID",
                    "helper_text": "Use your finetuned model for response generation. Make sure to select the matching base model from the dropdown.",
                    "visibility": {
                        "logic": "AND",
                        "conditions": [
                            {
                                "field": "use_finetuned_model",
                                "operator": "==",
                                "value": True,
                            },
                            {
                                "field": "use_personal_api_key",
                                "operator": "==",
                                "value": True,
                            },
                        ],
                    },
                    "component": {"type": "text"},
                },
            ],
            "outputs": [],
            "title": "Custom",
        },
        "openai**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Response",
                    "label": "JSON Response",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
            "title": "OpenAI",
        },
        "openai**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                },
                {
                    "field": "use_finetuned_model",
                    "type": "bool",
                    "value": False,
                    "label": "Use Finetuned Model ID",
                    "helper_text": "",
                    "component": {"type": "bool"},
                },
                {
                    "field": "finetuned_model",
                    "type": "string",
                    "value": "",
                    "label": "Finetuned Model ID",
                    "helper_text": "Use your finetuned model for response generation. Make sure to select the matching base model from the dropdown.",
                    "visibility": {
                        "field": "use_finetuned_model",
                        "operator": "==",
                        "value": True,
                    },
                    "component": {"type": "text"},
                },
            ],
            "outputs": [],
        },
        "anthropic**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Response",
                    "label": "JSON Response",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "temperature",
                    "type": "float",
                    "value": 0.5,
                    "label": "Temperature",
                    "helper_text": 'The "creativity" of the response - increase the temperature for more creative responses.',
                    "placeholder": "Temperature",
                    "section": "advanced_settings",
                    "component": {
                        "type": "number_slider",
                        "min": "0",
                        "max": "1",
                        "step": "0.01",
                        "is_advanced_setting": True,
                    },
                },
                {
                    "field": "max_tokens",
                    "type": "int64",
                    "value": 64000,
                    "label": "Max Tokens",
                    "helper_text": "The maximum amount of input + output tokens the model will take in and generate per run (1 token = 4 characters). Note: different models have different token limits and the workflow will error if the max token is reached.",
                    "placeholder": "Max Tokens",
                    "section": "advanced_settings",
                    "component": {
                        "type": "number",
                        "is_advanced_setting": True,
                        "decorators": {"hide": ["variable_switch"]},
                    },
                },
                {
                    "field": "enable_web_search",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Enable Claude's built-in web search tool to search the web during response generation",
                    "label": "Web Search",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
            ],
            "outputs": [],
            "title": "Anthropic",
        },
        "anthropic**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "perplexity**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "Perplexity",
        },
        "perplexity**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "google**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "max_tokens",
                    "type": "int64",
                    "value": 65535,
                    "label": "Max Tokens",
                    "helper_text": "The maximum amount of input + output tokens the model will take in and generate per run (1 token = 4 characters). Note: different models have different token limits and the workflow will error if the max token is reached.",
                    "placeholder": "Max Tokens",
                    "section": "advanced_settings",
                    "component": {
                        "type": "number",
                        "is_advanced_setting": True,
                        "decorators": {"hide": ["variable_switch"]},
                    },
                },
                {
                    "field": "thinking_token_limit",
                    "type": "int64",
                    "value": 24576,
                    "label": "Thinking Tokens",
                    "helper_text": "The maximum number of tokens the model can use for thinking",
                    "placeholder": "Thinking Token Limit",
                    "section": "advanced_settings",
                    "component": {
                        "type": "number",
                        "is_advanced_setting": True,
                        "decorators": {"hide": ["variable_switch"]},
                    },
                },
            ],
            "outputs": [],
            "title": "Google",
        },
        "google**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "cohere**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "Cohere",
        },
        "cohere**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "together**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "Open Source",
        },
        "together**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "bedrock**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "stream",
                    "type": "bool",
                    "value": False,
                    "component": {"type": "bool", "hidden_from_ui": True},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use personal AWS credentials",
                    "placeholder": "Use Personal AWS Credentials",
                    "label": "Use Personal AWS Credentials",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "Bedrock",
        },
        "bedrock**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "aws_access_key_id",
                    "label": "AWS Access Key ID",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your AWS Access Key ID",
                    "component": {"type": "password"},
                },
                {
                    "field": "aws_secret_access_key",
                    "label": "AWS Secret Access Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your AWS Secret Access Key",
                    "component": {"type": "password"},
                },
                {
                    "field": "aws_region",
                    "label": "AWS Region",
                    "type": "string",
                    "value": "us-east-1",
                    "helper_text": "AWS region where Bedrock models are enabled",
                    "component": {
                        "type": "dropdown",
                        "source": "dropdown_options",
                        "source_key": "aws_bedrock_region",
                    },
                },
            ],
            "outputs": [],
        },
        "azure**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "Azure",
        },
        "azure**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                },
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "label": "Endpoint",
                    "helper_text": "The Azure OpenAI endpoint URL (e.g., https://your-resource-name.openai.azure.com)",
                    "component": {"type": "text"},
                },
                {
                    "field": "deployment_id",
                    "type": "string",
                    "value": "",
                    "label": "Deployment ID",
                    "helper_text": "The deployment ID for the Azure OpenAI model. This is required when using Azure OpenAI services.",
                    "component": {"type": "text"},
                },
            ],
            "outputs": [],
        },
        "xai**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "xAI",
        },
        "xai**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "groq**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "json_response",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to return the response as a JSON object",
                    "placeholder": "JSON Output",
                    "label": "JSON Output",
                    "section": "advanced_settings",
                    "component": {"type": "bool", "is_advanced_setting": True},
                },
                {
                    "field": "use_personal_api_key",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use a personal API key",
                    "placeholder": "Use Personal Api Key",
                    "label": "Use Personal Api Key",
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [],
            "title": "Groq",
        },
        "groq**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = [
        "provider",
        "stream",
        "use_personal_api_key",
        "json_response",
        "show_sources",
        "retry_on_failure",
    ]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "prompt", "label": "Prompt"},
        {"field": "system", "label": "System Instructions"},
    ]

    _REQUIRED_FIELDS = ["api_key", "json_schema"]

    def __init__(
        self,
        provider: str = "openai",
        stream: bool = False,
        use_personal_api_key: bool = False,
        json_response: bool = False,
        show_sources: bool = False,
        model: str = "gpt-4o",
        prompt: str = "",
        system: str = "",
        api_key: str = "",
        aws_access_key_id: str = "",
        aws_region: str = "us-east-1",
        aws_secret_access_key: str = "",
        baseUrl: str = "",
        base_url: str = "",
        citation_metadata: List[str] = [],
        deployment_id: str = "",
        enable_web_search: bool = False,
        endpoint: str = "",
        finetuned_model: str = "",
        jsonSchema: str = "",
        json_schema: str = "",
        reasoning_effort: str = "default",
        safe_context_token_window: bool = False,
        thinking_token_limit: int = 24576,
        use_finetuned_model: bool = False,
        verbosity: str = "default",
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        safety: Optional[SafetyConfig] = None,
        retry: Optional[RetryConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        _cfg_safety = safety if safety is not None else SafetyConfig()
        enable_moderation = _cfg_safety.moderation
        enable_pii_name = _cfg_safety.pii_name
        enable_pii_email = _cfg_safety.pii_email
        enable_pii_phone = _cfg_safety.pii_phone
        enable_pii_ssn = _cfg_safety.pii_ssn
        enable_pii_address = _cfg_safety.pii_address
        enable_pii_cc = _cfg_safety.pii_cc
        _cfg_retry = retry if retry is not None else RetryConfig()
        max_retries = _cfg_retry.max_retries
        retry_interval_ms = _cfg_retry.interval_ms
        retry_on_failure = True if retry is not None else False
        # Initialize with params
        params = {}
        params["provider"] = provider
        params["stream"] = stream
        params["use_personal_api_key"] = use_personal_api_key
        params["json_response"] = json_response
        params["show_sources"] = show_sources
        params["retry_on_failure"] = retry_on_failure

        super().__init__(
            node_type="llm",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if enable_moderation is not None:
            self.inputs["enable_moderation"] = enable_moderation
        if enable_pii_name is not None:
            self.inputs["enable_pii_name"] = enable_pii_name
        if enable_pii_email is not None:
            self.inputs["enable_pii_email"] = enable_pii_email
        if enable_pii_phone is not None:
            self.inputs["enable_pii_phone"] = enable_pii_phone
        if enable_pii_ssn is not None:
            self.inputs["enable_pii_ssn"] = enable_pii_ssn
        if enable_pii_address is not None:
            self.inputs["enable_pii_address"] = enable_pii_address
        if enable_pii_cc is not None:
            self.inputs["enable_pii_cc"] = enable_pii_cc
        if max_retries is not None:
            self.inputs["max_retries"] = max_retries
        if retry_interval_ms is not None:
            self.inputs["retry_interval_ms"] = retry_interval_ms
        if retry_on_failure is not None:
            self.inputs["retry_on_failure"] = retry_on_failure
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if system is not None:
            self.inputs["system"] = system
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if stream is not None:
            self.inputs["stream"] = stream
        if show_sources is not None:
            self.inputs["show_sources"] = show_sources
        if citation_metadata is not None:
            self.inputs["citation_metadata"] = citation_metadata
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if baseUrl is not None:
            self.inputs["baseUrl"] = baseUrl
        if jsonSchema is not None:
            self.inputs["jsonSchema"] = jsonSchema
        if reasoning_effort is not None:
            self.inputs["reasoning_effort"] = reasoning_effort
        if verbosity is not None:
            self.inputs["verbosity"] = verbosity
        if safe_context_token_window is not None:
            self.inputs["safe_context_token_window"] = safe_context_token_window
        if json_schema is not None:
            self.inputs["json_schema"] = json_schema
        if json_response is not None:
            self.inputs["json_response"] = json_response
        if base_url is not None:
            self.inputs["base_url"] = base_url
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if use_finetuned_model is not None:
            self.inputs["use_finetuned_model"] = use_finetuned_model
        if finetuned_model is not None:
            self.inputs["finetuned_model"] = finetuned_model
        if enable_web_search is not None:
            self.inputs["enable_web_search"] = enable_web_search
        if thinking_token_limit is not None:
            self.inputs["thinking_token_limit"] = thinking_token_limit
        if aws_access_key_id is not None:
            self.inputs["aws_access_key_id"] = aws_access_key_id
        if aws_secret_access_key is not None:
            self.inputs["aws_secret_access_key"] = aws_secret_access_key
        if aws_region is not None:
            self.inputs["aws_region"] = aws_region
        if endpoint is not None:
            self.inputs["endpoint"] = endpoint
        if deployment_id is not None:
            self.inputs["deployment_id"] = deployment_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "LlmNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
