"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_telegram")
class IntegrationTelegramNode(Node):
    """
    Telegram

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### edit_message_text
        text: New text of the message (1-4096 characters)
        chat_id: ID of the chat to get information about
        message_id: ID of the message to delete
        parse_mode: Mode for parsing entities in the message text
    ### send_message
        text: New text of the message (1-4096 characters)
        chat_id: ID of the chat to get information about
        disable_notification: Pass true if it is not necessary to send a notification to all chat members about the new pinned message
        disable_web_page_preview: Disables link previews for links in this message
        parse_mode: Mode for parsing entities in the message text
    ### send_animation
        animation: Animation to send (file_id, HTTP URL, or file path)
        caption: Animation caption (0-1024 characters, optional)
        chat_id: ID of the chat to get information about
        parse_mode: Mode for parsing entities in the message text
    ### send_audio
        audio: Audio file to send (file_id, HTTP URL, or file path)
        caption: Animation caption (0-1024 characters, optional)
        chat_id: ID of the chat to get information about
        duration: Duration of the audio in seconds (optional)
        performer: Performer of the audio (optional)
        title: New title for the chat (1-255 characters)
    ### send_document
        caption: Animation caption (0-1024 characters, optional)
        chat_id: ID of the chat to get information about
        document: Document to send (file_id, HTTP URL, or file path)
        parse_mode: Mode for parsing entities in the message text
    ### send_photo
        caption: Animation caption (0-1024 characters, optional)
        chat_id: ID of the chat to get information about
        parse_mode: Mode for parsing entities in the message text
        photo: Photo to send (file_id, HTTP URL, or file path)
    ### send_video
        caption: Animation caption (0-1024 characters, optional)
        chat_id: ID of the chat to get information about
        duration: Duration of the audio in seconds (optional)
        height: Video height (optional)
        video: Video to send (file_id, HTTP URL, or file path)
        width: Video width (optional)
    ### get_chat
        chat_id: ID of the chat to get information about
    ### get_updates
        chat_id: ID of the chat to get information about
        limit: Number of updates to retrieve (1-100, default: 10)
        offset: Offset for pagination (default: 0)
    ### list_administrators
        chat_id: ID of the chat to get information about
    ### get_member
        chat_id: ID of the chat to get information about
        user_id: ID of the user to get member details for
    ### leave_chat
        chat_id: ID of the chat to get information about
    ### update_description
        chat_id: ID of the chat to get information about
        description: New description for the chat (0-255 characters)
    ### update_title
        chat_id: ID of the chat to get information about
        title: New title for the chat (1-255 characters)
    ### delete_message
        chat_id: ID of the chat to get information about
        message_id: ID of the message to delete
    ### pin_message
        chat_id: ID of the chat to get information about
        disable_notification: Pass true if it is not necessary to send a notification to all chat members about the new pinned message
        message_id: ID of the message to delete
    ### send_location
        chat_id: ID of the chat to get information about
        heading: Direction in which the user is moving (1-360 degrees, optional)
        latitude: Latitude of the location
        live_period: Period in seconds for which the location will be updated (60-86400, optional)
        longitude: Longitude of the location
    ### send_media_group
        chat_id: ID of the chat to get information about
        media: JSON array of InputMedia objects (2-10 items). Send with type(type of media) and value(url) keys.
    ### send_sticker
        chat_id: ID of the chat to get information about
        sticker: Sticker to send (file_id, HTTP URL, or file path)
    ### unpin_message
        chat_id: ID of the chat to get information about
        message_id: ID of the message to delete
    ### get_file
        telegram_file_id: File identifier to get info about

    ## Outputs
    ### get_chat
        accent_color_id: Accent color ID
        active_usernames: Array of active usernames in JSON format
        can_send_gift: Whether the user can send gifts (for private chats)
        chat_description: Description of the chat
        chat_id: ID of the chat
        chat_title: Title of the chat
        chat_type: Type of the chat (private, group, supergroup, channel)
        first_name: First name of the user (for private chats)
        last_name: Last name of the user (for private chats)
        max_reaction_count: Maximum number of reactions allowed
        raw_data: Raw API response data
        username: Username of the user (for private chats)
    ### list_administrators
        admin_count: Number of administrators
        admin_ids: Array of administrator user IDs in JSON format
        admin_names: Array of administrator names in JSON format
        admin_statuses: Array of administrator statuses in JSON format
        admin_usernames: Array of administrator usernames in JSON format
        administrators: List of chat administrators in JSON format
        raw_data: Raw API response data
    ### get_file
        file: The actual file content downloaded from Telegram
        file_id: Identifier for this file
        file_path: File path on Telegram servers
        file_size: File size, if known
        file_unique_id: Unique identifier for this file
        file_url: Direct download URL for the file
        raw_data: Raw API response data
    ### get_updates
        message_count: Number of messages retrieved
        message_dates: Array of message timestamps in JSON format
        message_ids: Array of message IDs in JSON format
        message_texts: Array of message texts in JSON format
        messages: Array of messages in JSON format
        raw_data: Raw API response data
        sender_names: Array of sender names in JSON format
        sender_usernames: Array of sender usernames in JSON format
        updates: Array of updates in JSON format
    ### edit_message_text
        message_id: ID of the edited message
        raw_data: Raw API response data
    ### send_animation
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_audio
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_document
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_location
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_message
        message_id: ID of the sent message
        message_text: Text of the sent message
        raw_data: Raw API response data
    ### send_photo
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_sticker
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_video
        message_id: ID of the sent message
        raw_data: Raw API response data
    ### send_media_group
        message_ids: Array of message IDs in JSON format
        raw_data: Raw API response data
    ### get_member
        raw_data: Raw API response data
        status: Member status (creator, administrator, member, restricted, left, kicked)
        user_id: ID of the user
        user_name: Name of the user
        user_username: Username of the user
    ### leave_chat
        raw_data: Raw API response data
    ### update_description
        raw_data: Raw API response data
    ### update_title
        raw_data: Raw API response data
    ### delete_message
        raw_data: Raw API response data
    ### pin_message
        raw_data: Raw API response data
    ### unpin_message
        raw_data: Raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Telegram>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "get_chat": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to get information about",
                }
            ],
            "outputs": [
                {"field": "chat_id", "type": "string", "helper_text": "ID of the chat"},
                {
                    "field": "chat_title",
                    "type": "string",
                    "helper_text": "Title of the chat",
                },
                {
                    "field": "chat_type",
                    "type": "string",
                    "helper_text": "Type of the chat (private, group, supergroup, channel)",
                },
                {
                    "field": "chat_description",
                    "type": "string",
                    "helper_text": "Description of the chat",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "First name of the user (for private chats)",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Last name of the user (for private chats)",
                },
                {
                    "field": "username",
                    "type": "string",
                    "helper_text": "Username of the user (for private chats)",
                },
                {
                    "field": "can_send_gift",
                    "type": "bool",
                    "helper_text": "Whether the user can send gifts (for private chats)",
                },
                {
                    "field": "active_usernames",
                    "type": "string",
                    "helper_text": "Array of active usernames in JSON format",
                },
                {
                    "field": "max_reaction_count",
                    "type": "int32",
                    "helper_text": "Maximum number of reactions allowed",
                },
                {
                    "field": "accent_color_id",
                    "type": "int32",
                    "helper_text": "Accent color ID",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_chat",
            "task_name": "tasks.telegram.get_chat",
            "description": "Read details of a specific chat",
            "label": "Get Chat",
            "variant": "common_integration_nodes",
            "required": ["chat_id"],
        },
        "get_updates": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to filter updates from (optional)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Number of updates to retrieve (1-100, default: 10)",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "value": 0,
                    "label": "Offset",
                    "helper_text": "Offset for pagination (default: 0)",
                },
            ],
            "outputs": [
                {
                    "field": "updates",
                    "type": "string",
                    "helper_text": "Array of updates in JSON format",
                },
                {
                    "field": "messages",
                    "type": "string",
                    "helper_text": "Array of messages in JSON format",
                },
                {
                    "field": "message_count",
                    "type": "int32",
                    "helper_text": "Number of messages retrieved",
                },
                {
                    "field": "message_ids",
                    "type": "string",
                    "helper_text": "Array of message IDs in JSON format",
                },
                {
                    "field": "message_texts",
                    "type": "string",
                    "helper_text": "Array of message texts in JSON format",
                },
                {
                    "field": "sender_names",
                    "type": "string",
                    "helper_text": "Array of sender names in JSON format",
                },
                {
                    "field": "sender_usernames",
                    "type": "string",
                    "helper_text": "Array of sender usernames in JSON format",
                },
                {
                    "field": "message_dates",
                    "type": "string",
                    "helper_text": "Array of message timestamps in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_updates",
            "task_name": "tasks.telegram.get_updates",
            "description": "Get multiple updates",
            "label": "List Updates",
            "variant": "common_integration_nodes",
            "required": [],
        },
        "list_administrators": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to list administrators from",
                }
            ],
            "outputs": [
                {
                    "field": "administrators",
                    "type": "string",
                    "helper_text": "List of chat administrators in JSON format",
                },
                {
                    "field": "admin_count",
                    "type": "int32",
                    "helper_text": "Number of administrators",
                },
                {
                    "field": "admin_ids",
                    "type": "string",
                    "helper_text": "Array of administrator user IDs in JSON format",
                },
                {
                    "field": "admin_names",
                    "type": "string",
                    "helper_text": "Array of administrator names in JSON format",
                },
                {
                    "field": "admin_usernames",
                    "type": "string",
                    "helper_text": "Array of administrator usernames in JSON format",
                },
                {
                    "field": "admin_statuses",
                    "type": "string",
                    "helper_text": "Array of administrator statuses in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_administrators",
            "task_name": "tasks.telegram.list_administrators",
            "description": "Get multiple administrators in a chat",
            "label": "List Administrators",
            "variant": "common_integration_nodes",
            "required": ["chat_id"],
        },
        "get_member": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "123456789",
                    "helper_text": "ID of the user to get member details for",
                },
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user",
                },
                {
                    "field": "user_username",
                    "type": "string",
                    "helper_text": "Username of the user",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Member status (creator, administrator, member, restricted, left, kicked)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_member",
            "task_name": "tasks.telegram.get_member",
            "description": "Read details of a specific member",
            "label": "Get Member",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "user_id"],
        },
        "leave_chat": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to leave",
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "leave_chat",
            "task_name": "tasks.telegram.leave_chat",
            "description": "Leave a chat",
            "label": "Leave Chat",
            "variant": "common_integration_nodes",
            "required": ["chat_id"],
        },
        "update_description": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to update description for",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "New chat description",
                    "helper_text": "New description for the chat (0-255 characters)",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "update_description",
            "task_name": "tasks.telegram.update_description",
            "description": "Update description of a chat",
            "label": "Update Description",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "description"],
        },
        "update_title": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to update title for",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "New chat title",
                    "helper_text": "New title for the chat (1-255 characters)",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "update_title",
            "task_name": "tasks.telegram.update_title",
            "description": "Update title of a chat",
            "label": "Update Title",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "title"],
        },
        "get_file": {
            "inputs": [
                {
                    "field": "telegram_file_id",
                    "type": "string",
                    "value": "",
                    "label": "Telegram File ID",
                    "placeholder": "BAADBAADrwADBREAAYdaWKoKI4kCAg",
                    "helper_text": "File identifier to get info about",
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Identifier for this file",
                },
                {
                    "field": "file_unique_id",
                    "type": "string",
                    "helper_text": "Unique identifier for this file",
                },
                {
                    "field": "file_size",
                    "type": "int32",
                    "helper_text": "File size, if known",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "File path on Telegram servers",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "Direct download URL for the file",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "The actual file content downloaded from Telegram",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_file",
            "task_name": "tasks.telegram.get_file",
            "description": "Read details of a specific file",
            "label": "Get File",
            "variant": "common_integration_nodes",
            "required": ["file_id"],
        },
        "delete_message": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat containing the message",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123",
                    "helper_text": "ID of the message to delete",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "delete_message",
            "task_name": "tasks.telegram.delete_message",
            "description": "Delete chat message",
            "label": "Delete Message",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "message_id"],
        },
        "edit_message_text": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat containing the message",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123",
                    "helper_text": "ID of the message to edit",
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "New Text",
                    "placeholder": "Updated message text",
                    "helper_text": "New text of the message (1-4096 characters)",
                },
                {
                    "field": "parse_mode",
                    "type": "string",
                    "value": "",
                    "label": "Parse Mode",
                    "helper_text": "Mode for parsing entities in the message text",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Markdown", "value": "Markdown"},
                            {"label": "MarkdownV2", "value": "MarkdownV2"},
                            {"label": "HTML", "value": "HTML"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the edited message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "edit_message_text",
            "task_name": "tasks.telegram.edit_message_text",
            "description": "Edit the text of an existing message",
            "label": "Edit Message Text",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "message_id", "text"],
        },
        "pin_message": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat containing the message",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123",
                    "helper_text": "ID of the message to pin",
                },
                {
                    "field": "disable_notification",
                    "type": "bool",
                    "value": False,
                    "label": "Disable Notification",
                    "helper_text": "Pass true if it is not necessary to send a notification to all chat members about the new pinned message",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "pin_message",
            "task_name": "tasks.telegram.pin_message",
            "description": "Pin message in the chat",
            "label": "Pin Message",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "message_id"],
        },
        "send_animation": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send animation to",
                },
                {
                    "field": "animation",
                    "type": "string",
                    "value": "",
                    "label": "Animation",
                    "placeholder": "https://example.com/animation.gif",
                    "helper_text": "Animation to send (file_id, HTTP URL, or file path)",
                },
                {
                    "field": "caption",
                    "type": "string",
                    "value": "",
                    "label": "Caption",
                    "placeholder": "Animation caption",
                    "helper_text": "Animation caption (0-1024 characters, optional)",
                },
                {
                    "field": "parse_mode",
                    "type": "string",
                    "value": "",
                    "label": "Parse Mode",
                    "helper_text": "Mode for parsing entities in the caption",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Markdown", "value": "Markdown"},
                            {"label": "MarkdownV2", "value": "MarkdownV2"},
                            {"label": "HTML", "value": "HTML"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_animation",
            "task_name": "tasks.telegram.send_animation",
            "description": "Send animation to the chat",
            "label": "Send Animation",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "animation"],
        },
        "send_audio": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send audio to",
                },
                {
                    "field": "audio",
                    "type": "string",
                    "value": "",
                    "label": "Audio",
                    "placeholder": "https://example.com/audio.mp3",
                    "helper_text": "Audio file to send (file_id, HTTP URL, or file path)",
                },
                {
                    "field": "caption",
                    "type": "string",
                    "value": "",
                    "label": "Caption",
                    "placeholder": "Audio caption",
                    "helper_text": "Audio caption (0-1024 characters, optional)",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Duration",
                    "helper_text": "Duration of the audio in seconds (optional)",
                },
                {
                    "field": "performer",
                    "type": "string",
                    "value": "",
                    "label": "Performer",
                    "placeholder": "Artist name",
                    "helper_text": "Performer of the audio (optional)",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Track title",
                    "helper_text": "Track name of the audio (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_audio",
            "task_name": "tasks.telegram.send_audio",
            "description": "Send audio file to the chat and display it in the music player",
            "label": "Send Audio",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "audio"],
        },
        "send_document": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send document to",
                },
                {
                    "field": "document",
                    "type": "string",
                    "value": "",
                    "label": "Document",
                    "placeholder": "https://example.com/document.pdf",
                    "helper_text": "Document to send (file_id, HTTP URL, or file path)",
                },
                {
                    "field": "caption",
                    "type": "string",
                    "value": "",
                    "label": "Caption",
                    "placeholder": "Document caption",
                    "helper_text": "Document caption (0-1024 characters, optional)",
                },
                {
                    "field": "parse_mode",
                    "type": "string",
                    "value": "",
                    "label": "Parse Mode",
                    "helper_text": "Mode for parsing entities in the caption",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Markdown", "value": "Markdown"},
                            {"label": "MarkdownV2", "value": "MarkdownV2"},
                            {"label": "HTML", "value": "HTML"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_document",
            "task_name": "tasks.telegram.send_document",
            "description": "Send document to the chat",
            "label": "Send Document",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "document"],
        },
        "send_location": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send location to",
                },
                {
                    "field": "latitude",
                    "type": "string",
                    "value": "",
                    "label": "Latitude",
                    "placeholder": "40.7128",
                    "helper_text": "Latitude of the location",
                },
                {
                    "field": "longitude",
                    "type": "string",
                    "value": "",
                    "label": "Longitude",
                    "placeholder": "-74.0060",
                    "helper_text": "Longitude of the location",
                },
                {
                    "field": "live_period",
                    "type": "int32",
                    "value": 0,
                    "label": "Live Period",
                    "helper_text": "Period in seconds for which the location will be updated (60-86400, optional)",
                },
                {
                    "field": "heading",
                    "type": "int32",
                    "value": 0,
                    "label": "Heading",
                    "helper_text": "Direction in which the user is moving (1-360 degrees, optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_location",
            "task_name": "tasks.telegram.send_location",
            "description": "Send a geolocation to the chat",
            "label": "Send Location",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "latitude", "longitude"],
        },
        "send_media_group": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send media group to",
                },
                {
                    "field": "media",
                    "type": "string",
                    "value": "[]",
                    "label": "Media",
                    "placeholder": '[{"type":"photo","media":"https://example.com/photo.jpg"}]',
                    "helper_text": "JSON array of InputMedia objects (2-10 items). Send with type(type of media) and value(url) keys.",
                },
            ],
            "outputs": [
                {
                    "field": "message_ids",
                    "type": "string",
                    "helper_text": "Array of message IDs in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_media_group",
            "task_name": "tasks.telegram.send_media_group",
            "description": "Send a group of photos and/or videos",
            "label": "Send Media Group",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "media"],
        },
        "send_message": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send message to",
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Message",
                    "placeholder": "Hello World!",
                    "helper_text": "Text of the message to be sent (1-4096 characters)",
                },
                {
                    "field": "parse_mode",
                    "type": "string",
                    "value": "",
                    "label": "Parse Mode",
                    "helper_text": "Mode for parsing entities in the message text",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Markdown", "value": "Markdown"},
                            {"label": "MarkdownV2", "value": "MarkdownV2"},
                            {"label": "HTML", "value": "HTML"},
                        ],
                    },
                },
                {
                    "field": "disable_web_page_preview",
                    "type": "bool",
                    "value": False,
                    "label": "Disable Web Page Preview",
                    "helper_text": "Disables link previews for links in this message",
                },
                {
                    "field": "disable_notification",
                    "type": "bool",
                    "value": False,
                    "label": "Disable Notification",
                    "helper_text": "Sends the message silently",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "message_text",
                    "type": "string",
                    "helper_text": "Text of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_message",
            "task_name": "tasks.telegram.send_message",
            "description": "Send message to the chat",
            "label": "Send Message",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "text"],
        },
        "send_photo": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send photo to",
                },
                {
                    "field": "photo",
                    "type": "string",
                    "value": "",
                    "label": "Photo",
                    "placeholder": "https://example.com/photo.jpg",
                    "helper_text": "Photo to send (file_id, HTTP URL, or file path)",
                },
                {
                    "field": "caption",
                    "type": "string",
                    "value": "",
                    "label": "Caption",
                    "placeholder": "Photo caption",
                    "helper_text": "Photo caption (0-1024 characters, optional)",
                },
                {
                    "field": "parse_mode",
                    "type": "string",
                    "value": "",
                    "label": "Parse Mode",
                    "helper_text": "Mode for parsing entities in the caption",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Markdown", "value": "Markdown"},
                            {"label": "MarkdownV2", "value": "MarkdownV2"},
                            {"label": "HTML", "value": "HTML"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_photo",
            "task_name": "tasks.telegram.send_photo",
            "description": "Send photo to the chat",
            "label": "Send Photo",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "photo"],
        },
        "send_sticker": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send sticker to",
                },
                {
                    "field": "sticker",
                    "type": "string",
                    "value": "",
                    "label": "Sticker",
                    "placeholder": "CAACAgIAAxkBAAICGmG...",
                    "helper_text": "Sticker to send (file_id, HTTP URL, or file path)",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_sticker",
            "task_name": "tasks.telegram.send_sticker",
            "description": "Send sticker to the chat",
            "label": "Send Sticker",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "sticker"],
        },
        "send_video": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat to send video to",
                },
                {
                    "field": "video",
                    "type": "string",
                    "value": "",
                    "label": "Video",
                    "placeholder": "https://example.com/video.mp4",
                    "helper_text": "Video to send (file_id, HTTP URL, or file path)",
                },
                {
                    "field": "caption",
                    "type": "string",
                    "value": "",
                    "label": "Caption",
                    "placeholder": "Video caption",
                    "helper_text": "Video caption (0-1024 characters, optional)",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "value": 0,
                    "label": "Duration",
                    "helper_text": "Duration of the video in seconds (optional)",
                },
                {
                    "field": "width",
                    "type": "int32",
                    "value": 0,
                    "label": "Width",
                    "helper_text": "Video width (optional)",
                },
                {
                    "field": "height",
                    "type": "int32",
                    "value": 0,
                    "label": "Height",
                    "helper_text": "Video height (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_video",
            "task_name": "tasks.telegram.send_video",
            "description": "Send video to the chat",
            "label": "Send Video",
            "variant": "common_integration_nodes",
            "required": ["chat_id", "video"],
        },
        "unpin_message": {
            "inputs": [
                {
                    "field": "chat_id",
                    "type": "string",
                    "value": "",
                    "label": "Chat ID",
                    "placeholder": "-1001234567890",
                    "helper_text": "ID of the chat containing the message",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123",
                    "helper_text": "ID of the message to unpin (optional, if not specified, the most recent pinned message will be unpinned)",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "unpin_message",
            "task_name": "tasks.telegram.unpin_message",
            "description": "Unpin message from the chat",
            "label": "Unpin Message",
            "variant": "common_integration_nodes",
            "required": ["chat_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        text: str = "",
        animation: str = "",
        audio: str = "",
        caption: str = "",
        chat_id: str = "",
        description: str = "",
        disable_notification: bool = False,
        disable_web_page_preview: bool = False,
        document: str = "",
        duration: int = 0,
        heading: int = 0,
        height: int = 0,
        latitude: str = "",
        limit: int = 10,
        live_period: int = 0,
        longitude: str = "",
        media: str = "[]",
        message_id: str = "",
        offset: int = 0,
        parse_mode: str = "",
        performer: str = "",
        photo: str = "",
        sticker: str = "",
        telegram_file_id: str = "",
        title: str = "",
        user_id: str = "",
        video: str = "",
        width: int = 0,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_telegram",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if chat_id is not None:
            self.inputs["chat_id"] = chat_id
        if limit is not None:
            self.inputs["limit"] = limit
        if offset is not None:
            self.inputs["offset"] = offset
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if description is not None:
            self.inputs["description"] = description
        if title is not None:
            self.inputs["title"] = title
        if telegram_file_id is not None:
            self.inputs["telegram_file_id"] = telegram_file_id
        if message_id is not None:
            self.inputs["message_id"] = message_id
        if text is not None:
            self.inputs["text"] = text
        if parse_mode is not None:
            self.inputs["parse_mode"] = parse_mode
        if disable_notification is not None:
            self.inputs["disable_notification"] = disable_notification
        if animation is not None:
            self.inputs["animation"] = animation
        if caption is not None:
            self.inputs["caption"] = caption
        if audio is not None:
            self.inputs["audio"] = audio
        if duration is not None:
            self.inputs["duration"] = duration
        if performer is not None:
            self.inputs["performer"] = performer
        if document is not None:
            self.inputs["document"] = document
        if latitude is not None:
            self.inputs["latitude"] = latitude
        if longitude is not None:
            self.inputs["longitude"] = longitude
        if live_period is not None:
            self.inputs["live_period"] = live_period
        if heading is not None:
            self.inputs["heading"] = heading
        if media is not None:
            self.inputs["media"] = media
        if disable_web_page_preview is not None:
            self.inputs["disable_web_page_preview"] = disable_web_page_preview
        if photo is not None:
            self.inputs["photo"] = photo
        if sticker is not None:
            self.inputs["sticker"] = sticker
        if video is not None:
            self.inputs["video"] = video
        if width is not None:
            self.inputs["width"] = width
        if height is not None:
            self.inputs["height"] = height
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationTelegramNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
