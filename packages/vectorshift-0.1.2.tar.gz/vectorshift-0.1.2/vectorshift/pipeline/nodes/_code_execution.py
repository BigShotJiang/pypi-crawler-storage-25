"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import NameType, NameTypeValueAny


@Node.register_node_type("code_execution")
class CodeExecutionNode(Node):
    """
    Execute code in the language of your choice.

    ## Inputs
    ### Common Inputs
        [processed_inputs]: The [processed_inputs] input
        code: The Python code to execute
        function_name: Name of the Python function to execute
        input_schema: Schema defining the input parameters
        language: Programming language (0 = Python)
        output_schema: Schema defining the output parameters
        processed_inputs: Dynamic inputs generated from input schema
        processed_outputs: Dynamic outputs generated from output schema

    ## Outputs
    ### Common Outputs
        [processed_outputs]: The [processed_outputs] output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "[processed_inputs]",
            "helper_text": "The [processed_inputs] input",
            "value": None,
            "type": "",
        },
        {
            "field": "code",
            "helper_text": "The Python code to execute",
            "value": 'def main(input_0):\n\t"""\n\tDescription:\n\tInputs:\n\t\tinput_0: Any\n\tOutputs:\n\t\toutput_0: Any\n\t"""\n\t\n\t\n\toutput_0 = input_0\n\treturn {\'output_0\': output_0}',
            "type": "string",
        },
        {
            "field": "function_name",
            "helper_text": "Name of the Python function to execute",
            "value": "main",
            "type": "string",
        },
        {
            "field": "input_schema",
            "helper_text": "Schema defining the input parameters",
            "value": [{"id": "input_0", "name": "input_0", "type": "any", "value": ""}],
            "type": "vec<interface{id: string, name: string, type: string, value: any}>",
        },
        {
            "field": "language",
            "helper_text": "Programming language (0 = Python)",
            "value": 0,
            "type": "enum<int32>",
        },
        {
            "field": "output_schema",
            "helper_text": "Schema defining the output parameters",
            "value": [{"id": "output_0", "name": "output_0", "type": "any"}],
            "type": "vec<interface{id: string, name: string, type: string}>",
        },
        {
            "field": "processed_inputs",
            "helper_text": "Dynamic inputs generated from input schema",
            "value": {"input_0": "any"},
            "type": "map<string, string>",
        },
        {
            "field": "processed_outputs",
            "helper_text": "Dynamic outputs generated from output schema",
            "value": {"output_0": "any"},
            "type": "map<string, string>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "[processed_outputs]",
            "helper_text": "The [processed_outputs] output",
            "type": "",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = ["code"]

    def __init__(
        self,
        code: str = '''def main(input_0):
    """
    Description:
    Inputs:
        input_0: Any
    Outputs:
        output_0: Any
    """


    output_0 = input_0
    return {'output_0': output_0}''',
        function_name: str = "main",
        input_schema: List[NameTypeValueAny] = [
            {"id": "input_0", "name": "input_0", "type": "any", "value": ""}
        ],
        language: int = 0,
        output_schema: List[NameType] = [
            {"id": "output_0", "name": "output_0", "type": "any"}
        ],
        processed_inputs: Dict[str, str] = {"input_0": "any"},
        processed_outputs: Dict[str, str] = {"output_0": "any"},
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="code_execution",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if input_schema is not None:
            self.inputs["input_schema"] = input_schema
        if output_schema is not None:
            self.inputs["output_schema"] = output_schema
        if processed_inputs is not None:
            self.inputs["processed_inputs"] = processed_inputs
        if processed_outputs is not None:
            self.inputs["processed_outputs"] = processed_outputs
        if function_name is not None:
            self.inputs["function_name"] = function_name
        if code is not None:
            self.inputs["code"] = code
        if language is not None:
            self.inputs["language"] = language
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CodeExecutionNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
