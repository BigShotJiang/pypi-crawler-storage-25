"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_pinecone")
class IntegrationPineconeNode(Node):
    """
    Pinecone

    ## Inputs
    ### Common Inputs
        action: Select the Pinecone operation to perform
        integration: Connect to your Pinecone account
    ### retrieve_documents
        query: Vector values as JSON array to query for similar vectors
        filter: JSON filter to apply to metadata (optional)
        include_metadata: Include metadata in the response
        include_values: Include vector values in the response
        index: The Pinecone index to query
        limit: Maximum number of vectors to return
        namespace: Select the namespace to query (queries across all namespaces if left empty)
    ### query_pinecone
        query: Vector values as JSON array to query for similar vectors
        embedding_model: Select the embedding model to use to embed the query
        index: The Pinecone index to query
        namespace: Select the namespace to query (queries across all namespaces if left empty)
    ### insert_documents
        batch_size: Number of vectors to upsert in each batch
        index: The Pinecone index to query
        namespace: Select the namespace to query (queries across all namespaces if left empty)
        vectors: JSON array of vectors to insert with id, values, and optional metadata
    ### update_documents
        id: ID of the vector to update
        index: The Pinecone index to query
        metadata: New metadata as JSON object (optional)
        namespace: Select the namespace to query (queries across all namespaces if left empty)
        set_metadata: Replace all metadata (true) or merge with existing (false)
        values: New vector values as JSON array (optional)
    ### get_vector
        id: ID of the vector to update
        include_metadata: Include metadata in the response
        include_values: Include vector values in the response
        index: The Pinecone index to query
        namespace: Select the namespace to query (queries across all namespaces if left empty)
    ### list_vectors
        ids: List of vector IDs to retrieve (required - Pinecone doesn't support listing all vectors)
        include_metadata: Include metadata in the response
        include_values: Include vector values in the response
        index: The Pinecone index to query
        limit: Maximum number of vectors to return
        namespace: Select the namespace to query (queries across all namespaces if left empty)

    ## Outputs
    ### list_vectors
        count: Number of vectors retrieved
        ids_list: List of vector IDs
        metadata_list: List of metadata objects for each vector
        raw_data: Raw JSON response from Pinecone
    ### retrieve_documents
        count: Number of matches returned
        matches: Similar vectors found with scores and metadata
        raw_data: Raw JSON response from Pinecone
    ### get_vector
        found: Whether the vector was found
        metadata: Vector metadata as JSON object
        raw_data: Raw JSON response from Pinecone
        values: Vector values as JSON array
        vector: Retrieved vector with metadata and values
    ### query_pinecone
        output: Query output in Langchain-style documents
        raw_data: Raw JSON response from Pinecone
    ### insert_documents
        raw_data: Raw response from Pinecone
        upserted_count: Number of vectors successfully upserted
    ### update_documents
        raw_data: Raw response from Pinecone
        updated_id: ID of the updated vector
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the Pinecone operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Pinecone account",
            "value": None,
            "type": "integration<Pinecone>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "list_vectors": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "helper_text": "The Pinecone index to query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "namespace",
                    "type": "string",
                    "value": "",
                    "label": "Namespace",
                    "helper_text": "Select the namespace to query (queries across all namespaces if left empty)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=namespace&index={inputs.index}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "ids",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Vector IDs",
                    "helper_text": "List of vector IDs to retrieve (required - Pinecone doesn't support listing all vectors)",
                },
                {
                    "field": "include_values",
                    "type": "bool",
                    "value": True,
                    "label": "Include Values",
                    "helper_text": "Include vector values in the response",
                },
                {
                    "field": "include_metadata",
                    "type": "bool",
                    "value": True,
                    "label": "Include Metadata",
                    "helper_text": "Include metadata in the response",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of vectors to return",
                },
            ],
            "outputs": [
                {
                    "field": "metadata_list",
                    "type": "vec<interface>",
                    "helper_text": "List of metadata objects for each vector",
                },
                {
                    "field": "ids_list",
                    "type": "vec<interface>",
                    "helper_text": "List of vector IDs",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of vectors retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Pinecone",
                },
            ],
            "name": "list_vectors",
            "task_name": "tasks.pinecone.list_vectors",
            "description": "Get multiple vectors",
            "label": "List Vectors",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "index",
                "namespace",
                "ids",
                "include_values",
                "include_metadata",
                "limit",
            ],
            "required": ["index", "ids", "limit"],
        },
        "insert_documents": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "helper_text": "The Pinecone index to insert into",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "namespace",
                    "type": "string",
                    "value": "",
                    "label": "Namespace",
                    "helper_text": "Select the namespace to insert into (uses default namespace if left empty)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=namespace&index={inputs.index}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "vectors",
                    "type": "string",
                    "value": "",
                    "label": "Vectors Data",
                    "placeholder": '[{"id": "vec1", "values": [0.1, 0.2], "metadata": {"text": "document"}}]',
                    "helper_text": "JSON array of vectors to insert with id, values, and optional metadata",
                },
                {
                    "field": "batch_size",
                    "type": "int32",
                    "value": 100,
                    "label": "Batch Size",
                    "helper_text": "Number of vectors to upsert in each batch",
                },
            ],
            "outputs": [
                {
                    "field": "upserted_count",
                    "type": "int32",
                    "helper_text": "Number of vectors successfully upserted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Pinecone",
                },
            ],
            "name": "insert_documents",
            "task_name": "tasks.pinecone.insert_documents",
            "description": "Insert or update vectors in a Pinecone index",
            "label": "Insert Documents",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "index",
                "namespace",
                "vectors",
                "batch_size",
            ],
            "required": ["index", "vectors"],
        },
        "retrieve_documents": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "helper_text": "The Pinecone index to query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "namespace",
                    "type": "string",
                    "value": "",
                    "label": "Namespace",
                    "helper_text": "Select the namespace to query (queries across all namespaces if left empty)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=namespace&index={inputs.index}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query Vector",
                    "placeholder": "[0.1, 0.2, 0.3, ...]",
                    "helper_text": "Vector values as JSON array to query for similar vectors",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of similar vectors to return",
                },
                {
                    "field": "include_values",
                    "type": "bool",
                    "value": False,
                    "label": "Include Values",
                    "helper_text": "Include vector values in the response",
                },
                {
                    "field": "include_metadata",
                    "type": "bool",
                    "value": True,
                    "label": "Include Metadata",
                    "helper_text": "Include metadata in the response",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Metadata Filter",
                    "placeholder": '{"category": "document"}',
                    "helper_text": "JSON filter to apply to metadata (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "matches",
                    "type": "vec<string>",
                    "helper_text": "Similar vectors found with scores and metadata",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of matches returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Pinecone",
                },
            ],
            "name": "retrieve_documents",
            "task_name": "tasks.pinecone.retrieve_documents",
            "description": "Get multiple documents",
            "label": "List Documents",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "index",
                "namespace",
                "query",
                "limit",
                "include_values",
                "include_metadata",
                "filter",
            ],
            "required": ["index", "query", "limit"],
        },
        "update_documents": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "helper_text": "The Pinecone index to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "namespace",
                    "type": "string",
                    "value": "",
                    "label": "Namespace",
                    "helper_text": "Select the namespace to update (uses default namespace if left empty)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=namespace&index={inputs.index}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "id",
                    "type": "string",
                    "value": "",
                    "label": "Vector ID",
                    "helper_text": "ID of the vector to update",
                },
                {
                    "field": "values",
                    "type": "string",
                    "value": "",
                    "label": "New Values",
                    "placeholder": "[0.1, 0.2, 0.3, ...]",
                    "helper_text": "New vector values as JSON array (optional)",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "value": "",
                    "label": "New Metadata",
                    "placeholder": '{"text": "updated document", "category": "new"}',
                    "helper_text": "New metadata as JSON object (optional)",
                },
                {
                    "field": "set_metadata",
                    "type": "bool",
                    "value": False,
                    "label": "Set Metadata",
                    "helper_text": "Replace all metadata (true) or merge with existing (false)",
                },
            ],
            "outputs": [
                {
                    "field": "updated_id",
                    "type": "string",
                    "helper_text": "ID of the updated vector",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Pinecone",
                },
            ],
            "name": "update_documents",
            "task_name": "tasks.pinecone.update_documents",
            "description": "Update vector values or metadata in a Pinecone index",
            "label": "Update Documents",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "index",
                "namespace",
                "id",
                "values",
                "metadata",
                "set_metadata",
            ],
            "required": ["index", "id"],
        },
        "get_vector": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "helper_text": "The Pinecone index to query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "namespace",
                    "type": "string",
                    "value": "",
                    "label": "Namespace",
                    "helper_text": "Select the namespace to query (queries across all namespaces if left empty)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=namespace&index={inputs.index}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "id",
                    "type": "string",
                    "value": "",
                    "label": "Vector ID",
                    "helper_text": "ID of the vector to retrieve",
                },
                {
                    "field": "include_values",
                    "type": "bool",
                    "value": True,
                    "label": "Include Values",
                    "helper_text": "Include vector values in the response",
                },
                {
                    "field": "include_metadata",
                    "type": "bool",
                    "value": True,
                    "label": "Include Metadata",
                    "helper_text": "Include metadata in the response",
                },
            ],
            "outputs": [
                {
                    "field": "vector",
                    "type": "string",
                    "helper_text": "Retrieved vector with metadata and values",
                },
                {
                    "field": "values",
                    "type": "string",
                    "helper_text": "Vector values as JSON array",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "helper_text": "Vector metadata as JSON object",
                },
                {
                    "field": "found",
                    "type": "bool",
                    "helper_text": "Whether the vector was found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Pinecone",
                },
            ],
            "name": "get_vector",
            "task_name": "tasks.pinecone.get_vector",
            "description": "Read details of a specific vector",
            "label": "Get Vector",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "index",
                "namespace",
                "id",
                "include_values",
                "include_metadata",
            ],
            "required": ["index", "id"],
        },
        "query_pinecone": {
            "inputs": [
                {
                    "field": "embedding_model",
                    "type": "string",
                    "value": "",
                    "label": "Embedding Model",
                    "helper_text": "Select the embedding model to use to embed the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {
                                "label": "OpenAI Text Embedding 3 Small",
                                "value": "openai/text-embedding-3-small",
                            },
                            {
                                "label": "OpenAI Text Embedding 3 Large",
                                "value": "openai/text-embedding-3-large",
                            },
                            {
                                "label": "OpenAI Text Embedding Ada 002",
                                "value": "openai/text-embedding-ada-002",
                            },
                            {
                                "label": "Cohere Embed English v3.0",
                                "value": "cohere/embed-english-v3.0",
                            },
                            {
                                "label": "Cohere Embed Multilingual v3.0",
                                "value": "cohere/embed-multilingual-v3.0",
                            },
                            {
                                "label": "Cohere Embed English Light v3.0",
                                "value": "cohere/embed-english-light-v3.0",
                            },
                            {
                                "label": "Cohere Embed Multilingual Light v3.0",
                                "value": "cohere/embed-multilingual-light-v3.0",
                            },
                        ],
                    },
                },
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "helper_text": "The Pinecone index to query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "namespace",
                    "type": "string",
                    "value": "",
                    "label": "Namespace",
                    "helper_text": "Select the namespace to query (queries across all namespaces if left empty)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=namespace&index={inputs.index}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "Birthday parties in March",
                    "helper_text": "Natural Language query",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<string>",
                    "helper_text": "Query output in Langchain-style documents",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Pinecone",
                },
            ],
            "name": "query_pinecone",
            "task_name": "tasks.vectordbs.integrations.pinecone.query",
            "description": "Query Pinecone data",
            "label": "Query Pinecone",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "embedding_model",
                "index",
                "namespace",
                "query",
            ],
            "required": ["index", "query"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        batch_size: int = 100,
        embedding_model: str = "",
        filter: str = "",
        ids: List[str] = [],
        include_metadata: bool = True,
        include_values: bool = True,
        index: str = "",
        limit: int = 10,
        metadata: str = "",
        namespace: str = "",
        set_metadata: bool = False,
        values: str = "",
        vectors: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_pinecone",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if index is not None:
            self.inputs["index"] = index
        if namespace is not None:
            self.inputs["namespace"] = namespace
        if ids is not None:
            self.inputs["ids"] = ids
        if include_values is not None:
            self.inputs["include_values"] = include_values
        if include_metadata is not None:
            self.inputs["include_metadata"] = include_metadata
        if limit is not None:
            self.inputs["limit"] = limit
        if vectors is not None:
            self.inputs["vectors"] = vectors
        if batch_size is not None:
            self.inputs["batch_size"] = batch_size
        if query is not None:
            self.inputs["query"] = query
        if filter is not None:
            self.inputs["filter"] = filter
        if id is not None:
            self.inputs["id"] = id
        if values is not None:
            self.inputs["values"] = values
        if metadata is not None:
            self.inputs["metadata"] = metadata
        if set_metadata is not None:
            self.inputs["set_metadata"] = set_metadata
        if embedding_model is not None:
            self.inputs["embedding_model"] = embedding_model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationPineconeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
