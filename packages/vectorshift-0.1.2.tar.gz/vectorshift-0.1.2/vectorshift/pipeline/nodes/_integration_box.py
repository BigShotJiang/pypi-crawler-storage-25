"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_box")
class IntegrationBoxNode(Node):
    """
    Box

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### search_files
        query: Search query to find files
        file_extensions: Filter by file extensions (optional)
        folder_id: Select the Folder to upload files to
        limit: Maximum number of results to return (default: 10)
        offset: Number of records to skip from the start. Must be a multiple of the limit value (e.g., if limit is 6, valid offsets are 0, 6, 12, ...)
    ### search_files_and_folders
        query: Search query to find files
        file_extensions: Filter by file extensions (optional)
        folder_id: Select the Folder to upload files to
        limit: Maximum number of results to return (default: 10)
        offset: Number of records to skip from the start. Must be a multiple of the limit value (e.g., if limit is 6, valid offsets are 0, 6, 12, ...)
        type: Type of item to search for
    ### share_file
        access: Access level for the shared link
        can_download: Whether users can download the file
        can_preview: Whether users can preview the file
        file_id: Select the file to copy
    ### share_folder
        access: Access level for the shared link
        can_download: Whether users can download the file
        can_preview: Whether users can preview the file
        folder_id: Select the Folder to upload files to
    ### update_folder
        description: Description for the folder (optional)
        folder_id: Select the Folder to upload files to
        new_name: Name for the copied file (optional)
    ### copy_file
        destination_folder_id: Select the destination folder
        file_id: Select the file to copy
        new_name: Name for the copied file (optional)
    ### delete_file
        file_id: Select the file to copy
    ### download_file
        file_id: Select the file to copy
    ### read_file
        file_id: Select the file to copy
    ### upload_files
        files: The number of files to be appended. Files will be appended in successive fashion (e.g., file-1 first, then file-2, etc.)
        folder_id: Select the Folder to upload files to
    ### read_folder
        folder_id: Select the Folder to upload files to
    ### delete_folder
        folder_id: Select the Folder to upload files to
        recursive: Delete folder and all its contents (use with caution)
    ### create_folder
        folder_name: Name of the folder to create
        parent_folder_id: Select the parent folder where the new folder will be created

    ## Outputs
    ### share_file
        access_level: Access level of the shared link
        permissions: Permissions for the shared link
        raw_data: Raw API response data from Box
        shared_link: The shared link URL
    ### share_folder
        access_level: Access level of the shared link
        permissions: Permissions for the shared link
        raw_data: Raw API response data from Box
        shared_link: The shared link URL
    ### download_file
        created_at: File creation timestamp
        creator_email: Email of the file creator
        creator_name: Name of the file creator
        file_content: Downloaded file content
        file_id: Box file ID
        file_name: Name of the downloaded file
        file_size: Size of the downloaded file
        file_url: URL to access the downloaded file
        last_editor_email: Email of the last editor
        last_editor_name: Name of the last editor
        mime_type: MIME type of the downloaded file
        modified_at: File last modified timestamp
        owner_email: Email of the file owner
        owner_name: Name of the file owner
        parent_folder_id: ID of the parent folder
        parent_folder_name: Name of the parent folder
        raw_data: Raw API response data from Box
    ### read_file
        created_at: When the file was created
        creator_email: Email of the file creator
        creator_name: Name of the file creator
        file_id: ID of the file
        file_name: Name of the file
        file_size: Size of the file
        file_url: URL to access the file
        last_editor_email: Email of the last editor
        last_editor_name: Name of the last editor
        mime_type: MIME type of the file
        modified_at: When the file was last modified
        owner_email: Email of the file owner
        owner_name: Name of the file owner
        parent_folder_id: ID of the parent folder
        parent_folder_name: Name of the parent folder
        raw_data: Raw API response data from Box
    ### create_folder
        created_at: When the folder was created
        folder_id: ID of the created folder
        folder_name: Name of the created folder
        folder_url: URL to access the created folder
        raw_data: Raw API response data from Box
    ### read_folder
        created_at: When the folder was created
        folder_id: ID of the folder
        folder_name: Name of the folder
        folder_url: URL to access the folder
        item_count: Number of items in the folder
        modified_at: When the folder was last modified
        owner_email: Email of the folder owner
        owner_name: Name of the folder owner
        parent_folder_id: ID of the parent folder
        raw_data: Raw API response data from Box
    ### upload_files
        created_dates: Array of creation timestamps
        file_ids: Array of IDs of uploaded files
        file_names: Array of names of uploaded files
        file_sizes: Array of file sizes in bytes
        file_urls: Array of URLs to access uploaded files
        modified_dates: Array of modification timestamps
        raw_data: Raw API response data from Box
        total_count: Total number of files uploaded
    ### search_files
        created_dates: List of file creation timestamps
        file_ids: List of file IDs
        file_names: List of file names
        file_types: List of file types
        file_urls: List of file URLs
        files: List of found files with detailed information (legacy format)
        modified_dates: List of file modification timestamps
        owner_emails: List of file owner emails
        owner_names: List of file owner names
        parent_folder_ids: List of parent folder IDs
        raw_data: Raw API response data from Box
        total_count: Total number of files found
    ### search_files_and_folders
        created_dates: List of item creation timestamps
        item_ids: List of item IDs
        item_names: List of item names
        item_types: List of item types
        item_urls: List of item URLs
        items: List of found items with detailed information
        modified_dates: List of item modification timestamps
        owner_emails: List of item owner emails
        owner_names: List of item owner names
        parent_folder_ids: List of parent folder IDs
        raw_data: Raw API response data from Box
        total_count: Total number of items found
    ### update_folder
        description: Description of the updated folder
        folder_id: ID of the updated folder
        folder_name: Name of the updated folder
        modified_at: When the folder was last modified
        raw_data: Raw API response data from Box
    ### copy_file
        file_id: ID of the copied file
        file_name: Name of the copied file
        file_url: URL to access the copied file
        raw_data: Raw API response data from Box
    ### delete_file
        message: Deletion result message
        raw_data: Raw API response data from Box
    ### delete_folder
        message: Deletion result message
        raw_data: Raw API response data from Box
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Box>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "upload_files": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the Folder to upload files to",
                    "agent_helper_text": "The actual numeric folder ID of the destination folder. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "files",
                    "type": "vec<file>",
                    "value": [""],
                    "label": "Files",
                    "placeholder": "Files",
                    "helper_text": "The number of files to be appended. Files will be appended in successive fashion (e.g., file-1 first, then file-2, etc.)",
                },
            ],
            "outputs": [
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of IDs of uploaded files",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Array of names of uploaded files",
                },
                {
                    "field": "file_sizes",
                    "type": "vec<string>",
                    "helper_text": "Array of file sizes in bytes",
                },
                {
                    "field": "file_urls",
                    "type": "vec<string>",
                    "helper_text": "Array of URLs to access uploaded files",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of creation timestamps",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of modification timestamps",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of files uploaded",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "upload_files",
            "task_name": "tasks.box.upload_files",
            "description": "Upload files to Box",
            "agent_helper_text": "Use this tool when you have file content or data that needs to be placed into a Box folder. The file data may come from a Download File action, from another integration, or from a pipeline. This tool requires actual file content as input (the 'files' field). If the user explicitly asks to download a file and then upload it to a folder, use Download File followed by this tool.",
            "label": "Upload files",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "folder_id", "files"],
            "required": ["folder_id", "files"],
        },
        "copy_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to copy",
                    "agent_helper_text": "The actual numeric file ID of the file to copy. NEVER use {user_vs_object}, the integration/account value, or a file name here. If the user only provides a file name, you MUST first call 'Search Files' (search_files) with the file name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination Folder",
                    "helper_text": "Select the destination folder",
                    "agent_helper_text": "The actual numeric folder ID of the destination folder. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "label": "New Name (Optional)",
                    "placeholder": "Leave empty to keep original name",
                    "helper_text": "Name for the copied file (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the copied file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the copied file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL to access the copied file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "copy_file",
            "task_name": "tasks.box.copy_file",
            "description": "Copy a file to another location",
            "agent_helper_text": "Use this tool when the user asks to copy, duplicate, or move a file from one Box folder to another. This operates entirely within Box using file IDs — no file content passes through. Optionally provide a new name for the copied file. Do NOT use this tool when the user explicitly asks to download a file and then upload it — in that case, use Download File followed by Upload Files instead.",
            "label": "Copy File",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "file_id",
                "destination_folder_id",
                "new_name",
            ],
            "required": ["file_id", "destination_folder_id"],
        },
        "delete_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to delete",
                    "agent_helper_text": "The actual numeric file ID of the file to delete. NEVER use {user_vs_object}, the integration/account value, or a file name here. If the user only provides a file name, you MUST first call 'Search Files' (search_files) with the file name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion result message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "delete_file",
            "task_name": "tasks.box.delete_file",
            "description": "Delete a file from Box",
            "label": "Delete File",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "download_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to download",
                    "agent_helper_text": "The actual numeric file ID of the file to download. NEVER use {user_vs_object}, the integration/account value, or a file name here. If the user only provides a file name, you MUST first call 'Search Files' (search_files) with the file name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {"field": "file_id", "type": "string", "helper_text": "Box file ID"},
                {
                    "field": "file_content",
                    "type": "file",
                    "helper_text": "Downloaded file content",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the downloaded file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the downloaded file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the downloaded file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL to access the downloaded file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "File creation timestamp",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "File last modified timestamp",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "parent_folder_name",
                    "type": "string",
                    "helper_text": "Name of the parent folder",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the file owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the file owner",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the file creator",
                },
                {
                    "field": "creator_email",
                    "type": "string",
                    "helper_text": "Email of the file creator",
                },
                {
                    "field": "last_editor_name",
                    "type": "string",
                    "helper_text": "Name of the last editor",
                },
                {
                    "field": "last_editor_email",
                    "type": "string",
                    "helper_text": "Email of the last editor",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "download_file",
            "task_name": "tasks.box.download_file",
            "description": "Download a file from Box",
            "label": "Download File",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "read_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to read information about",
                    "agent_helper_text": "The actual numeric file ID of the file to read. NEVER use {user_vs_object}, the integration/account value, or a file name here. If the user only provides a file name, you MUST first call 'Search Files' (search_files) with the file name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {"field": "file_id", "type": "string", "helper_text": "ID of the file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL to access the file",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "parent_folder_name",
                    "type": "string",
                    "helper_text": "Name of the parent folder",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the file owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the file owner",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the file creator",
                },
                {
                    "field": "creator_email",
                    "type": "string",
                    "helper_text": "Email of the file creator",
                },
                {
                    "field": "last_editor_name",
                    "type": "string",
                    "helper_text": "Name of the last editor",
                },
                {
                    "field": "last_editor_email",
                    "type": "string",
                    "helper_text": "Email of the last editor",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "read_file",
            "task_name": "tasks.box.read_file",
            "description": "Read details of a specific file",
            "label": "Get File",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "search_files": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "Enter search terms",
                    "helper_text": "Search query to find files",
                },
                {
                    "field": "file_extensions",
                    "type": "vec<string>",
                    "value": [],
                    "label": "File Extensions (Optional)",
                    "placeholder": "pdf,docx,txt",
                    "helper_text": "Filter by file extensions (optional)",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Search in Folder (Optional)",
                    "helper_text": "Select folder to search in (optional - leave empty to search all)",
                    "agent_helper_text": "IMPORTANT: This field is OPTIONAL. Leave it EMPTY to search across all of Box. NEVER put a folder name, {user_vs_object}, integration value, or any fabricated placeholder here. Only use this field if you already have a verified numeric folder ID from a previous successful Search Files or Get Folder call. If the user mentions a folder name in their prompt, put the file/folder name you are looking for in the 'query' field instead and leave this folder_id field empty.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return (default: 10)",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "value": 0,
                    "label": "Offset",
                    "helper_text": "Number of records to skip from the start. Must be a multiple of the limit value (e.g., if limit is 6, valid offsets are 0, 6, 12, ...)",
                },
            ],
            "outputs": [
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "List of file IDs",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "List of file names",
                },
                {
                    "field": "file_types",
                    "type": "vec<string>",
                    "helper_text": "List of file types",
                },
                {
                    "field": "file_urls",
                    "type": "vec<string>",
                    "helper_text": "List of file URLs",
                },
                {
                    "field": "parent_folder_ids",
                    "type": "vec<string>",
                    "helper_text": "List of parent folder IDs",
                },
                {
                    "field": "owner_names",
                    "type": "vec<string>",
                    "helper_text": "List of file owner names",
                },
                {
                    "field": "owner_emails",
                    "type": "vec<string>",
                    "helper_text": "List of file owner emails",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of file creation timestamps",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of file modification timestamps",
                },
                {
                    "field": "files",
                    "type": "vec<string>",
                    "helper_text": "List of found files with detailed information (legacy format)",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of files found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "search_files",
            "task_name": "tasks.box.search_files",
            "description": "Search for files in Box",
            "label": "Search Files",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "query",
                "file_extensions",
                "folder_id",
                "limit",
                "offset",
            ],
            "required": ["query", "limit"],
        },
        "search_files_and_folders": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "Enter search terms",
                    "helper_text": "Search query to find files or folders",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "file",
                    "label": "Type",
                    "helper_text": "Type of item to search for",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Files and Folders", "value": "both"},
                            {"label": "Files only", "value": "file"},
                            {"label": "Folders only", "value": "folder"},
                        ],
                    },
                },
                {
                    "field": "file_extensions",
                    "type": "vec<string>",
                    "value": [],
                    "label": "File Extensions (Optional)",
                    "placeholder": "pdf,docx,txt",
                    "helper_text": "Filter by file extensions (applies to file searches only)",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Search in Folder (Optional)",
                    "helper_text": "Select folder to search in (optional - leave empty to search all)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of results to return (default: 10)",
                },
                {
                    "field": "offset",
                    "type": "int32",
                    "value": 0,
                    "label": "Offset",
                    "helper_text": "Number of records to skip from the start. Must be a multiple of the limit value (e.g., if limit is 6, valid offsets are 0, 6, 12, ...)",
                },
            ],
            "outputs": [
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of item IDs",
                },
                {
                    "field": "item_names",
                    "type": "vec<string>",
                    "helper_text": "List of item names",
                },
                {
                    "field": "item_types",
                    "type": "vec<string>",
                    "helper_text": "List of item types",
                },
                {
                    "field": "item_urls",
                    "type": "vec<string>",
                    "helper_text": "List of item URLs",
                },
                {
                    "field": "parent_folder_ids",
                    "type": "vec<string>",
                    "helper_text": "List of parent folder IDs",
                },
                {
                    "field": "owner_names",
                    "type": "vec<string>",
                    "helper_text": "List of item owner names",
                },
                {
                    "field": "owner_emails",
                    "type": "vec<string>",
                    "helper_text": "List of item owner emails",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of item creation timestamps",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of item modification timestamps",
                },
                {
                    "field": "items",
                    "type": "vec<string>",
                    "helper_text": "List of found items with detailed information",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of items found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "search_files_and_folders",
            "task_name": "tasks.box.search_files_and_folders",
            "description": "Search for files and folders in Box, optionally within a selected folder",
            "label": "Search Files & Folders",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "query",
                "type",
                "file_extensions",
                "folder_id",
                "limit",
                "offset",
            ],
            "required": ["query", "type", "limit"],
        },
        "share_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to share",
                    "agent_helper_text": "The actual numeric file ID of the file to share. NEVER use {user_vs_object}, the integration/account value, or a file name here. If the user only provides a file name, you MUST first call 'Search Files' (search_files) with the file name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "access",
                    "type": "string",
                    "value": "open",
                    "label": "Access Level",
                    "helper_text": "Access level for the shared link",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Open", "value": "open"},
                            {"label": "Company", "value": "company"},
                            {"label": "Collaborators", "value": "collaborators"},
                        ],
                    },
                },
                {
                    "field": "can_download",
                    "type": "bool",
                    "value": True,
                    "label": "Allow Download",
                    "helper_text": "Whether users can download the file",
                },
                {
                    "field": "can_preview",
                    "type": "bool",
                    "value": True,
                    "label": "Allow Preview",
                    "helper_text": "Whether users can preview the file",
                },
            ],
            "outputs": [
                {
                    "field": "shared_link",
                    "type": "string",
                    "helper_text": "The shared link URL",
                },
                {
                    "field": "access_level",
                    "type": "string",
                    "helper_text": "Access level of the shared link",
                },
                {
                    "field": "permissions",
                    "type": "string",
                    "helper_text": "Permissions for the shared link",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "share_file",
            "task_name": "tasks.box.share_file",
            "description": "Create a shared link for a file",
            "label": "Share File",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "file_id",
                "access",
                "can_download",
                "can_preview",
            ],
            "required": ["file_id"],
        },
        "create_folder": {
            "inputs": [
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "label": "Folder Name",
                    "placeholder": "My New Folder",
                    "helper_text": "Name of the folder to create",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Folder",
                    "helper_text": "Select the parent folder where the new folder will be created",
                    "agent_helper_text": "The actual numeric folder ID of the parent folder. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the created folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the created folder",
                },
                {
                    "field": "folder_url",
                    "type": "string",
                    "helper_text": "URL to access the created folder",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.box.create_folder",
            "description": "Create a new folder in Box",
            "label": "Create Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "parent_folder_id",
                "folder_name",
            ],
            "required": ["folder_name", "parent_folder_id"],
        },
        "read_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to read information about",
                    "agent_helper_text": "The actual numeric folder ID of the folder to read. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "folder_url",
                    "type": "string",
                    "helper_text": "URL to access the folder",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "item_count",
                    "type": "int32",
                    "helper_text": "Number of items in the folder",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the folder owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the folder owner",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "read_folder",
            "task_name": "tasks.box.read_folder",
            "description": "Read details of a specific folder",
            "label": "Get Folder",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "folder_id"],
            "required": ["folder_id"],
        },
        "delete_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to delete",
                    "agent_helper_text": "The actual numeric folder ID of the folder to delete. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "recursive",
                    "type": "bool",
                    "value": False,
                    "label": "Delete Recursively",
                    "helper_text": "Delete folder and all its contents (use with caution)",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion result message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "delete_folder",
            "task_name": "tasks.box.delete_folder",
            "description": "Delete a folder from Box",
            "label": "Delete Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "folder_id", "recursive"],
            "required": ["folder_id"],
        },
        "share_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to share",
                    "agent_helper_text": "The actual numeric folder ID of the folder to share. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "access",
                    "type": "string",
                    "value": "open",
                    "label": "Access Level",
                    "helper_text": "Access level for the shared link",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Open", "value": "open"},
                            {"label": "Company", "value": "company"},
                            {"label": "Collaborators", "value": "collaborators"},
                        ],
                    },
                },
                {
                    "field": "can_download",
                    "type": "bool",
                    "value": True,
                    "label": "Allow Download",
                    "helper_text": "Whether users can download files from the folder",
                },
                {
                    "field": "can_preview",
                    "type": "bool",
                    "value": True,
                    "label": "Allow Preview",
                    "helper_text": "Whether users can preview files in the folder",
                },
            ],
            "outputs": [
                {
                    "field": "shared_link",
                    "type": "string",
                    "helper_text": "The shared link URL",
                },
                {
                    "field": "access_level",
                    "type": "string",
                    "helper_text": "Access level of the shared link",
                },
                {
                    "field": "permissions",
                    "type": "string",
                    "helper_text": "Permissions for the shared link",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "share_folder",
            "task_name": "tasks.box.share_folder",
            "description": "Create a shared link for a folder",
            "label": "Share Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "folder_id",
                "access",
                "can_download",
                "can_preview",
            ],
            "required": ["folder_id"],
        },
        "update_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to update",
                    "agent_helper_text": "The actual numeric folder ID of the folder to update. NEVER use {user_vs_object}, the integration/account value, or a folder name here. If the user only provides a folder name, you MUST first call 'Search Files' (search_files) with the folder name in the query field and folder_id left empty to get the numeric ID, then use that ID here.",
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "label": "New Name",
                    "placeholder": "Leave empty to keep current name",
                    "helper_text": "New name for the folder",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description (Optional)",
                    "placeholder": "Folder description",
                    "helper_text": "Description for the folder (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the updated folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the updated folder",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the updated folder",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data from Box",
                },
            ],
            "name": "update_folder",
            "task_name": "tasks.box.update_folder",
            "description": "Update folder properties",
            "label": "Update Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "folder_id",
                "new_name",
                "description",
            ],
            "required": ["folder_id", "new_name"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        access: str = "open",
        can_download: bool = True,
        can_preview: bool = True,
        description: str = "",
        destination_folder_id: str = "",
        file_extensions: List[str] = [],
        file_id: str = "",
        files: List[str] = [""],
        folder_id: str = "",
        folder_name: str = "",
        limit: int = 10,
        new_name: str = "",
        offset: int = 0,
        parent_folder_id: str = "",
        recursive: bool = False,
        type: str = "file",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_box",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if files is not None:
            self.inputs["files"] = files
        if file_id is not None:
            self.inputs["file_id"] = file_id
        if destination_folder_id is not None:
            self.inputs["destination_folder_id"] = destination_folder_id
        if new_name is not None:
            self.inputs["new_name"] = new_name
        if query is not None:
            self.inputs["query"] = query
        if file_extensions is not None:
            self.inputs["file_extensions"] = file_extensions
        if limit is not None:
            self.inputs["limit"] = limit
        if offset is not None:
            self.inputs["offset"] = offset
        if type is not None:
            self.inputs["type"] = type
        if access is not None:
            self.inputs["access"] = access
        if can_download is not None:
            self.inputs["can_download"] = can_download
        if can_preview is not None:
            self.inputs["can_preview"] = can_preview
        if folder_name is not None:
            self.inputs["folder_name"] = folder_name
        if parent_folder_id is not None:
            self.inputs["parent_folder_id"] = parent_folder_id
        if recursive is not None:
            self.inputs["recursive"] = recursive
        if description is not None:
            self.inputs["description"] = description
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationBoxNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
