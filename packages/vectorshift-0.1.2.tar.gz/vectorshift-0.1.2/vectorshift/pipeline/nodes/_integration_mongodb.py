"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_mongodb")
class IntegrationMongodbNode(Node):
    """
    MongoDB

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### find
        query: The MongoDB query to find all matching records
        collection: The collection on which to perform the query
    ### find_one
        query: The MongoDB query to find all matching records
        collection: The collection on which to perform the query
    ### aggregate
        query: The MongoDB query to find all matching records
        collection: The collection on which to perform the query
    ### mongodb_nl
        query: The MongoDB query to find all matching records
        collection: The collection on which to perform the query
    ### mongodb_nl_aggregation
        query: The MongoDB query to find all matching records
        collection: The collection on which to perform the query
    ### insert
        collection: The collection on which to perform the query
        document: The document to insert (JSON format)
    ### update
        collection: The collection on which to perform the query
        filter: The filter to select documents to update (JSON format)
        update: The update operation (JSON format)
    ### delete
        collection: The collection on which to perform the query
        filter: The filter to select documents to update (JSON format)
    ### find_and_update
        collection: The collection on which to perform the query
        filter: The filter to select documents to update (JSON format)
        update: The update operation (JSON format)
    ### find_and_replace
        collection: The collection on which to perform the query
        filter: The filter to select documents to update (JSON format)
        replacement: The replacement document (JSON format)

    ## Outputs
    ### Common Outputs
        output: Results of the Query. Example: {“name”: “John”, “age”: 29, “height”: 185}
        raw_data: Raw unprocessed data from MongoDB operation
    ### delete
        deleted_count: Number of documents deleted
    ### insert
        inserted_id: The ID of the inserted document
    ### update
        matched_count: Number of documents matched by the filter
        modified_count: Number of documents actually modified
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<MongoDB>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "Results of the Query. Example: {“name”: “John”, “age”: 29, “height”: 185}",
            "type": "string",
        },
        {
            "field": "raw_data",
            "helper_text": "Raw unprocessed data from MongoDB operation",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "find": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "{“name”: “John”, “age”: {“gte”: 28}}",
                    "helper_text": "The MongoDB query to find all matching records",
                },
            ],
            "outputs": [],
            "name": "find",
            "task_name": "tasks.mongodb.find",
            "description": "Query MongoDB data",
            "label": "MongoDB Find",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "collection", "query"],
        },
        "find_one": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "{“name”: “John”, “age”: {“gte”: 28}}",
                    "helper_text": "The MongoDB query to find all matching records",
                },
            ],
            "outputs": [],
            "name": "find_one",
            "task_name": "tasks.mongodb.find_one",
            "description": "Query MongoDB data",
            "label": "MongoDB Find One",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "collection", "query"],
        },
        "aggregate": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "{“name”: “John”, “age”: {“gte”: 28}}",
                    "helper_text": "The MongoDB query to find all matching records",
                },
            ],
            "outputs": [],
            "name": "aggregate",
            "task_name": "tasks.mongodb.aggregate",
            "description": "Run an Aggregation on MongoDB data",
            "label": "MongoDB Aggregate",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "collection", "query"],
        },
        "mongodb_nl": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "{“name”: “John”, “age”: {“gte”: 28}}",
                    "helper_text": "The MongoDB query to find all matching records",
                },
            ],
            "outputs": [],
            "name": "mongodb_nl",
            "task_name": "tasks.mongodb.mongodb_nl",
            "description": "Query MongoDB data with Natural Language",
            "label": "NL Query",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "collection", "query"],
        },
        "mongodb_nl_aggregation": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection on which to perform the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "{“name”: “John”, “age”: {“gte”: 28}}",
                    "helper_text": "The MongoDB query to find all matching records",
                },
            ],
            "outputs": [],
            "name": "mongodb_nl_aggregation",
            "task_name": "tasks.mongodb.mongodb_nl_aggregation",
            "description": "Aggregate MongoDB data with Natural Language",
            "label": "NL Aggregation",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "collection", "query"],
        },
        "insert": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection in which to insert the document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "document",
                    "type": "string",
                    "value": "",
                    "label": "Document",
                    "placeholder": '{"name": "John", "age": 30, "city": "New York"}',
                    "helper_text": "The document to insert (JSON format)",
                },
            ],
            "outputs": [
                {
                    "field": "inserted_id",
                    "type": "string",
                    "helper_text": "The ID of the inserted document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw unprocessed data from MongoDB operation",
                },
            ],
            "name": "insert",
            "task_name": "tasks.mongodb.insert",
            "description": "Insert a document into MongoDB collection",
            "label": "Insert Document",
            "variant": "common_integration_nodes",
            "required": ["collection", "document"],
            "ui_sort_order": ["integration", "action", "collection", "document"],
        },
        "update": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection in which to update documents",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": '{"age": {"$gte": 18}}',
                    "helper_text": "The filter to select documents to update (JSON format)",
                },
                {
                    "field": "update",
                    "type": "string",
                    "value": "",
                    "label": "Update",
                    "placeholder": '{"$set": {"status": "active"}}',
                    "helper_text": "The update operation (JSON format)",
                },
            ],
            "outputs": [
                {
                    "field": "matched_count",
                    "type": "int32",
                    "helper_text": "Number of documents matched by the filter",
                },
                {
                    "field": "modified_count",
                    "type": "int32",
                    "helper_text": "Number of documents actually modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw unprocessed data from MongoDB operation",
                },
            ],
            "name": "update",
            "task_name": "tasks.mongodb.update",
            "description": "Update documents in MongoDB collection",
            "label": "Update Documents",
            "variant": "common_integration_nodes",
            "required": ["collection", "filter", "update"],
            "ui_sort_order": [
                "integration",
                "action",
                "collection",
                "filter",
                "update",
            ],
        },
        "delete": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection from which to delete documents",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": '{"status": "inactive"}',
                    "helper_text": "The filter to select documents to delete (JSON format)",
                },
            ],
            "outputs": [
                {
                    "field": "deleted_count",
                    "type": "int32",
                    "helper_text": "Number of documents deleted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw unprocessed data from MongoDB operation",
                },
            ],
            "name": "delete",
            "task_name": "tasks.mongodb.delete",
            "description": "Delete documents from MongoDB collection",
            "label": "Delete Documents",
            "variant": "common_integration_nodes",
            "required": ["collection", "filter"],
            "ui_sort_order": ["integration", "action", "collection", "filter"],
        },
        "find_and_update": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection in which to find and update a document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": '{"name": "John"}',
                    "helper_text": "The filter to select the document to update (JSON format)",
                },
                {
                    "field": "update",
                    "type": "string",
                    "value": "",
                    "label": "Update",
                    "placeholder": '{"$set": {"age": 31}}',
                    "helper_text": "The update operation (JSON format)",
                },
            ],
            "outputs": [],
            "name": "find_and_update",
            "task_name": "tasks.mongodb.find_and_update",
            "description": "Find and update a single document in MongoDB collection",
            "label": "Find and Update Document",
            "variant": "common_integration_nodes",
            "required": ["collection", "filter", "update"],
            "ui_sort_order": [
                "integration",
                "action",
                "collection",
                "filter",
                "update",
            ],
        },
        "find_and_replace": {
            "inputs": [
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "helper_text": "The collection in which to find and replace a document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": '{"name": "John"}',
                    "helper_text": "The filter to select the document to replace (JSON format)",
                },
                {
                    "field": "replacement",
                    "type": "string",
                    "value": "",
                    "label": "Replacement",
                    "placeholder": '{"name": "John", "age": 32, "city": "Boston"}',
                    "helper_text": "The replacement document (JSON format)",
                },
            ],
            "outputs": [],
            "name": "find_and_replace",
            "task_name": "tasks.mongodb.find_and_replace",
            "description": "Find and replace a single document in MongoDB collection",
            "label": "Find and Replace Document",
            "variant": "common_integration_nodes",
            "required": ["collection", "filter", "replacement"],
            "ui_sort_order": [
                "integration",
                "action",
                "collection",
                "filter",
                "replacement",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        collection: str = "",
        document: str = "",
        filter: str = "",
        replacement: str = "",
        update: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_mongodb",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if collection is not None:
            self.inputs["collection"] = collection
        if query is not None:
            self.inputs["query"] = query
        if document is not None:
            self.inputs["document"] = document
        if filter is not None:
            self.inputs["filter"] = filter
        if update is not None:
            self.inputs["update"] = update
        if replacement is not None:
            self.inputs["replacement"] = replacement
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMongodbNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
