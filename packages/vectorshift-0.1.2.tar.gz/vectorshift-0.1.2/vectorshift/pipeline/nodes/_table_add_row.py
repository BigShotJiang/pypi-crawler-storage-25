"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("table_add_row")
class TableAddRowNode(Node):
    """
    Add New Row to Table.

    ## Inputs
    ### Common Inputs
        table: The ID of the table to be used
    ### [<A>]
        [<A>.columns]: The [<A>.columns] input

    ## Outputs
    ### Common Outputs
        table: The table with the added new row
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "table",
            "helper_text": "The ID of the table to be used",
            "value": {"object_id": "", "object_type": ObjectType.TABLE},
            "type": "table",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "table",
            "helper_text": "The table with the added new row",
            "type": "table",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "[<A>]": {
            "inputs": [
                {
                    "field": "[<A>.columns]",
                    "type": "",
                    "component_config": {
                        "components": [{"type": "bool", "component_field": True}]
                    },
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["table"]

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = ["table"]

    def __init__(
        self,
        table: Any = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["table"] = table

        super().__init__(
            node_type="table_add_row",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if table is not None:
            self.inputs["table"] = table
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TableAddRowNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
