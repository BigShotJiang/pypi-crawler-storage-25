"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_coda")
class IntegrationCodaNode(Node):
    """
    Coda

    ## Inputs
    ### Common Inputs
        action: Select the Coda operation to perform
        integration: Connect to your Coda account
    ### create_row
        cells: JSON object with column-value pairs to insert
        doc_id: Choose the Coda document
        key_columns: Optional key columns for upsert behavior
        table_id: Choose the table to insert into
    ### update_row
        cells: JSON object with column-value pairs to insert
        doc_id: Choose the Coda document
        row_id: The ID of the row to retrieve
        table_id: Choose the table to insert into
    ### get_column
        column_id: Choose the column to retrieve
        doc_id: Choose the Coda document
        table_id: Choose the table to insert into
    ### push_button
        column_id: Choose the column to retrieve
        doc_id: Choose the Coda document
        row_id: The ID of the row to retrieve
        table_id: Choose the table to insert into
    ### push_view_button
        column_id: Choose the column to retrieve
        doc_id: Choose the Coda document
        row_id: The ID of the row to retrieve
        table_id: Choose the table to insert into
        view_id: Choose the view to retrieve
    ### get_control
        control_id: The ID of the control to retrieve
        doc_id: Choose the Coda document
    ### list_controls
        doc_id: Choose the Coda document
        limit: Maximum number of controls to return
    ### get_formula
        doc_id: Choose the Coda document
        formula_id: The ID of the formula to retrieve
    ### list_formulas
        doc_id: Choose the Coda document
        limit: Maximum number of controls to return
    ### delete_rows
        doc_id: Choose the Coda document
        row_ids: List of row IDs to delete
        table_id: Choose the table to insert into
    ### list_columns
        doc_id: Choose the Coda document
        table_id: Choose the table to insert into
    ### list_rows
        doc_id: Choose the Coda document
        limit: Maximum number of controls to return
        table_id: Choose the table to insert into
        use_column_names: Return column names instead of IDs
    ### get_row
        doc_id: Choose the Coda document
        row_id: The ID of the row to retrieve
        table_id: Choose the table to insert into
        use_column_names: Return column names instead of IDs
    ### get_view
        doc_id: Choose the Coda document
        table_id: Choose the table to insert into
        view_id: Choose the view to retrieve
    ### list_views
        doc_id: Choose the Coda document
        limit: Maximum number of controls to return
        table_id: Choose the table to insert into
    ### list_view_columns
        doc_id: Choose the Coda document
        table_id: Choose the table to insert into
        view_id: Choose the view to retrieve
    ### list_view_rows
        doc_id: Choose the Coda document
        limit: Maximum number of controls to return
        table_id: Choose the table to insert into
        use_column_names: Return column names instead of IDs
        view_id: Choose the view to retrieve
    ### delete_view_row
        doc_id: Choose the Coda document
        row_id: The ID of the row to retrieve
        table_id: Choose the table to insert into
        view_id: Choose the view to retrieve

    ## Outputs
    ### get_column
        column: Column details as JSON
        name: Column name
        raw_data: Raw JSON response from Coda API
        type: Column type
    ### list_columns
        column_names: List of column names
        columns: List of columns as JSON
        count: Number of columns returned
        raw_data: Raw JSON response from Coda API
    ### list_view_columns
        column_names: List of column names
        columns: List of view columns as JSON
        count: Number of columns returned
        raw_data: Raw JSON response from Coda API
    ### get_control
        control: Control details as JSON
        name: Control name
        raw_data: Raw JSON response from Coda API
        type: Control type
        value: Current control value
    ### list_controls
        controls: List of controls as JSON
        count: Number of controls returned
        raw_data: Raw JSON response from Coda API
    ### list_formulas
        count: Number of formulas returned
        formulas: List of formulas as JSON
        raw_data: Raw JSON response from Coda API
    ### list_rows
        count: Number of rows returned
        raw_data: Raw JSON response from Coda API
        rows: List of rows as JSON
    ### list_views
        count: Number of views returned
        raw_data: Raw JSON response from Coda API
        views: List of views as JSON
    ### list_view_rows
        count: Number of rows returned
        raw_data: Raw JSON response from Coda API
        rows: List of view rows as JSON
    ### delete_rows
        deleted_rows: Number of rows deleted
        raw_data: Raw response from Coda API
    ### get_formula
        formula: Formula details as JSON
        name: Formula name
        raw_data: Raw JSON response from Coda API
        value: Current formula value
    ### get_view
        name: View name
        raw_data: Raw JSON response from Coda API
        type: View type
        view: View details as JSON
    ### create_row
        raw_data: Raw response from Coda API
        row_data: Created row data as JSON
        row_id: ID of the created row
    ### get_row
        raw_data: Raw JSON response from Coda API
        row: Row data as JSON
        values: Row values as JSON
    ### update_row
        raw_data: Raw response from Coda API
        row_data: Updated row data as JSON
        row_id: ID of the updated row
    ### push_button
        raw_data: Raw response from Coda API
        request_id: ID of the button push request
    ### delete_view_row
        raw_data: Raw response from Coda API
    ### push_view_button
        raw_data: Raw response from Coda API
        request_id: ID of the button push request
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the Coda operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Coda account",
            "value": None,
            "type": "integration<Coda>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "get_control": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "control_id",
                    "type": "string",
                    "value": "",
                    "label": "Control ID",
                    "placeholder": "Enter control ID",
                    "helper_text": "The ID of the control to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "control",
                    "type": "string",
                    "helper_text": "Control details as JSON",
                },
                {"field": "name", "type": "string", "helper_text": "Control name"},
                {"field": "type", "type": "string", "helper_text": "Control type"},
                {
                    "field": "value",
                    "type": "string",
                    "helper_text": "Current control value",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "get_control",
            "task_name": "tasks.coda.get_control",
            "description": "Get a specific control from a Coda document",
            "label": "Get Control",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "control_id"],
            "ui_sort_order": ["integration", "action", "doc_id", "control_id"],
        },
        "list_controls": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of controls to return",
                },
            ],
            "outputs": [
                {
                    "field": "controls",
                    "type": "string",
                    "helper_text": "List of controls as JSON",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of controls returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_controls",
            "task_name": "tasks.coda.get_all_controls",
            "description": "Get multiple controls",
            "label": "List Controls",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "limit"],
            "ui_sort_order": ["integration", "action", "doc_id", "limit"],
        },
        "get_formula": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "formula_id",
                    "type": "string",
                    "value": "",
                    "label": "Formula ID",
                    "placeholder": "Enter formula ID",
                    "helper_text": "The ID of the formula to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "formula",
                    "type": "string",
                    "helper_text": "Formula details as JSON",
                },
                {"field": "name", "type": "string", "helper_text": "Formula name"},
                {
                    "field": "value",
                    "type": "string",
                    "helper_text": "Current formula value",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "get_formula",
            "task_name": "tasks.coda.get_formula",
            "description": "Get a specific formula from a Coda document",
            "label": "Get Formula",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "formula_id"],
            "ui_sort_order": ["integration", "action", "doc_id", "formula_id"],
        },
        "list_formulas": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of formulas to return",
                },
            ],
            "outputs": [
                {
                    "field": "formulas",
                    "type": "string",
                    "helper_text": "List of formulas as JSON",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of formulas returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_formulas",
            "task_name": "tasks.coda.get_all_formulas",
            "description": "Get multiple formulas",
            "label": "List Formulas",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "limit"],
            "ui_sort_order": ["integration", "action", "doc_id", "limit"],
        },
        "create_row": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert into",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "cells",
                    "type": "string",
                    "value": "",
                    "label": "Row Data",
                    "placeholder": '{"column1": "value1", "column2": "value2"}',
                    "helper_text": "JSON object with column-value pairs to insert",
                },
                {
                    "field": "key_columns",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Key Columns",
                    "helper_text": "Optional key columns for upsert behavior",
                },
            ],
            "outputs": [
                {
                    "field": "row_id",
                    "type": "string",
                    "helper_text": "ID of the created row",
                },
                {
                    "field": "row_data",
                    "type": "string",
                    "helper_text": "Created row data as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Coda API",
                },
            ],
            "name": "create_row",
            "task_name": "tasks.coda.create_row",
            "description": "Create/Insert a new row into a Coda table",
            "label": "Create Row",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "cells"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "cells",
                "key_columns",
            ],
        },
        "delete_rows": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to delete from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "row_ids",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Row IDs",
                    "placeholder": "Enter row IDs to delete",
                    "helper_text": "List of row IDs to delete",
                },
            ],
            "outputs": [
                {
                    "field": "deleted_rows",
                    "type": "int32",
                    "helper_text": "Number of rows deleted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Coda API",
                },
            ],
            "name": "delete_rows",
            "task_name": "tasks.coda.delete_rows",
            "description": "Delete one or multiple rows from a Coda table",
            "label": "Delete Rows",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "row_ids"],
            "ui_sort_order": ["integration", "action", "doc_id", "table_id", "row_ids"],
        },
        "list_columns": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to get columns from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "columns",
                    "type": "string",
                    "helper_text": "List of columns as JSON",
                },
                {
                    "field": "column_names",
                    "type": "vec<string>",
                    "helper_text": "List of column names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of columns returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_columns",
            "task_name": "tasks.coda.get_all_columns",
            "description": "Get multiple columns",
            "label": "List Columns",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id"],
            "ui_sort_order": ["integration", "action", "doc_id", "table_id"],
        },
        "list_rows": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to get rows from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return",
                },
                {
                    "field": "use_column_names",
                    "type": "bool",
                    "value": True,
                    "label": "Use Column Names",
                    "helper_text": "Return column names instead of IDs",
                },
            ],
            "outputs": [
                {
                    "field": "rows",
                    "type": "string",
                    "helper_text": "List of rows as JSON",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_rows",
            "task_name": "tasks.coda.get_all_rows",
            "description": "Get multiple rows",
            "label": "List Rows",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "limit",
                "use_column_names",
            ],
        },
        "get_column": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column ID",
                    "placeholder": "Select column",
                    "helper_text": "Choose the column to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "column",
                    "type": "string",
                    "helper_text": "Column details as JSON",
                },
                {"field": "name", "type": "string", "helper_text": "Column name"},
                {"field": "type", "type": "string", "helper_text": "Column type"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "get_column",
            "task_name": "tasks.coda.get_column",
            "description": "Get a specific column from a Coda table",
            "label": "Get Column",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "column_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "column_id",
            ],
        },
        "get_row": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row ID",
                    "placeholder": "Enter row ID",
                    "helper_text": "The ID of the row to retrieve",
                },
                {
                    "field": "use_column_names",
                    "type": "bool",
                    "value": True,
                    "label": "Use Column Names",
                    "helper_text": "Return column names instead of IDs",
                },
            ],
            "outputs": [
                {"field": "row", "type": "string", "helper_text": "Row data as JSON"},
                {
                    "field": "values",
                    "type": "string",
                    "helper_text": "Row values as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "get_row",
            "task_name": "tasks.coda.get_row",
            "description": "Get a specific row from a Coda table",
            "label": "Get Row",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "row_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "row_id",
                "use_column_names",
            ],
        },
        "update_row": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row ID",
                    "placeholder": "Enter row ID",
                    "helper_text": "The ID of the row to update",
                },
                {
                    "field": "cells",
                    "type": "string",
                    "value": "",
                    "label": "Update Data",
                    "placeholder": '{"column1": "new_value1", "column2": "new_value2"}',
                    "helper_text": "JSON object with column-value pairs to update",
                },
            ],
            "outputs": [
                {
                    "field": "row_id",
                    "type": "string",
                    "helper_text": "ID of the updated row",
                },
                {
                    "field": "row_data",
                    "type": "string",
                    "helper_text": "Updated row data as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Coda API",
                },
            ],
            "name": "update_row",
            "task_name": "tasks.coda.update_row",
            "description": "Update a row in a Coda table",
            "label": "Update Row",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "row_id", "cells"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "row_id",
                "cells",
            ],
        },
        "push_button": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row ID",
                    "placeholder": "Enter row ID",
                    "helper_text": "The ID of the row containing the button",
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column ID",
                    "placeholder": "Select column",
                    "helper_text": "The column containing the button",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "request_id",
                    "type": "string",
                    "helper_text": "ID of the button push request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Coda API",
                },
            ],
            "name": "push_button",
            "task_name": "tasks.coda.push_button",
            "description": "Push a button in a Coda table",
            "label": "Push Button",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "row_id", "column_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "row_id",
                "column_id",
            ],
        },
        "get_view": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "label": "View ID",
                    "placeholder": "Select view",
                    "helper_text": "Choose the view to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "view",
                    "type": "string",
                    "helper_text": "View details as JSON",
                },
                {"field": "name", "type": "string", "helper_text": "View name"},
                {"field": "type", "type": "string", "helper_text": "View type"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "get_view",
            "task_name": "tasks.coda.get_view",
            "description": "Get a specific view from a Coda table",
            "label": "Get View",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "view_id"],
            "ui_sort_order": ["integration", "action", "doc_id", "table_id", "view_id"],
        },
        "list_views": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to get views from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of views to return",
                },
            ],
            "outputs": [
                {
                    "field": "views",
                    "type": "string",
                    "helper_text": "List of views as JSON",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of views returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_views",
            "task_name": "tasks.coda.get_all_views",
            "description": "Get multiple views from a table",
            "label": "List Views",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "limit"],
            "ui_sort_order": ["integration", "action", "doc_id", "table_id", "limit"],
        },
        "list_view_columns": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "label": "View ID",
                    "placeholder": "Select view",
                    "helper_text": "Choose the view to get columns from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "columns",
                    "type": "string",
                    "helper_text": "List of view columns as JSON",
                },
                {
                    "field": "column_names",
                    "type": "vec<string>",
                    "helper_text": "List of column names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of columns returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_view_columns",
            "task_name": "tasks.coda.get_all_view_columns",
            "description": "Get multiple columns from a view",
            "label": "List View Columns",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "view_id"],
            "ui_sort_order": ["integration", "action", "doc_id", "table_id", "view_id"],
        },
        "list_view_rows": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "label": "View ID",
                    "placeholder": "Select view",
                    "helper_text": "Choose the view to get rows from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return",
                },
                {
                    "field": "use_column_names",
                    "type": "bool",
                    "value": True,
                    "label": "Use Column Names",
                    "helper_text": "Return column names instead of IDs",
                },
            ],
            "outputs": [
                {
                    "field": "rows",
                    "type": "string",
                    "helper_text": "List of view rows as JSON",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Coda API",
                },
            ],
            "name": "list_view_rows",
            "task_name": "tasks.coda.get_all_view_rows",
            "description": "Get multiple rows from a view",
            "label": "List View Rows",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "view_id", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "view_id",
                "limit",
                "use_column_names",
            ],
        },
        "delete_view_row": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "label": "View ID",
                    "placeholder": "Select view",
                    "helper_text": "Choose the view",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row ID",
                    "placeholder": "Enter row ID",
                    "helper_text": "The ID of the row to delete from the view",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Coda API",
                }
            ],
            "name": "delete_view_row",
            "task_name": "tasks.coda.delete_view_row",
            "description": "Delete a row from a Coda view",
            "label": "Delete View Row",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "view_id", "row_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "view_id",
                "row_id",
            ],
        },
        "push_view_button": {
            "inputs": [
                {
                    "field": "doc_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "Select document",
                    "helper_text": "Choose the Coda document",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=doc_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "label": "Table ID",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&doc_id={inputs.doc_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "label": "View ID",
                    "placeholder": "Select view",
                    "helper_text": "Choose the view",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row ID",
                    "placeholder": "Enter row ID",
                    "helper_text": "The ID of the row containing the button",
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column ID",
                    "placeholder": "Select column",
                    "helper_text": "The column containing the button",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&doc_id={inputs.doc_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "request_id",
                    "type": "string",
                    "helper_text": "ID of the button push request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Coda API",
                },
            ],
            "name": "push_view_button",
            "task_name": "tasks.coda.push_view_button",
            "description": "Push a button in a Coda view",
            "label": "Push View Button",
            "variant": "common_integration_nodes",
            "required": ["doc_id", "table_id", "view_id", "row_id", "column_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "doc_id",
                "table_id",
                "view_id",
                "row_id",
                "column_id",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        cells: str = "",
        column_id: str = "",
        control_id: str = "",
        doc_id: str = "",
        formula_id: str = "",
        key_columns: List[str] = [],
        limit: int = 10,
        row_id: str = "",
        row_ids: List[str] = [],
        table_id: str = "",
        use_column_names: bool = True,
        view_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_coda",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if doc_id is not None:
            self.inputs["doc_id"] = doc_id
        if control_id is not None:
            self.inputs["control_id"] = control_id
        if limit is not None:
            self.inputs["limit"] = limit
        if formula_id is not None:
            self.inputs["formula_id"] = formula_id
        if table_id is not None:
            self.inputs["table_id"] = table_id
        if cells is not None:
            self.inputs["cells"] = cells
        if key_columns is not None:
            self.inputs["key_columns"] = key_columns
        if row_ids is not None:
            self.inputs["row_ids"] = row_ids
        if use_column_names is not None:
            self.inputs["use_column_names"] = use_column_names
        if column_id is not None:
            self.inputs["column_id"] = column_id
        if row_id is not None:
            self.inputs["row_id"] = row_id
        if view_id is not None:
            self.inputs["view_id"] = view_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationCodaNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
