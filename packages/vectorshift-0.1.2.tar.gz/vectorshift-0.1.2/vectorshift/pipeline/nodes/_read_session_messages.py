"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("read_session_messages")
class ReadSessionMessagesNode(Node):
    """
    Read all messages from a session with derived metadata

    ## Inputs
    ### Common Inputs
        message_type_filter: Filter messages by type
        offset: Number of messages to skip from the beginning
        session_id: The session ID to read from

    ## Outputs
    ### Common Outputs
        conversation: Clean conversation messages (text and reasoning)
        messages: All raw session messages as JSON strings
        reasoning_messages: Reasoning/thinking messages
        result: Overall session result and metadata as JSON
        tool_calls: Tool calls with status and request/response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "message_type_filter",
            "helper_text": "Filter messages by type",
            "value": "none",
            "type": "string",
        },
        {
            "field": "offset",
            "helper_text": "Number of messages to skip from the beginning",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "session_id",
            "helper_text": "The session ID to read from",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "conversation",
            "helper_text": "Clean conversation messages (text and reasoning)",
            "type": "vec<string>",
        },
        {
            "field": "messages",
            "helper_text": "All raw session messages as JSON strings",
            "type": "vec<string>",
        },
        {
            "field": "reasoning_messages",
            "helper_text": "Reasoning/thinking messages",
            "type": "vec<string>",
        },
        {
            "field": "result",
            "helper_text": "Overall session result and metadata as JSON",
            "type": "string",
        },
        {
            "field": "tool_calls",
            "helper_text": "Tool calls with status and request/response data",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["session_id"]

    def __init__(
        self,
        message_type_filter: str = "none",
        offset: int = 0,
        session_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="read_session_messages",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if session_id is not None:
            self.inputs["session_id"] = session_id
        if message_type_filter is not None:
            self.inputs["message_type_filter"] = message_type_filter
        if offset is not None:
            self.inputs["offset"] = offset
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ReadSessionMessagesNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
