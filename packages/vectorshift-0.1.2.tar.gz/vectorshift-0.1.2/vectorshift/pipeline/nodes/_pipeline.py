"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("pipeline")
class PipelineNode(Node):
    """
    {{collection.pipelines}}

    ## Inputs
    ### Common Inputs
        pipeline: The ID of the pipeline to be used
    ### [<A>]
        [<A>.inputs]: The [<A>.inputs] input
    ### [pipeline_branches._id.<A>]
        [<A>.inputs]: The [<A>.inputs] input

    ## Outputs
    ### [<A>]
        [<A>.outputs]: The [<A>.outputs] output
    ### [pipeline_branches._id.<A>]
        [<A>.outputs]: The [<A>.outputs] output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "pipeline",
            "helper_text": "The ID of the pipeline to be used",
            "value": {"object_type": ObjectType.PIPELINE, "object_id": ""},
            "type": "pipeline",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "[<A>]": {
            "inputs": [
                {
                    "field": "[<A>.inputs]",
                    "type": "",
                    "component_config": {
                        "components": [
                            {
                                "type": "text",
                                "list_item_label": "Item $i",
                                "list_button_label": "Add Item",
                            }
                        ]
                    },
                }
            ],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "[pipeline_branches._id.<A>]": {
            "inputs": [
                {
                    "field": "[<A>.inputs]",
                    "type": "",
                    "component_config": {
                        "components": [
                            {
                                "type": "text",
                                "list_item_label": "Item $i",
                                "list_button_label": "Add Item",
                            }
                        ]
                    },
                }
            ],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["pipeline"]

    _batch_mode_allowed = True

    def __init__(
        self,
        pipeline: "Pipeline" = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["pipeline"] = pipeline

        super().__init__(
            node_type="pipeline",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if pipeline is not None:
            self.inputs["pipeline"] = pipeline
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "PipelineNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
