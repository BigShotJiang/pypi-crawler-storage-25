"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import QueryEnhancementConfig, RerankConfig, RetrievalConfig


@Node.register_node_type("knowledge_base")
class KnowledgeBaseNode(Node):
    """
    Semantically query a knowledge base that can contain files, scraped URLs, and data from synced integrations (e.g., Google Drive).

    ## Inputs
    ### Common Inputs
        query: The query will be used to search documents for relevant content semantically. Must not be empty, only include relevant information for retrieval or metadata filter generation. Generally expand any specific acronyms or abbreviations but include the original acronym or abbreviation as well
        alpha: The alpha value for the retrieval. 1.0 is pure vector search and 0.0 is pure lexical search
        answer_multiple_questions: Extract separate questions from the query and retrieve content separately for each question to improve search performance
        do_advanced_qa: Use additional LLM calls to analyze each document to improve answer correctness
        do_nl_metadata_query: Do a natural language metadata query
        enable_context: Enable context
        enable_document_db_filter: Enable the document DB filter
        enable_filter: Filter the content returned from the knowledge base
        expand_query: Expand query to improve semantic search
        expand_query_terms: Expand query terms to improve semantic search
        format_context_for_llm: Format the context for the LLM
        generate_metadata_filters: Use an LLM to generate metadata filters to refine your query
        knowledge_base: Select an existing knowledge base, Object type is 'kb'
        rerank_documents: Rerank the documents returned from the knowledge base
        retrieval_unit: The unit of retrieval. Chunks will return the most relevant chunks from the knowledge base as well as their text content. Documents will return the document metadata as well as most relevant snippets from the document. Pages will return complete pages with all chunks from pages containing relevant content
        score_cutoff: The score cutoff
        set_response_format: Generate an LLM response from the retrieved context
        stream_response: Whether to stream the LLM response
        top_k: The number of relevant chunks to be returned
        transform_query: Transform the query for better semantic search
    ### When do_advanced_qa = True
        advanced_search_mode: The mode to use for the advanced search
        qa_model_name: The model to use for the QA
    ### When enable_context = True
        context: Additional context to pass to the query analysis and qa steps
    ### When enable_document_db_filter = True
        document_db_filter: Filter the documents returned from the knowledge base
    ### When enable_filter = True
        filter: Filter the content returned from the knowledge base
    ### When rerank_documents = True
        num_chunks_to_rerank: The number of chunks to rerank
        rerank_model: Refine the initial ranking of returned chunks based on relevancy
    ### When set_response_format = True and stream_response = True
        system_prompt: The system prompt to use for the LLM
    ### When set_response_format = True and stream_response = False
        system_prompt: The system prompt to use for the LLM

    ## Outputs
    ### When do_advanced_qa = False and retrieval_unit = 'chunks' and format_context_for_llm = False
        chunks: Semantically similar chunks retrieved from the knowledge base.
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
    ### When do_advanced_qa = False and retrieval_unit = 'chunks' and format_context_for_llm = True
        chunks: Semantically similar chunks retrieved from the knowledge base.
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        formatted_text: Knowledge base outputs formatted for input to a LLM
    ### When do_advanced_qa = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        response: The response from the knowledge base
    ### When enable_filter = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
    ### When do_advanced_qa = False and retrieval_unit = 'documents' and format_context_for_llm = False
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        documents: The documents returned from the knowledge base
    ### When do_advanced_qa = False and retrieval_unit = 'documents' and format_context_for_llm = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        documents: Semantically similar documents retrieved from the knowledge base.
        formatted_text: Knowledge base outputs formatted for input to a LLM
    ### When do_advanced_qa = False and retrieval_unit = 'pages' and format_context_for_llm = False
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        pages: Complete pages with all chunks retrieved from the knowledge base.
    ### When do_advanced_qa = False and retrieval_unit = 'pages' and format_context_for_llm = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        formatted_text: Knowledge base outputs formatted for input to a LLM
        pages: Complete pages with all chunks retrieved from the knowledge base.
    ### When enable_context = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
    ### When enable_document_db_filter = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
    ### When set_response_format = True and stream_response = True
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        response: The response from the knowledge base
    ### When set_response_format = True and stream_response = False
        citation_metadata: Citation metadata for knowledge base outputs, used for showing sources in LLM responses
        response: The response from the knowledge base
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "The query will be used to search documents for relevant content semantically. Must not be empty, only include relevant information for retrieval or metadata filter generation. Generally expand any specific acronyms or abbreviations but include the original acronym or abbreviation as well",
            "value": "",
            "type": "string",
        },
        {
            "field": "alpha",
            "helper_text": "The alpha value for the retrieval. 1.0 is pure vector search and 0.0 is pure lexical search",
            "value": 0.5,
            "type": "float",
        },
        {
            "field": "answer_multiple_questions",
            "helper_text": "Extract separate questions from the query and retrieve content separately for each question to improve search performance",
            "value": False,
            "type": "bool",
        },
        {
            "field": "do_advanced_qa",
            "helper_text": "Use additional LLM calls to analyze each document to improve answer correctness",
            "value": False,
            "type": "bool",
        },
        {
            "field": "do_nl_metadata_query",
            "helper_text": "Do a natural language metadata query",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_context",
            "helper_text": "Enable context",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_document_db_filter",
            "helper_text": "Enable the document DB filter",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_filter",
            "helper_text": "Filter the content returned from the knowledge base",
            "value": False,
            "type": "bool",
        },
        {
            "field": "expand_query",
            "helper_text": "Expand query to improve semantic search",
            "value": False,
            "type": "bool",
        },
        {
            "field": "expand_query_terms",
            "helper_text": "Expand query terms to improve semantic search",
            "value": False,
            "type": "bool",
        },
        {
            "field": "format_context_for_llm",
            "helper_text": "Format the context for the LLM",
            "value": True,
            "type": "bool",
        },
        {
            "field": "generate_metadata_filters",
            "helper_text": "Use an LLM to generate metadata filters to refine your query",
            "value": False,
            "type": "bool",
        },
        {
            "field": "knowledge_base",
            "helper_text": "Select an existing knowledge base, Object type is 'kb'",
            "value": {"object_type": ObjectType.KNOWLEDGE_BASE, "object_id": ""},
            "type": "knowledge_base",
        },
        {
            "field": "rerank_documents",
            "helper_text": "Rerank the documents returned from the knowledge base",
            "value": False,
            "type": "bool",
        },
        {
            "field": "retrieval_unit",
            "helper_text": "The unit of retrieval. Chunks will return the most relevant chunks from the knowledge base as well as their text content. Documents will return the document metadata as well as most relevant snippets from the document. Pages will return complete pages with all chunks from pages containing relevant content",
            "value": "chunks",
            "type": "string",
        },
        {
            "field": "score_cutoff",
            "helper_text": "The score cutoff",
            "value": 0,
            "type": "float",
        },
        {
            "field": "set_response_format",
            "helper_text": "Generate an LLM response from the retrieved context",
            "value": False,
            "type": "bool",
        },
        {
            "field": "stream_response",
            "helper_text": "Whether to stream the LLM response",
            "value": False,
            "type": "bool",
        },
        {
            "field": "top_k",
            "helper_text": "The number of relevant chunks to be returned",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "transform_query",
            "helper_text": "Transform the query for better semantic search",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)**(*)**(*)**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "qa_model_name",
                    "label": "QA Model Name",
                    "type": "string",
                    "value": "gpt-4o-mini",
                    "helper_text": "The model to use for the QA",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dropdown",
                        "source_key": "qa_models",
                        "is_advanced_setting": True,
                        "agent_field_type": "static",
                        "disable_conversion": False,
                    },
                },
                {
                    "field": "advanced_search_mode",
                    "label": "Advanced Search Mode",
                    "type": "string",
                    "value": "accurate",
                    "helper_text": "The mode to use for the advanced search",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dropdown",
                        "is_advanced_setting": True,
                        "agent_field_type": "static",
                        "disable_conversion": False,
                        "options": [
                            {"label": "Fast", "value": "fast"},
                            {"label": "Accurate", "value": "accurate"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "response",
                    "type": "string",
                    "helper_text": "The response from the knowledge base",
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
            ],
        },
        "(*)**true**(*)**(*)**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "filter",
                    "label": "Filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter the content returned from the knowledge base",
                    "agent_direct_value": True,
                }
            ],
            "outputs": [
                {
                    "field": "citation_metadata",
                    "label": "Citation Metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                }
            ],
        },
        "(*)**(*)**true**(*)**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "rerank_model",
                    "label": "Rerank Model",
                    "type": "string",
                    "value": "cohere/rerank-english-v3.0",
                    "helper_text": "Refine the initial ranking of returned chunks based on relevancy",
                    "component": {"type": "dropdown", "source_key": "rerank_models"},
                    "is_advanced_setting": True,
                    "agent_field_type": "static",
                    "disable_conversion": False,
                    "section": "advanced_settings",
                },
                {
                    "field": "num_chunks_to_rerank",
                    "label": "Num Chunks to Rerank",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "The number of chunks to rerank",
                    "is_advanced_setting": True,
                    "agent_field_type": "static",
                    "disable_conversion": False,
                    "component": {"type": "number"},
                    "section": "advanced_settings",
                },
            ],
            "outputs": [],
        },
        "false**(*)**(*)**documents**(*)**false**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "documents",
                    "label": "Documents",
                    "type": "vec<string>",
                    "helper_text": "The documents returned from the knowledge base",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "citation_metadata",
                    "label": "Citation Metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
            ],
        },
        "false**(*)**(*)**chunks**(*)**false**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "chunks",
                    "label": "Chunks",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar chunks retrieved from the knowledge base.",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "citation_metadata",
                    "label": "Citation Metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                },
            ],
        },
        "false**(*)**(*)**documents**(*)**true**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "documents",
                    "label": "Documents",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar documents retrieved from the knowledge base.",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "citation_metadata",
                    "label": "Citation Metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "formatted_text",
                    "label": "Formatted Text",
                    "type": "string",
                    "helper_text": "Knowledge base outputs formatted for input to a LLM",
                },
            ],
        },
        "false**(*)**(*)**chunks**(*)**true**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "chunks",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar chunks retrieved from the knowledge base.",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "formatted_text",
                    "type": "string",
                    "helper_text": "Knowledge base outputs formatted for input to a LLM",
                },
            ],
        },
        "false**(*)**(*)**pages**(*)**false**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "pages",
                    "type": "vec<string>",
                    "helper_text": "Complete pages with all chunks retrieved from the knowledge base.",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
            ],
        },
        "false**(*)**(*)**pages**(*)**true**(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "pages",
                    "type": "vec<string>",
                    "helper_text": "Complete pages with all chunks retrieved from the knowledge base.",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
                {
                    "field": "formatted_text",
                    "type": "string",
                    "helper_text": "Knowledge base outputs formatted for input to a LLM",
                },
            ],
        },
        "(*)**(*)**(*)**(*)**true**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "context",
                    "label": "Context",
                    "type": "string",
                    "value": "",
                    "helper_text": "Additional context to pass to the query analysis and qa steps",
                }
            ],
            "outputs": [
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                }
            ],
        },
        "(*)**(*)**(*)**(*)**(*)**(*)**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "document_db_filter",
                    "label": "Document DB Filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter the documents returned from the knowledge base",
                    "section": "advanced_settings",
                }
            ],
            "outputs": [
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                }
            ],
        },
        "(*)**(*)**(*)**(*)**(*)**(*)**(*)**true**true": {
            "inputs": [
                {
                    "field": "system_prompt",
                    "label": "System Prompt",
                    "type": "string",
                    "value": "",
                    "helper_text": "The system prompt to use for the LLM",
                    "section": "advanced_settings",
                }
            ],
            "outputs": [
                {
                    "field": "response",
                    "type": "stream<string>",
                    "helper_text": "The response from the knowledge base",
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
            ],
        },
        "(*)**(*)**(*)**(*)**(*)**(*)**(*)**true**false": {
            "inputs": [
                {
                    "field": "system_prompt",
                    "label": "System Prompt",
                    "type": "string",
                    "value": "",
                    "helper_text": "The system prompt to use for the LLM",
                    "section": "advanced_settings",
                }
            ],
            "outputs": [
                {
                    "field": "response",
                    "type": "string",
                    "helper_text": "The response from the knowledge base",
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for knowledge base outputs, used for showing sources in LLM responses",
                    "exclude_from_agent_context": True,
                },
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = [
        "do_advanced_qa",
        "enable_filter",
        "rerank_documents",
        "retrieval_unit",
        "enable_context",
        "format_context_for_llm",
        "enable_document_db_filter",
        "set_response_format",
        "stream_response",
    ]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["query", "knowledge_base"]

    def __init__(
        self,
        do_advanced_qa: bool = False,
        enable_filter: bool = False,
        enable_context: bool = False,
        format_context_for_llm: bool = True,
        enable_document_db_filter: bool = False,
        set_response_format: bool = False,
        stream_response: bool = False,
        query: str = "",
        advanced_search_mode: str = "accurate",
        context: str = "",
        document_db_filter: str = "",
        filter: str = "",
        generate_metadata_filters: bool = False,
        knowledge_base: "KnowledgeBase" = "",
        qa_model_name: str = "gpt-4o-mini",
        system_prompt: str = "",
        dependencies: Optional[List[str]] = None,
        retrieval: Optional[RetrievalConfig] = None,
        rerank: Optional[RerankConfig] = None,
        query_enhancement: Optional[QueryEnhancementConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_retrieval = retrieval if retrieval is not None else RetrievalConfig()
        top_k = _cfg_retrieval.top_k
        alpha = _cfg_retrieval.alpha
        score_cutoff = _cfg_retrieval.score_cutoff
        retrieval_unit = _cfg_retrieval.unit
        _cfg_rerank = rerank if rerank is not None else RerankConfig()
        rerank_model = _cfg_rerank.model
        num_chunks_to_rerank = _cfg_rerank.num_chunks
        rerank_documents = True if rerank is not None else False
        _cfg_query_enhancement = (
            query_enhancement
            if query_enhancement is not None
            else QueryEnhancementConfig()
        )
        expand_query = _cfg_query_enhancement.expand
        expand_query_terms = _cfg_query_enhancement.expand_terms
        transform_query = _cfg_query_enhancement.transform
        answer_multiple_questions = _cfg_query_enhancement.multi_question
        do_nl_metadata_query = _cfg_query_enhancement.nl_metadata
        # Initialize with params
        params = {}
        params["do_advanced_qa"] = do_advanced_qa
        params["enable_filter"] = enable_filter
        params["rerank_documents"] = rerank_documents
        params["retrieval_unit"] = retrieval_unit
        params["enable_context"] = enable_context
        params["format_context_for_llm"] = format_context_for_llm
        params["enable_document_db_filter"] = enable_document_db_filter
        params["set_response_format"] = set_response_format
        params["stream_response"] = stream_response

        super().__init__(
            node_type="knowledge_base",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if top_k is not None:
            self.inputs["top_k"] = top_k
        if alpha is not None:
            self.inputs["alpha"] = alpha
        if score_cutoff is not None:
            self.inputs["score_cutoff"] = score_cutoff
        if retrieval_unit is not None:
            self.inputs["retrieval_unit"] = retrieval_unit
        if rerank_model is not None:
            self.inputs["rerank_model"] = rerank_model
        if num_chunks_to_rerank is not None:
            self.inputs["num_chunks_to_rerank"] = num_chunks_to_rerank
        if rerank_documents is not None:
            self.inputs["rerank_documents"] = rerank_documents
        if expand_query is not None:
            self.inputs["expand_query"] = expand_query
        if expand_query_terms is not None:
            self.inputs["expand_query_terms"] = expand_query_terms
        if transform_query is not None:
            self.inputs["transform_query"] = transform_query
        if answer_multiple_questions is not None:
            self.inputs["answer_multiple_questions"] = answer_multiple_questions
        if do_nl_metadata_query is not None:
            self.inputs["do_nl_metadata_query"] = do_nl_metadata_query
        if knowledge_base is not None:
            self.inputs["knowledge_base"] = knowledge_base
        if query is not None:
            self.inputs["query"] = query
        if enable_filter is not None:
            self.inputs["enable_filter"] = enable_filter
        if do_advanced_qa is not None:
            self.inputs["do_advanced_qa"] = do_advanced_qa
        if enable_context is not None:
            self.inputs["enable_context"] = enable_context
        if format_context_for_llm is not None:
            self.inputs["format_context_for_llm"] = format_context_for_llm
        if enable_document_db_filter is not None:
            self.inputs["enable_document_db_filter"] = enable_document_db_filter
        if set_response_format is not None:
            self.inputs["set_response_format"] = set_response_format
        if stream_response is not None:
            self.inputs["stream_response"] = stream_response
        if generate_metadata_filters is not None:
            self.inputs["generate_metadata_filters"] = generate_metadata_filters
        if qa_model_name is not None:
            self.inputs["qa_model_name"] = qa_model_name
        if advanced_search_mode is not None:
            self.inputs["advanced_search_mode"] = advanced_search_mode
        if filter is not None:
            self.inputs["filter"] = filter
        if context is not None:
            self.inputs["context"] = context
        if document_db_filter is not None:
            self.inputs["document_db_filter"] = document_db_filter
        if system_prompt is not None:
            self.inputs["system_prompt"] = system_prompt
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
