"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("ai_image_to_text")
class AiImageToTextNode(Node):
    """
    Generate Text from Image using AI

    ## Inputs
    ### Common Inputs
        prompt: Instructions on what you want to analyze from the image.
        system: Tell the AI model how you would like it to respond. Be as specific as possible. For example, you can instruct the model on what tone to respond in or how to respond given the information you provide
        temperature: The temperature of the model
        max_tokens: The maximum number of tokens to generate
        top_p: The top-p value
        image: The image for conversion
        json_response: Return the response as a JSON object
        provider: Select the provider that will be used to analyze image.
        stream: Stream the response
        use_personal_api_key: Use your personal API key
    ### When provider = 'openai'
        model: Select the image analyzing model.
    ### When provider = 'anthropic'
        model: Select the image analyzing model.
    ### When provider = 'google'
        model: Select the image analyzing model.
    ### When provider = 'xai'
        model: Select the image analyzing model.
    ### When use_personal_api_key = True
        api_key: Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run
    ### When json_response = True
        json_schema: The JSON schema to use for the response

    ## Outputs
    ### Common Outputs
        tokens_used: The number of tokens used
    ### When stream = False
        text: The Text from the Image.
    ### When stream = True
        text: Stream of text generated from the Image.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "prompt",
            "helper_text": "Instructions on what you want to analyze from the image.",
            "value": "",
            "type": "string",
        },
        {
            "field": "system",
            "helper_text": "Tell the AI model how you would like it to respond. Be as specific as possible. For example, you can instruct the model on what tone to respond in or how to respond given the information you provide",
            "value": "",
            "type": "string",
        },
        {
            "field": "temperature",
            "helper_text": "The temperature of the model",
            "value": 0.7,
            "type": "float",
        },
        {
            "field": "max_tokens",
            "helper_text": "The maximum number of tokens to generate",
            "value": 128000,
            "type": "int64",
        },
        {
            "field": "top_p",
            "helper_text": "The top-p value",
            "value": 0.9,
            "type": "float",
        },
        {
            "field": "image",
            "helper_text": "The image for conversion",
            "value": "",
            "type": "image",
        },
        {
            "field": "json_response",
            "helper_text": "Return the response as a JSON object",
            "value": False,
            "type": "bool",
        },
        {
            "field": "provider",
            "helper_text": "Select the provider that will be used to analyze image.",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "stream",
            "helper_text": "Stream the response",
            "value": False,
            "type": "bool",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "Use your personal API key",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "tokens_used",
            "helper_text": "The number of tokens used",
            "type": "int64",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "false**(*)**(*)**(*)": {"inputs": [], "outputs": []},
        "true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run",
                    "component": {
                        "type": "password",
                        "agent_field_type": "dynamic",
                        "disable_conversion": True,
                    },
                }
            ],
            "outputs": [],
        },
        "(*)**false**(*)**(*)": {"inputs": [], "outputs": []},
        "(*)**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "json_schema",
                    "type": "string",
                    "value": "",
                    "label": "JSON Schema",
                    "helper_text": "The JSON schema to use for the response",
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**false**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "The Text from the Image.",
                }
            ],
        },
        "(*)**(*)**true**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "text",
                    "type": "stream<string>",
                    "helper_text": "Stream of text generated from the Image.",
                }
            ],
        },
        "(*)**(*)**(*)**openai": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the image analyzing model.",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "image_to_text",
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                }
            ],
            "outputs": [],
            "title": "OpenAI Image to Text",
        },
        "(*)**(*)**(*)**anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the image analyzing model.",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "image_to_text",
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                }
            ],
            "outputs": [],
            "title": "Anthropic Image to Text",
        },
        "(*)**(*)**(*)**google": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the image analyzing model.",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "image_to_text",
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                }
            ],
            "outputs": [],
            "title": "Google Image to Text",
        },
        "(*)**(*)**(*)**xai": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the image analyzing model.",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "image_to_text",
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                }
            ],
            "outputs": [],
            "title": "XAI Image to Text",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_personal_api_key", "json_response", "stream", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["image", "api_key", "json_schema"]

    def __init__(
        self,
        use_personal_api_key: bool = False,
        json_response: bool = False,
        stream: bool = False,
        provider: str = "openai",
        model: str = "",
        prompt: str = "",
        system: str = "",
        api_key: str = "",
        image: Any = None,
        json_schema: str = "",
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["use_personal_api_key"] = use_personal_api_key
        params["json_response"] = json_response
        params["stream"] = stream
        params["provider"] = provider

        super().__init__(
            node_type="ai_image_to_text",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if provider is not None:
            self.inputs["provider"] = provider
        if system is not None:
            self.inputs["system"] = system
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if image is not None:
            self.inputs["image"] = image
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if json_response is not None:
            self.inputs["json_response"] = json_response
        if stream is not None:
            self.inputs["stream"] = stream
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if json_schema is not None:
            self.inputs["json_schema"] = json_schema
        if model is not None:
            self.inputs["model"] = model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiImageToTextNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
