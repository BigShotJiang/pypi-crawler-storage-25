"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("knowledge_base_loader")
class KnowledgeBaseLoaderNode(Node):
    """
    Load data into an existing knowledge base.

    ## Inputs
    ### Common Inputs
        document_type: Select the type of data to load
        knowledge_base: The knowledge base to load data into
        recursive: Scrape sub-pages of the provided link
    ### When document_type = 'File'
        documents: The file to be added to the selected knowledge base. Note: to convert text to file, use the Text to File node
    ### When document_type = 'URL' and recursive = True
        load_sitemap: Load URLs to crawl from a sitemap. If the URL is a sitemap, it will be used directly. If the URL is not a sitemap, the sitemap will be fetched automatically.
        max_depth: The maximum depth of the URL to crawl
        max_recursive_urls: The maximum number of recursive URLs to scrape
        rescrape_frequency: The frequency to rescrape the URL
        same_domain_only: Whether to only crawl links from the same domain
        url: The raw URL link (e.g., https://vectorshift.ai/)
        use_proxy: Use a proxy to crawl the website
    ### When document_type = 'URL' and recursive = False
        rescrape_frequency: The frequency to rescrape the URL
        url: The raw URL link (e.g., https://vectorshift.ai/)
        use_proxy: Use a proxy to crawl the website

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "document_type",
            "helper_text": "Select the type of data to load",
            "value": "File",
            "type": "enum<string>",
        },
        {
            "field": "knowledge_base",
            "helper_text": "The knowledge base to load data into",
            "value": {},
            "type": "knowledge_base",
        },
        {
            "field": "recursive",
            "helper_text": "Scrape sub-pages of the provided link",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "File**(*)": {
            "inputs": [
                {
                    "field": "documents",
                    "label": "Documents to load",
                    "type": "vec<file>",
                    "value": [""],
                    "helper_text": "The file to be added to the selected knowledge base. Note: to convert text to file, use the Text to File node",
                    "component": {
                        "type": "any",
                        "list_item_label": "Item $i",
                        "list_button_label": "Add Item",
                    },
                }
            ],
            "outputs": [],
        },
        "URL**false": {
            "inputs": [
                {
                    "field": "url",
                    "label": "URL to load",
                    "type": "string",
                    "value": "",
                    "helper_text": "The raw URL link (e.g., https://vectorshift.ai/)",
                },
                {
                    "field": "use_proxy",
                    "label": "Use proxy",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Use a proxy to crawl the website",
                },
                {
                    "field": "rescrape_frequency",
                    "label": "Rescrape Frequency",
                    "type": "enum<string>",
                    "value": "Never",
                    "helper_text": "The frequency to rescrape the URL",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Never", "value": "Never"},
                            {"label": "Daily", "value": "Daily"},
                            {"label": "Weekly", "value": "Weekly"},
                            {"label": "Monthly", "value": "Monthly"},
                        ],
                    },
                },
            ],
            "outputs": [],
        },
        "URL**true": {
            "inputs": [
                {
                    "field": "url",
                    "label": "URL to load",
                    "type": "string",
                    "value": "",
                    "helper_text": "The raw URL link (e.g., https://vectorshift.ai/)",
                },
                {
                    "field": "use_proxy",
                    "label": "Use proxy",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Use a proxy to crawl the website",
                },
                {
                    "field": "max_recursive_urls",
                    "label": "Max urls to crawl (max 800)",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "The maximum number of recursive URLs to scrape",
                },
                {
                    "field": "max_depth",
                    "label": "Max depth to crawl",
                    "type": "int32",
                    "value": 5,
                    "helper_text": "The maximum depth of the URL to crawl",
                },
                {
                    "field": "same_domain_only",
                    "label": "Same domain only",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to only crawl links from the same domain",
                },
                {
                    "field": "load_sitemap",
                    "label": "Load sitemap",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Load URLs to crawl from a sitemap. If the URL is a sitemap, it will be used directly. If the URL is not a sitemap, the sitemap will be fetched automatically.",
                },
                {
                    "field": "rescrape_frequency",
                    "label": "Rescrape Frequency",
                    "type": "enum<string>",
                    "value": "Never",
                    "helper_text": "The frequency to rescrape the URL",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Never", "value": "Never"},
                            {"label": "Daily", "value": "Daily"},
                            {"label": "Weekly", "value": "Weekly"},
                            {"label": "Monthly", "value": "Monthly"},
                        ],
                    },
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["document_type", "recursive"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["knowledge_base", "documents", "url"]

    def __init__(
        self,
        document_type: str = "File",
        recursive: bool = False,
        documents: List[str] = [""],
        knowledge_base: "KnowledgeBase" = "",
        load_sitemap: bool = False,
        max_depth: int = 5,
        max_recursive_urls: int = 10,
        rescrape_frequency: str = "Never",
        same_domain_only: bool = False,
        url: str = "",
        use_proxy: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["document_type"] = document_type
        params["recursive"] = recursive

        super().__init__(
            node_type="knowledge_base_loader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if knowledge_base is not None:
            self.inputs["knowledge_base"] = knowledge_base
        if document_type is not None:
            self.inputs["document_type"] = document_type
        if recursive is not None:
            self.inputs["recursive"] = recursive
        if documents is not None:
            self.inputs["documents"] = documents
        if url is not None:
            self.inputs["url"] = url
        if use_proxy is not None:
            self.inputs["use_proxy"] = use_proxy
        if rescrape_frequency is not None:
            self.inputs["rescrape_frequency"] = rescrape_frequency
        if max_recursive_urls is not None:
            self.inputs["max_recursive_urls"] = max_recursive_urls
        if max_depth is not None:
            self.inputs["max_depth"] = max_depth
        if same_domain_only is not None:
            self.inputs["same_domain_only"] = same_domain_only
        if load_sitemap is not None:
            self.inputs["load_sitemap"] = load_sitemap
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseLoaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
