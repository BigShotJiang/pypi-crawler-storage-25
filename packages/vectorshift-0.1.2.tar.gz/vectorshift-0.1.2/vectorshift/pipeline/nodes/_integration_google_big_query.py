"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_big_query")
class IntegrationGoogleBigQueryNode(Node):
    """
    Google BigQuery

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'execute_query'
        query: SQL query to execute
        dry_run: Validate query without executing
        project_id: The Google Cloud project ID
        timeout_ms: Query timeout in milliseconds
        use_legacy_sql: Use Legacy SQL syntax
    ### When action = 'insert_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'insert_rows'
        bigquery_table_id: The ID of the table to insert data into
        dataset_id: The ID of the dataset containing the table
        ignore_unknown_values: Ignore values that do not match the table schema
        project_id: The Google Cloud project ID
        skip_invalid_rows: Skip rows that contain invalid data

    ## Outputs
    ### When action = 'execute_query'
        cache_hit: Whether the query result was served from cache
        job_id: ID of the query job
        raw_data: Raw BigQuery API response in JSON format
        rows: Query results in JSON format
        schema: Result schema in JSON format
        total_bytes_processed: Total bytes processed by the query
        total_rows: Total number of rows returned
    ### When action = 'insert_rows'
        insert_errors: Array of any errors that occurred during insertion
        inserted_rows: Number of rows that were inserted
        raw_data: Raw BigQuery API response in JSON format
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google BigQuery>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "execute_query**(*)": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The Google Cloud project ID",
                    "label": "Project ID",
                    "placeholder": "Select a project",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "SQL query to execute",
                    "label": "Query",
                    "placeholder": "SELECT * FROM `project.dataset.table` LIMIT 10",
                    "order": 4,
                },
                {
                    "field": "use_legacy_sql",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Use Legacy SQL syntax",
                    "label": "Use Legacy SQL",
                    "order": 5,
                },
                {
                    "field": "dry_run",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Validate query without executing",
                    "label": "Dry Run",
                    "order": 6,
                },
                {
                    "field": "timeout_ms",
                    "type": "int32",
                    "value": 30000,
                    "helper_text": "Query timeout in milliseconds",
                    "label": "Timeout (ms)",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "job_id",
                    "type": "string",
                    "helper_text": "ID of the query job",
                },
                {
                    "field": "rows",
                    "type": "string",
                    "helper_text": "Query results in JSON format",
                },
                {
                    "field": "schema",
                    "type": "string",
                    "helper_text": "Result schema in JSON format",
                },
                {
                    "field": "total_rows",
                    "type": "string",
                    "helper_text": "Total number of rows returned",
                },
                {
                    "field": "total_bytes_processed",
                    "type": "string",
                    "helper_text": "Total bytes processed by the query",
                },
                {
                    "field": "cache_hit",
                    "type": "bool",
                    "helper_text": "Whether the query result was served from cache",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw BigQuery API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "execute_query",
            "task_name": "tasks.google_big_query.run_query",
            "description": "Execute a SQL query in Google BigQuery",
            "label": "Execute Query",
            "ui_sort_order": [
                "integration",
                "action",
                "project_id",
                "query",
                "use_legacy_sql",
                "dry_run",
                "timeout_ms",
            ],
            "required": ["project_id", "query"],
        },
        "insert_rows**(*)": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The Google Cloud project ID",
                    "label": "Project ID",
                    "placeholder": "Select a project",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the dataset containing the table",
                    "label": "Dataset ID",
                    "placeholder": "Select a dataset",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&project_id={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "bigquery_table_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the table to insert data into",
                    "label": "Table ID",
                    "placeholder": "Select a table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bigquery_table_id&project_id={inputs.project_id}&dataset_id={inputs.dataset_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "ignore_unknown_values",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Ignore values that do not match the table schema",
                    "label": "Ignore Unknown Values",
                    "order": 6,
                },
                {
                    "field": "skip_invalid_rows",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Skip rows that contain invalid data",
                    "label": "Skip Invalid Rows",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "insert_errors",
                    "type": "array",
                    "helper_text": "Array of any errors that occurred during insertion",
                },
                {
                    "field": "inserted_rows",
                    "type": "int32",
                    "helper_text": "Number of rows that were inserted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw BigQuery API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "insert_rows",
            "task_name": "tasks.google_big_query.insert_rows",
            "description": "Insert rows into a table in Google BigQuery",
            "label": "Insert Rows",
            "ui_sort_order": [
                "integration",
                "action",
                "project_id",
                "dataset_id",
                "bigquery_table_id",
                "ignore_unknown_values",
                "skip_invalid_rows",
            ],
            "required": ["project_id", "dataset_id", "bigquery_table_id"],
        },
        "insert_rows**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        bigquery_table_id: str = "",
        dataset_id: str = "",
        dry_run: bool = False,
        ignore_unknown_values: bool = False,
        project_id: str = "",
        skip_invalid_rows: bool = False,
        timeout_ms: int = 30000,
        use_legacy_sql: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_big_query",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if project_id is not None:
            self.inputs["project_id"] = project_id
        if query is not None:
            self.inputs["query"] = query
        if use_legacy_sql is not None:
            self.inputs["use_legacy_sql"] = use_legacy_sql
        if dry_run is not None:
            self.inputs["dry_run"] = dry_run
        if timeout_ms is not None:
            self.inputs["timeout_ms"] = timeout_ms
        if dataset_id is not None:
            self.inputs["dataset_id"] = dataset_id
        if bigquery_table_id is not None:
            self.inputs["bigquery_table_id"] = bigquery_table_id
        if ignore_unknown_values is not None:
            self.inputs["ignore_unknown_values"] = ignore_unknown_values
        if skip_invalid_rows is not None:
            self.inputs["skip_invalid_rows"] = skip_invalid_rows
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleBigQueryNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
