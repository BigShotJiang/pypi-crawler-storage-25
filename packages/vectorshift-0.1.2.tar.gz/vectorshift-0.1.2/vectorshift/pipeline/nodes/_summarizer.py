"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("summarizer")
class SummarizerNode(Node):
    """
    Summarize large texts using AI.

    ## Inputs
    ### Common Inputs
        model: The specific model for summarization
        text: The text to be summarized
        provider: The model provider

    ## Outputs
    ### Common Outputs
        summary: The summary of the text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for summarization",
            "value": "gpt-4o",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The text to be summarized",
            "value": "",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "summary", "helper_text": "The summary of the text", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "openai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "cohere": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "google": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "xai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "aws": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "azure": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "together": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for summarization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text"]

    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-4o",
        text: str = "",
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["provider"] = provider

        super().__init__(
            node_type="summarizer",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if text is not None:
            self.inputs["text"] = text
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "SummarizerNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
