"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_x")
class IntegrationXNode(Node):
    """
    X

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your X account
    ### create_post
        text: The text of the post
    ### create_thread
        text: The text of the post
    ### search_tweets
        query: Search query using X search operators
        end_time: Optional: Search tweets before this time
        include_retweets: Whether to include retweets in results
        max_results: Maximum number of tweets to return (10-100)
        sort_order: Sort tweets by recency or relevancy
        start_time: Optional: Search tweets after this time
    ### add_list_member
        list_id: ID of the list to add member to
        user_id: Alternative: User ID instead of username
        username: Username to get information for (without @)
    ### create_tweet
        media_urls: Optional: URLs of media to attach (up to 4)
        quote_tweet_id: Optional: ID of tweet to quote
        reply_to_tweet_id: Optional: ID of tweet to reply to
        tweet_text: The tweet content (max 280 characters)
    ### delete_tweet
        tweet_id: ID of the tweet to delete
    ### retweet_tweet
        tweet_id: ID of the tweet to delete
    ### get_user
        user_id: Alternative: User ID instead of username
        username: Username to get information for (without @)

    ## Outputs
    ### add_list_member
        added: Whether the user was successfully added
        list_id: ID of the list
        raw_data: Complete API response
        user_id: ID of the added user
    ### create_tweet
        author_id: ID of the tweet author
        created_at: Timestamp when the tweet was created
        raw_data: Complete API response
        tweet_id: ID of the created tweet
        tweet_url: URL to view the tweet
    ### search_tweets
        author_usernames: List of author usernames
        created_ats: List of creation timestamps
        like_counts: List of like counts
        raw_data: Complete API response
        retweet_counts: List of retweet counts
        total_results: Total number of tweets found
        tweet_ids: List of tweet IDs
        tweet_texts: List of tweet texts
    ### get_user
        bio: User's biography
        created_at: Account creation timestamp
        display_name: User's display name
        follower_count: Number of followers
        following_count: Number of accounts following
        profile_image_url: URL of profile image
        raw_data: Complete API response
        tweet_count: Number of tweets posted
        user_id: User's unique ID
        username: User's username (handle)
        verified: Whether the account is verified
    ### delete_tweet
        deleted: Whether the tweet was successfully deleted
        raw_data: Complete API response
        tweet_id: ID of the deleted tweet
    ### retweet_tweet
        original_tweet_id: ID of the original tweet
        raw_data: Complete API response
        retweet_id: ID of the retweet
        retweeted: Whether the tweet was successfully retweeted
    ### create_post
        post_url: URL of the created post
    ### create_thread
        post_url: URL of the created thread
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your X account",
            "value": None,
            "type": "integration<X>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_tweet": {
            "inputs": [
                {
                    "field": "tweet_text",
                    "type": "string",
                    "value": "",
                    "label": "Tweet Text",
                    "placeholder": "What's happening?",
                    "helper_text": "The tweet content (max 280 characters)",
                },
                {
                    "field": "reply_to_tweet_id",
                    "type": "string",
                    "value": "",
                    "label": "Reply to Tweet ID",
                    "placeholder": "1234567890123456789",
                    "helper_text": "Optional: ID of tweet to reply to",
                },
                {
                    "field": "media_urls",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Media URLs",
                    "helper_text": "Optional: URLs of media to attach (up to 4)",
                },
                {
                    "field": "quote_tweet_id",
                    "type": "string",
                    "value": "",
                    "label": "Quote Tweet ID",
                    "placeholder": "1234567890123456789",
                    "helper_text": "Optional: ID of tweet to quote",
                },
            ],
            "outputs": [
                {
                    "field": "tweet_id",
                    "type": "string",
                    "helper_text": "ID of the created tweet",
                },
                {
                    "field": "tweet_url",
                    "type": "string",
                    "helper_text": "URL to view the tweet",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the tweet was created",
                },
                {
                    "field": "author_id",
                    "type": "string",
                    "helper_text": "ID of the tweet author",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "name": "create_tweet",
            "task_name": "tasks.x.create_tweet",
            "description": "Create a new tweet or reply to an existing tweet",
            "label": "Create Tweet",
            "variant": "common_integration_nodes",
            "required": ["tweet_text"],
            "ui_sort_order": [
                "integration",
                "action",
                "tweet_text",
                "reply_to_tweet_id",
                "media_urls",
                "quote_tweet_id",
            ],
        },
        "delete_tweet": {
            "inputs": [
                {
                    "field": "tweet_id",
                    "type": "string",
                    "value": "",
                    "label": "Tweet ID",
                    "placeholder": "1234567890123456789",
                    "helper_text": "ID of the tweet to delete",
                }
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the tweet was successfully deleted",
                },
                {
                    "field": "tweet_id",
                    "type": "string",
                    "helper_text": "ID of the deleted tweet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "name": "delete_tweet",
            "task_name": "tasks.x.delete_tweet",
            "description": "Delete a tweet by ID",
            "label": "Delete Tweet",
            "variant": "common_integration_nodes",
            "required": ["tweet_id"],
            "ui_sort_order": ["integration", "action", "tweet_id"],
        },
        "search_tweets": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "VectorShift OR #AI",
                    "helper_text": "Search query using X search operators",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "label": "Max Results",
                    "helper_text": "Maximum number of tweets to return (10-100)",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "recency",
                    "label": "Sort Order",
                    "helper_text": "Sort tweets by recency or relevancy",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Recency", "value": "recency"},
                            {"label": "Relevancy", "value": "relevancy"},
                        ],
                    },
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start Time",
                    "placeholder": "2024-01-01T00:00:00Z",
                    "helper_text": "Optional: Search tweets after this time",
                },
                {
                    "field": "end_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "End Time",
                    "placeholder": "2024-12-31T23:59:59Z",
                    "helper_text": "Optional: Search tweets before this time",
                },
                {
                    "field": "include_retweets",
                    "type": "bool",
                    "value": True,
                    "label": "Include Retweets",
                    "helper_text": "Whether to include retweets in results",
                },
            ],
            "outputs": [
                {
                    "field": "tweet_ids",
                    "type": "vec<string>",
                    "helper_text": "List of tweet IDs",
                },
                {
                    "field": "tweet_texts",
                    "type": "vec<string>",
                    "helper_text": "List of tweet texts",
                },
                {
                    "field": "author_usernames",
                    "type": "vec<string>",
                    "helper_text": "List of author usernames",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "like_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of like counts",
                },
                {
                    "field": "retweet_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of retweet counts",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of tweets found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "name": "search_tweets",
            "task_name": "tasks.x.search_tweets",
            "description": "Search for tweets using X search operators",
            "label": "Search Tweets",
            "variant": "common_integration_nodes",
            "required": ["query", "max_results"],
            "ui_sort_order": [
                "integration",
                "action",
                "query",
                "max_results",
                "sort_order",
                "start_time",
                "end_time",
                "include_retweets",
            ],
        },
        "retweet_tweet": {
            "inputs": [
                {
                    "field": "tweet_id",
                    "type": "string",
                    "value": "",
                    "label": "Tweet ID",
                    "placeholder": "1234567890123456789",
                    "helper_text": "ID of the tweet to retweet",
                }
            ],
            "outputs": [
                {
                    "field": "retweeted",
                    "type": "bool",
                    "helper_text": "Whether the tweet was successfully retweeted",
                },
                {
                    "field": "retweet_id",
                    "type": "string",
                    "helper_text": "ID of the retweet",
                },
                {
                    "field": "original_tweet_id",
                    "type": "string",
                    "helper_text": "ID of the original tweet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "name": "retweet_tweet",
            "task_name": "tasks.x.retweet_tweet",
            "description": "Retweet a tweet by ID",
            "label": "Retweet Tweet",
            "variant": "common_integration_nodes",
            "required": ["tweet_id"],
            "ui_sort_order": ["integration", "action", "tweet_id"],
        },
        "get_user": {
            "inputs": [
                {
                    "field": "username",
                    "type": "string",
                    "value": "",
                    "label": "Username",
                    "placeholder": "elonmusk",
                    "helper_text": "Username to get information for (without @)",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "44196397",
                    "helper_text": "Alternative: User ID instead of username",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "User's unique ID",
                },
                {
                    "field": "username",
                    "type": "string",
                    "helper_text": "User's username (handle)",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "User's display name",
                },
                {"field": "bio", "type": "string", "helper_text": "User's biography"},
                {
                    "field": "follower_count",
                    "type": "int32",
                    "helper_text": "Number of followers",
                },
                {
                    "field": "following_count",
                    "type": "int32",
                    "helper_text": "Number of accounts following",
                },
                {
                    "field": "tweet_count",
                    "type": "int32",
                    "helper_text": "Number of tweets posted",
                },
                {
                    "field": "verified",
                    "type": "bool",
                    "helper_text": "Whether the account is verified",
                },
                {
                    "field": "profile_image_url",
                    "type": "string",
                    "helper_text": "URL of profile image",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Account creation timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.x.get_user",
            "description": "Get information about a user by username or ID",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "required": [],
            "ui_sort_order": ["integration", "action", "username", "user_id"],
        },
        "add_list_member": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List ID",
                    "placeholder": "1234567890123456789",
                    "helper_text": "ID of the list to add member to",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "44196397",
                    "helper_text": "ID of the user to add to the list",
                },
                {
                    "field": "username",
                    "type": "string",
                    "value": "",
                    "label": "Username",
                    "placeholder": "elonmusk",
                    "helper_text": "Alternative: Username instead of user ID (without @)",
                },
            ],
            "outputs": [
                {
                    "field": "added",
                    "type": "bool",
                    "helper_text": "Whether the user was successfully added",
                },
                {"field": "list_id", "type": "string", "helper_text": "ID of the list"},
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "ID of the added user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "name": "add_list_member",
            "task_name": "tasks.x.add_list_member",
            "description": "Add a member to a list",
            "label": "Add List Member",
            "variant": "common_integration_nodes",
            "required": ["list_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "list_id",
                "user_id",
                "username",
            ],
        },
        "create_post": {
            "inputs": [
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Text",
                    "placeholder": "Hello World!",
                    "helper_text": "The text of the post",
                }
            ],
            "outputs": [
                {
                    "field": "post_url",
                    "type": "string",
                    "helper_text": "URL of the created post",
                }
            ],
            "name": "create_post",
            "task_name": "tasks.x.create_post",
            "description": "Create a new post on X",
            "label": "Create Post",
            "ui_sort_order": ["integration", "action", "text"],
        },
        "create_thread": {
            "inputs": [
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Text",
                    "placeholder": '["Post1", "Post2", "Post3"]',
                    "helper_text": "A list of text to be posted as a thread",
                }
            ],
            "outputs": [
                {
                    "field": "post_url",
                    "type": "string",
                    "helper_text": "URL of the created thread",
                }
            ],
            "name": "create_thread",
            "task_name": "tasks.x.create_thread",
            "description": "Create a new thread on X",
            "label": "Create Thread",
            "ui_sort_order": ["integration", "action", "text"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        text: str = "",
        query: str = "",
        end_time: Any = -1,
        include_retweets: bool = True,
        list_id: str = "",
        max_results: int = 10,
        media_urls: List[str] = [],
        quote_tweet_id: str = "",
        reply_to_tweet_id: str = "",
        sort_order: str = "recency",
        start_time: Any = -1,
        tweet_id: str = "",
        tweet_text: str = "",
        user_id: str = "",
        username: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_x",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if tweet_text is not None:
            self.inputs["tweet_text"] = tweet_text
        if reply_to_tweet_id is not None:
            self.inputs["reply_to_tweet_id"] = reply_to_tweet_id
        if media_urls is not None:
            self.inputs["media_urls"] = media_urls
        if quote_tweet_id is not None:
            self.inputs["quote_tweet_id"] = quote_tweet_id
        if tweet_id is not None:
            self.inputs["tweet_id"] = tweet_id
        if query is not None:
            self.inputs["query"] = query
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if start_time is not None:
            self.inputs["start_time"] = start_time
        if end_time is not None:
            self.inputs["end_time"] = end_time
        if include_retweets is not None:
            self.inputs["include_retweets"] = include_retweets
        if username is not None:
            self.inputs["username"] = username
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if list_id is not None:
            self.inputs["list_id"] = list_id
        if text is not None:
            self.inputs["text"] = text
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationXNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
