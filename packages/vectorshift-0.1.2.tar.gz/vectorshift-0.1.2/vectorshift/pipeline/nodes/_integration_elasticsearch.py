"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_elasticsearch")
class IntegrationElasticsearchNode(Node):
    """
    Elasticsearch

    ## Inputs
    ### Common Inputs
        action: Select the operation to perform
        integration: Connect to your Elasticsearch cluster
    ### list_documents
        query: Elasticsearch query in JSON format (optional - defaults to match_all)
        from: Starting offset for pagination
        index: Elasticsearch index name
        limit: Maximum number of documents to return
    ### search_index
        query: Elasticsearch query in JSON format (optional - defaults to match_all)
        index: Elasticsearch index name
    ### delete_index
        confirm_delete: Confirm that you want to delete this index and all its data
        index: Elasticsearch index name
    ### create_document
        document: JSON document to index
        document_id: Unique identifier for the document (optional - will be auto-generated if empty)
        index: Elasticsearch index name
    ### update_document
        document: JSON document to index
        document_id: Unique identifier for the document (optional - will be auto-generated if empty)
        index: Elasticsearch index name
        upsert: Create document if it doesn't exist
    ### get_document
        document_id: Unique identifier for the document (optional - will be auto-generated if empty)
        index: Elasticsearch index name
    ### delete_document
        document_id: Unique identifier for the document (optional - will be auto-generated if empty)
        index: Elasticsearch index name
    ### list_indices
        include_system: Include system indices (starting with .)
        limit: Maximum number of documents to return
        pattern: Index pattern to match (use * for all indices)
    ### create_index
        index: Elasticsearch index name
        mappings: Index mappings in JSON format (optional)
        settings: Index settings in JSON format (optional)
    ### get_index
        index: Elasticsearch index name

    ## Outputs
    ### create_index
        acknowledged: Whether the operation was acknowledged
        index: Name of the created index
        raw_data: Raw Elasticsearch response
        shards_acknowledged: Whether the shard allocation was acknowledged
    ### delete_index
        acknowledged: Whether the deletion was acknowledged
        raw_data: Raw Elasticsearch response
    ### get_index
        aliases: Index aliases as JSON
        mappings: Index mappings as JSON
        raw_data: Raw Elasticsearch response
        settings: Index settings as JSON
    ### list_indices
        count: Number of indices found
        indices: List of indices as JSON array
        raw_data: Raw Elasticsearch response
    ### get_document
        document: Retrieved document content as JSON
        found: Whether the document was found
        raw_data: Raw Elasticsearch response
        version: Document version number
    ### create_document
        document_id: ID of the created document
        index: Index where the document was created
        raw_data: Raw Elasticsearch response
    ### update_document
        document_id: ID of the updated document
        raw_data: Raw Elasticsearch response
        result: Operation result (updated, created, or noop)
        version: New version number of the document
    ### list_documents
        documents: Retrieved documents as JSON array
        raw_data: Raw Elasticsearch response
        returned_count: Number of documents returned in this response
        total_hits: Total number of documents matching the query
    ### delete_document
        found: Whether the document was found and deleted
        raw_data: Raw Elasticsearch response
        result: Operation result (deleted or not_found)
    ### search_index
        output: Search results from the Elasticsearch index
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Elasticsearch cluster",
            "value": None,
            "type": "integration<Elasticsearch>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_document": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "doc-123",
                    "helper_text": "Unique identifier for the document (optional - will be auto-generated if empty)",
                },
                {
                    "field": "document",
                    "type": "string",
                    "value": "",
                    "label": "Document",
                    "placeholder": '{"title": "My Document", "content": "Document content here", "tags": ["important"]}',
                    "helper_text": "JSON document to index",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the created document",
                },
                {
                    "field": "index",
                    "type": "string",
                    "helper_text": "Index where the document was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "create_document",
            "task_name": "tasks.elasticsearch.create_document",
            "description": "Create a new document in an Elasticsearch index",
            "label": "Create Document",
            "variant": "common_integration_nodes",
            "required": ["index", "document"],
            "ui_sort_order": [
                "integration",
                "action",
                "index",
                "document_id",
                "document",
            ],
        },
        "get_document": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "doc-123",
                    "helper_text": "ID of the document to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "document",
                    "type": "string",
                    "helper_text": "Retrieved document content as JSON",
                },
                {
                    "field": "found",
                    "type": "bool",
                    "helper_text": "Whether the document was found",
                },
                {
                    "field": "version",
                    "type": "int32",
                    "helper_text": "Document version number",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "get_document",
            "task_name": "tasks.elasticsearch.get_document",
            "description": "Read details of a specific document",
            "label": "Get Document",
            "variant": "common_integration_nodes",
            "required": ["index", "document_id"],
            "ui_sort_order": ["integration", "action", "index", "document_id"],
        },
        "list_documents": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of documents to return",
                },
                {
                    "field": "from",
                    "type": "int32",
                    "value": 0,
                    "label": "From",
                    "helper_text": "Starting offset for pagination",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": '{"match_all": {}}',
                    "helper_text": "Elasticsearch query in JSON format (optional - defaults to match_all)",
                },
            ],
            "outputs": [
                {
                    "field": "documents",
                    "type": "string",
                    "helper_text": "Retrieved documents as JSON array",
                },
                {
                    "field": "total_hits",
                    "type": "int32",
                    "helper_text": "Total number of documents matching the query",
                },
                {
                    "field": "returned_count",
                    "type": "int32",
                    "helper_text": "Number of documents returned in this response",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "list_documents",
            "task_name": "tasks.elasticsearch.list_documents",
            "description": "Get multiple documents",
            "label": "List Documents",
            "variant": "common_integration_nodes",
            "required": ["index", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "index",
                "limit",
                "from",
                "query",
            ],
        },
        "update_document": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "doc-123",
                    "helper_text": "ID of the document to update",
                },
                {
                    "field": "document",
                    "type": "string",
                    "value": "",
                    "label": "Document",
                    "placeholder": '{"title": "Updated Title", "content": "Updated content"}',
                    "helper_text": "JSON document with updated fields",
                },
                {
                    "field": "upsert",
                    "type": "bool",
                    "value": False,
                    "label": "Upsert",
                    "helper_text": "Create document if it doesn't exist",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the updated document",
                },
                {
                    "field": "version",
                    "type": "int32",
                    "helper_text": "New version number of the document",
                },
                {
                    "field": "result",
                    "type": "string",
                    "helper_text": "Operation result (updated, created, or noop)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "update_document",
            "task_name": "tasks.elasticsearch.update_document",
            "description": "Update an existing document in an Elasticsearch index",
            "label": "Update Document",
            "variant": "common_integration_nodes",
            "required": ["index", "document_id", "document"],
            "ui_sort_order": [
                "integration",
                "action",
                "index",
                "document_id",
                "document",
                "upsert",
            ],
        },
        "delete_document": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "doc-123",
                    "helper_text": "ID of the document to delete",
                },
            ],
            "outputs": [
                {
                    "field": "found",
                    "type": "bool",
                    "helper_text": "Whether the document was found and deleted",
                },
                {
                    "field": "result",
                    "type": "string",
                    "helper_text": "Operation result (deleted or not_found)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "delete_document",
            "task_name": "tasks.elasticsearch.delete_document",
            "description": "Delete a document from an Elasticsearch index",
            "label": "Delete Document",
            "variant": "common_integration_nodes",
            "required": ["index", "document_id"],
            "ui_sort_order": ["integration", "action", "index", "document_id"],
        },
        "create_index": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index Name",
                    "placeholder": "my-new-index",
                    "helper_text": "Name for the new Elasticsearch index",
                },
                {
                    "field": "mappings",
                    "type": "string",
                    "value": "",
                    "label": "Mappings",
                    "placeholder": '{"properties": {"title": {"type": "text"}, "timestamp": {"type": "date"}}}',
                    "helper_text": "Index mappings in JSON format (optional)",
                },
                {
                    "field": "settings",
                    "type": "string",
                    "value": "",
                    "label": "Settings",
                    "placeholder": '{"number_of_shards": 1, "number_of_replicas": 0}',
                    "helper_text": "Index settings in JSON format (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "index",
                    "type": "string",
                    "helper_text": "Name of the created index",
                },
                {
                    "field": "acknowledged",
                    "type": "bool",
                    "helper_text": "Whether the operation was acknowledged",
                },
                {
                    "field": "shards_acknowledged",
                    "type": "bool",
                    "helper_text": "Whether the shard allocation was acknowledged",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "create_index",
            "task_name": "tasks.elasticsearch.create_index",
            "description": "Create a new Elasticsearch index with optional mappings and settings",
            "label": "Create Index",
            "variant": "common_integration_nodes",
            "required": ["index"],
            "ui_sort_order": ["integration", "action", "index", "mappings", "settings"],
        },
        "get_index": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "mappings",
                    "type": "string",
                    "helper_text": "Index mappings as JSON",
                },
                {
                    "field": "settings",
                    "type": "string",
                    "helper_text": "Index settings as JSON",
                },
                {
                    "field": "aliases",
                    "type": "string",
                    "helper_text": "Index aliases as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "get_index",
            "task_name": "tasks.elasticsearch.get_index",
            "description": "Get information about an Elasticsearch index",
            "label": "Get Index",
            "variant": "common_integration_nodes",
            "required": ["index"],
            "ui_sort_order": ["integration", "action", "index"],
        },
        "list_indices": {
            "inputs": [
                {
                    "field": "pattern",
                    "type": "string",
                    "value": "*",
                    "label": "Pattern",
                    "placeholder": "*",
                    "helper_text": "Index pattern to match (use * for all indices)",
                },
                {
                    "field": "include_system",
                    "type": "bool",
                    "value": False,
                    "label": "Include System Indices",
                    "helper_text": "Include system indices (starting with .)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of indices to return",
                },
            ],
            "outputs": [
                {
                    "field": "indices",
                    "type": "string",
                    "helper_text": "List of indices as JSON array",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of indices found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "list_indices",
            "task_name": "tasks.elasticsearch.list_indices",
            "description": "Get multiple indices",
            "label": "List Indices",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "pattern",
                "include_system",
                "limit",
            ],
        },
        "delete_index": {
            "inputs": [
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=index&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "confirm_delete",
                    "type": "bool",
                    "value": False,
                    "label": "Confirm Delete",
                    "helper_text": "Confirm that you want to delete this index and all its data",
                },
            ],
            "outputs": [
                {
                    "field": "acknowledged",
                    "type": "bool",
                    "helper_text": "Whether the deletion was acknowledged",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw Elasticsearch response",
                },
            ],
            "name": "delete_index",
            "task_name": "tasks.elasticsearch.delete_index",
            "description": "Delete an Elasticsearch index and all its documents",
            "label": "Delete Index",
            "variant": "common_integration_nodes",
            "required": ["index", "confirm_delete"],
            "ui_sort_order": ["integration", "action", "index", "confirm_delete"],
        },
        "search_index": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "JSON Query",
                    "placeholder": '{"query_string": {"query": "mountain*", "fields": ["title", "description"]}}',
                    "helper_text": "Query to search over index in JSON format",
                },
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "my-index",
                    "helper_text": "Elasticsearch index name",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Search results from the Elasticsearch index",
                }
            ],
            "name": "search_index",
            "task_name": "tasks.elasticsearch.search_index",
            "description": "Query your Elasticsearch index",
            "label": "Search Elasticsearch index",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        confirm_delete: bool = False,
        document: str = "",
        document_id: str = "",
        from_: int = 0,
        include_system: bool = False,
        index: str = "",
        limit: int = 10,
        mappings: str = "",
        pattern: str = "*",
        settings: str = "",
        upsert: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_elasticsearch",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if index is not None:
            self.inputs["index"] = index
        if document_id is not None:
            self.inputs["document_id"] = document_id
        if document is not None:
            self.inputs["document"] = document
        if limit is not None:
            self.inputs["limit"] = limit
        if from_ is not None:
            self.inputs["from"] = from_
        if query is not None:
            self.inputs["query"] = query
        if upsert is not None:
            self.inputs["upsert"] = upsert
        if mappings is not None:
            self.inputs["mappings"] = mappings
        if settings is not None:
            self.inputs["settings"] = settings
        if pattern is not None:
            self.inputs["pattern"] = pattern
        if include_system is not None:
            self.inputs["include_system"] = include_system
        if confirm_delete is not None:
            self.inputs["confirm_delete"] = confirm_delete
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if from_ is not None:
            self.inputs["from"] = from_
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationElasticsearchNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
