"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("image_gen")
class ImageGenNode(Node):
    """


    ## Inputs
    ### Common Inputs
        model: The model input
        prompt: The prompt input
        aspect_ratio: The aspect_ratio input
        image_count: The image_count input
        provider: The provider input
        size: The size input

    ## Outputs
    ### Common Outputs
        images: The images output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The model input",
            "value": "gpt-4-1106-preview",
            "type": "string",
        },
        {
            "field": "prompt",
            "helper_text": "The prompt input",
            "value": "",
            "type": "string",
        },
        {
            "field": "aspect_ratio",
            "helper_text": "The aspect_ratio input",
            "value": "1:1",
            "type": "string",
        },
        {
            "field": "image_count",
            "helper_text": "The image_count input",
            "value": "1",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "The provider input",
            "value": "llmOpenAI",
            "type": "string",
        },
        {
            "field": "size",
            "helper_text": "The size input",
            "value": "512x512",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "images", "helper_text": "The images output", "type": "vec<image>"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    def __init__(
        self,
        model: str = "gpt-4-1106-preview",
        prompt: str = "",
        aspect_ratio: str = "1:1",
        image_count: str = "1",
        provider: str = "llmOpenAI",
        size: str = "512x512",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="image_gen",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if size is not None:
            self.inputs["size"] = size
        if aspect_ratio is not None:
            self.inputs["aspect_ratio"] = aspect_ratio
        if image_count is not None:
            self.inputs["image_count"] = image_count
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ImageGenNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
