"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import NameItem


@Node.register_node_type("listen")
class ListenNode(Node):
    """
    Listen for user input at a stage in the conversation.

    ## Inputs
    ### Common Inputs
        variant: The variant input
    ### button
        allow_user_message: The allow_user_message input
        buttons: The buttons input
        processed_outputs: The processed_outputs input

    ## Outputs
    ### button
        [processed_outputs]: The [processed_outputs] output
        user_message: The user_message output
    ### capture
        response: The user message.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "variant",
            "helper_text": "The variant input",
            "value": "",
            "type": "string",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "button": {
            "title": "Button",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/listen/button",
            "helper_text": "Present users with clickable buttons during a conversation at this step and wait for the user to select one.",
            "short_description": "Present users with clickable buttons during a conversation at this step and wait for the user to select one.",
            "inputs": [
                {
                    "field": "buttons",
                    "type": "vec<interface{name: string,id: string}>",
                    "value": [{"name": "Button 1", "id": "button_1"}],
                    "component": {
                        "type": "table",
                        "decorators": {
                            "hide": ["general_input_label", "multiple_switch"]
                        },
                        "vertical_table_layout": True,
                        "table": {
                            "name": {
                                "label": "Button",
                                "auto_increment_prefix": "Button",
                                "auto_increment_snake_case": False,
                            }
                        },
                        "processed_field": "processed_outputs",
                        "processed_key_field": "id",
                        "processed_value_default": "path",
                        "id_prefix": "button",
                    },
                },
                {
                    "field": "processed_outputs",
                    "visibility": False,
                    "type": "map<string, string>",
                    "value": {"button_1": "path"},
                },
                {
                    "field": "variant",
                    "type": "string",
                    "value": "button",
                    "visibility": False,
                },
                {
                    "field": "allow_user_message",
                    "label": "Allow user message",
                    "type": "bool",
                    "value": False,
                    "component": {"type": "bool"},
                },
            ],
            "outputs": [
                {"field": "[processed_outputs]", "type": ""},
                {
                    "field": "user_message",
                    "type": "path",
                    "value": "",
                    "visibility": {
                        "field": "allow_user_message",
                        "operator": "==",
                        "value": True,
                    },
                },
            ],
            "show_output_handle": False,
        },
        "capture": {
            "title": "Capture",
            "advanced_settings": True,
            "batch_mode": False,
            "documentation_url": "https://docs.vectorshift.ai/platform/pipelines/conversational/listen/capture",
            "helper_text": "The conversation will pause at this step in the conversation and wait for the user to respond in chat. The user response will be stored in the capture response variable.",
            "short_description": "The conversation will pause at this step in the conversation and wait for the user to respond in chat. The user response will be stored in the capture response variable.",
            "inputs": [
                {
                    "field": "variant",
                    "type": "string",
                    "value": "capture",
                    "visibility": False,
                }
            ],
            "outputs": [
                {
                    "field": "response",
                    "type": "string",
                    "value": "",
                    "helper_text": "The user message.",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["variant"]

    _batch_mode_allowed = True

    def __init__(
        self,
        variant: str = "",
        allow_user_message: bool = False,
        buttons: List[NameItem] = [{"name": "Button 1", "id": "button_1"}],
        processed_outputs: Dict[str, str] = {"button_1": "path"},
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["variant"] = variant

        super().__init__(
            node_type="listen",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if variant is not None:
            self.inputs["variant"] = variant
        if buttons is not None:
            self.inputs["buttons"] = buttons
        if processed_outputs is not None:
            self.inputs["processed_outputs"] = processed_outputs
        if allow_user_message is not None:
            self.inputs["allow_user_message"] = allow_user_message
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ListenNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
