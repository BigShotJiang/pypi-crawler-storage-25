"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("chunking")
class ChunkingNode(Node):
    """
    Split text into chunks. Supports different chunking strategies like markdown-aware, sentence-based, or dynamic sizing.

    ## Inputs
    ### Common Inputs
        text: The text to chunk
        chunk_overlap: The overlap of each chunk of text.
        chunk_size: The size of each chunk of text.
        splitter_method: Strategy for grouping segmented text into final chunks. 'sentence': groups sentences; 'markdown': respects Markdown structure (headers, code); 'dynamic': optimizes breaks for size using chosen segmentation method.
    ### dynamic
        segmentation_method: The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.

    ## Outputs
    ### Common Outputs
        chunks: The chunks output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "text",
            "helper_text": "The text to chunk",
            "value": "",
            "type": "string",
        },
        {
            "field": "chunk_overlap",
            "helper_text": "The overlap of each chunk of text.",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "chunk_size",
            "helper_text": "The size of each chunk of text.",
            "value": 512,
            "type": "int32",
        },
        {
            "field": "splitter_method",
            "helper_text": "Strategy for grouping segmented text into final chunks. 'sentence': groups sentences; 'markdown': respects Markdown structure (headers, code); 'dynamic': optimizes breaks for size using chosen segmentation method.",
            "value": "markdown",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "chunks", "helper_text": "The chunks output", "type": "vec<string>"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "dynamic": {
            "inputs": [
                {
                    "field": "segmentation_method",
                    "type": "string",
                    "value": "words",
                    "helper_text": "The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Words", "value": "words"},
                            {"label": "Sentences", "value": "sentences"},
                            {"label": "Paragraphs", "value": "paragraphs"},
                        ],
                    },
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["splitter_method"]

    _batch_mode_allowed = True

    def __init__(
        self,
        splitter_method: str = "markdown",
        text: str = "",
        chunk_overlap: int = 0,
        chunk_size: int = 512,
        segmentation_method: str = "words",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["splitter_method"] = splitter_method

        super().__init__(
            node_type="chunking",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if text is not None:
            self.inputs["text"] = text
        if chunk_size is not None:
            self.inputs["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            self.inputs["chunk_overlap"] = chunk_overlap
        if splitter_method is not None:
            self.inputs["splitter_method"] = splitter_method
        if segmentation_method is not None:
            self.inputs["segmentation_method"] = segmentation_method
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ChunkingNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
