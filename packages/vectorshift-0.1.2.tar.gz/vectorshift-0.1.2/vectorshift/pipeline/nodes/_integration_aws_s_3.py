"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_aws_s_3")
class IntegrationAwsS3Node(Node):
    """
    AWS S3

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your AWS account
    ### create_bucket
        bucket_name: Enter the name of the bucket to create
        public_read_access: Allow public read access to objects
        region: AWS region for the bucket
        versioning_enabled: Enable object versioning for this bucket
    ### delete_bucket
        bucket_name: Enter the name of the bucket to create
    ### search_bucket
        bucket_name: Enter the name of the bucket to create
        max_results: Maximum number of results to return
        search_query: Search for objects containing this text in their key
    ### upload_file
        bucket_name: Enter the name of the bucket to create
        content_type: MIME type of the file (optional)
        file: Select a file to upload
        metadata: Custom metadata as JSON
        object_key: Enter the key (path) for the object
        storage_class: Select the storage class
    ### list_files
        bucket_name: Enter the name of the bucket to create
        max_keys: Maximum number of objects to return
        prefix: Filter objects by prefix
    ### list_folders
        bucket_name: Enter the name of the bucket to create
        delimiter: Delimiter for folder structure
        prefix: Filter objects by prefix
    ### copy_file
        destination_key: Select the folder and enter the filename
        source_key: Select the source object
    ### create_folder
        folder_name: Name of the new folder to create
        parent_folder_id: Select the parent folder (optional - leave empty to create in bucket root)
    ### delete_folder
        folder_name: Name of the new folder to create
        force_delete: Delete folder even if it contains files
    ### download_file
        object_key: Enter the key (path) for the object
    ### delete_file
        object_key: Enter the key (path) for the object

    ## Outputs
    ### create_bucket
        bucket_name: The name of the created bucket
        location: The region where the bucket was created
        raw_data: The raw API response data
    ### upload_file
        bucket_name: The bucket containing the object
        etag: The ETag of the object
        object_key: The key of the uploaded object
        raw_data: The raw API response data
        size: The size of the object in bytes
        url: The S3 URL of the object
        version_id: The version ID of the object (if versioning enabled)
    ### download_file
        bucket_name: The bucket containing the object
        content: The content of the object (if text-based)
        content_length: The size of the object in bytes
        content_type: The content type of the object
        etag: The ETag of the object
        file: The downloaded file
        last_modified: When the object was last modified
        metadata: Custom metadata of the object
        object_key: The key of the downloaded object
        raw_data: The raw API response data
    ### create_folder
        bucket_name: The bucket containing the folder
        folder_name: The name of the created folder
        raw_data: The raw API response data
    ### list_buckets
        bucket_names: List of bucket names
        buckets: List of bucket objects
        creation_dates: List of bucket creation dates
        raw_data: The raw API response data
    ### delete_folder
        deleted_count: Number of objects deleted
        deleted_objects: List of deleted object keys
        message: Success or error message
    ### copy_file
        destination_key: The destination object key
        etag: The ETag of the copied object
        raw_data: The raw API response data
        source_key: The source object key
    ### list_files
        etags: List of object ETags
        last_modified_dates: List of last modified dates
        object_keys: List of object keys
        object_sizes: List of object sizes in bytes
        objects: List of object metadata
        raw_data: The raw API response data
        truncated: Whether the result was truncated
    ### list_folders
        folder_count: Number of folders found
        folder_names: List of folder names
        folders: JSON array of folder prefixes
        raw_data: The raw API response data
    ### delete_bucket
        message: Success or error message
    ### delete_file
        message: Success or error message
        version_id: Version ID of the deleted object (if versioning enabled)
    ### search_bucket
        object_count: Number of matching objects found
        object_keys: List of matching object keys
        objects: JSON array of matching objects
        raw_data: The raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your AWS account",
            "value": None,
            "type": "integration<Aws S3>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_bucket": {
            "inputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "value": "",
                    "label": "Bucket Name",
                    "helper_text": "Enter the name of the bucket to create",
                    "placeholder": "my-s3-bucket",
                },
                {
                    "field": "region",
                    "type": "string",
                    "value": "us-east-1",
                    "label": "Region",
                    "helper_text": "AWS region for the bucket",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "US East (N. Virginia)", "value": "us-east-1"},
                            {"label": "US East (Ohio)", "value": "us-east-2"},
                            {"label": "US West (N. California)", "value": "us-west-1"},
                            {"label": "US West (Oregon)", "value": "us-west-2"},
                            {"label": "Africa (Cape Town)", "value": "af-south-1"},
                            {"label": "Asia Pacific (Hong Kong)", "value": "ap-east-1"},
                            {
                                "label": "Asia Pacific (Hyderabad)",
                                "value": "ap-south-2",
                            },
                            {
                                "label": "Asia Pacific (Jakarta)",
                                "value": "ap-southeast-3",
                            },
                            {
                                "label": "Asia Pacific (Melbourne)",
                                "value": "ap-southeast-4",
                            },
                            {"label": "Asia Pacific (Mumbai)", "value": "ap-south-1"},
                            {
                                "label": "Asia Pacific (Osaka)",
                                "value": "ap-northeast-3",
                            },
                            {
                                "label": "Asia Pacific (Seoul)",
                                "value": "ap-northeast-2",
                            },
                            {
                                "label": "Asia Pacific (Singapore)",
                                "value": "ap-southeast-1",
                            },
                            {
                                "label": "Asia Pacific (Sydney)",
                                "value": "ap-southeast-2",
                            },
                            {
                                "label": "Asia Pacific (Tokyo)",
                                "value": "ap-northeast-1",
                            },
                            {"label": "Canada (Central)", "value": "ca-central-1"},
                            {"label": "Canada West (Calgary)", "value": "ca-west-1"},
                            {"label": "Europe (Frankfurt)", "value": "eu-central-1"},
                            {"label": "Europe (Ireland)", "value": "eu-west-1"},
                            {"label": "Europe (London)", "value": "eu-west-2"},
                            {"label": "Europe (Milan)", "value": "eu-south-1"},
                            {"label": "Europe (Paris)", "value": "eu-west-3"},
                            {"label": "Europe (Spain)", "value": "eu-south-2"},
                            {"label": "Europe (Stockholm)", "value": "eu-north-1"},
                            {"label": "Europe (Zurich)", "value": "eu-central-2"},
                            {"label": "Israel (Tel Aviv)", "value": "il-central-1"},
                            {"label": "Middle East (Bahrain)", "value": "me-south-1"},
                            {"label": "Middle East (UAE)", "value": "me-central-1"},
                            {
                                "label": "South America (São Paulo)",
                                "value": "sa-east-1",
                            },
                        ],
                    },
                },
                {
                    "field": "versioning_enabled",
                    "type": "bool",
                    "value": False,
                    "label": "Enable Versioning",
                    "helper_text": "Enable object versioning for this bucket",
                },
                {
                    "field": "public_read_access",
                    "type": "bool",
                    "value": False,
                    "label": "Public Read Access",
                    "helper_text": "Allow public read access to objects",
                },
            ],
            "outputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The name of the created bucket",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The region where the bucket was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "create_bucket",
            "task_name": "tasks.aws_s3.create_bucket",
            "description": "Creates a new bucket in Amazon S3",
            "label": "Create Bucket",
            "input_sort_order": [
                "integration",
                "action",
                "bucket_name",
                "region",
                "versioning_enabled",
                "public_read_access",
            ],
            "required": ["bucket_name", "region"],
        },
        "list_buckets": {
            "inputs": [],
            "outputs": [
                {
                    "field": "buckets",
                    "type": "string",
                    "helper_text": "List of bucket objects",
                },
                {
                    "field": "bucket_names",
                    "type": "vec<string>",
                    "helper_text": "List of bucket names",
                },
                {
                    "field": "creation_dates",
                    "type": "vec<string>",
                    "helper_text": "List of bucket creation dates",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "list_buckets",
            "task_name": "tasks.aws_s3.list_buckets",
            "description": "Lists all buckets in the AWS account",
            "label": "List Buckets",
            "input_sort_order": ["integration", "action"],
        },
        "delete_bucket": {
            "inputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "hidden": True,
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                }
            ],
            "name": "delete_bucket",
            "task_name": "tasks.aws_s3.delete_bucket",
            "description": "Deletes a bucket from Amazon S3",
            "label": "Delete Bucket",
            "variant": "common_integration_file_nodes",
            "input_sort_order": ["integration", "action", "bucket_name"],
            "required": ["bucket_name"],
        },
        "search_bucket": {
            "inputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "hidden": True,
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket to search within",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "search_query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "helper_text": "Search for objects containing this text in their key",
                    "placeholder": "documents/",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 100,
                    "label": "Max Results",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "100",
                },
            ],
            "outputs": [
                {
                    "field": "objects",
                    "type": "string",
                    "helper_text": "JSON array of matching objects",
                },
                {
                    "field": "object_keys",
                    "type": "vec<string>",
                    "helper_text": "List of matching object keys",
                },
                {
                    "field": "object_count",
                    "type": "int32",
                    "helper_text": "Number of matching objects found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "search_bucket",
            "task_name": "tasks.aws_s3.search_bucket",
            "description": "Search for objects within an S3 bucket by key name",
            "label": "Search Within Bucket",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "bucket_name",
                "search_query",
                "max_results",
            ],
            "required": ["bucket_name", "search_query"],
        },
        "upload_file": {
            "inputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "hidden": True,
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "object_key",
                    "type": "string",
                    "value": "",
                    "label": "Object Key",
                    "helper_text": "Enter the key (path) for the object",
                    "placeholder": "folder/subfolder/file.txt",
                },
                {
                    "field": "file",
                    "type": "file",
                    "label": "File",
                    "helper_text": "Select a file to upload",
                    "value": "",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "",
                    "label": "Content Type",
                    "helper_text": "MIME type of the file (optional)",
                    "placeholder": "text/plain",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "value": "STANDARD",
                    "label": "Storage Class",
                    "helper_text": "Select the storage class",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Standard", "value": "STANDARD"},
                            {
                                "label": "Reduced Redundancy",
                                "value": "REDUCED_REDUNDANCY",
                            },
                            {"label": "Standard-IA", "value": "STANDARD_IA"},
                            {"label": "One Zone-IA", "value": "ONEZONE_IA"},
                            {"label": "Glacier", "value": "GLACIER"},
                            {"label": "Deep Archive", "value": "DEEP_ARCHIVE"},
                        ],
                    },
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "value": "",
                    "label": "Metadata",
                    "helper_text": "Custom metadata as JSON",
                    "placeholder": '{"key": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "object_key",
                    "type": "string",
                    "helper_text": "The key of the uploaded object",
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The bucket containing the object",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "The ETag of the object",
                },
                {
                    "field": "version_id",
                    "type": "string",
                    "helper_text": "The version ID of the object (if versioning enabled)",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "The size of the object in bytes",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "The S3 URL of the object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "upload_file",
            "task_name": "tasks.aws_s3.upload_file",
            "description": "Upload a file to Amazon S3 with optional metadata and storage class",
            "label": "Upload File",
            "variant": "common_integration_file_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "bucket_name",
                "object_key",
                "file",
                "content_type",
                "storage_class",
                "metadata",
            ],
            "required": ["bucket_name", "object_key", "file"],
        },
        "download_file": {
            "inputs": [
                {
                    "field": "object_key",
                    "type": "string",
                    "hidden": True,
                    "label": "Object Key",
                    "helper_text": "Select the object to download",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {"field": "file", "type": "file", "helper_text": "The downloaded file"},
                {
                    "field": "object_key",
                    "type": "string",
                    "helper_text": "The key of the downloaded object",
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The bucket containing the object",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "The content of the object (if text-based)",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "The content type of the object",
                },
                {
                    "field": "content_length",
                    "type": "string",
                    "helper_text": "The size of the object in bytes",
                },
                {
                    "field": "last_modified",
                    "type": "timestamp",
                    "helper_text": "When the object was last modified",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "The ETag of the object",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "helper_text": "Custom metadata of the object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "download_file",
            "task_name": "tasks.aws_s3.download_file",
            "description": "Download a file from Amazon S3 and retrieve its content and metadata",
            "label": "Download File",
            "variant": "common_integration_file_nodes",
            "input_sort_order": ["integration", "action", "object_key"],
            "required": ["object_key"],
        },
        "list_files": {
            "inputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "hidden": True,
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "prefix",
                    "type": "string",
                    "value": "",
                    "label": "Prefix",
                    "helper_text": "Filter objects by prefix",
                    "placeholder": "folder/",
                },
                {
                    "field": "max_keys",
                    "type": "int32",
                    "value": 10,
                    "label": "Max Keys",
                    "helper_text": "Maximum number of objects to return",
                    "placeholder": "10",
                },
            ],
            "outputs": [
                {
                    "field": "objects",
                    "type": "string",
                    "helper_text": "List of object metadata",
                },
                {
                    "field": "object_keys",
                    "type": "vec<string>",
                    "helper_text": "List of object keys",
                },
                {
                    "field": "object_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of object sizes in bytes",
                },
                {
                    "field": "last_modified_dates",
                    "type": "vec<string>",
                    "helper_text": "List of last modified dates",
                },
                {
                    "field": "etags",
                    "type": "vec<string>",
                    "helper_text": "List of object ETags",
                },
                {
                    "field": "truncated",
                    "type": "bool",
                    "helper_text": "Whether the result was truncated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "list_files",
            "task_name": "tasks.aws_s3.list_files",
            "description": "Get multiple files",
            "label": "List Files",
            "variant": "common_integration_file_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "bucket_name",
                "prefix",
                "max_keys",
            ],
            "required": ["bucket_name"],
        },
        "delete_file": {
            "inputs": [
                {
                    "field": "object_key",
                    "type": "string",
                    "hidden": True,
                    "label": "Object Key",
                    "helper_text": "Select the object to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "version_id",
                    "type": "string",
                    "helper_text": "Version ID of the deleted object (if versioning enabled)",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
            ],
            "name": "delete_file",
            "task_name": "tasks.aws_s3.delete_file",
            "description": "Delete a file from Amazon S3",
            "label": "Delete File",
            "variant": "common_integration_file_nodes",
            "input_sort_order": ["integration", "action", "object_key"],
            "required": ["object_key"],
        },
        "copy_file": {
            "inputs": [
                {
                    "field": "source_key",
                    "type": "string",
                    "hidden": True,
                    "label": "Source Object Key",
                    "helper_text": "Select the source object",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "destination_key",
                    "type": "string",
                    "value": "",
                    "label": "Destination Key",
                    "helper_text": "Select the folder and enter the filename",
                    "placeholder": "folder/new-file.txt",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "source_key",
                    "type": "string",
                    "helper_text": "The source object key",
                },
                {
                    "field": "destination_key",
                    "type": "string",
                    "helper_text": "The destination object key",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "The ETag of the copied object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "copy_file",
            "task_name": "tasks.aws_s3.copy_file",
            "description": "Copy a file from one location to another in Amazon S3",
            "label": "Copy File",
            "variant": "common_integration_file_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "source_key",
                "destination_key",
            ],
            "required": ["source_key", "destination_key"],
        },
        "create_folder": {
            "inputs": [
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select the parent folder (optional - leave empty to create in bucket root)",
                    "label": "Parent Folder",
                    "placeholder": "",
                    "order": 3,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "label": "Folder Name",
                    "helper_text": "Name of the new folder to create",
                    "placeholder": "New Folder",
                },
            ],
            "outputs": [
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "The name of the created folder",
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The bucket containing the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.aws_s3.create_folder",
            "description": "Create a folder in Amazon S3 by creating a placeholder object",
            "label": "Create Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "parent_folder_id",
                "folder_name",
            ],
            "required": ["folder_name"],
        },
        "delete_folder": {
            "inputs": [
                {
                    "field": "folder_name",
                    "type": "string",
                    "hidden": True,
                    "value": "",
                    "label": "Folder Name",
                    "helper_text": "Select the folder to delete",
                    "placeholder": "folder/subfolder/",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "force_delete",
                    "type": "bool",
                    "value": False,
                    "label": "Force Delete",
                    "helper_text": "Delete folder even if it contains files",
                },
            ],
            "outputs": [
                {
                    "field": "deleted_objects",
                    "type": "vec<string>",
                    "helper_text": "List of deleted object keys",
                },
                {
                    "field": "deleted_count",
                    "type": "int32",
                    "helper_text": "Number of objects deleted",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
            ],
            "name": "delete_folder",
            "task_name": "tasks.aws_s3.delete_folder",
            "description": "Delete a folder and optionally all its contents from Amazon S3",
            "label": "Delete Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "folder_name", "force_delete"],
            "required": ["folder_name"],
        },
        "list_folders": {
            "inputs": [
                {
                    "field": "bucket_name",
                    "type": "string",
                    "hidden": True,
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "prefix",
                    "type": "string",
                    "value": "",
                    "label": "Prefix",
                    "helper_text": "Filter folders by prefix",
                    "placeholder": "folder/",
                },
                {
                    "field": "delimiter",
                    "type": "string",
                    "value": "/",
                    "label": "Delimiter",
                    "helper_text": "Delimiter for folder structure",
                    "placeholder": "/",
                },
            ],
            "outputs": [
                {
                    "field": "folders",
                    "type": "string",
                    "helper_text": "JSON array of folder prefixes",
                },
                {
                    "field": "folder_names",
                    "type": "vec<string>",
                    "helper_text": "List of folder names",
                },
                {
                    "field": "folder_count",
                    "type": "int32",
                    "helper_text": "Number of folders found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "list_folders",
            "task_name": "tasks.aws_s3.list_folders",
            "description": "Get multiple folders",
            "label": "List Folders",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "bucket_name",
                "prefix",
                "delimiter",
            ],
            "required": ["bucket_name"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        bucket_name: str = "",
        content_type: str = "",
        delimiter: str = "/",
        destination_key: str = "",
        file: str = "",
        folder_name: str = "",
        force_delete: bool = False,
        max_keys: int = 10,
        max_results: int = 100,
        metadata: str = "",
        object_key: str = "",
        parent_folder_id: str = "",
        prefix: str = "",
        public_read_access: bool = False,
        region: str = "us-east-1",
        search_query: str = "",
        source_key: Optional[str] = None,
        storage_class: str = "STANDARD",
        versioning_enabled: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_aws_s_3",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if bucket_name is not None:
            self.inputs["bucket_name"] = bucket_name
        if region is not None:
            self.inputs["region"] = region
        if versioning_enabled is not None:
            self.inputs["versioning_enabled"] = versioning_enabled
        if public_read_access is not None:
            self.inputs["public_read_access"] = public_read_access
        if search_query is not None:
            self.inputs["search_query"] = search_query
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if object_key is not None:
            self.inputs["object_key"] = object_key
        if file is not None:
            self.inputs["file"] = file
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if storage_class is not None:
            self.inputs["storage_class"] = storage_class
        if metadata is not None:
            self.inputs["metadata"] = metadata
        if prefix is not None:
            self.inputs["prefix"] = prefix
        if max_keys is not None:
            self.inputs["max_keys"] = max_keys
        if source_key is not None:
            self.inputs["source_key"] = source_key
        if destination_key is not None:
            self.inputs["destination_key"] = destination_key
        if parent_folder_id is not None:
            self.inputs["parent_folder_id"] = parent_folder_id
        if folder_name is not None:
            self.inputs["folder_name"] = folder_name
        if force_delete is not None:
            self.inputs["force_delete"] = force_delete
        if delimiter is not None:
            self.inputs["delimiter"] = delimiter
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationAwsS3Node":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
