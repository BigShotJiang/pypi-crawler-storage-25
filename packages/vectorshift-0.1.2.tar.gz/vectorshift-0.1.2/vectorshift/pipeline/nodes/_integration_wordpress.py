"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_wordpress")
class IntegrationWordpressNode(Node):
    """
    Wordpress

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### create_post
        post_content: The content of the post
        post_title: The title of the post
        wordpress_url: Wordpress domain URL

    ## Outputs
    ### create_post
        post_url: URL of the created WordPress post
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Wordpress>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "default_integration_nodes"},
        "create_post": {
            "inputs": [
                {
                    "field": "wordpress_url",
                    "type": "string",
                    "value": "",
                    "label": "Wordpress URL",
                    "placeholder": "test.wordpress.com",
                    "helper_text": "Wordpress domain URL",
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "post_title",
                    "type": "string",
                    "value": "",
                    "label": "Post Title",
                    "placeholder": "An overview of Generative AI",
                    "helper_text": "The title of the post",
                },
                {
                    "field": "post_content",
                    "type": "string",
                    "value": "",
                    "label": "Post Content",
                    "placeholder": "This is an overview...",
                    "helper_text": "The content of the post",
                },
            ],
            "outputs": [
                {
                    "field": "post_url",
                    "type": "string",
                    "helper_text": "URL of the created WordPress post",
                }
            ],
            "name": "create_post",
            "task_name": "tasks.wordpress.create_post",
            "description": "Create post on Wordpress site",
            "label": "Post to Wordpress",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        post_content: str = "",
        post_title: str = "",
        wordpress_url: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_wordpress",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if wordpress_url is not None:
            self.inputs["wordpress_url"] = wordpress_url
        if post_title is not None:
            self.inputs["post_title"] = post_title
        if post_content is not None:
            self.inputs["post_content"] = post_content
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationWordpressNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
