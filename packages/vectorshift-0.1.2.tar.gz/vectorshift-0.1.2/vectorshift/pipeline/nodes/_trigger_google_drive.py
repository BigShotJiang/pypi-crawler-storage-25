"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_google_drive")
class TriggerGoogleDriveNode(Node):
    """
    Google Drive Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        trigger_enabled: Enable/Disable Automation
    ### new_file
        item_id: Select the folder to watch
    ### updated_file
        item_id: Select the folder to watch
    ### new_folder
        item_id: Select the folder to watch

    ## Outputs
    ### new_file
        created_time: When the file was created
        description: Description of the file
        download_link: Direct download link for the file
        file_id: Unique identifier of the file
        last_modifier_email: Email of the last person who modified the file
        last_modifier_name: Name of the last person who modified the file
        mime_type: MIME type of the file
        modified_time: When the file was last modified
        name: Name of the file
        owner_email: Email of the file owner
        owner_name: Name of the file owner
        parent_folder_ids: IDs of parent folders
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_view_link: Link to view the file in browser
    ### updated_file
        created_time: When the file was created
        description: Description of the file
        download_link: Direct download link for the file
        file_id: Unique identifier of the file
        last_modifier_email: Email of the last person who modified the file
        last_modifier_name: Name of the last person who modified the file
        mime_type: MIME type of the file
        modified_time: When the file was last modified
        name: Name of the file
        owner_email: Email of the file owner
        owner_name: Name of the file owner
        parent_folder_ids: IDs of parent folders
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_view_link: Link to view the file in browser
    ### new_folder
        created_time: When the folder was created
        description: Description of the folder
        file_id: Unique identifier of the folder
        last_modifier_email: Email of the last person who modified the folder
        last_modifier_name: Name of the last person who modified the folder
        modified_time: When the folder was last modified
        name: Name of the folder
        owner_email: Email of the folder owner
        owner_name: Name of the folder owner
        parent_folder_ids: IDs of parent folders
        trigger_timestamp: When this trigger was activated
        web_view_link: Link to view the folder in browser
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Google Drive>",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_file": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select the folder to watch",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the file",
                },
                {"field": "name", "type": "string", "helper_text": "Name of the file"},
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_view_link",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "download_link",
                    "type": "string",
                    "helper_text": "Direct download link for the file",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the file",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the file owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the file owner",
                },
                {
                    "field": "last_modifier_email",
                    "type": "string",
                    "helper_text": "Email of the last person who modified the file",
                },
                {
                    "field": "last_modifier_name",
                    "type": "string",
                    "helper_text": "Name of the last person who modified the file",
                },
                {
                    "field": "parent_folder_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of parent folders",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_file",
            "task_name": "tasks.google_drive.new_file",
            "description": "Triggers when a new file is created in the specified folder",
            "label": "New File",
        },
        "updated_file": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "File/Folder",
                    "helper_text": "Select the file/folder to watch",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the file",
                },
                {"field": "name", "type": "string", "helper_text": "Name of the file"},
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_view_link",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "download_link",
                    "type": "string",
                    "helper_text": "Direct download link for the file",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the file",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the file owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the file owner",
                },
                {
                    "field": "last_modifier_email",
                    "type": "string",
                    "helper_text": "Email of the last person who modified the file",
                },
                {
                    "field": "last_modifier_name",
                    "type": "string",
                    "helper_text": "Name of the last person who modified the file",
                },
                {
                    "field": "parent_folder_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of parent folders",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_file",
            "task_name": "tasks.google_drive.updated_file",
            "description": "Triggers when the selected file is updated, or when any file is updated in the selected folder",
            "label": "Updated File",
        },
        "new_folder": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select the folder to watch",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the folder",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "web_view_link",
                    "type": "string",
                    "helper_text": "Link to view the folder in browser",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the folder",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the folder owner",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the folder owner",
                },
                {
                    "field": "last_modifier_email",
                    "type": "string",
                    "helper_text": "Email of the last person who modified the folder",
                },
                {
                    "field": "last_modifier_name",
                    "type": "string",
                    "helper_text": "Name of the last person who modified the folder",
                },
                {
                    "field": "parent_folder_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of parent folders",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_folder",
            "task_name": "tasks.google_drive.new_folder",
            "description": "Triggers when a new folder is created in the specified folder",
            "label": "New Folder",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_google_drive",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerGoogleDriveNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
