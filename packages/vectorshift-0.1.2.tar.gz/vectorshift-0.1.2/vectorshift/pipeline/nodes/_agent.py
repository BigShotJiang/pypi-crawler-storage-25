"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("agent")
class AgentNode(Node):
    """
    Agent

    ## Inputs
    ### Common Inputs
        agent: The ID of the agent to be used
        use_existing_agent: Whether to use an existing agent
    ### When use_existing_agent = False
        model: Select the LLM model to be used
        [processed_inputs]: The [processed_inputs] input
        agent_config: The complete agent configuration including instructions, tools, inputs, and outputs
        processed_inputs: Dynamic inputs generated from agent inputs configuration
        processed_outputs: Dynamic outputs generated from agent outputs configuration
        provider: Select the LLM provider to be used
    ### When use_existing_agent = True and agent = '[<A>]'
        [<A>.inputs]: The [<A>.inputs] input

    ## Outputs
    ### When use_existing_agent = True and agent = '[<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When use_existing_agent = False
        [processed_outputs]: The [processed_outputs] output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "agent",
            "helper_text": "The ID of the agent to be used",
            "value": {"object_id": "", "object_type": ObjectType.AGENT},
            "type": "agent",
        },
        {
            "field": "use_existing_agent",
            "helper_text": "Whether to use an existing agent",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**[<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "false**(*)": {
            "inputs": [
                {
                    "field": "agent_config",
                    "type": "any",
                    "value": {},
                    "label": "Agent Config",
                    "helper_text": "The complete agent configuration including instructions, tools, inputs, and outputs",
                    "is_hidden_in_agent": True,
                    "ignore_variables": {"node": True, "agent": False},
                },
                {
                    "field": "provider",
                    "type": "enum<string>",
                    "value": "openai",
                    "label": "Provider",
                    "helper_text": "Select the LLM provider to be used",
                    "is_advanced_setting": True,
                    "is_hidden_in_agent": True,
                },
                {
                    "field": "model",
                    "type": "enum<string>",
                    "value": "gpt-4.1",
                    "label": "Model",
                    "helper_text": "Select the LLM model to be used",
                    "placeholder": "Select Model",
                    "is_hidden_in_agent": True,
                },
                {
                    "field": "processed_inputs",
                    "type": "map<string, string>",
                    "value": {},
                    "helper_text": "Dynamic inputs generated from agent inputs configuration",
                    "is_hidden_in_agent": True,
                },
                {
                    "field": "processed_outputs",
                    "type": "map<string, string>",
                    "value": {},
                    "helper_text": "Dynamic outputs generated from agent outputs configuration",
                    "is_hidden_in_agent": True,
                },
                {"field": "[processed_inputs]", "type": "", "is_hidden_in_agent": True},
            ],
            "outputs": [
                {"field": "[processed_outputs]", "type": "", "is_hidden_in_agent": True}
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_existing_agent", "agent"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["use_existing_agent", "agent"]

    def __init__(
        self,
        use_existing_agent: bool = False,
        agent: "Agent" = "",
        model: str = "gpt-4.1",
        agent_config: Any = {},
        processed_inputs: Dict[str, str] = {},
        processed_outputs: Dict[str, str] = {},
        provider: str = "openai",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["use_existing_agent"] = use_existing_agent
        params["agent"] = agent

        super().__init__(
            node_type="agent",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if agent is not None:
            self.inputs["agent"] = agent
        if use_existing_agent is not None:
            self.inputs["use_existing_agent"] = use_existing_agent
        if agent_config is not None:
            self.inputs["agent_config"] = agent_config
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if processed_inputs is not None:
            self.inputs["processed_inputs"] = processed_inputs
        if processed_outputs is not None:
            self.inputs["processed_outputs"] = processed_outputs
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AgentNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
