"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("time")
class TimeNode(Node):
    """
    Outputs the current time (often connected to LLM node)

    ## Inputs
    ### Common Inputs
        delta_time_unit: The unit of the delta
        delta_value: The value of the delta
        is_positive: If the time should be positive
        is_positive_delta: If the time should be positive
        output_format: The format of the output time
        time_node_zone: The timezone of the time node
        use_delta: Adjust the current time by adding or subtracting a specific amount. Use this to offset the time from the selected timezone

    ## Outputs
    ### Common Outputs
        processed_time: The time from the node
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "delta_time_unit",
            "helper_text": "The unit of the delta",
            "value": "Seconds",
            "type": "string",
        },
        {
            "field": "delta_value",
            "helper_text": "The value of the delta",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "is_positive",
            "helper_text": "If the time should be positive",
            "value": "+",
            "type": "string",
        },
        {
            "field": "is_positive_delta",
            "helper_text": "If the time should be positive",
            "value": True,
            "type": "bool",
        },
        {
            "field": "output_format",
            "helper_text": "The format of the output time",
            "value": "MM/DD/YYYY",
            "type": "string",
        },
        {
            "field": "time_node_zone",
            "helper_text": "The timezone of the time node",
            "value": "America/New_York",
            "type": "string",
        },
        {
            "field": "use_delta",
            "helper_text": "Adjust the current time by adding or subtracting a specific amount. Use this to offset the time from the selected timezone",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "processed_time",
            "helper_text": "The time from the node",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = False

    def __init__(
        self,
        delta_time_unit: str = "Seconds",
        delta_value: int = 0,
        is_positive: str = "+",
        is_positive_delta: bool = True,
        output_format: str = "MM/DD/YYYY",
        time_node_zone: str = "America/New_York",
        use_delta: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="time",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if is_positive is not None:
            self.inputs["is_positive"] = is_positive
        if use_delta is not None:
            self.inputs["use_delta"] = use_delta
        if is_positive_delta is not None:
            self.inputs["is_positive_delta"] = is_positive_delta
        if delta_value is not None:
            self.inputs["delta_value"] = delta_value
        if delta_time_unit is not None:
            self.inputs["delta_time_unit"] = delta_time_unit
        if output_format is not None:
            self.inputs["output_format"] = output_format
        if time_node_zone is not None:
            self.inputs["time_node_zone"] = time_node_zone
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TimeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
