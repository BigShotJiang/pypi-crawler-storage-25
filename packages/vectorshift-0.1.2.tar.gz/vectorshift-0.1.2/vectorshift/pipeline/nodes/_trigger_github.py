"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_github")
class TriggerGithubNode(Node):
    """
    GitHub Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        trigger_enabled: Enable/Disable Automation
    ### push
        item_id: Select the repository to watch for new commits
    ### pull_request
        item_id: Select the repository to watch for new commits
    ### issues
        item_id: Select the repository to watch for new commits
    ### issue_comment
        item_id: Select the repository to watch for new commits
    ### workflow_run
        item_id: Select the repository to watch for new commits
    ### release
        item_id: Select the repository to watch for new commits
    ### delete
        item_id: Select the repository to watch for new commits
    ### repository
        item_id: Select the repository to watch for new commits
    ### deployment
        item_id: Select the repository to watch for new commits
    ### pull_request_review
        item_id: Select the repository to watch for new commits
    ### dev_pr_merged_to_main
        item_id: Select the repository to watch for new commits

    ## Outputs
    ### pull_request
        action: Action that triggered the event (opened, closed, etc.)
        base_ref: Base branch/ref of the pull request
        head_ref: Head branch/ref of the pull request
        html_url: HTML URL of the pull request
        merged: Whether the pull request is merged
        pull_request_number: Pull request number
        raw_data: Complete raw data for this GitHub event
        reviewers: List of all requested reviewers for the pull request
    ### issues
        action: Action that triggered the event (opened, closed, etc.)
        html_url: HTML URL of the issue
        issue_number: Issue number
        raw_data: Complete raw data for this GitHub event
        state: State of the issue (open, closed)
        title: Title of the issue
        user: Username of the issue author
    ### issue_comment
        action: Action that triggered the event (created, edited, deleted)
        comment_body: Body/content of the comment
        comment_id: Comment ID
        comment_url: HTML URL of the comment
        issue_number: Issue number that the comment belongs to
        raw_data: Complete raw data for this GitHub event
        user: Username of the comment author
    ### workflow_run
        action: Action that triggered the event (requested, completed, etc.)
        conclusion: Conclusion of the workflow run (success, failure, cancelled, etc.)
        head_branch: Branch that triggered the workflow run
        head_sha: SHA of the commit that triggered the workflow run
        html_url: HTML URL of the workflow run
        raw_data: Complete raw data for this GitHub event
        status: Status of the workflow run (queued, in_progress, completed)
        workflow_name: Name of the workflow
        workflow_run_id: Workflow run ID
    ### release
        action: Action that triggered the event (published, created, edited, deleted, prereleased, released)
        author: Username of the release author
        body: Release notes/body
        draft: Whether the release is a draft
        html_url: HTML URL of the release
        name: Name of the release
        prerelease: Whether the release is a prerelease
        raw_data: Complete raw data for this GitHub event
        release_id: Release ID
        tag_name: Tag name of the release
    ### repository
        action: Action that triggered the event (created, deleted, archived, unarchived, publicized, privatized, edited, renamed, transferred)
        raw_data: Complete raw data for this GitHub event
        repository_id: Repository ID
        repository_name: Full name of the repository (owner/repo)
        repository_url: HTML URL of the repository
        user: Username of the user who performed the action
        visibility: Visibility of the repository (public or private)
    ### deployment
        action: Action that triggered the event (created)
        creator: Username of the user who created the deployment
        deployment_id: Deployment ID
        description: Deployment description
        environment: Environment name (e.g., production, staging)
        raw_data: Complete raw data for this GitHub event
        ref: Branch or tag being deployed
        sha: SHA of the commit being deployed
    ### pull_request_review
        action: Action that triggered the event (submitted, edited, or dismissed)
        body: The body of the review
        pull_request_id: The ID of the pull request
        pull_request_number: The number of the pull request
        raw_data: Complete raw data for this GitHub event
        review_id: The ID of the pull request review
        reviewer: Username of the user who created the review
        state: The review state (e.g., approved, changes_requested, commented)
    ### push
        author_email: Email of the commit author
        author_name: Name of the commit author
        branch: Branch name (e.g., refs/heads/main)
        commit_message: Commit message
        commit_sha: SHA of the commit
        commit_url: URL of the commit
        raw_data: Complete raw data for this GitHub event
        repository: Full name of the repository (owner/repo)
    ### dev_pr_merged_to_main
        base_ref: Base branch that was merged into (main)
        head_ref: Head branch that was merged (dev)
        html_url: HTML URL of the pull request
        merged_by: Username of the person who merged the pull request
        pull_request_number: Pull request number
        raw_data: Complete raw data for this GitHub event
        reviewers: List of all requested reviewers for the pull request
    ### delete
        pusher_type: Type of user who deleted the reference
        raw_data: Complete raw data for this GitHub event
        ref: Name of the branch or tag that was deleted
        ref_type: Type of reference deleted (branch or tag)
        user: Username of the user who deleted the reference
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Github>",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "push": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for new commits",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "commit_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "helper_text": "Commit message",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "helper_text": "Name of the commit author",
                },
                {
                    "field": "author_email",
                    "type": "string",
                    "helper_text": "Email of the commit author",
                },
                {
                    "field": "commit_url",
                    "type": "string",
                    "helper_text": "URL of the commit",
                },
                {
                    "field": "branch",
                    "type": "string",
                    "helper_text": "Branch name (e.g., refs/heads/main)",
                },
                {
                    "field": "repository",
                    "type": "string",
                    "helper_text": "Full name of the repository (owner/repo)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "push",
            "task_name": "tasks.github.push",
            "description": "Triggers when new commits are pushed to the repository",
            "label": "New Commit",
        },
        "pull_request": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for pull requests",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (opened, closed, etc.)",
                },
                {
                    "field": "pull_request_number",
                    "type": "int32",
                    "helper_text": "Pull request number",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "HTML URL of the pull request",
                },
                {
                    "field": "head_ref",
                    "type": "string",
                    "helper_text": "Head branch/ref of the pull request",
                },
                {
                    "field": "base_ref",
                    "type": "string",
                    "helper_text": "Base branch/ref of the pull request",
                },
                {
                    "field": "merged",
                    "type": "boolean",
                    "helper_text": "Whether the pull request is merged",
                },
                {
                    "field": "reviewers",
                    "type": "vec<string>",
                    "helper_text": "List of all requested reviewers for the pull request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "pull_request",
            "task_name": "tasks.github.pull_request",
            "description": "Triggers when a pull request is created, updated, or closed",
            "label": "New Pull Request",
        },
        "issues": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for issues",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (opened, closed, etc.)",
                },
                {
                    "field": "issue_number",
                    "type": "int32",
                    "helper_text": "Issue number",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "HTML URL of the issue",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "State of the issue (open, closed)",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "Username of the issue author",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "issues",
            "task_name": "tasks.github.issues",
            "description": "Triggers when an issue is created, updated, or closed",
            "label": "New Issue",
        },
        "issue_comment": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for issue comments",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (created, edited, deleted)",
                },
                {"field": "comment_id", "type": "int32", "helper_text": "Comment ID"},
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Body/content of the comment",
                },
                {
                    "field": "comment_url",
                    "type": "string",
                    "helper_text": "HTML URL of the comment",
                },
                {
                    "field": "issue_number",
                    "type": "int32",
                    "helper_text": "Issue number that the comment belongs to",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "Username of the comment author",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "issue_comment",
            "task_name": "tasks.github.issue_comment",
            "description": "Triggers when a comment is created, edited, or deleted on an issue",
            "label": "New Issue Comment",
        },
        "workflow_run": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for workflow runs",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (requested, completed, etc.)",
                },
                {
                    "field": "workflow_run_id",
                    "type": "int32",
                    "helper_text": "Workflow run ID",
                },
                {
                    "field": "workflow_name",
                    "type": "string",
                    "helper_text": "Name of the workflow",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the workflow run (queued, in_progress, completed)",
                },
                {
                    "field": "conclusion",
                    "type": "string",
                    "helper_text": "Conclusion of the workflow run (success, failure, cancelled, etc.)",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "HTML URL of the workflow run",
                },
                {
                    "field": "head_branch",
                    "type": "string",
                    "helper_text": "Branch that triggered the workflow run",
                },
                {
                    "field": "head_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit that triggered the workflow run",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "workflow_run",
            "task_name": "tasks.github.workflow_run",
            "description": "Triggers when a GitHub Actions workflow run is requested or completed",
            "label": "Workflow Run",
        },
        "release": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for releases",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (published, created, edited, deleted, prereleased, released)",
                },
                {"field": "release_id", "type": "int32", "helper_text": "Release ID"},
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the release",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the release",
                },
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "Release notes/body",
                },
                {
                    "field": "draft",
                    "type": "boolean",
                    "helper_text": "Whether the release is a draft",
                },
                {
                    "field": "prerelease",
                    "type": "boolean",
                    "helper_text": "Whether the release is a prerelease",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "HTML URL of the release",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Username of the release author",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "release",
            "task_name": "tasks.github.release",
            "description": "Triggers when a release is published, created, edited, or deleted",
            "label": "New Release",
        },
        "delete": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for branch or tag deletions",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "ref",
                    "type": "string",
                    "helper_text": "Name of the branch or tag that was deleted",
                },
                {
                    "field": "ref_type",
                    "type": "string",
                    "helper_text": "Type of reference deleted (branch or tag)",
                },
                {
                    "field": "pusher_type",
                    "type": "string",
                    "helper_text": "Type of user who deleted the reference",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "Username of the user who deleted the reference",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "delete",
            "task_name": "tasks.github.delete",
            "description": "Triggers when a branch or tag is deleted",
            "label": "Branch or Tag Deletion",
        },
        "repository": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for repository events",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (created, deleted, archived, unarchived, publicized, privatized, edited, renamed, transferred)",
                },
                {
                    "field": "repository_id",
                    "type": "int32",
                    "helper_text": "Repository ID",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Full name of the repository (owner/repo)",
                },
                {
                    "field": "repository_url",
                    "type": "string",
                    "helper_text": "HTML URL of the repository",
                },
                {
                    "field": "visibility",
                    "type": "string",
                    "helper_text": "Visibility of the repository (public or private)",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "Username of the user who performed the action",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "repository",
            "task_name": "tasks.github.repository",
            "description": "Triggers when a repository is created, deleted, archived, or modified",
            "label": "Repository Event",
        },
        "deployment": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for deployments",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (created)",
                },
                {
                    "field": "deployment_id",
                    "type": "int32",
                    "helper_text": "Deployment ID",
                },
                {
                    "field": "sha",
                    "type": "string",
                    "helper_text": "SHA of the commit being deployed",
                },
                {
                    "field": "ref",
                    "type": "string",
                    "helper_text": "Branch or tag being deployed",
                },
                {
                    "field": "environment",
                    "type": "string",
                    "helper_text": "Environment name (e.g., production, staging)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Deployment description",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "helper_text": "Username of the user who created the deployment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "deployment",
            "task_name": "tasks.github.deployment",
            "description": "Triggers when a deployment is created",
            "label": "Deployment",
        },
        "pull_request_review": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for pull request reviews",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action that triggered the event (submitted, edited, or dismissed)",
                },
                {
                    "field": "review_id",
                    "type": "int32",
                    "helper_text": "The ID of the pull request review",
                },
                {
                    "field": "pull_request_id",
                    "type": "int32",
                    "helper_text": "The ID of the pull request",
                },
                {
                    "field": "pull_request_number",
                    "type": "int32",
                    "helper_text": "The number of the pull request",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "The review state (e.g., approved, changes_requested, commented)",
                },
                {
                    "field": "reviewer",
                    "type": "string",
                    "helper_text": "Username of the user who created the review",
                },
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "The body of the review",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "pull_request_review",
            "task_name": "tasks.github.pull_request_review",
            "description": "Triggers when a pull request review is submitted, edited, or dismissed",
            "label": "Pull Request Review",
        },
        "dev_pr_merged_to_main": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Repository",
                    "helper_text": "Select the repository to watch for dev-to-main merges",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "pull_request_number",
                    "type": "int32",
                    "helper_text": "Pull request number",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "HTML URL of the pull request",
                },
                {
                    "field": "head_ref",
                    "type": "string",
                    "helper_text": "Head branch that was merged (dev)",
                },
                {
                    "field": "base_ref",
                    "type": "string",
                    "helper_text": "Base branch that was merged into (main)",
                },
                {
                    "field": "merged_by",
                    "type": "string",
                    "helper_text": "Username of the person who merged the pull request",
                },
                {
                    "field": "reviewers",
                    "type": "vec<string>",
                    "helper_text": "List of all requested reviewers for the pull request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete raw data for this GitHub event",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "dev_pr_merged_to_main",
            "task_name": "tasks.github.dev_pr_merged_to_main",
            "description": "Triggers when a pull request from dev is merged into main",
            "label": "Pull Request from Dev Merged to Main",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_github",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerGithubNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
