"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("merge")
class MergeNode(Node):
    """
    Recombine paths created by a condition node. Note: if you are not using a condition node, you shouldn’t use a merge node

    ## Inputs
    ### Common Inputs
        function: The function to apply to the input fields
        type: The expected type of the input and output fields
    ### When type = '<T>'
        fields: The fields input

    ## Outputs
    ### When function = 'first' and type = '<T>'
        output: The Text from the path based on the condition node
    ### When function = 'join' and type = '<T>'
        output: The Text from the path based on the condition node
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "function",
            "helper_text": "The function to apply to the input fields",
            "value": "first",
            "type": "string",
        },
        {
            "field": "type",
            "helper_text": "The expected type of the input and output fields",
            "value": "string",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**<T>": {
            "inputs": [
                {
                    "field": "fields",
                    "label": "Path",
                    "type": "vec<<T>>",
                    "value": [""],
                    "component": {
                        "type": "text",
                        "decorators": {
                            "hide": ["general_input_label", "multiple_switch"]
                        },
                        "list_item_label": "Path $i",
                        "list_button_label": "Add Path",
                    },
                }
            ],
            "outputs": [],
        },
        "first**<T>": {
            "inputs": [],
            "outputs": [
                {
                    "field": "output",
                    "type": "<T>",
                    "helper_text": "The Text from the path based on the condition node",
                }
            ],
        },
        "join**<T>": {
            "inputs": [],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<<T>>",
                    "helper_text": "The Text from the path based on the condition node",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["function", "type"]

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = ["fields"]

    def __init__(
        self,
        function: str = "first",
        type: str = "string",
        fields: List[Any] = [""],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["function"] = function
        params["type"] = type

        super().__init__(
            node_type="merge",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if type is not None:
            self.inputs["type"] = type
        if function is not None:
            self.inputs["function"] = function
        if fields is not None:
            self.inputs["fields"] = fields
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "MergeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
