"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_databricks")
class IntegrationDatabricksNode(Node):
    """
    Databricks

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'execute_query'
        query: SQL query to execute against the Databricks SQL Warehouse
        catalog_name: Select the name of the Catalog
        on_wait_timeout: Action to take when timeout is reached
        schema_name: Select the name of the Schema
        wait_timeout: Timeout for waiting for query completion (e.g., 30s, 1m, 5m)
        warehouse_id: Select the ID of the Warehouse to perform the action
    ### When action = 'insert_row' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'create_cluster'
        autotermination_minutes: Auto-termination time in minutes ( Set to 0 to disable auto-termination )
        cluster_name: Name of the cluster
        enable_elastic_disk: Enable elastic disk for the cluster
        node_type_id: Node type for cluster instances
        num_workers: Number of worker nodes
        spark_version: Spark version for the cluster
    ### When action = 'insert_row'
        catalog_name: Select the name of the Catalog
        schema_name: Select the name of the Schema
        table_name: Select the name of Table to insert the row
        warehouse_id: Select the ID of the Warehouse to perform the action
    ### When action = 'delete_cluster'
        cluster_id: ID of the cluster to delete
    ### When action = 'read_cluster'
        cluster_id: ID of the cluster to delete
    ### When action = 'create_job'
        cluster_id: ID of the cluster to delete
        job_name: Name of the job
        max_concurrent_runs: Maximum number of concurrent runs
        notebook_path: Path to the notebook
        timeout_seconds: Timeout in seconds
    ### When action = 'upload_file'
        file: File to upload
        overwrite: Overwrite existing file
        path: Path of the directory to create
    ### When action = 'get_clusters'
        num_messages: Maximum number of clusters to retrieve
    ### When action = 'get_groups'
        num_messages: Maximum number of clusters to retrieve
    ### When action = 'create_directory'
        path: Path of the directory to create
    ### When action = 'get_directory_contents'
        path: Path of the directory to create
    ### When action = 'delete_file'
        path: Path of the directory to create
    ### When action = 'delete_directory'
        path: Path of the directory to create
        recursive: Delete directory recursively

    ## Outputs
    ### When action = 'get_clusters'
        cluster_details: Complete cluster details in JSON format
        cluster_ids: List of cluster IDs
        cluster_names: List of cluster names
        cluster_states: List of cluster states
        creator_user_names: List of cluster creator usernames
        raw_data: Raw response data in JSON format
        spark_versions: List of spark versions
    ### When action = 'create_cluster'
        cluster_id: ID of the created cluster
        cluster_name: Name of the created cluster
        creator_user_name: Username of the cluster creator
        raw_data: Complete cluster details in JSON format
        spark_version: Spark version of the cluster
        state: Current state of the cluster
    ### When action = 'delete_cluster'
        cluster_id: ID of the deleted cluster
        message: Status message
    ### When action = 'read_cluster'
        cluster_id: ID of the cluster
        cluster_name: Name of the cluster
        creator_user_name: Username of the cluster creator
        node_type_id: Node type of the cluster
        num_workers: Number of workers in the cluster
        raw_data: Complete cluster details in JSON format
        spark_version: Spark version of the cluster
        start_time: Start time of the cluster
        state: Current state of the cluster
        terminated_time: Termination time of the cluster
    ### When action = 'execute_query'
        column_names: Names of the columns in the result set
        column_types: Data types of the columns in the result set
        data: Query results as array of rows
        manifest: Query manifest information in JSON format
        raw_response: Complete API response in JSON format
        result: Complete result data in JSON format
        row_count: Number of rows returned by the query
        statement_id: ID of the executed statement
        status: Status of the query execution
    ### When action = 'create_job'
        created_time: Creation time of the job
        creator_user_name: Username of the job creator
        job_id: ID of the created job
        job_name: Name of the created job
        raw_data: Complete job details in JSON format
    ### When action = 'get_directory_contents'
        file_details: Complete file details in JSON format
        file_names: List of file names
        file_paths: List of file paths
        file_sizes: List of file sizes
        file_types: List of file types (file/directory)
        modification_times: List of modification times
        raw_data: Raw response data in JSON format
    ### When action = 'upload_file'
        file_size: Size of the uploaded file
        message: Status message
        path: Path of the uploaded file
    ### When action = 'get_groups'
        group_details: Complete group details in JSON format
        group_ids: List of group IDs
        group_names: List of group names
        member_counts: List of member counts for each group
        raw_data: Raw response data in JSON format
    ### When action = 'create_directory'
        message: Status message
        path: Path of the created directory
    ### When action = 'delete_file'
        message: Status message
        path: Path of the deleted file
    ### When action = 'delete_directory'
        message: Status message
        path: Path of the deleted directory
    ### When action = 'insert_row'
        operation_status: Status of the insert operation
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Databricks>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "insert_row**(*)": {
            "inputs": [
                {
                    "field": "warehouse_id",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Warehouse",
                    "helper_text": "Select the ID of the Warehouse to perform the action",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=warehouse_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "catalog_name",
                    "type": "string",
                    "value": "",
                    "label": "Catalog",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Catalog",
                    "helper_text": "Select the name of the Catalog",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=catalog_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema_name",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Schema",
                    "helper_text": "Select the name of the Schema",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema_name&catalog_name={inputs.catalog_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Table",
                    "helper_text": "Select the name of Table to insert the row",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&catalog_name={inputs.catalog_name}&schema_name={inputs.schema_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "operation_status",
                    "type": "string",
                    "helper_text": "Status of the insert operation",
                }
            ],
            "name": "insert_row",
            "task_name": "tasks.databricks.insert_row",
            "description": "Insert a new row into a Databricks Table",
            "label": "Insert A Row",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "warehouse_id",
                "catalog_name",
                "schema_name",
                "table_name",
            ],
            "required": ["warehouse_id", "catalog_name", "schema_name", "table_name"],
        },
        "insert_row**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "execute_query**(*)": {
            "inputs": [
                {
                    "field": "warehouse_id",
                    "type": "string",
                    "value": "",
                    "label": "Warehouse",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Warehouse",
                    "helper_text": "Select the ID of the Warehouse to execute the query",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=warehouse_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "catalog_name",
                    "type": "string",
                    "value": "",
                    "label": "Catalog",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Catalog",
                    "helper_text": "Optional: Select the catalog name",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=catalog_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "schema_name",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "agent_field_type": "dynamic",
                    "placeholder": "Select Schema",
                    "helper_text": "Optional: Select the schema name",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema_name&catalog_name={inputs.catalog_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "SELECT * FROM my_table LIMIT 10",
                    "helper_text": "SQL query to execute against the Databricks SQL Warehouse",
                },
                {
                    "field": "wait_timeout",
                    "type": "string",
                    "value": "50s",
                    "label": "Wait Timeout",
                    "placeholder": "50s",
                    "helper_text": "Timeout for waiting for query completion (e.g., 30s, 1m, 5m)",
                },
                {
                    "field": "on_wait_timeout",
                    "type": "string",
                    "value": "CONTINUE",
                    "label": "On Wait Timeout",
                    "helper_text": "Action to take when timeout is reached",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Continue", "value": "CONTINUE"},
                            {"label": "Cancel", "value": "CANCEL"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "statement_id",
                    "type": "string",
                    "helper_text": "ID of the executed statement",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the query execution",
                },
                {
                    "field": "column_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the columns in the result set",
                },
                {
                    "field": "column_types",
                    "type": "vec<string>",
                    "helper_text": "Data types of the columns in the result set",
                },
                {
                    "field": "data",
                    "type": "vec<vec<any>>",
                    "helper_text": "Query results as array of rows",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned by the query",
                },
                {
                    "field": "result",
                    "type": "string",
                    "helper_text": "Complete result data in JSON format",
                },
                {
                    "field": "manifest",
                    "type": "string",
                    "helper_text": "Query manifest information in JSON format",
                },
                {
                    "field": "raw_response",
                    "type": "string",
                    "helper_text": "Complete API response in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "execute_query",
            "task_name": "tasks.databricks.execute_query",
            "description": "Execute SQL queries against Databricks SQL Warehouses",
            "label": "Execute SQL Query",
            "ui_sort_order": [
                "integration",
                "action",
                "warehouse_id",
                "query",
                "catalog_name_optional",
                "schema_name_optional",
                "wait_timeout",
                "on_wait_timeout",
            ],
        },
        "create_cluster**(*)": {
            "inputs": [
                {
                    "field": "cluster_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the cluster",
                    "label": "Cluster Name",
                    "placeholder": "my-cluster",
                },
                {
                    "field": "spark_version",
                    "type": "string",
                    "value": "",
                    "helper_text": "Spark version for the cluster",
                    "label": "Spark Version",
                    "placeholder": "13.3.x-scala2.12",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=spark_version&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "node_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Node type for cluster instances",
                    "label": "Node Type",
                    "placeholder": "i3.xlarge",
                },
                {
                    "field": "num_workers",
                    "type": "int32",
                    "value": 2,
                    "helper_text": "Number of worker nodes",
                    "label": "Number of Workers",
                    "placeholder": "2",
                },
                {
                    "field": "autotermination_minutes",
                    "type": "int32",
                    "value": 120,
                    "helper_text": "Auto-termination time in minutes ( Set to 0 to disable auto-termination )",
                    "label": "Auto-termination (minutes)",
                    "placeholder": "120",
                },
                {
                    "field": "enable_elastic_disk",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Enable elastic disk for the cluster",
                    "label": "Enable Elastic Disk",
                },
            ],
            "outputs": [
                {
                    "field": "cluster_id",
                    "type": "string",
                    "helper_text": "ID of the created cluster",
                },
                {
                    "field": "cluster_name",
                    "type": "string",
                    "helper_text": "Name of the created cluster",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the cluster",
                },
                {
                    "field": "spark_version",
                    "type": "string",
                    "helper_text": "Spark version of the cluster",
                },
                {
                    "field": "creator_user_name",
                    "type": "string",
                    "helper_text": "Username of the cluster creator",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete cluster details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_cluster",
            "task_name": "tasks.databricks.create_cluster",
            "description": "Create a new Databricks cluster",
            "label": "Create Cluster",
            "ui_sort_order": [
                "integration",
                "action",
                "cluster_name",
                "spark_version",
                "node_type_id",
                "num_workers",
                "autotermination_minutes",
                "enable_elastic_disk",
            ],
        },
        "delete_cluster**(*)": {
            "inputs": [
                {
                    "field": "cluster_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the cluster to delete",
                    "label": "Cluster ID",
                    "placeholder": "cluster-123",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=cluster_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "cluster_id",
                    "type": "string",
                    "helper_text": "ID of the deleted cluster",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_cluster",
            "task_name": "tasks.databricks.delete_cluster",
            "description": "Delete a Databricks cluster",
            "label": "Delete Cluster",
            "ui_sort_order": ["integration", "action", "cluster_id"],
        },
        "get_clusters**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of clusters to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [
                {
                    "field": "cluster_ids",
                    "type": "vec<string>",
                    "helper_text": "List of cluster IDs",
                },
                {
                    "field": "cluster_names",
                    "type": "vec<string>",
                    "helper_text": "List of cluster names",
                },
                {
                    "field": "cluster_states",
                    "type": "vec<string>",
                    "helper_text": "List of cluster states",
                },
                {
                    "field": "spark_versions",
                    "type": "vec<string>",
                    "helper_text": "List of spark versions",
                },
                {
                    "field": "creator_user_names",
                    "type": "vec<string>",
                    "helper_text": "List of cluster creator usernames",
                },
                {
                    "field": "cluster_details",
                    "type": "string",
                    "helper_text": "Complete cluster details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data in JSON format",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_clusters",
            "task_name": "tasks.databricks.get_clusters",
            "description": "Get multiple clusters",
            "label": "List Clusters",
            "inputs_sort_order": ["integration", "action", "num_messages"],
        },
        "read_cluster**(*)": {
            "inputs": [
                {
                    "field": "cluster_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the cluster to read",
                    "label": "Cluster ID",
                    "placeholder": "cluster-123",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=cluster_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "cluster_id",
                    "type": "string",
                    "helper_text": "ID of the cluster",
                },
                {
                    "field": "cluster_name",
                    "type": "string",
                    "helper_text": "Name of the cluster",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the cluster",
                },
                {
                    "field": "spark_version",
                    "type": "string",
                    "helper_text": "Spark version of the cluster",
                },
                {
                    "field": "node_type_id",
                    "type": "string",
                    "helper_text": "Node type of the cluster",
                },
                {
                    "field": "num_workers",
                    "type": "int32",
                    "helper_text": "Number of workers in the cluster",
                },
                {
                    "field": "creator_user_name",
                    "type": "string",
                    "helper_text": "Username of the cluster creator",
                },
                {
                    "field": "start_time",
                    "type": "string",
                    "helper_text": "Start time of the cluster",
                },
                {
                    "field": "terminated_time",
                    "type": "string",
                    "helper_text": "Termination time of the cluster",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete cluster details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_cluster",
            "task_name": "tasks.databricks.read_cluster",
            "description": "Read details of a specific cluster",
            "label": "Get Cluster",
            "inputs_sort_order": ["integration", "action", "cluster_id"],
        },
        "create_job**(*)": {
            "inputs": [
                {
                    "field": "job_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the job",
                    "label": "Job Name",
                    "placeholder": "my-job",
                },
                {
                    "field": "notebook_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path to the notebook",
                    "label": "Notebook Path",
                    "placeholder": "/Users/user@company.com/my-notebook",
                },
                {
                    "field": "cluster_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the cluster to run the job on",
                    "label": "Cluster ID",
                    "placeholder": "cluster-123",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=cluster_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "max_concurrent_runs",
                    "type": "int32",
                    "value": 1,
                    "helper_text": "Maximum number of concurrent runs",
                    "label": "Max Concurrent Runs",
                    "placeholder": "1",
                },
                {
                    "field": "timeout_seconds",
                    "type": "int32",
                    "value": 3600,
                    "helper_text": "Timeout in seconds",
                    "label": "Timeout (seconds)",
                    "placeholder": "3600",
                },
            ],
            "outputs": [
                {
                    "field": "job_id",
                    "type": "string",
                    "helper_text": "ID of the created job",
                },
                {
                    "field": "job_name",
                    "type": "string",
                    "helper_text": "Name of the created job",
                },
                {
                    "field": "creator_user_name",
                    "type": "string",
                    "helper_text": "Username of the job creator",
                },
                {
                    "field": "created_time",
                    "type": "string",
                    "helper_text": "Creation time of the job",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete job details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_job",
            "task_name": "tasks.databricks.create_job",
            "description": "Create a new Databricks job",
            "label": "Create Job",
            "ui_sort_order": [
                "integration",
                "action",
                "job_name",
                "notebook_path",
                "cluster_id",
                "max_concurrent_runs",
                "timeout_seconds",
            ],
        },
        "create_directory**(*)": {
            "inputs": [
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the directory to create",
                    "label": "Directory Path",
                    "placeholder": "/my-directory",
                }
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "Path of the created directory",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "variant": "default_integration_nodes",
            "name": "create_directory",
            "task_name": "tasks.databricks.create_directory",
            "description": "Create a new directory in Databricks",
            "label": "Create Directory",
            "ui_sort_order": ["integration", "action", "path"],
        },
        "upload_file**(*)": {
            "inputs": [
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path where the file should be uploaded",
                    "label": "File Path",
                    "placeholder": "/my-file.txt",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "File to upload",
                    "label": "File",
                },
                {
                    "field": "overwrite",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Overwrite existing file",
                    "label": "Overwrite",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "Path of the uploaded file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the uploaded file",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "variant": "common_integration_nodes",
            "name": "upload_file",
            "task_name": "tasks.databricks.upload_file",
            "description": "Upload a file to Databricks",
            "label": "Upload File",
            "ui_sort_order": ["integration", "action", "path", "file", "overwrite"],
        },
        "get_directory_contents**(*)": {
            "inputs": [
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the directory to list",
                    "label": "Directory Path",
                    "placeholder": "/my-directory",
                }
            ],
            "outputs": [
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "List of file names",
                },
                {
                    "field": "file_paths",
                    "type": "vec<string>",
                    "helper_text": "List of file paths",
                },
                {
                    "field": "file_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of file sizes",
                },
                {
                    "field": "file_types",
                    "type": "vec<string>",
                    "helper_text": "List of file types (file/directory)",
                },
                {
                    "field": "modification_times",
                    "type": "vec<string>",
                    "helper_text": "List of modification times",
                },
                {
                    "field": "file_details",
                    "type": "string",
                    "helper_text": "Complete file details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data in JSON format",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_directory_contents",
            "task_name": "tasks.databricks.get_directory_contents",
            "description": "Get contents of a directory in Databricks",
            "label": "Get Directory Contents",
            "ui_sort_order": ["integration", "action", "path"],
        },
        "delete_file**(*)": {
            "inputs": [
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the file to delete",
                    "label": "File Path",
                    "placeholder": "/my-file.txt",
                }
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "Path of the deleted file",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "variant": "default_integration_nodes",
            "name": "delete_file",
            "task_name": "tasks.databricks.delete_file",
            "description": "Delete a file from Databricks",
            "label": "Delete File",
            "ui_sort_order": ["integration", "action", "path"],
        },
        "delete_directory**(*)": {
            "inputs": [
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the directory to delete",
                    "label": "Directory Path",
                    "placeholder": "/my-directory",
                },
                {
                    "field": "recursive",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Delete directory recursively",
                    "label": "Recursive",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "Path of the deleted directory",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "variant": "default_integration_nodes",
            "name": "delete_directory",
            "task_name": "tasks.databricks.delete_directory",
            "description": "Delete a directory from Databricks",
            "label": "Delete Directory",
            "ui_sort_order": ["integration", "action", "path", "recursive"],
        },
        "get_groups**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of groups to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of group IDs",
                },
                {
                    "field": "group_names",
                    "type": "vec<string>",
                    "helper_text": "List of group names",
                },
                {
                    "field": "member_counts",
                    "type": "vec<string>",
                    "helper_text": "List of member counts for each group",
                },
                {
                    "field": "group_details",
                    "type": "string",
                    "helper_text": "Complete group details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data in JSON format",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_groups",
            "task_name": "tasks.databricks.get_groups",
            "description": "Get multiple groups",
            "label": "List Groups",
            "inputs_sort_order": ["integration", "action", "num_messages"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "cluster_name",
        "spark_version",
        "node_type_id",
        "num_workers",
        "cluster_id",
        "path",
        "file",
        "job_name",
        "notebook_path",
        "num_messages",
    ]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        autotermination_minutes: int = 120,
        catalog_name: str = "",
        cluster_id: str = "",
        cluster_name: str = "",
        enable_elastic_disk: bool = True,
        file: str = "",
        job_name: str = "",
        max_concurrent_runs: int = 1,
        node_type_id: str = "",
        notebook_path: str = "",
        num_messages: int = 10,
        num_workers: int = 2,
        on_wait_timeout: str = "CONTINUE",
        overwrite: bool = False,
        path: str = "",
        recursive: bool = False,
        schema_name: str = "",
        spark_version: str = "",
        table_name: str = "",
        timeout_seconds: int = 3600,
        wait_timeout: str = "50s",
        warehouse_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_databricks",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if warehouse_id is not None:
            self.inputs["warehouse_id"] = warehouse_id
        if catalog_name is not None:
            self.inputs["catalog_name"] = catalog_name
        if schema_name is not None:
            self.inputs["schema_name"] = schema_name
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if query is not None:
            self.inputs["query"] = query
        if wait_timeout is not None:
            self.inputs["wait_timeout"] = wait_timeout
        if on_wait_timeout is not None:
            self.inputs["on_wait_timeout"] = on_wait_timeout
        if cluster_name is not None:
            self.inputs["cluster_name"] = cluster_name
        if spark_version is not None:
            self.inputs["spark_version"] = spark_version
        if node_type_id is not None:
            self.inputs["node_type_id"] = node_type_id
        if num_workers is not None:
            self.inputs["num_workers"] = num_workers
        if autotermination_minutes is not None:
            self.inputs["autotermination_minutes"] = autotermination_minutes
        if enable_elastic_disk is not None:
            self.inputs["enable_elastic_disk"] = enable_elastic_disk
        if cluster_id is not None:
            self.inputs["cluster_id"] = cluster_id
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if job_name is not None:
            self.inputs["job_name"] = job_name
        if notebook_path is not None:
            self.inputs["notebook_path"] = notebook_path
        if max_concurrent_runs is not None:
            self.inputs["max_concurrent_runs"] = max_concurrent_runs
        if timeout_seconds is not None:
            self.inputs["timeout_seconds"] = timeout_seconds
        if path is not None:
            self.inputs["path"] = path
        if file is not None:
            self.inputs["file"] = file
        if overwrite is not None:
            self.inputs["overwrite"] = overwrite
        if recursive is not None:
            self.inputs["recursive"] = recursive
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationDatabricksNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
