"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_reddit")
class IntegrationRedditNode(Node):
    """
    Reddit

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Reddit account
    ### search_posts
        query: Search terms to look for
        limit: Maximum number of posts to retrieve (1-100)
        sort_type: How to sort the posts
        subreddit: Name of the subreddit to post to
        time_filter: Time filter for top posts
    ### list_subreddits
        category: Category of subreddits to retrieve
        limit: Maximum number of posts to retrieve (1-100)
    ### delete_comment
        comment_id: ID of the comment to delete
    ### reply_comment
        comment_id: ID of the comment to delete
        reply_text: Text content of the reply
    ### create_comment
        comment_text: Text content of the comment
        post_id: ID of the post to delete
    ### list_posts
        limit: Maximum number of posts to retrieve (1-100)
        sort_type: How to sort the posts
        subreddit: Name of the subreddit to post to
        time_filter: Time filter for top posts
    ### list_comments
        limit: Maximum number of posts to retrieve (1-100)
        post_id: ID of the post to delete
        sort_type: How to sort the posts
        subreddit: Name of the subreddit to post to
    ### create_post
        nsfw: Mark post as NSFW
        post_type: Type of post to create
        spoiler: Mark post as spoiler
        subreddit: Name of the subreddit to post to
        text_content: Text content for text posts
        title: Title of the post
        url: URL for link posts
    ### delete_post
        post_id: ID of the post to delete
    ### get_post
        post_id: ID of the post to delete
        subreddit: Name of the subreddit to post to
    ### get_subreddit
        subreddit_name: Name of the subreddit to get information about
    ### get_user
        username: Username of the Reddit user

    ## Outputs
    ### get_subreddit
        active_users: Number of active users
        created_utc: Creation timestamp
        description: Description of the subreddit
        display_name: Display name of the subreddit
        is_nsfw: Whether subreddit is NSFW
        is_quarantined: Whether subreddit is quarantined
        name: Name of the subreddit
        raw_data: Complete API response
        subreddit_id: ID of the subreddit
        subreddit_type: Type of subreddit (public, private, etc.)
        subscribers: Number of subscribers
        title: Title of the subreddit
        url: URL to the subreddit
    ### get_post
        author: Author of the post
        content: Content of the post
        created_utc: Creation timestamp
        is_nsfw: Whether post is NSFW
        is_spoiler: Whether post is marked as spoiler
        num_comments: Number of comments
        post_id: ID of the post
        raw_data: Complete API response
        score: Score (upvotes - downvotes)
        subreddit: Subreddit where post is located
        title: Title of the post
        url: URL of the post
    ### create_comment
        author: Author of the comment
        comment_id: ID of the created comment
        comment_text: Text of the created comment
        created_utc: Creation timestamp
        permalink: Permalink to the comment
        post_id: ID of the post commented on
        raw_data: Complete API response
    ### reply_comment
        author: Author of the reply
        created_utc: Creation timestamp
        parent_comment_id: ID of the parent comment
        permalink: Permalink to the reply
        raw_data: Complete API response
        reply_id: ID of the created reply
        reply_text: Text of the created reply
    ### list_subreddits
        category: Category searched
        raw_data: Complete API response
        subreddit_active_users: Array of active user counts
        subreddit_created_utc: Array of subreddit creation timestamps
        subreddit_descriptions: Array of subreddit descriptions
        subreddit_display_names: Array of subreddit display names
        subreddit_ids: Array of subreddit IDs
        subreddit_is_nsfw: Array of NSFW flags
        subreddit_is_quarantined: Array of quarantine flags
        subreddit_names: Array of subreddit names
        subreddit_subscribers: Array of subscriber counts
        subreddit_titles: Array of subreddit titles
        subreddit_types: Array of subreddit types
        subreddit_urls: Array of subreddit URLs
        subreddits: List of subreddits in JSON format
        total_count: Total number of subreddits retrieved
    ### list_comments
        comment_authors: Array of comment authors
        comment_bodies: Array of comment bodies
        comment_created_utc: Array of comment creation timestamps
        comment_depth: Array of comment depths in thread
        comment_ids: Array of comment IDs
        comment_is_submitter: Array of submitter flags
        comment_parent_ids: Array of parent comment IDs
        comment_permalinks: Array of comment permalinks
        comment_scores: Array of comment scores
        comments: List of comments in JSON format
        post_id: ID of the post
        raw_data: Complete API response
        subreddit: Subreddit name
        total_count: Total number of comments retrieved
    ### get_profile
        comment_karma: Comment karma score
        created_utc: Account creation timestamp
        has_verified_email: Whether email is verified
        id: User ID
        is_gold: Whether user has Reddit Gold
        is_mod: Whether user is a moderator
        link_karma: Link karma score
        raw_data: Complete API response
        total_karma: Total karma score
        username: Reddit username
    ### get_user
        comment_karma: Comment karma score
        created_utc: Account creation timestamp
        has_verified_email: Whether email is verified
        is_gold: Whether user has Reddit Gold
        is_mod: Whether user is a moderator
        link_karma: Link karma score
        profile_url: URL to user's profile
        raw_data: Complete API response
        total_karma: Total karma score
        user_id: ID of the user
        username: Username
    ### delete_post
        message: Status message
        raw_data: Complete API response
    ### delete_comment
        message: Status message
        raw_data: Complete API response
    ### list_posts
        post_authors: Array of post authors
        post_content: Array of post content (for text posts)
        post_created_utc: Array of post creation timestamps
        post_ids: Array of post IDs
        post_is_nsfw: Array of NSFW flags
        post_is_spoiler: Array of spoiler flags
        post_num_comments: Array of post comment counts
        post_scores: Array of post scores
        post_subreddits: Array of post subreddits
        post_titles: Array of post titles
        post_urls: Array of post URLs
        posts: List of posts in JSON format
        raw_data: Complete API response
        subreddit: Subreddit name
        total_count: Total number of posts retrieved
    ### search_posts
        post_authors: Array of post authors
        post_content: Array of post content (for text posts)
        post_created_utc: Array of post creation timestamps
        post_ids: Array of post IDs
        post_is_nsfw: Array of NSFW flags
        post_is_spoiler: Array of spoiler flags
        post_num_comments: Array of post comment counts
        post_scores: Array of post scores
        post_subreddits: Array of post subreddits
        post_titles: Array of post titles
        post_urls: Array of post URLs
        posts: List of matching posts in JSON format
        raw_data: Complete API response
        search_query: Search query used
        subreddit: Subreddit searched (if specified)
        total_count: Total number of posts found
    ### create_post
        post_id: ID of the created post
        post_title: Title of the created post
        post_url: URL to the created post
        raw_data: Complete API response
        subreddit: Subreddit where post was created
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Reddit account",
            "value": None,
            "type": "integration<Reddit>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_post": {
            "inputs": [
                {
                    "field": "subreddit",
                    "type": "string",
                    "value": "",
                    "label": "Subreddit",
                    "placeholder": "Enter subreddit name",
                    "helper_text": "Name of the subreddit to post to",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Enter post title",
                    "helper_text": "Title of the post",
                },
                {
                    "field": "post_type",
                    "type": "string",
                    "value": "text",
                    "label": "Post Type",
                    "helper_text": "Type of post to create",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text Post", "value": "text"},
                            {"label": "Link Post", "value": "link"},
                        ],
                    },
                },
                {
                    "field": "text_content",
                    "type": "string",
                    "value": "",
                    "label": "Text Content",
                    "placeholder": "Enter post content",
                    "helper_text": "Text content for text posts",
                },
                {
                    "field": "url",
                    "type": "string",
                    "value": "",
                    "label": "URL",
                    "placeholder": "Enter URL",
                    "helper_text": "URL for link posts",
                },
                {
                    "field": "nsfw",
                    "type": "bool",
                    "value": False,
                    "label": "NSFW",
                    "helper_text": "Mark post as NSFW",
                },
                {
                    "field": "spoiler",
                    "type": "bool",
                    "value": False,
                    "label": "Spoiler",
                    "helper_text": "Mark post as spoiler",
                },
            ],
            "outputs": [
                {
                    "field": "post_id",
                    "type": "string",
                    "helper_text": "ID of the created post",
                },
                {
                    "field": "post_title",
                    "type": "string",
                    "helper_text": "Title of the created post",
                },
                {
                    "field": "post_url",
                    "type": "string",
                    "helper_text": "URL to the created post",
                },
                {
                    "field": "subreddit",
                    "type": "string",
                    "helper_text": "Subreddit where post was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_post",
            "task_name": "tasks.reddit.create_post",
            "description": "Submit a post to a subreddit",
            "label": "Create Post",
            "required": ["subreddit", "title", "post_type"],
            "ui_sort_order": [
                "integration",
                "action",
                "subreddit",
                "title",
                "post_type",
                "text_content",
                "url",
                "nsfw",
                "spoiler",
            ],
        },
        "delete_post": {
            "inputs": [
                {
                    "field": "post_id",
                    "type": "string",
                    "value": "",
                    "label": "Post ID",
                    "placeholder": "Enter post ID",
                    "helper_text": "ID of the post to delete",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_post",
            "task_name": "tasks.reddit.delete_post",
            "description": "Delete a post from a subreddit",
            "label": "Delete Post",
            "required": ["post_id"],
            "ui_sort_order": ["integration", "action", "post_id"],
        },
        "get_post": {
            "inputs": [
                {
                    "field": "subreddit",
                    "type": "string",
                    "value": "",
                    "label": "Subreddit",
                    "placeholder": "Enter subreddit name",
                    "helper_text": "Name of the subreddit containing the post",
                },
                {
                    "field": "post_id",
                    "type": "string",
                    "value": "",
                    "label": "Post ID",
                    "placeholder": "Enter post ID",
                    "helper_text": "ID of the post to retrieve",
                },
            ],
            "outputs": [
                {"field": "post_id", "type": "string", "helper_text": "ID of the post"},
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the post",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author of the post",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "Content of the post",
                },
                {"field": "url", "type": "string", "helper_text": "URL of the post"},
                {
                    "field": "subreddit",
                    "type": "string",
                    "helper_text": "Subreddit where post is located",
                },
                {
                    "field": "score",
                    "type": "int32",
                    "helper_text": "Score (upvotes - downvotes)",
                },
                {
                    "field": "num_comments",
                    "type": "int32",
                    "helper_text": "Number of comments",
                },
                {
                    "field": "created_utc",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "is_nsfw",
                    "type": "bool",
                    "helper_text": "Whether post is NSFW",
                },
                {
                    "field": "is_spoiler",
                    "type": "bool",
                    "helper_text": "Whether post is marked as spoiler",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_post",
            "task_name": "tasks.reddit.get_post",
            "description": "Get a post from a subreddit",
            "label": "Get Post",
            "required": ["subreddit", "post_id"],
            "ui_sort_order": ["integration", "action", "subreddit", "post_id"],
        },
        "list_posts": {
            "inputs": [
                {
                    "field": "subreddit",
                    "type": "string",
                    "value": "",
                    "label": "Subreddit",
                    "placeholder": "Enter subreddit name",
                    "helper_text": "Name of the subreddit to get posts from",
                },
                {
                    "field": "sort_type",
                    "type": "string",
                    "value": "hot",
                    "label": "Sort Type",
                    "helper_text": "How to sort the posts",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Hot", "value": "hot"},
                            {"label": "New", "value": "new"},
                            {"label": "Rising", "value": "rising"},
                            {"label": "Top", "value": "top"},
                        ],
                    },
                },
                {
                    "field": "time_filter",
                    "type": "string",
                    "value": "all",
                    "label": "Time Filter",
                    "helper_text": "Time filter for top posts",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All Time", "value": "all"},
                            {"label": "Past Day", "value": "day"},
                            {"label": "Past Week", "value": "week"},
                            {"label": "Past Month", "value": "month"},
                            {"label": "Past Year", "value": "year"},
                        ],
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of posts to retrieve (1-100)",
                },
            ],
            "outputs": [
                {
                    "field": "posts",
                    "type": "vec<string>",
                    "helper_text": "List of posts in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of posts retrieved",
                },
                {
                    "field": "subreddit",
                    "type": "string",
                    "helper_text": "Subreddit name",
                },
                {
                    "field": "post_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of post IDs",
                },
                {
                    "field": "post_titles",
                    "type": "vec<string>",
                    "helper_text": "Array of post titles",
                },
                {
                    "field": "post_authors",
                    "type": "vec<string>",
                    "helper_text": "Array of post authors",
                },
                {
                    "field": "post_scores",
                    "type": "vec<int32>",
                    "helper_text": "Array of post scores",
                },
                {
                    "field": "post_urls",
                    "type": "vec<string>",
                    "helper_text": "Array of post URLs",
                },
                {
                    "field": "post_subreddits",
                    "type": "vec<string>",
                    "helper_text": "Array of post subreddits",
                },
                {
                    "field": "post_created_utc",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of post creation timestamps",
                },
                {
                    "field": "post_num_comments",
                    "type": "vec<int32>",
                    "helper_text": "Array of post comment counts",
                },
                {
                    "field": "post_content",
                    "type": "vec<string>",
                    "helper_text": "Array of post content (for text posts)",
                },
                {
                    "field": "post_is_nsfw",
                    "type": "vec<bool>",
                    "helper_text": "Array of NSFW flags",
                },
                {
                    "field": "post_is_spoiler",
                    "type": "vec<bool>",
                    "helper_text": "Array of spoiler flags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_posts",
            "task_name": "tasks.reddit.list_posts",
            "description": "Get multiple posts from a subreddit",
            "label": "List Posts",
            "required": ["subreddit", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "subreddit",
                "sort_type",
                "time_filter",
                "limit",
            ],
        },
        "search_posts": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "Enter search terms",
                    "helper_text": "Search terms to look for",
                },
                {
                    "field": "subreddit",
                    "type": "string",
                    "value": "",
                    "label": "Subreddit",
                    "placeholder": "Enter subreddit name (optional)",
                    "helper_text": "Limit search to specific subreddit (leave empty to search all of Reddit)",
                },
                {
                    "field": "sort_type",
                    "type": "string",
                    "value": "relevance",
                    "label": "Sort Type",
                    "helper_text": "How to sort search results",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Relevance", "value": "relevance"},
                            {"label": "Hot", "value": "hot"},
                            {"label": "Top", "value": "top"},
                            {"label": "New", "value": "new"},
                            {"label": "Comments", "value": "comments"},
                        ],
                    },
                },
                {
                    "field": "time_filter",
                    "type": "string",
                    "value": "all",
                    "label": "Time Filter",
                    "helper_text": "Time filter for search results",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All Time", "value": "all"},
                            {"label": "Past Day", "value": "day"},
                            {"label": "Past Week", "value": "week"},
                            {"label": "Past Month", "value": "month"},
                            {"label": "Past Year", "value": "year"},
                        ],
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of posts to retrieve (1-100)",
                },
            ],
            "outputs": [
                {
                    "field": "posts",
                    "type": "vec<string>",
                    "helper_text": "List of matching posts in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of posts found",
                },
                {
                    "field": "search_query",
                    "type": "string",
                    "helper_text": "Search query used",
                },
                {
                    "field": "subreddit",
                    "type": "string",
                    "helper_text": "Subreddit searched (if specified)",
                },
                {
                    "field": "post_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of post IDs",
                },
                {
                    "field": "post_titles",
                    "type": "vec<string>",
                    "helper_text": "Array of post titles",
                },
                {
                    "field": "post_authors",
                    "type": "vec<string>",
                    "helper_text": "Array of post authors",
                },
                {
                    "field": "post_scores",
                    "type": "vec<int32>",
                    "helper_text": "Array of post scores",
                },
                {
                    "field": "post_urls",
                    "type": "vec<string>",
                    "helper_text": "Array of post URLs",
                },
                {
                    "field": "post_subreddits",
                    "type": "vec<string>",
                    "helper_text": "Array of post subreddits",
                },
                {
                    "field": "post_created_utc",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of post creation timestamps",
                },
                {
                    "field": "post_num_comments",
                    "type": "vec<int32>",
                    "helper_text": "Array of post comment counts",
                },
                {
                    "field": "post_content",
                    "type": "vec<string>",
                    "helper_text": "Array of post content (for text posts)",
                },
                {
                    "field": "post_is_nsfw",
                    "type": "vec<bool>",
                    "helper_text": "Array of NSFW flags",
                },
                {
                    "field": "post_is_spoiler",
                    "type": "vec<bool>",
                    "helper_text": "Array of spoiler flags",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "search_posts",
            "task_name": "tasks.reddit.search_posts",
            "description": "Search posts in a subreddit or across Reddit",
            "label": "Search Posts",
            "required": ["query", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "query",
                "subreddit",
                "sort_type",
                "time_filter",
                "limit",
            ],
        },
        "create_comment": {
            "inputs": [
                {
                    "field": "post_id",
                    "type": "string",
                    "value": "",
                    "label": "Post ID",
                    "placeholder": "Enter post ID",
                    "helper_text": "ID of the post to comment on",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "value": "",
                    "label": "Comment Text",
                    "placeholder": "Enter comment text",
                    "helper_text": "Text content of the comment",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the created comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "Text of the created comment",
                },
                {
                    "field": "post_id",
                    "type": "string",
                    "helper_text": "ID of the post commented on",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author of the comment",
                },
                {
                    "field": "created_utc",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "Permalink to the comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_comment",
            "task_name": "tasks.reddit.create_comment",
            "description": "Create a top-level comment in a post",
            "label": "Create Comment",
            "required": ["post_id", "comment_text"],
            "ui_sort_order": ["integration", "action", "post_id", "comment_text"],
        },
        "list_comments": {
            "inputs": [
                {
                    "field": "subreddit",
                    "type": "string",
                    "value": "",
                    "label": "Subreddit",
                    "placeholder": "Enter subreddit name",
                    "helper_text": "Name of the subreddit containing the post",
                },
                {
                    "field": "post_id",
                    "type": "string",
                    "value": "",
                    "label": "Post ID",
                    "placeholder": "Enter post ID",
                    "helper_text": "ID of the post to get comments from",
                },
                {
                    "field": "sort_type",
                    "type": "string",
                    "value": "best",
                    "label": "Sort Type",
                    "helper_text": "How to sort the comments",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Best", "value": "best"},
                            {"label": "Top", "value": "top"},
                            {"label": "New", "value": "new"},
                            {"label": "Controversial", "value": "controversial"},
                            {"label": "Old", "value": "old"},
                            {"label": "Q&A", "value": "qa"},
                        ],
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of comments to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "comments",
                    "type": "vec<string>",
                    "helper_text": "List of comments in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of comments retrieved",
                },
                {"field": "post_id", "type": "string", "helper_text": "ID of the post"},
                {
                    "field": "subreddit",
                    "type": "string",
                    "helper_text": "Subreddit name",
                },
                {
                    "field": "comment_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of comment IDs",
                },
                {
                    "field": "comment_bodies",
                    "type": "vec<string>",
                    "helper_text": "Array of comment bodies",
                },
                {
                    "field": "comment_authors",
                    "type": "vec<string>",
                    "helper_text": "Array of comment authors",
                },
                {
                    "field": "comment_scores",
                    "type": "vec<int32>",
                    "helper_text": "Array of comment scores",
                },
                {
                    "field": "comment_created_utc",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of comment creation timestamps",
                },
                {
                    "field": "comment_permalinks",
                    "type": "vec<string>",
                    "helper_text": "Array of comment permalinks",
                },
                {
                    "field": "comment_parent_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of parent comment IDs",
                },
                {
                    "field": "comment_is_submitter",
                    "type": "vec<bool>",
                    "helper_text": "Array of submitter flags",
                },
                {
                    "field": "comment_depth",
                    "type": "vec<int32>",
                    "helper_text": "Array of comment depths in thread",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_comments",
            "task_name": "tasks.reddit.list_comments",
            "description": "Get multiple comments",
            "label": "List Comments",
            "required": ["subreddit", "post_id", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "subreddit",
                "post_id",
                "sort_type",
                "limit",
            ],
        },
        "delete_comment": {
            "inputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "Enter comment ID",
                    "helper_text": "ID of the comment to delete",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_comment",
            "task_name": "tasks.reddit.delete_comment",
            "description": "Remove a comment from a post",
            "label": "Delete Comment",
            "required": ["comment_id"],
            "ui_sort_order": ["integration", "action", "comment_id"],
        },
        "reply_comment": {
            "inputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "Enter comment ID",
                    "helper_text": "ID of the comment to reply to",
                },
                {
                    "field": "reply_text",
                    "type": "string",
                    "value": "",
                    "label": "Reply Text",
                    "placeholder": "Enter reply text",
                    "helper_text": "Text content of the reply",
                },
            ],
            "outputs": [
                {
                    "field": "reply_id",
                    "type": "string",
                    "helper_text": "ID of the created reply",
                },
                {
                    "field": "reply_text",
                    "type": "string",
                    "helper_text": "Text of the created reply",
                },
                {
                    "field": "parent_comment_id",
                    "type": "string",
                    "helper_text": "ID of the parent comment",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author of the reply",
                },
                {
                    "field": "created_utc",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "Permalink to the reply",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "reply_comment",
            "task_name": "tasks.reddit.reply_comment",
            "description": "Write a reply to a comment in a post",
            "label": "Reply to Comment",
            "required": ["comment_id", "reply_text"],
            "ui_sort_order": ["integration", "action", "comment_id", "reply_text"],
        },
        "get_profile": {
            "inputs": [],
            "outputs": [
                {
                    "field": "username",
                    "type": "string",
                    "helper_text": "Reddit username",
                },
                {"field": "id", "type": "string", "helper_text": "User ID"},
                {
                    "field": "created_utc",
                    "type": "timestamp",
                    "helper_text": "Account creation timestamp",
                },
                {
                    "field": "link_karma",
                    "type": "int32",
                    "helper_text": "Link karma score",
                },
                {
                    "field": "comment_karma",
                    "type": "int32",
                    "helper_text": "Comment karma score",
                },
                {
                    "field": "total_karma",
                    "type": "int32",
                    "helper_text": "Total karma score",
                },
                {
                    "field": "is_gold",
                    "type": "bool",
                    "helper_text": "Whether user has Reddit Gold",
                },
                {
                    "field": "is_mod",
                    "type": "bool",
                    "helper_text": "Whether user is a moderator",
                },
                {
                    "field": "has_verified_email",
                    "type": "bool",
                    "helper_text": "Whether email is verified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_profile",
            "task_name": "tasks.reddit.get_profile",
            "description": "Get authenticated user's profile information",
            "label": "Get Profile",
            "required": [],
            "ui_sort_order": ["integration", "action"],
        },
        "get_subreddit": {
            "inputs": [
                {
                    "field": "subreddit_name",
                    "type": "string",
                    "value": "",
                    "label": "Subreddit Name",
                    "placeholder": "Enter subreddit name",
                    "helper_text": "Name of the subreddit to get information about",
                }
            ],
            "outputs": [
                {
                    "field": "subreddit_id",
                    "type": "string",
                    "helper_text": "ID of the subreddit",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the subreddit",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Display name of the subreddit",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the subreddit",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the subreddit",
                },
                {
                    "field": "subscribers",
                    "type": "int32",
                    "helper_text": "Number of subscribers",
                },
                {
                    "field": "active_users",
                    "type": "int32",
                    "helper_text": "Number of active users",
                },
                {
                    "field": "created_utc",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "is_nsfw",
                    "type": "bool",
                    "helper_text": "Whether subreddit is NSFW",
                },
                {
                    "field": "is_quarantined",
                    "type": "bool",
                    "helper_text": "Whether subreddit is quarantined",
                },
                {
                    "field": "subreddit_type",
                    "type": "string",
                    "helper_text": "Type of subreddit (public, private, etc.)",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "URL to the subreddit",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_subreddit",
            "task_name": "tasks.reddit.get_subreddit",
            "description": "Read details of a specific subreddit",
            "label": "Get Subreddit",
            "required": ["subreddit_name"],
            "ui_sort_order": ["integration", "action", "subreddit_name"],
        },
        "list_subreddits": {
            "inputs": [
                {
                    "field": "category",
                    "type": "string",
                    "value": "popular",
                    "label": "Category",
                    "helper_text": "Category of subreddits to retrieve",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Popular", "value": "popular"},
                            {"label": "New", "value": "new"},
                            {"label": "Gold", "value": "gold"},
                            {"label": "Default", "value": "default"},
                        ],
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of subreddits to retrieve (1-100)",
                },
            ],
            "outputs": [
                {
                    "field": "subreddits",
                    "type": "vec<string>",
                    "helper_text": "List of subreddits in JSON format",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of subreddits retrieved",
                },
                {
                    "field": "category",
                    "type": "string",
                    "helper_text": "Category searched",
                },
                {
                    "field": "subreddit_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit IDs",
                },
                {
                    "field": "subreddit_names",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit names",
                },
                {
                    "field": "subreddit_display_names",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit display names",
                },
                {
                    "field": "subreddit_titles",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit titles",
                },
                {
                    "field": "subreddit_descriptions",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit descriptions",
                },
                {
                    "field": "subreddit_subscribers",
                    "type": "vec<int32>",
                    "helper_text": "Array of subscriber counts",
                },
                {
                    "field": "subreddit_active_users",
                    "type": "vec<int32>",
                    "helper_text": "Array of active user counts",
                },
                {
                    "field": "subreddit_created_utc",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of subreddit creation timestamps",
                },
                {
                    "field": "subreddit_is_nsfw",
                    "type": "vec<bool>",
                    "helper_text": "Array of NSFW flags",
                },
                {
                    "field": "subreddit_is_quarantined",
                    "type": "vec<bool>",
                    "helper_text": "Array of quarantine flags",
                },
                {
                    "field": "subreddit_types",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit types",
                },
                {
                    "field": "subreddit_urls",
                    "type": "vec<string>",
                    "helper_text": "Array of subreddit URLs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_subreddits",
            "task_name": "tasks.reddit.list_subreddits",
            "description": "Get multiple subreddits",
            "label": "List Subreddits",
            "required": ["limit"],
            "ui_sort_order": ["integration", "action", "category", "limit"],
        },
        "get_user": {
            "inputs": [
                {
                    "field": "username",
                    "type": "string",
                    "value": "",
                    "label": "Username",
                    "placeholder": "Enter username",
                    "helper_text": "Username of the Reddit user",
                }
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {"field": "username", "type": "string", "helper_text": "Username"},
                {
                    "field": "created_utc",
                    "type": "timestamp",
                    "helper_text": "Account creation timestamp",
                },
                {
                    "field": "link_karma",
                    "type": "int32",
                    "helper_text": "Link karma score",
                },
                {
                    "field": "comment_karma",
                    "type": "int32",
                    "helper_text": "Comment karma score",
                },
                {
                    "field": "total_karma",
                    "type": "int32",
                    "helper_text": "Total karma score",
                },
                {
                    "field": "is_gold",
                    "type": "bool",
                    "helper_text": "Whether user has Reddit Gold",
                },
                {
                    "field": "is_mod",
                    "type": "bool",
                    "helper_text": "Whether user is a moderator",
                },
                {
                    "field": "has_verified_email",
                    "type": "bool",
                    "helper_text": "Whether email is verified",
                },
                {
                    "field": "profile_url",
                    "type": "string",
                    "helper_text": "URL to user's profile",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_user",
            "task_name": "tasks.reddit.get_user",
            "description": "Get information about a specific user",
            "label": "Get User",
            "required": ["username"],
            "ui_sort_order": ["integration", "action", "username"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        category: str = "popular",
        comment_id: str = "",
        comment_text: str = "",
        limit: int = 10,
        nsfw: bool = False,
        post_id: str = "",
        post_type: str = "text",
        reply_text: str = "",
        sort_type: str = "hot",
        spoiler: bool = False,
        subreddit: str = "",
        subreddit_name: str = "",
        text_content: str = "",
        time_filter: str = "all",
        title: str = "",
        url: str = "",
        username: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_reddit",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if subreddit is not None:
            self.inputs["subreddit"] = subreddit
        if title is not None:
            self.inputs["title"] = title
        if post_type is not None:
            self.inputs["post_type"] = post_type
        if text_content is not None:
            self.inputs["text_content"] = text_content
        if url is not None:
            self.inputs["url"] = url
        if nsfw is not None:
            self.inputs["nsfw"] = nsfw
        if spoiler is not None:
            self.inputs["spoiler"] = spoiler
        if post_id is not None:
            self.inputs["post_id"] = post_id
        if sort_type is not None:
            self.inputs["sort_type"] = sort_type
        if time_filter is not None:
            self.inputs["time_filter"] = time_filter
        if limit is not None:
            self.inputs["limit"] = limit
        if query is not None:
            self.inputs["query"] = query
        if comment_text is not None:
            self.inputs["comment_text"] = comment_text
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if reply_text is not None:
            self.inputs["reply_text"] = reply_text
        if subreddit_name is not None:
            self.inputs["subreddit_name"] = subreddit_name
        if category is not None:
            self.inputs["category"] = category
        if username is not None:
            self.inputs["username"] = username
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationRedditNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
