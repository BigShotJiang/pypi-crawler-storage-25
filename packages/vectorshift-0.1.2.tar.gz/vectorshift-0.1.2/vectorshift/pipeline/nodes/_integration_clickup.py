"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_clickup")
class IntegrationClickupNode(Node):
    """
    ClickUp

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'get_tasks'
        archived: Show archived tasks
        assignees: Filter by assignee (requires Team, Space, Folder, and List to be selected first)
        custom_fields: Custom field filters in JSON format: {"field_id": "value"}
        date_updated_gt: Tasks updated after this date (YYYY-MM-DD)
        date_updated_lt: Tasks updated before this date (YYYY-MM-DD)
        due_date_gt: Tasks due after this date (YYYY-MM-DD)
        due_date_lt: Tasks due before this date (YYYY-MM-DD)
        folder_id: The ID of the folder
        include_closed: Include closed tasks
        include_markdown_description: Include markdown description
        list_id: The ID of the list where task will be created
        order_by: Sort tasks by field (created, updated, due_date, etc.)
        reverse: Reverse the sort order
        space_id: The ID of the space
        statuses: Filter by specific task statuses (requires Team, Space, Folder, and List to be selected first)
        subtasks: Include subtasks
        tags: Filter by tag names
        team_id: The ID of the team
        use_date: Filter tasks by created date range
    ### When action = 'get_lists'
        archived: Show archived tasks
        folder_id: The ID of the folder
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'get_folders'
        archived: Show archived tasks
        limit: Maximum number of folders to retrieve
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'create_comment'
        assign_user: User ID to assign to this comment
        comment_on: Select where to add the comment
        comment_text: Content of the comment
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        notify_all: Notify all members when task is created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
        view_id: The ID of the view to add comment to (required when Comment On is 'View')
    ### When action = 'get_time_entries'
        assignee: Filter by assignee user ID
        folder_id: The ID of the folder
        include_location_names: Include location names
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
        use_date: Filter tasks by created date range
    ### When action = 'add_time_entry_tag'
        background_color: Background color for the tag(s) in hex format (applies to all tags if multiple)
        foreground_color: Foreground (text) color for the tag(s) in hex format (applies to all tags if multiple)
        tag_name: Name of the tag
        team_id: The ID of the team
        time_entry_id: The ID of the time entry to delete
    ### When action = 'delete_checklist'
        checklist_id: The ID of the checklist to delete
    ### When action = 'update_checklist'
        checklist_id: The ID of the checklist to delete
        update_checklist_name: New name for the checklist
        update_checklist_position: New position for the checklist
    ### When action = 'create_checklist_item'
        checklist_id: The ID of the checklist to delete
        checklist_item_assignee: User ID to assign to this checklist item
        checklist_item_name: Name of the checklist item
    ### When action = 'delete_checklist_item'
        checklist_id: The ID of the checklist to delete
        checklist_item_id: The ID of the checklist item to delete
    ### When action = 'update_checklist_item'
        checklist_id: The ID of the checklist to delete
        checklist_item_id: The ID of the checklist item to delete
        update_checklist_item_assignee: New assignee for the checklist item
        update_checklist_item_name: New name for the checklist item
        update_checklist_item_parent: New parent for the checklist item
        update_checklist_item_resolved: Mark checklist item as resolved
    ### When action = 'create_checklist'
        checklist_name: Name of the checklist
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'update_comment'
        comment_id: The ID of the comment to update (comment under task or list)
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        team_id: The ID of the team
        update_comment_assignee: User ID to assign the comment to
        update_comment_resolved: Mark the comment as resolved
        update_comment_text: New content for the comment
    ### When action = 'delete_comment'
        comment_id: The ID of the comment to update (comment under task or list)
    ### When action = 'get_comments'
        comment_on: Select where to add the comment
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
        view_id: The ID of the view to add comment to (required when Comment On is 'View')
    ### When action = 'set_custom_field'
        custom_field_id: The ID of the custom field
        custom_field_value: The value to set for the custom field
        custom_task_ids: Use custom task IDs
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'get_task_members'
        custom_task_ids: Use custom task IDs
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'get_tasks' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_time_entries' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'create_task_dependency'
        depends_on_task_id: The ID of the task that this task depends on
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'delete_task_dependency'
        depends_on_task_id: The ID of the task that this task depends on
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'create_time_entry'
        duration_minutes: Duration in minutes
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        start_time: Start time for the time entry (ISO 8601 format)
        task_id: The ID of the task to read
        team_id: The ID of the team
        time_entry_assignee: Assignee user ID for the time entry
        time_entry_billable: Mark time entry as billable
        time_entry_description: Description of the time entry
        time_entry_tags: Comma-separated list of tags or JSON objects
    ### When action = 'create_space'
        enable_custom_fields: Allow custom fields
        enable_dependency_warnings: Allow dependency warnings
        enable_incomplete_warnings: Allow incomplete warnings
        enable_priority: Allow priority
        enable_tags: Allow tags
        enable_time_tracking: Allow time tracking
        space_multiple_assignees: Allow multiple assignees
        space_name: Name of the space
        team_id: The ID of the team
    ### When action = 'get_tasks' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_time_entries' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'create_task'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        markdown_content: Task content in markdown format
        notify_all: Notify all members when task is created
        parent_id: ID of the parent task (for subtasks)
        space_id: The ID of the space
        task_assignees: List of assignee IDs
        task_description: Description of the task
        task_due_date: Due date for the task (timestamp)
        task_name: Name of the task
        task_priority: Priority of the task
        task_start_date: Start date for the task (timestamp)
        task_status: Status of the task
        task_tags: List of tags for the task
        team_id: The ID of the team
        time_estimate: Time estimate for the task in hours
    ### When action = 'update_task'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        notify_all: Notify all members when task is created
        remove_all_assignees: If enabled, all assignees will be removed from the task
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
        update_markdown_content: Task content in markdown format
        update_parent_id: New parent task ID (for subtasks)
        update_task_assignees: New list of assignee IDs (will not work if remove_assignees is enabled)
        update_task_description: New description for the task
        update_task_due_date: New due date for the task (timestamp)
        update_task_name: New name for the task
        update_task_priority: New priority for the task
        update_task_start_date: New start date for the task (timestamp)
        update_task_status: New status for the task
        update_task_tags: New list of tags for the task
        update_time_estimate: New time estimate for the task in hours
    ### When action = 'read_task'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'delete_task'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'create_list'
        folder_id: The ID of the folder
        folderless: If enabled, create list at space root level without a folder
        list_content: Description of the list
        list_name: Name of the list
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'update_list'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        team_id: The ID of the team
        update_list_content: New description for the list
        update_list_name: New name for the list
    ### When action = 'read_list'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'delete_list'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'update_folder'
        folder_id: The ID of the folder
        space_id: The ID of the space
        team_id: The ID of the team
        update_folder_name: New name for the folder
    ### When action = 'read_folder'
        folder_id: The ID of the folder
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'delete_folder'
        folder_id: The ID of the folder
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'start_time_entry'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        task_id: The ID of the task to read
        team_id: The ID of the team
        time_entry_billable: Mark time entry as billable
        time_entry_description: Description of the time entry
    ### When action = 'add_task_tag'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        tag_name: Name of the tag
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'remove_task_tag'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        tag_name: Name of the tag
        task_id: The ID of the task to read
        team_id: The ID of the team
    ### When action = 'get_custom_fields'
        folder_id: The ID of the folder
        list_id: The ID of the list where task will be created
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'create_folder'
        folder_name: Name of the folder
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'read_time_entry'
        get_running: Get currently running time entry
        team_id: The ID of the team
        time_entry_id: The ID of the time entry to delete
    ### When action = 'create_goal'
        goal_color: Color for the goal
        goal_description: Description of the goal
        goal_due_date: Due date for the goal (YYYY-MM-DD or RFC3339)
        goal_multiple_owners: Allow multiple owners
        goal_name: Name of the goal
        goal_owners: Comma-separated list of owner user IDs
        team_id: The ID of the team
    ### When action = 'delete_goal'
        goal_id: The ID of the goal to delete
    ### When action = 'read_goal'
        goal_id: The ID of the goal to delete
    ### When action = 'update_goal'
        goal_id: The ID of the goal to delete
        update_goal_add_owners: Comma-separated list of owner user IDs to add
        update_goal_color: New color for the goal
        update_goal_description: New description for the goal
        update_goal_due_date: New due date for the goal (YYYY-MM-DD or RFC3339)
        update_goal_name: New name for the goal
        update_goal_remove_owners: Comma-separated list of owner user IDs to remove
    ### When action = 'create_goal_key_result'
        goal_id: The ID of the goal to delete
        key_result_list_ids: Comma-separated list of list IDs
        key_result_name: Name of the key result
        key_result_owners: Comma-separated list of owner user IDs
        key_result_steps_end: Target value for the key result
        key_result_steps_start: Starting value for the key result
        key_result_task_ids: Comma-separated list of task IDs
        key_result_type: Type of key result
        key_result_unit: Unit for the key result
    ### When action = 'get_goals'
        include_completed: Include completed goals
        team_id: The ID of the team
    ### When action = 'delete_goal_key_result'
        key_result_id: The ID of the key result to delete
    ### When action = 'update_goal_key_result'
        key_result_id: The ID of the key result to delete
        update_key_result_name: New name for the key result
        update_key_result_note: New note for the key result
        update_key_result_steps_current: Current progress value
        update_key_result_steps_end: New target value
        update_key_result_steps_start: New starting value
        update_key_result_unit: New unit for the key result
    ### When action = 'get_space_tags'
        limit: Maximum number of folders to retrieve
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'get_list_members'
        list_id: The ID of the list where task will be created
    ### When action = 'add_task_to_list'
        list_id: The ID of the list where task will be created
        task_id: The ID of the task to read
    ### When action = 'remove_task_from_list'
        list_id: The ID of the list where task will be created
        task_id: The ID of the task to read
    ### When action = 'update_space_tag'
        new_tag_name: New name for the tag
        space_id: The ID of the space
        tag_background_color: Background color for the tag
        tag_foreground_color: Foreground color for the tag
        tag_name: Name of the tag
        team_id: The ID of the team
    ### When action = 'get_tasks' and use_date = False
        num_messages: Specify the number of tasks to fetch
    ### When action = 'get_time_entries' and use_date = False
        num_messages: Specify the number of tasks to fetch
    ### When action = 'read_space'
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'delete_space'
        space_id: The ID of the space
        team_id: The ID of the team
    ### When action = 'create_space_tag'
        space_id: The ID of the space
        tag_background_color: Background color for the tag
        tag_foreground_color: Foreground color for the tag
        tag_name: Name of the tag
        team_id: The ID of the team
    ### When action = 'delete_space_tag'
        space_id: The ID of the space
        tag_name: Name of the tag
        team_id: The ID of the team
    ### When action = 'remove_time_entry_tag'
        tag_name: Name of the tag
        team_id: The ID of the team
        time_entry_id: The ID of the time entry to delete
    ### When action = 'delete_time_entry'
        team_id: The ID of the team
        time_entry_id: The ID of the time entry to delete
    ### When action = 'stop_time_entry'
        team_id: The ID of the team
    ### When action = 'update_time_entry'
        team_id: The ID of the team
        time_entry_id: The ID of the time entry to delete
        update_time_entry_billable: Mark time entry as billable
        update_time_entry_description: New description for the time entry
        update_time_entry_duration_minutes: New duration in minutes
        update_time_entry_start: New start time (RFC3339 format)
        update_time_entry_task_id: New task ID for the time entry
    ### When action = 'get_time_entry_tags'
        team_id: The ID of the team
    ### When action = 'get_tasks' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_time_entries' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_space'
        access: Whether the user has access to the space
        color: Color of the space
        features: Space features in JSON format
        raw_data: Raw API response data in JSON format
        space_details: Space details in JSON format
        space_id: ID of the space
        space_name: Name of the space
        statuses: Space statuses in JSON format
    ### When action = 'read_list'
        assignee: Assignee of the list
        due_date: Due date of the list
        folder: Folder information in JSON format
        list_details: List details in JSON format
        list_id: ID of the list
        list_name: Name of the list
        order_index: Order index of the list
        priority: Priority of the list
        raw_data: Raw API response data in JSON format
        space: Space information in JSON format
        start_date: Start date of the list
        status: Status of the list
        statuses: List of statuses in JSON format
        task_count: Number of tasks in the list
    ### When action = 'read_task'
        assignees: List of assignees for the task
        created_at: Creation timestamp of the task
        description: Description of the task
        due_date: Due date of the task
        priority: Priority of the task
        raw_data: Raw API response data in JSON format
        start_date: Start date of the task
        status: Status of the task
        tags: List of tags for the task
        task_details: Task details in JSON format
        task_id: ID of the task
        task_name: Name of the task
        task_url: URL of the task
        updated_at: Last update timestamp of the task
    ### When action = 'read_time_entry'
        billable: Whether the time entry is billable
        created_at: Creation timestamp of the time entry
        description: Description of the time entry
        duration: Duration of the time entry
        end: End time of the time entry
        raw_data: Raw API response data in JSON format
        source: Source of the time entry
        start: Start time of the time entry
        tags: Tags in JSON format
        task: Task information in JSON format
        time_entry_details: Time entry details in JSON format
        time_entry_id: ID of the time entry
        user: User information in JSON format
    ### When action = 'create_checklist'
        checklist_details: Checklist details in JSON format
        checklist_id: ID of the created checklist
        checklist_name: Name of the created checklist
        raw_data: Raw API response data in JSON format
    ### When action = 'update_checklist'
        checklist_details: Checklist details in JSON format
        checklist_id: ID of the updated checklist
        checklist_name: Name of the updated checklist
        raw_data: Raw API response data in JSON format
    ### When action = 'create_checklist_item'
        checklist_details: Checklist details in JSON format
        checklist_id: ID of the checklist
        checklist_item_id: ID of the created checklist item
        raw_data: Raw API response data in JSON format
    ### When action = 'update_checklist_item'
        checklist_details: Checklist details in JSON format
        checklist_id: ID of the checklist
        checklist_name: Name of the checklist
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_checklist'
        checklist_id: ID of the deleted checklist
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_checklist_item'
        checklist_id: ID of the checklist
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'read_goal'
        color: Color of the goal
        created_at: Creation timestamp of the goal
        description: Description of the goal
        due_date: Due date of the goal
        folder_access: Whether the goal has folder access
        goal_details: Goal details in JSON format
        goal_id: ID of the goal
        goal_name: Name of the goal
        history: Goal history in JSON format
        key_results: Key results in JSON format
        multiple_owners: Whether the goal has multiple owners
        owners: Goal owners in JSON format
        percent_completed: Percentage of goal completion
        pretty_id: Pretty ID of the goal
        pretty_url: Pretty URL of the goal
        raw_data: Raw API response data in JSON format
        team_id: ID of the team
        updated_at: Update timestamp of the goal
    ### When action = 'get_comments'
        comment_created_dates: List of comment creation dates
        comment_details: Comments details in JSON format
        comment_ids: List of comment IDs
        comment_texts: List of comment texts
        comment_updated_dates: List of comment update dates
        comment_users: List of comment authors in JSON format
        raw_data: Raw API response data in JSON format
    ### When action = 'create_comment'
        comment_details: Comment details in JSON format
        comment_id: ID of the created comment
        comment_text: Text of the created comment
        created_at: Creation timestamp of the comment
        raw_data: Raw API response data in JSON format
        user: User who created the comment
    ### When action = 'update_comment'
        comment_id: ID of the updated comment
        comment_text: Text of the updated comment
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_comment'
        comment_id: ID of the deleted comment
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'create_task'
        created_at: Creation timestamp of the task
        raw_data: Raw API response data in JSON format
        status: Status of the created task
        task_details: Task details in JSON format
        task_id: ID of the created task
        task_name: Name of the created task
        task_url: URL of the created task
    ### When action = 'set_custom_field'
        custom_field_id: ID of the custom field
        custom_field_value: New value of the custom field
        message: Success message
        raw_data: Raw API response data in JSON format
        task_id: ID of the task
    ### When action = 'get_custom_fields'
        custom_field_ids: List of custom field IDs
        custom_field_names: List of custom field names
        custom_field_types: List of custom field types
        custom_fields_details: Custom fields details in JSON format
        raw_data: Raw API response data in JSON format
    ### When action = 'create_task_dependency'
        depends_on_task_id: ID of the task this depends on
        message: Success message
        raw_data: Raw API response data in JSON format
        task_id: ID of the dependent task
    ### When action = 'delete_task_dependency'
        depends_on_task_id: ID of the task this depends on
        message: Success message
        raw_data: Raw API response data in JSON format
        task_id: ID of the dependent task
    ### When action = 'create_folder'
        folder_details: Folder details in JSON format
        folder_id: ID of the created folder
        folder_name: Name of the created folder
        raw_data: Raw API response data in JSON format
    ### When action = 'update_folder'
        folder_details: Folder details in JSON format
        folder_id: ID of the updated folder
        folder_name: Name of the updated folder
        raw_data: Raw API response data in JSON format
    ### When action = 'read_folder'
        folder_details: Folder details in JSON format
        folder_id: ID of the folder
        folder_name: Name of the folder
        hidden: Whether the folder is hidden
        lists: Lists in the folder in JSON format
        order_index: Order index of the folder
        raw_data: Raw API response data in JSON format
        space: Space information in JSON format
        task_count: Number of tasks in the folder
    ### When action = 'get_folders'
        folder_details: Folders details in JSON format
        folder_hidden_states: List of folder hidden states
        folder_ids: List of folder IDs
        folder_lists: List of lists in JSON format
        folder_names: List of folder names
        folder_order_indexes: List of folder order indexes
        folder_spaces: List of spaces in JSON format
        folder_task_counts: List of task counts in JSON format
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_folder'
        folder_id: ID of the deleted folder
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'get_goals'
        goal_colors: List of goal colors
        goal_created_dates: List of goal creation dates
        goal_descriptions: List of goal descriptions
        goal_details: Goals details in JSON format
        goal_due_dates: List of goal due dates
        goal_folder_access: List of folder access flags
        goal_ids: List of goal IDs
        goal_key_results: List of key results in JSON format
        goal_multiple_owners: List of multiple owners flags
        goal_names: List of goal names
        goal_owners: List of goal owners in JSON format
        goal_percent_completed: List of goal completion percentages
        goal_pretty_ids: List of goal pretty IDs
        goal_pretty_urls: List of goal pretty URLs
        goal_team_ids: List of team IDs
        goal_updated_dates: List of goal update dates
        raw_data: Raw API response data in JSON format
    ### When action = 'create_goal'
        goal_details: Goal details in JSON format
        goal_id: ID of the created goal
        goal_name: Name of the created goal
        raw_data: Raw API response data in JSON format
    ### When action = 'update_goal'
        goal_details: Goal details in JSON format
        goal_id: ID of the updated goal
        goal_name: Name of the updated goal
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_goal'
        goal_id: ID of the deleted goal
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'create_goal_key_result'
        key_result_details: Key result details in JSON format
        key_result_id: ID of the created key result
        key_result_name: Name of the created key result
        raw_data: Raw API response data in JSON format
    ### When action = 'update_goal_key_result'
        key_result_details: Key result details in JSON format
        key_result_id: ID of the updated key result
        key_result_name: Name of the updated key result
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_goal_key_result'
        key_result_id: ID of the deleted key result
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'get_lists'
        list_assignees: List of assignees in JSON format
        list_details: Lists details in JSON format
        list_due_dates: List of due dates
        list_folders: List of folders in JSON format
        list_ids: List of list IDs
        list_names: List of list names
        list_order_indexes: List of list order indexes
        list_priorities: List of priorities in JSON format
        list_spaces: List of spaces in JSON format
        list_start_dates: List of start dates
        list_status_arrays: List of status arrays in JSON format
        list_statuses: List of list statuses
        list_task_counts: List of task counts in JSON format
        raw_data: Raw API response data in JSON format
    ### When action = 'create_list'
        list_details: List details in JSON format
        list_id: ID of the created list
        list_name: Name of the created list
        raw_data: Raw API response data in JSON format
    ### When action = 'update_list'
        list_details: List details in JSON format
        list_id: ID of the updated list
        list_name: Name of the updated list
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_list'
        list_id: ID of the deleted list
        message: Success message
        raw_data: Raw API response data in JSON format
    ### When action = 'add_task_to_list'
        list_id: ID of the list
        message: Success message
        raw_data: Raw API response data in JSON format
        task_id: ID of the task
    ### When action = 'remove_task_from_list'
        list_id: ID of the list
        message: Success message
        raw_data: Raw API response data in JSON format
        task_id: ID of the task
    ### When action = 'get_list_members'
        member_details: Members details in JSON format
        member_emails: List of member emails
        member_ids: List of member user IDs
        member_names: List of member usernames
        raw_data: Raw API response data in JSON format
    ### When action = 'get_task_members'
        member_ids: List of member user IDs
        member_names: List of member usernames
        member_roles: List of member roles
        members_details: Members details in JSON format
        raw_data: Raw API response data in JSON format
    ### When action = 'delete_task'
        message: Success message
        raw_data: Raw API response data in JSON format
        task_id: ID of the deleted task
    ### When action = 'delete_space'
        message: Success message
        raw_data: Raw API response data in JSON format
        space_id: ID of the deleted space
    ### When action = 'delete_time_entry'
        message: Success message
        raw_data: Raw API response data in JSON format
        response_data: Response data from the API
        time_entry_id: ID of the deleted time entry
    ### When action = 'start_time_entry'
        message: Success message
        raw_data: Raw API response data in JSON format
        time_entry_details: Time entry details in JSON format
        time_entry_id: ID of the started time entry
    ### When action = 'stop_time_entry'
        message: Success message
        raw_data: Raw API response data in JSON format
        time_entry_details: Time entry details in JSON format
        time_entry_id: ID of the stopped time entry
    ### When action = 'create_space_tag'
        message: Success message
        raw_data: Raw API response data in JSON format
        space_id: ID of the space
        tag_name: Name of the created tag
    ### When action = 'delete_space_tag'
        message: Success message
        raw_data: Raw API response data in JSON format
        space_id: ID of the space
        tag_name: Name of the deleted tag
    ### When action = 'update_space_tag'
        message: Success message
        new_tag_name: New name of the tag
        old_tag_name: Previous name of the tag
        raw_data: Raw API response data in JSON format
        space_id: ID of the space
    ### When action = 'add_task_tag'
        message: Success message
        raw_data: Raw API response data in JSON format
        tag_name: Name of the added tag
        task_id: ID of the task
    ### When action = 'remove_task_tag'
        message: Success message
        raw_data: Raw API response data in JSON format
        tag_name: Name of the removed tag
        task_id: ID of the task
    ### When action = 'add_time_entry_tag'
        message: Success message
        raw_data: Raw API response data in JSON format
        tag_name: Name of the added tag
        time_entry_ids: Array of time entry IDs that were tagged
    ### When action = 'remove_time_entry_tag'
        message: Success message
        raw_data: Raw API response data in JSON format
        tag_names: List of removed tag names
        time_entry_ids: Array of time entry IDs that were tagged
    ### When action = 'update_task'
        raw_data: Raw API response data in JSON format
        status: Status of the updated task
        task_details: Task details in JSON format
        task_id: ID of the updated task
        task_name: Name of the updated task
        task_url: URL of the updated task
        updated_at: Update timestamp of the task
    ### When action = 'get_tasks'
        raw_data: Raw API response data in JSON format
        task_assignees: Task assignees in JSON format
        task_created_dates: List of task creation dates
        task_descriptions: List of task descriptions
        task_details: Tasks details in JSON format
        task_due_dates: List of task due dates
        task_ids: List of task IDs
        task_names: List of task names
        task_priorities: Task priorities in JSON format
        task_start_dates: List of task start dates
        task_statuses: List of task statuses
        task_tags: Task tags in JSON format
        task_updated_dates: List of task update dates
        task_urls: List of task URLs
    ### When action = 'create_space'
        raw_data: Raw API response data in JSON format
        space_details: Space details in JSON format
        space_id: ID of the created space
        space_name: Name of the created space
    ### When action = 'create_time_entry'
        raw_data: Raw API response data in JSON format
        time_entry_details: Time entry details in JSON format
        time_entry_id: ID of the created time entry
    ### When action = 'get_time_entries'
        raw_data: Raw API response data in JSON format
        time_entry_billables: List of billable flags
        time_entry_created_dates: List of creation dates
        time_entry_descriptions: List of descriptions
        time_entry_details: Time entries details in JSON format
        time_entry_durations: List of durations
        time_entry_ends: List of end times
        time_entry_ids: List of time entry IDs
        time_entry_sources: List of sources
        time_entry_starts: List of start times
        time_entry_tags: List of tags in JSON format
        time_entry_tasks: List of tasks in JSON format
        time_entry_users: List of users in JSON format
    ### When action = 'update_time_entry'
        raw_data: Raw API response data in JSON format
        time_entry_details: Time entry details in JSON format
        time_entry_id: ID of the updated time entry
    ### When action = 'get_space_tags'
        raw_data: Raw API response data in JSON format
        space_id: ID of the space
        tag_backgrounds: List of tag background colors
        tag_creators: List of tag creator IDs
        tag_details: Tags details in JSON format
        tag_foregrounds: List of tag foreground colors
        tag_names: List of tag names
    ### When action = 'get_time_entry_tags'
        raw_data: Raw API response data in JSON format
        tag_details: Time entry tags details in JSON format
        tag_names: List of time entry tag names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Clickup>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list where task will be created",
                    "label": "List",
                    "placeholder": "Select list",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the task",
                    "label": "Status",
                    "placeholder": "to do",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=status&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_assignees",
                    "type": "string",
                    "value": "",
                    "helper_text": "List of assignee IDs",
                    "label": "Assignees",
                    "placeholder": "User IDs",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the task",
                    "label": "Priority",
                    "placeholder": "Normal",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Urgent", "value": "1"},
                            {"label": "High", "value": "2"},
                            {"label": "Normal", "value": "3"},
                            {"label": "Low", "value": "4"},
                        ],
                    },
                },
                {
                    "field": "task_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the task",
                    "label": "Task Name",
                    "placeholder": "Complete project documentation",
                },
                {
                    "field": "task_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the task",
                    "label": "Task Description",
                    "placeholder": "Write comprehensive documentation for the project",
                },
                {
                    "field": "task_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "List of tags for the task",
                    "label": "Tags",
                    "placeholder": "Tags",
                },
                {
                    "field": "task_due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date for the task (timestamp)",
                    "label": "Due Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "task_start_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Start date for the task (timestamp)",
                    "label": "Start Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the parent task (for subtasks)",
                    "label": "Parent Task ID",
                    "placeholder": "Parent task ID",
                },
                {
                    "field": "time_estimate",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Time estimate for the task in hours",
                    "label": "Time Estimate",
                    "placeholder": "2",
                },
                {
                    "field": "notify_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Notify all members when task is created",
                    "label": "Notify All",
                    "placeholder": False,
                },
                {
                    "field": "markdown_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Task content in markdown format",
                    "label": "Markdown Content",
                    "placeholder": "## Task Details\n- Item 1\n- Item 2",
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the created task",
                },
                {
                    "field": "task_name",
                    "type": "string",
                    "helper_text": "Name of the created task",
                },
                {
                    "field": "task_url",
                    "type": "string",
                    "helper_text": "URL of the created task",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the created task",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the task",
                },
                {
                    "field": "task_details",
                    "type": "string",
                    "helper_text": "Task details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_task",
            "task_name": "tasks.clickup.create_task",
            "description": "Create a new task in ClickUp",
            "label": "Create Task",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_status",
                "task_assignees",
                "task_priority",
                "task_name",
                "task_description",
                "task_tags",
                "task_due_date",
                "task_start_date",
                "parent_id",
                "time_estimate",
                "notify_all",
                "markdown_content",
            ],
            "required": ["list_id", "task_name", "task_description"],
        },
        "update_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to read tasks from",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to read",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_task_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "New status for the task",
                    "label": "Status",
                    "placeholder": "in progress",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=status&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_task_assignees",
                    "type": "string",
                    "value": "",
                    "helper_text": "New list of assignee IDs (will not work if remove_assignees is enabled)",
                    "label": "Assignees",
                    "placeholder": "User IDs",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "notify_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "If enabled, creation notifications will be sent to everyone including the creator of the task",
                    "label": "Notify All",
                },
                {
                    "field": "remove_all_assignees",
                    "type": "bool",
                    "value": False,
                    "helper_text": "If enabled, all assignees will be removed from the task",
                    "label": "Remove All Assignees",
                },
                {
                    "field": "update_task_priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "New priority for the task",
                    "label": "Priority",
                    "placeholder": "Normal",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Urgent", "value": "1"},
                            {"label": "High", "value": "2"},
                            {"label": "Normal", "value": "3"},
                            {"label": "Low", "value": "4"},
                        ],
                    },
                },
                {
                    "field": "update_task_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the task",
                    "label": "Task Name",
                    "placeholder": "Updated task name",
                },
                {
                    "field": "update_task_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the task",
                    "label": "Task Description",
                    "placeholder": "Updated description",
                },
                {
                    "field": "update_task_due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "New due date for the task (timestamp)",
                    "label": "Due Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "update_task_start_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "New start date for the task (timestamp)",
                    "label": "Start Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "update_task_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "New list of tags for the task",
                    "label": "Tags",
                    "placeholder": "Tags",
                },
                {
                    "field": "update_parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "New parent task ID (for subtasks)",
                    "label": "Parent Task ID",
                    "placeholder": "Parent task ID",
                },
                {
                    "field": "update_time_estimate",
                    "type": "int32",
                    "value": "",
                    "helper_text": "New time estimate for the task in hours",
                    "label": "Time Estimate",
                    "placeholder": "2",
                },
                {
                    "field": "update_markdown_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Task content in markdown format",
                    "label": "Markdown Content",
                    "placeholder": "## Task Details\n- Item 1\n- Item 2",
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the updated task",
                },
                {
                    "field": "task_name",
                    "type": "string",
                    "helper_text": "Name of the updated task",
                },
                {
                    "field": "task_url",
                    "type": "string",
                    "helper_text": "URL of the updated task",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the updated task",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Update timestamp of the task",
                },
                {
                    "field": "task_details",
                    "type": "string",
                    "helper_text": "Task details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_task",
            "task_name": "tasks.clickup.update_task",
            "description": "Update an existing task in ClickUp",
            "label": "Update Task",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "update_task_status",
                "update_task_assignees",
                "notify_all",
                "remove_all_assignees",
                "update_task_priority",
                "update_task_name",
                "update_task_description",
                "update_task_due_date",
                "update_task_start_date",
                "update_task_tags",
                "update_parent_id",
                "update_time_estimate",
                "update_markdown_content",
            ],
            "required": ["task_id"],
        },
        "read_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to read tasks from",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to read",
                    "label": "Task ID",
                    "placeholder": "Select task ID",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {
                    "field": "task_name",
                    "type": "string",
                    "helper_text": "Name of the task",
                },
                {
                    "field": "task_url",
                    "type": "string",
                    "helper_text": "URL of the task",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the task",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the task",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the task",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the task",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees for the task",
                },
                {
                    "field": "tags",
                    "type": "vec<string>",
                    "helper_text": "List of tags for the task",
                },
                {
                    "field": "priority",
                    "type": "string",
                    "helper_text": "Priority of the task",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the task",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "Start date of the task",
                },
                {
                    "field": "task_details",
                    "type": "string",
                    "helper_text": "Task details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "read_task",
            "task_name": "tasks.clickup.read_task",
            "description": "Read details of a specific task",
            "label": "Get Task",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
            ],
            "required": ["task_id"],
        },
        "delete_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to delete tasks from",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to delete",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the deleted task",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_task",
            "task_name": "tasks.clickup.delete_task",
            "description": "Delete an existing task in ClickUp",
            "label": "Delete Task",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
            ],
            "required": ["task_id"],
        },
        "get_tasks**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space (requires Team to be selected first)",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder (requires Team and Space to be selected first)",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to get tasks from (requires Team, Space, and Folder to be selected first)",
                    "label": "List",
                    "placeholder": "Select list",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Filter tasks by created date range",
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "helper_text": "Show archived tasks",
                    "label": "Archived",
                },
                {
                    "field": "include_markdown_description",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "helper_text": "Include markdown description",
                    "label": "Include Markdown Description",
                },
                {
                    "field": "include_closed",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "helper_text": "Include closed tasks",
                    "label": "Include Closed",
                },
                {
                    "field": "subtasks",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "helper_text": "Include subtasks",
                    "label": "Include Subtasks",
                },
                {
                    "field": "reverse",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "helper_text": "Reverse the sort order",
                    "label": "Reverse Sort",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort tasks by field (created, updated, due_date, etc.)",
                    "label": "Order By",
                    "placeholder": "created",
                },
                {
                    "field": "statuses",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by specific task statuses (requires Team, Space, Folder, and List to be selected first)",
                    "label": "Status",
                    "placeholder": "to do",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=status&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignees",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by assignee (requires Team, Space, Folder, and List to be selected first)",
                    "label": "Assignees",
                    "placeholder": "User IDs",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by tag names",
                    "label": "Tags",
                    "placeholder": "Enter tag names",
                },
                {
                    "field": "due_date_gt",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Tasks due after this date (YYYY-MM-DD)",
                    "label": "Due Date After",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "due_date_lt",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Tasks due before this date (YYYY-MM-DD)",
                    "label": "Due Date Before",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "date_updated_gt",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Tasks updated after this date (YYYY-MM-DD)",
                    "label": "Updated After",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "date_updated_lt",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Tasks updated before this date (YYYY-MM-DD)",
                    "label": "Updated Before",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": 'Custom field filters in JSON format: {"field_id": "value"}',
                    "label": "Custom Fields",
                    "placeholder": '{"cf_123": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "task_ids",
                    "type": "vec<string>",
                    "helper_text": "List of task IDs",
                },
                {
                    "field": "task_names",
                    "type": "vec<string>",
                    "helper_text": "List of task names",
                },
                {
                    "field": "task_urls",
                    "type": "vec<string>",
                    "helper_text": "List of task URLs",
                },
                {
                    "field": "task_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of task statuses",
                },
                {
                    "field": "task_details",
                    "type": "string",
                    "helper_text": "Tasks details in JSON format",
                },
                {
                    "field": "task_assignees",
                    "type": "string",
                    "helper_text": "Task assignees in JSON format",
                },
                {
                    "field": "task_tags",
                    "type": "string",
                    "helper_text": "Task tags in JSON format",
                },
                {
                    "field": "task_priorities",
                    "type": "string",
                    "helper_text": "Task priorities in JSON format",
                },
                {
                    "field": "task_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of task due dates",
                },
                {
                    "field": "task_start_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of task start dates",
                },
                {
                    "field": "task_created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of task creation dates",
                },
                {
                    "field": "task_updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of task update dates",
                },
                {
                    "field": "task_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of task descriptions",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_tasks",
            "task_name": "tasks.clickup.get_tasks",
            "description": "Get multiple tasks",
            "label": "List Tasks",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "archived",
                "include_markdown_description",
                "include_closed",
                "subtasks",
                "reverse",
                "order_by",
                "statuses",
                "assignees",
                "tags",
                "due_date_gt",
                "due_date_lt",
                "date_updated_gt",
                "date_updated_lt",
                "custom_fields",
            ],
            "required": ["team_id"],
        },
        "get_tasks**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Tasks",
                    "helper_text": "Specify the number of tasks to fetch",
                }
            ],
            "outputs": [],
        },
        "get_tasks**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_tasks**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_tasks**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "comment_on",
                    "type": "string",
                    "value": "Task",
                    "helper_text": "Select where to add the comment",
                    "label": "Comment On",
                    "placeholder": "Select target",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Task", "value": "Task"},
                            {"label": "List", "value": "List"},
                            {"label": "View", "value": "View"},
                        ],
                    },
                },
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list (required when commenting on List or when selecting a Task)",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to add comment to (required when Comment On is 'Task')",
                    "label": "Task",
                    "placeholder": "Select task",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the view to add comment to (required when Comment On is 'View')",
                    "label": "View",
                    "placeholder": "Select view",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assign_user",
                    "type": "string",
                    "value": "",
                    "helper_text": "User ID to assign to this comment",
                    "label": "Assign User",
                    "placeholder": "123456",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the comment",
                    "label": "Comment Text",
                    "placeholder": "This is a comment",
                },
                {
                    "field": "notify_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Notify all members",
                    "label": "Notify All",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the created comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "Text of the created comment",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the comment",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "User who created the comment",
                },
                {
                    "field": "comment_details",
                    "type": "string",
                    "helper_text": "Comment details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_comment",
            "task_name": "tasks.clickup.create_comment",
            "description": "Create a new comment on a ClickUp task, list, or view",
            "label": "Create Comment",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "comment_on",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "view_id",
                "assign_user",
                "comment_text",
                "notify_all",
            ],
            "required": ["comment_text", "comment_on"],
        },
        "get_comments**(*)**(*)": {
            "inputs": [
                {
                    "field": "comment_on",
                    "type": "string",
                    "value": "Task",
                    "helper_text": "Select where to get comments from",
                    "label": "Comment On",
                    "placeholder": "Select target",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Task", "value": "Task"},
                            {"label": "List", "value": "List"},
                            {"label": "View", "value": "View"},
                        ],
                    },
                },
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list (required when getting comments from List or when selecting a Task)",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to get comments from (required when Comment On is 'Task')",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "view_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the view to get comments from (required when Comment On is 'View')",
                    "label": "View",
                    "placeholder": "Select view",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=view_name&team={inputs.team_id}&space={inputs.space_id}&folder={inputs.folder_id}&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "comment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of comment IDs",
                },
                {
                    "field": "comment_texts",
                    "type": "vec<string>",
                    "helper_text": "List of comment texts",
                },
                {
                    "field": "comment_users",
                    "type": "string",
                    "helper_text": "List of comment authors in JSON format",
                },
                {
                    "field": "comment_created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of comment creation dates",
                },
                {
                    "field": "comment_updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of comment update dates",
                },
                {
                    "field": "comment_details",
                    "type": "string",
                    "helper_text": "Comments details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_comments",
            "task_name": "tasks.clickup.get_comments",
            "description": "Get multiple comments from a ClickUp task",
            "label": "List Comments",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "comment_on",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "view_id",
            ],
            "required": ["comment_on"],
        },
        "update_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list (required for assignee dropdown)",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the comment to update (comment under task or list)",
                    "label": "Comment ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "update_comment_text",
                    "type": "string",
                    "value": "",
                    "helper_text": "New content for the comment",
                    "label": "Comment Text",
                    "placeholder": "Updated comment text",
                },
                {
                    "field": "update_comment_assignee",
                    "type": "string",
                    "value": "",
                    "helper_text": "User ID to assign the comment to",
                    "label": "Assignee ID",
                    "placeholder": "Select assignee",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=assignee&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_comment_resolved",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Mark the comment as resolved",
                    "label": "Resolved",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the updated comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "Text of the updated comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_comment",
            "task_name": "tasks.clickup.update_comment",
            "description": "Update an existing comment on a ClickUp task",
            "label": "Update Comment",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "comment_id",
                "update_comment_text",
                "update_comment_assignee",
                "update_comment_resolved",
            ],
            "required": ["comment_id"],
        },
        "delete_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the comment to delete",
                    "label": "Comment ID",
                    "placeholder": "abc123def456",
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the deleted comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_comment",
            "task_name": "tasks.clickup.delete_comment",
            "description": "Delete an existing comment from a ClickUp task",
            "label": "Delete Comment",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "comment_id"],
            "required": ["comment_id"],
        },
        "create_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folderless",
                    "type": "bool",
                    "value": False,
                    "helper_text": "If enabled, create list at space root level without a folder",
                    "label": "Folderless List",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder where list will be created (ignored if folderless is enabled)",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the list",
                    "label": "List Name",
                    "placeholder": "My New List",
                },
                {
                    "field": "list_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the list",
                    "label": "List Description",
                    "placeholder": "Description for the new list",
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the created list",
                },
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Name of the created list",
                },
                {
                    "field": "list_details",
                    "type": "string",
                    "helper_text": "List details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_list",
            "task_name": "tasks.clickup.create_list",
            "description": "Create a new list in ClickUp",
            "label": "Create List",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folderless",
                "folder_id",
                "list_name",
                "list_content",
            ],
            "required": ["list_name"],
        },
        "update_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to update",
                    "label": "List",
                    "placeholder": "Select list",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_list_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the list",
                    "label": "List Name",
                    "placeholder": "Updated list name",
                },
                {
                    "field": "update_list_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the list",
                    "label": "List Description",
                    "placeholder": "Updated description",
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the updated list",
                },
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Name of the updated list",
                },
                {
                    "field": "list_details",
                    "type": "string",
                    "helper_text": "List details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_list",
            "task_name": "tasks.clickup.update_list",
            "description": "Update an existing list in ClickUp",
            "label": "Update List",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "update_list_name",
                "update_list_content",
            ],
            "required": ["list_id"],
        },
        "read_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to read",
                    "label": "List",
                    "placeholder": "Select list",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "list_id", "type": "string", "helper_text": "ID of the list"},
                {
                    "field": "list_name",
                    "type": "string",
                    "helper_text": "Name of the list",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the list",
                },
                {
                    "field": "order_index",
                    "type": "int32",
                    "helper_text": "Order index of the list",
                },
                {
                    "field": "task_count",
                    "type": "string",
                    "helper_text": "Number of tasks in the list",
                },
                {
                    "field": "priority",
                    "type": "string",
                    "helper_text": "Priority of the list",
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "helper_text": "Assignee of the list",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the list",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "Start date of the list",
                },
                {
                    "field": "folder",
                    "type": "string",
                    "helper_text": "Folder information in JSON format",
                },
                {
                    "field": "space",
                    "type": "string",
                    "helper_text": "Space information in JSON format",
                },
                {
                    "field": "statuses",
                    "type": "string",
                    "helper_text": "List of statuses in JSON format",
                },
                {
                    "field": "list_details",
                    "type": "string",
                    "helper_text": "List details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "read_list",
            "task_name": "tasks.clickup.read_list",
            "description": "Read details of a specific list",
            "label": "Get List",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
            ],
            "required": ["list_id"],
        },
        "get_lists**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder to get lists from",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Show archived lists",
                    "label": "Archived",
                },
            ],
            "outputs": [
                {
                    "field": "list_ids",
                    "type": "vec<string>",
                    "helper_text": "List of list IDs",
                },
                {
                    "field": "list_names",
                    "type": "vec<string>",
                    "helper_text": "List of list names",
                },
                {
                    "field": "list_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of list statuses",
                },
                {
                    "field": "list_order_indexes",
                    "type": "vec<int32>",
                    "helper_text": "List of list order indexes",
                },
                {
                    "field": "list_task_counts",
                    "type": "string",
                    "helper_text": "List of task counts in JSON format",
                },
                {
                    "field": "list_priorities",
                    "type": "string",
                    "helper_text": "List of priorities in JSON format",
                },
                {
                    "field": "list_assignees",
                    "type": "string",
                    "helper_text": "List of assignees in JSON format",
                },
                {
                    "field": "list_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of due dates",
                },
                {
                    "field": "list_start_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of start dates",
                },
                {
                    "field": "list_folders",
                    "type": "string",
                    "helper_text": "List of folders in JSON format",
                },
                {
                    "field": "list_spaces",
                    "type": "string",
                    "helper_text": "List of spaces in JSON format",
                },
                {
                    "field": "list_status_arrays",
                    "type": "string",
                    "helper_text": "List of status arrays in JSON format",
                },
                {
                    "field": "list_details",
                    "type": "string",
                    "helper_text": "Lists details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_lists",
            "task_name": "tasks.clickup.get_lists",
            "description": "Get multiple lists",
            "label": "List Lists",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "archived",
            ],
        },
        "delete_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to delete",
                    "label": "List",
                    "placeholder": "Select list",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the deleted list",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_list",
            "task_name": "tasks.clickup.delete_list",
            "description": "Delete an existing list in ClickUp",
            "label": "Delete List",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
            ],
            "required": ["list_id"],
        },
        "get_list_members**(*)**(*)": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to get members from",
                    "label": "List ID",
                    "placeholder": "abc123def456",
                }
            ],
            "outputs": [
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member user IDs",
                },
                {
                    "field": "member_names",
                    "type": "vec<string>",
                    "helper_text": "List of member usernames",
                },
                {
                    "field": "member_emails",
                    "type": "vec<string>",
                    "helper_text": "List of member emails",
                },
                {
                    "field": "member_details",
                    "type": "string",
                    "helper_text": "Members details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_list_members",
            "task_name": "tasks.clickup.get_list_members",
            "description": "Get multiple members who have access to a list",
            "label": "List List Members",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "list_id"],
            "required": ["list_id"],
        },
        "create_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space where folder will be created",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the folder",
                    "label": "Folder Name",
                    "placeholder": "My New Folder",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the created folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the created folder",
                },
                {
                    "field": "folder_details",
                    "type": "string",
                    "helper_text": "Folder details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.clickup.create_folder",
            "description": "Create a new folder in ClickUp",
            "label": "Create Folder",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_name",
            ],
            "required": ["space_id", "folder_name"],
        },
        "update_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder to update",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the folder",
                    "label": "Folder Name",
                    "placeholder": "Updated folder name",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the updated folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the updated folder",
                },
                {
                    "field": "folder_details",
                    "type": "string",
                    "helper_text": "Folder details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_folder",
            "task_name": "tasks.clickup.update_folder",
            "description": "Update an existing folder in ClickUp",
            "label": "Update Folder",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "update_folder_name",
            ],
            "required": ["folder_id", "update_folder_name"],
        },
        "read_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder to read",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "order_index",
                    "type": "int32",
                    "helper_text": "Order index of the folder",
                },
                {
                    "field": "hidden",
                    "type": "bool",
                    "helper_text": "Whether the folder is hidden",
                },
                {
                    "field": "task_count",
                    "type": "string",
                    "helper_text": "Number of tasks in the folder",
                },
                {
                    "field": "space",
                    "type": "string",
                    "helper_text": "Space information in JSON format",
                },
                {
                    "field": "lists",
                    "type": "string",
                    "helper_text": "Lists in the folder in JSON format",
                },
                {
                    "field": "folder_details",
                    "type": "string",
                    "helper_text": "Folder details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "read_folder",
            "task_name": "tasks.clickup.read_folder",
            "description": "Read details of a specific folder",
            "label": "Get Folder",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
            ],
            "required": ["folder_id"],
        },
        "get_folders**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space to get folders from",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Show archived folders",
                    "label": "Archived",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of folders to retrieve",
                    "label": "Limit",
                    "placeholder": "10",
                },
            ],
            "outputs": [
                {
                    "field": "folder_ids",
                    "type": "vec<string>",
                    "helper_text": "List of folder IDs",
                },
                {
                    "field": "folder_names",
                    "type": "vec<string>",
                    "helper_text": "List of folder names",
                },
                {
                    "field": "folder_order_indexes",
                    "type": "vec<int32>",
                    "helper_text": "List of folder order indexes",
                },
                {
                    "field": "folder_hidden_states",
                    "type": "vec<bool>",
                    "helper_text": "List of folder hidden states",
                },
                {
                    "field": "folder_task_counts",
                    "type": "string",
                    "helper_text": "List of task counts in JSON format",
                },
                {
                    "field": "folder_spaces",
                    "type": "string",
                    "helper_text": "List of spaces in JSON format",
                },
                {
                    "field": "folder_lists",
                    "type": "string",
                    "helper_text": "List of lists in JSON format",
                },
                {
                    "field": "folder_details",
                    "type": "string",
                    "helper_text": "Folders details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_folders",
            "task_name": "tasks.clickup.get_folders",
            "description": "Get multiple folders",
            "label": "List Folders",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "archived",
                "limit",
            ],
            "required": ["space_id"],
        },
        "delete_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder to delete",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the deleted folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_folder",
            "task_name": "tasks.clickup.delete_folder",
            "description": "Delete an existing folder in ClickUp",
            "label": "Delete Folder",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
            ],
            "required": ["folder_id"],
        },
        "create_space**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team where space will be created",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the space",
                    "label": "Space Name",
                    "placeholder": "My New Space",
                },
                {
                    "field": "space_multiple_assignees",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow multiple assignees",
                    "label": "Multiple Assignees",
                },
                {
                    "field": "enable_time_tracking",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow time tracking",
                    "label": "Time Tracking",
                },
                {
                    "field": "enable_priority",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow priority",
                    "label": "Priority",
                },
                {
                    "field": "enable_tags",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow tags",
                    "label": "Tags",
                },
                {
                    "field": "enable_custom_fields",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow custom fields",
                    "label": "Custom Fields",
                },
                {
                    "field": "enable_incomplete_warnings",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow incomplete warnings",
                    "label": "Incomplete Warnings",
                },
                {
                    "field": "enable_dependency_warnings",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow dependency warnings",
                    "label": "Dependency Warnings",
                },
            ],
            "outputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the created space",
                },
                {
                    "field": "space_name",
                    "type": "string",
                    "helper_text": "Name of the created space",
                },
                {
                    "field": "space_details",
                    "type": "string",
                    "helper_text": "Space details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_space",
            "task_name": "tasks.clickup.create_space",
            "description": "Create a new space in ClickUp",
            "label": "Create Space",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_name",
                "space_multiple_assignees",
                "enable_time_tracking",
                "enable_priority",
                "enable_tags",
                "enable_custom_fields",
                "enable_incomplete_warnings",
                "enable_dependency_warnings",
            ],
            "required": ["team_id", "space_name"],
        },
        "read_space**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space to read",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the space",
                },
                {
                    "field": "space_name",
                    "type": "string",
                    "helper_text": "Name of the space",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the space",
                },
                {
                    "field": "access",
                    "type": "bool",
                    "helper_text": "Whether the user has access to the space",
                },
                {
                    "field": "statuses",
                    "type": "string",
                    "helper_text": "Space statuses in JSON format",
                },
                {
                    "field": "features",
                    "type": "string",
                    "helper_text": "Space features in JSON format",
                },
                {
                    "field": "space_details",
                    "type": "string",
                    "helper_text": "Space details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "read_space",
            "task_name": "tasks.clickup.read_space",
            "description": "Read details of a specific space",
            "label": "Get Space",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "team_id", "space_id"],
            "required": ["space_id"],
        },
        "delete_space**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space to delete",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the deleted space",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_space",
            "task_name": "tasks.clickup.delete_space",
            "description": "Delete an existing space in ClickUp",
            "label": "Delete Space",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "team_id", "space_id"],
            "required": ["space_id"],
        },
        "create_checklist**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to add checklist to",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to add checklist to",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "checklist_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the checklist",
                    "label": "Checklist Name",
                    "placeholder": "My Checklist",
                },
            ],
            "outputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the created checklist",
                },
                {
                    "field": "checklist_name",
                    "type": "string",
                    "helper_text": "Name of the created checklist",
                },
                {
                    "field": "checklist_details",
                    "type": "string",
                    "helper_text": "Checklist details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_checklist",
            "task_name": "tasks.clickup.create_checklist",
            "description": "Create a new checklist in a ClickUp task",
            "label": "Create Checklist",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "checklist_name",
            ],
            "required": ["task_id", "checklist_name"],
        },
        "delete_checklist**(*)**(*)": {
            "inputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist to delete",
                    "label": "Checklist ID",
                    "placeholder": "abc123def456",
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the deleted checklist",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_checklist",
            "task_name": "tasks.clickup.delete_checklist",
            "description": "Delete an existing checklist in ClickUp",
            "label": "Delete Checklist",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "checklist_id"],
            "required": ["checklist_id"],
        },
        "update_checklist**(*)**(*)": {
            "inputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist to update",
                    "label": "Checklist ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "update_checklist_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the checklist",
                    "label": "Checklist Name",
                    "placeholder": "Updated checklist name",
                },
                {
                    "field": "update_checklist_position",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "New position for the checklist",
                    "label": "Position",
                    "placeholder": "0",
                },
            ],
            "outputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the updated checklist",
                },
                {
                    "field": "checklist_name",
                    "type": "string",
                    "helper_text": "Name of the updated checklist",
                },
                {
                    "field": "checklist_details",
                    "type": "string",
                    "helper_text": "Checklist details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_checklist",
            "task_name": "tasks.clickup.update_checklist",
            "description": "Update an existing checklist in ClickUp",
            "label": "Update Checklist",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "checklist_id",
                "update_checklist_name",
                "update_checklist_position",
            ],
            "required": ["checklist_id"],
        },
        "create_checklist_item**(*)**(*)": {
            "inputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist to add item to",
                    "label": "Checklist ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "checklist_item_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the checklist item",
                    "label": "Item Name",
                    "placeholder": "Checklist item name",
                },
                {
                    "field": "checklist_item_assignee",
                    "type": "string",
                    "value": "",
                    "helper_text": "User ID to assign to this checklist item",
                    "label": "Assignee",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the checklist",
                },
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "helper_text": "ID of the created checklist item",
                },
                {
                    "field": "checklist_details",
                    "type": "string",
                    "helper_text": "Checklist details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_checklist_item",
            "task_name": "tasks.clickup.create_checklist_item",
            "description": "Create a new item in a ClickUp checklist",
            "label": "Create Checklist Item",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "checklist_id",
                "checklist_item_name",
                "checklist_item_assignee",
            ],
            "required": ["checklist_id", "checklist_item_name"],
        },
        "delete_checklist_item**(*)**(*)": {
            "inputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist",
                    "label": "Checklist ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist item to delete",
                    "label": "Checklist Item ID",
                    "placeholder": "item123",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the checklist",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_checklist_item",
            "task_name": "tasks.clickup.delete_checklist_item",
            "description": "Delete an existing item from a ClickUp checklist",
            "label": "Delete Checklist Item",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "checklist_id",
                "checklist_item_id",
            ],
            "required": ["checklist_id", "checklist_item_id"],
        },
        "update_checklist_item**(*)**(*)": {
            "inputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist",
                    "label": "Checklist ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "checklist_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the checklist item to update",
                    "label": "Checklist Item ID",
                    "placeholder": "item123",
                },
                {
                    "field": "update_checklist_item_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the checklist item",
                    "label": "Item Name",
                    "placeholder": "Updated item name",
                },
                {
                    "field": "update_checklist_item_parent",
                    "type": "string",
                    "value": "",
                    "helper_text": "New parent for the checklist item",
                    "label": "Parent",
                    "placeholder": "parent123",
                },
                {
                    "field": "update_checklist_item_assignee",
                    "type": "string",
                    "value": "",
                    "helper_text": "New assignee for the checklist item",
                    "label": "Assignee",
                    "placeholder": "123456",
                },
                {
                    "field": "update_checklist_item_resolved",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Mark checklist item as resolved",
                    "label": "Resolved",
                },
            ],
            "outputs": [
                {
                    "field": "checklist_id",
                    "type": "string",
                    "helper_text": "ID of the checklist",
                },
                {
                    "field": "checklist_name",
                    "type": "string",
                    "helper_text": "Name of the checklist",
                },
                {
                    "field": "checklist_details",
                    "type": "string",
                    "helper_text": "Checklist details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_checklist_item",
            "task_name": "tasks.clickup.update_checklist_item",
            "description": "Update an existing item in a ClickUp checklist",
            "label": "Update Checklist Item",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "checklist_id",
                "checklist_item_id",
                "update_checklist_item_name",
                "update_checklist_item_parent",
                "update_checklist_item_assignee",
                "update_checklist_item_resolved",
            ],
            "required": ["checklist_id", "checklist_item_id"],
        },
        "create_goal**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "goal_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the goal",
                    "label": "Goal Name",
                    "placeholder": "Complete project by Q4",
                },
                {
                    "field": "goal_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the goal",
                    "label": "Goal Description",
                    "placeholder": "Complete the entire project with all deliverables",
                },
                {
                    "field": "goal_due_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Due date for the goal (YYYY-MM-DD or RFC3339)",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "goal_color",
                    "type": "string",
                    "value": "",
                    "helper_text": "Color for the goal",
                    "label": "Color",
                    "placeholder": "#ff0000",
                },
                {
                    "field": "goal_multiple_owners",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Allow multiple owners",
                    "label": "Multiple Owners",
                },
                {
                    "field": "goal_owners",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of owner user IDs",
                    "label": "Owners",
                    "placeholder": "123456,789012",
                },
            ],
            "outputs": [
                {
                    "field": "goal_id",
                    "type": "string",
                    "helper_text": "ID of the created goal",
                },
                {
                    "field": "goal_name",
                    "type": "string",
                    "helper_text": "Name of the created goal",
                },
                {
                    "field": "goal_details",
                    "type": "string",
                    "helper_text": "Goal details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_goal",
            "task_name": "tasks.clickup.create_goal",
            "description": "Create a new goal in ClickUp",
            "label": "Create Goal",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "goal_name",
                "goal_description",
                "goal_due_date",
                "goal_color",
                "goal_multiple_owners",
                "goal_owners",
            ],
            "required": ["team_id", "goal_name"],
        },
        "delete_goal**(*)**(*)": {
            "inputs": [
                {
                    "field": "goal_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the goal to delete",
                    "label": "Goal ID",
                    "placeholder": "abc123def456",
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "goal_id",
                    "type": "string",
                    "helper_text": "ID of the deleted goal",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_goal",
            "task_name": "tasks.clickup.delete_goal",
            "description": "Delete an existing goal in ClickUp",
            "label": "Delete Goal",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "goal_id"],
            "required": ["goal_id"],
        },
        "read_goal**(*)**(*)": {
            "inputs": [
                {
                    "field": "goal_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the goal to read",
                    "label": "Goal ID",
                    "placeholder": "abc123def456",
                }
            ],
            "outputs": [
                {"field": "goal_id", "type": "string", "helper_text": "ID of the goal"},
                {
                    "field": "goal_name",
                    "type": "string",
                    "helper_text": "Name of the goal",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the goal",
                },
                {"field": "team_id", "type": "string", "helper_text": "ID of the team"},
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the goal",
                },
                {
                    "field": "pretty_id",
                    "type": "string",
                    "helper_text": "Pretty ID of the goal",
                },
                {
                    "field": "pretty_url",
                    "type": "string",
                    "helper_text": "Pretty URL of the goal",
                },
                {
                    "field": "multiple_owners",
                    "type": "bool",
                    "helper_text": "Whether the goal has multiple owners",
                },
                {
                    "field": "folder_access",
                    "type": "bool",
                    "helper_text": "Whether the goal has folder access",
                },
                {
                    "field": "percent_completed",
                    "type": "float",
                    "helper_text": "Percentage of goal completion",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the goal",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Update timestamp of the goal",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the goal",
                },
                {
                    "field": "owners",
                    "type": "string",
                    "helper_text": "Goal owners in JSON format",
                },
                {
                    "field": "key_results",
                    "type": "string",
                    "helper_text": "Key results in JSON format",
                },
                {
                    "field": "history",
                    "type": "string",
                    "helper_text": "Goal history in JSON format",
                },
                {
                    "field": "goal_details",
                    "type": "string",
                    "helper_text": "Goal details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "read_goal",
            "task_name": "tasks.clickup.read_goal",
            "description": "Read details of a specific goal",
            "label": "Get Goal",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "goal_id"],
            "required": ["goal_id"],
        },
        "get_goals**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "include_completed",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include completed goals",
                    "label": "Include Completed",
                },
            ],
            "outputs": [
                {
                    "field": "goal_ids",
                    "type": "vec<string>",
                    "helper_text": "List of goal IDs",
                },
                {
                    "field": "goal_names",
                    "type": "vec<string>",
                    "helper_text": "List of goal names",
                },
                {
                    "field": "goal_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of goal descriptions",
                },
                {
                    "field": "goal_team_ids",
                    "type": "vec<string>",
                    "helper_text": "List of team IDs",
                },
                {
                    "field": "goal_colors",
                    "type": "vec<string>",
                    "helper_text": "List of goal colors",
                },
                {
                    "field": "goal_pretty_ids",
                    "type": "vec<string>",
                    "helper_text": "List of goal pretty IDs",
                },
                {
                    "field": "goal_pretty_urls",
                    "type": "vec<string>",
                    "helper_text": "List of goal pretty URLs",
                },
                {
                    "field": "goal_multiple_owners",
                    "type": "vec<bool>",
                    "helper_text": "List of multiple owners flags",
                },
                {
                    "field": "goal_folder_access",
                    "type": "vec<bool>",
                    "helper_text": "List of folder access flags",
                },
                {
                    "field": "goal_percent_completed",
                    "type": "vec<float>",
                    "helper_text": "List of goal completion percentages",
                },
                {
                    "field": "goal_created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of goal creation dates",
                },
                {
                    "field": "goal_updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of goal update dates",
                },
                {
                    "field": "goal_due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of goal due dates",
                },
                {
                    "field": "goal_owners",
                    "type": "string",
                    "helper_text": "List of goal owners in JSON format",
                },
                {
                    "field": "goal_key_results",
                    "type": "string",
                    "helper_text": "List of key results in JSON format",
                },
                {
                    "field": "goal_details",
                    "type": "string",
                    "helper_text": "Goals details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_goals",
            "task_name": "tasks.clickup.get_goals",
            "description": "Get multiple goals",
            "label": "List Goals",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "include_completed",
            ],
            "required": ["team_id"],
        },
        "update_goal**(*)**(*)": {
            "inputs": [
                {
                    "field": "goal_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the goal to update",
                    "label": "Goal ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "update_goal_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the goal",
                    "label": "Goal Name",
                    "placeholder": "Updated goal name",
                },
                {
                    "field": "update_goal_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the goal",
                    "label": "Goal Description",
                    "placeholder": "Updated description",
                },
                {
                    "field": "update_goal_due_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "New due date for the goal (YYYY-MM-DD or RFC3339)",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "update_goal_color",
                    "type": "string",
                    "value": "",
                    "helper_text": "New color for the goal",
                    "label": "Color",
                    "placeholder": "#ff0000",
                },
                {
                    "field": "update_goal_add_owners",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of owner user IDs to add",
                    "label": "Add Owners",
                    "placeholder": "123456,789012",
                },
                {
                    "field": "update_goal_remove_owners",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of owner user IDs to remove",
                    "label": "Remove Owners",
                    "placeholder": "123456,789012",
                },
            ],
            "outputs": [
                {
                    "field": "goal_id",
                    "type": "string",
                    "helper_text": "ID of the updated goal",
                },
                {
                    "field": "goal_name",
                    "type": "string",
                    "helper_text": "Name of the updated goal",
                },
                {
                    "field": "goal_details",
                    "type": "string",
                    "helper_text": "Goal details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_goal",
            "task_name": "tasks.clickup.update_goal",
            "description": "Update an existing goal in ClickUp",
            "label": "Update Goal",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "goal_id",
                "update_goal_name",
                "update_goal_description",
                "update_goal_due_date",
                "update_goal_color",
                "update_goal_add_owners",
                "update_goal_remove_owners",
            ],
            "required": ["goal_id"],
        },
        "create_goal_key_result**(*)**(*)": {
            "inputs": [
                {
                    "field": "goal_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the goal to add key result to",
                    "label": "Goal ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "key_result_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the key result",
                    "label": "Key Result Name",
                    "placeholder": "Increase revenue by 20%",
                },
                {
                    "field": "key_result_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of key result",
                    "label": "Type",
                    "placeholder": "percentage",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Number", "value": "number"},
                            {"label": "Currency", "value": "currency"},
                            {"label": "Boolean", "value": "boolean"},
                            {"label": "Percentage", "value": "percentage"},
                            {"label": "Automatic", "value": "automatic"},
                        ],
                    },
                },
                {
                    "field": "key_result_unit",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unit for the key result",
                    "label": "Unit",
                    "placeholder": "%",
                },
                {
                    "field": "key_result_steps_start",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Starting value for the key result",
                    "label": "Start Value",
                    "placeholder": "0",
                },
                {
                    "field": "key_result_steps_end",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Target value for the key result",
                    "label": "Target Value",
                    "placeholder": "10",
                },
                {
                    "field": "key_result_task_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of task IDs",
                    "label": "Task IDs",
                    "placeholder": "task1,task2",
                },
                {
                    "field": "key_result_list_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of list IDs",
                    "label": "List IDs",
                    "placeholder": "list1,list2",
                },
                {
                    "field": "key_result_owners",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of owner user IDs",
                    "label": "Owners",
                    "placeholder": "123456,789012",
                },
            ],
            "outputs": [
                {
                    "field": "key_result_id",
                    "type": "string",
                    "helper_text": "ID of the created key result",
                },
                {
                    "field": "key_result_name",
                    "type": "string",
                    "helper_text": "Name of the created key result",
                },
                {
                    "field": "key_result_details",
                    "type": "string",
                    "helper_text": "Key result details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_goal_key_result",
            "task_name": "tasks.clickup.create_goal_key_result",
            "description": "Create a new key result for a goal in ClickUp",
            "label": "Create Goal Key Result",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "goal_id",
                "key_result_name",
                "key_result_type",
                "key_result_unit",
                "key_result_steps_start",
                "key_result_steps_end",
                "key_result_task_ids",
                "key_result_list_ids",
                "key_result_owners",
            ],
            "required": ["goal_id", "key_result_name"],
        },
        "delete_goal_key_result**(*)**(*)": {
            "inputs": [
                {
                    "field": "key_result_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the key result to delete",
                    "label": "Key Result ID",
                    "placeholder": "abc123def456",
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "key_result_id",
                    "type": "string",
                    "helper_text": "ID of the deleted key result",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_goal_key_result",
            "task_name": "tasks.clickup.delete_goal_key_result",
            "description": "Delete an existing key result in ClickUp",
            "label": "Delete Goal Key Result",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "key_result_id"],
            "required": ["key_result_id"],
        },
        "update_goal_key_result**(*)**(*)": {
            "inputs": [
                {
                    "field": "key_result_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the key result to update",
                    "label": "Key Result ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "update_key_result_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the key result",
                    "label": "Key Result Name",
                    "placeholder": "Updated key result name",
                },
                {
                    "field": "update_key_result_note",
                    "type": "string",
                    "value": "",
                    "helper_text": "New note for the key result",
                    "label": "Note",
                    "placeholder": "Updated note",
                },
                {
                    "field": "update_key_result_steps_current",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Current progress value",
                    "label": "Current Value",
                    "placeholder": "50",
                },
                {
                    "field": "update_key_result_steps_start",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "New starting value",
                    "label": "Start Value",
                    "placeholder": "0",
                },
                {
                    "field": "update_key_result_steps_end",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "New target value",
                    "label": "Target Value",
                    "placeholder": "10",
                },
                {
                    "field": "update_key_result_unit",
                    "type": "string",
                    "value": "",
                    "helper_text": "New unit for the key result",
                    "label": "Unit",
                    "placeholder": "%",
                },
            ],
            "outputs": [
                {
                    "field": "key_result_id",
                    "type": "string",
                    "helper_text": "ID of the updated key result",
                },
                {
                    "field": "key_result_name",
                    "type": "string",
                    "helper_text": "Name of the updated key result",
                },
                {
                    "field": "key_result_details",
                    "type": "string",
                    "helper_text": "Key result details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_goal_key_result",
            "task_name": "tasks.clickup.update_goal_key_result",
            "description": "Update an existing key result in ClickUp",
            "label": "Update Goal Key Result",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "key_result_id",
                "update_key_result_name",
                "update_key_result_note",
                "update_key_result_steps_current",
                "update_key_result_steps_start",
                "update_key_result_steps_end",
                "update_key_result_unit",
            ],
            "required": ["key_result_id"],
        },
        "create_time_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "start_time",
                    "type": "string",
                    "value": "",
                    "helper_text": "Start time for the time entry (ISO 8601 format)",
                    "label": "Start Time",
                    "placeholder": "2024-01-01T00:00:00Z",
                },
                {
                    "field": "duration_minutes",
                    "type": "int32",
                    "value": 60,
                    "helper_text": "Duration in minutes",
                    "label": "Duration (minutes)",
                    "placeholder": "60",
                },
                {
                    "field": "time_entry_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the time entry",
                    "label": "Description",
                    "placeholder": "Working on feature implementation",
                },
                {
                    "field": "time_entry_billable",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Mark time entry as billable",
                    "label": "Billable",
                },
                {
                    "field": "time_entry_assignee",
                    "type": "string",
                    "value": "",
                    "helper_text": "Assignee user ID for the time entry",
                    "label": "Assignee",
                    "placeholder": "123456",
                },
                {
                    "field": "time_entry_tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of tags or JSON objects",
                    "label": "Tags",
                    "placeholder": "development,feature",
                },
            ],
            "outputs": [
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "helper_text": "ID of the created time entry",
                },
                {
                    "field": "time_entry_details",
                    "type": "string",
                    "helper_text": "Time entry details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_time_entry",
            "task_name": "tasks.clickup.create_time_entry",
            "description": "Create a new time entry in ClickUp",
            "label": "Create Time Entry",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "start_time",
                "duration_minutes",
                "time_entry_description",
                "time_entry_billable",
                "time_entry_assignee",
                "time_entry_tags",
            ],
            "required": ["team_id", "task_id", "start_time", "duration_minutes"],
        },
        "delete_time_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the time entry to delete",
                    "label": "Time Entry ID",
                    "placeholder": "abc123def456",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "helper_text": "ID of the deleted time entry",
                },
                {
                    "field": "response_data",
                    "type": "string",
                    "helper_text": "Response data from the API",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_time_entry",
            "task_name": "tasks.clickup.delete_time_entry",
            "description": "Delete an existing time entry in ClickUp",
            "label": "Delete Time Entry",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "team_id", "time_entry_id"],
            "required": ["team_id", "time_entry_id"],
        },
        "read_time_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the time entry to get (leave empty if getting running time entry)",
                    "label": "Time Entry ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "get_running",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Get currently running time entry",
                    "label": "Get Running Time Entry",
                },
            ],
            "outputs": [
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "helper_text": "ID of the time entry",
                },
                {
                    "field": "task",
                    "type": "string",
                    "helper_text": "Task information in JSON format",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "User information in JSON format",
                },
                {
                    "field": "billable",
                    "type": "bool",
                    "helper_text": "Whether the time entry is billable",
                },
                {
                    "field": "start",
                    "type": "timestamp",
                    "helper_text": "Start time of the time entry",
                },
                {
                    "field": "end",
                    "type": "timestamp",
                    "helper_text": "End time of the time entry",
                },
                {
                    "field": "duration",
                    "type": "string",
                    "helper_text": "Duration of the time entry",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the time entry",
                },
                {
                    "field": "tags",
                    "type": "string",
                    "helper_text": "Tags in JSON format",
                },
                {
                    "field": "source",
                    "type": "string",
                    "helper_text": "Source of the time entry",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the time entry",
                },
                {
                    "field": "time_entry_details",
                    "type": "string",
                    "helper_text": "Time entry details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "read_time_entry",
            "task_name": "tasks.clickup.read_time_entry",
            "description": "Read details of a specific time entry",
            "label": "Get Time Entry",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "time_entry_id",
                "get_running",
            ],
            "required": ["team_id", "time_entry_id"],
        },
        "get_time_entries**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by assignee user ID",
                    "label": "Assignee",
                    "placeholder": "123456",
                },
                {
                    "field": "include_location_names",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include location names",
                    "label": "Include Location Names",
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by space ID",
                    "label": "Space ID",
                    "placeholder": "space123",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by folder ID",
                    "label": "Folder ID",
                    "placeholder": "folder123",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by list ID",
                    "label": "List ID",
                    "placeholder": "list123",
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by task ID",
                    "label": "Task ID",
                    "placeholder": "task123",
                },
            ],
            "outputs": [
                {
                    "field": "time_entry_ids",
                    "type": "vec<string>",
                    "helper_text": "List of time entry IDs",
                },
                {
                    "field": "time_entry_tasks",
                    "type": "string",
                    "helper_text": "List of tasks in JSON format",
                },
                {
                    "field": "time_entry_users",
                    "type": "string",
                    "helper_text": "List of users in JSON format",
                },
                {
                    "field": "time_entry_billables",
                    "type": "vec<bool>",
                    "helper_text": "List of billable flags",
                },
                {
                    "field": "time_entry_starts",
                    "type": "vec<timestamp>",
                    "helper_text": "List of start times",
                },
                {
                    "field": "time_entry_ends",
                    "type": "vec<timestamp>",
                    "helper_text": "List of end times",
                },
                {
                    "field": "time_entry_durations",
                    "type": "vec<string>",
                    "helper_text": "List of durations",
                },
                {
                    "field": "time_entry_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of descriptions",
                },
                {
                    "field": "time_entry_tags",
                    "type": "string",
                    "helper_text": "List of tags in JSON format",
                },
                {
                    "field": "time_entry_sources",
                    "type": "vec<string>",
                    "helper_text": "List of sources",
                },
                {
                    "field": "time_entry_created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "time_entry_details",
                    "type": "string",
                    "helper_text": "Time entries details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_time_entries",
            "task_name": "tasks.clickup.get_time_entries",
            "description": "Get multiple time entries",
            "label": "List Time Entries",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "assignee",
                "include_location_names",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
            ],
            "required": ["team_id", "num_messages"],
        },
        "get_time_entries**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Time Entries",
                    "helper_text": "Specify the number of time entries to fetch",
                }
            ],
            "outputs": [],
        },
        "get_time_entries**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_time_entries**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_time_entries**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "start_time_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list",
                    "label": "List",
                    "placeholder": "Select list",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "time_entry_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the time entry",
                    "label": "Description",
                    "placeholder": "Working on feature implementation",
                },
                {
                    "field": "time_entry_billable",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Mark time entry as billable",
                    "label": "Billable",
                },
            ],
            "outputs": [
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "helper_text": "ID of the started time entry",
                },
                {
                    "field": "time_entry_details",
                    "type": "string",
                    "helper_text": "Time entry details in JSON format",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "start_time_entry",
            "task_name": "tasks.clickup.start_time_entry",
            "description": "Start a new time entry in ClickUp",
            "label": "Start Time Entry",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "time_entry_description",
                "time_entry_billable",
            ],
            "required": ["team_id", "space_id", "folder_id", "list_id", "task_id"],
        },
        "stop_time_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "helper_text": "ID of the stopped time entry",
                },
                {
                    "field": "time_entry_details",
                    "type": "string",
                    "helper_text": "Time entry details in JSON format",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "stop_time_entry",
            "task_name": "tasks.clickup.stop_time_entry",
            "description": "Stop the currently running time entry in ClickUp",
            "label": "Stop Time Entry",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "team_id"],
            "required": ["team_id"],
        },
        "update_time_entry**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the time entry to update",
                    "label": "Time Entry ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "update_time_entry_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the time entry",
                    "label": "Description",
                    "placeholder": "Updated description",
                },
                {
                    "field": "update_time_entry_billable",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Mark time entry as billable",
                    "label": "Billable",
                },
                {
                    "field": "update_time_entry_start",
                    "type": "string",
                    "value": "",
                    "helper_text": "New start time (RFC3339 format)",
                    "label": "Start Time",
                    "placeholder": "2024-01-01T09:00:00Z",
                },
                {
                    "field": "update_time_entry_duration_minutes",
                    "type": "int32",
                    "value": 60,
                    "helper_text": "New duration in minutes",
                    "label": "Duration (minutes)",
                    "placeholder": "60",
                },
                {
                    "field": "update_time_entry_task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "New task ID for the time entry",
                    "label": "Task ID",
                    "placeholder": "task123",
                },
            ],
            "outputs": [
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "helper_text": "ID of the updated time entry",
                },
                {
                    "field": "time_entry_details",
                    "type": "string",
                    "helper_text": "Time entry details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_time_entry",
            "task_name": "tasks.clickup.update_time_entry",
            "description": "Update an existing time entry in ClickUp",
            "label": "Update Time Entry",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "time_entry_id",
                "update_time_entry_description",
                "update_time_entry_billable",
                "update_time_entry_start",
                "update_time_entry_duration_minutes",
                "update_time_entry_task_id",
            ],
            "required": ["team_id", "time_entry_id"],
        },
        "create_space_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the tag",
                    "label": "Tag Name",
                    "placeholder": "urgent",
                },
                {
                    "field": "tag_foreground_color",
                    "type": "string",
                    "value": "#000000",
                    "helper_text": "Foreground color for the tag",
                    "label": "Foreground Color",
                    "placeholder": "#000000",
                },
                {
                    "field": "tag_background_color",
                    "type": "string",
                    "value": "#ffffff",
                    "helper_text": "Background color for the tag",
                    "label": "Background Color",
                    "placeholder": "#ffffff",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Name of the created tag",
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the space",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_space_tag",
            "task_name": "tasks.clickup.create_space_tag",
            "description": "Create a new tag in a ClickUp space",
            "label": "Create Space Tag",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "tag_name",
                "tag_foreground_color",
                "tag_background_color",
            ],
            "required": ["space_id", "tag_name"],
        },
        "delete_space_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the tag to delete",
                    "label": "Tag Name",
                    "placeholder": "Select tag",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=tag_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Name of the deleted tag",
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the space",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_space_tag",
            "task_name": "tasks.clickup.delete_space_tag",
            "description": "Delete an existing tag from a ClickUp space",
            "label": "Delete Space Tag",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "tag_name",
            ],
            "required": ["space_id", "tag_name"],
        },
        "get_space_tags**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of tags to fetch",
                    "label": "Max Results",
                    "placeholder": "10",
                },
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "tag_foregrounds",
                    "type": "vec<string>",
                    "helper_text": "List of tag foreground colors",
                },
                {
                    "field": "tag_backgrounds",
                    "type": "vec<string>",
                    "helper_text": "List of tag background colors",
                },
                {
                    "field": "tag_creators",
                    "type": "vec<int32>",
                    "helper_text": "List of tag creator IDs",
                },
                {
                    "field": "tag_details",
                    "type": "string",
                    "helper_text": "Tags details in JSON format",
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the space",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_space_tags",
            "task_name": "tasks.clickup.get_space_tags",
            "description": "Get multiple tags",
            "label": "List Space Tags",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "limit",
            ],
            "required": ["space_id", "limit"],
        },
        "update_space_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the tag to update",
                    "label": "Tag to Update",
                    "placeholder": "Select tag",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=tag_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "new_tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the tag",
                    "label": "New Tag Name",
                    "placeholder": "high-priority",
                },
                {
                    "field": "tag_foreground_color",
                    "type": "string",
                    "value": "#000000",
                    "helper_text": "New foreground color for the tag",
                    "label": "Foreground Color",
                    "placeholder": "#000000",
                },
                {
                    "field": "tag_background_color",
                    "type": "string",
                    "value": "#ffffff",
                    "helper_text": "New background color for the tag",
                    "label": "Background Color",
                    "placeholder": "#ffffff",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "old_tag_name",
                    "type": "string",
                    "helper_text": "Previous name of the tag",
                },
                {
                    "field": "new_tag_name",
                    "type": "string",
                    "helper_text": "New name of the tag",
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the space",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "update_space_tag",
            "task_name": "tasks.clickup.update_space_tag",
            "description": "Update an existing tag in a ClickUp space",
            "label": "Update Space Tag",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "tag_name",
                "new_tag_name",
                "tag_foreground_color",
                "tag_background_color",
            ],
            "required": ["space_id", "tag_name"],
        },
        "add_task_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the tag to add",
                    "label": "Tag Name",
                    "placeholder": "urgent",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Name of the added tag",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "add_task_tag",
            "task_name": "tasks.clickup.add_task_tag",
            "description": "Add a tag to a ClickUp task",
            "label": "Add Task Tag",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "tag_name",
            ],
            "required": ["task_id", "tag_name"],
        },
        "remove_task_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the tag to remove",
                    "label": "Tag Name",
                    "placeholder": "urgent",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Name of the removed tag",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "remove_task_tag",
            "task_name": "tasks.clickup.remove_task_tag",
            "description": "Remove a tag from a ClickUp task",
            "label": "Remove Task Tag",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "tag_name",
            ],
            "required": ["task_id", "tag_name"],
        },
        "create_task_dependency**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task that depends on another",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "depends_on_task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task that this task depends on",
                    "label": "Depends On Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the dependent task",
                },
                {
                    "field": "depends_on_task_id",
                    "type": "string",
                    "helper_text": "ID of the task this depends on",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "create_task_dependency",
            "task_name": "tasks.clickup.create_task_dependency",
            "description": "Create a dependency between two ClickUp tasks",
            "label": "Create Task Dependency",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "depends_on_task_id",
            ],
            "required": ["task_id", "depends_on_task_id"],
        },
        "delete_task_dependency**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list",
                    "label": "List",
                    "placeholder": "Select list",
                    "show_on_node": True,
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task that depends on another",
                    "label": "Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "depends_on_task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task that this task depends on",
                    "label": "Depends On Task",
                    "placeholder": "Select task",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task_name&list={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the dependent task",
                },
                {
                    "field": "depends_on_task_id",
                    "type": "string",
                    "helper_text": "ID of the task this depends on",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "delete_task_dependency",
            "task_name": "tasks.clickup.delete_task_dependency",
            "description": "Delete a dependency between two ClickUp tasks",
            "label": "Delete Task Dependency",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
                "task_id",
                "depends_on_task_id",
            ],
            "required": ["task_id", "depends_on_task_id"],
        },
        "add_task_to_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to add",
                    "label": "Task ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to add the task to",
                    "label": "List ID",
                    "placeholder": "123456789",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {"field": "list_id", "type": "string", "helper_text": "ID of the list"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "add_task_to_list",
            "task_name": "tasks.clickup.add_task_to_list",
            "description": "Add a task to an additional ClickUp list",
            "label": "Add Task to List",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "task_id", "list_id"],
            "required": ["task_id", "list_id"],
        },
        "remove_task_from_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to remove",
                    "label": "Task ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to remove the task from",
                    "label": "List ID",
                    "placeholder": "123456789",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {"field": "list_id", "type": "string", "helper_text": "ID of the list"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "remove_task_from_list",
            "task_name": "tasks.clickup.remove_task_from_list",
            "description": "Remove a task from a ClickUp list",
            "label": "Remove Task from List",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "task_id", "list_id"],
            "required": ["task_id", "list_id"],
        },
        "get_custom_fields**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the folder",
                    "label": "Folder",
                    "placeholder": "Select folder",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=folder_name&space={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the list to get custom fields from",
                    "label": "List",
                    "placeholder": "Select list",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_name&folder={inputs.folder_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "custom_field_ids",
                    "type": "vec<string>",
                    "helper_text": "List of custom field IDs",
                },
                {
                    "field": "custom_field_names",
                    "type": "vec<string>",
                    "helper_text": "List of custom field names",
                },
                {
                    "field": "custom_field_types",
                    "type": "vec<string>",
                    "helper_text": "List of custom field types",
                },
                {
                    "field": "custom_fields_details",
                    "type": "string",
                    "helper_text": "Custom fields details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_custom_fields",
            "task_name": "tasks.clickup.get_custom_fields",
            "description": "Get multiple custom fields",
            "label": "List Custom Fields",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "space_id",
                "folder_id",
                "list_id",
            ],
            "required": ["list_id"],
        },
        "set_custom_field**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task",
                    "label": "Task ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "custom_field_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the custom field",
                    "label": "Custom Field ID",
                    "placeholder": "field123",
                },
                {
                    "field": "custom_field_value",
                    "type": "string",
                    "value": "",
                    "helper_text": "The value to set for the custom field",
                    "label": "Custom Field Value",
                    "placeholder": "New value",
                },
                {
                    "field": "custom_task_ids",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Use custom task IDs",
                    "label": "Custom Task IDs",
                },
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team (required if using custom task IDs)",
                    "label": "Team ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {
                    "field": "custom_field_id",
                    "type": "string",
                    "helper_text": "ID of the custom field",
                },
                {
                    "field": "custom_field_value",
                    "type": "string",
                    "helper_text": "New value of the custom field",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "set_custom_field",
            "task_name": "tasks.clickup.set_custom_field",
            "description": "Set a custom field value on a ClickUp task",
            "label": "Set Custom Field",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "task_id",
                "custom_field_id",
                "custom_field_value",
                "custom_task_ids",
                "team_id",
            ],
            "required": ["task_id", "custom_field_id", "custom_field_value"],
        },
        "get_task_members**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the task to get members from",
                    "label": "Task ID",
                    "placeholder": "abc123def456",
                },
                {
                    "field": "custom_task_ids",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Use custom task IDs",
                    "label": "Custom Task IDs",
                },
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team (required if using custom task IDs)",
                    "label": "Team ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "List of member user IDs",
                },
                {
                    "field": "member_names",
                    "type": "vec<string>",
                    "helper_text": "List of member usernames",
                },
                {
                    "field": "member_roles",
                    "type": "vec<string>",
                    "helper_text": "List of member roles",
                },
                {
                    "field": "members_details",
                    "type": "string",
                    "helper_text": "Members details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_task_members",
            "task_name": "tasks.clickup.get_task_members",
            "description": "Get multiple members associated with a task",
            "label": "List Task Members",
            "variant": "default_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "task_id",
                "custom_task_ids",
                "team_id",
            ],
            "required": ["task_id"],
        },
        "add_time_entry_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "One or more time entry IDs (comma-separated for multiple)",
                    "label": "Time Entry ID",
                    "placeholder": "abc123def456, xyz789ghi012",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Enter comma separated tag names",
                    "label": "Tag Name",
                    "placeholder": "new_tag1, new_tag2",
                },
                {
                    "field": "background_color",
                    "type": "string",
                    "value": "#ff0000",
                    "helper_text": "Background color for the tag(s) in hex format (applies to all tags if multiple)",
                    "label": "Background Color",
                    "placeholder": "#ff0000",
                },
                {
                    "field": "foreground_color",
                    "type": "string",
                    "value": "#ffffff",
                    "helper_text": "Foreground (text) color for the tag(s) in hex format (applies to all tags if multiple)",
                    "label": "Foreground Color",
                    "placeholder": "#ffffff",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "time_entry_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of time entry IDs that were tagged",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Name of the added tag",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "add_time_entry_tag",
            "task_name": "tasks.clickup.add_time_entry_tag",
            "description": "Add a tag to one or more ClickUp time entries",
            "label": "Add Time Entry Tag",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "time_entry_id",
                "tag_name",
                "background_color",
                "foreground_color",
            ],
            "required": ["team_id", "time_entry_id", "tag_name"],
        },
        "get_time_entry_tags**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of time entry tag names",
                },
                {
                    "field": "tag_details",
                    "type": "vec<string>",
                    "helper_text": "Time entry tags details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_time_entry_tags",
            "task_name": "tasks.clickup.get_time_entry_tags",
            "description": "Get multiple time entry tags",
            "label": "List Time Entry Tags",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "team_id"],
            "required": ["team_id"],
        },
        "remove_time_entry_tag**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the team",
                    "label": "Team",
                    "placeholder": "Select team",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "time_entry_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "One or more time entry IDs (comma-separated for multiple)",
                    "label": "Time Entry ID",
                    "placeholder": "abc123def456, xyz789ghi012",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the tag(s) to remove (comma-separated for multiple)",
                    "label": "Tag Name",
                    "placeholder": "Select or type tag name(s)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=time_entry_tag_name&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "time_entry_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of time entry IDs that were tagged",
                },
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of removed tag names",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "remove_time_entry_tag",
            "task_name": "tasks.clickup.remove_time_entry_tag",
            "description": "Remove a tag from one or more ClickUp time entries",
            "label": "Remove Time Entry Tag",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "time_entry_id",
                "tag_name",
            ],
            "required": ["team_id", "time_entry_id", "tag_name"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "num_messages"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        archived: bool = False,
        assign_user: str = "",
        assignee: str = "",
        assignees: str = "",
        background_color: str = "#ff0000",
        checklist_id: str = "",
        checklist_item_assignee: str = "",
        checklist_item_id: str = "",
        checklist_item_name: str = "",
        checklist_name: str = "",
        comment_id: str = "",
        comment_on: str = "Task",
        comment_text: str = "",
        custom_field_id: str = "",
        custom_field_value: str = "",
        custom_fields: str = "",
        custom_task_ids: bool = False,
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        date_updated_gt: Any = None,
        date_updated_lt: Any = None,
        depends_on_task_id: str = "",
        due_date_gt: Any = None,
        due_date_lt: Any = None,
        duration_minutes: int = 60,
        enable_custom_fields: bool = True,
        enable_dependency_warnings: bool = True,
        enable_incomplete_warnings: bool = True,
        enable_priority: bool = True,
        enable_tags: bool = True,
        enable_time_tracking: bool = True,
        exact_date: TimeRange = {"start": "", "end": ""},
        folder_id: str = "",
        folder_name: str = "",
        folderless: bool = False,
        foreground_color: str = "#ffffff",
        get_running: bool = False,
        goal_color: str = "",
        goal_description: str = "",
        goal_due_date: str = "",
        goal_id: str = "",
        goal_multiple_owners: bool = False,
        goal_name: str = "",
        goal_owners: str = "",
        include_closed: bool = False,
        include_completed: bool = False,
        include_location_names: bool = False,
        include_markdown_description: bool = False,
        key_result_id: str = "",
        key_result_list_ids: str = "",
        key_result_name: str = "",
        key_result_owners: str = "",
        key_result_steps_end: int = 10,
        key_result_steps_start: int = 0,
        key_result_task_ids: str = "",
        key_result_type: str = "",
        key_result_unit: str = "",
        limit: int = 10,
        list_content: str = "",
        list_id: str = "",
        list_name: str = "",
        markdown_content: str = "",
        new_tag_name: str = "",
        notify_all: bool = False,
        num_messages: int = 10,
        order_by: str = "",
        parent_id: str = "",
        remove_all_assignees: bool = False,
        reverse: bool = False,
        space_id: str = "",
        space_multiple_assignees: bool = True,
        space_name: str = "",
        start_time: str = "",
        statuses: str = "",
        subtasks: bool = False,
        tag_background_color: str = "#ffffff",
        tag_foreground_color: str = "#000000",
        tag_name: str = "",
        tags: str = "",
        task_assignees: str = "",
        task_description: str = "",
        task_due_date: Any = None,
        task_id: str = "",
        task_name: str = "",
        task_priority: str = "",
        task_start_date: Any = None,
        task_status: str = "",
        task_tags: str = "",
        team_id: str = "",
        time_entry_assignee: str = "",
        time_entry_billable: bool = False,
        time_entry_description: str = "",
        time_entry_id: str = "",
        time_entry_tags: str = "",
        time_estimate: int = None,
        update_checklist_item_assignee: str = "",
        update_checklist_item_name: str = "",
        update_checklist_item_parent: str = "",
        update_checklist_item_resolved: bool = False,
        update_checklist_name: str = "",
        update_checklist_position: int = 0,
        update_comment_assignee: str = "",
        update_comment_resolved: bool = False,
        update_comment_text: str = "",
        update_folder_name: str = "",
        update_goal_add_owners: str = "",
        update_goal_color: str = "",
        update_goal_description: str = "",
        update_goal_due_date: str = "",
        update_goal_name: str = "",
        update_goal_remove_owners: str = "",
        update_key_result_name: str = "",
        update_key_result_note: str = "",
        update_key_result_steps_current: int = 0,
        update_key_result_steps_end: int = 10,
        update_key_result_steps_start: int = 0,
        update_key_result_unit: str = "",
        update_list_content: str = "",
        update_list_name: str = "",
        update_markdown_content: str = "",
        update_parent_id: str = "",
        update_task_assignees: str = "",
        update_task_description: str = "",
        update_task_due_date: Any = None,
        update_task_name: str = "",
        update_task_priority: str = "",
        update_task_start_date: Any = None,
        update_task_status: str = "",
        update_task_tags: str = "",
        update_time_entry_billable: bool = False,
        update_time_entry_description: str = "",
        update_time_entry_duration_minutes: int = 60,
        update_time_entry_start: str = "",
        update_time_entry_task_id: str = "",
        update_time_estimate: int = None,
        view_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_clickup",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if team_id is not None:
            self.inputs["team_id"] = team_id
        if space_id is not None:
            self.inputs["space_id"] = space_id
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if list_id is not None:
            self.inputs["list_id"] = list_id
        if task_status is not None:
            self.inputs["task_status"] = task_status
        if task_assignees is not None:
            self.inputs["task_assignees"] = task_assignees
        if task_priority is not None:
            self.inputs["task_priority"] = task_priority
        if task_name is not None:
            self.inputs["task_name"] = task_name
        if task_description is not None:
            self.inputs["task_description"] = task_description
        if task_tags is not None:
            self.inputs["task_tags"] = task_tags
        if task_due_date is not None:
            self.inputs["task_due_date"] = task_due_date
        if task_start_date is not None:
            self.inputs["task_start_date"] = task_start_date
        if parent_id is not None:
            self.inputs["parent_id"] = parent_id
        if time_estimate is not None:
            self.inputs["time_estimate"] = time_estimate
        if notify_all is not None:
            self.inputs["notify_all"] = notify_all
        if markdown_content is not None:
            self.inputs["markdown_content"] = markdown_content
        if task_id is not None:
            self.inputs["task_id"] = task_id
        if update_task_status is not None:
            self.inputs["update_task_status"] = update_task_status
        if update_task_assignees is not None:
            self.inputs["update_task_assignees"] = update_task_assignees
        if remove_all_assignees is not None:
            self.inputs["remove_all_assignees"] = remove_all_assignees
        if update_task_priority is not None:
            self.inputs["update_task_priority"] = update_task_priority
        if update_task_name is not None:
            self.inputs["update_task_name"] = update_task_name
        if update_task_description is not None:
            self.inputs["update_task_description"] = update_task_description
        if update_task_due_date is not None:
            self.inputs["update_task_due_date"] = update_task_due_date
        if update_task_start_date is not None:
            self.inputs["update_task_start_date"] = update_task_start_date
        if update_task_tags is not None:
            self.inputs["update_task_tags"] = update_task_tags
        if update_parent_id is not None:
            self.inputs["update_parent_id"] = update_parent_id
        if update_time_estimate is not None:
            self.inputs["update_time_estimate"] = update_time_estimate
        if update_markdown_content is not None:
            self.inputs["update_markdown_content"] = update_markdown_content
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if archived is not None:
            self.inputs["archived"] = archived
        if include_markdown_description is not None:
            self.inputs["include_markdown_description"] = include_markdown_description
        if include_closed is not None:
            self.inputs["include_closed"] = include_closed
        if subtasks is not None:
            self.inputs["subtasks"] = subtasks
        if reverse is not None:
            self.inputs["reverse"] = reverse
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if statuses is not None:
            self.inputs["statuses"] = statuses
        if assignees is not None:
            self.inputs["assignees"] = assignees
        if tags is not None:
            self.inputs["tags"] = tags
        if due_date_gt is not None:
            self.inputs["due_date_gt"] = due_date_gt
        if due_date_lt is not None:
            self.inputs["due_date_lt"] = due_date_lt
        if date_updated_gt is not None:
            self.inputs["date_updated_gt"] = date_updated_gt
        if date_updated_lt is not None:
            self.inputs["date_updated_lt"] = date_updated_lt
        if custom_fields is not None:
            self.inputs["custom_fields"] = custom_fields
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if comment_on is not None:
            self.inputs["comment_on"] = comment_on
        if view_id is not None:
            self.inputs["view_id"] = view_id
        if assign_user is not None:
            self.inputs["assign_user"] = assign_user
        if comment_text is not None:
            self.inputs["comment_text"] = comment_text
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if update_comment_text is not None:
            self.inputs["update_comment_text"] = update_comment_text
        if update_comment_assignee is not None:
            self.inputs["update_comment_assignee"] = update_comment_assignee
        if update_comment_resolved is not None:
            self.inputs["update_comment_resolved"] = update_comment_resolved
        if folderless is not None:
            self.inputs["folderless"] = folderless
        if list_name is not None:
            self.inputs["list_name"] = list_name
        if list_content is not None:
            self.inputs["list_content"] = list_content
        if update_list_name is not None:
            self.inputs["update_list_name"] = update_list_name
        if update_list_content is not None:
            self.inputs["update_list_content"] = update_list_content
        if folder_name is not None:
            self.inputs["folder_name"] = folder_name
        if update_folder_name is not None:
            self.inputs["update_folder_name"] = update_folder_name
        if limit is not None:
            self.inputs["limit"] = limit
        if space_name is not None:
            self.inputs["space_name"] = space_name
        if space_multiple_assignees is not None:
            self.inputs["space_multiple_assignees"] = space_multiple_assignees
        if enable_time_tracking is not None:
            self.inputs["enable_time_tracking"] = enable_time_tracking
        if enable_priority is not None:
            self.inputs["enable_priority"] = enable_priority
        if enable_tags is not None:
            self.inputs["enable_tags"] = enable_tags
        if enable_custom_fields is not None:
            self.inputs["enable_custom_fields"] = enable_custom_fields
        if enable_incomplete_warnings is not None:
            self.inputs["enable_incomplete_warnings"] = enable_incomplete_warnings
        if enable_dependency_warnings is not None:
            self.inputs["enable_dependency_warnings"] = enable_dependency_warnings
        if checklist_name is not None:
            self.inputs["checklist_name"] = checklist_name
        if checklist_id is not None:
            self.inputs["checklist_id"] = checklist_id
        if update_checklist_name is not None:
            self.inputs["update_checklist_name"] = update_checklist_name
        if update_checklist_position is not None:
            self.inputs["update_checklist_position"] = update_checklist_position
        if checklist_item_name is not None:
            self.inputs["checklist_item_name"] = checklist_item_name
        if checklist_item_assignee is not None:
            self.inputs["checklist_item_assignee"] = checklist_item_assignee
        if checklist_item_id is not None:
            self.inputs["checklist_item_id"] = checklist_item_id
        if update_checklist_item_name is not None:
            self.inputs["update_checklist_item_name"] = update_checklist_item_name
        if update_checklist_item_parent is not None:
            self.inputs["update_checklist_item_parent"] = update_checklist_item_parent
        if update_checklist_item_assignee is not None:
            self.inputs["update_checklist_item_assignee"] = (
                update_checklist_item_assignee
            )
        if update_checklist_item_resolved is not None:
            self.inputs["update_checklist_item_resolved"] = (
                update_checklist_item_resolved
            )
        if goal_name is not None:
            self.inputs["goal_name"] = goal_name
        if goal_description is not None:
            self.inputs["goal_description"] = goal_description
        if goal_due_date is not None:
            self.inputs["goal_due_date"] = goal_due_date
        if goal_color is not None:
            self.inputs["goal_color"] = goal_color
        if goal_multiple_owners is not None:
            self.inputs["goal_multiple_owners"] = goal_multiple_owners
        if goal_owners is not None:
            self.inputs["goal_owners"] = goal_owners
        if goal_id is not None:
            self.inputs["goal_id"] = goal_id
        if include_completed is not None:
            self.inputs["include_completed"] = include_completed
        if update_goal_name is not None:
            self.inputs["update_goal_name"] = update_goal_name
        if update_goal_description is not None:
            self.inputs["update_goal_description"] = update_goal_description
        if update_goal_due_date is not None:
            self.inputs["update_goal_due_date"] = update_goal_due_date
        if update_goal_color is not None:
            self.inputs["update_goal_color"] = update_goal_color
        if update_goal_add_owners is not None:
            self.inputs["update_goal_add_owners"] = update_goal_add_owners
        if update_goal_remove_owners is not None:
            self.inputs["update_goal_remove_owners"] = update_goal_remove_owners
        if key_result_name is not None:
            self.inputs["key_result_name"] = key_result_name
        if key_result_type is not None:
            self.inputs["key_result_type"] = key_result_type
        if key_result_unit is not None:
            self.inputs["key_result_unit"] = key_result_unit
        if key_result_steps_start is not None:
            self.inputs["key_result_steps_start"] = key_result_steps_start
        if key_result_steps_end is not None:
            self.inputs["key_result_steps_end"] = key_result_steps_end
        if key_result_task_ids is not None:
            self.inputs["key_result_task_ids"] = key_result_task_ids
        if key_result_list_ids is not None:
            self.inputs["key_result_list_ids"] = key_result_list_ids
        if key_result_owners is not None:
            self.inputs["key_result_owners"] = key_result_owners
        if key_result_id is not None:
            self.inputs["key_result_id"] = key_result_id
        if update_key_result_name is not None:
            self.inputs["update_key_result_name"] = update_key_result_name
        if update_key_result_note is not None:
            self.inputs["update_key_result_note"] = update_key_result_note
        if update_key_result_steps_current is not None:
            self.inputs["update_key_result_steps_current"] = (
                update_key_result_steps_current
            )
        if update_key_result_steps_start is not None:
            self.inputs["update_key_result_steps_start"] = update_key_result_steps_start
        if update_key_result_steps_end is not None:
            self.inputs["update_key_result_steps_end"] = update_key_result_steps_end
        if update_key_result_unit is not None:
            self.inputs["update_key_result_unit"] = update_key_result_unit
        if start_time is not None:
            self.inputs["start_time"] = start_time
        if duration_minutes is not None:
            self.inputs["duration_minutes"] = duration_minutes
        if time_entry_description is not None:
            self.inputs["time_entry_description"] = time_entry_description
        if time_entry_billable is not None:
            self.inputs["time_entry_billable"] = time_entry_billable
        if time_entry_assignee is not None:
            self.inputs["time_entry_assignee"] = time_entry_assignee
        if time_entry_tags is not None:
            self.inputs["time_entry_tags"] = time_entry_tags
        if time_entry_id is not None:
            self.inputs["time_entry_id"] = time_entry_id
        if get_running is not None:
            self.inputs["get_running"] = get_running
        if assignee is not None:
            self.inputs["assignee"] = assignee
        if include_location_names is not None:
            self.inputs["include_location_names"] = include_location_names
        if update_time_entry_description is not None:
            self.inputs["update_time_entry_description"] = update_time_entry_description
        if update_time_entry_billable is not None:
            self.inputs["update_time_entry_billable"] = update_time_entry_billable
        if update_time_entry_start is not None:
            self.inputs["update_time_entry_start"] = update_time_entry_start
        if update_time_entry_duration_minutes is not None:
            self.inputs["update_time_entry_duration_minutes"] = (
                update_time_entry_duration_minutes
            )
        if update_time_entry_task_id is not None:
            self.inputs["update_time_entry_task_id"] = update_time_entry_task_id
        if tag_name is not None:
            self.inputs["tag_name"] = tag_name
        if tag_foreground_color is not None:
            self.inputs["tag_foreground_color"] = tag_foreground_color
        if tag_background_color is not None:
            self.inputs["tag_background_color"] = tag_background_color
        if new_tag_name is not None:
            self.inputs["new_tag_name"] = new_tag_name
        if depends_on_task_id is not None:
            self.inputs["depends_on_task_id"] = depends_on_task_id
        if custom_field_id is not None:
            self.inputs["custom_field_id"] = custom_field_id
        if custom_field_value is not None:
            self.inputs["custom_field_value"] = custom_field_value
        if custom_task_ids is not None:
            self.inputs["custom_task_ids"] = custom_task_ids
        if background_color is not None:
            self.inputs["background_color"] = background_color
        if foreground_color is not None:
            self.inputs["foreground_color"] = foreground_color
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationClickupNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
