"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("file")
class FileNode(Node):
    """
    Load a static file into the workflow as a raw File or process it into Text.

    ## Inputs
    ### Common Inputs
        file_parser: The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.
        selected_option: Select an existing file from the VectorShift platform
    ### upload
        file: The file that was passed in
    ### name
        file_name: The name of the file from the VectorShift platform (for files on the File tab)

    ## Outputs
    ### Common Outputs
        file: The file that was passed in
        file_name: The name of the file
        processed_text: The processed text of the file
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "file_parser",
            "helper_text": "The processing model with which the document will be processed. Default processing model includes standard document parsing / OCR. Llamaparse will allow for ability to read documents with complex features (e.g., tables, charts, etc.). Llamaparse will be charged at 0.3 cents per page. Textract for most advanced data extraction and will be charged at 1.5 cents per page.",
            "value": "default",
            "type": "string",
        },
        {
            "field": "selected_option",
            "helper_text": "Select an existing file from the VectorShift platform",
            "value": "upload",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "file", "helper_text": "The file that was passed in", "type": "file"},
        {"field": "file_name", "helper_text": "The name of the file", "type": "string"},
        {
            "field": "processed_text",
            "helper_text": "The processed text of the file",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "upload": {
            "inputs": [
                {
                    "field": "file",
                    "type": "file",
                    "label": "File",
                    "helper_text": "The file that was passed in",
                }
            ],
            "outputs": [],
        },
        "name": {
            "inputs": [
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "label": "File Name",
                    "helper_text": "The name of the file from the VectorShift platform (for files on the File tab)",
                    "placeholder": 'Type "{{" to utilize variables',
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["selected_option"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["file", "file_name"]

    def __init__(
        self,
        selected_option: str = "upload",
        file: Optional[str] = None,
        file_name: str = "",
        file_parser: str = "default",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["selected_option"] = selected_option

        super().__init__(
            node_type="file",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file_parser is not None:
            self.inputs["file_parser"] = file_parser
        if selected_option is not None:
            self.inputs["selected_option"] = selected_option
        if file is not None:
            self.inputs["file"] = file
        if file_name is not None:
            self.inputs["file_name"] = file_name
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "FileNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
