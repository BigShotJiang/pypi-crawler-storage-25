"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("text_to_file")
class TextToFileNode(Node):
    """
    Convert data from type Text to type File.

    ## Inputs
    ### Common Inputs
        text: The text for conversion.
        file_name: The name for the generated file (without extension).
        file_type: The type of file to convert the text to.

    ## Outputs
    ### Common Outputs
        file: The text as converted to a file.
        file_name: The name of the generated file.
        file_type: The type of file that was converted the text to.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "text",
            "helper_text": "The text for conversion.",
            "value": "",
            "type": "string",
        },
        {
            "field": "file_name",
            "helper_text": "The name for the generated file (without extension).",
            "value": "converted_file",
            "type": "string",
        },
        {
            "field": "file_type",
            "helper_text": "The type of file to convert the text to.",
            "value": "PDF",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "file",
            "helper_text": "The text as converted to a file.",
            "type": "file",
        },
        {
            "field": "file_name",
            "helper_text": "The name of the generated file.",
            "type": "string",
        },
        {
            "field": "file_type",
            "helper_text": "The type of file that was converted the text to.",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text", "file_name"]

    def __init__(
        self,
        text: str = "",
        file_name: str = "converted_file",
        file_type: str = "PDF",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="text_to_file",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file_type is not None:
            self.inputs["file_type"] = file_type
        if text is not None:
            self.inputs["text"] = text
        if file_name is not None:
            self.inputs["file_name"] = file_name
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TextToFileNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
