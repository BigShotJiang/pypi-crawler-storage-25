"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_algolia")
class IntegrationAlgoliaNode(Node):
    """
    Algolia

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### search_index
        query: Keyword to be searched in the index
        index: An index where the data used by Algolia is stored
        return_mode: Choose between returning as chunks or JSON

    ## Outputs
    ### Common Outputs
        output: Search results from the Algolia index in the specified format
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Algolia>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "Search results from the Algolia index in the specified format",
            "type": "any",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "search_index": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "“iPhone 16”",
                    "helper_text": "Keyword to be searched in the index",
                },
                {
                    "field": "index",
                    "type": "string",
                    "value": "",
                    "label": "Index",
                    "placeholder": "database",
                    "helper_text": "An index where the data used by Algolia is stored",
                },
                {
                    "field": "return_mode",
                    "type": "string",
                    "value": "json",
                    "label": "Return Mode",
                    "agent_field_type": "dynamic",
                    "placeholder": "Choose between returning as chunks or JSON",
                    "helper_text": "Choose between returning as chunks or JSON",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "JSON", "value": "json"},
                            {"label": "Chunks", "value": "chunks"},
                        ],
                    },
                },
            ],
            "outputs": [],
            "name": "search_index",
            "task_name": "tasks.algolia.search_index",
            "description": "Query your Algolia index",
            "label": "Search Algolia index",
            "variant": "common_integration_nodes",
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        index: str = "",
        return_mode: str = "json",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_algolia",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if query is not None:
            self.inputs["query"] = query
        if index is not None:
            self.inputs["index"] = index
        if return_mode is not None:
            self.inputs["return_mode"] = return_mode
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationAlgoliaNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
