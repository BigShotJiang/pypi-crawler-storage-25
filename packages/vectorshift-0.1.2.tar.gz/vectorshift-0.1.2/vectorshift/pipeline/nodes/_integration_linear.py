"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_linear")
class IntegrationLinearNode(Node):
    """
    Linear

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'create_new_issue'
        assignee_id: Assign the issue to a user
        description: The description of the ticket
        priority: Issue priority
        state_id: Set the workflow state
        team_id: The team within Linear
        title: The title of the issue
    ### When action = 'update_issue'
        assignee_id: Assign the issue to a user
        description: The description of the ticket
        issue_id: The ID of the issue to update
        priority: Issue priority
        state_id: Set the workflow state
        team_id: The team within Linear
        title: The title of the issue
        update_team_id: Move to a different team
    ### When action = 'list_issues'
        assignee_id: Assign the issue to a user
        priority: Issue priority
        return_all: Return all matching issues regardless of count
        state_id: Set the workflow state
        team_id: The team within Linear
        use_date: Toggle to use dates
    ### When action = 'create_comment'
        comment: The comment text
        issue_id: The ID of the issue to update
        parent_id: ID of parent comment for replies (optional)
        team_id: The team within Linear
    ### When action = 'list_issues' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'list_issues' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'delete_issue'
        issue_id: The ID of the issue to update
        team_id: The team within Linear
    ### When action = 'get_issue'
        issue_id: The ID of the issue to update
        team_id: The team within Linear
    ### When action = 'add_link'
        issue_id: The ID of the issue to update
        link: The URL to attach to the issue
        team_id: The team within Linear
    ### When action = 'list_issues' and use_date = False
        num_messages: Specify the number of issues to fetch
    ### When action = 'list_issues' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'create_new_issue'
        assignee_email: Email of the assigned user
        assignee_name: Name of the assigned user
        created_at: When the issue was created
        description: Description of the created issue
        issue_id: Unique identifier of the created issue
        issue_identifier: Human-readable identifier (e.g., ABC-123)
        priority: Priority level of the issue
        raw_data: Raw API response data
        state: Current workflow state of the issue
        team_key: Key/abbreviation of the team
        team_name: Name of the team the issue belongs to
        title: Title of the created issue
    ### When action = 'update_issue'
        assignee_email: Email of the assigned user
        assignee_name: Name of the assigned user
        description: Updated description of the issue
        issue_id: Unique identifier of the updated issue
        issue_identifier: Human-readable identifier (e.g., ABC-123)
        priority: Updated priority level of the issue
        raw_data: Raw API response data
        state: Current workflow state of the issue
        team_key: Key/abbreviation of the team
        team_name: Name of the team the issue belongs to
        title: Updated title of the issue
        updated_at: When the issue was last updated
    ### When action = 'get_issue'
        assignee_email: Email of the assigned user
        assignee_id: ID of the assigned user
        assignee_name: Name of the assigned user
        comment_count: Number of comments on the issue
        comments: Comments on the issue
        created_at: When the issue was created
        creator_email: Email of the user who created the issue
        creator_id: ID of the user who created the issue
        creator_name: Name of the user who created the issue
        description: Description of the issue
        due_date: Due date of the issue
        issue_id: Unique identifier of the issue
        issue_identifier: Human-readable identifier (e.g., ABC-123)
        priority: Priority level of the issue
        project_id: ID of the project the issue belongs to
        project_name: Name of the project the issue belongs to
        raw_data: Raw API response data
        state: Current workflow state of the issue
        state_type: Type of the workflow state
        team_id: ID of the team the issue belongs to
        team_key: Key/abbreviation of the team
        team_name: Name of the team the issue belongs to
        title: Title of the issue
        updated_at: When the issue was last updated
    ### When action = 'list_issues'
        assignee_emails: List of assigned user emails
        assignee_ids: List of assigned user IDs
        assignee_names: List of assigned user names
        created_at: List of creation timestamps for all issues
        creator_emails: List of issue creator emails
        creator_ids: List of issue creator IDs
        creator_names: List of issue creator names
        descriptions: List of issue descriptions
        due_dates: List of due dates for all issues
        issue_count: Total number of issues returned
        issue_identifiers: List of human-readable identifiers (e.g., ABC-123)
        issue_identifiers_str: List of issue identifiers as strings
        issue_ids: List of unique identifiers for all issues
        issue_titles: List of issue titles (duplicate of titles)
        priorities: List of priority levels for all issues
        project_ids: List of project IDs for all issues
        project_names: List of project names for all issues
        raw_data: Raw API response data
        state_types: List of workflow state types
        states: List of workflow states for all issues
        team_ids: List of team IDs for all issues
        team_keys: List of team keys/abbreviations
        team_names: List of team names for all issues
        titles: List of issue titles
        updated_at: List of last update timestamps for all issues
    ### When action = 'add_link'
        attachment_id: ID of the added attachment
        issue_id: ID of the issue the link was added to
        link: URL of the added link
        raw_data: Raw API response data
        title: Title of the added attachment
    ### When action = 'create_comment'
        comment_body: Content of the created comment
        comment_id: Unique identifier of the created comment
        created_at: When the comment was created
        raw_data: Raw API response data
        user_email: Email of the user who created the comment
        user_name: Name of the user who created the comment
    ### When action = 'delete_issue'
        issue_id: ID of the deleted issue
        raw_data: Raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Linear>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_new_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "label": "Select Team",
                    "helper_text": "The team within Linear",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Bug on submit button",
                    "helper_text": "The title of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Clicking on submit button leads to wrong page",
                    "helper_text": "The description of the ticket",
                },
                {
                    "field": "assignee_id",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "helper_text": "Assign the issue to a user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "state_id",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "helper_text": "Set the workflow state",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=state_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "0",
                    "placeholder": "None",
                    "label": "Select Priority",
                    "helper_text": "Issue priority",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "0", "label": "None"},
                            {"value": "1", "label": "Urgent"},
                            {"value": "2", "label": "High"},
                            {"value": "3", "label": "Medium"},
                            {"value": "4", "label": "Low"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created issue",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Human-readable identifier (e.g., ABC-123)",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the created issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the created issue",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current workflow state of the issue",
                },
                {
                    "field": "priority",
                    "type": "int32",
                    "helper_text": "Priority level of the issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was created",
                },
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "Name of the assigned user",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "Email of the assigned user",
                },
                {
                    "field": "team_name",
                    "type": "string",
                    "helper_text": "Name of the team the issue belongs to",
                },
                {
                    "field": "team_key",
                    "type": "string",
                    "helper_text": "Key/abbreviation of the team",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_new_issue",
            "task_name": "tasks.linear.create_new_issue",
            "description": "Create a new issue",
            "label": "Create New Issue",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "team_id",
                "title",
                "description",
                "assignee_id",
                "state_id",
                "priority",
            ],
            "required": ["team_id", "title"],
        },
        "update_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "label": "Select Team",
                    "helper_text": "The team within Linear",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Issue",
                    "helper_text": "The ID of the issue to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "placeholder": "Updated bug title",
                    "helper_text": "New title for the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Updated description",
                    "helper_text": "New description for the issue",
                },
                {
                    "field": "update_team_id",
                    "type": "string",
                    "value": "",
                    "label": "Update Team",
                    "helper_text": "Move to a different team",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignee_id",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "helper_text": "Change assignee",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "state_id",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "helper_text": "Change workflow state",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=state_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "0",
                    "placeholder": "None",
                    "label": "Change Priority",
                    "helper_text": "Change priority",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "0", "label": "None"},
                            {"value": "1", "label": "Urgent"},
                            {"value": "2", "label": "High"},
                            {"value": "3", "label": "Medium"},
                            {"value": "4", "label": "Low"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated issue",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Human-readable identifier (e.g., ABC-123)",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Updated title of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Updated description of the issue",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current workflow state of the issue",
                },
                {
                    "field": "priority",
                    "type": "int32",
                    "helper_text": "Updated priority level of the issue",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was last updated",
                },
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "Name of the assigned user",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "Email of the assigned user",
                },
                {
                    "field": "team_name",
                    "type": "string",
                    "helper_text": "Name of the team the issue belongs to",
                },
                {
                    "field": "team_key",
                    "type": "string",
                    "helper_text": "Key/abbreviation of the team",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_issue",
            "task_name": "tasks.linear.update_issue",
            "description": "Update an existing issue",
            "label": "Update Issue",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "team_id",
                "issue_id",
                "title",
                "description",
                "update_team_id",
                "assignee_id",
                "state_id",
                "priority",
            ],
            "required": ["team_id", "issue_id"],
        },
        "delete_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "label": "Select Team",
                    "helper_text": "The team within Linear",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Issue",
                    "helper_text": "The ID of the issue to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the deleted issue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_issue",
            "task_name": "tasks.linear.delete_issue",
            "description": "Delete an issue",
            "label": "Delete Issue",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "team_id", "issue_id"],
            "required": ["team_id", "issue_id"],
        },
        "get_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "label": "Select Team",
                    "helper_text": "The team within Linear",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Issue",
                    "helper_text": "The ID of the issue to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the issue",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Human-readable identifier (e.g., ABC-123)",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current workflow state of the issue",
                },
                {
                    "field": "state_type",
                    "type": "string",
                    "helper_text": "Type of the workflow state",
                },
                {
                    "field": "priority",
                    "type": "int32",
                    "helper_text": "Priority level of the issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was last updated",
                },
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "Name of the assigned user",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "Email of the assigned user",
                },
                {
                    "field": "assignee_id",
                    "type": "string",
                    "helper_text": "ID of the assigned user",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the issue",
                },
                {
                    "field": "creator_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the issue",
                },
                {
                    "field": "creator_id",
                    "type": "string",
                    "helper_text": "ID of the user who created the issue",
                },
                {
                    "field": "team_name",
                    "type": "string",
                    "helper_text": "Name of the team the issue belongs to",
                },
                {
                    "field": "team_key",
                    "type": "string",
                    "helper_text": "Key/abbreviation of the team",
                },
                {
                    "field": "team_id",
                    "type": "string",
                    "helper_text": "ID of the team the issue belongs to",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "Name of the project the issue belongs to",
                },
                {
                    "field": "project_id",
                    "type": "string",
                    "helper_text": "ID of the project the issue belongs to",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the issue",
                },
                {
                    "field": "comment_count",
                    "type": "int32",
                    "helper_text": "Number of comments on the issue",
                },
                {
                    "field": "comments",
                    "type": "string",
                    "helper_text": "Comments on the issue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_issue",
            "task_name": "tasks.linear.get_issue",
            "description": "Read details of a specific issue",
            "label": "Get Issue",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "team_id", "issue_id"],
            "required": ["team_id", "issue_id"],
        },
        "list_issues**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                },
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Team",
                    "helper_text": "Filter by team",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "state_id",
                    "type": "string",
                    "value": "",
                    "label": "Select State",
                    "helper_text": "Filter by workflow state",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=state_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "assignee_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Assignee",
                    "helper_text": "Filter by assignee",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "placeholder": "None",
                    "label": "Select Priority",
                    "helper_text": "Filter by priority",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "0", "label": "None"},
                            {"value": "1", "label": "Urgent"},
                            {"value": "2", "label": "High"},
                            {"value": "3", "label": "Medium"},
                            {"value": "4", "label": "Low"},
                        ],
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "label": "Return All",
                    "helper_text": "Return all matching issues regardless of count",
                },
            ],
            "outputs": [
                {
                    "field": "issue_count",
                    "type": "int32",
                    "helper_text": "Total number of issues returned",
                },
                {
                    "field": "issue_ids",
                    "type": "vec<string>",
                    "helper_text": "List of unique identifiers for all issues",
                },
                {
                    "field": "issue_identifiers",
                    "type": "vec<string>",
                    "helper_text": "List of human-readable identifiers (e.g., ABC-123)",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of issue titles",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of issue descriptions",
                },
                {
                    "field": "states",
                    "type": "vec<string>",
                    "helper_text": "List of workflow states for all issues",
                },
                {
                    "field": "state_types",
                    "type": "vec<string>",
                    "helper_text": "List of workflow state types",
                },
                {
                    "field": "priorities",
                    "type": "vec<int32>",
                    "helper_text": "List of priority levels for all issues",
                },
                {
                    "field": "created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps for all issues",
                },
                {
                    "field": "updated_at",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last update timestamps for all issues",
                },
                {
                    "field": "assignee_names",
                    "type": "vec<string>",
                    "helper_text": "List of assigned user names",
                },
                {
                    "field": "assignee_emails",
                    "type": "vec<string>",
                    "helper_text": "List of assigned user emails",
                },
                {
                    "field": "assignee_ids",
                    "type": "vec<string>",
                    "helper_text": "List of assigned user IDs",
                },
                {
                    "field": "creator_names",
                    "type": "vec<string>",
                    "helper_text": "List of issue creator names",
                },
                {
                    "field": "creator_emails",
                    "type": "vec<string>",
                    "helper_text": "List of issue creator emails",
                },
                {
                    "field": "creator_ids",
                    "type": "vec<string>",
                    "helper_text": "List of issue creator IDs",
                },
                {
                    "field": "team_names",
                    "type": "vec<string>",
                    "helper_text": "List of team names for all issues",
                },
                {
                    "field": "team_keys",
                    "type": "vec<string>",
                    "helper_text": "List of team keys/abbreviations",
                },
                {
                    "field": "team_ids",
                    "type": "vec<string>",
                    "helper_text": "List of team IDs for all issues",
                },
                {
                    "field": "project_names",
                    "type": "vec<string>",
                    "helper_text": "List of project names for all issues",
                },
                {
                    "field": "project_ids",
                    "type": "vec<string>",
                    "helper_text": "List of project IDs for all issues",
                },
                {
                    "field": "due_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of due dates for all issues",
                },
                {
                    "field": "issue_titles",
                    "type": "vec<string>",
                    "helper_text": "List of issue titles (duplicate of titles)",
                },
                {
                    "field": "issue_identifiers_str",
                    "type": "vec<string>",
                    "helper_text": "List of issue identifiers as strings",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_issues",
            "task_name": "tasks.linear.list_issues",
            "description": "Get multiple issues",
            "label": "List Issues",
            "variant": "get_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "team_id",
                "state_id",
                "assignee_id",
                "priority",
                "return_all",
            ],
            "required": [],
        },
        "list_issues**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Number of Issues",
                    "helper_text": "Specify the number of issues to fetch",
                }
            ],
            "outputs": [],
        },
        "list_issues**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_issues**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_issues**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "add_link**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "label": "Select Team",
                    "helper_text": "The team within Linear",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Issue",
                    "helper_text": "The ID of the issue to add a link to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "link",
                    "type": "string",
                    "value": "",
                    "label": "Link URL",
                    "placeholder": "https://example.com/document",
                    "helper_text": "The URL to attach to the issue",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the issue the link was added to",
                },
                {
                    "field": "link",
                    "type": "string",
                    "helper_text": "URL of the added link",
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "ID of the added attachment",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the added attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_link",
            "task_name": "tasks.linear.add_link",
            "description": "Add a link to an issue",
            "label": "Add Link",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "team_id",
                "issue_id",
                "link",
            ],
            "required": ["team_id", "issue_id", "link"],
        },
        "create_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "label": "Select Team",
                    "helper_text": "The team within Linear",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Issue",
                    "helper_text": "The ID of the issue to add a comment to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=issue_id&team_id={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "comment",
                    "type": "string",
                    "value": "",
                    "label": "Comment",
                    "placeholder": "More users are facing this issue",
                    "helper_text": "The comment text",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "label": "Parent Comment ID",
                    "helper_text": "ID of parent comment for replies (optional)",
                    "placeholder": "4fc4-aa4b-1234567890",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created comment",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Content of the created comment",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the comment",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_comment",
            "task_name": "tasks.linear.create_new_comment",
            "description": "Add a comment to an issue",
            "label": "Add Comment",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "team_id",
                "issue_id",
                "comment",
                "parent_id",
            ],
            "required": ["team_id", "issue_id", "comment"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "num_messages"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        assignee_id: str = "",
        comment: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        description: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        issue_id: str = "",
        link: str = "",
        num_messages: int = 10,
        parent_id: str = "",
        priority: str = "0",
        return_all: bool = False,
        state_id: str = "",
        team_id: Optional[str] = None,
        title: str = "",
        update_team_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_linear",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if team_id is not None:
            self.inputs["team_id"] = team_id
        if title is not None:
            self.inputs["title"] = title
        if description is not None:
            self.inputs["description"] = description
        if assignee_id is not None:
            self.inputs["assignee_id"] = assignee_id
        if state_id is not None:
            self.inputs["state_id"] = state_id
        if priority is not None:
            self.inputs["priority"] = priority
        if issue_id is not None:
            self.inputs["issue_id"] = issue_id
        if update_team_id is not None:
            self.inputs["update_team_id"] = update_team_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if link is not None:
            self.inputs["link"] = link
        if comment is not None:
            self.inputs["comment"] = comment
        if parent_id is not None:
            self.inputs["parent_id"] = parent_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationLinearNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
