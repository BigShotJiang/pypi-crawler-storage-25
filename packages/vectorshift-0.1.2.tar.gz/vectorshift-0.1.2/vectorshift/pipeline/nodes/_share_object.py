"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("share_object")
class ShareObjectNode(Node):
    """
    Share a VectorShift object with another user

    ## Inputs
    ### Common Inputs
        object_type: The object_type input
        org_name: Enter the name of the organization of the user (leave blank if not part of org)
        user_identifier: Enter the username or email of the user you want to share with
    ### knowledge_base
        object: The object input

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "object_type",
            "helper_text": "The object_type input",
            "value": "knowledge_base",
            "type": "string",
        },
        {
            "field": "org_name",
            "helper_text": "Enter the name of the organization of the user (leave blank if not part of org)",
            "value": "",
            "type": "string",
        },
        {
            "field": "user_identifier",
            "helper_text": "Enter the username or email of the user you want to share with",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "knowledge_base": {
            "inputs": [{"field": "object", "type": "knowledge_base"}],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["object_type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["user_identifier"]

    def __init__(
        self,
        object_type: str = "knowledge_base",
        object: "KnowledgeBase" = "",
        org_name: str = "",
        user_identifier: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["object_type"] = object_type

        super().__init__(
            node_type="share_object",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if object_type is not None:
            self.inputs["object_type"] = object_type
        if user_identifier is not None:
            self.inputs["user_identifier"] = user_identifier
        if org_name is not None:
            self.inputs["org_name"] = org_name
        if object is not None:
            self.inputs["object"] = object
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ShareObjectNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
