"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_twilio")
class IntegrationTwilioNode(Node):
    """
    Twilio

    ## Inputs
    ### Common Inputs
        action: Select the Twilio operation to perform
        integration: Provide your Twilio API Key SID and Secret
    ### make_call
        language: Language for text-to-speech
        message: Enter the message content to send
        to: Enter the recipient's phone number (include country code)
        voice: Select the voice for text-to-speech
    ### send_message
        media_url: URL of media to send (for MMS only)
        message: Enter the message content to send
        message_type: Select the type of message to send
        to: Enter the recipient's phone number (include country code)

    ## Outputs
    ### make_call
        call_sid: Unique identifier for the initiated call
        duration: Duration of the call in seconds
        error_code: Error code if call failed
        error_message: Error message if call failed
        price: Price charged for the call
        price_unit: Currency unit for the price
        raw_data: Raw JSON response from Twilio API
        status: Status of the call operation
    ### send_message
        error_code: Error code if message failed
        error_message: Error message if send failed
        message_sid: Unique identifier for the sent message
        price: Price charged for the message
        price_unit: Currency unit for the price
        raw_data: Raw JSON response from Twilio API
        status: Status of the message send operation
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the Twilio operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Provide your Twilio API Key SID and Secret",
            "value": None,
            "type": "integration<Twilio>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "send_message": {
            "inputs": [
                {
                    "field": "to",
                    "type": "string",
                    "value": "",
                    "label": "Recipient Number",
                    "placeholder": "+1234567890",
                    "helper_text": "Enter the recipient's phone number (include country code)",
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "label": "Message Content",
                    "placeholder": "Your message here",
                    "helper_text": "Enter the message content to send",
                },
                {
                    "field": "message_type",
                    "type": "string",
                    "value": "SMS",
                    "label": "Message Type",
                    "helper_text": "Select the type of message to send",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "SMS", "value": "SMS"},
                            {"label": "MMS", "value": "MMS"},
                            {"label": "WhatsApp", "value": "WhatsApp"},
                        ],
                    },
                },
                {
                    "field": "media_url",
                    "type": "string",
                    "value": "",
                    "label": "Media URL",
                    "placeholder": "https://example.com/image.jpg",
                    "helper_text": "URL of media to send (for MMS only)",
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the message send operation",
                },
                {
                    "field": "message_sid",
                    "type": "string",
                    "helper_text": "Unique identifier for the sent message",
                },
                {
                    "field": "error_code",
                    "type": "string",
                    "helper_text": "Error code if message failed",
                },
                {
                    "field": "error_message",
                    "type": "string",
                    "helper_text": "Error message if send failed",
                },
                {
                    "field": "price",
                    "type": "string",
                    "helper_text": "Price charged for the message",
                },
                {
                    "field": "price_unit",
                    "type": "string",
                    "helper_text": "Currency unit for the price",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Twilio API",
                },
            ],
            "name": "send_message",
            "task_name": "tasks.twilio.send_message",
            "description": "Send an SMS, MMS, or WhatsApp message using Twilio",
            "label": "Send Message",
            "required": ["to", "message", "message_type"],
            "input_sort_order": [
                "integration",
                "action",
                "to",
                "message",
                "message_type",
                "media_url",
            ],
        },
        "make_call": {
            "inputs": [
                {
                    "field": "to",
                    "type": "string",
                    "value": "",
                    "label": "Recipient Number",
                    "placeholder": "+1234567890",
                    "helper_text": "Enter the recipient's phone number (include country code)",
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "label": "Message Content",
                    "placeholder": "Hello, this is a call from your application",
                    "helper_text": "Enter the message content for text-to-speech",
                },
                {
                    "field": "voice",
                    "type": "string",
                    "value": "alice",
                    "label": "Voice",
                    "helper_text": "Select the voice for text-to-speech",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Alice", "value": "alice"},
                            {"label": "Man", "value": "man"},
                            {"label": "Woman", "value": "woman"},
                        ],
                    },
                },
                {
                    "field": "language",
                    "type": "string",
                    "value": "en",
                    "label": "Language",
                    "helper_text": "Language for text-to-speech",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "English", "value": "en"},
                            {"label": "Spanish", "value": "es"},
                            {"label": "French", "value": "fr"},
                            {"label": "German", "value": "de"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the call operation",
                },
                {
                    "field": "call_sid",
                    "type": "string",
                    "helper_text": "Unique identifier for the initiated call",
                },
                {
                    "field": "duration",
                    "type": "string",
                    "helper_text": "Duration of the call in seconds",
                },
                {
                    "field": "price",
                    "type": "string",
                    "helper_text": "Price charged for the call",
                },
                {
                    "field": "price_unit",
                    "type": "string",
                    "helper_text": "Currency unit for the price",
                },
                {
                    "field": "error_code",
                    "type": "string",
                    "helper_text": "Error code if call failed",
                },
                {
                    "field": "error_message",
                    "type": "string",
                    "helper_text": "Error message if call failed",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from Twilio API",
                },
            ],
            "name": "make_call",
            "task_name": "tasks.twilio.make_call",
            "description": "Make a phone call using Twilio's text-to-speech feature",
            "label": "Make Call",
            "required": ["to", "message", "voice", "language"],
            "input_sort_order": [
                "integration",
                "action",
                "to",
                "message",
                "voice",
                "language",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "to", "message"]

    def __init__(
        self,
        action: str = "",
        language: str = "en",
        media_url: str = "",
        message: str = "",
        message_type: str = "SMS",
        to: str = "",
        voice: str = "alice",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_twilio",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if to is not None:
            self.inputs["to"] = to
        if message is not None:
            self.inputs["message"] = message
        if message_type is not None:
            self.inputs["message_type"] = message_type
        if media_url is not None:
            self.inputs["media_url"] = media_url
        if voice is not None:
            self.inputs["voice"] = voice
        if language is not None:
            self.inputs["language"] = language
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationTwilioNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
