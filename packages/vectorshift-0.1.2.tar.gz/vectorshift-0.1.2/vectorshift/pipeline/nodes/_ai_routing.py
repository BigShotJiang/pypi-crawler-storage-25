"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("ai_routing")
class AiRoutingNode(Node):
    """
    Route the execution flow to different paths based on the value of the conditions.

    ## Inputs
    ### Common Inputs
        model: The specific model for categorization
        temperature: The temperature of the model
        max_tokens: The maximum number of tokens to generate
        top_p: The top-p value
        conditions: The conditions input
        enable_shared_memory: If enabled, Shared Memory will be included as context for routing decisions
        input_query: Specify the message that the AI router will classify
        outputs: The outputs input
        provider: The model provider
    ### When enable_shared_memory = True
        shared_memory: The shared memory that will be used as context for AI to determine the routing

    ## Outputs
    ### Common Outputs
        [outputs]: The [outputs] output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for categorization",
            "value": "",
            "type": "string",
        },
        {
            "field": "temperature",
            "helper_text": "The temperature of the model",
            "value": 0.7,
            "type": "float",
        },
        {
            "field": "max_tokens",
            "helper_text": "The maximum number of tokens to generate",
            "value": 2048,
            "type": "int64",
        },
        {
            "field": "top_p",
            "helper_text": "The top-p value",
            "value": 1.0,
            "type": "float",
        },
        {
            "field": "conditions",
            "helper_text": "The conditions input",
            "value": ["", ""],
            "type": "vec<string>",
        },
        {
            "field": "enable_shared_memory",
            "helper_text": "If enabled, Shared Memory will be included as context for routing decisions",
            "value": False,
            "type": "bool",
        },
        {
            "field": "input_query",
            "helper_text": "Specify the message that the AI router will classify",
            "value": "",
            "type": "string",
        },
        {
            "field": "outputs",
            "helper_text": "The outputs input",
            "value": {"path_0": "path", "path_1": "path"},
            "type": "map<string, string>",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "[outputs]", "helper_text": "The [outputs] output", "type": ""}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**true": {
            "inputs": [
                {
                    "field": "shared_memory",
                    "type": "string",
                    "value": "",
                    "helper_text": "The shared memory that will be used as context for AI to determine the routing",
                    "label": "Shared Memory",
                    "component": {"type": "text"},
                }
            ],
            "outputs": [],
        },
        "openai**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "anthropic**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "temperature",
                    "label": "Temperature",
                    "component": {"type": "number_slider"},
                    "min": "0",
                    "max": "1",
                    "step": "0.01",
                    "section": "advanced_settings",
                    "type": "float",
                    "value": 0.7,
                    "helper_text": "The temperature of the model",
                },
            ],
            "outputs": [],
        },
        "google**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "xai**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "temperature",
                    "label": "Temperature",
                    "component": {"type": "number_slider"},
                    "min": "0",
                    "max": "1",
                    "step": "0.01",
                    "section": "advanced_settings",
                    "type": "float",
                    "value": 0.7,
                    "helper_text": "The temperature of the model",
                },
            ],
            "outputs": [],
        },
        "cohere**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "perplexity**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "together**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "bedrock**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "azure**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM Model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["provider", "enable_shared_memory"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["input_query"]

    def __init__(
        self,
        provider: str = "openai",
        enable_shared_memory: bool = False,
        model: str = "",
        conditions: List[str] = ["", ""],
        input_query: str = "",
        outputs: Dict[str, str] = {"path_0": "path", "path_1": "path"},
        shared_memory: str = "",
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["provider"] = provider
        params["enable_shared_memory"] = enable_shared_memory

        super().__init__(
            node_type="ai_routing",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if enable_shared_memory is not None:
            self.inputs["enable_shared_memory"] = enable_shared_memory
        if input_query is not None:
            self.inputs["input_query"] = input_query
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if conditions is not None:
            self.inputs["conditions"] = conditions
        if outputs is not None:
            self.inputs["outputs"] = outputs
        if shared_memory is not None:
            self.inputs["shared_memory"] = shared_memory
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiRoutingNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
