"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_outlook")
class TriggerOutlookNode(Node):
    """
    Outlook Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        item_id: Select the Trigger
        trigger_enabled: Enable/Disable Automation

    ## Outputs
    ### new_email
        attachments: Attachments of the email
        bcc_emails: Email addresses of the BCC recipients
        cc_emails: Email addresses of the CC recipients
        contents_of_email: Contents of the email
        email_id: Unique identifier of the email
        raw_data: Raw API response data for the email
        received_time: When the email was received
        recipient_email: Email address of the recipient
        sender_email: Email address of the sender
        subject: Subject of the email
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Outlook>",
        },
        {
            "field": "item_id",
            "helper_text": "Select the Trigger",
            "value": "",
            "type": "string",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_email": {
            "inputs": [],
            "outputs": [
                {
                    "field": "email_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the email",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Subject of the email",
                },
                {
                    "field": "sender_email",
                    "type": "string",
                    "helper_text": "Email address of the sender",
                },
                {
                    "field": "recipient_email",
                    "type": "string",
                    "helper_text": "Email address of the recipient",
                },
                {
                    "field": "cc_emails",
                    "type": "string",
                    "helper_text": "Email addresses of the CC recipients",
                },
                {
                    "field": "bcc_emails",
                    "type": "string",
                    "helper_text": "Email addresses of the BCC recipients",
                },
                {
                    "field": "received_time",
                    "type": "string",
                    "helper_text": "When the email was received",
                },
                {
                    "field": "contents_of_email",
                    "type": "string",
                    "helper_text": "Contents of the email",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "helper_text": "Attachments of the email",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data for the email",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_email",
            "task_name": "tasks.outlook.new_email",
            "description": "Triggers when new email appears in the specified mailbox",
            "label": "New Email",
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Mailbox"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_outlook",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerOutlookNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
