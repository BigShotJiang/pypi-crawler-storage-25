"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_microsoft_calendar")
class IntegrationMicrosoftCalendarNode(Node):
    """
    Microsoft Calendar

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'find_meeting_times'
        activity_domain: Controls which hours to consider for scheduling. 'Work' restricts suggestions to each attendee's individual work hours and timezone. 'Personal' extends to weekends. 'Unrestricted' allows any time of day.
        attendee_emails: List of attendee email addresses to find common available times.
        attendee_types: Type for each attendee (maps 1:1 with attendee emails). Values: 'required' (must attend), 'optional' (nice to have), 'resource' (room/equipment). Defaults to 'required' if not provided.
        end_date_and_time: The last date and end time for everyday to look for availability
        is_location_required: Whether a meeting location is required for the suggestions.
        is_organizer_optional: Whether the organizer (you) is optional for the meeting
        location_names: Optional list of preferred meeting location names. Must be registered room resources in your organization (Exchange/Microsoft 365 room mailboxes). Graph API will attempt to resolve and verify room availability for each provided location.
        max_suggestions: Maximum number of meeting time suggestions to return. Typical values: 5-20.
        meeting_duration: Duration of the meeting (e.g., 30, 60m, 1h, 90). Defaults to minutes if no suffix provided.
        minimum_attendee_percentage: Minimum percentage of attendees that must be available for a slot to be suggested (0-100). Use 100 to require all attendees, or lower values (e.g., 50) for flexible scheduling where not everyone needs to attend.
        start_date_and_time: The first date and start time for everyday to look for availability
        suggest_location: Whether the API should suggest available meeting rooms.
        timezone: IANA Time Zone code (e.g., US/Eastern)
    ### When action = 'new_event'
        all_day_event: Whether this is an all-day event
        allow_new_time_proposals: Whether attendees can propose new times
        attendees: Comma-separated list of attendee email addresses
        body: Description/body of the event
        calendar: The ID of the calendar to create event in
        categories: Comma-separated list of categories
        duration: The duration of the event in minutes. Default: 30 (in minutes)
        hide_attendees: Whether to hide attendees from each other
        importance: Importance level of the event
        is_online_meeting: Whether to create an online meeting
        is_reminder_on: Whether to enable reminder
        location: Location of the event
        online_meeting_provider: Provider for online meeting
        reminder_minutes: Minutes before event to send reminder (default 15)
        response_requested: Whether responses are requested from attendees
        sensitivity: Sensitivity level of the event
        show_as: How to show the time slot
        start_datetime: The start time of the event (RFC3339 format)
        subject: The subject/title of the event
    ### When action = 'update_event'
        attendees: Comma-separated list of attendee email addresses
        calendar_id: The ID of the calendar to retrieve
        categories: Comma-separated list of categories
        description: New description/body of the event
        end_datetime: New end time of the event (RFC3339 format)
        event_id: The ID of the event to retrieve
        event_subject: New subject/title of the event
        importance: Importance level of the event
        is_all_day: Filter for all-day events only
        is_reminder_on: Whether to enable reminder
        location: Location of the event
        reminder_minutes: Minutes before event to send reminder (default 15)
        sensitivity: Sensitivity level of the event
        show_as: How to show the time slot
        start_datetime: The start time of the event (RFC3339 format)
    ### When action = 'get_calendar'
        calendar_id: The ID of the calendar to retrieve
    ### When action = 'update_calendar'
        calendar_id: The ID of the calendar to retrieve
        calendar_name: The name of the calendar to create
        color: Color for the calendar
    ### When action = 'delete_calendar'
        calendar_id: The ID of the calendar to retrieve
    ### When action = 'get_event'
        calendar_id: The ID of the calendar to retrieve
        event_id: The ID of the event to retrieve
    ### When action = 'list_events'
        calendar_id: The ID of the calendar to retrieve
        from_all_calendars: Whether to list events from all calendars
        has_attachments: Filter for events with attachments
        importance: Importance level of the event
        is_all_day: Filter for all-day events only
        location_contains: Filter events by location
        order_by: Field to order results by
        sensitivity: Sensitivity level of the event
        show_as: How to show the time slot
        subject_contains: Filter events by subject containing this text
        use_date: Toggle to use dates
    ### When action = 'delete_event'
        calendar_id: The ID of the calendar to retrieve
        event_id: The ID of the event to retrieve
    ### When action = 'create_calendar'
        calendar_name: The name of the calendar to create
        color: Color for the calendar
    ### When action = 'list_events' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'check_availability'
        end_date_and_time: The last date and end time for everyday to look for availability
        slot_duration: The duration of an individual slot to look for (in minutes). Default: 30 (in minutes)
        start_date_and_time: The first date and start time for everyday to look for availability
        timezone: IANA Time Zone code (e.g., US/Eastern)
    ### When action = 'list_events' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'list_calendars'
        filter_query: Filter query to filter calendars. Examples: 'canShare eq true', 'canEdit eq true', 'isDefaultCalendar eq false'
        limit: Maximum number of calendars to retrieve
        order_by: Field to order results by
    ### When action = 'list_people'
        filter_query: Filter query to filter calendars. Examples: 'canShare eq true', 'canEdit eq true', 'isDefaultCalendar eq false'
        limit: Maximum number of calendars to retrieve
        order_by: Field to order results by
        search: Search users by display name or email
    ### When action = 'list_users'
        limit: Maximum number of calendars to retrieve
        search: Search users by display name or email
    ### When action = 'list_events' and use_date = False
        num_messages: Specify the number of events to fetch
    ### When action = 'list_events' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_user'
        user_identifier: The user's ID or organizational email (work/school accounts only, not personal @outlook.com/@hotmail.com)

    ## Outputs
    ### When action = 'find_meeting_times'
        all_end_datetimes: All suggested end datetimes (ordered by confidence, highest first)
        all_start_datetimes: All suggested start datetimes (ordered by confidence, highest first)
        available_slots: Human-readable list of available meeting slots with confidence scores
        best_end_datetime: End datetime of the top suggestion
        best_start_datetime: Start datetime of the top (highest confidence) suggestion
        confidences: Confidence scores (0-100) for each suggestion (ordered highest first)
        duration: Meeting duration in minutes
        empty_reason: Reason if no meeting times could be found (e.g., AttendeesUnavailable, OrganizerUnavailable)
        meeting_suggestions: Detailed meeting suggestions in JSON format with attendee availability
        raw_data: Raw API response data in JSON format
        total_suggestions: Number of meeting time suggestions returned
    ### When action = 'get_event'
        allow_new_time_proposals: Whether new time proposals are allowed
        attendee_emails: List of attendee email addresses
        attendees: List of attendees in JSON format
        categories: Categories assigned to the event
        created_datetime: When the event was created
        description: Description of the event
        description_preview: Preview of the description
        end_datetime: End datetime of the event
        event_id: ID of the event
        event_subject: Subject of the event
        has_attachments: Whether the event has attachments
        hide_attendees: Whether attendees are hidden
        importance: Importance level of the event
        is_all_day: Whether the event is all day
        is_cancelled: Whether the event is cancelled
        is_online_meeting: Whether this is an online meeting
        is_organizer: Whether the user is the organizer
        is_recurring: Whether the event is recurring
        is_reminder_on: Whether reminder is enabled
        last_modified_datetime: When the event was last modified
        location: Location of the event
        online_meeting_url: Online meeting URL if applicable
        organizer_email: Email of the event organizer
        organizer_name: Name of the event organizer
        raw_data: Raw API response data in JSON format
        recurrence_interval: Recurrence interval if applicable
        recurrence_type: Type of recurrence if applicable
        reminder_minutes: Minutes before event for reminder
        response_requested: Whether responses are requested
        sensitivity: Sensitivity level of the event
        show_as: How the time slot is shown
        start_datetime: Start datetime of the event
        web_link: Web link to the event
    ### When action = 'new_event'
        attendees: List of attendee email addresses
        calendar_id: ID of the calendar the event was created in
        description: Description of the event
        end_datetime: End datetime of the event
        event_id: ID of the created event
        event_subject: Subject of the created event
        is_all_day: Whether the event is all day
        location: Location of the event
        online_meeting_url: Online meeting URL if applicable
        output: Calendar event link
        raw_data: Raw API response data in JSON format
        start_datetime: Start datetime of the event
        web_link: Web link to the event
    ### When action = 'check_availability'
        availability_summary: Summary of availability including total free slots and search parameters
        free_slots: Structured list of free time slots
        output: List of available time slots with start and end datetimes
        raw_data: Raw API response data in JSON format
    ### When action = 'create_calendar'
        calendar_id: ID of the created calendar
        calendar_name: Name of the created calendar
        can_edit: Whether the calendar can be edited
        can_share: Whether the calendar can be shared
        color: Color of the created calendar
        is_default: Whether the calendar is the default calendar
        raw_data: Raw API response data in JSON format
    ### When action = 'get_calendar'
        calendar_id: ID of the calendar
        calendar_name: Name of the calendar
        can_edit: Whether the calendar can be edited
        can_share: Whether the calendar can be shared
        can_view_private_items: Whether private items can be viewed
        color: Color of the calendar
        hex_color: Hex color of the calendar
        is_default: Whether the calendar is the default calendar
        is_removable: Whether the calendar is removable
        owner_email: Email of the calendar owner
        owner_name: Name of the calendar owner
        raw_data: Raw API response data in JSON format
    ### When action = 'update_calendar'
        calendar_id: ID of the updated calendar
        calendar_name: Name of the updated calendar
        can_edit: Whether the calendar can be edited
        can_share: Whether the calendar can be shared
        color: Color of the updated calendar
        hex_color: Hex color of the updated calendar
        is_default: Whether the calendar is the default calendar
        raw_data: Raw API response data in JSON format
    ### When action = 'list_calendars'
        calendar_ids: List of calendar IDs
        calendar_names: List of calendar names
        calendars: List of calendars in JSON format
        has_more: Whether there are more calendars available
        raw_data: Raw API response data in JSON format
        total_count: Total number of calendars retrieved
    ### When action = 'update_event'
        description: Description of the updated event
        end_datetime: End datetime of the updated event
        event_id: ID of the updated event
        event_subject: Subject of the updated event
        is_all_day: Whether the event is all day
        location: Location of the updated event
        online_meeting_url: Online meeting URL if applicable
        raw_data: Raw API response data in JSON format
        start_datetime: Start datetime of the updated event
        web_link: Web link to the updated event
    ### When action = 'get_user'
        display_name: The user's display name
        email: The user's email address
        id: The unique ID of the user
        job_title: The user's job title
        mobile_phone: The user's mobile phone number
        office_location: The user's office location
        raw_data: Complete response from Microsoft Graph API
        user_principal_name: The primary sign-in name for the user
    ### When action = 'list_events'
        event_ids: List of event IDs
        event_subjects: List of event subjects
        events: List of events in JSON format
        has_more: Whether there are more events available
        raw_data: Raw API response data in JSON format
        total_count: Total number of events retrieved
    ### When action = 'delete_calendar'
        message: Success message
    ### When action = 'delete_event'
        message: Success message
    ### When action = 'list_people'
        person_departments: List of person departments
        person_emails: List of person email addresses
        person_ids: List of person IDs
        person_job_titles: List of person job titles
        person_names: List of person display names
        raw_data: Complete response from Microsoft Graph API
        total_count: Total number of people returned
    ### When action = 'list_users'
        raw_data: Complete response from Microsoft Graph API
        total_count: Total number of users returned
        user_emails: List of user email addresses
        user_ids: List of user IDs
        user_names: List of user display names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Microsoft Calendar>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_calendar**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_name",
                    "type": "string",
                    "value": "",
                    "label": "Calendar Name",
                    "placeholder": "My Calendar",
                    "helper_text": "The name of the calendar to create",
                },
                {
                    "field": "color",
                    "type": "string",
                    "value": "",
                    "label": "Color",
                    "helper_text": "Color for the calendar",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Light Blue", "value": "light_blue"},
                            {"label": "Light Brown", "value": "light_brown"},
                            {"label": "Light Gray", "value": "light_gray"},
                            {"label": "Light Green", "value": "light_green"},
                            {"label": "Light Orange", "value": "light_orange"},
                            {"label": "Light Pink", "value": "light_pink"},
                            {"label": "Light Red", "value": "light_red"},
                            {"label": "Light Teal", "value": "light_teal"},
                            {"label": "Light Yellow", "value": "light_yellow"},
                            {"label": "Auto", "value": "auto"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "helper_text": "ID of the created calendar",
                },
                {
                    "field": "calendar_name",
                    "type": "string",
                    "helper_text": "Name of the created calendar",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the created calendar",
                },
                {
                    "field": "is_default",
                    "type": "bool",
                    "helper_text": "Whether the calendar is the default calendar",
                },
                {
                    "field": "can_edit",
                    "type": "bool",
                    "helper_text": "Whether the calendar can be edited",
                },
                {
                    "field": "can_share",
                    "type": "bool",
                    "helper_text": "Whether the calendar can be shared",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_calendar",
            "task_name": "tasks.microsoft_calendar.create_calendar",
            "description": "Create a new calendar",
            "label": "Create Calendar",
            "ui_sort_order": ["integration", "action", "calendar_name", "color"],
            "required": ["calendar_name"],
        },
        "get_calendar**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar to retrieve",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "helper_text": "ID of the calendar",
                },
                {
                    "field": "calendar_name",
                    "type": "string",
                    "helper_text": "Name of the calendar",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the calendar",
                },
                {
                    "field": "hex_color",
                    "type": "string",
                    "helper_text": "Hex color of the calendar",
                },
                {
                    "field": "is_default",
                    "type": "bool",
                    "helper_text": "Whether the calendar is the default calendar",
                },
                {
                    "field": "can_edit",
                    "type": "bool",
                    "helper_text": "Whether the calendar can be edited",
                },
                {
                    "field": "can_share",
                    "type": "bool",
                    "helper_text": "Whether the calendar can be shared",
                },
                {
                    "field": "can_view_private_items",
                    "type": "bool",
                    "helper_text": "Whether private items can be viewed",
                },
                {
                    "field": "is_removable",
                    "type": "bool",
                    "helper_text": "Whether the calendar is removable",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the calendar owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the calendar owner",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_calendar",
            "task_name": "tasks.microsoft_calendar.get_calendar",
            "description": "Get a specific calendar",
            "label": "Get Calendar",
            "required": ["calendar_id"],
            "inputs_sort_order": ["integration", "action", "calendar_id"],
        },
        "list_calendars**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of calendars to retrieve",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "name",
                    "label": "Order By",
                    "helper_text": "Field to order results by",
                },
                {
                    "field": "filter_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter Query",
                    "placeholder": "e.g. canShare eq true",
                    "helper_text": "Filter query to filter calendars. Examples: 'canShare eq true', 'canEdit eq true', 'isDefaultCalendar eq false'",
                },
            ],
            "outputs": [
                {
                    "field": "calendars",
                    "type": "string",
                    "helper_text": "List of calendars in JSON format",
                },
                {
                    "field": "calendar_names",
                    "type": "vec<string>",
                    "helper_text": "List of calendar names",
                },
                {
                    "field": "calendar_ids",
                    "type": "vec<string>",
                    "helper_text": "List of calendar IDs",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total number of calendars retrieved",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether there are more calendars available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "list_calendars",
            "task_name": "tasks.microsoft_calendar.list_calendars",
            "description": "List calendars",
            "label": "List Calendars",
            "ui_sort_order": [
                "integration",
                "action",
                "limit",
                "filter_query",
                "order_by",
            ],
            "required": ["limit"],
        },
        "update_calendar**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar to update",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "calendar_name",
                    "type": "string",
                    "value": "",
                    "label": "Calendar Name",
                    "placeholder": "Updated Calendar Name",
                    "helper_text": "New name for the calendar",
                },
                {
                    "field": "color",
                    "type": "string",
                    "value": "",
                    "label": "Color",
                    "helper_text": "New color for the calendar",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Light Blue", "value": "light_blue"},
                            {"label": "Light Brown", "value": "light_brown"},
                            {"label": "Light Gray", "value": "light_gray"},
                            {"label": "Light Green", "value": "light_green"},
                            {"label": "Light Orange", "value": "light_orange"},
                            {"label": "Light Pink", "value": "light_pink"},
                            {"label": "Light Red", "value": "light_red"},
                            {"label": "Light Teal", "value": "light_teal"},
                            {"label": "Light Yellow", "value": "light_yellow"},
                            {"label": "Auto", "value": "auto"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "helper_text": "ID of the updated calendar",
                },
                {
                    "field": "calendar_name",
                    "type": "string",
                    "helper_text": "Name of the updated calendar",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the updated calendar",
                },
                {
                    "field": "hex_color",
                    "type": "string",
                    "helper_text": "Hex color of the updated calendar",
                },
                {
                    "field": "is_default",
                    "type": "bool",
                    "helper_text": "Whether the calendar is the default calendar",
                },
                {
                    "field": "can_edit",
                    "type": "bool",
                    "helper_text": "Whether the calendar can be edited",
                },
                {
                    "field": "can_share",
                    "type": "bool",
                    "helper_text": "Whether the calendar can be shared",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_calendar",
            "task_name": "tasks.microsoft_calendar.update_calendar",
            "description": "Update a calendar",
            "label": "Update Calendar",
            "required": ["calendar_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "calendar_id",
                "calendar_name",
                "color",
            ],
        },
        "delete_calendar**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar to delete",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Success message"}
            ],
            "variant": "common_integration_nodes",
            "name": "delete_calendar",
            "task_name": "tasks.microsoft_calendar.delete_calendar",
            "description": "Delete a calendar",
            "label": "Delete Calendar",
            "required": ["calendar_id"],
            "inputs_sort_order": ["integration", "action", "calendar_id"],
        },
        "new_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar to create event in",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Event Subject",
                    "placeholder": "Meeting with team",
                    "helper_text": "The subject/title of the event",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Event description",
                    "helper_text": "Description/body of the event",
                },
                {
                    "field": "start_datetime",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start DateTime",
                    "placeholder": "2024-06-24T19:00:00-05:00",
                    "helper_text": "The start time of the event (RFC3339 format)",
                    "agent_helper_text": "If the user specifies a timezone, include the UTC offset in the datetime (e.g., 2024-06-24T19:00:00-05:00 for US/Eastern, 2024-06-24T19:00:00+05:30 for Asia/Kolkata). If no timezone is mentioned, omit the offset.",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "value": 30,
                    "label": "Duration",
                    "placeholder": "30 minutes",
                    "helper_text": "The duration of the event in minutes. Default: 30 (in minutes)",
                },
                {
                    "field": "all_day_event",
                    "type": "bool",
                    "value": False,
                    "label": "All Day Event",
                    "helper_text": "Whether this is an all-day event",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "Meeting room or address",
                    "helper_text": "Location of the event",
                },
                {
                    "field": "attendees",
                    "type": "string",
                    "value": "",
                    "label": "Attendees",
                    "placeholder": "email1@example.com,email2@example.com",
                    "helper_text": "Comma-separated list of attendee email addresses",
                },
                {
                    "field": "is_reminder_on",
                    "type": "bool",
                    "value": True,
                    "label": "Reminder On",
                    "helper_text": "Whether to enable reminder",
                },
                {
                    "field": "reminder_minutes",
                    "type": "int32",
                    "value": 15,
                    "label": "Reminder Minutes",
                    "helper_text": "Minutes before event to send reminder (default 15)",
                },
                {
                    "field": "importance",
                    "type": "string",
                    "value": "normal",
                    "label": "Importance",
                    "helper_text": "Importance level of the event",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "low"},
                            {"label": "Normal", "value": "normal"},
                            {"label": "High", "value": "high"},
                        ],
                    },
                },
                {
                    "field": "sensitivity",
                    "type": "string",
                    "value": "normal",
                    "label": "Sensitivity",
                    "helper_text": "Sensitivity level of the event",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Normal", "value": "normal"},
                            {"label": "Personal", "value": "personal"},
                            {"label": "Private", "value": "private"},
                            {"label": "Confidential", "value": "confidential"},
                        ],
                    },
                },
                {
                    "field": "show_as",
                    "type": "string",
                    "value": "busy",
                    "label": "Show As",
                    "helper_text": "How to show the time slot",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Free", "value": "free"},
                            {"label": "Tentative", "value": "tentative"},
                            {"label": "Busy", "value": "busy"},
                            {"label": "Out of Office", "value": "out_of_office"},
                            {
                                "label": "Working Elsewhere",
                                "value": "working_elsewhere",
                            },
                        ],
                    },
                },
                {
                    "field": "categories",
                    "type": "string",
                    "value": "",
                    "label": "Categories",
                    "placeholder": "Category1, Category2",
                    "helper_text": "Comma-separated list of categories",
                },
                {
                    "field": "is_online_meeting",
                    "type": "bool",
                    "value": False,
                    "label": "Online Meeting",
                    "helper_text": "Whether to create an online meeting",
                },
                {
                    "field": "online_meeting_provider",
                    "type": "string",
                    "value": "teamsForBusiness",
                    "label": "Online Meeting Provider",
                    "helper_text": "Provider for online meeting",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {
                                "label": "Teams for Business",
                                "value": "teamsForBusiness",
                            },
                            {
                                "label": "Skype for Business",
                                "value": "skypeForBusiness",
                            },
                            {
                                "label": "Skype for Consumer",
                                "value": "skypeForConsumer",
                            },
                        ],
                    },
                },
                {
                    "field": "hide_attendees",
                    "type": "bool",
                    "value": False,
                    "label": "Hide Attendees",
                    "helper_text": "Whether to hide attendees from each other",
                },
                {
                    "field": "response_requested",
                    "type": "bool",
                    "value": True,
                    "label": "Response Requested",
                    "helper_text": "Whether responses are requested from attendees",
                },
                {
                    "field": "allow_new_time_proposals",
                    "type": "bool",
                    "value": False,
                    "label": "Allow New Time Proposals",
                    "helper_text": "Whether attendees can propose new times",
                },
            ],
            "outputs": [
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "ID of the created event",
                },
                {
                    "field": "calendar_id",
                    "type": "string",
                    "helper_text": "ID of the calendar the event was created in",
                },
                {
                    "field": "event_subject",
                    "type": "string",
                    "helper_text": "Subject of the created event",
                },
                {
                    "field": "start_datetime",
                    "type": "timestamp",
                    "helper_text": "Start datetime of the event",
                },
                {
                    "field": "end_datetime",
                    "type": "timestamp",
                    "helper_text": "End datetime of the event",
                },
                {
                    "field": "is_all_day",
                    "type": "bool",
                    "helper_text": "Whether the event is all day",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "Location of the event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the event",
                },
                {
                    "field": "web_link",
                    "type": "string",
                    "helper_text": "Web link to the event",
                },
                {
                    "field": "online_meeting_url",
                    "type": "string",
                    "helper_text": "Online meeting URL if applicable",
                },
                {
                    "field": "attendees",
                    "type": "vec<string>",
                    "helper_text": "List of attendee email addresses",
                },
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Calendar event link",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "new_event",
            "task_name": "tasks.microsoft_calendar.create_event",
            "description": "Create a new calendar event",
            "label": "Create Event",
            "ui_sort_order": [
                "integration",
                "action",
                "calendar",
                "subject",
                "body",
                "start_datetime",
                "duration",
                "all_day_event",
                "location",
                "attendees",
                "is_reminder_on",
                "reminder_minutes",
                "importance",
                "sensitivity",
                "show_as",
                "categories",
                "is_online_meeting",
                "online_meeting_provider",
                "hide_attendees",
                "response_requested",
                "allow_new_time_proposals",
            ],
            "required": ["subject", "calendar", "start_datetime", "duration"],
        },
        "check_availability**(*)**(*)": {
            "inputs": [
                {
                    "field": "start_date_and_time",
                    "type": "timestamp",
                    "value": "",
                    "label": "Start Date & Start Work Time",
                    "placeholder": "2024-06-24",
                    "helper_text": "The first date and start time for everyday to look for availability",
                },
                {
                    "field": "end_date_and_time",
                    "type": "timestamp",
                    "value": "",
                    "label": "End Date & End Work Time",
                    "placeholder": "2024-06-24",
                    "helper_text": "The last date and end time for everyday to look for availability",
                },
                {
                    "field": "slot_duration",
                    "type": "int32",
                    "value": "",
                    "label": "Slot duration",
                    "placeholder": "30 minutes",
                    "helper_text": "The duration of an individual slot to look for (in minutes). Default: 30 (in minutes)",
                },
                {
                    "field": "timezone",
                    "type": "string",
                    "value": "US/Eastern",
                    "label": "Timezone",
                    "placeholder": "US/Eastern",
                    "helper_text": "IANA Time Zone code (e.g., US/Eastern)",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "List of available time slots with start and end datetimes",
                },
                {
                    "field": "free_slots",
                    "type": "string",
                    "helper_text": "Structured list of free time slots",
                },
                {
                    "field": "availability_summary",
                    "type": "string",
                    "helper_text": "Summary of availability including total free slots and search parameters",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "check_availability",
            "variant": "common_integration_nodes",
            "task_name": "tasks.microsoft_calendar.check_availability",
            "description": "Check Microsoft calendar availability",
            "label": "Check Availability",
            "ui_sort_order": [
                "integration",
                "action",
                "timezone",
                "start_date_and_time",
                "end_date_and_time",
                "slot_duration",
            ],
            "required": ["start_date_and_time", "end_date_and_time"],
        },
        "find_meeting_times**(*)**(*)": {
            "inputs": [
                {
                    "field": "attendee_emails",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Attendee Emails",
                    "placeholder": "user1@company.com",
                    "helper_text": "List of attendee email addresses to find common available times.",
                },
                {
                    "field": "attendee_types",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Attendee Types",
                    "placeholder": "required, optional",
                    "helper_text": "Type for each attendee (maps 1:1 with attendee emails). Values: 'required' (must attend), 'optional' (nice to have), 'resource' (room/equipment). Defaults to 'required' if not provided.",
                },
                {
                    "field": "start_date_and_time",
                    "type": "timestamp",
                    "value": "",
                    "label": "Start Date & Time",
                    "placeholder": "2024-06-24T00:00:00",
                    "helper_text": "Optional. Start of the time range to search for available meeting times. If provided, results are limited to this window.",
                    "agent_helper_text": "Optional. Do NOT set this unless the user has explicitly provided a start date or time. Do not guess, infer, or assume a value. If left empty, the API uses each attendee's configured work hours automatically. Note: start and end must always be set together — never set one without the other. If the user provides only a date with no time, use T00:00:00 (e.g., 2024-06-24T00:00:00). Only include a specific time if the user explicitly provides one.",
                },
                {
                    "field": "end_date_and_time",
                    "type": "timestamp",
                    "value": "",
                    "label": "End Date & Time",
                    "placeholder": "2024-06-28T23:59:59",
                    "helper_text": "Optional. End of the time range to search for available meeting times. If provided, results are limited to this window.",
                    "agent_helper_text": "Optional. Do NOT set this unless the user has explicitly provided an end date or time. Do not guess, infer, or assume a value. If left empty, the API uses each attendee's configured work hours automatically. Note: start and end must always be set together — never set one without the other. If the user provides only a date with no time, use T23:59:59 (e.g., 2024-06-28T23:59:59). Only include a specific time if the user explicitly provides one.",
                },
                {
                    "field": "meeting_duration",
                    "type": "string",
                    "value": "60",
                    "label": "Meeting Duration",
                    "placeholder": "60",
                    "helper_text": "Duration of the meeting (e.g., 30, 60m, 1h, 90). Defaults to minutes if no suffix provided.",
                },
                {
                    "field": "timezone",
                    "type": "string",
                    "value": "US/Eastern",
                    "label": "Timezone",
                    "placeholder": "US/Eastern",
                    "helper_text": "IANA Time Zone for the search window and response times (e.g., US/Eastern, Europe/London). Note: each attendee's work hours are based on their own mailbox timezone, not this field.",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "minimum_attendee_percentage",
                    "type": "int32",
                    "value": 100,
                    "label": "Minimum Attendee Percentage",
                    "placeholder": "100",
                    "helper_text": "Minimum percentage of attendees that must be available for a slot to be suggested (0-100). Use 100 to require all attendees, or lower values (e.g., 50) for flexible scheduling where not everyone needs to attend.",
                },
                {
                    "field": "max_suggestions",
                    "type": "int32",
                    "value": 20,
                    "label": "Max Suggestions",
                    "placeholder": "20",
                    "helper_text": "Maximum number of meeting time suggestions to return. Typical values: 5-20.",
                },
                {
                    "field": "is_organizer_optional",
                    "type": "bool",
                    "value": False,
                    "label": "Organizer Optional",
                    "helper_text": "Whether the organizer (you) is optional for the meeting",
                },
                {
                    "field": "activity_domain",
                    "type": "string",
                    "value": "work",
                    "label": "Activity Domain",
                    "helper_text": "Controls which hours to consider for scheduling. 'Work' restricts suggestions to each attendee's individual work hours and timezone. 'Personal' extends to weekends. 'Unrestricted' allows any time of day.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Work (business hours only)", "value": "work"},
                            {
                                "label": "Personal (work hours + weekends)",
                                "value": "personal",
                            },
                            {
                                "label": "Unrestricted (any time)",
                                "value": "unrestricted",
                            },
                        ],
                    },
                },
                {
                    "field": "location_names",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Location Names",
                    "placeholder": "Conference Room A, Building 1 Room 201",
                    "helper_text": "Optional list of preferred meeting location names. Must be registered room resources in your organization (Exchange/Microsoft 365 room mailboxes). Graph API will attempt to resolve and verify room availability for each provided location.",
                },
                {
                    "field": "is_location_required",
                    "type": "bool",
                    "value": False,
                    "label": "Location Required",
                    "helper_text": "Whether a meeting location is required for the suggestions.",
                },
                {
                    "field": "suggest_location",
                    "type": "bool",
                    "value": False,
                    "label": "Suggest Location",
                    "helper_text": "Whether the API should suggest available meeting rooms.",
                },
            ],
            "outputs": [
                {
                    "field": "available_slots",
                    "type": "vec<string>",
                    "helper_text": "Human-readable list of available meeting slots with confidence scores",
                },
                {
                    "field": "meeting_suggestions",
                    "type": "string",
                    "helper_text": "Detailed meeting suggestions in JSON format with attendee availability",
                },
                {
                    "field": "best_start_datetime",
                    "type": "timestamp",
                    "helper_text": "Start datetime of the top (highest confidence) suggestion",
                },
                {
                    "field": "best_end_datetime",
                    "type": "timestamp",
                    "helper_text": "End datetime of the top suggestion",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "helper_text": "Meeting duration in minutes",
                },
                {
                    "field": "all_start_datetimes",
                    "type": "vec<timestamp>",
                    "helper_text": "All suggested start datetimes (ordered by confidence, highest first)",
                },
                {
                    "field": "all_end_datetimes",
                    "type": "vec<timestamp>",
                    "helper_text": "All suggested end datetimes (ordered by confidence, highest first)",
                },
                {
                    "field": "confidences",
                    "type": "vec<int32>",
                    "helper_text": "Confidence scores (0-100) for each suggestion (ordered highest first)",
                },
                {
                    "field": "total_suggestions",
                    "type": "int32",
                    "helper_text": "Number of meeting time suggestions returned",
                },
                {
                    "field": "empty_reason",
                    "type": "string",
                    "helper_text": "Reason if no meeting times could be found (e.g., AttendeesUnavailable, OrganizerUnavailable)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "find_meeting_times",
            "variant": "common_integration_nodes",
            "task_name": "tasks.microsoft_calendar.find_meeting_times",
            "description": "Find common available meeting times for multiple attendees (Scheduling Assistant)",
            "label": "Find Meeting Times",
            "banner_text": "Note: Searches within a maximum 42-day window.",
            "required": ["attendee_emails", "meeting_duration", "timezone"],
            "inputs_sort_order": [
                "integration",
                "action",
                "attendee_emails",
                "attendee_types",
                "timezone",
                "start_date_and_time",
                "end_date_and_time",
                "meeting_duration",
                "minimum_attendee_percentage",
                "max_suggestions",
                "is_organizer_optional",
                "activity_domain",
                "location_names",
                "is_location_required",
                "suggest_location",
            ],
        },
        "get_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar containing the event",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "value": "",
                    "label": "Event ID",
                    "placeholder": "Event ID",
                    "helper_text": "The ID of the event to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "ID of the event",
                },
                {
                    "field": "event_subject",
                    "type": "string",
                    "helper_text": "Subject of the event",
                },
                {
                    "field": "start_datetime",
                    "type": "timestamp",
                    "helper_text": "Start datetime of the event",
                },
                {
                    "field": "end_datetime",
                    "type": "timestamp",
                    "helper_text": "End datetime of the event",
                },
                {
                    "field": "is_all_day",
                    "type": "bool",
                    "helper_text": "Whether the event is all day",
                },
                {
                    "field": "is_cancelled",
                    "type": "bool",
                    "helper_text": "Whether the event is cancelled",
                },
                {
                    "field": "is_organizer",
                    "type": "bool",
                    "helper_text": "Whether the user is the organizer",
                },
                {
                    "field": "is_reminder_on",
                    "type": "bool",
                    "helper_text": "Whether reminder is enabled",
                },
                {
                    "field": "reminder_minutes",
                    "type": "string",
                    "helper_text": "Minutes before event for reminder",
                },
                {
                    "field": "has_attachments",
                    "type": "bool",
                    "helper_text": "Whether the event has attachments",
                },
                {
                    "field": "importance",
                    "type": "string",
                    "helper_text": "Importance level of the event",
                },
                {
                    "field": "sensitivity",
                    "type": "string",
                    "helper_text": "Sensitivity level of the event",
                },
                {
                    "field": "show_as",
                    "type": "string",
                    "helper_text": "How the time slot is shown",
                },
                {
                    "field": "response_requested",
                    "type": "bool",
                    "helper_text": "Whether responses are requested",
                },
                {
                    "field": "allow_new_time_proposals",
                    "type": "bool",
                    "helper_text": "Whether new time proposals are allowed",
                },
                {
                    "field": "hide_attendees",
                    "type": "bool",
                    "helper_text": "Whether attendees are hidden",
                },
                {
                    "field": "is_online_meeting",
                    "type": "bool",
                    "helper_text": "Whether this is an online meeting",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "Location of the event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the event",
                },
                {
                    "field": "description_preview",
                    "type": "string",
                    "helper_text": "Preview of the description",
                },
                {
                    "field": "categories",
                    "type": "vec<string>",
                    "helper_text": "Categories assigned to the event",
                },
                {
                    "field": "organizer_email",
                    "type": "string",
                    "helper_text": "Email of the event organizer",
                },
                {
                    "field": "organizer_name",
                    "type": "string",
                    "helper_text": "Name of the event organizer",
                },
                {
                    "field": "attendees",
                    "type": "string",
                    "helper_text": "List of attendees in JSON format",
                },
                {
                    "field": "attendee_emails",
                    "type": "vec<string>",
                    "helper_text": "List of attendee email addresses",
                },
                {
                    "field": "online_meeting_url",
                    "type": "string",
                    "helper_text": "Online meeting URL if applicable",
                },
                {
                    "field": "is_recurring",
                    "type": "bool",
                    "helper_text": "Whether the event is recurring",
                },
                {
                    "field": "recurrence_type",
                    "type": "string",
                    "helper_text": "Type of recurrence if applicable",
                },
                {
                    "field": "recurrence_interval",
                    "type": "string",
                    "helper_text": "Recurrence interval if applicable",
                },
                {
                    "field": "created_datetime",
                    "type": "timestamp",
                    "helper_text": "When the event was created",
                },
                {
                    "field": "last_modified_datetime",
                    "type": "timestamp",
                    "helper_text": "When the event was last modified",
                },
                {
                    "field": "web_link",
                    "type": "string",
                    "helper_text": "Web link to the event",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_event",
            "task_name": "tasks.microsoft_calendar.get_event",
            "description": "Get a specific event",
            "label": "Get Event",
            "required": ["calendar_id", "event_id"],
            "inputs_sort_order": [
                "event_id",
                "integration",
                "action",
                "calendar_id",
                "event_id",
            ],
        },
        "list_events**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar to list events from",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "from_all_calendars",
                    "type": "bool",
                    "value": False,
                    "label": "From All Calendars",
                    "helper_text": "Whether to list events from all calendars",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "subject_contains",
                    "type": "string",
                    "value": "",
                    "label": "Subject Contains",
                    "placeholder": "Meeting",
                    "helper_text": "Filter events by subject containing this text",
                },
                {
                    "field": "location_contains",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "Conference Room",
                    "helper_text": "Filter events by location",
                },
                {
                    "field": "importance",
                    "type": "string",
                    "value": "",
                    "label": "Importance",
                    "helper_text": "Filter by importance level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": ""},
                            {"label": "Low", "value": "low"},
                            {"label": "Normal", "value": "normal"},
                            {"label": "High", "value": "high"},
                        ],
                    },
                },
                {
                    "field": "sensitivity",
                    "type": "string",
                    "value": "",
                    "label": "Sensitivity",
                    "helper_text": "Filter by sensitivity level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": ""},
                            {"label": "Normal", "value": "normal"},
                            {"label": "Personal", "value": "personal"},
                            {"label": "Private", "value": "private"},
                            {"label": "Confidential", "value": "confidential"},
                        ],
                    },
                },
                {
                    "field": "show_as",
                    "type": "string",
                    "value": "",
                    "label": "Show As",
                    "helper_text": "Filter by show as status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": ""},
                            {"label": "Free", "value": "free"},
                            {"label": "Tentative", "value": "tentative"},
                            {"label": "Busy", "value": "busy"},
                            {"label": "Out of Office", "value": "out_of_office"},
                            {
                                "label": "Working Elsewhere",
                                "value": "working_elsewhere",
                            },
                        ],
                    },
                },
                {
                    "field": "is_all_day",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "label": "All Day Only",
                    "helper_text": "Filter for all-day events only",
                },
                {
                    "field": "has_attachments",
                    "type": "bool",
                    "value": False,
                    "hidden": True,
                    "label": "Has Attachments",
                    "helper_text": "Filter for events with attachments",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "start/dateTime",
                    "label": "Order By",
                    "placeholder": "start/dateTime",
                    "helper_text": "Field to order results by",
                },
            ],
            "outputs": [
                {
                    "field": "events",
                    "type": "string",
                    "helper_text": "List of events in JSON format",
                },
                {
                    "field": "event_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of event subjects",
                },
                {
                    "field": "event_ids",
                    "type": "vec<string>",
                    "helper_text": "List of event IDs",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total number of events retrieved",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether there are more events available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_events",
            "task_name": "tasks.microsoft_calendar.list_events",
            "description": "List events from Microsoft Calendar",
            "label": "List Events",
            "ui_sort_order": [
                "integration",
                "action",
                "calendar_id",
                "from_all_calendars",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "limit",
                "subject_contains",
                "location_contains",
                "importance",
                "sensitivity",
                "show_as",
                "is_all_day",
                "has_attachments",
                "order_by",
            ],
            "required": ["num_messages"],
        },
        "list_events**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Events",
                    "helper_text": "Specify the number of events to fetch",
                }
            ],
            "outputs": [],
        },
        "list_events**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_events**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_events**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "update_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar containing the event",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "value": "",
                    "label": "Event ID",
                    "placeholder": "Event ID",
                    "helper_text": "The ID of the event to update",
                },
                {
                    "field": "event_subject",
                    "type": "string",
                    "value": "",
                    "label": "Event Subject",
                    "placeholder": "Updated meeting title",
                    "helper_text": "New subject/title of the event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Updated event description",
                    "helper_text": "New description/body of the event",
                },
                {
                    "field": "start_datetime",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start DateTime",
                    "placeholder": "2024-06-24T19:00:00-05:00",
                    "helper_text": "New start time of the event (RFC3339 format)",
                    "agent_helper_text": "If the user specifies a timezone, include the UTC offset in the datetime (e.g., 2024-06-24T19:00:00-05:00 for US/Eastern, 2024-06-24T19:00:00+05:30 for Asia/Kolkata). If no timezone is mentioned, omit the offset.",
                },
                {
                    "field": "end_datetime",
                    "type": "timestamp",
                    "value": -1,
                    "label": "End DateTime",
                    "placeholder": "2024-06-24T20:00:00",
                    "helper_text": "New end time of the event (RFC3339 format)",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "New meeting location",
                    "helper_text": "New location of the event",
                },
                {
                    "field": "is_all_day",
                    "type": "bool",
                    "value": False,
                    "label": "All Day Event",
                    "helper_text": "Whether this is an all-day event",
                },
                {
                    "field": "attendees",
                    "type": "string",
                    "value": "",
                    "label": "Attendees",
                    "placeholder": "email1@example.com,email2@example.com",
                    "helper_text": "New comma-separated list of attendee email addresses",
                },
                {
                    "field": "is_reminder_on",
                    "type": "bool",
                    "value": True,
                    "label": "Reminder On",
                    "helper_text": "Whether to enable reminder",
                },
                {
                    "field": "reminder_minutes",
                    "type": "int32",
                    "value": 15,
                    "label": "Reminder Minutes",
                    "helper_text": "Minutes before event to send reminder",
                },
                {
                    "field": "importance",
                    "type": "string",
                    "value": "",
                    "label": "Importance",
                    "helper_text": "New importance level of the event",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Low", "value": "low"},
                            {"label": "Normal", "value": "normal"},
                            {"label": "High", "value": "high"},
                        ],
                    },
                },
                {
                    "field": "sensitivity",
                    "type": "string",
                    "value": "",
                    "label": "Sensitivity",
                    "helper_text": "New sensitivity level of the event",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Normal", "value": "normal"},
                            {"label": "Personal", "value": "personal"},
                            {"label": "Private", "value": "private"},
                            {"label": "Confidential", "value": "confidential"},
                        ],
                    },
                },
                {
                    "field": "show_as",
                    "type": "string",
                    "value": "",
                    "label": "Show As",
                    "helper_text": "How to show the time slot",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Free", "value": "free"},
                            {"label": "Tentative", "value": "tentative"},
                            {"label": "Busy", "value": "busy"},
                            {"label": "Out of Office", "value": "out_of_office"},
                            {
                                "label": "Working Elsewhere",
                                "value": "working_elsewhere",
                            },
                        ],
                    },
                },
                {
                    "field": "categories",
                    "type": "string",
                    "value": "",
                    "label": "Categories",
                    "placeholder": "Category1, Category2",
                    "helper_text": "New comma-separated list of categories",
                },
            ],
            "outputs": [
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "ID of the updated event",
                },
                {
                    "field": "event_subject",
                    "type": "string",
                    "helper_text": "Subject of the updated event",
                },
                {
                    "field": "start_datetime",
                    "type": "timestamp",
                    "helper_text": "Start datetime of the updated event",
                },
                {
                    "field": "end_datetime",
                    "type": "timestamp",
                    "helper_text": "End datetime of the updated event",
                },
                {
                    "field": "is_all_day",
                    "type": "bool",
                    "helper_text": "Whether the event is all day",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "Location of the updated event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the updated event",
                },
                {
                    "field": "web_link",
                    "type": "string",
                    "helper_text": "Web link to the updated event",
                },
                {
                    "field": "online_meeting_url",
                    "type": "string",
                    "helper_text": "Online meeting URL if applicable",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_event",
            "task_name": "tasks.microsoft_calendar.update_event",
            "description": "Update an event",
            "label": "Update Event",
            "required": ["calendar_id", "event_id"],
            "inputs_sort_order": [
                "event_id",
                "integration",
                "action",
                "calendar_id",
                "event_id",
                "event_subject",
                "description",
                "start_datetime",
                "end_datetime",
                "location",
                "is_all_day",
                "attendees",
                "is_reminder_on",
                "reminder_minutes",
                "importance",
                "sensitivity",
                "show_as",
                "categories",
            ],
        },
        "delete_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar_id",
                    "type": "string",
                    "value": "",
                    "label": "Calendar ID",
                    "placeholder": "Calendar ID",
                    "helper_text": "The ID of the calendar containing the event",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "value": "",
                    "label": "Event ID",
                    "placeholder": "Event ID",
                    "helper_text": "The ID of the event to delete",
                },
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Success message"}
            ],
            "variant": "common_integration_nodes",
            "name": "delete_event",
            "task_name": "tasks.microsoft_calendar.delete_event",
            "description": "Delete an event",
            "label": "Delete Event",
            "required": ["calendar_id", "event_id"],
            "inputs_sort_order": [
                "event_id",
                "integration",
                "action",
                "calendar_id",
                "event_id",
            ],
        },
        "get_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_identifier",
                    "type": "string",
                    "value": "",
                    "label": "User ID or Email",
                    "placeholder": "user@company.com or user-id",
                    "helper_text": "The user's ID or organizational email (work/school accounts only, not personal @outlook.com/@hotmail.com)",
                }
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "The unique ID of the user",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "The user's display name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "The user's email address",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "helper_text": "The user's job title",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "helper_text": "The user's mobile phone number",
                },
                {
                    "field": "office_location",
                    "type": "string",
                    "helper_text": "The user's office location",
                },
                {
                    "field": "user_principal_name",
                    "type": "string",
                    "helper_text": "The primary sign-in name for the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.microsoft_calendar.get_user",
            "description": "Get details of a user from the organization directory",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "required": ["user_identifier"],
            "inputs_sort_order": ["integration", "action", "user_identifier"],
        },
        "list_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of users to retrieve",
                },
                {
                    "field": "search",
                    "type": "string",
                    "value": "",
                    "label": "Search",
                    "placeholder": "John",
                    "helper_text": "Search users by display name or email",
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user display names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user email addresses",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of users returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "list_users",
            "task_name": "tasks.microsoft_calendar.list_users",
            "description": "List users from the organization directory",
            "label": "List Users",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": ["integration", "action", "limit", "search"],
        },
        "list_people**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of people to retrieve",
                },
                {
                    "field": "search",
                    "type": "string",
                    "value": "",
                    "label": "Search",
                    "placeholder": "John",
                    "helper_text": "Fuzzy search people by name or email (e.g. a name or email address).",
                },
                {
                    "field": "filter_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "personType/class eq 'Person'",
                    "helper_text": "Filter by person type. Examples: personType/class eq 'Person' (individuals), personType/class eq 'Group' (groups), personType/subclass eq 'OrganizationUser' (org members), personType/subclass eq 'PersonalContact' (personal contacts).",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "placeholder": "displayName",
                    "helper_text": "Field to sort results by (e.g. displayName). By default results are sorted by relevance.",
                },
            ],
            "outputs": [
                {
                    "field": "person_ids",
                    "type": "vec<string>",
                    "helper_text": "List of person IDs",
                },
                {
                    "field": "person_names",
                    "type": "vec<string>",
                    "helper_text": "List of person display names",
                },
                {
                    "field": "person_emails",
                    "type": "vec<string>",
                    "helper_text": "List of person email addresses",
                },
                {
                    "field": "person_departments",
                    "type": "vec<string>",
                    "helper_text": "List of person departments",
                },
                {
                    "field": "person_job_titles",
                    "type": "vec<string>",
                    "helper_text": "List of person job titles",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of people returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from Microsoft Graph API",
                },
            ],
            "name": "list_people",
            "task_name": "tasks.microsoft_calendar.list_people",
            "description": "List people relevant to the signed-in user based on communication patterns",
            "label": "List People",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "limit",
                "search",
                "filter_query",
                "order_by",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "event_id", "limit", "num_messages"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        activity_domain: str = "work",
        all_day_event: bool = False,
        allow_new_time_proposals: bool = False,
        attendee_emails: List[str] = [],
        attendee_types: List[str] = [],
        attendees: str = "",
        body: str = "",
        calendar: str = "",
        calendar_id: str = "",
        calendar_name: str = "",
        categories: str = "",
        color: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        description: str = "",
        duration: int = 30,
        end_date_and_time: Any = None,
        end_datetime: Any = -1,
        event_id: str = "",
        event_subject: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        filter_query: str = "",
        from_all_calendars: bool = False,
        has_attachments: bool = False,
        hide_attendees: bool = False,
        importance: str = "normal",
        is_all_day: bool = False,
        is_location_required: bool = False,
        is_online_meeting: bool = False,
        is_organizer_optional: bool = False,
        is_reminder_on: bool = True,
        limit: int = 10,
        location: str = "",
        location_contains: str = "",
        location_names: List[str] = [],
        max_suggestions: int = 20,
        meeting_duration: str = "60",
        minimum_attendee_percentage: int = 100,
        num_messages: int = 10,
        online_meeting_provider: str = "teamsForBusiness",
        order_by: str = "name",
        reminder_minutes: int = 15,
        response_requested: bool = True,
        search: str = "",
        sensitivity: str = "normal",
        show_as: str = "busy",
        slot_duration: int = None,
        start_date_and_time: Any = None,
        start_datetime: Any = -1,
        subject: str = "",
        subject_contains: str = "",
        suggest_location: bool = False,
        timezone: str = "US/Eastern",
        user_identifier: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_microsoft_calendar",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if calendar_name is not None:
            self.inputs["calendar_name"] = calendar_name
        if color is not None:
            self.inputs["color"] = color
        if calendar_id is not None:
            self.inputs["calendar_id"] = calendar_id
        if limit is not None:
            self.inputs["limit"] = limit
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if filter_query is not None:
            self.inputs["filter_query"] = filter_query
        if calendar is not None:
            self.inputs["calendar"] = calendar
        if subject is not None:
            self.inputs["subject"] = subject
        if body is not None:
            self.inputs["body"] = body
        if start_datetime is not None:
            self.inputs["start_datetime"] = start_datetime
        if duration is not None:
            self.inputs["duration"] = duration
        if all_day_event is not None:
            self.inputs["all_day_event"] = all_day_event
        if location is not None:
            self.inputs["location"] = location
        if attendees is not None:
            self.inputs["attendees"] = attendees
        if is_reminder_on is not None:
            self.inputs["is_reminder_on"] = is_reminder_on
        if reminder_minutes is not None:
            self.inputs["reminder_minutes"] = reminder_minutes
        if importance is not None:
            self.inputs["importance"] = importance
        if sensitivity is not None:
            self.inputs["sensitivity"] = sensitivity
        if show_as is not None:
            self.inputs["show_as"] = show_as
        if categories is not None:
            self.inputs["categories"] = categories
        if is_online_meeting is not None:
            self.inputs["is_online_meeting"] = is_online_meeting
        if online_meeting_provider is not None:
            self.inputs["online_meeting_provider"] = online_meeting_provider
        if hide_attendees is not None:
            self.inputs["hide_attendees"] = hide_attendees
        if response_requested is not None:
            self.inputs["response_requested"] = response_requested
        if allow_new_time_proposals is not None:
            self.inputs["allow_new_time_proposals"] = allow_new_time_proposals
        if start_date_and_time is not None:
            self.inputs["start_date_and_time"] = start_date_and_time
        if end_date_and_time is not None:
            self.inputs["end_date_and_time"] = end_date_and_time
        if slot_duration is not None:
            self.inputs["slot_duration"] = slot_duration
        if timezone is not None:
            self.inputs["timezone"] = timezone
        if attendee_emails is not None:
            self.inputs["attendee_emails"] = attendee_emails
        if attendee_types is not None:
            self.inputs["attendee_types"] = attendee_types
        if meeting_duration is not None:
            self.inputs["meeting_duration"] = meeting_duration
        if minimum_attendee_percentage is not None:
            self.inputs["minimum_attendee_percentage"] = minimum_attendee_percentage
        if max_suggestions is not None:
            self.inputs["max_suggestions"] = max_suggestions
        if is_organizer_optional is not None:
            self.inputs["is_organizer_optional"] = is_organizer_optional
        if activity_domain is not None:
            self.inputs["activity_domain"] = activity_domain
        if location_names is not None:
            self.inputs["location_names"] = location_names
        if is_location_required is not None:
            self.inputs["is_location_required"] = is_location_required
        if suggest_location is not None:
            self.inputs["suggest_location"] = suggest_location
        if event_id is not None:
            self.inputs["event_id"] = event_id
        if from_all_calendars is not None:
            self.inputs["from_all_calendars"] = from_all_calendars
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if subject_contains is not None:
            self.inputs["subject_contains"] = subject_contains
        if location_contains is not None:
            self.inputs["location_contains"] = location_contains
        if is_all_day is not None:
            self.inputs["is_all_day"] = is_all_day
        if has_attachments is not None:
            self.inputs["has_attachments"] = has_attachments
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if event_subject is not None:
            self.inputs["event_subject"] = event_subject
        if description is not None:
            self.inputs["description"] = description
        if end_datetime is not None:
            self.inputs["end_datetime"] = end_datetime
        if user_identifier is not None:
            self.inputs["user_identifier"] = user_identifier
        if search is not None:
            self.inputs["search"] = search
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMicrosoftCalendarNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
