"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import FindReplace


@Node.register_node_type("find_and_replace")
class FindAndReplaceNode(Node):
    """
    Find and replace words in a given text

    ## Inputs
    ### Common Inputs
        replacements: The replacements input
        text_to_manipulate: The text to find and replace words in

    ## Outputs
    ### Common Outputs
        processed_text: The final text with found words replaced
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "replacements",
            "helper_text": "The replacements input",
            "value": [],
            "type": "vec<interface{id: string, find: string, replace: string}>",
        },
        {
            "field": "text_to_manipulate",
            "helper_text": "The text to find and replace words in",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "processed_text",
            "helper_text": "The final text with found words replaced",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text_to_manipulate"]

    def __init__(
        self,
        replacements: List[FindReplace] = [],
        text_to_manipulate: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="find_and_replace",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if text_to_manipulate is not None:
            self.inputs["text_to_manipulate"] = text_to_manipulate
        if replacements is not None:
            self.inputs["replacements"] = replacements
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "FindAndReplaceNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
