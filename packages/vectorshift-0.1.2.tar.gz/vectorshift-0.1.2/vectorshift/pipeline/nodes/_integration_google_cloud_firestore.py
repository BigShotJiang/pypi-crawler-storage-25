"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_cloud_firestore")
class IntegrationGoogleCloudFirestoreNode(Node):
    """
    Google Cloud Firestore

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### query_documents
        query: Firestore query in JSON format
        database: The Firestore database name. Leave as (default) for the default database
        project_id: The Google Cloud project ID
    ### create_document
        collection: The collection name where the document will be created
        database: The Firestore database name. Leave as (default) for the default database
        document_id: Optional document ID. If not provided, Firestore will generate one automatically
        fields: JSON object containing the document fields
        project_id: The Google Cloud project ID
    ### upsert_document
        collection: The collection name where the document will be created
        database: The Firestore database name. Leave as (default) for the default database
        fields: JSON object containing the document fields
        project_id: The Google Cloud project ID
        update_key: The field name in the document that contains the document ID
    ### delete_document
        collection: The collection name where the document will be created
        database: The Firestore database name. Leave as (default) for the default database
        document_id: Optional document ID. If not provided, Firestore will generate one automatically
        project_id: The Google Cloud project ID
    ### read_document
        collection: The collection name where the document will be created
        database: The Firestore database name. Leave as (default) for the default database
        document_id: Optional document ID. If not provided, Firestore will generate one automatically
        project_id: The Google Cloud project ID
    ### get_documents
        collection: The collection name where the document will be created
        database: The Firestore database name. Leave as (default) for the default database
        limit: Maximum number of documents to retrieve
        project_id: The Google Cloud project ID
    ### get_collections
        database: The Firestore database name. Leave as (default) for the default database
        limit: Maximum number of documents to retrieve
        project_id: The Google Cloud project ID

    ## Outputs
    ### get_collections
        collection_count: Number of collections retrieved
        collection_ids: List of collection IDs
        collections: Array of collection information in JSON format
        raw_data: The raw data returned from the API
    ### create_document
        create_time: Timestamp when the document was created
        document_id: The ID of the created document
        document_name: The full resource name of the created document
        fields: The document fields in JSON format
        raw_data: The raw data returned from the API
        update_time: Timestamp when the document was last updated
    ### read_document
        create_time: Timestamp when the document was created
        document_id: The ID of the document
        document_name: The full resource name of the document
        fields: The document fields in JSON format
        raw_data: The raw data returned from the API
        update_time: Timestamp when the document was last updated
    ### get_documents
        create_times: List of timestamps when the documents were created
        document_count: Number of documents retrieved
        document_ids: List of document IDs
        document_names: List of document names
        documents: Array of documents in JSON format
        raw_data: The raw data returned from the API
        update_times: List of timestamps when the documents were last updated
    ### query_documents
        create_times: List of timestamps when the documents were created
        document_count: Number of documents that match the query
        document_ids: List of matching document IDs
        document_names: List of document names
        documents: Array of matching documents in JSON format
        raw_data: The raw data returned from the API
        update_times: List of timestamps when the documents were last updated
    ### delete_document
        deleted_at: Timestamp when the document was deleted
        document_id: The ID of the deleted document
        raw_data: The raw data returned from the API
    ### upsert_document
        document_id: The ID of the upserted document
        fields: The document fields in JSON format
        raw_data: The raw data returned from the API
        update_time: Timestamp when the document was last updated
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Cloud Firestore>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_document": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "placeholder": "users",
                    "helper_text": "The collection name where the document will be created",
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "user123",
                    "helper_text": "Optional document ID. If not provided, Firestore will generate one automatically",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Document Fields",
                    "placeholder": '{"name": "John Doe", "age": 30}',
                    "helper_text": "JSON object containing the document fields",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "The ID of the created document",
                },
                {
                    "field": "document_name",
                    "type": "string",
                    "helper_text": "The full resource name of the created document",
                },
                {
                    "field": "create_time",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the document was created",
                },
                {
                    "field": "update_time",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the document was last updated",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "The document fields in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "create_document",
            "task_name": "tasks.google_cloud_firestore.create_document",
            "description": "Create a new document in Google Cloud Firestore",
            "label": "Create Document",
            "input_sort_order": [
                "integration",
                "action",
                "project_id",
                "collection",
                "fields",
            ],
        },
        "upsert_document": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "placeholder": "users",
                    "helper_text": "The collection name where the document exists or will be created",
                },
                {
                    "field": "update_key",
                    "type": "string",
                    "value": "",
                    "label": "Update Key",
                    "placeholder": "user_id",
                    "helper_text": "The field name in the document that contains the document ID",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Document Fields",
                    "placeholder": '{"user_id": "user123", "name": "John Doe", "age": 30}',
                    "helper_text": "JSON object containing the document fields. Must include the update key field",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "The ID of the upserted document",
                },
                {
                    "field": "update_time",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the document was last updated",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "The document fields in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "upsert_document",
            "task_name": "tasks.google_cloud_firestore.upsert_document",
            "description": "Update an existing document or create it if it doesn't exist",
            "label": "Create or Update Document",
            "input_sort_order": [
                "integration",
                "action",
                "project_id",
                "collection",
                "update_key",
                "fields",
            ],
        },
        "delete_document": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "placeholder": "users",
                    "helper_text": "The collection name containing the document to delete",
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "user123",
                    "helper_text": "The ID of the document to delete",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "The ID of the deleted document",
                },
                {
                    "field": "deleted_at",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the document was deleted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "delete_document",
            "task_name": "tasks.google_cloud_firestore.delete_document",
            "description": "Delete a document from Google Cloud Firestore",
            "label": "Delete Document",
            "input_sort_order": [
                "integration",
                "action",
                "project_id",
                "collection",
                "document_id",
            ],
            "required": ["document_id"],
        },
        "read_document": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "placeholder": "users",
                    "helper_text": "The collection name containing the document to read",
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "value": "",
                    "label": "Document ID",
                    "placeholder": "user123",
                    "helper_text": "The ID of the document to read",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "The ID of the document",
                },
                {
                    "field": "document_name",
                    "type": "string",
                    "helper_text": "The full resource name of the document",
                },
                {
                    "field": "create_time",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the document was created",
                },
                {
                    "field": "update_time",
                    "type": "timestamp",
                    "helper_text": "Timestamp when the document was last updated",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "The document fields in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "read_document",
            "task_name": "tasks.google_cloud_firestore.read_document",
            "description": "Read details of a specific document",
            "label": "Get Document",
            "input_sort_order": [
                "integration",
                "action",
                "project_id",
                "collection",
                "document_id",
            ],
            "required": ["document_id"],
        },
        "get_documents": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "placeholder": "users",
                    "helper_text": "The collection name to retrieve documents from",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of documents to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "documents",
                    "type": "string",
                    "helper_text": "Array of documents in JSON format",
                },
                {
                    "field": "document_ids",
                    "type": "vec<string>",
                    "helper_text": "List of document IDs",
                },
                {
                    "field": "document_names",
                    "type": "vec<string>",
                    "helper_text": "List of document names",
                },
                {
                    "field": "create_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of timestamps when the documents were created",
                },
                {
                    "field": "update_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of timestamps when the documents were last updated",
                },
                {
                    "field": "document_count",
                    "type": "int32",
                    "helper_text": "Number of documents retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "get_documents",
            "task_name": "tasks.google_cloud_firestore.get_documents",
            "description": "Get multiple documents",
            "label": "List Documents",
            "input_sort_order": [
                "integration",
                "action",
                "project_id",
                "collection",
                "limit",
            ],
        },
        "query_documents": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query JSON",
                    "placeholder": '{"from":[{"collectionId":"users"}]}',
                    "helper_text": "Firestore query in JSON format",
                },
            ],
            "outputs": [
                {
                    "field": "documents",
                    "type": "string",
                    "helper_text": "Array of matching documents in JSON format",
                },
                {
                    "field": "document_ids",
                    "type": "vec<string>",
                    "helper_text": "List of matching document IDs",
                },
                {
                    "field": "document_names",
                    "type": "vec<string>",
                    "helper_text": "List of document names",
                },
                {
                    "field": "create_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of timestamps when the documents were created",
                },
                {
                    "field": "update_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of timestamps when the documents were last updated",
                },
                {
                    "field": "document_count",
                    "type": "int32",
                    "helper_text": "Number of documents that match the query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "query_documents",
            "task_name": "tasks.google_cloud_firestore.query_documents",
            "description": "Query documents using Firestore structured query",
            "label": "Query Documents",
            "input_sort_order": ["integration", "action", "project_id", "query"],
        },
        "get_collections": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "my-project-123",
                    "helper_text": "The Google Cloud project ID",
                },
                {
                    "field": "database",
                    "type": "string",
                    "value": "(default)",
                    "label": "Database",
                    "placeholder": "(default)",
                    "helper_text": "The Firestore database name. Leave as (default) for the default database",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of collections to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "collections",
                    "type": "string",
                    "helper_text": "Array of collection information in JSON format",
                },
                {
                    "field": "collection_ids",
                    "type": "vec<string>",
                    "helper_text": "List of collection IDs",
                },
                {
                    "field": "collection_count",
                    "type": "int32",
                    "helper_text": "Number of collections retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw data returned from the API",
                },
            ],
            "name": "get_collections",
            "task_name": "tasks.google_cloud_firestore.get_collections",
            "description": "Get multiple collections",
            "label": "List Collections",
            "input_sort_order": ["integration", "action", "project_id", "limit"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "project_id",
        "database",
        "collection",
        "fields",
        "update_key",
        "limit",
        "query",
    ]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        collection: str = "",
        database: str = "(default)",
        document_id: str = "",
        fields: str = "",
        limit: int = 10,
        project_id: str = "",
        update_key: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_cloud_firestore",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if project_id is not None:
            self.inputs["project_id"] = project_id
        if database is not None:
            self.inputs["database"] = database
        if collection is not None:
            self.inputs["collection"] = collection
        if document_id is not None:
            self.inputs["document_id"] = document_id
        if fields is not None:
            self.inputs["fields"] = fields
        if update_key is not None:
            self.inputs["update_key"] = update_key
        if limit is not None:
            self.inputs["limit"] = limit
        if query is not None:
            self.inputs["query"] = query
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleCloudFirestoreNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
