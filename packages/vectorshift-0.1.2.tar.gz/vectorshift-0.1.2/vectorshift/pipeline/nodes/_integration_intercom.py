"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_intercom")
class IntegrationIntercomNode(Node):
    """
    Intercom

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Intercom account
    ### create_lead
        avatar: URL of the lead's avatar image
        companies: Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)
        custom_attributes: Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)
        email: The email address of the lead
        name: The name of the company
        phone: The phone number of the lead
        unsubscribed_from_emails: Whether the lead has unsubscribed from emails
        update_last_request_at: Whether to update the last request timestamp
        utm_campaign: UTM campaign parameter
        utm_content: UTM content parameter
        utm_medium: UTM medium parameter
        utm_source: UTM source parameter
        utm_term: UTM term parameter
    ### update_lead
        avatar: URL of the lead's avatar image
        companies: Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)
        custom_attributes: Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)
        email: The email address of the lead
        name: The name of the company
        phone: The phone number of the lead
        unsubscribed_from_emails: Whether the lead has unsubscribed from emails
        update_by: How to identify the lead to update
        update_last_request_at: Whether to update the last request timestamp
        utm_campaign: UTM campaign parameter
        utm_content: UTM content parameter
        utm_medium: UTM medium parameter
        utm_source: UTM source parameter
        utm_term: UTM term parameter
        value: The value to search for based on the selected field
    ### create_user
        avatar: URL of the lead's avatar image
        companies: Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)
        custom_attributes: Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)
        id_value: The email or user ID for the user
        identifier_type: How to identify the user
        name: The name of the company
        phone: The phone number of the lead
        session_count: Number of sessions the user has had
        unsubscribed_from_emails: Whether the lead has unsubscribed from emails
        update_last_request_at: Whether to update the last request timestamp
        utm_campaign: UTM campaign parameter
        utm_content: UTM content parameter
        utm_medium: UTM medium parameter
        utm_source: UTM source parameter
        utm_term: UTM term parameter
    ### update_user
        avatar: URL of the lead's avatar image
        companies: Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)
        custom_attributes: Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)
        email: The email address of the lead
        name: The name of the company
        phone: The phone number of the lead
        session_count: Number of sessions the user has had
        unsubscribed_from_emails: Whether the lead has unsubscribed from emails
        update_by: How to identify the lead to update
        update_last_request_at: Whether to update the last request timestamp
        utm_campaign: UTM campaign parameter
        utm_content: UTM content parameter
        utm_medium: UTM medium parameter
        utm_source: UTM source parameter
        utm_term: UTM term parameter
        value: The value to search for based on the selected field
    ### create_company
        company_id: The unique identifier for the company in your system
        custom_attributes: Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)
        industry: The industry the company operates in
        monthly_spend: The monthly revenue from this company
        name: The name of the company
        plan: The name of the plan the company is on
        size: The number of employees
        website: The company's website URL
    ### update_company
        company_id: The unique identifier for the company in your system
        custom_attributes: Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)
        industry: The industry the company operates in
        monthly_spend: The monthly revenue from this company
        name: The name of the company
        plan: The name of the plan the company is on
        size: The number of employees
        website: The company's website URL
    ### list_users
        company_id: The unique identifier for the company in your system
        email: The email address of the lead
        limit: Maximum number of companies to retrieve
        segment_id: Filter by segment ID (optional)
        tag_id: Filter by tag ID (optional)
    ### delete_lead
        delete_by: How to identify the lead to delete
        value: The value to search for based on the selected field
    ### list_leads
        email: The email address of the lead
        limit: Maximum number of companies to retrieve
        phone: The phone number of the lead
    ### delete_user
        id: The ID of the user to delete
    ### list_companies
        limit: Maximum number of companies to retrieve
        segment_id: Filter by segment ID (optional)
        tag_id: Filter by tag ID (optional)
    ### list_company_users
        limit: Maximum number of companies to retrieve
        list_by: How to identify the company
        value: The value to search for based on the selected field
    ### get_company
        select_by: How to identify the company
        value: The value to search for based on the selected field
    ### get_lead
        select_by: How to identify the company
        value: The value to search for based on the selected field
    ### get_user
        select_by: How to identify the company
        value: The value to search for based on the selected field

    ## Outputs
    ### create_company
        app_id: Intercom app ID
        company_id: Custom company ID
        company_name: Name of the created company
        created_at: When the company was created
        custom_attributes: Custom attributes of the company (JSON)
        id: Intercom internal ID of the company
        industry: Industry of the company
        last_request_at: When the company last made a request
        monthly_spend: Monthly spend of the company
        plan: Plan the company is on
        raw_data: Raw API response data
        remote_created_at: When the company was created in remote system
        session_count: Number of sessions from the company
        size: Size of the company
        updated_at: When the company was last updated
        user_count: Number of users in the company
        website: Company website URL
    ### get_company
        app_id: Intercom app ID
        company_id: Custom company ID
        company_name: Name of the company
        created_at: When the company was created
        custom_attributes: Custom attributes of the company (JSON)
        id: Intercom internal ID of the company
        industry: Industry of the company
        last_request_at: When the company last made a request
        monthly_spend: Monthly spend of the company
        plan: Plan the company is on
        raw_data: Raw API response data
        remote_created_at: When the company was created in remote system
        session_count: Number of sessions from the company
        size: Size of the company
        updated_at: When the company was last updated
        user_count: Number of users in the company
        website: Company website URL
    ### update_company
        app_id: Intercom app ID
        company_id: Custom company ID
        company_name: Name of the updated company
        created_at: When the company was created
        custom_attributes: Custom attributes of the company (JSON)
        id: Intercom internal ID of the company
        industry: Industry of the company
        last_request_at: When the company last made a request
        monthly_spend: Monthly spend of the company
        plan: Plan the company is on
        raw_data: Raw API response data
        remote_created_at: When the company was created in remote system
        session_count: Number of sessions from the company
        size: Size of the company
        updated_at: When the company was last updated
        user_count: Number of users in the company
        website: Company website URL
    ### list_companies
        app_ids: List of Intercom app IDs
        company_ids: List of custom company IDs
        company_names: List of company names
        created_ats: List of creation timestamps
        custom_attributes: List of custom attributes (JSON strings)
        ids: List of Intercom internal IDs
        industries: List of company industries
        last_request_ats: List of last request timestamps
        monthly_spends: List of monthly spends per company
        plans: List of company plans
        raw_data: Raw API response data
        remote_created_ats: List of remote creation timestamps
        session_counts: List of session counts per company
        sizes: List of company sizes
        updated_ats: List of last update timestamps
        user_counts: List of user counts per company
        websites: List of company websites
    ### create_lead
        browser: Browser used by the lead
        browser_language: Browser language
        company_ids: List of associated company IDs
        created_at: When the lead was created
        custom_attributes: Custom attributes of the lead (JSON)
        email: Email of the lead
        external_id: External ID of the lead (provided by you)
        has_hard_bounced: Whether email has hard bounced
        id: Intercom internal ID of the lead
        last_contacted_at: When the lead was last contacted
        last_email_clicked_at: When the lead last clicked an email
        last_email_opened_at: When the lead last opened an email
        last_replied_at: When the lead last replied
        last_seen_at: When the lead was last seen
        lead_id: External ID of the lead (provided by you)
        lead_name: Name of the created lead
        marked_email_as_spam: Whether email was marked as spam
        os: Operating system
        owner_id: Owner ID of the lead
        phone: Phone number of the lead
        raw_data: Raw API response data
        role: Role of the contact (lead)
        signed_up_at: When the lead signed up
        unsubscribed_from_emails: Whether unsubscribed from emails
        updated_at: When the lead was last updated
        workspace_id: Workspace ID
    ### get_lead
        browser: Browser used by the lead
        browser_language: Browser language
        company_ids: List of associated company IDs
        created_at: When the lead was created
        custom_attributes: Custom attributes of the lead (JSON)
        email: Email of the lead
        external_id: External ID of the lead (provided by you)
        has_hard_bounced: Whether email has hard bounced
        id: Intercom internal ID of the lead
        last_contacted_at: When the lead was last contacted
        last_email_clicked_at: When the lead last clicked an email
        last_email_opened_at: When the lead last opened an email
        last_replied_at: When the lead last replied
        last_seen_at: When the lead was last seen
        lead_id: External ID of the lead (provided by you)
        lead_name: Name of the lead
        marked_email_as_spam: Whether email was marked as spam
        os: Operating system
        owner_id: Owner ID of the lead
        phone: Phone number of the lead
        raw_data: Raw API response data
        role: Role of the contact (lead)
        signed_up_at: When the lead signed up
        unsubscribed_from_emails: Whether unsubscribed from emails
        updated_at: When the lead was last updated
        workspace_id: Workspace ID
    ### update_lead
        browser: Browser used by the lead
        browser_language: Browser language
        company_ids: List of associated company IDs
        created_at: When the lead was created
        custom_attributes: Custom attributes of the lead (JSON)
        email: Email of the lead
        external_id: External ID of the lead (provided by you)
        has_hard_bounced: Whether email has hard bounced
        id: Intercom internal ID of the lead
        last_contacted_at: When the lead was last contacted
        last_email_clicked_at: When the lead last clicked an email
        last_email_opened_at: When the lead last opened an email
        last_replied_at: When the lead last replied
        last_seen_at: When the lead was last seen
        lead_id: External ID of the lead (provided by you)
        lead_name: Name of the updated lead
        marked_email_as_spam: Whether email was marked as spam
        os: Operating system
        owner_id: Owner ID of the lead
        phone: Phone number of the lead
        raw_data: Raw API response data
        role: Role of the contact (lead)
        signed_up_at: When the lead signed up
        unsubscribed_from_emails: Whether unsubscribed from emails
        updated_at: When the lead was last updated
        workspace_id: Workspace ID
    ### create_user
        browser: Browser used by the user
        browser_language: Browser language
        company_ids: List of associated company IDs
        created_at: When the user was created
        custom_attributes: Custom attributes of the user (JSON)
        email: Email of the user
        external_id: External ID of the user (provided by you)
        has_hard_bounced: Whether email has hard bounced
        id: Intercom internal ID of the user
        last_contacted_at: When the user was last contacted
        last_email_clicked_at: When the user last clicked an email
        last_email_opened_at: When the user last opened an email
        last_replied_at: When the user last replied
        last_seen_at: When the user was last seen
        marked_email_as_spam: Whether email was marked as spam
        os: Operating system
        owner_id: Owner ID of the user
        phone: Phone number of the user
        raw_data: Raw API response data
        role: Role of the contact (user)
        session_count: Number of sessions
        signed_up_at: When the user signed up
        unsubscribed_from_emails: Whether unsubscribed from emails
        updated_at: When the user was last updated
        user_id: External ID of the user (provided by you)
        user_name: Name of the created user
        workspace_id: Workspace ID
    ### get_user
        browser: Browser used by the user
        browser_language: Browser language
        company_ids: List of associated company IDs
        created_at: When the user was created
        custom_attributes: Custom attributes of the user (JSON)
        email: Email of the user
        external_id: External ID of the user (provided by you)
        has_hard_bounced: Whether email has hard bounced
        id: Intercom internal ID of the user
        last_contacted_at: When the user was last contacted
        last_email_clicked_at: When the user last clicked an email
        last_email_opened_at: When the user last opened an email
        last_replied_at: When the user last replied
        last_seen_at: When the user was last seen
        marked_email_as_spam: Whether email was marked as spam
        os: Operating system
        owner_id: Owner ID of the user
        phone: Phone number of the user
        raw_data: Raw API response data
        role: Role of the contact (user)
        session_count: Number of sessions
        signed_up_at: When the user signed up
        unsubscribed_from_emails: Whether unsubscribed from emails
        updated_at: When the user was last updated
        user_id: External ID of the user (provided by you)
        user_name: Name of the user
        workspace_id: Workspace ID
    ### update_user
        browser: Browser used by the user
        browser_language: Browser language
        company_ids: List of associated company IDs
        created_at: When the user was created
        custom_attributes: Custom attributes of the user (JSON)
        email: Email of the user
        external_id: External ID of the user (provided by you)
        has_hard_bounced: Whether email has hard bounced
        id: Intercom internal ID of the user
        last_contacted_at: When the user was last contacted
        last_email_clicked_at: When the user last clicked an email
        last_email_opened_at: When the user last opened an email
        last_replied_at: When the user last replied
        last_seen_at: When the user was last seen
        marked_email_as_spam: Whether email was marked as spam
        os: Operating system
        owner_id: Owner ID of the user
        phone: Phone number of the user
        raw_data: Raw API response data
        role: Role of the contact (user)
        session_count: Number of sessions
        signed_up_at: When the user signed up
        unsubscribed_from_emails: Whether unsubscribed from emails
        updated_at: When the user was last updated
        user_id: External ID of the user (provided by you)
        user_name: Name of the updated user
        workspace_id: Workspace ID
    ### list_company_users
        company_ids: List of company IDs for each user
        created_ats: List of creation timestamps
        custom_attributes: List of custom attributes for each user (JSON)
        external_ids: List of external IDs (provided by you)
        ids: List of Intercom internal IDs
        last_seen_ats: List of last seen timestamps
        owner_ids: List of owner IDs
        raw_data: Raw API response data
        session_counts: List of session counts
        updated_ats: List of last update timestamps
        user_emails: List of user emails
        user_ids: List of external IDs (provided by you)
        user_names: List of user names
        user_phones: List of user phone numbers
        workspace_ids: List of workspace IDs
    ### list_leads
        company_ids: List of company IDs for each lead
        created_ats: List of creation timestamps
        custom_attributes: List of custom attributes for each lead (JSON)
        external_ids: List of external IDs (provided by you)
        ids: List of Intercom internal IDs
        last_seen_ats: List of last seen timestamps
        lead_emails: List of lead emails
        lead_ids: List of external IDs (provided by you)
        lead_names: List of lead names
        lead_phones: List of lead phone numbers
        owner_ids: List of owner IDs
        raw_data: Raw API response data
        updated_ats: List of last update timestamps
        workspace_ids: List of workspace IDs
    ### list_users
        company_ids: List of company IDs for each user
        created_ats: List of creation timestamps
        custom_attributes: List of custom attributes for each user (JSON)
        external_ids: List of external IDs (provided by you)
        ids: List of Intercom internal IDs
        last_seen_ats: List of last seen timestamps
        owner_ids: List of owner IDs
        raw_data: Raw API response data
        session_counts: List of session counts
        updated_ats: List of last update timestamps
        user_emails: List of user emails
        user_ids: List of external IDs (provided by you)
        user_names: List of user names
        user_phones: List of user phone numbers
        workspace_ids: List of workspace IDs
    ### delete_lead
        raw_data: Status message
    ### delete_user
        raw_data: Status message
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Intercom account",
            "value": None,
            "type": "integration<Intercom>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_company": {
            "inputs": [
                {
                    "field": "company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company ID",
                    "placeholder": "my-company-123",
                    "helper_text": "The unique identifier for the company in your system",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Inc.",
                    "helper_text": "The name of the company",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                    "helper_text": "The company's website URL",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "The industry the company operates in",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "value": 0,
                    "label": "Company Size",
                    "placeholder": "100",
                    "helper_text": "The number of employees",
                    "disable_conversion": True,
                },
                {
                    "field": "plan",
                    "type": "string",
                    "value": "",
                    "label": "Plan",
                    "placeholder": "Enterprise",
                    "helper_text": "The name of the plan the company is on",
                },
                {
                    "field": "monthly_spend",
                    "type": "int32",
                    "value": 0,
                    "label": "Monthly Spend",
                    "placeholder": "5000",
                    "helper_text": "The monthly revenue from this company",
                    "disable_conversion": True,
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "value": "",
                    "label": "Custom Attributes",
                    "placeholder": "key1:value1,key2:value2",
                    "helper_text": "Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the company",
                },
                {"field": "app_id", "type": "string", "helper_text": "Intercom app ID"},
                {
                    "field": "company_id",
                    "type": "string",
                    "helper_text": "Custom company ID",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "Name of the created company",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the company was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the company was last updated",
                },
                {
                    "field": "user_count",
                    "type": "int32",
                    "helper_text": "Number of users in the company",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "helper_text": "Number of sessions from the company",
                },
                {
                    "field": "monthly_spend",
                    "type": "int32",
                    "helper_text": "Monthly spend of the company",
                },
                {
                    "field": "plan",
                    "type": "string",
                    "helper_text": "Plan the company is on",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Company website URL",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "helper_text": "Industry of the company",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the company",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the company (JSON)",
                },
                {
                    "field": "remote_created_at",
                    "type": "timestamp",
                    "helper_text": "When the company was created in remote system",
                },
                {
                    "field": "last_request_at",
                    "type": "timestamp",
                    "helper_text": "When the company last made a request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_company",
            "task_name": "tasks.intercom.create_company",
            "description": "Create a new company",
            "label": "Create Company",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "company_id",
                "name",
                "website",
                "industry",
                "size",
                "plan",
                "monthly_spend",
                "custom_attributes",
            ],
            "required": ["company_id"],
        },
        "get_company": {
            "inputs": [
                {
                    "field": "select_by",
                    "type": "string",
                    "value": "id",
                    "label": "Select By",
                    "helper_text": "How to identify the company",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "id", "label": "ID"},
                            {"value": "company_id", "label": "Company ID"},
                            {"value": "name", "label": "Name"},
                        ],
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "company-123",
                    "helper_text": "The value to search for based on the selected field",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the company",
                },
                {"field": "app_id", "type": "string", "helper_text": "Intercom app ID"},
                {
                    "field": "company_id",
                    "type": "string",
                    "helper_text": "Custom company ID",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "Name of the company",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the company was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the company was last updated",
                },
                {
                    "field": "user_count",
                    "type": "int32",
                    "helper_text": "Number of users in the company",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "helper_text": "Number of sessions from the company",
                },
                {
                    "field": "monthly_spend",
                    "type": "int32",
                    "helper_text": "Monthly spend of the company",
                },
                {
                    "field": "plan",
                    "type": "string",
                    "helper_text": "Plan the company is on",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Company website URL",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "helper_text": "Industry of the company",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the company",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the company (JSON)",
                },
                {
                    "field": "remote_created_at",
                    "type": "timestamp",
                    "helper_text": "When the company was created in remote system",
                },
                {
                    "field": "last_request_at",
                    "type": "timestamp",
                    "helper_text": "When the company last made a request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_company",
            "task_name": "tasks.intercom.get_company",
            "description": "Read details of a company",
            "label": "Get Company",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "select_by", "value"],
            "required": ["value"],
        },
        "list_companies": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of companies to retrieve",
                    "disable_conversion": True,
                },
                {
                    "field": "segment_id",
                    "type": "string",
                    "value": "",
                    "label": "Segment ID",
                    "placeholder": "segment-123",
                    "helper_text": "Filter by segment ID (optional)",
                },
                {
                    "field": "tag_id",
                    "type": "string",
                    "value": "",
                    "label": "Tag ID",
                    "placeholder": "tag-123",
                    "helper_text": "Filter by tag ID (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "ids",
                    "type": "vec<string>",
                    "helper_text": "List of Intercom internal IDs",
                },
                {
                    "field": "app_ids",
                    "type": "vec<string>",
                    "helper_text": "List of Intercom app IDs",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of custom company IDs",
                },
                {
                    "field": "company_names",
                    "type": "vec<string>",
                    "helper_text": "List of company names",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "updated_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last update timestamps",
                },
                {
                    "field": "user_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of user counts per company",
                },
                {
                    "field": "session_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of session counts per company",
                },
                {
                    "field": "monthly_spends",
                    "type": "vec<int32>",
                    "helper_text": "List of monthly spends per company",
                },
                {
                    "field": "websites",
                    "type": "vec<string>",
                    "helper_text": "List of company websites",
                },
                {
                    "field": "industries",
                    "type": "vec<string>",
                    "helper_text": "List of company industries",
                },
                {
                    "field": "plans",
                    "type": "vec<string>",
                    "helper_text": "List of company plans",
                },
                {
                    "field": "sizes",
                    "type": "vec<int32>",
                    "helper_text": "List of company sizes",
                },
                {
                    "field": "remote_created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of remote creation timestamps",
                },
                {
                    "field": "last_request_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last request timestamps",
                },
                {
                    "field": "custom_attributes",
                    "type": "vec<string>",
                    "helper_text": "List of custom attributes (JSON strings)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_companies",
            "task_name": "tasks.intercom.list_companies",
            "description": "Get multiple companies",
            "label": "List Companies",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "limit",
                "segment_id",
                "tag_id",
            ],
            "required": [],
        },
        "update_company": {
            "inputs": [
                {
                    "field": "company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company Name or ID",
                    "helper_text": "Select company from dropdown, or enter company ID directly",
                    "placeholder": "my-company-123",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "multi_select": False,
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=companies&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Inc.",
                    "helper_text": "The new name of the company",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                    "helper_text": "The new website URL",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "The new industry",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "value": 0,
                    "label": "Company Size",
                    "placeholder": "100",
                    "helper_text": "The new number of employees",
                    "disable_conversion": True,
                },
                {
                    "field": "plan",
                    "type": "string",
                    "value": "",
                    "label": "Plan",
                    "placeholder": "Enterprise",
                    "helper_text": "The new plan name",
                },
                {
                    "field": "monthly_spend",
                    "type": "int32",
                    "value": 0,
                    "label": "Monthly Spend",
                    "placeholder": "5000",
                    "helper_text": "The new monthly revenue",
                    "disable_conversion": True,
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "value": "",
                    "label": "Custom Attributes",
                    "placeholder": "key1:value1,key2:value2",
                    "helper_text": "Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the company",
                },
                {"field": "app_id", "type": "string", "helper_text": "Intercom app ID"},
                {
                    "field": "company_id",
                    "type": "string",
                    "helper_text": "Custom company ID",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "Name of the updated company",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the company was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the company was last updated",
                },
                {
                    "field": "user_count",
                    "type": "int32",
                    "helper_text": "Number of users in the company",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "helper_text": "Number of sessions from the company",
                },
                {
                    "field": "monthly_spend",
                    "type": "int32",
                    "helper_text": "Monthly spend of the company",
                },
                {
                    "field": "plan",
                    "type": "string",
                    "helper_text": "Plan the company is on",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Company website URL",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "helper_text": "Industry of the company",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the company",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the company (JSON)",
                },
                {
                    "field": "remote_created_at",
                    "type": "timestamp",
                    "helper_text": "When the company was created in remote system",
                },
                {
                    "field": "last_request_at",
                    "type": "timestamp",
                    "helper_text": "When the company last made a request",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_company",
            "task_name": "tasks.intercom.update_company",
            "description": "Update a company",
            "label": "Update Company",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "company_id",
                "name",
                "website",
                "industry",
                "size",
                "plan",
                "monthly_spend",
                "custom_attributes",
            ],
            "required": ["company_id"],
        },
        "list_company_users": {
            "inputs": [
                {
                    "field": "list_by",
                    "type": "string",
                    "value": "id",
                    "label": "List By",
                    "helper_text": "How to identify the company",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "id", "label": "ID"},
                            {"value": "company_id", "label": "Company ID"},
                        ],
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "company-123",
                    "helper_text": "The company identifier value",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of users to retrieve",
                    "disable_conversion": True,
                },
            ],
            "outputs": [
                {
                    "field": "ids",
                    "type": "vec<string>",
                    "helper_text": "List of Intercom internal IDs",
                },
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of external IDs (provided by you)",
                },
                {
                    "field": "external_ids",
                    "type": "vec<string>",
                    "helper_text": "List of external IDs (provided by you)",
                },
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "helper_text": "List of workspace IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user emails",
                },
                {
                    "field": "user_phones",
                    "type": "vec<string>",
                    "helper_text": "List of user phone numbers",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "updated_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last update timestamps",
                },
                {
                    "field": "last_seen_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last seen timestamps",
                },
                {
                    "field": "session_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of session counts",
                },
                {
                    "field": "company_ids",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of company IDs for each user",
                },
                {
                    "field": "custom_attributes",
                    "type": "vec<string>",
                    "helper_text": "List of custom attributes for each user (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_company_users",
            "task_name": "tasks.intercom.list_company_users",
            "description": "List users belonging to a company",
            "label": "List Company Users",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "list_by", "value", "limit"],
            "required": ["value"],
        },
        "create_lead": {
            "inputs": [
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "lead@example.com",
                    "helper_text": "The email address of the lead",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "John Doe",
                    "helper_text": "The name of the lead",
                },
                {
                    "field": "companies",
                    "type": "string",
                    "value": "",
                    "label": "Company Names or IDs",
                    "helper_text": "Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)",
                    "placeholder": "company-1,company-2",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "multi_select": True,
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=companies&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "The phone number of the lead",
                },
                {
                    "field": "avatar",
                    "type": "string",
                    "value": "",
                    "label": "Avatar URL",
                    "placeholder": "https://example.com/avatar.png",
                    "helper_text": "URL of the lead's avatar image",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "value": False,
                    "label": "Unsubscribed From Emails",
                    "helper_text": "Whether the lead has unsubscribed from emails",
                },
                {
                    "field": "update_last_request_at",
                    "type": "bool",
                    "value": False,
                    "label": "Update Last Request At",
                    "helper_text": "Whether to update the last request timestamp",
                },
                {
                    "field": "utm_source",
                    "type": "string",
                    "value": "",
                    "label": "UTM Source",
                    "placeholder": "google",
                    "helper_text": "UTM source parameter",
                },
                {
                    "field": "utm_medium",
                    "type": "string",
                    "value": "",
                    "label": "UTM Medium",
                    "placeholder": "cpc",
                    "helper_text": "UTM medium parameter",
                },
                {
                    "field": "utm_campaign",
                    "type": "string",
                    "value": "",
                    "label": "UTM Campaign",
                    "placeholder": "spring_sale",
                    "helper_text": "UTM campaign parameter",
                },
                {
                    "field": "utm_term",
                    "type": "string",
                    "value": "",
                    "label": "UTM Term",
                    "placeholder": "running shoes",
                    "helper_text": "UTM term parameter",
                },
                {
                    "field": "utm_content",
                    "type": "string",
                    "value": "",
                    "label": "UTM Content",
                    "placeholder": "banner_ad",
                    "helper_text": "UTM content parameter",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "value": "",
                    "label": "Custom Attributes",
                    "placeholder": "key1:value1,key2:value2",
                    "helper_text": "Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the lead",
                },
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "External ID of the lead (provided by you)",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the lead (provided by you)",
                },
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "Workspace ID",
                },
                {
                    "field": "lead_name",
                    "type": "string",
                    "helper_text": "Name of the created lead",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the lead",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the lead",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the contact (lead)",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the lead",
                },
                {
                    "field": "has_hard_bounced",
                    "type": "bool",
                    "helper_text": "Whether email has hard bounced",
                },
                {
                    "field": "marked_email_as_spam",
                    "type": "bool",
                    "helper_text": "Whether email was marked as spam",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "helper_text": "Whether unsubscribed from emails",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated company IDs",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last updated",
                },
                {
                    "field": "signed_up_at",
                    "type": "timestamp",
                    "helper_text": "When the lead signed up",
                },
                {
                    "field": "last_seen_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last seen",
                },
                {
                    "field": "last_replied_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last replied",
                },
                {
                    "field": "last_contacted_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last contacted",
                },
                {
                    "field": "last_email_opened_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last opened an email",
                },
                {
                    "field": "last_email_clicked_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last clicked an email",
                },
                {
                    "field": "browser",
                    "type": "string",
                    "helper_text": "Browser used by the lead",
                },
                {
                    "field": "browser_language",
                    "type": "string",
                    "helper_text": "Browser language",
                },
                {"field": "os", "type": "string", "helper_text": "Operating system"},
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the lead (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_lead",
            "task_name": "tasks.intercom.create_lead",
            "description": "Create a new lead",
            "label": "Create Lead",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "email",
                "name",
                "companies",
                "phone",
                "avatar",
                "unsubscribed_from_emails",
                "update_last_request_at",
                "utm_source",
                "utm_medium",
                "utm_campaign",
                "utm_term",
                "utm_content",
                "custom_attributes",
            ],
            "required": ["email"],
        },
        "get_lead": {
            "inputs": [
                {
                    "field": "select_by",
                    "type": "string",
                    "value": "id",
                    "label": "Select By",
                    "helper_text": "How to identify the lead",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "id", "label": "ID"},
                            {"value": "email", "label": "Email"},
                            {"value": "user_id", "label": "User ID"},
                            {"value": "phone", "label": "Phone"},
                        ],
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "lead-123",
                    "helper_text": "The value to search for based on the selected field",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the lead",
                },
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "External ID of the lead (provided by you)",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the lead (provided by you)",
                },
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "Workspace ID",
                },
                {
                    "field": "lead_name",
                    "type": "string",
                    "helper_text": "Name of the lead",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the lead",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the lead",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the contact (lead)",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the lead",
                },
                {
                    "field": "has_hard_bounced",
                    "type": "bool",
                    "helper_text": "Whether email has hard bounced",
                },
                {
                    "field": "marked_email_as_spam",
                    "type": "bool",
                    "helper_text": "Whether email was marked as spam",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "helper_text": "Whether unsubscribed from emails",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated company IDs",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last updated",
                },
                {
                    "field": "signed_up_at",
                    "type": "timestamp",
                    "helper_text": "When the lead signed up",
                },
                {
                    "field": "last_seen_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last seen",
                },
                {
                    "field": "last_replied_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last replied",
                },
                {
                    "field": "last_contacted_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last contacted",
                },
                {
                    "field": "last_email_opened_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last opened an email",
                },
                {
                    "field": "last_email_clicked_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last clicked an email",
                },
                {
                    "field": "browser",
                    "type": "string",
                    "helper_text": "Browser used by the lead",
                },
                {
                    "field": "browser_language",
                    "type": "string",
                    "helper_text": "Browser language",
                },
                {"field": "os", "type": "string", "helper_text": "Operating system"},
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the lead (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_lead",
            "task_name": "tasks.intercom.get_lead",
            "description": "Read details of a lead",
            "label": "Get Lead",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "select_by", "value"],
            "required": ["value"],
        },
        "list_leads": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of leads to retrieve",
                    "disable_conversion": True,
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email Filter",
                    "placeholder": "lead@example.com",
                    "helper_text": "Filter by email (optional)",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone Filter",
                    "placeholder": "+1234567890",
                    "helper_text": "Filter by phone (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "ids",
                    "type": "vec<string>",
                    "helper_text": "List of Intercom internal IDs",
                },
                {
                    "field": "lead_ids",
                    "type": "vec<string>",
                    "helper_text": "List of external IDs (provided by you)",
                },
                {
                    "field": "external_ids",
                    "type": "vec<string>",
                    "helper_text": "List of external IDs (provided by you)",
                },
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "helper_text": "List of workspace IDs",
                },
                {
                    "field": "lead_names",
                    "type": "vec<string>",
                    "helper_text": "List of lead names",
                },
                {
                    "field": "lead_emails",
                    "type": "vec<string>",
                    "helper_text": "List of lead emails",
                },
                {
                    "field": "lead_phones",
                    "type": "vec<string>",
                    "helper_text": "List of lead phone numbers",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "company_ids",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of company IDs for each lead",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "updated_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last update timestamps",
                },
                {
                    "field": "last_seen_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last seen timestamps",
                },
                {
                    "field": "custom_attributes",
                    "type": "vec<string>",
                    "helper_text": "List of custom attributes for each lead (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_leads",
            "task_name": "tasks.intercom.list_leads",
            "description": "Get multiple leads",
            "label": "List Leads",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "limit", "email", "phone"],
            "required": [],
        },
        "update_lead": {
            "inputs": [
                {
                    "field": "update_by",
                    "type": "string",
                    "value": "id",
                    "label": "Update By",
                    "helper_text": "How to identify the lead to update",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "intercom_id_user_id",
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "lead-123",
                    "helper_text": "The identifier value of the lead to update",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "lead@example.com",
                    "helper_text": "The new email address",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "John Doe",
                    "helper_text": "The new name",
                },
                {
                    "field": "companies",
                    "type": "string",
                    "value": "",
                    "label": "Company Names or IDs",
                    "helper_text": "Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)",
                    "placeholder": "company-1,company-2",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "multi_select": True,
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=companies&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "The new phone number",
                },
                {
                    "field": "avatar",
                    "type": "string",
                    "value": "",
                    "label": "Avatar URL",
                    "placeholder": "https://example.com/avatar.png",
                    "helper_text": "URL of the new avatar image",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "value": False,
                    "label": "Unsubscribed From Emails",
                    "helper_text": "Whether the lead has unsubscribed from emails",
                },
                {
                    "field": "update_last_request_at",
                    "type": "bool",
                    "value": False,
                    "label": "Update Last Request At",
                    "helper_text": "Whether to update the last request timestamp",
                },
                {
                    "field": "utm_source",
                    "type": "string",
                    "value": "",
                    "label": "UTM Source",
                    "placeholder": "google",
                    "helper_text": "UTM source parameter",
                },
                {
                    "field": "utm_medium",
                    "type": "string",
                    "value": "",
                    "label": "UTM Medium",
                    "placeholder": "cpc",
                    "helper_text": "UTM medium parameter",
                },
                {
                    "field": "utm_campaign",
                    "type": "string",
                    "value": "",
                    "label": "UTM Campaign",
                    "placeholder": "spring_sale",
                    "helper_text": "UTM campaign parameter",
                },
                {
                    "field": "utm_term",
                    "type": "string",
                    "value": "",
                    "label": "UTM Term",
                    "placeholder": "running shoes",
                    "helper_text": "UTM term parameter",
                },
                {
                    "field": "utm_content",
                    "type": "string",
                    "value": "",
                    "label": "UTM Content",
                    "placeholder": "banner_ad",
                    "helper_text": "UTM content parameter",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "value": "",
                    "label": "Custom Attributes",
                    "placeholder": "key1:value1,key2:value2",
                    "helper_text": "Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the lead",
                },
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "External ID of the lead (provided by you)",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the lead (provided by you)",
                },
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "Workspace ID",
                },
                {
                    "field": "lead_name",
                    "type": "string",
                    "helper_text": "Name of the updated lead",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the lead",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the lead",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the contact (lead)",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the lead",
                },
                {
                    "field": "has_hard_bounced",
                    "type": "bool",
                    "helper_text": "Whether email has hard bounced",
                },
                {
                    "field": "marked_email_as_spam",
                    "type": "bool",
                    "helper_text": "Whether email was marked as spam",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "helper_text": "Whether unsubscribed from emails",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated company IDs",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last updated",
                },
                {
                    "field": "signed_up_at",
                    "type": "timestamp",
                    "helper_text": "When the lead signed up",
                },
                {
                    "field": "last_seen_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last seen",
                },
                {
                    "field": "last_replied_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last replied",
                },
                {
                    "field": "last_contacted_at",
                    "type": "timestamp",
                    "helper_text": "When the lead was last contacted",
                },
                {
                    "field": "last_email_opened_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last opened an email",
                },
                {
                    "field": "last_email_clicked_at",
                    "type": "timestamp",
                    "helper_text": "When the lead last clicked an email",
                },
                {
                    "field": "browser",
                    "type": "string",
                    "helper_text": "Browser used by the lead",
                },
                {
                    "field": "browser_language",
                    "type": "string",
                    "helper_text": "Browser language",
                },
                {"field": "os", "type": "string", "helper_text": "Operating system"},
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the lead (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_lead",
            "task_name": "tasks.intercom.update_lead",
            "description": "Update a lead",
            "label": "Update Lead",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "update_by",
                "value",
                "email",
                "name",
                "phone",
                "avatar",
                "unsubscribed_from_emails",
                "update_last_request_at",
                "utm_source",
                "utm_medium",
                "utm_campaign",
                "utm_term",
                "utm_content",
                "companies",
                "custom_attributes",
            ],
            "required": ["value"],
        },
        "delete_lead": {
            "inputs": [
                {
                    "field": "delete_by",
                    "type": "string",
                    "value": "id",
                    "label": "Delete By",
                    "helper_text": "How to identify the lead to delete",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "intercom_id_user_id",
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "lead-123",
                    "helper_text": "The identifier value of the lead to delete",
                },
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Status message"}
            ],
            "name": "delete_lead",
            "task_name": "tasks.intercom.delete_lead",
            "description": "Delete a lead",
            "label": "Delete Lead",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "delete_by", "value"],
            "required": ["value"],
        },
        "create_user": {
            "inputs": [
                {
                    "field": "identifier_type",
                    "type": "string",
                    "value": "email",
                    "label": "Identifier Type",
                    "helper_text": "How to identify the user",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "email", "label": "Email"},
                            {"value": "user_id", "label": "User ID"},
                        ],
                    },
                },
                {
                    "field": "id_value",
                    "type": "string",
                    "value": "",
                    "label": "Identifier Value",
                    "placeholder": "user@example.com",
                    "helper_text": "The email or user ID for the user",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "John Doe",
                    "helper_text": "The name of the user",
                },
                {
                    "field": "companies",
                    "type": "string",
                    "value": "",
                    "label": "Company Names or IDs",
                    "helper_text": "Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)",
                    "placeholder": "company-1,company-2",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "multi_select": True,
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=companies&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "The phone number of the user",
                },
                {
                    "field": "avatar",
                    "type": "string",
                    "value": "",
                    "label": "Avatar URL",
                    "placeholder": "https://example.com/avatar.png",
                    "helper_text": "URL of the user's avatar image",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "value": False,
                    "label": "Unsubscribed From Emails",
                    "helper_text": "Whether the user has unsubscribed from emails",
                },
                {
                    "field": "update_last_request_at",
                    "type": "bool",
                    "value": False,
                    "label": "Update Last Request At",
                    "helper_text": "Whether to update the last request timestamp",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "value": 0,
                    "label": "Session Count",
                    "placeholder": "10",
                    "helper_text": "Number of sessions the user has had",
                    "disable_conversion": True,
                },
                {
                    "field": "utm_source",
                    "type": "string",
                    "value": "",
                    "label": "UTM Source",
                    "placeholder": "google",
                    "helper_text": "UTM source parameter",
                },
                {
                    "field": "utm_medium",
                    "type": "string",
                    "value": "",
                    "label": "UTM Medium",
                    "placeholder": "cpc",
                    "helper_text": "UTM medium parameter",
                },
                {
                    "field": "utm_campaign",
                    "type": "string",
                    "value": "",
                    "label": "UTM Campaign",
                    "placeholder": "spring_sale",
                    "helper_text": "UTM campaign parameter",
                },
                {
                    "field": "utm_term",
                    "type": "string",
                    "value": "",
                    "label": "UTM Term",
                    "placeholder": "running shoes",
                    "helper_text": "UTM term parameter",
                },
                {
                    "field": "utm_content",
                    "type": "string",
                    "value": "",
                    "label": "UTM Content",
                    "placeholder": "banner_ad",
                    "helper_text": "UTM content parameter",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "value": "",
                    "label": "Custom Attributes",
                    "placeholder": "key1:value1,key2:value2",
                    "helper_text": "Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the user",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "External ID of the user (provided by you)",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the user (provided by you)",
                },
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "Workspace ID",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the created user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the user",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the contact (user)",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the user",
                },
                {
                    "field": "has_hard_bounced",
                    "type": "bool",
                    "helper_text": "Whether email has hard bounced",
                },
                {
                    "field": "marked_email_as_spam",
                    "type": "bool",
                    "helper_text": "Whether email was marked as spam",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "helper_text": "Whether unsubscribed from emails",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated company IDs",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the user was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last updated",
                },
                {
                    "field": "signed_up_at",
                    "type": "timestamp",
                    "helper_text": "When the user signed up",
                },
                {
                    "field": "last_seen_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last seen",
                },
                {
                    "field": "last_replied_at",
                    "type": "timestamp",
                    "helper_text": "When the user last replied",
                },
                {
                    "field": "last_contacted_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last contacted",
                },
                {
                    "field": "last_email_opened_at",
                    "type": "timestamp",
                    "helper_text": "When the user last opened an email",
                },
                {
                    "field": "last_email_clicked_at",
                    "type": "timestamp",
                    "helper_text": "When the user last clicked an email",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "helper_text": "Number of sessions",
                },
                {
                    "field": "browser",
                    "type": "string",
                    "helper_text": "Browser used by the user",
                },
                {
                    "field": "browser_language",
                    "type": "string",
                    "helper_text": "Browser language",
                },
                {"field": "os", "type": "string", "helper_text": "Operating system"},
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the user (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_user",
            "task_name": "tasks.intercom.create_user",
            "description": "Create a new user",
            "label": "Create User",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "identifier_type",
                "id_value",
                "name",
                "phone",
                "avatar",
                "unsubscribed_from_emails",
                "update_last_request_at",
                "session_count",
                "utm_source",
                "utm_medium",
                "utm_campaign",
                "utm_term",
                "utm_content",
                "companies",
                "custom_attributes",
            ],
            "required": ["identifier_type", "id_value"],
        },
        "get_user": {
            "inputs": [
                {
                    "field": "select_by",
                    "type": "string",
                    "value": "id",
                    "label": "Select By",
                    "helper_text": "How to identify the user",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "intercom_id_user_id",
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "user-123",
                    "helper_text": "The value to search for based on the selected field",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the user",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "External ID of the user (provided by you)",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the user (provided by you)",
                },
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "Workspace ID",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the user",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the contact (user)",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the user",
                },
                {
                    "field": "has_hard_bounced",
                    "type": "bool",
                    "helper_text": "Whether email has hard bounced",
                },
                {
                    "field": "marked_email_as_spam",
                    "type": "bool",
                    "helper_text": "Whether email was marked as spam",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "helper_text": "Whether unsubscribed from emails",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated company IDs",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the user was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last updated",
                },
                {
                    "field": "signed_up_at",
                    "type": "timestamp",
                    "helper_text": "When the user signed up",
                },
                {
                    "field": "last_seen_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last seen",
                },
                {
                    "field": "last_replied_at",
                    "type": "timestamp",
                    "helper_text": "When the user last replied",
                },
                {
                    "field": "last_contacted_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last contacted",
                },
                {
                    "field": "last_email_opened_at",
                    "type": "timestamp",
                    "helper_text": "When the user last opened an email",
                },
                {
                    "field": "last_email_clicked_at",
                    "type": "timestamp",
                    "helper_text": "When the user last clicked an email",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "helper_text": "Number of sessions",
                },
                {
                    "field": "browser",
                    "type": "string",
                    "helper_text": "Browser used by the user",
                },
                {
                    "field": "browser_language",
                    "type": "string",
                    "helper_text": "Browser language",
                },
                {"field": "os", "type": "string", "helper_text": "Operating system"},
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the user (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.intercom.get_user",
            "description": "Read details of a user",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "select_by", "value"],
            "required": ["value"],
        },
        "list_users": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of users to retrieve",
                    "disable_conversion": True,
                },
                {
                    "field": "company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company ID Filter",
                    "placeholder": "company-123",
                    "helper_text": "Filter by custom company ID (optional)",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email Filter",
                    "placeholder": "user@example.com",
                    "helper_text": "Filter by email (optional)",
                },
                {
                    "field": "segment_id",
                    "type": "string",
                    "value": "",
                    "label": "Segment ID Filter",
                    "placeholder": "segment-123",
                    "helper_text": "Filter by segment ID (optional)",
                },
                {
                    "field": "tag_id",
                    "type": "string",
                    "value": "",
                    "label": "Tag ID Filter",
                    "placeholder": "tag-123",
                    "helper_text": "Filter by tag ID (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "ids",
                    "type": "vec<string>",
                    "helper_text": "List of Intercom internal IDs",
                },
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of external IDs (provided by you)",
                },
                {
                    "field": "external_ids",
                    "type": "vec<string>",
                    "helper_text": "List of external IDs (provided by you)",
                },
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "helper_text": "List of workspace IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user emails",
                },
                {
                    "field": "user_phones",
                    "type": "vec<string>",
                    "helper_text": "List of user phone numbers",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "company_ids",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of company IDs for each user",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "updated_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last update timestamps",
                },
                {
                    "field": "last_seen_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last seen timestamps",
                },
                {
                    "field": "session_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of session counts",
                },
                {
                    "field": "custom_attributes",
                    "type": "vec<string>",
                    "helper_text": "List of custom attributes for each user (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_users",
            "task_name": "tasks.intercom.list_users",
            "description": "Get multiple users",
            "label": "List Users",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "limit",
                "company_id",
                "email",
                "segment_id",
                "tag_id",
            ],
            "required": [],
        },
        "update_user": {
            "inputs": [
                {
                    "field": "update_by",
                    "type": "string",
                    "value": "id",
                    "label": "Update By",
                    "helper_text": "How to identify the user to update",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "id", "label": "ID"},
                            {"value": "user_id", "label": "User ID"},
                            {"value": "email", "label": "Email"},
                        ],
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "user-123",
                    "helper_text": "The identifier value of the user to update",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "user@example.com",
                    "helper_text": "The new email address",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "John Doe",
                    "helper_text": "The new name",
                },
                {
                    "field": "companies",
                    "type": "string",
                    "value": "",
                    "label": "Company Names or IDs",
                    "helper_text": "Select companies from dropdown, or enter company IDs comma-separated (e.g., company-1,company-2)",
                    "placeholder": "company-1,company-2",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "multi_select": True,
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=companies&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1234567890",
                    "helper_text": "The new phone number",
                },
                {
                    "field": "avatar",
                    "type": "string",
                    "value": "",
                    "label": "Avatar URL",
                    "placeholder": "https://example.com/avatar.png",
                    "helper_text": "URL of the new avatar image",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "value": False,
                    "label": "Unsubscribed From Emails",
                    "helper_text": "Whether the user has unsubscribed from emails",
                },
                {
                    "field": "update_last_request_at",
                    "type": "bool",
                    "value": False,
                    "label": "Update Last Request At",
                    "helper_text": "Whether to update the last request timestamp",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "value": 0,
                    "label": "Session Count",
                    "placeholder": "10",
                    "helper_text": "Number of sessions the user has had",
                    "disable_conversion": True,
                },
                {
                    "field": "utm_source",
                    "type": "string",
                    "value": "",
                    "label": "UTM Source",
                    "placeholder": "google",
                    "helper_text": "UTM source parameter",
                },
                {
                    "field": "utm_medium",
                    "type": "string",
                    "value": "",
                    "label": "UTM Medium",
                    "placeholder": "cpc",
                    "helper_text": "UTM medium parameter",
                },
                {
                    "field": "utm_campaign",
                    "type": "string",
                    "value": "",
                    "label": "UTM Campaign",
                    "placeholder": "spring_sale",
                    "helper_text": "UTM campaign parameter",
                },
                {
                    "field": "utm_term",
                    "type": "string",
                    "value": "",
                    "label": "UTM Term",
                    "placeholder": "running shoes",
                    "helper_text": "UTM term parameter",
                },
                {
                    "field": "utm_content",
                    "type": "string",
                    "value": "",
                    "label": "UTM Content",
                    "placeholder": "banner_ad",
                    "helper_text": "UTM content parameter",
                },
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "value": "",
                    "label": "Custom Attributes",
                    "placeholder": "key1:value1,key2:value2",
                    "helper_text": "Custom attributes as key:value pairs, comma-separated (e.g., plan:premium,tier:gold)",
                },
            ],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Intercom internal ID of the user",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "External ID of the user (provided by you)",
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "helper_text": "External ID of the user (provided by you)",
                },
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "Workspace ID",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the updated user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the user",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the contact (user)",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the user",
                },
                {
                    "field": "has_hard_bounced",
                    "type": "bool",
                    "helper_text": "Whether email has hard bounced",
                },
                {
                    "field": "marked_email_as_spam",
                    "type": "bool",
                    "helper_text": "Whether email was marked as spam",
                },
                {
                    "field": "unsubscribed_from_emails",
                    "type": "bool",
                    "helper_text": "Whether unsubscribed from emails",
                },
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated company IDs",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the user was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last updated",
                },
                {
                    "field": "signed_up_at",
                    "type": "timestamp",
                    "helper_text": "When the user signed up",
                },
                {
                    "field": "last_seen_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last seen",
                },
                {
                    "field": "last_replied_at",
                    "type": "timestamp",
                    "helper_text": "When the user last replied",
                },
                {
                    "field": "last_contacted_at",
                    "type": "timestamp",
                    "helper_text": "When the user was last contacted",
                },
                {
                    "field": "last_email_opened_at",
                    "type": "timestamp",
                    "helper_text": "When the user last opened an email",
                },
                {
                    "field": "last_email_clicked_at",
                    "type": "timestamp",
                    "helper_text": "When the user last clicked an email",
                },
                {
                    "field": "session_count",
                    "type": "int32",
                    "helper_text": "Number of sessions",
                },
                {
                    "field": "browser",
                    "type": "string",
                    "helper_text": "Browser used by the user",
                },
                {
                    "field": "browser_language",
                    "type": "string",
                    "helper_text": "Browser language",
                },
                {"field": "os", "type": "string", "helper_text": "Operating system"},
                {
                    "field": "custom_attributes",
                    "type": "string",
                    "helper_text": "Custom attributes of the user (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_user",
            "task_name": "tasks.intercom.update_user",
            "description": "Update a user",
            "label": "Update User",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "update_by",
                "value",
                "email",
                "name",
                "phone",
                "avatar",
                "unsubscribed_from_emails",
                "update_last_request_at",
                "session_count",
                "utm_source",
                "utm_medium",
                "utm_campaign",
                "utm_term",
                "utm_content",
                "companies",
                "custom_attributes",
            ],
            "required": ["value"],
        },
        "delete_user": {
            "inputs": [
                {
                    "field": "id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "user-123",
                    "helper_text": "The ID of the user to delete",
                }
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Status message"}
            ],
            "name": "delete_user",
            "task_name": "tasks.intercom.delete_user",
            "description": "Delete a user",
            "label": "Delete User",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "id"],
            "required": ["id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        avatar: str = "",
        companies: str = "",
        company_id: str = "",
        custom_attributes: str = "",
        delete_by: str = "id",
        email: str = "",
        id_value: str = "",
        identifier_type: str = "email",
        industry: str = "",
        limit: int = 10,
        list_by: str = "id",
        monthly_spend: int = 0,
        name: str = "",
        phone: str = "",
        plan: str = "",
        segment_id: str = "",
        select_by: str = "id",
        session_count: int = 0,
        size: int = 0,
        tag_id: str = "",
        unsubscribed_from_emails: bool = False,
        update_by: str = "id",
        update_last_request_at: bool = False,
        utm_campaign: str = "",
        utm_content: str = "",
        utm_medium: str = "",
        utm_source: str = "",
        utm_term: str = "",
        value: str = "",
        website: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_intercom",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if integration is not None:
            self.inputs["integration"] = integration
        if action is not None:
            self.inputs["action"] = action
        if company_id is not None:
            self.inputs["company_id"] = company_id
        if name is not None:
            self.inputs["name"] = name
        if website is not None:
            self.inputs["website"] = website
        if industry is not None:
            self.inputs["industry"] = industry
        if size is not None:
            self.inputs["size"] = size
        if plan is not None:
            self.inputs["plan"] = plan
        if monthly_spend is not None:
            self.inputs["monthly_spend"] = monthly_spend
        if custom_attributes is not None:
            self.inputs["custom_attributes"] = custom_attributes
        if select_by is not None:
            self.inputs["select_by"] = select_by
        if value is not None:
            self.inputs["value"] = value
        if limit is not None:
            self.inputs["limit"] = limit
        if segment_id is not None:
            self.inputs["segment_id"] = segment_id
        if tag_id is not None:
            self.inputs["tag_id"] = tag_id
        if list_by is not None:
            self.inputs["list_by"] = list_by
        if email is not None:
            self.inputs["email"] = email
        if companies is not None:
            self.inputs["companies"] = companies
        if phone is not None:
            self.inputs["phone"] = phone
        if avatar is not None:
            self.inputs["avatar"] = avatar
        if unsubscribed_from_emails is not None:
            self.inputs["unsubscribed_from_emails"] = unsubscribed_from_emails
        if update_last_request_at is not None:
            self.inputs["update_last_request_at"] = update_last_request_at
        if utm_source is not None:
            self.inputs["utm_source"] = utm_source
        if utm_medium is not None:
            self.inputs["utm_medium"] = utm_medium
        if utm_campaign is not None:
            self.inputs["utm_campaign"] = utm_campaign
        if utm_term is not None:
            self.inputs["utm_term"] = utm_term
        if utm_content is not None:
            self.inputs["utm_content"] = utm_content
        if update_by is not None:
            self.inputs["update_by"] = update_by
        if delete_by is not None:
            self.inputs["delete_by"] = delete_by
        if identifier_type is not None:
            self.inputs["identifier_type"] = identifier_type
        if id_value is not None:
            self.inputs["id_value"] = id_value
        if session_count is not None:
            self.inputs["session_count"] = session_count
        if id is not None:
            self.inputs["id"] = id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationIntercomNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
