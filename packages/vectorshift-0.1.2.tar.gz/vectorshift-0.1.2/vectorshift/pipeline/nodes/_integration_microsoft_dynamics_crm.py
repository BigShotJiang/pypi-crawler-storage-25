"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_microsoft_dynamics_crm")
class IntegrationMicrosoftDynamicsCrmNode(Node):
    """
    Microsoft Dynamics CRM

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Microsoft Dynamics CRM account
    ### When action = 'delete_account'
        account_id: Select the account to delete
    ### When action = 'get_account'
        account_id: Select the account to delete
        expand: Related entities to expand (optional, e.g., primarycontactid)
        select_fields: Comma-separated list of fields to return (optional, e.g., name,accountnumber,telephone1)
    ### When action = 'update_account'
        account_id: Select the account to delete
        account_number: Account number
        additional_fields: Additional fields as JSON object
        address_line1: Street address
        city: City
        country: Country
        description: Description of the account
        email: Primary email address
        industry: Industry type
        name: Updated account name
        number_of_employees: Number of employees
        phone: Primary phone number
        postal_code: Postal or ZIP code
        revenue: Annual revenue
        state: State or Province
        website: Website URL
    ### When action = 'create_account'
        account_number: Account number
        additional_fields: Additional fields as JSON object
        address_line1: Street address
        city: City
        country: Country
        create_account_name: Name of the account (required)
        description: Description of the account
        email: Primary email address
        industry: Industry type
        number_of_employees: Number of employees
        phone: Primary phone number
        postal_code: Postal or ZIP code
        revenue: Annual revenue
        state: State or Province
        website: Website URL
    ### When action = 'list_accounts' and use_date = True and use_exact_date = False
        date_range: Pick the relative date range
    ### When action = 'list_accounts' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'list_accounts'
        expand: Related entities to expand (optional, e.g., primarycontactid)
        filter: OData filter expression (e.g., statecode eq 0)
        order_by: Field to sort by (e.g., name asc, createdon desc)
        select_fields: Comma-separated list of fields to return (optional, e.g., name,accountnumber,telephone1)
        use_date: Toggle to filter accounts by date
    ### When action = 'list_accounts' and use_date = False
        num_messages: Specify the number of accounts to fetch (max 5000)
    ### When action = 'list_accounts' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'create_account'
        account_id: ID of the created account
        account_name: Name of the created account
        created_on: When the account was created
        raw_data: Raw API response data
    ### When action = 'get_account'
        account_id: Unique identifier of the account
        account_name: Name of the account
        account_number: Account number
        address: Street address
        city: City
        country: Country
        created_on: When the account was created
        email: Primary email address
        industry: Industry type
        modified_on: When the account was last modified
        number_of_employees: Number of employees
        owner_id: ID of the account owner
        phone: Primary phone number
        raw_data: Raw API response data
        revenue: Annual revenue
        state: State or Province
        state_code: State code of the account
        status_code: Status code of the account
        website: Website URL
    ### When action = 'update_account'
        account_id: ID of the updated account
        account_name: Name of the updated account
        modified_on: When the account was last modified
        raw_data: Raw API response data
    ### When action = 'list_accounts'
        account_ids: List of account IDs
        account_names: List of account names
        accounts: List of accounts in JSON format
        raw_data: Raw API response data
        total_count: Total number of accounts returned
    ### When action = 'delete_account'
        deleted_account_id: ID of the deleted account
        message: Success message
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Microsoft Dynamics CRM account",
            "value": None,
            "type": "integration<Microsoft Dynamics CRM>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "create_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "create_account_name",
                    "type": "string",
                    "value": "",
                    "label": "Account Name",
                    "helper_text": "Name of the account (required)",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "label": "Account Number",
                    "helper_text": "Account number",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description of the account",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "helper_text": "Primary phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "helper_text": "Website URL",
                },
                {
                    "field": "address_line1",
                    "type": "string",
                    "value": "",
                    "label": "Address Line 1",
                    "helper_text": "Street address",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "helper_text": "City",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State/Province",
                    "helper_text": "State or Province",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Postal Code",
                    "helper_text": "Postal or ZIP code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "helper_text": "Country",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "helper_text": "Industry type",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "revenue",
                    "type": "string",
                    "value": "",
                    "label": "Annual Revenue",
                    "helper_text": "Annual revenue",
                },
                {
                    "field": "additional_fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields (JSON)",
                    "helper_text": "Additional fields as JSON object",
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the created account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the created account",
                },
                {
                    "field": "created_on",
                    "type": "timestamp",
                    "helper_text": "When the account was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "create_account",
            "task_name": "tasks.microsoft_dynamics_crm.create_account",
            "description": "Create a new account in Microsoft Dynamics CRM",
            "label": "Create Account",
            "input_sort_order": [
                "action",
                "integration",
                "create_account_name",
                "account_number",
                "description",
                "email",
                "phone",
                "website",
                "address_line1",
                "city",
                "state",
                "postal_code",
                "country",
                "industry",
                "number_of_employees",
                "revenue",
                "additional_fields",
            ],
            "required": ["create_account_name"],
        },
        "delete_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Select the account to delete",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "deleted_account_id",
                    "type": "string",
                    "helper_text": "ID of the deleted account",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_account",
            "task_name": "tasks.microsoft_dynamics_crm.delete_account",
            "description": "Delete an account from Microsoft Dynamics CRM",
            "label": "Delete Account",
            "input_sort_order": ["action", "integration", "account_id"],
            "required": ["account_id"],
        },
        "get_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Select the account to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "select_fields",
                    "type": "string",
                    "value": "",
                    "label": "Select Fields",
                    "helper_text": "Comma-separated list of fields to return (optional, e.g., name,accountnumber,telephone1)",
                },
                {
                    "field": "expand",
                    "type": "string",
                    "value": "",
                    "label": "Expand Relations",
                    "helper_text": "Related entities to expand (optional, e.g., primarycontactid)",
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the account",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "helper_text": "Account number",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Primary phone number",
                },
                {"field": "website", "type": "string", "helper_text": "Website URL"},
                {"field": "address", "type": "string", "helper_text": "Street address"},
                {"field": "city", "type": "string", "helper_text": "City"},
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "State or Province",
                },
                {"field": "country", "type": "string", "helper_text": "Country"},
                {"field": "industry", "type": "string", "helper_text": "Industry type"},
                {"field": "revenue", "type": "string", "helper_text": "Annual revenue"},
                {
                    "field": "number_of_employees",
                    "type": "string",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "created_on",
                    "type": "timestamp",
                    "helper_text": "When the account was created",
                },
                {
                    "field": "modified_on",
                    "type": "timestamp",
                    "helper_text": "When the account was last modified",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "ID of the account owner",
                },
                {
                    "field": "state_code",
                    "type": "string",
                    "helper_text": "State code of the account",
                },
                {
                    "field": "status_code",
                    "type": "string",
                    "helper_text": "Status code of the account",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_account",
            "task_name": "tasks.microsoft_dynamics_crm.get_account",
            "description": "Get details of a specific account from Microsoft Dynamics CRM",
            "label": "Get Account",
            "input_sort_order": [
                "action",
                "integration",
                "account_id",
                "select_fields",
                "expand",
            ],
            "required": ["account_id"],
        },
        "list_accounts**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to filter accounts by date",
                    "hidden": True,
                },
                {
                    "field": "select_fields",
                    "type": "string",
                    "value": "",
                    "label": "Select Fields",
                    "helper_text": "Comma-separated list of fields to return (optional)",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "label": "OData Filter",
                    "helper_text": "OData filter expression (e.g., statecode eq 0)",
                    "hidden": True,
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "helper_text": "Field to sort by (e.g., name asc, createdon desc)",
                    "hidden": True,
                },
                {
                    "field": "expand",
                    "type": "string",
                    "value": "",
                    "label": "Expand Relations",
                    "helper_text": "Related entities to expand (optional)",
                    "hidden": True,
                },
            ],
            "outputs": [
                {
                    "field": "accounts",
                    "type": "vec<string>",
                    "helper_text": "List of accounts in JSON format",
                },
                {
                    "field": "account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of account IDs",
                },
                {
                    "field": "account_names",
                    "type": "vec<string>",
                    "helper_text": "List of account names",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total number of accounts returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_accounts",
            "task_name": "tasks.microsoft_dynamics_crm.list_accounts",
            "description": "Get multiple accounts from Microsoft Dynamics CRM",
            "label": "List Accounts",
            "input_sort_order": [
                "action",
                "integration",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "select_fields",
                "filter",
                "order_by",
                "expand",
            ],
            "required": ["num_messages"],
        },
        "list_accounts**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "label": "Number of Accounts",
                    "helper_text": "Specify the number of accounts to fetch (max 5000)",
                }
            ],
            "outputs": [],
        },
        "list_accounts**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_accounts**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "Pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_accounts**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "update_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "label": "Account",
                    "helper_text": "Select the account to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Account Name",
                    "helper_text": "Updated account name",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "label": "Account Number",
                    "helper_text": "Updated account number",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Updated description",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "helper_text": "Updated email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "helper_text": "Updated phone number",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "helper_text": "Updated website URL",
                },
                {
                    "field": "address_line1",
                    "type": "string",
                    "value": "",
                    "label": "Address Line 1",
                    "helper_text": "Updated street address",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "helper_text": "Updated city",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State/Province",
                    "helper_text": "Updated state or province",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Postal Code",
                    "helper_text": "Updated postal code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "helper_text": "Updated country",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "helper_text": "Updated industry",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "helper_text": "Updated number of employees",
                },
                {
                    "field": "revenue",
                    "type": "string",
                    "value": "",
                    "label": "Annual Revenue",
                    "helper_text": "Updated annual revenue",
                },
                {
                    "field": "additional_fields",
                    "type": "string",
                    "value": "",
                    "label": "Additional Fields (JSON)",
                    "helper_text": "Additional fields to update as JSON object",
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the updated account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the updated account",
                },
                {
                    "field": "modified_on",
                    "type": "timestamp",
                    "helper_text": "When the account was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_account",
            "task_name": "tasks.microsoft_dynamics_crm.update_account",
            "description": "Update an existing account in Microsoft Dynamics CRM",
            "label": "Update Account",
            "input_sort_order": [
                "action",
                "integration",
                "account_id",
                "name",
                "account_number",
                "description",
                "email",
                "phone",
                "website",
                "address_line1",
                "city",
                "state",
                "postal_code",
                "country",
                "industry",
                "number_of_employees",
                "revenue",
                "additional_fields",
            ],
            "required": ["account_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "create_account_name", "account_id"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        account_id: str = "",
        account_number: str = "",
        additional_fields: str = "",
        address_line1: str = "",
        city: str = "",
        country: str = "",
        create_account_name: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        description: str = "",
        email: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        expand: str = "",
        filter: str = "",
        industry: str = "",
        name: str = "",
        num_messages: int = 10,
        number_of_employees: int = 0,
        order_by: str = "",
        phone: str = "",
        postal_code: str = "",
        revenue: str = "",
        select_fields: str = "",
        state: str = "",
        website: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_microsoft_dynamics_crm",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if create_account_name is not None:
            self.inputs["create_account_name"] = create_account_name
        if account_number is not None:
            self.inputs["account_number"] = account_number
        if description is not None:
            self.inputs["description"] = description
        if email is not None:
            self.inputs["email"] = email
        if phone is not None:
            self.inputs["phone"] = phone
        if website is not None:
            self.inputs["website"] = website
        if address_line1 is not None:
            self.inputs["address_line1"] = address_line1
        if city is not None:
            self.inputs["city"] = city
        if state is not None:
            self.inputs["state"] = state
        if postal_code is not None:
            self.inputs["postal_code"] = postal_code
        if country is not None:
            self.inputs["country"] = country
        if industry is not None:
            self.inputs["industry"] = industry
        if number_of_employees is not None:
            self.inputs["number_of_employees"] = number_of_employees
        if revenue is not None:
            self.inputs["revenue"] = revenue
        if additional_fields is not None:
            self.inputs["additional_fields"] = additional_fields
        if account_id is not None:
            self.inputs["account_id"] = account_id
        if select_fields is not None:
            self.inputs["select_fields"] = select_fields
        if expand is not None:
            self.inputs["expand"] = expand
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if filter is not None:
            self.inputs["filter"] = filter
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if name is not None:
            self.inputs["name"] = name
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMicrosoftDynamicsCrmNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
