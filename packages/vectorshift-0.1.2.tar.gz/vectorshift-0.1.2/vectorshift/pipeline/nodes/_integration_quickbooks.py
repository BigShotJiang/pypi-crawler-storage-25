"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_quickbooks")
class IntegrationQuickbooksNode(Node):
    """
    QuickBooks

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your QuickBooks account
    ### When action = 'list_bills'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_customers'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_employees'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_estimates'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_items'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_payments'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_purchases'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_vendors'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'list_invoices'
        query: Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')
        return_all: Return all bills or limit results
    ### When action = 'create_vendor'
        account_number: Account number
        active: Whether the customer is active
        balance: Opening balance
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
        company_name: Legal or trade name of the customer's business
        display_name: Customer display name
        family_name: Customer's last name
        given_name: Customer's first name
        primary_email_address: Main email address for the customer
        primary_phone: Customer's main phone number
        print_on_check_name: Name to print on checks
        vendor_1099: Whether the vendor receives 1099
    ### When action = 'update_vendor'
        account_number: Account number
        active: Whether the customer is active
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
        company_name: Legal or trade name of the customer's business
        family_name: Customer's last name
        given_name: Customer's first name
        primary_email_address: Main email address for the customer
        primary_phone: Customer's main phone number
        print_on_check_name: Name to print on checks
        vendor_1099: Whether the vendor receives 1099
        vendor_id: QuickBooks ID of the vendor
    ### When action = 'list_transactions'
        accounts_payable_paid: Filter by Accounts Payable payment status
        accounts_receivable_paid: Filter by Accounts Receivable payment status
        bothamount: Monetary amount to filter results by (exact match)
        cleared_status: Filter by cleared status
        creation_date_from: Creation date from (YYYY-MM-DD)
        creation_date_predefined: Predefined date range for creation date
        creation_date_to: Creation date to (YYYY-MM-DD)
        customer_ids: Customer IDs (comma-separated for multiple)
        date_range_from: Transaction date from (YYYY-MM-DD)
        date_range_predefined: Predefined date range for transaction date
        date_range_to: Transaction date to (YYYY-MM-DD)
        department_ids: Department IDs (comma-separated for multiple)
        document_number: Document/Reference number
        due_date_from: Due date from (YYYY-MM-DD)
        due_date_predefined: Predefined date range for due date
        due_date_to: Due date to (YYYY-MM-DD)
        group_by: Field to group results by
        memo_ids: Search text in private notes/memos
        modification_date_from: Modification date from (YYYY-MM-DD)
        modification_date_predefined: Predefined date range for modification date
        modification_date_to: Modification date to (YYYY-MM-DD)
        payment_method: Payment method
        printed_status: Filter by print status
        quick_zoom_url: Include Quick Zoom URL in results
        sort_by: Field to sort by
        sort_order: Sort order
        source_account_type: Source account type
        term_ids: Term IDs (comma-separated for multiple)
        transaction_type: Type of transaction to query
        vendor_ids: Vendor IDs (comma-separated for multiple)
    ### When action = 'create_customer'
        active: Whether the customer is active
        add_billing_address: Add billing address details
        balance: Opening balance
        company_name: Legal or trade name of the customer's business
        display_name: Customer display name
        family_name: Customer's last name
        fully_qualified_name: Fully qualified name (hierarchical)
        given_name: Customer's first name
        middle_name: Customer's middle name
        notes: Internal notes about the customer
        parent_customer_id: Parent customer ID for sub-customers (leave empty for standalone customer)
        preferred_delivery_method: Preferred delivery method (Email, Print, or None)
        primary_email_address: Main email address for the customer
        primary_phone: Customer's main phone number
        print_on_check_name: Name to print on checks
        suffix: Suffix of the name (e.g., Jr., Sr., III)
        taxable: Whether the customer is taxable
        title: Title of the person (e.g., Mr., Mrs., Dr.)
    ### When action = 'update_customer'
        active: Whether the customer is active
        add_billing_address: Add billing address details
        balance: Opening balance
        company_name: Legal or trade name of the customer's business
        customer_id: QuickBooks ID of the customer to retrieve
        display_name: Customer display name
        family_name: Customer's last name
        fully_qualified_name: Fully qualified name (hierarchical)
        given_name: Customer's first name
        middle_name: Customer's middle name
        notes: Internal notes about the customer
        parent_customer_id: Parent customer ID for sub-customers (leave empty for standalone customer)
        preferred_delivery_method: Preferred delivery method (Email, Print, or None)
        primary_email_address: Main email address for the customer
        primary_phone: Customer's main phone number
        print_on_check_name: Name to print on checks
        suffix: Suffix of the name (e.g., Jr., Sr., III)
        taxable: Whether the customer is taxable
        title: Title of the person (e.g., Mr., Mrs., Dr.)
    ### When action = 'create_employee'
        active: Whether the customer is active
        add_billing_address: Add billing address details
        billable_time: Whether employee time is billable
        display_name: Customer display name
        family_name: Customer's last name
        given_name: Customer's first name
        primary_email_address: Main email address for the customer
        primary_phone: Customer's main phone number
        print_on_check_name: Name to print on checks
        ssn: Social Security Number
    ### When action = 'update_employee'
        active: Whether the customer is active
        add_billing_address: Add billing address details
        billable_time: Whether employee time is billable
        display_name: Customer display name
        employee_id: QuickBooks ID of the employee to retrieve
        family_name: Customer's last name
        given_name: Customer's first name
        primary_email_address: Main email address for the customer
        primary_phone: Customer's main phone number
        print_on_check_name: Name to print on checks
        ssn: Social Security Number
    ### When action = 'create_bill'
        ap_account_id: Accounts Payable account ID
        doc_number: Document/Reference number
        due_date: Due date for the bill
        line_items: Line items for the bill. Each item should be a JSON object with: account_id (required), amount (required), description (optional), detail_type (optional), item_id (optional), position (optional)
        private_note: Private note/memo for internal use
        sales_term_id: Sales term ID (e.g., Net 30)
        txn_date: Transaction date
        vendor_id: QuickBooks ID of the vendor
    ### When action = 'update_bill'
        ap_account_id: Accounts Payable account ID
        ap_account_name: Accounts Payable account name
        bill_id: QuickBooks ID of the bill to retrieve
        due_date: Due date for the bill
        sales_term_id: Sales term ID (e.g., Net 30)
        sales_term_name: Sales term name
        txn_date: Transaction date
    ### When action = 'create_estimate'
        apply_tax_after_discount: Apply tax after discount
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
        billing_email: Billing email address
        custom_fields: Custom fields for the estimate. Each item should be a JSON object with: id (required - the custom field ID), value (required)
        customer_id: QuickBooks ID of the customer to retrieve
        customer_memo: Message to customer
        doc_number: Document/Reference number
        email_status: Email status
        line_items: Line items for the bill. Each item should be a JSON object with: account_id (required), amount (required), description (optional), detail_type (optional), item_id (optional), position (optional)
        print_status: Print status
        shipping_address_city: Shipping city
        shipping_address_country: Shipping country
        shipping_address_line: Shipping street address
        shipping_address_postal_code: Shipping postal code
        shipping_address_state: Shipping state/province
        txn_date: Transaction date
    ### When action = 'update_estimate'
        apply_tax_after_discount: Apply tax after discount
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
        billing_email: Billing email address
        customer_memo: Message to customer
        doc_number: Document/Reference number
        email_status: Email status
        estimate_id: QuickBooks ID of the estimate to retrieve
        print_status: Print status
        shipping_address_city: Shipping city
        shipping_address_country: Shipping country
        shipping_address_line: Shipping street address
        shipping_address_postal_code: Shipping postal code
        shipping_address_state: Shipping state/province
        txn_date: Transaction date
    ### When action = 'get_bill'
        bill_id: QuickBooks ID of the bill to retrieve
    ### When action = 'delete_bill'
        bill_id: QuickBooks ID of the bill to retrieve
    ### When action = 'create_customer' and add_billing_address = True
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
    ### When action = 'update_customer' and add_billing_address = True
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
    ### When action = 'create_employee' and add_billing_address = True
        billing_address_city: City
        billing_address_country_subdivision_code: State or province code (e.g., CA, NY)
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
    ### When action = 'update_employee' and add_billing_address = True
        billing_address_city: City
        billing_address_country_subdivision_code: State or province code (e.g., CA, NY)
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
    ### When action = 'create_invoice'
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
        billing_email: Billing email address
        custom_fields: Custom fields for the estimate. Each item should be a JSON object with: id (required - the custom field ID), value (required)
        customer_id: QuickBooks ID of the customer to retrieve
        customer_memo: Message to customer
        doc_number: Document/Reference number
        due_date: Due date for the bill
        email_status: Email status
        line_items: Line items for the bill. Each item should be a JSON object with: account_id (required), amount (required), description (optional), detail_type (optional), item_id (optional), position (optional)
        print_status: Print status
        shipping_address_city: Shipping city
        shipping_address_country: Shipping country
        shipping_address_line: Shipping street address
        shipping_address_postal_code: Shipping postal code
        shipping_address_state: Shipping state/province
        txn_date: Transaction date
    ### When action = 'update_invoice'
        billing_address_city: City
        billing_address_country: Country
        billing_address_line: Street address line
        billing_address_postal_code: Postal/ZIP code
        billing_address_state: State or province code
        billing_email: Billing email address
        customer_memo: Message to customer
        doc_number: Document/Reference number
        due_date: Due date for the bill
        email_status: Email status
        invoice_id: QuickBooks ID of the invoice to retrieve
        print_status: Print status
        shipping_address_city: Shipping city
        shipping_address_country: Shipping country
        shipping_address_line: Shipping street address
        shipping_address_postal_code: Shipping postal code
        shipping_address_state: Shipping state/province
        txn_date: Transaction date
    ### When action = 'get_customer'
        customer_id: QuickBooks ID of the customer to retrieve
    ### When action = 'create_payment'
        customer_id: QuickBooks ID of the customer to retrieve
        total_amount: Total payment amount
        txn_date: Transaction date
    ### When action = 'send_estimate'
        email: Email address to send the estimate to
        estimate_id: QuickBooks ID of the estimate to retrieve
    ### When action = 'send_payment'
        email: Email address to send the estimate to
        payment_id: QuickBooks ID of the payment to retrieve
    ### When action = 'send_invoice'
        email: Email address to send the estimate to
        invoice_id: QuickBooks ID of the invoice to retrieve
    ### When action = 'get_employee'
        employee_id: QuickBooks ID of the employee to retrieve
    ### When action = 'get_estimate'
        estimate_id: QuickBooks ID of the estimate to retrieve
    ### When action = 'delete_estimate'
        estimate_id: QuickBooks ID of the estimate to retrieve
    ### When action = 'get_invoice'
        invoice_id: QuickBooks ID of the invoice to retrieve
    ### When action = 'delete_invoice'
        invoice_id: QuickBooks ID of the invoice to retrieve
    ### When action = 'void_invoice'
        invoice_id: QuickBooks ID of the invoice to retrieve
    ### When action = 'list_bills' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_customers' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_employees' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_estimates' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_items' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_payments' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_purchases' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_vendors' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'list_invoices' and return_all = False
        limit: Maximum number of bills to return
    ### When action = 'get_payment'
        payment_id: QuickBooks ID of the payment to retrieve
    ### When action = 'update_payment'
        payment_id: QuickBooks ID of the payment to retrieve
        txn_date: Transaction date
    ### When action = 'delete_payment'
        payment_id: QuickBooks ID of the payment to retrieve
    ### When action = 'void_payment'
        payment_id: QuickBooks ID of the payment to retrieve
    ### When action = 'get_purchase'
        purchase_id: QuickBooks ID of the purchase to retrieve
    ### When action = 'get_item'
        quickbooks_item_id: QuickBooks ID of the item to retrieve
    ### When action = 'get_vendor'
        vendor_id: QuickBooks ID of the vendor

    ## Outputs
    ### When action = 'create_customer'
        active: Whether customer is active
        balance: Outstanding balance
        company_name: Company name
        display_name: Customer display name
        id: Created customer ID
        raw_data: Complete customer data from QuickBooks
    ### When action = 'get_customer'
        active: Whether customer is active
        balance: Outstanding balance
        company_name: Company name
        display_name: Customer display name
        email: Primary email address
        id: Customer ID
        raw_data: Complete customer data from QuickBooks
    ### When action = 'update_customer'
        active: Whether customer is active
        balance: Outstanding balance
        company_name: Company name
        display_name: Customer display name
        id: Updated customer ID
        raw_data: Complete customer data from QuickBooks
    ### When action = 'create_employee'
        active: Whether employee is active
        display_name: Employee display name
        family_name: Last name
        given_name: First name
        id: Created employee ID
        raw_data: Complete employee data from QuickBooks
    ### When action = 'get_employee'
        active: Whether employee is active
        display_name: Employee display name
        email: Primary email address
        family_name: Last name
        given_name: First name
        id: Employee ID
        raw_data: Complete employee data from QuickBooks
    ### When action = 'update_employee'
        active: Whether employee is active
        display_name: Employee display name
        family_name: Last name
        given_name: First name
        id: Updated employee ID
        raw_data: Complete employee data from QuickBooks
    ### When action = 'get_item'
        active: Whether the item is active
        description: Item description
        id: Item ID
        name: Item name
        qty_on_hand: Quantity on hand (for inventory items)
        raw_data: Complete item data from QuickBooks
        type: Item type (Service, Inventory, NonInventory)
        unit_price: Unit price
    ### When action = 'get_vendor'
        active: Whether vendor is active
        display_name: Vendor display name
        id: Vendor ID
        raw_data: Complete vendor data from QuickBooks
    ### When action = 'create_bill'
        balance: Outstanding balance
        doc_number: Bill number/reference
        due_date: Payment due date
        id: Created bill ID
        raw_data: Complete bill data from QuickBooks
        total_amt: Total amount
    ### When action = 'get_bill'
        balance: Outstanding balance
        doc_number: Bill number/reference
        due_date: Payment due date
        id: Bill ID
        raw_data: Complete bill data from QuickBooks
        total_amt: Total amount
    ### When action = 'update_bill'
        balance: Outstanding balance
        doc_number: Bill number/reference
        due_date: Payment due date
        id: Updated bill ID
        raw_data: Complete bill data from QuickBooks
        total_amt: Total amount
    ### When action = 'create_invoice'
        balance: Balance due
        doc_number: Invoice number/reference
        due_date: Payment due date
        id: Created invoice ID
        raw_data: Complete invoice data from QuickBooks
        total_amt: Total amount
        txn_date: Transaction date
    ### When action = 'update_invoice'
        balance: Balance due
        doc_number: Invoice number/reference
        due_date: Payment due date
        id: Updated invoice ID
        raw_data: Complete invoice data from QuickBooks
        total_amt: Total amount
        txn_date: Transaction date
    ### When action = 'delete_bill'
        bill_id: ID of the deleted bill
        raw_data: Complete response from QuickBooks
    ### When action = 'list_bills'
        bill_ids: List of bill IDs
        bills: Array of bills
        count: Number of bills returned
        raw_data: Complete response from QuickBooks
        return_all: Whether all bills were returned
    ### When action = 'list_customers'
        count: Number of customers returned
        customer_ids: List of customer IDs
        customers: Array of customers
        raw_data: Complete response from QuickBooks
        return_all: Whether all customers were returned
    ### When action = 'list_employees'
        count: Number of employees returned
        employee_ids: List of employee IDs
        employees: Array of employees
        raw_data: Complete response from QuickBooks
    ### When action = 'list_estimates'
        count: Number of estimates returned
        estimate_ids: List of estimate IDs
        estimates: Array of estimates
        raw_data: Complete response from QuickBooks
    ### When action = 'list_items'
        count: Number of items returned
        item_ids: List of item IDs
        items: Array of items
        raw_data: Complete response from QuickBooks
        return_all: Whether all items were returned
    ### When action = 'list_payments'
        count: Number of payments returned
        payment_ids: List of payment IDs
        payments: Array of payments
        raw_data: Complete response from QuickBooks
        return_all: Whether all payments were returned
    ### When action = 'list_purchases'
        count: Number of purchases returned
        purchase_ids: List of purchase IDs
        purchases: Array of purchases
        raw_data: Complete response from QuickBooks
        return_all: Whether all purchases were returned
    ### When action = 'list_vendors'
        count: Number of vendors returned
        raw_data: Complete response from QuickBooks
        return_all: Whether all vendors were returned
        vendor_ids: List of vendor IDs
        vendors: Array of vendors
    ### When action = 'list_invoices'
        count: Number of invoices returned
        invoice_ids: List of invoice IDs
        invoices: Array of invoices
        raw_data: Complete response from QuickBooks
        return_all: Whether all invoices were returned
    ### When action = 'create_vendor'
        display_name: Vendor display name
        id: Created vendor ID
        raw_data: Complete vendor data from QuickBooks
    ### When action = 'update_vendor'
        display_name: Vendor display name
        id: Updated vendor ID
        raw_data: Complete vendor data from QuickBooks
    ### When action = 'create_estimate'
        doc_number: Estimate number/reference
        expiration_date: Expiration date
        id: Created estimate ID
        raw_data: Complete estimate data from QuickBooks
        total_amt: Total amount
        total_tax: Total tax amount
        txn_date: Transaction date
    ### When action = 'get_estimate'
        doc_number: Estimate number/reference
        file: Estimate PDF file
        file_name: PDF file name
        id: Estimate ID
    ### When action = 'update_estimate'
        doc_number: Estimate number/reference
        expiration_date: Expiration date
        id: Updated estimate ID
        raw_data: Complete estimate data from QuickBooks
        total_amt: Total amount
        total_tax: Total tax amount
        txn_date: Transaction date
    ### When action = 'send_estimate'
        email: Email address the estimate was sent to
        estimate_id: ID of the sent estimate
        raw_data: Complete response from QuickBooks
    ### When action = 'send_payment'
        email: Email address the payment was sent to
        payment_id: ID of the sent payment
        raw_data: Complete response from QuickBooks
    ### When action = 'send_invoice'
        email: Email address the invoice was sent to
        invoice_id: ID of the sent invoice
        raw_data: Complete response from QuickBooks
    ### When action = 'delete_estimate'
        estimate_id: ID of the deleted estimate
        raw_data: Complete response from QuickBooks
    ### When action = 'get_payment'
        file: Payment PDF file
        file_name: PDF file name
        id: Payment ID
    ### When action = 'get_invoice'
        file: Invoice PDF file
        file_name: PDF file name
        id: Invoice ID
    ### When action = 'create_payment'
        id: Created payment ID
        raw_data: Complete payment data from QuickBooks
        total_amount: Total payment amount
        txn_date: Transaction date
    ### When action = 'update_payment'
        id: Updated payment ID
        raw_data: Complete payment data from QuickBooks
        total_amount: Total payment amount
        txn_date: Transaction date
    ### When action = 'get_purchase'
        id: Purchase ID
        raw_data: Complete purchase data from QuickBooks
        total_amt: Total amount
        txn_date: Transaction date
    ### When action = 'delete_invoice'
        invoice_id: ID of the deleted invoice
        raw_data: Complete response from QuickBooks
    ### When action = 'void_invoice'
        invoice_id: ID of the voided invoice
        raw_data: Complete response from QuickBooks
    ### When action = 'delete_payment'
        payment_id: ID of the deleted payment
        raw_data: Complete response from QuickBooks
    ### When action = 'void_payment'
        payment_id: ID of the voided payment
        raw_data: Complete response from QuickBooks
    ### When action = 'list_transactions'
        raw_data: Complete response from QuickBooks API
        transaction_ids: List of transaction IDs
        transactions: Transaction data from QuickBooks
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your QuickBooks account",
            "value": None,
            "type": "integration<QuickBooks>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_bill**(*)**(*)": {
            "inputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the vendor",
                    "label": "Vendor id",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=vendor_id&parent_id=vendors&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "line_items",
                    "type": "vec<string>",
                    "value": [""],
                    "helper_text": "Line items for the bill. Each item should be a JSON object with: account_id (required), amount (required), description (optional), detail_type (optional), item_id (optional), position (optional)",
                    "label": "Line",
                    "placeholder": '{"account_id":"35","amount":100.00,"description":"Office Supplies"}',
                },
                {
                    "field": "ap_account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Accounts Payable account ID",
                    "label": "Accounts Payable Account",
                    "placeholder": "33",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date for the bill",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
                {
                    "field": "sales_term_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sales term ID (e.g., Net 30)",
                    "label": "Sales Term",
                    "placeholder": "3",
                },
                {
                    "field": "doc_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Document/Reference number",
                    "label": "Document Number",
                    "placeholder": "INV-001",
                },
                {
                    "field": "private_note",
                    "type": "string",
                    "value": "",
                    "helper_text": "Private note/memo for internal use",
                    "label": "Private Note",
                    "placeholder": "Internal notes",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created bill ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Bill number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {
                    "field": "balance",
                    "type": "float",
                    "helper_text": "Outstanding balance",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Payment due date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete bill data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_bill",
            "task_name": "tasks.quickbooks.create_bill",
            "description": "Create a new bill in QuickBooks",
            "label": "Create Bill",
            "required": ["vendor_id", "line_items"],
            "inputs_sort_order": [
                "integration",
                "action",
                "vendor_id",
                "line_items",
                "ap_account_id",
                "due_date",
                "txn_date",
                "sales_term_id",
                "doc_number",
                "private_note",
            ],
        },
        "get_bill**(*)**(*)": {
            "inputs": [
                {
                    "field": "bill_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the bill to retrieve",
                    "label": "Bill ID",
                    "placeholder": "145",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Bill ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Bill number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {
                    "field": "balance",
                    "type": "float",
                    "helper_text": "Outstanding balance",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Payment due date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete bill data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_bill",
            "task_name": "tasks.quickbooks.get_bill",
            "description": "Retrieve a bill from QuickBooks by ID",
            "label": "Get Bill",
            "required": ["bill_id"],
            "inputs_sort_order": ["integration", "action", "bill_id"],
        },
        "list_bills**(*)**(*)": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (e.g., Balance > 0 or DueDate > '2024-01-01')",
                    "label": "Query",
                    "placeholder": "WHERE Balance > '0'",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all bills or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
            ],
            "outputs": [
                {
                    "field": "bill_ids",
                    "type": "vec<string>",
                    "helper_text": "List of bill IDs",
                },
                {
                    "field": "bills",
                    "type": "vec<string>",
                    "helper_text": "Array of bills",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of bills returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all bills were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_bills",
            "task_name": "tasks.quickbooks.list_bills",
            "description": "List bills from QuickBooks",
            "label": "List Bills",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "query",
            ],
        },
        "list_bills**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of bills to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_bill**(*)**(*)": {
            "inputs": [
                {
                    "field": "bill_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the bill to update",
                    "label": "Bill ID",
                    "placeholder": "145",
                },
                {
                    "field": "ap_account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Accounts Payable account ID",
                    "label": "Accounts Payable Account ID",
                    "placeholder": "33",
                },
                {
                    "field": "ap_account_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Accounts Payable account name",
                    "label": "Accounts Payable Account Name",
                    "placeholder": "Accounts Payable",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date for the bill",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
                {
                    "field": "sales_term_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sales term ID (e.g., Net 30)",
                    "label": "Sales Term ID",
                    "placeholder": "3",
                },
                {
                    "field": "sales_term_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sales term name",
                    "label": "Sales Term Name",
                    "placeholder": "Net 30",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated bill ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Bill number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {
                    "field": "balance",
                    "type": "float",
                    "helper_text": "Outstanding balance",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Payment due date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete bill data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_bill",
            "task_name": "tasks.quickbooks.update_bill",
            "description": "Update an existing bill in QuickBooks (only non-empty fields are updated)",
            "label": "Update Bill",
            "required": ["bill_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "bill_id",
                "ap_account_id",
                "ap_account_name",
                "due_date",
                "txn_date",
                "sales_term_id",
                "sales_term_name",
            ],
        },
        "delete_bill**(*)**(*)": {
            "inputs": [
                {
                    "field": "bill_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the bill to delete",
                    "label": "Bill ID",
                    "placeholder": "145",
                }
            ],
            "outputs": [
                {
                    "field": "bill_id",
                    "type": "string",
                    "helper_text": "ID of the deleted bill",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_bill",
            "task_name": "tasks.quickbooks.delete_bill",
            "description": "Delete a bill from QuickBooks",
            "label": "Delete Bill",
            "required": ["bill_id"],
            "inputs_sort_order": ["integration", "action", "bill_id"],
        },
        "create_customer**(*)**(*)": {
            "inputs": [
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer display name",
                    "label": "Display Name",
                    "placeholder": "King's Groceries",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Legal or trade name of the customer's business",
                    "label": "Company Name",
                    "placeholder": "King Groceries",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the person (e.g., Mr., Mrs., Dr.)",
                    "label": "Title",
                    "placeholder": "Mr",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's first name",
                    "label": "Given Name",
                    "placeholder": "James",
                },
                {
                    "field": "middle_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's middle name",
                    "label": "Middle Name",
                    "placeholder": "B",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's last name",
                    "label": "Family Name",
                    "placeholder": "King",
                },
                {
                    "field": "suffix",
                    "type": "string",
                    "value": "",
                    "helper_text": "Suffix of the name (e.g., Jr., Sr., III)",
                    "label": "Suffix",
                    "placeholder": "Jr",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Internal notes about the customer",
                    "label": "Notes",
                    "placeholder": "Here are other details",
                },
                {
                    "field": "primary_email_address",
                    "type": "string",
                    "value": "",
                    "helper_text": "Main email address for the customer",
                    "label": "Primary Email Address",
                    "placeholder": "jdrew@myemail.com",
                },
                {
                    "field": "primary_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's main phone number",
                    "label": "Primary Phone",
                    "placeholder": "(555) 555-5555",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the customer is active",
                    "label": "Active",
                    "placeholder": "true",
                },
                {
                    "field": "taxable",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the customer is taxable",
                    "label": "Taxable",
                    "placeholder": "false",
                },
                {
                    "field": "parent_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Parent customer ID for sub-customers (leave empty for standalone customer)",
                    "label": "Parent Customer ID",
                    "placeholder": "52",
                },
                {
                    "field": "balance",
                    "type": "float",
                    "value": 0,
                    "helper_text": "Opening balance",
                    "label": "Balance",
                    "placeholder": "0.00",
                },
                {
                    "field": "preferred_delivery_method",
                    "type": "string",
                    "value": "Email",
                    "label": "Preferred Delivery Method",
                    "helper_text": "Preferred delivery method (Email, Print, or None)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Email", "value": "Email"},
                            {"label": "Print", "value": "Print"},
                        ],
                    },
                },
                {
                    "field": "print_on_check_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name to print on checks",
                    "label": "Print On Check Name",
                    "placeholder": "King Groceries",
                },
                {
                    "field": "fully_qualified_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fully qualified name (hierarchical)",
                    "label": "Fully Qualified Name",
                    "placeholder": "Parent:Sub-Customer",
                },
                {
                    "field": "add_billing_address",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Add billing address details",
                    "label": "Billing Address",
                    "placeholder": "false",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created customer ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Customer display name",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "Company name",
                },
                {
                    "field": "balance",
                    "type": "float",
                    "helper_text": "Outstanding balance",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether customer is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete customer data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_customer",
            "task_name": "tasks.quickbooks.create_customer",
            "description": "Create a new customer in QuickBooks",
            "label": "Create Customer",
            "required": ["display_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "display_name",
                "company_name",
                "title",
                "given_name",
                "middle_name",
                "family_name",
                "suffix",
                "notes",
                "primary_email_address",
                "primary_phone",
                "active",
                "taxable",
                "parent_customer_id",
                "balance",
                "preferred_delivery_method",
                "print_on_check_name",
                "fully_qualified_name",
                "add_billing_address",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
            ],
        },
        "create_customer**(*)**true": {
            "inputs": [
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address line",
                    "label": "Billing address line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City",
                    "label": "City",
                    "placeholder": "Mountain View",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "State or province code",
                    "label": "State/province",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal/ZIP code",
                    "label": "Postal code",
                    "placeholder": "94042",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Country",
                    "label": "Country",
                    "placeholder": "USA",
                },
            ],
            "outputs": [],
        },
        "get_customer**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the customer to retrieve",
                    "label": "Customer ID",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&parent_id=customers&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Customer ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Customer display name",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "Company name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "balance",
                    "type": "float",
                    "helper_text": "Outstanding balance",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether customer is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete customer data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_customer",
            "task_name": "tasks.quickbooks.get_customer",
            "description": "Retrieve a customer from QuickBooks by ID",
            "label": "Get Customer",
            "required": ["customer_id"],
            "inputs_sort_order": ["integration", "action", "customer_id"],
        },
        "list_customers**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all customers or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (e.g., Active = true or Balance > 100)",
                    "label": "Query",
                    "placeholder": "WHERE Active = true",
                },
            ],
            "outputs": [
                {
                    "field": "customer_ids",
                    "type": "vec<string>",
                    "helper_text": "List of customer IDs",
                },
                {
                    "field": "customers",
                    "type": "vec<string>",
                    "helper_text": "Array of customers",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of customers returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all customers were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_customers",
            "task_name": "tasks.quickbooks.list_customers",
            "description": "List customers from QuickBooks",
            "label": "List Customers",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_customers**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of customers to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_customer**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the customer to update",
                    "label": "Customer ID",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&parent_id=customers&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer display name",
                    "label": "Display Name",
                    "placeholder": "King's Groceries",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Legal or trade name of the customer's business",
                    "label": "Company Name",
                    "placeholder": "King Groceries",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the person (e.g., Mr., Mrs., Dr.)",
                    "label": "Title",
                    "placeholder": "Mr",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's first name",
                    "label": "Given Name",
                    "placeholder": "James",
                },
                {
                    "field": "middle_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's middle name",
                    "label": "Middle Name",
                    "placeholder": "B",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's last name",
                    "label": "Family Name",
                    "placeholder": "King",
                },
                {
                    "field": "suffix",
                    "type": "string",
                    "value": "",
                    "helper_text": "Suffix of the name (e.g., Jr., Sr., III)",
                    "label": "Suffix",
                    "placeholder": "Jr",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "helper_text": "Internal notes about the customer",
                    "label": "Notes",
                    "placeholder": "Here are other details",
                },
                {
                    "field": "primary_email_address",
                    "type": "string",
                    "value": "",
                    "helper_text": "Main email address for the customer",
                    "label": "Primary Email Address",
                    "placeholder": "jdrew@myemail.com",
                },
                {
                    "field": "primary_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer's main phone number",
                    "label": "Primary Phone",
                    "placeholder": "(555) 555-5555",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the customer is active",
                    "label": "Active",
                    "placeholder": "true",
                },
                {
                    "field": "taxable",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the customer is taxable",
                    "label": "Taxable",
                    "placeholder": "false",
                },
                {
                    "field": "parent_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Parent customer ID for sub-customers (leave empty for standalone customer)",
                    "label": "Parent Customer ID",
                    "placeholder": "52",
                },
                {
                    "field": "balance",
                    "type": "float",
                    "value": 0,
                    "helper_text": "Opening balance",
                    "label": "Balance",
                    "placeholder": "0.00",
                },
                {
                    "field": "preferred_delivery_method",
                    "type": "string",
                    "value": "Email",
                    "helper_text": "Preferred delivery method (Email, Print, or None)",
                    "label": "Preferred Delivery Method",
                    "placeholder": "Email",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Email", "value": "Email"},
                            {"label": "Print", "value": "Print"},
                        ],
                    },
                },
                {
                    "field": "print_on_check_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name to print on checks",
                    "label": "Print On Check Name",
                    "placeholder": "King Groceries",
                },
                {
                    "field": "fully_qualified_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fully qualified name (hierarchical)",
                    "label": "Fully Qualified Name",
                    "placeholder": "Parent:Sub-Customer",
                },
                {
                    "field": "add_billing_address",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Add billing address details",
                    "label": "Billing Address",
                    "placeholder": "false",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated customer ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Customer display name",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "Company name",
                },
                {
                    "field": "balance",
                    "type": "float",
                    "helper_text": "Outstanding balance",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether customer is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete customer data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_customer",
            "task_name": "tasks.quickbooks.update_customer",
            "description": "Update a customer in QuickBooks (only non-empty fields are updated)",
            "label": "Update Customer",
            "required": ["customer_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "customer_id",
                "display_name",
                "company_name",
                "title",
                "given_name",
                "middle_name",
                "family_name",
                "suffix",
                "notes",
                "primary_email_address",
                "primary_phone",
                "active",
                "taxable",
                "parent_customer_id",
                "balance",
                "preferred_delivery_method",
                "print_on_check_name",
                "fully_qualified_name",
                "add_billing_address",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
            ],
        },
        "update_customer**(*)**true": {
            "inputs": [
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address line",
                    "label": "Billing address line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City",
                    "label": "City",
                    "placeholder": "Mountain View",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "State or province code",
                    "label": "State/province",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal/ZIP code",
                    "label": "Postal code",
                    "placeholder": "94042",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Country",
                    "label": "Country",
                    "placeholder": "USA",
                },
            ],
            "outputs": [],
        },
        "create_employee**(*)**(*)": {
            "inputs": [
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee's last name",
                    "label": "Family Name",
                    "placeholder": "Doe",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee's first name",
                    "label": "Given Name",
                    "placeholder": "John",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee display name",
                    "label": "Display Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "primary_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee's main phone number",
                    "label": "Primary Phone",
                    "placeholder": "(555) 555-5555",
                },
                {
                    "field": "primary_email_address",
                    "type": "string",
                    "value": "",
                    "helper_text": "Main email address for the employee",
                    "label": "Primary Email Address",
                    "placeholder": "john.doe@example.com",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the employee is active",
                    "label": "Active",
                    "placeholder": "true",
                },
                {
                    "field": "billable_time",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether employee time is billable",
                    "label": "Billable Time",
                    "placeholder": "false",
                },
                {
                    "field": "print_on_check_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name to print on checks",
                    "label": "Print On Check Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "ssn",
                    "type": "string",
                    "value": "",
                    "helper_text": "Social Security Number",
                    "label": "Social Security Number",
                    "placeholder": "XXX-XX-XXXX",
                },
                {
                    "field": "add_billing_address",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Add billing address details",
                    "label": "Billing Address",
                    "placeholder": "false",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created employee ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Employee display name",
                },
                {"field": "given_name", "type": "string", "helper_text": "First name"},
                {"field": "family_name", "type": "string", "helper_text": "Last name"},
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether employee is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete employee data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_employee",
            "task_name": "tasks.quickbooks.create_employee",
            "description": "Create a new employee in QuickBooks",
            "label": "Create Employee",
            "required": ["family_name", "given_name", "display_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "family_name",
                "given_name",
                "display_name",
                "primary_phone",
                "primary_email_address",
                "active",
                "billable_time",
                "print_on_check_name",
                "ssn",
                "add_billing_address",
                "billing_address_line",
                "billing_address_city",
                "billing_address_country_subdivision_code",
                "billing_address_postal_code",
            ],
        },
        "create_employee**(*)**true": {
            "inputs": [
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address line",
                    "label": "Line 1",
                    "placeholder": "45 N. Elm Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City",
                    "label": "City",
                    "placeholder": "Middlefield",
                },
                {
                    "field": "billing_address_country_subdivision_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "State or province code (e.g., CA, NY)",
                    "label": "Country Subdivision Code",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal/ZIP code",
                    "label": "Postal Code",
                    "placeholder": "93242",
                },
            ],
            "outputs": [],
        },
        "get_employee**(*)**(*)": {
            "inputs": [
                {
                    "field": "employee_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the employee to retrieve",
                    "label": "Employee ID",
                    "placeholder": "1",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Employee ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Employee display name",
                },
                {"field": "given_name", "type": "string", "helper_text": "First name"},
                {"field": "family_name", "type": "string", "helper_text": "Last name"},
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Primary email address",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether employee is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete employee data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_employee",
            "task_name": "tasks.quickbooks.get_employee",
            "description": "Retrieve an employee from QuickBooks by ID",
            "label": "Get Employee",
            "required": ["employee_id"],
            "inputs_sort_order": ["integration", "action", "employee_id"],
        },
        "list_employees**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all employees or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (e.g., Active = true or GivenName = 'John')",
                    "label": "Query",
                    "placeholder": "WHERE Active = true",
                },
            ],
            "outputs": [
                {
                    "field": "employee_ids",
                    "type": "vec<string>",
                    "helper_text": "List of employee IDs",
                },
                {
                    "field": "employees",
                    "type": "vec<string>",
                    "helper_text": "Array of employees",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of employees returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_employees",
            "task_name": "tasks.quickbooks.list_employees",
            "description": "List employees from QuickBooks",
            "label": "List Employees",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_employees**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of employees to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_employee**(*)**(*)": {
            "inputs": [
                {
                    "field": "employee_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the employee to update",
                    "label": "Employee ID",
                    "placeholder": "1",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee's first name",
                    "label": "Given Name",
                    "placeholder": "John",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee's last name",
                    "label": "Family Name",
                    "placeholder": "Doe",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee display name",
                    "label": "Display Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "primary_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Employee's main phone number",
                    "label": "Primary Phone",
                    "placeholder": "(555) 555-5555",
                },
                {
                    "field": "primary_email_address",
                    "type": "string",
                    "value": "",
                    "helper_text": "Main email address for the employee",
                    "label": "Primary Email Address",
                    "placeholder": "john.doe@example.com",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the employee is active",
                    "label": "Active",
                    "placeholder": "true",
                },
                {
                    "field": "billable_time",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether employee time is billable",
                    "label": "Billable Time",
                    "placeholder": "false",
                },
                {
                    "field": "print_on_check_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name to print on checks",
                    "label": "Print On Check Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "ssn",
                    "type": "string",
                    "value": "",
                    "helper_text": "Social Security Number",
                    "label": "Social Security Number",
                    "placeholder": "XXX-XX-XXXX",
                },
                {
                    "field": "add_billing_address",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Add billing address details",
                    "label": "Billing Address",
                    "placeholder": "false",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated employee ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Employee display name",
                },
                {"field": "given_name", "type": "string", "helper_text": "First name"},
                {"field": "family_name", "type": "string", "helper_text": "Last name"},
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether employee is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete employee data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_employee",
            "task_name": "tasks.quickbooks.update_employee",
            "description": "Update an employee in QuickBooks (only non-empty fields are updated)",
            "label": "Update Employee",
            "required": ["employee_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "employee_id",
                "given_name",
                "family_name",
                "display_name",
                "primary_phone",
                "primary_email_address",
                "active",
                "billable_time",
                "print_on_check_name",
                "ssn",
                "add_billing_address",
                "billing_address_line",
                "billing_address_city",
                "billing_address_country_subdivision_code",
                "billing_address_postal_code",
            ],
        },
        "update_employee**(*)**true": {
            "inputs": [
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address line",
                    "label": "Line 1",
                    "placeholder": "45 N. Elm Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City",
                    "label": "City",
                    "placeholder": "Middlefield",
                },
                {
                    "field": "billing_address_country_subdivision_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "State or province code (e.g., CA, NY)",
                    "label": "Country Subdivision Code",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal/ZIP code",
                    "label": "Postal Code",
                    "placeholder": "93242",
                },
            ],
            "outputs": [],
        },
        "create_estimate**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the customer",
                    "label": "Customer ID",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&parent_id=customers&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "line_items",
                    "type": "vec<string>",
                    "value": [""],
                    "helper_text": "Line items for the estimate. Each item should be a JSON object with: amount (required), description (optional), detail_type (optional), item_id (optional), position (optional), quantity (optional), tax_code_ref_id (optional)",
                    "label": "Line",
                    "placeholder": '{"amount":100.00,"description":"Consulting Services","item_id":"1","quantity":5}',
                },
                {
                    "field": "custom_fields",
                    "type": "vec<string>",
                    "value": [""],
                    "helper_text": "Custom fields for the estimate. Each item should be a JSON object with: id (required - the custom field ID), value (required)",
                    "label": "Custom Fields",
                    "placeholder": '{"id":"1","value":"PROJ-2025-001"}',
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
                {
                    "field": "doc_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Document/Reference number",
                    "label": "Document Number",
                    "placeholder": "EST-001",
                },
                {
                    "field": "customer_memo",
                    "type": "string",
                    "value": "",
                    "helper_text": "Message to customer",
                    "label": "Customer Memo",
                    "placeholder": "Thank you for your business",
                },
                {
                    "field": "billing_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing email address",
                    "label": "Billing Email",
                    "placeholder": "billing@example.com",
                },
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Address Line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing Address City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state/province",
                    "label": "Billing Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Address Postal Code",
                    "placeholder": "94102",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "shipping_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping street address",
                    "label": "Shipping Address Line",
                    "placeholder": "456 Oak Avenue",
                },
                {
                    "field": "shipping_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping city",
                    "label": "Shipping Address City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "shipping_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping state/province",
                    "label": "Shipping Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "shipping_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping postal code",
                    "label": "Shipping Address Postal Code",
                    "placeholder": "90001",
                },
                {
                    "field": "shipping_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping country",
                    "label": "Shipping Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "apply_tax_after_discount",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Apply tax after discount",
                    "label": "Apply Tax After Discount",
                    "placeholder": "false",
                },
                {
                    "field": "print_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Print status",
                    "label": "Print Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_print_status",
                    },
                },
                {
                    "field": "email_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email status",
                    "label": "Email Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_email_status",
                    },
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created estimate ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Estimate number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {
                    "field": "total_tax",
                    "type": "float",
                    "helper_text": "Total tax amount",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "expiration_date",
                    "type": "timestamp",
                    "helper_text": "Expiration date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete estimate data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_estimate",
            "task_name": "tasks.quickbooks.create_estimate",
            "description": "Create a new estimate in QuickBooks",
            "label": "Create Estimate",
            "required": ["customer_id", "line_items"],
            "inputs_sort_order": [
                "integration",
                "action",
                "customer_id",
                "line_items",
                "custom_fields",
                "txn_date",
                "doc_number",
                "customer_memo",
                "billing_email",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
                "shipping_address_line",
                "shipping_address_city",
                "shipping_address_state",
                "shipping_address_postal_code",
                "shipping_address_country",
                "apply_tax_after_discount",
                "print_status",
                "email_status",
            ],
        },
        "get_estimate**(*)**(*)": {
            "inputs": [
                {
                    "field": "estimate_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the estimate to retrieve",
                    "label": "Estimate ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Estimate ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Estimate number/reference",
                },
                {"field": "file", "type": "file", "helper_text": "Estimate PDF file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "PDF file name",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_estimate",
            "task_name": "tasks.quickbooks.get_estimate",
            "description": "Retrieve an estimate PDF from QuickBooks by ID",
            "label": "Get Estimate",
            "required": ["estimate_id"],
            "inputs_sort_order": ["integration", "action", "estimate_id"],
        },
        "list_estimates**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all estimates or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (e.g., TotalAmt > 1000 or TxnDate > '2024-01-01')",
                    "label": "Query",
                    "placeholder": "WHERE TotalAmt > 1000",
                },
            ],
            "outputs": [
                {
                    "field": "estimate_ids",
                    "type": "vec<string>",
                    "helper_text": "List of estimate IDs",
                },
                {
                    "field": "estimates",
                    "type": "vec<string>",
                    "helper_text": "Array of estimates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of estimates returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_estimates",
            "task_name": "tasks.quickbooks.list_estimates",
            "description": "List estimates from QuickBooks",
            "label": "List Estimates",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_estimates**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of estimates to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_estimate**(*)**(*)": {
            "inputs": [
                {
                    "field": "estimate_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the estimate to update",
                    "label": "Estimate ID",
                    "placeholder": "123",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
                {
                    "field": "doc_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Document/Reference number",
                    "label": "Document Number",
                    "placeholder": "EST-001",
                },
                {
                    "field": "customer_memo",
                    "type": "string",
                    "value": "",
                    "helper_text": "Message to customer",
                    "label": "Customer Memo",
                    "placeholder": "Thank you for your business",
                },
                {
                    "field": "billing_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing email address",
                    "label": "Billing Email",
                    "placeholder": "billing@example.com",
                },
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Address Line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing Address City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state/province",
                    "label": "Billing Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Address Postal Code",
                    "placeholder": "94102",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "shipping_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping street address",
                    "label": "Shipping Address Line",
                    "placeholder": "456 Oak Avenue",
                },
                {
                    "field": "shipping_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping city",
                    "label": "Shipping Address City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "shipping_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping state/province",
                    "label": "Shipping Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "shipping_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping postal code",
                    "label": "Shipping Address Postal Code",
                    "placeholder": "90001",
                },
                {
                    "field": "shipping_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping country",
                    "label": "Shipping Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "apply_tax_after_discount",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Apply tax after discount",
                    "label": "Apply Tax After Discount",
                    "placeholder": "false",
                },
                {
                    "field": "print_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Print status",
                    "label": "Print Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_print_status",
                    },
                },
                {
                    "field": "email_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email status",
                    "label": "Email Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_email_status",
                    },
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated estimate ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Estimate number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {
                    "field": "total_tax",
                    "type": "float",
                    "helper_text": "Total tax amount",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "expiration_date",
                    "type": "timestamp",
                    "helper_text": "Expiration date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete estimate data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_estimate",
            "task_name": "tasks.quickbooks.update_estimate",
            "description": "Update an existing estimate in QuickBooks (only non-empty fields are updated)",
            "label": "Update Estimate",
            "required": ["estimate_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "estimate_id",
                "txn_date",
                "doc_number",
                "customer_memo",
                "billing_email",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
                "shipping_address_line",
                "shipping_address_city",
                "shipping_address_state",
                "shipping_address_postal_code",
                "shipping_address_country",
                "apply_tax_after_discount",
                "print_status",
                "email_status",
            ],
        },
        "delete_estimate**(*)**(*)": {
            "inputs": [
                {
                    "field": "estimate_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the estimate to delete",
                    "label": "Estimate ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {
                    "field": "estimate_id",
                    "type": "string",
                    "helper_text": "ID of the deleted estimate",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_estimate",
            "task_name": "tasks.quickbooks.delete_estimate",
            "description": "Delete an estimate from QuickBooks",
            "label": "Delete Estimate",
            "required": ["estimate_id"],
            "inputs_sort_order": ["integration", "action", "estimate_id"],
        },
        "send_estimate**(*)**(*)": {
            "inputs": [
                {
                    "field": "estimate_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the estimate to send",
                    "label": "Estimate ID",
                    "placeholder": "123",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address to send the estimate to",
                    "label": "Email",
                    "placeholder": "customer@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "estimate_id",
                    "type": "string",
                    "helper_text": "ID of the sent estimate",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address the estimate was sent to",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_estimate",
            "task_name": "tasks.quickbooks.send_estimate",
            "description": "Send an estimate via email in QuickBooks",
            "label": "Send Estimate",
            "required": ["estimate_id", "email"],
            "inputs_sort_order": ["integration", "action", "estimate_id", "email"],
        },
        "get_item**(*)**(*)": {
            "inputs": [
                {
                    "field": "quickbooks_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the item to retrieve",
                    "label": "Item ID",
                    "placeholder": "1",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Item ID"},
                {"field": "name", "type": "string", "helper_text": "Item name"},
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Item type (Service, Inventory, NonInventory)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Item description",
                },
                {"field": "unit_price", "type": "float", "helper_text": "Unit price"},
                {
                    "field": "qty_on_hand",
                    "type": "float",
                    "helper_text": "Quantity on hand (for inventory items)",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether the item is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete item data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_item",
            "task_name": "tasks.quickbooks.get_item",
            "description": "Read an item from QuickBooks by ID",
            "label": "Get Item",
            "required": ["quickbooks_item_id"],
            "inputs_sort_order": ["integration", "action", "quickbooks_item_id"],
        },
        "list_items**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all items or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (e.g., Active = true or Type = 'Service')",
                    "label": "Query",
                    "placeholder": "WHERE Active = true",
                },
            ],
            "outputs": [
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of item IDs",
                },
                {
                    "field": "items",
                    "type": "vec<string>",
                    "helper_text": "Array of items",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of items returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all items were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_items",
            "task_name": "tasks.quickbooks.list_items",
            "description": "List items from QuickBooks",
            "label": "List Items",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_items**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of items to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "create_payment**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the customer",
                    "label": "Customer id",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&parent_id=customers&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "total_amount",
                    "type": "float",
                    "value": 0,
                    "helper_text": "Total payment amount",
                    "label": "Total Amount",
                    "placeholder": "100.00",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created payment ID"},
                {
                    "field": "total_amount",
                    "type": "float",
                    "helper_text": "Total payment amount",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete payment data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_payment",
            "task_name": "tasks.quickbooks.create_payment",
            "description": "Create a new payment in QuickBooks",
            "label": "Create Payment",
            "required": ["customer_id", "total_amount"],
            "inputs_sort_order": [
                "integration",
                "action",
                "customer_id",
                "total_amount",
                "txn_date",
            ],
        },
        "get_payment**(*)**(*)": {
            "inputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the payment to retrieve",
                    "label": "Payment ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Payment ID"},
                {"field": "file", "type": "file", "helper_text": "Payment PDF file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "PDF file name",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_payment",
            "task_name": "tasks.quickbooks.get_payment",
            "description": "Retrieve a payment PDF from QuickBooks by ID",
            "label": "Get Payment",
            "required": ["payment_id"],
            "inputs_sort_order": ["integration", "action", "payment_id"],
        },
        "list_payments**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all payments or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (use single quotes for strings, e.g., TotalAmt > 100 or TxnDate > '2024-01-01')",
                    "label": "Query",
                    "placeholder": "WHERE TotalAmt > 100",
                },
            ],
            "outputs": [
                {
                    "field": "payment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of payment IDs",
                },
                {
                    "field": "payments",
                    "type": "vec<string>",
                    "helper_text": "Array of payments",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of payments returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all payments were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_payments",
            "task_name": "tasks.quickbooks.list_payments",
            "description": "List payments from QuickBooks",
            "label": "List Payments",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_payments**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of payments to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_payment**(*)**(*)": {
            "inputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the payment to update",
                    "label": "Payment ID",
                    "placeholder": "123",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated payment ID"},
                {
                    "field": "total_amount",
                    "type": "float",
                    "helper_text": "Total payment amount",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete payment data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_payment",
            "task_name": "tasks.quickbooks.update_payment",
            "description": "Update an existing payment in QuickBooks (only non-empty fields are updated)",
            "label": "Update Payment",
            "required": ["payment_id"],
            "inputs_sort_order": ["integration", "action", "payment_id", "txn_date"],
        },
        "delete_payment**(*)**(*)": {
            "inputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the payment to delete",
                    "label": "Payment ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "helper_text": "ID of the deleted payment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_payment",
            "task_name": "tasks.quickbooks.delete_payment",
            "description": "Delete a payment from QuickBooks",
            "label": "Delete Payment",
            "required": ["payment_id"],
            "inputs_sort_order": ["integration", "action", "payment_id"],
        },
        "send_payment**(*)**(*)": {
            "inputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the payment to send",
                    "label": "Payment ID",
                    "placeholder": "123",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address to send the payment to",
                    "label": "Email",
                    "placeholder": "customer@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "helper_text": "ID of the sent payment",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address the payment was sent to",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_payment",
            "task_name": "tasks.quickbooks.send_payment",
            "description": "Send a payment via email in QuickBooks",
            "label": "Send Payment",
            "required": ["payment_id", "email"],
            "inputs_sort_order": ["integration", "action", "payment_id", "email"],
        },
        "void_payment**(*)**(*)": {
            "inputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the payment to void",
                    "label": "Payment ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {
                    "field": "payment_id",
                    "type": "string",
                    "helper_text": "ID of the voided payment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "void_payment",
            "task_name": "tasks.quickbooks.void_payment",
            "description": "Void a payment in QuickBooks",
            "label": "Void Payment",
            "required": ["payment_id"],
            "inputs_sort_order": ["integration", "action", "payment_id"],
        },
        "get_purchase**(*)**(*)": {
            "inputs": [
                {
                    "field": "purchase_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the purchase to retrieve",
                    "label": "Purchase ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Purchase ID"},
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete purchase data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_purchase",
            "task_name": "tasks.quickbooks.get_purchase",
            "description": "Retrieve a purchase from QuickBooks by ID",
            "label": "Get Purchase",
            "required": ["purchase_id"],
            "inputs_sort_order": ["integration", "action", "purchase_id"],
        },
        "list_purchases**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all purchases or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (use single quotes for strings, e.g., TotalAmt > 100 or TxnDate > '2024-01-01')",
                    "label": "Query",
                    "placeholder": "WHERE TotalAmt > 100",
                },
            ],
            "outputs": [
                {
                    "field": "purchase_ids",
                    "type": "vec<string>",
                    "helper_text": "List of purchase IDs",
                },
                {
                    "field": "purchases",
                    "type": "vec<string>",
                    "helper_text": "Array of purchases",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of purchases returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all purchases were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_purchases",
            "task_name": "tasks.quickbooks.list_purchases",
            "description": "List purchases from QuickBooks",
            "label": "List Purchases",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_purchases**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of purchases to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "create_vendor**(*)**(*)": {
            "inputs": [
                {
                    "field": "display_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor display name",
                    "label": "Display Name",
                    "placeholder": "ABC Supplies",
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Account number",
                    "label": "Account Number",
                    "placeholder": "V-1001",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the vendor is active",
                    "label": "Active",
                    "placeholder": "true",
                },
                {
                    "field": "balance",
                    "type": "float",
                    "value": 0,
                    "helper_text": "Opening balance",
                    "label": "Balance",
                    "placeholder": "0.00",
                },
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Address Line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing Address City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state/province",
                    "label": "Billing Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Address Postal Code",
                    "placeholder": "94102",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Legal or trade name of the vendor's business",
                    "label": "Company Name",
                    "placeholder": "ABC Supplies Inc",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor's last name",
                    "label": "Family Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor's first name",
                    "label": "Given Name",
                    "placeholder": "John",
                },
                {
                    "field": "primary_email_address",
                    "type": "string",
                    "value": "",
                    "helper_text": "Main email address for the vendor",
                    "label": "Primary Email Address",
                    "placeholder": "john@abcsupplies.com",
                },
                {
                    "field": "primary_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor's main phone number",
                    "label": "Primary Phone",
                    "placeholder": "(555) 555-5555",
                },
                {
                    "field": "print_on_check_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name to print on checks",
                    "label": "Print-On-Check Name",
                    "placeholder": "ABC Supplies",
                },
                {
                    "field": "vendor_1099",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the vendor receives 1099",
                    "label": "Vendor 1099",
                    "placeholder": "false",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created vendor ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Vendor display name",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete vendor data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_vendor",
            "task_name": "tasks.quickbooks.create_vendor",
            "description": "Create a new vendor in QuickBooks",
            "label": "Create Vendor",
            "required": ["display_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "display_name",
                "account_number",
                "active",
                "balance",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
                "company_name",
                "family_name",
                "given_name",
                "primary_email_address",
                "primary_phone",
                "print_on_check_name",
                "vendor_1099",
            ],
        },
        "get_vendor**(*)**(*)": {
            "inputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the vendor to retrieve",
                    "label": "Vendor ID",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=vendor_id&parent_id=vendors&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Vendor ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Vendor display name",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether vendor is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete vendor data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_vendor",
            "task_name": "tasks.quickbooks.get_vendor",
            "description": "Retrieve a vendor from QuickBooks by ID",
            "label": "Get Vendor",
            "required": ["vendor_id"],
            "inputs_sort_order": ["integration", "action", "vendor_id"],
        },
        "list_vendors**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all vendors or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (use single quotes for strings, e.g., Active = true or DisplayName = 'ABC')",
                    "label": "Query",
                    "placeholder": "WHERE Active = true",
                },
            ],
            "outputs": [
                {
                    "field": "vendor_ids",
                    "type": "vec<string>",
                    "helper_text": "List of vendor IDs",
                },
                {
                    "field": "vendors",
                    "type": "vec<string>",
                    "helper_text": "Array of vendors",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of vendors returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all vendors were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_vendors",
            "task_name": "tasks.quickbooks.list_vendors",
            "description": "List vendors from QuickBooks",
            "label": "List Vendors",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_vendors**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of vendors to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_vendor**(*)**(*)": {
            "inputs": [
                {
                    "field": "vendor_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the vendor to update",
                    "label": "Vendor ID",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=vendor_id&parent_id=vendors&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "account_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Account number",
                    "label": "Account Number",
                    "placeholder": "V-1001",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the vendor is active",
                    "label": "Active",
                    "placeholder": "true",
                },
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Address Line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing Address City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state/province",
                    "label": "Billing Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Address Postal Code",
                    "placeholder": "94102",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Legal or trade name of the vendor's business",
                    "label": "Company Name",
                    "placeholder": "ABC Supplies Inc",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor's last name",
                    "label": "Family Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor's first name",
                    "label": "Given Name",
                    "placeholder": "John",
                },
                {
                    "field": "primary_email_address",
                    "type": "string",
                    "value": "",
                    "helper_text": "Main email address for the vendor",
                    "label": "Primary Email Address",
                    "placeholder": "john@abcsupplies.com",
                },
                {
                    "field": "primary_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor's main phone number",
                    "label": "Primary Phone",
                    "placeholder": "(555) 555-5555",
                },
                {
                    "field": "print_on_check_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name to print on checks",
                    "label": "Print-On-Check Name",
                    "placeholder": "ABC Supplies",
                },
                {
                    "field": "vendor_1099",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the vendor receives 1099",
                    "label": "Vendor 1099",
                    "placeholder": "false",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated vendor ID"},
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Vendor display name",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete vendor data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_vendor",
            "task_name": "tasks.quickbooks.update_vendor",
            "description": "Update an existing vendor in QuickBooks (only non-empty fields are updated)",
            "label": "Update Vendor",
            "required": ["vendor_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "vendor_id",
                "account_number",
                "active",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
                "company_name",
                "family_name",
                "given_name",
                "primary_email_address",
                "primary_phone",
                "print_on_check_name",
                "vendor_1099",
            ],
        },
        "create_invoice**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the customer",
                    "label": "Customer id",
                    "placeholder": "1",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&parent_id=customers&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "line_items",
                    "type": "vec<string>",
                    "value": [""],
                    "helper_text": "Line items for the invoice. Each item should be a JSON object with: amount (required), description (optional), detail_type (optional), item_id (optional), position (optional), tax_code_ref_id (optional), quantity (optional)",
                    "label": "Line",
                    "placeholder": '{"amount":100.00,"description":"Consulting Services","item_id":"1","quantity":1}',
                },
                {
                    "field": "custom_fields",
                    "type": "vec<string>",
                    "value": [""],
                    "helper_text": "Custom fields for the invoice. Each item should be a JSON object with: id (required - the custom field ID), value (required)",
                    "label": "Custom Fields",
                    "placeholder": '{"id":"1","value":"John Smith"}',
                },
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Address Line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing Address City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state/province",
                    "label": "Billing Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Address Postal Code",
                    "placeholder": "94102",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "billing_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing email address",
                    "label": "Billing Email",
                    "placeholder": "billing@example.com",
                },
                {
                    "field": "customer_memo",
                    "type": "string",
                    "value": "",
                    "helper_text": "Message to customer",
                    "label": "Customer Memo",
                    "placeholder": "Thank you for your business",
                },
                {
                    "field": "doc_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Document/Invoice number",
                    "label": "Document Number",
                    "placeholder": "INV-001",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Payment due date",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "email_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email status",
                    "label": "Email Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_email_status",
                    },
                },
                {
                    "field": "print_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Print status",
                    "label": "Print Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_print_status",
                    },
                },
                {
                    "field": "shipping_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping street address",
                    "label": "Shipping Address Line",
                    "placeholder": "456 Oak Avenue",
                },
                {
                    "field": "shipping_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping city",
                    "label": "Shipping Address City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "shipping_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping state/province",
                    "label": "Shipping Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "shipping_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping postal code",
                    "label": "Shipping Address Postal Code",
                    "placeholder": "90001",
                },
                {
                    "field": "shipping_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping country",
                    "label": "Shipping Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Created invoice ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Invoice number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {"field": "balance", "type": "float", "helper_text": "Balance due"},
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Payment due date",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete invoice data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_invoice",
            "task_name": "tasks.quickbooks.create_invoice",
            "description": "Create a new invoice in QuickBooks",
            "label": "Create Invoice",
            "required": ["customer_id", "line_items"],
            "inputs_sort_order": [
                "integration",
                "action",
                "customer_id",
                "line_items",
                "custom_fields",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
                "billing_email",
                "customer_memo",
                "doc_number",
                "due_date",
                "email_status",
                "print_status",
                "shipping_address_line",
                "shipping_address_city",
                "shipping_address_state",
                "shipping_address_postal_code",
                "shipping_address_country",
                "txn_date",
            ],
        },
        "get_invoice**(*)**(*)": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the invoice to retrieve",
                    "label": "Invoice ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Invoice ID"},
                {"field": "file", "type": "file", "helper_text": "Invoice PDF file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "PDF file name",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_invoice",
            "task_name": "tasks.quickbooks.get_invoice",
            "description": "Retrieve an invoice PDF from QuickBooks by ID",
            "label": "Get Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": ["integration", "action", "invoice_id"],
        },
        "list_invoices**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return all invoices or limit results",
                    "label": "Return All",
                    "placeholder": "true",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional filter condition (use single quotes for strings, e.g., TotalAmt > 100 or WHERE MetaData.LastUpdatedTime > '2021-01-01')",
                    "label": "Query",
                    "placeholder": "WHERE TotalAmt > '100'",
                },
            ],
            "outputs": [
                {
                    "field": "invoice_ids",
                    "type": "vec<string>",
                    "helper_text": "List of invoice IDs",
                },
                {
                    "field": "invoices",
                    "type": "vec<string>",
                    "helper_text": "Array of invoices",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of invoices returned",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "helper_text": "Whether all invoices were returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_invoices",
            "task_name": "tasks.quickbooks.list_invoices",
            "description": "List invoices from QuickBooks",
            "label": "List Invoices",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "query",
                "limit",
            ],
        },
        "list_invoices**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of invoices to return",
                    "label": "Limit",
                    "placeholder": "10",
                }
            ],
            "outputs": [],
        },
        "update_invoice**(*)**(*)": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the invoice to update",
                    "label": "Invoice ID",
                    "placeholder": "123",
                },
                {
                    "field": "billing_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Address Line",
                    "placeholder": "123 Main Street",
                },
                {
                    "field": "billing_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing Address City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state/province",
                    "label": "Billing Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Address Postal Code",
                    "placeholder": "94102",
                },
                {
                    "field": "billing_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "billing_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing email address",
                    "label": "Billing Email",
                    "placeholder": "billing@example.com",
                },
                {
                    "field": "customer_memo",
                    "type": "string",
                    "value": "",
                    "helper_text": "Message to customer",
                    "label": "Customer Memo",
                    "placeholder": "Thank you for your business",
                },
                {
                    "field": "doc_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Document/Invoice number",
                    "label": "Document Number",
                    "placeholder": "INV-001",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Payment due date",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "email_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email status",
                    "label": "Email Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_email_status",
                    },
                },
                {
                    "field": "print_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Print status",
                    "label": "Print Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_print_status",
                    },
                },
                {
                    "field": "shipping_address_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping street address",
                    "label": "Shipping Address Line",
                    "placeholder": "456 Oak Avenue",
                },
                {
                    "field": "shipping_address_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping city",
                    "label": "Shipping Address City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "shipping_address_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping state/province",
                    "label": "Shipping Address State",
                    "placeholder": "CA",
                },
                {
                    "field": "shipping_address_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping postal code",
                    "label": "Shipping Address Postal Code",
                    "placeholder": "90001",
                },
                {
                    "field": "shipping_address_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Shipping country",
                    "label": "Shipping Address Country",
                    "placeholder": "USA",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date",
                    "label": "Transaction Date",
                    "placeholder": "2024-01-15",
                },
            ],
            "outputs": [
                {"field": "id", "type": "string", "helper_text": "Updated invoice ID"},
                {
                    "field": "doc_number",
                    "type": "string",
                    "helper_text": "Invoice number/reference",
                },
                {"field": "total_amt", "type": "float", "helper_text": "Total amount"},
                {"field": "balance", "type": "float", "helper_text": "Balance due"},
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Payment due date",
                },
                {
                    "field": "txn_date",
                    "type": "timestamp",
                    "helper_text": "Transaction date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete invoice data from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_invoice",
            "task_name": "tasks.quickbooks.update_invoice",
            "description": "Update an existing invoice in QuickBooks (only non-empty fields are updated)",
            "label": "Update Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "invoice_id",
                "billing_address_line",
                "billing_address_city",
                "billing_address_state",
                "billing_address_postal_code",
                "billing_address_country",
                "billing_email",
                "customer_memo",
                "doc_number",
                "due_date",
                "email_status",
                "print_status",
                "shipping_address_line",
                "shipping_address_city",
                "shipping_address_state",
                "shipping_address_postal_code",
                "shipping_address_country",
                "txn_date",
            ],
        },
        "delete_invoice**(*)**(*)": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the invoice to delete",
                    "label": "Invoice ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "ID of the deleted invoice",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_invoice",
            "task_name": "tasks.quickbooks.delete_invoice",
            "description": "Delete an invoice from QuickBooks",
            "label": "Delete Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": ["integration", "action", "invoice_id"],
        },
        "send_invoice**(*)**(*)": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the invoice to send",
                    "label": "Invoice ID",
                    "placeholder": "123",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address to send the invoice to",
                    "label": "Email",
                    "placeholder": "customer@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "ID of the sent invoice",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address the invoice was sent to",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_invoice",
            "task_name": "tasks.quickbooks.send_invoice",
            "description": "Send an invoice via email in QuickBooks",
            "label": "Send Invoice",
            "required": ["invoice_id", "email"],
            "inputs_sort_order": ["integration", "action", "invoice_id", "email"],
        },
        "void_invoice**(*)**(*)": {
            "inputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "QuickBooks ID of the invoice to void",
                    "label": "Invoice ID",
                    "placeholder": "123",
                }
            ],
            "outputs": [
                {
                    "field": "invoice_id",
                    "type": "string",
                    "helper_text": "ID of the voided invoice",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "void_invoice",
            "task_name": "tasks.quickbooks.void_invoice",
            "description": "Void an invoice in QuickBooks",
            "label": "Void Invoice",
            "required": ["invoice_id"],
            "inputs_sort_order": ["integration", "action", "invoice_id"],
        },
        "list_transactions**(*)**(*)": {
            "inputs": [
                {
                    "field": "transaction_type",
                    "type": "string",
                    "value": "Invoice",
                    "helper_text": "Type of transaction to query",
                    "label": "Transaction Type",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_transaction_type",
                    },
                },
                {
                    "field": "accounts_payable_paid",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by Accounts Payable payment status",
                    "label": "Accounts Payable Paid",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Paid", "value": "true"},
                            {"label": "Unpaid", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "accounts_receivable_paid",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by Accounts Receivable payment status",
                    "label": "Accounts Receivable Paid",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Paid", "value": "true"},
                            {"label": "Unpaid", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "cleared_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by cleared status",
                    "label": "Cleared Status",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Cleared", "value": "Cleared"},
                            {"label": "Uncleared", "value": "Uncleared"},
                            {"label": "Reconciled", "value": "Reconciled"},
                            {"label": "Deposited", "value": "Deposited"},
                        ],
                    },
                },
                {
                    "field": "customer_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer IDs (comma-separated for multiple)",
                    "label": "Customer IDs",
                    "placeholder": "123,456",
                    "hidden": True,
                },
                {
                    "field": "date_range_from",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date from (YYYY-MM-DD)",
                    "label": "Date Range (Custom) - From",
                    "placeholder": "2024-01-01",
                    "hidden": True,
                },
                {
                    "field": "date_range_to",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Transaction date to (YYYY-MM-DD)",
                    "label": "Date Range (Custom) - To",
                    "placeholder": "2024-12-31",
                    "hidden": True,
                },
                {
                    "field": "date_range_predefined",
                    "type": "string",
                    "value": "",
                    "helper_text": "Predefined date range for transaction date",
                    "label": "Date Range (Predefined)",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_date_range",
                    },
                },
                {
                    "field": "creation_date_from",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Creation date from (YYYY-MM-DD)",
                    "label": "Date Range for Creation Date (Custom) - From",
                    "placeholder": "2024-01-01",
                    "hidden": True,
                },
                {
                    "field": "creation_date_to",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Creation date to (YYYY-MM-DD)",
                    "label": "Date Range for Creation Date (Custom) - To",
                    "placeholder": "2024-12-31",
                    "hidden": True,
                },
                {
                    "field": "creation_date_predefined",
                    "type": "string",
                    "value": "",
                    "helper_text": "Predefined date range for creation date",
                    "label": "Date Range for Creation Date (Predefined)",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_date_range",
                    },
                },
                {
                    "field": "due_date_from",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date from (YYYY-MM-DD)",
                    "label": "Date Range for Due Date (Custom) - From",
                    "placeholder": "2024-01-01",
                    "hidden": True,
                },
                {
                    "field": "due_date_to",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date to (YYYY-MM-DD)",
                    "label": "Date Range for Due Date (Custom) - To",
                    "placeholder": "2024-12-31",
                    "hidden": True,
                },
                {
                    "field": "due_date_predefined",
                    "type": "string",
                    "value": "",
                    "helper_text": "Predefined date range for due date",
                    "label": "Date Range for Due Date (Predefined)",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_date_range",
                    },
                },
                {
                    "field": "modification_date_from",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Modification date from (YYYY-MM-DD)",
                    "label": "Date Range for Modification Date (Custom) - From",
                    "placeholder": "2024-01-01",
                    "hidden": True,
                },
                {
                    "field": "modification_date_to",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Modification date to (YYYY-MM-DD)",
                    "label": "Date Range for Modification Date (Custom) - To",
                    "placeholder": "2024-12-31",
                    "hidden": True,
                },
                {
                    "field": "modification_date_predefined",
                    "type": "string",
                    "value": "",
                    "helper_text": "Predefined date range for modification date",
                    "label": "Date Range for Modification Date (Predefined)",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_date_range",
                    },
                },
                {
                    "field": "department_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Department IDs (comma-separated for multiple)",
                    "label": "Department IDs",
                    "placeholder": "1,2,3",
                    "hidden": True,
                },
                {
                    "field": "document_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Document/Reference number",
                    "label": "Document Number",
                    "placeholder": "INV-001",
                    "hidden": True,
                },
                {
                    "field": "group_by",
                    "type": "string",
                    "value": "",
                    "helper_text": "Field to group results by",
                    "label": "Group By",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_group_by",
                    },
                },
                {
                    "field": "memo_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search text in private notes/memos",
                    "label": "Memo IDs",
                    "placeholder": "Office supplies",
                    "hidden": True,
                },
                {
                    "field": "payment_method",
                    "type": "string",
                    "value": "",
                    "helper_text": "Payment method",
                    "label": "Payment Method",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_payment_method",
                    },
                },
                {
                    "field": "printed_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by print status",
                    "label": "Printed Status",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Not Printed", "value": "NotSet"},
                            {"label": "Printed", "value": "Printed"},
                            {"label": "Need To Print", "value": "NeedToPrint"},
                        ],
                    },
                },
                {
                    "field": "quick_zoom_url",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include Quick Zoom URL in results",
                    "label": "Quick Zoom URL",
                    "hidden": True,
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "helper_text": "Field to sort by",
                    "label": "Sort By",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_sort_by",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "ascend",
                    "helper_text": "Sort order",
                    "label": "Sort Order",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Ascending", "value": "ascend"},
                            {"label": "Descending", "value": "descend"},
                        ],
                    },
                },
                {
                    "field": "source_account_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source account type",
                    "label": "Source Account Type",
                    "hidden": True,
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "quickbooks_account_type",
                    },
                },
                {
                    "field": "term_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Term IDs (comma-separated for multiple)",
                    "label": "Term IDs",
                    "placeholder": "1,2",
                    "hidden": True,
                },
                {
                    "field": "bothamount",
                    "type": "float",
                    "value": "",
                    "helper_text": "Monetary amount to filter results by (exact match)",
                    "label": "Transaction Amount",
                    "placeholder": "100.00",
                    "hidden": True,
                },
                {
                    "field": "vendor_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Vendor IDs (comma-separated for multiple)",
                    "label": "Vendor IDs",
                    "placeholder": "1,2,3",
                    "hidden": True,
                },
            ],
            "outputs": [
                {
                    "field": "transaction_ids",
                    "type": "vec<string>",
                    "helper_text": "List of transaction IDs",
                },
                {
                    "field": "transactions",
                    "type": "string",
                    "helper_text": "Transaction data from QuickBooks",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from QuickBooks API",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_transactions",
            "task_name": "tasks.quickbooks.list_transactions",
            "description": "List transactions from QuickBooks with comprehensive filtering options",
            "label": "List Transactions",
            "inputs_sort_order": [
                "integration",
                "action",
                "transaction_type",
                "accounts_payable_paid",
                "accounts_receivable_paid",
                "cleared_status",
                "customer_ids",
                "date_range_from",
                "date_range_to",
                "date_range_predefined",
                "creation_date_from",
                "creation_date_to",
                "creation_date_predefined",
                "due_date_from",
                "due_date_to",
                "due_date_predefined",
                "modification_date_from",
                "modification_date_to",
                "modification_date_predefined",
                "department_ids",
                "document_number",
                "group_by",
                "memo_ids",
                "payment_method",
                "printed_status",
                "quick_zoom_url",
                "sort_by",
                "sort_order",
                "source_account_type",
                "term_ids",
                "bothamount",
                "vendor_ids",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "return_all", "add_billing_address"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        return_all: bool = True,
        add_billing_address: bool = False,
        query: str = "",
        account_number: str = "",
        accounts_payable_paid: str = "",
        accounts_receivable_paid: str = "",
        active: bool = True,
        ap_account_id: str = "",
        ap_account_name: str = "",
        apply_tax_after_discount: bool = False,
        balance: Any = 0,
        bill_id: str = "",
        billable_time: bool = False,
        billing_address_city: str = "",
        billing_address_country: str = "",
        billing_address_country_subdivision_code: str = "",
        billing_address_line: str = "",
        billing_address_postal_code: str = "",
        billing_address_state: str = "",
        billing_email: str = "",
        bothamount: Any = None,
        cleared_status: str = "",
        company_name: str = "",
        creation_date_from: Any = None,
        creation_date_predefined: str = "",
        creation_date_to: Any = None,
        custom_fields: List[str] = [""],
        customer_id: str = "",
        customer_ids: str = "",
        customer_memo: str = "",
        date_range_from: Any = None,
        date_range_predefined: str = "",
        date_range_to: Any = None,
        department_ids: str = "",
        display_name: str = "",
        doc_number: str = "",
        document_number: str = "",
        due_date: Any = None,
        due_date_from: Any = None,
        due_date_predefined: str = "",
        due_date_to: Any = None,
        email: str = "",
        email_status: str = "",
        employee_id: str = "",
        estimate_id: str = "",
        family_name: str = "",
        fully_qualified_name: str = "",
        given_name: str = "",
        group_by: str = "",
        invoice_id: str = "",
        limit: int = 10,
        line_items: List[str] = [""],
        memo_ids: str = "",
        middle_name: str = "",
        modification_date_from: Any = None,
        modification_date_predefined: str = "",
        modification_date_to: Any = None,
        notes: str = "",
        parent_customer_id: str = "",
        payment_id: str = "",
        payment_method: str = "",
        preferred_delivery_method: str = "Email",
        primary_email_address: str = "",
        primary_phone: str = "",
        print_on_check_name: str = "",
        print_status: str = "",
        printed_status: str = "",
        private_note: str = "",
        purchase_id: str = "",
        quick_zoom_url: bool = False,
        quickbooks_item_id: str = "",
        sales_term_id: str = "",
        sales_term_name: str = "",
        shipping_address_city: str = "",
        shipping_address_country: str = "",
        shipping_address_line: str = "",
        shipping_address_postal_code: str = "",
        shipping_address_state: str = "",
        sort_by: str = "",
        sort_order: str = "ascend",
        source_account_type: str = "",
        ssn: str = "",
        suffix: str = "",
        taxable: bool = False,
        term_ids: str = "",
        title: str = "",
        total_amount: Any = 0,
        transaction_type: str = "Invoice",
        txn_date: Any = None,
        vendor_1099: bool = False,
        vendor_id: str = "",
        vendor_ids: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["return_all"] = return_all
        params["add_billing_address"] = add_billing_address

        super().__init__(
            node_type="integration_quickbooks",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if vendor_id is not None:
            self.inputs["vendor_id"] = vendor_id
        if line_items is not None:
            self.inputs["line_items"] = line_items
        if ap_account_id is not None:
            self.inputs["ap_account_id"] = ap_account_id
        if due_date is not None:
            self.inputs["due_date"] = due_date
        if txn_date is not None:
            self.inputs["txn_date"] = txn_date
        if sales_term_id is not None:
            self.inputs["sales_term_id"] = sales_term_id
        if doc_number is not None:
            self.inputs["doc_number"] = doc_number
        if private_note is not None:
            self.inputs["private_note"] = private_note
        if bill_id is not None:
            self.inputs["bill_id"] = bill_id
        if query is not None:
            self.inputs["query"] = query
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if ap_account_name is not None:
            self.inputs["ap_account_name"] = ap_account_name
        if sales_term_name is not None:
            self.inputs["sales_term_name"] = sales_term_name
        if display_name is not None:
            self.inputs["display_name"] = display_name
        if company_name is not None:
            self.inputs["company_name"] = company_name
        if title is not None:
            self.inputs["title"] = title
        if given_name is not None:
            self.inputs["given_name"] = given_name
        if middle_name is not None:
            self.inputs["middle_name"] = middle_name
        if family_name is not None:
            self.inputs["family_name"] = family_name
        if suffix is not None:
            self.inputs["suffix"] = suffix
        if notes is not None:
            self.inputs["notes"] = notes
        if primary_email_address is not None:
            self.inputs["primary_email_address"] = primary_email_address
        if primary_phone is not None:
            self.inputs["primary_phone"] = primary_phone
        if active is not None:
            self.inputs["active"] = active
        if taxable is not None:
            self.inputs["taxable"] = taxable
        if parent_customer_id is not None:
            self.inputs["parent_customer_id"] = parent_customer_id
        if balance is not None:
            self.inputs["balance"] = balance
        if preferred_delivery_method is not None:
            self.inputs["preferred_delivery_method"] = preferred_delivery_method
        if print_on_check_name is not None:
            self.inputs["print_on_check_name"] = print_on_check_name
        if fully_qualified_name is not None:
            self.inputs["fully_qualified_name"] = fully_qualified_name
        if add_billing_address is not None:
            self.inputs["add_billing_address"] = add_billing_address
        if billing_address_line is not None:
            self.inputs["billing_address_line"] = billing_address_line
        if billing_address_city is not None:
            self.inputs["billing_address_city"] = billing_address_city
        if billing_address_state is not None:
            self.inputs["billing_address_state"] = billing_address_state
        if billing_address_postal_code is not None:
            self.inputs["billing_address_postal_code"] = billing_address_postal_code
        if billing_address_country is not None:
            self.inputs["billing_address_country"] = billing_address_country
        if customer_id is not None:
            self.inputs["customer_id"] = customer_id
        if billable_time is not None:
            self.inputs["billable_time"] = billable_time
        if ssn is not None:
            self.inputs["ssn"] = ssn
        if billing_address_country_subdivision_code is not None:
            self.inputs["billing_address_country_subdivision_code"] = (
                billing_address_country_subdivision_code
            )
        if employee_id is not None:
            self.inputs["employee_id"] = employee_id
        if custom_fields is not None:
            self.inputs["custom_fields"] = custom_fields
        if customer_memo is not None:
            self.inputs["customer_memo"] = customer_memo
        if billing_email is not None:
            self.inputs["billing_email"] = billing_email
        if shipping_address_line is not None:
            self.inputs["shipping_address_line"] = shipping_address_line
        if shipping_address_city is not None:
            self.inputs["shipping_address_city"] = shipping_address_city
        if shipping_address_state is not None:
            self.inputs["shipping_address_state"] = shipping_address_state
        if shipping_address_postal_code is not None:
            self.inputs["shipping_address_postal_code"] = shipping_address_postal_code
        if shipping_address_country is not None:
            self.inputs["shipping_address_country"] = shipping_address_country
        if apply_tax_after_discount is not None:
            self.inputs["apply_tax_after_discount"] = apply_tax_after_discount
        if print_status is not None:
            self.inputs["print_status"] = print_status
        if email_status is not None:
            self.inputs["email_status"] = email_status
        if estimate_id is not None:
            self.inputs["estimate_id"] = estimate_id
        if email is not None:
            self.inputs["email"] = email
        if quickbooks_item_id is not None:
            self.inputs["quickbooks_item_id"] = quickbooks_item_id
        if total_amount is not None:
            self.inputs["total_amount"] = total_amount
        if payment_id is not None:
            self.inputs["payment_id"] = payment_id
        if purchase_id is not None:
            self.inputs["purchase_id"] = purchase_id
        if account_number is not None:
            self.inputs["account_number"] = account_number
        if vendor_1099 is not None:
            self.inputs["vendor_1099"] = vendor_1099
        if invoice_id is not None:
            self.inputs["invoice_id"] = invoice_id
        if transaction_type is not None:
            self.inputs["transaction_type"] = transaction_type
        if accounts_payable_paid is not None:
            self.inputs["accounts_payable_paid"] = accounts_payable_paid
        if accounts_receivable_paid is not None:
            self.inputs["accounts_receivable_paid"] = accounts_receivable_paid
        if cleared_status is not None:
            self.inputs["cleared_status"] = cleared_status
        if customer_ids is not None:
            self.inputs["customer_ids"] = customer_ids
        if date_range_from is not None:
            self.inputs["date_range_from"] = date_range_from
        if date_range_to is not None:
            self.inputs["date_range_to"] = date_range_to
        if date_range_predefined is not None:
            self.inputs["date_range_predefined"] = date_range_predefined
        if creation_date_from is not None:
            self.inputs["creation_date_from"] = creation_date_from
        if creation_date_to is not None:
            self.inputs["creation_date_to"] = creation_date_to
        if creation_date_predefined is not None:
            self.inputs["creation_date_predefined"] = creation_date_predefined
        if due_date_from is not None:
            self.inputs["due_date_from"] = due_date_from
        if due_date_to is not None:
            self.inputs["due_date_to"] = due_date_to
        if due_date_predefined is not None:
            self.inputs["due_date_predefined"] = due_date_predefined
        if modification_date_from is not None:
            self.inputs["modification_date_from"] = modification_date_from
        if modification_date_to is not None:
            self.inputs["modification_date_to"] = modification_date_to
        if modification_date_predefined is not None:
            self.inputs["modification_date_predefined"] = modification_date_predefined
        if department_ids is not None:
            self.inputs["department_ids"] = department_ids
        if document_number is not None:
            self.inputs["document_number"] = document_number
        if group_by is not None:
            self.inputs["group_by"] = group_by
        if memo_ids is not None:
            self.inputs["memo_ids"] = memo_ids
        if payment_method is not None:
            self.inputs["payment_method"] = payment_method
        if printed_status is not None:
            self.inputs["printed_status"] = printed_status
        if quick_zoom_url is not None:
            self.inputs["quick_zoom_url"] = quick_zoom_url
        if sort_by is not None:
            self.inputs["sort_by"] = sort_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if source_account_type is not None:
            self.inputs["source_account_type"] = source_account_type
        if term_ids is not None:
            self.inputs["term_ids"] = term_ids
        if bothamount is not None:
            self.inputs["bothamount"] = bothamount
        if vendor_ids is not None:
            self.inputs["vendor_ids"] = vendor_ids
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationQuickbooksNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
