"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("output")
class OutputNode(Node):
    """
    Output data of different types from your workflow.

    ## Inputs
    ### Common Inputs
        description: The output description. If pipeline is used as a tool in an agent, the description will be passed to the agent to help the agent know how to fill this output.
        format_output: The format_output input
        output_type: The output_type input
    ### dataframe
        dataframe_type: The type of dataframe to be used
        value: The value input
    ### string
        value: The value input
    ### file
        value: The value input
    ### audio
        value: The value input
    ### json
        value: The value input
    ### image
        value: The value input
    ### stream<string>
        value: The value input
    ### vec<file>
        value: The value input
    ### int32
        value: The value input
    ### float
        value: The value input
    ### bool
        value: The value input
    ### timestamp
        value: The value input

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "description",
            "helper_text": "The output description. If pipeline is used as a tool in an agent, the description will be passed to the agent to help the agent know how to fill this output.",
            "value": "",
            "type": "string",
        },
        {
            "field": "format_output",
            "helper_text": "The format_output input",
            "value": True,
            "type": "bool",
        },
        {
            "field": "output_type",
            "helper_text": "The output_type input",
            "value": "string",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "string": {
            "inputs": [
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "string",
                    "helper_text": "Output raw text",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "file": {
            "inputs": [
                {
                    "field": "value",
                    "type": "file",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "file",
                    "helper_text": "Output file of any type: PDF, Word, Excel, CSV, MP3, JPEG, etc.",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "audio": {
            "inputs": [
                {
                    "field": "value",
                    "type": "audio",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "audio",
                    "helper_text": "Output raw audio. Output can be generated with the text to speech node",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "json": {
            "inputs": [
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "json",
                    "helper_text": "Output JSON (e.g., LLMs can output JSON - input the schema by selecting “JSON Output” in the gear of the LLM)",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "image": {
            "inputs": [
                {
                    "field": "value",
                    "type": "image",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "image",
                    "helper_text": "Output Image(s) (images are of file type PNG)",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "stream<string>": {
            "inputs": [
                {
                    "field": "value",
                    "type": "stream<string>",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "stream<string>",
                    "helper_text": "Output as a stream of raw text",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
            "banner_text": 'Ensure to check "Stream Response" in gear of the LLM',
        },
        "vec<file>": {
            "inputs": [
                {
                    "field": "value",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "vec<file>",
                    "helper_text": "Output a list of files",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "int32": {
            "inputs": [
                {
                    "field": "value",
                    "type": "int32",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "int32",
                    "helper_text": "Output an integer",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "float": {
            "inputs": [
                {
                    "field": "value",
                    "type": "float",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "float",
                    "helper_text": "Output a float",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "bool": {
            "inputs": [
                {
                    "field": "value",
                    "type": "bool",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                    "component": {"type": "bool", "component_field": True},
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "bool",
                    "helper_text": "Output a boolean",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "timestamp": {
            "inputs": [
                {
                    "field": "value",
                    "type": "timestamp",
                    "value": "",
                    "label": "Output",
                    "placeholder": 'Type "{{" to utilize variables',
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "timestamp",
                    "helper_text": "Output a timestamp",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
        "dataframe": {
            "inputs": [
                {
                    "field": "dataframe_type",
                    "type": "string",
                    "value": "table",
                    "label": "Dataframe Type",
                    "helper_text": "The type of dataframe to be used",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Table", "value": "table"},
                            {"label": "SQL", "value": "sql"},
                            {"label": "CSV", "value": "csv"},
                            {"label": "JSON", "value": "json"},
                            {"label": "MD", "value": "md"},
                            {"label": "File", "value": "dataframe_file"},
                        ],
                    },
                    "visibility": False,
                },
                {
                    "field": "output_type",
                    "label": "Type",
                    "type": "string",
                    "value": "dataframe",
                    "helper_text": "Output a dataframe/table (can display as table view or download as CSV/JSON)",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "value",
                    "type": "dataframe",
                    "value": {
                        "object_info": {"object_id": "", "object_type": ObjectType.TABLE}
                    },
                    "label": "Output",
                    "helper_text": "The dataframe to aggregate",
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["output_type"]

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = ["value"]

    def __init__(
        self,
        output_type: str = "string",
        dataframe_type: str = "table",
        description: str = "",
        format_output: bool = True,
        value: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["output_type"] = output_type

        super().__init__(
            node_type="output",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if output_type is not None:
            self.inputs["output_type"] = output_type
        if description is not None:
            self.inputs["description"] = description
        if format_output is not None:
            self.inputs["format_output"] = format_output
        if value is not None:
            self.inputs["value"] = value
        if dataframe_type is not None:
            self.inputs["dataframe_type"] = dataframe_type
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "OutputNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
