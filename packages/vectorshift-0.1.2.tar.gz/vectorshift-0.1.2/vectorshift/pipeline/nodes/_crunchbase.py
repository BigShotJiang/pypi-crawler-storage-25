"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("crunchbase")
class CrunchbaseNode(Node):
    """
    Call the Crunchbase API to look up companies, people, funding rounds, and acquisitions.

    ## Inputs
    ### Common Inputs
        body: JSON body for searches/* endpoints. IMPORTANT: categories and location_identifiers require UUIDs from autocomplete, not text! Example: {"field_ids":["identifier","funding_total"],"query":[{"type":"predicate","field_id":"categories","operator_id":"includes","values":["uuid-from-autocomplete"]}],"limit":25}
        endpoint: API path: 'autocompletes' | 'entities/organizations/{id}' | 'entities/people/{id}' | 'searches/organizations' | 'searches/funding_rounds' | 'searches/people'
        query_params: Query string for GET requests. Autocomplete: 'query={name}&collection_ids=organization.companies'. Entity lookup: 'field_ids=short_description,funding_total&card_ids=founders'

    ## Outputs
    ### Common Outputs
        output: Raw JSON response from Crunchbase API
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "body",
            "helper_text": 'JSON body for searches/* endpoints. IMPORTANT: categories and location_identifiers require UUIDs from autocomplete, not text! Example: {"field_ids":["identifier","funding_total"],"query":[{"type":"predicate","field_id":"categories","operator_id":"includes","values":["uuid-from-autocomplete"]}],"limit":25}',
            "value": "",
            "type": "string",
        },
        {
            "field": "endpoint",
            "helper_text": "API path: 'autocompletes' | 'entities/organizations/{id}' | 'entities/people/{id}' | 'searches/organizations' | 'searches/funding_rounds' | 'searches/people'",
            "value": "",
            "type": "string",
        },
        {
            "field": "query_params",
            "helper_text": "Query string for GET requests. Autocomplete: 'query={name}&collection_ids=organization.companies'. Entity lookup: 'field_ids=short_description,funding_total&card_ids=founders'",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "Raw JSON response from Crunchbase API",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["endpoint"]

    def __init__(
        self,
        body: str = "",
        endpoint: str = "",
        query_params: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="crunchbase",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if endpoint is not None:
            self.inputs["endpoint"] = endpoint
        if body is not None:
            self.inputs["body"] = body
        if query_params is not None:
            self.inputs["query_params"] = query_params
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CrunchbaseNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
