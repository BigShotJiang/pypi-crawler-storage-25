"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_airtable")
class IntegrationAirtableNode(Node):
    """
    Airtable

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: The integration input
    ### When action = 'new_record' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'write_list_to_column' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'update_records' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'read_row'
        base_id: Name of the Airtable base
        download_attachments: Comma seperated values of attachment fields to download files from
        record_id: ID of the record to retrieve
        table_id: Name of the table in the selected base
    ### When action = 'read_table'
        base_id: Name of the Airtable base
        table_id: Name of the table in the selected base
    ### When action = 'new_record'
        base_id: Name of the Airtable base
        table_id: Name of the table in the selected base
    ### When action = 'write_list_to_column'
        base_id: Name of the Airtable base
        table_id: Name of the table in the selected base
    ### When action = 'search_records'
        base_id: Name of the Airtable base
        filter_formula: Airtable formula to filter records (optional)
        limit: Maximum number of records to return (0 for all)
        sort_ascending: Comma-separated field names to sort in ascending order (e.g., 'Name, Email')
        sort_descending: Comma-separated field names to sort in descending order (e.g., 'Priority, Date')
        table_id: Name of the table in the selected base
    ### When action = 'update_records'
        base_id: Name of the Airtable base
        condition: Conditional Operator
        table_id: Name of the table in the selected base
        update_all_matches: If enabled, updates all records matching the criteria. If disabled, updates only the first matching record
    ### When action = 'delete_record'
        base_id: Name of the Airtable base
        record_id: ID of the record to retrieve
        table_id: Name of the table in the selected base
    ### When action = 'get_table_schema'
        base_id: Name of the Airtable base
    ### When action = 'get_bases'
        limit: Maximum number of records to return (0 for all)
        permission_level: Filter bases by permission levels (comma-separated if multiple selected)
        return_all: Return all bases without pagination. If false, uses the limit parameter

    ## Outputs
    ### When action = 'read_table' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'get_bases'
        base_ids: List of base IDs
        base_names: List of base names
        count: Total number of bases returned
        permission_levels: List of permission levels for each base
        raw_data: Raw API response
    ### When action = 'get_table_schema'
        column_headers: List of Column Headers
        raw_data: Raw API response
        table_ids: List of table IDs
        table_names: List of table names
    ### When action = 'read_row'
        created_time: Record creation timestamp
        downloaded_attachments: List of successfully downloaded attachment files
        downloaded_count: Number of attachments successfully downloaded
        failed_count: Number of attachments that failed to download
        failed_downloads: List of failed downloads with error details
        fields: List of fields
        fields_data: List of fields data
        raw_data: Raw API response
        record_id: ID of the record
    ### When action = 'delete_record'
        deleted: Whether the record was deleted
        deleted_id: ID of the deleted record
        raw_data: Raw API response
    ### When action = 'update_records'
        failed_count: Number of records that failed to update
        failed_ids: IDs of records that failed to update
        raw_data: Summary of the update operation including any error messages
        record_ids: IDs of all successfully updated records
        updated_count: Number of records successfully updated
    ### When action = 'read_table'
        raw_data: Raw API response
    ### When action = 'new_record'
        raw_data: Raw API response
        record_id: ID of the created record
    ### When action = 'write_list_to_column'
        raw_data: Raw API response
    ### When action = 'search_records'
        raw_data: Raw API response
        record_count: Total number of records found
        record_ids: List of record IDs
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Airtable>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "read_row**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "label": "Record ID",
                    "placeholder": "recJByvZjXEVabcde",
                    "helper_text": "ID of the record to retrieve",
                },
                {
                    "field": "download_attachments",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Download Attachments",
                    "placeholder": "Select",
                    "helper_text": "Comma seperated values of attachment fields to download files from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=download_attachments&base_id={inputs.base_id}&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the record",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Record creation timestamp",
                },
                {
                    "field": "fields",
                    "type": "vec<string>",
                    "helper_text": "List of fields",
                },
                {
                    "field": "fields_data",
                    "type": "vec<string>",
                    "helper_text": "List of fields data",
                },
                {
                    "field": "downloaded_attachments",
                    "type": "vec<file>",
                    "helper_text": "List of successfully downloaded attachment files",
                },
                {
                    "field": "downloaded_count",
                    "type": "int32",
                    "helper_text": "Number of attachments successfully downloaded",
                },
                {
                    "field": "failed_downloads",
                    "type": "vec<string>",
                    "helper_text": "List of failed downloads with error details",
                },
                {
                    "field": "failed_count",
                    "type": "int32",
                    "helper_text": "Number of attachments that failed to download",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                },
            ],
            "name": "read_row",
            "task_name": "tasks.airtable.read_row",
            "description": "Read details of a specific row",
            "label": "Get Row",
            "inputs_sort_order": [
                "integration",
                "action",
                "base_id",
                "table_id",
                "record_id",
                "download_attachments",
            ],
        },
        "read_table**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "read_table",
            "task_name": "tasks.airtable.read_table",
            "description": "Read details of a specific table",
            "label": "Get Table",
            "inputs_sort_order": ["integration", "action", "base_id", "table_id"],
        },
        "read_table**[endpoint_0.<A>]": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "new_record**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the created record",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                },
            ],
            "name": "new_record",
            "task_name": "tasks.airtable.write_to_table",
            "description": "Add new record in an Airtable database",
            "label": "Add New Record",
            "ui_sort_order": ["integration", "action", "base_id", "table_id"],
        },
        "new_record**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "write_list_to_column**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                }
            ],
            "name": "write_list_to_column",
            "task_name": "tasks.airtable.write_list_to_column",
            "description": "Fill specified columns empty cells with the input values (inputs can be list)",
            "label": "Column List Writer",
            "ui_sort_order": ["integration", "action", "base_id", "table_id"],
        },
        "write_list_to_column**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "search_records**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "filter_formula",
                    "type": "string",
                    "value": "",
                    "label": "Filter Formula",
                    "placeholder": "NOT({Status} = 'Done')",
                    "helper_text": "Airtable formula to filter records (optional)",
                },
                {
                    "field": "sort_ascending",
                    "type": "string",
                    "value": "",
                    "label": "Sort Ascending",
                    "placeholder": "Name, Created Time",
                    "helper_text": "Comma-separated field names to sort in ascending order (e.g., 'Name, Email')",
                },
                {
                    "field": "sort_descending",
                    "type": "string",
                    "value": "",
                    "label": "Sort Descending",
                    "placeholder": "Priority, Last Modified",
                    "helper_text": "Comma-separated field names to sort in descending order (e.g., 'Priority, Date')",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of records to return (0 for all)",
                },
            ],
            "outputs": [
                {
                    "field": "record_ids",
                    "type": "vec<string>",
                    "helper_text": "List of record IDs",
                },
                {
                    "field": "record_count",
                    "type": "int32",
                    "helper_text": "Total number of records found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                },
            ],
            "name": "search_records",
            "task_name": "tasks.airtable.search_records",
            "description": "Search for records in a table or list all records",
            "label": "Search Records",
            "ui_sort_order": [
                "integration",
                "action",
                "base_id",
                "table_id",
                "filter_formula",
                "sort_ascending",
                "sort_descending",
                "limit",
            ],
            "required": ["limit"],
        },
        "update_records**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "update_all_matches",
                    "type": "bool",
                    "value": False,
                    "label": "Update All Matches",
                    "helper_text": "If enabled, updates all records matching the criteria. If disabled, updates only the first matching record",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "label": "Conditional Operator",
                    "placeholder": "",
                    "helper_text": "Conditional Operator",
                },
            ],
            "outputs": [
                {
                    "field": "record_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of all successfully updated records",
                },
                {
                    "field": "updated_count",
                    "type": "int32",
                    "helper_text": "Number of records successfully updated",
                },
                {
                    "field": "failed_count",
                    "type": "int32",
                    "helper_text": "Number of records that failed to update",
                },
                {
                    "field": "failed_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of records that failed to update",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Summary of the update operation including any error messages",
                },
            ],
            "name": "update_records",
            "task_name": "tasks.airtable.update_records",
            "description": "Update records matching the specified search values in a table",
            "label": "Update Records",
            "operation": "update",
            "inputs_sort_order": [
                "integration",
                "action",
                "base_id",
                "table_id",
                "update_all_matches",
                "condition",
            ],
        },
        "update_records**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "delete_record**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Table",
                    "placeholder": "My Table",
                    "helper_text": "Name of the table in the selected base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_id&base_id={inputs.base_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "label": "Record ID",
                    "placeholder": "recJByvZjXEVabcde",
                    "helper_text": "ID of the record to delete",
                },
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the record was deleted",
                },
                {
                    "field": "deleted_id",
                    "type": "string",
                    "helper_text": "ID of the deleted record",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                },
            ],
            "name": "delete_record",
            "task_name": "tasks.airtable.delete_record",
            "description": "Delete a specific record from a table",
            "label": "Delete Record",
            "ui_sort_order": [
                "integration",
                "action",
                "base_id",
                "table_id",
                "record_id",
            ],
        },
        "get_bases**(*)": {
            "inputs": [
                {
                    "field": "permission_level",
                    "type": "string",
                    "value": "",
                    "label": "Permission Level",
                    "placeholder": "Select permission levels",
                    "helper_text": "Filter bases by permission levels (comma-separated if multiple selected)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Read", "value": "read"},
                            {"label": "Comment", "value": "comment"},
                            {"label": "Edit", "value": "edit"},
                            {"label": "Create", "value": "create"},
                        ],
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all bases without pagination. If false, uses the limit parameter",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of bases to return (default: 10, only applies when Return All is false)",
                },
            ],
            "outputs": [
                {
                    "field": "base_ids",
                    "type": "vec<string>",
                    "helper_text": "List of base IDs",
                },
                {
                    "field": "base_names",
                    "type": "vec<string>",
                    "helper_text": "List of base names",
                },
                {
                    "field": "permission_levels",
                    "type": "vec<string>",
                    "helper_text": "List of permission levels for each base",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of bases returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                },
            ],
            "name": "get_bases",
            "task_name": "tasks.airtable.get_bases",
            "description": "Get multiple bases",
            "label": "List Bases",
            "inputs_sort_order": [
                "integration",
                "action",
                "permission_level",
                "return_all",
                "limit",
            ],
        },
        "get_table_schema**(*)": {
            "inputs": [
                {
                    "field": "base_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Base",
                    "placeholder": "My Base",
                    "helper_text": "Name of the Airtable base",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=base_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "table_ids",
                    "type": "vec<string>",
                    "helper_text": "List of table IDs",
                },
                {
                    "field": "table_names",
                    "type": "vec<string>",
                    "helper_text": "List of table names",
                },
                {
                    "field": "column_headers",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of Column Headers",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response",
                },
            ],
            "name": "get_table_schema",
            "task_name": "tasks.airtable.get_table_schema",
            "description": "Read details of a specific table schema",
            "label": "Get Table Schema",
            "inputs_sort_order": ["integration", "action", "base_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "base_id", "table_id"]

    def __init__(
        self,
        action: str = "",
        base_id: str = "",
        condition: str = "",
        download_attachments: str = "",
        filter_formula: str = "",
        limit: int = 10,
        permission_level: str = "",
        record_id: str = "",
        return_all: bool = False,
        sort_ascending: str = "",
        sort_descending: str = "",
        table_id: str = "",
        update_all_matches: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_airtable",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if base_id is not None:
            self.inputs["base_id"] = base_id
        if table_id is not None:
            self.inputs["table_id"] = table_id
        if record_id is not None:
            self.inputs["record_id"] = record_id
        if download_attachments is not None:
            self.inputs["download_attachments"] = download_attachments
        if filter_formula is not None:
            self.inputs["filter_formula"] = filter_formula
        if sort_ascending is not None:
            self.inputs["sort_ascending"] = sort_ascending
        if sort_descending is not None:
            self.inputs["sort_descending"] = sort_descending
        if limit is not None:
            self.inputs["limit"] = limit
        if update_all_matches is not None:
            self.inputs["update_all_matches"] = update_all_matches
        if condition is not None:
            self.inputs["condition"] = condition
        if permission_level is not None:
            self.inputs["permission_level"] = permission_level
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationAirtableNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
