"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("duplicate_list")
class DuplicateListNode(Node):
    """
    Create a new list by duplicating a single item with the size of the new list either matching the size of another list, or a specified size.

    ## Inputs
    ### Common Inputs
        specify_list_size: Check this box if you want to manually specify the list size. In this case 'Match List Size' will not be used.
        type: The type of the list
    ### When specify_list_size = True and type = '<T>'
        input_field: Item to duplicate
        list_size: The size of the new list
    ### When specify_list_size = False and type = '<T>'
        input_field: Item to duplicate
        list_size_to_match: The size of the list you want to match

    ## Outputs
    ### When specify_list_size = True and type = '<T>'
        output: The duplicated list
    ### When specify_list_size = False and type = '<T>'
        output: The duplicated list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "specify_list_size",
            "helper_text": "Check this box if you want to manually specify the list size. In this case 'Match List Size' will not be used.",
            "value": "false",
            "type": "bool",
        },
        {
            "field": "type",
            "helper_text": "The type of the list",
            "value": "string",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**<T>": {
            "inputs": [
                {
                    "field": "list_size",
                    "label": "List Size",
                    "type": "int32",
                    "value": 1,
                    "helper_text": "The size of the new list",
                    "component": {"type": "number"},
                },
                {
                    "field": "input_field",
                    "label": "Item for duplication",
                    "type": "<T>",
                    "value": "",
                    "placeholder": 'Type "{{" to utilize variables',
                    "helper_text": "Item to duplicate",
                    "component": {"type": "any", "component_field": True},
                },
                {
                    "field": "list_size",
                    "label": "List Size",
                    "type": "int32",
                    "value": 1,
                    "helper_text": "The size of the new list",
                    "component": {"type": "number"},
                },
                {
                    "field": "input_field",
                    "label": "Item for duplication",
                    "type": "<T>",
                    "value": "",
                    "placeholder": 'Type "{{" to utilize variables',
                    "helper_text": "Item to duplicate",
                    "component": {"type": "any", "component_field": True},
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<<T>>",
                    "helper_text": "The duplicated list",
                }
            ],
        },
        "false**<T>": {
            "inputs": [
                {
                    "field": "list_size_to_match",
                    "label": "List To Match",
                    "type": "vec<string>",
                    "value": [],
                    "helper_text": "The size of the list you want to match",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "input_field",
                    "label": "Item for duplication",
                    "type": "<T>",
                    "value": "",
                    "placeholder": 'Type "{{" to utilize variables',
                    "helper_text": "Item to duplicate",
                    "component": {"type": "any", "component_field": True},
                },
                {
                    "field": "list_size_to_match",
                    "label": "List To Match",
                    "type": "vec<string>",
                    "value": [],
                    "helper_text": "The size of the list you want to match",
                    "component": {"type": "text", "default_itemize": False},
                },
                {
                    "field": "input_field",
                    "label": "Item for duplication",
                    "type": "<T>",
                    "value": "",
                    "placeholder": 'Type "{{" to utilize variables',
                    "helper_text": "Item to duplicate",
                    "component": {"type": "any", "component_field": True},
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<<T>>",
                    "helper_text": "The duplicated list",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["specify_list_size", "type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["input_field", "list_size_to_match", "list_size"]

    def __init__(
        self,
        specify_list_size: bool = True,
        type: str = "string",
        list_size: int = 1,
        list_size_to_match: List[str] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        input_field: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["specify_list_size"] = specify_list_size
        params["type"] = type

        super().__init__(
            node_type="duplicate_list",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if type is not None:
            self.inputs["type"] = type
        if specify_list_size is not None:
            self.inputs["specify_list_size"] = specify_list_size
        if list_size is not None:
            self.inputs["list_size"] = list_size
        if input_field is not None:
            self.inputs["input_field"] = input_field
        if list_size_to_match is not None:
            self.inputs["list_size_to_match"] = list_size_to_match
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if input_field is not None:
            self.inputs["input_field"] = input_field

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "DuplicateListNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
