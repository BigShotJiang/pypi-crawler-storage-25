"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_peopledatalabs")
class IntegrationPeopledatalabsNode(Node):
    """
    PeopleDataLabs

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### enrich_person
        company: The name, website, or social URL of a company where the person has worked
        email: Email address of the person
        first_name: First name of the person
        last_name: Last name of the person
        location: The location where a person lives (can be address, city, country, etc.)
        profile_url: Social media profile URLs for the contact (LinkedIn, Twitter, Facebook, etc.)
    ### search_companies
        company_size_ranges: Comma-separated list of company size ranges. The value should be one of the ones mentioned here: https://docs.peopledatalabs.com/docs/company-sizes
        country: Name of the country
        founded_year_range: A range representing the founding year of the company
        industries: Comma-separated list of industries
        number_of_results: Number of results to return
        tags: Comma-separated tags associated with the company
    ### search_people
        country: Name of the country
        job_company_names: Comma-separated list of company names to search within
        job_titles: Comma-separated list of job titles
        number_of_results: Number of results to return
        skills: Comma-separated list of skills to search for
    ### search_people_query
        es_query: A valid Elasticsearch query. Available Fields: https://docs.peopledatalabs.com/docs/elasticsearch-mapping
        number_of_results: Number of results to return
        sql: A valid SQL query
    ### search_companies_query
        es_query: A valid Elasticsearch query. Available Fields: https://docs.peopledatalabs.com/docs/elasticsearch-mapping
        number_of_results: Number of results to return
        sql: A valid SQL query
    ### enrich_company
        name: The name of the company
        profile: Company social media profile URL
        website: Company website URL

    ## Outputs
    ### enrich_person
        output: Enriched person data including additional information found
    ### search_people
        output: List of matching people profiles
    ### search_people_query
        output: List of matching people profiles
    ### enrich_company
        output: Enriched company data including additional information found
    ### search_companies
        output: List of matching company profiles
    ### search_companies_query
        output: List of matching company profiles
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<PeopleDataLabs>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "default_integration_nodes"},
        "enrich_person": {
            "inputs": [
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "First name of the person",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name of the person",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "San Francisco, CA",
                    "helper_text": "The location where a person lives (can be address, city, country, etc.)",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@doe.com",
                    "helper_text": "Email address of the person",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                    "helper_text": "The name, website, or social URL of a company where the person has worked",
                },
                {
                    "field": "profile_url",
                    "type": "string",
                    "value": "",
                    "label": "Profile URL",
                    "placeholder": "linkedin.com/in/johnsmith",
                    "helper_text": "Social media profile URLs for the contact (LinkedIn, Twitter, Facebook, etc.)",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Enriched person data including additional information found",
                }
            ],
            "name": "enrich_person",
            "task_name": "tasks.peopledatalabs.enrich_person",
            "description": "Enrich Person",
            "label": "Enrich Person",
        },
        "search_people": {
            "inputs": [
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "US",
                    "helper_text": "Name of the country",
                },
                {
                    "field": "job_titles",
                    "type": "string",
                    "value": "",
                    "label": "Job Titles",
                    "placeholder": "Software Engineer, Product Manager, CTO",
                    "helper_text": "Comma-separated list of job titles",
                },
                {
                    "field": "job_company_names",
                    "type": "string",
                    "value": "",
                    "label": "Job Company Names",
                    "placeholder": "Google, Microsoft, Apple",
                    "helper_text": "Comma-separated list of company names to search within",
                },
                {
                    "field": "skills",
                    "type": "string",
                    "value": "",
                    "label": "Skills",
                    "placeholder": "Python, Machine Learning, Leadership",
                    "helper_text": "Comma-separated list of skills to search for",
                },
                {
                    "field": "number_of_results",
                    "type": "string",
                    "value": "",
                    "label": "Number of Results",
                    "placeholder": "10",
                    "helper_text": "Number of results to return",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "List of matching people profiles",
                }
            ],
            "name": "search_people",
            "task_name": "tasks.peopledatalabs.search_people",
            "description": "Search People",
            "label": "Search People",
        },
        "search_people_query": {
            "inputs": [
                {
                    "field": "es_query",
                    "type": "string",
                    "value": "",
                    "label": "ES Query",
                    "placeholder": '{"query": {"match_all": {}}}',
                    "helper_text": "A valid Elasticsearch query. Available Fields: https://docs.peopledatalabs.com/docs/elasticsearch-mapping",
                },
                {
                    "field": "sql",
                    "type": "string",
                    "value": "",
                    "label": "SQL",
                    "placeholder": '{"query": {"match": {"job_title": "Software Engineer"}}}',
                    "helper_text": "A valid SQL query",
                },
                {
                    "field": "number_of_results",
                    "type": "string",
                    "value": "",
                    "label": "Number of Results",
                    "placeholder": "10",
                    "helper_text": "Number of results to return",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "List of matching people profiles",
                }
            ],
            "name": "search_people_query",
            "task_name": "tasks.peopledatalabs.search_people_query",
            "description": "Search People (query)",
            "label": "Search People (query)",
        },
        "enrich_company": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "Acme Corp",
                    "helper_text": "The name of the company",
                },
                {
                    "field": "profile",
                    "type": "string",
                    "value": "",
                    "label": "Profile",
                    "placeholder": "linkedin.com/company/acme-corp",
                    "helper_text": "Company social media profile URL",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "www.acmecorp.com",
                    "helper_text": "Company website URL",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Enriched company data including additional information found",
                }
            ],
            "name": "enrich_company",
            "task_name": "tasks.peopledatalabs.enrich_company",
            "description": "Enrich Company",
            "label": "Enrich Company",
        },
        "search_companies": {
            "inputs": [
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "label": "Tags",
                    "placeholder": "B2B, SaaS, Fintech",
                    "helper_text": "Comma-separated tags associated with the company",
                },
                {
                    "field": "industries",
                    "type": "string",
                    "value": "",
                    "label": "Industries",
                    "placeholder": "Technology, Healthcare, Finance",
                    "helper_text": "Comma-separated list of industries",
                },
                {
                    "field": "company_size_ranges",
                    "type": "string",
                    "value": "",
                    "label": "Company Size Ranges",
                    "placeholder": "1-10, 11-50, 51-200, 201-500, 501-1000, 1000+",
                    "helper_text": "Comma-separated list of company size ranges. The value should be one of the ones mentioned here: https://docs.peopledatalabs.com/docs/company-sizes",
                },
                {
                    "field": "founded_year_range",
                    "type": "string",
                    "value": "",
                    "label": "Founded Year Range",
                    "placeholder": "2015-2020",
                    "helper_text": "A range representing the founding year of the company",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "US",
                    "helper_text": "Name of the country",
                },
                {
                    "field": "number_of_results",
                    "type": "string",
                    "value": "",
                    "label": "Number of Results",
                    "placeholder": "10",
                    "helper_text": "Number of results to return",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "List of matching company profiles",
                }
            ],
            "name": "search_companies",
            "task_name": "tasks.peopledatalabs.search_companies",
            "description": "Search Companies",
            "label": "Search Companies",
        },
        "search_companies_query": {
            "inputs": [
                {
                    "field": "es_query",
                    "type": "string",
                    "value": "",
                    "label": "Elastic Search Query",
                    "placeholder": '{"query": {"match_all": {}}}',
                    "helper_text": "A valid Elasticsearch query. Available fields: https://docs.peopledatalabs.com/docs/elasticsearch-mapping-company",
                },
                {
                    "field": "sql",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "SELECT * FROM companies WHERE industry = 'Technology'",
                    "helper_text": "A valid SQL Query. Available fields: https://docs.peopledatalabs.com/docs/company-schema",
                },
                {
                    "field": "number_of_results",
                    "type": "int32",
                    "value": 10,
                    "label": "Number of Results",
                    "placeholder": "10",
                    "helper_text": "Number of results to display",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "List of matching company profiles",
                }
            ],
            "name": "search_companies_query",
            "task_name": "tasks.peopledatalabs.search_companies_query",
            "description": "Search Companies (query)",
            "label": "Search Companies (query)",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        company: str = "",
        company_size_ranges: str = "",
        country: str = "",
        email: str = "",
        es_query: str = "",
        first_name: str = "",
        founded_year_range: str = "",
        industries: str = "",
        job_company_names: str = "",
        job_titles: str = "",
        last_name: str = "",
        location: str = "",
        name: str = "",
        number_of_results: str = "",
        profile: str = "",
        profile_url: str = "",
        skills: str = "",
        sql: str = "",
        tags: str = "",
        website: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_peopledatalabs",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if location is not None:
            self.inputs["location"] = location
        if email is not None:
            self.inputs["email"] = email
        if company is not None:
            self.inputs["company"] = company
        if profile_url is not None:
            self.inputs["profile_url"] = profile_url
        if country is not None:
            self.inputs["country"] = country
        if job_titles is not None:
            self.inputs["job_titles"] = job_titles
        if job_company_names is not None:
            self.inputs["job_company_names"] = job_company_names
        if skills is not None:
            self.inputs["skills"] = skills
        if number_of_results is not None:
            self.inputs["number_of_results"] = number_of_results
        if es_query is not None:
            self.inputs["es_query"] = es_query
        if sql is not None:
            self.inputs["sql"] = sql
        if name is not None:
            self.inputs["name"] = name
        if profile is not None:
            self.inputs["profile"] = profile
        if website is not None:
            self.inputs["website"] = website
        if tags is not None:
            self.inputs["tags"] = tags
        if industries is not None:
            self.inputs["industries"] = industries
        if company_size_ranges is not None:
            self.inputs["company_size_ranges"] = company_size_ranges
        if founded_year_range is not None:
            self.inputs["founded_year_range"] = founded_year_range
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationPeopledatalabsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
