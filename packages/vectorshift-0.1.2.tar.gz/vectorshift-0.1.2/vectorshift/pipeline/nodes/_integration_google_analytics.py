"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_google_analytics")
class IntegrationGoogleAnalyticsNode(Node):
    """
    Google Analytics

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Google Analytics account
    ### When action = 'read_ga4_report'
        currency_code: Currency code for monetary metrics
        dimensions: Comma-separated list of dimensions (e.g., date,country)
        keep_empty_rows: Include rows with all zero metrics
        metric_aggregations: List of metric aggregations to apply
        metrics: Comma-separated list of metrics (e.g., totalUsers,sessions)
        order_by: Order by configuration for results
        property_id: Enter the GA4 property
        return_all: Return all results instead of limiting
        return_property_quota: Return property quota usage
        simple: Return simplified output format
        use_date: Toggle to use dates
    ### When action = 'read_ga4_report' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'read_ga4_report' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'read_ga4_report' and use_date = False
        num_messages: Specify the number of results to fetch
    ### When action = 'read_ga4_report' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_ga4_report'
        raw_data: Raw response data
        row_count: Total number of rows returned
        rows: Report data rows
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Google Analytics account",
            "value": None,
            "type": "integration<Google Analytics>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "read_ga4_report**(*)**(*)": {
            "inputs": [
                {
                    "field": "property_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Enter the GA4 property",
                    "label": "Property",
                    "placeholder": "Enter the GA4 property",
                },
                {
                    "field": "metrics",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of metrics (e.g., totalUsers,sessions)",
                    "label": "Metrics",
                    "placeholder": "totalUsers,sessions,screenPageViews",
                },
                {
                    "field": "dimensions",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of dimensions (e.g., date,country)",
                    "label": "Dimensions",
                    "placeholder": "date,country,deviceCategory",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Return all results instead of limiting",
                    "label": "Return All Results",
                },
                {
                    "field": "simple",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return simplified output format",
                    "label": "Simple Output",
                },
                {
                    "field": "keep_empty_rows",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include rows with all zero metrics",
                    "label": "Keep Empty Rows",
                },
                {
                    "field": "currency_code",
                    "type": "string",
                    "value": "USD",
                    "helper_text": "Currency code for monetary metrics",
                    "label": "Currency Code",
                    "placeholder": "USD",
                },
                {
                    "field": "return_property_quota",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Return property quota usage",
                    "label": "Return Property Quota",
                },
                {
                    "field": "metric_aggregations",
                    "type": "string",
                    "value": "",
                    "helper_text": "List of metric aggregations to apply",
                    "label": "Metric Aggregations",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Total", "value": "TOTAL"},
                            {"label": "Minimum", "value": "MINIMUM"},
                            {"label": "Maximum", "value": "MAXIMUM"},
                        ],
                    },
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "placeholder": "metric:totalUsers desc",
                    "helper_text": "Order by configuration for results",
                    "label": "Order By",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                },
            ],
            "outputs": [
                {
                    "field": "rows",
                    "type": "vec<string>",
                    "helper_text": "Report data rows",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Total number of rows returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_ga4_report",
            "task_name": "tasks.google_analytics.read_ga4_report",
            "description": "Get analytics report from Google Analytics 4",
            "label": "Get GA4 Report",
            "ui_sort_order": [
                "integration",
                "action",
                "property_id",
                "metrics",
                "dimensions",
                "return_all",
                "simple",
                "keep_empty_rows",
                "currency_code",
                "return_property_quota",
                "metric_aggregations",
                "order_by",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
            ],
        },
        "read_ga4_report**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Results",
                    "helper_text": "Specify the number of results to fetch",
                    "hidden": True,
                }
            ],
            "outputs": [],
        },
        "read_ga4_report**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "hidden": True,
                }
            ],
            "outputs": [],
        },
        "read_ga4_report**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "read_ga4_report**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "property_id", "num_messages"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        currency_code: str = "USD",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        dimensions: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        keep_empty_rows: bool = False,
        metric_aggregations: str = "",
        metrics: str = "",
        num_messages: int = 10,
        order_by: str = "",
        property_id: str = "",
        return_all: bool = False,
        return_property_quota: bool = False,
        simple: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_google_analytics",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if property_id is not None:
            self.inputs["property_id"] = property_id
        if metrics is not None:
            self.inputs["metrics"] = metrics
        if dimensions is not None:
            self.inputs["dimensions"] = dimensions
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if simple is not None:
            self.inputs["simple"] = simple
        if keep_empty_rows is not None:
            self.inputs["keep_empty_rows"] = keep_empty_rows
        if currency_code is not None:
            self.inputs["currency_code"] = currency_code
        if return_property_quota is not None:
            self.inputs["return_property_quota"] = return_property_quota
        if metric_aggregations is not None:
            self.inputs["metric_aggregations"] = metric_aggregations
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleAnalyticsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
