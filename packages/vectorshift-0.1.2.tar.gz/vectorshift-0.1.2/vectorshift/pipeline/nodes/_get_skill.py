"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("get_skill")
class GetSkillNode(Node):
    """
    Retrieve the full content of a skill by its ID

    ## Inputs
    ### Common Inputs
        skill: The skill to retrieve

    ## Outputs
    ### Common Outputs
        content: The full content of the skill
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "skill",
            "helper_text": "The skill to retrieve",
            "value": {"object_id": "", "object_type": ObjectType.SKILL},
            "type": "prompt",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "content",
            "helper_text": "The full content of the skill",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["skill"]

    def __init__(
        self,
        skill: Any = {"object_id": "", "object_type": ObjectType.SKILL},
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="get_skill",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if skill is not None:
            self.inputs["skill"] = skill
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "GetSkillNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
