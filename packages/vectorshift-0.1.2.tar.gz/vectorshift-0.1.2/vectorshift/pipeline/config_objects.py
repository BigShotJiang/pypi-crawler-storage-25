"""
This module provides typed configuration objects for grouping related parameters.
Config objects allow users to pass related parameters as single, logical units
rather than multiple flat keyword arguments. Each config object can be flattened
back into individual arguments when constructing nodes or other components.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Any


class _ConfigBase:
    """Mixin providing ``to_kwargs()`` for flattening config → node kwargs."""

    # Subclasses define {config_attr: node_input_name} (set as class attribute)
    _field_map: dict[str, str] = {}

    def to_kwargs(self) -> dict[str, Any]:
        """Flatten this config to a dict of node constructor kwargs."""
        result: dict[str, Any] = {}
        for f in fields(self):  # type: ignore[arg-type]
            node_key = self._field_map.get(f.name, f.name)
            result[node_key] = getattr(self, f.name)
        return result


# ── Shared configs (used by multiple node types) ──────────────────────────


@dataclass(frozen=True)
class SamplingConfig(_ConfigBase):
    """LLM generation parameters — shared by LLM, Categorizer, Summarizer, and other AI nodes.

    Attributes:
        temperature: Creativity of the response (0.0–2.0).
        top_p: Nucleus sampling threshold (0.0–1.0).
        max_tokens: Maximum input + output tokens per run.
    """

    temperature: float = 0.5
    top_p: float = 0.5
    max_tokens: int = 128000

    _field_map = {
        "temperature": "temperature",
        "top_p": "top_p",
        "max_tokens": "max_tokens",
    }


# ── LLM-specific configs ─────────────────────────────────────────────────


@dataclass(frozen=True)
class SafetyConfig(_ConfigBase):
    """PII detection and content moderation flags (LLM node only).

    Attributes:
        moderation: Enable content moderation.
        pii_name: Detect personal names.
        pii_email: Detect email addresses.
        pii_phone: Detect phone numbers.
        pii_ssn: Detect social security numbers.
        pii_address: Detect physical addresses.
        pii_cc: Detect credit card numbers.
    """

    moderation: bool = False
    pii_name: bool = False
    pii_email: bool = False
    pii_phone: bool = False
    pii_ssn: bool = False
    pii_address: bool = False
    pii_cc: bool = False

    _field_map = {
        "moderation": "enable_moderation",
        "pii_name": "enable_pii_name",
        "pii_email": "enable_pii_email",
        "pii_phone": "enable_pii_phone",
        "pii_ssn": "enable_pii_ssn",
        "pii_address": "enable_pii_address",
        "pii_cc": "enable_pii_cc",
    }


@dataclass(frozen=True)
class RetryConfig(_ConfigBase):
    """Retry-on-failure settings (LLM node only).

    When provided, ``retry_on_failure`` is automatically set to ``True``.

    Attributes:
        max_retries: Maximum number of retry attempts.
        interval_ms: Delay between retries in milliseconds.
    """

    max_retries: int = 1
    interval_ms: int = 1000

    _field_map = {
        "max_retries": "max_retries",
        "interval_ms": "retry_interval_ms",
    }

    def to_kwargs(self) -> dict[str, Any]:
        result = super().to_kwargs()
        result["retry_on_failure"] = True
        return result


# ── Knowledge Base configs ────────────────────────────────────────────────


@dataclass(frozen=True)
class RetrievalConfig(_ConfigBase):
    """Controls how chunks are retrieved from a knowledge base.

    Attributes:
        top_k: Number of top results to retrieve.
        alpha: Balance between vector (0.0) and lexical (1.0) search.
        score_cutoff: Minimum similarity score threshold.
        unit: Retrieval unit — ``"chunks"``, ``"documents"``, or ``"pages"``.
    """

    top_k: int = 10
    alpha: float = 0.5
    score_cutoff: float = 0.0
    unit: str = "chunks"

    _field_map = {
        "top_k": "top_k",
        "alpha": "alpha",
        "score_cutoff": "score_cutoff",
        "unit": "retrieval_unit",
    }


@dataclass(frozen=True)
class RerankConfig(_ConfigBase):
    """Reranking settings for knowledge base retrieval.

    When provided, ``rerank_documents`` is automatically set to ``True``.

    Attributes:
        model: Reranking model identifier (e.g. ``"cohere/rerank-english-v3.0"``).
        num_chunks: Number of chunks to send to the reranker.
    """

    model: str = "cohere/rerank-english-v3.0"
    num_chunks: int = 10

    _field_map = {
        "model": "rerank_model",
        "num_chunks": "num_chunks_to_rerank",
    }

    def to_kwargs(self) -> dict[str, Any]:
        result = super().to_kwargs()
        result["rerank_documents"] = True
        return result


@dataclass(frozen=True)
class QueryEnhancementConfig(_ConfigBase):
    """Query expansion and transformation settings for knowledge base.

    Attributes:
        expand: Enable query expansion.
        expand_terms: Enable term-level expansion.
        transform: Enable query transformation.
        multi_question: Answer multiple questions from a single query.
        nl_metadata: Enable natural language metadata query generation.
    """

    expand: bool = False
    expand_terms: bool = False
    transform: bool = False
    multi_question: bool = False
    nl_metadata: bool = False

    _field_map = {
        "expand": "expand_query",
        "expand_terms": "expand_query_terms",
        "transform": "transform_query",
        "multi_question": "answer_multiple_questions",
        "nl_metadata": "do_nl_metadata_query",
    }
