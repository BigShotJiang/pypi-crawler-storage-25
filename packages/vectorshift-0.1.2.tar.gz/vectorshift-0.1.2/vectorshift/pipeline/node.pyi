"""Type stub for Node base class.

Intentionally omits __getattr__ so type checkers flag invalid
attribute access on non-dynamic nodes. Dynamic nodes re-declare
__getattr__ -> str in nodes.pyi individually.
"""

from abc import ABC
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Optional,
    Protocol,
    Type,
    TypeVar,
    runtime_checkable,
)

@runtime_checkable
class NodeOutputs(Protocol): ...

T = TypeVar("T", bound=NodeOutputs)

class Node(ABC):
    _node_registry: ClassVar[Dict[str, Type[Node]]]
    _COMMON_INPUTS: List[Dict[str, Any]]
    _COMMON_OUTPUTS: List[Dict[str, Any]]
    _CONFIGS: ClassVar[Dict[str, Dict[str, Any]]]
    _PARAMS: ClassVar[List[str]]

    id: str
    node_type: str
    name: Optional[str]
    task_name: Optional[str]
    execution_mode: Optional[str]
    inputs: Dict[str, Any]
    outputs: List[str]
    cyclic_inputs: Dict[str, Any]

    @classmethod
    def register_node_type(cls, node_type: str) -> Any: ...
    @classmethod
    def from_json(cls, data: dict) -> Node: ...
    def update_inputs(self, **kwargs: Any) -> None: ...
    def get_dependencies(self) -> tuple[set[str], set[str]]: ...
    def add_cyclic_input(self, key: str, value: str) -> None: ...
    def set_output_name_attributes(self) -> None: ...
    def set_node_task_name(self) -> None: ...
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...

def extract_dependencies_from_node_input(node_input: Any) -> list[str]: ...
