"""Finetuning Engine."""

from abc import ABC, abstractmethod
from typing import Any

from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.llms.llm import LLM
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.cohere_rerank import CohereRerank


class BaseLLMFinetuneEngine(ABC):
    """Base LLM finetuning engine."""

    @abstractmethod
    def finetune(self) -> None:
        """
        Run the finetuning process for the LLM.

        Implementations should submit or execute the training job using the
        configured dataset and hyperparameters. This method blocks until the
        finetuning job completes. After a successful call, `get_finetuned_model`
        should return the resulting model.
        """

    @abstractmethod
    def get_finetuned_model(self, **model_kwargs: Any) -> LLM:
        """Gets finetuned model."""


class BaseEmbeddingFinetuneEngine(ABC):
    """Base Embedding finetuning engine."""

    @abstractmethod
    def finetune(self) -> None:
        """
        Run the finetuning process for the embedding model.

        Implementations should submit or execute the training job using the
        configured dataset and hyperparameters. This method blocks until the
        finetuning job completes. After a successful call, `get_finetuned_model`
        should return the resulting model.
        """

    @abstractmethod
    def get_finetuned_model(self, **model_kwargs: Any) -> BaseEmbedding:
        """Gets finetuned model."""


class BaseCrossEncoderFinetuningEngine(ABC):
    """Base Cross Encoder Finetuning Engine."""

    @abstractmethod
    def finetune(self) -> None:
        """
        Run the finetuning process for the cross-encoder model.

        Implementations should submit or execute the training job using the
        configured dataset and hyperparameters. This method blocks until the
        finetuning job completes. After a successful call, `get_finetuned_model`
        should return the resulting re-ranker model.
        """

    @abstractmethod
    def get_finetuned_model(
        self, model_name: str, top_n: int = 3
    ) -> SentenceTransformerRerank:
        """Gets fine-tuned Cross-Encoder model as re-ranker."""


class BaseCohereRerankerFinetuningEngine(ABC):
    """Base Cohere Reranker Finetuning Engine."""

    @abstractmethod
    def finetune(self) -> None:
        """
        Run the finetuning process for the Cohere reranker model.

        Implementations should submit or execute the training job using the
        configured dataset and hyperparameters. This method blocks until the
        finetuning job completes. After a successful call, `get_finetuned_model`
        should return the resulting reranker model.
        """

    @abstractmethod
    def get_finetuned_model(self, top_n: int = 5) -> CohereRerank:
        """Gets finetuned model."""
