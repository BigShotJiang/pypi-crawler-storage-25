from baddns.base import BadDNS_base

from baddns.lib.dnsmanager import DNSManager
from baddns.lib.dnswalk import DnsWalk
from baddns.lib.findings import Finding

import logging

log = logging.getLogger(__name__)


class BadDNS_ns(BadDNS_base):
    name = "NS"
    description = "Check for dangling NS records, and interrogate them for takeover opportunities"

    def __init__(self, target, **kwargs):
        super().__init__(target, **kwargs)

        self._dnswalk_kwargs = kwargs

        self.target_dnsmanager = DNSManager(
            target, dns_client=self.dns_client, custom_nameservers=self.custom_nameservers
        )

    async def _dispatch(self):
        # omit everything except CNAME. If there is a CNAME chain, we want to run against the end of it.
        await self.target_dnsmanager.dispatchDNS(omit_types=["A", "AAAA", "MX", "NS", "SOA", "TXT", "NSEC"])

        if self.target_dnsmanager.answers["CNAME"] != None:
            self.infomsg(
                f"Detected CNAME(S). Will set target to end of CNAME chain: [{self.target_dnsmanager.answers['CNAME'][-1]}]"
            )
            self.target_dnsmanager.target = self.target_dnsmanager.answers["CNAME"][-1]
            self.target = self.target_dnsmanager.answers["CNAME"][-1]
            self.target_dnsmanager.reset_answers()

        await self.target_dnsmanager.dispatchDNS(omit_types=["A", "AAAA", "CNAME", "MX", "NS", "TXT", "NSEC"])

        dnswalk = DnsWalk(
            self.target_dnsmanager,
            **{
                k: v
                for k, v in self._dnswalk_kwargs.items()
                if k in ("raw_query_max_retries", "raw_query_timeout", "raw_query_retry_wait")
            },
        )
        self.target_dnsmanager.answers["NS"] = await dnswalk.ns_trace(self.target)
        return True

    @staticmethod
    def get_substring_matches(nameservers, strings):
        matched_nameservers = set()
        matched_signatures = set()

        for ns in nameservers:
            for s in strings:
                if s in ns:
                    matched_nameservers.add(ns)
                    matched_signatures.add(s)

        if not matched_nameservers and not matched_signatures:
            return None

        return list(matched_nameservers), list(matched_signatures)

    def analyze(self):
        log.debug("Staring analysis")
        findings = []
        if self.target_dnsmanager.answers["NS"] and len(self.target_dnsmanager.answers["NS"]) > 0:
            target_nameservers = self.target_dnsmanager.answers["NS"]
            log.debug("Nameserver(s) found. Continuing...")
        else:
            return False
        if self.target_dnsmanager.answers["SOA"] == None:
            log.debug("No SOA record found w/nameservers present")
            r = None
            # Check positive signatures first
            for sig in self.signatures:
                if sig.signature["mode"] == "dns_nosoa" and not sig.signature.get("negative_signature", False):
                    sig_nameservers = [ns for ns in sig.signature["identifiers"]["nameservers"]]
                    r = self.get_substring_matches(target_nameservers, sig_nameservers)
                    if r:
                        findings.append(
                            Finding(
                                {
                                    "target": self.target_dnsmanager.target,
                                    "description": "Dangling NS Records (NS records without SOA) with known impact",
                                    "confidence": "HIGH",
                                    "severity": "MEDIUM",
                                    "signature": sig.signature["service_name"],
                                    "indicator": f"DnsWalk Analysis with signature match: {r[1]}",
                                    "trigger": target_nameservers,
                                    "module": type(self),
                                }
                            )
                        )
                        log.debug(
                            f"Found match for for target nameservers {', '.join(target_nameservers)} with signature [{sig.signature['service_name']}]"
                        )
                        return findings
            # Check negative signatures before falling back to generic
            for sig in self.signatures:
                if sig.signature["mode"] == "dns_nosoa" and sig.signature.get("negative_signature", False):
                    sig_nameservers = [ns for ns in sig.signature["identifiers"]["nameservers"]]
                    r = self.get_substring_matches(target_nameservers, sig_nameservers)
                    if r:
                        log.debug(
                            f"Negative signature match [{sig.signature['service_name']}] for nameservers {', '.join(target_nameservers)}, suppressing generic finding"
                        )
                        return findings
            log.debug(
                f"No signature found, falling back to report generic dangling NS record for nameservers: [{', '.join(target_nameservers)}]]"
            )
            findings.append(
                Finding(
                    {
                        "target": self.target_dnsmanager.target,
                        "description": "Dangling NS Records (NS records without SOA)",
                        "confidence": "LOW",
                        "severity": "MEDIUM",
                        "signature": "GENERIC",
                        "indicator": "DNSWalk Analysis",
                        "trigger": target_nameservers,
                        "module": type(self),
                    }
                )
            )

        return findings
