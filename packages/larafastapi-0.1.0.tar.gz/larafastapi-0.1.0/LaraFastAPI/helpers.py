from fastapi import APIRouter
from jinja2 import Environment, FileSystemLoader
from fastapi.responses import HTMLResponse

def view(htmlfile: str, render_vars: dict = None):
    """渲染HTML视图
    Args:
        htmlfile: HTML模板文件路径，相对于app/views目录，例如"msgs/show.html"
        render_vars: 模板渲染变量字典，例如{"msg": msg}
    Returns:
        HTMLResponse: 渲染后的HTML响应
    """
    template = Environment(loader=FileSystemLoader("app/views")).get_template(htmlfile)
    return HTMLResponse(content=template.render(**(render_vars or {})))

def resource_router(controller, prefix: str, tags: list):
    """生成RESTful资源路由
    Args:
        controller: 控制器实例, 必须实现index、show、create、update、delete方法
        prefix: 路由前缀，例如"/users"
        tags: 路由标签列表, 用于API文档分类
    Returns:
        APIRouter: 包含资源路由的APIRouter实例
    """
    router = APIRouter(prefix=prefix, tags=tags)

    # 绑定路由 -> 控制器方法
    router.get("/")(controller.index)
    router.get("/{item_id}")(controller.show)
    router.post("/")(controller.create)
    router.put("/{item_id}")(controller.update)
    router.delete("/{item_id}")(controller.delete)

    return router

def controller_router(controller, prefix: str, tags: list):
    """生成控制器路由
    Args:
        controller: 控制器实例，必须实现对应方法
        prefix: 路由前缀，例如"/users"
        tags: 路由标签列表，用于API文档分类
    Returns:
        APIRouter: 包含控制器路由的APIRouter实例
    """
    router = APIRouter(prefix=prefix, tags=tags)

    # 绑定路由 -> 控制器方法
    for method_name in dir(controller):
        if not method_name.startswith("_"):
            method = getattr(controller, method_name)
            if callable(method):
                router.add_api_route(f"/{method_name}", method)

    return router