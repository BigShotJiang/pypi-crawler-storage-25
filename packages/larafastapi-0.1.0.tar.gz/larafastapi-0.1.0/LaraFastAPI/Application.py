from fastapi import FastAPI
from routes.web import routes as web_router
from routes.api import routes as api_router
from routes.default import router as default_router
from LaraFastAPI.helpers import controller_router, resource_router

class Application:
    """创建FastAPI应用实例"""
    app = None
    def __init__(self, title: str = "FastAPI MVC Example"):
        # 创建FastAPI应用实例
        self.app = FastAPI(title=title)

        # 注册default路由
        self.app.include_router(default_router)
        # 注册web路由
        for router in web_router:
            # self.app.include_router(router[2], prefix=router[0], tags=[router[1]])
            self.app.include_router(controller_router(router[2], router[0], [router[1]]))
        # 注册api路由
        for router in api_router:
            self.app.include_router(resource_router(router[2], router[0], [router[1]]))
