from LaraFastApi.Controller import Controller
from app.models.User import User

class UserController(Controller):
    def index(self):
        # 获取所有数据
        users = User.get()
        return users.serialize()
    
    def show(self, item_id: int):
        # 获取单条数据
        user = User.find(item_id)
        # 显示html视图
        return self.fetch("users/show.html", {"user": user})