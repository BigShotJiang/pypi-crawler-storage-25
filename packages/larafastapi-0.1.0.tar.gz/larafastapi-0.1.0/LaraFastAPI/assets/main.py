from LaraFastApi.Application import Application

app = Application().app
