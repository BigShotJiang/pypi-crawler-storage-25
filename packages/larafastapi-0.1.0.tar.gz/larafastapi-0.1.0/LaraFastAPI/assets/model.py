from masoniteorm.models import Model

class User(Model):
    __table__ = "users"
    __fillable__ = ["name", "email", "password"]