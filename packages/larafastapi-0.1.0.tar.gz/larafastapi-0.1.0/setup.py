import os
from setuptools import setup, find_packages
from setuptools.command.install import install
import shutil

class PostInstallCommand(install):
    """自定义安装后命令，用于在安装后执行额外操作（例如文件拷贝）"""
    
    def run(self):
        # 先执行标准的 setup 安装逻辑
        install.run(self)

        # 自定义安装后逻辑：建立项目目录结构
        os.makedirs(os.path.join(os.getcwd(), 'config'), exist_ok=True)
        os.makedirs(os.path.join(os.getcwd(), 'routes'), exist_ok=True)
        os.makedirs(os.path.join(os.getcwd(), 'app'), exist_ok=True)
        os.makedirs(os.path.join(os.getcwd(), 'app', 'controllers'), exist_ok=True)
        os.makedirs(os.path.join(os.getcwd(), 'app', 'models'), exist_ok=True)
        os.makedirs(os.path.join(os.getcwd(), 'app', 'views'), exist_ok=True)

        # 自定义执行逻辑：复制assets目录下的文件到对应位置
        assets_dir = os.path.join(os.path.dirname(__file__), 'LaraFastAPI', 'assets')
        files = [
            ("controller.py", os.path.join(os.getcwd(), 'app', 'controllers', 'UserController.py')),
            ("model.py", os.path.join(os.getcwd(), 'app', 'models', 'User.py')),
            ("web.py", os.path.join(os.getcwd(), 'routes', 'web.py')),
            ("api.py", os.path.join(os.getcwd(), 'routes', 'api.py')),
            ("default.py", os.path.join(os.getcwd(), 'routes', 'default.py')),
            ("larafast", os.path.join(os.getcwd(), 'larafast')),
            ("database.py", os.path.join(os.getcwd(), 'config', 'database.py')),
            ("main.py", os.path.join(os.getcwd(), 'main.py')),
        ]
        for filename, destination in files:
            source_file = os.path.join(assets_dir, filename)
            if os.path.isfile(source_file):
                print(f"Copying file {source_file} to {destination} ...")
                shutil.copy2(source_file, destination)

# Setup 配置
setup(
    name="LaraFastAPI",  # 包的名称
    version="0.1.0",    # 包的版本号
    packages=find_packages(),  # 自动搜寻所有子包
    install_requires=[  # 安装依赖项
        "fastapi",
        "uvicorn",
        "jinja2",
        "python-dotenv",
        "masonite-orm",
        "pymysql"
    ],
    cmdclass={
        'install': PostInstallCommand,
    },
)