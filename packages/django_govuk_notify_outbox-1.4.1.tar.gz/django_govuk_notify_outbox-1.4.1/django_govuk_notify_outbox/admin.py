import json
from typing import Any, Dict, List, Optional, Tuple

from django.contrib import admin
from django.http import HttpRequest
from django.urls import reverse
from django.utils.html import escape, mark_safe  # type: ignore

from .models import EmailMessage, EmailMessageEvent


def _preserve_spacing(data: str) -> Any:
    return mark_safe(escape(data).replace('\n', '<br>').replace(' ', '&nbsp;'))


def _pretty_json(data: Dict[Any, Any]) -> Any:
    return mark_safe(escape(json.dumps(data, indent=2)).replace('\n', '<br>').replace(' ', '&nbsp;'))


class MessageEventInline(admin.StackedInline[EmailMessageEvent, EmailMessage]):
    model = EmailMessageEvent
    exclude = ['http_response', 'exception_stack_trace', 'exception_message']
    readonly_fields = [
        'type',
        'result',
        'start',
        'end',
        '_http_response',
        'http_error_status_code',
        'http_error_type',
        'http_error_message',
        'exception_type',
        '_exception_message',
        '_exception_stack_trace',
    ]

    @admin.display(description="Http response")
    def _http_response(self, obj: EmailMessageEvent) -> Any:
        return _pretty_json(obj.http_response) if obj.http_response is not None else None

    @admin.display(description="Exception message")
    def _exception_message(self, obj: EmailMessageEvent) -> Any:
        return _preserve_spacing(obj.exception_message) if obj.exception_message is not None else None

    @admin.display(description="Exception stack trace")
    def _exception_stack_trace(self, obj: EmailMessageEvent) -> Any:
        return _preserve_spacing(obj.exception_stack_trace) if obj.exception_stack_trace is not None else None


@admin.register(EmailMessage)
class EmailMessageAdmin(admin.ModelAdmin[EmailMessage]):
    exclude = ['personalisation']
    readonly_fields = ['_personalisation']
    list_display = [
        "email_address",
        "reference",
        "status",
        "created_on",
    ]
    list_filter = ["status",]
    show_facets = admin.ShowFacets.ALWAYS
    inlines = [MessageEventInline]

    @admin.display(description="Personalisation")
    def _personalisation(self, obj: EmailMessage) -> Any:
        return _pretty_json(obj.personalisation) if obj.personalisation is not None else None

    def get_ordering(self, request: HttpRequest) -> Tuple[str]:
        return ("-created_on",)

    def has_change_permission(self, request: HttpRequest, obj: Optional[EmailMessage] = None) -> bool:
        return False

    def has_add_permission(self, request: HttpRequest) -> bool:
        return False

    def has_delete_permission(
        self, request: HttpRequest, obj: Optional[EmailMessage] = None
    ) -> bool:
        return False
