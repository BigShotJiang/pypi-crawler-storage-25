"""Pure resolve() decision function — no state beyond args."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from duh.kernel.untrusted import UNTAINTED_SOURCES, TaintSource

if TYPE_CHECKING:
    from duh.kernel.confirmation import ConfirmationMinter
from duh.security.config import SecurityPolicy
from duh.security.engine import FindingStore
from duh.security.exceptions import ExceptionStore
from duh.security.finding import Finding

__all__ = [
    "DANGEROUS_TOOLS",
    "any_tainted",
    "resolve_confirmation",
    "ConfirmationPolicyDecision",
    "ToolUseEvent",
    "PolicyDecision",
    "resolve",
]

# Public alias (used by 7.2 confirmation gating)
DANGEROUS_TOOLS: frozenset[str] = frozenset({
    "Bash", "Write", "Edit", "MultiEdit", "NotebookEdit",
    "WebFetch", "Docker", "HTTP",
})

# Private alias for backward compat inside this module
_DANGEROUS_TOOLS: frozenset[str] = DANGEROUS_TOOLS


def any_tainted(chain: list) -> bool:
    """Return True if any item in the event chain has a tainted source."""
    for item in chain:
        src = getattr(item, "_source", TaintSource.SYSTEM)
        if src not in UNTAINTED_SOURCES:
            return True
    return False


@dataclass(frozen=True, slots=True)
class ToolUseEvent:
    tool: str
    cwd: Path


@dataclass(frozen=True, slots=True)
class PolicyDecision:
    action: Literal["allow", "warn", "block"]
    reason: str
    findings: tuple[Finding, ...]
    remediation: str | None


@dataclass
class ConfirmationPolicyDecision:
    """Decision from the confirmation token gate (7.2)."""
    action: Literal["allow", "block"]
    reason: str


def resolve_confirmation(
    *,
    tool: str,
    input_obj: dict,
    chain: list,
    minter: "ConfirmationMinter",
    session_id: str,
    token: str | None,
) -> ConfirmationPolicyDecision:
    """Gate dangerous tool calls from tainted context on confirmation token."""
    if tool not in DANGEROUS_TOOLS:
        return ConfirmationPolicyDecision(action="allow", reason="non-dangerous tool")
    if not any_tainted(chain):
        return ConfirmationPolicyDecision(action="allow", reason="untainted context")
    if token and minter.validate(token, session_id, tool, input_obj):
        return ConfirmationPolicyDecision(action="allow", reason="valid confirmation token")
    return ConfirmationPolicyDecision(
        action="block",
        reason=(
            "Dangerous tool called from tainted context without confirmation. "
            "Confirm interactively or add a user-origin /continue."
        ),
    )


def resolve(
    event: ToolUseEvent,
    policy: SecurityPolicy,
    findings: FindingStore,
    exceptions: ExceptionStore,
    *,
    at: datetime | None = None,
) -> PolicyDecision:
    now = at or datetime.now(tz=timezone.utc)
    active = [
        f for f in findings.active(scope=event.cwd)
        if not exceptions.covers(f, at=now)
    ]
    fail_set = set(policy.fail_on or ())
    report_set = set(policy.report_on or ())
    blocking = [f for f in active if f.severity in fail_set]
    warning = [f for f in active if f.severity in report_set and f not in blocking]

    if event.tool in _DANGEROUS_TOOLS and blocking:
        top = blocking[0]
        fixed = top.fixed_in or "unknown"
        remediation = (
            f"Fix {top.id} (fixed in {fixed}) or add exception:\n"
            f"  duh security exception add {top.id} --reason='...' --expires=YYYY-MM-DD"
        )
        return PolicyDecision(
            action="block",
            reason=f"{len(blocking)} unresolved {top.severity.value} finding(s)",
            findings=tuple(blocking),
            remediation=remediation,
        )

    if warning:
        return PolicyDecision(
            action="warn",
            reason=f"{len(warning)} finding(s) below block threshold",
            findings=tuple(warning),
            remediation=None,
        )

    return PolicyDecision(
        action="allow",
        reason="clear",
        findings=(),
        remediation=None,
    )
