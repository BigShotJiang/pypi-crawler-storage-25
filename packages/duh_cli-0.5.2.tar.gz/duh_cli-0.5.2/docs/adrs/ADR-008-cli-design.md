# ADR-008: CLI Design

**Status:** Accepted — implemented 2026-04-14
**Date**: 2026-04-07

## Context

Production AI harnesses often have complex CLI entry points: React/Ink rendering, OAuth flows, enterprise settings, feature flags, and dozens of startup optimizations. They support many modes (REPL, print, API, coordinator, assistant, remote) and import a large module graph at startup.

D.U.H. needs a CLI that provides the core workflows without the complexity.

### Patterns from production harnesses

1. **Provider auto-detection**: Check API key environment variables, fall back to local providers. No explicit `--provider` flag needed.

2. **Flag conventions**:
   - `-p "prompt"` — print mode (non-interactive, outputs to stdout)
   - `--model <name>` — model override
   - `--output-format json` — JSON output (stream-json for streaming)
   - `--dangerously-skip-permissions` — auto-approve all tools
   - `--continue` — resume last session
   - `--resume <id>` — resume specific session
   - `--max-turns <n>` — agentic loop limit
   - `--system-prompt <text>` — system prompt override

3. **Output conventions**:
   - Text output to stdout (for piping)
   - Human messages, tool traces, errors to stderr
   - `--output-format json` for machine consumption
   - Exit code 0 on success, 1 on error

4. **Error UX**: Errors are human-readable with actionable hints. "Credit balance is too low" → "Go to console.anthropic.com → Plans & Billing to add credits." Not raw stack traces.

5. **Doctor subcommand**: A diagnostics command checks environment health (runtime version, API key, config, tools).

## Decision

Implement a minimal CLI using `argparse` (stdlib, no deps) with the same flag conventions where they make sense.

### Modes

| Mode | Invocation | Output |
|------|-----------|--------|
| Print | `duh -p "prompt"` | Streaming text to stdout |
| Help | `duh` (no args) | Usage help |
| Doctor | `duh doctor` | Diagnostic checks |
| JSON | `duh -p "prompt" --output-format json` | JSON array of events |

Interactive REPL mode is future work — print mode covers the scripting/automation use case first.

### Flag Conventions

Following established conventions where possible:

| Flag | Short | Description | Convention |
|------|-------|-------------|---------------|
| `--prompt` | `-p` | Print mode prompt | `-p` |
| `--model` | | Model override | `--model` |
| `--provider` | | Provider (anthropic/ollama) | Auto-detect |
| `--output-format` | | text or json | `--output-format` |
| `--max-turns` | | Agentic loop limit | `--max-turns` |
| `--system-prompt` | | System prompt override | `--system-prompt` |
| `--dangerously-skip-permissions` | | Auto-approve all | Same |
| `--debug` | `-d` | Full event tracing | `--verbose` |
| `--version` | | Show version | `--version` |

### Provider Auto-Detection

```
1. --provider flag (explicit)
2. ANTHROPIC_API_KEY set → anthropic
3. Ollama reachable at localhost:11434 → ollama
4. Error with actionable message
```

### Output Format

- **text** (default): Streaming text to stdout. Tool calls and errors to stderr with ANSI color.
- **json**: Array of all events as JSON to stdout after completion.

### Error UX

Every error includes what went wrong AND what to do about it:

```python
_ERROR_HINTS = {
    "credit balance is too low": "Go to console.anthropic.com → Plans & Billing...",
    "invalid x-api-key": "Check ANTHROPIC_API_KEY is set correctly.",
    "rate_limit": "Wait a moment and try again.",
    "overloaded": "API is overloaded. Try again or use --model claude-haiku-4-5...",
    "prompt is too long": "Conversation too long. Try a shorter prompt...",
    "Could not resolve authentication": "No API key found. Set ANTHROPIC_API_KEY...",
}
```

### Debug Mode

`--debug` / `-d` enables:
- Full event tracing to stderr (every event type and payload summary)
- Thinking block output (dimmed italic)
- Tool result content (truncated)
- Provider and model identification at startup

### Doctor

`duh doctor` checks:
- Python version (>= 3.12)
- ANTHROPIC_API_KEY presence
- Config directory
- anthropic SDK installed
- Available tools

### Future Enhancements

- **REPL mode**: Interactive chat loop (no `-p`)
- **`--continue` / `--resume`**: Session resumption
- **`--output-format stream-json`**: NDJSON streaming (one event per line)
- **Subcommands**: `duh init`, `duh config`, `duh mcp`
- **Shell completion**: bash/zsh/fish via argparse hooks

## Consequences

- Zero external CLI dependencies (stdlib argparse)
- Matches established CLI flag conventions where they make sense
- Errors guide users to solutions, not stack traces
- Provider auto-detection works out of the box (set key → it works)
- Debug mode gives full visibility without cluttering normal output
- Doctor subcommand provides instant diagnostics

## Implementation Notes

- Argument parsing: `duh/cli/parser.py`
- Print-mode runner: `duh/cli/runner.py`
- Interactive REPL: `duh/cli/repl.py` (ADR-024)
- SDK / NDJSON protocol: `duh/cli/sdk_runner.py` + `duh/cli/ndjson.py` (ADR-021)
- Doctor subcommand: `duh/cli/doctor.py`
- Entry point: `duh/cli/main.py` (plus `duh/__main__.py`)
- Connection pre-warming: `duh/cli/prewarm.py` (ADR-050)
