import pytest
from datetime import datetime, date, timedelta
from shiftwise.models import Shift, User, Leave, SwapRequest, Role, LeaveType, LeaveStatus
from shiftwise.managers import ShiftManager, LeaveManager, SwapManager
from shiftwise.exceptions import ShiftFullError, ShiftConflictError, LeaveConflictError

@pytest.fixture
def shift_manager():
    return ShiftManager()

@pytest.fixture
def today():
    return date.today()

@pytest.fixture
def now():
    return datetime.now()

def test_assign_employee_success(shift_manager, now):
    shift = Shift(shift_id="S1", title="Morning", start_time=now, end_time=now + timedelta(hours=4), max_capacity=2, required_skills=["Cashier"])
    assigned_shift = shift_manager.assign_employee(shift, "E1", ["Cashier"], [], [])
    assert "E1" in assigned_shift.assigned_employee_ids

def test_assign_employee_no_skills(shift_manager, now):
    shift = Shift(shift_id="S1", title="Morning", start_time=now, end_time=now + timedelta(hours=4), max_capacity=2, required_skills=["Security"])
    with pytest.raises(Exception) as excinfo:
        shift_manager.assign_employee(shift, "E1", ["Cashier"], [], [])
    assert "Employee lacks required skill" in str(excinfo.value)

def test_assign_employee_full(shift_manager, now):
    shift = Shift(shift_id="S1", title="Morning", start_time=now, end_time=now + timedelta(hours=4), max_capacity=1, assigned_employee_ids=["E1"])
    with pytest.raises(ShiftFullError):
        shift_manager.assign_employee(shift, "E2", [], [], [])

def test_assign_employee_conflict(shift_manager, now):
    shift1 = Shift(shift_id="S1", title="Morning", start_time=now, end_time=now + timedelta(hours=4), max_capacity=2)
    shift2 = Shift(shift_id="S2", title="Overlap", start_time=now + timedelta(hours=2), end_time=now + timedelta(hours=6), max_capacity=2)
    
    with pytest.raises(ShiftConflictError):
        shift_manager.assign_employee(shift2, "E1", [], [shift1], [])

def test_assign_employee_leave_conflict(shift_manager, now, today):
    shift = Shift(shift_id="S1", title="Morning", start_time=now, end_time=now + timedelta(hours=4), max_capacity=2)
    leave = Leave(leave_id="L1", employee_id="E1", leave_type=LeaveType.SICK, start_date=today, end_date=today, status=LeaveStatus.APPROVED)
    
    with pytest.raises(LeaveConflictError):
        shift_manager.assign_employee(shift, "E1", [], [], [leave])

def test_leave_manager_approve():
    leave_manager = LeaveManager()
    leave = Leave(leave_id="L1", employee_id="E1", leave_type=LeaveType.SICK, start_date=date.today(), end_date=date.today())
    approved_leave = leave_manager.approve_leave(leave, manager_role="MANAGER")
    assert approved_leave.status == LeaveStatus.APPROVED
