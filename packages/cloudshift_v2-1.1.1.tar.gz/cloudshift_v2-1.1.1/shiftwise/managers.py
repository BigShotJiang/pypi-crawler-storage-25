from typing import List
from .models import Shift, Leave, SwapRequest, LeaveStatus, SwapStatus
from .validators import (
    validate_shift_capacity, validate_employee_no_conflict,
    validate_no_leave_conflict, validate_employee_skills
)
from .exceptions import DuplicateRequestError, InvalidRoleError


class ShiftManager:
    def __init__(self):
        # Depending on the system, state might normally be persisted in a DB.
        # This library encapsulates the business rules,
        # which can accept current state as parameters.
        pass

    def assign_employee(
        self, shift: Shift, employee_id: str, employee_skills: List[str],
        current_employee_shifts: List[Shift],
        current_employee_leaves: List[Leave]
    ) -> Shift:
        """Assigns an employee to a shift after validating rules."""
        if employee_id in shift.assigned_employee_ids:
            return shift  # Already assigned

        validate_shift_capacity(shift)
        validate_employee_skills(shift, employee_skills)
        validate_employee_no_conflict(shift, current_employee_shifts)
        validate_no_leave_conflict(shift, current_employee_leaves)

        shift.assigned_employee_ids.append(employee_id)
        return shift

    def remove_employee(self, shift: Shift, employee_id: str) -> Shift:
        """Removes an employee from a shift."""
        if employee_id in shift.assigned_employee_ids:
            shift.assigned_employee_ids.remove(employee_id)
        return shift


class LeaveManager:
    def request_leave(self, employee_id: str, existing_leaves: List[Leave], new_leave: Leave) -> Leave:
        """Process a new leave request."""
        # Check for duplicates or overlapping unapproved leaves
        for leave in existing_leaves:
            if leave.start_date <= new_leave.end_date and leave.end_date >= new_leave.start_date:
                raise DuplicateRequestError("A leave request already exists for this period.")

        new_leave.status = LeaveStatus.PENDING
        return new_leave

    def approve_leave(self, leave: Leave, manager_role: str) -> Leave:
        if manager_role != "MANAGER":
            raise InvalidRoleError("Only managers can approve leaves.")
        leave.status = LeaveStatus.APPROVED
        return leave

    def reject_leave(self, leave: Leave, manager_role: str) -> Leave:
        if manager_role != "MANAGER":
            raise InvalidRoleError("Only managers can reject leaves.")
        leave.status = LeaveStatus.REJECTED
        return leave


class SwapManager:
    def request_swap(self, swap_request: SwapRequest, existing_swaps: List[SwapRequest]) -> SwapRequest:
        for request in existing_swaps:
            if request.requester_shift_id == swap_request.requester_shift_id and request.status == SwapStatus.PENDING:
                raise DuplicateRequestError("A pending swap request already exists for this shift.")

        swap_request.status = SwapStatus.PENDING
        return swap_request

    def approve_swap(self, swap_request: SwapRequest, target_employee_id: str, shift_manager: ShiftManager,
                     requester_shifts: List[Shift], target_shifts: List[Shift],
                     requester_shift: Shift, target_shift: Shift) -> bool:
        """
        Approves a swap request by validating that both can take the other's shift.
        Returns True if successful.
        """
        if swap_request.target_employee_id != target_employee_id:
            raise InvalidRoleError("Only the target employee can approve the swap.")

        # Temporarily detach from shifts to avoid self-conflict
        target_shift_copy = [s for s in target_shifts if s.shift_id != target_shift.shift_id]
        requester_shift_copy = [s for s in requester_shifts if s.shift_id != requester_shift.shift_id]

        # Ensure target can take requester's shift
        validate_employee_no_conflict(requester_shift, target_shift_copy)
        # Ensure requester can take target's shift
        validate_employee_no_conflict(target_shift, requester_shift_copy)

        swap_request.status = SwapStatus.APPROVED
        return True
