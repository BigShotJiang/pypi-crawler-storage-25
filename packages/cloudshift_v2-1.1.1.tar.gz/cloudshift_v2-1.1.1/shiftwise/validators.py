from typing import List
from datetime import datetime, date

from .models import Shift, Leave
from .exceptions import ShiftConflictError, LeaveConflictError, ShiftFullError


def check_overlapping_times(start1: datetime, end1: datetime, start2: datetime, end2: datetime) -> bool:
    """Checks if two time ranges overlap."""
    return max(start1, start2) < min(end1, end2)


def check_overlapping_date_time(leave_start: date, leave_end: date, shift_start: datetime, shift_end: datetime) -> bool:
    """Checks if a shift falls within a leave date range."""
    # Convert dates to datetimes for comparison (assuming start of day for leave_start, end of day for leave_end)
    leave_start_dt = datetime.combine(leave_start, datetime.min.time())
    leave_end_dt = datetime.combine(leave_end, datetime.max.time())
    return check_overlapping_times(leave_start_dt, leave_end_dt, shift_start, shift_end)


def validate_shift_capacity(shift: Shift):
    if len(shift.assigned_employee_ids) >= shift.max_capacity:
        raise ShiftFullError(f"Shift {shift.shift_id} has reached its maximum capacity of {shift.max_capacity}.")


def validate_employee_no_conflict(new_shift: Shift, employee_shifts: List[Shift]):
    for shift in employee_shifts:
        if check_overlapping_times(new_shift.start_time, new_shift.end_time, shift.start_time, shift.end_time):
            raise ShiftConflictError(f"Shift {new_shift.shift_id} overlaps with existing shift {shift.shift_id}.")


def validate_no_leave_conflict(new_shift: Shift, employee_leaves: List[Leave]):
    for leave in employee_leaves:
        if check_overlapping_date_time(leave.start_date, leave.end_date, new_shift.start_time, new_shift.end_time):
            raise LeaveConflictError(
                f"Shift {new_shift.shift_id} conflicts with approved leave "
                f"from {leave.start_date} to {leave.end_date}."
            )


def validate_employee_skills(shift: Shift, employee_skills: List[str]):
    for skill in shift.required_skills:
        if skill not in employee_skills:
            from .exceptions import ShiftwiseException
            raise ShiftwiseException(f"Employee lacks required skill: {skill}")
