class ShiftwiseException(Exception):
    """Base exception for shiftwise library."""
    pass


class ShiftFullError(ShiftwiseException):
    """Raised when a shift has reached its maximum capacity."""
    pass


class ShiftConflictError(ShiftwiseException):
    """Raised when an employee is assigned to overlapping shifts."""
    pass


class InvalidRoleError(ShiftwiseException):
    """Raised when an action is performed by a user with insufficient permissions."""
    pass


class LeaveConflictError(ShiftwiseException):
    """Raised when a leave overlaps with scheduled shifts without cover."""
    pass


class DuplicateRequestError(ShiftwiseException):
    """Raised when submitting duplicate swap or leave requests."""
    pass
