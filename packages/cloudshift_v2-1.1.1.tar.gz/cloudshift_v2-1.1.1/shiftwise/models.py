from dataclasses import dataclass, field
from datetime import datetime, date
from typing import List
from enum import Enum


class Role(str, Enum):
    MANAGER = "MANAGER"
    EMPLOYEE = "EMPLOYEE"


@dataclass
class User:
    user_id: str
    email: str
    first_name: str
    last_name: str
    role: Role
    skills: List[str] = field(default_factory=list)


@dataclass
class Shift:
    shift_id: str
    title: str
    start_time: datetime
    end_time: datetime
    max_capacity: int
    required_skills: List[str] = field(default_factory=list)
    assigned_employee_ids: List[str] = field(default_factory=list)


class LeaveType(str, Enum):
    SICK = "SICK"
    CASUAL = "CASUAL"
    ANNUAL = "ANNUAL"


class LeaveStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass
class Leave:
    leave_id: str
    employee_id: str
    leave_type: LeaveType
    start_date: date
    end_date: date
    status: LeaveStatus = LeaveStatus.PENDING


class SwapStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass
class SwapRequest:
    swap_id: str
    requester_id: str
    target_employee_id: str
    requester_shift_id: str
    target_shift_id: str
    status: SwapStatus = SwapStatus.PENDING
