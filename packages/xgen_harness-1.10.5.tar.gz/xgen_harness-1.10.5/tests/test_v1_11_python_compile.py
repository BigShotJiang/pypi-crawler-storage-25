"""v1.10.0/v1.11.0 — Python 채널 컴파일러 테스트.

transpile_to_python / write_package / compile_and_pack round-trip.
"""

import ast
import json
import subprocess
import sys
from pathlib import Path

import pytest


# ─────────────────────────────────────────────────────────
# 픽스처
# ─────────────────────────────────────────────────────────


@pytest.fixture
def sample_cluster_config():
    return {
        "stages": ["s01_input", "s03_prompt", "s04_tool", "s06_context", "s07_act", "s08_decide", "s09_finalize"],
        "system_prompt": "당신은 도움이 되는 AI 어시스턴트입니다.",
        "provider": "openai",
        "model": "gpt-4o",
        "stage_params": {
            "s06_context": {"top_k": 10, "reranker": True, "rerank_top_k": 5},
            "s08_decide": {"strategy": "judge_then_loop", "judge_model": "gpt-4o-mini"},
        },
        "runtime_defaults": {
            "synth_raw_threshold": 2000,
            "synth_sub_max_turns": 8,
            "tool_consecutive_failure_limit": 3,
        },
        "rag_collections": ["test-coll-abc"],
        "mcp_sessions": [],
        "db_connections": [],
    }


# ─────────────────────────────────────────────────────────
# transpile_to_python
# ─────────────────────────────────────────────────────────


def test_transpile_produces_expected_files(sample_cluster_config):
    from xgen_harness.compile import transpile_to_python

    tree = transpile_to_python(
        {"harness_config": sample_cluster_config},
        package_name="plateer-xgen-wf-abc",
        package_version="0.1.0",
        include_mcp=True,
        workflow_description="테스트",
    )
    expected = {
        "pyproject.toml",
        "README.md",
        "plateer_xgen_wf_abc/__init__.py",
        "plateer_xgen_wf_abc/flow.py",
        "plateer_xgen_wf_abc/__main__.py",
        "plateer_xgen_wf_abc/config.toml.example",
        "plateer_xgen_wf_abc/mcp.py",
    }
    assert set(tree.keys()) == expected


def test_transpile_module_sanitize(sample_cluster_config):
    from xgen_harness.compile import transpile_to_python

    # 하이픈 / 숫자 시작 / 특수문자 → underscore
    tree = transpile_to_python(
        {"harness_config": sample_cluster_config},
        package_name="my-cool-pkg",
        package_version="0.1.0",
        include_mcp=False,
    )
    assert "my_cool_pkg/__init__.py" in tree
    assert "my_cool_pkg/flow.py" in tree
    assert "my_cool_pkg/mcp.py" not in tree  # include_mcp=False


def test_transpile_all_python_files_parse(sample_cluster_config):
    """생성된 .py 파일은 ast.parse 통과 (syntactically valid)."""
    from xgen_harness.compile import transpile_to_python

    tree = transpile_to_python(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        include_mcp=True,
    )
    for path, content in tree.items():
        if path.endswith(".py"):
            ast.parse(content)  # raises SyntaxError 시 실패


def test_transpile_cluster_defaults_preserved(sample_cluster_config):
    """CLUSTER_DEFAULTS 안에 cluster origin 값 그대로 박혀있음."""
    from xgen_harness.compile import transpile_to_python

    tree = transpile_to_python(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        include_mcp=False,
    )
    flow_py = tree["test_pkg/flow.py"]
    # 핵심 값들이 소스에 그대로 박혀있는지 (literal 검색)
    assert '"top_k": 10' in flow_py
    assert '"reranker": True' in flow_py
    assert '"synth_raw_threshold": 2000' in flow_py
    assert '"test-coll-abc"' in flow_py


def test_transpile_harness_pin_in_pyproject(sample_cluster_config):
    """pyproject.toml 의 xgen-harness 의존성이 exact pin."""
    from xgen_harness.compile import transpile_to_python

    tree = transpile_to_python(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        harness_version_pin="==1.10.0",
    )
    pyproject = tree["pyproject.toml"]
    assert 'xgen-harness==1.10.0' in pyproject


# ─────────────────────────────────────────────────────────
# write_package + compile_and_pack
# ─────────────────────────────────────────────────────────


def test_write_package(tmp_path, sample_cluster_config):
    from xgen_harness.compile import transpile_to_python, write_package

    tree = transpile_to_python(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        include_mcp=True,
    )
    out = write_package(tree, tmp_path / "pkg")
    assert (out / "pyproject.toml").exists()
    assert (out / "test_pkg" / "flow.py").exists()
    assert (out / "test_pkg" / "mcp.py").exists()


def test_compile_and_pack_source(tmp_path, sample_cluster_config):
    from xgen_harness.compile import compile_and_pack

    pkg_dir = compile_and_pack(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        package_version="0.1.0",
        out_dir=tmp_path,
        format="source",
    )
    assert pkg_dir.is_dir()
    assert (pkg_dir / "pyproject.toml").exists()


def test_compile_and_pack_tarball(tmp_path, sample_cluster_config):
    from xgen_harness.compile import compile_and_pack

    tar = compile_and_pack(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        package_version="0.1.0",
        out_dir=tmp_path,
        format="tarball",
    )
    assert tar.name.endswith(".tar.gz")
    assert tar.stat().st_size > 0


def test_compile_and_pack_wheel(tmp_path, sample_cluster_config):
    """`build` 모듈 설치돼 있으면 wheel 빌드."""
    try:
        import build  # type: ignore[import-untyped]  # noqa: F401
    except ImportError:
        pytest.skip("PEP 517 `build` 모듈 미설치 — wheel 테스트 skip")

    from xgen_harness.compile import compile_and_pack

    wheel = compile_and_pack(
        {"harness_config": sample_cluster_config},
        package_name="test-pkg",
        package_version="0.1.0",
        out_dir=tmp_path,
        format="wheel",
    )
    assert wheel.name.endswith(".whl")
    assert wheel.stat().st_size > 0


def test_round_trip_install_import(tmp_path, sample_cluster_config):
    """transpile → wheel → install --no-deps → subprocess import → CLUSTER_DEFAULTS 값 보존."""
    try:
        import build  # type: ignore[import-untyped]  # noqa: F401
    except ImportError:
        pytest.skip("PEP 517 `build` 모듈 미설치 — round-trip 테스트 skip")

    from xgen_harness.compile import compile_and_pack

    wheel = compile_and_pack(
        {"harness_config": sample_cluster_config},
        package_name="round-trip-pkg",
        package_version="0.1.0",
        out_dir=tmp_path / "dist",
        format="wheel",
    )
    install_target = tmp_path / "site"
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet", "--no-deps",
         "--target", str(install_target), str(wheel)],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, f"pip install failed: {r.stderr}"

    # subprocess import — sys.path 에 install_target 박고 import + CLUSTER_DEFAULTS dump
    script = (
        f'import sys; sys.path.insert(0, {str(install_target)!r}); '
        'import round_trip_pkg; '
        'import json; '
        'print(json.dumps({"top_k": round_trip_pkg.CLUSTER_DEFAULTS["stage_params"]["s06_context"]["top_k"], '
        '"reranker": round_trip_pkg.CLUSTER_DEFAULTS["stage_params"]["s06_context"]["reranker"], '
        '"synth_raw_threshold": round_trip_pkg.CLUSTER_DEFAULTS["runtime_defaults"]["synth_raw_threshold"], '
        '"rag_collections": round_trip_pkg.CLUSTER_DEFAULTS["rag_collections"], '
        '"has_build_pipeline": callable(round_trip_pkg.build_pipeline)}))'
    )
    r2 = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True, text=True,
    )
    assert r2.returncode == 0, f"subprocess import failed: {r2.stderr}"
    payload = json.loads(r2.stdout.strip())
    assert payload["top_k"] == 10
    assert payload["reranker"] is True
    assert payload["synth_raw_threshold"] == 2000
    assert payload["rag_collections"] == ["test-coll-abc"]
    assert payload["has_build_pipeline"] is True


def test_compile_module_top_level_exports():
    """xgen_harness.compile 에 신규 함수 노출."""
    from xgen_harness.compile import (
        transpile_to_python, write_package,
        build_wheel, build_sdist, pack_tarball, compile_and_pack, BuildError,
    )
    assert callable(transpile_to_python)
    assert callable(write_package)
    assert callable(build_wheel)
    assert callable(build_sdist)
    assert callable(pack_tarball)
    assert callable(compile_and_pack)
    assert issubclass(BuildError, RuntimeError)
