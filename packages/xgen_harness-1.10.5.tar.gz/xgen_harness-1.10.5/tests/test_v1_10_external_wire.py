"""v1.10.0 — 외부 wire 인프라 테스트.

interfaces / adapters / config.sources / HarnessConfig.resolve / Pipeline.from_config inject.
"""

import asyncio
import json
import tempfile
from pathlib import Path

import pytest


# ─────────────────────────────────────────────────────────
# interfaces
# ─────────────────────────────────────────────────────────


def test_interfaces_top_level_import():
    """xgen_harness.interfaces — DocService / OntologyService / LLMProvider re-export."""
    from xgen_harness.interfaces import DocService, OntologyService, LLMProvider, ProviderEvent
    assert DocService is not None
    assert OntologyService is not None
    assert LLMProvider is not None
    assert ProviderEvent is not None


def test_doc_service_protocol_duck_type():
    """DocService Protocol — runtime_checkable 로 isinstance 통과."""
    from xgen_harness.interfaces import DocService

    class MyDoc:
        async def search(self, query, collection_name, **kwargs):
            return [{"content": "hit", "score": 0.9}]

    assert isinstance(MyDoc(), DocService)

    # search 메서드 없으면 False
    class NotDoc:
        async def other(self): pass

    assert not isinstance(NotDoc(), DocService)


# ─────────────────────────────────────────────────────────
# adapters
# ─────────────────────────────────────────────────────────


def test_qdrant_doc_service_satisfies_protocol():
    """QdrantDocService 가 DocService Protocol 만족."""
    from xgen_harness.adapters import QdrantDocService
    from xgen_harness.interfaces import DocService

    qd = QdrantDocService(url="http://localhost:6333")
    assert isinstance(qd, DocService)


def test_adapters_re_export_create_provider():
    """adapters 에서 providers.create_provider re-export."""
    from xgen_harness.adapters import create_provider, register_provider
    assert callable(create_provider)
    assert callable(register_provider)


# ─────────────────────────────────────────────────────────
# config.sources
# ─────────────────────────────────────────────────────────


def test_dict_config_source():
    from xgen_harness.config import DictConfigSource
    data = {"system_prompt": "hi", "stage_params": {"s06": {"top_k": 10}}}
    src = DictConfigSource(data)
    assert src.load() == data


def test_env_config_source_basic():
    from xgen_harness.config import EnvConfigSource
    env = {
        "XGEN_HARNESS_SYSTEM_PROMPT": "from env",
        "XGEN_HARNESS_RAG_COLLECTIONS": '["c1", "c2"]',
        "OTHER_VAR": "ignored",
    }
    src = EnvConfigSource(env=env)
    loaded = src.load()
    assert loaded["system_prompt"] == "from env"
    assert loaded["rag_collections"] == ["c1", "c2"]
    assert "other_var" not in loaded


def test_env_config_source_nested():
    from xgen_harness.config import EnvConfigSource
    env = {
        "XGEN_HARNESS_STAGE_PARAMS__S06_CONTEXT__TOP_K": "20",
        "XGEN_HARNESS_STAGE_PARAMS__S06_CONTEXT__RERANKER": "true",
        "XGEN_HARNESS_RUNTIME_DEFAULTS__SYNTH_RAW_THRESHOLD": "5000",
    }
    src = EnvConfigSource(env=env)
    loaded = src.load()
    assert loaded["stage_params"]["s06_context"]["top_k"] == 20
    assert loaded["stage_params"]["s06_context"]["reranker"] is True
    assert loaded["runtime_defaults"]["synth_raw_threshold"] == 5000


def test_env_config_source_value_types():
    from xgen_harness.config import EnvConfigSource
    env = {
        "XGEN_HARNESS_BOOL_T": "true",
        "XGEN_HARNESS_BOOL_F": "false",
        "XGEN_HARNESS_INT": "42",
        "XGEN_HARNESS_FLOAT": "0.7",
        "XGEN_HARNESS_STR": "hello",
    }
    src = EnvConfigSource(env=env)
    loaded = src.load()
    assert loaded["bool_t"] is True
    assert loaded["bool_f"] is False
    assert loaded["int"] == 42
    assert loaded["float"] == 0.7
    assert loaded["str"] == "hello"


def test_file_config_source_toml(tmp_path):
    from xgen_harness.config import FileConfigSource
    f = tmp_path / "config.toml"
    f.write_text(
        '[stage_params.s06_context]\ntop_k = 30\nreranker = true\n\n'
        '[runtime_defaults]\nsynth_sub_max_turns = 10\n'
    )
    src = FileConfigSource(f)
    loaded = src.load()
    assert loaded["stage_params"]["s06_context"]["top_k"] == 30
    assert loaded["stage_params"]["s06_context"]["reranker"] is True
    assert loaded["runtime_defaults"]["synth_sub_max_turns"] == 10


def test_file_config_source_json(tmp_path):
    from xgen_harness.config import FileConfigSource
    f = tmp_path / "config.json"
    f.write_text(json.dumps({"system_prompt": "json sys"}))
    src = FileConfigSource(f)
    assert src.load() == {"system_prompt": "json sys"}


def test_file_config_source_missing_ok():
    from xgen_harness.config import FileConfigSource
    src = FileConfigSource("/nonexistent/path.toml")
    assert src.load() == {}


def test_deep_merge_basic():
    from xgen_harness.config import deep_merge
    base = {"a": 1, "b": {"x": 1, "y": 2}}
    overlay = {"b": {"x": 99}, "c": 3}
    assert deep_merge(base, overlay) == {"a": 1, "b": {"x": 99, "y": 2}, "c": 3}


def test_deep_merge_list_overrides():
    """list 는 통째 덮음 (deep merge 안 함)."""
    from xgen_harness.config import deep_merge
    base = {"rag_collections": ["a", "b"]}
    overlay = {"rag_collections": ["c"]}
    assert deep_merge(base, overlay) == {"rag_collections": ["c"]}


# ─────────────────────────────────────────────────────────
# HarnessConfig.resolve
# ─────────────────────────────────────────────────────────


def test_harness_config_resolve_priority():
    """sources[0] 이 가장 우선."""
    from xgen_harness import HarnessConfig
    from xgen_harness.config import DictConfigSource, EnvConfigSource

    cluster = {"system_prompt": "cluster", "stage_params": {"s06_context": {"top_k": 10, "reranker": True}}}
    env = {"XGEN_HARNESS_STAGE_PARAMS__S06_CONTEXT__TOP_K": "20"}

    config = HarnessConfig.resolve(sources=[
        EnvConfigSource(env=env),
        DictConfigSource(cluster),
    ])
    # env top_k=20 우선, cluster reranker=True 보존, cluster system_prompt 유지
    assert config.system_prompt == "cluster"
    assert config.stage_params["s06_context"] == {"top_k": 20, "reranker": True}


def test_harness_config_resolve_runtime_defaults_register():
    """runtime_defaults source 가 자동 register."""
    from xgen_harness import HarnessConfig
    from xgen_harness.config import DictConfigSource
    from xgen_harness.core.runtime_defaults import get_runtime_default

    HarnessConfig.resolve(sources=[
        DictConfigSource({
            "runtime_defaults": {
                "test_v1_10_marker": 12345,
            },
        }),
    ])
    assert get_runtime_default("test_v1_10_marker") == 12345


def test_harness_config_resolve_none_skip():
    """sources 에 None 박혀도 skip."""
    from xgen_harness import HarnessConfig
    from xgen_harness.config import DictConfigSource

    config = HarnessConfig.resolve(sources=[
        None,
        DictConfigSource({"system_prompt": "ok"}),
        None,
    ])
    assert config.system_prompt == "ok"


def test_harness_config_resolve_empty():
    """빈 sources 도 OK — default HarnessConfig 반환."""
    from xgen_harness import HarnessConfig
    config = HarnessConfig.resolve(sources=[])
    assert config is not None
    assert isinstance(config.stage_params, dict)


# ─────────────────────────────────────────────────────────
# Pipeline.from_config — doc_service / provider inject
# ─────────────────────────────────────────────────────────


def test_pipeline_from_config_inject_doc_service():
    from xgen_harness import Pipeline, HarnessConfig
    from xgen_harness.adapters import QdrantDocService

    qd = QdrantDocService(url="http://localhost:6333")
    pipe = Pipeline.from_config(HarnessConfig(), doc_service=qd)
    assert pipe._injected_doc_service is qd
    assert pipe._injected_provider is None


def test_pipeline_from_config_no_inject_bc():
    """BC: doc_service / provider 미주입 시 None — 기존 cluster wire 영향 X."""
    from xgen_harness import Pipeline, HarnessConfig
    pipe = Pipeline.from_config(HarnessConfig())
    assert pipe._injected_doc_service is None
    assert pipe._injected_provider is None
