# AGENTS.md

Instructions for AI coding agents working on this repository.

## Project overview

`infinity-observability-sdk` is a **Python SDK** (published to PyPI) that provides
a unified observability stack for all Infinity Constellation services — tracing,
structured logging, and optional error tracking.

- **Type**: Library (not an application — no server, no Django, no Dockerfile)
- **Package manager**: [uv](https://github.com/astral-sh/uv) (not pip, not poetry)
- **Python**: 3.12+
- **Core deps**: `opentelemetry-api`, `opentelemetry-sdk`,
  `opentelemetry-exporter-otlp-proto-http`, `structlog`
- **Optional extras**: `[logfire]`, `[sentry]`, `[django]`

## Project layout

```
├── infinity_observability_sdk/
│   ├── __init__.py        # Public API exports
│   ├── sdk.py             # Core: configure_observability, agent_context, get_tracer,
│   │                      #       instrument_django, get_environment, get_current_config
│   └── _logging.py        # Structured logging via structlog
├── tests/
│   └── test_sdk.py        # Unit tests (all components)
├── .github/
│   ├── actions/setup/     # Composite action: Python + uv setup
│   └── workflows/
│       ├── ci.yml         # Lint, format-check, test, build — on every push/PR
│       └── release.yml    # CI + PSR version bump + conditional PyPI publish — on merge to main
├── Makefile               # Task runner (install, lint, format, test, build, ci)
├── pyproject.toml         # Package config, deps, optional extras, tool config
├── AGENTS.md              # This file
├── CLAUDE.md              # Claude-specific overrides
```

Note: `_django.py` no longer exists — Django instrumentation (`instrument_django()`) lives in `sdk.py`.

## Dev environment setup

```bash
uv sync --dev   # Install all deps including dev group
uv run pytest   # Run tests
```

All Python commands must use `uv run ...` — never bare `python` or `pip`.

## Build, lint, and test commands

| Task | Command |
|---|---|
| Format code | `make format` |
| Check formatting | `make format-check` |
| Lint | `make lint` |
| Lint + auto-fix | `make lint-fix` |
| Run tests | `make test` |
| Run tests (verbose) | `make test-verbose` |
| Build package | `make build` |
| Validate package | `make check` |
| Full CI locally | `make ci` |

After large changesets, run `make ci` to verify nothing is broken.
This is the same sequence GitHub Actions runs.

## Adding dependencies

```bash
uv add <package>              # Runtime dependency (goes in [project].dependencies)
uv add --optional logfire <package>  # Optional extra dependency
uv add --dev <package>        # Dev-only dependency (goes in [dependency-groups].dev)
```

Do NOT edit `pyproject.toml` dependency lists by hand.

## Testing conventions

- Test files are named `test_*.py` and live in `tests/`
- Use `InMemorySpanExporter` from `opentelemetry.sdk.trace.export.in_memory_span_exporter`
  for span assertions (not the `.in_memory` submodule — that path changed in v1.39)
- The `_reset_sdk` fixture in `tests/test_sdk.py` resets OTel global state
  between tests by clearing `trace._TRACER_PROVIDER` and `trace._TRACER_PROVIDER_SET_ONCE._done`
- Soft dependencies (sentry, logfire) are tested via `patch.dict("sys.modules", ...)`
- Required env vars are set via the `env` fixture using `monkeypatch`

## Commit message convention

This project follows [Conventional Commits](https://www.conventionalcommits.org/).
Every commit message must have the format:

```
<type>(<scope>): <short summary>

[optional body]

[optional footer(s)]
```

### Types

| Type | When to use | Version bump |
|---|---|---|
| `feat` | New feature or public API addition | minor |
| `fix` | Bug fix | patch |
| `docs` | Documentation only | none |
| `style` | Formatting, whitespace (no logic change) | none |
| `refactor` | Code restructuring (no feature or fix) | none |
| `perf` | Performance improvement | patch |
| `test` | Adding or updating tests | none |
| `build` | Build system, dependencies, pyproject.toml | none |
| `ci` | CI/CD workflow changes | none |
| `chore` | Maintenance tasks | none |

### Scope

| Scope | Area |
|---|---|
| `sdk` | `sdk.py` — core configure/trace/agent_context/instrument_django |
| `logging` | `_logging.py` — structlog configuration |
| `django` | Django integration (`instrument_django()` in `sdk.py`) |
| `deps` | Dependency updates |
| `ci` | GitHub Actions workflows |
| `docs` | README, AGENTS.md |

### Examples

```
feat(sdk): add configure_metrics() for OTel metrics support
fix(logging): preserve existing root handlers on re-configure
refactor(sdk): extract _configure_sentry into dedicated module
test(sdk): add agent_context baggage cleanup assertion
build(deps): bump opentelemetry-sdk to 1.40.0
ci: pin ubuntu-latest to ubuntu-24.04 for reproducibility
docs(sdk): add usage examples to README
chore: update .gitignore for uv cache
```

### Breaking changes

Append `!` after the type/scope, or add a `BREAKING CHANGE:` footer:

```
feat(sdk)!: remove logfire as a hard dependency

BREAKING CHANGE: logfire is now an optional extra. Install with
`pip install infinity-observability-sdk[logfire]` to restore previous behaviour.
```

Breaking changes trigger a **major** version bump.

## Versioning and releases

This project uses [semantic versioning](https://semver.org/) (`MAJOR.MINOR.PATCH`).
Releases are **fully automated** via `python-semantic-release` on every merge to `main`.

Version bumps are derived from commit messages:

- `fix:` / `perf:` → **patch** (0.2.0 → 0.2.1)
- `feat:` → **minor** (0.2.1 → 0.3.0)
- `BREAKING CHANGE` / `!` → **major** (0.3.0 → 1.0.0)
- All other types (`docs`, `style`, `refactor`, `test`, `build`, `ci`, `chore`)
  do not trigger a release on their own but appear in the next release's changelog.

The version is set in **one place**: `pyproject.toml` → `[project].version`.
`sdk.py` reads it at runtime via `importlib.metadata.version()` — no manual sync needed.

**Do not manually create GitHub Releases or bump the version.**
The release pipeline handles this automatically.

## CI/CD pipeline

### On every push and PR (`ci.yml`)
1. `uv sync --dev`
2. `ruff check .` — lint
3. `ruff format --check .` — format check
4. `pytest` — tests
5. `uv build` — package builds cleanly
6. `uvx twine check dist/*` — package metadata is valid

### On merge to main (`release.yml`)
1. Runs the full CI suite (same as above)
2. `python-semantic-release` analyses commits since the last release
3. If a release-worthy commit exists: bumps `pyproject.toml` version, creates a
   `vX.Y.Z` tag, and publishes a GitHub Release with generated release notes
4. The version-bump commit uses `[skip ci]` to prevent re-triggering this workflow

The PyPI publish steps run **inside `release.yml`** (not a separate workflow), gated on
`steps.release.outputs.released == 'true'`. This avoids the GitHub restriction that
blocks downstream workflows triggered by `GITHUB_TOKEN`-created Release events.

## PR workflow

- Work in feature branches, open PRs against `main`
- Tag `slensgra` as reviewer
- All CI checks must pass before merge
- PR title should follow the same conventional commit format (it becomes the
  squash-merge commit message)

## Important conventions

- Soft dependencies (sentry-sdk, logfire, opentelemetry-instrumentation-django)
  are never imported at module level — always inside try/except ImportError blocks
- `configure_observability()` is idempotent — safe to call multiple times; subsequent
  calls are no-ops
- `ENVIRONMENT=development` switches log output from JSON to human-readable console
- The `agent_context()` API signature is **backward-compatible** — do not remove
  or rename positional parameters
- `instrument_django` is exported from the top-level `__init__.py` — consumers
  import it as `from infinity_observability_sdk import instrument_django`
