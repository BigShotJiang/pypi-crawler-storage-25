"""
Structured logging configuration using *structlog*.

* **Production** (default): JSON lines to stdout with OTel trace correlation.
* **Development** (``ENVIRONMENT=development``): Colorful console output.

Called automatically by :func:`~infinity_observability_sdk.sdk.configure_observability`.
Can also be called standalone for services that only need logging.
"""

from __future__ import annotations

import logging
import os
import sys

import structlog
from opentelemetry import trace

_handler: logging.Handler | None = None


def reset_handler_for_testing() -> None:
    """Reset logging handler state.  For use in tests only."""
    global _handler
    if _handler is not None:
        logging.getLogger().removeHandler(_handler)
        _handler = None


# ---------------------------------------------------------------------------
# Processors
# ---------------------------------------------------------------------------


def _add_otel_trace_context(
    _logger: object,
    _method_name: str,
    event_dict: structlog.types.EventDict,
) -> structlog.types.EventDict:
    """Inject ``trace_id`` and ``span_id`` from the current OTel context."""
    span = trace.get_current_span()
    if span.is_recording():
        ctx = span.get_span_context()
        event_dict["trace_id"] = format(ctx.trace_id, "032x")
        event_dict["span_id"] = format(ctx.span_id, "016x")
    return event_dict


def _add_service_name(
    service_name: str,
) -> structlog.types.Processor:
    """Return a processor that adds ``service`` to every log event."""

    def processor(
        _logger: object,
        _method_name: str,
        event_dict: structlog.types.EventDict,
    ) -> structlog.types.EventDict:
        event_dict["service"] = service_name
        return event_dict

    return processor


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def configure_logging(
    service_name: str,
    log_level: str = "INFO",
    environment: str | None = None,
) -> None:
    """Configure *structlog* and the stdlib root logger.

    Parameters
    ----------
    service_name:
        Identifies the service in log output (e.g. ``"bu.service"``).
    log_level:
        Python log level name (``"DEBUG"``, ``"INFO"``, etc.).
    environment:
        Deployment environment string.  When called via
        :func:`~infinity_observability_sdk.configure_observability` this is
        supplied from the single cached read of the ``ENVIRONMENT`` env var.
        When called standalone it falls back to reading ``ENVIRONMENT`` directly.
    """
    resolved_env = (
        environment
        if environment is not None
        else os.environ.get("ENVIRONMENT", "production")
    )
    is_dev = resolved_env.lower() == "development"

    # Shared processors — run for both structlog-originated and stdlib-
    # originated log events.
    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        _add_service_name(service_name),
        _add_otel_trace_context,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.stdlib.ExtraAdder(),
        structlog.processors.StackInfoRenderer(),
    ]

    if is_dev:
        # Pretty console output for local development.
        renderer: structlog.types.Processor = structlog.dev.ConsoleRenderer()
    else:
        # JSON for production — one object per line.
        renderer = structlog.processors.JSONRenderer()

    # --- Configure structlog itself ---
    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # --- Hook into stdlib logging so Django / uvicorn / third-party libs
    #     also produce structured output through the same pipeline. ---
    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
        foreign_pre_chain=shared_processors,
    )

    global _handler

    new_handler = logging.StreamHandler(sys.stdout)
    new_handler.setFormatter(formatter)

    root = logging.getLogger()
    if _handler is not None and _handler in root.handlers:
        root.removeHandler(_handler)
    root.addHandler(new_handler)
    root.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    _handler = new_handler
