"""
Infinity Observability SDK
==========================

Unified observability for Infinity Constellation services — tracing,
structured logging, and optional error tracking.

Quick start::

    from infinity_observability_sdk import configure_observability, ObservabilityConfig

    configure_observability(ObservabilityConfig(
        business_unit_name="my_bu",
        service_name="my_service",
    ))

Required environment variables:
    INFINITY_OBSERVABILITY_ENDPOINT: The OTLP collector endpoint.
    INFINITY_OBSERVABILITY_API_KEY:  API key for authentication.

Optional extras::

    pip install infinity-observability-sdk[logfire]   # pydantic-ai / httpx auto-instrumentation
    pip install infinity-observability-sdk[sentry]    # Sentry error tracking
    pip install infinity-observability-sdk[django]    # Django OTel auto-instrumentation
"""

from .sdk import (
    ObservabilityConfig,
    agent_context,
    configure_observability,
    get_current_config,
    get_environment,
    get_tracer,
    instrument_django,
)
from ._logging import configure_logging

__all__ = [
    "ObservabilityConfig",
    "configure_observability",
    "agent_context",
    "get_tracer",
    "get_environment",
    "get_current_config",
    "configure_logging",
    "instrument_django",
]
