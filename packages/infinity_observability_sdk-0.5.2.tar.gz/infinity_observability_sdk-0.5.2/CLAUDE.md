<!-- Claude-specific overrides. The canonical agent instructions live in AGENTS.md. -->

Read AGENTS.md first — it contains the project layout, build/test commands,
commit conventions, and all workflow instructions.

## Claude-specific notes

- When generating commit messages, always use the Conventional Commits format
  documented in AGENTS.md.
- Use `uv run ...` for all Python commands. Never bare `python` or `pip`.
- To add dependencies use `uv add <pkg>`, not manual pyproject.toml edits.
- Run `make ci` after large changesets to catch regressions.
- This is a library — do not create application files (Dockerfile, manage.py, etc.).
