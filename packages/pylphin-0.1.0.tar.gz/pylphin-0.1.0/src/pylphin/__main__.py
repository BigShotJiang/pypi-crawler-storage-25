"""Allow running as `python -m pylphin`."""
from .pylphin import main

if __name__ == "__main__":
    main()
