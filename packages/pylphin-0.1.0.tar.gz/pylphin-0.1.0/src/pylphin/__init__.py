"""Pylphin — Dolphin-inspired PyQt6 file explorer."""

__version__ = "0.1.0"
__author__ = "D. Saahishnu Ram"

from .pylphin import (
    Pylphin,
    pick_file,
    pick_files,
    pick_folder,
    main,
)

__all__ = [
    "Pylphin",
    "pick_file",
    "pick_files",
    "pick_folder",
    "main",
    "__version__",
]
