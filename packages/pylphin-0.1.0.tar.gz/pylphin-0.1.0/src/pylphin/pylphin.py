
"""
Pylphin — Dolphin-inspired PyQt6 file explorer
Breeze Icons (LGPL-3.0) — https://github.com/KDE/breeze-icons
Local-first MIME icon edition + OS fallback + removable eject + live drive rescan
Author: D. Saahishnu Ram
"""
import sys, os, re, shutil, subprocess, urllib.request, mimetypes
from datetime import datetime
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QSplitter, QTreeView, QListView,
    QVBoxLayout, QHBoxLayout, QToolBar, QStatusBar, QLabel, QPushButton,
    QLineEdit, QMenu, QMessageBox, QInputDialog, QAbstractItemView,
    QHeaderView, QStackedWidget, QTreeWidget, QTreeWidgetItem,
    QFileIconProvider, QSizePolicy, QStyledItemDelegate, QStyle, QPlainTextEdit
)
from PyQt6.QtGui import (
    QIcon, QFont, QAction, QColor, QFileSystemModel,
    QCursor, QDesktopServices, QPainter, QPalette, QPainterPath
)
from PyQt6.QtCore import (
    Qt, QDir, QUrl, QSize, QModelIndex, QThread, pyqtSignal,
    QTimer, QFileInfo, QRect, QEventLoop, QEvent
)

# ──────────────────────────────────────────────────────────────────────────────
#  OPTIONAL libmagic for accurate MIME detection (pip install python-magic)
# ──────────────────────────────────────────────────────────────────────────────
try:
    import magic
    _HAS_MAGIC = True
except Exception:
    _HAS_MAGIC = False

# ──────────────────────────────────────────────────────────────────────────────
#  LOCAL ICON DISCOVERY
# ──────────────────────────────────────────────────────────────────────────────
_SCRIPT_DIR = Path(__file__).resolve().parent
_ASSETS_DIR = _SCRIPT_DIR / "assets" / "icons"  # ← ADD THIS

LOCAL_SVG_MAP: dict[str, Path] = {
    p.stem: p for p in _ASSETS_DIR.glob("*.svg")  # ← CHANGED
    if p.is_file() and p.stat().st_size > 0
}

def _local_icon(name: str) -> QIcon | None:
    """Return a QIcon for a local SVG name if it exists and is non-empty."""
    path = LOCAL_SVG_MAP.get(name)
    if path is None:
        return None
    return QIcon(str(path))

# ──────────────────────────────────────────────────────────────────────────────
#  REMOTE UI ICONS  (toolbar / sidebar fallback — only downloaded if missing locally)
# ──────────────────────────────────────────────────────────────────────────────
BASE_URL = "https://raw.githubusercontent.com/KDE/breeze-icons/master/"
CACHE    = Path.home() / ".cache" / "Pylphin" / "icons"

UI_ICONS = {
    "go-previous":   "icons/actions/22/go-previous.svg",
    "go-next":       "icons/actions/22/go-next.svg",
    "go-up":         "icons/actions/22/go-up.svg",
    "view-refresh":  "icons/actions/22/view-refresh.svg",
    "go-home":       "icons/actions/22/go-home.svg",
    "folder-new":    "icons/actions/22/folder-new.svg",
    "edit-delete":   "icons/actions/22/edit-delete.svg",
    "edit-rename":   "icons/actions/22/edit-rename.svg",
    "view-icons":    "icons/actions/22/view-list-icons.svg",
    "view-list":     "icons/actions/22/view-list-text.svg",
    "view-details":  "icons/actions/22/view-list-details.svg",
    "view-hidden":   "icons/actions/22/view-hidden.svg",
    "terminal":      "icons/apps/22/utilities-terminal.svg",
    "place-home":    "icons/actions/22/go-home.svg",
    "place-desktop": "icons/places/22/user-desktop.svg",
    "place-docs":    "icons/places/22/folder-documents.svg",
    "place-dl":      "icons/places/22/folder-downloads.svg",
    "place-music":   "icons/places/22/folder-music.svg",
    "place-pics":    "icons/places/22/folder-pictures.svg",
    "place-videos":  "icons/places/22/folder-videos.svg",
    "place-trash":   "icons/places/22/user-trash.svg",
    "place-network": "icons/places/22/network-workgroup.svg",
    "place-drive":   "icons/devices/22/drive-harddisk.svg",
    "place-folder":  "icons/places/22/folder.svg",
}

_PLACE_ALIASES = {
    "place-home":    "user-home",
    "place-desktop": "user-desktop",
    "place-docs":    "folder-documents",
    "place-dl":      "folder-downloads",
    "place-music":   "folder-music",
    "place-pics":    "folder-pictures",
    "place-videos":  "folder-videos",
    "place-trash":   "user-trash",
    "place-network": "network-workgroup",
    "place-drive":   "drive-harddisk",
    "place-folder":  "folder",
}

ALL_ICONS = {**UI_ICONS}

# ──────────────────────────────────────────────────────────────────────────────
#  SVG RECOLORING (applied only to remote UI icons)
# ──────────────────────────────────────────────────────────────────────────────
_COLOR_SUBS_DARK = [
    (re.compile(r'(\.ColorScheme-Text\s*\{[^}]*color\s*:\s*)#[0-9a-fA-F]{6}'),  r'\g<1>#eff0f1'),
    (re.compile(r'(\.ColorScheme-Highlight\s*\{[^}]*color\s*:\s*)#[0-9a-fA-F]{6}'), r'\g<1>#3daee9'),
    (re.compile(r'(\.ColorScheme-ButtonText\s*\{[^}]*color\s*:\s*)#[0-9a-fA-F]{6}'), r'\g<1>#eff0f1'),
]

def _recolor_dark(svg_bytes: bytes) -> bytes:
    t = svg_bytes.decode("utf-8", errors="replace")
    for pat, repl in _COLOR_SUBS_DARK:
        t = pat.sub(repl, t)
    return t.encode("utf-8")

# ──────────────────────────────────────────────────────────────────────────────
#  REMOTE DOWNLOAD HELPERS
# ──────────────────────────────────────────────────────────────────────────────
def _download_icon(name: str) -> Path | None:
    path_rel = ALL_ICONS.get(name)
    if not path_rel:
        return None
    dest = CACHE / f"{name}.svg"
    if dest.exists():
        return dest
    try:
        with urllib.request.urlopen(BASE_URL + path_rel, timeout=8) as r:
            raw = r.read()
        stripped = raw.strip()
        if len(stripped) < 200 and stripped.endswith(b".svg"):
            link = stripped.decode()
            base = "/".join(path_rel.split("/")[:-1])
            resolved = os.path.normpath(base + "/" + link).replace("\\", "/")
            with urllib.request.urlopen(BASE_URL + resolved, timeout=8) as r2:
                raw = r2.read()
        raw = _recolor_dark(raw)
        CACHE.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        return dest
    except Exception:
        return None

class _Downloader(QThread):
    done = pyqtSignal(str, str)
    def __init__(self, names): super().__init__(); self.names = names
    def run(self):
        for n in self.names:
            p = _download_icon(n)
            if p: self.done.emit(n, str(p))


# ──────────────────────────────────────────────────────────────────────────────
#  EJECT WORKER  (runs in background thread — never blocks the UI)
# ──────────────────────────────────────────────────────────────────────────────
def _win_eject_ctypes(letter: str) -> bool:
    """
    Most reliable Windows eject: DeviceIoControl(IOCTL_STORAGE_EJECT_MEDIA).
    Works on USB sticks, SD cards, external HDDs.
    """
    import ctypes, ctypes.wintypes as wt
    GENERIC_READ        = 0x80000000
    GENERIC_WRITE       = 0x40000000
    FILE_SHARE_READ     = 0x00000001
    FILE_SHARE_WRITE    = 0x00000002
    OPEN_EXISTING       = 3
    INVALID_HANDLE      = ctypes.c_void_p(-1).value
    IOCTL_STORAGE_EJECT = 0x2D4808          # IOCTL_STORAGE_EJECT_MEDIA

    k32 = ctypes.windll.kernel32
    handle = k32.CreateFileW(
        f"\\\\.\\{letter}:",
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        None, OPEN_EXISTING, 0, None
    )
    if handle == INVALID_HANDLE or handle == 0:
        return False
    try:
        returned = ctypes.c_ulong(0)
        ok = k32.DeviceIoControl(
            handle, IOCTL_STORAGE_EJECT,
            None, 0, None, 0,
            ctypes.byref(returned), None
        )
        return bool(ok)
    finally:
        k32.CloseHandle(handle)


class _EjectWorker(QThread):
    succeeded = pyqtSignal(str)          # label
    failed    = pyqtSignal(str, str)     # label, reason

    def __init__(self, path: str):
        super().__init__()
        self._path = path

    def run(self):
        path = self._path
        if sys.platform == "win32":
            self._eject_win(path)
        else:
            self._eject_linux(path)

    # ── Windows ────────────────────────────────────────────────────────────
    def _eject_win(self, path: str):
        letter = Path(path).drive.rstrip(":\\")
        label  = f"{letter}:"

        # Method 1: DeviceIoControl (most reliable, no subprocess)
        try:
            if _win_eject_ctypes(letter):
                self.succeeded.emit(label)
                return
        except Exception:
            pass

        # Method 2: PowerShell Shell.Application COM
        try:
            ps = (
                f'$sh = New-Object -comObject Shell.Application; '
                f'$ns = $sh.Namespace(17); '
                f'$item = $ns.ParseName("{letter}:"); '
                f'if ($item) {{ $item.InvokeVerb("Eject") }}'
            )
            subprocess.run(
                ["powershell", "-WindowStyle", "Hidden", "-Command", ps],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                check=True, timeout=15, capture_output=True
            )
            self.succeeded.emit(label)
            return
        except Exception:
            pass

        # Method 3: WMIC (legacy Windows fallback)
        try:
            subprocess.run(
                ["wmic", "path", "win32_logicaldisk",
                 "where", f"DeviceID='{letter}:'", "call", "Eject"],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                check=True, timeout=15, capture_output=True
            )
            self.succeeded.emit(label)
            return
        except Exception:
            pass

        self.failed.emit(label,
            "All three eject methods failed.\n"
            "Try the system tray Safely Remove Hardware icon.")

    # ── Linux ──────────────────────────────────────────────────────────────
    def _eject_linux(self, path: str):
        label = Path(path).name or path
        dev = None
        try:
            with open("/proc/mounts", "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2 and parts[1] == path:
                        dev = parts[0]; break
        except Exception:
            pass
        if not dev:
            try:
                out = subprocess.check_output(
                    ["findmnt", "-n", "-o", "SOURCE", path],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
                if out: dev = out
            except Exception:
                pass
        if dev:
            try:
                subprocess.run(["udisksctl", "unmount", "-b", dev],
                               check=False, timeout=10, capture_output=True)
                subprocess.run(["udisksctl", "power-off", "-b", dev],
                               check=False, timeout=10, capture_output=True)
                self.succeeded.emit(label); return
            except Exception:
                pass
            try:
                subprocess.run(["eject", dev],
                               check=False, timeout=10, capture_output=True)
                self.succeeded.emit(label); return
            except Exception:
                pass
        self.failed.emit(label,
            "Could not automatically eject this drive.\n"
            "Please use your system tray / file manager.")


class IconManager:
    def __init__(self):
        self._icons: dict[str, QIcon] = {}
        CACHE.mkdir(parents=True, exist_ok=True)
        for name, path in LOCAL_SVG_MAP.items():
            self._icons[name] = QIcon(str(path))
        for p in CACHE.glob("*.svg"):
            self._icons.setdefault(p.stem, QIcon(str(p)))

    def get(self, name: str, fallback: str = "") -> QIcon:
        if name in self._icons:
            return self._icons[name]
        p = _download_icon(name)
        if p:
            self._icons[name] = QIcon(str(p))
            return self._icons[name]
        if fallback:
            return self.get(fallback)
        return QIcon()

    def start_download(self, on_ready=None):
        missing = [n for n in ALL_ICONS if n not in self._icons]
        if not missing: return
        self._worker = _Downloader(missing)
        if on_ready: self._worker.done.connect(on_ready)
        self._worker.done.connect(lambda n, p: self._icons.update({n: QIcon(p)}))
        self._worker.start()

ICONS = IconManager()

# ──────────────────────────────────────────────────────────────────────────────
#  EXTENSION BUCKETS (last-resort heuristics)
# ──────────────────────────────────────────────────────────────────────────────
_IMG   = {".jpg",".jpeg",".png",".gif",".bmp",".webp",".tiff",".ico",".svg"}
_AUDIO = {".mp3",".flac",".ogg",".wav",".aac",".m4a",".opus",".wma"}
_VIDEO = {".mp4",".mkv",".avi",".mov",".webm",".flv",".wmv",".m4v"}
_TEXT  = {".txt",".md",".rst",".log",".csv",".ini",".cfg"}
_CODE  = {".cpp",".c",".h",".hpp",".js",".ts",".jsx",".tsx",
          ".java",".cs",".go",".rs",".rb",".php",".swift",".kt",".lua",
          ".nim",".r",".scala",".qml",".cmake"}
_HTML  = {".html",".htm",".xml",".xhtml"}
_ZIP   = {".zip",".7z"}
_TAR   = {".gz",".bz2",".xz",".tar",".tgz",".tbz2"}
_ARCH  = {".rar",".cab",".iso",".img"}
_WORD  = {".doc",".docx",".odt",".rtf"}
_XL    = {".xls",".xlsx",".ods",".csv"}
_EXE   = {".exe",".msi",".com",".dll"}
_SH    = {".sh",".bash",".zsh",".fish",".bat",".cmd",".ps1"}

# ──────────────────────────────────────────────────────────────────────────────
#  BREEZE FILE ICON PROVIDER (Extension-first → MIME → OS → Unknown)
# ──────────────────────────────────────────────────────────────────────────────
class BreezeIconProvider(QFileIconProvider):
    def __init__(self):
        super().__init__()
        self._ext_map = self._build_ext_map()

    @staticmethod
    def _build_ext_map() -> dict[str, str]:
        """Extension → local icon name (only if the SVG actually exists)."""
        m: dict[str, str] = {}

        manual: dict[str, str] = {
            ".py": "text-x-python",
            ".pyw": "text-x-python",
            ".pyc": "application-x-python-bytecode",
            ".pyo": "application-x-python-bytecode",
            ".cpp": "text-x-c++src",
            ".cxx": "text-x-c++src",
            ".cc": "text-x-c++src",
            ".h": "text-x-chdr",
            ".hpp": "text-x-c++hdr",
            ".c": "text-x-csrc",
            ".rs": "text-x-rust",
            ".go": "text-x-go",
            ".js": "application-javascript",
            ".mjs": "application-javascript",
            ".java": "text-x-java",
            ".class": "application-x-java",
            ".jar": "application-x-java-archive",
            ".cs": "text-x-csharp",
            ".php": "application-x-php",
            ".rb": "text-x-ruby",
            ".swift": "text-x-swift",
            ".kt": "text-x-kotlin",
            ".kts": "text-x-kotlin",
            ".lua": "text-x-lua",
            ".nim": "text-x-nim",
            ".r": "text-x-r",
            ".scala": "text-x-scala",
            ".sh": "application-x-shellscript",
            ".bash": "application-x-shellscript",
            ".zsh": "application-x-shellscript",
            ".fish": "application-x-shellscript",
            ".ps1": "application-x-powershell",
            ".bat": "application-x-ms-dos-executable",
            ".cmd": "application-x-ms-dos-executable",
            ".exe": "application-x-ms-dos-executable",
            ".msi": "application-x-ms-dos-executable",
            ".dll": "application-x-sharedlib",
            ".so": "application-x-sharedlib",
            ".pdf": "application-pdf",
            ".doc": "application-msword",
            ".docx": "application-vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".dot": "application-msword-template",
            ".dotx": "application-vnd.openxmlformats-officedocument.wordprocessingml.template",
            ".xls": "application-vnd.ms-excel",
            ".xlsx": "application-vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".xlsm": "application-vnd.ms-excel.sheet.macroenabled.12",
            ".ppt": "application-vnd.ms-powerpoint",
            ".pptx": "application-vnd.openxmlformats-officedocument.presentationml.presentation",
            ".potx": "application-vnd.openxmlformats-officedocument.presentationml.template",
            ".odt": "application-vnd.oasis.opendocument.text",
            ".ods": "application-vnd.oasis.opendocument.spreadsheet",
            ".odp": "application-vnd.oasis.opendocument.presentation",
            ".odg": "application-vnd.oasis.opendocument.graphics",
            ".html": "text-html",
            ".htm": "text-html",
            ".xhtml": "application-xhtml+xml",
            ".css": "text-css",
            ".xml": "text-xml",
            ".json": "application-json",
            ".toml": "application-toml",
            ".yaml": "application-x-yaml",
            ".yml": "application-x-yaml",
            ".ini": "text-x-generic",
            ".cfg": "text-x-generic",
            ".conf": "text-x-generic",
            ".txt": "text-plain",
            ".md": "text-markdown",
            ".rst": "text-x-generic",
            ".log": "text-x-generic",
            ".csv": "text-csv",
            ".tsv": "text-csv",
            ".sql": "application-sql",
            ".db": "application-vnd.sqlite3",
            ".sqlite": "application-vnd.sqlite3",
            ".sqlite3": "application-vnd.sqlite3",
            ".zip": "application-zip",
            ".tar": "application-x-tar",
            ".gz": "application-x-gzip",
            ".tgz": "application-x-compressed-tar",
            ".bz2": "application-x-bzip",
            ".tbz2": "application-x-bzip-compressed-tar",
            ".xz": "application-x-xz-compressed-tar",
            ".txz": "application-x-xz-compressed-tar",
            ".7z": "application-x-7z-compressed",
            ".rar": "application-x-rar",
            ".cab": "application-vnd.ms-cab-compressed",
            ".iso": "application-x-cd-image",
            ".img": "application-x-raw-disk-image",
            ".dmg": "application-x-apple-diskimage",
            ".deb": "application-x-deb",
            ".rpm": "application-x-rpm",
            ".apk": "android-package-archive",
            ".appimage": "application-vnd.appimage",
            ".snap": "application-vnd.snap",
            ".flatpak": "application-vnd.flatpak",
            ".mp3": "audio-mpeg",
            ".ogg": "audio-x-vorbis+ogg",
            ".oga": "audio-x-vorbis+ogg",
            ".ogv": "video-x-theora+ogg",
            ".flac": "audio-x-flac",
            ".wav": "audio-x-wav",
            ".aac": "audio-aac",
            ".m4a": "audio-mp4",
            ".opus": "audio-x-opus+ogg",
            ".wma": "audio-x-ms-wma",
            ".mp4": "video-mp4",
            ".m4v": "video-mp4",
            ".mkv": "video-x-matroska",
            ".avi": "video-x-msvideo",
            ".mov": "video-quicktime",
            ".wmv": "video-x-ms-wmv",
            ".flv": "video-x-flv",
            ".webm": "video-webm",
            ".jpg": "image-jpeg",
            ".jpeg": "image-jpeg",
            ".png": "image-png",
            ".gif": "image-gif",
            ".bmp": "image-bmp",
            ".webp": "image-webp",
            ".tiff": "image-tiff",
            ".tif": "image-tiff",
            ".svg": "image-svg+xml",
            ".svgz": "image-svg+xml-compressed",
            ".ico": "image-vnd.microsoft.icon",
            ".xcf": "image-x-xcf",
            ".psd": "image-x-psd",
            ".dng": "image-x-adobe-dng",
            ".ai": "application-illustrator",
            ".eps": "image-x-eps",
            ".ps": "application-postscript",
            ".epub": "application-epub+zip",
            ".tex": "text-x-tex",
            ".bib": "text-x-bibtex",
            ".patch": "text-x-patch",
            ".diff": "text-x-patch",
            ".po": "text-x-po",
            ".mo": "application-x-gettext-translation",
            ".qml": "text-x-qml",
            ".cmake": "text-x-cmake",
            ".dockerfile": "text-dockerfile",
            ".vtt": "text-vtt",
            ".srt": "application-x-srt",
            ".sub": "text-x-subviewer",
            ".ssa": "text-x-ssa",
            ".ass": "text-x-ssa",
            ".nfo": "text-x-nfo",
            ".dtd": "text-x-dtd",
            ".sgml": "text-sgml",
            ".wml": "text-vnd.wap.wml",
            ".reg": "text-x-generic",
            ".vcf": "text-x-vcard",
            ".ics": "text-calendar",
            ".vcs": "text-calendar",
        }

        for ext, icon_name in manual.items():
            if icon_name in LOCAL_SVG_MAP:
                m[ext] = icon_name

        # Augment with stdlib mimetypes for anything we have locally
        for ext, mime in {**mimetypes.types_map, **mimetypes.common_types}.items():
            icon_name = mime.replace("/", "-")
            if icon_name in LOCAL_SVG_MAP and ext not in m:
                m[ext] = icon_name

        return m

    def _mime_icon(self, mime: str) -> QIcon | None:
        """Resolve a MIME type string to a local icon."""
        if not mime:
            return None
        direct = mime.replace("/", "-")
        ic = _local_icon(direct)
        if ic:
            return ic

        category = mime.split("/")[0]
        generics = {
            "text": "text-x-generic",
            "image": "image-x-generic",
            "audio": "audio-x-generic",
            "video": "video-x-generic",
            "application": "application-octet-stream",
            "message": "message-rfc822",
            "multipart": "package-x-generic",
            "inode": "inode-directory",
        }
        generic = generics.get(category)
        if generic:
            ic = _local_icon(generic)
            if ic:
                return ic
        return None

    def icon(self, arg):
        if isinstance(arg, QFileInfo):
            # ── Directory ──
            if arg.isDir():
                p = Path(arg.absoluteFilePath())
                name = p.name.lower()
                specials = {
                    "desktop": "user-desktop",
                    "documents": "folder-documents",
                    "downloads": "folder-downloads",
                    "music": "folder-music",
                    "pictures": "folder-pictures",
                    "videos": "folder-videos",
                    "home": "user-home",
                    "trash": "user-trash",
                }
                if name in specials:
                    ic = _local_icon(specials[name])
                    if ic:
                        return ic
                for cand in ("inode-directory", "folder"):
                    ic = _local_icon(cand)
                    if ic:
                        return ic
                return ICONS.get("inode-dir", "folder")

            # ── File ──
            file_path = arg.absoluteFilePath()
            ext = Path(file_path).suffix.lower()

            # 1) Hard extension map FIRST (most reliable for theming)
            if ext in self._ext_map:
                ic = _local_icon(self._ext_map[ext])
                if ic:
                    return ic

            # 2) MIME detection (libmagic / mimetypes)
            mime = None
            # NOTE: libmagic intentionally NOT called here — reading file
            # content for every icon in a large directory causes UI freeze.
            # Extension + mimetypes DB is fast enough for icon resolution.
            mime, _ = mimetypes.guess_type(file_path, strict=False)

            if mime:
                ic = self._mime_icon(mime)
                if ic:
                    return ic

            # 3) Generic buckets (extensions without dedicated icons)
            if ext in _IMG and _local_icon("image-x-generic"):
                return _local_icon("image-x-generic")
            if ext in _AUDIO and _local_icon("audio-x-generic"):
                return _local_icon("audio-x-generic")
            if ext in _VIDEO and _local_icon("video-x-generic"):
                return _local_icon("video-x-generic")
            if ext in _CODE and _local_icon("text-x-generic"):
                return _local_icon("text-x-generic")
            if ext in _TEXT and _local_icon("text-plain"):
                return _local_icon("text-plain")
            if ext in _HTML and _local_icon("text-html"):
                return _local_icon("text-html")
            if ext in _ZIP and _local_icon("application-zip"):
                return _local_icon("application-zip")
            if ext in _TAR and _local_icon("application-x-compressed-tar"):
                return _local_icon("application-x-compressed-tar")
            if ext in _ARCH and _local_icon("application-x-archive"):
                return _local_icon("application-x-archive")
            if ext in _WORD and _local_icon("application-msword"):
                return _local_icon("application-msword")
            if ext in _XL and _local_icon("application-vnd.ms-excel"):
                return _local_icon("application-vnd.ms-excel")
            if ext in _EXE and _local_icon("application-x-ms-dos-executable"):
                return _local_icon("application-x-ms-dos-executable")
            if ext in _SH and _local_icon("application-x-shellscript"):
                return _local_icon("application-x-shellscript")
            if ext == ".pdf" and _local_icon("application-pdf"):
                return _local_icon("application-pdf")

            # 4) OS fallback — ask the operating system for its icon
            sys_icon = super().icon(arg)
            if not sys_icon.isNull():
                return sys_icon

            # 5) Unknown fallback
            ic = _local_icon("unknown")
            if ic:
                return ic
            return ICONS.get("unknown")

        return super().icon(arg)

# ──────────────────────────────────────────────────────────────────────────────
#  GLIMPSE SPEEDY — Quick-look file preview (Space to open/close)
# ──────────────────────────────────────────────────────────────────────────────
try:
    from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
    from PyQt6.QtMultimediaWidgets import QVideoWidget
    _HAS_MEDIA = True
except ImportError:
    _HAS_MEDIA = False

_GS_AUDIO = {'.mp3','.flac','.ogg','.oga','.wav','.aiff','.aif',
             '.m4a','.aac','.opus','.wma','.mpc','.ape','.wv',
             '.au','.snd','.spx','.mid','.midi','.amr','.ra'}
_GS_VIDEO = {'.mp4','.mkv','.webm','.avi','.wmv','.flv','.ogv',
             '.mov','.m4v','.ts','.m2ts','.mpg','.mpeg','.3gp',
             '.rm','.rmvb','.divx','.vob','.asf','.f4v'}
_GS_IMAGE = {'.jpg','.jpeg','.png','.gif','.bmp','.webp','.tiff',
             '.tif','.svg','.ico','.pbm','.pgm','.ppm','.xbm',
             '.xpm','.avif','.heic'}
_GS_TEXT  = {'.txt','.md','.rst','.log','.csv','.ini','.cfg','.conf',
             '.env','.py','.pyw','.js','.ts','.jsx','.tsx','.html',
             '.htm','.css','.json','.xml','.yaml','.yml','.toml',
             '.sh','.bash','.zsh','.fish','.bat','.cmd','.ps1',
             '.c','.cpp','.h','.hpp','.java','.cs','.go','.rs',
             '.rb','.php','.lua','.r','.sql','.awk','.pl','.pm',
             '.tcl','.nfo','.readme','.cmake','.dockerfile','.gd',
             '.nim','.kt','.scala','.hs','.lhs','.qml','.vtt',
             '.srt','.ssa','.ass','.sub','.diff','.patch','.gitignore'}


def _fmt_time(ms: int) -> str:
    s = ms // 1000
    return f"{s//60}:{s%60:02d}"

def _fmt_size(n: int) -> str:
    for unit in ("B","KB","MB","GB","TB"):
        if n < 1024: return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return f"{n:.1f} PB"


class _ImageView(QWidget):
    """Scrollable, mouse-drag-pannable, scroll-to-zoom image viewer."""
    def __init__(self):
        super().__init__()
        from PyQt6.QtWidgets import QScrollArea
        self._zoom = 1.0
        self._pix_orig = None
        self._drag_start = None
        self._scroll_start = None

        self._label = QLabel(alignment=Qt.AlignmentFlag.AlignCenter)
        self._label.setStyleSheet("background:transparent;")

        self._sa = QScrollArea()
        self._sa.setWidget(self._label)
        self._sa.setWidgetResizable(False)
        self._sa.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._sa.setStyleSheet("QScrollArea{background:#111214;border:none;}")
        self._sa.horizontalScrollBar().setStyleSheet(
            "QScrollBar:horizontal{height:6px;background:#1a1d1f;}"
            "QScrollBar::handle:horizontal{background:#3c4045;border-radius:3px;}")
        self._sa.verticalScrollBar().setStyleSheet(
            "QScrollBar:vertical{width:6px;background:#1a1d1f;}"
            "QScrollBar::handle:vertical{background:#3c4045;border-radius:3px;}")

        # Zoom info label overlay
        self._zoom_lbl = QLabel("100%", self)
        self._zoom_lbl.setStyleSheet(
            "background:rgba(0,0,0,160);color:#eff0f1;"
            "border-radius:4px;padding:2px 7px;font-size:8pt;")
        self._zoom_lbl.hide()
        self._zoom_timer = QTimer(singleShot=True)
        self._zoom_timer.timeout.connect(self._zoom_lbl.hide)

        # Zoom buttons bar
        btn_bar = QWidget()
        bl = QHBoxLayout(btn_bar); bl.setContentsMargins(0,4,0,4); bl.setSpacing(4)
        bl.addStretch()
        for label, fn in [("−", self._zoom_out), ("Fit", self._zoom_fit),
                          ("1:1", self._zoom_actual), ("+", self._zoom_in)]:
            b = QPushButton(label)
            b.setFixedHeight(22); b.setFixedWidth(36)
            b.setStyleSheet("QPushButton{background:#2a2e32;border:1px solid #3d4045;"
                            "border-radius:3px;color:#eff0f1;font-size:8pt;}"
                            "QPushButton:hover{background:#3daee9;}")
            b.clicked.connect(fn); bl.addWidget(b)
        bl.addStretch()
        btn_bar.setStyleSheet("background:#1a1d1f;")

        vl = QVBoxLayout(self); vl.setContentsMargins(0,0,0,0); vl.setSpacing(0)
        vl.addWidget(self._sa, 1)
        vl.addWidget(btn_bar)

        self._sa.viewport().installEventFilter(self)

    def load(self, path: str):
        self._pix_orig = QPixmap(path)
        if self._pix_orig.isNull():
            # Try SVG
            from PyQt6.QtSvg import QSvgRenderer
            r = QSvgRenderer(path)
            if r.isValid():
                self._pix_orig = QPixmap(512, 512)
                self._pix_orig.fill(Qt.GlobalColor.transparent)
                p = QPainter(self._pix_orig); r.render(p); p.end()
        self._zoom = 1.0
        self.zoom_fit()
        self._apply()

    def zoom_fit(self):
        if not self._pix_orig: return
        vp = self._sa.viewport().size()
        pw, ph = self._pix_orig.width(), self._pix_orig.height()
        if pw <= 0 or ph <= 0: return
        self._zoom = min(vp.width()/pw, vp.height()/ph, 1.0)

    def _zoom_fit(self):    self.zoom_fit(); self._apply()
    def _zoom_actual(self): self._zoom = 1.0; self._apply()
    def _zoom_in(self):     self._zoom = min(self._zoom * 1.25, 16.0); self._apply()
    def _zoom_out(self):    self._zoom = max(self._zoom / 1.25, 0.05); self._apply()

    def _apply(self):
        if not self._pix_orig: return
        w = max(1, int(self._pix_orig.width()  * self._zoom))
        h = max(1, int(self._pix_orig.height() * self._zoom))
        scaled = self._pix_orig.scaled(w, h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self._label.setPixmap(scaled)
        self._label.setFixedSize(scaled.size())
        self._zoom_lbl.setText(f"{self._zoom*100:.0f}%")
        self._zoom_lbl.adjustSize()
        self._zoom_lbl.move(8, 8)
        self._zoom_lbl.show()
        self._zoom_timer.start(1200)

    def eventFilter(self, obj, e):
        from PyQt6.QtCore import QEvent
        if obj is self._sa.viewport():
            if e.type() == QEvent.Type.Wheel:
                factor = 1.15 if e.angleDelta().y() > 0 else 1/1.15
                self._zoom = max(0.05, min(self._zoom * factor, 16.0))
                self._apply(); return True
            if e.type() == QEvent.Type.MouseButtonPress and \
               e.button() == Qt.MouseButton.LeftButton:
                self._drag_start = e.pos()
                hb, vb = self._sa.horizontalScrollBar(), self._sa.verticalScrollBar()
                self._scroll_start = (hb.value(), vb.value())
                self._sa.viewport().setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))
                return True
            if e.type() == QEvent.Type.MouseMove and self._drag_start:
                delta = e.pos() - self._drag_start
                hb, vb = self._sa.horizontalScrollBar(), self._sa.verticalScrollBar()
                hb.setValue(self._scroll_start[0] - delta.x())
                vb.setValue(self._scroll_start[1] - delta.y())
                return True
            if e.type() == QEvent.Type.MouseButtonRelease:
                self._drag_start = None
                self._sa.viewport().setCursor(QCursor(Qt.CursorShape.ArrowCursor))
                return True
        return super().eventFilter(obj, e)


class _MediaControls(QWidget):
    """Shared play/pause/seek/volume controls for audio and video."""
    def __init__(self, player: "QMediaPlayer", audio_out: "QAudioOutput"):
        super().__init__()
        from PyQt6.QtWidgets import QSlider
        self._player = player
        self._audio  = audio_out
        self._seeking = False

        self.setStyleSheet("background:#1a1d1f;")
        vl = QVBoxLayout(self); vl.setContentsMargins(10,6,10,8); vl.setSpacing(4)

        # Seek row
        seek_row = QHBoxLayout(); seek_row.setSpacing(8)
        self._pos_lbl  = QLabel("0:00"); self._pos_lbl.setStyleSheet("color:#8a9099;font-size:8pt;")
        self._dur_lbl  = QLabel("0:00"); self._dur_lbl.setStyleSheet("color:#8a9099;font-size:8pt;")
        self._seek_sl  = QSlider(Qt.Orientation.Horizontal)
        self._seek_sl.setRange(0, 0)
        self._seek_sl.setStyleSheet(
            "QSlider::groove:horizontal{height:4px;background:#3d4045;border-radius:2px;}"
            "QSlider::handle:horizontal{width:12px;height:12px;margin:-4px 0;"
            "background:#3daee9;border-radius:6px;}"
            "QSlider::sub-page:horizontal{background:#3daee9;border-radius:2px;}")
        seek_row.addWidget(self._pos_lbl)
        seek_row.addWidget(self._seek_sl, 1)
        seek_row.addWidget(self._dur_lbl)

        # Button + volume row
        btn_row = QHBoxLayout(); btn_row.setSpacing(6)
        self._btn_play = QPushButton("▶")
        self._btn_play.setFixedSize(36, 36)
        self._btn_play.setStyleSheet(
            "QPushButton{background:#3daee9;border:none;border-radius:18px;"
            "color:#fff;font-size:14pt;}"
            "QPushButton:hover{background:#52c0f0;}")

        vol_lbl = QLabel("🔊"); vol_lbl.setStyleSheet("color:#8a9099;")
        self._vol_sl = QSlider(Qt.Orientation.Horizontal)
        self._vol_sl.setRange(0, 100); self._vol_sl.setValue(80)
        self._vol_sl.setFixedWidth(90)
        self._vol_sl.setStyleSheet(
            "QSlider::groove:horizontal{height:4px;background:#3d4045;border-radius:2px;}"
            "QSlider::handle:horizontal{width:10px;height:10px;margin:-3px 0;"
            "background:#eff0f1;border-radius:5px;}"
            "QSlider::sub-page:horizontal{background:#eff0f1;border-radius:2px;}")

        btn_row.addStretch()
        btn_row.addWidget(self._btn_play)
        btn_row.addStretch()
        btn_row.addWidget(vol_lbl)
        btn_row.addWidget(self._vol_sl)

        vl.addLayout(seek_row)
        vl.addLayout(btn_row)

        # Connections
        self._btn_play.clicked.connect(self._toggle)
        self._seek_sl.sliderPressed.connect(lambda: setattr(self, '_seeking', True))
        self._seek_sl.sliderReleased.connect(self._do_seek)
        self._vol_sl.valueChanged.connect(
            lambda v: audio_out.setVolume(v / 100))
        player.positionChanged.connect(self._on_pos)
        player.durationChanged.connect(self._on_dur)
        player.playbackStateChanged.connect(self._on_state)
        audio_out.setVolume(0.8)

    def _toggle(self):
        from PyQt6.QtMultimedia import QMediaPlayer
        if self._player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self._player.pause()
        else:
            self._player.play()

    def _do_seek(self):
        self._seeking = False
        self._player.setPosition(self._seek_sl.value())

    def _on_pos(self, ms: int):
        if not self._seeking:
            self._seek_sl.setValue(ms)
        self._pos_lbl.setText(_fmt_time(ms))

    def _on_dur(self, ms: int):
        self._seek_sl.setRange(0, ms)
        self._dur_lbl.setText(_fmt_time(ms))

    def _on_state(self, state):
        from PyQt6.QtMultimedia import QMediaPlayer
        self._btn_play.setText("⏸" if state == QMediaPlayer.PlaybackState.PlayingState else "▶")

    def stop(self):
        try: self._player.stop()
        except Exception: pass


class GlimpseSpeedy(QWidget):
    """
    GlimpseSpeedy — Quick-look preview panel
    Space = open/close  |  Esc = close  |  ←/→ = prev/next file
    """
    closed = pyqtSignal()

    _TITLE_H = 38
    _STATUS_H = 26

    def __init__(self, parent=None):
        super().__init__(parent, Qt.WindowType.Window |
                         Qt.WindowType.FramelessWindowHint |
                         Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("GlimpseSpeedy{background:#1a1d1f;border:1px solid #3d4045;"
                           "border-radius:8px;}")

        self._files: list[str] = []
        self._idx   = 0
        self._drag_pos = None
        self._player = None
        self._audio_out = None
        self._media_controls = None

        self._build_ui()

    # ── Build UI ─────────────────────────────────────────────────────────────
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(1, 1, 1, 1)
        root.setSpacing(0)

        # ── Title bar ──
        self._title_bar = QWidget()
        self._title_bar.setFixedHeight(self._TITLE_H)
        self._title_bar.setStyleSheet("background:#232629;border-radius:7px 7px 0 0;")
        tl = QHBoxLayout(self._title_bar)
        tl.setContentsMargins(10, 0, 8, 0); tl.setSpacing(6)

        self._btn_prev = QPushButton("‹")
        self._btn_next = QPushButton("›")
        for b in (self._btn_prev, self._btn_next):
            b.setFixedSize(26, 26)
            b.setStyleSheet("QPushButton{background:#2a2e32;border:1px solid #3d4045;"
                            "border-radius:13px;color:#eff0f1;font-size:14pt;}"
                            "QPushButton:hover{background:#3daee9;border-color:#3daee9;}"
                            "QPushButton:disabled{color:#4d5257;}")
        self._btn_prev.clicked.connect(self._prev)
        self._btn_next.clicked.connect(self._next)

        self._title_lbl = QLabel("GlimpseSpeedy")
        self._title_lbl.setStyleSheet("color:#eff0f1;font-weight:600;font-size:9pt;")
        self._title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self._idx_lbl = QLabel("")
        self._idx_lbl.setStyleSheet("color:#6b737c;font-size:8pt;")

        btn_close = QPushButton("✕")
        btn_close.setFixedSize(26, 26)
        btn_close.setStyleSheet("QPushButton{background:#2a2e32;border:1px solid #3d4045;"
                                "border-radius:13px;color:#c0392b;font-size:10pt;}"
                                "QPushButton:hover{background:#c0392b;color:#fff;}")
        btn_close.clicked.connect(self.close_preview)

        tl.addWidget(self._btn_prev)
        tl.addWidget(self._btn_next)
        tl.addSpacing(4)
        tl.addWidget(self._title_lbl, 1)
        tl.addWidget(self._idx_lbl)
        tl.addSpacing(4)
        tl.addWidget(btn_close)
        root.addWidget(self._title_bar)

        # ── Content stack ──
        self._stack = QStackedWidget()
        self._stack.setStyleSheet("background:#111214;")
        root.addWidget(self._stack, 1)

        # Page 0: Image
        self._img_view = _ImageView()
        self._stack.addWidget(self._img_view)

        # Page 1: Text
        self._txt_view = QPlainTextEdit()
        self._txt_view.setReadOnly(True)
        self._txt_view.setFont(QFont("Consolas,Courier New,monospace", 9))
        self._txt_view.setStyleSheet(
            "QPlainTextEdit{background:#111214;color:#eff0f1;border:none;"
            "selection-background-color:#3daee9;padding:8px;}"
            "QScrollBar:vertical{width:7px;background:#1a1d1f;}"
            "QScrollBar::handle:vertical{background:#3c4045;border-radius:3px;}")
        self._stack.addWidget(self._txt_view)

        # Page 2: Video (built lazily when first needed)
        self._video_page = QWidget()
        self._video_page.setStyleSheet("background:#000;")
        self._vp_layout = QVBoxLayout(self._video_page)
        self._vp_layout.setContentsMargins(0, 0, 0, 0); self._vp_layout.setSpacing(0)
        self._video_widget = None
        self._stack.addWidget(self._video_page)

        # Page 3: Audio
        self._audio_page = QWidget()
        self._audio_page.setStyleSheet("background:#111214;")
        al = QVBoxLayout(self._audio_page)
        al.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._audio_icon = QLabel("🎵")
        self._audio_icon.setStyleSheet("font-size:64pt;")
        self._audio_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._audio_meta = QLabel()
        self._audio_meta.setStyleSheet("color:#eff0f1;font-size:10pt;")
        self._audio_meta.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._audio_meta.setWordWrap(True)
        al.addStretch()
        al.addWidget(self._audio_icon)
        al.addWidget(self._audio_meta)
        al.addStretch()
        # controls injected later
        self._audio_ctrl_slot = al
        self._stack.addWidget(self._audio_page)

        # Page 4: Info / fallback
        self._info_page = QWidget()
        self._info_page.setStyleSheet("background:#111214;")
        il = QVBoxLayout(self._info_page)
        il.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._info_icon = QLabel("📄")
        self._info_icon.setStyleSheet("font-size:64pt;")
        self._info_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._info_lbl = QLabel()
        self._info_lbl.setStyleSheet("color:#eff0f1;font-size:10pt;line-height:1.6;")
        self._info_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._info_lbl.setWordWrap(True)
        btn_open = QPushButton("Open with system default")
        btn_open.setStyleSheet("QPushButton{background:#3daee9;border:none;border-radius:4px;"
                               "color:#fff;padding:6px 18px;}"
                               "QPushButton:hover{background:#52c0f0;}")
        btn_open.clicked.connect(self._open_externally)
        il.addStretch()
        il.addWidget(self._info_icon)
        il.addWidget(self._info_lbl)
        il.addSpacing(16)
        il.addWidget(btn_open, alignment=Qt.AlignmentFlag.AlignHCenter)
        il.addStretch()
        self._stack.addWidget(self._info_page)

        # ── Status bar ──
        self._status_bar = QWidget()
        self._status_bar.setFixedHeight(self._STATUS_H)
        self._status_bar.setStyleSheet("background:#141618;border-radius:0 0 7px 7px;")
        sl = QHBoxLayout(self._status_bar)
        sl.setContentsMargins(12, 0, 12, 0)
        self._status_lbl = QLabel()
        self._status_lbl.setStyleSheet("color:#6b737c;font-size:8pt;")
        sl.addWidget(self._status_lbl)
        sl.addStretch()
        hint = QLabel("Space/Esc close  ·  ←/→ navigate  ·  scroll to zoom")
        hint.setStyleSheet("color:#4d5257;font-size:7.5pt;")
        sl.addWidget(hint)
        root.addWidget(self._status_bar)

    # ── Public API ───────────────────────────────────────────────────────────
    def show_files(self, files: list[str], start_idx: int = 0):
        """Open the preview for `files[start_idx]`."""
        self._stop_media()
        self._files = files
        self._idx   = max(0, min(start_idx, len(files)-1))
        self._load_current()
        if not self.isVisible():
            self._size_to_screen()
            self.show()
        self.raise_()
        self.activateWindow()

    def close_preview(self):
        self._stop_media()
        self.hide()
        self.closed.emit()

    # ── Navigation ───────────────────────────────────────────────────────────
    def _prev(self):
        if self._idx > 0:
            self._idx -= 1; self._load_current()
    def _next(self):
        if self._idx < len(self._files)-1:
            self._idx += 1; self._load_current()

    # ── Load ─────────────────────────────────────────────────────────────────
    def _load_current(self):
        if not self._files: return
        self._stop_media()
        path = self._files[self._idx]
        p    = Path(path)
        ext  = p.suffix.lower()

        self._title_lbl.setText(p.name)
        n = len(self._files)
        self._idx_lbl.setText(f"{self._idx+1}/{n}" if n > 1 else "")
        self._btn_prev.setEnabled(self._idx > 0)
        self._btn_next.setEnabled(self._idx < n-1)

        # Status bar
        try:
            sz = os.path.getsize(path)
            mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M")
            self._status_lbl.setText(f"{_fmt_size(sz)}  ·  {mtime}  ·  {path}")
        except Exception:
            self._status_lbl.setText(path)

        if ext in _GS_IMAGE:
            self._show_image(path)
        elif ext in _GS_TEXT or self._sniff_text(path):
            self._show_text(path)
        elif ext in _GS_VIDEO and _HAS_MEDIA:
            self._show_video(path)
        elif ext in _GS_AUDIO and _HAS_MEDIA:
            self._show_audio(path)
        else:
            self._show_info(path, ext)

    def _show_image(self, path):
        self._stack.setCurrentIndex(0)
        self._img_view.load(path)

    def _show_text(self, path):
        self._stack.setCurrentIndex(1)
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read(256_000)
            if len(content) == 256_000:
                content += "\n\n[…file truncated at 256 KB…]"
            self._txt_view.setPlainText(content)
            # Scroll to top without needing QTextCursor imported
            sb = self._txt_view.verticalScrollBar()
            if sb:
                sb.setValue(0)
        except Exception as e:
            self._txt_view.setPlainText(f"Could not read file:\n{e}")

    def _show_video(self, path):
        self._stack.setCurrentIndex(2)
        self._ensure_player()
        if self._video_widget is None:
            self._video_widget = QVideoWidget()
            self._video_widget.setStyleSheet("background:#000;")
            self._vp_layout.addWidget(self._video_widget, 1)
            self._player.setVideoOutput(self._video_widget)
            mc = _MediaControls(self._player, self._audio_out)
            self._vp_layout.addWidget(mc)
            self._media_controls = mc
        self._player.setSource(QUrl.fromLocalFile(path))
        self._player.play()

    def _show_audio(self, path):
        self._stack.setCurrentIndex(3)
        self._ensure_player()
        # Inject controls once
        if self._media_controls is None or \
           not isinstance(self._media_controls.parent(), type(self._audio_page)):
            if self._media_controls is not None:
                self._media_controls.setParent(None)
            mc = _MediaControls(self._player, self._audio_out)
            self._audio_ctrl_slot.addWidget(mc)
            self._media_controls = mc
        # Metadata
        name = Path(path).stem
        meta_txt = name
        try:
            import mutagen
            tags = mutagen.File(path, easy=True)
            if tags:
                t = tags.get('title',  [name])[0]
                a = tags.get('artist', [''])[0]
                al = tags.get('album',  [''])[0]
                meta_txt = t
                if a:  meta_txt += f"\n{a}"
                if al: meta_txt += f"\n{al}"
        except Exception:
            pass
        self._audio_meta.setText(meta_txt)
        self._player.setSource(QUrl.fromLocalFile(path))
        self._player.play()

    def _show_info(self, path, ext):
        self._stack.setCurrentIndex(4)
        icons = {'.pdf':'📄','.zip':'🗜','.7z':'🗜','.rar':'🗜',
                 '.exe':'⚙','.msi':'⚙','.dll':'⚙',
                 '.doc':'📝','.docx':'📝','.xls':'📊','.xlsx':'📊',
                 '.ppt':'📑','.pptx':'📑','.db':'🗃','.sqlite':'🗃',
                 '.iso':'💿','.img':'💿','.dmg':'💿','.ttf':'🔤','.otf':'🔤'}
        self._info_icon.setText(icons.get(ext, '📄'))
        try:
            sz   = os.path.getsize(path)
            mime, _ = mimetypes.guess_type(path)
            info = (f"<b>{Path(path).name}</b><br><br>"
                    f"Size: {_fmt_size(sz)}<br>"
                    f"Type: {mime or ext or 'Unknown'}<br>"
                    f"Modified: {datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M')}")
            if not _HAS_MEDIA and ext in (_GS_AUDIO | _GS_VIDEO):
                info += "<br><br><i>Install PyQt6-Qt6-Multimedia<br>for audio/video preview</i>"
            self._info_lbl.setText(info)
        except Exception as e:
            self._info_lbl.setText(str(e))

    # ── Helpers ──────────────────────────────────────────────────────────────
    def _ensure_player(self):
        if self._player is None:
            self._player    = QMediaPlayer(self)
            self._audio_out = QAudioOutput(self)
            self._player.setAudioOutput(self._audio_out)

    def _stop_media(self):
        if self._player:
            try: self._player.stop()
            except Exception: pass

    def _open_externally(self):
        if self._files:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self._files[self._idx]))

    @staticmethod
    def _sniff_text(path: str) -> bool:
        """Return True if the first 512 bytes look like UTF-8 text."""
        try:
            with open(path, 'rb') as f:
                chunk = f.read(512)
            chunk.decode('utf-8')
            return b'\x00' not in chunk
        except Exception:
            return False

    def _size_to_screen(self):
        screen = QApplication.primaryScreen().availableGeometry()
        w = int(screen.width()  * 0.78)
        h = int(screen.height() * 0.82)
        self.resize(w, h)
        self.move(screen.center() - self.rect().center())

    # ── Frameless window drag ────────────────────────────────────────────────
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and \
           self._title_bar.geometry().contains(e.pos()):
            self._drag_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if e.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(e.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, e):
        self._drag_pos = None

    # ── Keyboard ─────────────────────────────────────────────────────────────
    def keyPressEvent(self, e):
        k = e.key()
        if k in (Qt.Key.Key_Escape, Qt.Key.Key_Space): self.close_preview()
        elif k == Qt.Key.Key_Left:  self._prev()
        elif k == Qt.Key.Key_Right: self._next()
        else: super().keyPressEvent(e)

    def paintEvent(self, e):
        # Rounded-corner background
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        path = QPainterPath()
        r = self.rect().adjusted(0, 0, -1, -1)
        path.addRoundedRect(r.x(), r.y(), r.width(), r.height(), 8, 8)
        p.fillPath(path, QColor("#1a1d1f"))
        p.setPen(QColor("#3d4045"))
        p.drawPath(path)
        p.end()

# ──────────────────────────────────────────────────────────────────────────────
#  SIDEBAR CAPACITY DELEGATE + EJECT BUTTON
# ──────────────────────────────────────────────────────────────────────────────
class SidebarRowDelegate(QStyledItemDelegate):
    EJECT_HIT = 28   # generous clickable width on the right edge

    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        usage_data = index.data(Qt.ItemDataRole.UserRole + 1)
        if usage_data and isinstance(usage_data, dict):
            pct = usage_data.get("percentage", 0)
            painter.save()
            text_rect = option.rect
            bar_height = 5
            bar_width = 120
            x = text_rect.left() + 26
            y = text_rect.bottom() - bar_height - 6
            painter.setPen(Qt.PenStyle.NoPen)
            is_selected = option.state & QStyle.StateFlag.State_Selected
            painter.setBrush(QColor("#3a3a3a" if is_selected else "#dcdcdc"))
            painter.drawRoundedRect(x, y, bar_width, bar_height, 2, 2)
            accent = QColor("#2ecc71" if pct < 85 else "#e74c3c")
            painter.setBrush(accent)
            painter.drawRoundedRect(x, y, int(bar_width * (pct / 100.0)), bar_height, 2, 2)
            painter.restore()

        # Eject button for removable drives
        is_removable = index.data(Qt.ItemDataRole.UserRole + 2)
        if is_removable:
            eject_ic = _local_icon("eject button")
            if eject_ic and not eject_ic.isNull():
                painter.save()
                sz = 16
                x = option.rect.right() - sz - 4
                y = option.rect.top() + (option.rect.height() - sz) // 2
                eject_ic.paint(painter, x, y, sz, sz)
                painter.restore()

    def sizeHint(self, option, index):
        hint = super().sizeHint(option, index)
        usage_data = index.data(Qt.ItemDataRole.UserRole + 1)
        if usage_data:
            hint.setHeight(hint.height() + 14)
        return hint

class Sidebar(QTreeWidget):
    navigate = pyqtSignal(str)
    eject_requested = pyqtSignal(str)

    _PLACES = [
        ("Places", [
            ("Home",      str(Path.home()),                 "place-home",    False),
            ("Desktop",   str(Path.home()/"Desktop"),       "place-desktop", False),
            ("Documents", str(Path.home()/"Documents"),     "place-docs",    False),
            ("Downloads", str(Path.home()/"Downloads"),     "place-dl",      False),
            ("Music",     str(Path.home()/"Music"),         "place-music",   False),
            ("Pictures",  str(Path.home()/"Pictures"),      "place-pics",    False),
            ("Videos",    str(Path.home()/"Videos"),        "place-videos",  False),
            ("Trash",     str(Path.home()/".local/share/Trash") if sys.platform != "win32"
                          else str(Path.home()/"$RECYCLE.BIN"), "place-trash", False),
        ]),
        ("Network", [
            ("Network",   "//",                             "place-network", False),
        ]),
        ("Devices", []),
    ]

    def __init__(self):
        super().__init__()
        self.setObjectName("sidebar")
        self.setHeaderHidden(True)
        self.setIndentation(0)
        self.setIconSize(QSize(18, 18))
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setAnimated(True)
        self.setItemDelegate(SidebarRowDelegate())
        self._build()
        self.itemClicked.connect(self._clicked)

        # Live drive rescan every 22 seconds
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._rescan_devices)
        self._timer.start(2000)
        self._last_devs: set[str] = set()

    # ── Device enumeration ──
    @staticmethod
    def _enum_devices() -> list[tuple[str, str, str, bool]]:
        """Return list of (label, path, icon_key, is_removable) for current drives."""
        devs = []
        if sys.platform == "win32":
            import ctypes
            DRIVE_REMOVABLE = 2
            DRIVE_CDROM     = 5
            for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                p = f"{letter}:\\"
                if os.path.exists(p):
                    dt = ctypes.windll.kernel32.GetDriveTypeW(p)
                    is_removable = dt in (DRIVE_REMOVABLE, DRIVE_CDROM)
                    devs.append((f"Local Disk ({letter}:)", p, "place-drive", is_removable))
        else:
            devs.append(("Root System", "/", "place-drive", False))
            try:
                with open("/proc/mounts", "r", encoding="utf-8") as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 2:
                            mnt = parts[1]
                            if mnt != "/" and os.path.ismount(mnt):
                                if any(mnt.startswith(pre) for pre in ("/media", "/run/media", "/mnt")):
                                    devs.append((Path(mnt).name or mnt, mnt, "place-drive", True))
            except Exception:
                pass
        return devs

    def _build(self):
        defs = [list(row) for row in self._PLACES]
        defs[2][1] = self._enum_devices()
        self._last_devs = {d[1] for d in defs[2][1]}

        for section, items in defs:
            grp = QTreeWidgetItem([f"  {section}"])
            grp.setFlags(Qt.ItemFlag.ItemIsEnabled)
            f = grp.font(0); f.setPointSize(7); f.setBold(True); grp.setFont(0, f)
            grp.setForeground(0, QColor("#6b737c"))
            self.addTopLevelItem(grp)
            grp.setExpanded(True)
            for entry in items:
                label, path, icon_key = entry[0], entry[1], entry[2]
                is_removable = entry[3] if len(entry) > 3 else False
                if not os.path.exists(path) and path not in ("//",):
                    continue
                it = QTreeWidgetItem([f"  {label}"])
                it.setData(0, Qt.ItemDataRole.UserRole, path)
                it.setData(0, Qt.ItemDataRole.UserRole + 2, is_removable)
                if icon_key == "place-drive":
                    try:
                        total, used, free = shutil.disk_usage(path)
                        pct = int((used / total) * 100)
                        it.setData(0, Qt.ItemDataRole.UserRole + 1, {"percentage": pct})
                    except Exception:
                        pass
                alias = _PLACE_ALIASES.get(icon_key, icon_key)
                ic = _local_icon(alias) or ICONS.get(icon_key)
                if not ic.isNull(): it.setIcon(0, ic)
                grp.addChild(it)

    def _rescan_devices(self):
        current = self._enum_devices()
        current_set = {d[1] for d in current}
        if current_set == self._last_devs:
            return
        self._last_devs = current_set

        # Find the Devices group (last top-level item)
        root = self.invisibleRootItem()
        devices_grp = None
        for g in range(root.childCount()):
            grp = root.child(g)
            text = grp.text(0).strip().lower()
            if text == "devices":
                devices_grp = grp
                break

        if devices_grp is None:
            return

        # Remember selection
        sel_path = None
        sel = self.currentItem()
        if sel:
            sel_path = sel.data(0, Qt.ItemDataRole.UserRole)

        # Clear old children
        while devices_grp.childCount():
            devices_grp.takeChild(0)

        # Rebuild
        for label, path, icon_key, is_removable in current:
            if not os.path.exists(path) and path not in ("//",):
                continue
            it = QTreeWidgetItem([f"  {label}"])
            it.setData(0, Qt.ItemDataRole.UserRole, path)
            it.setData(0, Qt.ItemDataRole.UserRole + 2, is_removable)
            try:
                total, used, free = shutil.disk_usage(path)
                pct = int((used / total) * 100)
                it.setData(0, Qt.ItemDataRole.UserRole + 1, {"percentage": pct})
            except Exception:
                pass
            alias = _PLACE_ALIASES.get(icon_key, icon_key)
            ic = _local_icon(alias) or ICONS.get(icon_key)
            if not ic.isNull(): it.setIcon(0, ic)
            devices_grp.addChild(it)

        # Restore selection if still present
        if sel_path:
            self._mark(self.invisibleRootItem(), sel_path)

    def refresh_icons(self):
        root = self.invisibleRootItem()
        for g in range(root.childCount()):
            grp = root.child(g)
            for i in range(grp.childCount()):
                it = grp.child(i)
                path = it.data(0, Qt.ItemDataRole.UserRole)
                if not path: continue
                p = Path(path)
                if p == Path.home():              k = "place-home"
                elif p.name.lower() == "desktop": k = "place-desktop"
                elif p.name.lower() == "documents": k = "place-docs"
                elif p.name.lower() == "downloads": k = "place-dl"
                elif p.name.lower() == "music":   k = "place-music"
                elif p.name.lower() == "pictures":k = "place-pics"
                elif p.name.lower() == "videos":  k = "place-videos"
                elif p.name.lower() in ("trash",".local"): k = "place-trash"
                elif path == "//":                k = "place-network"
                else:                             k = "place-drive"
                alias = _PLACE_ALIASES.get(k, k)
                ic = _local_icon(alias) or ICONS.get(k)
                if not ic.isNull(): it.setIcon(0, ic)

    def _clicked(self, item, _):
        path = item.data(0, Qt.ItemDataRole.UserRole)
        if path and path != "//" and os.path.isdir(path):
            self.navigate.emit(path)

    def mark(self, path):
        self._mark(self.invisibleRootItem(), path)

    def _mark(self, node, path):
        for i in range(node.childCount()):
            ch = node.child(i)
            if ch.data(0, Qt.ItemDataRole.UserRole) == path:
                self.setCurrentItem(ch)
            self._mark(ch, path)

    def mousePressEvent(self, event):
        # Map to viewport coordinates for reliable hit-testing
        vp_pos = self.viewport().mapFromParent(event.pos())
        idx = self.indexAt(vp_pos)
        if idx.isValid():
            is_removable = idx.data(Qt.ItemDataRole.UserRole + 2)
            if is_removable:
                rect = self.visualRect(idx)
                # Icon is painted at rect.right() - 20, width 16  →  hit zone right-28..right
                if vp_pos.x() >= rect.right() - SidebarRowDelegate.EJECT_HIT:
                    path = idx.data(Qt.ItemDataRole.UserRole)
                    if path:
                        self.eject_requested.emit(path)
                    return
        super().mousePressEvent(event)

# ──────────────────────────────────────────────────────────────────────────────
#  BREADCRUMB BAR
# ──────────────────────────────────────────────────────────────────────────────
class BreadcrumbBar(QWidget):
    navigate = pyqtSignal(str)
    def __init__(self):
        super().__init__()
        self._lay = QHBoxLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setSpacing(0)
        self._lay.addStretch()

    def set_path(self, path: str):
        while self._lay.count() > 1:
            w = self._lay.takeAt(0).widget()
            if w: w.deleteLater()
        parts = Path(path).parts
        cum = ""
        for i, part in enumerate(parts):
            cum = part if (sys.platform == "win32" and i == 0) else \
                  ("/" if part == "/" else os.path.join(cum, part))
            t = cum
            btn = QPushButton(part)
            btn.setObjectName("crumb")
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            btn.clicked.connect(lambda _, p=t: self.navigate.emit(p))
            self._lay.insertWidget(self._lay.count()-1, btn)
            if i < len(parts)-1:
                sep = QLabel("›"); sep.setObjectName("crumbSep")
                self._lay.insertWidget(self._lay.count()-1, sep)

# ──────────────────────────────────────────────────────────────────────────────
#  BREEZE DARK — PALETTE + STYLESHEET
#  Applied at QApplication level so it wins over OS light/dark mode,
#  QDialog/QMessageBox/QInputDialog backgrounds, scrollbars, tooltips, etc.
# ──────────────────────────────────────────────────────────────────────────────
def _breeze_dark_palette() -> QPalette:
    C = QColor
    p = QPalette()
    # Active state
    sets = [
        (QPalette.ColorRole.Window,          "#232629"),
        (QPalette.ColorRole.WindowText,      "#eff0f1"),
        (QPalette.ColorRole.Base,            "#1b1e20"),
        (QPalette.ColorRole.AlternateBase,   "#232629"),
        (QPalette.ColorRole.Text,            "#eff0f1"),
        (QPalette.ColorRole.BrightText,      "#ffffff"),
        (QPalette.ColorRole.Button,          "#2a2e32"),
        (QPalette.ColorRole.ButtonText,      "#eff0f1"),
        (QPalette.ColorRole.Highlight,       "#3daee9"),
        (QPalette.ColorRole.HighlightedText, "#ffffff"),
        (QPalette.ColorRole.Link,            "#3daee9"),
        (QPalette.ColorRole.LinkVisited,     "#7f8c8d"),
        (QPalette.ColorRole.ToolTipBase,     "#2a2e32"),
        (QPalette.ColorRole.ToolTipText,     "#eff0f1"),
        (QPalette.ColorRole.PlaceholderText, "#6b737c"),
        (QPalette.ColorRole.Mid,             "#3d4045"),
        (QPalette.ColorRole.Midlight,        "#2a2e32"),
        (QPalette.ColorRole.Dark,            "#18191a"),
        (QPalette.ColorRole.Shadow,          "#0d0e0f"),
    ]
    for role, hex_ in sets:
        for group in (QPalette.ColorGroup.Active,
                      QPalette.ColorGroup.Inactive):
            p.setColor(group, role, C(hex_))
    # Disabled state (muted)
    disabled = [
        (QPalette.ColorRole.Window,     "#232629"),
        (QPalette.ColorRole.WindowText, "#6b737c"),
        (QPalette.ColorRole.Text,       "#6b737c"),
        (QPalette.ColorRole.ButtonText, "#6b737c"),
        (QPalette.ColorRole.Base,       "#1b1e20"),
        (QPalette.ColorRole.Button,     "#252829"),
        (QPalette.ColorRole.Highlight,  "#2a2e32"),
        (QPalette.ColorRole.HighlightedText, "#6b737c"),
    ]
    for role, hex_ in disabled:
        p.setColor(QPalette.ColorGroup.Disabled, role, C(hex_))
    return p

BREEZE_DARK_QSS = """
* { font-family:"Noto Sans","Segoe UI",sans-serif; font-size:9pt; }
QMainWindow, QWidget { background:#232629; color:#eff0f1; }
QDialog { background:#232629; color:#eff0f1; }
/* ── Toolbar ── */
QToolBar {
    background:#2a2e32; border:none;
    border-bottom:1px solid #141618; padding:2px 4px; spacing:2px;
}
QToolBar QToolButton {
    background:transparent; border:1px solid transparent;
    border-radius:4px; padding:4px; color:#eff0f1;
    min-width:30px; min-height:30px;
}
QToolBar QToolButton:hover   { background:#3daee9; border-color:#3daee9; }
QToolBar QToolButton:pressed { background:#2980b9; }
QToolBar QToolButton:disabled{ color:#4d5257; }
QToolBar::separator { background:#3d4045; width:1px; margin:5px 3px; }
/* ── Nav row ── */
QWidget#navRow { background:#2a2e32; border-bottom:1px solid #141618; }
/* ── Address / search inputs ── */
QLineEdit {
    background:#1b1e20; border:1px solid #3a3f44; border-radius:4px;
    padding:3px 10px; color:#eff0f1;
    selection-background-color:#3daee9; selection-color:#fff;
}
QLineEdit:focus { border-color:#3daee9; }
QLineEdit#searchBar { border-radius:14px; }
QLineEdit[objectName="addrBar"] { border-radius:4px; }
/* ── Sidebar ── */
QTreeWidget#sidebar {
    background:#1f2224; border:none;
    border-right:1px solid #141618; outline:none; padding:2px 0;
}
QTreeWidget#sidebar::item { padding:5px 6px; border-radius:4px; margin:1px 4px; }
QTreeWidget#sidebar::item:selected { background:#3daee9; color:#fff; }
QTreeWidget#sidebar::item:hover:!selected { background:#2a2e32; }
/* ── File views ── */
QListView, QTreeView {
    background:#232629; alternate-background-color:#252829;
    border:none; outline:none;
    selection-background-color:#3daee9; selection-color:#fff;
    show-decoration-selected:1;
}
QListView::item, QTreeView::item { padding:3px; border-radius:4px; }
QListView::item:selected, QTreeView::item:selected { background:#3daee9; color:#fff; }
QListView::item:hover:!selected, QTreeView::item:hover:!selected { background:#2c2f32; }
/* ── Column headers ── */
QHeaderView::section {
    background:#2a2e32; color:#eff0f1; border:none;
    border-right:1px solid #3d4045; border-bottom:1px solid #3d4045;
    padding:4px 8px; font-weight:500;
}
QHeaderView::section:hover { background:#333840; }
/* ── Scrollbars ── */
QScrollBar:vertical   { background:#1e2124; width:9px; border-radius:4px; margin:0; }
QScrollBar::handle:vertical { background:#3c4045; border-radius:4px; min-height:20px; margin:1px; }
QScrollBar::handle:vertical:hover { background:#50575e; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QScrollBar:horizontal { background:#1e2124; height:9px; border-radius:4px; margin:0; }
QScrollBar::handle:horizontal { background:#3c4045; border-radius:4px; min-width:20px; margin:1px; }
QScrollBar::handle:horizontal:hover { background:#50575e; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width:0; }
/* ── Status bar ── */
QStatusBar { background:#1a1d1f; border-top:1px solid #141618; color:#8a9099; font-size:8.5pt; }
QStatusBar::item { border:none; }
/* ── Context / popup menus ── */
QMenu {
    background:#2a2e32; border:1px solid #3d4045;
    border-radius:6px; padding:4px; color:#eff0f1;
}
QMenu::item { padding:5px 28px 5px 10px; border-radius:4px; }
QMenu::item:selected { background:#3daee9; color:#fff; }
QMenu::separator { height:1px; background:#3d4045; margin:3px 6px; }
/* ── Dialogs (QInputDialog, QMessageBox) ── */
QDialogButtonBox QPushButton, QDialog QPushButton {
    background:#2a2e32; border:1px solid #3d4045; border-radius:4px;
    padding:5px 16px; color:#eff0f1; min-width:72px;
}
QDialogButtonBox QPushButton:hover, QDialog QPushButton:hover { background:#3daee9; border-color:#3daee9; }
QDialogButtonBox QPushButton:pressed, QDialog QPushButton:pressed { background:#2980b9; }
QDialogButtonBox QPushButton:default, QDialog QPushButton:default { border-color:#3daee9; }
/* ── Breadcrumb ── */
QPushButton#crumb {
    background:transparent; border:none; color:#eff0f1;
    padding:3px 5px; border-radius:3px; font-size:9pt;
}
QPushButton#crumb:hover { background:#2c3035; color:#3daee9; }
QLabel#crumbSep { color:#4a5058; font-size:10pt; }
/* ── View-mode / misc buttons ── */
QPushButton#modeBtn {
    background:transparent; border:1px solid transparent;
    border-radius:4px; padding:3px; min-width:30px; min-height:30px;
}
QPushButton#modeBtn:hover { background:#2c3035; }
QPushButton#modeBtn[on="1"] { background:#3daee9; border-color:#2d9fd8; }
/* ── Splitter ── */
QSplitter::handle { background:#141618; }
/* ── Tooltips ── */
QToolTip {
    background:#2a2e32; color:#eff0f1;
    border:1px solid #3daee9; border-radius:4px; padding:4px 8px;
}
"""

# ──────────────────────────────────────────────────────────────────────────────
#  MAIN WINDOW
# ──────────────────────────────────────────────────────────────────────────────
class Pylphin(QMainWindow):
    file_picked = pyqtSignal(list)

    def eventFilter(self, obj, event):
        if obj in (self._iv, self._lv, self._dv) and event.type() == QEvent.Type.KeyPress:
            if event.key() == Qt.Key.Key_Space and not event.modifiers():
                self._toggle_glimpse()
                return True
        return super().eventFilter(obj, event)
    
    def __init__(self, picker_mode=False, pick_type="file", extension_filter="*", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pylphin")
        self.resize(1100, 680)
        self._path    = str(Path.home())
        self._hist    = []
        self._hpos    = -1
        self._mode    = "icons"
        self._picker_mode = picker_mode
        self._pick_type = pick_type       # "file" | "files" | "folder"
        self._extension_filter = extension_filter
        self._selected_paths = []

        self._setup_model()
        self._setup_ui()
        # GlimpseSpeedy instance (reused across previews)
        self._glimpse = GlimpseSpeedy()

        self._go(self._path, push=True)
        ICONS.start_download(self._icon_arrived)

    def _setup_model(self):
        self.model = QFileSystemModel()
        self.model.setRootPath("")
        self.model.setFilter(QDir.Filter.AllEntries | QDir.Filter.NoDotAndDotDot | QDir.Filter.Hidden)
        self.model.setIconProvider(BreezeIconProvider())

    def _setup_ui(self):
        c = QWidget(); self.setCentralWidget(c)
        vl = QVBoxLayout(c); vl.setContentsMargins(0,0,0,0); vl.setSpacing(0)

        self._build_toolbar(vl)
        self._build_navrow(vl)

        sp = QSplitter(Qt.Orientation.Horizontal)
        sp.setHandleWidth(1)
        self.sidebar = Sidebar()
        self.sidebar.navigate.connect(lambda p: self._go(p, push=True))
        self.sidebar.eject_requested.connect(self._eject_drive)
        self.sidebar.setFixedWidth(195)
        sp.addWidget(self.sidebar)

        self._stack = QStackedWidget()
        self._build_views()
        sp.addWidget(self._stack)
        sp.setStretchFactor(1, 1)
        vl.addWidget(sp, 1)

        sb = QStatusBar(); sb.setFixedHeight(24)
        self._status = QLabel()
        sb.addWidget(self._status)
        self.setStatusBar(sb)

    def _build_toolbar(self, parent_layout):
        tb = QToolBar(); tb.setMovable(False)
        tb.setIconSize(QSize(20,20))
        tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
        parent_layout.addWidget(tb)
        self._toolbar = tb

        def act(key, tip, fn, sc=None):
            a = QAction(ICONS.get(key), "", self)
            a._key = key; a.setToolTip(tip)
            if sc: a.setShortcut(sc)
            a.triggered.connect(fn)
            return a

        self.a_back  = act("go-previous","Back (Alt+←)",   self._back,   "Alt+Left")
        self.a_fwd   = act("go-next",    "Forward (Alt+→)", self._fwd,    "Alt+Right")
        self.a_up    = act("go-up",      "Up (Alt+↑)",      self._up,     "Alt+Up")
        self.a_ref   = act("view-refresh","Reload (F5)",     self._reload, "F5")
        self.a_home  = act("go-home",    "Home",
                           lambda: self._go(str(Path.home()), push=True))
        self.a_hide  = act("view-hidden","Toggle Hidden",    self._toggle_hidden)
        self.a_mkdir = act("folder-new", "New Folder",       self._mkdir)
        self.a_del   = act("edit-delete","Delete",           self._delete, "Delete")
        self.a_ren   = act("edit-rename","Rename (F2)",      self._rename, "F2")
        self.a_term  = act("terminal",   "Open Terminal Here",self._terminal)
        self._tb_actions = [self.a_back,self.a_fwd,self.a_up,self.a_ref,
                            self.a_home,self.a_hide,self.a_mkdir,
                            self.a_del,self.a_ren,self.a_term]

        for a in [self.a_back,self.a_fwd,self.a_up]: tb.addAction(a)
        tb.addSeparator()
        tb.addAction(self.a_home); tb.addAction(self.a_ref)
        tb.addSeparator()
        tb.addAction(self.a_hide)
        tb.addSeparator()
        tb.addAction(self.a_mkdir); tb.addAction(self.a_ren); tb.addAction(self.a_del)
        tb.addSeparator()
        tb.addAction(self.a_term)
        if self._picker_mode:
            tb.addSeparator()
            self.a_select = QAction(ICONS.get("dialog-ok"), "Select", self)
            self.a_select._key = "dialog-ok"
            self.a_select.setToolTip("Select (Enter)")
            self.a_select.setShortcut("Return")
            self.a_select.triggered.connect(self._confirm_pick)
            self.a_select.setEnabled(self._pick_type == "folder")
            tb.addAction(self.a_select)
            self._tb_actions.append(self.a_select)
        self._upd_nav()

    def _build_navrow(self, parent_layout):
        row = QWidget(); row.setFixedHeight(36)
        row.setObjectName("navRow")
        hl = QHBoxLayout(row); hl.setContentsMargins(6,0,6,0); hl.setSpacing(6)
        parent_layout.addWidget(row)

        self._crumb = BreadcrumbBar()
        self._crumb.navigate.connect(lambda p: self._go(p, push=True))
        hl.addWidget(self._crumb, 1)

        self._addr = QLineEdit(); self._addr.setObjectName("addrBar")
        self._addr.setVisible(False); self._addr.returnPressed.connect(self._addr_go)
        hl.addWidget(self._addr, 1)

        btn_kbd = QPushButton("⌨"); btn_kbd.setObjectName("modeBtn")
        btn_kbd.setToolTip("Edit path"); btn_kbd.setFixedSize(30,30)
        btn_kbd.clicked.connect(self._toggle_addr); hl.addWidget(btn_kbd)
        hl.addSpacing(6)

        self._mbtn = {}
        for key, tip, mode in [
            ("view-icons",   "Icon View",    "icons"),
            ("view-list",    "List View",    "list"),
            ("view-details", "Details View", "details"),
        ]:
            b = QPushButton(); b.setObjectName("modeBtn")
            b.setToolTip(tip); b.setFixedSize(30,30)
            ic = ICONS.get(key)
            if not ic.isNull(): b.setIcon(ic); b.setIconSize(QSize(16,16))
            else: b.setText({"icons":"⊞","list":"☰","details":"≡"}[mode])
            b._key = key; b._mode = mode
            b.clicked.connect(lambda _, m=mode: self._set_mode(m))
            self._mbtn[mode] = b; hl.addWidget(b)
        hl.addSpacing(6)

        self._search = QLineEdit(); self._search.setObjectName("searchBar")
        self._search.setPlaceholderText("Search…"); self._search.setFixedWidth(190)
        self._search.textChanged.connect(self._filter); hl.addWidget(self._search)
        if self._picker_mode:
            self._search.setVisible(False)

    def _build_views(self):
        iv = QListView()
        iv.setViewMode(QListView.ViewMode.IconMode)
        iv.setIconSize(QSize(48,48)); iv.setGridSize(QSize(88,78))
        iv.setResizeMode(QListView.ResizeMode.Adjust)
        iv.setMovement(QListView.Movement.Static); iv.setSpacing(2)
        iv.setModel(self.model)
        iv.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        iv.doubleClicked.connect(self._activate)
        iv.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        iv.customContextMenuRequested.connect(self._ctx)
        self._iv = iv; self._stack.addWidget(iv)

        lv = QListView()
        lv.setViewMode(QListView.ViewMode.ListMode)
        lv.setIconSize(QSize(22,22))
        lv.setModel(self.model)
        lv.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        lv.doubleClicked.connect(self._activate)
        lv.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        lv.customContextMenuRequested.connect(self._ctx)
        self._lv = lv; self._stack.addWidget(lv)

        dv = QTreeView()
        dv.setModel(self.model); dv.setIconSize(QSize(20,20))
        dv.setRootIsDecorated(False); dv.setAlternatingRowColors(True)
        dv.setSortingEnabled(True)
        dv.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        dv.doubleClicked.connect(self._activate)
        dv.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        dv.customContextMenuRequested.connect(self._ctx)
        h = dv.header()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in range(1,4): h.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        self._dv = dv; self._stack.addWidget(dv)

        for v in (self._iv, self._lv, self._dv):
            v.installEventFilter(self)
                
        v.selectionModel().selectionChanged.connect(self._on_selection_changed)

        self._set_mode("icons")

    def _icon_arrived(self, name, path):
        for a in self._tb_actions:
            if getattr(a, "_key", None) == name: a.setIcon(QIcon(path))
        for m, b in self._mbtn.items():
            if getattr(b, "_key", None) == name:
                b.setIcon(QIcon(path)); b.setIconSize(QSize(16,16)); b.setText("")
        self.sidebar.refresh_icons()
        self.model.setIconProvider(BreezeIconProvider())

    def _go(self, path: str, push=False):
        if not os.path.isdir(path): return
        self._path = path
        self.model.setRootPath(path)
        idx = self.model.index(path)
        for v in (self._iv, self._lv, self._dv): v.setRootIndex(idx)
        self._crumb.set_path(path)
        self._addr.setText(path)
        if self._picker_mode:
            self.setWindowTitle(f"Select {self._pick_type.title()} — {Path(path).name or path}")
        else:
            self.setWindowTitle(f"Pylphin — {Path(path).name or path}")
        self.sidebar.mark(path)
        if push:
            self._hist = self._hist[:self._hpos+1]
            self._hist.append(path); self._hpos = len(self._hist)-1
        self._upd_nav(); self._upd_status()
        self._apply_picker_filter()

    def _back(self):
        if self._hpos > 0: self._hpos -= 1; self._go(self._hist[self._hpos])
    def _fwd(self):
        if self._hpos < len(self._hist)-1: self._hpos += 1; self._go(self._hist[self._hpos])
    def _up(self):
        parent = str(Path(self._path).parent)
        if parent != self._path: self._go(parent, push=True)
    def _reload(self): self._go(self._path)
    def _upd_nav(self):
        self.a_back.setEnabled(self._hpos > 0)
        self.a_fwd.setEnabled(self._hpos < len(self._hist)-1)
        self.a_up.setEnabled(str(Path(self._path).parent) != self._path)
    def _activate(self, idx: QModelIndex):
        p = self.model.filePath(idx)
        if os.path.isdir(p):
            self._go(p, push=True)
        else:
            if self._picker_mode and self._pick_type in ("file", "files"):
                self._confirm_pick([p])
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(p))

    def _toggle_addr(self):
        vis = self._addr.isVisible()
        self._addr.setVisible(not vis); self._crumb.setVisible(vis)
        if not vis: self._addr.setFocus(); self._addr.selectAll()
    def _addr_go(self):
        p = self._addr.text().strip()
        if os.path.isdir(p): self._go(p, push=True); self._toggle_addr()
        else:
            self._addr.setStyleSheet("background:#3b1818;border-color:#c0392b;")
            QTimer.singleShot(800, lambda: self._addr.setStyleSheet(""))

    def _set_mode(self, mode):
        self._mode = mode
        self._stack.setCurrentIndex({"icons":0,"list":1,"details":2}[mode])
        for m, b in self._mbtn.items():
            b.setProperty("on", "1" if m == mode else "0")
            b.style().unpolish(b); b.style().polish(b)

    def _toggle_hidden(self):
        f = self.model.filter()
        self.model.setFilter(f & ~QDir.Filter.Hidden if f & QDir.Filter.Hidden
                             else f | QDir.Filter.Hidden)

    def _filter(self, txt):
        if txt: self.model.setNameFilters([f"*{txt}*"]); self.model.setNameFilterDisables(False)
        else: self.model.setNameFilters([])

    def _sel(self):
        v = self._stack.currentWidget()
        return list({self.model.filePath(i)
                     for i in v.selectionModel().selectedIndexes()
                     if i.column() == 0})

    def _mkdir(self):
        name, ok = QInputDialog.getText(self, "New Folder", "Folder name:")
        if ok and name:
            try: os.makedirs(os.path.join(self._path, name), exist_ok=True)
            except Exception as e: QMessageBox.critical(self,"Error",str(e))

    def _delete(self):
        paths = self._sel()
        if not paths: return
        preview = "\n".join(Path(p).name for p in paths[:6])
        if len(paths) > 6: preview += f"\n… +{len(paths)-6} more"
        if QMessageBox.question(self,"Delete",f"Permanently delete?\n\n{preview}",
           QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No
           ) == QMessageBox.StandardButton.Yes:
            for p in paths:
                try: shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
                except Exception as e: QMessageBox.critical(self,"Error",f"{p}:\n{e}")

    def _rename(self):
        paths = self._sel()
        if len(paths) != 1: return
        old = paths[0]
        n, ok = QInputDialog.getText(self,"Rename","New name:",text=Path(old).name)
        if ok and n:
            try: os.rename(old, os.path.join(os.path.dirname(old), n))
            except Exception as e: QMessageBox.critical(self,"Error",str(e))

    def _terminal(self):
        if sys.platform == "win32": subprocess.Popen(["cmd.exe"], cwd=self._path)
        else:
            for t in ["konsole","gnome-terminal","xterm"]:
                if shutil.which(t): subprocess.Popen([t], cwd=self._path); break

    def _eject_drive(self, path: str):
        """Kick off a background eject so the UI never freezes."""
        worker = _EjectWorker(path)
        worker.succeeded.connect(self._on_eject_ok)
        worker.failed.connect(self._on_eject_fail)
        if not hasattr(self, "_eject_workers"):
            self._eject_workers = []
        self._eject_workers.append(worker)
        worker.finished.connect(
            lambda: self._eject_workers.remove(worker)
            if worker in self._eject_workers else None)
        worker.start()

    def _on_eject_ok(self, label: str):
        QMessageBox.information(self, "Drive Ejected",
            f"\u2714  {label}\n\nIt is now safe to remove the drive.")

    def _on_eject_fail(self, label: str, reason: str):
        QMessageBox.critical(self, "Eject Failed",
            f"Could not eject  {label}\n\n{reason}")
    def _ctx(self, pos):
        v = self._stack.currentWidget()
        idx = v.indexAt(pos)
        m = QMenu(self)
        def mi(key, label, fn):
            a = m.addAction(label, fn)
            alias = _PLACE_ALIASES.get(key, key)
            ic = _local_icon(alias) or ICONS.get(key)
            if not ic.isNull(): a.setIcon(ic)
        if idx.isValid():
            p = self.model.filePath(idx)
            if os.path.isdir(p):
                mi("place-folder", "Open", lambda: self._go(p, push=True))
                if self._picker_mode and self._pick_type == "folder":
                    m.addSeparator()
                    mi("dialog-ok", "Select this folder", lambda: self._confirm_pick([p]))
            else:
                mi("unknown", "Open", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(p)))
                if self._picker_mode and self._pick_type in ("file", "files"):
                    m.addSeparator()
                    mi("dialog-ok", "Select this file", lambda: self._confirm_pick([p]))
            m.addSeparator()
            mi("edit-rename","Rename",  self._rename)
            mi("edit-delete","Delete",  self._delete)
            m.addSeparator()
            m.addAction("Copy Path", lambda: QApplication.clipboard().setText(p))
        else:
            if self._picker_mode and self._pick_type == "folder":
                mi("dialog-ok", "Select current folder", self._confirm_pick)
            mi("folder-new",  "New Folder", self._mkdir)
            m.addSeparator()
            mi("view-refresh","Refresh",    self._reload)
        m.addSeparator()
        mi("terminal", "Open Terminal Here", self._terminal)
        m.exec(v.viewport().mapToGlobal(pos))

    def _on_selection_changed(self):
        if not self._picker_mode or self._pick_type == "folder":
            return
        has_sel = len(self._sel()) > 0
        if hasattr(self, "a_select"):
            self.a_select.setEnabled(has_sel)

    def _confirm_pick(self, paths=None):
        if self._pick_type == "folder":
            self._selected_paths = [self._path]
            self.file_picked.emit(self._selected_paths)
            self.close()
            return
        if paths is None:
            paths = self._sel()
        if not paths:
            return
        if self._pick_type == "file":
            paths = [paths[0]]
        self._selected_paths = paths
        self.file_picked.emit(paths)
        self.close()

    def _apply_picker_filter(self):
        if self._picker_mode and self._extension_filter:
            exts = self._extension_filter
            if isinstance(exts, str):
                if exts == "*" or exts == "":
                    self.model.setNameFilters([])
                    return
                exts = [exts]
            patterns = []
            for ext in exts:
                ext = ext.strip()
                if not ext:
                    continue
                if not ext.startswith("*"):
                    ext = f"*{ext}"
                patterns.append(ext)
            if patterns:
                self.model.setNameFilters(patterns)
                self.model.setNameFilterDisables(False)
            else:
                self.model.setNameFilters([])
        else:
            self.model.setNameFilters([])

    def _upd_status(self):
        try:
            e = list(os.scandir(self._path))
            nd = sum(1 for x in e if x.is_dir())
            nf = sum(1 for x in e if x.is_file())
            self._status.setText(
                f"{nd} folder{'s' if nd!=1 else ''}, {nf} file{'s' if nf!=1 else ''}  ·  {self._path}")
        except PermissionError:
            self._status.setText(f"{self._path}  (permission denied)")

    def keyPressEvent(self, e):
        k = e.key()
        if k == Qt.Key.Key_Backspace:
            self._back()
        elif k == Qt.Key.Key_Escape and self._addr.isVisible():
            self._toggle_addr()
        elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self._picker_mode:
            self._confirm_pick()
        elif k == Qt.Key.Key_Space:
            self._toggle_glimpse()
        else:
            super().keyPressEvent(e)

    def _toggle_glimpse(self):
        if self._glimpse.isVisible():
            self._glimpse.close_preview()
            return
        # Gather all files in current dir (same order as view)
        sel = self._sel()
        # If nothing selected or a folder selected, pick first file selection
        files = [p for p in sel if os.path.isfile(p)]
        if not files:
            # No selection — preview all files in folder
            try:
                all_items = sorted(
                    (os.path.join(self._path, f) for f in os.listdir(self._path)
                     if os.path.isfile(os.path.join(self._path, f))),
                    key=lambda x: x.lower()
                )
                files = all_items
            except Exception:
                return
        if not files:
            return
        self._glimpse.show_files(files, 0)


# ──────────────────────────────────────────────────────────────────────────────
def _ensure_app():
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
        app.setApplicationName("Pylphin")
        app.setStyle("Fusion")
        app.setPalette(_breeze_dark_palette())
        app.setStyleSheet(BREEZE_DARK_QSS)
    return app


def _run_picker(picker):
    app = _ensure_app()
    result = []
    loop = QEventLoop()

    def on_picked(paths):
        result.extend(paths)
        loop.quit()

    picker.file_picked.connect(on_picked)
    picker.destroyed.connect(loop.quit)
    picker.show()
    picker.raise_()
    picker.activateWindow()

    loop.exec()
    return result


def pick_file(start_path=None, extension="*", parent=None) -> str | None:
    """Open Pylphin as a single-file picker dialog.

    Args:
        start_path: Directory to open (default: home directory).
        extension:  Extension filter. Pass a single string (``'.txt'``,
                    ``'.png'``, ``'*'``) or a list of strings
                    (``['.zip', '.linkzip']``) to allow multiple types.
        parent:     Optional parent QWidget.

    Returns:
        Absolute file path, or ``None`` if cancelled.
    """
    picker = Pylphin(picker_mode=True, pick_type="file",
                       extension_filter=extension, parent=parent)
    if start_path and os.path.isdir(start_path):
        picker._go(start_path)
    res = _run_picker(picker)
    return res[0] if res else None


def pick_files(start_path=None, extension="*", parent=None) -> list[str]:
    """Open Pylphin as a multi-file picker dialog.

    Args:
        start_path: Directory to open (default: home directory).
        extension:  Extension filter. Pass a single string (``'.txt'``,
                    ``'.png'``, ``'*'``) or a list of strings
                    (``['.zip', '.linkzip']``) to allow multiple types.
        parent:     Optional parent QWidget.

    Returns:
        List of absolute file paths (empty if cancelled).
    """
    picker = Pylphin(picker_mode=True, pick_type="files",
                       extension_filter=extension, parent=parent)
    if start_path and os.path.isdir(start_path):
        picker._go(start_path)
    return _run_picker(picker)


def pick_folder(start_path=None, parent=None) -> str | None:
    """Open Pylphin as a folder picker dialog.

    Args:
        start_path: Directory to open (default: home directory).
        parent:     Optional parent QWidget.

    Returns:
        Absolute folder path, or ``None`` if cancelled.
    """
    picker = Pylphin(picker_mode=True, pick_type="folder", parent=parent)
    if start_path and os.path.isdir(start_path):
        picker._go(start_path)
    res = _run_picker(picker)
    return res[0] if res else None


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Pylphin")
    app.setStyle("Fusion")
    # Force Breeze Dark regardless of OS light/dark setting
    app.setPalette(_breeze_dark_palette())
    app.setStyleSheet(BREEZE_DARK_QSS)
    w = Pylphin(); w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
