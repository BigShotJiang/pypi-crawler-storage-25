"""argus-me Hugging Face Space demo.

Give Me fragments. I give you understanding.
"""

import os
import tempfile

import gradio as gr

from argus_me import Me

# ── LLM Provider presets ───────────────────────────────────

PROVIDERS = {
    "SiliconFlow (free, Qwen3-8B)": {
        "base_url": "https://api.siliconflow.cn/v1",
        "model": "Qwen/Qwen3-8B",
        "key_env": "SILICONFLOW_API_KEY",
    },
    "Groq (free, Qwen3-32B)": {
        "base_url": "https://api.groq.com/openai/v1",
        "model": "qwen/qwen3-32b",
        "key_env": "GROQ_API_KEY",
    },
    "OpenRouter (free, Qwen3.6-Plus)": {
        "base_url": "https://openrouter.ai/api/v1",
        "model": "qwen/qwen3.6-plus-preview:free",
        "key_env": "OPENROUTER_API_KEY",
    },
    "Custom (bring your own)": {
        "base_url": "",
        "model": "",
        "key_env": "",
    },
}

# ── Session state ──────────────────────────────────────────

_sessions: dict[str, Me] = {}


def _get_or_create_me(
    session_id: str,
    provider: str,
    custom_url: str,
    custom_model: str,
    custom_key: str,
    redact: bool,
) -> Me:
    """Get or create a Me instance for a session."""
    if provider == "Custom (bring your own)":
        base_url = custom_url.strip()
        model = custom_model.strip()
        api_key = custom_key.strip()
        if not base_url or not model or not api_key:
            raise gr.Error("Please fill in URL, Model, and API Key for custom provider.")
    else:
        preset = PROVIDERS[provider]
        base_url = preset["base_url"]
        model = preset["model"]
        api_key = custom_key.strip() or os.environ.get(preset["key_env"], "")
        if not api_key:
            raise gr.Error(
                f"API key required. Set {preset['key_env']} in Space secrets, "
                "or paste your key in the API Key field."
            )

    # Reuse existing session or create new
    key = f"{session_id}:{base_url}:{model}"
    if key not in _sessions:
        db_path = os.path.join(tempfile.gettempdir(), f"argus_me_{session_id}.db")
        _sessions[key] = Me(
            name="Demo User",
            db_path=db_path,
            llm_base_url=base_url,
            llm_model=model,
            llm_api_key=api_key,
            redact=redact,
        )
    return _sessions[key]


# ── Core logic ─────────────────────────────────────────────


def process_fragment(
    text: str,
    provider: str,
    custom_url: str,
    custom_model: str,
    custom_key: str,
    redact: bool,
    history: list,
    session_id: str,
):
    """Ingest a fragment and run understand()."""
    if not text.strip():
        raise gr.Error("Please write something first.")

    me = _get_or_create_me(session_id, provider, custom_url, custom_model, custom_key, redact)

    # Build redact preview (regenerate so it persists after LLM completes)
    redact_preview = ""
    if redact:
        try:
            from argus_me.redact import is_available, redact_text

            if is_available():
                redacted, key = redact_text(text)
                if key:
                    items = "\n".join(
                        f"| `{pseudo}` | `{real}` |" for pseudo, real in key.items()
                    )
                    redact_preview = (
                        "### Privacy Protection (argus-redact)\n\n"
                        "**What LLM sees:**\n"
                        f"```\n{redacted}\n```\n\n"
                        "**Redaction map:**\n\n"
                        "| LLM sees | Your original |\n"
                        "|----------|---------------|\n"
                        f"{items}\n\n"
                        f"**{len(key)} PII item(s) encrypted.** "
                        "Real names and data never reach the LLM."
                    )
                else:
                    redact_preview = (
                        "### Privacy Protection (argus-redact)\n\n"
                        "No PII detected — your text is clean."
                    )
        except Exception:
            pass

    # Ingest and understand
    me.ingest(text)
    try:
        result = me.understand()
    except Exception as e:
        raise gr.Error(f"LLM call failed: {e}")

    # Build snapshot display
    snap = me.snapshot()
    fragment_count = len(history) + 1

    # Format understanding
    understanding = f"## Understanding after {fragment_count} fragment(s)\n\n"

    if snap["summary"]:
        understanding += f"### Summary\n{snap['summary']}\n\n"

    if snap["conflict"]:
        understanding += f"### Tension\n{snap['conflict']}\n\n"

    emotion = snap["emotion"]
    if emotion["word"]:
        bar_len = int((emotion["valence"] + 1) / 2 * 10) if emotion["valence"] is not None else 5
        bar = "+" * bar_len + "-" * (10 - bar_len)
        understanding += (
            f"### Emotion\n"
            f"**{emotion['word']}** `[{bar}]` "
            f"valence: {emotion['valence']}, arousal: {emotion['arousal']}\n\n"
        )

    if snap["entities"]:
        understanding += "### People in your world\n"
        for e in snap["entities"]:
            dyn = e.get("dynamics", 0)
            arrow = "+" if dyn > 0.1 else ("-" if dyn < -0.1 else "~")
            understanding += f"- **{e['canonical_name']}** ({arrow}{abs(dyn):.1f})\n"
        understanding += "\n"

    if snap["matters"]:
        understanding += "### What you care about\n"
        for m in snap["matters"]:
            understanding += f"- **{m['name']}**: {m.get('current', '')}\n"
        understanding += "\n"

    if snap["possibilities"]:
        understanding += "### What might happen\n"
        for p in snap["possibilities"]:
            conf = p.get("confidence", "medium")
            understanding += f"- **{p['event']}** ({conf})\n"
            if p.get("narrative"):
                understanding += f"  {p['narrative'][:120]}\n"
        understanding += "\n"

    if snap["self_profile"]:
        understanding += f"### Who you are (evolving)\n{snap['self_profile']}\n\n"

    if snap["gaps"]:
        understanding += "### What Me doesn't know yet\n"
        for g in snap["gaps"]:
            understanding += f"- {g.get('description', '')}\n"
        understanding += "\n"

    # Update history
    history = history + [text]

    return understanding, redact_preview, history


def clear_session(session_id: str):
    """Reset the session."""
    keys_to_remove = [k for k in _sessions if k.startswith(session_id)]
    for k in keys_to_remove:
        del _sessions[k]
    # Clean temp db
    db_path = os.path.join(tempfile.gettempdir(), f"argus_me_{session_id}.db")
    if os.path.exists(db_path):
        os.remove(db_path)
    return "", "", []


# ── UI ─────────────────────────────────────────────────────

EXAMPLES = [
    "今天和Tom开会讨论了产品方向，他觉得应该先做B端，我倾向C端但没有反驳。回来路上一直在想这个事。",
    "Judy told me she's thinking about leaving BigCorp. She seemed stressed. I suggested she take a week off first.",
    "日记：最近总觉得时间不够用，产品、融资、团队三件事压在一起。今天决定先放下融资，专注产品。",
    "Met with investor today. They liked the demo but worried about market size. Need to rethink the pitch.",
    "和宋教练确认了周六的课程安排，2.5小时的课程结构。他对课件内容很满意。",
]

with gr.Blocks(
    title="argus-me",
    theme=gr.themes.Soft(),
    css="""
    .main-title { text-align: center; margin-bottom: 0; }
    .subtitle { text-align: center; color: #666; margin-top: 0; }
    """,
) as demo:
    # Session state
    session_id = gr.State(lambda: os.urandom(8).hex())
    history = gr.State([])

    # Header
    gr.Markdown("# argus-me", elem_classes="main-title")
    gr.Markdown(
        "*Give Me fragments. I give you understanding.*",
        elem_classes="subtitle",
    )
    gr.Markdown(
        "Write a diary entry, a conversation, or anything on your mind. "
        "Me processes your fragments through a **4-call cognitive pipeline** "
        "and builds an evolving understanding — entities, matters, emotions, "
        "possibilities, and a self-portrait that grows with every interaction.\n\n"
        "**Try it**: paste a fragment below, click Understand, then add more. "
        "The understanding deepens with each fragment."
    )

    # Output (above input so user sees feedback immediately)
    status_output = gr.Markdown(visible=False)
    redact_output = gr.Markdown(label="Privacy Protection")
    understanding_output = gr.Markdown(label="Me's Understanding")

    # Input
    text_input = gr.Textbox(
        label="Your fragment",
        placeholder="Write a diary entry, conversation, thought...",
        lines=4,
    )
    with gr.Row():
        redact_toggle = gr.Checkbox(
            label="Privacy protection (argus-redact)",
            value=False,
        )
        submit_btn = gr.Button("Understand", variant="primary", scale=2)
        clear_btn = gr.Button("Start over", scale=1)

    gr.Examples(examples=EXAMPLES, inputs=text_input, label="Try these")

    # LLM config (collapsed, defaults work out of the box)
    with gr.Accordion("Advanced: LLM Provider", open=False):
        gr.Markdown(
            "*Default provider is pre-configured. "
            "Only change this if you want to use your own API key or a different model.*"
        )
        provider = gr.Dropdown(
            choices=list(PROVIDERS.keys()),
            value="OpenRouter (free, Qwen3.6-Plus)",
            label="Provider",
        )
        with gr.Row():
            custom_url = gr.Textbox(
                label="Base URL",
                placeholder="https://api.example.com/v1",
                visible=False,
            )
            custom_model = gr.Textbox(
                label="Model",
                placeholder="model-name",
                visible=False,
            )
        custom_key = gr.Textbox(
            label="API Key (optional, override default)",
            type="password",
            placeholder="Leave empty to use default",
        )

        def toggle_custom(choice):
            is_custom = choice == "Custom (bring your own)"
            return gr.update(visible=is_custom), gr.update(visible=is_custom)

        provider.change(toggle_custom, provider, [custom_url, custom_model])

    # Actions — step 1: redact preview (instant), step 2: LLM (slow)

    def show_redact_and_loading(text, redact_on):
        """Instant: show redaction preview + loading state."""
        preview = ""
        if redact_on and text.strip():
            try:
                from argus_me.redact import is_available, redact_text

                if is_available():
                    redacted, key = redact_text(text)
                    if key:
                        # Build visual diff
                        items = "\n".join(
                            f"| `{pseudo}` | `{real}` |"
                            for pseudo, real in key.items()
                        )
                        preview = (
                            "### Privacy Protection (argus-redact)\n\n"
                            "**What LLM sees:**\n"
                            f"```\n{redacted}\n```\n\n"
                            "**Redaction map:**\n\n"
                            "| LLM sees | Your original |\n"
                            "|----------|---------------|\n"
                            f"{items}\n\n"
                            f"**{len(key)} PII item(s) encrypted.** "
                            "Real names and data never reach the LLM."
                        )
                    else:
                        preview = (
                            "### Privacy Protection (argus-redact)\n\n"
                            "No PII detected — your text is clean."
                        )
            except Exception:
                preview = ""

        status = "**Thinking... 4 LLM calls in progress, this may take 30-60 seconds.**"
        return (
            gr.update(value=preview) if preview else gr.update(value=""),
            gr.update(value=status, visible=True),
            gr.update(interactive=False, value="Thinking..."),
        )

    def hide_loading():
        return (
            gr.update(visible=False),
            gr.update(interactive=True, value="Understand"),
            "",
        )

    submit_btn.click(
        show_redact_and_loading,
        inputs=[text_input, redact_toggle],
        outputs=[redact_output, status_output, submit_btn],
    ).then(
        process_fragment,
        inputs=[text_input, provider, custom_url, custom_model, custom_key, redact_toggle, history, session_id],
        outputs=[understanding_output, redact_output, history],  # redact_output kept from step 1 if empty
    ).then(
        hide_loading,
        outputs=[status_output, submit_btn, text_input],
    )

    # Note: process_fragment returns redact_preview="" which clears the preview
    # after LLM completes. To keep it visible, we preserve in process_fragment.

    clear_btn.click(
        clear_session,
        inputs=[session_id],
        outputs=[understanding_output, redact_output, history],
    )

    # How it works
    gr.Markdown("""
---

## What is argus-me?

A **cognitive exoskeleton** — not an assistant, not a diary, not a therapist.
It amplifies what you can perceive about your own life by processing fragments
into structured understanding.

| What the system does | What you do |
|---------------------|-------------|
| Track patterns across months | Decide what matters |
| Never forget what was said 3 months ago | Judge what's important |
| Detect contradictions between values and behavior | Decide what to do about them |

### The 4-Call Pipeline

Each `understand()` runs your fragments through four sequential LLM calls:

| Call | Question | Output |
|------|----------|--------|
| **WHO** | Who is mentioned? How do they relate to me? | Entities, aliases, self-portrait updates |
| **WHAT** | What happened? What changed? | Summary, emotion, matters, cognitive gaps |
| **MEANING** | What patterns am I not seeing? | Behavioral observations, tensions |
| **POSSIBILITIES** | What might happen next? | Scenario narratives per open matter |

### What makes v0.2 different

| Feature | What it does |
|---------|-------------|
| **Epoch memory** | Compresses ~14 runs into semantic summaries. The system remembers months, not just the last 5 runs. |
| **Observations** | Self-knowledge stored as typed, evidence-linked atoms — not a growing text blob. |
| **Compliance gate** | Deterministic regex check blocks clinical/diagnostic language before it reaches your data. |
| **Telescoping context** | LLM sees compressed long-term memory + detailed recent memory. |
| **Adversarial probe** | Optionally challenges high-confidence patterns — "try to break it" before trusting it. |

### Safety

All outputs use **behavioral observation language** — the system describes what you *did*,
never what you *are*. Clinical terms (diagnoses, treatment verbs) are blocked by a deterministic
compliance gate before reaching your database. The system is an analyst, never a companion.

### Privacy

When privacy protection is on, [argus-redact](https://github.com/wan9yu/argus-redact) encrypts
real names and PII before sending to the LLM. The LLM never sees your real data.

### Install

```python
pip install argus-me

from argus_me import Me

me = Me(
    name="Your Name",
    db_path="memory.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
)

me.ingest("Had coffee with Tom today.")
me.ingest("Diary: feeling stuck on product direction.")
result = me.understand()
snap = me.snapshot()
```

---

Built with **argus-me v0.2.2** | Privacy by **[argus-redact](https://github.com/wan9yu/argus-redact) v0.2.0**

[GitHub](https://github.com/wan9yu/argus-me) |
[PyPI](https://pypi.org/project/argus-me/) |
[argus-redact](https://github.com/wan9yu/argus-redact) |
Apache 2.0
""")


if __name__ == "__main__":
    demo.launch()
