"""Structured report generation — read-only, does not modify DB."""

from .llm import call_llm, create_client, load_template, parse_json


def generate_report(
    path: str,
    template_name: str,
    *,
    llm_base_url: str,
    llm_model: str,
    llm_api_key: str = "ollama",
    prompt_dir: str | None = None,
) -> dict:
    """Generate a structured report. Read-only — no DB writes."""
    from .models import (
        get_all_entities,
        get_latest_emotion,
        get_open_matters,
        get_recent_runs,
        read_self_profile,
    )

    # Assemble data context
    snapshot = {
        "self_profile": read_self_profile(path),
        "matters": get_open_matters(path),
        "entities": get_all_entities(path),
        "runs": get_recent_runs(path, limit=5),
        "emotion": get_latest_emotion(path),
    }

    prompt = load_template(f"report_{template_name}", prompt_dir).render(
        snapshot=snapshot,
    )

    client = create_client(llm_base_url, api_key=llm_api_key)
    raw, _ = call_llm(
        client, llm_model, prompt, temperature=0.3, max_tokens=4000
    )
    return parse_json(raw, default={"error": "Failed to generate report"})
