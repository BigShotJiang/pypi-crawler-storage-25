"""Compliance gate — deterministic safety checks before DB writes.

Runs before any LLM output is written to observations/self_profile/insight_queue.
Does not depend on LLM. Pure regex matching.
"""

import re
from typing import NamedTuple


class ComplianceResult(NamedTuple):
    passed: bool
    violations: list[str]
    sanitized: str | None


# ── Clinical terms (hard block — entire text discarded) ────

CLINICAL_TERMS = [
    # DSM/ICD diagnoses (Chinese)
    r"焦虑症|抑郁症|躁郁|强迫症|PTSD|创伤后|人格障碍|精神分裂",
    # DSM/ICD diagnoses (English)
    r"anxiety\s*disorder|depression\s*disorder|bipolar|OCD|PTSD|personality\s*disorder",
    # Diagnostic verbs (Chinese)
    r"诊断为|确诊|患有|症状表现为",
    # Diagnostic verbs (English)
    r"diagnosed\s+with|suffering\s+from|symptoms\s+of",
    # Treatment terms (Chinese)
    r"需要治疗|建议就医|药物|处方|疗程",
    # Treatment terms (English)
    r"needs?\s+treatment|should\s+seek\s+therapy|medication|prescription",
]

# ── Inference patterns (soft block — downgrade, not discard) ──

INFERENCE_PATTERNS = [
    # "你是/你有...倾向/特质" (Chinese)
    r"你(?:是|有|存在|表现出).*(?:倾向|特质|人格|性格|心理)",
    # "you are/have...tendency/trait" (English)
    r"you\s+(?:are|have|exhibit|display).*(?:tendency|trait|personality|disposition)",
    # Psychological mechanism verbs with subject "你" (Chinese)
    r"你(?:在|正在)?(?:回避|逃避|压抑|投射|否认|合理化)",
    # Psychological mechanism verbs (English)
    r"you\s+(?:are|is)\s+(?:avoiding|repressing|projecting|denying|rationalizing)",
    # Emotional state assertions (Chinese)
    r"你(?:感到|内心|潜意识|深层).*(?:恐惧|焦虑|抑郁|愤怒)",
    # Emotional state assertions (English)
    r"you\s+(?:feel|subconsciously|deep\s+down).*(?:fear|anxiety|anger)",
]

_CLINICAL_RE = [re.compile(p, re.IGNORECASE) for p in CLINICAL_TERMS]
_INFERENCE_RE = [re.compile(p, re.IGNORECASE) for p in INFERENCE_PATTERNS]


def compliance_check(text: str, profile: str = "personal") -> ComplianceResult:
    """Check text against compliance rules.

    Profiles:
      "personal": full clinical + inference checks (default)
      "business": no checks (business data, not personal reflections)

    Returns:
        ComplianceResult:
          passed=True: safe to write
          passed=False + sanitized=None: clinical terms, discard entirely
          passed=False + sanitized=text: inference language, downgrade
    """
    if not text:
        return ComplianceResult(passed=True, violations=[], sanitized=None)

    if profile == "business":
        return ComplianceResult(passed=True, violations=[], sanitized=None)

    # Clinical terms → hard block
    violations = []
    for i, pattern in enumerate(_CLINICAL_RE):
        if pattern.search(text):
            violations.append(f"CLINICAL_{i}")

    if violations:
        return ComplianceResult(passed=False, violations=violations, sanitized=None)

    # Inference patterns → soft block (downgrade)
    for i, pattern in enumerate(_INFERENCE_RE):
        if pattern.search(text):
            violations.append(f"INFERENCE_{i}")

    if violations:
        return ComplianceResult(passed=False, violations=violations, sanitized=text)

    return ComplianceResult(passed=True, violations=[], sanitized=None)
