"""argus-me — personal cognitive engine library."""

__version__ = "0.2.2"

from .me import Me

__all__ = ["Me"]
