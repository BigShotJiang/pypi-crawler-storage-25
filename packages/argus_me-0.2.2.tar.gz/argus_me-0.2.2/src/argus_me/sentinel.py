"""Subconscious — stats preamble, cognitive debt scanning, anti-bias.

L1: Pure statistics + heuristics. No LLM calls.
L2: Optional semantic layer. One LLM call to interpret L1 anomalies.
Runs inline at the end of every understand() call.
"""

import json as _json
from datetime import date, datetime, timedelta, timezone

from .llm import call_llm, create_client, load_template, parse_json
from .models import connect

# ── Thresholds ─────────────────────────────────────────────

_EMOTION_TREND_DELTA = 0.1  # valence diff to count as rising/falling
_STALE_MATTER_DAYS = 7  # days without mention → stale
_EMOTION_INFLECTION_DAYS = 3  # consecutive same-direction days
_EMOTION_HIGH_CONCERN = -0.3  # valence below this → high priority
_UNCONFIRMED_MIN_INTERACTIONS = 3  # interactions before flagging unconfirmed
_HIGH_FREQ_MULTIPLIER = 2.5  # weekly mentions > avg * this → flagged
_RELATIONSHIP_GAP_DAYS = 14  # days without seeing entity → gap
_ECHO_CHAMBER_THRESHOLD = 0.8  # top-2 entity mention ratio
_ECHO_CHAMBER_MIN_FRAGMENTS = 5  # minimum fragments for echo detection
_EMOTION_GRANULARITY_MIN = 3  # distinct emotions below this → low
_INSIGHT_CONCENTRATION_THRESHOLD = 0.6  # possibility ratio on single matter
_INSIGHT_CONCENTRATION_MIN = 5  # minimum possibilities for detection
_MATTER_AVOIDANCE_DAYS = 14  # days → avoidance signal
_DYNAMICS_DRIFT_THRESHOLD = -0.3  # entity dynamics below this → drifting
_DYNAMICS_DRIFT_MIN_INTERACTIONS = 3
_INTENTION_SURFACE_THRESHOLD = 0.7  # confidence to surface as insight


def _today() -> str:
    return date.today().isoformat()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Stats preamble ─────────────────────────────────────────


def generate_preamble(path: str) -> dict:
    """Generate stats preamble for LLM prompt injection. Read-only."""
    conn = connect(path)
    try:
        preamble: dict = {}

        # Emotion trend: 7d vs 30d valence mean
        today = date.today()
        d7 = (today - timedelta(days=7)).isoformat()
        d30 = (today - timedelta(days=30)).isoformat()

        rows_7d = conn.execute(
            "SELECT valence FROM runs WHERE date >= ? AND valence IS NOT NULL",
            (d7,),
        ).fetchall()
        rows_30d = conn.execute(
            "SELECT valence FROM runs WHERE date >= ? AND valence IS NOT NULL",
            (d30,),
        ).fetchall()

        if rows_7d:
            mean_7d = round(sum(r["valence"] for r in rows_7d) / len(rows_7d), 2)
            mean_30d = (
                round(sum(r["valence"] for r in rows_30d) / len(rows_30d), 2)
                if rows_30d
                else mean_7d
            )
            if mean_7d > mean_30d + _EMOTION_TREND_DELTA:
                direction = "rising"
            elif mean_7d < mean_30d - _EMOTION_TREND_DELTA:
                direction = "falling"
            else:
                direction = "stable"
            preamble["emotion_trend"] = {
                "7d_mean": mean_7d,
                "30d_mean": mean_30d,
                "direction": direction,
            }

        # Matter staleness: open matters with days since last run mention
        open_matters = conn.execute(
            "SELECT id, name, opened_date FROM matters WHERE status='open'"
        ).fetchall()
        staleness = []
        for m in open_matters:
            last_run = conn.execute(
                "SELECT MAX(date) as last_date FROM runs" " WHERE summary LIKE ?",
                (f"%{m['name']}%",),
            ).fetchone()
            last_date = last_run["last_date"] if last_run else m["opened_date"]
            if last_date:
                try:
                    days = (today - date.fromisoformat(last_date)).days
                except (ValueError, TypeError):
                    days = 0
                staleness.append(
                    {
                        "name": m["name"],
                        "days_since_mention": days,
                    }
                )
        if staleness:
            staleness.sort(key=lambda x: x["days_since_mention"], reverse=True)
            preamble["matter_staleness"] = staleness

        return preamble
    finally:
        conn.close()


# ── Cognitive debt scanning ────────────────────────────────


def scan_debts(path: str) -> list[dict]:
    """Detect cognitive debts. Returns insight dicts (does not write)."""
    insights: list[dict] = []
    insights.extend(_scan_stale_matters(path))
    insights.extend(_scan_emotion_inflection(path))
    insights.extend(_scan_unconfirmed_entities(path))
    insights.extend(_scan_high_freq_entities(path))
    insights.extend(_scan_relationship_gaps(path))
    return insights


def _matter_inactivity(path: str) -> list[tuple[dict, int]]:
    """Compute (matter, days_inactive) for all open matters. Shared by debt + intention scanners."""
    conn = connect(path)
    try:
        today_d = date.today()
        matters = conn.execute(
            "SELECT id, name, opened_date FROM matters WHERE status='open'"
        ).fetchall()
        results = []
        for m in matters:
            last_run = conn.execute(
                "SELECT MAX(date) as last_date FROM runs WHERE summary LIKE ?",
                (f"%{m['name']}%",),
            ).fetchone()
            last_date = last_run["last_date"] if last_run else m["opened_date"]
            if last_date:
                try:
                    days = (today_d - date.fromisoformat(last_date)).days
                except (ValueError, TypeError):
                    continue
                results.append((dict(m), days))
        return results
    finally:
        conn.close()


def _scan_stale_matters(path: str) -> list[dict]:
    """Open matters not mentioned in runs for >7 days."""
    return [
        {
            "type": "stale_matter",
            "description": f"{m['name']} inactive for {days} days",
            "priority": "high" if days >= _MATTER_AVOIDANCE_DAYS else "medium",
        }
        for m, days in _matter_inactivity(path)
        if days >= _STALE_MATTER_DAYS
    ]


def _scan_emotion_inflection(path: str) -> list[dict]:
    """3+ consecutive days of same-direction valence change."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT date, valence FROM runs"
            " WHERE valence IS NOT NULL"
            " ORDER BY date DESC LIMIT 7"
        ).fetchall()
        if len(rows) < 3:
            return []

        # Check for monotonic decline or rise
        vals = [r["valence"] for r in reversed(rows)]
        declining = all(vals[i] > vals[i + 1] for i in range(min(3, len(vals) - 1)))
        rising = all(vals[i] < vals[i + 1] for i in range(min(3, len(vals) - 1)))

        insights = []
        if declining:
            priority = "high" if vals[-1] < _EMOTION_HIGH_CONCERN else "medium"
            insights.append(
                {
                    "type": "emotion_inflection",
                    "description": "Emotional valence declining for 3+ consecutive days",
                    "priority": priority,
                }
            )
        elif rising:
            insights.append(
                {
                    "type": "emotion_inflection",
                    "description": "Emotional valence rising for 3+ consecutive days",
                    "priority": "low",
                }
            )
        return insights
    finally:
        conn.close()


def _scan_unconfirmed_entities(path: str) -> list[dict]:
    """Entity with 3+ interactions but no note and not in any matter."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT e.canonical_name, e.interaction_count"
            " FROM entities e"
            " WHERE e.id != 'self'"
            f" AND e.interaction_count >= {_UNCONFIRMED_MIN_INTERACTIONS}"
            " AND (e.note IS NULL OR e.note = '')"
            " AND e.id NOT IN (SELECT entity_id FROM matter_entities)"
        ).fetchall()
        return [
            {
                "type": "unconfirmed_entity",
                "description": (
                    f"{r['canonical_name']} has {r['interaction_count']}"
                    " interactions but no context"
                ),
                "priority": "medium",
            }
            for r in rows
        ]
    finally:
        conn.close()


def _scan_high_freq_entities(path: str) -> list[dict]:
    """Entity mentioned far more than usual this week."""
    conn = connect(path)
    try:
        d7 = (date.today() - timedelta(days=7)).isoformat()
        d90 = (date.today() - timedelta(days=90)).isoformat()
        entities = conn.execute(
            "SELECT id, canonical_name, interaction_count, first_seen"
            " FROM entities WHERE id != 'self'"
        ).fetchall()
        results = []
        for e in entities:
            recent = conn.execute(
                "SELECT COUNT(*) FROM runs" " WHERE date >= ? AND summary LIKE ?",
                (d7, f"%{e['canonical_name']}%"),
            ).fetchone()[0]
            total = conn.execute(
                "SELECT COUNT(*) FROM runs" " WHERE date >= ? AND summary LIKE ?",
                (d90, f"%{e['canonical_name']}%"),
            ).fetchone()[0]
            try:
                days_active = (date.today() - date.fromisoformat(e["first_seen"])).days
            except (ValueError, TypeError):
                days_active = 90
            weeks_90 = max(days_active // 7, 1)
            weekly_avg = total / weeks_90
            if recent > 0 and weekly_avg > 0 and recent > weekly_avg * _HIGH_FREQ_MULTIPLIER:
                results.append(
                    {
                        "type": "high_freq_entity",
                        "description": (
                            f"{e['canonical_name']} mentioned {recent}x this week"
                            f" (avg {weekly_avg:.1f}/week)"
                        ),
                        "priority": "medium",
                    }
                )
        return results
    finally:
        conn.close()


def _scan_relationship_gaps(path: str) -> list[dict]:
    """Entity with interaction gap exceeding normal pattern."""
    conn = connect(path)
    try:
        today_d = date.today()
        entities = conn.execute(
            "SELECT canonical_name, last_seen, interaction_count"
            " FROM entities WHERE id != 'self'"
            f" AND interaction_count >= {_DYNAMICS_DRIFT_MIN_INTERACTIONS}"
        ).fetchall()
        results = []
        for e in entities:
            try:
                last = date.fromisoformat(e["last_seen"])
                gap = (today_d - last).days
            except (ValueError, TypeError):
                continue
            if gap > _RELATIONSHIP_GAP_DAYS:
                results.append(
                    {
                        "type": "relationship_gap",
                        "description": (f"Haven't seen {e['canonical_name']}" f" in {gap} days"),
                        "priority": "medium",
                    }
                )
        return results
    finally:
        conn.close()


# ── Anti-bias scanning ─────────────────────────────────────


def scan_antibias(path: str) -> list[dict]:
    """Bias-specific detections. Returns insight dicts."""
    insights: list[dict] = []
    insights.extend(_scan_echo_chamber(path))
    insights.extend(_scan_emotion_granularity(path))
    insights.extend(_scan_insight_concentration(path))
    return insights


def _scan_echo_chamber(path: str) -> list[dict]:
    """>80% of recent fragments involve only 1-2 entities (14-day window)."""
    conn = connect(path)
    try:
        d14 = (date.today() - timedelta(days=14)).isoformat()
        fragments = conn.execute(
            "SELECT transcript FROM fragments WHERE date >= ? AND type='text'",
            (d14,),
        ).fetchall()
        if len(fragments) < _ECHO_CHAMBER_MIN_FRAGMENTS:
            return []

        entities = conn.execute("SELECT canonical_name FROM entities WHERE id != 'self'").fetchall()
        if not entities:
            return []

        entity_names = [e["canonical_name"] for e in entities]
        mention_counts: dict[str, int] = {}
        for f in fragments:
            text = f["transcript"] or ""
            for name in entity_names:
                if name in text:
                    mention_counts[name] = mention_counts.get(name, 0) + 1

        if not mention_counts:
            return []

        total_mentions = sum(mention_counts.values())
        top_2 = sorted(mention_counts.values(), reverse=True)[:2]
        top_2_sum = sum(top_2)

        if total_mentions > 0 and top_2_sum / total_mentions > _ECHO_CHAMBER_THRESHOLD:
            return [
                {
                    "type": "echo_chamber_risk",
                    "description": ("Most recent fragments involve only 1-2 people"),
                    "priority": "medium",
                }
            ]
        return []
    finally:
        conn.close()


def _scan_emotion_granularity(path: str) -> list[dict]:
    """<3 distinct emotion words in 30 days."""
    conn = connect(path)
    try:
        d30 = (date.today() - timedelta(days=30)).isoformat()
        rows = conn.execute(
            "SELECT DISTINCT emotion_word FROM runs"
            " WHERE date >= ? AND emotion_word IS NOT NULL"
            " AND emotion_word != ''",
            (d30,),
        ).fetchall()
        distinct = len(rows)
        if distinct > 0 and distinct < _EMOTION_GRANULARITY_MIN:
            return [
                {
                    "type": "low_emotion_granularity",
                    "description": (f"Only {distinct} distinct emotion words in 30 days"),
                    "priority": "medium",
                }
            ]
        return []
    finally:
        conn.close()


def _scan_insight_concentration(path: str) -> list[dict]:
    """>60% of recent possibilities focus on same matter (14-day window)."""
    conn = connect(path)
    try:
        d14 = (date.today() - timedelta(days=14)).isoformat()
        rows = conn.execute(
            "SELECT matter_id FROM possibilities"
            " WHERE created_at >= ? AND matter_id IS NOT NULL",
            (d14,),
        ).fetchall()
        if len(rows) < _INSIGHT_CONCENTRATION_MIN:
            return []
        counts: dict[int, int] = {}
        for r in rows:
            mid = r["matter_id"]
            counts[mid] = counts.get(mid, 0) + 1
        total = sum(counts.values())
        max_count = max(counts.values())
        if total > 0 and max_count / total > _INSIGHT_CONCENTRATION_THRESHOLD:
            return [
                {
                    "type": "insight_concentration",
                    "description": (
                        f"{max_count}/{total} recent possibilities" " focus on a single matter"
                    ),
                    "priority": "medium",
                }
            ]
        return []
    finally:
        conn.close()


# ── Insight queue writes ───────────────────────────────────


def write_insights(path: str, insights: list[dict]) -> None:
    """Write insights to queue with 7-day dedup."""
    if not insights:
        return
    conn = connect(path)
    try:
        now = _now()
        d7 = (date.today() - timedelta(days=7)).isoformat()
        for ins in insights:
            # Dedup: same type + description within 7 days
            existing = conn.execute(
                "SELECT id FROM insight_queue"
                " WHERE type=? AND description=? AND detected_at >= ?",
                (ins["type"], ins["description"], d7),
            ).fetchone()
            if existing:
                continue
            conn.execute(
                "INSERT INTO insight_queue"
                " (type, description, priority, status, detected_at, created_at)"
                " VALUES (?, ?, ?, 'pending', ?, ?)",
                (ins["type"], ins["description"], ins.get("priority", "medium"), now, now),
            )
        conn.commit()
    finally:
        conn.close()


# ── Intention scanning ─────────────────────────────────────


def scan_intentions(path: str) -> list[dict]:
    """Detect implicit intentions from behavioral patterns."""
    intentions: list[dict] = []
    intentions.extend(_scan_matter_avoidance(path))
    intentions.extend(_scan_dynamics_drift(path))
    return intentions


def _scan_matter_avoidance(path: str) -> list[dict]:
    """Open matter not mentioned in runs for 14+ days → avoidance signal."""
    return [
        {
            "content": (
                f"May be unconsciously avoiding '{m['name']}'" f" (not mentioned in {days} days)"
            ),
            "type": "implicit",
            "confidence": min(0.3 + (days - 14) * 0.02, 0.7),
            "related_matters": f"[{m['id']}]",
        }
        for m, days in _matter_inactivity(path)
        if days >= _MATTER_AVOIDANCE_DAYS
    ]


def _scan_dynamics_drift(path: str) -> list[dict]:
    """Entity with strongly negative dynamics → distancing signal."""
    conn = connect(path)
    try:
        entities = conn.execute(
            "SELECT canonical_name, dynamics, interaction_count"
            f" FROM entities WHERE id != 'self' AND dynamics < {_DYNAMICS_DRIFT_THRESHOLD}"
            " AND interaction_count >= 3"
        ).fetchall()
        results = []
        for e in entities:
            results.append(
                {
                    "content": (
                        f"Relationship with {e['canonical_name']} declining"
                        f" (dynamics: {e['dynamics']:.2f})"
                    ),
                    "type": "implicit",
                    "confidence": min(abs(e["dynamics"]) * 0.7, 0.6),
                }
            )
        return results
    finally:
        conn.close()


def write_intention(
    path: str,
    *,
    content: str,
    intention_type: str = "implicit",
    confidence: float = 0.3,
    related_matters: str = "",
) -> None:
    """Write or update an intention. Dedup by content."""
    conn = connect(path)
    try:
        now = _now()
        today_str = date.today().isoformat()
        existing = conn.execute(
            "SELECT id FROM intentions WHERE content=? AND status='active'",
            (content,),
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE intentions SET confidence=?," " last_reinforced=?, updated_at=? WHERE id=?",
                (confidence, today_str, now, existing["id"]),
            )
        else:
            conn.execute(
                "INSERT INTO intentions"
                " (content, type, confidence, status, formed_date,"
                " related_matters, created_at, updated_at)"
                " VALUES (?, ?, ?, 'active', ?, ?, ?, ?)",
                (content, intention_type, confidence, today_str, related_matters, now, now),
            )
        conn.commit()
    finally:
        conn.close()


def get_active_intentions(path: str) -> list[dict]:
    """Return active intentions for Call 3/4 injection."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM intentions WHERE status='active'" " ORDER BY confidence DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Main entry point ───────────────────────────────────────


def _surface_intentions(path: str) -> int:
    """Surface high-confidence intentions as insights. Returns count surfaced."""
    conn = connect(path)
    try:
        now = _now()
        rows = conn.execute(
            "SELECT id, content, confidence FROM intentions"
            " WHERE status='active' AND confidence >= ?"
            " AND surfaced_at IS NULL",
            (_INTENTION_SURFACE_THRESHOLD,),
        ).fetchall()
        for r in rows:
            # Write as insight
            conn.execute(
                "INSERT INTO insight_queue"
                " (type, description, priority, status, detected_at, created_at)"
                " VALUES ('implicit_intention', ?, 'high', 'pending', ?, ?)",
                (r["content"], now, now),
            )
            # Mark intention as surfaced
            conn.execute(
                "UPDATE intentions SET surfaced_at=?, updated_at=? WHERE id=?",
                (now, now, r["id"]),
            )
        conn.commit()
        return len(rows)
    finally:
        conn.close()


# ── L1 metadata scanning ───────────────────────────────────

_METADATA_CONDITIONS = {
    "older_than_days": lambda val, threshold: (
        val is not None
        and (date.today() - date.fromisoformat(str(val))).days > threshold
    ),
    "greater_than": lambda val, threshold: val is not None and float(val) > threshold,
    "less_than": lambda val, threshold: val is not None and float(val) < threshold,
}


def scan_metadata_rules(path: str, rules: list[dict]) -> list[dict]:
    """Scan entities against metadata rules. Returns anomaly list."""
    if not rules:
        return []
    conn = connect(path)
    try:
        entities = conn.execute(
            "SELECT id, canonical_name, metadata"
            " FROM entities WHERE id != 'self'"
        ).fetchall()
        anomalies = []
        for e in entities:
            meta = _json.loads(e["metadata"] or "{}")
            for rule in rules:
                field = rule.get("field", "")
                condition = rule.get("condition", "")
                threshold = rule.get("threshold")
                check_fn = _METADATA_CONDITIONS.get(condition)
                if not check_fn:
                    continue
                # Extract field value
                key = field.replace("metadata.", "") if field.startswith("metadata.") else field
                val = meta.get(key)
                try:
                    if check_fn(val, threshold):
                        anomalies.append({
                            "entity_name": e["canonical_name"],
                            "rule": f"{field} {condition} {threshold}",
                            "value": str(val),
                        })
                except (ValueError, TypeError):
                    continue
        return anomalies
    finally:
        conn.close()


# ── L2 semantic layer ──────────────────────────────────────


def run_sentinel_l2(
    path: str,
    anomalies: list[dict],
    llm_base_url: str,
    llm_model: str,
    llm_api_key: str = "ollama",
    prompt_dir: str | None = None,
) -> list[dict]:
    """L2: LLM interprets L1 anomalies in context of self_profile."""
    if not anomalies:
        return []
    from .models import read_self_profile

    client = create_client(llm_base_url, api_key=llm_api_key)
    self_profile = read_self_profile(path)

    anomaly_text = "\n".join(
        f"- {a['entity_name']}: {a['rule']} (current: {a['value']})"
        for a in anomalies
    )
    prompt = (
        f"你是数据分析师。基于以下自我画像和统计异常，哪些值得关注？\n\n"
        f"[自我画像]\n{self_profile}\n\n"
        f"[统计异常]\n{anomaly_text}\n\n"
        f"输出 JSON: {{\"insights\": [{{\"description\": \"...\", \"priority\": \"high/medium/low\"}}]}}"
    )

    raw, _ = call_llm(
        client, llm_model, prompt, temperature=0.2, max_tokens=1000
    )
    result = parse_json(raw, default={"insights": []})
    return result.get("insights", [])


def run_subconscious(path: str) -> dict:
    """Run all subconscious scanners. Called at end of understand()."""
    preamble = generate_preamble(path)

    debts = scan_debts(path)
    antibias = scan_antibias(path)
    intentions = scan_intentions(path)

    all_insights = debts + antibias
    write_insights(path, all_insights)

    # Write detected intentions
    for intent in intentions:
        write_intention(
            path,
            content=intent["content"],
            intention_type=intent.get("type", "implicit"),
            confidence=intent.get("confidence", 0.3),
            related_matters=intent.get("related_matters", ""),
        )

    # Surface high-confidence intentions as insights
    surfaced = _surface_intentions(path)

    return {
        "preamble": preamble,
        "insights_found": len(all_insights),
        "intentions_updated": len(intentions),
        "intentions_surfaced": surfaced,
    }
