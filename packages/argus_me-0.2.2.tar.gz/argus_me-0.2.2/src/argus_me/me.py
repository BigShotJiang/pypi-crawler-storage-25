"""Me class — single entry point for argus-me."""

from datetime import date as _date_today_cls
from datetime import datetime, timezone

from .etl import run_pipeline
from .report import generate_report
from .models import (
    batch_import_entities,
    dismiss_matter_by_id,
    ensure_self,
    entity_stats as _entity_stats,
    expect_possibility,
    get_active_possibilities,
    get_all_entities,
    get_current_observations,
    get_epochs,
    get_latest_emotion,
    get_latest_gaps,
    get_open_matters,
    query_entities as _query_entities,
    get_pending_insights,
    get_recent_runs,
    init_db,
    merge_entities,
    read_self_profile,
    register_alias,
    set_matter_priorities,
    update_entity_metadata as _update_entity_metadata,
    update_entity_note,
    update_self_profile,
    write_fragment,
    write_observation,
)


class Me:
    """Personal cognitive engine.

    One class. Six parameters. A name, a memory, a brain,
    a privacy setting, and an optional cognitive style.
    """

    def __init__(
        self,
        name: str,
        db_path: str,
        llm_base_url: str,
        llm_model: str,
        llm_api_key: str = "ollama",
        redact: bool = False,
        prompt_dir: str | None = None,
        adversarial_probe: bool = False,
        compliance_profile: str = "personal",
    ):
        self.name = name
        self.db_path = db_path
        self.llm_base_url = llm_base_url
        self.llm_model = llm_model
        self.llm_api_key = llm_api_key
        self.redact = redact
        self.prompt_dir = prompt_dir
        self.adversarial_probe = adversarial_probe
        self.compliance_profile = compliance_profile

        init_db(db_path)
        ensure_self(db_path, name)

    # ── Input ──────────────────────────────────────────────

    def ingest(
        self, text: str, date: str | None = None, metadata: dict | None = None
    ) -> str:
        """Feed a text fragment into the system. Returns fragment ID."""
        if date is None:
            date = _date_today_cls.today().isoformat()
        return write_fragment(
            self.db_path, text=text, date=date, metadata=metadata
        )

    # ── Processing ─────────────────────────────────────────

    def understand(self) -> dict:
        """Process unprocessed fragments through the 4-call LLM pipeline."""
        return run_pipeline(
            self.db_path,
            llm_base_url=self.llm_base_url,
            llm_model=self.llm_model,
            llm_api_key=self.llm_api_key,
            prompt_dir=self.prompt_dir,
            redact=self.redact,
            adversarial_probe=self.adversarial_probe,
        )

    # ── User interactions (each auto-records a cognitive fragment) ──

    def _record_action(self, transcript: str) -> str:
        """Record a cognitive fragment for a user action."""
        return write_fragment(
            self.db_path,
            text=transcript,
            date=_date_today_cls.today().isoformat(),
            fragment_type="action",
            source="user_action",
        )

    def dismiss(self, matter_id: int) -> None:
        """Dismiss a matter. Stop tracking this concern."""
        name = dismiss_matter_by_id(self.db_path, matter_id)
        self._record_action(f"User no longer tracking: {name}")

    def expect(self, possibility_id: str) -> None:
        """Mark a possibility as user-expected."""
        event = expect_possibility(self.db_path, possibility_id)
        self._record_action(f"User expects: {event}")

    def alias(self, name: str, entity_id: str | None = None) -> None:
        """Register a name alias. If entity_id is None, alias points to self."""
        target = entity_id or "self"
        register_alias(self.db_path, name, target)
        if target == "self":
            self._record_action(f"User confirmed: '{name}' is me")
        else:
            self._record_action(f"User confirmed: '{name}' is {target}")

    def merge(self, keep_id: str, absorb_id: str) -> None:
        """Merge two entities. Absorbed entity's data transfers to kept."""
        keep_name, absorb_name = merge_entities(self.db_path, keep_id, absorb_id)
        self._record_action(f"User merged {absorb_name} into {keep_name}")

    def note(self, entity_id: str, text: str) -> None:
        """Add a user note to an entity."""
        name = update_entity_note(self.db_path, entity_id, text)
        self._record_action(f"User noted on {name}: {text}")

    def edit_profile(self, text: str) -> None:
        """Replace the self-profile text. User edits are authoritative."""
        update_self_profile(self.db_path, text)
        write_observation(
            self.db_path,
            source="user",
            content=text,
            observation_type="trait",
            confidence=1.0,
        )
        self._record_action("User edited self-portrait")

    def import_entities(self, entities: list[dict]) -> int:
        """Batch import entities with metadata. Returns count imported."""
        count = batch_import_entities(self.db_path, entities)
        if count > 0:
            self._record_action(f"Batch imported {count} entities")
        return count

    def report(self, template_name: str) -> dict:
        """Generate a structured report. Read-only — no DB writes."""
        return generate_report(
            self.db_path,
            template_name,
            llm_base_url=self.llm_base_url,
            llm_model=self.llm_model,
            llm_api_key=self.llm_api_key,
            prompt_dir=self.prompt_dir,
        )

    def query_entities(
        self,
        where: dict | None = None,
        order_by: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """Query entities with metadata filters."""
        return _query_entities(
            self.db_path, where=where, order_by=order_by,
            limit=limit, offset=offset,
        )

    def entity_stats(self) -> dict:
        """Summary statistics about entities."""
        return _entity_stats(self.db_path)

    def update_entity_metadata(self, entity_id: str, data: dict) -> None:
        """Shallow merge data into entity metadata."""
        name = _update_entity_metadata(self.db_path, entity_id, data)
        self._record_action(f"Updated metadata for {name}")

    def prioritize(self, matter_ids: list[int]) -> None:
        """Set display priority for matters. First ID = highest."""
        set_matter_priorities(self.db_path, matter_ids)
        self._record_action(f"User prioritized matters: {matter_ids}")

    def answer(self, gap_id: str, response: str) -> None:
        """Respond to a cognitive gap."""
        self._record_action(f"User answered [{gap_id}]: {response}")

    # ── Output: snapshot ───────────────────────────────────

    def snapshot(self) -> dict:
        """Point-in-time cognitive snapshot."""
        latest = self.latest_run
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "self_profile": read_self_profile(self.db_path),
            "matters": get_open_matters(self.db_path),
            "entities": get_all_entities(self.db_path),
            "possibilities": get_active_possibilities(self.db_path),
            "emotion": get_latest_emotion(self.db_path),
            "gaps": get_latest_gaps(self.db_path),
            "summary": latest.get("summary", "") if latest else "",
            "conflict": latest.get("conflict", "") if latest else "",
        }

    # ── Output: live properties ────────────────────────────

    @property
    def matters(self) -> list[dict]:
        """Open matters."""
        return get_open_matters(self.db_path)

    @property
    def entities(self) -> list[dict]:
        """All entities (excluding self)."""
        return get_all_entities(self.db_path)

    @property
    def possibilities(self) -> list[dict]:
        """Active possibilities."""
        return get_active_possibilities(self.db_path)

    @property
    def self_profile(self) -> str:
        """Current self-understanding text."""
        return read_self_profile(self.db_path)

    @property
    def gaps(self) -> list:
        """Gaps from the latest run."""
        return get_latest_gaps(self.db_path)

    @property
    def runs(self) -> list[dict]:
        """Recent run summaries."""
        return get_recent_runs(self.db_path)

    @property
    def latest_run(self) -> dict | None:
        """Most recent run, or None if no runs yet."""
        runs = get_recent_runs(self.db_path, limit=1)
        return runs[0] if runs else None

    @property
    def insights(self) -> list[dict]:
        """Pending insights from the subconscious."""
        return get_pending_insights(self.db_path)

    @property
    def epochs(self) -> list[dict]:
        """Memory epochs, most recent first."""
        return get_epochs(self.db_path, limit=100)

    @property
    def observations(self) -> list[dict]:
        """Current (non-superseded) self-knowledge observations."""
        return get_current_observations(self.db_path)
