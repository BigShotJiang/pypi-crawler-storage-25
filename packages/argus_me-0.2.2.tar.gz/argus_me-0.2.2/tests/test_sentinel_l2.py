"""Tests for sentinel L2 — metadata scanning + LLM semantic interpretation."""

import json
from datetime import date, timedelta

from conftest import make_mock_llm


def _make_me_with_entities(tmp_path):
    from argus_me import Me

    me = Me(
        name="XX Store",
        db_path=str(tmp_path / "memory.db"),
        llm_base_url="http://localhost:11434/v1",
        llm_model="qwen2.5:32b",
    )
    me.edit_profile("我是XX儿童摄影店，关注到店率和客户留存")
    me.import_entities([
        {"name": "张妈妈", "metadata": {
            "balance": 3000,
            "last_visit": (date.today() - timedelta(days=45)).isoformat(),
        }},
        {"name": "李爸爸", "metadata": {
            "balance": 5000,
            "last_visit": (date.today() - timedelta(days=5)).isoformat(),
        }},
        {"name": "王奶奶", "metadata": {
            "balance": 800,
            "last_visit": (date.today() - timedelta(days=60)).isoformat(),
        }},
    ])
    return me


class TestMetadataScan:
    """L1 metadata scanning based on cached rules."""

    def test_should_scan_with_rules(self, tmp_path):
        from argus_me.sentinel import scan_metadata_rules

        me = _make_me_with_entities(tmp_path)

        rules = [
            {
                "field": "metadata.last_visit",
                "condition": "older_than_days",
                "threshold": 30,
            },
        ]
        results = scan_metadata_rules(me.db_path, rules)
        names = {r["entity_name"] for r in results}
        assert "张妈妈" in names
        assert "王奶奶" in names
        assert "李爸爸" not in names

    def test_should_handle_empty_rules(self, tmp_path):
        from argus_me.sentinel import scan_metadata_rules

        me = _make_me_with_entities(tmp_path)
        results = scan_metadata_rules(me.db_path, [])
        assert results == []

    def test_should_handle_greater_than_rule(self, tmp_path):
        from argus_me.sentinel import scan_metadata_rules

        me = _make_me_with_entities(tmp_path)

        rules = [
            {
                "field": "metadata.balance",
                "condition": "greater_than",
                "threshold": 2000,
            },
        ]
        results = scan_metadata_rules(me.db_path, rules)
        names = {r["entity_name"] for r in results}
        assert "张妈妈" in names
        assert "李爸爸" in names
        assert "王奶奶" not in names


class TestSentinelL2:
    """L2 semantic layer — LLM interprets L1 anomalies."""

    def test_should_produce_insights_from_anomalies(self, tmp_path, monkeypatch):
        from argus_me.sentinel import run_sentinel_l2

        me = _make_me_with_entities(tmp_path)

        anomalies = [
            {"entity_name": "张妈妈", "rule": "last_visit > 30 days", "value": "45 days"},
            {"entity_name": "王奶奶", "rule": "last_visit > 30 days", "value": "60 days"},
        ]

        monkeypatch.setattr(
            "argus_me.sentinel.call_llm",
            make_mock_llm(responses=[json.dumps({
                "insights": [
                    {"description": "两位客户长期未到店，可能需要邀约", "priority": "high"},
                ],
            })]),
        )

        insights = run_sentinel_l2(
            me.db_path, anomalies,
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )
        assert len(insights) >= 1

    def test_should_return_empty_when_no_anomalies(self, tmp_path):
        from argus_me.sentinel import run_sentinel_l2

        me = _make_me_with_entities(tmp_path)
        insights = run_sentinel_l2(
            me.db_path, [],
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )
        assert insights == []
