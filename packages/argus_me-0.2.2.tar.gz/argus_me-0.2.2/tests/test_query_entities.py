"""Tests for entities batch query API."""

import json


def _seed_entities(me):
    me.import_entities([
        {"name": "张妈妈", "metadata": {"balance": 3000, "last_visit": "2026-03-01", "stage": "百天"}},
        {"name": "李爸爸", "metadata": {"balance": 5000, "last_visit": "2026-02-15", "stage": "周岁"}},
        {"name": "王奶奶", "metadata": {"balance": 800, "last_visit": "2026-03-28", "stage": "满月"}},
        {"name": "赵妈妈", "metadata": {"balance": 12000, "last_visit": "2026-01-10", "stage": "百天"}},
        {"name": "陈爸爸", "metadata": {"balance": 200, "last_visit": "2026-03-25", "stage": "周岁"}},
    ])


class TestQueryEntities:
    """me.query_entities() with filters."""

    def test_should_return_all_with_no_filter(self, me):
        _seed_entities(me)
        results = me.query_entities()
        assert len(results) == 5

    def test_should_filter_by_metadata_gt(self, me):
        _seed_entities(me)
        results = me.query_entities(
            where={"metadata.balance__gt": 1000}
        )
        names = {e["canonical_name"] for e in results}
        assert "张妈妈" in names
        assert "李爸爸" in names
        assert "赵妈妈" in names
        assert "陈爸爸" not in names

    def test_should_filter_by_metadata_lt(self, me):
        _seed_entities(me)
        results = me.query_entities(
            where={"metadata.balance__lt": 1000}
        )
        names = {e["canonical_name"] for e in results}
        assert "王奶奶" in names
        assert "陈爸爸" in names
        assert "张妈妈" not in names

    def test_should_filter_by_metadata_eq(self, me):
        _seed_entities(me)
        results = me.query_entities(
            where={"metadata.stage__eq": "百天"}
        )
        assert len(results) == 2

    def test_should_support_limit_and_offset(self, me):
        _seed_entities(me)
        page1 = me.query_entities(limit=2, offset=0)
        page2 = me.query_entities(limit=2, offset=2)
        assert len(page1) == 2
        assert len(page2) == 2
        assert page1[0]["canonical_name"] != page2[0]["canonical_name"]

    def test_should_order_by_metadata_field(self, me):
        _seed_entities(me)
        results = me.query_entities(
            order_by="metadata.balance DESC"
        )
        balances = [
            json.loads(e["metadata"]).get("balance", 0) for e in results
        ]
        assert balances == sorted(balances, reverse=True)

    def test_should_combine_filters(self, me):
        _seed_entities(me)
        results = me.query_entities(
            where={
                "metadata.balance__gt": 1000,
                "metadata.stage__eq": "百天",
            }
        )
        assert len(results) == 2
        names = {e["canonical_name"] for e in results}
        assert names == {"张妈妈", "赵妈妈"}

    def test_should_return_empty_for_no_match(self, me):
        _seed_entities(me)
        results = me.query_entities(
            where={"metadata.balance__gt": 100000}
        )
        assert results == []

    def test_should_reject_invalid_operator(self, me):
        import pytest

        _seed_entities(me)
        with pytest.raises(ValueError, match="operator"):
            me.query_entities(where={"metadata.balance__drop": 1})


class TestEntityStats:
    """me.entity_stats() summary statistics."""

    def test_should_return_total_count(self, me):
        _seed_entities(me)
        stats = me.entity_stats()
        assert stats["total"] == 5

    def test_should_return_zero_for_empty(self, me):
        stats = me.entity_stats()
        assert stats["total"] == 0
