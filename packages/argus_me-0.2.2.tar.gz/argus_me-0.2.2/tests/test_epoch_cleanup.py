"""Tests for epoch cleanup — observations dedup, supersession, stale decay."""

from argus_me.models import (
    connect,
    get_current_observations,
    write_observation,
)


def _make_db(tmp_path):
    from argus_me.models import ensure_self, init_db

    db_path = str(tmp_path / "memory.db")
    init_db(db_path)
    ensure_self(db_path, "Wang Yu")
    return db_path


class TestApplyObservationCleanup:
    """Deterministic cleanup from Call 0 signals."""

    def test_should_mark_duplicate_as_superseded(self, tmp_path):
        from argus_me.etl import apply_observation_cleanup

        db_path = _make_db(tmp_path)
        id1 = write_observation(db_path, source="call_3", content="Delays decisions")
        id2 = write_observation(db_path, source="call_3", content="Delays decisions often")

        apply_observation_cleanup(
            db_path,
            {
                "duplicate": [{"obsolete_id": id1, "keep_id": id2}],
            },
        )

        obs = get_current_observations(db_path)
        assert len(obs) == 1
        assert obs[0]["id"] == id2

    def test_should_mark_superseded_observation(self, tmp_path):
        from argus_me.etl import apply_observation_cleanup

        db_path = _make_db(tmp_path)
        id1 = write_observation(db_path, source="call_3", content="Hesitant", confidence=0.6)
        id2 = write_observation(db_path, source="call_3", content="Decisive", confidence=0.7)

        apply_observation_cleanup(
            db_path,
            {
                "superseded": [{"old_id": id1, "new_id": id2}],
            },
        )

        obs = get_current_observations(db_path)
        assert len(obs) == 1
        assert obs[0]["content"] == "Decisive"

    def test_should_decay_stale_confidence(self, tmp_path):
        from argus_me.etl import apply_observation_cleanup

        db_path = _make_db(tmp_path)
        oid = write_observation(
            db_path,
            source="call_3",
            content="Old pattern",
            observation_type="pattern",
            confidence=0.8,
        )

        apply_observation_cleanup(db_path, {"stale": [oid]})

        conn = connect(db_path)
        row = conn.execute("SELECT confidence FROM observations WHERE id=?", (oid,)).fetchone()
        assert row["confidence"] == 0.4  # 0.8 * 0.5
        conn.close()

    def test_should_never_delete_observations(self, tmp_path):
        from argus_me.etl import apply_observation_cleanup

        db_path = _make_db(tmp_path)
        write_observation(db_path, source="call_3", content="Obs 1")
        write_observation(db_path, source="call_3", content="Obs 2")
        write_observation(db_path, source="call_3", content="Obs 3")

        apply_observation_cleanup(
            db_path,
            {
                "duplicate": [{"obsolete_id": 1, "keep_id": 2}],
                "stale": [3],
            },
        )

        conn = connect(db_path)
        total = conn.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
        assert total == 3  # none deleted
        conn.close()

    def test_should_handle_empty_cleanup(self, tmp_path):
        from argus_me.etl import apply_observation_cleanup

        db_path = _make_db(tmp_path)
        apply_observation_cleanup(db_path, {})  # no-op, no crash
