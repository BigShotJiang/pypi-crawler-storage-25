"""Tests for Phase 3: deadline, report, compliance_profile."""

import json
from datetime import date, timedelta

from conftest import insert_matter, make_mock_llm


class TestMattersDeadline:
    """matters.deadline column + urgency."""

    def test_should_store_deadline(self, me):
        from argus_me.models import connect, write_matters

        write_matters(
            me.db_path,
            [{"name": "Launch", "current": "Planning", "who": [], "deadline": "2026-04-10"}],
            date="2026-04-01",
        )
        conn = connect(me.db_path)
        row = conn.execute("SELECT deadline FROM matters WHERE name='Launch'").fetchone()
        assert row["deadline"] == "2026-04-10"
        conn.close()

    def test_should_allow_null_deadline(self, me):
        from argus_me.models import connect, write_matters

        write_matters(
            me.db_path,
            [{"name": "No deadline", "current": "Open", "who": []}],
            date="2026-04-01",
        )
        conn = connect(me.db_path)
        row = conn.execute("SELECT deadline FROM matters WHERE name='No deadline'").fetchone()
        assert row["deadline"] is None
        conn.close()


class TestReport:
    """me.report(template_name) — structured report generation."""

    def test_should_generate_report(self, me, monkeypatch):
        me.ingest("Today was productive.")
        monkeypatch.setattr(
            "argus_me.etl.call_llm", make_mock_llm(),
        )
        me.understand()

        monkeypatch.setattr(
            "argus_me.report.call_llm",
            make_mock_llm(responses=[json.dumps({
                "title": "Daily Review",
                "summary": "Productive day.",
                "actions": ["Follow up with Tom"],
            })]),
        )

        result = me.report("daily_review")
        assert result["title"] == "Daily Review"
        assert "actions" in result

    def test_should_use_custom_template(self, me, tmp_path, monkeypatch):
        (tmp_path / "report_custom.j2").write_text(
            "Generate report.\n{{ snapshot }}\nOutput JSON: {\"result\": \"ok\"}"
        )
        me_custom = me.__class__(
            name="Test",
            db_path=me.db_path,
            llm_base_url=me.llm_base_url,
            llm_model=me.llm_model,
            prompt_dir=str(tmp_path),
        )
        monkeypatch.setattr(
            "argus_me.report.call_llm",
            make_mock_llm(responses=[json.dumps({"result": "ok"})]),
        )
        result = me_custom.report("custom")
        assert result["result"] == "ok"

    def test_report_should_not_modify_db(self, me, monkeypatch):
        from argus_me.models import connect

        monkeypatch.setattr(
            "argus_me.report.call_llm",
            make_mock_llm(responses=[json.dumps({"title": "Test"})]),
        )
        conn = connect(me.db_path)
        frag_before = conn.execute("SELECT COUNT(*) FROM fragments").fetchone()[0]
        conn.close()

        me.report("daily_review")

        conn = connect(me.db_path)
        frag_after = conn.execute("SELECT COUNT(*) FROM fragments").fetchone()[0]
        conn.close()
        assert frag_after == frag_before


class TestComplianceProfile:
    """Me(compliance_profile=...) configurable rules."""

    def test_should_use_personal_profile_by_default(self, tmp_path):
        from argus_me import Me

        me = Me(
            name="Test",
            db_path=str(tmp_path / "memory.db"),
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )
        assert me.compliance_profile == "personal"

    def test_should_accept_business_profile(self, tmp_path):
        from argus_me import Me

        me = Me(
            name="Store",
            db_path=str(tmp_path / "memory.db"),
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
            compliance_profile="business",
        )
        assert me.compliance_profile == "business"

    def test_business_profile_should_not_block_clinical_terms(self, tmp_path):
        from argus_me import Me
        from argus_me.models import get_current_observations, write_observation

        me = Me(
            name="Store",
            db_path=str(tmp_path / "memory.db"),
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
            compliance_profile="business",
        )
        # Business profile should not block clinical terms
        write_observation(
            me.db_path,
            source="call_3",
            content="客户提到焦虑症相关话题",
            compliance_profile="business",
        )
        obs = get_current_observations(me.db_path)
        assert len(obs) == 1
