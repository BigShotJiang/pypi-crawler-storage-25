"""Tests for P0: fragments.metadata consumption + ingest metadata param."""

import json

from conftest import make_mock_llm

from argus_me.models import connect, get_unprocessed_fragments


class TestIngestMetadata:
    """me.ingest() with metadata parameter."""

    def test_should_store_metadata_in_fragment(self, me):
        me.ingest("Daily report", metadata={"revenue": 120000, "complaints": 2})

        frags = get_unprocessed_fragments(me.db_path)
        assert len(frags) == 1
        meta = json.loads(frags[0]["metadata"])
        assert meta["revenue"] == 120000
        assert meta["complaints"] == 2

    def test_should_default_to_empty_metadata(self, me):
        me.ingest("No metadata")

        frags = get_unprocessed_fragments(me.db_path)
        assert json.loads(frags[0]["metadata"]) == {}

    def test_should_inject_metadata_into_call2_prompt(self, me, monkeypatch):
        me.ingest("Daily report", metadata={
            "revenue": 120000, "new_clients": 8, "visit_rate": 0.62,
        })

        prompts = []
        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(capture=prompts),
        )
        me.understand()

        call2_prompt = prompts[1]
        assert "revenue" in call2_prompt
        assert "120000" in call2_prompt


class TestImportEntities:
    """me.import_entities() batch import."""

    def test_should_import_entities_with_metadata(self, me):
        me.import_entities([
            {"name": "张妈妈", "metadata": {"balance": 3000, "stage": "百天"}},
            {"name": "李爸爸", "metadata": {"balance": 5000, "stage": "周岁"}},
        ])

        entities = me.entities
        names = {e["canonical_name"] for e in entities}
        assert "张妈妈" in names
        assert "李爸爸" in names

    def test_should_merge_on_existing_entity(self, me):
        me.import_entities([
            {"name": "张妈妈", "metadata": {"balance": 3000}},
        ])
        me.import_entities([
            {"name": "张妈妈", "metadata": {"balance": 2500, "new_field": "x"}},
        ])

        conn = connect(me.db_path)
        row = conn.execute(
            "SELECT metadata FROM entities WHERE canonical_name='张妈妈'"
        ).fetchone()
        meta = json.loads(row["metadata"])
        assert meta["balance"] == 2500  # overwritten
        assert meta["new_field"] == "x"  # merged
        conn.close()

    def test_should_record_action_fragment(self, me):
        from conftest import count_action_fragments

        me.import_entities([
            {"name": "A"}, {"name": "B"}, {"name": "C"},
        ])
        assert count_action_fragments(me.db_path) == 1

    def test_should_handle_empty_list(self, me):
        me.import_entities([])  # no crash

    def test_should_not_create_duplicate_entities(self, me):
        me.import_entities([
            {"name": "Tom", "metadata": {"balance": 100}},
            {"name": "Tom", "metadata": {"balance": 200}},
        ])
        entities = [e for e in me.entities if e["canonical_name"] == "Tom"]
        assert len(entities) == 1

    def test_should_use_single_transaction(self, me):
        """Performance: bulk import should not commit per entity."""
        # Import 100 entities — should be fast (single transaction)
        data = [{"name": f"Entity_{i}", "metadata": {"id": i}} for i in range(100)]
        me.import_entities(data)
        assert len(me.entities) == 100
