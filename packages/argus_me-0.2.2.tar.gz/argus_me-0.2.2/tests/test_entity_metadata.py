"""Tests for update_entity_metadata explicit API."""

import json

from conftest import get_entity_id


class TestUpdateEntityMetadata:
    """me.update_entity_metadata(entity_id, data)."""

    def test_should_update_metadata(self, me):
        from argus_me.models import connect

        me.import_entities([{"name": "Tom", "metadata": {"balance": 100}}])
        eid = get_entity_id(me.db_path, "Tom")
        me.update_entity_metadata(eid, {"balance": 200, "vip": True})

        conn = connect(me.db_path)
        row = conn.execute(
            "SELECT metadata FROM entities WHERE id=?", (eid,)
        ).fetchone()
        meta = json.loads(row["metadata"])
        assert meta["balance"] == 200
        assert meta["vip"] is True
        conn.close()

    def test_should_shallow_merge(self, me):
        me.import_entities([
            {"name": "Tom", "metadata": {"a": 1, "b": 2}},
        ])
        eid = get_entity_id(me.db_path, "Tom")
        me.update_entity_metadata(eid, {"b": 99, "c": 3})

        from argus_me.models import connect

        conn = connect(me.db_path)
        meta = json.loads(
            conn.execute(
                "SELECT metadata FROM entities WHERE id=?", (eid,)
            ).fetchone()["metadata"]
        )
        assert meta == {"a": 1, "b": 99, "c": 3}
        conn.close()

    def test_should_record_fragment(self, me):
        from conftest import count_action_fragments

        me.import_entities([{"name": "Tom"}])
        eid = get_entity_id(me.db_path, "Tom")
        me.update_entity_metadata(eid, {"balance": 500})
        # import_entities records 1 fragment, update_entity_metadata records another
        assert count_action_fragments(me.db_path) == 2
