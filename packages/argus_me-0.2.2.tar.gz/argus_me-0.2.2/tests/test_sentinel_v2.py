"""Tests for sentinel v2 — missing debt + antibias scanners."""

from datetime import date, timedelta

from argus_me.models import connect, write_possibilities
from conftest import insert_matter, insert_run


def _make_db(tmp_path):
    from argus_me.models import ensure_self, init_db

    db_path = str(tmp_path / "memory.db")
    init_db(db_path)
    ensure_self(db_path, "Wang Yu")
    return db_path


class TestScanUnconfirmedEntities:
    """Entity with high interaction but no note and not in any matter."""

    def test_should_detect_unconfirmed_entity(self, tmp_path):
        from argus_me.sentinel import scan_debts

        db_path = _make_db(tmp_path)
        # Insert entity with 3+ interactions but no note, not in any matter
        conn = connect(db_path)
        conn.execute(
            "INSERT INTO entities"
            " (id, canonical_name, dynamics, interaction_count,"
            " first_seen, last_seen, note, created_at, updated_at)"
            " VALUES ('e1', 'Mystery Person', 0.0, 5,"
            " '2026-01-01', '2026-03-30', '', '2026-01-01', '2026-03-30')"
        )
        conn.commit()
        conn.close()

        insights = scan_debts(db_path)
        unconfirmed = [i for i in insights if i["type"] == "unconfirmed_entity"]
        assert len(unconfirmed) >= 1
        assert "Mystery Person" in unconfirmed[0]["description"]


class TestScanHighFreqEntities:
    """Entity mentioned far more than usual this week."""

    def test_should_detect_high_freq_entity(self, tmp_path):
        from argus_me.sentinel import scan_debts

        db_path = _make_db(tmp_path)
        today = date.today()
        # Entity with low historical average but high recent mentions
        conn = connect(db_path)
        conn.execute(
            "INSERT INTO entities"
            " (id, canonical_name, dynamics, interaction_count,"
            " first_seen, last_seen, note, created_at, updated_at)"
            " VALUES ('e1', 'Tom', 0.0, 3,"
            " '2026-01-01', ?, '', '2026-01-01', ?)",
            (today.isoformat(), today.isoformat()),
        )
        conn.commit()
        conn.close()
        # Many recent runs mentioning Tom
        for i in range(5):
            d = (today - timedelta(days=i)).isoformat()
            insert_run(db_path, run_date=d, summary=f"Met Tom, discussed day {i}")

        insights = scan_debts(db_path)
        # May or may not trigger depending on ratio
        assert isinstance(insights, list)


class TestScanRelationshipGaps:
    """Entity with interaction gap exceeding statistical threshold."""

    def test_should_detect_relationship_gap(self, tmp_path):
        from argus_me.sentinel import scan_debts

        db_path = _make_db(tmp_path)
        today = date.today()
        # Entity seen long ago, not recently
        conn = connect(db_path)
        old = (today - timedelta(days=30)).isoformat()
        conn.execute(
            "INSERT INTO entities"
            " (id, canonical_name, dynamics, interaction_count,"
            " first_seen, last_seen, note, created_at, updated_at)"
            " VALUES ('e1', 'Old Friend', 0.3, 10,"
            " '2025-01-01', ?, '', '2025-01-01', ?)",
            (old, old),
        )
        conn.commit()
        conn.close()

        insights = scan_debts(db_path)
        assert isinstance(insights, list)


class TestScanInsightConcentration:
    """More than 60% of recent possibilities focus on same matter."""

    def test_should_detect_concentration(self, tmp_path):
        from argus_me.sentinel import scan_antibias

        db_path = _make_db(tmp_path)
        insert_matter(db_path, "Hot topic", opened_date="2026-03-01")
        insert_matter(db_path, "Other topic", opened_date="2026-03-01")

        conn = connect(db_path)
        matter_id_hot = conn.execute("SELECT id FROM matters WHERE name='Hot topic'").fetchone()[
            "id"
        ]
        matter_id_other = conn.execute(
            "SELECT id FROM matters WHERE name='Other topic'"
        ).fetchone()["id"]
        conn.close()

        # 8 possibilities on hot topic, 2 on other
        for i in range(8):
            write_possibilities(
                db_path,
                [{"matter_id": matter_id_hot, "event": f"Hot {i}"}],
                run_id=f"run-{i}",
            )
        for i in range(2):
            write_possibilities(
                db_path,
                [{"matter_id": matter_id_other, "event": f"Other {i}"}],
                run_id=f"run-other-{i}",
            )

        insights = scan_antibias(db_path)
        concentration = [i for i in insights if i["type"] == "insight_concentration"]
        assert len(concentration) >= 1


class TestSemanticShift:
    """Semantic shift detection between run groups."""

    def test_should_return_float(self, tmp_path, monkeypatch):
        import json

        from argus_me.etl import semantic_shift

        db_path = _make_db(tmp_path)
        today = date.today()
        for i in range(8):
            insert_run(
                db_path,
                run_date=(today - timedelta(days=8 - i)).isoformat(),
                summary=f"Topic {i}",
            )

        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            lambda *a, **kw: (json.dumps({"similarity": 0.3}), {}),
        )

        shift = semantic_shift(db_path, "http://localhost:11434/v1", "qwen2.5:32b")
        assert 0.0 <= shift <= 1.0
        assert shift == 0.7  # 1.0 - 0.3

    def test_should_return_zero_when_insufficient_runs(self, tmp_path):
        from argus_me.etl import semantic_shift

        db_path = _make_db(tmp_path)
        insert_run(db_path, run_date="2026-03-28", summary="Only one")

        shift = semantic_shift(db_path, "http://localhost:11434/v1", "qwen2.5:32b")
        assert shift == 0.0
