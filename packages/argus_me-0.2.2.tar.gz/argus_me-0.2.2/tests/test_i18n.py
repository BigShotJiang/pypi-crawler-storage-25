"""Tests for semantic_shift wired into should_consolidate."""

from datetime import date, timedelta

from conftest import insert_run


class TestSemanticShiftInTrigger:
    """semantic_shift wired into should_consolidate."""

    def test_should_trigger_on_semantic_shift(self, tmp_path, monkeypatch):
        from argus_me.etl import should_consolidate
        from argus_me.models import ensure_self, init_db

        db_path = str(tmp_path / "memory.db")
        init_db(db_path)
        ensure_self(db_path, "Test")

        today = date.today()
        for i in range(10):
            insert_run(
                db_path,
                run_date=(today - timedelta(days=10 - i)).isoformat(),
                summary=f"Topic {i}",
            )

        monkeypatch.setattr(
            "argus_me.etl._semantic_shift_score",
            lambda path: 0.8,
        )

        result = should_consolidate(db_path)
        assert result is not None
