"""Tests for compliance gate — deterministic safety checks before DB writes."""


class TestComplianceCheck:
    """compliance_check() — regex-based safety validation."""

    def test_should_block_chinese_clinical_terms(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("用户可能患有焦虑症的早期症状")
        assert not result.passed
        assert any("CLINICAL" in v for v in result.violations)
        assert result.sanitized is None

    def test_should_block_english_clinical_terms(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("User may be suffering from PTSD based on avoidance patterns")
        assert not result.passed
        assert any("CLINICAL" in v for v in result.violations)
        assert result.sanitized is None

    def test_should_downgrade_chinese_inference(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("你有明显的逃避倾向")
        assert not result.passed
        assert any("INFERENCE" in v for v in result.violations)
        assert result.sanitized is not None

    def test_should_downgrade_english_inference(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("you are avoiding conflict")
        assert not result.passed
        assert any("INFERENCE" in v for v in result.violations)
        assert result.sanitized is not None

    def test_should_pass_behavioral_chinese(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("过去两周中有5次在讨论项目预算时转换话题")
        assert result.passed

    def test_should_pass_behavioral_english(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("Mentioned career change 3 times in the last 4 runs")
        assert result.passed

    def test_should_handle_empty_string(self):
        from argus_me.compliance import compliance_check

        result = compliance_check("")
        assert result.passed


class TestComplianceInObservations:
    """Compliance gate integrated with write_observation."""

    def test_should_block_clinical_observation(self, memory_db):
        from argus_me.models import get_current_observations, write_observation

        result = write_observation(
            memory_db,
            source="call_3",
            content="诊断为社交焦虑症",
        )
        assert result is None
        assert get_current_observations(memory_db) == []

    def test_should_downgrade_inference_observation(self, memory_db):
        from argus_me.models import get_current_observations, write_observation

        write_observation(
            memory_db,
            source="call_3",
            content="你有回避倾向",
            observation_type="trait",
            confidence=0.8,
        )
        obs = get_current_observations(memory_db)
        assert len(obs) == 1
        assert obs[0]["observation_type"] == "behavior"
        assert obs[0]["confidence"] <= 0.2

    def test_should_write_clean_observation(self, memory_db):
        from argus_me.models import get_current_observations, write_observation

        write_observation(
            memory_db,
            source="call_3",
            content="过去一周推迟了3次决策",
        )
        obs = get_current_observations(memory_db)
        assert len(obs) == 1
        assert obs[0]["confidence"] == 0.5


class TestComplianceInSelfProfile:
    """Compliance gate integrated with append_self_profile."""

    def test_should_block_clinical_delta(self, memory_db):
        from argus_me.models import append_self_profile, ensure_self, read_self_profile

        ensure_self(memory_db, "Test")
        append_self_profile(memory_db, ["诊断为抑郁症"])
        profile = read_self_profile(memory_db)
        assert "抑郁症" not in profile

    def test_should_keep_clean_delta(self, memory_db):
        from argus_me.models import append_self_profile, ensure_self, read_self_profile

        ensure_self(memory_db, "Test")
        append_self_profile(memory_db, ["Software engineer"])
        profile = read_self_profile(memory_db)
        assert "Software engineer" in profile


class TestComplianceLog:
    """Violations should be logged to compliance_log table."""

    def test_should_log_blocked_observation(self, memory_db):
        from argus_me.models import connect, write_observation

        write_observation(
            memory_db,
            source="call_3",
            content="患有强迫症",
        )
        conn = connect(memory_db)
        logs = conn.execute("SELECT * FROM compliance_log").fetchall()
        assert len(logs) == 1
        assert logs[0]["action"] == "observation_blocked"
        conn.close()

    def test_should_log_downgraded_observation(self, memory_db):
        from argus_me.models import connect, write_observation

        write_observation(
            memory_db,
            source="call_3",
            content="你有回避倾向",
            observation_type="trait",
            confidence=0.8,
        )
        conn = connect(memory_db)
        logs = conn.execute("SELECT * FROM compliance_log").fetchall()
        assert len(logs) == 1
        assert logs[0]["action"] == "observation_downgraded"
        conn.close()
