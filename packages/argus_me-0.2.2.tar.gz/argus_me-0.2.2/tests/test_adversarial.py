"""Tests for adversarial probe — challenge high-confidence observations."""

import json

from conftest import make_mock_llm, seed_history


class TestAdversarialProbe:
    """Probe high-confidence patterns for contradictions."""

    def test_should_probe_high_confidence_pattern(self, me, monkeypatch):
        from argus_me.etl import run_adversarial_probe as adversarial_probe

        seed_history(me.db_path)

        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=[json.dumps({
                "contradictions_found": True,
                "evidence": "Run from 2026-03-28 shows active engagement",
                "revised_confidence": 0.4,
                "reasoning": "Evidence of opposite behavior found",
            })]),
        )

        result = adversarial_probe(
            me.db_path,
            observation={"content": "Always avoids conflict", "confidence": 0.8},
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )

        assert result["contradictions_found"] is True
        assert result["revised_confidence"] < 0.8

    def test_should_return_no_contradictions_when_none_found(self, me, monkeypatch):
        from argus_me.etl import run_adversarial_probe as adversarial_probe

        seed_history(me.db_path)

        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=[json.dumps({
                "contradictions_found": False,
                "evidence": "",
                "revised_confidence": 0.8,
                "reasoning": "No contradicting evidence in history",
            })]),
        )

        result = adversarial_probe(
            me.db_path,
            observation={"content": "Values autonomy", "confidence": 0.8},
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )

        assert result["contradictions_found"] is False
        assert result["revised_confidence"] == 0.8


class TestAdversarialInPipeline:
    """Pipeline integration — probe triggers for high-confidence observations."""

    def test_should_probe_in_pipeline_when_enabled(self, tmp_path, monkeypatch):
        from argus_me import Me
        from argus_me.models import get_current_observations

        me = Me(
            name="Test",
            db_path=str(tmp_path / "memory.db"),
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
            adversarial_probe=True,
        )
        me.ingest("Test fragment.")

        call_count = {"n": 0}

        def tracking_llm(client, model, prompt, **kwargs):
            call_count["n"] += 1
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps({
                    "summary": "Test.",
                    "conflict": "",
                    "emotion": "neutral",
                    "valence": 0.0,
                    "arousal": 0.3,
                    "persons": [],
                    "new_matters": [],
                    "dismissed": [],
                    "gaps": [],
                }),
                json.dumps({
                    "conflict": "",
                    "gaps": [],
                    "self_observations": [
                        {
                            "content": "High confidence pattern",
                            "type": "pattern",
                            "confidence": 0.8,
                        },
                    ],
                }),
                json.dumps({
                    "contradictions_found": False,
                    "evidence": "",
                    "revised_confidence": 0.7,
                    "reasoning": "No contradictions",
                }),
                json.dumps([]),
            ]
            idx = min(call_count["n"] - 1, len(responses) - 1)
            return responses[idx], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", tracking_llm)
        me.understand()

        # Call 1 + Call 2 + Call 3 + probe = 4 (no Call 4 since no matters)
        assert call_count["n"] >= 4

    def test_should_not_probe_when_disabled(self, me, mock_llm):
        me.ingest("Test fragment.")
        me.understand()
        # Default: adversarial_probe=False, only 4 calls
        assert len(mock_llm) == 4
