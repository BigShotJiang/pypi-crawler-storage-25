# API Reference

The public interface of the `Me` class.

---

## Constructor

```python
me = Me(
    name="Wang Yu",
    db_path="./data/memory.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
    llm_api_key="ollama",
    redact=False,
    prompt_dir=None,
    adversarial_probe=False,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `name` | str | required | Entity name (person, store, team), used to create the self entity |
| `db_path` | str | required | Path to SQLite database file (created if missing) |
| `llm_base_url` | str | required | OpenAI-compatible API endpoint (Ollama, OpenAI, Groq, etc.) |
| `llm_model` | str | required | Model name for LLM calls |
| `llm_api_key` | str | `"ollama"` | API key for the LLM provider |
| `redact` | bool | `False` | If True, strips PII before LLM calls via argus-redact |
| `adversarial_probe` | bool | `False` | If True, challenge high-confidence pattern/trait observations |
| `prompt_dir` | str \| None | `None` | Custom prompt template directory (overrides built-in) |

The constructor creates the database file if it does not exist and runs schema migrations automatically.

> **Planned (v0.3)**: `compliance_profile` parameter, `import_entities()`, `query_entities()`, `report()` method. See [Roadmap](10-roadmap.md).

---

## Input

### me.ingest(text, date=None, metadata=None)

Feed a text fragment into the system. Can be called multiple times before `understand()`.

```python
# Personal use
me.ingest("今天和老板聊了项目进度", date="2026-03-15")

# Store use — with structured metadata (v0.3)
me.ingest("今天的日报", metadata={"revenue": 120000, "new_clients": 8})
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `text` | str | required | Fragment content (conversation, diary, report) |
| `date` | str \| None | today | Content date (YYYY-MM-DD). Use when content is from a past date. |
| `metadata` | dict \| None | None | Structured data attached to fragment. Injected into Call 2 prompt. (v0.3) |

Returns: fragment ID (str).

> **Note**: Fragment-level metadata (KPIs, metrics) is distinct from entity-level metadata. Fragment metadata describes a point-in-time snapshot; entity metadata describes persistent attributes. See [Roadmap](10-roadmap.md) for entity metadata support.

---

## Processing

### me.understand()

Process all unprocessed fragments through the 4-call LLM pipeline + subconscious.

```python
result = me.understand()
```

**Pipeline**: Each call to `understand()` executes:

1. **Trigger check** -- Should an epoch be created first? (run count / time gap)
2. **Call 0** (if triggered) -- Consolidate recent runs into an epoch + rebuild self_profile
3. **Call 1 (WHO)** -- Entity resolution, self-observation extraction
4. **Call 2 (WHAT)** -- Summary, emotion detection, matter updates, gap identification
5. **Call 3 (MEANING)** -- Pattern detection, self-model observations
6. **Call 4 (POSSIBILITIES)** -- Scenario narratives for open matters
7. **Subconscious** -- Sentinel scans, insight queuing, intention scanning

Epoch consolidation triggers on three signals: run count (8-20), time gap (>7 days), or semantic shift (>0.5 theme change between recent and prior runs).

**Returns** a dict:
```python
{
    "run_id": "uuid",
    "date": "2026-03-15",
    "summary": "...",
    "emotion": {"word": "...", "valence": -0.3, "arousal": 0.6},
    "conflict": "...",
    "fragments_processed": 2,
    "entities_updated": 3,
    "matters_updated": 1,
    "possibilities_generated": 4,
    "insights_found": 1,
}
```

With 0 unprocessed fragments, returns immediately (no LLM calls, subconscious still runs).

---

## Reading State

Properties that return current state. All are read-only, queried from the database on each access.

| Property | Returns | Description |
|----------|---------|-------------|
| `me.self_profile` | str | Current self-understanding text |
| `me.matters` | list[dict] | Open matters |
| `me.entities` | list[dict] | All entities (excluding self) |
| `me.possibilities` | list[dict] | Active scenario narratives |
| `me.insights` | list[dict] | Pending insights from the sentinel |
| `me.gaps` | list | Cognitive gaps from the latest run |
| `me.runs` | list[dict] | Recent run summaries |
| `me.latest_run` | dict \| None | Most recent run, or None |
| `me.epochs` | list[dict] | Memory epochs, newest first |
| `me.observations` | list[dict] | Current (non-superseded) self-knowledge observations |

### me.snapshot()

Point-in-time cognitive freeze. Returns a dict, not a file.

```python
snap = me.snapshot()
```

Returns:
```python
{
    "timestamp": "2026-03-15T22:30:00+00:00",
    "self_profile": "...",
    "matters": [...],
    "entities": [...],
    "possibilities": [...],
    "emotion": {"word": "...", "valence": 0.3, "arousal": 0.5},
    "gaps": [...],
    "summary": "...",
    "conflict": "...",
}
```

snapshot() is a photo -- frozen, timestamped. Live properties are a mirror -- always current.

---

## Actions

Every action method auto-creates a fragment recording the action itself. This closes the cognitive feedback loop.

### me.dismiss(matter_id)

Mark a matter as dismissed. The user is no longer tracking this concern.

```python
me.dismiss(42)
```

### me.expect(possibility_id)

Mark a possibility as user-expected. Expresses plans and intentions.

```python
me.expect("possibility-uuid")
```

### me.alias(name, entity_id=None)

Register a name alias. If `entity_id` is None, the alias points to self.

```python
me.alias("Professor Wang")                    # "Professor Wang" is me
me.alias("Tommy", entity_id="entity-uuid")    # "Tommy" is this entity
```

### me.merge(keep_id, absorb_id)

Merge two entities. Absorbed entity's aliases, matter connections, and notes transfer to the kept entity.

```python
me.merge(keep_id="entity-uuid-1", absorb_id="entity-uuid-2")
```

### me.note(entity_id, text)

Add a user note to an entity.

```python
me.note("entity-uuid", "Met at the conference. Sharp on distributed systems.")
```

### me.edit_profile(text)

Replace the self-profile text. User edits are authoritative. Also creates an observation with `source='user'`, `confidence=1.0`.

```python
me.edit_profile("Software engineer, transitioning to indie products.")
```

### me.prioritize(matter_ids)

Set display priority for matters by providing an ordered list. First ID = highest priority.

```python
me.prioritize([5, 12, 3])  # matter 5 highest, 3 lowest
```

### me.answer(gap_id, response)

Respond to a cognitive gap surfaced by the pipeline.

```python
me.answer("gap-uuid", "Yes, that project is still active.")
```

---

## The Action-Fragment Loop

Every action method automatically creates a fragment that records what the user did:

```
User calls me.dismiss(42)
  -> Fragment created: "User no longer tracking: career transition"
  -> Next understand() call sees this fragment in context
  -> System learns from the user's decisions
```

This is not logging. It is a deliberate design choice. When the user dismisses a matter, that tells the system something about the user's priorities. When the user edits their profile, that tells the system where its model was wrong. These signals are too valuable to discard.
