# Roadmap

Where argus-me is going, what it is deliberately not doing, and how we measure progress.

---

## v0.2 (Shipped)

**Theme**: Epoch memory + Telescoping + Observations + Safety compliance + Compliance gate

### Shipped Components

| Component | Version | What It Does |
|-----------|---------|-------------|
| Epochs + Call 0 | v0.1.5 | Compresses ~14 runs into a semantic memory unit with boundary markers |
| Mixed trigger | v0.2.1 | Consolidation fires on count (8-20), semantic shift (>0.5), or time gap (>7 days) |
| Telescoping context | v0.1.4 | Replaces fixed 5-run window with compressed epochs + full recent runs |
| Observations table | v0.1.4 | Typed, timestamped, evidence-linked atoms of self-knowledge |
| Self-profile rebuild | v0.1.5 | Cached narrative synthesis from observations at each epoch boundary |
| Path B compliance | v0.1.6 | Behavioral language only across all prompts |
| Sentinel completion | v0.1.6 | All 5 debt scanners + all 3 antibias scanners |
| Compliance gate | v0.2.1 | Deterministic regex check before all DB writes (compliance.py) |
| Epoch cleanup | v0.2.1 | Observations dedup, supersession, stale decay via Call 0 signals |
| Fork isolation | v0.2.1 | Speculative outputs isolated from fact base (documented principle) |
| Adversarial probe | v0.2.1 | Optional challenge of high-confidence observations (Me(adversarial_probe=True)) |

---

## v0.3 (Current Target)

**Theme**: From personal engine to general "Me" substrate. Any entity — person, store, team, fund — can be a Me instance.

### Phase 1 (P0)

| Component | What It Does |
|-----------|-------------|
| fragments.metadata consumption | Structured KPIs (revenue, visit_rate, etc.) injected into Call 2 prompt |
| Prompt variable generalization | Full variable API contract; templates decide which to consume |
| me.import_entities() | Batch import thousands of entities from CRM/external systems |

### Phase 2 (P1)

| Component | What It Does |
|-----------|-------------|
| entities.metadata column | JSON metadata on entities (customer attributes, portfolio metrics) |
| Sentinel L2 | self_profile-driven semantic scan with LLM interpretation of L1 anomalies |
| me.query_entities() | Filtered/sorted/paginated entity queries for large datasets |

### Phase 3 (P2)

| Component | What It Does |
|-----------|-------------|
| matters.deadline | Time pressure with configurable urgency window |
| me.report() | Structured report generation (independent report.py, read-only) |
| compliance_profile | Configurable compliance rules per domain (personal vs business) |

---

## Post-0.3 (Needs Data Validation)

These features are designed but deferred. They require real-world epoch data to validate before implementation.

### Dream System

Offline processing inspired by sleep neuroscience. Two channels:

- **NREM** (integration): Cross-epoch pattern extraction, detail deprioritization, conflict resolution. Low temperature (0.1-0.3). Produces the raw material.
- **REM** (creative hypothesis): Trisociation -- colliding a goal seed, a distant epoch theme, and a self-model signal to generate novel hypotheses. Higher temperature (0.5-0.7). Produces the surprises.

NREM must execute before REM (hard data dependency, not a preference).

**Gating condition**: Dream ships only after the epoch system demonstrates measurable ROI. If telescoping context does not produce meaningfully better outputs than the v0.1 5-run window, the Dream system's foundation is not justified.

### ACT Flexibility Detection

CompACT 3-factor behavioral observations (Openness to Experience / Behavioral Awareness / Valued Action) extracted from natural language fragments. Detects shifts in psychological flexibility over time using behavioral markers, never clinical assessment.

**Gating condition**: Requires 30+ epochs of data for reliable calibration. Cold-start period is deliberately long.

### CCR Rigidity Detection

Confirm-Challenge Ratio monitoring per self-model dimension. Detects when the system preferentially confirms its existing model of you rather than updating it.

- CCR > 0.9 triggers anti-bias intervention
- Trend matters more than absolute value
- Implemented as part of the subconscious layer

### Reverse Influence Audit

Detects when the system's observations create a feedback loop: the system tells you something about yourself, you internalize it, your future fragments confirm it, and the system's confidence rises -- based on evidence it manufactured.

Triggered when an observation's confidence rises steadily over 3+ epochs and its direction aligns with previously generated possibilities.

---

## v1.0+ (Distant Vision)

These require validated v0.2 and post-0.2 systems working in production.

### Hierarchical Consolidation

Mega-epochs: compressing epochs into higher-order memory units for users with years of data. The same compression principles apply, with stricter fact-anchor requirements to prevent cumulative drift.

### Multi-Modal Fragments

Voice recordings, images, and other input types alongside text. The fragment pipeline expands its intake while the downstream processing remains the same: WHO, WHAT, MEANING, POSSIBILITIES.

### Team/Organization Mode

Shared observation spaces where multiple users can surface collective patterns. Requires solving consent, privacy boundaries, and the distinction between individual and group-level observations.

---

## Explicitly NOT Planned

These are not deferred features. They are out of scope by design.

### Clinical Features

No diagnosis. No treatment recommendations. No DSM/ICD terminology. No crisis intervention beyond directing users to appropriate resources. argus-me is a cognitive tool, not a healthcare product. See [Safety Mechanisms](08-safety.md) for the full rationale.

### Behavior Prediction Presented as Fact

The system discovers retrospective patterns and presents scenario narratives. It does not predict what you will do and present that prediction as knowledge. Five layers of resistance (regulatory, reputational, liability, UX, accuracy) make this territory dangerous for any product. For argus-me, it also contradicts the exoskeleton philosophy: amplify cognition, do not replace it.

### Unsupervised Therapeutic Interventions

The system does not run CBT exercises, exposure hierarchies, or any structured therapeutic protocol. Even if the underlying patterns suggest a user might benefit from such interventions, the system's role is to surface the pattern and let the user decide what to do with it.

---

## North Star

> **Does the operator discover more about their entity because the system exists?**

This is not a technical metric. It is a human judgment. The system either shows you something you could not see on your own, or it does not.

### Our Own Benchmark

No existing benchmark measures "self-understanding amplification." We create our own:

1. Prepare real fragment sequences (different user profiles, different time spans)
2. Run N cycles of `understand()`
3. Human judges read Call 3 and Call 4 outputs
4. For each output, answer: **"Did this show me something I could not see on my own?"**
5. Record and label: "insight" or "no insight"

As versions iterate, re-run the same fragments. Compare output quality. Humans can tell the difference between genuine insight and noise. We do not need more complicated math.

### Auxiliary Metrics

Three proxy indicators that help make decisions, though none replaces the core human judgment:

| Metric | What It Measures | Target |
|--------|-----------------|--------|
| **Insight trigger rate** | Did the user take action after reading output? (dismiss / expect / note / edit) | > 40% after 30 runs |
| **Memory ROI** | Does telescoping context produce better output than no-history baseline? | 1.5x insight rate vs. no-history condition |
| **System humility** | How often does the user override the system? (edit_profile, dismiss observation) | Healthy range: 10-30%. Too low = sycophancy. Too high = poor quality. |

If Memory ROI does not validate, the epoch system's value proposition is not proven and subsequent features (Dream, ACT, CCR) should not ship.

---

## Decision Log

Major scope decisions and their rationale, for contributors who want to understand why the roadmap looks the way it does.

| Decision | Rationale |
|----------|-----------|
| Dream deferred to post-0.2 | Requires epoch data to validate; building on unproven foundation is waste |
| ACT as single framework (not IFS/Jung/Existential) | 80% of features do not drive retention; multi-framework requires therapist judgment that cannot be safely automated |
| Prediction reframed as deep MEANING | Behavioral prediction faces five layers of market resistance; what argus-me does is retrospective pattern discovery |
| UWM (User World Model) frozen | Predicting user behavior is replacing cognition, not amplifying it -- contradicts exoskeleton philosophy |
| LIWC demoted | CompACT detection from natural language is sufficient for MVP; LIWC adds dependency without demonstrated value |

For the full analysis behind each decision, see the [blueprint](../blueprint.md) section 4.
