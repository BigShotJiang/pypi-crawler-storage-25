# Memory System

How argus-me remembers across months and years.

---

## The Problem

In v0.1, the system's memory is a sliding window: the last 5 runs. This is `build_network_context()`, which retrieves the 5 most recent run outputs and injects them into Call 2/3/4 prompts.

This works for continuity across a few days. It fails catastrophically over longer periods.

**After 30 runs**, the system has forgotten everything from runs 1-25. Patterns that span weeks are invisible.

**After 100 runs**, the system has forgotten 95% of its history. A user who has been journaling for three months gets the same depth of context as one who started last week.

**After a gap**, if the user stops for two weeks and returns, the 5 most recent runs are stale and irrelevant. The system has no way to compress what came before the gap into usable context.

The fundamental issue: raw runs are too detailed for long-term context, but discarding them destroys longitudinal patterns. The system needs a compression layer.

---

## Epochs

An epoch is a compressed semantic summary of a group of runs. It captures the gist of what happened during a period without preserving every detail.

### Schema

```sql
CREATE TABLE epochs (
    id                          INTEGER PRIMARY KEY,
    start_date                  TEXT NOT NULL,
    end_date                    TEXT NOT NULL,
    run_count                   INTEGER NOT NULL,
    summary                     TEXT NOT NULL,
    themes                      TEXT DEFAULT '[]',
    avg_valence                 REAL,
    self_model_delta            TEXT DEFAULT '',
    boundary_start_trigger      TEXT,
    boundary_start_run_id       INTEGER,
    boundary_start_context_shift TEXT,
    boundary_end_state          TEXT,
    boundary_end_run_id         INTEGER,
    boundary_end_unresolved     TEXT DEFAULT '[]',
    continuing_threads          TEXT DEFAULT '[]',
    created_at                  TEXT NOT NULL
);
```

### What an Epoch Contains

| Field | Purpose |
|-------|---------|
| `summary` | 2-3 paragraph narrative of what happened during this period |
| `themes` | JSON array of topic tags (e.g., `["career", "relationship", "health"]`) |
| `avg_valence` | Average emotional valence across the epoch's runs |
| `self_model_delta` | How the self-model changed during this period |
| `boundary_start_*` | Why this epoch started here -- what triggered the boundary |
| `boundary_end_*` | What was happening when the epoch ended -- the state at closure |
| `continuing_threads` | JSON array of unresolved matters and patterns that carry forward |

The boundary fields are critical. They answer two questions that pure summarization misses: "Why did this period feel different from the one before it?" and "What was left unfinished when it ended?"

### What an Epoch Does NOT Contain

**Individual fragments.** Fragments are never compressed, summarized, or deleted. They remain in the `fragments` table permanently.

**Individual runs.** Runs are never deleted. They are tagged with `epoch_id` to record which epoch absorbed them, but the full run output stays in the database.

**Entity or matter details.** Entities, matters, possibilities, intentions, and observations live in their own tables. Epochs summarize the narrative arc, not the structured data.

Epochs are additive. They add a compression layer on top of existing data. Nothing is lost.

---

## When Epochs Are Created

Epoch creation is triggered by a mixed signal: semantic shift, time gap, or run count. The logic runs at the start of every `understand()` call.

### Trigger Conditions

An epoch is created when ALL of:

1. `unconsolidated_run_count >= 8` (minimum -- never create an epoch from fewer than 8 runs)

AND at least one of:

2. `unconsolidated_run_count >= 20` (maximum -- always create an epoch at 20 runs)
3. `semantic_shift > 0.5` (the LLM detects a thematic break between recent runs and prior runs)
4. `time_gap > 7 days` (more than 7 days since the last run)

### Semantic Shift Detection

When the run count reaches 8, the system asks the LLM to compare the themes of the 3 most recent runs against the 3 runs before them. If the themes have shifted significantly (score > 0.5 on a 0-1 scale), the system considers this a natural boundary.

Cost: approximately 500 tokens. This check only runs when `run_count >= 8`, so it is infrequent.

### The Landing Zone

Most epochs will contain approximately 14 runs. This is the "Goldilocks zone" identified by cognitive science research: enough runs for meaningful gist extraction, few enough to preserve thematic coherence.

The MIN=8 / MAX=20 bounds are engineering guardrails. The semantic shift trigger is the primary mechanism for finding natural boundaries.

### Creation Process (Call 0)

When triggered, Call 0 executes:

1. Gather all unconsolidated runs
2. Ask the LLM to produce: narrative summary, themes, boundary annotations, continuing threads
3. Write the epoch row
4. Tag each consolidated run with `epoch_id`
5. Rebuild the self-model cache from current observations

Cost: approximately 2,000-3,000 tokens. Amortized over ~14 runs, this adds roughly 150-200 tokens per run.

---

## Telescoping Context

Epochs alone do not help unless they reach the LLM. Telescoping context is the injection strategy that replaces `build_network_context()`'s fixed 5-run window.

### What Gets Injected

Every Call 2, Call 3, and Call 4 receives:

1. **Epoch summaries** -- up to 10 most recent epochs, newest first. Each is a compressed paragraph with themes and boundary annotations.
2. **Unconsolidated runs** -- all runs that have not yet been absorbed into an epoch. These are the detailed recent history.

```
[Long-term memory: 10 epochs]
Epoch 10 (Mar 1-14): Career transition dominated. Talked to Alex
about leaving. Valence declined steadily. Unresolved: whether to
take the offer.

Epoch 9 (Feb 15-28): Health focus period. Started running again...
...

[Recent memory: unconsolidated runs]
Run 147 (Mar 28): Conversation with Alex about timeline...
Run 146 (Mar 27): Reflected on what "success" means...
Run 145 (Mar 26): ...
```

### Token Budget

| Component | Budget | Rationale |
|-----------|--------|-----------|
| Epoch summaries (up to 10) | ~3,500 chars | ~350 chars per epoch summary |
| Unconsolidated runs | ~1,400 chars | Detailed recent context |
| **Total injection** | **~4,900 chars** | Roughly equivalent to the old 5-run window |

The total token cost is comparable to v0.1's context injection. The information density is dramatically higher: 10 epochs covering potentially 140 runs, plus full recent detail.

### Why "Telescoping"

The name reflects the structure: distant past is compressed (epoch summaries), recent past is detailed (full runs). Like a telescope, the system sees far and near simultaneously, but with different resolution.

This mirrors how human memory works. You remember last week in detail. You remember last month in broad strokes. You remember last year by its major events. The system does the same.

---

## Cognitive Science Basis

The memory system is grounded in three established theories, each with A-level evidence:

### CLS -- Complementary Learning Systems

McClelland et al. 1995, updated 2016. The brain uses two systems: the hippocampus for rapid, detailed storage (like individual runs) and the neocortex for slow, compressed, generalized storage (like epochs). Replay during sleep transfers information from hippocampus to neocortex.

**Engineering mapping**: Runs are the hippocampus. Epochs are the neocortex. Call 0 is the replay mechanism.

### TCM -- Temporal Context Model

Howard and Kahana 2002. Memory retrieval is weighted by temporal context -- recent items are retrieved with more detail, older items are retrieved through their associations. Context drifts over time, creating natural clustering.

**Engineering mapping**: Telescoping context implements TCM directly. Recent runs get full detail. Older epochs get compressed summaries. The weighting is structural, not algorithmic.

### EST -- Event Segmentation Theory

Zacks et al. 2007. Humans naturally segment continuous experience into discrete events at points of change. These boundaries are not arbitrary -- they correspond to shifts in goals, locations, actors, or causal chains.

**Engineering mapping**: The semantic shift trigger detects these natural boundaries. An epoch boundary should correspond to a genuine shift in the user's life, not an arbitrary run count.

---

## What the Memory System Preserves

A common concern with compression: what gets lost?

The answer for argus-me: **nothing is deleted**.

| Data | Preserved? | Where |
|------|-----------|-------|
| Fragments | Always | `fragments` table, immutable |
| Runs | Always | `runs` table, tagged with `epoch_id` |
| Entities | Always | `entities` table |
| Matters | Always | `matters` table |
| Possibilities | Always | `possibilities` table |
| Intentions | Always | `intentions` table |
| Observations | Always | `observations` table (superseded, never deleted) |
| Epochs | Always | `epochs` table |

Compression happens at the **context injection** layer only. The LLM sees a compressed view. The database retains everything. Any past run can be queried directly.

---

## Future: Dream System (Post-0.2)

Epochs are the foundation for the Dream system, which is designed but deferred to post-0.2 pending data validation.

The Dream system will process epoch content in two phases:

**NREM Dream** -- Integration. Cross-epoch pattern detection, deprioritization of noise, resolution of historical contradictions. Low temperature (0.1-0.3). Runs before REM.

**REM Dream** -- Creative synthesis. Generates novel hypotheses by colliding concepts from distant epochs. Higher temperature (0.5-0.7). Uses continuing threads as goal seeds.

Dream outputs enter the `insight_queue` as unverified hypotheses and follow the same lifecycle as sentinel insights: pending, injected, consumed.

The epoch system is designed with Dream in mind. Boundary annotations, continuing threads, and themes tags all serve as input for the Dream system. But epochs provide value on their own -- telescoping context does not require Dream to function. This is why epochs ship in v0.2 while Dream waits for validation data.
