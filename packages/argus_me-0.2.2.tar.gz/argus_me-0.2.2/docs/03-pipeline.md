# Pipeline

The `understand()` method is the core processing loop. It takes unprocessed fragments and transforms them into entities, matters, runs, possibilities, observations, and insights through a series of LLM calls and post-processing steps.

---

## Pipeline Overview

```
me.understand()
  |
  |-- 1. Get unprocessed fragments
  |-- 2. Compress transcript, redact if needed
  |-- 3. Trigger check: should_consolidate()? (count / time_gap / semantic_shift)
  |     +-- [If yes] Call 0: CONSOLIDATE -> epoch + cleanup -> rebuild self_profile
  |-- 4. Call 1: WHO (entity resolution)
  |-- 5. Call 2: WHAT (facts, emotion, matters)
  |-- 6. Call 3: MEANING (insights, self-observations)
  |     +-- [If adversarial_probe] challenge high-confidence pattern/trait
  |-- 7. Compliance gate: all observations checked before DB write
  |-- 8. Write run record
  |-- 9. Call 4: POSSIBILITIES (scenarios per open matter)
  |-- 10. Mark fragments processed
  +-- 11. Subconscious (sentinel stats, cognitive debt, anti-bias, intention scanning)
```

Each call builds on the output of previous calls within the same run. If an individual call fails (LLM error, JSON parse failure), the pipeline logs the error and continues with the remaining calls. A partial run is better than no run.

---

## Pre-Pipeline: Epoch Trigger Check

Before entering the main pipeline, the system checks whether memory consolidation is needed.

### Trigger logic

```python
def should_consolidate(path: str) -> bool:
    unconsolidated = get_unconsolidated_run_count(path)
    if unconsolidated < 8:        # MIN_RUNS -- not enough data
        return False
    if unconsolidated >= 20:      # MAX_RUNS -- hard ceiling
        return True
    if semantic_shift(path) > 0.5:
        return True
    if time_gap_days(path) > 7:
        return True
    return False
```

Three independent signals, any one sufficient (above the MIN=8 floor):

| Signal | Threshold | What it detects |
|--------|-----------|----------------|
| **Run count** | >= 20 | Accumulation ceiling -- consolidate regardless |
| **Semantic shift** | > 0.5 | Topic/theme change between recent and prior runs |
| **Time gap** | > 7 days | User returned after a break -- natural boundary |

The `semantic_shift()` function compares themes of the 3 most recent unconsolidated runs against the 3 prior ones using a lightweight LLM call (~500 tokens). Returns 0.0 (identical themes) to 1.0 (completely different). Only invoked when run count >= 8.

Default landing zone: ~14 runs per epoch. This maps to the cognitive science "Goldilocks zone" for gist extraction (2-10 comparable epochs over 70-140 total runs).

---

## Call 0: CONSOLIDATE

Triggered conditionally. Creates an epoch from all unconsolidated runs.

### Input

- All unconsolidated runs (full summaries, emotions, conflicts, gaps)
- Up to 3 previous epochs (for continuity)

### Process

1. LLM generates a compressed summary with boundary annotations (temperature=0.1)
2. System writes the epoch row to the `epochs` table
3. All consolidated runs are marked with the new `epoch_id`
4. Self-profile cache is rebuilt from the observations table

### Output schema (from LLM)

```json
{
  "summary": "50-word epoch digest",
  "themes": ["theme1", "theme2"],
  "avg_valence": 0.6,
  "self_model_delta": "changes to self-understanding in this period",
  "boundary_start": {
    "trigger": "semantic_shift|time_gap|max_runs",
    "context_shift": "how context differs from previous epoch"
  },
  "boundary_end": {
    "closing_state": "user state at epoch end",
    "unresolved": ["matter1", "matter2"]
  },
  "continuing_threads": [
    {"theme": "thread description", "started_epoch": 3, "status": "active"}
  ]
}
```

### Self-profile rebuild

At epoch creation, the cached `self_profile` text is rebuilt from structured observations:

1. Fetch stable observations (confidence >= 0.8, appeared in 3+ runs)
2. Fetch 20 most recent observations
3. LLM synthesizes a coherent profile narrative (temperature=0.1)
4. Replace `entities.self_profile` where `id='self'`

Between epochs, Call 1/3 outputs still append to self_profile for real-time responsiveness. Each epoch creation resets from the structured evidence base.

### Token cost

~2,000-3,000 tokens per consolidation. Amortized over ~14 runs: ~150-200 tokens/run.

---

## Call 1: WHO

Entity resolution and self-knowledge extraction.

### Input

- Current fragment transcript
- Known entity list with aliases

### Process

1. LLM identifies entities mentioned in the fragment
2. Resolves against known entities or creates new ones
3. Extracts self_profile deltas (what this fragment reveals about the user)

### Output handling (v0.2 change)

Self-profile deltas are dual-written:

1. Appended to `entities.self_profile` (preserves v0.1 behavior)
2. Written to `observations` table as `source='call_1'`, `observation_type='trait'`

This dual-write ensures backward compatibility while building the structured observation history.

---

## Call 2: WHAT

Facts, emotion, matters, and cognitive gaps.

### Input

- Fragment transcript
- Entity resolution output from Call 1
- **Telescoping context** (v0.2 change)

### Telescoping context injection

Replaces the v0.1 fixed 5-run window:

```
[Known network]
- Entity relationships and dynamics

[Long-term memory (epoch summaries)]
- Epoch 5 (2026-01-15 -> 2026-02-01): compressed summary | closing: state
- Epoch 4 (2025-12-20 -> 2026-01-14): compressed summary
- ...up to 10 epochs

[Recent memory (unconsolidated)]
- 2026-02-15: run summary
- 2026-02-12: run summary
- ...all unconsolidated runs
```

Token impact: ~50 tokens per epoch for boundary_end_state, max +500 tokens for 10 epochs. Unconsolidated runs (typically 8-20) replace the old fixed window.

### Output

- Summary (first-person perspective)
- Emotion (valence, arousal, emotion word)
- Matter updates (new matters, status changes, mention counts)
- Conflict (core tension in this fragment)
- Cognitive gaps (questions the fragment raises but doesn't answer)

---

## Call 3: MEANING

Deeper analysis -- self-observations and pattern detection.

### Input

- Fragment transcript
- Call 1 and Call 2 outputs
- **Cached self_profile** (synthesized narrative from observations)

### Output handling (v0.2 change)

Self-observations are dual-written:

1. Appended to `entities.self_profile` (preserves v0.1 behavior)
2. Written to `observations` table as `source='call_3'`

Observations from Call 3 can be structured:

```json
{
  "content": "tends to deprioritize personal needs when work pressure increases",
  "type": "pattern",
  "evidence_fragments": ["fragment-id-1", "fragment-id-2"]
}
```

Or plain strings (backward compatible with v0.1 prompts), in which case they default to `observation_type='behavior'`.

---

## Call 4: POSSIBILITIES

Scenario narratives for each open matter.

### Input

- All open matters with current status
- Call 1-3 outputs from this run
- **Telescoping context** (same injection as Call 2)
- Cached self_profile

### Output

For each open matter, 1-3 possibility scenarios:

- Event title (what might happen)
- Narrative (why, triggers, consequences)
- Confidence (high / medium / low)
- Historical precedent (similar past pattern, if any)

Possibilities are stories, not probabilities. They expand the user's vision of what could happen next.

---

## Subconscious

Post-pipeline analysis that runs after every understand() cycle.

### Sentinel stats

Statistical analysis of accumulated data:

- Entity interaction frequency and dynamics trends
- Matter mention counts and staleness detection
- Emotional trajectory (valence/arousal over time)

### Cognitive debt

Tracks unresolved cognitive gaps across runs. A gap mentioned in multiple runs without resolution gets escalated to the insight queue.

### Anti-bias

Checks for echo chamber patterns:

- Are the same entities dominating attention?
- Are matters clustering around a single theme?
- Is emotional valence suspiciously stable (possible sycophancy)?

### Intention scanning

Detects implicit intentions from behavior patterns. When an intention's confidence crosses a threshold, it surfaces as an insight. Intentions silently improve possibility quality by providing deeper context to Call 4.

---

## Fragment Feedback Loop

User actions create action fragments that enter the pipeline on the next `understand()` call:

```
User dismisses matter "Job search"
  -> fragment created: type='action', "User no longer tracking: Job search"
  -> next understand() processes this fragment
  -> Call 2 updates matter status
  -> Call 3 may observe: "stepping back from active job search"
  -> Call 4 adjusts possibility scenarios accordingly
```

This loop is how user corrections propagate through the system. The system learns not just from what the user says, but from what the user does with the system's output.

---

## Token Budget

| Component | Tokens per invocation |
|-----------|----------------------|
| Semantic shift check | ~500 (only when runs >= 8) |
| Call 0 (consolidation) | ~2,000-3,000 |
| Call 1 (WHO) | ~1,000-1,500 |
| Call 2 (WHAT) | ~1,500-2,500 |
| Call 3 (MEANING) | ~1,500-2,000 |
| Call 4 (POSSIBILITIES) | ~2,000-3,000 |
| Subconscious | ~500-1,000 |
| **Typical run (no consolidation)** | **~6,500-10,000** |
| **Run with consolidation** | **~9,000-13,500** |
| **Amortized per run (~14 runs/epoch)** | **~600 extra tokens (+15% over v0.1 baseline)** |

---

## Error Handling

The pipeline is designed to be resilient to partial failures.

| Failure | Behavior |
|---------|----------|
| Call 0 LLM error | Skip consolidation, proceed with Call 1. Consolidation retried next run. |
| Call 1 LLM error | Skip entity resolution. Call 2-4 proceed with reduced context. |
| Call 2 LLM error | No run record written for this fragment. Fragment remains unprocessed. |
| Call 3 LLM error | Skip meaning extraction. Call 4 proceeds without self-observations. |
| Call 4 LLM error | Skip possibility generation. Run record still written from Call 2. |
| JSON parse error | `parse_json()` returns a safe default. Pipeline continues with empty/default values. |
| Database error | Logged and raised. Pipeline stops -- database integrity is non-negotiable. |

The guiding principle: a partial understanding is better than no understanding. The only hard stop is database corruption.
