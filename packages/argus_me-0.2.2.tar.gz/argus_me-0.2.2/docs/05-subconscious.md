# Subconscious

The sentinel system that watches for patterns the main pipeline might miss.

---

## Role

The subconscious is a background analysis layer that runs after every `understand()` call. It scans the database for signals that individual calls cannot detect -- trends over time, statistical anomalies, gaps in coverage.

Its outputs are injected as a statistics preamble into Call 2 (WHAT) and Call 3 (MEANING), giving those calls awareness of the broader context without requiring them to query the database themselves.

**Critical constraint: the subconscious is read-only.** It never calls the LLM. It never modifies core tables (fragments, runs, entities, matters). It reads data, computes statistics, and queues insights. Nothing more.

---

## The Sentinel

The sentinel is the core component of the subconscious. It generates a structured preamble that is prepended to the context for Call 2 and Call 3.

The preamble contains:
- Emotion trend summary (last N runs)
- Matter staleness alerts
- Entity frequency statistics
- Any pending insights from the insight queue

The sentinel runs three categories of scans.

### 1. Cognitive Debt Scanning

Cognitive debt is unprocessed or underprocessed information. The sentinel detects five types:

**Stale matters.** Any matter not mentioned in fragments for 7+ days. The user may have resolved it silently, or they may be avoiding it. Either way, Call 2/3 should know.

**Emotion inflection.** When the dominant emotion trends monotonically in one direction for 3+ consecutive days. A steady decline (or steady climb) that the user hasn't acknowledged is worth surfacing.

**Unconfirmed entities.** Entities mentioned only once, without enough context for the system to classify them. They may be important people or topics that the user hasn't elaborated on.

**High-frequency entities.** Entities that appear disproportionately often relative to others. May indicate an unacknowledged preoccupation.

**Relationship gaps.** When two entities appear together frequently but the system has no explicit relationship record between them. The connection may be obvious to the user but invisible to the system.

### 2. Anti-Bias Scanning

The system can develop blind spots. Anti-bias scanning detects three types:

**Echo chamber risk.** When more than 80% of recent fragments revolve around 1-2 entities. The user's attention may be narrowing, or the system may be reinforcing a fixation through its own outputs.

**Low emotion granularity.** When the system has used fewer than 3 distinct emotion words across 30 days of runs. This suggests either the user's emotional expression is being flattened, or the system is failing to detect nuance.

**Insight concentration.** When most insights cluster around a single theme or entity. Healthy self-reflection is multidimensional. Concentration may indicate the system is stuck in a loop.

### 3. Intention Scanning

Intentions are things the user has stated they want to do or change. The sentinel monitors their health:

**Matter avoidance.** When a matter has been open for 14+ days with no new fragments or actions related to it. This is distinct from staleness (7+ days) -- avoidance is a longer-term signal that may indicate the matter is genuinely difficult for the user.

**Dynamics drift.** When a matter's trajectory score drops below -0.3 (on a -1.0 to 1.0 scale). The situation is getting worse, and the user may not realize the trend.

---

## Insight Lifecycle

When a scan detects something noteworthy, it does not surface the finding directly. Instead, it follows a lifecycle:

```
detected
    |
    v
insight_queue (status: pending)
    |
    v
injected into next Call 2/3 preamble
    |
    v
consumed (status: consumed, with timestamp)
```

### Detection

A scan fires and produces a structured insight:

```json
{
  "type": "stale_matter",
  "matter_id": 42,
  "description": "Career transition matter not mentioned in 12 days",
  "detected_at": "2026-03-15",
  "priority": 2
}
```

### Queuing

The insight enters `insight_queue` with `status = 'pending'`. It waits there until the next `understand()` call.

### Injection

At the start of the next Call 2 or Call 3, pending insights are formatted into the statistics preamble. The LLM sees them as contextual background, not as directives. Example preamble section:

```
[Sentinel notes]
- Matter "career transition" has not appeared in fragments for 12 days.
- Emotion trend: 4-day declining valence (0.6 → 0.3).
- Entity "Alex" mentioned in 8 of last 10 fragments (high concentration).
```

### Consumption

After injection, the insight is marked `consumed` with a timestamp. It will not be injected again.

### Deduplication

A 7-day dedup window prevents the same insight from being generated repeatedly. If a scan produces an insight that matches the type, target, and description of a consumed insight from the last 7 days, the new insight is silently dropped.

This prevents the sentinel from nagging. If the user is still not talking about the stale matter after 7 days, a new insight will be generated -- but not before.

---

## What the Subconscious Does NOT Do

Clarity about boundaries is as important as clarity about capabilities.

**It never calls the LLM.** All scanning is statistical -- counting, comparing, thresholding. No natural language generation happens in the subconscious. This keeps it fast, deterministic, and free from hallucination risk.

**It never modifies core tables.** It reads from fragments, runs, entities, matters, and observations. It writes only to `insight_queue`. If a scan suggests something should change (e.g., a matter should be marked stale), it surfaces the suggestion to Call 2/3 and lets the LLM decide.

**It never makes decisions for the user.** Insights are observations, not recommendations. "This matter has been dormant for 12 days" is a fact. "You should think about this matter" is a recommendation. The subconscious produces the former. Call 2/3 may produce the latter.

**It does not replace Call 3 pattern detection.** Call 3 uses the LLM to find semantic patterns in content. The sentinel uses statistics to find structural patterns in metadata (dates, counts, frequencies). They are complementary, not redundant.

---

## Relationship to Other Components

**Telescoping context** provides the LLM with historical content (what was said). The sentinel provides the LLM with historical statistics (what the patterns look like). Together, they give Call 2/3 both narrative and quantitative awareness.

**The observations table** receives its entries from Call 1 and Call 3. The sentinel does not write observations. But it may detect conditions that cause Call 3 to generate better observations -- for example, flagging an emotion inflection that Call 3 then investigates.

**Epochs** are created by Call 0. The sentinel does not trigger epoch creation. But its staleness and avoidance signals may appear in epoch boundary annotations, since they reflect what was happening at the time.

---

## Design Rationale

Why a separate subconscious layer instead of putting everything in the main calls?

**Token efficiency.** Statistical scans are cheap. Running them outside the LLM means the main calls only receive pre-computed summaries, not raw data to analyze.

**Determinism.** The sentinel produces the same output given the same database state. This makes it testable without mocking LLM responses.

**Separation of concerns.** The main calls focus on understanding the current fragment. The sentinel focuses on longitudinal patterns. Mixing these in one prompt degrades both.

**Consistency.** The sentinel runs the same scans every time, with the same thresholds. An LLM asked to "check for stale matters" might forget, get creative, or apply inconsistent criteria.
