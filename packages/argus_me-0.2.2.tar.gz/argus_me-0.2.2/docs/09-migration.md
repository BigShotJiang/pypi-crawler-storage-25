# Migration

## Upgrading

```bash
pip install argus-me --upgrade
```

Migration is fully automatic. On first load after upgrade, `init_db()` detects the current schema version and applies all pending migrations. No manual steps required.

```python
from argus_me import Me

me = Me(
    name="Your Entity Name",
    db_path="path/to/existing.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
)
# Database is now at the latest schema version.
# All existing data is preserved.
```

---

## What's Guaranteed

- **No data loss**: Migrations only add tables and columns. No rows are deleted or altered.
- **Idempotent**: Running migrations multiple times is safe.
- **Automatic**: Triggered by `Me()` constructor, no CLI or manual SQL needed.
- **Backward compatible**: All existing `Me` methods and properties continue to work after upgrade.

---

## Breaking Changes

**None for the public API across all v0.x releases.**

If you have custom code that directly queries the SQLite database, be aware that new versions may add tables and columns. Direct SQL queries against existing tables will continue to work without modification.

---

## Schema Version History

| Version | Release | Changes |
|---------|---------|---------|
| v19 | v0.1.0 | Baseline: 10 tables (fragments, entities, matters, runs, etc.) |
| v20 | v0.1.4 | +epochs table, +observations table, +runs.epoch_id column |
| v21 | v0.2.1 | +compliance_log table |
