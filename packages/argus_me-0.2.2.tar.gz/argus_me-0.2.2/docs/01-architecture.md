# Architecture

argus-me is a Python library (`pip install argus-me`). Single entry point: the `Me` class. Not an agent, not an assistant, not an app -- a pure library that processes fragments into evolving understanding. Any entity can be a Me: a person, a store, a fund, a team.

---

## v0.1 Baseline

Schema v19. ~2100 lines of Python. 10 SQLite tables. 4 Jinja2 prompt templates (Chinese).

```
User input
  |
  v
fragments (immutable)
  |
  v
understand()
  |-- Call 1: WHO     -- entity resolution, self_profile delta
  |-- Call 2: WHAT    -- summary, emotion, matters, cognitive gaps
  |-- Call 3: MEANING -- self_observations, pattern detection
  |-- Call 4: POSSIBILITIES -- scenario narratives per open matter
  +-- Subconscious   -- sentinel stats, cognitive debt, anti-bias, intention scanning
  |
  v
snapshot() / matters / insights
```

Each `understand()` invocation processes unprocessed fragments through 4 sequential LLM calls, then runs subconscious analysis. User actions (dismiss matter, expect possibility, edit profile) create action fragments that feed back into the next cycle.

---

## v0.2 Additions

v0.2 adds memory compression (Epochs), structured self-knowledge (observations table), telescoping context injection, compliance gate, adversarial probe, and safety mechanisms. Schema v21.

```
fragments (immutable)
  |
  v
understand()
  |
  |-- [Trigger Check] semantic_shift / time_gap / count >= threshold?
  |     |
  |     +-- [If triggered] Call 0: CONSOLIDATE
  |           |-- Create Epoch (compressed memory of N runs)
  |           +-- Rebuild self_profile cache from observations
  |
  |-- Call 1: WHO        -- entity resolution; deltas -> observations table
  |-- Call 2: WHAT       -- inject telescoping context (epochs + unconsolidated runs)
  |-- Call 3: MEANING    -- self_observations -> observations table
  |-- Call 4: POSSIBILITIES -- inject telescoping context + cached self_profile
  +-- Subconscious       -- sentinel stats + cognitive debt + anti-bias
  |
  v
snapshot() / matters / insights
```

### What changed from v0.1

| Component | v0.1 | v0.2 |
|-----------|------|------|
| Memory window | Fixed last 5 runs | Telescoping: up to 10 epoch summaries + all unconsolidated runs |
| Self-knowledge | Flat `self_profile` text field on entities | Typed observations table (behavior/trait/pattern) with confidence scores; flat field becomes cached synthesis |
| Memory compression | None (runs accumulate forever) | Epochs: ~14 runs compressed into a semantic summary with boundary annotations |
| Context for Call 2/4 | Entity network + 5 recent runs | Entity network + epoch summaries + unconsolidated runs |
| Pipeline entry | Directly into Call 1 | Trigger check -> optional Call 0 -> Call 1 |

---

## File Structure

```
src/argus_me/
├── me.py           Public API (Me class). Orchestrates ingest/understand/snapshot.
├── models.py       All SQLite operations. One memory.db per user, WAL mode.
├── etl.py          Pipeline logic. Call 0-4 orchestration, context building.
├── llm.py          LLM client. Prompt loading, API calls, JSON parsing.
├── sentinel.py     Subconscious analysis. Stats, cognitive debt, anti-bias.
├── compliance.py   Deterministic safety checks. Regex-based compliance gate before DB writes.
├── redact.py       PII redaction integration.
└── prompts/        Jinja2 templates (overridable via prompt_dir parameter).
```

---

## Key Architectural Decisions

### Single SQLite file

One `memory.db` per user. WAL mode for concurrent reads. No external database dependency. The file is the complete state of one Me instance's understanding. Portable, backupable, inspectable with any SQLite client.

### Append-only fragments

Fragments are immutable after creation. The `raw` and `transcript` fields are never modified. Administrative fields (`processed`, `run_id`) are updated by the pipeline, but content is permanent. This guarantees auditability -- any observation can be traced back to its source fragments.

### Functional style

Database functions in `models.py` each open and close their own connection. No shared connection state. Each function takes a `path: str` parameter. This trades a small performance cost for simplicity and thread safety.

### Minimal dependencies

Core dependencies: `openai` (OpenAI-compatible client), `jinja2` (prompt templates), `uuid6` (time-sortable IDs). Works with any OpenAI-compatible LLM provider: Ollama, OpenAI, Anthropic (via compatibility layer), vLLM, LM Studio.

### Dual-write migration strategy

During v0.1 to v0.2 transition, self-knowledge is written to both the old `entities.self_profile` field and the new `observations` table. The flat field serves as the runtime read source until the first epoch triggers a full rebuild from structured observations. No data loss, no breaking change.

---

## What's Deferred to Post-0.2

| Feature | Why deferred |
|---------|-------------|
| Dream system (NREM/REM) | Requires 2+ epochs of data to validate. Dream outputs need the four-layer validation framework, which depends on sufficient observation history. |
| ACT flexibility detection | CompACT 3-factor detection from language fragments requires 30+ epochs for reliable cold-start. No value until sufficient longitudinal data exists. |
| CCR rigidity detection | Confirm-Challenge Ratio monitoring depends on the observations table having enough history to compute meaningful ratios. |
| Absence map | Statistical baseline for tracking what the user does NOT talk about requires 30-epoch cold start. |
| Adaptive epoch sizing | v0.2 uses fixed parameters (MIN=8, MAX=20). Adaptive sizing based on usage density planned for a future version. |
