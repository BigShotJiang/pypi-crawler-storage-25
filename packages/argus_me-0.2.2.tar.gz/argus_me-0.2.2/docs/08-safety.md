# Safety Mechanisms

argus-me processes sensitive data — personal reflections, business operations, team dynamics. This document describes the safety architecture that ensures the system remains a cognitive tool, regardless of the entity it represents.

---

## 6 Safety Rules (Non-Negotiable)

These rules are not configurable. They apply to every user-facing output, every prompt template, and every design decision.

### 1. Behavioral Language Only (Path B)

All user-facing output describes observed patterns in behavioral terms. The system never infers psychological states or uses clinical terminology.

| Allowed | Not Allowed |
|---------|-------------|
| "Your language in the last 3 entries focused on work deadlines" | "You are experiencing anxiety" |
| "You mentioned avoiding this topic in entries #12, #18, and #24" | "You have avoidance tendencies" |
| "Your descriptions of this relationship shifted from action words to passive phrasing" | "You are becoming emotionally disengaged" |

The prohibition covers both English and Chinese output. Banned verbs in prompts: detect, diagnose, assess, evaluate, identify (and their Chinese equivalents).

### 2. Hypotheses, Not Conclusions

Every pattern discovery is framed as a question or tentative observation, never as a definitive characterization.

- Dream outputs enter the system with `status=unverified`
- Observations carry explicit `confidence` scores (0.0-1.0)
- Presentation language uses hedging: "Have you noticed...?", "A pattern that appears...", "This might suggest..."

A single observation is a data point. Only convergent evidence across multiple epochs and sources earns high confidence.

### 3. Evidence-Linked Claims

Every observation must trace to specific fragment IDs. The `evidence_fragments` field in the observations table is not optional decoration -- it is the mechanism that prevents the system from fabricating patterns.

Claims without evidence links are automatically downgraded or discarded during epoch consolidation.

### 4. Analyst Role, Never Companion

The system prompt locks the LLM role to "analyst/advisor" across all calls. This is a direct defense against sycophancy amplification.

Research shows that condensed user profiles are the single largest driver of LLM sycophancy (Kelley & Riedl, CHI 2026). The "companion" role decreases cognitive independence; the "advisor" role increases it. argus-me injects self_profile into every call -- making role constraint essential, not optional.

Anti-sycophancy instructions are injected alongside self_profile in Call 3 and Call 4 prompts.

### 5. User Is the Authority

The system surfaces patterns; the user decides what they mean. No observation overrides the user's self-report.

- Users can dismiss any observation
- Users can edit their self_profile directly
- User-provided observations (`source='user'`) are never automatically superseded by system-generated ones
- The system tracks when users disagree with its observations -- this is signal, not error

### 6. No Clinical Territory

argus-me does not diagnose, treat, prescribe, or simulate a therapeutic relationship. Specifically:

- No DSM/ICD terminology in any output
- No treatment recommendations
- No crisis intervention (the system should direct users to appropriate resources if distress signals are detected, not attempt to handle them)
- No simulation of therapeutic techniques (CBT worksheets, exposure hierarchies, etc.)

This is a self-understanding tool. It belongs on the same shelf as a journal, not in a therapist's office.

---

## Defense Layers

The 6 rules define *what* the system must not do. The defense layers define *how* violations are prevented at each known risk surface.

### Layer 0: Compliance Gate (compliance.py)

**Risk**: LLM outputs clinical terminology or psychological inference despite prompt constraints. Once written to `observations` or `self_profile`, toxic content permanently pollutes the self-model.

**Defenses**:
- **Deterministic regex check**: `compliance_check()` runs before every DB write to `observations` and `self_profile`. No LLM dependency — pure pattern matching.
- **Hard block**: Clinical terms (DSM/ICD diagnoses, treatment verbs) → entire text discarded, logged to `compliance_log`.
- **Soft block**: Inference language ("you have avoidance tendencies") → observation downgraded to `type='behavior'`, confidence capped at 0.2.
- **Audit trail**: Every interception logged with original text, violations, and action taken. The `compliance_log` table enables retrospective analysis of prompt compliance gaps.

**Priority**: P0 -- this is the safety bottom line. Cannot be disabled.

### Layer 1: Integration Drift

**Risk**: Each compression step (runs to epochs, epochs to mega-epochs) is lossy. Paraphrasing can invert causal direction. Common patterns overwrite the user's atypical ones. After enough compression cycles, the system's memory of you becomes a plausible fiction.

**Defenses**:
- **Anchored-append compression**: Epoch summaries are built incrementally, not by full rewrite. Original wording is preserved for key facts.
- **Fact anchors**: 3-5 verifiable facts extracted per epoch. These are literal quotes or specific dates that can be checked against source fragments.
- **Periodic audit**: Every 10 epochs, sample-verify epoch summaries against their source runs. Flag drift.

**Priority**: P0 -- drift is silent and cumulative.

### Layer 2: Regulatory Compliance

**Risk**: Emerging legislation (see Regulatory Context below) targets AI systems that detect emotions or mental states. argus-me's pattern detection could be classified under these laws.

**Defenses**:
- **Path B language**: All user-facing output uses behavioral observation terms, never psychological inference language.
- **Wellness positioning**: Product framing as a self-understanding tool, not a mental health tool. Aligned with FDA general wellness guidance and state-level self-help exemptions.
- **Compliance checklist**: Pre-launch gate that audits every prompt template and output format against banned terminology.

**Priority**: P0 -- regulatory risk is existential.

### Layer 3: LLM Projection

**Risk**: The LLM attributes common human traits to the user based on training data priors rather than fragment evidence. Research shows LLMs systematically skew toward high openness / low extraversion profiles (Nature Machine Intelligence, 2025). Implicit preference extraction accuracy is only 37-48% (PersonaMem-v2).

**Defenses**:
- **Prompt separation**: System prompts explicitly distinguish "observed behavior" from "inferred trait."
- **Type tagging**: Observations are typed as `behavior`, `trait`, or `pattern`, each with different default confidence levels. Behaviors start higher; traits start lower.
- **Baseline blacklist**: Development-time scan with synthetic fragments to identify universal traits the LLM projects onto everyone. These are blacklisted from observations.

**Priority**: P1 -- systematic but detectable.

### Layer 4: Sycophancy

**Risk**: Self_profile injection causes Call 3/4 to shift from honest observation to user-pleasing output. The system tells you what you want to hear instead of what the evidence shows.

**Defenses**:
- **Analyst role lock**: Rule 4 above. Never "companion."
- **Anti-sycophancy instructions**: Injected alongside self_profile in prompts.
- **Periodic A/B monitoring**: Compare insight criticality with and without self_profile injection. If the system becomes systematically less challenging with profile, the injection strategy needs revision.

**Priority**: P1 -- well-understood and mitigable.

### Layer 5: Schema Rigidity (Future)

**Risk**: Once the system forms a model of you, it preferentially confirms that model. New evidence that contradicts the model is downweighted or ignored. You become frozen in the system's first impression.

**Defense** (planned for post-0.2):
- **CCR monitoring**: Confirm-Challenge Ratio tracked per observation dimension. CCR > 0.9 triggers anti-bias intervention.
- **Trend detection**: A rising CCR trend over epochs matters more than the absolute value.
- **Layered architecture**: The three-tier self-model (L0 compiled / L1 active / L2 trial) ensures new contradictory evidence always has a place to land, even when it conflicts with established observations.

**Priority**: P2 -- requires epoch data to implement meaningfully.

### Layer 6: Fork Isolation

**Risk**: If Call 4 (POSSIBILITIES) or future Dream outputs are fed back as context into Call 1/2/3, the system creates a feedback loop where it generates speculative content, reads it as historical fact, and produces more speculation to confirm the original guess. This manufactures false evidence.

**Defenses**:
1. Speculative outputs (possibilities, dream hypotheses) write only to `possibilities` table or `insight_queue` (status=pending). Never to `fragments`, `observations`, `entities`, or `runs`.
2. Speculative outputs are never injected as context into Call 1, Call 2, or Call 3. Only Call 4 and Dream see their own prior outputs.
3. Only when a user explicitly calls `me.expect(possibility_id)` does a possibility re-enter the main loop — via an action fragment, not by direct injection.
4. Dream hypotheses follow the same rule: they surface through `insight_queue`, never modify `observations` or `self_profile` directly.

**Why this matters**: The system's speculations are its most creative outputs, but also its least grounded. Mixing speculation with evidence corrupts the evidence base. This isolation is already enforced in v0.2 code — this layer documents the principle so future contributors don't accidentally break it.

**Priority**: P1 -- architectural invariant, not a feature.

---

## Regulatory Context

### The Emerging Landscape

Illinois HB 1806 (Workplace Online Privacy Rights Act, effective August 2025) prohibits AI systems from "detecting emotions or mental states." The prohibition targets the *detection act itself*, not just downstream use.

As of early 2026, 78 related bills are active across 27 US states. Colorado HB 26-1195 extends the scope further. The trend is accelerating.

### argus-me's Compliance Position

argus-me's primary defense relies on self-help exemptions (e.g., Illinois Section 35), which require the product to not "purport to offer therapy."

Three elements make this defense tenable:

1. **Path B language** -- the system describes behavioral patterns, never detects psychological states. This is a meaningful distinction under current statutory language.
2. **Wellness positioning** -- the product is framed as a self-understanding journal tool, aligned with FDA general wellness guidance. It sits alongside meditation apps and mood trackers, not clinical software.
3. **No clinical territory** -- Rule 6 above. The system never diagnoses, treats, or simulates therapy.

### What This Means for Contributors

- Every new prompt template must pass the compliance checklist before merge
- User-facing strings must use behavioral observation language
- Features that would cross into clinical territory (diagnosis, treatment recommendation, crisis intervention) are explicitly out of scope -- see the [roadmap](10-roadmap.md) "Explicitly NOT Planned" section
- When in doubt, describe what the user *did*, not what the user *is*

---

## Design Rationale

The safety architecture is not conservative by default. It is conservative because the evidence demands it.

- **Gist extraction creates false memories**: Three A-level DRM experiments prove that the same mechanism producing genuine insights simultaneously strengthens fabricated patterns (Payne 2009, Diekelmann 2010, Macera 2019). Every Dream output is a candidate, not a conclusion.
- **User profiles amplify sycophancy**: Condensed profiles are the single largest sycophancy driver in LLMs (Kelley & Riedl 2026). Injecting self_profile without guardrails would make the system progressively less honest.
- **Compression drifts silently**: Larger compression models are not more faithful (Guo et al. 2026). Multi-round compression produces "confident but subtly wrong" outputs. Without anchors and audits, the system's memory of you degrades into a plausible average.
- **Feedback loops are invisible**: AI personality traits reshape user self-concept (CHI 2026). The system's observations can manufacture their own confirming evidence. Standard validation does not catch this.

These are not theoretical risks. They are documented failure modes of systems similar to argus-me. The safety architecture exists because building a cognitive exoskeleton without it would be building a cognitive trap.
