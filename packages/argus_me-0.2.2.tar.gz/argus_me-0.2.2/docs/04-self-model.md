# Self-Model

How argus-me builds and maintains a model of the entity it represents — whether a person, a store, a team, or any other "Me".

---

## The Problem with v0.1

In v0.1, `self_profile` is a flat TEXT column -- a single blob that Call 1 and Call 3 append to after every run. This works for the first 20 runs. Then it breaks.

**Unbounded growth.** Each run adds observations without removing anything. After 100 runs the profile is thousands of words, most of it redundant.

**Contradictions accumulate.** Run 12 says "tends to avoid conflict." Run 47 says "confronted the situation directly." Both coexist in the same blob. The LLM has no way to know which is current, so it hedges or picks whichever appears last.

**No provenance.** A statement in the profile cannot be traced back to which fragment or run produced it. When the profile says something wrong, there is no way to find and fix the source.

**No user authority.** If the user disagrees with a profile statement, they have no structured way to override it. They can edit the text, but the next run may re-append the same thing.

---

## v0.2 Solution: Observations + Cached Synthesis

The self-model is rebuilt from the ground up with two layers:

1. **Observations table** -- typed, timestamped, evidence-linked atoms
2. **Cached synthesis** -- a narrative profile rebuilt periodically from high-confidence observations

The observations are the source of truth. The synthesis is a convenience layer for prompt injection.

### Observations

An observation is one atomic statement about the user, stored in the `observations` table.

```sql
CREATE TABLE observations (
    id              INTEGER PRIMARY KEY,
    date            TEXT NOT NULL,
    source          TEXT NOT NULL,        -- call_1 | call_3 | user | dream
    content         TEXT NOT NULL,
    tags            TEXT DEFAULT '[]',
    confidence      REAL DEFAULT 0.5,
    observation_type TEXT DEFAULT 'behavior',
    evidence_fragments TEXT DEFAULT '[]',
    superseded_by   INTEGER REFERENCES observations(id),
    run_id          TEXT,
    created_at      TEXT NOT NULL
);
```

Each observation has:

| Field | Purpose |
|-------|---------|
| `date` | When the observation was made |
| `source` | Which call or actor produced it |
| `content` | The observation itself, in natural language |
| `tags` | JSON array of topic tags for retrieval |
| `confidence` | 0.0 to 1.0, starting at 0.5 for system-generated |
| `observation_type` | One of three types (see below) |
| `evidence_fragments` | JSON array of fragment IDs that support this claim |
| `superseded_by` | Points to the replacement observation, if any |

### Observation Types

Three types, each with different semantics:

**behavior** -- A specific, time-bound action or pattern of actions.

> "Postponed 3 decisions this week, all related to career."

Behaviors are the most concrete type. They are directly observable in the user's fragments. Default confidence: 0.5.

**trait** -- A generalized characteristic inferred from multiple behaviors.

> "Tends to avoid conflict in professional settings."

Traits require more evidence than behaviors. They should be supported by multiple fragment IDs in `evidence_fragments`. Default confidence: 0.4 (lower because inference is involved).

**pattern** -- A conditional or temporal relationship between events.

> "Whenever a deadline approaches, sleep quality drops and journaling frequency increases."

Patterns are the most interpretive type. They connect observations across time. Default confidence: 0.3.

### Supersession, Not Deletion

Observations are never deleted. When a newer observation contradicts an older one, the older observation's `superseded_by` field points to the replacement. The original row stays in the database.

This means:
- The full history of what the system believed is preserved
- Contradictions are tracked explicitly, not silently overwritten
- A query for "current observations" filters on `WHERE superseded_by IS NULL`

### Where Observations Come From

**Call 1 (WHO)** generates observations when it detects self-referential content in fragments. These are typically `behavior` type.

**Call 3 (MEANING)** generates observations when it discovers patterns across multiple runs. These are typically `pattern` or `trait` type.

**User actions** create observations via `me.edit_profile()`. These always have `source = 'user'` and `confidence = 1.0`.

**Dream system** (post-0.2) will generate observations with `source = 'dream'` and low initial confidence.

---

## Cached Synthesis

The `self_profile` column still exists in v0.2, but its role changes. Instead of being appended to incrementally, it is **rebuilt from scratch** at each epoch creation.

The rebuild process:

1. Query all observations where `superseded_by IS NULL` and `confidence >= 0.4`
2. Group by `observation_type`
3. Ask the LLM to synthesize a coherent narrative profile from these observations
4. Store the result in `self_profile`

Between epoch creations, Call 1 and Call 3 write to the observations table only. They do not touch `self_profile` directly.

**Why cache at all?** Token budget. Injecting a synthesized narrative into Call 2/3/4 prompts costs far fewer tokens than injecting hundreds of individual observations. The cache is a compression layer, not the source of truth.

**What about contradictions?** The synthesis includes a "key contradictions" section when high-confidence observations conflict. This prevents the synthesis from papering over genuine tensions in the user's self-knowledge.

---

## User Authority

The user always wins.

`me.edit_profile(text)` creates a new observation with:
- `source = 'user'`
- `confidence = 1.0`
- `observation_type = 'trait'` (user self-reports are treated as trait-level)

Because user-sourced observations have the highest possible confidence, they dominate the cached synthesis. If the system says "tends to avoid conflict" and the user says "I confront problems directly," the user's statement takes precedence in the next synthesis rebuild.

The system-generated observation is not deleted -- it gets `superseded_by` pointing to the user's observation. The system can still see the history, but the user's word is final.

---

## What This Enables

**Traceable claims.** Every statement in the self-portrait can be traced to specific fragments. "Why does it say I avoid conflict?" becomes a query, not a mystery.

**Natural evolution.** As the user changes, old observations are superseded by new ones. The profile evolves without accumulating debris.

**Contradiction as signal.** When high-confidence observations conflict, that is itself a meaningful pattern worth surfacing to the user.

**Bounded growth.** The observations table grows, but the cached synthesis stays roughly constant in size. Token cost does not scale linearly with usage.

---

## Future: L0/L1/L2 Tier Promotion (Post-0.2)

The current design treats all observations equally (modulo confidence scores). Post-0.2 introduces a three-tier promotion system:

| Tier | Name | Criteria | Role |
|------|------|----------|------|
| L2 | Trial | New, fewer than 2 supporting runs | Candidate, not injected into prompts |
| L1 | Active | Appears in 2+ runs, not contradicted | Injected into Call 3/4 prompts |
| L0 | Compiled | Stable across 5+ runs | Part of the core self-model, injected into all calls |

This creates a natural maturation path: observations start as tentative hypotheses and earn their place through repeated confirmation. It also enables CCR (Confirm-Challenge Ratio) rigidity detection -- if an L0 observation is only ever confirmed and never challenged, the system flags potential confirmation bias.

The tier system is designed but not implemented in v0.2. The observations table schema already supports it (confidence scores map to tier thresholds), so no schema changes will be needed.
