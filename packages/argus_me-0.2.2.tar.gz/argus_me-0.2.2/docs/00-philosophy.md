# Philosophy

argus-me is a cognitive exoskeleton. It amplifies human self-cognition -- it does not replace it.

---

## Division of Labor

The system and the human are good at fundamentally different things.

| The system is good at | The human is good at |
|----------------------|---------------------|
| Tireless repetition across hundreds of interactions | Setting direction and priorities |
| Pattern tracking across months and years | Making meaning from discovered patterns |
| Never forgetting what was said three months ago | Judging what matters and what doesn't |
| Detecting contradictions between stated values and observed behavior | Deciding what to do about contradictions |

The system is a tireless observer. The human is the meaning-maker. Neither can do the other's job.

---

## The Ultimate Test

> Does the user discover more possibilities about themselves?

Not "does the system understand the user better" -- but "does the user understand themselves better because the system exists."

This is a human judgment, not a metric. If the user reads the output and thinks "I already knew all of this," the system has failed. If the user thinks "I hadn't seen it that way before," it has succeeded.

---

## Five Core Principles

### 1. Plausibility over accuracy

Insights don't need to be "correct." They need to be plausible enough to guide action and open new perspectives. Perfect accuracy about the past matters less than useful framing of the present.

*Grounded in: Weick's sensemaking theory (A-level evidence).*

### 2. Scenario narratives over probability numbers

Humans understand stories, not probabilities. When the system projects future possibilities, it tells short stories about what might happen and why -- not "there is a 63% chance of X."

*Grounded in: Schacter's constructive episodic simulation + Klein's Recognition-Primed Decision model (both A-level).*

### 3. Framework-guided emergence over passive accumulation

Raw fragments are noise. Fragments gain meaning when organized through frameworks -- entities, matters, temporal patterns, emotional arcs. The system provides structure; insights emerge from within it.

*Grounded in: Gestalt psychology + Klein's Data/Frame model.*

### 4. Iterative revision over linear stacking

New fragments can overturn old insights. The system reconstructs understanding, not just appends to it. Yesterday's confident pattern may be revised by today's contradicting evidence.

*Grounded in: Abductive reasoning + memory reconsolidation research.*

### 5. Never reduce possibilities, always expand them

The system presents patterns and hypotheses. The user decides what they mean. Every output should open doors, not close them. Dream outputs are questions, never conclusions.

---

## What argus-me Is NOT

**Not a therapist.** The system does not diagnose, treat, or simulate a therapeutic relationship. All user-facing language describes observed behavioral patterns, never psychological states. It stays firmly in wellness territory.

**Not a diary.** Fragments go in, but what comes out is not a record of what happened -- it is a structured understanding of what the patterns mean. The value is in the processing, not the storage.

**Not a recommendation engine.** The system does not tell the user what to do. It surfaces patterns the user hasn't noticed and presents scenarios they haven't considered. Direction and judgment remain with the human.

**Not a prediction engine.** The system discovers retrospective patterns and presents forward-looking scenarios. It does not predict behavior or claim to know what the user will do. The distinction matters: pattern discovery amplifies cognition; behavior prediction replaces it.
