# Data Model

Single SQLite database (`memory.db`), WAL mode. Schema v21 adds 3 new tables and 1 new column to the v19 baseline.

---

## Overview

13 tables total: 10 from v0.1 (unchanged except one added column) + 3 new.

```
+------------------+     +-------------------+     +------------------+
|    fragments     |     |      runs         |     |     epochs       |
|  (immutable      |---->|  (pipeline output)|---->|  (compressed     |
|   user input)    |     |  + epoch_id FK    |     |   memory units)  |
+------------------+     +-------------------+     +------------------+
                                |
                                v
+------------------+     +-------------------+
|  observations    |     |  insight_queue    |
|  (typed atoms    |     |  (subconscious    |
|   of self-       |     |   findings)       |
|   knowledge)     |     |                   |
+------------------+     +-------------------+
```

Four primitives drive the model:

| Primitive | Table | What it is |
|-----------|-------|-----------|
| **Fragment** | `fragments` | Atomic input from any source. Immutable after creation. |
| **Self** | `entities` (id='self') | The center node. Self-profile text lives here (cached synthesis in v0.2). |
| **Entity** | `entities` | Anything in the user's cognitive world -- person, team, org, concept. |
| **Matter** | `matters` | A current concern connecting the user to entities. Open or dismissed. |

Everything else is derived: emotions are properties of runs, relationships come from matter_entities co-occurrence, possibilities are forward projections.

---

## Existing Tables (v19, unchanged)

### fragments -- Raw input stream

```sql
CREATE TABLE fragments (
    id          TEXT PRIMARY KEY,        -- UUID v7
    type        TEXT NOT NULL,           -- 'text' / 'action'
    date        TEXT NOT NULL,           -- YYYY-MM-DD (content date)
    source      TEXT,                    -- 'ingest' / 'user_action'
    raw         TEXT,                    -- original content
    transcript  TEXT,                    -- preprocessed text (what the LLM sees)
    metadata    TEXT DEFAULT '{}',       -- JSON, type-specific fields
    processed   INTEGER DEFAULT 0,      -- 0=pending, 1=consumed
    run_id      TEXT,                    -- which run consumed this fragment
    created_at  TEXT NOT NULL
);
```

Content fields (`raw`, `transcript`, `metadata`) are immutable. Administrative fields (`processed`, `run_id`) are updated by the pipeline.

### entities -- Nodes in the cognitive world

```sql
CREATE TABLE entities (
    id               TEXT PRIMARY KEY,      -- UUID; 'self' for the user
    canonical_name   TEXT NOT NULL UNIQUE,
    dynamics         REAL DEFAULT 0.0,      -- relationship temperature (-1 to 1)
    interaction_count INTEGER DEFAULT 1,
    first_seen       TEXT NOT NULL,
    last_seen        TEXT NOT NULL,
    note             TEXT DEFAULT '',        -- user's notes
    self_profile     TEXT DEFAULT '',        -- only used for id='self'
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);
```

No `type` column -- an entity's meaning comes from which matters it participates in. No `role` column -- role is per-matter on `matter_entities`.

In v0.2, `self_profile` becomes a cached synthesis rebuilt from the observations table at each epoch boundary. Between epochs, Call 1/3 deltas still append here for real-time responsiveness.

### entity_aliases -- Name resolution

```sql
CREATE TABLE entity_aliases (
    alias      TEXT PRIMARY KEY,
    entity_id  TEXT NOT NULL REFERENCES entities(id),
    confidence REAL DEFAULT 1.0,
    source     TEXT DEFAULT 'system',   -- 'system' / 'llm' / 'user'
    created_at TEXT NOT NULL
);
```

### matters -- Current concerns

```sql
CREATE TABLE matters (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT,                    -- 4-8 char short title
    current          TEXT,                    -- current status description
    status           TEXT DEFAULT 'open',     -- open / dismissed (only two states)
    source           TEXT DEFAULT 'llm',      -- 'llm' / 'user'
    priority         REAL DEFAULT 0.5,
    opened_date      TEXT NOT NULL,
    mention_count    INTEGER DEFAULT 1,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);
```

Only two statuses: `open` and `dismissed`. A dismissed matter stops sensitizing attention.

### matter_entities -- Connections

```sql
CREATE TABLE matter_entities (
    matter_id      INTEGER NOT NULL REFERENCES matters(id),
    entity_id      TEXT NOT NULL REFERENCES entities(id),
    role_in_matter TEXT,                 -- "advisor" / "partner" / "bank"
    UNIQUE(matter_id, entity_id)
);
```

### runs -- Pipeline output (modified in v0.2)

```sql
CREATE TABLE runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    date         TEXT NOT NULL,
    run_id       TEXT NOT NULL,               -- UUID v7
    summary      TEXT NOT NULL,
    valence      REAL,                        -- emotion: pleasure-displeasure (-1 to 1)
    arousal      REAL,                        -- emotion: activation (0 to 1)
    emotion_word TEXT,
    conflict     TEXT DEFAULT '',
    gaps         TEXT DEFAULT '[]',           -- JSON array of cognitive gaps
    model_version TEXT,
    created_at   TEXT NOT NULL,
    epoch_id     INTEGER REFERENCES epochs(id)  -- NEW in v0.2, nullable
);
```

**v0.2 change**: `epoch_id` column added. Nullable. `NULL` means the run has not been consolidated into an epoch. Existing v19 rows remain with `epoch_id = NULL` and are treated as unconsolidated.

### possibilities -- Forward scenarios

```sql
CREATE TABLE possibilities (
    id                    TEXT PRIMARY KEY,   -- UUID v7
    matter_id             INTEGER REFERENCES matters(id),
    event                 TEXT NOT NULL,
    narrative             TEXT DEFAULT '',
    confidence            TEXT DEFAULT 'medium', -- high / medium / low
    prob                  REAL,                  -- internal sorting only
    historical_precedent  TEXT DEFAULT '',
    status                TEXT DEFAULT '',     -- '' / 'expected' / 'happened' / 'dismissed'
    run_id                TEXT,
    created_at            TEXT NOT NULL,
    validated_at          TEXT
);
```

### intentions -- Hidden cognitive layer

```sql
CREATE TABLE intentions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    content         TEXT NOT NULL,
    type            TEXT NOT NULL,           -- 'explicit' / 'implicit'
    confidence      REAL NOT NULL,
    status          TEXT DEFAULT 'active',   -- 'active' / 'surfaced' / 'dissolved'
    formed_date     TEXT NOT NULL,
    last_reinforced TEXT,
    related_matters TEXT,                    -- JSON: [matter_id, ...]
    evidence        TEXT,                    -- JSON: supporting evidence
    surfaced_at     TEXT,
    run_id          TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
```

Intentions are not exposed by default. They silently improve possibility quality by providing deeper context. When confidence crosses a threshold, they surface as insights.

### insight_queue -- Subconscious findings

```sql
CREATE TABLE insight_queue (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL,               -- 'stale_matter' / 'emotion_inflection' /
                                             -- 'high_freq_entity' / 'relationship_gap' /
                                             -- 'implicit_intention' / 'echo_chamber_risk' / ...
    description TEXT NOT NULL,
    evidence    TEXT,                         -- JSON
    priority    TEXT DEFAULT 'medium',
    status      TEXT DEFAULT 'pending',       -- 'pending' / 'consumed' / 'expired'
    run_id      TEXT,
    detected_at TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
```

### meta -- Schema versioning

```sql
CREATE TABLE meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
-- Preset: ('schema_version', '21')
```

---

## New Tables (v0.2)

### epochs -- Compressed memory units

```sql
CREATE TABLE epochs (
    id                       INTEGER PRIMARY KEY AUTOINCREMENT,
    start_date               TEXT NOT NULL,
    end_date                 TEXT NOT NULL,
    run_count                INTEGER NOT NULL,
    summary                  TEXT NOT NULL,          -- 50-word epoch digest
    themes                   TEXT DEFAULT '[]',      -- JSON array of theme strings
    avg_valence              REAL,
    self_model_delta         TEXT DEFAULT '',        -- changes to self-understanding in this period
    boundary_start_trigger   TEXT,                   -- 'semantic_shift' / 'time_gap' / 'max_runs'
    boundary_start_run_id    INTEGER,
    boundary_start_context_shift TEXT,               -- how context differs from previous epoch
    boundary_end_state       TEXT,                   -- user state at epoch end
    boundary_end_run_id      INTEGER,
    boundary_end_unresolved  TEXT DEFAULT '[]',      -- JSON array of unresolved matter names
    continuing_threads       TEXT DEFAULT '[]',      -- JSON array of thread objects
    created_at               TEXT NOT NULL
);
```

An epoch compresses ~14 runs (MIN=8, MAX=20) into a semantic summary with boundary annotations. Boundary fields capture how the epoch started (what triggered the segmentation) and ended (user state, unresolved concerns). `continuing_threads` tracks themes that span multiple epochs.

### observations -- Typed self-knowledge atoms

```sql
CREATE TABLE observations (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    date               TEXT NOT NULL,
    source             TEXT NOT NULL,           -- 'call_1' / 'call_3' / 'user' / 'dream'
    content            TEXT NOT NULL,           -- the observation itself
    tags               TEXT DEFAULT '[]',       -- JSON array
    confidence         REAL DEFAULT 0.5,        -- 0.0-1.0
    observation_type   TEXT DEFAULT 'behavior', -- 'behavior' / 'trait' / 'pattern'
    evidence_fragments TEXT DEFAULT '[]',       -- JSON array of fragment IDs
    superseded_by      INTEGER REFERENCES observations(id),
    run_id             TEXT,
    created_at         TEXT NOT NULL
);
```

Observations replace the flat `self_profile` text as the authoritative source of self-knowledge.

- **behavior**: what the user does ("tends to avoid conflict in work settings")
- **trait**: a stable characteristic ("values autonomy over security")
- **pattern**: a recurring cross-temporal pattern ("energy drops after social events")

Each observation links to its evidence fragments. When a newer observation supersedes an older one, `superseded_by` points to the replacement -- the original row is never deleted.

### compliance_log -- Safety audit trail

```sql
CREATE TABLE compliance_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL,
    action      TEXT NOT NULL,        -- 'observation_blocked' / 'observation_downgraded' / 'profile_delta_blocked'
    original_text TEXT NOT NULL,      -- intercepted text
    violations  TEXT NOT NULL,        -- JSON: ["CLINICAL_3", "INFERENCE_1"]
    run_id      TEXT,
    created_at  TEXT NOT NULL
);
```

Records every compliance gate interception. Used for auditing prompt compliance gaps and tuning Path B rules. The compliance gate runs deterministic regex checks before any LLM output is written to `observations` or `self_profile`.

---

## Indexes

```sql
-- Existing (v19)
CREATE INDEX idx_fragments_unprocessed ON fragments(processed, date) WHERE processed = 0;
CREATE INDEX idx_matter_entities_entity ON matter_entities(entity_id);
CREATE INDEX idx_possibilities_matter ON possibilities(matter_id, status);
CREATE INDEX idx_intentions_active ON intentions(status) WHERE status = 'active';
CREATE INDEX idx_insight_queue_pending ON insight_queue(status) WHERE status = 'pending';

-- New (v0.2)
CREATE INDEX idx_observations_source ON observations(source);
CREATE INDEX idx_observations_type ON observations(observation_type);
CREATE INDEX idx_observations_confidence ON observations(confidence);
```

---

## Migration: v19 to v21

The migration is backward compatible with no data loss. Two migration steps run automatically via `init_db()`:

**v19 → v20:**
1. Create `epochs` and `observations` tables (IF NOT EXISTS).
2. Add `epoch_id` column to `runs` (check PRAGMA table_info first -- ALTER TABLE is not idempotent).

**v20 → v21:**
3. Create `compliance_log` table (IF NOT EXISTS).
3. Create new indexes.
4. Update `meta.schema_version` to `'21'`.

All 10 existing tables remain structurally untouched (except the `runs.epoch_id` addition). Existing rows are unaffected. The `entities.self_profile` field is preserved and continues to function as the runtime read source until the first epoch triggers a full rebuild from observations.

The migration function is idempotent -- safe to run multiple times on the same database.

---

## The Feedback Loop

Every user action creates an action fragment that feeds back into the next `understand()` cycle:

| User action | Fragment created |
|------------|-----------------|
| Register alias | `type='action'`, "User confirmed: '{name}' is {entity}" |
| Dismiss matter | `type='action'`, "User no longer tracking: {name}" |
| Expect possibility | `type='action'`, "User expects: {event}" |
| Edit self-profile | `type='action'`, "User edited self-portrait" |
| Respond to gap | `type='action'`, "User answered: {response}" |
| Add note to entity | `type='action'`, "User noted on {name}: {text}" |
| Merge entities | `type='action'`, "User merged {absorbed} into {kept}" |

This loop is how the system learns from user corrections. A dismissed matter tells the system about the user's priorities. An edited self-profile tells it where its understanding was wrong.
