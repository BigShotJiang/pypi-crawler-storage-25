from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RequestContext:
    session_id: str | None = None
    gw_trace: bool | None = None
