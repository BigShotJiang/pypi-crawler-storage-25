from __future__ import annotations

import urllib.request
import urllib.error
import xml.etree.ElementTree as ET

from .request_context import RequestContext
from .exceptions import SoapFaultException

_SOAP_NS = 'http://schemas.xmlsoap.org/soap/envelope/'
_TYPES_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'


class SoapClient:
    def __init__(self, endpoint: str, debug: bool = False) -> None:
        self._endpoint = endpoint
        self._debug = debug

    def _invoke(self, soap_action: str, request_obj: object, context: RequestContext | None) -> ET.Element:
        ctx = context or RequestContext()
        request_el = request_obj.to_xml()  # type: ignore[attr-defined]
        body_xml = ET.tostring(request_el, encoding="unicode")
        envelope = self._build_envelope(body_xml, ctx)

        if self._debug:
            print(">>> SOAP REQUEST")
            print(envelope)

        req = urllib.request.Request(
            self._endpoint,
            data=envelope.encode("utf-8"),
            headers={
                "Content-Type": "text/xml; charset=UTF-8",
                "SOAPAction": soap_action,
            },
        )
        try:
            with urllib.request.urlopen(req) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            raw = exc.read()

        if self._debug:
            print("<<< SOAP RESPONSE")
            print(raw.decode("utf-8", errors="replace"))

        doc = ET.fromstring(raw)
        body = doc.find('{http://schemas.xmlsoap.org/soap/envelope/}Body')
        if body is None:
            raise ValueError("SOAP response is missing a Body element")
        payload = next(iter(body), None)
        if payload is None:
            raise ValueError("SOAP Body is empty")
        local = payload.tag.split("}", 1)[-1] if "}" in payload.tag else payload.tag
        if local == "Fault":
            raise self._parse_fault(payload)
        return payload

    @staticmethod
    def _parse_fault(fault: ET.Element) -> SoapFaultException:
        def _text(tag: str) -> str | None:
            el = fault.find(tag)
            return el.text if el is not None else None
        return SoapFaultException(
            _text("faultcode") or "",
            _text("faultstring") or "",
            _text("detail"),
        )

    @staticmethod
    def _escape(value: str) -> str:
        return (
            value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&apos;")
        )

    def _build_envelope(self, body_xml: str, ctx: RequestContext) -> str:
        parts = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<soapenv:Envelope xmlns:soapenv="' + _SOAP_NS + '" xmlns:typ="' + _TYPES_NS + '">',
            "<soapenv:Header>",
        ]
        if ctx.session_id:
            parts.append("<typ:session>" + self._escape(ctx.session_id) + "</typ:session>")
        if ctx.gw_trace is not None:
            parts.append("<typ:gwTrace>" + ("true" if ctx.gw_trace else "false") + "</typ:gwTrace>")
        parts += [
            "</soapenv:Header>",
            "<soapenv:Body>" + body_xml + "</soapenv:Body>",
            "</soapenv:Envelope>",
        ]
        return "".join(parts)
