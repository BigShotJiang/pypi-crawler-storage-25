from __future__ import annotations


class SoapFaultException(Exception):
    def __init__(self, fault_code: str, fault_string: str, detail: str | None = None) -> None:
        super().__init__(f"{fault_code}: {fault_string}")
        self.fault_code = fault_code
        self.fault_string = fault_string
        self.detail = detail
