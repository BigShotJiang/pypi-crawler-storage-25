from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetQuickMessagesResponse:
    start_date: datetime | None = None
    items: Items | None = None
    status: Status | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getQuickMessagesResponse'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{http://schemas.novell.com/2005/01/GroupWise/types}}startDate')
            _c.text = self.start_date.isoformat()
        if self.items is not None:
            self.items.to_xml(_el, f'{{{_NS}}}items')
        if self.status is not None:
            self.status.to_xml(_el, f'{{{_NS}}}status')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{http://schemas.novell.com/2005/01/GroupWise/types}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}items')
        if _c is not None:
            from gwsoap.types.Items import Items
            _f['items'] = Items.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}status')
        if _c is not None:
            from gwsoap.types.Status import Status
            _f['status'] = Status.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetQuickMessagesResponse:
        return cls(**cls._parse_fields(_el))
