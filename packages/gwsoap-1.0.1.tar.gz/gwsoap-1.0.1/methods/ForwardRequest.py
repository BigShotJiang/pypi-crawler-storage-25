from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class ForwardRequest:
    id: str | None = None
    view: View | None = None
    embed: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}forwardRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.view is not None:
            self.view.to_xml(_el, f'{{{_NS}}}view')
        if self.embed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}embed')
            _c.text = ('true' if self.embed else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}view')
        if _c is not None:
            from gwsoap.types.View import View
            _f['view'] = View.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}embed')
        if _c is not None:
            if _c.text is not None:
                _f['embed'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ForwardRequest:
        return cls(**cls._parse_fields(_el))
