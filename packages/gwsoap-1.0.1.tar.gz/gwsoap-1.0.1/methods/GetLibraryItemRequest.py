from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetLibraryItemRequest:
    library: str | None = None
    document_number: int | None = None
    version_number: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getLibraryItemRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.library is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}library')
            _c.text = self.library
        if self.document_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}documentNumber')
            _c.text = str(self.document_number)
        if self.version_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionNumber')
            _c.text = self.version_number

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}library')
        if _c is not None:
            if _c.text is not None:
                _f['library'] = _c.text
        _c = _el.find(f'{{{_NS}}}documentNumber')
        if _c is not None:
            if _c.text is not None:
                _f['document_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}versionNumber')
        if _c is not None:
            if _c.text is not None:
                _f['version_number'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetLibraryItemRequest:
        return cls(**cls._parse_fields(_el))
