from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class StartFreeBusySessionRequest:
    users: FreeBusyUserList | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}startFreeBusySessionRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.users is not None:
            self.users.to_xml(_el, f'{{{_NS}}}users')
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}startDate')
            _c.text = self.start_date.isoformat()
        if self.end_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}endDate')
            _c.text = self.end_date.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}users')
        if _c is not None:
            from gwsoap.types.FreeBusyUserList import FreeBusyUserList
            _f['users'] = FreeBusyUserList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}endDate')
        if _c is not None:
            if _c.text is not None:
                _f['end_date'] = datetime.fromisoformat(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> StartFreeBusySessionRequest:
        return cls(**cls._parse_fields(_el))
