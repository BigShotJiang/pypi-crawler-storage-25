from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class RemoveProxyUserResponse:
    status: Status | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}removeProxyUserResponse'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.status is not None:
            self.status.to_xml(_el, f'{{{_NS}}}status')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}status')
        if _c is not None:
            from gwsoap.types.Status import Status
            _f['status'] = Status.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RemoveProxyUserResponse:
        return cls(**cls._parse_fields(_el))
