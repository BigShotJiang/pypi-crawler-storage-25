from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetFreeBusyResponse:
    free_busy_stats: FreeBusyStats | None = None
    free_busy_info: FreeBusyInfoList | None = None
    status: Status | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getFreeBusyResponse'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.free_busy_stats is not None:
            self.free_busy_stats.to_xml(_el, f'{{{_NS}}}freeBusyStats')
        if self.free_busy_info is not None:
            self.free_busy_info.to_xml(_el, f'{{{_NS}}}freeBusyInfo')
        if self.status is not None:
            self.status.to_xml(_el, f'{{{_NS}}}status')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}freeBusyStats')
        if _c is not None:
            from gwsoap.types.FreeBusyStats import FreeBusyStats
            _f['free_busy_stats'] = FreeBusyStats.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}freeBusyInfo')
        if _c is not None:
            from gwsoap.types.FreeBusyInfoList import FreeBusyInfoList
            _f['free_busy_info'] = FreeBusyInfoList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}status')
        if _c is not None:
            from gwsoap.types.Status import Status
            _f['status'] = Status.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetFreeBusyResponse:
        return cls(**cls._parse_fields(_el))
