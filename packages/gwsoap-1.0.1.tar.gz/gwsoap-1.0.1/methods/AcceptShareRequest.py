from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class AcceptShareRequest:
    id: str | None = None
    name: str | None = None
    container: str | None = None
    description: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}acceptShareRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{http://schemas.novell.com/2005/01/GroupWise/types}}description')
            _c.text = self.description

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{http://schemas.novell.com/2005/01/GroupWise/types}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AcceptShareRequest:
        return cls(**cls._parse_fields(_el))
