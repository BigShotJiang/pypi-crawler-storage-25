from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class RemoveCustomDefinitionRequest:
    customs: CustomList | None = None
    books: bool | None = None
    do_asynchronous: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}removeCustomDefinitionRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.customs is not None:
            self.customs.to_xml(_el, f'{{{_NS}}}customs')
        if self.books is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}books')
            _c.text = ('true' if self.books else 'false')
        if self.do_asynchronous is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}doAsynchronous')
            _c.text = ('true' if self.do_asynchronous else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}customs')
        if _c is not None:
            from gwsoap.types.CustomList import CustomList
            _f['customs'] = CustomList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}books')
        if _c is not None:
            if _c.text is not None:
                _f['books'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}doAsynchronous')
        if _c is not None:
            if _c.text is not None:
                _f['do_asynchronous'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RemoveCustomDefinitionRequest:
        return cls(**cls._parse_fields(_el))
