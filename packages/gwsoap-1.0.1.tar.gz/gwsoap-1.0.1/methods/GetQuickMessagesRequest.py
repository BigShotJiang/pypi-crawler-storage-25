from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetQuickMessagesRequest:
    list: MessageList | None = None
    start_date: datetime | None = None
    container: str | None = None
    types: MessageTypeList | None = None
    source: ItemSourceList | None = None
    view: View | None = None
    count: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getQuickMessagesRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.list is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}list')
            _c.text = self.list.value
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{http://schemas.novell.com/2005/01/GroupWise/types}}startDate')
            _c.text = self.start_date.isoformat()
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.types is not None:
            self.types.to_xml(_el, f'{{{_NS}}}types')
        if self.source is not None:
            self.source.to_xml(_el, f'{{{_NS}}}source')
        if self.view is not None:
            self.view.to_xml(_el, f'{{{_NS}}}view')
        if self.count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}count')
            _c.text = str(self.count)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}list')
        if _c is not None:
            from gwsoap.types.MessageList import MessageList
            if _c.text is not None:
                _f['list'] = MessageList(_c.text)
        _c = _el.find(f'{{http://schemas.novell.com/2005/01/GroupWise/types}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}types')
        if _c is not None:
            from gwsoap.types.MessageTypeList import MessageTypeList
            _f['types'] = MessageTypeList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}source')
        if _c is not None:
            from gwsoap.types.ItemSourceList import ItemSourceList
            _f['source'] = ItemSourceList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}view')
        if _c is not None:
            from gwsoap.types.View import View
            _f['view'] = View.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}count')
        if _c is not None:
            if _c.text is not None:
                _f['count'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetQuickMessagesRequest:
        return cls(**cls._parse_fields(_el))
