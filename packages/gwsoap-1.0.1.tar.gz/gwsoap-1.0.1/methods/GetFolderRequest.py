from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetFolderRequest:
    id: str | None = None
    folder_type: FolderType | None = None
    types: MessageTypeList | None = None
    source: ItemSourceList | None = None
    view: View | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getFolderRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.folder_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}folderType')
            _c.text = self.folder_type.value
        if self.types is not None:
            self.types.to_xml(_el, f'{{{_NS}}}types')
        if self.source is not None:
            self.source.to_xml(_el, f'{{{_NS}}}source')
        if self.view is not None:
            self.view.to_xml(_el, f'{{{_NS}}}view')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}folderType')
        if _c is not None:
            from gwsoap.types.FolderType import FolderType
            if _c.text is not None:
                _f['folder_type'] = FolderType(_c.text)
        _c = _el.find(f'{{{_NS}}}types')
        if _c is not None:
            from gwsoap.types.MessageTypeList import MessageTypeList
            _f['types'] = MessageTypeList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}source')
        if _c is not None:
            from gwsoap.types.ItemSourceList import ItemSourceList
            _f['source'] = ItemSourceList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}view')
        if _c is not None:
            from gwsoap.types.View import View
            _f['view'] = View.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetFolderRequest:
        return cls(**cls._parse_fields(_el))
