from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class LoginRequest:
    auth: Authentication | None = None
    language: str | None = None
    version: Decimal | None = None
    application: str | None = None
    userid: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}loginRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.auth is not None:
            self.auth.to_xml(_el, f'{{{_NS}}}auth')
        if self.language is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}language')
            _c.text = self.language
        if self.version is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}version')
            _c.text = str(self.version)
        if self.application is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}application')
            _c.text = self.application
        if self.userid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userid')
            _c.text = ('true' if self.userid else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}auth')
        if _c is not None:
            from gwsoap.types.Authentication import Authentication
            _f['auth'] = Authentication.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}language')
        if _c is not None:
            if _c.text is not None:
                _f['language'] = _c.text
        _c = _el.find(f'{{{_NS}}}version')
        if _c is not None:
            if _c.text is not None:
                _f['version'] = Decimal(_c.text)
        _c = _el.find(f'{{{_NS}}}application')
        if _c is not None:
            if _c.text is not None:
                _f['application'] = _c.text
        _c = _el.find(f'{{{_NS}}}userid')
        if _c is not None:
            if _c.text is not None:
                _f['userid'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> LoginRequest:
        return cls(**cls._parse_fields(_el))
