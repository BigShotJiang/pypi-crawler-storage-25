from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetItemsRequest:
    container: str | None = None
    view: View | None = None
    filter: Filter | None = None
    items: ItemRefList | None = None
    count: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getItemsRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.view is not None:
            self.view.to_xml(_el, f'{{{_NS}}}view')
        if self.filter is not None:
            self.filter.to_xml(_el, f'{{{_NS}}}filter')
        if self.items is not None:
            self.items.to_xml(_el, f'{{{_NS}}}items')
        if self.count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}count')
            _c.text = str(self.count)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}view')
        if _c is not None:
            from gwsoap.types.View import View
            _f['view'] = View.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}filter')
        if _c is not None:
            from gwsoap.types.Filter import Filter
            _f['filter'] = Filter.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}items')
        if _c is not None:
            from gwsoap.types.ItemRefList import ItemRefList
            _f['items'] = ItemRefList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}count')
        if _c is not None:
            if _c.text is not None:
                _f['count'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetItemsRequest:
        return cls(**cls._parse_fields(_el))
