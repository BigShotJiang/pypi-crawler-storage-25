from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class GetFolderListRequest:
    parent: str | None = None
    view: View | None = None
    recurse: bool | None = None
    imap: bool | None = None
    nntp: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getFolderListRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.parent is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}parent')
            _c.text = self.parent
        if self.view is not None:
            self.view.to_xml(_el, f'{{{_NS}}}view')
        if self.recurse is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}recurse')
            _c.text = ('true' if self.recurse else 'false')
        if self.imap is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}imap')
            _c.text = ('true' if self.imap else 'false')
        if self.nntp is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}nntp')
            _c.text = ('true' if self.nntp else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}parent')
        if _c is not None:
            if _c.text is not None:
                _f['parent'] = _c.text
        _c = _el.find(f'{{{_NS}}}view')
        if _c is not None:
            from gwsoap.types.View import View
            _f['view'] = View.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}recurse')
        if _c is not None:
            if _c.text is not None:
                _f['recurse'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}imap')
        if _c is not None:
            if _c.text is not None:
                _f['imap'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}nntp')
        if _c is not None:
            if _c.text is not None:
                _f['nntp'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetFolderListRequest:
        return cls(**cls._parse_fields(_el))
