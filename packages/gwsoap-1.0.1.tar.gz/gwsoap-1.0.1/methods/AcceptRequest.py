from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class AcceptRequest:
    items: ItemRefList | None = None
    comment: str | None = None
    accept_level: AcceptLevel | None = None
    recurrence_all_instances: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}acceptRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.items is not None:
            self.items.to_xml(_el, f'{{{_NS}}}items')
        if self.comment is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}comment')
            _c.text = self.comment
        if self.accept_level is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}acceptLevel')
            _c.text = self.accept_level.value
        if self.recurrence_all_instances is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}recurrenceAllInstances')
            _c.text = str(self.recurrence_all_instances)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}items')
        if _c is not None:
            from gwsoap.types.ItemRefList import ItemRefList
            _f['items'] = ItemRefList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}comment')
        if _c is not None:
            if _c.text is not None:
                _f['comment'] = _c.text
        _c = _el.find(f'{{{_NS}}}acceptLevel')
        if _c is not None:
            from gwsoap.types.AcceptLevel import AcceptLevel
            if _c.text is not None:
                _f['accept_level'] = AcceptLevel(_c.text)
        _c = _el.find(f'{{{_NS}}}recurrenceAllInstances')
        if _c is not None:
            if _c.text is not None:
                _f['recurrence_all_instances'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AcceptRequest:
        return cls(**cls._parse_fields(_el))
