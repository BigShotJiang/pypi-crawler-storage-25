from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class MoveItemRequest:
    id: str | None = None
    container: str | None = None
    from_value: str | None = None
    before: str | None = None
    after: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}moveItemRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.from_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}from')
            _c.text = self.from_value
        if self.before is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}before')
            _c.text = self.before
        if self.after is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}after')
            _c.text = self.after

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            if _c.text is not None:
                _f['from_value'] = _c.text
        _c = _el.find(f'{{{_NS}}}before')
        if _c is not None:
            if _c.text is not None:
                _f['before'] = _c.text
        _c = _el.find(f'{{{_NS}}}after')
        if _c is not None:
            if _c.text is not None:
                _f['after'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> MoveItemRequest:
        return cls(**cls._parse_fields(_el))
