from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class AddMembersRequest:
    container: str | None = None
    members: GroupMemberList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}addMembersRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.members is not None:
            self.members.to_xml(_el, f'{{{_NS}}}members')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}members')
        if _c is not None:
            from gwsoap.types.GroupMemberList import GroupMemberList
            _f['members'] = GroupMemberList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AddMembersRequest:
        return cls(**cls._parse_fields(_el))
