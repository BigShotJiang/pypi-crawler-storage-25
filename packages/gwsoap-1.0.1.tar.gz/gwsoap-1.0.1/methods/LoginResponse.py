from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class LoginResponse:
    session: str | None = None
    userinfo: UserInfo | None = None
    entry: AccessRightEntry | None = None
    gw_version: str | None = None
    build: str | None = None
    redirect_to_host: list[Host] = _field(default_factory=list)
    server_utc_time: datetime | None = None
    status: Status | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}loginResponse'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.session is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}session')
            _c.text = self.session
        if self.userinfo is not None:
            self.userinfo.to_xml(_el, f'{{{_NS}}}userinfo')
        if self.entry is not None:
            self.entry.to_xml(_el, f'{{{_NS}}}entry')
        if self.gw_version is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}gwVersion')
            _c.text = self.gw_version
        if self.build is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}build')
            _c.text = self.build
        for _v in self.redirect_to_host:
            _v.to_xml(_el, f'{{{_NS}}}redirectToHost')
        if self.server_utc_time is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}serverUTCTime')
            _c.text = self.server_utc_time.isoformat()
        if self.status is not None:
            self.status.to_xml(_el, f'{{{_NS}}}status')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}session')
        if _c is not None:
            if _c.text is not None:
                _f['session'] = _c.text
        _c = _el.find(f'{{{_NS}}}userinfo')
        if _c is not None:
            from gwsoap.types.UserInfo import UserInfo
            _f['userinfo'] = UserInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}entry')
        if _c is not None:
            from gwsoap.types.AccessRightEntry import AccessRightEntry
            _f['entry'] = AccessRightEntry.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}gwVersion')
        if _c is not None:
            if _c.text is not None:
                _f['gw_version'] = _c.text
        _c = _el.find(f'{{{_NS}}}build')
        if _c is not None:
            if _c.text is not None:
                _f['build'] = _c.text
        from gwsoap.types.Host import Host
        _f['redirect_to_host'] = [Host.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}redirectToHost')]
        _c = _el.find(f'{{{_NS}}}serverUTCTime')
        if _c is not None:
            if _c.text is not None:
                _f['server_utc_time'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}status')
        if _c is not None:
            from gwsoap.types.Status import Status
            _f['status'] = Status.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> LoginResponse:
        return cls(**cls._parse_fields(_el))
