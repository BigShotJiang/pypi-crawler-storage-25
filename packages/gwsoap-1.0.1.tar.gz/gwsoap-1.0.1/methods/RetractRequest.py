from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class RetractRequest:
    items: ItemRefList | None = None
    comment: str | None = None
    retracting_all_instances: bool | None = None
    retract_caused_by_resend: bool | None = None
    retract_type: RetractType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}retractRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.items is not None:
            self.items.to_xml(_el, f'{{{_NS}}}items')
        if self.comment is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}comment')
            _c.text = self.comment
        if self.retracting_all_instances is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retractingAllInstances')
            _c.text = ('true' if self.retracting_all_instances else 'false')
        if self.retract_caused_by_resend is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retractCausedByResend')
            _c.text = ('true' if self.retract_caused_by_resend else 'false')
        if self.retract_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retractType')
            _c.text = self.retract_type.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}items')
        if _c is not None:
            from gwsoap.types.ItemRefList import ItemRefList
            _f['items'] = ItemRefList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}comment')
        if _c is not None:
            if _c.text is not None:
                _f['comment'] = _c.text
        _c = _el.find(f'{{{_NS}}}retractingAllInstances')
        if _c is not None:
            if _c.text is not None:
                _f['retracting_all_instances'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}retractCausedByResend')
        if _c is not None:
            if _c.text is not None:
                _f['retract_caused_by_resend'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}retractType')
        if _c is not None:
            from gwsoap.types.RetractType import RetractType
            if _c.text is not None:
                _f['retract_type'] = RetractType(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RetractRequest:
        return cls(**cls._parse_fields(_el))
