from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class ModifyPasswordRequest:
    old: str | None = None
    new_value: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}modifyPasswordRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.old is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}old')
            _c.text = self.old
        if self.new_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}new')
            _c.text = self.new_value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}old')
        if _c is not None:
            if _c.text is not None:
                _f['old'] = _c.text
        _c = _el.find(f'{{{_NS}}}new')
        if _c is not None:
            if _c.text is not None:
                _f['new_value'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ModifyPasswordRequest:
        return cls(**cls._parse_fields(_el))
