from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class DelegateRequest:
    id: str | None = None
    comment_to_organizer: str | None = None
    comment_to_delegatee: str | None = None
    distribution: Distribution | None = None
    recurrence_all_instances: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}delegateRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.comment_to_organizer is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}commentToOrganizer')
            _c.text = self.comment_to_organizer
        if self.comment_to_delegatee is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}commentToDelegatee')
            _c.text = self.comment_to_delegatee
        if self.distribution is not None:
            self.distribution.to_xml(_el, f'{{{_NS}}}distribution')
        if self.recurrence_all_instances is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}recurrenceAllInstances')
            _c.text = str(self.recurrence_all_instances)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}commentToOrganizer')
        if _c is not None:
            if _c.text is not None:
                _f['comment_to_organizer'] = _c.text
        _c = _el.find(f'{{{_NS}}}commentToDelegatee')
        if _c is not None:
            if _c.text is not None:
                _f['comment_to_delegatee'] = _c.text
        _c = _el.find(f'{{{_NS}}}distribution')
        if _c is not None:
            from gwsoap.types.Distribution import Distribution
            _f['distribution'] = Distribution.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}recurrenceAllInstances')
        if _c is not None:
            if _c.text is not None:
                _f['recurrence_all_instances'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> DelegateRequest:
        return cls(**cls._parse_fields(_el))
