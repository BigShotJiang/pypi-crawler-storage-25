from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class ReadCursorRequest:
    container: str | None = None
    cursor: int | None = None
    forward: bool | None = None
    position: CursorSeek | None = None
    count: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}readCursorRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.cursor is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}cursor')
            _c.text = str(self.cursor)
        if self.forward is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}forward')
            _c.text = ('true' if self.forward else 'false')
        if self.position is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}position')
            _c.text = self.position.value
        if self.count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}count')
            _c.text = str(self.count)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}cursor')
        if _c is not None:
            if _c.text is not None:
                _f['cursor'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}forward')
        if _c is not None:
            if _c.text is not None:
                _f['forward'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}position')
        if _c is not None:
            from gwsoap.types.CursorSeek import CursorSeek
            if _c.text is not None:
                _f['position'] = CursorSeek(_c.text)
        _c = _el.find(f'{{{_NS}}}count')
        if _c is not None:
            if _c.text is not None:
                _f['count'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ReadCursorRequest:
        return cls(**cls._parse_fields(_el))
