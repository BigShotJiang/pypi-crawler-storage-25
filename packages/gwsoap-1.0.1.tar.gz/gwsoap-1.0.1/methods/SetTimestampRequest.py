from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class SetTimestampRequest:
    backup: datetime | None = None
    retention: datetime | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}setTimestampRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.backup is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}backup')
            _c.text = self.backup.isoformat()
        if self.retention is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retention')
            _c.text = self.retention.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}backup')
        if _c is not None:
            if _c.text is not None:
                _f['backup'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}retention')
        if _c is not None:
            if _c.text is not None:
                _f['retention'] = datetime.fromisoformat(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SetTimestampRequest:
        return cls(**cls._parse_fields(_el))
