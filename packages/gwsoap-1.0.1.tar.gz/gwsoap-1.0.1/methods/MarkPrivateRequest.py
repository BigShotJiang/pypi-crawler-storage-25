from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/methods'

@dataclass
class MarkPrivateRequest:
    items: ItemRefList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}markPrivateRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.items is not None:
            self.items.to_xml(_el, f'{{{_NS}}}items')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}items')
        if _c is not None:
            from gwsoap.types.ItemRefList import ItemRefList
            _f['items'] = ItemRefList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> MarkPrivateRequest:
        return cls(**cls._parse_fields(_el))
