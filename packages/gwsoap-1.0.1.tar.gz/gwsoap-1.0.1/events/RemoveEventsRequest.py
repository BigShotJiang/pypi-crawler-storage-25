from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class RemoveEventsRequest:
    key: str | None = None
    from_value: datetime | None = None
    until: datetime | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}removeEventsRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.key is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}key')
            _c.text = self.key
        if self.from_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}from')
            _c.text = self.from_value.isoformat()
        if self.until is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}until')
            _c.text = self.until.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}key')
        if _c is not None:
            if _c.text is not None:
                _f['key'] = _c.text
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            if _c.text is not None:
                _f['from_value'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}until')
        if _c is not None:
            if _c.text is not None:
                _f['until'] = datetime.fromisoformat(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RemoveEventsRequest:
        return cls(**cls._parse_fields(_el))
