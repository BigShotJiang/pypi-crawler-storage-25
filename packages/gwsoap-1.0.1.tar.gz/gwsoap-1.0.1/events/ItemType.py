from __future__ import annotations

from enum import Enum


class ItemType(str, Enum):
    ADDRESSBOOKITEM = 'AddressBookItem'
    APPOINTMENT = 'Appointment'
    CALENDARITEM = 'CalendarItem'
    CONTACT = 'Contact'
    GROUP = 'Group'
    MAIL = 'Mail'
    NOTE = 'Note'
    ORGANIZATION = 'Organization'
    PHONEMESSAGE = 'PhoneMessage'
    RESOURCE = 'Resource'
    TASK = 'Task'
    DOCUMENTREF = 'DocumentRef'
