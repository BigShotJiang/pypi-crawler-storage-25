from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field as _field
from gwsoap.events.Field import Field

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class FieldList:
    value: list[Field] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FieldList'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        _el.text = ' '.join(str(_v) for _v in self.value)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        return {'value': [_v for _v in (_el.text or '').split() if _v]}

    @classmethod
    def from_xml(cls, _el: ET.Element) -> FieldList:
        return cls(**cls._parse_fields(_el))
