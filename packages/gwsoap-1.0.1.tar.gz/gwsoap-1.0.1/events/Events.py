from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from gwsoap._utils import iso_duration as _iso_duration, parse_duration as _parse_duration
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class Events:
    key: str | None = None
    persistence: timedelta | None = None
    ip_address: str | None = None
    port: int | None = None
    http: bool | None = None
    definition: EventDefinition | None = None
    enabled: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Events'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.key is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}key')
            _c.text = self.key
        if self.persistence is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}persistence')
            _c.text = _iso_duration(self.persistence)
        if self.ip_address is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}ipAddress')
            _c.text = self.ip_address
        if self.port is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}port')
            _c.text = str(self.port)
        if self.http is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}http')
            _c.text = ('true' if self.http else 'false')
        if self.definition is not None:
            self.definition.to_xml(_el, f'{{{_NS}}}definition')
        if self.enabled is not None:
            _el.set('enabled', ('true' if self.enabled else 'false'))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}key')
        if _c is not None:
            if _c.text is not None:
                _f['key'] = _c.text
        _c = _el.find(f'{{{_NS}}}persistence')
        if _c is not None:
            if _c.text is not None:
                _f['persistence'] = _parse_duration(_c.text)
        _c = _el.find(f'{{{_NS}}}ipAddress')
        if _c is not None:
            if _c.text is not None:
                _f['ip_address'] = _c.text
        _c = _el.find(f'{{{_NS}}}port')
        if _c is not None:
            if _c.text is not None:
                _f['port'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}http')
        if _c is not None:
            if _c.text is not None:
                _f['http'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}definition')
        if _c is not None:
            from gwsoap.events.EventDefinition import EventDefinition
            _f['definition'] = EventDefinition.from_xml(_c)
        _v = _el.get('enabled')
        if _v is not None:
            _f['enabled'] = ((_v) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Events:
        return cls(**cls._parse_fields(_el))
