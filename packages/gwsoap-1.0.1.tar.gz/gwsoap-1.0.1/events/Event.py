from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class Event:
    event: EventType | None = None
    id: str | None = None
    time_stamp: datetime | None = None
    field: FieldList | None = None
    container: str | None = None
    from_value: str | None = None
    key: str | None = None
    uid: int | None = None
    type: ItemType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Event'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.event is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}event')
            _c.text = self.event.value
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.time_stamp is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}timeStamp')
            _c.text = self.time_stamp.isoformat()
        if self.field is not None:
            self.field.to_xml(_el, f'{{{_NS}}}field')
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.from_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}from')
            _c.text = self.from_value
        if self.key is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}key')
            _c.text = self.key
        if self.uid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}uid')
            _c.text = str(self.uid)
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}event')
        if _c is not None:
            from gwsoap.events.EventType import EventType
            if _c.text is not None:
                _f['event'] = EventType(_c.text)
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}timeStamp')
        if _c is not None:
            if _c.text is not None:
                _f['time_stamp'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}field')
        if _c is not None:
            from gwsoap.events.FieldList import FieldList
            _f['field'] = FieldList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            if _c.text is not None:
                _f['from_value'] = _c.text
        _c = _el.find(f'{{{_NS}}}key')
        if _c is not None:
            if _c.text is not None:
                _f['key'] = _c.text
        _c = _el.find(f'{{{_NS}}}uid')
        if _c is not None:
            if _c.text is not None:
                _f['uid'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.events.ItemType import ItemType
            if _c.text is not None:
                _f['type'] = ItemType(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Event:
        return cls(**cls._parse_fields(_el))
