from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class ContainerList:
    container: list[str] = _field(default_factory=list)
    not_value: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ContainerList'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.container:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = _v
        if self.not_value is not None:
            _el.set('not', ('true' if self.not_value else 'false'))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _f['container'] = [_c.text for _c in _el.findall(f'{{{_NS}}}container') if _c.text is not None]
        _v = _el.get('not')
        if _v is not None:
            _f['not_value'] = ((_v) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ContainerList:
        return cls(**cls._parse_fields(_el))
