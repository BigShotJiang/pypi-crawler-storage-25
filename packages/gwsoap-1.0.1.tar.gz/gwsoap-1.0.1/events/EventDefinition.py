from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class EventDefinition:
    events: EventTypeList | None = None
    type: ItemTypeList | None = None
    field: FieldList | None = None
    containers: ContainerList | None = None
    sub_type: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}EventDefinition'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.events is not None:
            self.events.to_xml(_el, f'{{{_NS}}}events')
        if self.type is not None:
            self.type.to_xml(_el, f'{{{_NS}}}type')
        if self.field is not None:
            self.field.to_xml(_el, f'{{{_NS}}}field')
        if self.containers is not None:
            self.containers.to_xml(_el, f'{{{_NS}}}containers')
        if self.sub_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}subType')
            _c.text = self.sub_type

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}events')
        if _c is not None:
            from gwsoap.events.EventTypeList import EventTypeList
            _f['events'] = EventTypeList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.events.ItemTypeList import ItemTypeList
            _f['type'] = ItemTypeList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}field')
        if _c is not None:
            from gwsoap.events.FieldList import FieldList
            _f['field'] = FieldList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}containers')
        if _c is not None:
            from gwsoap.events.ContainerList import ContainerList
            _f['containers'] = ContainerList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}subType')
        if _c is not None:
            if _c.text is not None:
                _f['sub_type'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> EventDefinition:
        return cls(**cls._parse_fields(_el))
