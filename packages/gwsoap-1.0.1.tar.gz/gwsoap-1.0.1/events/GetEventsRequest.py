from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/events'

@dataclass
class GetEventsRequest:
    key: str | None = None
    from_value: datetime | None = None
    until: datetime | None = None
    uid: int | None = None
    count: int | None = None
    remove: bool | None = None
    notify: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}getEventsRequest'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.key is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}key')
            _c.text = self.key
        if self.from_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}from')
            _c.text = self.from_value.isoformat()
        if self.until is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}until')
            _c.text = self.until.isoformat()
        if self.uid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}uid')
            _c.text = str(self.uid)
        if self.count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}count')
            _c.text = str(self.count)
        if self.remove is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}remove')
            _c.text = ('true' if self.remove else 'false')
        if self.notify is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}notify')
            _c.text = ('true' if self.notify else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}key')
        if _c is not None:
            if _c.text is not None:
                _f['key'] = _c.text
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            if _c.text is not None:
                _f['from_value'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}until')
        if _c is not None:
            if _c.text is not None:
                _f['until'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}uid')
        if _c is not None:
            if _c.text is not None:
                _f['uid'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}count')
        if _c is not None:
            if _c.text is not None:
                _f['count'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}remove')
        if _c is not None:
            if _c.text is not None:
                _f['remove'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}notify')
        if _c is not None:
            if _c.text is not None:
                _f['notify'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GetEventsRequest:
        return cls(**cls._parse_fields(_el))
