from __future__ import annotations

import base64
import re
from datetime import timedelta


def b64enc(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def b64dec(s: str) -> bytes:
    return base64.b64decode(s)


def iso_duration(td: timedelta) -> str:
    total = int(td.total_seconds())
    sign = "-" if total < 0 else ""
    total = abs(total)
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    return f"{sign}P{days}DT{hours}H{minutes}M{seconds}S"


def parse_duration(s: str) -> timedelta:
    m = re.fullmatch(
        r"(-?)P(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)D)?"
        r"(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?",
        s,
    )
    if not m:
        raise ValueError(f"Invalid ISO 8601 duration: {s!r}")
    sign = -1 if m.group(1) == "-" else 1
    years = int(m.group(2) or 0)
    months = int(m.group(3) or 0)
    days = int(m.group(4) or 0)
    hours = int(m.group(5) or 0)
    minutes = int(m.group(6) or 0)
    seconds = float(m.group(7) or 0)
    total_days = years * 365 + months * 30 + days
    return sign * timedelta(days=total_days, hours=hours, minutes=minutes, seconds=seconds)
