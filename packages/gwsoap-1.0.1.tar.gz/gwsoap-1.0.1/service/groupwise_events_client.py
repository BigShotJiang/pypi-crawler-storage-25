from __future__ import annotations

from gwsoap.soap.soap_client import SoapClient
from gwsoap.soap.request_context import RequestContext
from gwsoap.soap.exceptions import SoapFaultException
from gwsoap.events import *

DEFAULT_ENDPOINT = 'http://localhost:7191'

class GroupWiseEventsClient(SoapClient):
    def __init__(self, endpoint: str = DEFAULT_ENDPOINT, debug: bool = False) -> None:
        super().__init__(endpoint, debug)

    def clean_event_configuration(self, request: CleanEventConfigurationRequest, context: RequestContext | None = None) -> CleanEventConfigurationResponse:
        _el = self._invoke('cleanEventConfigurationRequest', request, context)
        return CleanEventConfigurationResponse.from_xml(_el)

    def configure_events(self, request: ConfigureEventsRequest, context: RequestContext | None = None) -> ConfigureEventsResponse:
        _el = self._invoke('configureEventsRequest', request, context)
        return ConfigureEventsResponse.from_xml(_el)

    def get_event_configuration(self, request: GetEventConfigurationRequest, context: RequestContext | None = None) -> GetEventConfigurationResponse:
        _el = self._invoke('getEventConfigurationRequest', request, context)
        return GetEventConfigurationResponse.from_xml(_el)

    def get_events(self, request: GetEventsRequest, context: RequestContext | None = None) -> GetEventsResponse:
        _el = self._invoke('getEventsRequest', request, context)
        return GetEventsResponse.from_xml(_el)

    def remove_event_configuration(self, request: RemoveEventConfigurationRequest, context: RequestContext | None = None) -> RemoveEventConfigurationResponse:
        _el = self._invoke('removeEventConfigurationRequest', request, context)
        return RemoveEventConfigurationResponse.from_xml(_el)

    def remove_events(self, request: RemoveEventsRequest, context: RequestContext | None = None) -> RemoveEventsResponse:
        _el = self._invoke('removeEventsRequest', request, context)
        return RemoveEventsResponse.from_xml(_el)

