from __future__ import annotations

from gwsoap.soap.soap_client import SoapClient
from gwsoap.soap.request_context import RequestContext
from gwsoap.soap.exceptions import SoapFaultException
from gwsoap.methods import *

DEFAULT_ENDPOINT = 'http://localhost:8080'

class GroupWiseClient(SoapClient):
    def __init__(self, endpoint: str = DEFAULT_ENDPOINT, debug: bool = False) -> None:
        super().__init__(endpoint, debug)

    def accept(self, request: AcceptRequest, context: RequestContext | None = None) -> AcceptResponse:
        _el = self._invoke('acceptRequest', request, context)
        return AcceptResponse.from_xml(_el)

    def accept_share(self, request: AcceptShareRequest, context: RequestContext | None = None) -> AcceptShareResponse:
        _el = self._invoke('acceptShareRequest', request, context)
        return AcceptShareResponse.from_xml(_el)

    def add_item(self, request: AddItemRequest, context: RequestContext | None = None) -> AddItemResponse:
        _el = self._invoke('addItemRequest', request, context)
        return AddItemResponse.from_xml(_el)

    def add_items(self, request: AddItemsRequest, context: RequestContext | None = None) -> AddItemsResponse:
        _el = self._invoke('addItemsRequest', request, context)
        return AddItemsResponse.from_xml(_el)

    def add_members(self, request: AddMembersRequest, context: RequestContext | None = None) -> AddMembersResponse:
        _el = self._invoke('addMembersRequest', request, context)
        return AddMembersResponse.from_xml(_el)

    def close_free_busy_session(self, request: CloseFreeBusySessionRequest, context: RequestContext | None = None) -> CloseFreeBusySessionResponse:
        _el = self._invoke('closeFreeBusySessionRequest', request, context)
        return CloseFreeBusySessionResponse.from_xml(_el)

    def complete(self, request: CompleteRequest, context: RequestContext | None = None) -> CompleteResponse:
        _el = self._invoke('completeRequest', request, context)
        return CompleteResponse.from_xml(_el)

    def create_cursor(self, request: CreateCursorRequest, context: RequestContext | None = None) -> CreateCursorResponse:
        _el = self._invoke('createCursorRequest', request, context)
        return CreateCursorResponse.from_xml(_el)

    def create_item(self, request: CreateItemRequest, context: RequestContext | None = None) -> CreateItemResponse:
        _el = self._invoke('createItemRequest', request, context)
        return CreateItemResponse.from_xml(_el)

    def create_items(self, request: CreateItemsRequest, context: RequestContext | None = None) -> CreateItemsResponse:
        _el = self._invoke('createItemsRequest', request, context)
        return CreateItemsResponse.from_xml(_el)

    def create_junk_entry(self, request: CreateJunkEntryRequest, context: RequestContext | None = None) -> CreateJunkEntryResponse:
        _el = self._invoke('createJunkEntryRequest', request, context)
        return CreateJunkEntryResponse.from_xml(_el)

    def create_proxy_access(self, request: CreateProxyAccessRequest, context: RequestContext | None = None) -> CreateProxyAccessResponse:
        _el = self._invoke('createProxyAccessRequest', request, context)
        return CreateProxyAccessResponse.from_xml(_el)

    def create_signature(self, request: CreateSignatureRequest, context: RequestContext | None = None) -> CreateSignatureResponse:
        _el = self._invoke('createSignatureRequest', request, context)
        return CreateSignatureResponse.from_xml(_el)

    def decline(self, request: DeclineRequest, context: RequestContext | None = None) -> DeclineResponse:
        _el = self._invoke('declineRequest', request, context)
        return DeclineResponse.from_xml(_el)

    def delegate(self, request: DelegateRequest, context: RequestContext | None = None) -> DelegateResponse:
        _el = self._invoke('delegateRequest', request, context)
        return DelegateResponse.from_xml(_el)

    def destroy_cursor(self, request: DestroyCursorRequest, context: RequestContext | None = None) -> DestroyCursorResponse:
        _el = self._invoke('destroyCursorRequest', request, context)
        return DestroyCursorResponse.from_xml(_el)

    def execute_rule(self, request: ExecuteRuleRequest, context: RequestContext | None = None) -> ExecuteRuleResponse:
        _el = self._invoke('executeRuleRequest', request, context)
        return ExecuteRuleResponse.from_xml(_el)

    def forward(self, request: ForwardRequest, context: RequestContext | None = None) -> ForwardResponse:
        _el = self._invoke('forwardRequest', request, context)
        return ForwardResponse.from_xml(_el)

    def get_address_book_list(self, request: GetAddressBookListRequest, context: RequestContext | None = None) -> GetAddressBookListResponse:
        _el = self._invoke('getAddressBookListRequest', request, context)
        return GetAddressBookListResponse.from_xml(_el)

    def get_attachment_request_message(self, request: GetAttachmentRequest, context: RequestContext | None = None) -> GetAttachmentResponse:
        _el = self._invoke('getAttachmentRequestMessage', request, context)
        return GetAttachmentResponse.from_xml(_el)

    def get_category_list(self, request: GetCategoryListRequest, context: RequestContext | None = None) -> GetCategoryListResponse:
        _el = self._invoke('getCategoryListRequest', request, context)
        return GetCategoryListResponse.from_xml(_el)

    def get_custom_list(self, request: GetCustomListRequest, context: RequestContext | None = None) -> GetCustomListResponse:
        _el = self._invoke('getCustomListRequest', request, context)
        return GetCustomListResponse.from_xml(_el)

    def get_deltas(self, request: GetDeltasRequest, context: RequestContext | None = None) -> GetDeltasResponse:
        _el = self._invoke('getDeltasRequest', request, context)
        return GetDeltasResponse.from_xml(_el)

    def get_delta_info(self, request: GetDeltaInfoRequest, context: RequestContext | None = None) -> GetDeltaInfoResponse:
        _el = self._invoke('getDeltaInfoRequest', request, context)
        return GetDeltaInfoResponse.from_xml(_el)

    def get_document_type_list(self, request: GetDocumentTypeListRequest, context: RequestContext | None = None) -> GetDocumentTypeListResponse:
        _el = self._invoke('getDocumentTypeListRequest', request, context)
        return GetDocumentTypeListResponse.from_xml(_el)

    def get_folder(self, request: GetFolderRequest, context: RequestContext | None = None) -> GetFolderResponse:
        _el = self._invoke('getFolderRequest', request, context)
        return GetFolderResponse.from_xml(_el)

    def get_folder_list(self, request: GetFolderListRequest, context: RequestContext | None = None) -> GetFolderListResponse:
        _el = self._invoke('getFolderListRequest', request, context)
        return GetFolderListResponse.from_xml(_el)

    def get_free_busy(self, request: GetFreeBusyRequest, context: RequestContext | None = None) -> GetFreeBusyResponse:
        _el = self._invoke('getFreeBusyRequest', request, context)
        return GetFreeBusyResponse.from_xml(_el)

    def get_item(self, request: GetItemRequest, context: RequestContext | None = None) -> GetItemResponse:
        _el = self._invoke('getItemRequest', request, context)
        return GetItemResponse.from_xml(_el)

    def get_items(self, request: GetItemsRequest, context: RequestContext | None = None) -> GetItemsResponse:
        _el = self._invoke('getItemsRequest', request, context)
        return GetItemsResponse.from_xml(_el)

    def get_junk_entries(self, request: GetJunkEntriesRequest, context: RequestContext | None = None) -> GetJunkEntriesResponse:
        _el = self._invoke('getJunkEntriesRequest', request, context)
        return GetJunkEntriesResponse.from_xml(_el)

    def get_junk_mail_settings(self, request: GetJunkMailSettingsRequest, context: RequestContext | None = None) -> GetJunkMailSettingsResponse:
        _el = self._invoke('getJunkMailSettingsRequest', request, context)
        return GetJunkMailSettingsResponse.from_xml(_el)

    def get_library_item(self, request: GetLibraryItemRequest, context: RequestContext | None = None) -> GetLibraryItemResponse:
        _el = self._invoke('getLibraryItemRequest', request, context)
        return GetLibraryItemResponse.from_xml(_el)

    def get_library_list(self, request: GetLibraryListRequest, context: RequestContext | None = None) -> GetLibraryListResponse:
        _el = self._invoke('getLibraryListRequest', request, context)
        return GetLibraryListResponse.from_xml(_el)

    def get_quick_messages(self, request: GetQuickMessagesRequest, context: RequestContext | None = None) -> GetQuickMessagesResponse:
        _el = self._invoke('getQuickMessagesRequest', request, context)
        return GetQuickMessagesResponse.from_xml(_el)

    def get_proxy_access_list(self, request: GetProxyAccessListRequest, context: RequestContext | None = None) -> GetProxyAccessListResponse:
        _el = self._invoke('getProxyAccessListRequest', request, context)
        return GetProxyAccessListResponse.from_xml(_el)

    def get_proxy_list(self, request: GetProxyListRequest, context: RequestContext | None = None) -> GetProxyListResponse:
        _el = self._invoke('getProxyListRequest', request, context)
        return GetProxyListResponse.from_xml(_el)

    def get_rule_list(self, request: GetRuleListRequest, context: RequestContext | None = None) -> GetRuleListResponse:
        _el = self._invoke('getRuleListRequest', request, context)
        return GetRuleListResponse.from_xml(_el)

    def get_settings(self, request: GetSettingsRequest, context: RequestContext | None = None) -> GetSettingsResponse:
        _el = self._invoke('getSettingsRequest', request, context)
        return GetSettingsResponse.from_xml(_el)

    def get_signatures(self, request: GetSignaturesRequest, context: RequestContext | None = None) -> GetSignaturesResponse:
        _el = self._invoke('getSignaturesRequest', request, context)
        return GetSignaturesResponse.from_xml(_el)

    def get_timestamp(self, request: GetTimestampRequest, context: RequestContext | None = None) -> GetTimestampResponse:
        _el = self._invoke('getTimestampRequest', request, context)
        return GetTimestampResponse.from_xml(_el)

    def get_timezone_list(self, request: GetTimezoneListRequest, context: RequestContext | None = None) -> GetTimezoneListResponse:
        _el = self._invoke('getTimezoneListRequest', request, context)
        return GetTimezoneListResponse.from_xml(_el)

    def get_user_list(self, request: GetUserListRequest, context: RequestContext | None = None) -> GetUserListResponse:
        _el = self._invoke('getUserListRequest', request, context)
        return GetUserListResponse.from_xml(_el)

    def login(self, request: LoginRequest, context: RequestContext | None = None) -> LoginResponse:
        _el = self._invoke('loginRequest', request, context)
        return LoginResponse.from_xml(_el)

    def logout(self, request: LogoutRequest, context: RequestContext | None = None) -> LogoutResponse:
        _el = self._invoke('logoutRequest', request, context)
        return LogoutResponse.from_xml(_el)

    def mark_private(self, request: MarkPrivateRequest, context: RequestContext | None = None) -> MarkPrivateResponse:
        _el = self._invoke('markPrivateRequest', request, context)
        return MarkPrivateResponse.from_xml(_el)

    def mark_read(self, request: MarkReadRequest, context: RequestContext | None = None) -> MarkReadResponse:
        _el = self._invoke('markReadRequest', request, context)
        return MarkReadResponse.from_xml(_el)

    def mark_un_private(self, request: MarkUnPrivateRequest, context: RequestContext | None = None) -> MarkUnPrivateResponse:
        _el = self._invoke('markUnPrivateRequest', request, context)
        return MarkUnPrivateResponse.from_xml(_el)

    def mark_un_read(self, request: MarkUnReadRequest, context: RequestContext | None = None) -> MarkUnReadResponse:
        _el = self._invoke('markUnReadRequest', request, context)
        return MarkUnReadResponse.from_xml(_el)

    def modify_item(self, request: ModifyItemRequest, context: RequestContext | None = None) -> ModifyItemResponse:
        _el = self._invoke('modifyItemRequest', request, context)
        return ModifyItemResponse.from_xml(_el)

    def modify_items(self, request: ModifyItemsRequest, context: RequestContext | None = None) -> ModifyItemsResponse:
        _el = self._invoke('modifyItemsRequest', request, context)
        return ModifyItemsResponse.from_xml(_el)

    def modify_junk_entry(self, request: ModifyJunkEntryRequest, context: RequestContext | None = None) -> ModifyJunkEntryResponse:
        _el = self._invoke('modifyJunkEntryRequest', request, context)
        return ModifyJunkEntryResponse.from_xml(_el)

    def modify_junk_mail_settings(self, request: ModifyJunkMailSettingsRequest, context: RequestContext | None = None) -> ModifyJunkMailSettingsResponse:
        _el = self._invoke('modifyJunkMailSettingsRequest', request, context)
        return ModifyJunkMailSettingsResponse.from_xml(_el)

    def modify_password(self, request: ModifyPasswordRequest, context: RequestContext | None = None) -> ModifyPasswordResponse:
        _el = self._invoke('modifyPasswordRequest', request, context)
        return ModifyPasswordResponse.from_xml(_el)

    def modify_proxy_access(self, request: ModifyProxyAccessRequest, context: RequestContext | None = None) -> ModifyProxyAccessResponse:
        _el = self._invoke('modifyProxyAccessRequest', request, context)
        return ModifyProxyAccessResponse.from_xml(_el)

    def modify_settings(self, request: ModifySettingsRequest, context: RequestContext | None = None) -> ModifySettingsResponse:
        _el = self._invoke('modifySettingsRequest', request, context)
        return ModifySettingsResponse.from_xml(_el)

    def modify_signatures(self, request: ModifySignaturesRequest, context: RequestContext | None = None) -> ModifySignaturesResponse:
        _el = self._invoke('modifySignaturesRequest', request, context)
        return ModifySignaturesResponse.from_xml(_el)

    def move_item(self, request: MoveItemRequest, context: RequestContext | None = None) -> MoveItemResponse:
        _el = self._invoke('moveItemRequest', request, context)
        return MoveItemResponse.from_xml(_el)

    def position_cursor(self, request: PositionCursorRequest, context: RequestContext | None = None) -> PositionCursorResponse:
        _el = self._invoke('positionCursorRequest', request, context)
        return PositionCursorResponse.from_xml(_el)

    def purge_deleted_items(self, request: PurgeDeletedItemsRequest, context: RequestContext | None = None) -> PurgeDeletedItemsResponse:
        _el = self._invoke('purgeDeletedItemsRequest', request, context)
        return PurgeDeletedItemsResponse.from_xml(_el)

    def purge(self, request: PurgeRequest, context: RequestContext | None = None) -> PurgeResponse:
        _el = self._invoke('purgeRequest', request, context)
        return PurgeResponse.from_xml(_el)

    def read_cursor(self, request: ReadCursorRequest, context: RequestContext | None = None) -> ReadCursorResponse:
        _el = self._invoke('readCursorRequest', request, context)
        return ReadCursorResponse.from_xml(_el)

    def remove_custom_definition(self, request: RemoveCustomDefinitionRequest, context: RequestContext | None = None) -> RemoveCustomDefinitionResponse:
        _el = self._invoke('removeCustomDefinitionRequest', request, context)
        return RemoveCustomDefinitionResponse.from_xml(_el)

    def remove_item(self, request: RemoveItemRequest, context: RequestContext | None = None) -> RemoveItemResponse:
        _el = self._invoke('removeItemRequest', request, context)
        return RemoveItemResponse.from_xml(_el)

    def remove_items(self, request: RemoveItemsRequest, context: RequestContext | None = None) -> RemoveItemsResponse:
        _el = self._invoke('removeItemsRequest', request, context)
        return RemoveItemsResponse.from_xml(_el)

    def remove_junk_entry(self, request: RemoveJunkEntryRequest, context: RequestContext | None = None) -> RemoveJunkEntryResponse:
        _el = self._invoke('removeJunkEntryRequest', request, context)
        return RemoveJunkEntryResponse.from_xml(_el)

    def remove_members(self, request: RemoveMembersRequest, context: RequestContext | None = None) -> RemoveMembersResponse:
        _el = self._invoke('removeMembersRequest', request, context)
        return RemoveMembersResponse.from_xml(_el)

    def remove_proxy_access(self, request: RemoveProxyAccessRequest, context: RequestContext | None = None) -> RemoveProxyAccessResponse:
        _el = self._invoke('removeProxyAccessRequest', request, context)
        return RemoveProxyAccessResponse.from_xml(_el)

    def remove_proxy_user(self, request: RemoveProxyUserRequest, context: RequestContext | None = None) -> RemoveProxyUserResponse:
        _el = self._invoke('removeProxyUserRequest', request, context)
        return RemoveProxyUserResponse.from_xml(_el)

    def remove_signature(self, request: RemoveSignatureRequest, context: RequestContext | None = None) -> RemoveSignatureResponse:
        _el = self._invoke('removeSignatureRequest', request, context)
        return RemoveSignatureResponse.from_xml(_el)

    def reply(self, request: ReplyRequest, context: RequestContext | None = None) -> ReplyResponse:
        _el = self._invoke('replyRequest', request, context)
        return ReplyResponse.from_xml(_el)

    def retract(self, request: RetractRequest, context: RequestContext | None = None) -> RetractResponse:
        _el = self._invoke('retractRequest', request, context)
        return RetractResponse.from_xml(_el)

    def send_item(self, request: SendItemRequest, context: RequestContext | None = None) -> SendItemResponse:
        _el = self._invoke('sendItemRequest', request, context)
        return SendItemResponse.from_xml(_el)

    def set_timestamp(self, request: SetTimestampRequest, context: RequestContext | None = None) -> SetTimestampResponse:
        _el = self._invoke('setTimestampRequest', request, context)
        return SetTimestampResponse.from_xml(_el)

    def start_free_busy_session(self, request: StartFreeBusySessionRequest, context: RequestContext | None = None) -> StartFreeBusySessionResponse:
        _el = self._invoke('startFreeBusySessionRequest', request, context)
        return StartFreeBusySessionResponse.from_xml(_el)

    def unaccept(self, request: UnacceptRequest, context: RequestContext | None = None) -> UnacceptResponse:
        _el = self._invoke('unacceptRequest', request, context)
        return UnacceptResponse.from_xml(_el)

    def uncomplete(self, request: UncompleteRequest, context: RequestContext | None = None) -> UncompleteResponse:
        _el = self._invoke('uncompleteRequest', request, context)
        return UncompleteResponse.from_xml(_el)

    def update_version_status(self, request: UpdateVersionStatusRequest, context: RequestContext | None = None) -> UpdateVersionStatusResponse:
        _el = self._invoke('updateVersionStatusRequest', request, context)
        return UpdateVersionStatusResponse.from_xml(_el)

    def get_account_list(self, request: GetAccountListRequest, context: RequestContext | None = None) -> GetAccountListResponse:
        _el = self._invoke('getAccountListRequest', request, context)
        return GetAccountListResponse.from_xml(_el)

    def get_disk_space_usage(self, request: GetDiskSpaceUsageRequest, context: RequestContext | None = None) -> GetDiskSpaceUsageResponse:
        _el = self._invoke('getDiskSpaceUsageRequest', request, context)
        return GetDiskSpaceUsageResponse.from_xml(_el)

    def get_string(self, request: GetStringRequest, context: RequestContext | None = None) -> GetStringResponse:
        _el = self._invoke('getStringRequest', request, context)
        return GetStringResponse.from_xml(_el)

    def resolve(self, request: ResolveRequest, context: RequestContext | None = None) -> ResolveResponse:
        _el = self._invoke('resolveRequest', request, context)
        return ResolveResponse.from_xml(_el)

    def restore_item(self, request: RestoreItemRequest, context: RequestContext | None = None) -> RestoreItemResponse:
        _el = self._invoke('restoreItemRequest', request, context)
        return RestoreItemResponse.from_xml(_el)

    def stub_item(self, request: StubItemRequest, context: RequestContext | None = None) -> StubItemResponse:
        _el = self._invoke('stubItemRequest', request, context)
        return StubItemResponse.from_xml(_el)

