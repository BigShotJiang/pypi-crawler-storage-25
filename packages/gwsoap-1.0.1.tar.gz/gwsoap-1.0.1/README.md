# GroupWise Python Client

Auto-generated Python package for the GroupWise WSDL/XSD schemas.

## Package layout

```
_utils.py              helper functions (base64, ISO 8601 duration)
types/                 XSD types namespace classes
methods/               XSD methods namespace classes
events/                XSD events namespace classes
soap/
  request_context.py   RequestContext dataclass
  exceptions.py        SoapFaultException
  soap_client.py       Base SOAP/HTTP client
service/
  groupwise_client.py        GroupWise main service client
  groupwise_events_client.py GroupWise events service client
```

## Usage

```python
from groupwise.service.groupwise_client import GroupWiseClient
from groupwise.methods.LoginRequest import LoginRequest
from groupwise.soap.request_context import RequestContext

client = GroupWiseClient("https://your-server/soap")
req = LoginRequest()
# populate req fields ...
response = client.login(req)
```

## Regenerate

```powershell
python tools/wsdl2python.py --wsdl wsdl/groupwise.wsdl --output generated/groupwise-python-client
```
