from __future__ import annotations

from enum import Enum


class ViewType(str, Enum):
    DETAILS = 'details'
    LARGEICONS = 'largeIcons'
    SMALLICON = 'smallIcon'
    LIST = 'list'
    DISCUSSION = 'discussion'
    CALENDAR = 'calendar'
    TASKLIST = 'tasklist'
    PANEL = 'panel'
    ADDRESSCARDS = 'addressCards'
