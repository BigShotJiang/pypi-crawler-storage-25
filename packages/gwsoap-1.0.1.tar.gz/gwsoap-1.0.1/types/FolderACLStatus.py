from __future__ import annotations

from enum import Enum


class FolderACLStatus(str, Enum):
    PENDING = 'pending'
    ACCEPTED = 'accepted'
    DELETED = 'deleted'
    OPENED = 'opened'
    OWNER = 'owner'
