from __future__ import annotations

from dataclasses import dataclass
from datetime import date
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PersonalInfo:
    birthday: date | None = None
    website: str | None = None
    spouse: str | None = None
    children: str | None = None
    hobbies: str | None = None
    nick_name: str | None = None
    picture: PictureData | None = None
    wedding_anniversary: date | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PersonalInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.birthday is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}birthday')
            _c.text = self.birthday.isoformat()
        if self.website is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}website')
            _c.text = self.website
        if self.spouse is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}spouse')
            _c.text = self.spouse
        if self.children is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}children')
            _c.text = self.children
        if self.hobbies is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hobbies')
            _c.text = self.hobbies
        if self.nick_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}nickName')
            _c.text = self.nick_name
        if self.picture is not None:
            self.picture.to_xml(_el, f'{{{_NS}}}picture')
        if self.wedding_anniversary is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}weddingAnniversary')
            _c.text = self.wedding_anniversary.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}birthday')
        if _c is not None:
            if _c.text is not None:
                _f['birthday'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}website')
        if _c is not None:
            if _c.text is not None:
                _f['website'] = _c.text
        _c = _el.find(f'{{{_NS}}}spouse')
        if _c is not None:
            if _c.text is not None:
                _f['spouse'] = _c.text
        _c = _el.find(f'{{{_NS}}}children')
        if _c is not None:
            if _c.text is not None:
                _f['children'] = _c.text
        _c = _el.find(f'{{{_NS}}}hobbies')
        if _c is not None:
            if _c.text is not None:
                _f['hobbies'] = _c.text
        _c = _el.find(f'{{{_NS}}}nickName')
        if _c is not None:
            if _c.text is not None:
                _f['nick_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}picture')
        if _c is not None:
            from gwsoap.types.PictureData import PictureData
            _f['picture'] = PictureData.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}weddingAnniversary')
        if _c is not None:
            if _c.text is not None:
                _f['wedding_anniversary'] = date.fromisoformat(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> PersonalInfo:
        return cls(**cls._parse_fields(_el))
