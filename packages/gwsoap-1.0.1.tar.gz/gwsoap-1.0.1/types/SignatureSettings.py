from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SignatureSettings:
    enabled: bool | None = None
    add: SignatureType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SignatureSettings'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.enabled is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}enabled')
            _c.text = ('true' if self.enabled else 'false')
        if self.add is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}add')
            _c.text = self.add.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}enabled')
        if _c is not None:
            if _c.text is not None:
                _f['enabled'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}add')
        if _c is not None:
            from gwsoap.types.SignatureType import SignatureType
            if _c.text is not None:
                _f['add'] = SignatureType(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SignatureSettings:
        return cls(**cls._parse_fields(_el))
