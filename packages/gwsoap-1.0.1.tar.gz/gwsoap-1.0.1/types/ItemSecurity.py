from __future__ import annotations

from enum import Enum


class ItemSecurity(str, Enum):
    NORMAL = 'Normal'
    PROPRIETARY = 'Proprietary'
    CONFIDENTIAL = 'Confidential'
    SECRET = 'Secret'
    TOPSECRET = 'TopSecret'
    FORYOUREYESONLY = 'ForYourEyesOnly'
