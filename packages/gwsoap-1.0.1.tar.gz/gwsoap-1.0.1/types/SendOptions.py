from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SendOptions:
    request_reply: SendOptionsRequestReply | None = None
    mime_encoding: str | None = None
    status_tracking: StatusTracking | None = None
    notification: ReturnNotification | None = None
    update_frequent_contacts: bool | None = None
    work_flow: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SendOptions'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.request_reply is not None:
            self.request_reply.to_xml(_el, f'{{{_NS}}}requestReply')
        if self.mime_encoding is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}mimeEncoding')
            _c.text = self.mime_encoding
        if self.status_tracking is not None:
            self.status_tracking.to_xml(_el, f'{{{_NS}}}statusTracking')
        if self.notification is not None:
            self.notification.to_xml(_el, f'{{{_NS}}}notification')
        if self.update_frequent_contacts is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}updateFrequentContacts')
            _c.text = ('true' if self.update_frequent_contacts else 'false')
        if self.work_flow is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}workFlow')
            _c.text = ('true' if self.work_flow else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}requestReply')
        if _c is not None:
            from gwsoap.types.SendOptionsRequestReply import SendOptionsRequestReply
            _f['request_reply'] = SendOptionsRequestReply.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}mimeEncoding')
        if _c is not None:
            if _c.text is not None:
                _f['mime_encoding'] = _c.text
        _c = _el.find(f'{{{_NS}}}statusTracking')
        if _c is not None:
            from gwsoap.types.StatusTracking import StatusTracking
            _f['status_tracking'] = StatusTracking.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}notification')
        if _c is not None:
            from gwsoap.types.ReturnNotification import ReturnNotification
            _f['notification'] = ReturnNotification.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}updateFrequentContacts')
        if _c is not None:
            if _c.text is not None:
                _f['update_frequent_contacts'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}workFlow')
        if _c is not None:
            if _c.text is not None:
                _f['work_flow'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SendOptions:
        return cls(**cls._parse_fields(_el))
