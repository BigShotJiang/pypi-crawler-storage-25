from __future__ import annotations

from enum import Enum


class ItemClass(str, Enum):
    PUBLIC = 'Public'
    PRIVATE = 'Private'
