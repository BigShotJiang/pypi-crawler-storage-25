from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from gwsoap.types.ContainerItem import ContainerItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class BoxEntry(ContainerItem):
    status: ItemStatus | None = None
    thread: str | None = None
    msg_id: str | None = None
    message_id: str | None = None
    client_message_id: str | None = None
    source: ItemSource | None = None
    return_sent_items_id: bool | None = None
    delivered: datetime | None = None
    class_value: ItemClass | None = None
    security: ItemSecurity | None = None
    comment: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}BoxEntry'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'BoxEntry')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.status is not None:
            self.status.to_xml(_el, f'{{{_NS}}}status')
        if self.thread is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}thread')
            _c.text = self.thread
        if self.msg_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}msgId')
            _c.text = self.msg_id
        if self.message_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}messageId')
            _c.text = self.message_id
        if self.client_message_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}clientMessageId')
            _c.text = self.client_message_id
        if self.source is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}source')
            _c.text = self.source.value
        if self.return_sent_items_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}returnSentItemsId')
            _c.text = ('true' if self.return_sent_items_id else 'false')
        if self.delivered is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}delivered')
            _c.text = self.delivered.isoformat()
        if self.class_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}class')
            _c.text = self.class_value.value
        if self.security is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}security')
            _c.text = self.security.value
        if self.comment is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}comment')
            _c.text = self.comment

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}status')
        if _c is not None:
            from gwsoap.types.ItemStatus import ItemStatus
            _f['status'] = ItemStatus.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}thread')
        if _c is not None:
            if _c.text is not None:
                _f['thread'] = _c.text
        _c = _el.find(f'{{{_NS}}}msgId')
        if _c is not None:
            if _c.text is not None:
                _f['msg_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}messageId')
        if _c is not None:
            if _c.text is not None:
                _f['message_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}clientMessageId')
        if _c is not None:
            if _c.text is not None:
                _f['client_message_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}source')
        if _c is not None:
            from gwsoap.types.ItemSource import ItemSource
            if _c.text is not None:
                _f['source'] = ItemSource(_c.text)
        _c = _el.find(f'{{{_NS}}}returnSentItemsId')
        if _c is not None:
            if _c.text is not None:
                _f['return_sent_items_id'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}delivered')
        if _c is not None:
            if _c.text is not None:
                _f['delivered'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}class')
        if _c is not None:
            from gwsoap.types.ItemClass import ItemClass
            if _c.text is not None:
                _f['class_value'] = ItemClass(_c.text)
        _c = _el.find(f'{{{_NS}}}security')
        if _c is not None:
            from gwsoap.types.ItemSecurity import ItemSecurity
            if _c.text is not None:
                _f['security'] = ItemSecurity(_c.text)
        _c = _el.find(f'{{{_NS}}}comment')
        if _c is not None:
            if _c.text is not None:
                _f['comment'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> BoxEntry:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'Appointment':
            from gwsoap.types.Appointment import Appointment
            return Appointment(**Appointment._parse_fields(_el))
        if _t == 'CalendarItem':
            from gwsoap.types.CalendarItem import CalendarItem
            return CalendarItem(**CalendarItem._parse_fields(_el))
        if _t == 'DocumentRef':
            from gwsoap.types.DocumentRef import DocumentRef
            return DocumentRef(**DocumentRef._parse_fields(_el))
        if _t == 'Mail':
            from gwsoap.types.Mail import Mail
            return Mail(**Mail._parse_fields(_el))
        if _t == 'Note':
            from gwsoap.types.Note import Note
            return Note(**Note._parse_fields(_el))
        if _t == 'PhoneMessage':
            from gwsoap.types.PhoneMessage import PhoneMessage
            return PhoneMessage(**PhoneMessage._parse_fields(_el))
        if _t == 'SharedNotification':
            from gwsoap.types.SharedNotification import SharedNotification
            return SharedNotification(**SharedNotification._parse_fields(_el))
        if _t == 'Task':
            from gwsoap.types.Task import Task
            return Task(**Task._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
