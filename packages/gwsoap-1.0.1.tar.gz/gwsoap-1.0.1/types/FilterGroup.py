from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from gwsoap.types.FilterElement import FilterElement
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FilterGroup(FilterElement):
    element: list[FilterElement] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FilterGroup'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'FilterGroup')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        for _v in self.element:
            _v.to_xml(_el, f'{{{_NS}}}element')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        from gwsoap.types.FilterElement import FilterElement
        _f['element'] = [FilterElement.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}element')]
        return _f
