from __future__ import annotations

from enum import Enum


class AppointmentConflict(str, Enum):
    YES = 'Yes'
    NO = 'No'
    IGNORE = 'Ignore'
