from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.ContainerItem import ContainerItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Rule(ContainerItem):
    execution: Execution | None = None
    sequence: int | None = None
    enabled: bool | None = None
    types: str | None = None
    source: str | None = None
    conflict: AppointmentConflict | None = None
    filter: Filter | None = None
    actions: RuleActionList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Rule'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Rule')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.execution is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}execution')
            _c.text = self.execution.value
        if self.sequence is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}sequence')
            _c.text = str(self.sequence)
        if self.enabled is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}enabled')
            _c.text = ('true' if self.enabled else 'false')
        if self.types is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}types')
            _c.text = self.types
        if self.source is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}source')
            _c.text = self.source
        if self.conflict is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}conflict')
            _c.text = self.conflict.value
        if self.filter is not None:
            self.filter.to_xml(_el, f'{{{_NS}}}filter')
        if self.actions is not None:
            self.actions.to_xml(_el, f'{{{_NS}}}actions')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}execution')
        if _c is not None:
            from gwsoap.types.Execution import Execution
            if _c.text is not None:
                _f['execution'] = Execution(_c.text)
        _c = _el.find(f'{{{_NS}}}sequence')
        if _c is not None:
            if _c.text is not None:
                _f['sequence'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}enabled')
        if _c is not None:
            if _c.text is not None:
                _f['enabled'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}types')
        if _c is not None:
            if _c.text is not None:
                _f['types'] = _c.text
        _c = _el.find(f'{{{_NS}}}source')
        if _c is not None:
            if _c.text is not None:
                _f['source'] = _c.text
        _c = _el.find(f'{{{_NS}}}conflict')
        if _c is not None:
            from gwsoap.types.AppointmentConflict import AppointmentConflict
            if _c.text is not None:
                _f['conflict'] = AppointmentConflict(_c.text)
        _c = _el.find(f'{{{_NS}}}filter')
        if _c is not None:
            from gwsoap.types.Filter import Filter
            _f['filter'] = Filter.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}actions')
        if _c is not None:
            from gwsoap.types.RuleActionList import RuleActionList
            _f['actions'] = RuleActionList.from_xml(_c)
        return _f
