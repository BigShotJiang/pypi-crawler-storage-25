from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Account import Account
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class NNTP(Account):
    folder: str | None = None
    inbound: Server | None = None
    outbound: Server | None = None
    life: int | None = None
    max_messages: int | None = None
    new_messages_x_days_old: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}NNTP'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'NNTP')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.folder is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}folder')
            _c.text = self.folder
        if self.inbound is not None:
            self.inbound.to_xml(_el, f'{{{_NS}}}inbound')
        if self.outbound is not None:
            self.outbound.to_xml(_el, f'{{{_NS}}}outbound')
        if self.life is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}life')
            _c.text = str(self.life)
        if self.max_messages is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}maxMessages')
            _c.text = str(self.max_messages)
        if self.new_messages_x_days_old is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}newMessagesXDaysOld')
            _c.text = str(self.new_messages_x_days_old)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}folder')
        if _c is not None:
            if _c.text is not None:
                _f['folder'] = _c.text
        _c = _el.find(f'{{{_NS}}}inbound')
        if _c is not None:
            from gwsoap.types.Server import Server
            _f['inbound'] = Server.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}outbound')
        if _c is not None:
            from gwsoap.types.Server import Server
            _f['outbound'] = Server.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}life')
        if _c is not None:
            if _c.text is not None:
                _f['life'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}maxMessages')
        if _c is not None:
            if _c.text is not None:
                _f['max_messages'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}newMessagesXDaysOld')
        if _c is not None:
            if _c.text is not None:
                _f['new_messages_x_days_old'] = int(_c.text)
        return _f
