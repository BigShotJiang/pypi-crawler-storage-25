from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class GroupMember:
    id: str | None = None
    name: str | None = None
    email: str | None = None
    dist_type: DistributionType | None = None
    item_type: ContactType | None = None
    members: GroupMemberList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}GroupMember'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.email is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}email')
            _c.text = self.email
        if self.dist_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}distType')
            _c.text = self.dist_type.value
        if self.item_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}itemType')
            _c.text = self.item_type.value
        if self.members is not None:
            self.members.to_xml(_el, f'{{{_NS}}}members')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}email')
        if _c is not None:
            if _c.text is not None:
                _f['email'] = _c.text
        _c = _el.find(f'{{{_NS}}}distType')
        if _c is not None:
            from gwsoap.types.DistributionType import DistributionType
            if _c.text is not None:
                _f['dist_type'] = DistributionType(_c.text)
        _c = _el.find(f'{{{_NS}}}itemType')
        if _c is not None:
            from gwsoap.types.ContactType import ContactType
            if _c.text is not None:
                _f['item_type'] = ContactType(_c.text)
        _c = _el.find(f'{{{_NS}}}members')
        if _c is not None:
            from gwsoap.types.GroupMemberList import GroupMemberList
            _f['members'] = GroupMemberList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> GroupMember:
        return cls(**cls._parse_fields(_el))
