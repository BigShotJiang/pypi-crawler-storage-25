from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FilterElement:
    op: FilterOp | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FilterElement'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.op is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}op')
            _c.text = self.op.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}op')
        if _c is not None:
            from gwsoap.types.FilterOp import FilterOp
            if _c.text is not None:
                _f['op'] = FilterOp(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> FilterElement:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'FilterEntry':
            from gwsoap.types.FilterEntry import FilterEntry
            return FilterEntry(**FilterEntry._parse_fields(_el))
        if _t == 'FilterGroup':
            from gwsoap.types.FilterGroup import FilterGroup
            return FilterGroup(**FilterGroup._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
