from __future__ import annotations

from enum import Enum


class ColumnType(str, Enum):
    WINDOWS = 'Windows'
    JAVA = 'Java'
