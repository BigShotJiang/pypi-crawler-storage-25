from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PhoneNumber:
    value: str | None = None
    type: PhoneNumberType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PhoneNumber'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.value is not None:
            _el.text = self.value
        if self.type is not None:
            _el.set('type', self.type.value)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        if _el.text is not None:
            _f['value'] = _el.text
        _v = _el.get('type')
        if _v is not None:
            from gwsoap.types.PhoneNumberType import PhoneNumberType
            _f['type'] = PhoneNumberType(_v)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> PhoneNumber:
        return cls(**cls._parse_fields(_el))
