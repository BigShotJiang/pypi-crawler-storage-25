from __future__ import annotations

from enum import Enum


class JunkMatchType(str, Enum):
    EMAIL = 'email'
    DOMAIN = 'domain'
