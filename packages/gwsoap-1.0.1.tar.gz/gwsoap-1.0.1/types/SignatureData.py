from __future__ import annotations

from dataclasses import dataclass
from gwsoap._utils import b64enc as _b64enc, b64dec as _b64dec
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SignatureData:
    size: int | None = None
    data: bytes | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SignatureData'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.size is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}size')
            _c.text = str(self.size)
        if self.data is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}data')
            _c.text = _b64enc(self.data)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}size')
        if _c is not None:
            if _c.text is not None:
                _f['size'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}data')
        if _c is not None:
            if _c.text is not None:
                _f['data'] = _b64dec(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SignatureData:
        return cls(**cls._parse_fields(_el))
