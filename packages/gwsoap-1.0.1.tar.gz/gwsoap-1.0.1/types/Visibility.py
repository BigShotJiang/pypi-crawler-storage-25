from __future__ import annotations

from enum import Enum


class Visibility(str, Enum):
    POSTOFFICE = 'PostOffice'
    DOMAIN = 'Domain'
    SYSTEM = 'System'
    UNLISTED = 'Unlisted'
    UNKNOWN = 'Unknown'
