from __future__ import annotations

from enum import Enum


class VersionStatus(str, Enum):
    AVAILABLE = 'available'
    CHECKEDOUT = 'checkedOut'
    INUSE = 'inUse'
    DELETED = 'deleted'
    ARCHIVED = 'archived'
    MASSINUSE = 'massInUse'
    UNAVAILABLE = 'unavailable'
