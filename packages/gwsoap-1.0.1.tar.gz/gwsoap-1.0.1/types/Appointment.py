from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from datetime import datetime
from gwsoap.types.CalendarItem import CalendarItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Appointment(CalendarItem):
    start_date: datetime | None = None
    end_date: datetime | None = None
    start_day: date | None = None
    end_day: date | None = None
    accept_level: AcceptLevel | None = None
    alarm: Alarm | None = None
    all_day_event: bool | None = None
    place: str | None = None
    timezone: Timezone | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Appointment'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Appointment')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}startDate')
            _c.text = self.start_date.isoformat()
        if self.end_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}endDate')
            _c.text = self.end_date.isoformat()
        if self.start_day is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}startDay')
            _c.text = self.start_day.isoformat()
        if self.end_day is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}endDay')
            _c.text = self.end_day.isoformat()
        if self.accept_level is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}acceptLevel')
            _c.text = self.accept_level.value
        if self.alarm is not None:
            self.alarm.to_xml(_el, f'{{{_NS}}}alarm')
        if self.all_day_event is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}allDayEvent')
            _c.text = ('true' if self.all_day_event else 'false')
        if self.place is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}place')
            _c.text = self.place
        if self.timezone is not None:
            self.timezone.to_xml(_el, f'{{{_NS}}}timezone')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}endDate')
        if _c is not None:
            if _c.text is not None:
                _f['end_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}startDay')
        if _c is not None:
            if _c.text is not None:
                _f['start_day'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}endDay')
        if _c is not None:
            if _c.text is not None:
                _f['end_day'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}acceptLevel')
        if _c is not None:
            from gwsoap.types.AcceptLevel import AcceptLevel
            if _c.text is not None:
                _f['accept_level'] = AcceptLevel(_c.text)
        _c = _el.find(f'{{{_NS}}}alarm')
        if _c is not None:
            from gwsoap.types.Alarm import Alarm
            _f['alarm'] = Alarm.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}allDayEvent')
        if _c is not None:
            if _c.text is not None:
                _f['all_day_event'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}place')
        if _c is not None:
            if _c.text is not None:
                _f['place'] = _c.text
        _c = _el.find(f'{{{_NS}}}timezone')
        if _c is not None:
            from gwsoap.types.Timezone import Timezone
            _f['timezone'] = Timezone.from_xml(_c)
        return _f
