from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ModifyItem:
    id: str | None = None
    notification: SharedFolderNotification | None = None
    updates: ItemChanges | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ModifyItem'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.notification is not None:
            self.notification.to_xml(_el, f'{{{_NS}}}notification')
        if self.updates is not None:
            self.updates.to_xml(_el, f'{{{_NS}}}updates')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}notification')
        if _c is not None:
            from gwsoap.types.SharedFolderNotification import SharedFolderNotification
            _f['notification'] = SharedFolderNotification.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}updates')
        if _c is not None:
            from gwsoap.types.ItemChanges import ItemChanges
            _f['updates'] = ItemChanges.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ModifyItem:
        return cls(**cls._parse_fields(_el))
