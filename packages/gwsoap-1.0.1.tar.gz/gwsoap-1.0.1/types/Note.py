from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from gwsoap.types.CalendarItem import CalendarItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Note(CalendarItem):
    start_date: date | None = None
    timezone: Timezone | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Note'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Note')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}startDate')
            _c.text = self.start_date.isoformat()
        if self.timezone is not None:
            self.timezone.to_xml(_el, f'{{{_NS}}}timezone')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}timezone')
        if _c is not None:
            from gwsoap.types.Timezone import Timezone
            _f['timezone'] = Timezone.from_xml(_c)
        return _f
