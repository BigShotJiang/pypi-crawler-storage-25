from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from gwsoap._utils import b64enc as _b64enc, b64dec as _b64dec
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AttachmentItemInfo:
    id: AttachmentID | None = None
    name: str | None = None
    content_id: str | None = None
    content_type: str | None = None
    size: int | None = None
    date: datetime | None = None
    data: bytes | None = None
    hidden: bool | None = None
    is_personal: bool | None = None
    hash: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AttachmentItemInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            self.id.to_xml(_el, f'{{{_NS}}}id')
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.content_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}contentId')
            _c.text = self.content_id
        if self.content_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}contentType')
            _c.text = self.content_type
        if self.size is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}size')
            _c.text = str(self.size)
        if self.date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}date')
            _c.text = self.date.isoformat()
        if self.data is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}data')
            _c.text = _b64enc(self.data)
        if self.hidden is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hidden')
            _c.text = ('true' if self.hidden else 'false')
        if self.is_personal is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isPersonal')
            _c.text = ('true' if self.is_personal else 'false')
        if self.hash is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hash')
            _c.text = self.hash

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            from gwsoap.types.AttachmentID import AttachmentID
            _f['id'] = AttachmentID.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}contentId')
        if _c is not None:
            if _c.text is not None:
                _f['content_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}contentType')
        if _c is not None:
            if _c.text is not None:
                _f['content_type'] = _c.text
        _c = _el.find(f'{{{_NS}}}size')
        if _c is not None:
            if _c.text is not None:
                _f['size'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}date')
        if _c is not None:
            if _c.text is not None:
                _f['date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}data')
        if _c is not None:
            if _c.text is not None:
                _f['data'] = _b64dec(_c.text)
        _c = _el.find(f'{{{_NS}}}hidden')
        if _c is not None:
            if _c.text is not None:
                _f['hidden'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}isPersonal')
        if _c is not None:
            if _c.text is not None:
                _f['is_personal'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}hash')
        if _c is not None:
            if _c.text is not None:
                _f['hash'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AttachmentItemInfo:
        return cls(**cls._parse_fields(_el))
