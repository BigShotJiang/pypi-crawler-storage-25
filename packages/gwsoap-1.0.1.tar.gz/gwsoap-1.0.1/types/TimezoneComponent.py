from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class TimezoneComponent:
    name: str | None = None
    month: int | None = None
    day: int | None = None
    day_of_week: DayOfWeek | None = None
    hour: int | None = None
    minute: int | None = None
    offset: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}TimezoneComponent'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.month is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}month')
            _c.text = str(self.month)
        if self.day is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}day')
            _c.text = str(self.day)
        if self.day_of_week is not None:
            self.day_of_week.to_xml(_el, f'{{{_NS}}}dayOfWeek')
        if self.hour is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hour')
            _c.text = str(self.hour)
        if self.minute is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}minute')
            _c.text = str(self.minute)
        if self.offset is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}offset')
            _c.text = str(self.offset)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}month')
        if _c is not None:
            if _c.text is not None:
                _f['month'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}day')
        if _c is not None:
            if _c.text is not None:
                _f['day'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}dayOfWeek')
        if _c is not None:
            from gwsoap.types.DayOfWeek import DayOfWeek
            _f['day_of_week'] = DayOfWeek.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}hour')
        if _c is not None:
            if _c.text is not None:
                _f['hour'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}minute')
        if _c is not None:
            if _c.text is not None:
                _f['minute'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}offset')
        if _c is not None:
            if _c.text is not None:
                _f['offset'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> TimezoneComponent:
        return cls(**cls._parse_fields(_el))
