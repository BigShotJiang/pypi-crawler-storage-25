from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.ContainerItem import ContainerItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AddressBookItem(ContainerItem):
    uuid: str | None = None
    comment: str | None = None
    sync: DeltaSyncType | None = None
    domain: str | None = None
    post_office: str | None = None
    distinguished_name: str | None = None
    userid: str | None = None
    p_ab_guid: str | None = None
    visibility: Visibility | None = None
    external: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AddressBookItem'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'AddressBookItem')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.uuid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}uuid')
            _c.text = self.uuid
        if self.comment is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}comment')
            _c.text = self.comment
        if self.sync is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}sync')
            _c.text = self.sync.value
        if self.domain is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}domain')
            _c.text = self.domain
        if self.post_office is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}postOffice')
            _c.text = self.post_office
        if self.distinguished_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}distinguishedName')
            _c.text = self.distinguished_name
        if self.userid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userid')
            _c.text = self.userid
        if self.p_ab_guid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}PABGuid')
            _c.text = self.p_ab_guid
        if self.visibility is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}visibility')
            _c.text = self.visibility.value
        if self.external is not None:
            _el.set('external', ('true' if self.external else 'false'))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}uuid')
        if _c is not None:
            if _c.text is not None:
                _f['uuid'] = _c.text
        _c = _el.find(f'{{{_NS}}}comment')
        if _c is not None:
            if _c.text is not None:
                _f['comment'] = _c.text
        _c = _el.find(f'{{{_NS}}}sync')
        if _c is not None:
            from gwsoap.types.DeltaSyncType import DeltaSyncType
            if _c.text is not None:
                _f['sync'] = DeltaSyncType(_c.text)
        _c = _el.find(f'{{{_NS}}}domain')
        if _c is not None:
            if _c.text is not None:
                _f['domain'] = _c.text
        _c = _el.find(f'{{{_NS}}}postOffice')
        if _c is not None:
            if _c.text is not None:
                _f['post_office'] = _c.text
        _c = _el.find(f'{{{_NS}}}distinguishedName')
        if _c is not None:
            if _c.text is not None:
                _f['distinguished_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}userid')
        if _c is not None:
            if _c.text is not None:
                _f['userid'] = _c.text
        _c = _el.find(f'{{{_NS}}}PABGuid')
        if _c is not None:
            if _c.text is not None:
                _f['p_ab_guid'] = _c.text
        _c = _el.find(f'{{{_NS}}}visibility')
        if _c is not None:
            from gwsoap.types.Visibility import Visibility
            if _c.text is not None:
                _f['visibility'] = Visibility(_c.text)
        _v = _el.get('external')
        if _v is not None:
            _f['external'] = ((_v) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AddressBookItem:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'Contact':
            from gwsoap.types.Contact import Contact
            return Contact(**Contact._parse_fields(_el))
        if _t == 'Group':
            from gwsoap.types.Group import Group
            return Group(**Group._parse_fields(_el))
        if _t == 'Nickname':
            from gwsoap.types.Nickname import Nickname
            return Nickname(**Nickname._parse_fields(_el))
        if _t == 'Organization':
            from gwsoap.types.Organization import Organization
            return Organization(**Organization._parse_fields(_el))
        if _t == 'Resource':
            from gwsoap.types.Resource import Resource
            return Resource(**Resource._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
