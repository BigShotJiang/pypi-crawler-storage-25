from __future__ import annotations

from enum import Enum


class SignatureType(str, Enum):
    AUTOMATIC = 'Automatic'
    PROMPT = 'Prompt'
