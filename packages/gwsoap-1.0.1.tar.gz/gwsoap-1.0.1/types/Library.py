from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Library(Item):
    description: str | None = None
    domain: str | None = None
    post_office: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Library'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Library')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.domain is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}domain')
            _c.text = self.domain
        if self.post_office is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}postOffice')
            _c.text = self.post_office

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}domain')
        if _c is not None:
            if _c.text is not None:
                _f['domain'] = _c.text
        _c = _el.find(f'{{{_NS}}}postOffice')
        if _c is not None:
            if _c.text is not None:
                _f['post_office'] = _c.text
        return _f
