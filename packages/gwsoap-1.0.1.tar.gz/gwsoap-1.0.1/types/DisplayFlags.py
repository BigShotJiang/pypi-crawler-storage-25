from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DisplayFlags:
    hide_non_tasklist_items: bool | None = None
    show_quick_viewer: bool | None = None
    remember_quick_viewer: bool | None = None
    summary: bool | None = None
    show_group_labels: bool | None = None
    show_folder_tree: bool | None = None
    remember_folder_tree: bool | None = None
    show_simple_folder_tree: bool | None = None
    show_full_folder_tree: bool | None = None
    message_preview: bool | None = None
    hide_completed: bool | None = None
    hide_completed_after_one_day: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DisplayFlags'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.hide_non_tasklist_items is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hideNonTasklistItems')
            _c.text = ('true' if self.hide_non_tasklist_items else 'false')
        if self.show_quick_viewer is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}showQuickViewer')
            _c.text = ('true' if self.show_quick_viewer else 'false')
        if self.remember_quick_viewer is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}rememberQuickViewer')
            _c.text = ('true' if self.remember_quick_viewer else 'false')
        if self.summary is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}summary')
            _c.text = ('true' if self.summary else 'false')
        if self.show_group_labels is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}showGroupLabels')
            _c.text = ('true' if self.show_group_labels else 'false')
        if self.show_folder_tree is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}showFolderTree')
            _c.text = ('true' if self.show_folder_tree else 'false')
        if self.remember_folder_tree is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}rememberFolderTree')
            _c.text = ('true' if self.remember_folder_tree else 'false')
        if self.show_simple_folder_tree is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}showSimpleFolderTree')
            _c.text = ('true' if self.show_simple_folder_tree else 'false')
        if self.show_full_folder_tree is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}showFullFolderTree')
            _c.text = ('true' if self.show_full_folder_tree else 'false')
        if self.message_preview is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}messagePreview')
            _c.text = ('true' if self.message_preview else 'false')
        if self.hide_completed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hideCompleted')
            _c.text = ('true' if self.hide_completed else 'false')
        if self.hide_completed_after_one_day is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hideCompletedAfterOneDay')
            _c.text = ('true' if self.hide_completed_after_one_day else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}hideNonTasklistItems')
        if _c is not None:
            if _c.text is not None:
                _f['hide_non_tasklist_items'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}showQuickViewer')
        if _c is not None:
            if _c.text is not None:
                _f['show_quick_viewer'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}rememberQuickViewer')
        if _c is not None:
            if _c.text is not None:
                _f['remember_quick_viewer'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}summary')
        if _c is not None:
            if _c.text is not None:
                _f['summary'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}showGroupLabels')
        if _c is not None:
            if _c.text is not None:
                _f['show_group_labels'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}showFolderTree')
        if _c is not None:
            if _c.text is not None:
                _f['show_folder_tree'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}rememberFolderTree')
        if _c is not None:
            if _c.text is not None:
                _f['remember_folder_tree'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}showSimpleFolderTree')
        if _c is not None:
            if _c.text is not None:
                _f['show_simple_folder_tree'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}showFullFolderTree')
        if _c is not None:
            if _c.text is not None:
                _f['show_full_folder_tree'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}messagePreview')
        if _c is not None:
            if _c.text is not None:
                _f['message_preview'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}hideCompleted')
        if _c is not None:
            if _c.text is not None:
                _f['hide_completed'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}hideCompletedAfterOneDay')
        if _c is not None:
            if _c.text is not None:
                _f['hide_completed_after_one_day'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> DisplayFlags:
        return cls(**cls._parse_fields(_el))
