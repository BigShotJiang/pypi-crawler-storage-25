from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Server:
    host: Host | None = None
    flags: ServerFlags | None = None
    userid: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Server'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.host is not None:
            self.host.to_xml(_el, f'{{{_NS}}}host')
        if self.flags is not None:
            self.flags.to_xml(_el, f'{{{_NS}}}flags')
        if self.userid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userid')
            _c.text = self.userid

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}host')
        if _c is not None:
            from gwsoap.types.Host import Host
            _f['host'] = Host.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}flags')
        if _c is not None:
            from gwsoap.types.ServerFlags import ServerFlags
            _f['flags'] = ServerFlags.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}userid')
        if _c is not None:
            if _c.text is not None:
                _f['userid'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Server:
        return cls(**cls._parse_fields(_el))
