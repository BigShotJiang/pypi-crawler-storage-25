from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class LinkInfo:
    id: str | None = None
    type: LinkType | None = None
    thread: str | None = None
    copy_attachments: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}LinkInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type.value
        if self.thread is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}thread')
            _c.text = self.thread
        if self.copy_attachments is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}copyAttachments')
            _c.text = ('true' if self.copy_attachments else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.types.LinkType import LinkType
            if _c.text is not None:
                _f['type'] = LinkType(_c.text)
        _c = _el.find(f'{{{_NS}}}thread')
        if _c is not None:
            if _c.text is not None:
                _f['thread'] = _c.text
        _c = _el.find(f'{{{_NS}}}copyAttachments')
        if _c is not None:
            if _c.text is not None:
                _f['copy_attachments'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> LinkInfo:
        return cls(**cls._parse_fields(_el))
