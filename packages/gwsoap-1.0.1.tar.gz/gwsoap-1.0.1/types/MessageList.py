from __future__ import annotations

from enum import Enum


class MessageList(str, Enum):
    ALL = 'All'
    MODIFIED = 'Modified'
    NEW = 'New'
