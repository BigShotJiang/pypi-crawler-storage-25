from __future__ import annotations

from enum import Enum


class ItemOptionsPriority(str, Enum):
    HIGH = 'High'
    STANDARD = 'Standard'
    LOW = 'Low'
