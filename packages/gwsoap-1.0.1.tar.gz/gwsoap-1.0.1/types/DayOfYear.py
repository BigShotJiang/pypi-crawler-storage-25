from __future__ import annotations

DayOfYear = int
