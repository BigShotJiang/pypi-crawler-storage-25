from __future__ import annotations

Day = int
