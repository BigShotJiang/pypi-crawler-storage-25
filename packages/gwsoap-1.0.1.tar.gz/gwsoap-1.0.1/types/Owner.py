from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Owner:
    domain: str | None = None
    post_office: str | None = None
    userid: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Owner'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.domain is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}domain')
            _c.text = self.domain
        if self.post_office is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}postOffice')
            _c.text = self.post_office
        if self.userid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userid')
            _c.text = self.userid

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}domain')
        if _c is not None:
            if _c.text is not None:
                _f['domain'] = _c.text
        _c = _el.find(f'{{{_NS}}}postOffice')
        if _c is not None:
            if _c.text is not None:
                _f['post_office'] = _c.text
        _c = _el.find(f'{{{_NS}}}userid')
        if _c is not None:
            if _c.text is not None:
                _f['userid'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Owner:
        return cls(**cls._parse_fields(_el))
