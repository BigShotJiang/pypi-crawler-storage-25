from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ServerFlags:
    save_password: bool | None = None
    use_incoming_auth: bool | None = None
    secure_connection: bool | None = None
    auth_required: bool | None = None
    i_map_acl: bool | None = None
    net_mail: bool | None = None
    s_sl_required: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ServerFlags'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.save_password is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}savePassword')
            _c.text = ('true' if self.save_password else 'false')
        if self.use_incoming_auth is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}useIncomingAuth')
            _c.text = ('true' if self.use_incoming_auth else 'false')
        if self.secure_connection is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}secureConnection')
            _c.text = ('true' if self.secure_connection else 'false')
        if self.auth_required is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}authRequired')
            _c.text = ('true' if self.auth_required else 'false')
        if self.i_map_acl is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}IMAP_ACL')
            _c.text = ('true' if self.i_map_acl else 'false')
        if self.net_mail is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}netMail')
            _c.text = ('true' if self.net_mail else 'false')
        if self.s_sl_required is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}SSLRequired')
            _c.text = ('true' if self.s_sl_required else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}savePassword')
        if _c is not None:
            if _c.text is not None:
                _f['save_password'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}useIncomingAuth')
        if _c is not None:
            if _c.text is not None:
                _f['use_incoming_auth'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}secureConnection')
        if _c is not None:
            if _c.text is not None:
                _f['secure_connection'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}authRequired')
        if _c is not None:
            if _c.text is not None:
                _f['auth_required'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}IMAP_ACL')
        if _c is not None:
            if _c.text is not None:
                _f['i_map_acl'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}netMail')
        if _c is not None:
            if _c.text is not None:
                _f['net_mail'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}SSLRequired')
        if _c is not None:
            if _c.text is not None:
                _f['s_sl_required'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ServerFlags:
        return cls(**cls._parse_fields(_el))
