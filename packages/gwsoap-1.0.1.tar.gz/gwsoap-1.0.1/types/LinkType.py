from __future__ import annotations

from enum import Enum


class LinkType(str, Enum):
    FORWARD = 'forward'
    REPLY = 'reply'
