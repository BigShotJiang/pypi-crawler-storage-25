from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AdvancedInfo:
    freebusy_website: str | None = None
    teaming_website: str | None = None
    customer_id: str | None = None
    government_id: str | None = None
    organizational_id: str | None = None
    computer_network_name: str | None = None
    ftp_site: str | None = None
    mileage: str | None = None
    user_field1: str | None = None
    user_field2: str | None = None
    user_field3: str | None = None
    user_field4: str | None = None
    black_berry_pin: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AdvancedInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.freebusy_website is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}freebusyWebsite')
            _c.text = self.freebusy_website
        if self.teaming_website is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}teamingWebsite')
            _c.text = self.teaming_website
        if self.customer_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}customerId')
            _c.text = self.customer_id
        if self.government_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}governmentId')
            _c.text = self.government_id
        if self.organizational_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}organizationalId')
            _c.text = self.organizational_id
        if self.computer_network_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}computerNetworkName')
            _c.text = self.computer_network_name
        if self.ftp_site is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}ftpSite')
            _c.text = self.ftp_site
        if self.mileage is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}mileage')
            _c.text = self.mileage
        if self.user_field1 is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userField1')
            _c.text = self.user_field1
        if self.user_field2 is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userField2')
            _c.text = self.user_field2
        if self.user_field3 is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userField3')
            _c.text = self.user_field3
        if self.user_field4 is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userField4')
            _c.text = self.user_field4
        if self.black_berry_pin is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}BlackBerryPIN')
            _c.text = self.black_berry_pin

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}freebusyWebsite')
        if _c is not None:
            if _c.text is not None:
                _f['freebusy_website'] = _c.text
        _c = _el.find(f'{{{_NS}}}teamingWebsite')
        if _c is not None:
            if _c.text is not None:
                _f['teaming_website'] = _c.text
        _c = _el.find(f'{{{_NS}}}customerId')
        if _c is not None:
            if _c.text is not None:
                _f['customer_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}governmentId')
        if _c is not None:
            if _c.text is not None:
                _f['government_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}organizationalId')
        if _c is not None:
            if _c.text is not None:
                _f['organizational_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}computerNetworkName')
        if _c is not None:
            if _c.text is not None:
                _f['computer_network_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}ftpSite')
        if _c is not None:
            if _c.text is not None:
                _f['ftp_site'] = _c.text
        _c = _el.find(f'{{{_NS}}}mileage')
        if _c is not None:
            if _c.text is not None:
                _f['mileage'] = _c.text
        _c = _el.find(f'{{{_NS}}}userField1')
        if _c is not None:
            if _c.text is not None:
                _f['user_field1'] = _c.text
        _c = _el.find(f'{{{_NS}}}userField2')
        if _c is not None:
            if _c.text is not None:
                _f['user_field2'] = _c.text
        _c = _el.find(f'{{{_NS}}}userField3')
        if _c is not None:
            if _c.text is not None:
                _f['user_field3'] = _c.text
        _c = _el.find(f'{{{_NS}}}userField4')
        if _c is not None:
            if _c.text is not None:
                _f['user_field4'] = _c.text
        _c = _el.find(f'{{{_NS}}}BlackBerryPIN')
        if _c is not None:
            if _c.text is not None:
                _f['black_berry_pin'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AdvancedInfo:
        return cls(**cls._parse_fields(_el))
