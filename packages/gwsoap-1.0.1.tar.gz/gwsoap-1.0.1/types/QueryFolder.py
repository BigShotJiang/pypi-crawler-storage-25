from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Folder import Folder
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class QueryFolder(Folder):
    folder_type: FolderType | None = None
    query: Query | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}QueryFolder'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'QueryFolder')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.folder_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}folderType')
            _c.text = self.folder_type.value
        if self.query is not None:
            self.query.to_xml(_el, f'{{{_NS}}}query')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}folderType')
        if _c is not None:
            from gwsoap.types.FolderType import FolderType
            if _c.text is not None:
                _f['folder_type'] = FolderType(_c.text)
        _c = _el.find(f'{{{_NS}}}query')
        if _c is not None:
            from gwsoap.types.Query import Query
            _f['query'] = Query.from_xml(_c)
        return _f
