from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AccessRightChanges:
    add: AccessRightEntry | None = None
    delete: AccessRightEntry | None = None
    update: AccessRightEntry | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AccessRightChanges'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.add is not None:
            self.add.to_xml(_el, f'{{{_NS}}}add')
        if self.delete is not None:
            self.delete.to_xml(_el, f'{{{_NS}}}delete')
        if self.update is not None:
            self.update.to_xml(_el, f'{{{_NS}}}update')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}add')
        if _c is not None:
            from gwsoap.types.AccessRightEntry import AccessRightEntry
            _f['add'] = AccessRightEntry.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}delete')
        if _c is not None:
            from gwsoap.types.AccessRightEntry import AccessRightEntry
            _f['delete'] = AccessRightEntry.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}update')
        if _c is not None:
            from gwsoap.types.AccessRightEntry import AccessRightEntry
            _f['update'] = AccessRightEntry.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AccessRightChanges:
        return cls(**cls._parse_fields(_el))
