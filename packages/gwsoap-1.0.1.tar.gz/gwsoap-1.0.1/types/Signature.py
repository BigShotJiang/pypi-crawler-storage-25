from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Signature:
    id: str | None = None
    name: str | None = None
    default_value: bool | None = None
    part: SignatureData | None = None
    global_value: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Signature'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.default_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}default')
            _c.text = ('true' if self.default_value else 'false')
        if self.part is not None:
            self.part.to_xml(_el, f'{{{_NS}}}part')
        if self.global_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}global')
            _c.text = ('true' if self.global_value else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}default')
        if _c is not None:
            if _c.text is not None:
                _f['default_value'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}part')
        if _c is not None:
            from gwsoap.types.SignatureData import SignatureData
            _f['part'] = SignatureData.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}global')
        if _c is not None:
            if _c.text is not None:
                _f['global_value'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Signature:
        return cls(**cls._parse_fields(_el))
