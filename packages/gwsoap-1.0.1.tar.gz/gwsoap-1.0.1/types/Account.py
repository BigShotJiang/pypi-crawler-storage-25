from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Account(Item):
    from_value: From | None = None
    server_timeout: int | None = None
    flags: AccountFlags | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Account'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Account')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.from_value is not None:
            self.from_value.to_xml(_el, f'{{{_NS}}}from')
        if self.server_timeout is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}serverTimeout')
            _c.text = str(self.server_timeout)
        if self.flags is not None:
            self.flags.to_xml(_el, f'{{{_NS}}}flags')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            from gwsoap.types.From import From
            _f['from_value'] = From.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}serverTimeout')
        if _c is not None:
            if _c.text is not None:
                _f['server_timeout'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}flags')
        if _c is not None:
            from gwsoap.types.AccountFlags import AccountFlags
            _f['flags'] = AccountFlags.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Account:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'IMAP':
            from gwsoap.types.IMAP import IMAP
            return IMAP(**IMAP._parse_fields(_el))
        if _t == 'NNTP':
            from gwsoap.types.NNTP import NNTP
            return NNTP(**NNTP._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
