from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FreeBusyStats:
    responded: int | None = None
    outstanding: int | None = None
    total: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FreeBusyStats'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.responded is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}responded')
            _c.text = str(self.responded)
        if self.outstanding is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}outstanding')
            _c.text = str(self.outstanding)
        if self.total is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}total')
            _c.text = str(self.total)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}responded')
        if _c is not None:
            if _c.text is not None:
                _f['responded'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}outstanding')
        if _c is not None:
            if _c.text is not None:
                _f['outstanding'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}total')
        if _c is not None:
            if _c.text is not None:
                _f['total'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> FreeBusyStats:
        return cls(**cls._parse_fields(_el))
