from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from datetime import date
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class RecurrenceDateType:
    date: list[date] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}RecurrenceDateType'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.date:
            _c = ET.SubElement(_el, f'{{{_NS}}}date')
            _c.text = _v.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _f['date'] = [date.fromisoformat(_c.text) for _c in _el.findall(f'{{{_NS}}}date') if _c.text is not None]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RecurrenceDateType:
        return cls(**cls._parse_fields(_el))
