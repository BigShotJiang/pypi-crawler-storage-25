from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Timezone:
    id: str | None = None
    description: str | None = None
    daylight: TimezoneComponent | None = None
    standard: TimezoneComponent | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Timezone'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.daylight is not None:
            self.daylight.to_xml(_el, f'{{{_NS}}}daylight')
        if self.standard is not None:
            self.standard.to_xml(_el, f'{{{_NS}}}standard')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}daylight')
        if _c is not None:
            from gwsoap.types.TimezoneComponent import TimezoneComponent
            _f['daylight'] = TimezoneComponent.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}standard')
        if _c is not None:
            from gwsoap.types.TimezoneComponent import TimezoneComponent
            _f['standard'] = TimezoneComponent.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Timezone:
        return cls(**cls._parse_fields(_el))
