from __future__ import annotations

from enum import Enum


class AcceptLevel(str, Enum):
    FREE = 'Free'
    TENTATIVE = 'Tentative'
    BUSY = 'Busy'
    OUTOFOFFICE = 'OutOfOffice'
    NODISPLAY = 'NoDisplay'
