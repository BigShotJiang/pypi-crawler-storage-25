from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ProblemEntry:
    element: str | None = None
    code: int | None = None
    description: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ProblemEntry'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.element is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}element')
            _c.text = self.element
        if self.code is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}code')
            _c.text = str(self.code)
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}element')
        if _c is not None:
            if _c.text is not None:
                _f['element'] = _c.text
        _c = _el.find(f'{{{_NS}}}code')
        if _c is not None:
            if _c.text is not None:
                _f['code'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ProblemEntry:
        return cls(**cls._parse_fields(_el))
