from __future__ import annotations

from enum import Enum


class AgeAction(str, Enum):
    ARCHIVE = 'archive'
    DELETE = 'delete'
    RETAIN = 'retain'
