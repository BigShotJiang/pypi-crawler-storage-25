from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.AddressBookItem import AddressBookItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Group(AddressBookItem):
    email: str | None = None
    members: GroupMemberList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Group'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Group')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.email is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}email')
            _c.text = self.email
        if self.members is not None:
            self.members.to_xml(_el, f'{{{_NS}}}members')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}email')
        if _c is not None:
            if _c.text is not None:
                _f['email'] = _c.text
        _c = _el.find(f'{{{_NS}}}members')
        if _c is not None:
            from gwsoap.types.GroupMemberList import GroupMemberList
            _f['members'] = GroupMemberList.from_xml(_c)
        return _f
