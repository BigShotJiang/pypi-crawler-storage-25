from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from datetime import datetime
from gwsoap.types.BoxEntry import BoxEntry
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Mail(BoxEntry):
    subject: str | None = None
    original_subject: str | None = None
    subject_prefix: str | None = None
    distribution: Distribution | None = None
    message: MessageBody | None = None
    attachments: AttachmentInfo | None = None
    options: ItemOptions | None = None
    link: LinkInfo | None = None
    has_attachment: bool | None = None
    size: int | None = None
    sub_type: str | None = None
    nntp_or_imap: bool | None = None
    smime_type: SMimeOperation | None = None
    checklist: ChecklistInfo | None = None
    x_field: list[str] = _field(default_factory=list)
    original_id: str | None = None
    archive_id: str | None = None
    threading: ItemThreading | None = None
    retention_modified: datetime | None = None
    rss_url: str | None = None
    internet: bool | None = None
    stub: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Mail'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Mail')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.subject is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}subject')
            _c.text = self.subject
        if self.original_subject is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}originalSubject')
            _c.text = self.original_subject
        if self.subject_prefix is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}subjectPrefix')
            _c.text = self.subject_prefix
        if self.distribution is not None:
            self.distribution.to_xml(_el, f'{{{_NS}}}distribution')
        if self.message is not None:
            self.message.to_xml(_el, f'{{{_NS}}}message')
        if self.attachments is not None:
            self.attachments.to_xml(_el, f'{{{_NS}}}attachments')
        if self.options is not None:
            self.options.to_xml(_el, f'{{{_NS}}}options')
        if self.link is not None:
            self.link.to_xml(_el, f'{{{_NS}}}link')
        if self.has_attachment is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hasAttachment')
            _c.text = ('true' if self.has_attachment else 'false')
        if self.size is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}size')
            _c.text = str(self.size)
        if self.sub_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}subType')
            _c.text = self.sub_type
        if self.nntp_or_imap is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}nntpOrImap')
            _c.text = ('true' if self.nntp_or_imap else 'false')
        if self.smime_type is not None:
            self.smime_type.to_xml(_el, f'{{{_NS}}}smimeType')
        if self.checklist is not None:
            self.checklist.to_xml(_el, f'{{{_NS}}}checklist')
        for _v in self.x_field:
            _c = ET.SubElement(_el, f'{{{_NS}}}xField')
            _c.text = _v
        if self.original_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}originalId')
            _c.text = self.original_id
        if self.archive_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}archiveId')
            _c.text = self.archive_id
        if self.threading is not None:
            self.threading.to_xml(_el, f'{{{_NS}}}threading')
        if self.retention_modified is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retentionModified')
            _c.text = self.retention_modified.isoformat()
        if self.rss_url is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}rssURL')
            _c.text = self.rss_url
        if self.internet is not None:
            _el.set('internet', ('true' if self.internet else 'false'))
        if self.stub is not None:
            _el.set('stub', ('true' if self.stub else 'false'))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}subject')
        if _c is not None:
            if _c.text is not None:
                _f['subject'] = _c.text
        _c = _el.find(f'{{{_NS}}}originalSubject')
        if _c is not None:
            if _c.text is not None:
                _f['original_subject'] = _c.text
        _c = _el.find(f'{{{_NS}}}subjectPrefix')
        if _c is not None:
            if _c.text is not None:
                _f['subject_prefix'] = _c.text
        _c = _el.find(f'{{{_NS}}}distribution')
        if _c is not None:
            from gwsoap.types.Distribution import Distribution
            _f['distribution'] = Distribution.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}message')
        if _c is not None:
            from gwsoap.types.MessageBody import MessageBody
            _f['message'] = MessageBody.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}attachments')
        if _c is not None:
            from gwsoap.types.AttachmentInfo import AttachmentInfo
            _f['attachments'] = AttachmentInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}options')
        if _c is not None:
            from gwsoap.types.ItemOptions import ItemOptions
            _f['options'] = ItemOptions.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}link')
        if _c is not None:
            from gwsoap.types.LinkInfo import LinkInfo
            _f['link'] = LinkInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}hasAttachment')
        if _c is not None:
            if _c.text is not None:
                _f['has_attachment'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}size')
        if _c is not None:
            if _c.text is not None:
                _f['size'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}subType')
        if _c is not None:
            if _c.text is not None:
                _f['sub_type'] = _c.text
        _c = _el.find(f'{{{_NS}}}nntpOrImap')
        if _c is not None:
            if _c.text is not None:
                _f['nntp_or_imap'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}smimeType')
        if _c is not None:
            from gwsoap.types.SMimeOperation import SMimeOperation
            _f['smime_type'] = SMimeOperation.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}checklist')
        if _c is not None:
            from gwsoap.types.ChecklistInfo import ChecklistInfo
            _f['checklist'] = ChecklistInfo.from_xml(_c)
        _f['x_field'] = [_c.text for _c in _el.findall(f'{{{_NS}}}xField') if _c.text is not None]
        _c = _el.find(f'{{{_NS}}}originalId')
        if _c is not None:
            if _c.text is not None:
                _f['original_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}archiveId')
        if _c is not None:
            if _c.text is not None:
                _f['archive_id'] = _c.text
        _c = _el.find(f'{{{_NS}}}threading')
        if _c is not None:
            from gwsoap.types.ItemThreading import ItemThreading
            _f['threading'] = ItemThreading.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}retentionModified')
        if _c is not None:
            if _c.text is not None:
                _f['retention_modified'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}rssURL')
        if _c is not None:
            if _c.text is not None:
                _f['rss_url'] = _c.text
        _v = _el.get('internet')
        if _v is not None:
            _f['internet'] = ((_v) or '').lower() in ('true', '1')
        _v = _el.get('stub')
        if _v is not None:
            _f['stub'] = ((_v) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Mail:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'Appointment':
            from gwsoap.types.Appointment import Appointment
            return Appointment(**Appointment._parse_fields(_el))
        if _t == 'CalendarItem':
            from gwsoap.types.CalendarItem import CalendarItem
            return CalendarItem(**CalendarItem._parse_fields(_el))
        if _t == 'DocumentRef':
            from gwsoap.types.DocumentRef import DocumentRef
            return DocumentRef(**DocumentRef._parse_fields(_el))
        if _t == 'Note':
            from gwsoap.types.Note import Note
            return Note(**Note._parse_fields(_el))
        if _t == 'PhoneMessage':
            from gwsoap.types.PhoneMessage import PhoneMessage
            return PhoneMessage(**PhoneMessage._parse_fields(_el))
        if _t == 'SharedNotification':
            from gwsoap.types.SharedNotification import SharedNotification
            return SharedNotification(**SharedNotification._parse_fields(_el))
        if _t == 'Task':
            from gwsoap.types.Task import Task
            return Task(**Task._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
