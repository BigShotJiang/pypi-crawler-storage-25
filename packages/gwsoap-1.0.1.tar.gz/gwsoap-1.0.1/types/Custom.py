from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Custom:
    field: str | None = None
    value: str | None = None
    notify: ReturnNotificationOptions | None = None
    locked: bool | None = None
    admin_only: bool | None = None
    type: CustomType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Custom'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.field is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}field')
            _c.text = self.field
        if self.value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}value')
            _c.text = self.value
        if self.notify is not None:
            self.notify.to_xml(_el, f'{{{_NS}}}notify')
        if self.locked is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}locked')
            _c.text = ('true' if self.locked else 'false')
        if self.admin_only is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}adminOnly')
            _c.text = ('true' if self.admin_only else 'false')
        if self.type is not None:
            _el.set('type', self.type.value)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}field')
        if _c is not None:
            if _c.text is not None:
                _f['field'] = _c.text
        _c = _el.find(f'{{{_NS}}}value')
        if _c is not None:
            if _c.text is not None:
                _f['value'] = _c.text
        _c = _el.find(f'{{{_NS}}}notify')
        if _c is not None:
            from gwsoap.types.ReturnNotificationOptions import ReturnNotificationOptions
            _f['notify'] = ReturnNotificationOptions.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}locked')
        if _c is not None:
            if _c.text is not None:
                _f['locked'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}adminOnly')
        if _c is not None:
            if _c.text is not None:
                _f['admin_only'] = ((_c.text) or '').lower() in ('true', '1')
        _v = _el.get('type')
        if _v is not None:
            from gwsoap.types.CustomType import CustomType
            _f['type'] = CustomType(_v)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Custom:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'DocumentCustom':
            from gwsoap.types.DocumentCustom import DocumentCustom
            return DocumentCustom(**DocumentCustom._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
