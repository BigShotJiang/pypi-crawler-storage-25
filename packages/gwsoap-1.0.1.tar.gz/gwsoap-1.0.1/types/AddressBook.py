from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AddressBook(Item):
    description: str | None = None
    is_personal: bool | None = None
    is_frequent_contacts: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AddressBook'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'AddressBook')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.is_personal is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isPersonal')
            _c.text = ('true' if self.is_personal else 'false')
        if self.is_frequent_contacts is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isFrequentContacts')
            _c.text = ('true' if self.is_frequent_contacts else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}isPersonal')
        if _c is not None:
            if _c.text is not None:
                _f['is_personal'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}isFrequentContacts')
        if _c is not None:
            if _c.text is not None:
                _f['is_frequent_contacts'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AddressBook:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'SharedBook':
            from gwsoap.types.SharedBook import SharedBook
            return SharedBook(**SharedBook._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
