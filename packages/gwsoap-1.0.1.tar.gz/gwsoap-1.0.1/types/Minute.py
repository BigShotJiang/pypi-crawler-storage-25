from __future__ import annotations

Minute = int
