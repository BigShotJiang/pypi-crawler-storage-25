from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from gwsoap.types.CalendarItem import CalendarItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Task(CalendarItem):
    start_date: date | None = None
    due_date: date | None = None
    assigned_date: date | None = None
    task_priority: str | None = None
    completed: bool | None = None
    timezone: Timezone | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Task'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Task')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}startDate')
            _c.text = self.start_date.isoformat()
        if self.due_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}dueDate')
            _c.text = self.due_date.isoformat()
        if self.assigned_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}assignedDate')
            _c.text = self.assigned_date.isoformat()
        if self.task_priority is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}taskPriority')
            _c.text = self.task_priority
        if self.completed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}completed')
            _c.text = ('true' if self.completed else 'false')
        if self.timezone is not None:
            self.timezone.to_xml(_el, f'{{{_NS}}}timezone')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}dueDate')
        if _c is not None:
            if _c.text is not None:
                _f['due_date'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}assignedDate')
        if _c is not None:
            if _c.text is not None:
                _f['assigned_date'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}taskPriority')
        if _c is not None:
            if _c.text is not None:
                _f['task_priority'] = _c.text
        _c = _el.find(f'{{{_NS}}}completed')
        if _c is not None:
            if _c.text is not None:
                _f['completed'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}timezone')
        if _c is not None:
            from gwsoap.types.Timezone import Timezone
            _f['timezone'] = Timezone.from_xml(_c)
        return _f
