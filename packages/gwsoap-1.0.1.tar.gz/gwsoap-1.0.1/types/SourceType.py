from __future__ import annotations

from enum import Enum


class SourceType(str, Enum):
    LIBRARY = 'Library'
    USER = 'User'
