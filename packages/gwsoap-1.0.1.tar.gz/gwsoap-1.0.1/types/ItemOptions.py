from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ItemOptions:
    priority: ItemOptionsPriority | None = None
    expires: datetime | None = None
    delay_delivery_until: datetime | None = None
    conceal_subject: bool | None = None
    hidden: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ItemOptions'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.priority is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}priority')
            _c.text = self.priority.value
        if self.expires is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}expires')
            _c.text = self.expires.isoformat()
        if self.delay_delivery_until is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}delayDeliveryUntil')
            _c.text = self.delay_delivery_until.isoformat()
        if self.conceal_subject is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}concealSubject')
            _c.text = ('true' if self.conceal_subject else 'false')
        if self.hidden is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hidden')
            _c.text = ('true' if self.hidden else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}priority')
        if _c is not None:
            from gwsoap.types.ItemOptionsPriority import ItemOptionsPriority
            if _c.text is not None:
                _f['priority'] = ItemOptionsPriority(_c.text)
        _c = _el.find(f'{{{_NS}}}expires')
        if _c is not None:
            if _c.text is not None:
                _f['expires'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}delayDeliveryUntil')
        if _c is not None:
            if _c.text is not None:
                _f['delay_delivery_until'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}concealSubject')
        if _c is not None:
            if _c.text is not None:
                _f['conceal_subject'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}hidden')
        if _c is not None:
            if _c.text is not None:
                _f['hidden'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ItemOptions:
        return cls(**cls._parse_fields(_el))
