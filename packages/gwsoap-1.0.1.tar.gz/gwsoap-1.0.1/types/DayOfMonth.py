from __future__ import annotations

DayOfMonth = int
