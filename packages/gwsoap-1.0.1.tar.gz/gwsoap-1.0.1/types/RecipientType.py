from __future__ import annotations

from enum import Enum


class RecipientType(str, Enum):
    USER = 'User'
    RESOURCE = 'Resource'
    PERSONALGROUP = 'PersonalGroup'
    SYSTEMGROUP = 'SystemGroup'
    PERSONALGROUPMEMBER = 'PersonalGroupMember'
    SYSTEMGROUPMEMBER = 'SystemGroupMember'
