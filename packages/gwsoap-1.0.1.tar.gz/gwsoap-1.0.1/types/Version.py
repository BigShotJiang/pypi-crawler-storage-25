from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from gwsoap.types.ContainerItem import ContainerItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Version(ContainerItem):
    library: NameAndEmail | None = None
    document_number: int | None = None
    version_creator: NameAndEmail | None = None
    retrieved_by: NameAndEmail | None = None
    retrieved_date: datetime | None = None
    version_number: int | None = None
    version_description: str | None = None
    version_status: VersionStatus | None = None
    life: int | None = None
    age_action: AgeAction | None = None
    file_size: int | None = None
    filename: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Version'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Version')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.library is not None:
            self.library.to_xml(_el, f'{{{_NS}}}library')
        if self.document_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}documentNumber')
            _c.text = str(self.document_number)
        if self.version_creator is not None:
            self.version_creator.to_xml(_el, f'{{{_NS}}}versionCreator')
        if self.retrieved_by is not None:
            self.retrieved_by.to_xml(_el, f'{{{_NS}}}retrievedBy')
        if self.retrieved_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retrievedDate')
            _c.text = self.retrieved_date.isoformat()
        if self.version_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionNumber')
            _c.text = str(self.version_number)
        if self.version_description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionDescription')
            _c.text = self.version_description
        if self.version_status is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionStatus')
            _c.text = self.version_status.value
        if self.life is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}life')
            _c.text = str(self.life)
        if self.age_action is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}ageAction')
            _c.text = self.age_action.value
        if self.file_size is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}fileSize')
            _c.text = str(self.file_size)
        if self.filename is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}filename')
            _c.text = self.filename

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}library')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['library'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}documentNumber')
        if _c is not None:
            if _c.text is not None:
                _f['document_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}versionCreator')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['version_creator'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}retrievedBy')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['retrieved_by'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}retrievedDate')
        if _c is not None:
            if _c.text is not None:
                _f['retrieved_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}versionNumber')
        if _c is not None:
            if _c.text is not None:
                _f['version_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}versionDescription')
        if _c is not None:
            if _c.text is not None:
                _f['version_description'] = _c.text
        _c = _el.find(f'{{{_NS}}}versionStatus')
        if _c is not None:
            from gwsoap.types.VersionStatus import VersionStatus
            if _c.text is not None:
                _f['version_status'] = VersionStatus(_c.text)
        _c = _el.find(f'{{{_NS}}}life')
        if _c is not None:
            if _c.text is not None:
                _f['life'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}ageAction')
        if _c is not None:
            from gwsoap.types.AgeAction import AgeAction
            if _c.text is not None:
                _f['age_action'] = AgeAction(_c.text)
        _c = _el.find(f'{{{_NS}}}fileSize')
        if _c is not None:
            if _c.text is not None:
                _f['file_size'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}filename')
        if _c is not None:
            if _c.text is not None:
                _f['filename'] = _c.text
        return _f
