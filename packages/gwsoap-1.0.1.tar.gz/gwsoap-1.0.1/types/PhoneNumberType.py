from __future__ import annotations

from enum import Enum


class PhoneNumberType(str, Enum):
    FAX = 'Fax'
    HOME = 'Home'
    MOBILE = 'Mobile'
    OFFICE = 'Office'
    PAGER = 'Pager'
    CALLBACK = 'CallBack'
    OFFICE2 = 'Office2'
    RADIO = 'Radio'
    CAR = 'Car'
    OTHER = 'Other'
    TELEX = 'Telex'
    ISDN = 'ISDN'
    ASSISTANT = 'Assistant'
    HOME2 = 'Home2'
    FAXOFFICE = 'FaxOffice'
    FAXHOME = 'FaxHome'
    TTYTDD = 'TTYTDD'
    COMPANY = 'Company'
