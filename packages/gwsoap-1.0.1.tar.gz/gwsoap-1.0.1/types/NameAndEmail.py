from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class NameAndEmail:
    display_name: str | None = None
    email: str | None = None
    uuid: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}NameAndEmail'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.display_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}displayName')
            _c.text = self.display_name
        if self.email is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}email')
            _c.text = self.email
        if self.uuid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}uuid')
            _c.text = self.uuid

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}displayName')
        if _c is not None:
            if _c.text is not None:
                _f['display_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}email')
        if _c is not None:
            if _c.text is not None:
                _f['email'] = _c.text
        _c = _el.find(f'{{{_NS}}}uuid')
        if _c is not None:
            if _c.text is not None:
                _f['uuid'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> NameAndEmail:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'AccessControlListEntry':
            from gwsoap.types.AccessControlListEntry import AccessControlListEntry
            return AccessControlListEntry(**AccessControlListEntry._parse_fields(_el))
        if _t == 'AccessRightEntry':
            from gwsoap.types.AccessRightEntry import AccessRightEntry
            return AccessRightEntry(**AccessRightEntry._parse_fields(_el))
        if _t == 'FolderACLEntry':
            from gwsoap.types.FolderACLEntry import FolderACLEntry
            return FolderACLEntry(**FolderACLEntry._parse_fields(_el))
        if _t == 'FreeBusyInfo':
            from gwsoap.types.FreeBusyInfo import FreeBusyInfo
            return FreeBusyInfo(**FreeBusyInfo._parse_fields(_el))
        if _t == 'From':
            from gwsoap.types.From import From
            return From(**From._parse_fields(_el))
        if _t == 'ProxyUser':
            from gwsoap.types.ProxyUser import ProxyUser
            return ProxyUser(**ProxyUser._parse_fields(_el))
        if _t == 'Recipient':
            from gwsoap.types.Recipient import Recipient
            return Recipient(**Recipient._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
