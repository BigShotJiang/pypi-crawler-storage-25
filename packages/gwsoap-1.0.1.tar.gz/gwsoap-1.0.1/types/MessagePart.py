from __future__ import annotations

from dataclasses import dataclass
from gwsoap._utils import b64enc as _b64enc, b64dec as _b64dec
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class MessagePart:
    value: bytes | None = None
    id: str | None = None
    content_id: str | None = None
    content_type: str | None = None
    length: int | None = None
    offset: int | None = None
    hash: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}MessagePart'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.value is not None:
            _el.text = _b64enc(self.value)
        if self.id is not None:
            _el.set('id', self.id)
        if self.content_id is not None:
            _el.set('contentId', self.content_id)
        if self.content_type is not None:
            _el.set('contentType', self.content_type)
        if self.length is not None:
            _el.set('length', str(self.length))
        if self.offset is not None:
            _el.set('offset', str(self.offset))
        if self.hash is not None:
            _el.set('hash', self.hash)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        if _el.text is not None:
            _f['value'] = _b64dec(_el.text)
        _v = _el.get('id')
        if _v is not None:
            _f['id'] = _v
        _v = _el.get('contentId')
        if _v is not None:
            _f['content_id'] = _v
        _v = _el.get('contentType')
        if _v is not None:
            _f['content_type'] = _v
        _v = _el.get('length')
        if _v is not None:
            _f['length'] = int(_v)
        _v = _el.get('offset')
        if _v is not None:
            _f['offset'] = int(_v)
        _v = _el.get('hash')
        if _v is not None:
            _f['hash'] = _v
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> MessagePart:
        return cls(**cls._parse_fields(_el))
