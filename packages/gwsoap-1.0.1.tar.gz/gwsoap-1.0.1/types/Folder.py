from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Folder(Item):
    parent: str | None = None
    description: str | None = None
    count: int | None = None
    has_unread: bool | None = None
    unread_count: int | None = None
    sequence: int | None = None
    settings: str | None = None
    calendar_attribute: CalendarFolderAttribute | None = None
    u_rl: str | None = None
    frequency: int | None = None
    display_settings: FolderDisplaySettings | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Folder'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Folder')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.parent is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}parent')
            _c.text = self.parent
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}count')
            _c.text = str(self.count)
        if self.has_unread is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hasUnread')
            _c.text = ('true' if self.has_unread else 'false')
        if self.unread_count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}unreadCount')
            _c.text = str(self.unread_count)
        if self.sequence is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}sequence')
            _c.text = str(self.sequence)
        if self.settings is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}settings')
            _c.text = self.settings
        if self.calendar_attribute is not None:
            self.calendar_attribute.to_xml(_el, f'{{{_NS}}}calendarAttribute')
        if self.u_rl is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}URL')
            _c.text = self.u_rl
        if self.frequency is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}frequency')
            _c.text = str(self.frequency)
        if self.display_settings is not None:
            self.display_settings.to_xml(_el, f'{{{_NS}}}displaySettings')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}parent')
        if _c is not None:
            if _c.text is not None:
                _f['parent'] = _c.text
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}count')
        if _c is not None:
            if _c.text is not None:
                _f['count'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}hasUnread')
        if _c is not None:
            if _c.text is not None:
                _f['has_unread'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}unreadCount')
        if _c is not None:
            if _c.text is not None:
                _f['unread_count'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}sequence')
        if _c is not None:
            if _c.text is not None:
                _f['sequence'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}settings')
        if _c is not None:
            if _c.text is not None:
                _f['settings'] = _c.text
        _c = _el.find(f'{{{_NS}}}calendarAttribute')
        if _c is not None:
            from gwsoap.types.CalendarFolderAttribute import CalendarFolderAttribute
            _f['calendar_attribute'] = CalendarFolderAttribute.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}URL')
        if _c is not None:
            if _c.text is not None:
                _f['u_rl'] = _c.text
        _c = _el.find(f'{{{_NS}}}frequency')
        if _c is not None:
            if _c.text is not None:
                _f['frequency'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}displaySettings')
        if _c is not None:
            from gwsoap.types.FolderDisplaySettings import FolderDisplaySettings
            _f['display_settings'] = FolderDisplaySettings.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Folder:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'ContactFolder':
            from gwsoap.types.ContactFolder import ContactFolder
            return ContactFolder(**ContactFolder._parse_fields(_el))
        if _t == 'IMAPFolder':
            from gwsoap.types.IMAPFolder import IMAPFolder
            return IMAPFolder(**IMAPFolder._parse_fields(_el))
        if _t == 'NNTPFolder':
            from gwsoap.types.NNTPFolder import NNTPFolder
            return NNTPFolder(**NNTPFolder._parse_fields(_el))
        if _t == 'QueryFolder':
            from gwsoap.types.QueryFolder import QueryFolder
            return QueryFolder(**QueryFolder._parse_fields(_el))
        if _t == 'SharedFolder':
            from gwsoap.types.SharedFolder import SharedFolder
            return SharedFolder(**SharedFolder._parse_fields(_el))
        if _t == 'SystemFolder':
            from gwsoap.types.SystemFolder import SystemFolder
            return SystemFolder(**SystemFolder._parse_fields(_el))
        if _t == 'UserContactFolder':
            from gwsoap.types.UserContactFolder import UserContactFolder
            return UserContactFolder(**UserContactFolder._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
