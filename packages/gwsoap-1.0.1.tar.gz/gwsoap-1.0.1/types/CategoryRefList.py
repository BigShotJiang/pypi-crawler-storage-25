from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class CategoryRefList:
    category: list[str] = _field(default_factory=list)
    primary: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}CategoryRefList'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.category:
            _c = ET.SubElement(_el, f'{{{_NS}}}category')
            _c.text = _v
        if self.primary is not None:
            _el.set('primary', self.primary)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _f['category'] = [_c.text for _c in _el.findall(f'{{{_NS}}}category') if _c.text is not None]
        _v = _el.get('primary')
        if _v is not None:
            _f['primary'] = _v
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> CategoryRefList:
        return cls(**cls._parse_fields(_el))
