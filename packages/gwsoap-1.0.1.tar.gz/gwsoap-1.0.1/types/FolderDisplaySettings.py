from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.DisplaySettings import DisplaySettings
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FolderDisplaySettings(DisplaySettings):
    panel_columns: int | None = None
    panels: PanelList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FolderDisplaySettings'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'FolderDisplaySettings')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.panel_columns is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}panelColumns')
            _c.text = str(self.panel_columns)
        if self.panels is not None:
            self.panels.to_xml(_el, f'{{{_NS}}}panels')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}panelColumns')
        if _c is not None:
            if _c.text is not None:
                _f['panel_columns'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}panels')
        if _c is not None:
            from gwsoap.types.PanelList import PanelList
            _f['panels'] = PanelList.from_xml(_c)
        return _f
