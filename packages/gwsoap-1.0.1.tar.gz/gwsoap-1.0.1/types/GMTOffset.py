from __future__ import annotations

GMTOffset = int
