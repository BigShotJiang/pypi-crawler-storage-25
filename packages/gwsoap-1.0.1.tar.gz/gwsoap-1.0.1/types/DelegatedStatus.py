from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.CommentStatus import CommentStatus
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DelegatedStatus(CommentStatus):
    userid: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DelegatedStatus'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'DelegatedStatus')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.userid is not None:
            _el.set('userid', self.userid)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _v = _el.get('userid')
        if _v is not None:
            _f['userid'] = _v
        return _f
