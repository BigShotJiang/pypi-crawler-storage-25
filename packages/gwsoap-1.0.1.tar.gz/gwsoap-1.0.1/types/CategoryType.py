from __future__ import annotations

from enum import Enum


class CategoryType(str, Enum):
    NORMAL = 'Normal'
    PERSONAL = 'Personal'
    FOLLOWUP = 'FollowUp'
    URGENT = 'Urgent'
    LOWPRIORITY = 'LowPriority'
