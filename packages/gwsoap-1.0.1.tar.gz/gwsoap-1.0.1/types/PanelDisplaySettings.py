from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.DisplaySettings import DisplaySettings
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PanelDisplaySettings(DisplaySettings):
    panel_name: str | None = None
    column: int | None = None
    index: int | None = None
    container: str | None = None
    filter: Filter | None = None
    split_bar: str | None = None
    width: int | None = None
    height: int | None = None
    original_height: int | None = None
    week_view_columns: int | None = None
    calendar_view: CalendarViewType | None = None
    website: str | None = None
    interval: int | None = None
    h_scroll_position: int | None = None
    v_scroll_position: int | None = None
    description: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PanelDisplaySettings'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'PanelDisplaySettings')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.panel_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}panelName')
            _c.text = self.panel_name
        if self.column is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}column')
            _c.text = str(self.column)
        if self.index is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}index')
            _c.text = str(self.index)
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.filter is not None:
            self.filter.to_xml(_el, f'{{{_NS}}}filter')
        if self.split_bar is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}splitBar')
            _c.text = self.split_bar
        if self.width is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}width')
            _c.text = str(self.width)
        if self.height is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}height')
            _c.text = str(self.height)
        if self.original_height is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}originalHeight')
            _c.text = str(self.original_height)
        if self.week_view_columns is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}weekViewColumns')
            _c.text = str(self.week_view_columns)
        if self.calendar_view is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}calendarView')
            _c.text = self.calendar_view.value
        if self.website is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}website')
            _c.text = self.website
        if self.interval is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}interval')
            _c.text = str(self.interval)
        if self.h_scroll_position is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hScrollPosition')
            _c.text = str(self.h_scroll_position)
        if self.v_scroll_position is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}vScrollPosition')
            _c.text = str(self.v_scroll_position)
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}panelName')
        if _c is not None:
            if _c.text is not None:
                _f['panel_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}column')
        if _c is not None:
            if _c.text is not None:
                _f['column'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}index')
        if _c is not None:
            if _c.text is not None:
                _f['index'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}filter')
        if _c is not None:
            from gwsoap.types.Filter import Filter
            _f['filter'] = Filter.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}splitBar')
        if _c is not None:
            if _c.text is not None:
                _f['split_bar'] = _c.text
        _c = _el.find(f'{{{_NS}}}width')
        if _c is not None:
            if _c.text is not None:
                _f['width'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}height')
        if _c is not None:
            if _c.text is not None:
                _f['height'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}originalHeight')
        if _c is not None:
            if _c.text is not None:
                _f['original_height'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}weekViewColumns')
        if _c is not None:
            if _c.text is not None:
                _f['week_view_columns'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}calendarView')
        if _c is not None:
            from gwsoap.types.CalendarViewType import CalendarViewType
            if _c.text is not None:
                _f['calendar_view'] = CalendarViewType(_c.text)
        _c = _el.find(f'{{{_NS}}}website')
        if _c is not None:
            if _c.text is not None:
                _f['website'] = _c.text
        _c = _el.find(f'{{{_NS}}}interval')
        if _c is not None:
            if _c.text is not None:
                _f['interval'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}hScrollPosition')
        if _c is not None:
            if _c.text is not None:
                _f['h_scroll_position'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}vScrollPosition')
        if _c is not None:
            if _c.text is not None:
                _f['v_scroll_position'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        return _f
