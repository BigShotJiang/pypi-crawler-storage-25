from __future__ import annotations

WeekOfYear = int
