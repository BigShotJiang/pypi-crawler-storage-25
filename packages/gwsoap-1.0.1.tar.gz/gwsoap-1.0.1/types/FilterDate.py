from __future__ import annotations

from enum import Enum


class FilterDate(str, Enum):
    TODAY = 'Today'
    TOMORROW = 'Tomorrow'
    THISMONTH = 'ThisMonth'
    THISWEEK = 'ThisWeek'
    THISYEAR = 'ThisYear'
    YESTERDAY = 'Yesterday'
