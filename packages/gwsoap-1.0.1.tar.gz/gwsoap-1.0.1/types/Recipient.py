from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.NameAndEmail import NameAndEmail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Recipient(NameAndEmail):
    dist_type: DistributionType | None = None
    recip_type: RecipientType | None = None
    recipient_status: RecipientStatus | None = None
    accept_level: AcceptLevel | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Recipient'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Recipient')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.dist_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}distType')
            _c.text = self.dist_type.value
        if self.recip_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}recipType')
            _c.text = self.recip_type.value
        if self.recipient_status is not None:
            self.recipient_status.to_xml(_el, f'{{{_NS}}}recipientStatus')
        if self.accept_level is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}acceptLevel')
            _c.text = self.accept_level.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}distType')
        if _c is not None:
            from gwsoap.types.DistributionType import DistributionType
            if _c.text is not None:
                _f['dist_type'] = DistributionType(_c.text)
        _c = _el.find(f'{{{_NS}}}recipType')
        if _c is not None:
            from gwsoap.types.RecipientType import RecipientType
            if _c.text is not None:
                _f['recip_type'] = RecipientType(_c.text)
        _c = _el.find(f'{{{_NS}}}recipientStatus')
        if _c is not None:
            from gwsoap.types.RecipientStatus import RecipientStatus
            _f['recipient_status'] = RecipientStatus.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}acceptLevel')
        if _c is not None:
            from gwsoap.types.AcceptLevel import AcceptLevel
            if _c.text is not None:
                _f['accept_level'] = AcceptLevel(_c.text)
        return _f
