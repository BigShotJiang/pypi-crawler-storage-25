from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Mail import Mail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SharedNotification(Mail):
    notification: NotificationType | None = None
    description: str | None = None
    rights: Rights | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SharedNotification'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'SharedNotification')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.notification is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}notification')
            _c.text = self.notification.value
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.rights is not None:
            self.rights.to_xml(_el, f'{{{_NS}}}rights')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}notification')
        if _c is not None:
            from gwsoap.types.NotificationType import NotificationType
            if _c.text is not None:
                _f['notification'] = NotificationType(_c.text)
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}rights')
        if _c is not None:
            from gwsoap.types.Rights import Rights
            _f['rights'] = Rights.from_xml(_c)
        return _f
