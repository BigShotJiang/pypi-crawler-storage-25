from __future__ import annotations

from enum import Enum


class CalendarViewType(str, Enum):
    DAY = 'day'
    MONTH = 'month'
    MULTIUSER = 'multiUser'
    WEEK = 'week'
    YEAR = 'year'
