from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class CalendarFolderAttribute:
    flags: list[CalendarFolderFlags] = _field(default_factory=list)
    color: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}CalendarFolderAttribute'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.flags:
            _c = ET.SubElement(_el, f'{{{_NS}}}flags')
            _c.text = str(_v)
        if self.color is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}color')
            _c.text = str(self.color)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        from gwsoap.types.CalendarFolderFlags import CalendarFolderFlags
        _f['flags'] = [CalendarFolderFlags(_c.text) for _c in _el.findall(f'{{{_NS}}}flags') if _c.text]
        _c = _el.find(f'{{{_NS}}}color')
        if _c is not None:
            if _c.text is not None:
                _f['color'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> CalendarFolderAttribute:
        return cls(**cls._parse_fields(_el))
