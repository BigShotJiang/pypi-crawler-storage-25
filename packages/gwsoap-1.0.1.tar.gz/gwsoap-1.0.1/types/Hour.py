from __future__ import annotations

Hour = int
