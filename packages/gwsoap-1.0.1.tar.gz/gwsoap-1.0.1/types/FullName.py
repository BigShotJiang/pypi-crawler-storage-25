from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FullName:
    display_name: str | None = None
    name_prefix: str | None = None
    first_name: str | None = None
    middle_name: str | None = None
    last_name: str | None = None
    name_suffix: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FullName'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.display_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}displayName')
            _c.text = self.display_name
        if self.name_prefix is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}namePrefix')
            _c.text = self.name_prefix
        if self.first_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}firstName')
            _c.text = self.first_name
        if self.middle_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}middleName')
            _c.text = self.middle_name
        if self.last_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}lastName')
            _c.text = self.last_name
        if self.name_suffix is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}nameSuffix')
            _c.text = self.name_suffix

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}displayName')
        if _c is not None:
            if _c.text is not None:
                _f['display_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}namePrefix')
        if _c is not None:
            if _c.text is not None:
                _f['name_prefix'] = _c.text
        _c = _el.find(f'{{{_NS}}}firstName')
        if _c is not None:
            if _c.text is not None:
                _f['first_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}middleName')
        if _c is not None:
            if _c.text is not None:
                _f['middle_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}lastName')
        if _c is not None:
            if _c.text is not None:
                _f['last_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}nameSuffix')
        if _c is not None:
            if _c.text is not None:
                _f['name_suffix'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> FullName:
        return cls(**cls._parse_fields(_el))
