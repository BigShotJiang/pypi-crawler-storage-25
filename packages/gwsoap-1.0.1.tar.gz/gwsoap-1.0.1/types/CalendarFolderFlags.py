from __future__ import annotations

from enum import Enum


class CalendarFolderFlags(str, Enum):
    SHOWINLIST = 'ShowInList'
    DONTINCLUDECONTENT = 'DontIncludeContent'
    PUBLISH = 'Publish'
