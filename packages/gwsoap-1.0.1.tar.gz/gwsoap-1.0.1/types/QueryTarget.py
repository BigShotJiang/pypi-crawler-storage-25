from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class QueryTarget:
    source: SourceType | None = None
    info: UserInfo | None = None
    container: list[str] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}QueryTarget'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.source is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}source')
            _c.text = self.source.value
        if self.info is not None:
            self.info.to_xml(_el, f'{{{_NS}}}info')
        for _v in self.container:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = _v

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}source')
        if _c is not None:
            from gwsoap.types.SourceType import SourceType
            if _c.text is not None:
                _f['source'] = SourceType(_c.text)
        _c = _el.find(f'{{{_NS}}}info')
        if _c is not None:
            from gwsoap.types.UserInfo import UserInfo
            _f['info'] = UserInfo.from_xml(_c)
        _f['container'] = [_c.text for _c in _el.findall(f'{{{_NS}}}container') if _c.text is not None]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> QueryTarget:
        return cls(**cls._parse_fields(_el))
