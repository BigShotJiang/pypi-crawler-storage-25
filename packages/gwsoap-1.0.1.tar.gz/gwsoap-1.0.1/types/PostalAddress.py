from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PostalAddress:
    description: str | None = None
    street_address: str | None = None
    location: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    po_box: str | None = None
    type: PostalAddressType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PostalAddress'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.street_address is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}streetAddress')
            _c.text = self.street_address
        if self.location is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}location')
            _c.text = self.location
        if self.city is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}city')
            _c.text = self.city
        if self.state is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}state')
            _c.text = self.state
        if self.postal_code is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}postalCode')
            _c.text = self.postal_code
        if self.country is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}country')
            _c.text = self.country
        if self.po_box is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}poBox')
            _c.text = self.po_box
        if self.type is not None:
            _el.set('type', self.type.value)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}streetAddress')
        if _c is not None:
            if _c.text is not None:
                _f['street_address'] = _c.text
        _c = _el.find(f'{{{_NS}}}location')
        if _c is not None:
            if _c.text is not None:
                _f['location'] = _c.text
        _c = _el.find(f'{{{_NS}}}city')
        if _c is not None:
            if _c.text is not None:
                _f['city'] = _c.text
        _c = _el.find(f'{{{_NS}}}state')
        if _c is not None:
            if _c.text is not None:
                _f['state'] = _c.text
        _c = _el.find(f'{{{_NS}}}postalCode')
        if _c is not None:
            if _c.text is not None:
                _f['postal_code'] = _c.text
        _c = _el.find(f'{{{_NS}}}country')
        if _c is not None:
            if _c.text is not None:
                _f['country'] = _c.text
        _c = _el.find(f'{{{_NS}}}poBox')
        if _c is not None:
            if _c.text is not None:
                _f['po_box'] = _c.text
        _v = _el.get('type')
        if _v is not None:
            from gwsoap.types.PostalAddressType import PostalAddressType
            _f['type'] = PostalAddressType(_v)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> PostalAddress:
        return cls(**cls._parse_fields(_el))
