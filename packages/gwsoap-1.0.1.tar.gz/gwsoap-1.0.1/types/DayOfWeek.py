from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DayOfWeek:
    value: WeekDay | None = None
    occurrence: OccurrenceType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DayOfWeek'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.value is not None:
            _el.text = str(self.value)
        if self.occurrence is not None:
            _el.set('occurrence', self.occurrence.value)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        if _el.text is not None:
            from gwsoap.types.WeekDay import WeekDay
            _f['value'] = _el.text
        _v = _el.get('occurrence')
        if _v is not None:
            from gwsoap.types.OccurrenceType import OccurrenceType
            _f['occurrence'] = OccurrenceType(_v)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> DayOfWeek:
        return cls(**cls._parse_fields(_el))
