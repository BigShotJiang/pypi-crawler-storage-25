from __future__ import annotations

from dataclasses import dataclass
from datetime import date
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class RecurrenceRule:
    frequency: Frequency | None = None
    count: int | None = None
    until: date | None = None
    interval: int | None = None
    by_day: DayOfYearWeekList | None = None
    by_month_day: DayOfMonthList | None = None
    by_year_day: DayOfYearList | None = None
    by_month: MonthList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}RecurrenceRule'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.frequency is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}frequency')
            _c.text = self.frequency.value
        if self.count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}count')
            _c.text = str(self.count)
        if self.until is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}until')
            _c.text = self.until.isoformat()
        if self.interval is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}interval')
            _c.text = str(self.interval)
        if self.by_day is not None:
            self.by_day.to_xml(_el, f'{{{_NS}}}byDay')
        if self.by_month_day is not None:
            self.by_month_day.to_xml(_el, f'{{{_NS}}}byMonthDay')
        if self.by_year_day is not None:
            self.by_year_day.to_xml(_el, f'{{{_NS}}}byYearDay')
        if self.by_month is not None:
            self.by_month.to_xml(_el, f'{{{_NS}}}byMonth')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}frequency')
        if _c is not None:
            from gwsoap.types.Frequency import Frequency
            if _c.text is not None:
                _f['frequency'] = Frequency(_c.text)
        _c = _el.find(f'{{{_NS}}}count')
        if _c is not None:
            if _c.text is not None:
                _f['count'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}until')
        if _c is not None:
            if _c.text is not None:
                _f['until'] = date.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}interval')
        if _c is not None:
            if _c.text is not None:
                _f['interval'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}byDay')
        if _c is not None:
            from gwsoap.types.DayOfYearWeekList import DayOfYearWeekList
            _f['by_day'] = DayOfYearWeekList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}byMonthDay')
        if _c is not None:
            from gwsoap.types.DayOfMonthList import DayOfMonthList
            _f['by_month_day'] = DayOfMonthList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}byYearDay')
        if _c is not None:
            from gwsoap.types.DayOfYearList import DayOfYearList
            _f['by_year_day'] = DayOfYearList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}byMonth')
        if _c is not None:
            from gwsoap.types.MonthList import MonthList
            _f['by_month'] = MonthList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RecurrenceRule:
        return cls(**cls._parse_fields(_el))
