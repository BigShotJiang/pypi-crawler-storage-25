from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PhoneFlags:
    called: bool | None = None
    please_call: bool | None = None
    will_call: bool | None = None
    returned_your_call: bool | None = None
    wants_to_see_you: bool | None = None
    came_to_see_you: bool | None = None
    urgent: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PhoneFlags'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.called is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}called')
            _c.text = ('true' if self.called else 'false')
        if self.please_call is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}pleaseCall')
            _c.text = ('true' if self.please_call else 'false')
        if self.will_call is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}willCall')
            _c.text = ('true' if self.will_call else 'false')
        if self.returned_your_call is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}returnedYourCall')
            _c.text = ('true' if self.returned_your_call else 'false')
        if self.wants_to_see_you is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}wantsToSeeYou')
            _c.text = ('true' if self.wants_to_see_you else 'false')
        if self.came_to_see_you is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}cameToSeeYou')
            _c.text = ('true' if self.came_to_see_you else 'false')
        if self.urgent is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}urgent')
            _c.text = ('true' if self.urgent else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}called')
        if _c is not None:
            if _c.text is not None:
                _f['called'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}pleaseCall')
        if _c is not None:
            if _c.text is not None:
                _f['please_call'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}willCall')
        if _c is not None:
            if _c.text is not None:
                _f['will_call'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}returnedYourCall')
        if _c is not None:
            if _c.text is not None:
                _f['returned_your_call'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}wantsToSeeYou')
        if _c is not None:
            if _c.text is not None:
                _f['wants_to_see_you'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}cameToSeeYou')
        if _c is not None:
            if _c.text is not None:
                _f['came_to_see_you'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}urgent')
        if _c is not None:
            if _c.text is not None:
                _f['urgent'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> PhoneFlags:
        return cls(**cls._parse_fields(_el))
