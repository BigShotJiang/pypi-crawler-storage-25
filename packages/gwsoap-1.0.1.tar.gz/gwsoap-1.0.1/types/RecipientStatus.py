from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class RecipientStatus:
    delivered: datetime | None = None
    undeliverable: datetime | None = None
    transferred: datetime | None = None
    transfer_delayed: datetime | None = None
    transfer_failed: TransferFailedStatus | None = None
    downloaded: datetime | None = None
    downloaded_by_third_party: datetime | None = None
    retract_requested: datetime | None = None
    retracted: datetime | None = None
    opened: datetime | None = None
    deleted: datetime | None = None
    undeleted: datetime | None = None
    purged: datetime | None = None
    accepted: CommentStatus | None = None
    declined: CommentStatus | None = None
    replied: datetime | None = None
    forwarded: datetime | None = None
    shared: datetime | None = None
    started: datetime | None = None
    completed: datetime | None = None
    incomplete: datetime | None = None
    delegated: DelegatedStatus | None = None
    delegatee_status: list[DelegateeStatus] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}RecipientStatus'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.delivered is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}delivered')
            _c.text = self.delivered.isoformat()
        if self.undeliverable is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}undeliverable')
            _c.text = self.undeliverable.isoformat()
        if self.transferred is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}transferred')
            _c.text = self.transferred.isoformat()
        if self.transfer_delayed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}transferDelayed')
            _c.text = self.transfer_delayed.isoformat()
        if self.transfer_failed is not None:
            self.transfer_failed.to_xml(_el, f'{{{_NS}}}transferFailed')
        if self.downloaded is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}downloaded')
            _c.text = self.downloaded.isoformat()
        if self.downloaded_by_third_party is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}downloadedByThirdParty')
            _c.text = self.downloaded_by_third_party.isoformat()
        if self.retract_requested is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retractRequested')
            _c.text = self.retract_requested.isoformat()
        if self.retracted is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}retracted')
            _c.text = self.retracted.isoformat()
        if self.opened is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}opened')
            _c.text = self.opened.isoformat()
        if self.deleted is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}deleted')
            _c.text = self.deleted.isoformat()
        if self.undeleted is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}undeleted')
            _c.text = self.undeleted.isoformat()
        if self.purged is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}purged')
            _c.text = self.purged.isoformat()
        if self.accepted is not None:
            self.accepted.to_xml(_el, f'{{{_NS}}}accepted')
        if self.declined is not None:
            self.declined.to_xml(_el, f'{{{_NS}}}declined')
        if self.replied is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}replied')
            _c.text = self.replied.isoformat()
        if self.forwarded is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}forwarded')
            _c.text = self.forwarded.isoformat()
        if self.shared is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}shared')
            _c.text = self.shared.isoformat()
        if self.started is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}started')
            _c.text = self.started.isoformat()
        if self.completed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}completed')
            _c.text = self.completed.isoformat()
        if self.incomplete is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}incomplete')
            _c.text = self.incomplete.isoformat()
        if self.delegated is not None:
            self.delegated.to_xml(_el, f'{{{_NS}}}delegated')
        for _v in self.delegatee_status:
            _v.to_xml(_el, f'{{{_NS}}}delegateeStatus')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}delivered')
        if _c is not None:
            if _c.text is not None:
                _f['delivered'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}undeliverable')
        if _c is not None:
            if _c.text is not None:
                _f['undeliverable'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}transferred')
        if _c is not None:
            if _c.text is not None:
                _f['transferred'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}transferDelayed')
        if _c is not None:
            if _c.text is not None:
                _f['transfer_delayed'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}transferFailed')
        if _c is not None:
            from gwsoap.types.TransferFailedStatus import TransferFailedStatus
            _f['transfer_failed'] = TransferFailedStatus.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}downloaded')
        if _c is not None:
            if _c.text is not None:
                _f['downloaded'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}downloadedByThirdParty')
        if _c is not None:
            if _c.text is not None:
                _f['downloaded_by_third_party'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}retractRequested')
        if _c is not None:
            if _c.text is not None:
                _f['retract_requested'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}retracted')
        if _c is not None:
            if _c.text is not None:
                _f['retracted'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}opened')
        if _c is not None:
            if _c.text is not None:
                _f['opened'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}deleted')
        if _c is not None:
            if _c.text is not None:
                _f['deleted'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}undeleted')
        if _c is not None:
            if _c.text is not None:
                _f['undeleted'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}purged')
        if _c is not None:
            if _c.text is not None:
                _f['purged'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}accepted')
        if _c is not None:
            from gwsoap.types.CommentStatus import CommentStatus
            _f['accepted'] = CommentStatus.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}declined')
        if _c is not None:
            from gwsoap.types.CommentStatus import CommentStatus
            _f['declined'] = CommentStatus.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}replied')
        if _c is not None:
            if _c.text is not None:
                _f['replied'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}forwarded')
        if _c is not None:
            if _c.text is not None:
                _f['forwarded'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}shared')
        if _c is not None:
            if _c.text is not None:
                _f['shared'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}started')
        if _c is not None:
            if _c.text is not None:
                _f['started'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}completed')
        if _c is not None:
            if _c.text is not None:
                _f['completed'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}incomplete')
        if _c is not None:
            if _c.text is not None:
                _f['incomplete'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}delegated')
        if _c is not None:
            from gwsoap.types.DelegatedStatus import DelegatedStatus
            _f['delegated'] = DelegatedStatus.from_xml(_c)
        from gwsoap.types.DelegateeStatus import DelegateeStatus
        _f['delegatee_status'] = [DelegateeStatus.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}delegateeStatus')]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RecipientStatus:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'DelegateeStatus':
            from gwsoap.types.DelegateeStatus import DelegateeStatus
            return DelegateeStatus(**DelegateeStatus._parse_fields(_el))
        if _t == 'TransferFailedStatus':
            from gwsoap.types.TransferFailedStatus import TransferFailedStatus
            return TransferFailedStatus(**TransferFailedStatus._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
