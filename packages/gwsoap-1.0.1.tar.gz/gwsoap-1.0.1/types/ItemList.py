from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ItemList:
    item: list[Item] = _field(default_factory=list)
    offset: int | None = None
    count: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ItemList'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.item:
            _v.to_xml(_el, f'{{{_NS}}}item')
        if self.offset is not None:
            _el.set('offset', str(self.offset))
        if self.count is not None:
            _el.set('count', str(self.count))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        from gwsoap.types.Item import Item
        _f['item'] = [Item.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}item')]
        _v = _el.get('offset')
        if _v is not None:
            _f['offset'] = int(_v)
        _v = _el.get('count')
        if _v is not None:
            _f['count'] = int(_v)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ItemList:
        return cls(**cls._parse_fields(_el))
