from __future__ import annotations

from enum import Enum


class PostalAddressType(str, Enum):
    HOME = 'Home'
    OFFICE = 'Office'
    OTHER = 'Other'
