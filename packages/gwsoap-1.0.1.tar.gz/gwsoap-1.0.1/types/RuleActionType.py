from __future__ import annotations

from enum import Enum


class RuleActionType(str, Enum):
    ACCEPT = 'Accept'
    ARCHIVE = 'Archive'
    CATEGORY = 'Category'
    DELEGATE = 'Delegate'
    DELETE = 'Delete'
    FORWARD = 'Forward'
    LINK = 'Link'
    MARKPRIVATE = 'MarkPrivate'
    MARKREAD = 'MarkRead'
    MARKUNREAD = 'MarkUnread'
    MOVE = 'Move'
    PURGE = 'Purge'
    REPLY = 'Reply'
    REPLYWITHTEXT = 'ReplyWithText'
    SEND = 'Send'
    STOPRULES = 'StopRules'
    UNKNOWN = 'Unknown'
