from __future__ import annotations

UUID = str
