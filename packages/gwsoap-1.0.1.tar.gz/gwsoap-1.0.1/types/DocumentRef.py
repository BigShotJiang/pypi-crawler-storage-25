from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Mail import Mail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DocumentRef(Mail):
    library: NameAndEmail | None = None
    document_number: int | None = None
    filename: str | None = None
    document_type_name: str | None = None
    author: NameAndEmail | None = None
    creator: NameAndEmail | None = None
    version_creator: NameAndEmail | None = None
    official_version: int | None = None
    current_version: int | None = None
    version_number: int | None = None
    version_description: str | None = None
    file_size: int | None = None
    acl: AccessControlList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DocumentRef'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'DocumentRef')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.library is not None:
            self.library.to_xml(_el, f'{{{_NS}}}library')
        if self.document_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}documentNumber')
            _c.text = str(self.document_number)
        if self.filename is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}filename')
            _c.text = self.filename
        if self.document_type_name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}documentTypeName')
            _c.text = self.document_type_name
        if self.author is not None:
            self.author.to_xml(_el, f'{{{_NS}}}author')
        if self.creator is not None:
            self.creator.to_xml(_el, f'{{{_NS}}}creator')
        if self.version_creator is not None:
            self.version_creator.to_xml(_el, f'{{{_NS}}}versionCreator')
        if self.official_version is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}officialVersion')
            _c.text = str(self.official_version)
        if self.current_version is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}currentVersion')
            _c.text = str(self.current_version)
        if self.version_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionNumber')
            _c.text = str(self.version_number)
        if self.version_description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionDescription')
            _c.text = self.version_description
        if self.file_size is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}fileSize')
            _c.text = str(self.file_size)
        if self.acl is not None:
            self.acl.to_xml(_el, f'{{{_NS}}}acl')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}library')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['library'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}documentNumber')
        if _c is not None:
            if _c.text is not None:
                _f['document_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}filename')
        if _c is not None:
            if _c.text is not None:
                _f['filename'] = _c.text
        _c = _el.find(f'{{{_NS}}}documentTypeName')
        if _c is not None:
            if _c.text is not None:
                _f['document_type_name'] = _c.text
        _c = _el.find(f'{{{_NS}}}author')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['author'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}creator')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['creator'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}versionCreator')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['version_creator'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}officialVersion')
        if _c is not None:
            if _c.text is not None:
                _f['official_version'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}currentVersion')
        if _c is not None:
            if _c.text is not None:
                _f['current_version'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}versionNumber')
        if _c is not None:
            if _c.text is not None:
                _f['version_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}versionDescription')
        if _c is not None:
            if _c.text is not None:
                _f['version_description'] = _c.text
        _c = _el.find(f'{{{_NS}}}fileSize')
        if _c is not None:
            if _c.text is not None:
                _f['file_size'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}acl')
        if _c is not None:
            from gwsoap.types.AccessControlList import AccessControlList
            _f['acl'] = AccessControlList.from_xml(_c)
        return _f
