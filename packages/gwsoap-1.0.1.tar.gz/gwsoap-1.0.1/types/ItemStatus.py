from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ItemStatus:
    accepted: bool | None = None
    completed: bool | None = None
    delegated: bool | None = None
    deleted: bool | None = None
    forwarded: bool | None = None
    private_value: bool | None = None
    opened: bool | None = None
    read: bool | None = None
    replied: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ItemStatus'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.accepted is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}accepted')
            _c.text = ('true' if self.accepted else 'false')
        if self.completed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}completed')
            _c.text = ('true' if self.completed else 'false')
        if self.delegated is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}delegated')
            _c.text = ('true' if self.delegated else 'false')
        if self.deleted is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}deleted')
            _c.text = ('true' if self.deleted else 'false')
        if self.forwarded is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}forwarded')
            _c.text = ('true' if self.forwarded else 'false')
        if self.private_value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}private')
            _c.text = ('true' if self.private_value else 'false')
        if self.opened is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}opened')
            _c.text = ('true' if self.opened else 'false')
        if self.read is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}read')
            _c.text = ('true' if self.read else 'false')
        if self.replied is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}replied')
            _c.text = ('true' if self.replied else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}accepted')
        if _c is not None:
            if _c.text is not None:
                _f['accepted'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}completed')
        if _c is not None:
            if _c.text is not None:
                _f['completed'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}delegated')
        if _c is not None:
            if _c.text is not None:
                _f['delegated'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}deleted')
        if _c is not None:
            if _c.text is not None:
                _f['deleted'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}forwarded')
        if _c is not None:
            if _c.text is not None:
                _f['forwarded'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}private')
        if _c is not None:
            if _c.text is not None:
                _f['private_value'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}opened')
        if _c is not None:
            if _c.text is not None:
                _f['opened'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}read')
        if _c is not None:
            if _c.text is not None:
                _f['read'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}replied')
        if _c is not None:
            if _c.text is not None:
                _f['replied'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ItemStatus:
        return cls(**cls._parse_fields(_el))
