from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class MonthList:
    month: list[int] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}MonthList'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.month:
            _c = ET.SubElement(_el, f'{{{_NS}}}month')
            _c.text = str(_v)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _f['month'] = [int(_c.text) for _c in _el.findall(f'{{{_NS}}}month') if _c.text is not None]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> MonthList:
        return cls(**cls._parse_fields(_el))
