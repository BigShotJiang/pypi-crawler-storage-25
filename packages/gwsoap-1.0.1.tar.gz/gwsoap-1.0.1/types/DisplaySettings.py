from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DisplaySettings(Item):
    folder_type: DisplayFolderType | None = None
    setting_type: DisplaySettingsType | None = None
    flags: DisplayFlags | None = None
    types: str | None = None
    source: str | None = None
    view: ViewType | None = None
    columns: list[ColumnSettings] = _field(default_factory=list)
    filter_days_forward: int | None = None
    filter_days_backward: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DisplaySettings'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'DisplaySettings')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.folder_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}folderType')
            _c.text = self.folder_type.value
        if self.setting_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}settingType')
            _c.text = self.setting_type.value
        if self.flags is not None:
            self.flags.to_xml(_el, f'{{{_NS}}}flags')
        if self.types is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}types')
            _c.text = self.types
        if self.source is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}source')
            _c.text = self.source
        if self.view is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}view')
            _c.text = self.view.value
        for _v in self.columns:
            _v.to_xml(_el, f'{{{_NS}}}columns')
        if self.filter_days_forward is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}filterDaysForward')
            _c.text = str(self.filter_days_forward)
        if self.filter_days_backward is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}filterDaysBackward')
            _c.text = str(self.filter_days_backward)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}folderType')
        if _c is not None:
            from gwsoap.types.DisplayFolderType import DisplayFolderType
            if _c.text is not None:
                _f['folder_type'] = DisplayFolderType(_c.text)
        _c = _el.find(f'{{{_NS}}}settingType')
        if _c is not None:
            from gwsoap.types.DisplaySettingsType import DisplaySettingsType
            if _c.text is not None:
                _f['setting_type'] = DisplaySettingsType(_c.text)
        _c = _el.find(f'{{{_NS}}}flags')
        if _c is not None:
            from gwsoap.types.DisplayFlags import DisplayFlags
            _f['flags'] = DisplayFlags.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}types')
        if _c is not None:
            if _c.text is not None:
                _f['types'] = _c.text
        _c = _el.find(f'{{{_NS}}}source')
        if _c is not None:
            if _c.text is not None:
                _f['source'] = _c.text
        _c = _el.find(f'{{{_NS}}}view')
        if _c is not None:
            from gwsoap.types.ViewType import ViewType
            if _c.text is not None:
                _f['view'] = ViewType(_c.text)
        from gwsoap.types.ColumnSettings import ColumnSettings
        _f['columns'] = [ColumnSettings.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}columns')]
        _c = _el.find(f'{{{_NS}}}filterDaysForward')
        if _c is not None:
            if _c.text is not None:
                _f['filter_days_forward'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}filterDaysBackward')
        if _c is not None:
            if _c.text is not None:
                _f['filter_days_backward'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> DisplaySettings:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'FolderDisplaySettings':
            from gwsoap.types.FolderDisplaySettings import FolderDisplaySettings
            return FolderDisplaySettings(**FolderDisplaySettings._parse_fields(_el))
        if _t == 'PanelDisplaySettings':
            from gwsoap.types.PanelDisplaySettings import PanelDisplaySettings
            return PanelDisplaySettings(**PanelDisplaySettings._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
