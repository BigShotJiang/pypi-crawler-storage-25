from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DiskSpaceUsage:
    max_size: int | None = None
    threshold: int | None = None
    used: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DiskSpaceUsage'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.max_size is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}maxSize')
            _c.text = str(self.max_size)
        if self.threshold is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}threshold')
            _c.text = str(self.threshold)
        if self.used is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}used')
            _c.text = str(self.used)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}maxSize')
        if _c is not None:
            if _c.text is not None:
                _f['max_size'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}threshold')
        if _c is not None:
            if _c.text is not None:
                _f['threshold'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}used')
        if _c is not None:
            if _c.text is not None:
                _f['used'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> DiskSpaceUsage:
        return cls(**cls._parse_fields(_el))
