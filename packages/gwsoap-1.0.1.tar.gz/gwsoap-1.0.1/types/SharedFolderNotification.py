from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SharedFolderNotification:
    subject: str | None = None
    message: str | None = None
    description: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SharedFolderNotification'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.subject is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}subject')
            _c.text = self.subject
        if self.message is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}message')
            _c.text = self.message
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}subject')
        if _c is not None:
            if _c.text is not None:
                _f['subject'] = _c.text
        _c = _el.find(f'{{{_NS}}}message')
        if _c is not None:
            if _c.text is not None:
                _f['message'] = _c.text
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SharedFolderNotification:
        return cls(**cls._parse_fields(_el))
