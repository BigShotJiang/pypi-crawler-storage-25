from __future__ import annotations

from enum import Enum


class NotificationType(str, Enum):
    SHAREDADDRESSBOOK = 'SharedAddressBook'
    SHAREDFOLDER = 'SharedFolder'
