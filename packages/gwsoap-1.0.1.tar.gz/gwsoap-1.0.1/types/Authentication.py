from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Authentication:
    username: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Authentication'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.username is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}username')
            _c.text = self.username

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}username')
        if _c is not None:
            if _c.text is not None:
                _f['username'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Authentication:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'PlainText':
            from gwsoap.types.PlainText import PlainText
            return PlainText(**PlainText._parse_fields(_el))
        if _t == 'Proxy':
            from gwsoap.types.Proxy import Proxy
            return Proxy(**Proxy._parse_fields(_el))
        if _t == 'TrustedApplication':
            from gwsoap.types.TrustedApplication import TrustedApplication
            return TrustedApplication(**TrustedApplication._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
