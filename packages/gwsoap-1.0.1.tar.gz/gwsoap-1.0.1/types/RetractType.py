from __future__ import annotations

from enum import Enum


class RetractType(str, Enum):
    MYMAILBOX = 'myMailbox'
    RECIPIENTMAILBOXES = 'recipientMailboxes'
    ALLMAILBOXES = 'allMailboxes'
