from __future__ import annotations

from enum import Enum


class StatusTrackingOptions(str, Enum):
    NONE = 'None'
    DELIVERED = 'Delivered'
    DELIVEREDANDOPENED = 'DeliveredAndOpened'
    ALL = 'All'
