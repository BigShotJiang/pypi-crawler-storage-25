from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.NameAndEmail import NameAndEmail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class From(NameAndEmail):
    reply_to: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}From'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'From')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.reply_to is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}replyTo')
            _c.text = self.reply_to

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}replyTo')
        if _c is not None:
            if _c.text is not None:
                _f['reply_to'] = _c.text
        return _f
