from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.AddressBookItem import AddressBookItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Resource(AddressBookItem):
    phone: str | None = None
    resource_type: str | None = None
    email: str | None = None
    owner: ItemRef | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Resource'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Resource')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.phone is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}phone')
            _c.text = self.phone
        if self.resource_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}resourceType')
            _c.text = self.resource_type
        if self.email is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}email')
            _c.text = self.email
        if self.owner is not None:
            self.owner.to_xml(_el, f'{{{_NS}}}owner')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}phone')
        if _c is not None:
            if _c.text is not None:
                _f['phone'] = _c.text
        _c = _el.find(f'{{{_NS}}}resourceType')
        if _c is not None:
            if _c.text is not None:
                _f['resource_type'] = _c.text
        _c = _el.find(f'{{{_NS}}}email')
        if _c is not None:
            if _c.text is not None:
                _f['email'] = _c.text
        _c = _el.find(f'{{{_NS}}}owner')
        if _c is not None:
            from gwsoap.types.ItemRef import ItemRef
            _f['owner'] = ItemRef.from_xml(_c)
        return _f
