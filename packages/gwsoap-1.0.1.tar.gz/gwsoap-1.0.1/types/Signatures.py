from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Signatures:
    signature: list[Signature] = _field(default_factory=list)
    setting: SignatureSettings | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Signatures'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.signature:
            _v.to_xml(_el, f'{{{_NS}}}signature')
        if self.setting is not None:
            self.setting.to_xml(_el, f'{{{_NS}}}setting')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        from gwsoap.types.Signature import Signature
        _f['signature'] = [Signature.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}signature')]
        _c = _el.find(f'{{{_NS}}}setting')
        if _c is not None:
            from gwsoap.types.SignatureSettings import SignatureSettings
            _f['setting'] = SignatureSettings.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Signatures:
        return cls(**cls._parse_fields(_el))
