from __future__ import annotations

from enum import Enum


class DisplayFolderType(str, Enum):
    CALENDAR = 'Calendar'
    CHECKLIST = 'Checklist'
    CONTACTS = 'Contacts'
    CONTACTSPERSONAL = 'ContactsPersonal'
    CONTACTSOFFICE = 'ContactsOffice'
    CONTACTSUSERDEFINED = 'ContactsUserDefined'
    DISCUSSIONTHREAD = 'DiscussionThread'
    DISCUSSIONTHREADLIST = 'DiscussionThreadList'
    DOCUMENTS = 'Documents'
    DRAFT = 'Draft'
    MAILBOX = 'Mailbox'
    NNTPSERVER = 'NNTPServer'
    NORMAL = 'Normal'
    PANELCALENDAR = 'PanelCalendar'
    PANELCHECKLIST = 'PanelChecklist'
    PANELRECENTACTIVITY = 'PanelRecentActivity'
    PANELSUMMARYCALENDAR = 'PanelSummaryCalendar'
    PANELUNREADITEMS = 'PanelUnreadItems'
    QUERY = 'Query'
    QUERYRESULTS = 'QueryResults'
    SENTITEMS = 'SentItems'
    TASKLIST = 'TaskList'
    TOOLBAR = 'Toolbar'
    TRASH = 'Trash'
    UNKNOWN = 'Unknown'
    USERDEFINED = 'UserDefined'
    VERSIONLIST = 'VersionList'
