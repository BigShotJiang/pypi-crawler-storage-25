from __future__ import annotations

from enum import Enum


class CustomType(str, Enum):
    STRING = 'String'
    NUMERIC = 'Numeric'
    DATE = 'Date'
    BINARY = 'Binary'
