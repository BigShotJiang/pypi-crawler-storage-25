from __future__ import annotations

from enum import Enum


class JunkHandlingListType(str, Enum):
    JUNK = 'junk'
    BLOCK = 'block'
    TRUST = 'trust'
