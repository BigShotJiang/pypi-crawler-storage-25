from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.AddressBook import AddressBook
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SharedBook(AddressBook):
    rights: Rights | None = None
    acl: AccessControlList | None = None
    owner: str | None = None
    is_shared_by_me: bool | None = None
    is_shared_to_me: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SharedBook'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'SharedBook')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.rights is not None:
            self.rights.to_xml(_el, f'{{{_NS}}}rights')
        if self.acl is not None:
            self.acl.to_xml(_el, f'{{{_NS}}}acl')
        if self.owner is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}owner')
            _c.text = self.owner
        if self.is_shared_by_me is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isSharedByMe')
            _c.text = ('true' if self.is_shared_by_me else 'false')
        if self.is_shared_to_me is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isSharedToMe')
            _c.text = ('true' if self.is_shared_to_me else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}rights')
        if _c is not None:
            from gwsoap.types.Rights import Rights
            _f['rights'] = Rights.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}acl')
        if _c is not None:
            from gwsoap.types.AccessControlList import AccessControlList
            _f['acl'] = AccessControlList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}owner')
        if _c is not None:
            if _c.text is not None:
                _f['owner'] = _c.text
        _c = _el.find(f'{{{_NS}}}isSharedByMe')
        if _c is not None:
            if _c.text is not None:
                _f['is_shared_by_me'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}isSharedToMe')
        if _c is not None:
            if _c.text is not None:
                _f['is_shared_to_me'] = ((_c.text) or '').lower() in ('true', '1')
        return _f
