from __future__ import annotations

from enum import Enum


class OccurrenceType(str, Enum):
    FIRST = 'First'
    SECOND = 'Second'
    THIRD = 'Third'
    FOURTH = 'Fourth'
    FIFTH = 'Fifth'
    LAST = 'Last'
