from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class OfficeInfo:
    organization: ItemRef | None = None
    department: str | None = None
    title: str | None = None
    website: str | None = None
    profession: str | None = None
    location: str | None = None
    manager: str | None = None
    assistant: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}OfficeInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.organization is not None:
            self.organization.to_xml(_el, f'{{{_NS}}}organization')
        if self.department is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}department')
            _c.text = self.department
        if self.title is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}title')
            _c.text = self.title
        if self.website is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}website')
            _c.text = self.website
        if self.profession is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}profession')
            _c.text = self.profession
        if self.location is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}location')
            _c.text = self.location
        if self.manager is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}manager')
            _c.text = self.manager
        if self.assistant is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}assistant')
            _c.text = self.assistant

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}organization')
        if _c is not None:
            from gwsoap.types.ItemRef import ItemRef
            _f['organization'] = ItemRef.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}department')
        if _c is not None:
            if _c.text is not None:
                _f['department'] = _c.text
        _c = _el.find(f'{{{_NS}}}title')
        if _c is not None:
            if _c.text is not None:
                _f['title'] = _c.text
        _c = _el.find(f'{{{_NS}}}website')
        if _c is not None:
            if _c.text is not None:
                _f['website'] = _c.text
        _c = _el.find(f'{{{_NS}}}profession')
        if _c is not None:
            if _c.text is not None:
                _f['profession'] = _c.text
        _c = _el.find(f'{{{_NS}}}location')
        if _c is not None:
            if _c.text is not None:
                _f['location'] = _c.text
        _c = _el.find(f'{{{_NS}}}manager')
        if _c is not None:
            if _c.text is not None:
                _f['manager'] = _c.text
        _c = _el.find(f'{{{_NS}}}assistant')
        if _c is not None:
            if _c.text is not None:
                _f['assistant'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> OfficeInfo:
        return cls(**cls._parse_fields(_el))
