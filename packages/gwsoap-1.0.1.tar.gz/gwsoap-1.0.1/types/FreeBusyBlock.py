from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FreeBusyBlock:
    start_date: datetime | None = None
    end_date: datetime | None = None
    accept_level: AcceptLevel | None = None
    subject: str | None = None
    place: str | None = None
    from_value: From | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FreeBusyBlock'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.start_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}startDate')
            _c.text = self.start_date.isoformat()
        if self.end_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}endDate')
            _c.text = self.end_date.isoformat()
        if self.accept_level is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}acceptLevel')
            _c.text = self.accept_level.value
        if self.subject is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}subject')
            _c.text = self.subject
        if self.place is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}place')
            _c.text = self.place
        if self.from_value is not None:
            self.from_value.to_xml(_el, f'{{{_NS}}}from')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}startDate')
        if _c is not None:
            if _c.text is not None:
                _f['start_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}endDate')
        if _c is not None:
            if _c.text is not None:
                _f['end_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}acceptLevel')
        if _c is not None:
            from gwsoap.types.AcceptLevel import AcceptLevel
            if _c.text is not None:
                _f['accept_level'] = AcceptLevel(_c.text)
        _c = _el.find(f'{{{_NS}}}subject')
        if _c is not None:
            if _c.text is not None:
                _f['subject'] = _c.text
        _c = _el.find(f'{{{_NS}}}place')
        if _c is not None:
            if _c.text is not None:
                _f['place'] = _c.text
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            from gwsoap.types.From import From
            _f['from_value'] = From.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> FreeBusyBlock:
        return cls(**cls._parse_fields(_el))
