from __future__ import annotations

from enum import Enum


class FilterOp(str, Enum):
    AND = 'and'
    OR = 'or'
    NOT = 'not'
    EQ = 'eq'
    NE = 'ne'
    GT = 'gt'
    LT = 'lt'
    GTE = 'gte'
    LTE = 'lte'
    CONTAINS = 'contains'
    CONTAINSWORD = 'containsWord'
    BEGINS = 'begins'
    EXISTS = 'exists'
    NOTEXIST = 'notExist'
    ISOF = 'isOf'
    ISNOTOF = 'isNotOf'
    FIELDEQUAL = 'fieldEqual'
    FIELDGTE = 'fieldGTE'
    FIELDGT = 'fieldGT'
    FIELDLTE = 'fieldLTE'
    FIELDLT = 'fieldLT'
    FIELDNE = 'fieldNE'
    FIELDDATEEQUAL = 'fieldDateEqual'
    BITCARE = 'bitCare'
    NOTCONTAINS = 'notContains'
