from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Settings:
    group: list[SettingsGroup] = _field(default_factory=list)
    setting: list[Custom] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Settings'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.group:
            _v.to_xml(_el, f'{{{_NS}}}group')
        for _v in self.setting:
            _v.to_xml(_el, f'{{{_NS}}}setting')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        from gwsoap.types.SettingsGroup import SettingsGroup
        _f['group'] = [SettingsGroup.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}group')]
        from gwsoap.types.Custom import Custom
        _f['setting'] = [Custom.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}setting')]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Settings:
        return cls(**cls._parse_fields(_el))
