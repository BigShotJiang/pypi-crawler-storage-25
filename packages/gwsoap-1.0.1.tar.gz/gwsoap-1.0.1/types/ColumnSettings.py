from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ColumnSettings:
    type: ColumnType | None = None
    sort: Sort | None = None
    headers: list[Header] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ColumnSettings'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type.value
        if self.sort is not None:
            self.sort.to_xml(_el, f'{{{_NS}}}sort')
        for _v in self.headers:
            _v.to_xml(_el, f'{{{_NS}}}headers')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.types.ColumnType import ColumnType
            if _c.text is not None:
                _f['type'] = ColumnType(_c.text)
        _c = _el.find(f'{{{_NS}}}sort')
        if _c is not None:
            from gwsoap.types.Sort import Sort
            _f['sort'] = Sort.from_xml(_c)
        from gwsoap.types.Header import Header
        _f['headers'] = [Header.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}headers')]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ColumnSettings:
        return cls(**cls._parse_fields(_el))
