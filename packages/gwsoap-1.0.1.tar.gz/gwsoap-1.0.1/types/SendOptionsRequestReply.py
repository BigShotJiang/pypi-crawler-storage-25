from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SendOptionsRequestReply:
    when_convenient: bool | None = None
    by_date: datetime | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SendOptionsRequestReply'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.when_convenient is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}whenConvenient')
            _c.text = ('true' if self.when_convenient else 'false')
        if self.by_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}byDate')
            _c.text = self.by_date.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}whenConvenient')
        if _c is not None:
            if _c.text is not None:
                _f['when_convenient'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}byDate')
        if _c is not None:
            if _c.text is not None:
                _f['by_date'] = datetime.fromisoformat(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SendOptionsRequestReply:
        return cls(**cls._parse_fields(_el))
