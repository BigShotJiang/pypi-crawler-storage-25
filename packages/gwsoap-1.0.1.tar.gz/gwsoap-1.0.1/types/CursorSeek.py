from __future__ import annotations

from enum import Enum


class CursorSeek(str, Enum):
    CURRENT = 'current'
    START = 'start'
    END = 'end'
