from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.AddressBookItem import AddressBookItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Contact(AddressBookItem):
    full_name: FullName | None = None
    email_list: EmailAddressList | None = None
    im_list: ImAddressList | None = None
    phone_list: PhoneList | None = None
    address_list: PostalAddressList | None = None
    office_info: OfficeInfo | None = None
    personal_info: PersonalInfo | None = None
    reference_info: ReferenceInfo | None = None
    advanced_info: AdvancedInfo | None = None
    contact_notes: ContactNotes | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Contact'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Contact')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.full_name is not None:
            self.full_name.to_xml(_el, f'{{{_NS}}}fullName')
        if self.email_list is not None:
            self.email_list.to_xml(_el, f'{{{_NS}}}emailList')
        if self.im_list is not None:
            self.im_list.to_xml(_el, f'{{{_NS}}}imList')
        if self.phone_list is not None:
            self.phone_list.to_xml(_el, f'{{{_NS}}}phoneList')
        if self.address_list is not None:
            self.address_list.to_xml(_el, f'{{{_NS}}}addressList')
        if self.office_info is not None:
            self.office_info.to_xml(_el, f'{{{_NS}}}officeInfo')
        if self.personal_info is not None:
            self.personal_info.to_xml(_el, f'{{{_NS}}}personalInfo')
        if self.reference_info is not None:
            self.reference_info.to_xml(_el, f'{{{_NS}}}referenceInfo')
        if self.advanced_info is not None:
            self.advanced_info.to_xml(_el, f'{{{_NS}}}advancedInfo')
        if self.contact_notes is not None:
            self.contact_notes.to_xml(_el, f'{{{_NS}}}contactNotes')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}fullName')
        if _c is not None:
            from gwsoap.types.FullName import FullName
            _f['full_name'] = FullName.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}emailList')
        if _c is not None:
            from gwsoap.types.EmailAddressList import EmailAddressList
            _f['email_list'] = EmailAddressList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}imList')
        if _c is not None:
            from gwsoap.types.ImAddressList import ImAddressList
            _f['im_list'] = ImAddressList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}phoneList')
        if _c is not None:
            from gwsoap.types.PhoneList import PhoneList
            _f['phone_list'] = PhoneList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}addressList')
        if _c is not None:
            from gwsoap.types.PostalAddressList import PostalAddressList
            _f['address_list'] = PostalAddressList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}officeInfo')
        if _c is not None:
            from gwsoap.types.OfficeInfo import OfficeInfo
            _f['office_info'] = OfficeInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}personalInfo')
        if _c is not None:
            from gwsoap.types.PersonalInfo import PersonalInfo
            _f['personal_info'] = PersonalInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}referenceInfo')
        if _c is not None:
            from gwsoap.types.ReferenceInfo import ReferenceInfo
            _f['reference_info'] = ReferenceInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}advancedInfo')
        if _c is not None:
            from gwsoap.types.AdvancedInfo import AdvancedInfo
            _f['advanced_info'] = AdvancedInfo.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}contactNotes')
        if _c is not None:
            from gwsoap.types.ContactNotes import ContactNotes
            _f['contact_notes'] = ContactNotes.from_xml(_c)
        return _f
