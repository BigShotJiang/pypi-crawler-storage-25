from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.NameAndEmail import NameAndEmail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AccessRightEntry(NameAndEmail):
    id: str | None = None
    appointment: AccessRight | None = None
    mail: AccessRight | None = None
    misc: AccessMiscRight | None = None
    note: AccessRight | None = None
    task: AccessRight | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AccessRightEntry'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'AccessRightEntry')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.appointment is not None:
            self.appointment.to_xml(_el, f'{{{_NS}}}appointment')
        if self.mail is not None:
            self.mail.to_xml(_el, f'{{{_NS}}}mail')
        if self.misc is not None:
            self.misc.to_xml(_el, f'{{{_NS}}}misc')
        if self.note is not None:
            self.note.to_xml(_el, f'{{{_NS}}}note')
        if self.task is not None:
            self.task.to_xml(_el, f'{{{_NS}}}task')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}appointment')
        if _c is not None:
            from gwsoap.types.AccessRight import AccessRight
            _f['appointment'] = AccessRight.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}mail')
        if _c is not None:
            from gwsoap.types.AccessRight import AccessRight
            _f['mail'] = AccessRight.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}misc')
        if _c is not None:
            from gwsoap.types.AccessMiscRight import AccessMiscRight
            _f['misc'] = AccessMiscRight.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}note')
        if _c is not None:
            from gwsoap.types.AccessRight import AccessRight
            _f['note'] = AccessRight.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}task')
        if _c is not None:
            from gwsoap.types.AccessRight import AccessRight
            _f['task'] = AccessRight.from_xml(_c)
        return _f
