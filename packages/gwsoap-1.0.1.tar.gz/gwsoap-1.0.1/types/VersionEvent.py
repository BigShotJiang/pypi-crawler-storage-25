from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.ContainerItem import ContainerItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class VersionEvent(ContainerItem):
    library: NameAndEmail | None = None
    document_number: int | None = None
    version_number: int | None = None
    creator: NameAndEmail | None = None
    event: VersionEventType | None = None
    event_number: int | None = None
    filename: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}VersionEvent'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'VersionEvent')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.library is not None:
            self.library.to_xml(_el, f'{{{_NS}}}library')
        if self.document_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}documentNumber')
            _c.text = str(self.document_number)
        if self.version_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}versionNumber')
            _c.text = str(self.version_number)
        if self.creator is not None:
            self.creator.to_xml(_el, f'{{{_NS}}}creator')
        if self.event is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}event')
            _c.text = self.event.value
        if self.event_number is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}eventNumber')
            _c.text = str(self.event_number)
        if self.filename is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}filename')
            _c.text = self.filename

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}library')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['library'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}documentNumber')
        if _c is not None:
            if _c.text is not None:
                _f['document_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}versionNumber')
        if _c is not None:
            if _c.text is not None:
                _f['version_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}creator')
        if _c is not None:
            from gwsoap.types.NameAndEmail import NameAndEmail
            _f['creator'] = NameAndEmail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}event')
        if _c is not None:
            from gwsoap.types.VersionEventType import VersionEventType
            if _c.text is not None:
                _f['event'] = VersionEventType(_c.text)
        _c = _el.find(f'{{{_NS}}}eventNumber')
        if _c is not None:
            if _c.text is not None:
                _f['event_number'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}filename')
        if _c is not None:
            if _c.text is not None:
                _f['filename'] = _c.text
        return _f
