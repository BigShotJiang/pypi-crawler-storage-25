from __future__ import annotations

from enum import Enum


class SortType(str, Enum):
    ASCENDING = 'Ascending'
    DESCENDING = 'Descending'
