from __future__ import annotations

from enum import Enum


class TextCase(str, Enum):
    LOWER = 'Lower'
    MIXED = 'Mixed'
    UPPER = 'Upper'
