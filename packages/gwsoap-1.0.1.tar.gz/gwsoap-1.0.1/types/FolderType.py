from __future__ import annotations

from enum import Enum


class FolderType(str, Enum):
    MAILBOX = 'Mailbox'
    SENTITEMS = 'SentItems'
    DRAFT = 'Draft'
    TRASH = 'Trash'
    CALENDAR = 'Calendar'
    CONTACTS = 'Contacts'
    DOCUMENTS = 'Documents'
    CHECKLIST = 'Checklist'
    CABINET = 'Cabinet'
    NORMAL = 'Normal'
    NNTPSERVER = 'NNTPServer'
    NNTPNEWSGROUP = 'NNTPNewsGroup'
    IMAP = 'IMAP'
    QUERY = 'Query'
    ROOT = 'Root'
    JUNKMAIL = 'JunkMail'
    NOTES = 'Notes'
    RSS = 'RSS'
    SUBSCRIBE = 'Subscribe'
    USERCONTACTS = 'UserContacts'
