from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class CommentStatus:
    value: datetime | None = None
    comment: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}CommentStatus'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.value is not None:
            _el.text = self.value.isoformat()
        if self.comment is not None:
            _el.set('comment', self.comment)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        if _el.text is not None:
            _f['value'] = datetime.fromisoformat(_el.text)
        _v = _el.get('comment')
        if _v is not None:
            _f['comment'] = _v
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> CommentStatus:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'DelegatedStatus':
            from gwsoap.types.DelegatedStatus import DelegatedStatus
            return DelegatedStatus(**DelegatedStatus._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
