from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Category(Item):
    type: CategoryType | None = None
    color: int | None = None
    background: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Category'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Category')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type.value
        if self.color is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}color')
            _c.text = str(self.color)
        if self.background is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}background')
            _c.text = str(self.background)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.types.CategoryType import CategoryType
            if _c.text is not None:
                _f['type'] = CategoryType(_c.text)
        _c = _el.find(f'{{{_NS}}}color')
        if _c is not None:
            if _c.text is not None:
                _f['color'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}background')
        if _c is not None:
            if _c.text is not None:
                _f['background'] = int(_c.text)
        return _f
