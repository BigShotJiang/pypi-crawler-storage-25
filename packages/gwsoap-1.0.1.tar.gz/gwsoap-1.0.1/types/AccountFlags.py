from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AccountFlags:
    add_signature: bool | None = None
    add_v_card: bool | None = None
    delete_from_trash: bool | None = None
    download_external_bodies: bool | None = None
    download_headers_only: bool | None = None
    download_new_only: bool | None = None
    expand_threads: bool | None = None
    life_delete: bool | None = None
    member_of_full_sync: bool | None = None
    never_download_old_messages: bool | None = None
    poll_at_startup: bool | None = None
    show_subscribed_folders: bool | None = None
    sync_when_folder_is_selected: bool | None = None
    watch_my_threads: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AccountFlags'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.add_signature is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}addSignature')
            _c.text = ('true' if self.add_signature else 'false')
        if self.add_v_card is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}addVCard')
            _c.text = ('true' if self.add_v_card else 'false')
        if self.delete_from_trash is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}deleteFromTrash')
            _c.text = ('true' if self.delete_from_trash else 'false')
        if self.download_external_bodies is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}downloadExternalBodies')
            _c.text = ('true' if self.download_external_bodies else 'false')
        if self.download_headers_only is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}downloadHeadersOnly')
            _c.text = ('true' if self.download_headers_only else 'false')
        if self.download_new_only is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}downloadNewOnly')
            _c.text = ('true' if self.download_new_only else 'false')
        if self.expand_threads is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}expandThreads')
            _c.text = ('true' if self.expand_threads else 'false')
        if self.life_delete is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}lifeDelete')
            _c.text = ('true' if self.life_delete else 'false')
        if self.member_of_full_sync is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}memberOfFullSync')
            _c.text = ('true' if self.member_of_full_sync else 'false')
        if self.never_download_old_messages is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}neverDownloadOldMessages')
            _c.text = ('true' if self.never_download_old_messages else 'false')
        if self.poll_at_startup is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}pollAtStartup')
            _c.text = ('true' if self.poll_at_startup else 'false')
        if self.show_subscribed_folders is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}showSubscribedFolders')
            _c.text = ('true' if self.show_subscribed_folders else 'false')
        if self.sync_when_folder_is_selected is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}syncWhenFolderIsSelected')
            _c.text = ('true' if self.sync_when_folder_is_selected else 'false')
        if self.watch_my_threads is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}watchMyThreads')
            _c.text = ('true' if self.watch_my_threads else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}addSignature')
        if _c is not None:
            if _c.text is not None:
                _f['add_signature'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}addVCard')
        if _c is not None:
            if _c.text is not None:
                _f['add_v_card'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}deleteFromTrash')
        if _c is not None:
            if _c.text is not None:
                _f['delete_from_trash'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}downloadExternalBodies')
        if _c is not None:
            if _c.text is not None:
                _f['download_external_bodies'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}downloadHeadersOnly')
        if _c is not None:
            if _c.text is not None:
                _f['download_headers_only'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}downloadNewOnly')
        if _c is not None:
            if _c.text is not None:
                _f['download_new_only'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}expandThreads')
        if _c is not None:
            if _c.text is not None:
                _f['expand_threads'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}lifeDelete')
        if _c is not None:
            if _c.text is not None:
                _f['life_delete'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}memberOfFullSync')
        if _c is not None:
            if _c.text is not None:
                _f['member_of_full_sync'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}neverDownloadOldMessages')
        if _c is not None:
            if _c.text is not None:
                _f['never_download_old_messages'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}pollAtStartup')
        if _c is not None:
            if _c.text is not None:
                _f['poll_at_startup'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}showSubscribedFolders')
        if _c is not None:
            if _c.text is not None:
                _f['show_subscribed_folders'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}syncWhenFolderIsSelected')
        if _c is not None:
            if _c.text is not None:
                _f['sync_when_folder_is_selected'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}watchMyThreads')
        if _c is not None:
            if _c.text is not None:
                _f['watch_my_threads'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AccountFlags:
        return cls(**cls._parse_fields(_el))
