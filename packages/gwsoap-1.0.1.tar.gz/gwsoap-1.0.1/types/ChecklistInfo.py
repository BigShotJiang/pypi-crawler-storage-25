from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ChecklistInfo:
    sequence: int | None = None
    due_date: datetime | None = None
    percent_complete: int | None = None
    completed: datetime | None = None
    thread: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ChecklistInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.sequence is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}sequence')
            _c.text = str(self.sequence)
        if self.due_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}dueDate')
            _c.text = self.due_date.isoformat()
        if self.percent_complete is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}percentComplete')
            _c.text = str(self.percent_complete)
        if self.completed is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}completed')
            _c.text = self.completed.isoformat()
        if self.thread is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}thread')
            _c.text = self.thread

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}sequence')
        if _c is not None:
            if _c.text is not None:
                _f['sequence'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}dueDate')
        if _c is not None:
            if _c.text is not None:
                _f['due_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}percentComplete')
        if _c is not None:
            if _c.text is not None:
                _f['percent_complete'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}completed')
        if _c is not None:
            if _c.text is not None:
                _f['completed'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}thread')
        if _c is not None:
            if _c.text is not None:
                _f['thread'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ChecklistInfo:
        return cls(**cls._parse_fields(_el))
