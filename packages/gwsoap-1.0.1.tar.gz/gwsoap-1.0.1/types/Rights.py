from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Rights:
    read: bool | None = None
    add: bool | None = None
    edit: bool | None = None
    delete: bool | None = None
    share: bool | None = None
    manage: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Rights'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.read is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}read')
            _c.text = ('true' if self.read else 'false')
        if self.add is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}add')
            _c.text = ('true' if self.add else 'false')
        if self.edit is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}edit')
            _c.text = ('true' if self.edit else 'false')
        if self.delete is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}delete')
            _c.text = ('true' if self.delete else 'false')
        if self.share is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}share')
            _c.text = ('true' if self.share else 'false')
        if self.manage is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}manage')
            _c.text = ('true' if self.manage else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}read')
        if _c is not None:
            if _c.text is not None:
                _f['read'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}add')
        if _c is not None:
            if _c.text is not None:
                _f['add'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}edit')
        if _c is not None:
            if _c.text is not None:
                _f['edit'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}delete')
        if _c is not None:
            if _c.text is not None:
                _f['delete'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}share')
        if _c is not None:
            if _c.text is not None:
                _f['share'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}manage')
        if _c is not None:
            if _c.text is not None:
                _f['manage'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Rights:
        return cls(**cls._parse_fields(_el))
