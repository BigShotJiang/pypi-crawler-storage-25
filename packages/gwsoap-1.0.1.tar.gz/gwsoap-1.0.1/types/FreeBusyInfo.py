from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.NameAndEmail import NameAndEmail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FreeBusyInfo(NameAndEmail):
    blocks: FreeBusyBlockList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FreeBusyInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'FreeBusyInfo')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.blocks is not None:
            self.blocks.to_xml(_el, f'{{{_NS}}}blocks')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}blocks')
        if _c is not None:
            from gwsoap.types.FreeBusyBlockList import FreeBusyBlockList
            _f['blocks'] = FreeBusyBlockList.from_xml(_c)
        return _f
