from __future__ import annotations

from enum import Enum


class ItemSource(str, Enum):
    RECEIVED = 'received'
    SENT = 'sent'
    DRAFT = 'draft'
    PERSONAL = 'personal'
