from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PostalAddressList:
    address: list[PostalAddress] = _field(default_factory=list)
    mailing_address: PostalAddressType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PostalAddressList'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        for _v in self.address:
            _v.to_xml(_el, f'{{{_NS}}}address')
        if self.mailing_address is not None:
            _el.set('mailingAddress', self.mailing_address.value)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        from gwsoap.types.PostalAddress import PostalAddress
        _f['address'] = [PostalAddress.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}address')]
        _v = _el.get('mailingAddress')
        if _v is not None:
            from gwsoap.types.PostalAddressType import PostalAddressType
            _f['mailing_address'] = PostalAddressType(_v)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> PostalAddressList:
        return cls(**cls._parse_fields(_el))
