from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from gwsoap.types.Custom import Custom
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DocumentCustom(Custom):
    id: str | None = None
    description: str | None = None
    read_only: bool | None = None
    hidden: bool | None = None
    required: bool | None = None
    text_case: TextCase | None = None
    maximum_length: int | None = None
    minimum: int | None = None
    maximum: int | None = None
    table: LookupTable | None = None
    related: list[LookupTable] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DocumentCustom'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'DocumentCustom')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.read_only is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}readOnly')
            _c.text = ('true' if self.read_only else 'false')
        if self.hidden is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}hidden')
            _c.text = ('true' if self.hidden else 'false')
        if self.required is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}required')
            _c.text = ('true' if self.required else 'false')
        if self.text_case is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}textCase')
            _c.text = self.text_case.value
        if self.maximum_length is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}maximumLength')
            _c.text = str(self.maximum_length)
        if self.minimum is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}minimum')
            _c.text = str(self.minimum)
        if self.maximum is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}maximum')
            _c.text = str(self.maximum)
        if self.table is not None:
            self.table.to_xml(_el, f'{{{_NS}}}table')
        for _v in self.related:
            _v.to_xml(_el, f'{{{_NS}}}related')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}readOnly')
        if _c is not None:
            if _c.text is not None:
                _f['read_only'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}hidden')
        if _c is not None:
            if _c.text is not None:
                _f['hidden'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}required')
        if _c is not None:
            if _c.text is not None:
                _f['required'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}textCase')
        if _c is not None:
            from gwsoap.types.TextCase import TextCase
            if _c.text is not None:
                _f['text_case'] = TextCase(_c.text)
        _c = _el.find(f'{{{_NS}}}maximumLength')
        if _c is not None:
            if _c.text is not None:
                _f['maximum_length'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}minimum')
        if _c is not None:
            if _c.text is not None:
                _f['minimum'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}maximum')
        if _c is not None:
            if _c.text is not None:
                _f['maximum'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}table')
        if _c is not None:
            from gwsoap.types.LookupTable import LookupTable
            _f['table'] = LookupTable.from_xml(_c)
        from gwsoap.types.LookupTable import LookupTable
        _f['related'] = [LookupTable.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}related')]
        return _f
