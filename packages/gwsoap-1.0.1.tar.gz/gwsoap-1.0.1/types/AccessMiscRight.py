from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AccessMiscRight:
    alarms: bool | None = None
    notify: bool | None = None
    read_hidden: bool | None = None
    setup: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AccessMiscRight'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.alarms is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}alarms')
            _c.text = ('true' if self.alarms else 'false')
        if self.notify is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}notify')
            _c.text = ('true' if self.notify else 'false')
        if self.read_hidden is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}readHidden')
            _c.text = ('true' if self.read_hidden else 'false')
        if self.setup is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}setup')
            _c.text = ('true' if self.setup else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}alarms')
        if _c is not None:
            if _c.text is not None:
                _f['alarms'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}notify')
        if _c is not None:
            if _c.text is not None:
                _f['notify'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}readHidden')
        if _c is not None:
            if _c.text is not None:
                _f['read_hidden'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}setup')
        if _c is not None:
            if _c.text is not None:
                _f['setup'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AccessMiscRight:
        return cls(**cls._parse_fields(_el))
