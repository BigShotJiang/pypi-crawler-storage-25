from __future__ import annotations

from enum import Enum


class DisplaySettingsType(str, Enum):
    FOLDER = 'Folder'
    FOLDERDEFAULT = 'FolderDefault'
    PANEL = 'Panel'
    PANELTEMPLATE = 'PanelTemplate'
    UNKNOWN = 'Unknown'
