from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ReturnNotification:
    opened: ReturnNotificationOptions | None = None
    deleted: ReturnNotificationOptions | None = None
    accepted: ReturnNotificationOptions | None = None
    declined: ReturnNotificationOptions | None = None
    completed: ReturnNotificationOptions | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ReturnNotification'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.opened is not None:
            self.opened.to_xml(_el, f'{{{_NS}}}opened')
        if self.deleted is not None:
            self.deleted.to_xml(_el, f'{{{_NS}}}deleted')
        if self.accepted is not None:
            self.accepted.to_xml(_el, f'{{{_NS}}}accepted')
        if self.declined is not None:
            self.declined.to_xml(_el, f'{{{_NS}}}declined')
        if self.completed is not None:
            self.completed.to_xml(_el, f'{{{_NS}}}completed')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}opened')
        if _c is not None:
            from gwsoap.types.ReturnNotificationOptions import ReturnNotificationOptions
            _f['opened'] = ReturnNotificationOptions.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}deleted')
        if _c is not None:
            from gwsoap.types.ReturnNotificationOptions import ReturnNotificationOptions
            _f['deleted'] = ReturnNotificationOptions.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}accepted')
        if _c is not None:
            from gwsoap.types.ReturnNotificationOptions import ReturnNotificationOptions
            _f['accepted'] = ReturnNotificationOptions.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}declined')
        if _c is not None:
            from gwsoap.types.ReturnNotificationOptions import ReturnNotificationOptions
            _f['declined'] = ReturnNotificationOptions.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}completed')
        if _c is not None:
            from gwsoap.types.ReturnNotificationOptions import ReturnNotificationOptions
            _f['completed'] = ReturnNotificationOptions.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ReturnNotification:
        return cls(**cls._parse_fields(_el))
