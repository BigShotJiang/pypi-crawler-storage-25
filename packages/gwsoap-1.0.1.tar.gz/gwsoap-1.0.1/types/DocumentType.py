from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class DocumentType:
    name: str | None = None
    life: int | None = None
    maximum_versions: int | None = None
    age_action: AgeAction | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}DocumentType'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.life is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}life')
            _c.text = str(self.life)
        if self.maximum_versions is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}maximumVersions')
            _c.text = str(self.maximum_versions)
        if self.age_action is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}ageAction')
            _c.text = self.age_action.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}life')
        if _c is not None:
            if _c.text is not None:
                _f['life'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}maximumVersions')
        if _c is not None:
            if _c.text is not None:
                _f['maximum_versions'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}ageAction')
        if _c is not None:
            from gwsoap.types.AgeAction import AgeAction
            if _c.text is not None:
                _f['age_action'] = AgeAction(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> DocumentType:
        return cls(**cls._parse_fields(_el))
