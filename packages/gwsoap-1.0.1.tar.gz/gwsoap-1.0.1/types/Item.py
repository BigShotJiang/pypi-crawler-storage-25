from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Item:
    id: str | None = None
    name: str | None = None
    version: int | None = None
    modified: datetime | None = None
    changes: ItemChanges | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Item'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.version is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}version')
            _c.text = str(self.version)
        if self.modified is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}modified')
            _c.text = self.modified.isoformat()
        if self.changes is not None:
            self.changes.to_xml(_el, f'{{{_NS}}}changes')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}version')
        if _c is not None:
            if _c.text is not None:
                _f['version'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}modified')
        if _c is not None:
            if _c.text is not None:
                _f['modified'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}changes')
        if _c is not None:
            from gwsoap.types.ItemChanges import ItemChanges
            _f['changes'] = ItemChanges.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Item:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'Account':
            from gwsoap.types.Account import Account
            return Account(**Account._parse_fields(_el))
        if _t == 'AddressBook':
            from gwsoap.types.AddressBook import AddressBook
            return AddressBook(**AddressBook._parse_fields(_el))
        if _t == 'AddressBookItem':
            from gwsoap.types.AddressBookItem import AddressBookItem
            return AddressBookItem(**AddressBookItem._parse_fields(_el))
        if _t == 'Appointment':
            from gwsoap.types.Appointment import Appointment
            return Appointment(**Appointment._parse_fields(_el))
        if _t == 'BoxEntry':
            from gwsoap.types.BoxEntry import BoxEntry
            return BoxEntry(**BoxEntry._parse_fields(_el))
        if _t == 'CalendarItem':
            from gwsoap.types.CalendarItem import CalendarItem
            return CalendarItem(**CalendarItem._parse_fields(_el))
        if _t == 'Category':
            from gwsoap.types.Category import Category
            return Category(**Category._parse_fields(_el))
        if _t == 'Contact':
            from gwsoap.types.Contact import Contact
            return Contact(**Contact._parse_fields(_el))
        if _t == 'ContactFolder':
            from gwsoap.types.ContactFolder import ContactFolder
            return ContactFolder(**ContactFolder._parse_fields(_el))
        if _t == 'ContainerItem':
            from gwsoap.types.ContainerItem import ContainerItem
            return ContainerItem(**ContainerItem._parse_fields(_el))
        if _t == 'DisplaySettings':
            from gwsoap.types.DisplaySettings import DisplaySettings
            return DisplaySettings(**DisplaySettings._parse_fields(_el))
        if _t == 'Document':
            from gwsoap.types.Document import Document
            return Document(**Document._parse_fields(_el))
        if _t == 'DocumentRef':
            from gwsoap.types.DocumentRef import DocumentRef
            return DocumentRef(**DocumentRef._parse_fields(_el))
        if _t == 'Folder':
            from gwsoap.types.Folder import Folder
            return Folder(**Folder._parse_fields(_el))
        if _t == 'FolderDisplaySettings':
            from gwsoap.types.FolderDisplaySettings import FolderDisplaySettings
            return FolderDisplaySettings(**FolderDisplaySettings._parse_fields(_el))
        if _t == 'Group':
            from gwsoap.types.Group import Group
            return Group(**Group._parse_fields(_el))
        if _t == 'IMAP':
            from gwsoap.types.IMAP import IMAP
            return IMAP(**IMAP._parse_fields(_el))
        if _t == 'IMAPFolder':
            from gwsoap.types.IMAPFolder import IMAPFolder
            return IMAPFolder(**IMAPFolder._parse_fields(_el))
        if _t == 'Library':
            from gwsoap.types.Library import Library
            return Library(**Library._parse_fields(_el))
        if _t == 'Mail':
            from gwsoap.types.Mail import Mail
            return Mail(**Mail._parse_fields(_el))
        if _t == 'NNTP':
            from gwsoap.types.NNTP import NNTP
            return NNTP(**NNTP._parse_fields(_el))
        if _t == 'NNTPFolder':
            from gwsoap.types.NNTPFolder import NNTPFolder
            return NNTPFolder(**NNTPFolder._parse_fields(_el))
        if _t == 'Nickname':
            from gwsoap.types.Nickname import Nickname
            return Nickname(**Nickname._parse_fields(_el))
        if _t == 'Note':
            from gwsoap.types.Note import Note
            return Note(**Note._parse_fields(_el))
        if _t == 'Organization':
            from gwsoap.types.Organization import Organization
            return Organization(**Organization._parse_fields(_el))
        if _t == 'PanelDisplaySettings':
            from gwsoap.types.PanelDisplaySettings import PanelDisplaySettings
            return PanelDisplaySettings(**PanelDisplaySettings._parse_fields(_el))
        if _t == 'PhoneMessage':
            from gwsoap.types.PhoneMessage import PhoneMessage
            return PhoneMessage(**PhoneMessage._parse_fields(_el))
        if _t == 'QueryFolder':
            from gwsoap.types.QueryFolder import QueryFolder
            return QueryFolder(**QueryFolder._parse_fields(_el))
        if _t == 'Resource':
            from gwsoap.types.Resource import Resource
            return Resource(**Resource._parse_fields(_el))
        if _t == 'Rule':
            from gwsoap.types.Rule import Rule
            return Rule(**Rule._parse_fields(_el))
        if _t == 'SharedBook':
            from gwsoap.types.SharedBook import SharedBook
            return SharedBook(**SharedBook._parse_fields(_el))
        if _t == 'SharedFolder':
            from gwsoap.types.SharedFolder import SharedFolder
            return SharedFolder(**SharedFolder._parse_fields(_el))
        if _t == 'SharedNotification':
            from gwsoap.types.SharedNotification import SharedNotification
            return SharedNotification(**SharedNotification._parse_fields(_el))
        if _t == 'SystemFolder':
            from gwsoap.types.SystemFolder import SystemFolder
            return SystemFolder(**SystemFolder._parse_fields(_el))
        if _t == 'Task':
            from gwsoap.types.Task import Task
            return Task(**Task._parse_fields(_el))
        if _t == 'UserContactFolder':
            from gwsoap.types.UserContactFolder import UserContactFolder
            return UserContactFolder(**UserContactFolder._parse_fields(_el))
        if _t == 'Version':
            from gwsoap.types.Version import Version
            return Version(**Version._parse_fields(_el))
        if _t == 'VersionEvent':
            from gwsoap.types.VersionEvent import VersionEvent
            return VersionEvent(**VersionEvent._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
