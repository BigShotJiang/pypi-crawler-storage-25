from __future__ import annotations

from enum import Enum


class ContactType(str, Enum):
    CONTACT = 'Contact'
    GROUP = 'Group'
    RESOURCE = 'Resource'
    ORGANIZATION = 'Organization'
