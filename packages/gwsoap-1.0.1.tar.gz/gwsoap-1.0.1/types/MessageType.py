from __future__ import annotations

from enum import Enum


class MessageType(str, Enum):
    APPOINTMENT = 'Appointment'
    CALENDARITEM = 'CalendarItem'
    DOCUMENTREFERENCE = 'DocumentReference'
    MAIL = 'Mail'
    NOTE = 'Note'
    PHONEMESSAGE = 'PhoneMessage'
    TASK = 'Task'
