from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Sort:
    type: SortType | None = None
    field: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Sort'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type.value
        if self.field is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}field')
            _c.text = self.field

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.types.SortType import SortType
            if _c.text is not None:
                _f['type'] = SortType(_c.text)
        _c = _el.find(f'{{{_NS}}}field')
        if _c is not None:
            if _c.text is not None:
                _f['field'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Sort:
        return cls(**cls._parse_fields(_el))
