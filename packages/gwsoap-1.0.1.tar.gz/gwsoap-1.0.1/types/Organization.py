from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.AddressBookItem import AddressBookItem
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Organization(AddressBookItem):
    contact: ItemRef | None = None
    phone: str | None = None
    fax: str | None = None
    address: PostalAddress | None = None
    website: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Organization'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'Organization')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.contact is not None:
            self.contact.to_xml(_el, f'{{{_NS}}}contact')
        if self.phone is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}phone')
            _c.text = self.phone
        if self.fax is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}fax')
            _c.text = self.fax
        if self.address is not None:
            self.address.to_xml(_el, f'{{{_NS}}}address')
        if self.website is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}website')
            _c.text = self.website

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}contact')
        if _c is not None:
            from gwsoap.types.ItemRef import ItemRef
            _f['contact'] = ItemRef.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}phone')
        if _c is not None:
            if _c.text is not None:
                _f['phone'] = _c.text
        _c = _el.find(f'{{{_NS}}}fax')
        if _c is not None:
            if _c.text is not None:
                _f['fax'] = _c.text
        _c = _el.find(f'{{{_NS}}}address')
        if _c is not None:
            from gwsoap.types.PostalAddress import PostalAddress
            _f['address'] = PostalAddress.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}website')
        if _c is not None:
            if _c.text is not None:
                _f['website'] = _c.text
        return _f
