from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class RuleAction:
    type: RuleActionType | None = None
    container: str | None = None
    item: Mail | None = None
    message: str | None = None
    accept_level: AcceptLevel | None = None
    categories: CategoryRefList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}RuleAction'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type.value
        if self.container is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}container')
            _c.text = self.container
        if self.item is not None:
            self.item.to_xml(_el, f'{{{_NS}}}item')
        if self.message is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}message')
            _c.text = self.message
        if self.accept_level is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}acceptLevel')
            _c.text = self.accept_level.value
        if self.categories is not None:
            self.categories.to_xml(_el, f'{{{_NS}}}categories')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            from gwsoap.types.RuleActionType import RuleActionType
            if _c.text is not None:
                _f['type'] = RuleActionType(_c.text)
        _c = _el.find(f'{{{_NS}}}container')
        if _c is not None:
            if _c.text is not None:
                _f['container'] = _c.text
        _c = _el.find(f'{{{_NS}}}item')
        if _c is not None:
            from gwsoap.types.Mail import Mail
            _f['item'] = Mail.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}message')
        if _c is not None:
            if _c.text is not None:
                _f['message'] = _c.text
        _c = _el.find(f'{{{_NS}}}acceptLevel')
        if _c is not None:
            from gwsoap.types.AcceptLevel import AcceptLevel
            if _c.text is not None:
                _f['accept_level'] = AcceptLevel(_c.text)
        _c = _el.find(f'{{{_NS}}}categories')
        if _c is not None:
            from gwsoap.types.CategoryRefList import CategoryRefList
            _f['categories'] = CategoryRefList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> RuleAction:
        return cls(**cls._parse_fields(_el))
