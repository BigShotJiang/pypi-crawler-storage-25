from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Status:
    code: int | None = None
    description: str | None = None
    info: str | None = None
    problems: ProblemList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Status'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.code is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}code')
            _c.text = str(self.code)
        if self.description is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}description')
            _c.text = self.description
        if self.info is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}info')
            _c.text = self.info
        if self.problems is not None:
            self.problems.to_xml(_el, f'{{{_NS}}}problems')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}code')
        if _c is not None:
            if _c.text is not None:
                _f['code'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}description')
        if _c is not None:
            if _c.text is not None:
                _f['description'] = _c.text
        _c = _el.find(f'{{{_NS}}}info')
        if _c is not None:
            if _c.text is not None:
                _f['info'] = _c.text
        _c = _el.find(f'{{{_NS}}}problems')
        if _c is not None:
            from gwsoap.types.ProblemList import ProblemList
            _f['problems'] = ProblemList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Status:
        return cls(**cls._parse_fields(_el))
