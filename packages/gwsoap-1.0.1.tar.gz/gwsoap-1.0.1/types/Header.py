from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Header:
    field: str | None = None
    width: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Header'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.field is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}field')
            _c.text = self.field
        if self.width is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}width')
            _c.text = str(self.width)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}field')
        if _c is not None:
            if _c.text is not None:
                _f['field'] = _c.text
        _c = _el.find(f'{{{_NS}}}width')
        if _c is not None:
            if _c.text is not None:
                _f['width'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Header:
        return cls(**cls._parse_fields(_el))
