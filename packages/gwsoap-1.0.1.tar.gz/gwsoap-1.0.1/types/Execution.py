from __future__ import annotations

from enum import Enum


class Execution(str, Enum):
    STARTUP = 'Startup'
    EXIT = 'Exit'
    NEW = 'New'
    FOLDEROPEN = 'FolderOpen'
    FOLDERCLOSE = 'FolderClose'
    FOLDERNEW = 'FolderNew'
    COMPLETED = 'Completed'
    USER = 'User'
    UNKNOWN = 'Unknown'
