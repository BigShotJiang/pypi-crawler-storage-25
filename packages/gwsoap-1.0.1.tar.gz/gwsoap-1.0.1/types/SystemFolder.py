from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Folder import Folder
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class SystemFolder(Folder):
    is_system_folder: bool | None = None
    folder_type: FolderType | None = None
    acl: FolderACL | None = None
    is_shared_by_me: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}SystemFolder'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'SystemFolder')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.is_system_folder is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isSystemFolder')
            _c.text = ('true' if self.is_system_folder else 'false')
        if self.folder_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}folderType')
            _c.text = self.folder_type.value
        if self.acl is not None:
            self.acl.to_xml(_el, f'{{{_NS}}}acl')
        if self.is_shared_by_me is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}isSharedByMe')
            _c.text = ('true' if self.is_shared_by_me else 'false')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}isSystemFolder')
        if _c is not None:
            if _c.text is not None:
                _f['is_system_folder'] = ((_c.text) or '').lower() in ('true', '1')
        _c = _el.find(f'{{{_NS}}}folderType')
        if _c is not None:
            from gwsoap.types.FolderType import FolderType
            if _c.text is not None:
                _f['folder_type'] = FolderType(_c.text)
        _c = _el.find(f'{{{_NS}}}acl')
        if _c is not None:
            from gwsoap.types.FolderACL import FolderACL
            _f['acl'] = FolderACL.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}isSharedByMe')
        if _c is not None:
            if _c.text is not None:
                _f['is_shared_by_me'] = ((_c.text) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> SystemFolder:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'ContactFolder':
            from gwsoap.types.ContactFolder import ContactFolder
            return ContactFolder(**ContactFolder._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
