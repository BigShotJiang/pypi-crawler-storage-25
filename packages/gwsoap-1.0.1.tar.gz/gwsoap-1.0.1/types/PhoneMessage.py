from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Mail import Mail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class PhoneMessage(Mail):
    caller: str | None = None
    company: str | None = None
    phone: str | None = None
    flags: PhoneFlags | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}PhoneMessage'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'PhoneMessage')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.caller is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}caller')
            _c.text = self.caller
        if self.company is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}company')
            _c.text = self.company
        if self.phone is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}phone')
            _c.text = self.phone
        if self.flags is not None:
            self.flags.to_xml(_el, f'{{{_NS}}}flags')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}caller')
        if _c is not None:
            if _c.text is not None:
                _f['caller'] = _c.text
        _c = _el.find(f'{{{_NS}}}company')
        if _c is not None:
            if _c.text is not None:
                _f['company'] = _c.text
        _c = _el.find(f'{{{_NS}}}phone')
        if _c is not None:
            if _c.text is not None:
                _f['phone'] = _c.text
        _c = _el.find(f'{{{_NS}}}flags')
        if _c is not None:
            from gwsoap.types.PhoneFlags import PhoneFlags
            _f['flags'] = PhoneFlags.from_xml(_c)
        return _f
