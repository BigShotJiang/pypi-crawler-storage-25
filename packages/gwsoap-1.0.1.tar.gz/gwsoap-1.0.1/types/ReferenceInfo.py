from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ReferenceInfo:
    last_reference_date: datetime | None = None
    reference_count: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ReferenceInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.last_reference_date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}lastReferenceDate')
            _c.text = self.last_reference_date.isoformat()
        if self.reference_count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}referenceCount')
            _c.text = str(self.reference_count)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}lastReferenceDate')
        if _c is not None:
            if _c.text is not None:
                _f['last_reference_date'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}referenceCount')
        if _c is not None:
            if _c.text is not None:
                _f['reference_count'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ReferenceInfo:
        return cls(**cls._parse_fields(_el))
