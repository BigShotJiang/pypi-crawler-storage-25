from __future__ import annotations

from enum import Enum


class DeltaSyncType(str, Enum):
    ADD = 'add'
    DELETE = 'delete'
    UPDATE = 'update'
