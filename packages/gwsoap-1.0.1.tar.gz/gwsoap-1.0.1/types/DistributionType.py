from __future__ import annotations

from enum import Enum


class DistributionType(str, Enum):
    TO = 'TO'
    CC = 'CC'
    BC = 'BC'
    REPLYTO = 'replyTo'
