from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class JunkEntry:
    id: str | None = None
    match: str | None = None
    match_type: JunkMatchType | None = None
    list_type: JunkHandlingListType | None = None
    use_count: int | None = None
    last_used: datetime | None = None
    version: int | None = None
    modified: datetime | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}JunkEntry'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.match is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}match')
            _c.text = self.match
        if self.match_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}matchType')
            _c.text = self.match_type.value
        if self.list_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}listType')
            _c.text = self.list_type.value
        if self.use_count is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}useCount')
            _c.text = str(self.use_count)
        if self.last_used is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}lastUsed')
            _c.text = self.last_used.isoformat()
        if self.version is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}version')
            _c.text = str(self.version)
        if self.modified is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}modified')
            _c.text = self.modified.isoformat()

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}match')
        if _c is not None:
            if _c.text is not None:
                _f['match'] = _c.text
        _c = _el.find(f'{{{_NS}}}matchType')
        if _c is not None:
            from gwsoap.types.JunkMatchType import JunkMatchType
            if _c.text is not None:
                _f['match_type'] = JunkMatchType(_c.text)
        _c = _el.find(f'{{{_NS}}}listType')
        if _c is not None:
            from gwsoap.types.JunkHandlingListType import JunkHandlingListType
            if _c.text is not None:
                _f['list_type'] = JunkHandlingListType(_c.text)
        _c = _el.find(f'{{{_NS}}}useCount')
        if _c is not None:
            if _c.text is not None:
                _f['use_count'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}lastUsed')
        if _c is not None:
            if _c.text is not None:
                _f['last_used'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}version')
        if _c is not None:
            if _c.text is not None:
                _f['version'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}modified')
        if _c is not None:
            if _c.text is not None:
                _f['modified'] = datetime.fromisoformat(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> JunkEntry:
        return cls(**cls._parse_fields(_el))
