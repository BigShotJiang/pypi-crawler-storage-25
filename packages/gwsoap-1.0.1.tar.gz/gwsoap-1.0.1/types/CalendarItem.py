from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Mail import Mail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class CalendarItem(Mail):
    rdate: RecurrenceDateType | None = None
    rrule: RecurrenceRule | None = None
    exdate: RecurrenceDateType | None = None
    recurrence_key: int | None = None
    i_cal_id: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}CalendarItem'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'CalendarItem')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.rdate is not None:
            self.rdate.to_xml(_el, f'{{{_NS}}}rdate')
        if self.rrule is not None:
            self.rrule.to_xml(_el, f'{{{_NS}}}rrule')
        if self.exdate is not None:
            self.exdate.to_xml(_el, f'{{{_NS}}}exdate')
        if self.recurrence_key is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}recurrenceKey')
            _c.text = str(self.recurrence_key)
        if self.i_cal_id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}iCalId')
            _c.text = self.i_cal_id

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}rdate')
        if _c is not None:
            from gwsoap.types.RecurrenceDateType import RecurrenceDateType
            _f['rdate'] = RecurrenceDateType.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}rrule')
        if _c is not None:
            from gwsoap.types.RecurrenceRule import RecurrenceRule
            _f['rrule'] = RecurrenceRule.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}exdate')
        if _c is not None:
            from gwsoap.types.RecurrenceDateType import RecurrenceDateType
            _f['exdate'] = RecurrenceDateType.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}recurrenceKey')
        if _c is not None:
            if _c.text is not None:
                _f['recurrence_key'] = int(_c.text)
        _c = _el.find(f'{{{_NS}}}iCalId')
        if _c is not None:
            if _c.text is not None:
                _f['i_cal_id'] = _c.text
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> CalendarItem:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'Appointment':
            from gwsoap.types.Appointment import Appointment
            return Appointment(**Appointment._parse_fields(_el))
        if _t == 'Note':
            from gwsoap.types.Note import Note
            return Note(**Note._parse_fields(_el))
        if _t == 'Task':
            from gwsoap.types.Task import Task
            return Task(**Task._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
