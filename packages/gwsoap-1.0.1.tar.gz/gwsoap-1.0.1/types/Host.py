from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Host:
    ip_address: str | None = None
    port: int | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Host'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.ip_address is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}ipAddress')
            _c.text = self.ip_address
        if self.port is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}port')
            _c.text = str(self.port)

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}ipAddress')
        if _c is not None:
            if _c.text is not None:
                _f['ip_address'] = _c.text
        _c = _el.find(f'{{{_NS}}}port')
        if _c is not None:
            if _c.text is not None:
                _f['port'] = int(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Host:
        return cls(**cls._parse_fields(_el))
