from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class LookupTable:
    name: str | None = None
    id: str | None = None
    value: list[str] = _field(default_factory=list)

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}LookupTable'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        for _v in self.value:
            _c = ET.SubElement(_el, f'{{{_NS}}}value')
            _c.text = _v

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _f['value'] = [_c.text for _c in _el.findall(f'{{{_NS}}}value') if _c.text is not None]
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> LookupTable:
        return cls(**cls._parse_fields(_el))
