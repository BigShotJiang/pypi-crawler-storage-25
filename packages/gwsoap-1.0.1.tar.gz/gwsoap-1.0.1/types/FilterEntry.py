from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.FilterElement import FilterElement
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class FilterEntry(FilterElement):
    field: str | None = None
    custom: Custom | None = None
    value: str | None = None
    date: FilterDate | None = None
    mask: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}FilterEntry'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'FilterEntry')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.field is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}field')
            _c.text = self.field
        if self.custom is not None:
            self.custom.to_xml(_el, f'{{{_NS}}}custom')
        if self.value is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}value')
            _c.text = self.value
        if self.date is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}date')
            _c.text = self.date.value
        if self.mask is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}mask')
            _c.text = self.mask

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}field')
        if _c is not None:
            if _c.text is not None:
                _f['field'] = _c.text
        _c = _el.find(f'{{{_NS}}}custom')
        if _c is not None:
            from gwsoap.types.Custom import Custom
            _f['custom'] = Custom.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}value')
        if _c is not None:
            if _c.text is not None:
                _f['value'] = _c.text
        _c = _el.find(f'{{{_NS}}}date')
        if _c is not None:
            from gwsoap.types.FilterDate import FilterDate
            if _c.text is not None:
                _f['date'] = FilterDate(_c.text)
        _c = _el.find(f'{{{_NS}}}mask')
        if _c is not None:
            if _c.text is not None:
                _f['mask'] = _c.text
        return _f
