from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class UserInfo:
    name: str | None = None
    email: str | None = None
    uuid: str | None = None
    userid: str | None = None
    domain: str | None = None
    post_office: str | None = None
    system: str | None = None
    fid: str | None = None
    recip_type: RecipientType | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}UserInfo'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.email is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}email')
            _c.text = self.email
        if self.uuid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}uuid')
            _c.text = self.uuid
        if self.userid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}userid')
            _c.text = self.userid
        if self.domain is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}domain')
            _c.text = self.domain
        if self.post_office is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}postOffice')
            _c.text = self.post_office
        if self.system is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}system')
            _c.text = self.system
        if self.fid is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}fid')
            _c.text = self.fid
        if self.recip_type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}recipType')
            _c.text = self.recip_type.value

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}email')
        if _c is not None:
            if _c.text is not None:
                _f['email'] = _c.text
        _c = _el.find(f'{{{_NS}}}uuid')
        if _c is not None:
            if _c.text is not None:
                _f['uuid'] = _c.text
        _c = _el.find(f'{{{_NS}}}userid')
        if _c is not None:
            if _c.text is not None:
                _f['userid'] = _c.text
        _c = _el.find(f'{{{_NS}}}domain')
        if _c is not None:
            if _c.text is not None:
                _f['domain'] = _c.text
        _c = _el.find(f'{{{_NS}}}postOffice')
        if _c is not None:
            if _c.text is not None:
                _f['post_office'] = _c.text
        _c = _el.find(f'{{{_NS}}}system')
        if _c is not None:
            if _c.text is not None:
                _f['system'] = _c.text
        _c = _el.find(f'{{{_NS}}}fid')
        if _c is not None:
            if _c.text is not None:
                _f['fid'] = _c.text
        _c = _el.find(f'{{{_NS}}}recipType')
        if _c is not None:
            from gwsoap.types.RecipientType import RecipientType
            if _c.text is not None:
                _f['recip_type'] = RecipientType(_c.text)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> UserInfo:
        return cls(**cls._parse_fields(_el))
