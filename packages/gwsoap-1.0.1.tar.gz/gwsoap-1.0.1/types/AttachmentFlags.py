from __future__ import annotations

from enum import Enum


class AttachmentFlags(str, Enum):
    COMPUTEHASH = 'ComputeHash'
    RETURNDATA = 'ReturnData'
