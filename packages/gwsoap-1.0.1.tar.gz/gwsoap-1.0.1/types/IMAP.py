from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Account import Account
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class IMAP(Account):
    folder: str | None = None
    inbound: Server | None = None
    outbound: Server | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}IMAP'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'IMAP')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.folder is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}folder')
            _c.text = self.folder
        if self.inbound is not None:
            self.inbound.to_xml(_el, f'{{{_NS}}}inbound')
        if self.outbound is not None:
            self.outbound.to_xml(_el, f'{{{_NS}}}outbound')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}folder')
        if _c is not None:
            if _c.text is not None:
                _f['folder'] = _c.text
        _c = _el.find(f'{{{_NS}}}inbound')
        if _c is not None:
            from gwsoap.types.Server import Server
            _f['inbound'] = Server.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}outbound')
        if _c is not None:
            from gwsoap.types.Server import Server
            _f['outbound'] = Server.from_xml(_c)
        return _f
