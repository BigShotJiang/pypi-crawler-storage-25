from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class StatusTracking:
    value: StatusTrackingOptions | None = None
    auto_delete: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}StatusTracking'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.value is not None:
            _el.text = str(self.value)
        if self.auto_delete is not None:
            _el.set('autoDelete', ('true' if self.auto_delete else 'false'))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        if _el.text is not None:
            from gwsoap.types.StatusTrackingOptions import StatusTrackingOptions
            _f['value'] = _el.text
        _v = _el.get('autoDelete')
        if _v is not None:
            _f['auto_delete'] = ((_v) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> StatusTracking:
        return cls(**cls._parse_fields(_el))
