from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.Authentication import Authentication
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class TrustedApplication(Authentication):
    proxy: str | None = None
    name: str | None = None
    key: str | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}TrustedApplication'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'TrustedApplication')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.proxy is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}proxy')
            _c.text = self.proxy
        if self.name is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}name')
            _c.text = self.name
        if self.key is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}key')
            _c.text = self.key

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}proxy')
        if _c is not None:
            if _c.text is not None:
                _f['proxy'] = _c.text
        _c = _el.find(f'{{{_NS}}}name')
        if _c is not None:
            if _c.text is not None:
                _f['name'] = _c.text
        _c = _el.find(f'{{{_NS}}}key')
        if _c is not None:
            if _c.text is not None:
                _f['key'] = _c.text
        return _f
