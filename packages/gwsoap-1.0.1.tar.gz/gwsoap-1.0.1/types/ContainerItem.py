from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as _field
from datetime import datetime
from gwsoap.types.Item import Item
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ContainerItem(Item):
    container: list[ContainerRef] = _field(default_factory=list)
    categories: CategoryRefList | None = None
    created: datetime | None = None
    customs: CustomList | None = None
    contacts: ContactRefList | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ContainerItem'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'ContainerItem')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        for _v in self.container:
            _v.to_xml(_el, f'{{{_NS}}}container')
        if self.categories is not None:
            self.categories.to_xml(_el, f'{{{_NS}}}categories')
        if self.created is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}created')
            _c.text = self.created.isoformat()
        if self.customs is not None:
            self.customs.to_xml(_el, f'{{{_NS}}}customs')
        if self.contacts is not None:
            self.contacts.to_xml(_el, f'{{{_NS}}}contacts')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        from gwsoap.types.ContainerRef import ContainerRef
        _f['container'] = [ContainerRef.from_xml(_c) for _c in _el.findall(f'{{{_NS}}}container')]
        _c = _el.find(f'{{{_NS}}}categories')
        if _c is not None:
            from gwsoap.types.CategoryRefList import CategoryRefList
            _f['categories'] = CategoryRefList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}created')
        if _c is not None:
            if _c.text is not None:
                _f['created'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}customs')
        if _c is not None:
            from gwsoap.types.CustomList import CustomList
            _f['customs'] = CustomList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}contacts')
        if _c is not None:
            from gwsoap.types.ContactRefList import ContactRefList
            _f['contacts'] = ContactRefList.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ContainerItem:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'AddressBookItem':
            from gwsoap.types.AddressBookItem import AddressBookItem
            return AddressBookItem(**AddressBookItem._parse_fields(_el))
        if _t == 'Appointment':
            from gwsoap.types.Appointment import Appointment
            return Appointment(**Appointment._parse_fields(_el))
        if _t == 'BoxEntry':
            from gwsoap.types.BoxEntry import BoxEntry
            return BoxEntry(**BoxEntry._parse_fields(_el))
        if _t == 'CalendarItem':
            from gwsoap.types.CalendarItem import CalendarItem
            return CalendarItem(**CalendarItem._parse_fields(_el))
        if _t == 'Contact':
            from gwsoap.types.Contact import Contact
            return Contact(**Contact._parse_fields(_el))
        if _t == 'Document':
            from gwsoap.types.Document import Document
            return Document(**Document._parse_fields(_el))
        if _t == 'DocumentRef':
            from gwsoap.types.DocumentRef import DocumentRef
            return DocumentRef(**DocumentRef._parse_fields(_el))
        if _t == 'Group':
            from gwsoap.types.Group import Group
            return Group(**Group._parse_fields(_el))
        if _t == 'Mail':
            from gwsoap.types.Mail import Mail
            return Mail(**Mail._parse_fields(_el))
        if _t == 'Nickname':
            from gwsoap.types.Nickname import Nickname
            return Nickname(**Nickname._parse_fields(_el))
        if _t == 'Note':
            from gwsoap.types.Note import Note
            return Note(**Note._parse_fields(_el))
        if _t == 'Organization':
            from gwsoap.types.Organization import Organization
            return Organization(**Organization._parse_fields(_el))
        if _t == 'PhoneMessage':
            from gwsoap.types.PhoneMessage import PhoneMessage
            return PhoneMessage(**PhoneMessage._parse_fields(_el))
        if _t == 'Resource':
            from gwsoap.types.Resource import Resource
            return Resource(**Resource._parse_fields(_el))
        if _t == 'Rule':
            from gwsoap.types.Rule import Rule
            return Rule(**Rule._parse_fields(_el))
        if _t == 'SharedNotification':
            from gwsoap.types.SharedNotification import SharedNotification
            return SharedNotification(**SharedNotification._parse_fields(_el))
        if _t == 'Task':
            from gwsoap.types.Task import Task
            return Task(**Task._parse_fields(_el))
        if _t == 'Version':
            from gwsoap.types.Version import Version
            return Version(**Version._parse_fields(_el))
        if _t == 'VersionEvent':
            from gwsoap.types.VersionEvent import VersionEvent
            return VersionEvent(**VersionEvent._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
