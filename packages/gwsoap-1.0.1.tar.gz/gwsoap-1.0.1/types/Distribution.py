from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class Distribution:
    from_value: From | None = None
    to: str | None = None
    cc: str | None = None
    bc: str | None = None
    recipients: RecipientList | None = None
    sendoptions: SendOptions | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}Distribution'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.from_value is not None:
            self.from_value.to_xml(_el, f'{{{_NS}}}from')
        if self.to is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}to')
            _c.text = self.to
        if self.cc is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}cc')
            _c.text = self.cc
        if self.bc is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}bc')
            _c.text = self.bc
        if self.recipients is not None:
            self.recipients.to_xml(_el, f'{{{_NS}}}recipients')
        if self.sendoptions is not None:
            self.sendoptions.to_xml(_el, f'{{{_NS}}}sendoptions')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}from')
        if _c is not None:
            from gwsoap.types.From import From
            _f['from_value'] = From.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}to')
        if _c is not None:
            if _c.text is not None:
                _f['to'] = _c.text
        _c = _el.find(f'{{{_NS}}}cc')
        if _c is not None:
            if _c.text is not None:
                _f['cc'] = _c.text
        _c = _el.find(f'{{{_NS}}}bc')
        if _c is not None:
            if _c.text is not None:
                _f['bc'] = _c.text
        _c = _el.find(f'{{{_NS}}}recipients')
        if _c is not None:
            from gwsoap.types.RecipientList import RecipientList
            _f['recipients'] = RecipientList.from_xml(_c)
        _c = _el.find(f'{{{_NS}}}sendoptions')
        if _c is not None:
            from gwsoap.types.SendOptions import SendOptions
            _f['sendoptions'] = SendOptions.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> Distribution:
        return cls(**cls._parse_fields(_el))
