from __future__ import annotations

from enum import Enum


class VersionEventType(str, Enum):
    ARCHIVE = 'archive'
    CHECKIN = 'checkIn'
    CHECKOUT = 'checkOut'
    COPYIN = 'copyIn'
    COPYOUT = 'copyOut'
    COPYVERSION = 'copyVersion'
    CREATED = 'created'
    DELETEVERSION = 'deleteVersion'
    ENDACCESS = 'endAccess'
    RESETSTATUS = 'resetStatus'
    RESTORE = 'restore'
    RETRIEVE = 'retrieve'
    SECURITYMODIFIED = 'securityModified'
    VERSIONDOWNLOADED = 'versionDownloaded'
    VIEWED = 'viewed'
    UNKNOWN = 'unknown'
