from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ContactNote:
    id: str | None = None
    created: datetime | None = None
    attachment: AttachmentItemInfo | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ContactNote'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.id is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}id')
            _c.text = self.id
        if self.created is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}created')
            _c.text = self.created.isoformat()
        if self.attachment is not None:
            self.attachment.to_xml(_el, f'{{{_NS}}}attachment')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}id')
        if _c is not None:
            if _c.text is not None:
                _f['id'] = _c.text
        _c = _el.find(f'{{{_NS}}}created')
        if _c is not None:
            if _c.text is not None:
                _f['created'] = datetime.fromisoformat(_c.text)
        _c = _el.find(f'{{{_NS}}}attachment')
        if _c is not None:
            from gwsoap.types.AttachmentItemInfo import AttachmentItemInfo
            _f['attachment'] = AttachmentItemInfo.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ContactNote:
        return cls(**cls._parse_fields(_el))
