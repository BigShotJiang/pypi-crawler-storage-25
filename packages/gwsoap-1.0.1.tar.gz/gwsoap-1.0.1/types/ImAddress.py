from __future__ import annotations

from dataclasses import dataclass
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class ImAddress:
    service: str | None = None
    address: str | None = None
    type: str | None = None
    primary: bool | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}ImAddress'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        if self.service is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}service')
            _c.text = self.service
        if self.address is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}address')
            _c.text = self.address
        if self.type is not None:
            _c = ET.SubElement(_el, f'{{{_NS}}}type')
            _c.text = self.type
        if self.primary is not None:
            _el.set('primary', ('true' if self.primary else 'false'))

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = {}
        _c = _el.find(f'{{{_NS}}}service')
        if _c is not None:
            if _c.text is not None:
                _f['service'] = _c.text
        _c = _el.find(f'{{{_NS}}}address')
        if _c is not None:
            if _c.text is not None:
                _f['address'] = _c.text
        _c = _el.find(f'{{{_NS}}}type')
        if _c is not None:
            if _c.text is not None:
                _f['type'] = _c.text
        _v = _el.get('primary')
        if _v is not None:
            _f['primary'] = ((_v) or '').lower() in ('true', '1')
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> ImAddress:
        return cls(**cls._parse_fields(_el))
