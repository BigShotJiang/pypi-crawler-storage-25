from __future__ import annotations

from dataclasses import dataclass
from gwsoap.types.NameAndEmail import NameAndEmail
import xml.etree.ElementTree as ET

_NS = 'http://schemas.novell.com/2005/01/GroupWise/types'

@dataclass
class AccessControlListEntry(NameAndEmail):
    rights: Rights | None = None

    def to_xml(self, parent: ET.Element | None = None, tag: str | None = None) -> ET.Element:
        _tag = tag or f'{{{_NS}}}AccessControlListEntry'
        _el = ET.SubElement(parent, _tag) if parent is not None else ET.Element(_tag)
        _el.set('{http://www.w3.org/2001/XMLSchema-instance}type', 'AccessControlListEntry')
        self._write_fields(_el)
        return _el

    def _write_fields(self, _el: ET.Element) -> None:
        super()._write_fields(_el)
        if self.rights is not None:
            self.rights.to_xml(_el, f'{{{_NS}}}rights')

    @classmethod
    def _parse_fields(cls, _el: ET.Element) -> dict:
        _f: dict = super()._parse_fields(_el)
        _c = _el.find(f'{{{_NS}}}rights')
        if _c is not None:
            from gwsoap.types.Rights import Rights
            _f['rights'] = Rights.from_xml(_c)
        return _f

    @classmethod
    def from_xml(cls, _el: ET.Element) -> AccessControlListEntry:
        _t = _el.get('{http://www.w3.org/2001/XMLSchema-instance}type')
        if _t and ':' in _t:
            _t = _t.split(':', 1)[1]
        if _t == 'FolderACLEntry':
            from gwsoap.types.FolderACLEntry import FolderACLEntry
            return FolderACLEntry(**FolderACLEntry._parse_fields(_el))
        return cls(**cls._parse_fields(_el))
