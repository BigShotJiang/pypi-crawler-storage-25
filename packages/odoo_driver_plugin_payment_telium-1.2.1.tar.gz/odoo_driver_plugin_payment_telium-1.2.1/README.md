# Odoo Driver Plugin - Payment Terminal - Ingenico

![License: AGPL v3](https://img.shields.io/badge/License-AGPL_v3-blue.svg)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/odoo-driver-plugin-payment-terminal)
![PyPI - Downloads](https://img.shields.io/pypi/dm/odoo-driver-plugin-payment-terminal)
![GitLab last commit](https://img.shields.io/gitlab/last-commit/81577360)
![GitLab stars](https://img.shields.io/gitlab/stars/81577360?style=social)


This project provide a plugin for ``odoo-driver``
to communicate with Payment Terminal with Telium protocol.

This plugin requires the following odoo module : [`pos_odoo_driver_payment`](https://github.com/grap/odoo-addons-pos)

To install this plugin, refer to the main project page : https://gitlab.com/grap-rhone-alpes/odoo-driver/.

For developpers, refer to this page : https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-printer-escpos/-/blob/main/DEVELOP.md.

## Table of contents

1. [Compatible Devices](#compatible-devices)
2. [Credits](#credits)
3. [Develop](#develop)


<a name="compatible-devices"></a>

## Compatible Devices

<table style="width: 100%;">
    <tbody>
        <tr>
            <td>Ingenico - Desk/5000</td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-payment-telium/-/raw/main/odoo_driver_plugin_payment_telium/static/img/ingenico__desk_5000.png" width="200" height="200" />
            </td>
        </tr>
        <tr>
            <td>Ingenico - Move/5000</td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-payment-telium/-/raw/main/odoo_driver_plugin_payment_telium/static/img/ingenico__move_5000.png" width="200" height="200" />
            </td>
        </tr>
    </tbody>
</table>

<a name="credits"></a>

## Credits

### Authors

* GRAP <https://www.grap.coop>

### Contributors

* Sylvain LE GAL <https://www.grap.coop/>

### Extra authorship

Part of the code in this project comes from the following projects, including:

* [Pywebdriver](https://github.com/pywebdriver/pywebdriver) (AGPL-3.0).

### Images

* [Credit Card Payment Terminal Icon](https://www.flaticon.com/fr/icone-gratuite/terminal-de-paiement_6137350), created by ToZ Icon (Flaticon).


<a name="develop"></a>

## Develop

### Local Installation

To install the odoo-driver library and some plugins, you can refer to this documentation:

https://gitlab.com/grap-rhone-alpes/odoo-driver-env

### Documentation

**Telium**

* https://pypi.org/project/pyTeliumManager/
