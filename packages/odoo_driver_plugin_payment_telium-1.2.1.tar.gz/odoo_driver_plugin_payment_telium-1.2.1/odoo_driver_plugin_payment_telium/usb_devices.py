USB_DEVICES = {
    (0x079B, 0x0028): {
        "name": "Ingenico - Move/5000",
        "image": "ingenico__move_5000.png",
    },
    (0x0B00, 0x0080): {
        "name": "Ingenico - Desk/5000",
        "image": "ingenico__desk_5000.png",
    },
}
