import simplejson
from flask import Blueprint, jsonify, request
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_odoo = Blueprint(
    "route_payment_telium_odoo", __name__, template_folder="templates"
)


@driver_routes_odoo.route(
    "/hw_proxy/payment_terminal_transaction_start", methods=["POST", "PUT"]
)
@logger.catch
def payment_terminal_transaction_start():
    driver = interface.drivers.get("printer")
    data = request.json.get("params", {}).get("payment_info", {})
    interface.log_data(data, "payment", "DEBUG")

    if type(data) is str:
        data = simplejson.loads(data)

    amount = float(data.get("amount").replace(",", "."))
    currency_iso = data.get("currency_iso")

    result = driver.push_amount(amount, currency_iso)
    return jsonify(jsonrpc="2.0", result=result)
