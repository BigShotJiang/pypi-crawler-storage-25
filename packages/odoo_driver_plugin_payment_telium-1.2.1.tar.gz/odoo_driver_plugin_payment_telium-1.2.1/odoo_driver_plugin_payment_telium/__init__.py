from pathlib import Path

from single_source import get_version

from . import usb_devices
from .payment_telium_driver import DriverPaymentIngenico
from .routes_odoo import driver_routes_odoo
from .routes_website import driver_routes_website

__version__ = get_version(__name__, Path(__file__).parent.parent)
__package_name__ = __name__

DRIVER_FUNCTION = "payment"
PLUGIN_NAME = "payment_telium"
DRIVER_CLASS = DriverPaymentIngenico
USB_DEVICES = usb_devices.USB_DEVICES
DRIVER_ROUTES_GROUPS = [driver_routes_odoo, driver_routes_website]
