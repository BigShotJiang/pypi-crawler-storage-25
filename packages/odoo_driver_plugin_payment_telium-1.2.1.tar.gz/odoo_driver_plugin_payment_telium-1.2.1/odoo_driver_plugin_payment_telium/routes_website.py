from flask import Blueprint, render_template
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_website = Blueprint(
    "route_payment_telium_website", __name__, template_folder="templates"
)


@driver_routes_website.route("/driver/payment_telium.html")
@logger.catch
def driver_payment_telium():
    print("driver_payment_telium")
    driver = interface.drivers.get("payment")
    return render_template("payment_telium_driver.html.jinja", driver=driver)
