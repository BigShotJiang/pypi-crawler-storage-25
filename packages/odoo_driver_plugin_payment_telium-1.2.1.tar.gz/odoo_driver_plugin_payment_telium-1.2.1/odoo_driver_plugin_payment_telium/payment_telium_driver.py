from flask_babel import gettext as _
from loguru import logger
from odoo_driver.drivers.driver_abstract import DriverAbstract
from telium import Telium, TeliumAsk, manager


class DriverPaymentIngenico(DriverAbstract):
    _driver_function = "payment"
    _plugin_name = "payment_telium"

    @property
    def name(self):
        return _("Payment Terminal")

    def push_amount(self, amount, currency_iso):
        if not self.terminal_file:
            return False
        telium_device = Telium(self.terminal_file)
        payment = TeliumAsk.new_payment(
            amount,
            payment_mode="debit",
            target_currency=currency_iso,
        )
        try:
            result = telium_device.ask(payment)
        except manager.TerminalInitializationFailedException as e:
            logger.error(f"{type(e).__name__} - {str(e)}")
            return False
        finally:
            telium_device.close()
        return result
