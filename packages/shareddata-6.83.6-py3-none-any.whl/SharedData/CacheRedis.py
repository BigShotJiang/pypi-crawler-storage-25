"""
Redis-backed last-state cache for Kafka stream consumers.

Key layout (all share hash-tag '{path}' → same cluster slot):
    {path}:<pkey>          BSON-encoded dict, one per logical entity
    {path}#pkeys           SET of all pkeys (enumeration index)
    {path}#<field>         header / counter scalars (CacheHeader)

Design:
    - At-least-once durability: Kafka path calls apply_batch(), awaits the
      Redis ack, then commits the offset. No data lost on crash.
    - Atomic read-modify-write: CAS via Lua script; SET + SADD + INCR happen
      in one server-side operation so the #pkeys index can never drift from
      the actual keyspace on a successful write.
    - Cluster-safe: data, pkey-set and header fields all share the '{path}'
      hash-tag, so multi-key Lua and SMEMBERS stay slot-local.
    - BSON encoding (handles datetime natively; same format as the Kafka
      pipeline).

Enumeration:
    - list_keys() → SMEMBERS {path}#pkeys   (fast; one round-trip)
    - update_keys() → SCAN the data prefix and rebuild the SET (reconciliation
      tool for the rare TTL-expiry drift case; call manually if needed)
"""
from __future__ import annotations

import asyncio
import os
import random
from collections.abc import Iterable, Iterator, Mapping
from fnmatch import fnmatch
from typing import Any

import bson
from redis import Redis
from redis.cluster import ClusterNode, RedisCluster
from redis.asyncio import Redis as RedisAsync
from redis.asyncio.cluster import ClusterNode as ClusterNodeAsync
from redis.asyncio.cluster import RedisCluster as RedisClusterAsync

from SharedData.Database import DATABASE_PKEYS


# ---------------------------------------------------------------------------
# Lua: atomic CAS + SADD pkey-set + INCR counter
# ---------------------------------------------------------------------------
# KEYS[1] = {path}:<pkey>           data
# KEYS[2] = {path}#pkeys            pkey SET
# KEYS[3] = {path}#cache->counter   counter
# ARGV[1] = expected previous bytes ('' if caller expects key to be absent)
# ARGV[2] = new bytes (BSON-encoded merged dict)
# ARGV[3] = pkey string (for SADD)
# ARGV[4] = TTL seconds (0 = no TTL)
# Returns: 1 on success, 0 on CAS conflict (caller retries).
_CAS_LUA = r"""
local current = redis.call('GET', KEYS[1])
if current == false then current = '' end
if current ~= ARGV[1] then
    return 0
end
local ttl = tonumber(ARGV[4])
if ttl and ttl > 0 then
    redis.call('SET', KEYS[1], ARGV[2], 'EX', ttl)
else
    redis.call('SET', KEYS[1], ARGV[2])
end
redis.call('SADD', KEYS[2], ARGV[3])
redis.call('INCR', KEYS[3])
return 1
"""


_COUNTER_FIELD = 'cache->counter'
# Production Kafka path: 1 writer per pkey (partition ownership) → CAS always
# succeeds on attempt 1. Retries matter only when a strategy/script writes to
# the same pkey concurrently with the consumer.
_MAX_CAS_RETRIES = 32
_CAS_BACKOFF_BASE_MS = 0.5
_CAS_BACKOFF_MAX_MS = 50.0


def _deep_merge(target: dict, source: Mapping) -> dict:
    """Recursively merge source into target. Mutates target; returns it."""
    for k, v in source.items():
        if isinstance(v, Mapping) and isinstance(target.get(k), dict):
            _deep_merge(target[k], v)
        else:
            target[k] = v
    return target


def _check_pkey(pkey: str) -> None:
    if not isinstance(pkey, str):
        raise TypeError('pkey must be a string')
    if not pkey:
        raise ValueError('pkey must be non-empty')
    if '#' in pkey or ':' in pkey:
        raise ValueError(f'pkey cannot contain # or : (got {pkey!r})')


def _parse_cluster_nodes() -> list[tuple[str, int]]:
    raw = os.environ.get('REDIS_CLUSTER_NODES')
    if not raw:
        raise RuntimeError('REDIS_CLUSTER_NODES not defined')
    nodes = []
    for part in raw.split(','):
        host, port = part.strip().split(':')
        nodes.append((host.strip(), int(port)))
    return nodes


def _build_sync_client():
    nodes = _parse_cluster_nodes()
    if len(nodes) > 1:
        return RedisCluster(
            startup_nodes=[ClusterNode(h, p) for h, p in nodes],
            decode_responses=False,
        )
    host, port = nodes[0]
    return Redis(host=host, port=port, decode_responses=False)


def _build_async_client():
    nodes = _parse_cluster_nodes()
    if len(nodes) > 1:
        return RedisClusterAsync(
            startup_nodes=[ClusterNodeAsync(h, p) for h, p in nodes],
            decode_responses=False,
        )
    host, port = nodes[0]
    return RedisAsync(host=host, port=port, decode_responses=False)


class CacheRedis:
    def __init__(
        self,
        database: str,
        period: str,
        source: str,
        tablename: str,
        user: str = 'master',
        ttl_seconds: int = 0,
        pkey_columns: list[str] | None = None,
    ):
        if database not in DATABASE_PKEYS:
            raise ValueError(f'unknown database {database!r}')
        self.database = database
        self.period = period
        self.source = source
        self.tablename = tablename
        self.user = user
        self.ttl_seconds = int(ttl_seconds)

        self.path = f'{user}/{database}/{period}/{source}/cache/{tablename}'
        self._tag = '{' + self.path + '}'

        # 6.80.7 pkey derivation: keep only the entity-identifier columns.
        # Override via pkey_columns if a caller wants the full DATABASE_PKEYS.
        if pkey_columns is None:
            pkey_columns = [
                c for c in DATABASE_PKEYS[database]
                if c in ('symbol', 'portfolio', 'tag')
            ]
        if not pkey_columns:
            raise ValueError(
                f'no entity pkey columns for database {database!r}; '
                f'pass pkey_columns explicitly'
            )
        self.pkey_columns = list(pkey_columns)
        self.pkeycolumns = self.pkey_columns  # legacy alias

        self.set_pkeys = f'{self._tag}#pkeys'

        self._redis = _build_sync_client()
        self._redis_async: Any | None = None
        self._redis_async_loop: Any | None = None

        # Register CAS script (evalsha + NOSCRIPT fallback handled by redis-py).
        self._cas = self._redis.register_script(_CAS_LUA)
        self._cas_async: Any | None = None

        # Header shim — same API as the old CacheHeader class.
        self.header = CacheHeader(self)

        # Seed counter once; no-op if already set.
        if self.header.get('cache->counter') is None:
            self.header['cache->counter'] = 0

    # ------------------------------------------------------------------
    # Back-compat property aliases
    # ------------------------------------------------------------------
    @property
    def redis(self):
        return self._redis

    @property
    def redis_async(self):
        return self._get_async()

    # ------------------------------------------------------------------
    # Async client (lazy; bound to the event loop that first asks for it)
    # ------------------------------------------------------------------
    def _get_async(self):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if self._redis_async is not None and self._redis_async_loop is not loop:
            self._redis_async = None
            self._cas_async = None
            self._redis_async_loop = None
        if self._redis_async is None:
            self._redis_async = _build_async_client()
            self._redis_async_loop = loop
        return self._redis_async

    def _get_async_cas(self):
        if self._cas_async is None:
            self._cas_async = self._get_async().register_script(_CAS_LUA)
        return self._cas_async

    async def aclose(self) -> None:
        if self._redis_async is not None:
            try:
                await self._redis_async.close()
            except Exception:
                pass
            self._redis_async = None

    # ------------------------------------------------------------------
    # Key helpers
    # ------------------------------------------------------------------
    def get_hash(self, pkey: str) -> str:
        return f'{self._tag}:{pkey}'

    def _counter_key(self) -> str:
        return f'{self._tag}#{_COUNTER_FIELD}'

    # ------------------------------------------------------------------
    # pkey derivation
    # ------------------------------------------------------------------
    def pkey_of(self, value: Mapping[str, Any]) -> str:
        parts = []
        for col in self.pkey_columns:
            if col not in value:
                raise KeyError(
                    f'message missing pkey column {col!r}: keys={list(value.keys())}'
                )
            s = str(value[col])
            if not s:
                raise ValueError(f'empty pkey value for column {col!r}')
            if '#' in s or ':' in s:
                raise ValueError(f'invalid pkey value for {col!r}: {s!r}')
            parts.append(s)
        return ','.join(parts)

    def get_pkey(self, value: Mapping[str, Any]) -> str:
        return self.pkey_of(value)

    # ------------------------------------------------------------------
    # Point reads
    # ------------------------------------------------------------------
    def __getitem__(self, pkey: str) -> dict:
        _check_pkey(pkey)
        raw = self._redis.get(self.get_hash(pkey))
        if raw is None:
            return {}
        return bson.BSON.decode(raw)

    def at(self, pkey: str) -> dict:
        _check_pkey(pkey)
        raw = self._redis.get(self.get_hash(pkey))
        if raw is None:
            raise KeyError(pkey)
        return bson.BSON.decode(raw)

    def get(self, pkey: str, default: Any = None) -> Any:
        _check_pkey(pkey)
        raw = self._redis.get(self.get_hash(pkey))
        if raw is None:
            return {} if default is None else default
        return bson.BSON.decode(raw)

    def mget(self, pkeys: Iterable[str]) -> list[dict]:
        pkeys = list(pkeys)
        if not pkeys:
            return []
        for pkey in pkeys:
            _check_pkey(pkey)
        raws = self._redis.mget([self.get_hash(p) for p in pkeys])
        return [bson.BSON.decode(r) if r is not None else {} for r in raws]

    async def aget(self, pkey: str, default: Any = None) -> Any:
        _check_pkey(pkey)
        r = self._get_async()
        raw = await r.get(self.get_hash(pkey))
        if raw is None:
            return {} if default is None else default
        return bson.BSON.decode(raw)

    async def amget(self, pkeys: Iterable[str]) -> list[dict]:
        pkeys = list(pkeys)
        if not pkeys:
            return []
        for pkey in pkeys:
            _check_pkey(pkey)
        r = self._get_async()
        raws = await r.mget([self.get_hash(p) for p in pkeys])
        return [bson.BSON.decode(raw) if raw is not None else {} for raw in raws]

    def exists(self, pkey: str) -> bool:
        _check_pkey(pkey)
        return bool(self._redis.exists(self.get_hash(pkey)))

    def key_ttl(self, pkey: str) -> int:
        _check_pkey(pkey)
        return int(self._redis.ttl(self.get_hash(pkey)))

    def load(self) -> dict:
        pkeys = self.list_keys('*')
        values = self.mget(pkeys)
        return dict(zip(pkeys, values))

    # ------------------------------------------------------------------
    # Writes (single pkey → CAS Lua, one round-trip in the happy path)
    # ------------------------------------------------------------------
    def __setitem__(self, pkey: str, new_value: Mapping[str, Any]) -> None:
        _check_pkey(pkey)
        self._cas_merge_sync(pkey, dict(new_value))

    def set(self, new_value: Mapping[str, Any], pkey: str | None = None) -> None:
        if pkey is None:
            pkey = self.pkey_of(new_value)
        self[pkey] = new_value

    def set_ex(self, pkey: str, value: Mapping[str, Any], ex: int) -> None:
        _check_pkey(pkey)
        self._cas_merge_sync(pkey, dict(value), ttl=int(ex))

    def __delitem__(self, pkey: str) -> None:
        _check_pkey(pkey)
        pipe = self._redis.pipeline(transaction=False)
        pipe.delete(self.get_hash(pkey))
        pipe.srem(self.set_pkeys, pkey)
        pipe.execute()

    # ------------------------------------------------------------------
    # Batch writes — the Kafka path
    # ------------------------------------------------------------------
    async def apply_batch(
        self,
        messages: Iterable[Mapping[str, Any]],
        mode: str = 'merge',
        strict: bool = False,
    ) -> int:
        """
        Apply a batch of messages with at-least-once semantics.

        Kafka consumers call this with strict=False: messages whose pkey can't
        be derived are skipped (skip counter incremented) instead of poisoning
        the stream. Returns only after Redis has acked every write, so the
        caller can commit the Kafka offset safely.
        """
        if mode not in ('merge', 'replace'):
            raise ValueError(f'invalid mode {mode!r}')
        messages = list(messages)
        if not messages:
            return 0

        conflated: dict[str, dict] = {}
        skipped = 0
        for msg in messages:
            try:
                pkey = self.pkey_of(msg)
            except (KeyError, ValueError, TypeError):
                if strict:
                    raise
                skipped += 1
                continue
            if pkey in conflated:
                _deep_merge(conflated[pkey], dict(msg))
            else:
                conflated[pkey] = dict(msg)

        if skipped:
            try:
                self._redis.incrby(
                    f'{self._tag}#cache->skip_counter', skipped
                )
            except Exception:
                pass

        await self._cas_write_many(conflated, mode=mode)
        return len(conflated)

    async def async_set(self, value_or_list) -> int:
        """Back-compat: now a durable write, returns after Redis ack."""
        if isinstance(value_or_list, list):
            return await self.apply_batch(value_or_list)
        return await self.apply_batch([value_or_list])

    # ------------------------------------------------------------------
    # CAS primitives
    # ------------------------------------------------------------------
    def _cas_merge_sync(self, pkey: str, delta: dict, ttl: int | None = None) -> None:
        data_key = self.get_hash(pkey)
        counter_key = self._counter_key()
        ttl_val = int(ttl if ttl is not None else self.ttl_seconds)

        for _ in range(_MAX_CAS_RETRIES):
            prev = self._redis.get(data_key)
            current = bson.BSON.decode(prev) if prev else {}
            merged = _deep_merge(current, delta) if current else dict(delta)
            new_bytes = bson.BSON.encode(merged)
            ok = self._cas(
                keys=[data_key, self.set_pkeys, counter_key],
                args=[prev if prev else b'', new_bytes, pkey, ttl_val],
                client=self._redis,
            )
            if ok:
                return
        raise RuntimeError(f'CAS retry exhausted for {pkey!r}')

    async def _cas_write_many(self, deltas: dict[str, dict], mode: str) -> None:
        if not deltas:
            return
        r = self._get_async()
        counter_key = self._counter_key()
        ttl = self.ttl_seconds
        script = self._get_async_cas()

        # Phase 1: pipelined GET (same-slot; cluster allows this).
        pkeys = list(deltas.keys())
        data_keys = [self.get_hash(p) for p in pkeys]
        pipe = r.pipeline(transaction=False)
        for k in data_keys:
            pipe.get(k)
        prevs = await pipe.execute()

        attempts: dict[str, bytes] = {
            pkey: (prev or b'') for pkey, prev in zip(pkeys, prevs)
        }

        # Phase 2: concurrent CAS via asyncio.gather. Cluster blocks evalsha
        # inside pipelines, so each Script call is routed independently.
        async def _one(pkey: str, prev: bytes):
            delta = deltas[pkey]
            if mode == 'merge':
                prev_dict = bson.BSON.decode(prev) if prev else {}
                merged = (
                    _deep_merge(prev_dict, delta) if prev_dict else dict(delta)
                )
            else:
                merged = dict(delta)
            new_bytes = bson.BSON.encode(merged)
            return await script(
                keys=[self.get_hash(pkey), self.set_pkeys, counter_key],
                args=[prev, new_bytes, pkey, ttl],
                client=r,
            )

        for attempt in range(_MAX_CAS_RETRIES):
            if not attempts:
                return
            ordered = list(attempts.items())
            results = await asyncio.gather(
                *(_one(pk, prev) for pk, prev in ordered)
            )
            retry_keys = [pk for (pk, _), ok in zip(ordered, results) if not ok]
            if not retry_keys:
                return
            delay_ms = min(
                _CAS_BACKOFF_BASE_MS * (2 ** min(attempt, 6)),
                _CAS_BACKOFF_MAX_MS,
            )
            await asyncio.sleep(random.uniform(0, delay_ms) / 1000.0)
            pipe = r.pipeline(transaction=False)
            for pk in retry_keys:
                pipe.get(self.get_hash(pk))
            new_prevs = await pipe.execute()
            attempts = {
                pk: (np or b'') for pk, np in zip(retry_keys, new_prevs)
            }

        raise RuntimeError(f'CAS retry exhausted for {list(attempts.keys())}')

    # ------------------------------------------------------------------
    # Enumeration — SMEMBERS on the pkey SET (fast path)
    # ------------------------------------------------------------------
    def list_keys(self, keyword: str = '*', count: int | None = None) -> list[str]:
        """SMEMBERS the pkey set; optional fnmatch filter and count limit.

        Empty-string members from legacy drift are dropped — they can't
        correspond to a valid data key.
        """
        members = self._redis.smembers(self.set_pkeys)
        decoded = [
            m.decode('utf-8') if isinstance(m, bytes) else m
            for m in members
        ]
        decoded = [k for k in decoded if k]
        if keyword and keyword != '*':
            decoded = [k for k in decoded if fnmatch(k, keyword)]
        if count is not None:
            decoded = decoded[:count]
        return decoded

    def update_keys(self, keyword: str = '*', count: int | None = None) -> list[str]:
        """
        Reconciliation: SCAN {path}:<keyword> and rebuild the pkey SET.

        Run this manually if keys expired via TTL (or were deleted out of band)
        and the SET holds ghost entries. The happy path does NOT need this —
        every write atomically adds the pkey via the CAS Lua script.
        """
        pattern = f'{self._tag}:{keyword}'
        scan_kw: dict = {'match': pattern}
        if count is not None:
            scan_kw['count'] = count
        prefix = f'{self._tag}:'
        plen = len(prefix)
        found: list[str] = []
        for key in self._redis.scan_iter(**scan_kw):
            key_s = key.decode('utf-8') if isinstance(key, bytes) else key
            if not key_s.startswith(prefix):
                continue
            found.append(key_s[plen:])
        self._redis.delete(self.set_pkeys)
        if found:
            for i in range(0, len(found), 1000):
                self._redis.sadd(self.set_pkeys, *found[i:i + 1000])
        return found

    def scan(self, keyword: str = '*', count: int | None = None) -> Iterator[str]:
        """Iterator form of list_keys."""
        yield from self.list_keys(keyword=keyword, count=count)

    def __iter__(self) -> Iterator[str]:
        yield from self.list_keys()

    # ------------------------------------------------------------------
    # Admin
    # ------------------------------------------------------------------
    def clear(self) -> None:
        pkeys = self.list_keys('*')
        if pkeys:
            data_keys = [self.get_hash(p) for p in pkeys]
            for i in range(0, len(data_keys), 1000):
                self._redis.delete(*data_keys[i:i + 1000])
        self._redis.delete(self.set_pkeys)
        header_fields = list(self.header)
        if header_fields:
            hkeys = [self.header.get_hash(f) for f in header_fields]
            for i in range(0, len(hkeys), 1000):
                self._redis.delete(*hkeys[i:i + 1000])

    def recursive_update(self, original: dict, updates: Mapping) -> dict:
        return _deep_merge(original, updates)


class CacheHeader:
    """Dict-like view over {path}#<field>. Same API as the 6.80.7 class."""

    def __init__(self, cache: CacheRedis):
        self.cache = cache

    def get_hash(self, field: str) -> str:
        return f'{self.cache._tag}#{field}'

    def __getitem__(self, field: str):
        return self.cache._redis.get(self.get_hash(field))

    def get(self, field: str, default=None):
        val = self.cache._redis.get(self.get_hash(field))
        return val if val is not None else default

    def __setitem__(self, field: str, value) -> None:
        self.cache._redis.set(self.get_hash(field), value)

    def set(self, field: str, value) -> None:
        self.cache._redis.set(self.get_hash(field), value)

    def __delitem__(self, field: str) -> None:
        self.cache._redis.delete(self.get_hash(field))

    def __iter__(self):
        # Enumerate via SCAN {path}#*  — filters out the '#pkeys' SET itself.
        pattern = f'{self.cache._tag}#*'
        pkeys_key = self.cache.set_pkeys
        for key in self.cache._redis.scan_iter(match=pattern):
            key_s = key.decode('utf-8') if isinstance(key, bytes) else key
            if key_s == pkeys_key:
                continue
            _, _, field = key_s.partition('#')
            if field:
                yield field

    def list_keys(self, keyword: str = '*', count: int | None = None) -> list[str]:
        out = []
        for field in self:
            if keyword == '*' or fnmatch(field, keyword):
                out.append(field)
                if count is not None and len(out) >= count:
                    break
        return out

    def incrby(self, field: str, value: int) -> int:
        return int(self.cache._redis.incrby(self.get_hash(field), value))

    async def async_incrby(self, field: str, value: int) -> int:
        r = self.cache._get_async()
        return int(await r.incrby(self.get_hash(field), value))
