"""CLI interface for talaria."""
from __future__ import annotations

import json
import os
import sys

import click
from rich.console import Console
from rich.table import Table

from talaria import __version__
from talaria.effort import effort_choices, effort_help_text

console = Console()


@click.group()
@click.version_option(version=__version__)
def cli():
    """talaria - Hermes\' winged sandals. Dispatch tasks through session-billed CLI backends."""
    pass


@cli.command()
@click.argument("task")
@click.option("--workdir", "-w", default=".", help="Working directory for the task.")
@click.option("--model", "-m", default=None, help="Model to use (default: opus).")
@click.option("--effort", "-e", default=None, type=click.Choice(effort_choices(), case_sensitive=False), help=f"{effort_help_text()} Default: config value.")
@click.option("--max-turns", default=None, type=int, help="Max agent turns (default: 20).")
@click.option("--timeout", "-t", default=None, type=int, help="Timeout in seconds (default: 300).")
@click.option("--max-budget", default=None, type=float, help="Max USD per task (default: 2.00).")
@click.option("--worktree", is_flag=True, help="Isolate in a git worktree.")
@click.option("--verify", default=None, help="Post-dispatch verification command.")
@click.option("--mcp-config", default=None, help="Path to MCP config file.")
@click.option("--context", default=None, help="Additional task context string.")
@click.option("--allowed-tools", default=None, help="Comma-separated allowed tools.")
@click.option("--skill", "-s", "skills", multiple=True, help="Skill name or path to inject (repeatable).")
@click.option("--retries", default=1, type=int, help="Retry count for transient failures.")
@click.option("--stream", is_flag=True, help="Stream output in real-time.")
@click.option("--json-output", is_flag=True, help="Output result as JSON.")
def run(task, workdir, model, effort, max_turns, timeout, max_budget, worktree,
        verify, mcp_config, context, allowed_tools, skills, retries, stream, json_output):
    """Dispatch a task to the CLI backend."""
    from talaria.runner import dispatch

    tools = allowed_tools.split(",") if allowed_tools else None
    skill_list = list(skills) if skills else None

    if not json_output:
        console.print(f"[dim]Dispatching: {task[:80]}...[/dim]")

    result = dispatch(
        task=task,
        workdir=os.path.abspath(workdir),
        model=model,
        max_turns=max_turns,
        max_budget_usd=max_budget,
        timeout=timeout,
        allowed_tools=tools,
        mcp_config=mcp_config,
        streaming=stream,
        worktree=worktree,
        context=context,
        verify_command=verify,
        retries=retries,
        skills=skill_list,
        effort=effort,
    )

    if json_output:
        output = {
            "success": result.success,
            "result": result.result,
            "session_id": result.session_id,
            "turns": result.turns_used,
            "cost_usd": result.cost_usd,
            "duration_seconds": result.duration_seconds,
            "discoveries": result.discoveries,
            "files_read": result.files_read,
            "files_modified": result.files_modified,
            "convention_proposals": result.convention_proposals,
            "verified": result.verified,
            "error": result.error,
            "log_path": result.log_path,
        }
        click.echo(json.dumps(output, indent=2))
    else:
        if result.success:
            console.print(f"\n[green bold]\u2713 Success[/green bold] ({result.turns_used} turns, ${result.cost_usd:.2f}, {result.duration_seconds:.0f}s)")
            if result.result:
                console.print(f"\n{result.result[:2000]}")
            if result.discoveries:
                console.print("\n[yellow bold]Discoveries:[/yellow bold]")
                for d in result.discoveries:
                    console.print(f"  - {d}")
            if result.verified is not None:
                status = "[green]\u2713 passed[/green]" if result.verified else "[red]\u2717 failed[/red]"
                console.print(f"\nVerification: {status}")
        else:
            console.print(f"\n[red bold]\u2717 Failed[/red bold]: {result.error}")

    sys.exit(0 if result.success else 1)


@cli.command()
def doctor():
    """Check system health and readiness."""
    from talaria.preflight import check_health

    console.print("[bold]Running health checks...[/bold]\n")
    health = check_health(cache_ttl=0)  # Force fresh check

    # Auth
    auth_icon = "\u2713" if health.auth_ok else "\u2717"
    auth_color = "green" if health.auth_ok else "red"
    console.print(f"  [{auth_color}]{auth_icon}[/{auth_color}] Auth: {'OK' if health.auth_ok else 'FAILED'}")

    # Version
    if health.backend_version:
        v_icon = "\u26a0" if health.version_changed else "\u2713"
        v_color = "yellow" if health.version_changed else "green"
        console.print(f"  [{v_color}]{v_icon}[/{v_color}] Backend: {health.backend_version}")
    else:
        console.print("  [red]\u2717[/red] Backend: not found")

    # Disk
    d_icon = "\u2713" if health.disk_ok else "\u26a0"
    d_color = "green" if health.disk_ok else "yellow"
    console.print(f"  [{d_color}]{d_icon}[/{d_color}] Disk: {'OK' if health.disk_ok else 'Low'}")

    # Warnings
    for w in health.warnings:
        console.print(f"  [yellow]\u26a0 {w}[/yellow]")

    # Errors
    for e in health.errors:
        console.print(f"  [red]\u2717 {e}[/red]")

    console.print()
    if health.healthy:
        console.print("[green bold]Ready to dispatch.[/green bold]")
    else:
        console.print("[red bold]Not ready. Fix errors above.[/red bold]")
        sys.exit(1)


@cli.command()
def status():
    """Show current status: circuit breaker, locks, config."""
    from talaria.config import TalariaConfig, LOCKS_DIR
    from talaria.tracker import summarize_usage

    config = TalariaConfig.load()
    usage = summarize_usage(since_hours=24.0)

    table = Table(title="talaria status")
    table.add_column("Setting", style="bold")
    table.add_column("Value")

    table.add_row("Default model", config.default_model)
    table.add_row("Max parallel", str(config.max_parallel))
    table.add_row("Daily budget", f"${config.daily_budget_usd:.2f}")
    table.add_row("Today\'s spend", f"${usage.total_cost_usd:.2f}")
    table.add_row("Today\'s dispatches", f"{usage.total_dispatches} ({usage.successful} ok, {usage.failed} failed)")
    table.add_row("Conventions", config.conventions_file or "(none)")
    table.add_row("MCP config", config.mcp_config or "(none)")

    # Active locks
    lock_count = 0
    if LOCKS_DIR.exists():
        lock_count = len(list(LOCKS_DIR.glob("*.lock")))
    table.add_row("Active locks", str(lock_count))

    console.print(table)


@cli.group()
def usage():
    """View dispatch usage and costs."""
    pass


@usage.command("today")
def usage_today():
    """Show today\'s usage."""
    from talaria.tracker import summarize_usage
    s = summarize_usage(since_hours=24.0)
    console.print(f"Dispatches: {s.total_dispatches} ({s.successful} ok, {s.failed} failed)")
    console.print(f"Total cost: ${s.total_cost_usd:.2f}")
    console.print(f"Avg cost: ${s.avg_cost_usd:.2f}")
    console.print(f"Avg duration: {s.avg_duration_seconds:.0f}s")


@usage.command("week")
def usage_week():
    """Show this week\'s usage."""
    from talaria.tracker import summarize_usage
    s = summarize_usage(since_hours=168.0)
    console.print(f"Dispatches: {s.total_dispatches} ({s.successful} ok, {s.failed} failed)")
    console.print(f"Total cost: ${s.total_cost_usd:.2f}")
    console.print(f"Avg cost: ${s.avg_cost_usd:.2f}")
    console.print(f"Avg duration: {s.avg_duration_seconds:.0f}s")


@cli.group()
def logs():
    """View dispatch logs."""
    pass


@logs.command("today")
def logs_today():
    """List today\'s dispatches."""
    from talaria.logger import list_logs
    entries = list_logs(days=1)
    if not entries:
        console.print("[dim]No dispatches today.[/dim]")
        return
    for e in entries:
        status = "[green]\u2713[/green]" if e.get("success") else "[red]\u2717[/red]"
        console.print(f"  {status} {e.get('timestamp', '?')[:19]} | {e.get('task', '?')[:60]} | {e.get('duration_seconds', 0):.0f}s")


@logs.command("failures")
def logs_failures():
    """Show only failed dispatches."""
    from talaria.logger import list_logs
    entries = list_logs(days=7, failures_only=True)
    if not entries:
        console.print("[dim]No failures in the last 7 days.[/dim]")
        return
    for e in entries:
        console.print(f"  [red]\u2717[/red] {e.get('timestamp', '?')[:19]} | {e.get('task', '?')[:60]}")


@cli.group()
def config():
    """Manage configuration."""
    pass


@config.command("show")
def config_show():
    """Show current configuration."""
    from dataclasses import asdict
    from talaria.config import TalariaConfig
    cfg = TalariaConfig.load()
    for key, value in asdict(cfg).items():
        console.print(f"  [bold]{key}[/bold]: {value}")


@config.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key, value):
    """Set a configuration value."""
    from talaria.config import TalariaConfig
    cfg = TalariaConfig.load()
    try:
        cfg.set_value(key, value)
        console.print(f"[green]\u2713[/green] {key} = {value}")
    except KeyError as e:
        console.print(f"[red]\u2717[/red] {e}")
        sys.exit(1)


class TaskParamType(click.ParamType):
    """Custom param type that collects --task values."""
    name = "task"


@cli.command("batch")
@click.option("--task", "-t", "tasks", multiple=True, required=True, help="Task to dispatch (repeatable).")
@click.option("--workdir", "-w", "workdirs", multiple=True, help="Working directory per task (repeatable, or one for all).")
@click.option("--model", "-m", default=None, help="Model for all tasks.")
@click.option("--max-parallel", default=None, type=int, help="Max concurrent dispatches.")
@click.option("--json-output", is_flag=True, help="Output results as JSON.")
def batch(tasks, workdirs, model, max_parallel, json_output):
    """Dispatch multiple tasks in parallel."""
    from talaria.batch import batch_dispatch

    # Build task list
    task_list = []
    for i, task_str in enumerate(tasks):
        wd = "."
        if workdirs:
            wd = workdirs[i] if i < len(workdirs) else workdirs[-1]
        task_dict = {"task": task_str, "workdir": os.path.abspath(wd)}
        if model:
            task_dict["model"] = model
        task_list.append(task_dict)

    if not json_output:
        console.print(f"[dim]Dispatching {len(task_list)} tasks (max {max_parallel or 3} parallel)...[/dim]")

    result = batch_dispatch(task_list, max_parallel=max_parallel)

    if json_output:
        output = {
            "total": result.total,
            "successful": result.successful,
            "failed": result.failed,
            "duration_seconds": result.duration_seconds,
            "total_cost_usd": result.total_cost_usd,
            "results": [
                {
                    "success": r.success,
                    "result": r.result,
                    "session_id": r.session_id,
                    "turns": r.turns_used,
                    "cost_usd": r.cost_usd,
                    "duration_seconds": r.duration_seconds,
                    "discoveries": r.discoveries,
                    "files_modified": r.files_modified,
                    "error": r.error,
                }
                for r in result.results
            ],
        }
        click.echo(json.dumps(output, indent=2))
    else:
        console.print(f"\n[bold]Batch complete:[/bold] {result.successful}/{result.total} succeeded in {result.duration_seconds:.0f}s (${result.total_cost_usd:.2f})\n")
        for i, r in enumerate(result.results):
            task_name = tasks[i][:60]
            if r.success:
                console.print(f"  [green]\u2713[/green] {task_name} ({r.turns_used} turns, ${r.cost_usd:.2f})")
                if r.discoveries:
                    for d in r.discoveries:
                        console.print(f"    [yellow]> {d}[/yellow]")
            else:
                console.print(f"  [red]\u2717[/red] {task_name}: {r.error}")

    sys.exit(0 if result.failed == 0 else 1)


@cli.command()
@click.option("--force", is_flag=True, help="Overwrite existing skill installation.")
def setup(force):
    """Set up talaria for your agent framework. Installs skill, creates conventions file, verifies health."""
    from talaria.setup_cmd import run_setup

    console.print("[bold]Setting up talaria...[/bold]\n")
    results = run_setup(force=force)

    # Skill
    skill = results["skill"]
    if skill["success"]:
        console.print(f"  [green]\u2713[/green] Skill: {skill['message']}")
    else:
        console.print(f"  [red]\u2717[/red] Skill: {skill['message']}")

    # Conventions
    conv = results["conventions"]
    if conv["created"]:
        console.print(f"  [green]\u2713[/green] Conventions: created at {conv['path']}")
    else:
        console.print(f"  [dim]\u2713[/dim] Conventions: already exists at {conv['path']}")

    # Config
    if results["config"]["created"]:
        console.print("  [green]\u2713[/green] Config: created with defaults")
    else:
        console.print("  [dim]\u2713[/dim] Config: already exists")

    # Health
    health = results["health"]
    if health and health.healthy:
        console.print(f"  [green]\u2713[/green] Health: {health.summary()}")
    elif health:
        console.print(f"  [red]\u2717[/red] Health: {health.summary()}")
        for e in health.errors:
            console.print(f"    [red]{e}[/red]")

    console.print()
    if results["skill"]["success"] and health and health.healthy:
        console.print("[green bold]Setup complete. Your agent will now use talaria for delegated tasks.[/green bold]")
    else:
        console.print("[yellow]Setup partially complete. Fix any errors above.[/yellow]")


@cli.command()
@click.option("--dry-run", is_flag=True, help="Print the upgrade command without running it.")
@click.option("--skip-setup", is_flag=True, help="Skip re-running talaria setup after upgrading.")
def update(dry_run, skip_setup):
    """Upgrade talaria in the current Python environment and refresh setup."""
    from talaria.updater import format_update_command, run_update

    result = run_update(dry_run=dry_run, skip_setup=skip_setup)
    command_text = format_update_command(result.command)

    if result.latest_version:
        click.echo(f"Current: {result.current_version} | Latest: {result.latest_version}")
    else:
        click.echo(f"Current: {result.current_version} | Latest: unknown")

    click.echo(f"Upgrade command: {command_text}")

    if dry_run:
        if not skip_setup:
            click.echo("After upgrade: talaria setup --force")
        return

    if result.update_available is False:
        console.print("[green]✓[/green] No newer published build found for this environment")
        return

    if not result.success:
        console.print(f"[red]✗[/red] Update failed: {result.error}")
        if result.pip_output:
            console.print(result.pip_output[-2000:])
        sys.exit(1)

    console.print("[green]✓[/green] Upgrade installed")
    if not skip_setup:
        console.print(f"[green]✓[/green] Setup refreshed: {result.setup_output}")
    console.print("[yellow]Restart any long-lived agent/session so it picks up the new code.[/yellow]")


@cli.command()
@click.argument("session_id")
@click.option("--task", "-t", default="Continue where you left off.", help="Follow-up task prompt.")
@click.option("--workdir", "-w", default=".", help="Working directory.")
@click.option("--json-output", is_flag=True, help="Output result as JSON.")
def resume(session_id, task, workdir, json_output):
    """Resume a previous dispatch session by ID."""
    import shutil
    import subprocess
    import time

    backend = shutil.which("claude")
    if not backend:
        console.print("[red]\u2717 Backend not found[/red]")
        sys.exit(1)

    cmd = [
        backend, "-p", task,
        "--resume", session_id,
        "--output-format", "json",
        "--max-turns", "20",
        "--dangerously-skip-permissions",
    ]

    if not json_output:
        console.print(f"[dim]Resuming session {session_id[:12]}...[/dim]")

    start = time.time()
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=300, cwd=os.path.abspath(workdir),
        )
        duration = time.time() - start
        stdout = proc.stdout.strip()
        first_line = stdout.split("\n")[0] if stdout else ""

        try:
            data = json.loads(first_line)
            result_text = data.get("result", "")
            success = data.get("subtype") == "success"
        except json.JSONDecodeError:
            result_text = stdout[:2000]
            success = proc.returncode == 0
            data = {}

        if json_output:
            click.echo(json.dumps({
                "success": success,
                "result": result_text,
                "session_id": session_id,
                "duration_seconds": duration,
                "cost_usd": data.get("total_cost_usd", 0),
            }, indent=2))
        else:
            if success:
                console.print(f"\n[green bold]\u2713 Resumed[/green bold] ({duration:.0f}s)")
                if result_text:
                    console.print(f"\n{result_text[:2000]}")
            else:
                console.print(f"\n[red bold]\u2717 Failed[/red bold]: {result_text[:500]}")

    except subprocess.TimeoutExpired:
        console.print("[red]\u2717 Resume timed out[/red]")
        sys.exit(1)

    sys.exit(0 if success else 1)


@cli.command("skills")
@click.option("--dirs", default=None, help="Comma-separated skill directories to search.")
def skills_list(dirs):
    """List available skills that can be injected into dispatches."""
    from talaria.config import TalariaConfig
    from talaria.skills import list_available_skills

    config = TalariaConfig.load()
    search_dirs = dirs.split(",") if dirs else config.skills_dirs
    skills = list_available_skills(search_dirs)

    if not skills:
        console.print("[dim]No skills found.[/dim]")
        console.print(f"[dim]Searched: {', '.join(search_dirs)}[/dim]")
        return

    table = Table(title=f"Available Skills ({len(skills)})")
    table.add_column("Name", style="bold")
    table.add_column("Path", style="dim")

    for s in skills:
        table.add_row(s["name"], s["path"])

    console.print(table)
    console.print("\n[dim]Use: talaria run \"task\" --skill <name>[/dim]")


# ─── Cron Commands ──────────────────────────────────────────────────


@cli.group()
def cron():
    """Schedule recurring dispatches on session billing."""
    pass


@cron.command("add")
@click.argument("name")
@click.argument("task")
@click.option("--schedule", "-s", required=True, help="Schedule: '30m', 'every 2h', 'daily', or cron expression '0 9 * * *'.")
@click.option("--workdir", "-w", default=".", help="Working directory.")
@click.option("--model", "-m", default=None, help="Model to use.")
@click.option("--skill", "skills", multiple=True, help="Skill name or path (repeatable).")
@click.option("--verify", default=None, help="Post-dispatch verification command.")
@click.option("--allowed-tools", default=None, help="Comma-separated allowed tools.")
@click.option("--mcp-config", default=None, help="Path to MCP config file.")
@click.option("--context", default=None, help="Additional task context.")
@click.option("--max-turns", default=None, type=int, help="Max agent turns.")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds.")
def cron_add(name, task, schedule, workdir, model, skills, verify,
             allowed_tools, mcp_config, context, max_turns, timeout):
    """Add a new scheduled dispatch job."""
    from talaria.cron import add_job, parse_interval, parse_cron_expression

    # Validate schedule
    if not parse_interval(schedule) and not parse_cron_expression(schedule):
        console.print(f"[red]✗ Invalid schedule:[/red] '{schedule}'")
        console.print("[dim]Examples: '30m', 'every 2h', 'daily', '0 9 * * *'[/dim]")
        sys.exit(1)

    tools = allowed_tools.split(",") if allowed_tools else []

    job = add_job(
        name=name,
        task=task,
        schedule=schedule,
        workdir=os.path.abspath(workdir),
        model=model,
        skills=list(skills) if skills else [],
        allowed_tools=tools,
        verify=verify,
        mcp_config=mcp_config,
        context=context,
        max_turns=max_turns,
        timeout=timeout,
    )

    console.print(f"[green bold]✓ Created job[/green bold] {job.id} ({job.name})")
    console.print(f"  Schedule: {job.schedule}")
    console.print(f"  Task: {job.task[:80]}")
    if job.skills:
        console.print(f"  Skills: {', '.join(job.skills)}")


@cron.command("list")
@click.option("--json-output", is_flag=True, help="Output as JSON.")
def cron_list(json_output):
    """List all scheduled jobs."""
    from talaria.cron import load_jobs

    jobs = load_jobs()

    if json_output:
        click.echo(json.dumps([j.to_dict() for j in jobs], indent=2))
        return

    if not jobs:
        console.print("[dim]No cron jobs configured.[/dim]")
        console.print("[dim]Add one: talaria cron add \"my-job\" \"task description\" --schedule 2h[/dim]")
        return

    table = Table(title=f"Cron Jobs ({len(jobs)})")
    table.add_column("ID", style="bold")
    table.add_column("Name")
    table.add_column("Schedule")
    table.add_column("Status")
    table.add_column("Last Run")
    table.add_column("Runs")
    table.add_column("Task", max_width=40)

    for job in jobs:
        status = "[green]enabled[/green]" if job.enabled else "[red]disabled[/red]"
        last = job.last_run[:16] if job.last_run else "never"
        result_icon = ""
        if job.last_result == "success":
            result_icon = " [green]✓[/green]"
        elif job.last_result == "failure":
            result_icon = " [red]✗[/red]"
        runs = f"{job.run_count} ({job.fail_count} failed)" if job.fail_count else str(job.run_count)
        table.add_row(job.id, job.name, job.schedule, status, f"{last}{result_icon}", runs, job.task[:40])

    console.print(table)


@cron.command("remove")
@click.argument("job_id")
def cron_remove(job_id):
    """Remove a scheduled job by ID."""
    from talaria.cron import remove_job

    if remove_job(job_id):
        console.print(f"[green]✓[/green] Removed job {job_id}")
    else:
        console.print(f"[red]✗[/red] Job {job_id} not found")
        sys.exit(1)


@cron.command("enable")
@click.argument("job_id")
def cron_enable(job_id):
    """Enable a disabled job."""
    from talaria.cron import set_enabled

    job = set_enabled(job_id, True)
    if job:
        console.print(f"[green]✓[/green] Enabled {job.name} ({job_id})")
    else:
        console.print(f"[red]✗[/red] Job {job_id} not found")
        sys.exit(1)


@cron.command("disable")
@click.argument("job_id")
def cron_disable(job_id):
    """Disable a job without removing it."""
    from talaria.cron import set_enabled

    job = set_enabled(job_id, False)
    if job:
        console.print(f"[yellow]⏸[/yellow] Disabled {job.name} ({job_id})")
    else:
        console.print(f"[red]✗[/red] Job {job_id} not found")
        sys.exit(1)


@cron.command("run")
@click.argument("job_id")
@click.option("--json-output", is_flag=True, help="Output result as JSON.")
def cron_run(job_id, json_output):
    """Manually run a specific job now (ignores schedule)."""
    from talaria.cron import get_job, record_run
    from talaria.runner import dispatch

    job = get_job(job_id)
    if not job:
        console.print(f"[red]✗[/red] Job {job_id} not found")
        sys.exit(1)

    if not json_output:
        console.print(f"[dim]Running: {job.name} ({job.task[:60]})...[/dim]")

    result = dispatch(
        task=job.task,
        workdir=job.workdir,
        model=job.model,
        effort=job.effort,
        skills=job.skills or None,
        allowed_tools=job.allowed_tools or None,
        verify_command=job.verify,
        mcp_config=job.mcp_config,
        context=job.context,
        max_turns=job.max_turns,
        timeout=job.timeout,
    )

    record_run(job_id, result.success)

    if json_output:
        output = {
            "job_id": job_id,
            "job_name": job.name,
            "success": result.success,
            "result": result.result,
            "discoveries": result.discoveries,
            "error": result.error,
            "duration_seconds": result.duration_seconds,
            "cost_usd": result.cost_usd,
        }
        click.echo(json.dumps(output, indent=2))
    else:
        if result.success:
            console.print(f"[green bold]✓ {job.name}[/green bold] ({result.turns_used} turns, {result.duration_seconds:.0f}s)")
            if result.discoveries:
                for d in result.discoveries:
                    console.print(f"  [yellow]> {d}[/yellow]")
        else:
            console.print(f"[red bold]✗ {job.name}:[/red bold] {result.error}")

    sys.exit(0 if result.success else 1)


@cron.command("run-due")
@click.option("--json-output", is_flag=True, help="Output results as JSON.")
@click.option("--dry-run", is_flag=True, help="Show what would run without running it.")
def cron_run_due(json_output, dry_run):
    """Run all jobs that are currently due. Call this from system crontab.

    Example system crontab entry (check every minute):
      * * * * * /path/to/talaria cron run-due --json-output >> ~/.config/talaria/cron.log 2>&1
    """
    from talaria.cron import get_due_jobs, record_run
    from talaria.runner import dispatch

    due = get_due_jobs()

    if not due:
        if not json_output:
            console.print("[dim]No jobs due.[/dim]")
        else:
            click.echo(json.dumps({"jobs_run": 0, "results": []}))
        return

    if dry_run:
        console.print(f"[bold]{len(due)} job(s) due:[/bold]")
        for job in due:
            console.print(f"  {job.id} {job.name} — {job.task[:60]}")
        return

    results = []
    for job in due:
        if not json_output:
            console.print(f"[dim]Running: {job.name}...[/dim]")

        result = dispatch(
            task=job.task,
            workdir=job.workdir,
            model=job.model,
            effort=job.effort,
            skills=job.skills or None,
            allowed_tools=job.allowed_tools or None,
            verify_command=job.verify,
            mcp_config=job.mcp_config,
            context=job.context,
            max_turns=job.max_turns,
            timeout=job.timeout,
        )

        record_run(job.id, result.success)

        results.append({
            "job_id": job.id,
            "job_name": job.name,
            "success": result.success,
            "result": result.result[:500],
            "error": result.error,
            "duration_seconds": result.duration_seconds,
        })

        if not json_output:
            icon = "[green]✓[/green]" if result.success else "[red]✗[/red]"
            console.print(f"  {icon} {job.name} ({result.duration_seconds:.0f}s)")

    if json_output:
        click.echo(json.dumps({
            "jobs_run": len(results),
            "results": results,
        }, indent=2))

    failed = sum(1 for r in results if not r["success"])
    sys.exit(1 if failed else 0)


@cron.command("install")
def cron_install():
    """Show system crontab entry to automate run-due.

    Copy the printed line into your crontab (crontab -e) to check for
    due jobs every minute. Each job then follows its own schedule.
    """
    import shutil
    talaria_bin = shutil.which("talaria")
    if not talaria_bin:
        console.print("[red]✗ talaria not found on PATH[/red]")
        sys.exit(1)

    console.print("[bold]Add this to your crontab[/bold] (crontab -e):\n")
    console.print(f"  * * * * * {talaria_bin} cron run-due --json-output >> ~/.config/talaria/cron.log 2>&1")
    console.print("\n[dim]This checks every minute; each job follows its own schedule.[/dim]")
    console.print("[dim]Logs go to ~/.config/talaria/cron.log[/dim]")


# ─── Slash Command Interface ────────────────────────────────────────


@cli.command("command")
@click.argument("text")
@click.option("--json-output", is_flag=True, help="Output as JSON (for bot integrations).")
def command_handler(text, json_output):
    """Execute a slash command string. For chat platform integrations.

    Any bot can pipe user messages through this:
      talaria command "/dispatch Fix the auth bug --effort high"
      talaria command "/talaria status"
      talaria command "/t cron list"

    Returns structured output suitable for any chat platform.
    """
    from talaria.commands import execute_command

    result = execute_command(text)

    if json_output:
        click.echo(json.dumps(result, indent=2))
    else:
        console.print(result["response"])

    sys.exit(0 if result["success"] else 1)


# ─── Purge Command ──────────────────────────────────────────────────


@cli.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def purge(yes):
    """Remove all talaria data: config, logs, usage tracking, locks, and cache.

    This is the nuclear option. After purging, talaria is as if it was never installed.
    Run `pip uninstall talaria` afterward to remove the package itself.
    """
    import shutil
    from talaria.config import CONFIG_DIR

    targets = []
    if CONFIG_DIR.exists():
        for item in sorted(CONFIG_DIR.iterdir()):
            targets.append(item)

    if not targets and not CONFIG_DIR.exists():
        console.print("[dim]Nothing to clean — talaria data directory doesn't exist.[/dim]")
        return

    console.print("[bold]The following will be deleted:[/bold]\n")
    total_size = 0
    for item in targets:
        if item.is_dir():
            size = sum(f.stat().st_size for f in item.rglob("*") if f.is_file())
            count = sum(1 for f in item.rglob("*") if f.is_file())
            console.print(f"  📁 {item.name}/ ({count} files, {_human_size(size)})")
        else:
            size = item.stat().st_size
            console.print(f"  📄 {item.name} ({_human_size(size)})")
        total_size += size

    console.print(f"\n  [bold]Total:[/bold] {_human_size(total_size)} at {CONFIG_DIR}")

    if not yes:
        click.confirm("\nProceed with purge?", abort=True)

    try:
        shutil.rmtree(CONFIG_DIR)
        console.print(f"\n[green bold]✓ Purged[/green bold] {CONFIG_DIR}")
        console.print("[dim]Run `pip uninstall talaria` to remove the package.[/dim]")
    except Exception as e:
        console.print(f"\n[red bold]✗ Failed:[/red bold] {e}")
        sys.exit(1)


def _human_size(size_bytes: int) -> str:
    """Format bytes as human-readable size."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.0f} {unit}" if unit == "B" else f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


if __name__ == "__main__":
    cli()
