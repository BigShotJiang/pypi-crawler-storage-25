"""talaria - Hermes' winged sandals. Dispatch AI agent tasks through session-billed CLI backends."""
from __future__ import annotations

__version__ = "0.2.7"

from talaria.runner import dispatch, dispatch_stream
from talaria.preflight import check_health
from talaria.batch import batch_dispatch

__all__ = ["dispatch", "dispatch_stream", "check_health", "batch_dispatch", "__version__"]
