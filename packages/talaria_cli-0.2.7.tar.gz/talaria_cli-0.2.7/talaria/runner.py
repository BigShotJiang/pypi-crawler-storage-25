"""Core task runner - dispatches work through CLI backend."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import AsyncIterator, Optional

from talaria.concurrency import acquire_lock, release_lock
from talaria.config import TalariaConfig, ensure_dirs
from talaria.context import build_context_file
from talaria.effort import get_supported_efforts, normalize_effort_for_backend
from talaria.feedback import TaskFeedback, parse_feedback
from talaria.logger import save_dispatch_log
from talaria.preflight import check_health, invalidate_auth_cache
from talaria.tracker import CircuitBreaker, UsageEntry, log_usage
from talaria.verify import run_verification
from talaria.worktree import create_worktree, remove_worktree, is_git_repo


@dataclass
class TaskResult:
    """Complete result from a dispatched task."""
    success: bool
    result: str
    session_id: str = ""
    turns_used: int = 0
    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    files_read: list = field(default_factory=list)
    files_modified: list = field(default_factory=list)
    discoveries: list = field(default_factory=list)
    convention_proposals: list = field(default_factory=list)
    verified: Optional[bool] = None
    verify_output: str = ""
    error: Optional[str] = None
    stderr: str = ""
    raw_json: dict = field(default_factory=dict)
    log_path: str = ""
    worktree_path: Optional[str] = None


def _find_backend() -> Optional[str]:
    return shutil.which("claude")


def _build_command(
    backend: str,
    task: str,
    model: str,
    max_turns: int,
    max_budget_usd: float,
    allowed_tools: list,
    mcp_config: Optional[str],
    context_file: Optional[str],
    streaming: bool,
    effort: Optional[str] = None,
) -> list:
    """Build the CLI command for dispatch."""
    cmd = [
        backend, "-p", task,
        "--output-format", "stream-json" if streaming else "json",
        "--max-turns", str(max_turns),
        "--model", model,
        "--dangerously-skip-permissions",
    ]

    if max_budget_usd > 0:
        cmd.extend(["--max-budget-usd", str(max_budget_usd)])

    if allowed_tools:
        cmd.extend(["--allowedTools"] + allowed_tools)

    if mcp_config:
        cmd.extend(["--mcp-config", mcp_config])

    if effort:
        cmd.extend(["--effort", effort])

    if context_file:
        cmd.extend(["--append-system-prompt-file", context_file])

    if streaming:
        cmd.append("--verbose")

    return cmd


def dispatch(
    task: str,
    workdir: str = ".",
    model: Optional[str] = None,
    max_turns: Optional[int] = None,
    max_budget_usd: Optional[float] = None,
    timeout: Optional[int] = None,
    allowed_tools: Optional[list] = None,
    mcp_config: Optional[str] = None,
    streaming: bool = False,
    worktree: bool = False,
    context: Optional[str] = None,
    verify_command: Optional[str] = None,
    retries: int = 1,
    skills: Optional[list] = None,
    effort: Optional[str] = None,
) -> TaskResult:
    """
    Dispatch a task through the CLI backend.
    This is the main entry point for talaria.
    """
    config = TalariaConfig.load()
    ensure_dirs()

    # Apply defaults
    model = model or config.default_model
    effort = effort or config.default_effort
    max_turns = max_turns or config.default_max_turns
    max_budget_usd = max_budget_usd if max_budget_usd is not None else config.default_max_budget_usd
    timeout = timeout or config.default_timeout
    allowed_tools = allowed_tools or config.default_allowed_tools
    mcp_config = mcp_config or config.mcp_config

    # Translate tool names (accepts both Hermes-style and Claude Code-style)
    from talaria.tools import translate_tools
    allowed_tools = translate_tools(allowed_tools)
    effort = normalize_effort_for_backend(effort, get_supported_efforts())

    # Resolve skills
    skills_content = None
    if skills:
        from talaria.skills import resolve_skills, format_skills_context
        try:
            resolved = resolve_skills(skills, config.skills_dirs)
            skills_content = format_skills_context(resolved)
        except FileNotFoundError as e:
            return TaskResult(success=False, result="", error=str(e))

    # Circuit breaker
    breaker = CircuitBreaker(config)
    ok, msg = breaker.can_dispatch()
    if not ok:
        return TaskResult(success=False, result="", error=f"Circuit breaker: {msg}")

    # Preflight
    health = check_health(workdir, config.auth_cache_ttl_seconds)
    if not health.healthy:
        return TaskResult(success=False, result="", error=f"Preflight failed: {health.summary()}")

    # Find backend
    backend = _find_backend()
    if not backend:
        return TaskResult(success=False, result="", error="CLI backend not found")

    # Directory lock
    workdir = os.path.abspath(workdir)
    lock_id = acquire_lock(workdir, timeout=10.0)
    if not lock_id:
        return TaskResult(
            success=False, result="",
            error=f"Could not acquire lock on {workdir} (another dispatch is running)"
        )

    # Worktree isolation
    actual_workdir = workdir
    wt_path = None
    if worktree and is_git_repo(workdir):
        wt_path = create_worktree(workdir)
        if wt_path:
            actual_workdir = wt_path

    # Build context
    context_file = build_context_file(config, actual_workdir, context, skills_content)

    try:
        result = _execute_with_retries(
            backend=backend,
            task=task,
            workdir=actual_workdir,
            model=model,
            max_turns=max_turns,
            max_budget_usd=max_budget_usd,
            timeout=timeout,
            allowed_tools=allowed_tools,
            mcp_config=mcp_config,
            context_file=context_file,
            streaming=streaming,
            retries=retries,
            config=config,
            effort=effort,
        )

        # Post-dispatch verification
        if verify_command and result.success:
            vr = run_verification(verify_command, actual_workdir)
            result.verified = vr.verified
            result.verify_output = vr.output

        # Track usage
        breaker.record_result(result.success)
        _log_result(result, task, workdir, model)

        result.worktree_path = wt_path
        return result

    finally:
        # Cleanup context file
        if context_file and os.path.exists(context_file):
            try:
                os.unlink(context_file)
            except OSError:
                pass

        # Cleanup worktree on failure
        if wt_path and not (result and result.success):
            remove_worktree(wt_path)

        # Release lock
        release_lock(workdir, lock_id)


def _execute_with_retries(
    backend: str,
    task: str,
    workdir: str,
    model: str,
    max_turns: int,
    max_budget_usd: float,
    timeout: int,
    allowed_tools: list,
    mcp_config: Optional[str],
    context_file: Optional[str],
    streaming: bool,
    retries: int,
    config: TalariaConfig,
    effort: Optional[str] = None,
) -> TaskResult:
    """Execute dispatch with retry logic."""
    last_error = None

    for attempt in range(retries + 1):
        if attempt > 0:
            # Exponential backoff
            time.sleep(2 ** attempt)
            # Re-check auth on retry
            invalidate_auth_cache()
            health = check_health(workdir, 0)
            if not health.healthy:
                last_error = f"Retry {attempt} preflight failed: {health.summary()}"
                continue

        result = _execute_once(
            backend=backend,
            task=task,
            workdir=workdir,
            model=model,
            max_turns=max_turns,
            max_budget_usd=max_budget_usd,
            timeout=timeout,
            allowed_tools=allowed_tools,
            mcp_config=mcp_config,
            context_file=context_file,
            streaming=streaming,
            effort=effort,
        )

        if result.success:
            return result

        # Only retry on transient errors
        error = result.error or ""
        transient = any(k in error.lower() for k in [
            "timeout", "401", "rate limit", "overloaded", "network",
            "connection", "503", "502",
        ])
        if not transient:
            return result

        last_error = result.error

    return TaskResult(
        success=False, result="",
        error=f"All {retries + 1} attempts failed. Last error: {last_error}",
    )


def _execute_once(
    backend: str,
    task: str,
    workdir: str,
    model: str,
    max_turns: int,
    max_budget_usd: float,
    timeout: int,
    allowed_tools: list,
    mcp_config: Optional[str],
    context_file: Optional[str],
    streaming: bool,
    effort: Optional[str] = None,
) -> TaskResult:
    """Execute a single dispatch attempt."""
    cmd = _build_command(
        backend, task, model, max_turns, max_budget_usd,
        allowed_tools, mcp_config, context_file, streaming, effort,
    )

    start = time.time()
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, cwd=workdir,
        )
        duration = time.time() - start
        stdout = proc.stdout.strip()
        stderr = proc.stderr.strip() if proc.stderr else ""

        return _parse_result(stdout, stderr, duration)

    except subprocess.TimeoutExpired:
        duration = time.time() - start
        return TaskResult(
            success=False, result="",
            duration_seconds=duration,
            error=f"Task timed out after {timeout}s",
        )
    except Exception as e:
        duration = time.time() - start
        return TaskResult(
            success=False, result="",
            duration_seconds=duration,
            error=str(e),
        )


def _parse_result(stdout: str, stderr: str, duration: float) -> TaskResult:
    """Parse CLI output into TaskResult."""
    # The JSON output may have hook errors after it
    first_line = stdout.split("\n")[0] if stdout else ""

    try:
        data = json.loads(first_line)
    except json.JSONDecodeError:
        # Try the full output
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            return TaskResult(
                success=False,
                result=stdout[:2000],
                stderr=stderr,
                duration_seconds=duration,
                error="Failed to parse backend output as JSON",
            )

    success = data.get("subtype") == "success"
    result_text = data.get("result", "")

    # Parse feedback from the result text
    feedback = parse_feedback(result_text) if result_text else TaskFeedback()

    # Extract usage info
    session_id = data.get("session_id", "")

    return TaskResult(
        success=success,
        result=result_text,
        session_id=session_id,
        turns_used=data.get("num_turns", 0),
        cost_usd=data.get("total_cost_usd", 0.0),
        duration_seconds=duration,
        files_read=feedback.files_read,
        files_modified=feedback.files_modified,
        discoveries=feedback.discoveries,
        convention_proposals=feedback.convention_proposals,
        stderr=stderr,
        raw_json=data,
    )


def _log_result(result: TaskResult, task: str, workdir: str, model: str) -> None:
    """Log dispatch result for tracking."""
    # Save detailed log
    result.log_path = save_dispatch_log(
        session_id=result.session_id,
        task=task,
        workdir=workdir,
        model=model,
        raw_json=result.raw_json,
        stderr=result.stderr,
        duration=result.duration_seconds,
        success=result.success,
    )

    # Track usage
    log_usage(UsageEntry(
        timestamp=datetime.now().isoformat(),
        task=task,
        model=model,
        cost_usd=result.cost_usd,
        turns=result.turns_used,
        duration_seconds=result.duration_seconds,
        session_id=result.session_id,
        success=result.success,
        workdir=workdir,
    ))


async def dispatch_stream(
    task: str,
    workdir: str = ".",
    **kwargs,
) -> AsyncIterator:
    """Streaming dispatch - yields output chunks as they arrive."""
    import asyncio

    config = TalariaConfig.load()
    backend = _find_backend()
    if not backend:
        yield "[ERROR] CLI backend not found"
        return

    model = kwargs.get("model") or config.default_model
    max_turns = kwargs.get("max_turns") or config.default_max_turns
    max_budget = kwargs.get("max_budget_usd", config.default_max_budget_usd)
    allowed_tools = kwargs.get("allowed_tools") or config.default_allowed_tools
    mcp_config = kwargs.get("mcp_config") or config.mcp_config
    effort = normalize_effort_for_backend(kwargs.get("effort") or config.default_effort, get_supported_efforts(backend))
    context_file = build_context_file(config, workdir, kwargs.get("context"))

    cmd = _build_command(
        backend, task, model, max_turns, max_budget,
        allowed_tools, mcp_config, context_file, streaming=True, effort=effort,
    )

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=workdir,
    )

    try:
        async for line in proc.stdout:
            decoded = line.decode().strip()
            if not decoded:
                continue
            try:
                event = json.loads(decoded)
                if event.get("type") == "assistant" and "message" in event:
                    content = event["message"].get("content", "")
                    if isinstance(content, str):
                        yield content
            except json.JSONDecodeError:
                yield decoded
    finally:
        if context_file and os.path.exists(context_file):
            try:
                os.unlink(context_file)
            except OSError:
                pass
