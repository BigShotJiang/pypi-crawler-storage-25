from __future__ import annotations

import inspect
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable, Mapping
from inspect import BoundArguments
from operator import attrgetter
from pathlib import Path
from typing import Any, Protocol, TypeVar, cast

import git
from git import Repo
from loguru import logger

from adiumentum.fp import identity
from adiumentum.path import PushInfoList
from adiumentum.timestamps import make_timestamp
from adiumentum.typing import ensure_tuple

C = TypeVar("C", bound=Callable)
type Getter = Callable[[object], Repo] | None
type MessageMaker = Callable[[Callable | str | None, BoundArguments | None, str | None], str]


class GitWrapperError(Exception): ...


class LoggerProtocol(Protocol):
    def debug(self, *args, **kwargs) -> None: ...
    def info(self, *args, **kwargs) -> None: ...
    def exception(self, *args, **kwargs) -> None: ...
    def warning(self, *args, **kwargs) -> None: ...


class GitWrapperBase(ABC):
    @abstractmethod
    def __call__(self, *args, **kwargs) -> Callable[[C], C]: ...

    @abstractmethod
    def wrap(self, *args, **kwargs) -> Callable[[C], C]: ...

    @abstractmethod
    def require_unchanged(self, *args, **kwargs) -> Callable[[C], C]: ...

    @abstractmethod
    def require_unchanged_except(self, *args, **kwargs) -> Callable[[C], C]: ...

    @staticmethod
    def default_message_maker(
        func: Callable | str | None,
        _: BoundArguments | None,
        timestamp: str | None = None,
    ) -> str:
        if isinstance(func, str):
            func_repr: str = f" while executing `{func}`"
        elif func is None:
            func_repr = ""
        else:
            func_repr = f" while executing `{func.__module__}.{func.__qualname__}`."
        return f"automatic commit by 'GitWrapper' at {timestamp or make_timestamp()}{func_repr}."

    @staticmethod
    def make_commit_message_maker(message_maker_maybe: MessageMaker | str | None) -> MessageMaker:
        if not message_maker_maybe:
            return GitWrapperBase.default_message_maker
        if isinstance(message_maker_maybe, str):

            def make_msg(*args, **kwargs) -> str:
                return message_maker_maybe

            return make_msg

        return message_maker_maybe

    @staticmethod
    def commit_data(
        repo: Repo,
        path_or_paths: Path | Iterable[Path] = tuple(),
        *,
        message: MessageMaker | str | None = None,
        func: Callable | str | None = None,
        push: bool = True,
        remote_name: str = "origin",
        remote_url: str | None = None,
        args: BoundArguments | None = None,
    ) -> tuple[git.Commit | None, PushInfoList | None]:
        for path in ensure_tuple(path_or_paths or repo.working_dir):
            repo.git.add(str(path))

        message_maker: MessageMaker = GitWrapperBase.make_commit_message_maker(message)
        message = message_maker(func, args, make_timestamp())

        commit = repo.index.commit(message)
        print("committed")

        push_info: PushInfoList | None = None
        if push:
            try:
                if remote_url:
                    remote = repo.create_remote(name=remote_name, url=remote_url)
                else:
                    remote = repo.remote(name=remote_name)
                push_info = remote.push()
            except Exception as e:
                logger.info(f"Push error: {e}")

        return commit, push_info

    @staticmethod
    def make_dirty_error(repo: Repo) -> GitWrapperError:
        msg = f"Repository at {repo.working_dir} is dirty; please commit changes and try again."
        return GitWrapperError(msg)

    @staticmethod
    def reset_to_last_commit(*, exc: Exception, funcname: str, repo: Repo) -> None:
        last_commit = next(repo.iter_commits())
        log_msg = (
            f"{exc.__class__} encountered when executing `{funcname}`; "
            f"performing a hard reset of the repository at {repo.working_dir} "
            f"to last commit: '{last_commit.hexsha[:7]}: {last_commit.summary}'."
        )
        logger.exception(log_msg)
        reset_message: str = repo.git.reset("--hard")
        logger.info(reset_message)
        logger.info(f"Untracked files: {repo.untracked_files}")
        raise exc

    def perform_commit_after(
        self,
        path_or_paths: Path | Iterable[Path] = tuple(),
        *,
        func: Callable | None,
        # maybe_commit: bool | str,
        push: bool,
        repo: Repo,
        message_maker: MessageMaker | str | None = None,
        args: BoundArguments,
        modname: str | None = None,
    ) -> None:
        # if maybe_commit and repo.is_dirty():
        # message = (  # TODO
        #     maybe_commit
        #     if isinstance(maybe_commit, str)
        #     else f"chore: back up unsaved changes after running {func.__qualname__}."
        # )
        self.commit_data(
            repo,
            path_or_paths,
            push=push,
            message=message_maker,
            func=func,
            args=args,
        )


class GitWrapperImplicit(GitWrapperBase):
    def __init__(self) -> None:
        pass

    def __call__(  # noqa: PLR0917
        self,
        param_name: str | None = None,
        getter: Getter = None,
        require_clean: bool = True,
        commit_after: str | bool = False,
        push: bool = False,
        verbose: bool = True,
        logger: LoggerProtocol = logger,
        message: MessageMaker | str | None = None,
    ) -> Callable[[C], C]:
        return self.wrap(
            param_name=param_name,
            getter=getter,
            require_clean=require_clean,
            commit_after=commit_after,
            push=push,
            verbose=verbose,
            logger=logger,
            message=message,
        )

    def wrap(  # noqa: PLR0917
        self,
        param_name: str | None = None,
        getter: Getter = None,
        require_clean: bool = True,
        commit_after: str | bool = False,
        push: bool = False,
        verbose: bool = True,
        logger: LoggerProtocol = logger,
        message: MessageMaker | str | None = None,
    ) -> Callable[[C], C]:
        def wrapper(func: C) -> C:
            name: str = func.__qualname__
            sig = inspect.signature(func)

            def inner(*args, **kwargs) -> Any:
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()

                repo = self.find_repo(
                    func,
                    bound_args=bound_args,
                    param_name=param_name,
                    getter=getter,
                    args_=args,
                    kwargs_=kwargs,
                    verbose=verbose,
                )

                if require_clean and repo.is_dirty():
                    raise self.make_dirty_error(repo)

                try:
                    logger.debug("running main try loop")
                    ret = func(*args, **kwargs)

                except Exception as e:
                    self.reset_to_last_commit(exc=e, funcname=name, repo=repo)
                    raise e

                if commit_after:
                    self.perform_commit_after(
                        repo=repo,
                        push=push,
                        message_maker=message,
                        func=func,
                        args=bound_args,
                    )

                return ret

            return cast(C, inner)

        return wrapper

    def require_unchanged(
        self,
        param_name: str | None = None,
        getter: Getter = None,
        verbose: bool = True,
        message: MessageMaker | str | None = None,  # TODO
    ) -> Callable[[C], C]:
        def wrapper(func: C) -> C:
            name: str = func.__qualname__
            sig = inspect.signature(func)

            def inner(*args, **kwargs) -> Any:
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()

                repo = self.find_repo(
                    func,
                    bound_args=bound_args,
                    param_name=param_name,
                    getter=getter,
                    args_=args,
                    kwargs_=kwargs,
                    verbose=verbose,
                )

                if repo.is_dirty():
                    raise self.make_dirty_error(repo)

                try:
                    ret = func(*args, **kwargs)
                    if repo.is_dirty():
                        raise self.make_dirty_error(repo)

                except Exception as e:
                    self.reset_to_last_commit(exc=e, funcname=name, repo=repo)
                    raise e

                return ret

            return cast(C, inner)

        return wrapper

    def require_unchanged_except(
        self,
        repo: Repo,
        ignore: Iterable[Path | str],
        verbose: bool = True,
    ) -> Callable[[C], C]:
        """Requires the repository to have no changes except to the specified files."""
        raise NotImplementedError
        # TODO: fold into require_unchanged as an 'ignore: tuple[Path, ...]' option?

    @staticmethod
    def find_repo(  # noqa: C901 ("too complex")
        f: Callable,
        *,
        bound_args: BoundArguments,
        param_name: str | None = None,
        getter: Getter = None,
        args_,
        kwargs_,
        verbose: bool = True,
    ) -> Repo:
        def walk_params(*, args_: Iterable[object], kwargs_: Mapping[str, object]) -> Repo:
            all_ = list(args_) + list(kwargs_.values())
            for arg in all_:
                if isinstance(arg, Repo):
                    return arg
            for arg in all_:
                if hasattr(arg, "repo"):
                    repo = getattr(arg, "repo", None)
                    if isinstance(repo, Repo):
                        return repo
            msg = (
                f"No parameter of {getattr(f, '__name__', '<unknown function>')} is of type 'Repo' "
                "or has an attribute 'repo' of type 'Repo'."
            )
            raise ValueError(msg)

        def _validate(param_name: str | None, getter: Getter) -> tuple[str | None, Getter]:
            if not param_name:
                return param_name, getter
            if "." in param_name:
                if getter:
                    msg = (
                        f"Parameter with attribute passed together with getter function:"
                        f" {param_name=}, {getter=}"
                    )
                    raise ValueError(msg)
                segments = param_name.split(".")
                if len(segments) > 2:
                    raise ValueError(f"Nested attributes not supported: {param_name}.")
                param_name, attr = segments
                getter = cast(Getter, attrgetter(attr))
            return param_name, getter

        param_name, getter = _validate(param_name, getter)
        if param_name:
            tmp = bound_args.arguments.get(param_name)
            repo = getter(tmp) if getter else tmp
            if not isinstance(repo, Repo):
                msg = f"Expected 'git.Repo'; got {type(repo)}."
                raise TypeError(msg)
        else:
            repo = walk_params(args_=args_, kwargs_=kwargs_)

        return repo


class GitWrapperExplicit(GitWrapperBase):
    def __call__(  # noqa: PLR0917
        self,
        repo: Repo | None,
        require_git: bool = True,
        require_clean: bool = True,
        commit_after: str | bool = False,
        push: bool = False,
        verbose: bool = True,
        logger: LoggerProtocol = logger,
        message: MessageMaker | str | None = None,
    ) -> Callable[[C], C]:
        return self.wrap(
            repo=repo,
            require_git=require_git,
            require_clean=require_clean,
            commit_after=commit_after,
            push=push,
            verbose=verbose,
            logger=logger,
            message=message,
        )

    def wrap(  # noqa: PLR0917
        self,
        repo: Repo | None,
        require_git: bool = True,
        require_clean: bool = True,
        commit_after: str | bool = False,
        push: bool = False,
        verbose: bool = True,
        logger: LoggerProtocol = logger,
        message: MessageMaker | str | None = None,
    ) -> Callable[[C], C]:
        if repo is None:
            if require_git:
                msg = "Git repo required and not supplied."
                raise GitWrapperError(msg)
            else:
                return identity

        def wrapper(func: C) -> C:
            name: str = func.__qualname__
            sig = inspect.signature(func)

            def inner(*args, **kwargs) -> Any:
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()

                if require_clean and repo.is_dirty():
                    raise self.make_dirty_error(repo)

                try:
                    logger.debug("running main try loop")
                    ret = func(*args, **kwargs)

                except Exception as e:
                    self.reset_to_last_commit(exc=e, funcname=name, repo=repo)
                    raise e

                if commit_after:
                    self.perform_commit_after(
                        repo=repo,
                        push=push,
                        message_maker=message,
                        func=func,
                        args=bound_args,
                    )

                return ret

            return cast(C, inner)

        return wrapper

    def require_unchanged(
        self,
        repo: Repo | None,
        require_git: bool = True,
        verbose: bool = True,
    ) -> Callable[[C], C]:
        if repo is None:
            if require_git:
                msg = "Git repo required and not supplied."
                raise GitWrapperError(msg)
            else:
                return identity

        repo = self.assert_repo(repo)

        def wrapper(func: C) -> C:
            name: str = func.__qualname__

            def inner(*args, **kwargs) -> Any:
                if repo.is_dirty():
                    raise self.make_dirty_error(repo)

                try:
                    ret = func(*args, **kwargs)
                    if repo.is_dirty():
                        raise self.make_dirty_error(repo)

                except Exception as e:
                    self.reset_to_last_commit(exc=e, funcname=name, repo=repo)
                    raise e

                return ret

            return cast(C, inner)

        return wrapper

    def require_unchanged_except(
        self,
        repo: Repo | None,
        ignore: Iterable[Path | str],
        require_git: bool = True,
        verbose: bool = True,
    ) -> Callable[[C], C]:
        """Requires the repository to have no changes except to the specified files."""
        raise NotImplementedError
        # TODO: fold into require_unchanged as an 'ignore: tuple[Path, ...]' option?

    @staticmethod
    def assert_repo(repo: Repo | None) -> Repo:
        if not isinstance(repo, Repo):
            raise TypeError
        return repo
