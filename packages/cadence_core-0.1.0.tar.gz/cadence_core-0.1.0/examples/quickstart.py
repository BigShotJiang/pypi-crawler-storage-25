#!/usr/bin/env python3
"""
Cadence quickstart — synthesize a tiny dataset and run fit + predict.

This is the demo advertised in README.md. It uses pre-assigned cluster IDs
so no sentence-transformers download is needed.

Run:
    pip install cadence
    python examples/quickstart.py
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# ─────────────────────────────────────────────────────────────────────────────
# 1. Synthetic dataset (replace with your own events_df)
# ─────────────────────────────────────────────────────────────────────────────

EVENTS = [
    "Patient admitted with chest pain",
    "ECG performed, ST elevation noted",
    "Blood work drawn, troponin elevated",
    "Echocardiogram completed",
    "Discharge planning initiated",
]
N_CLUSTERS = 5

rng = np.random.default_rng(42)
rows = []
base = pd.Timestamp("2024-01-01")

for pid in range(50):
    t = base
    for _ in range(10):
        t += pd.Timedelta(days=int(rng.integers(1, 30)))
        text = EVENTS[rng.integers(len(EVENTS))]
        rows.append(
            {
                "patient_id": f"P{pid:03d}",
                "timestamp": t,
                "event_text": text,
                "cluster_id": int(rng.integers(N_CLUSTERS)),
            }
        )

events_df = pd.DataFrame(rows)
print(f"Dataset: {len(events_df)} events, {events_df['patient_id'].nunique()} patients")
print(events_df.head(4).to_string(index=False))
print()

# ─────────────────────────────────────────────────────────────────────────────
# 2. Training
# ─────────────────────────────────────────────────────────────────────────────

from cadence import Cadence, CadenceConfig

config = CadenceConfig(
    n_clusters=N_CLUSTERS,
    batch_size=64,
    phase1_epochs=3,
    phase2_epochs=5,
    hidden1=128,
    hidden2=128,
    hidden3=64,
    swa_start=999,   # disable SWA for this tiny example
)

print("Training Cadence model...")
model = Cadence(config=config)
model.fit(events_df, epochs=8)
print("Training complete.")
print()

# ─────────────────────────────────────────────────────────────────────────────
# 3. Inference
# ─────────────────────────────────────────────────────────────────────────────

patient_history = events_df[events_df["patient_id"] == "P001"].copy()

print(f"Patient P001 has {len(patient_history)} events. Predicting next event...")
next_event, days_until = model.predict(patient_history)
print(f"  Predicted next event : {next_event}")
print(f"  Days until           : {days_until:.1f}")
print()

# Top-3
top3 = model.predict(patient_history, top_k=3)
print("Top-3 predictions:")
for p in top3["predictions"]:
    print(
        f"  {p['label']:15s}  confidence={p['confidence']:.3f}  "
        f"days={p['days']:.1f}"
    )

# ─────────────────────────────────────────────────────────────────────────────
# 4. Save and reload
# ─────────────────────────────────────────────────────────────────────────────

print()
save_dir = "/tmp/cadence_quickstart_model"
model.save(save_dir)
print(f"Model saved to {save_dir}")

model2 = Cadence.from_pretrained(save_dir, device="cpu")
next_event2, days2 = model2.predict(patient_history)
print(f"Reloaded model prediction: {next_event2}, {days2:.1f}d")
assert next_event == next_event2, "Reload mismatch!"
print("Round-trip check passed.")
