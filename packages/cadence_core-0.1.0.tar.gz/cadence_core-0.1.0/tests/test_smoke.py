"""Smoke test: synthesize tiny dataset, run fit + predict + save/load round-trip.

Requirements:
  - No GPU needed (CPU only)
  - No network calls (sentence-transformers and PubMedBERT are mocked)
  - Must pass in <2 minutes on a standard dev machine
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest
import torch


# ─────────────────────────────────────────────────────────────────────────────
# Synthetic dataset helpers
# ─────────────────────────────────────────────────────────────────────────────

_EVENT_TEXTS = [
    "Patient admitted with chest pain",
    "ECG performed, ST elevation noted",
    "Blood work drawn, troponin elevated",
    "Echocardiogram completed",
    "Discharge planning initiated",
]

N_PATIENTS = 50
N_CLUSTERS = 5
EVENTS_PER_PATIENT = 10


def make_events_df(seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    base = pd.Timestamp("2024-01-01")
    for pid in range(N_PATIENTS):
        t = base
        for _ in range(EVENTS_PER_PATIENT):
            t += pd.Timedelta(days=float(rng.integers(1, 30)))
            text = _EVENT_TEXTS[rng.integers(len(_EVENT_TEXTS))]
            cluster_id = rng.integers(N_CLUSTERS)
            rows.append(
                {
                    "patient_id": f"P{pid:03d}",
                    "timestamp": t,
                    "event_text": text,
                    "cluster_id": int(cluster_id),  # pre-assigned → skip clustering
                }
            )
    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────

def test_construct():
    """Cadence() constructs without error."""
    from cadence import Cadence, CadenceConfig

    cfg = CadenceConfig(n_clusters=N_CLUSTERS, n_features=884)
    model = Cadence(config=cfg)
    assert model._model is None


def test_fit_and_predict(tmp_path):
    """Full fit + predict end-to-end on tiny synthetic data (CPU, no network)."""
    from cadence import Cadence, CadenceConfig

    events_df = make_events_df(seed=42)

    cfg = CadenceConfig(
        n_clusters=N_CLUSTERS,
        batch_size=64,
        phase1_epochs=2,
        phase2_epochs=2,
        swa_start=999,       # disable SWA for smoke test speed
        early_stop_patience=999,
        early_stop_min_epoch=0,
        # Small architecture for speed
        hidden1=64,
        hidden2=64,
        hidden3=32,
        n_reg_bins=10,
        seed=0,
    )

    model = Cadence(config=cfg)

    # cluster_id column is pre-populated → no sentence-transformers call
    model.fit(events_df, epochs=4)

    assert model._model is not None
    assert model._prior is not None
    assert model._bin_centers is not None

    # Predict for one patient
    p001 = events_df[events_df["patient_id"] == "P001"].copy()
    result = model.predict(p001, top_k=1)
    assert isinstance(result, tuple)
    label, days = result
    assert isinstance(label, str)
    assert isinstance(days, float)
    assert days >= 0.0

    # top_k > 1
    result3 = model.predict(p001, top_k=3)
    assert isinstance(result3, dict)
    assert "predictions" in result3
    assert len(result3["predictions"]) <= 3


def test_save_load_roundtrip(tmp_path):
    """Save → reload → predict gives the same result."""
    from cadence import Cadence, CadenceConfig

    events_df = make_events_df(seed=7)

    cfg = CadenceConfig(
        n_clusters=N_CLUSTERS,
        batch_size=64,
        phase1_epochs=1,
        phase2_epochs=1,
        swa_start=999,
        hidden1=64,
        hidden2=64,
        hidden3=32,
        n_reg_bins=10,
        seed=0,
    )
    model = Cadence(config=cfg)
    model.fit(events_df, epochs=2)

    save_dir = tmp_path / "cadence_ckpt"
    model.save(str(save_dir))

    # Verify files exist
    assert (save_dir / "config.json").exists()
    assert (save_dir / "model.pt").exists()
    assert (save_dir / "bin_centers.npy").exists()

    # Reload
    model2 = Cadence.from_pretrained(str(save_dir), device="cpu")
    assert model2._model is not None

    # Predict with reloaded model
    p001 = events_df[events_df["patient_id"] == "P001"].copy()
    label1, days1 = model.predict(p001)
    label2, days2 = model2.predict(p001)
    assert label1 == label2, f"Label mismatch after reload: {label1!r} vs {label2!r}"
    assert abs(days1 - days2) < 0.01, f"Days mismatch: {days1} vs {days2}"


def test_feature_dim():
    """extract_features returns a float32 array with the expected length."""
    from cadence.features import (
        build_population_prior,
        extract_features,
    )

    rng = np.random.default_rng(0)
    n_clusters = N_CLUSTERS
    max_history = 10

    # Build a minimal record
    history = [
        {"cluster_id": int(rng.integers(n_clusters)), "days_from_start": float(i * 3)}
        for i in range(5)
    ]
    record = {
        "history": history,
        "target": {"cluster_id": 2, "days_from_prev": 4.0},
    }

    # Minimal prior
    prior = build_population_prior([record], n_clusters=n_clusters)

    feat = extract_features(record, prior, n_clusters=n_clusters, max_history=max_history)
    assert feat.dtype == np.float32
    assert feat.ndim == 1
    assert len(feat) > 0


def test_model_forward():
    """NVCFlatMLP forward pass produces correct output shapes."""
    from cadence.model import NVCFlatMLP
    from cadence.config import CadenceConfig

    cfg = CadenceConfig(hidden1=64, hidden2=64, hidden3=32, n_reg_bins=10)
    bin_centers = torch.linspace(0.0, cfg.log_days_clip, 10)
    model = NVCFlatMLP(
        n_features=20, n_classes=N_CLUSTERS, bin_centers=bin_centers, config=cfg
    )
    model.eval()

    x = torch.randn(4, 20)
    logits, reg_logits = model(x)
    assert logits.shape == (4, N_CLUSTERS)
    assert reg_logits.shape == (4, 10)

    days = model.predict_days(reg_logits)
    assert days.shape == (4,)
    assert (days >= 0).all()


def test_validate_events_df_missing_column():
    """validate_events_df raises ValueError on missing column."""
    from cadence.data import validate_events_df

    bad_df = pd.DataFrame({"patient_id": ["P1"], "event_text": ["foo"]})
    with pytest.raises(ValueError, match="timestamp"):
        validate_events_df(bad_df)


def test_population_prior_stability():
    """build_population_prior returns a stable dict for repeated calls."""
    from cadence.features import build_population_prior

    records = [
        {
            "history": [
                {"cluster_id": 0, "days_from_start": 0.0},
                {"cluster_id": 1, "days_from_start": 5.0},
            ],
            "target": {"cluster_id": 2, "days_from_prev": 3.0},
        }
    ] * 10

    prior1 = build_population_prior(records, n_clusters=5)
    prior2 = build_population_prior(records, n_clusters=5)
    assert prior1["global_gap_median"] == prior2["global_gap_median"]
    assert len(prior1["cluster_freq"]) == 5
