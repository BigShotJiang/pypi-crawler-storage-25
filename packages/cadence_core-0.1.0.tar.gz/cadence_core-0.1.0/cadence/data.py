"""events_df validation, sequence building, and PyTorch Dataset for Cadence.

User-facing data format
-----------------------
``events_df`` is a pandas DataFrame with (at minimum) these columns:

    patient_id   : any hashable type  — patient identifier
    timestamp    : datetime-like       — event time (will be coerced via pd.to_datetime)
    event_text   : str                 — free-text event description
    cluster_id   : int (optional)      — pre-assigned cluster; auto-assigned if missing

The library converts ``events_df`` into an internal list of *records*, where
each record represents one prediction example:

    {
        "patient_id": "P001",
        "history": [
            {"cluster_id": 3, "days_from_start": 0.0,  "event_text": "..."},
            {"cluster_id": 7, "days_from_start": 2.5,  "event_text": "..."},
            ...
        ],
        "target": {
            "cluster_id": 12,
            "days_from_prev": 4.0,
            "event_text": "..."
        }
    }
"""
from __future__ import annotations

import logging
from typing import List, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

log = logging.getLogger(__name__)

# Required columns (cluster_id is optional — auto-filled if clusterer is provided)
_REQUIRED_COLS = {"patient_id", "timestamp", "event_text"}


def validate_events_df(df) -> None:  # type: ignore[annotation-unchecked]
    """Raise ValueError if ``events_df`` is missing required columns."""
    import pandas as pd

    missing = _REQUIRED_COLS - set(df.columns)
    if missing:
        raise ValueError(
            f"events_df is missing required columns: {sorted(missing)}. "
            f"Expected at least {sorted(_REQUIRED_COLS)}."
        )
    if len(df) == 0:
        raise ValueError("events_df is empty.")


def events_df_to_records(
    df,  # pd.DataFrame
    clusterer=None,  # CadenceClusterer | None
    n_clusters: int = 50,
    max_history: int = 10,
) -> List[dict]:
    """Convert ``events_df`` to a list of prediction records.

    Parameters
    ----------
    df : pd.DataFrame
        Must have ``patient_id``, ``timestamp``, ``event_text``.
        Optional: ``cluster_id`` (skips clustering if present).
    clusterer : CadenceClusterer or None
        Required when ``cluster_id`` column is absent.
    n_clusters : int
    max_history : int

    Returns
    -------
    records : list of dict
    """
    import pandas as pd

    validate_events_df(df)
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values(["patient_id", "timestamp"]).reset_index(drop=True)

    # Assign clusters if needed
    if "cluster_id" not in df.columns:
        if clusterer is None:
            raise ValueError(
                "events_df has no 'cluster_id' column and no clusterer was provided. "
                "Either add a 'cluster_id' column or call model.fit_clusters() first."
            )
        texts = df["event_text"].tolist()
        df["cluster_id"] = clusterer.assign(texts)

    records = []
    for pid, group in df.groupby("patient_id", sort=False):
        group = group.sort_values("timestamp").reset_index(drop=True)
        n = len(group)

        # t0 = first event timestamp
        t0 = group["timestamp"].iloc[0]

        events = []
        for _, row in group.iterrows():
            days = (row["timestamp"] - t0).total_seconds() / 86400.0
            cid = int(row["cluster_id"])
            if not (0 <= cid < n_clusters):
                cid = 0
            events.append(
                {
                    "cluster_id": cid,
                    "days_from_start": float(days),
                    "event_text": str(row.get("event_text", "")),
                }
            )

        # Slide window: every suffix of length ≤ max_history predicts the next event
        for i in range(1, n):
            history_start = max(0, i - max_history)
            history = events[history_start:i]
            target_event = events[i]

            days_from_prev = (
                target_event["days_from_start"] - history[-1]["days_from_start"]
                if history
                else target_event["days_from_start"]
            )
            days_from_prev = max(days_from_prev, 0.5)

            records.append(
                {
                    "patient_id": pid,
                    "history": history,
                    "target": {
                        "cluster_id": target_event["cluster_id"],
                        "days_from_prev": float(days_from_prev),
                        "event_text": target_event["event_text"],
                    },
                }
            )

    return records


class CadenceDataset(Dataset):
    """PyTorch Dataset wrapping a feature matrix for training/evaluation.

    Parameters
    ----------
    X : np.ndarray, shape (n, n_features)
    y_cluster : np.ndarray, shape (n,), int32
    y_log_days : np.ndarray, shape (n,), float32
    """

    def __init__(
        self,
        X: np.ndarray,
        y_cluster: np.ndarray,
        y_log_days: np.ndarray,
    ) -> None:
        self.X = torch.from_numpy(X).float()
        self.y_cluster = torch.from_numpy(y_cluster).long()
        self.y_log_days = torch.from_numpy(y_log_days).float()

    def __len__(self) -> int:
        return len(self.X)

    def __getitem__(self, idx: int):
        return self.X[idx], self.y_cluster[idx], self.y_log_days[idx]
