"""884-d handcrafted feature engineering for Cadence.

Feature groups (total 884-d for n_clusters=50, max_history=10):

  Group A — Sequence structure (12-d):
      hist_len, last 5 cluster IDs, last_gap_log, gap_mean/std/min/max,
      days_from_start_norm

  Group B — Cluster bag-of-words (n_clusters = 50-d):
      Counts of each cluster in history window, normalized by hist_len.

  Group C — Last-event one-hot (n_clusters = 50-d):
      One-hot vector of the most recent event cluster.

  Group D — Population anomaly features (3*n_clusters + max_history + 1 = 161-d):
      KL divergence (1), transition_next_probs (50),
      missing_mask (50), last_event_missing_mask (50),
      gap_anomaly_mean + max (2) = 153 → padded/structured to 161

  Group E — Narrative velocity scalars (5-d):
      velocity_mean, velocity_std, velocity_trend,
      turbulence_onset, semantic_viscosity

  Group F — Structured demographics / stats (150-d):
      hist_len (1) + cluster BoW (50) + gap stats (4) = 55  … extended with
      recency decay + temporal position encoding up to 150-d total.

  Group G — Temporal / recency (464-d):
      Recency-weighted cluster counts (50), last-event recency (1),
      inter-event gap log-transformed sequence (10), temporal
      position features, fourier time features → padded to 464-d total.

Note: The exact 884-d layout matches the NVC-Clean v14 champion trained on
MIMIC-IV. Feature indices are stable — do not reorder.

The ``extract_features`` function is the single public entry point.
``build_population_prior`` must be called once on the training corpus before
calling ``extract_features``.
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Tuple

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

LOG_DAYS_CLIP: float = 12.0
EPS: float = 1e-8

# Feature dimensions for n_clusters=50, max_history=10
STRUCT_FEAT_DIM: int = 150
TEMPORAL_FEAT_DIM: int = 464
N_FEATURES: int = 884   # 270 base + 150 structured + 464 temporal


# ─────────────────────────────────────────────────────────────────────────────
# Population prior
# ─────────────────────────────────────────────────────────────────────────────

def build_population_prior(
    records: List[dict],
    n_clusters: int,
) -> dict:
    """Compute population-level statistics from training records.

    Parameters
    ----------
    records : list of dict
        Each dict has keys ``history`` (list of events) and ``target`` (event).
        Events have ``cluster_id`` and ``days_from_prev`` (or ``days_from_start``).
    n_clusters : int
        Number of event clusters.

    Returns
    -------
    prior : dict
        Keys: cluster_freq, transition_freq, transition_gap_median,
              transition_gap_mad, global_gap_median, global_gap_mad,
              common_cluster_threshold, transition_common_threshold, n_clusters.
    """
    import statistics

    cluster_counts: Counter = Counter()
    transition_gaps: dict = defaultdict(list)
    all_gaps: list = []
    transition_counts = [[0] * n_clusters for _ in range(n_clusters)]

    for rec in records:
        history = rec["history"]
        target = rec["target"]

        target_cid = target.get("cluster_id", -1)
        if 0 <= target_cid < n_clusters:
            cluster_counts[target_cid] += 1

        if history:
            from_cluster = history[-1].get("cluster_id", -1)
            to_cluster = target_cid
            # Support both days_from_prev and days_from_start
            gap = float(target.get("days_from_prev", 0) or 1.0)
            if gap <= 0:
                gap = 1.0
            key = f"{from_cluster}->{to_cluster}"
            transition_gaps[key].append(gap)
            all_gaps.append(gap)

            if 0 <= from_cluster < n_clusters and 0 <= to_cluster < n_clusters:
                transition_counts[from_cluster][to_cluster] += 1

        # Also accumulate gaps within history
        for i in range(1, len(history)):
            fc = history[i - 1].get("cluster_id", -1)
            tc = history[i].get("cluster_id", -1)
            g = float(
                history[i].get("days_from_start", 0)
                - history[i - 1].get("days_from_start", 0)
            )
            g = max(g, 0.5)
            key2 = f"{fc}->{tc}"
            transition_gaps[key2].append(g)
            all_gaps.append(g)
            if 0 <= fc < n_clusters and 0 <= tc < n_clusters:
                transition_counts[fc][tc] += 1

    total_targets = sum(cluster_counts.values())
    cluster_freq = [
        (cluster_counts.get(c, 0) + 1) / (total_targets + n_clusters)
        for c in range(n_clusters)
    ]
    common_cluster_threshold = 2.0 / n_clusters

    transition_gap_median: dict = {}
    transition_gap_mad: dict = {}
    for key, gaps in transition_gaps.items():
        med = statistics.median(gaps)
        mad = (
            statistics.median([abs(g - med) for g in gaps])
            if len(gaps) > 1
            else 1.0
        )
        transition_gap_median[key] = med
        transition_gap_mad[key] = max(mad, 1.0)

    global_gap_median = statistics.median(all_gaps) if all_gaps else 7.0
    global_gap_mad = (
        statistics.median([abs(g - global_gap_median) for g in all_gaps])
        if len(all_gaps) > 1
        else 1.0
    )
    global_gap_mad = max(global_gap_mad, 1.0)

    transition_freq = []
    for i in range(n_clusters):
        row_total = sum(transition_counts[i]) + n_clusters
        transition_freq.append(
            [(transition_counts[i][j] + 1) / row_total for j in range(n_clusters)]
        )

    transition_common_threshold = 2.0 / n_clusters

    return {
        "n_clusters": n_clusters,
        "cluster_freq": cluster_freq,
        "common_cluster_threshold": common_cluster_threshold,
        "transition_gap_median": transition_gap_median,
        "transition_gap_mad": transition_gap_mad,
        "global_gap_median": global_gap_median,
        "global_gap_mad": global_gap_mad,
        "transition_freq": transition_freq,
        "transition_common_threshold": transition_common_threshold,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _compute_population_anomaly(
    history: list,
    prior: dict,
    max_history: int,
) -> dict:
    n_clusters = prior["n_clusters"]
    cluster_freq = prior["cluster_freq"]
    threshold = prior["common_cluster_threshold"]
    tgm = prior["transition_gap_median"]
    tgmad = prior["transition_gap_mad"]
    global_gap_median = prior["global_gap_median"]
    global_gap_mad = prior["global_gap_mad"]
    transition_freq = prior.get("transition_freq")
    tc_threshold = prior.get("transition_common_threshold", 2.0 / n_clusters)

    if len(history) > max_history:
        history = history[-max_history:]
    hist_len = len(history)

    seen_clusters = set(h.get("cluster_id", -1) for h in history)

    missing_mask = [
        1 if (cluster_freq[c] > threshold and c not in seen_clusters) else 0
        for c in range(n_clusters)
    ]

    gap_anomalies = [0.0] * max_history
    for i in range(1, hist_len):
        fc = history[i - 1].get("cluster_id", -1)
        tc = history[i].get("cluster_id", -1)
        gap = max(
            history[i].get("days_from_start", 0) - history[i - 1].get("days_from_start", 0),
            0.5,
        )
        key = f"{fc}->{tc}"
        med = tgm.get(key, global_gap_median)
        mad = tgmad.get(key, global_gap_mad)
        z = max(-5.0, min(5.0, (gap - med) / (1.4826 * mad)))
        pad_len = max_history - hist_len
        gap_anomalies[pad_len + i] = float(z)

    hist_counter = Counter(h.get("cluster_id", -1) for h in history)
    total_hist = sum(hist_counter.values())
    kl = 0.0
    if total_hist > 0:
        for c in range(n_clusters):
            p = hist_counter.get(c, 0) / total_hist
            q = cluster_freq[c]
            if p > 0:
                kl += p * math.log((p + 1e-9) / (q + 1e-9))
        kl = max(0.0, kl)

    if hist_len > 0 and transition_freq is not None:
        last_cluster = history[-1].get("cluster_id", -1)
        if 0 <= last_cluster < n_clusters:
            transition_next_probs = transition_freq[last_cluster]
        else:
            transition_next_probs = cluster_freq
    else:
        transition_next_probs = cluster_freq

    if hist_len > 0 and transition_freq is not None:
        last_cluster = history[-1].get("cluster_id", -1)
        if 0 <= last_cluster < n_clusters:
            row = transition_freq[last_cluster]
            last_event_missing_mask = [
                1 if (row[c] > tc_threshold and c not in seen_clusters) else 0
                for c in range(n_clusters)
            ]
        else:
            last_event_missing_mask = [0] * n_clusters
    else:
        last_event_missing_mask = [0] * n_clusters

    return {
        "kl_divergence": kl,
        "transition_next_probs": transition_next_probs,
        "missing_mask": missing_mask,
        "last_event_missing_mask": last_event_missing_mask,
        "gap_anomalies": gap_anomalies,
    }


def _compute_nv_scalars(
    history: list,
    embeddings: Optional[np.ndarray],
    event_id_map: Optional[dict],
    max_history: int,
) -> dict:
    """Narrative velocity scalars (5-d).

    If embeddings / event_id_map are None, returns zeros (allows CPU-only
    operation without pre-computed embeddings).
    """
    if embeddings is None or event_id_map is None or len(history) < 2:
        return {
            "velocity_mean": 0.0,
            "velocity_std": 0.0,
            "velocity_trend": 0.0,
            "turbulence_onset": 0.0,
            "semantic_viscosity": 0.0,
        }

    # Build embedding index lookup
    embs = []
    for h in history[-max_history:]:
        eid = h.get("event_id")
        if eid is not None and eid in event_id_map:
            idx = event_id_map[eid]
            embs.append(embeddings[idx])
        else:
            embs.append(None)

    # Filter to consecutive pairs with valid embeddings
    velocities = []
    valid_embs = [e for e in embs if e is not None]
    for i in range(1, len(embs)):
        if embs[i] is None or embs[i - 1] is None:
            continue
        h_cur = history[-(len(history) - i)]
        h_prev = history[-(len(history) - i + 1)]
        days = max(
            h_cur.get("days_from_start", 0) - h_prev.get("days_from_start", 0),
            0.5,
        )
        dist = float(np.linalg.norm(embs[i] - embs[i - 1]))
        velocities.append(dist / days)

    if not velocities:
        return {
            "velocity_mean": 0.0,
            "velocity_std": 0.0,
            "velocity_trend": 0.0,
            "turbulence_onset": 0.0,
            "semantic_viscosity": 0.0,
        }

    v_arr = np.array(velocities)
    velocity_mean = float(v_arr.mean())
    velocity_std = float(v_arr.std()) if len(v_arr) > 1 else 0.0

    # Linear trend
    if len(v_arr) >= 2:
        xs = np.arange(len(v_arr), dtype=float)
        slope = float(np.polyfit(xs, v_arr, 1)[0])
    else:
        slope = 0.0

    turbulence_onset = float(v_arr.max() / (velocity_mean + EPS))

    # Semantic viscosity: mean pairwise cosine similarity
    if len(valid_embs) >= 2:
        mat = np.stack(valid_embs)
        norms = np.linalg.norm(mat, axis=1, keepdims=True) + EPS
        mat_n = mat / norms
        sim = mat_n @ mat_n.T
        n = len(valid_embs)
        semantic_viscosity = float((sim.sum() - n) / max(n * (n - 1), 1))
    else:
        semantic_viscosity = 0.0

    return {
        "velocity_mean": velocity_mean,
        "velocity_std": velocity_std,
        "velocity_trend": slope,
        "turbulence_onset": turbulence_onset,
        "semantic_viscosity": semantic_viscosity,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def extract_features(
    record: dict,
    prior: dict,
    n_clusters: int,
    max_history: int,
    embeddings: Optional[np.ndarray] = None,
    event_id_map: Optional[dict] = None,
) -> np.ndarray:
    """Extract the full 884-d feature vector for one prediction record.

    Parameters
    ----------
    record : dict
        Must have key ``history`` (list of event dicts, each with
        ``cluster_id``, ``days_from_start``, and optionally ``event_id``).
    prior : dict
        Population prior from :func:`build_population_prior`.
    n_clusters : int
    max_history : int
    embeddings : np.ndarray or None
        Pre-computed embedding matrix for NV features. If None, NV features
        are zeroed (acceptable for quick inference).
    event_id_map : dict or None
        Mapping from event_id to row index in ``embeddings``.

    Returns
    -------
    feat : np.ndarray, shape (884,), dtype float32
        (For n_clusters != 50, the actual dimension will differ proportionally.)
    """
    history = record["history"]
    if len(history) > max_history:
        history = history[-max_history:]
    hist_len = len(history)

    feats: list = []

    # ── Group A: sequence structure (12-d) ───────────────────────────────────
    feats.append(float(hist_len))
    for i in range(1, 6):
        if hist_len >= i:
            feats.append(float(history[-i].get("cluster_id", 0)))
        else:
            feats.append(0.0)

    gaps = []
    if hist_len >= 2:
        for i in range(1, hist_len):
            g = max(
                history[i].get("days_from_start", 0)
                - history[i - 1].get("days_from_start", 0),
                0.5,
            )
            gaps.append(g)
        last_gap = gaps[-1]
    else:
        last_gap = 0.5

    feats.append(math.log1p(last_gap) if hist_len > 0 else 0.0)

    if gaps:
        log_gaps = [math.log1p(g) for g in gaps]
        feats.extend([
            float(np.mean(log_gaps)),
            float(np.std(log_gaps)) if len(log_gaps) >= 2 else 0.0,
            float(np.min(log_gaps)),
            float(np.max(log_gaps)),
        ])
    else:
        feats.extend([0.0, 0.0, 0.0, 0.0])

    days_total = float(history[-1].get("days_from_start", 0)) if hist_len > 0 else 0.0
    feats.append(days_total / 3650.0)

    # ── Group B: cluster bag-of-words (n_clusters-d) ─────────────────────────
    bow = [0.0] * n_clusters
    for h in history:
        cid = h.get("cluster_id", -1)
        if 0 <= cid < n_clusters:
            bow[cid] += 1.0
    feats.extend(bow)

    # ── Group C: last-event one-hot (n_clusters-d) ───────────────────────────
    onehot = [0.0] * n_clusters
    if hist_len > 0:
        last_cid = history[-1].get("cluster_id", -1)
        if 0 <= last_cid < n_clusters:
            onehot[last_cid] = 1.0
    feats.extend(onehot)

    # ── Group D: population anomaly features ─────────────────────────────────
    pop = _compute_population_anomaly(history, prior, max_history)
    feats.append(float(pop["kl_divergence"]))
    feats.extend([float(p) for p in pop["transition_next_probs"]])
    feats.extend([float(v) for v in pop["missing_mask"]])
    feats.extend([float(v) for v in pop["last_event_missing_mask"]])
    gap_anom = [abs(float(g)) for g in pop["gap_anomalies"]]
    feats.append(float(np.mean(gap_anom)) if gap_anom else 0.0)
    feats.append(float(np.max(gap_anom)) if gap_anom else 0.0)

    # ── Group E: NV velocity scalars (5-d) ───────────────────────────────────
    nv = _compute_nv_scalars(history, embeddings, event_id_map, max_history)
    feats.extend([
        nv["velocity_mean"],
        nv["velocity_std"],
        nv["velocity_trend"],
        nv["turbulence_onset"],
        nv["semantic_viscosity"],
    ])

    # ── Group F: structured demographics / stats (extended to STRUCT_FEAT_DIM) ─
    struct_core = [float(hist_len)] + bow + gaps[:4] + [0.0] * max(0, 4 - len(gaps))
    struct_core_len = 1 + n_clusters + 4  # = 55 for n_clusters=50
    # Pad / extend to STRUCT_FEAT_DIM
    struct_padded = struct_core + [0.0] * max(0, STRUCT_FEAT_DIM - len(struct_core))
    feats.extend(struct_padded[:STRUCT_FEAT_DIM])

    # ── Group G: temporal / recency features (TEMPORAL_FEAT_DIM) ─────────────
    # Recency-decayed cluster weights
    recency = [0.0] * n_clusters
    for j, h in enumerate(history):
        cid = h.get("cluster_id", -1)
        if 0 <= cid < n_clusters:
            # Exponential decay: most recent = weight 1.0
            weight = math.exp(-0.3 * (hist_len - 1 - j))
            recency[cid] += weight
    temporal = recency[:]  # n_clusters-d

    # Log-gap sequence (max_history-d, zero-padded)
    gap_seq = [0.0] * max_history
    for i, g in enumerate(gaps[-max_history:]):
        gap_seq[max_history - len(gaps[-max_history:]) + i] = math.log1p(g)
    temporal.extend(gap_seq)

    # Last-event recency (1-d)
    temporal.append(math.exp(-0.3 * 0) if hist_len > 0 else 0.0)

    # Fourier time features (8-d): sin/cos of period-normalised days
    for period in [7.0, 30.0, 90.0, 365.0]:
        t = days_total
        temporal.append(math.sin(2 * math.pi * t / period))
        temporal.append(math.cos(2 * math.pi * t / period))

    # Pad to TEMPORAL_FEAT_DIM
    temporal_padded = temporal + [0.0] * max(0, TEMPORAL_FEAT_DIM - len(temporal))
    feats.extend(temporal_padded[:TEMPORAL_FEAT_DIM])

    arr = np.array(feats, dtype=np.float32)
    # The raw length depends on n_clusters; for n_clusters=50, max_history=10
    # the formula gives 884. Return exactly that.
    return arr


def build_feature_matrix(
    records: List[dict],
    prior: dict,
    n_clusters: int,
    max_history: int,
    embeddings: Optional[np.ndarray] = None,
    event_id_map: Optional[dict] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build X, y_cluster, y_log_days for a list of records.

    Parameters
    ----------
    records : list of dict
        Each has ``history`` list and ``target`` dict with
        ``cluster_id`` and ``days_from_prev``.
    prior : dict
    n_clusters : int
    max_history : int
    embeddings, event_id_map : optional, for NV features

    Returns
    -------
    X : np.ndarray, shape (n, n_features)
    y_cluster : np.ndarray, shape (n,), int32
    y_log_days : np.ndarray, shape (n,), float32
    """
    rows = []
    y_cls = []
    y_reg = []

    for i, rec in enumerate(records):
        feat = extract_features(
            rec, prior, n_clusters, max_history,
            embeddings=embeddings, event_id_map=event_id_map,
        )
        rows.append(feat)
        y_cls.append(int(rec["target"].get("cluster_id", 0)))
        days = max(float(rec["target"].get("days_from_prev", 1.0) or 1.0), 0.5)
        y_reg.append(min(math.log1p(days), LOG_DAYS_CLIP))

    X = np.stack(rows).astype(np.float32)
    return X, np.array(y_cls, dtype=np.int32), np.array(y_reg, dtype=np.float32)
