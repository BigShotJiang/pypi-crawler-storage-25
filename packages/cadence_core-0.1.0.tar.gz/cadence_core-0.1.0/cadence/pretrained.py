"""HuggingFace Hub checkpoint download and I/O for Cadence.

Checkpoint format (directory)
------------------------------
``model_dir/``
  config.json          — CadenceConfig serialised as JSON
  model.pt             — NVCFlatMLP state_dict + metadata
  bin_centers.npy      — quantile bin centres (float32 array)
  clusterer.pkl        — fitted CadenceClusterer (optional)
  cluster_labels.json  — human-readable label for each cluster ID (optional)

HuggingFace Hub pretrained weights
------------------------------------
Call ``Cadence.from_pretrained("amirrouh/cadence-mimic-100k")`` to download
the MIMIC-IV 100k checkpoint trained on male patients, seed 42.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional, Union

import numpy as np
import torch

log = logging.getLogger(__name__)


def save_checkpoint(
    model,           # NVCFlatMLP
    config,          # CadenceConfig
    bin_centers: np.ndarray,
    save_dir: Union[str, Path],
    clusterer=None,  # CadenceClusterer | None
    cluster_labels: Optional[dict] = None,
    extra: Optional[dict] = None,
) -> None:
    """Save a Cadence checkpoint to ``save_dir``.

    Parameters
    ----------
    model : NVCFlatMLP
    config : CadenceConfig
    bin_centers : np.ndarray
    save_dir : str | Path
    clusterer : CadenceClusterer or None
    cluster_labels : dict or None
        Maps cluster_id (int) → human-readable label (str).
    extra : dict or None
        Arbitrary extra metadata saved into config.json.
    """
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    # Config
    from dataclasses import asdict
    cfg_dict = asdict(config)
    if extra:
        cfg_dict.update(extra)
    (save_dir / "config.json").write_text(json.dumps(cfg_dict, indent=2))

    # Model weights
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "n_features": model.n_features,
            "n_classes": model.n_classes,
        },
        save_dir / "model.pt",
    )

    # Bin centres
    np.save(save_dir / "bin_centers.npy", bin_centers)

    # Clusterer
    if clusterer is not None:
        clusterer.save(save_dir)

    # Cluster labels
    if cluster_labels is not None:
        (save_dir / "cluster_labels.json").write_text(
            json.dumps(cluster_labels, indent=2)
        )

    log.info("Checkpoint saved to %s", save_dir)


def load_checkpoint(
    load_dir: Union[str, Path],
    device: Optional[Union[str, torch.device]] = None,
):
    """Load a Cadence checkpoint from ``load_dir``.

    Returns
    -------
    model : NVCFlatMLP
    config : CadenceConfig
    bin_centers : np.ndarray
    clusterer : CadenceClusterer or None
    cluster_labels : dict or None
    """
    from .config import CadenceConfig
    from .model import NVCFlatMLP
    from dataclasses import fields

    load_dir = Path(load_dir)

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(device)

    # Config
    cfg_dict = json.loads((load_dir / "config.json").read_text())
    valid_fields = {f.name for f in fields(CadenceConfig)}
    cfg_filtered = {k: v for k, v in cfg_dict.items() if k in valid_fields}
    config = CadenceConfig(**cfg_filtered)

    # Bin centres
    bin_centers = np.load(load_dir / "bin_centers.npy")
    bin_centers_t = torch.tensor(bin_centers, dtype=torch.float32)

    # Model weights
    ckpt = torch.load(load_dir / "model.pt", map_location=device, weights_only=False)
    n_features = ckpt.get("n_features", config.n_features)
    n_classes = ckpt.get("n_classes", config.n_clusters)

    model = NVCFlatMLP(
        n_features=n_features,
        n_classes=n_classes,
        bin_centers=bin_centers_t,
        config=config,
    ).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    # Clusterer (optional)
    clusterer = None
    clusterer_pkl = load_dir / "clusterer.pkl"
    if clusterer_pkl.exists():
        from .clustering import CadenceClusterer
        try:
            clusterer = CadenceClusterer.load(load_dir)
        except Exception as exc:
            log.warning("Could not load clusterer: %s", exc)

    # Cluster labels (optional)
    cluster_labels = None
    labels_json = load_dir / "cluster_labels.json"
    if labels_json.exists():
        cluster_labels = json.loads(labels_json.read_text())

    log.info(
        "Checkpoint loaded from %s  (n_features=%d, n_classes=%d, device=%s)",
        load_dir, n_features, n_classes, device,
    )
    return model, config, bin_centers, clusterer, cluster_labels


def download_from_hub(
    repo_id: str,
    local_dir: Optional[Union[str, Path]] = None,
    revision: Optional[str] = None,
) -> Path:
    """Download a Cadence checkpoint from HuggingFace Hub.

    Parameters
    ----------
    repo_id : str
        HuggingFace model repo, e.g. ``"amirrouh/cadence-mimic-100k"``.
    local_dir : str | Path | None
        Where to save. Defaults to ``~/.cache/cadence/<repo_id>``.
    revision : str | None
        Git revision / tag.

    Returns
    -------
    local_dir : Path
        Directory containing the downloaded checkpoint files.
    """
    from huggingface_hub import snapshot_download

    if local_dir is None:
        cache_root = Path.home() / ".cache" / "cadence"
        local_dir = cache_root / repo_id.replace("/", "--")

    local_dir = Path(local_dir)
    local_dir.mkdir(parents=True, exist_ok=True)

    log.info("Downloading %s → %s", repo_id, local_dir)
    snapshot_download(
        repo_id=repo_id,
        local_dir=str(local_dir),
        revision=revision,
        ignore_patterns=["*.md", "*.txt"],
    )
    return local_dir
