"""PubMedBERT embedding wrapper for Cadence.

Uses ``microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext`` to
produce 768-d embeddings per event text.  Two pooling strategies are
concatenated (mean pool + last token) → 1536-d per text.

These embeddings are used to AUGMENT the 884-d handcrafted features:
    input_to_model = concat([handcrafted_884, emb_mean_768, emb_last_768])
                   = 2420-d

This module is OPTIONAL.  When ``CadenceConfig.use_pubmedbert = False``
(the default), the 884-d handcrafted features are used alone and this
module is never imported.

# TODO(v0.2): add caching of embeddings to disk to avoid re-encoding at
# every training run.
"""
from __future__ import annotations

import logging
from typing import List, Optional, Union

import numpy as np
import torch

log = logging.getLogger(__name__)

_PUBMEDBERT_ID = (
    "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"
)


class PubMedBERTEmbedder:
    """Batch-encode clinical event texts with PubMedBERT.

    Parameters
    ----------
    model_id : str
        HuggingFace model identifier.
    device : str or torch.device
        Device to run inference on. Defaults to CUDA if available.
    batch_size : int
        Encoding batch size.
    max_length : int
        Tokenisation max length (PubMedBERT max = 512).
    """

    def __init__(
        self,
        model_id: str = _PUBMEDBERT_ID,
        device: Optional[Union[str, torch.device]] = None,
        batch_size: int = 64,
        max_length: int = 128,
    ) -> None:
        self.model_id = model_id
        self.batch_size = batch_size
        self.max_length = max_length

        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)

        self._tokenizer = None
        self._model = None

    # ------------------------------------------------------------------
    # Lazy load
    # ------------------------------------------------------------------

    def _load(self) -> None:
        if self._model is not None:
            return
        from transformers import AutoModel, AutoTokenizer

        log.info("Loading PubMedBERT: %s", self.model_id)
        self._tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        self._model = AutoModel.from_pretrained(self.model_id).to(self.device)
        self._model.eval()
        log.info("PubMedBERT loaded on %s", self.device)

    # ------------------------------------------------------------------
    # Encode
    # ------------------------------------------------------------------

    def encode(
        self,
        texts: List[str],
        show_progress: bool = False,
    ) -> np.ndarray:
        """Encode texts to 1536-d embeddings (mean + last token concatenated).

        Parameters
        ----------
        texts : list of str

        Returns
        -------
        embeddings : np.ndarray, shape (n, 1536)
        """
        self._load()
        results = []
        batches = range(0, len(texts), self.batch_size)
        if show_progress:
            from tqdm import tqdm
            batches = tqdm(batches, desc="PubMedBERT encoding")

        with torch.no_grad():
            for start in batches:
                batch = texts[start : start + self.batch_size]
                enc = self._tokenizer(
                    batch,
                    padding=True,
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors="pt",
                ).to(self.device)
                out = self._model(**enc, output_hidden_states=False)
                hidden = out.last_hidden_state  # (B, T, 768)

                # Mean pooling (over non-padding tokens)
                mask = enc["attention_mask"].unsqueeze(-1).float()  # (B, T, 1)
                mean_emb = (hidden * mask).sum(1) / mask.sum(1).clamp(min=1.0)

                # Last token (CLS = position 0 for BERT)
                last_emb = hidden[:, 0, :]

                combined = torch.cat([mean_emb, last_emb], dim=-1)  # (B, 1536)
                results.append(combined.cpu().numpy())

        return np.concatenate(results, axis=0).astype(np.float32)
