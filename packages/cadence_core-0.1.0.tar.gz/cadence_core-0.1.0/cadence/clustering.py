"""Event-text clustering: map raw event texts to integer cluster IDs.

Users call ``fit_clusters(texts)`` once on their corpus, then use
``assign_clusters(texts)`` at inference time.

Implementation:
  - Encoder: sentence-transformers ``all-MiniLM-L6-v2`` (384-d embeddings)
  - Clusterer: ``sklearn.cluster.MiniBatchKMeans`` (K=50 default)

The fitted encoder + clusterer are stored in ``CadenceClusterer`` and
serialised alongside the model checkpoint.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional, Union

import numpy as np

log = logging.getLogger(__name__)


class CadenceClusterer:
    """Fit and apply event-text clustering.

    Parameters
    ----------
    n_clusters : int
        Number of event clusters. Default 50 matches the paper.
    encoder_model : str
        Name of the sentence-transformer encoder.
    batch_size : int
        Batch size for sentence encoding.
    random_state : int
        Random state for reproducibility.
    """

    def __init__(
        self,
        n_clusters: int = 50,
        encoder_model: str = "all-MiniLM-L6-v2",
        batch_size: int = 256,
        random_state: int = 42,
    ) -> None:
        self.n_clusters = n_clusters
        self.encoder_model = encoder_model
        self.batch_size = batch_size
        self.random_state = random_state
        self._encoder = None
        self._clusterer = None
        self._is_fitted = False

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(self, texts: List[str]) -> "CadenceClusterer":
        """Fit encoder + KMeans on a list of event text strings.

        Parameters
        ----------
        texts : list of str
            All distinct event texts in the training corpus.

        Returns
        -------
        self
        """
        from sentence_transformers import SentenceTransformer
        from sklearn.cluster import MiniBatchKMeans

        log.info(
            "Fitting CadenceClusterer: n_clusters=%d, encoder=%s, n_texts=%d",
            self.n_clusters, self.encoder_model, len(texts),
        )

        self._encoder = SentenceTransformer(self.encoder_model)
        embs = self._encoder.encode(
            texts,
            batch_size=self.batch_size,
            show_progress_bar=True,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        log.info("Encoded %d texts → shape %s", len(texts), embs.shape)

        self._clusterer = MiniBatchKMeans(
            n_clusters=self.n_clusters,
            random_state=self.random_state,
            batch_size=max(1024, 10 * self.n_clusters),
            n_init=3,
        )
        self._clusterer.fit(embs)
        self._is_fitted = True
        log.info("KMeans fitted. Inertia: %.2f", self._clusterer.inertia_)
        return self

    # ------------------------------------------------------------------
    # Assign
    # ------------------------------------------------------------------

    def assign(self, texts: Union[List[str], str]) -> np.ndarray:
        """Map event text(s) to cluster IDs.

        Parameters
        ----------
        texts : str or list of str

        Returns
        -------
        cluster_ids : np.ndarray, shape (n,), dtype int
        """
        if not self._is_fitted:
            raise RuntimeError(
                "CadenceClusterer is not fitted. Call .fit() first."
            )
        if isinstance(texts, str):
            texts = [texts]
        embs = self._encoder.encode(
            texts,
            batch_size=self.batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return self._clusterer.predict(embs).astype(np.int32)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def save(self, directory: Union[str, Path]) -> None:
        """Save the fitted clusterer to ``directory``."""
        import pickle

        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        with open(directory / "clusterer.pkl", "wb") as f:
            pickle.dump(
                {
                    "n_clusters": self.n_clusters,
                    "encoder_model": self.encoder_model,
                    "clusterer": self._clusterer,
                    "is_fitted": self._is_fitted,
                },
                f,
            )
        log.info("Clusterer saved to %s", directory / "clusterer.pkl")

    @classmethod
    def load(cls, directory: Union[str, Path]) -> "CadenceClusterer":
        """Load a previously saved clusterer."""
        import pickle
        from sentence_transformers import SentenceTransformer

        directory = Path(directory)
        with open(directory / "clusterer.pkl", "rb") as f:
            state = pickle.load(f)

        obj = cls(
            n_clusters=state["n_clusters"],
            encoder_model=state["encoder_model"],
        )
        obj._clusterer = state["clusterer"]
        obj._is_fitted = state["is_fitted"]
        obj._encoder = SentenceTransformer(state["encoder_model"])
        return obj
