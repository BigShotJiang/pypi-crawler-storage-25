"""Cadence flat-MLP model (NVCFlatMLP) — the core nn.Module.

Architecture (NVC-Clean v14 champion):
  Input: n_features-dim handcrafted features (884-d by default)
         + optional 2x768-d PubMedBERT embeddings → 2420-d total
  Input dropout: Dropout(input_dropout)
  Layer 1: Linear → BatchNorm1d → GELU → Dropout
  Layer 2: Linear → BatchNorm1d → GELU → Dropout
  Layer 3: Linear → BatchNorm1d → GELU → Dropout  (+ residual skip from L2 output)
  Classification head: Linear(hidden3 → n_classes)
  Regression head:     Linear(hidden3 → n_reg_bins) → softmax expectation → days

Regression inference:
  probs         = softmax(reg_logits)                      # (B, n_bins)
  pred_log_days = sum(probs * bin_centers)                 # weighted expectation
  pred_days     = expm1(pred_log_days)

Loss (training):
  Classification: Asymmetric Loss (ASL, Ridnik et al. 2021, arXiv:2009.14119)
  Regression:     Gaussian-soft cross-entropy over quantile bins
  Optional aux:   smooth-L1 on log-days (ramp schedule)
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import CadenceConfig


# ─────────────────────────────────────────────────────────────────────────────
# Asymmetric Loss (ASL)
# ─────────────────────────────────────────────────────────────────────────────

class AsymmetricLoss(nn.Module):
    """Asymmetric Loss for multi-class classification with label smoothing.

    Reference: Ridnik et al. (2021) "Asymmetric Loss For Multi-Label
    Classification", ICCV 2021. arXiv:2009.14119.

    Adapted for single-label setting: applies asymmetric gamma parameters
    to down-weight easy negatives (gamma_neg > gamma_pos).
    """

    def __init__(
        self,
        gamma_neg: float = 4.0,
        gamma_pos: float = 1.0,
        label_smoothing: float = 0.15,
    ) -> None:
        super().__init__()
        self.gamma_neg = gamma_neg
        self.gamma_pos = gamma_pos
        self.label_smoothing = label_smoothing

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        n_classes = logits.size(-1)
        # Smooth one-hot
        smooth = self.label_smoothing / n_classes
        log_p = F.log_softmax(logits, dim=-1)
        p = torch.exp(log_p)

        # Build hard one-hot then smooth
        one_hot = torch.zeros_like(logits).scatter_(1, targets.unsqueeze(1), 1.0)
        one_hot = one_hot * (1.0 - self.label_smoothing) + smooth

        # Per-sample asymmetric gamma
        gamma = torch.where(one_hot >= 0.5,
                            torch.full_like(p, self.gamma_pos),
                            torch.full_like(p, self.gamma_neg))
        focal_weight = (1.0 - p) ** gamma
        loss = -(focal_weight * one_hot * log_p).sum(dim=-1)
        return loss.mean()


# ─────────────────────────────────────────────────────────────────────────────
# NVCFlatMLP
# ─────────────────────────────────────────────────────────────────────────────

class NVCFlatMLP(nn.Module):
    """Cadence flat-MLP with residual skip, BatchNorm, quantile-bin regression head.

    This is the single nn.Module that produces both the classification logits
    and the regression output (days-until-next-event) in one forward pass.

    Parameters
    ----------
    n_features : int
        Input feature dimension. Default 884 (handcrafted only).
        Use 2420 when PubMedBERT embeddings are appended.
    n_classes : int
        Number of event clusters (output classes). Default 50.
    bin_centers : torch.Tensor, shape (n_bins,)
        Midpoints of the quantile bins in log-day space. Required for
        regression inference. Stored as a buffer.
    config : CadenceConfig
        Hyperparameter container. Defaults used when None.
    """

    def __init__(
        self,
        n_features: int,
        n_classes: int,
        bin_centers: torch.Tensor,
        config: Optional[CadenceConfig] = None,
    ) -> None:
        super().__init__()
        if config is None:
            config = CadenceConfig()
        self.config = config
        self.n_features = n_features
        self.n_classes = n_classes
        self.register_buffer("bin_centers", bin_centers.float())

        h1 = config.hidden1
        h2 = config.hidden2
        h3 = config.hidden3
        drop = config.dropout
        idrop = config.input_dropout

        self.input_drop = nn.Dropout(idrop)

        self.layer1 = nn.Sequential(
            nn.Linear(n_features, h1),
            nn.BatchNorm1d(h1),
            nn.GELU(),
            nn.Dropout(drop),
        )
        self.layer2 = nn.Sequential(
            nn.Linear(h1, h2),
            nn.BatchNorm1d(h2),
            nn.GELU(),
            nn.Dropout(drop),
        )
        self.layer3 = nn.Sequential(
            nn.Linear(h2, h3),
            nn.BatchNorm1d(h3),
            nn.GELU(),
            nn.Dropout(drop),
        )
        self.res_proj = nn.Linear(h2, h3, bias=False)

        self.cls_head = nn.Linear(h3, n_classes)

        n_bins = bin_centers.shape[0]
        self.reg_head = nn.Linear(h3, n_bins)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(
        self, x: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Single forward pass.

        Parameters
        ----------
        x : torch.Tensor, shape (B, n_features)

        Returns
        -------
        logits : torch.Tensor, shape (B, n_classes)
        reg_logits : torch.Tensor, shape (B, n_bins)
            Raw bin logits for regression. Use :func:`reg_logits_to_days`
            to convert to predicted days.
        """
        x = self.input_drop(x)
        h1 = self.layer1(x)
        h2 = self.layer2(h1)
        h3 = self.layer3(h2) + self.res_proj(h2)
        logits = self.cls_head(h3)
        reg_logits = self.reg_head(h3)
        return logits, reg_logits

    def predict_days(self, reg_logits: torch.Tensor) -> torch.Tensor:
        """Convert raw reg bin logits to predicted days.

        Uses the soft-expectation over quantile bins in log-day space,
        then inverts the log1p transform.

        Parameters
        ----------
        reg_logits : torch.Tensor, shape (B, n_bins)

        Returns
        -------
        days : torch.Tensor, shape (B,)
        """
        probs = F.softmax(reg_logits, dim=-1)
        pred_log_days = (probs * self.bin_centers.unsqueeze(0)).sum(-1)
        return torch.expm1(pred_log_days.clamp(max=self.config.log_days_clip))

    @property
    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
