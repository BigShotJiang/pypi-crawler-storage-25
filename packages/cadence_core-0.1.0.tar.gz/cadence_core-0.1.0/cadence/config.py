"""Training and model hyperparameters for Cadence."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CadenceConfig:
    """Canonical hyperparameter dataclass for Cadence.

    All defaults replicate the published NVC-Clean v14 champion configuration
    (884-d flat-MLP with residual skip, BN, quantile-bin regression head).
    Override any field to experiment.
    """

    # ── Data ──────────────────────────────────────────────────────────────────
    n_clusters: int = 50
    """Number of event clusters (output classes). 50 matches the MIMIC-IV paper."""

    max_history: int = 10
    """Maximum number of history events to consider per prediction."""

    # ── Model ─────────────────────────────────────────────────────────────────
    n_features: int = 884
    """Handcrafted feature dimension (270 base + 150 structured + 464 temporal)."""

    hidden1: int = 1024
    hidden2: int = 1024
    hidden3: int = 512
    dropout: float = 0.3
    input_dropout: float = 0.1

    n_reg_bins: int = 40
    """Number of quantile bins for regression head."""

    # ── Training ──────────────────────────────────────────────────────────────
    batch_size: int = 512
    phase1_epochs: int = 10
    phase2_epochs: int = 90
    phase1_lr: float = 1e-3
    phase2_lr: float = 1e-4
    weight_decay: float = 3e-3
    early_stop_patience: int = 40
    early_stop_min_epoch: int = 80

    # ── Loss ──────────────────────────────────────────────────────────────────
    gamma_neg: float = 4.0
    """ASL asymmetric loss — negative de-emphasis exponent."""
    gamma_pos: float = 1.0
    """ASL asymmetric loss — positive focusing exponent."""
    label_smoothing: float = 0.15
    reg_weight: float = 1.0
    lambda_aux_max: float = 0.75

    # ── MixUp ─────────────────────────────────────────────────────────────────
    mixup_alpha: float = 0.4

    # ── SWA ───────────────────────────────────────────────────────────────────
    swa_start: int = 35
    """Epoch at which Stochastic Weight Averaging begins (relative to phase 2 start)."""
    swa_lr: float = 5e-5

    # ── Clustering ────────────────────────────────────────────────────────────
    cluster_encoder: str = "all-MiniLM-L6-v2"
    """Sentence-transformer model used to embed event texts for clustering."""

    # ── PubMedBERT embeddings ─────────────────────────────────────────────────
    pubmedbert_model: str = (
        "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"
    )
    """HuggingFace model ID for PubMedBERT embeddings (768-d)."""
    use_pubmedbert: bool = False
    """
    Whether to augment the 884-d features with 2x768-d PubMedBERT embeddings.
    When True, input dim = 884 + 768 + 768 = 2420.
    Requires the transformers / sentence-transformers packages and a GPU for
    reasonable throughput. Disabled by default so users can start without it.
    """

    # ── Misc ──────────────────────────────────────────────────────────────────
    log_days_clip: float = 12.0
    seed: int = 42
    num_workers: int = 0
