"""Load bundled prompt text files for assistant and technical interviewer roles."""

from __future__ import annotations

from importlib.resources import files
from typing import Any


def load_assistant_system_prompt() -> str:
    return (
        files("assessment_cli.prompts")
        .joinpath("assistant_system_prompt.md")
        .read_text(encoding="utf-8")
        .strip()
    )


def load_technical_interviewer_system_prompt() -> str:
    return (
        files("assessment_cli.prompts")
        .joinpath("technical_interviewer_system_prompt.md")
        .read_text(encoding="utf-8")
        .strip()
    )


def build_assistant_system_prompt() -> str | dict[str, Any] | None:
    """Preset claude_code plus bundled system prompt text."""
    text = load_assistant_system_prompt()
    if not text:
        return None
    # Field name is required by the Claude Agent SDK for preset supplemental instructions.
    return {"type": "preset", "preset": "claude_code", "append": text}


def build_technical_interviewer_system_prompt() -> str | None:
    """Dedicated technical interviewer prompt text (no claude_code preset)."""
    text = load_technical_interviewer_system_prompt()
    return text or None
