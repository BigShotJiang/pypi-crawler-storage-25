"""Textual-based terminal UI for the TenX assessment CLI."""

from __future__ import annotations

import asyncio
import logging
import os
import string
import sys
import time
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.theme import Theme
from textual import events, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, VerticalScroll
from textual.widgets import RichLog, Static, TextArea
from textual.widgets import Rule as TextualRule

logger = logging.getLogger(__name__)



# Single source of truth for every non-status color in the UI. Both the Rich
# theme (for markup like [accent]) and the Textual CSS (for widget styling)
# read from here, so a palette tweak is one edit.
_PALETTE = {
    "accent":    "#7C86FF",  # periwinkle — title, cursor, chip, prompt glyph, timer
    "body":      "#E4E4E4",  # high-emphasis text (neutral grey, R=G=B)
    "muted":     "#8B8B8B",  # medium text tier — instructional, dividers
    "low":       "#4A4A4A",  # low-emphasis (placeholder)
    "rule":      "#2A2A2A",  # subtle divider for Rich Panel borders
    "cursor_fg": "#161616",  # contrast color for the cursor glyph on accent
}

CLI_THEME = Theme(
    {
        # Text tiers
        "body":      _PALETTE["body"],
        "meta":      _PALETTE["muted"],
        "hint":      _PALETTE["muted"],
        "muted":     _PALETTE["low"],
        # Accent — text-only colouring for chips, timer, title, bullets.
        # No `reverse` / background fill: the user wants just coloured text.
        "accent":    _PALETTE["accent"],
        "chip":      _PALETTE["accent"],
        "timer":     _PALETTE["accent"],
        # Aliases so existing markup like [label]/[title]/[assistant]/[prompt] keeps working.
        "title":     _PALETTE["accent"],
        "label":     _PALETTE["accent"],
        "assistant": _PALETTE["accent"],
        "prompt":    _PALETTE["accent"],
        # Status — not part of the palette.
        "success":   "green",
        "error":     "bold red",
        "system":    "bright_magenta",
    }
)


def _supports_color() -> bool:
    return (
        sys.stdout.isatty()
        and sys.stderr.isatty()
        and os.environ.get("NO_COLOR") is None
    )


def _usage_tokens(usage: dict[str, Any]) -> tuple[int | None, int | None]:
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    if isinstance(input_tokens, int) and isinstance(output_tokens, int):
        return input_tokens, output_tokens
    return None, None


def _format_duration_mm_ss(total_seconds: int) -> str:
    safe_seconds = max(0, total_seconds)
    minutes, seconds = divmod(safe_seconds, 60)
    return f"{minutes:02d}:{seconds:02d}"


_TIMER_WARNING_THRESHOLDS: list[tuple[int, str]] = [
    (60, "1 minute"),
    (300, "5 minutes"),
]


def _pick_timer_warning(
    seconds_remaining: int,
    warnings_shown: set[int],
) -> tuple[int, str, set[int]] | None:
    """Return (threshold, label, thresholds_to_mark) for the most-urgent unseen warning.

    Returns None if no warning is due. The caller is responsible for merging
    `thresholds_to_mark` into its own `warnings_shown` — this helper does not
    mutate any input. Thresholds ordered most-urgent-first so a single
    seconds_remaining check fires at most one warning, and all larger
    thresholds are reported as ones to mark (so a long-idle resume that jumps
    straight into the 1-minute window doesn't retroactively fire the 5-minute
    warning).
    """
    for threshold_seconds, label in _TIMER_WARNING_THRESHOLDS:
        if threshold_seconds in warnings_shown:
            continue
        if seconds_remaining <= threshold_seconds:
            to_mark = {
                larger for larger, _ in _TIMER_WARNING_THRESHOLDS
                if larger >= threshold_seconds
            }
            return threshold_seconds, label, to_mark
    return None


def _styled_diff_line(line: str) -> Text:
    """Per-line styling for a unified-diff line."""
    if line.startswith("+++") or line.startswith("---"):
        return Text(line, style="bold cyan")
    if line.startswith("@@"):
        return Text(line, style="magenta")
    if line.startswith("+"):
        return Text(line, style="green")
    if line.startswith("-"):
        return Text(line, style="red")
    return Text(line)


def _resolve_question_answer(question_data: dict[str, Any], raw_answer: str) -> str:
    """Translate a typed AskUserQuestion answer into the label(s) the agent expects.

    If the answer is a comma-separated list of option indices, map them back to
    their label strings; otherwise treat the raw text as a free-form reply.
    """
    raw = raw_answer.strip()
    options = question_data.get("options")
    if not isinstance(options, list) or not raw:
        return raw
    chunks = [chunk.strip() for chunk in raw.split(",") if chunk.strip()]
    if not chunks or not all(chunk.isdigit() for chunk in chunks):
        return raw
    selected_labels: list[str] = []
    for chunk in chunks:
        option_index = int(chunk) - 1
        if 0 <= option_index < len(options):
            option = options[option_index]
            if isinstance(option, dict):
                selected_labels.append(str(option.get("label", "")))
    if not selected_labels:
        return raw
    is_multi_select = bool(question_data.get("multiSelect"))
    return ", ".join(selected_labels) if is_multi_select else selected_labels[0]


class ExitRequested(Exception):
    """Raised when the Textual app exits to unblock the REPL."""


_SPINNER_FRAMES: tuple[str, ...] = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")


class StatusHandle:
    """Animated status-bar widget — spinner rotates next to a persistent `Working...`
    label. Tool calls no longer flash through this bar (they get logged to the
    conversation transcript instead), so the bar's text doesn't change mid-turn."""

    def __init__(self, widget: Any, ui: "CLIUI | None" = None) -> None:
        self._widget = widget
        self._ui = ui
        self._frame_index = 0
        self._spinner_timer: Any = None

    def start(self) -> None:
        self._render()
        self._widget.display = True
        if self._ui is not None and self._ui._app is not None:
            self._spinner_timer = self._ui._app.set_interval(0.1, self._tick)

    def _tick(self) -> None:
        self._frame_index = (self._frame_index + 1) % len(_SPINNER_FRAMES)
        self._render()

    def _render(self) -> None:
        frame = _SPINNER_FRAMES[self._frame_index]
        # Use hex directly — Textual's Static widget doesn't resolve Rich
        # theme names like "accent", so we bypass theme lookup entirely.
        rendered = Text()
        rendered.append(f"{frame} Working...", style=_PALETTE["accent"])
        rendered.append(" (esc to interrupt)", style=_PALETTE["muted"])
        self._widget.update(rendered)

    def stop(self) -> None:
        if self._spinner_timer is not None:
            try:
                self._spinner_timer.stop()
            except Exception as exc:
                logger.debug("spinner timer stop failed: %s", exc)
            self._spinner_timer = None
        self._clear()

    def _clear(self) -> None:
        # Guard: only clear if we are still the active handle (no new turn started).
        if self._ui is not None and self._ui._active_status_handle is not self:
            return
        self._widget.update("")
        self._widget.display = False
        if self._ui is not None:
            self._ui._status_timer = None


class TenXConsole(Console):
    """Console subclass that carries a back-reference to CLIUI for modal dispatch."""

    _ui: "CLIUI"


class PromptArea(TextArea):
    """Growing multi-line input: Enter submits, Shift+Enter inserts newline."""

    PLACEHOLDER_TEXT = "try typing something…"
    cursor_blink = False

    def on_mount(self) -> None:
        self._queue: asyncio.Queue[str | None] = asyncio.Queue()
        # When armed, the next matching keypress resolves a decision and all
        # other keys are swallowed (so the candidate can't accidentally submit
        # a prompt mid-approval). `arm_key_decision` populates both fields;
        # `_on_key` clears them on match.
        self._plan_decision_queue: asyncio.Queue[str] | None = None
        self._decision_allowed: set[str] = set()
        self._placeholder_active = False
        self._show_placeholder()

    def _show_placeholder(self) -> None:
        self.load_text(self.PLACEHOLDER_TEXT)
        self._placeholder_active = True
        self.add_class("-placeholder")
        try:
            self.cursor_location = (0, 0)
        except Exception as exc:
            logger.debug("cursor reset failed: %s", exc)

    def _clear_placeholder(self) -> None:
        self.load_text("")
        self._placeholder_active = False
        self.remove_class("-placeholder")

    def arm_key_decision(self, allowed: set[str]) -> asyncio.Queue[str]:
        """Intercept the next keypress matching `allowed`; swallow everything else.

        Returns a queue the caller awaits for the decision. While armed,
        non-matching keys (including Enter) are consumed so the candidate
        cannot type into the prompt or submit a turn until they decide.
        """
        self._decision_allowed = set(allowed)
        self._plan_decision_queue = asyncio.Queue()
        return self._plan_decision_queue

    def _on_key(self, event: events.Key) -> None:
        if self._plan_decision_queue is not None:
            event.prevent_default()
            event.stop()
            if event.key in self._decision_allowed:
                queue = self._plan_decision_queue
                self._plan_decision_queue = None
                queue.put_nowait(event.key)
            return
        if event.key == "enter":
            event.prevent_default()
            event.stop()
            if self._placeholder_active:
                return
            text = self.text.strip()
            self._show_placeholder()
            self._queue.put_nowait(text)
            return
        if self._placeholder_active and event.is_printable:
            self._clear_placeholder()

    async def wait_for_submit(self) -> str:
        result = await self._queue.get()
        if result is None:
            raise ExitRequested
        return result

    def signal_exit(self) -> None:
        self._queue.put_nowait(None)


class TenXApp(App):
    """Textual application that owns the full screen layout."""

    # `string.Template` over f-strings / .format: CSS has many literal `{`
    # and `}` pairs, and $-placeholders don't collide with them. Drives
    # every color from _PALETTE so a palette edit propagates here too.
    CSS = string.Template("""
    Screen           {
        layout: vertical; overflow-y: auto; background: transparent;
        scrollbar-size: 0 0;
    }
    #scroll          {
        height: auto; background: transparent;
        scrollbar-size: 0 0;
    }
    #conversation    { height: auto; background: transparent; padding: 0 0 0 2; }
    #live-reply      {
        height: auto; display: none; padding: 0 0 0 2;
        color: $body; background: transparent;
    }
    Rule             { color: $muted; margin: 0; background: transparent; }
    #status-bar      {
        height: 1; color: $muted; padding: 0 2; margin-top: 1;
        display: none; background: transparent;
    }
    #prompt-row      { height: auto; background: transparent; }
    #prompt-prefix   {
        width: auto; height: auto; padding: 0 1 0 2;
        color: $accent; background: transparent;
    }
    #prompt          {
        height: auto; max-height: 10; width: 1fr; border: none;
        padding: 0 1 0 0; background: transparent; color: $body;
    }
    #prompt:focus    { background: transparent; }
    #prompt > .text-area--document { background: transparent; }
    #prompt > .text-area--cursor-line { background: transparent; }
    #prompt > .text-area--cursor { background: $accent; color: $cursor_fg; }
    #prompt.-placeholder { color: $low; }
    #prompt.-placeholder > .text-area--cursor { background: $low; color: $cursor_fg; }
    """).substitute(_PALETTE)

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=False),
        Binding("ctrl+l", "clear_conversation", "Clear", show=False),
        Binding("escape", "interrupt", "Interrupt", show=False, priority=True),
        Binding("shift+tab", "cycle_permission_mode", "Cycle mode", show=False, priority=True),
    ]

    def __init__(self, *, ui: "CLIUI") -> None:
        super().__init__()
        self._ui = ui

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="scroll"):
            yield RichLog(
                id="conversation",
                highlight=False,
                markup=True,
                wrap=True,
                auto_scroll=False,
            )
            yield Static("", id="live-reply")
            yield Static("", id="status-bar")
            yield TextualRule()
            with Horizontal(id="prompt-row"):
                yield Static(self._ui._prompt_prefix(), id="prompt-prefix")
                yield PromptArea(id="prompt", show_line_numbers=False)
            yield TextualRule()

    async def on_mount(self) -> None:
        self.console.push_theme(CLI_THEME)
        self._ui._app = self
        self.query_one("#prompt").focus()
        self._start_session()

    @work(name="session", exclusive=True)
    async def _start_session(self) -> None:
        """REPL worker — tied to this widget's lifetime, auto-cancelled on exit."""
        from assessment_cli.session import _run_repl  # lazy import avoids circular dependency

        try:
            await _run_repl(self._ui)
        except Exception as exc:
            try:
                self._ui._write(f"[error]Session error: {exc}[/error]")
            except Exception as write_exc:
                logger.warning("session worker UI write failed: %s", write_exc)
        finally:
            self.query_one("#prompt", PromptArea).signal_exit()
            self.exit()

    async def action_interrupt(self) -> None:
        self._ui.interrupt_event.set()
        client = self._ui._active_client
        if client is not None:
            try:
                await client.interrupt()
            except Exception as exc:
                logger.warning("client interrupt failed: %s", exc)

    def action_clear_conversation(self) -> None:
        self.query_one("#conversation", RichLog).clear()

    def action_quit(self) -> None:
        self.exit()

    async def action_cycle_permission_mode(self) -> None:
        await self._ui.cycle_permission_mode()
        self.query_one("#prompt-prefix", Static).update(self._ui._prompt_prefix())

    def on_key(self, event: events.Key) -> None:
        """Scroll to prompt and focus it when user types while scrolled up."""
        prompt = self.query_one("#prompt", PromptArea)
        if prompt.has_focus:
            return
        # Textual encodes modifiers in event.key (e.g. "ctrl+h"); a bare
        # printable character will have character == key, so we reject any
        # key that includes a "+" (a modifier prefix).
        if event.is_printable and "+" not in event.key:
            self.screen.scroll_end(animate=False)
            prompt.focus()


_MODE_CYCLE = ("default", "acceptEdits", "plan")
_MODE_LABELS = {
    "default": "›",
    "acceptEdits": "auto-accept ›",
    "plan": "plan ›",
}
_MODE_DISPLAY = {
    "default": "review (approve edits)",
    "acceptEdits": "auto-accept",
    "plan": "plan",
}


class CLIUI:
    def __init__(self, *, model: str, proxy_url: str | None) -> None:
        from assessment_cli.config import settings

        self.model = model
        self.proxy_url = (proxy_url or "").strip()
        self.timer_deadline_monotonic: float | None = None
        self.timer_duration_seconds: int | None = None
        self.interrupt_event: asyncio.Event = asyncio.Event()
        # Set by _run_repl so action_interrupt can forward ESC to the SDK client.
        self._active_client: Any = None
        # Tracks the live status handle and its pending clear timer so a new turn
        # can cancel a stale delayed-clear before overwriting the status bar.
        self._active_status_handle: StatusHandle | None = None
        self._status_timer: Any = None
        self._last_logged_tool: str | None = None
        # _app is set by TenXApp.on_mount once the Textual app starts
        self._app: TenXApp | None = None
        # Live permission mode — starts from settings, mutated by Shift+Tab
        self._permission_mode: str = settings.tenx_starting_mode

        self.console: TenXConsole = TenXConsole(
            theme=CLI_THEME,
            highlight=False,
            no_color=not _supports_color(),
            soft_wrap=False,
        )
        self.console._ui = self

    # ------------------------------------------------------------------
    # Internal property helpers (safe to call only after app has mounted)
    # ------------------------------------------------------------------

    @property
    def _log(self) -> Any:
        assert self._app is not None, "_log accessed before TenXApp mounted"
        return self._app.query_one("#conversation", RichLog)

    def _at_bottom(self) -> bool:
        """True when the screen is scrolled to (or within 3 lines of) the bottom."""
        if self._app is None:
            return True
        try:
            screen = self._app.screen
            return screen.scroll_y >= screen.max_scroll_y - 3
        except Exception:
            return True

    def _follow_scroll(self) -> None:
        """Scroll to bottom only if already near the bottom (follow mode)."""
        if self._app is None or not self._at_bottom():
            return
        try:
            self._app.screen.scroll_end(animate=False)
        except Exception as exc:
            logger.debug("scroll_end failed: %s", exc)

    def _write(self, content: Any) -> None:
        """Write a single line/renderable to the conversation RichLog.

        Spacing convention (applies to all public show_*/commit_*/print_*
        methods): each block writes exactly one blank line BEFORE its content
        and none after. Block = one logical unit (user message, assistant
        reply, timer warning, etc.). This keeps inter-block gaps at a
        consistent one line and avoids compounding when consecutive blocks
        would each add their own trailing blank. Intra-block vertical
        separators (like the blank line inside `show_banner` between
        metadata and help text) are fine — they're part of the block.
        """
        self._log.write(content)
        self._follow_scroll()

    @property
    def _status_widget(self) -> Any:
        assert self._app is not None, "_status_widget accessed before TenXApp mounted"
        return self._app.query_one("#status-bar", Static)

    @property
    def _prompt_widget(self) -> PromptArea:
        assert self._app is not None, "_prompt_widget accessed before TenXApp mounted"
        return self._app.query_one("#prompt", PromptArea)

    # ------------------------------------------------------------------
    # Timer helpers
    # ------------------------------------------------------------------

    def set_timer(self, *, duration_seconds: int, deadline_monotonic: float) -> None:
        self.timer_duration_seconds = duration_seconds
        self.timer_deadline_monotonic = deadline_monotonic

    def _seconds_remaining(self) -> int | None:
        if self.timer_deadline_monotonic is None:
            return None
        return max(0, int(self.timer_deadline_monotonic - time.monotonic()))

    # ------------------------------------------------------------------
    # Permission mode helpers
    # ------------------------------------------------------------------

    def _prompt_prefix(self) -> str:
        return _MODE_LABELS.get(self._permission_mode, "[accent]tenx ›[/accent]")

    async def cycle_permission_mode(self) -> str:
        """Advance to the next mode in the cycle; return the display label."""
        current_index = _MODE_CYCLE.index(self._permission_mode) if self._permission_mode in _MODE_CYCLE else 0
        next_mode = _MODE_CYCLE[(current_index + 1) % len(_MODE_CYCLE)]
        if self._active_client is not None:
            try:
                await self._active_client.set_permission_mode(next_mode)
            except Exception as exc:
                logger.warning("set_permission_mode failed: %s", exc)
                return _MODE_DISPLAY.get(self._permission_mode, self._permission_mode)
        self._permission_mode = next_mode
        return _MODE_DISPLAY.get(self._permission_mode, self._permission_mode)

    def show_mode(self) -> None:
        mode_display = _MODE_DISPLAY.get(self._permission_mode, self._permission_mode)
        self._write(
            f"[meta]Current mode:[/meta] {mode_display}  "
            "[hint](Shift+Tab to cycle: review → auto-accept → plan)[/hint]"
        )

    # ------------------------------------------------------------------
    # Inline approval helpers
    # ------------------------------------------------------------------
    #
    # Claude Code answers tool-use approvals in the conversation flow —
    # no modal overlays. These helpers render the proposal inline and
    # arm the prompt widget to intercept the next decision keypress,
    # so the candidate never loses sight of the diff/command/plan and
    # can scroll back to reference it during revision or execution.
    # All bodies are rendered as `Text` (not markup) so stray `[...]`
    # in tool input cannot hijack the style parser.

    def _write_bar_title(self, title_text: str) -> None:
        accent = _PALETTE["accent"]
        line = Text()
        line.append("│ ", style=accent)
        line.append(title_text, style="bold")
        self._write(line)

    def _write_bar_body(self, body_text: str, style: str = "body") -> None:
        accent = _PALETTE["accent"]
        line = Text()
        line.append("│ ", style=accent)
        if body_text:
            line.append(body_text, style=style)
        self._write(line)

    def _write_yn_hint(self) -> None:
        accent = _PALETTE["accent"]
        muted = _PALETTE["muted"]
        hint = Text()
        hint.append("│ ", style=accent)
        hint.append("y", style=accent)
        hint.append(" approve   ", style=muted)
        hint.append("n", style=accent)
        hint.append(" reject", style=muted)
        self._write(hint)

    async def _await_yn(self) -> str:
        queue = self._prompt_widget.arm_key_decision({"y", "n"})
        return await queue.get()

    async def await_plan_decision(self, plan_text: str) -> str:
        self._write("")
        self._write_bar_title("Proposed plan")
        self._write_bar_body("")
        body = plan_text.strip()
        if body:
            # Markdown renderable — headings, bullets, code blocks render
            # formatted. Bar prefix is dropped on the body since markdown
            # reflows across multiple terminal lines and prefixing each
            # would break the frame.
            self._write(Markdown(body))
        else:
            self._write_bar_body("No plan text provided.", style="meta")
        self._write_bar_body("")
        self._write_yn_hint()
        return await self._await_yn()

    async def await_edit_decision(
        self, *, tool_name: str, path: str, diff_lines: list[str]
    ) -> str:
        self._write("")
        self._write_bar_title(f"{tool_name} proposed change")
        if path:
            self._write_bar_body(path, style="meta")
        self._write_bar_body("")
        for diff_line in diff_lines:
            self._write(_styled_diff_line(diff_line))
        self._write_bar_body("")
        self._write_yn_hint()
        return await self._await_yn()

    async def await_bash_decision(self, *, command: str, description: str) -> str:
        self._write("")
        self._write_bar_title("Bash command")
        if description:
            self._write_bar_body(description, style="meta")
        self._write_bar_body(command, style="body")
        self._write_bar_body("")
        self._write_yn_hint()
        return await self._await_yn()

    async def await_user_questions(self, questions: list[dict[str, Any]]) -> dict[str, Any]:
        """Render AskUserQuestion prompts inline and collect typed answers.

        Uses the main prompt bar — when the candidate submits their answer,
        the turn's normal `read_prompt_async` is not blocked on it because
        the REPL is awaiting SDK messages during tool execution. The next
        Enter goes to whichever coroutine is awaiting the prompt queue.
        """
        answers: dict[str, str] = {}
        total = len(questions)
        accent = _PALETTE["accent"]
        muted = _PALETTE["muted"]
        for index, question_data in enumerate(questions, start=1):
            if not isinstance(question_data, dict):
                continue
            header = str(question_data.get("header", "")).strip()
            question_text = str(question_data.get("question", "")).strip()
            options = question_data.get("options")

            self._write("")
            self._write_bar_title(f"Question {index} of {total}")
            if header:
                self._write_bar_body(header, style="meta")
            if question_text:
                self._write_bar_body(question_text)
            if isinstance(options, list):
                for option_index, option in enumerate(options, start=1):
                    if not isinstance(option, dict):
                        continue
                    label = str(option.get("label", ""))
                    description = str(option.get("description", ""))
                    row = Text()
                    row.append("│ ", style=accent)
                    row.append(f"  {option_index}. ", style=accent)
                    row.append(label, style="body")
                    if description:
                        row.append(f" — {description}", style=muted)
                    self._write(row)
                self._write_bar_body("Type option number(s) or free text, then Enter.", style="meta")
            else:
                self._write_bar_body("Type your answer then Enter.", style="meta")

            raw = await self._prompt_widget.wait_for_submit()
            resolved = _resolve_question_answer(question_data, raw)
            answers[question_text] = resolved
        return {"questions": questions, "answers": answers}

    # ------------------------------------------------------------------
    # Show methods — write to RichLog (or stdout pre-app for startup_info)
    # ------------------------------------------------------------------

    def show_github_identity_panel(self, identity: Any, *, pending_field: str = "") -> None:
        """Show the GitHub identity form with auto-resolved fields ticked and pending field highlighted."""
        _FIELDS = [
            ("github_username", "Username"),
            ("github_name", "Name"),
            ("github_email", "Email"),
        ]
        all_resolved = not pending_field and all(getattr(identity, f, "") for f, _ in _FIELDS)

        rows: list[str] = []
        for field, label in _FIELDS:
            value = getattr(identity, field, "")
            padded = f"{label:<10}"
            if value:
                rows.append(f"  [success]✓[/success]  [meta]{padded}[/meta]  {value}")
            elif field == pending_field:
                rows.append(f"  [meta]›[/meta]  [body]{padded}[/body]  [meta]↵ type below[/meta]")
            else:
                rows.append(f"     [meta]{padded}[/meta]")

        subtitle = "[success]Identity linked[/success]" if all_resolved else None
        self._write(
            Panel(
                "\n".join(rows),
                title="[meta]GitHub[/meta]",
                subtitle=subtitle,
                border_style=_PALETTE["rule"],
                padding=(1, 1),
            )
        )

    def show_banner(self, *, version: str) -> None:
        """Stacked header with an accent-coloured vertical bar down its left edge.

        Each line gets a leading `│ ` in the accent colour, giving the whole
        banner a clear visual grouping without drawing a full box panel.
        """
        bar = "[accent]│[/accent] "
        self._write("")
        self._write(f"{bar}[meta]TenX AI v{version}[/meta]")
        self._write(f"{bar}[meta]{self.model}[/meta]")
        self._write(f"{bar}[meta]{Path.cwd()}[/meta]")
        self._write(f"{bar}")
        self._write(f"{bar}[hint]Type [/hint][chip]/help[/chip][hint] for commands.[/hint]")
        if self.timer_duration_seconds is not None:
            duration_chip = _format_duration_mm_ss(self.timer_duration_seconds)
            self._write(
                f"{bar}[hint]Assessment timer: [/hint][timer]{duration_chip}[/timer]"
                "[hint]. Type [/hint][chip]/time[/chip]"
                "[hint] to check remaining time.[/hint]"
            )

    def show_help(self) -> None:
        _HELP_ROWS = [
            ("/help",       "Show this command list"),
            ("/status",     "Show active model and chat history API status"),
            ("/time",       "Show remaining assessment time"),
            ("/mode",       "Show current permission mode"),
            ("/meta",       "Toggle per-message usage/timing footer"),
            ("/submit",     "Submit your solution"),
            ("/clear",      "Start a fresh session"),
            ("/exit",       "Exit the CLI"),
            ("Shift+Tab",   "Cycle mode: default → auto-accept → plan"),
            ("Shift+Enter", "Insert newline in input"),
        ]
        col_width = max(len(cmd) for cmd, _ in _HELP_ROWS)
        self._write(Rule(style="muted"))
        for cmd, desc in _HELP_ROWS:
            self._write(f"  [accent]{cmd:<{col_width}}[/accent]  [muted]│[/muted]  {desc}")

    def show_status(self) -> None:
        state = "configured" if self.proxy_url else "not configured"
        self._write(
            f"[meta]Model:[/meta] {self.model}  "
            f"[meta]Chat history API:[/meta] {state}"
        )

    def show_session_reset(self) -> None:
        self._write("[success]Started a new session.[/success]")

    def show_meta_mode(self, enabled: bool) -> None:
        value = "ON" if enabled else "OFF"
        self._write(f"[system]Meta footer {value}.[/system]")

    def show_time_remaining(self) -> None:
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            self._write("[meta]Assessment timer is not active.[/meta]")
            return
        if seconds_remaining == 0:
            self._write("[error]Assessment timer: 00:00 (time expired).[/error]")
            return
        self._write(
            f"[meta]Assessment timer remaining:[/meta] {_format_duration_mm_ss(seconds_remaining)}"
        )

    def check_timer_warnings(self, *, warnings_shown: set[int]) -> None:
        """Show a warning when the timer crosses key thresholds (5min, 1min)."""
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            return
        picked = _pick_timer_warning(seconds_remaining, warnings_shown)
        if picked is None:
            return
        _threshold, label, to_mark = picked
        warnings_shown |= to_mark
        self._write("")
        self._write(
            f"[error]Warning: {label} remaining. "
            "Submit your work soon with 'tenx-submit'.[/error]"
        )

    def show_error(self, message: str, *, hint: str = "") -> None:
        body = message
        if hint:
            body += f"\n[hint]{hint}[/hint]"
        self._write(Panel(body, title="Error", border_style="error"))

    def show_user_message(self, prompt: str) -> None:
        """Echo the user's submitted prompt with a remaining-time prefix and neutral arrow."""
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is not None:
            timer_label = _format_duration_mm_ss(seconds_remaining)
            prefix_markup = f"[timer]({timer_label})[/timer] [meta]›[/meta] "
        else:
            prefix_markup = "[meta]›[/meta] "
        self._write("")
        prefix = Text.from_markup(prefix_markup)
        body = Text(prompt, style="body")
        self._write(prefix + body)

    def start_working(self) -> StatusHandle:
        # Cancel any pending delayed-clear from the previous turn.
        if self._status_timer is not None:
            self._status_timer.stop()
            self._status_timer = None
        self._last_logged_tool = None
        handle = StatusHandle(self._status_widget, ui=self)
        self._active_status_handle = handle
        handle.start()
        return handle

    def update_working(self, status: StatusHandle | None, tool_label: str) -> None:
        """Log each new tool call to the conversation transcript only — the
        status bar keeps its animated `Working...` label for the whole turn."""
        if status is None:
            return
        try:
            if tool_label != self._last_logged_tool:
                self._last_logged_tool = tool_label
                self._write(f"[meta]    {tool_label}[/meta]")
        except Exception as exc:
            logger.warning("tool log write failed: %s", exc)

    def stop_working(self, status: StatusHandle | None) -> None:
        if status is None:
            return
        try:
            status.stop()
        except Exception as exc:
            logger.debug("status stop failed: %s", exc)

    @property
    def _live_reply(self) -> Any:
        assert self._app is not None, "_live_reply accessed before TenXApp mounted"
        return self._app.query_one("#live-reply", Static)

    def stream_live_reply(self, text: str) -> None:
        """Render streamed narrative as a static accent bullet + grey text.

        No spinner here — the status-bar `Working...` animation covers the
        "agent is doing something" signal. This just mirrors what's being
        generated so the user sees the narrative grow in real time.
        """
        try:
            widget = self._live_reply
            rendered = Text()
            rendered.append("• ", style="accent")
            rendered.append(text, style="meta")
            widget.update(rendered)
            widget.display = True
            self._follow_scroll()
        except Exception as exc:
            logger.warning("live-reply stream failed: %s", exc)

    def _render_assistant_reply(self, text: str) -> Any:
        """Build an accent-bulleted, hanging-indented renderable for an assistant reply.

        Table.grid gives us a 2-column layout: the lavender bullet in col 0
        (width 2), and the Markdown body in col 1. Multi-line bodies wrap
        inside col 1, so continuation lines stay indented under the first
        character of text rather than wrapping back to column 0.
        """
        grid = Table.grid(padding=0)
        grid.add_column(width=2, no_wrap=True)
        grid.add_column()
        grid.add_row(Text.from_markup("[accent]•[/accent] "), Markdown(text))
        return grid

    def commit_live_reply(self, text: str) -> None:
        """Clear live-reply then write the completed response to the RichLog.

        Spacing convention (see show_user_message, show_banner): every
        content block writes exactly one blank line BEFORE its content
        and none after. This gives a consistent one-line gap between
        blocks with no compounding.
        """
        try:
            self._live_reply.update("")
            self._live_reply.display = False
        except Exception as exc:
            logger.warning("live-reply commit failed: %s", exc)
        if text:
            self._write("")
            self._write(self._render_assistant_reply(text))

    def discard_live_reply(self) -> None:
        """Clear live-reply without writing to the RichLog (interrupt/error path)."""
        try:
            self._live_reply.update("")
            self._live_reply.display = False
        except Exception as exc:
            logger.debug("live-reply discard failed: %s", exc)

    def show_exit_summary(self, *, turn_count: int, session_id: str | None) -> None:
        """Print a brief summary when the session ends."""
        parts = [f"{turn_count} turn(s) recorded"]
        if session_id:
            parts.append(f"session {session_id[:8]}")
        self._write(
            f"[meta]Exiting ({', '.join(parts)}). Submit with 'tenx-submit'.[/meta]"
        )

    def print_meta_footer(self, *, duration_ms: int, usage: dict[str, Any]) -> None:
        input_tokens, output_tokens = _usage_tokens(usage)
        if input_tokens is not None and output_tokens is not None:
            self._write(
                f"[meta]{duration_ms} ms | input {input_tokens} | output {output_tokens}[/meta]"
            )
            return
        self._write(f"[meta]{duration_ms} ms[/meta]")

    # ------------------------------------------------------------------
    # Input helpers
    # ------------------------------------------------------------------

    async def read_prompt_async(self) -> str:
        """Read the next submitted prompt from the PromptInput widget."""
        return await self._prompt_widget.wait_for_submit()

    async def read_required_value_async(self, *, label: str, hint: str = "") -> str:
        """Prompt until a non-empty value is provided."""
        if hint:
            self._write(f"[hint]{hint}[/hint]")
        self._write(f"[meta]{label}:[/meta]")
        while True:
            raw_value = await self._prompt_widget.wait_for_submit()
            cleaned_value = raw_value.strip()
            if cleaned_value:
                return cleaned_value
            self._write(f"[error]{label} is required.[/error]")
