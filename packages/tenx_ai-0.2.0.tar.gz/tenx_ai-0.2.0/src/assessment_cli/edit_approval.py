"""Render and handle interactive approval prompts for tool calls."""

from __future__ import annotations

import difflib
import logging
from pathlib import Path
from typing import Any, Callable, Optional

from claude_agent_sdk.types import PermissionResultAllow, PermissionResultDeny, ToolPermissionContext
from rich.console import Console

logger = logging.getLogger(__name__)


def _to_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _resolve_file_path(*, cwd: Path, file_path: str) -> Path:
    candidate = Path(file_path)
    if not candidate.is_absolute():
        candidate = cwd / candidate
    return candidate.resolve()


def _read_file_if_exists(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _build_unified_diff(*, before: str, after: str, file_label: str) -> list[str]:
    return list(
        difflib.unified_diff(
            before.splitlines(),
            after.splitlines(),
            fromfile=f"{file_label} (before)",
            tofile=f"{file_label} (after)",
            lineterm="",
        )
    )


def _get_ui(console: Console) -> Any:
    """Return the CLIUI hosting this console for inline-approval dispatch."""
    from assessment_cli.ui import TenXConsole  # lazy import avoids circular

    assert isinstance(console, TenXConsole), "approval handler requires TenXConsole"
    return console._ui


def _current_mode(console: Console) -> str:
    """Read the live permission mode from the UI."""
    return _get_ui(console)._permission_mode


def _build_write_diff(*, cwd: Path, input_data: dict[str, Any]) -> tuple[str, list[str]]:
    file_path = _to_text(input_data.get("file_path"))
    content = _to_text(input_data.get("content"))
    resolved_path = _resolve_file_path(cwd=cwd, file_path=file_path)
    before_content = _read_file_if_exists(resolved_path)
    diff_lines = _build_unified_diff(
        before=before_content, after=content, file_label=file_path or str(resolved_path)
    )
    return str(resolved_path), diff_lines


def _build_edit_diff(*, input_data: dict[str, Any]) -> tuple[str, list[str]]:
    file_path = _to_text(input_data.get("file_path"))
    old_string = _to_text(input_data.get("old_string"))
    new_string = _to_text(input_data.get("new_string"))
    diff_lines = _build_unified_diff(
        before=old_string, after=new_string, file_label=file_path or "<in-memory edit>"
    )
    return file_path or "<unknown>", diff_lines


async def _decide_with_diff(
    *,
    console: Console,
    tool_name: str,
    path: str,
    diff_lines: list[str],
) -> PermissionResultAllow | PermissionResultDeny:
    ui = _get_ui(console)
    key = await ui.await_edit_decision(tool_name=tool_name, path=path, diff_lines=diff_lines)
    if key == "y":
        return PermissionResultAllow(updated_input={})
    return PermissionResultDeny(message="User rejected the proposed change.")


async def _approve_bash(
    *,
    console: Console,
    input_data: dict[str, Any],
) -> PermissionResultAllow | PermissionResultDeny:
    ui = _get_ui(console)
    command = _to_text(input_data.get("command"))
    description = _to_text(input_data.get("description"))
    key = await ui.await_bash_decision(command=command, description=description)
    if key == "y":
        return PermissionResultAllow(updated_input=input_data)
    return PermissionResultDeny(message="User rejected the proposed Bash command.")


async def _handle_ask_user_question(
    *,
    console: Console,
    input_data: dict[str, Any],
) -> PermissionResultAllow:
    questions = input_data.get("questions")
    if not isinstance(questions, list) or not questions:
        return PermissionResultAllow(updated_input=input_data)

    ui = _get_ui(console)
    result = await ui.await_user_questions(questions)
    if result:
        return PermissionResultAllow(updated_input=result)
    return PermissionResultAllow(updated_input=input_data)


async def _handle_exit_plan_mode(
    *,
    console: Console,
    input_data: dict[str, Any],
) -> PermissionResultAllow | PermissionResultDeny:
    ui = _get_ui(console)
    plan_text = _to_text(input_data.get("plan") or input_data.get("result") or "")
    key = await ui.await_plan_decision(plan_text)
    if key == "y":
        # SDK auto-transitions to acceptEdits after ExitPlanMode Allow
        return PermissionResultAllow(updated_input=input_data)
    # `interrupt=True` stops the current turn so the candidate can type
    # feedback on the plan. Without it, Claude Code treats the deny as a
    # tool-level failure and keeps processing, which looks like the UI hung
    # at "Working…" with no way to revise.
    return PermissionResultDeny(
        message="Plan rejected. Tell me what to change.",
        interrupt=True,
    )


def build_tool_approval_handler(
    *,
    cwd: Path,
    console: Console,
    pause_working: Optional[Callable[[], None]] = None,
    resume_working: Optional[Callable[[], None]] = None,
) -> Callable[[str, dict[str, Any], ToolPermissionContext], Any]:
    async def can_use_tool(
        tool_name: str,
        input_data: dict[str, Any],
        context: ToolPermissionContext,
    ) -> PermissionResultAllow | PermissionResultDeny:
        del context
        logger.debug("can_use_tool called: tool=%s", tool_name)
        if pause_working is not None:
            pause_working()

        try:
            if tool_name == "AskUserQuestion":
                return await _handle_ask_user_question(console=console, input_data=input_data)

            if tool_name == "ExitPlanMode":
                return await _handle_exit_plan_mode(console=console, input_data=input_data)

            mode = _current_mode(console)
            prompt_for_edits = mode == "default"

            if tool_name == "Write" and prompt_for_edits:
                path, diff_lines = _build_write_diff(cwd=cwd, input_data=input_data)
                decision = await _decide_with_diff(
                    console=console,
                    tool_name=tool_name,
                    path=path,
                    diff_lines=diff_lines,
                )
                if isinstance(decision, PermissionResultAllow):
                    return PermissionResultAllow(updated_input=input_data)
                return decision

            if tool_name == "Edit" and prompt_for_edits:
                path, diff_lines = _build_edit_diff(input_data=input_data)
                decision = await _decide_with_diff(
                    console=console,
                    tool_name=tool_name,
                    path=path,
                    diff_lines=diff_lines,
                )
                if isinstance(decision, PermissionResultAllow):
                    return PermissionResultAllow(updated_input=input_data)
                return decision

            if tool_name == "Bash" and prompt_for_edits:
                return await _approve_bash(console=console, input_data=input_data)

            return PermissionResultAllow(updated_input=input_data)
        except Exception:
            # Inline approval should not fail, but if it does, deny rather than
            # propagating to the SDK which would auto-allow the tool.
            logger.exception("can_use_tool dispatch failed for tool=%s; denying", tool_name)
            return PermissionResultDeny(message="Permission check failed — tool denied.")
        finally:
            if resume_working is not None:
                resume_working()

    return can_use_tool
