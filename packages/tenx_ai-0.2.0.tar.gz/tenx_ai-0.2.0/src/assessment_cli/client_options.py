"""Build Claude Agent SDK client options (API env, model, tools, cwd)."""

from pathlib import Path
from typing import Callable

from claude_agent_sdk import ClaudeAgentOptions
from rich.console import Console

from assessment_cli.config import settings
from assessment_cli.edit_approval import build_tool_approval_handler
from assessment_cli.subagents import build_explore_agent
from assessment_cli.system_prompt import (
    build_assistant_system_prompt,
    build_technical_interviewer_system_prompt,
)

ALL_AGENT_TOOLS = [
    "Read", "Write", "Edit", "Bash", "Glob", "Grep",
    "WebSearch", "WebFetch", "AskUserQuestion", "ExitPlanMode",
]


def require_api_key() -> str:
    api_key = (settings.anthropic_api_key or "").strip()
    if not api_key:
        raise SystemExit("Missing ANTHROPIC_API_KEY. Set it in .env and retry.")
    return api_key


def _build_anthropic_env(*, session_id: str | None) -> dict[str, str]:
    """Return ANTHROPIC_* env vars for the Claude agent subprocess.

    When ANTHROPIC_BASE_URL is set the proxy holds the real API key; we send
    the proxy bearer token (with optional session_id encoded) as x-api-key so
    the proxy can authenticate and apply per-session rate limits.
    """
    if settings.anthropic_base_url:
        proxy_token = (settings.assessment_proxy_token or "").strip()
        key = f"{proxy_token}:{session_id}" if session_id else proxy_token
        return {
            "ANTHROPIC_API_KEY": key,
            "ANTHROPIC_BASE_URL": settings.anthropic_base_url,
        }
    return {"ANTHROPIC_API_KEY": require_api_key()}


def build_options(
    *,
    cwd: Path,
    session_id: str | None = None,
    console: Console | None = None,
    pause_working: Callable[[], None] | None = None,
    resume_working: Callable[[], None] | None = None,
) -> ClaudeAgentOptions:
    env = _build_anthropic_env(session_id=session_id)
    approval_console = console or Console(highlight=False)
    permission_mode = settings.tenx_starting_mode

    return ClaudeAgentOptions(
        env=env,
        model=settings.model,
        system_prompt=build_assistant_system_prompt(),
        allowed_tools=ALL_AGENT_TOOLS,
        permission_mode=permission_mode,  # type: ignore[arg-type]
        can_use_tool=build_tool_approval_handler(
            cwd=cwd,
            console=approval_console,
            pause_working=pause_working,
            resume_working=resume_working,
        ),
        max_budget_usd=settings.tenx_max_budget_usd,
        agents={"Explore": build_explore_agent()},
        include_partial_messages=True,
        cwd=str(cwd),
    )


def build_technical_interviewer_options(*, cwd: Path, session_id: str | None = None) -> ClaudeAgentOptions:
    env = _build_anthropic_env(session_id=session_id)

    output_format = {
        "type": "json_schema",
        "schema": {
            "type": "object",
            "required": ["questions"],
            "properties": {
                "questions": {
                    "type": "array",
                    "minItems": 3,
                    "maxItems": 3,
                    "items": {
                        "type": "object",
                        "required": ["prompt"],
                        "properties": {
                            "prompt": {"type": "string", "minLength": 1},
                        },
                        "additionalProperties": False,
                    },
                },
            },
            "additionalProperties": False,
        },
    }

    return ClaudeAgentOptions(
        env=env,
        model=settings.model,
        system_prompt=build_technical_interviewer_system_prompt(),
        allowed_tools=[],
        permission_mode="acceptEdits",
        include_partial_messages=True,
        output_format=output_format,
        cwd=str(cwd),
    )
