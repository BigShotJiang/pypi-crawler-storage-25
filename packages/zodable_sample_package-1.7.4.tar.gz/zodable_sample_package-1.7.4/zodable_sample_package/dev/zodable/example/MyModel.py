from pydantic import BaseModel
from uuid import UUID

class MyModel(BaseModel):
    id: UUID
    name: str
