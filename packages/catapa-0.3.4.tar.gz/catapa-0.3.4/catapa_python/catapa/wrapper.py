"""CATAPA Python Client - Main Wrapper Class.

This module provides an ergonomic wrapper around the auto-generated CATAPA API client
with automatic OAuth2 authentication and token management.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

# Add generated package to path is now handled in __init__.py

import mimetypes
import os
import threading
from typing import Any

from catapa.auth import GrantType
from catapa.auth.catapa_auth import CatapaAuth, CatapaConfig
from catapa.auto_refresh_api_client import AutoRefreshApiClient
from catapa.http_method import HTTPMethod
from catapa.http_response import HttpResponse
from catapa.resource import Resource
from catapa.resource_registry import ROOT_RESOURCES
from openapi_client import Configuration

from .constant import USER_AGENT_KEY, USER_AGENT_VALUE

FILE_TUPLE_LEN_TWO = 2
FILE_TUPLE_LEN_THREE = 3


class Catapa(AutoRefreshApiClient):
    """Main CATAPA wrapper class providing access to all CATAPA APIs.

    Example:
        ```python
        from catapa_python import Catapa

        client = Catapa(
            tenant="your-tenant",
            client_id="your-client-id",
            client_secret="your-client-secret"
        )

        response = client.core.employees.list()
        employee = client.core.employees.retrieve(id="123")
        ```
    """

    def __init__(  # noqa: PLR0913
        self,
        tenant: str,
        client_id: str | None = None,
        client_secret: str | None = None,
        base_url: str = "https://api.catapa.com",
        grant_type: GrantType | None = None,
        *,
        access_token: str | None = None,
    ) -> None:
        """Initialize the CATAPA client.

        Exactly one authentication mode must be provided:

        - ``access_token``: static token, passed directly to each request (no auto-refresh).
        - ``client_id`` + ``client_secret``: OAuth2 client credentials with automatic token refresh.

        Args:
            tenant (str): Your CATAPA tenant name.
            client_id (str | None, optional): OAuth2 client ID. Required when using client credentials auth.
            client_secret (str | None, optional): OAuth2 client secret. Required when using client credentials auth.
            access_token (str | None, optional): Static access token. Required when using access token auth.
            base_url (str, optional): API base URL. Defaults to "https://api.catapa.com".
            grant_type (GrantType | None, optional): OAuth2 grant strategy. Only valid with client credentials auth.

        Raises:
            ValueError: If both or neither auth modes are provided, or if grant_type is used with access_token.
        """
        if access_token is not None and grant_type is not None:
            raise ValueError("grant_type cannot be used with access_token authentication")

        # Initialize attributes needed by __getattr__ BEFORE anything that might trigger it
        self._resource_cache: dict[str, Resource] = {}
        self._resource_cache_lock = threading.Lock()
        self._attr_index: dict[str, Any] = {node.attribute_name: node for node in ROOT_RESOURCES}

        self.config = CatapaConfig(
            tenant=tenant,
            client_id=client_id,
            client_secret=client_secret,
            access_token=access_token,
            base_url=base_url,
        )

        self._auth = CatapaAuth(self.config, grant_type=grant_type)
        self._tenant_key = "Tenant"

        # Get initial access token
        access_token = self._auth.get_access_token()

        # Configure SDK
        configuration = Configuration(host=self.config.base_url)
        configuration.access_token = access_token

        # Initialize parent AutoRefreshApiClient with auto-refresh
        super().__init__(configuration, auth=self._auth)

        if not hasattr(self, "default_headers"):
            self.default_headers = {}
        tenant_value = getattr(self.config, "tenant", None)
        self.default_headers[self._tenant_key] = tenant_value
        self.default_headers[USER_AGENT_KEY] = USER_AGENT_VALUE

    def __getattr__(self, name: str) -> Any:
        """Dynamically access resources through root nodes."""
        node = self._attr_index.get(name)
        if node is None:
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
        if name not in self._resource_cache:
            with self._resource_cache_lock:
                if name not in self._resource_cache:
                    self._resource_cache[name] = Resource(node, self)
        return self._resource_cache[name]

    def __dir__(self) -> list[str]:
        """List available resources for IDE autocomplete support.

        Returns:
            list[str]: All available attribute names from root resources
        """
        # Get standard class attributes
        base_attrs = list(object.__dir__(self))

        # Add all root resource attribute names
        resource_attrs = [node.attribute_name for node in ROOT_RESOURCES]

        return sorted(base_attrs + resource_attrs)

    def get_configuration(self) -> Configuration:
        """OpenAPI Configuration for advanced usage."""
        return self.configuration

    def refresh_auth(self) -> None:
        """Force refresh the authentication token.

        This is useful when you know the token has expired or you want to
        ensure you have a fresh token.
        """
        self._auth.refresh_token()
        if self.configuration and self._auth._token_info:
            self.configuration.access_token = self._auth._token_info.access_token

    def _resolve_file_entry(self, field_name: str, file_value: Any) -> tuple[str, tuple[str, bytes, str]] | None:
        """Resolve a single file entry into normalized tuple format.

        Args:
            field_name: The field name for the file.
            file_value: File value (tuple, file object, path string, or None).
        """
        if file_value is None:
            return None

        if isinstance(file_value, tuple):
            return self._resolve_file_tuple(field_name, file_value)

        if hasattr(file_value, "read"):
            return self._resolve_file_object(field_name, file_value)

        if isinstance(file_value, str):
            return self._resolve_file_path(field_name, file_value)

        msg = f"Unsupported file type for '{field_name}': {type(file_value)}"
        raise ValueError(msg)

    def _resolve_file_tuple(self, field_name: str, file_value: tuple) -> tuple[str, tuple[str, bytes, str]]:
        """Resolve file tuple (filename, data[, content_type]) into normalized format."""
        if len(file_value) == FILE_TUPLE_LEN_THREE:
            filename, file_data, content_type = file_value
        elif len(file_value) == FILE_TUPLE_LEN_TWO:
            filename, file_data = file_value
            content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        else:
            msg = f"File tuple for '{field_name}' must have 2 or 3 elements: (filename, data[, content_type])"
            raise ValueError(msg)

        file_content = self._read_file_data(file_data)
        return (field_name, (filename, file_content, content_type))

    def _resolve_file_object(self, field_name: str, file_value: Any) -> tuple[str, tuple[str, bytes, str]]:
        """Resolve file-like object into normalized format."""
        file_content = file_value.read()
        filename = getattr(file_value, "name", field_name)
        if filename:
            filename = os.path.basename(filename)
        content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        return (field_name, (filename, file_content, content_type))

    def _resolve_file_path(self, field_name: str, file_path: str) -> tuple[str, tuple[str, bytes, str]]:
        """Resolve file path string into normalized format."""
        with open(file_path, "rb") as file_handle:
            file_content = file_handle.read()
            filename = os.path.basename(file_path)
            content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
            return (field_name, (filename, file_content, content_type))

    def _read_file_data(self, file_data: Any) -> bytes:
        """Read file data from various input types into bytes."""
        if isinstance(file_data, str):
            return file_data.encode("utf-8")
        if hasattr(file_data, "read"):
            return file_data.read()
        return file_data

    def _prepare_multipart_data(self, body: Any | None, files: dict[str, Any]) -> list[tuple[str, Any]]:
        """Prepare multipart form data from body dict and files.

        Args:
            body: Optional dict of form fields to include.
            files: Dict of field_name -> file_value mappings.
        """
        post_params: list[tuple[str, Any]] = []

        if body is not None:
            temp_serialized_body = self.sanitize_for_serialization(body)
            if not isinstance(temp_serialized_body, dict):
                msg = "Multipart uploads only support dict bodies when 'files' is provided."
                raise ValueError(msg)
            for field_name, field_value in temp_serialized_body.items():
                post_params.append((field_name, field_value))

        for field_name, file_value in files.items():
            file_entry = self._resolve_file_entry(field_name, file_value)
            if file_entry is not None:
                post_params.append(file_entry)

        return post_params

    def request(  # noqa: PLR0913
        self,
        method: HTTPMethod | str,
        path: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        body: Any | None = None,
        files: dict[str, Any] | None = None,
        parse_json: bool = False,
    ) -> dict[str, Any] | list[Any] | HttpResponse:
        """Make HTTP request using same pipeline as generated methods (connection pool, auth, retries).

        Args:
            method: HTTP method (e.g., "GET", "POST").
            path: Endpoint path (e.g., "/v1/employees").
            params: Query parameters.
            headers: Additional headers.
            body: Request body. When files is None, sent as JSON. When files is provided,
                  body must be a dict and its fields are included as form fields in the
                  multipart request alongside the file uploads.
            files: Files for multipart upload. Supports file objects, paths, or tuples.
                   When provided with body, body fields are serialized as form parameters.
                   Note: Files are fully buffered into memory before upload.
            parse_json: If True, returns parsed dict/list. If False, returns HttpResponse.
        """
        method_str = self._normalize_http_method(method)
        path = self._normalize_path(path)
        header_params = self._prepare_headers(headers, path, method_str, body)
        url = self._build_url(path, params)
        serialized_body, post_params = self._prepare_request_data(body, files, header_params)

        response_data = self.call_api(
            method=method_str, url=url, header_params=header_params, body=serialized_body, post_params=post_params
        )

        response_data.read()
        http_response = HttpResponse(response_data)

        return http_response.json() if parse_json else http_response

    def _normalize_http_method(self, method: HTTPMethod | str) -> str:
        """Normalize HTTP method to uppercase string and validate."""
        if isinstance(method, str):
            method_str = method.upper()
            valid_methods = {m.value for m in HTTPMethod}
            if method_str not in valid_methods:
                msg = f"Invalid HTTP method: {method!r}. Expected one of {sorted(valid_methods)}."
                raise ValueError(msg)
            return method_str
        return method.value

    def _normalize_path(self, path: str) -> str:
        """Ensure path starts with '/'."""
        return path if path.startswith("/") else f"/{path}"

    def _prepare_headers(self, headers: dict[str, str] | None, path: str, method: str, body: Any) -> dict[str, str]:
        """Prepare request headers with auth and default headers."""
        header_params = dict(self.default_headers)
        if headers:
            header_params.update(headers)

        self.update_params_for_auth(
            headers=header_params,
            queries=[],
            auth_settings=["BearerAuth"],
            resource_path=path,
            method=method,
            body=body,
            request_auth=None,
        )
        return header_params

    def _build_url(self, path: str, params: dict[str, Any] | None) -> str:
        """Build full URL with query parameters."""
        url = f"{self.configuration.host}{path}"
        if params:
            sanitized_params = self.sanitize_for_serialization(params)
            url_query = self.parameters_to_url_query(sanitized_params, collection_formats={})
            if url_query:
                separator = "&" if "?" in url else "?"
                url += separator + url_query
        return url

    def _prepare_request_data(
        self, body: Any | None, files: dict[str, Any] | None, header_params: dict[str, str]
    ) -> tuple[Any | None, list[tuple[str, Any]] | None]:
        """Prepare request body and multipart data."""
        if files:
            post_params = self._prepare_multipart_data(body, files)
            header_params["Content-Type"] = "multipart/form-data"
            return None, post_params

        if body is not None:
            serialized_body = self.sanitize_for_serialization(body)
            if "Content-Type" not in header_params:
                header_params["Content-Type"] = "application/json"
            return serialized_body, None

        return None, None
