"""HTTP response wrapper providing requests-like interface for convenience.

This module wraps the OpenAPI client's RESTResponse to provide a familiar,
user-friendly interface similar to the popular requests library.

Authors:
    Handrian Adiputra (handrian.adiputra@gdplabs.id)

References:
    [1] https://requests.readthedocs.io/en/latest/api/#requests.Response
    [2] urllib3 HTTPResponse documentation
"""

import json
from functools import cached_property
from typing import TYPE_CHECKING, Any

from requests.structures import CaseInsensitiveDict

if TYPE_CHECKING:
    from catapa_python.generated.openapi_client.rest import RESTResponse


class HttpResponse:
    """Wrapper around RESTResponse providing a convenient interface to response data, headers, and status.

    Attributes:
        status_code (int): HTTP status code (e.g., 200, 404, 500).
        headers (dict[str, str]): Response headers as a dictionary.
        content (bytes): Raw response body as bytes.
        text (str): Response body decoded as UTF-8 string.
    """

    def __init__(self, rest_response: "RESTResponse") -> None:
        """Initialize HttpResponse wrapper."""
        self._response = rest_response

    @property
    def status_code(self) -> int:
        """Get HTTP status code."""
        return self._response.status

    @cached_property
    def headers(self) -> CaseInsensitiveDict[str]:
        """Get response headers as a case-insensitive dictionary."""
        return CaseInsensitiveDict(self._response.getheaders())

    @property
    def content(self) -> bytes:
        """Get raw response body as bytes."""
        return self._response.data or b""

    @property
    def text(self) -> str:
        """Get response body as UTF-8 decoded string."""
        content_type = self.headers.get("Content-Type", "")
        encoding = "utf-8"
        if "charset=" in content_type:
            encoding = content_type.split("charset=")[-1].split(";")[0].strip()
        return self.content.decode(encoding, errors="replace")

    @property
    def ok(self) -> bool:
        """Check if status code indicates success (< 400)."""
        return self.status_code < 400  # noqa: PLR2004

    def raise_for_status(self) -> None:
        """Raise exception if status code indicates error (>= 400)."""
        if not self.ok:
            msg = f"HTTP error: {self.status_code}"
            raise ValueError(msg)

    def json(self) -> dict[str, Any] | list[Any]:
        """Parse JSON response body."""
        if not self.content:
            raise ValueError("Response body is empty; cannot parse as JSON.")
        return json.loads(self.content)
