"""HTTP method enumeration for CATAPA API requests.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

from enum import Enum


class HTTPMethod(Enum):
    """HTTP method enumeration for API requests."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"

    def __str__(self) -> str:
        """Return the string value of the HTTP method."""
        return self.value
