"""CATAPA Python SDK Client.

Main entry point for the CATAPA Python SDK.

This package provides:
- Catapa: Main wrapper class with automatic OAuth2 authentication and namespace-based API access.
- CatapaAuth & CatapaConfig: Authentication utilities.
- GrantType, ClientCredentialsGrant, AuthorizationCodeGrant: OAuth2 grant types.
- All API classes via attribute, for example: client.core.employees.list()

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

# Authentication utilities
from catapa.auth import AuthorizationCodeGrant, ClientCredentialsGrant, GrantType
from catapa.auth.catapa_auth import CatapaAuth, CatapaConfig

# HTTP utilities
from catapa.http_method import HTTPMethod
from catapa.http_response import HttpResponse

# Main wrapper class
from catapa.wrapper import Catapa

__version__ = "0.3.4"
__author__ = "Catapa Team"
__email__ = "dev@catapa.com"

__all__ = [
    "Catapa",
    "CatapaAuth",
    "CatapaConfig",
    "GrantType",
    "ClientCredentialsGrant",
    "AuthorizationCodeGrant",
    "HTTPMethod",
    "HttpResponse",
]
