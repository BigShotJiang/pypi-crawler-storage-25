"""CATAPA Authentication Module.

This module handles OAuth2 authentication for the CATAPA API,
supporting pluggable grant types with automatic token refresh.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    [1] https://developer.catapa.com/#section/Authentication
"""

import time
from dataclasses import KW_ONLY, dataclass
from typing import Any

import requests
from catapa.auth import ClientCredentialsGrant, GrantType
from catapa.auth.constant import ONE_HOUR_IN_SECONDS, TOKEN_EXPIRATION_BUFFER_SECONDS


class CatapaAuthError(Exception):
    """Exception raised for CATAPA authentication errors.

    This exception is raised when authentication fails, such as when
    the OAuth2 token request fails or returns an error response.
    """

    pass


@dataclass
class CatapaConfig:
    """Configuration for CATAPA API authentication.

    Exactly one authentication mode must be provided:
    - ``access_token``: static token (no auto-refresh)
    - ``client_id`` + ``client_secret``: OAuth2 client credentials (auto-refresh)
    """

    tenant: str
    client_id: str | None = None
    client_secret: str | None = None
    base_url: str = "https://api.catapa.com"
    _: KW_ONLY
    access_token: str | None = None

    def __post_init__(self) -> None:
        """Validate that exactly one authentication mode is provided."""
        has_credentials = self.client_id is not None and self.client_secret is not None
        has_token = self.access_token is not None
        has_partial_credentials = (self.client_id is None) != (self.client_secret is None)

        if has_partial_credentials:
            raise ValueError("client_id and client_secret must both be provided together")
        if not has_credentials and not has_token:
            raise ValueError("Provide either access_token or both client_id and client_secret")
        if has_credentials and has_token:
            raise ValueError("Provide either access_token or client_id/client_secret, not both")


@dataclass
class TokenInfo:
    """Internal token storage with expiration tracking."""

    access_token: str
    token_type: str
    expires_at: float  # timestamp in seconds


class CatapaAuth:
    """Handles OAuth2 authentication with pluggable grant types and automatic token refresh.

    Attributes:
        config (CatapaConfig): Configuration for CATAPA API authentication.
        _token_info (TokenInfo | None): Internal token storage with expiration tracking.

    Example:
        auth = CatapaAuth(CatapaConfig(
            tenant="your-tenant",
            client_id="your-client-id",
            client_secret="your-client-secret"
        ))
        token = auth.get_access_token()
    """

    def __init__(self, config: CatapaConfig, grant_type: GrantType | None = None) -> None:
        """Initialize the CATAPA authentication instance.

        Args:
            config (CatapaConfig): Configuration for CATAPA API authentication.
            grant_type (GrantType | None, optional): OAuth2 grant strategy to use.
                Defaults to ClientCredentialsGrant.
        """
        self.config = config
        self._grant_type: GrantType = grant_type if grant_type is not None else ClientCredentialsGrant()
        self._token_info: TokenInfo | None = None

    def get_access_token(self) -> str:
        """Get a valid access token, refreshing if necessary.

        Returns:
            str: Valid access token

        Raises:
            CatapaAuthError: If authentication fails
        """
        if self.config.access_token is not None:
            return self.config.access_token

        # If we have a valid token, return it
        if self._token_info and self._is_token_valid():
            return self._token_info.access_token

        # Refresh the token
        return self._fetch_new_token()

    def refresh_token(self) -> None:
        """Force refresh the access token.

        No-op when using static access_token authentication.
        """
        if self.config.access_token is not None:
            return
        self._fetch_new_token()

    def _is_token_valid(self) -> bool:
        """Check if current token is valid (not expired).

        Returns:
            bool: True if token is valid, False otherwise
        """
        if not self._token_info:
            return False

        # Add buffer before expiration to ensure token is refreshed in time
        return time.time() < (self._token_info.expires_at - TOKEN_EXPIRATION_BUFFER_SECONDS)

    def _fetch_new_token(self) -> str:
        """Fetch a new access token.

        Returns:
            str: New access token

        Raises:
            CatapaAuthError: If authentication fails
        """
        try:
            if self._token_info is None:
                token_response = self._grant_type._fetch_access_token(self.config)
            else:
                token_response = self._grant_type._refresh_access_token(self.config)

            if "access_token" not in token_response:
                error = token_response.get("error", "unknown_error")
                error_description = token_response.get("error_description", "")
                detail = f" — {error_description}" if error_description else ""
                raise CatapaAuthError(f"Token request failed: {error}{detail}")

            self._token_info = TokenInfo(
                access_token=token_response["access_token"],
                token_type=token_response.get("token_type", "Bearer"),
                expires_at=time.time() + token_response.get("expires_in", ONE_HOUR_IN_SECONDS),
            )

            return self._token_info.access_token

        except requests.exceptions.RequestException as e:
            raise CatapaAuthError(f"Failed to obtain access token: {str(e)}") from e

    def validate_token(self, access_token: str | None = None) -> bool:
        """Validate access token using dedicated endpoint.

        Args:
            access_token (str | None, optional): Token to validate. If None, uses current token. Defaults to None.

        Returns:
            bool: True if token is valid, False otherwise
        """
        stored = self._token_info.access_token if self._token_info else None
        token = access_token or self.config.access_token or stored
        if not token:
            return False

        url = f"{self.config.base_url}/v1/oauth-clients/validate-access-token"

        try:
            response = requests.get(url, headers={"Tenant": self.config.tenant, "Authorization": f"Bearer {token}"})
            return response.ok  # 200 OK means valid, 401 means invalid
        except requests.exceptions.RequestException:
            # If validation endpoint fails, assume token is invalid
            return False

    def get_token_info(self) -> dict[str, Any] | None:
        """Get current token info for debugging/monitoring.

        Returns:
            dict[str, Any] | None: Token information or None if no token
        """
        if self.config.access_token is not None:
            token = self.config.access_token
            return {
                "access_token": token[:5] + "..." + token[-5:],
                "token_type": "Bearer",
                "expires_at": None,
                "is_valid": True,
            }

        if not self._token_info:
            return None

        return {
            "access_token": self._token_info.access_token[:5] + "..." + self._token_info.access_token[-5:],
            "token_type": self._token_info.token_type,
            "expires_at": self._token_info.expires_at,
            "is_valid": self._is_token_valid(),
        }

    def clear_token(self) -> None:
        """Clear stored token (useful for logout).

        No-op when using static access_token authentication.
        """
        if self.config.access_token is not None:
            return
        self._token_info = None
