"""OAuth2 Client Credentials Grant Type.

This module provides the Client Credentials grant type implementation,
suitable for machine-to-machine authentication.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    [1] https://developer.catapa.com/#section/Authentication
"""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from catapa.auth.grant_type.grant_type import GrantType

if TYPE_CHECKING:
    from catapa.auth.catapa_auth import CatapaConfig


@dataclass
class ClientCredentialsGrant(GrantType):
    """OAuth2 Client Credentials grant type for machine-to-machine authentication.

    This is the default grant type when none is specified. Stateless — no instance fields required.

    Example:
        auth = CatapaAuth(config)  # uses ClientCredentialsGrant by default
    """

    def _get_access_token_body(self) -> dict[str, str]:
        """Return the POST body for token acquisition."""
        return {"grant_type": "client_credentials"}

    def _refresh_access_token(self, config: "CatapaConfig") -> dict[str, Any]:
        """Re-authenticate with credentials to obtain a new token."""
        return self._fetch_access_token(config)
