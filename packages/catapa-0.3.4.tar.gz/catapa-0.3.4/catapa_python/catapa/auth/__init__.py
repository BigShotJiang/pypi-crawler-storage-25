"""CATAPA OAuth2 Authentication.

This package provides OAuth2 authentication and grant types for the CATAPA SDK.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    [1] https://developer.catapa.com/#section/Authentication
"""

from catapa.auth.grant_type import AuthorizationCodeGrant, ClientCredentialsGrant, GrantType

__all__ = [
    "GrantType",
    "ClientCredentialsGrant",
    "AuthorizationCodeGrant",
]
