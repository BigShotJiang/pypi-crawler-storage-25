"""CATAPA Constants.

This module contains constants used for CATAPA Public API.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

from importlib.metadata import version

USER_AGENT_KEY = "User-Agent"
USER_AGENT_VALUE = f"catapa-python/{version('catapa')}"
