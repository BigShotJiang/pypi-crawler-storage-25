"""StyleCraft MCP Server - 单品管理服务"""

import os
import httpx
from typing import List, Optional
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("stylecraft-service")

# 从环境变量读取配置
STYLECRAFT_API_BASE = os.getenv("STYLECRAFT_API_BASE", "http://124.70.92.59:9999")
STYLECRAFT_API_KEY = os.getenv("STYLECRAFT_API_KEY", "")


async def call_stylecraft_api(endpoint: str, api_key: str = None) -> dict:
    """调用 StyleCraft API"""
    headers = {}
    if api_key:
        headers["X-API-Key"] = api_key

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            response = await client.get(
                f"{STYLECRAFT_API_BASE}{endpoint}",
                headers=headers if headers else None
            )
            return response.json()
        except Exception as e:
            return {"success": False, "message": f"请求异常: {str(e)}"}


@mcp.tool()
async def get_all_clothes(api_key: str = None) -> str:
    """
    获取所有单品列表

    参数:
        api_key: API 认证密钥（可选）
    返回:
        所有单品列表的 JSON 字符串
    """
    result = await call_stylecraft_api("/api/yichu/getAllClothes", api_key)

    if result.get("success") is False:
        return f"请求失败: {result.get('message')}"

    # 提取数据
    data = result.get("data", [])

    if not data:
        return "暂无单品数据"

    # 格式化输出
    output = []
    for item in data:
        output.append(
            f"- 用户{item.get('userId', 'N/A')}: "
            f"图片={item.get('imageUrl', 'N/A')}, "
            f"分类={item.get('category', 'N/A')}, "
            f"颜色={item.get('colorName', 'N/A')}, "
            f"材质={item.get('material', 'N/A')}, "
            f"风格={item.get('styleTag', 'N/A')}"
        )

    return "\n".join(output) if output else "暂无单品数据"


if __name__ == "__main__":
    mcp.run(transport="sse")
