"""入口点"""

from stylecraft_mcp import main
main()
