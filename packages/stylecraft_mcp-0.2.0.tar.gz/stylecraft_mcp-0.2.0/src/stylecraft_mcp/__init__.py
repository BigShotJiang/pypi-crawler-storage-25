"""StyleCraft MCP - 单品管理服务"""

from .server import mcp, get_all_clothes

def main():
    """启动 MCP 服务"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
