# StyleCraft MCP

StyleCraft 单品管理 MCP 服务。

## 安装

```bash
pip install stylecraft-mcp
```

## 使用

```bash
stylecraft-mcp
```

## 工具

- `get_all_clothes`: 获取所有单品列表
