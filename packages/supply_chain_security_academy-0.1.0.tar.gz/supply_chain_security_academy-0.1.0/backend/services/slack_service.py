"""Slack integration service."""
from typing import Optional
from slack_sdk.web.async_client import AsyncWebClient
from slack_sdk.errors import SlackApiError
from backend.config import settings


class SlackService:
    """Service for Slack integrations."""

    def __init__(self):
        """Initialize Slack client."""
        self.client = AsyncWebClient(token=settings.slack_bot_token) if settings.slack_bot_token else None

    async def post_achievement(
        self, channel_id: str, user_name: str, challenge_title: str, points: int
    ) -> bool:
        """Post an achievement notification to Slack."""
        if not self.client:
            return False

        try:
            await self.client.chat_postMessage(
                channel=channel_id,
                text=f"🎉 *{user_name}* completed *{challenge_title}* and earned {points} points!",
            )
            return True
        except SlackApiError:
            return False

    async def post_weekly_summary(
        self, channel_id: str, challenges_completed: int, users_active: int, top_performer: str
    ) -> bool:
        """Post weekly training summary to Slack."""
        if not self.client:
            return False

        try:
            message = f"""📊 *Weekly Security Training Summary*
            
• Challenges completed: {challenges_completed}
• Active learners: {users_active}
• Top performer: {top_performer}

Keep up the great work securing our supply chain! 🔒"""

            await self.client.chat_postMessage(channel=channel_id, text=message)
            return True
        except SlackApiError:
            return False

    async def send_challenge_reminder(self, channel_id: str) -> bool:
        """Send a challenge reminder to Slack."""
        if not self.client:
            return False

        try:
            await self.client.chat_postMessage(
                channel=channel_id,
                text="🎯 New security challenges available! Log in to continue your training.",
            )
            return True
        except SlackApiError:
            return False


slack_service = SlackService()
