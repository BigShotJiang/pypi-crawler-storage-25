"""Stripe integration service."""
import stripe
from backend.config import settings

stripe.api_key = settings.stripe_secret_key


async def create_customer(email: str, name: str) -> str:
    """Create a Stripe customer."""
    customer = stripe.Customer.create(email=email, name=name)
    return customer.id


async def create_checkout_session(
    customer_id: str, price_id: str, quantity: int, success_url: str, cancel_url: str
) -> str:
    """Create a Stripe checkout session."""
    session = stripe.checkout.Session.create(
        customer=customer_id,
        payment_method_types=["card"],
        line_items=[{"price": price_id, "quantity": quantity}],
        mode="subscription",
        success_url=success_url,
        cancel_url=cancel_url,
    )
    return session.url


async def create_billing_portal_session(customer_id: str, return_url: str) -> str:
    """Create a Stripe billing portal session."""
    session = stripe.billing_portal.Session.create(customer=customer_id, return_url=return_url)
    return session.url


async def cancel_subscription(subscription_id: str) -> None:
    """Cancel a Stripe subscription."""
    stripe.Subscription.delete(subscription_id)


def verify_webhook_signature(payload: bytes, signature: str) -> dict:
    """Verify and parse a Stripe webhook event."""
    return stripe.Webhook.construct_event(
        payload, signature, settings.stripe_webhook_secret
    )
