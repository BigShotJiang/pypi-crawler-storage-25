"""Compliance reporting service."""
from datetime import datetime
from typing import List, Optional
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

from backend.models import Organization, User, UserProgress, Challenge


async def generate_compliance_report(
    db: AsyncSession,
    organization_id: int,
    start_date: datetime,
    end_date: datetime,
    user_ids: Optional[List[int]] = None,
) -> BytesIO:
    """Generate a compliance report PDF."""
    # Fetch organization
    org_result = await db.execute(
        select(Organization).where(Organization.id == organization_id)
    )
    org = org_result.scalar_one()

    # Build query
    query = select(UserProgress, User, Challenge).join(User).join(Challenge).where(
        UserProgress.organization_id == organization_id,
        UserProgress.completed_at >= start_date,
        UserProgress.completed_at <= end_date,
        UserProgress.completed == True,
    )

    if user_ids:
        query = query.where(UserProgress.user_id.in_(user_ids))

    result = await db.execute(query)
    records = result.all()

    # Calculate metrics
    total_users = len(set(r.UserProgress.user_id for r in records))
    total_challenges = len(records)
    total_hours = sum(r.UserProgress.time_spent_seconds for r in records) / 3600

    # Create PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    # Title
    title = Paragraph(
        f"<b>Supply Chain Security Training Report</b><br/>{org.name}", styles["Title"]
    )
    story.append(title)
    story.append(Spacer(1, 12))

    # Period
    period = Paragraph(
        f"Report Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
        styles["Normal"],
    )
    story.append(period)
    story.append(Spacer(1, 12))

    # Summary table
    summary_data = [
        ["Metric", "Value"],
        ["Total Users Trained", str(total_users)],
        ["Total Challenges Completed", str(total_challenges)],
        ["Total Training Hours", f"{total_hours:.1f}"],
        ["Report Generated", datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")],
    ]

    summary_table = Table(summary_data, colWidths=[300, 200])
    summary_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 12),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ]
        )
    )
    story.append(summary_table)
    story.append(Spacer(1, 20))

    # User details
    story.append(Paragraph("<b>User Training Details</b>", styles["Heading2"]))
    story.append(Spacer(1, 12))

    user_data = [["User", "Challenges Completed", "Hours Trained"]]
    user_stats = {}
    for record in records:
        user_name = record.User.full_name or record.User.email
        if user_name not in user_stats:
            user_stats[user_name] = {"count": 0, "hours": 0}
        user_stats[user_name]["count"] += 1
        user_stats[user_name]["hours"] += record.UserProgress.time_spent_seconds / 3600

    for user_name, stats in sorted(user_stats.items()):
        user_data.append([user_name, str(stats["count"]), f"{stats['hours']:.1f}"])

    user_table = Table(user_data, colWidths=[250, 150, 100])
    user_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 10),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ]
        )
    )
    story.append(user_table)

    # Footer
    story.append(Spacer(1, 30))
    footer = Paragraph(
        "<i>This report is generated for compliance purposes (SOC2, ISO27001, etc.) and certifies the above training activities were completed on the Supply Chain Security Academy platform.</i>",
        styles["Normal"],
    )
    story.append(footer)

    doc.build(story)
    buffer.seek(0)
    return buffer
