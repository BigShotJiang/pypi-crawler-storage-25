"""SQLAlchemy models."""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Float, Text
from sqlalchemy.orm import relationship

from backend.database import Base


class Organization(Base):
    """Organization (company account)."""

    __tablename__ = "organizations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    stripe_customer_id = Column(String(255), unique=True, index=True)
    subscription_status = Column(String(50), default="trial")  # trial, active, cancelled
    subscription_seats = Column(Integer, default=5)
    slack_workspace_id = Column(String(255), unique=True, nullable=True)
    slack_channel_id = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    users = relationship("User", back_populates="organization")
    progress = relationship("UserProgress", back_populates="organization")


class User(Base):
    """User account."""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    is_admin = Column(Boolean, default=False)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

    organization = relationship("Organization", back_populates="users")
    progress = relationship("UserProgress", back_populates="user")


class Challenge(Base):
    """Security training challenge."""

    __tablename__ = "challenges"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    difficulty = Column(String(50), nullable=False)  # beginner, intermediate, advanced
    category = Column(String(100), nullable=False)  # npm, supply-chain, malware, etc.
    package_data = Column(Text, nullable=False)  # JSON string with package metadata
    is_malicious = Column(Boolean, nullable=False)
    explanation = Column(Text, nullable=False)
    points = Column(Integer, default=10)
    is_free = Column(Boolean, default=False)  # Available in free tier
    created_at = Column(DateTime, default=datetime.utcnow)

    progress = relationship("UserProgress", back_populates="challenge")


class UserProgress(Base):
    """Track user progress through challenges."""

    __tablename__ = "user_progress"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    challenge_id = Column(Integer, ForeignKey("challenges.id"), nullable=False)
    completed = Column(Boolean, default=False)
    correct = Column(Boolean, nullable=True)
    attempts = Column(Integer, default=0)
    time_spent_seconds = Column(Integer, default=0)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="progress")
    organization = relationship("Organization", back_populates="progress")
    challenge = relationship("Challenge", back_populates="progress")
