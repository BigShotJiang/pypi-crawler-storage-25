"""Main FastAPI application."""
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import FastAPI, Depends, HTTPException, status, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.database import get_db, init_db
from backend.models import Organization, User, Challenge, UserProgress
from backend.auth import (
    get_password_hash,
    verify_password,
    create_access_token,
    get_current_user,
    get_admin_user,
)
from backend.schemas import (
    UserCreate,
    UserLogin,
    Token,
    UserResponse,
    OrganizationResponse,
    TeamMemberInvite,
    ChallengeResponse,
    ChallengeSubmit,
    ChallengeResult,
    UserProgressResponse,
    DashboardStats,
    LeaderboardEntry,
    ComplianceReportRequest,
)
from backend.services.stripe_service import (
    create_customer,
    create_checkout_session,
    create_billing_portal_session,
    verify_webhook_signature,
)
from backend.services.slack_service import slack_service
from backend.services.compliance_service import generate_compliance_report


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize database on startup."""
    await init_db()
    await seed_challenges()
    yield


app = FastAPI(
    title="Supply Chain Security Academy",
    description="Enterprise security training platform",
    version="0.1.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def seed_challenges():
    """Seed initial challenges."""
    from backend.database import async_session_maker
    import json

    async with async_session_maker() as db:
        # Check if challenges exist
        result = await db.execute(select(func.count(Challenge.id)))
        count = result.scalar()
        if count > 0:
            return

        challenges = [
            {
                "title": "Identify Typosquatting Attack",
                "description": "A package named 'reqeusts' was published. Is it malicious?",
                "difficulty": "beginner",
                "category": "npm",
                "package_data": json.dumps(
                    {
                        "name": "reqeusts",
                        "version": "1.0.0",
                        "description": "HTTP library",
                        "downloads": 150,
                        "created": "2026-03-25",
                    }
                ),
                "is_malicious": True,
                "explanation": "This is typosquatting of 'requests' - attackers register similar names to trick developers.",
                "points": 10,
                "is_free": True,
            },
            {
                "title": "Suspicious Maintainer Change",
                "description": "Popular package 'axios' changed maintainers overnight. Red flag?",
                "difficulty": "intermediate",
                "category": "supply-chain",
                "package_data": json.dumps(
                    {
                        "name": "axios",
                        "version": "2.0.0",
                        "maintainer": "new_user_2026",
                        "maintainer_age_days": 3,
                        "downloads": 50000000,
                    }
                ),
                "is_malicious": True,
                "explanation": "Sudden maintainer changes on popular packages are major red flags - this happened in the Axios NPM breach.",
                "points": 20,
                "is_free": True,
            },
            {
                "title": "Legitimate Package Update",
                "description": "Express.js released v5.0.0 with new features. Safe to upgrade?",
                "difficulty": "beginner",
                "category": "npm",
                "package_data": json.dumps(
                    {
                        "name": "express",
                        "version": "5.0.0",
                        "maintainer": "dougwilson",
                        "maintainer_age_days": 3650,
                        "downloads": 30000000,
                    }
                ),
                "is_malicious": False,
                "explanation": "Established maintainer with long history on a well-known package - this is legitimate.",
                "points": 10,
                "is_free": True,
            },
            {
                "title": "Obfuscated Code Detection",
                "description": "Package contains base64-encoded eval statements. Malicious?",
                "difficulty": "advanced",
                "category": "malware",
                "package_data": json.dumps(
                    {
                        "name": "util-helpers",
                        "version": "1.2.0",
                        "code_snippet": "eval(Buffer.from('...', 'base64').toString())",
                        "downloads": 500,
                    }
                ),
                "is_malicious": True,
                "explanation": "Obfuscated code execution patterns are strong indicators of malicious intent.",
                "points": 30,
                "is_free": False,
            },
            {
                "title": "Dependency Confusion Attack",
                "description": "Internal package '@company/logger' appears on public npm. Install it?",
                "difficulty": "intermediate",
                "category": "supply-chain",
                "package_data": json.dumps(
                    {
                        "name": "@company/logger",
                        "version": "99.0.0",
                        "scope": "public",
                        "created": "2026-04-01",
                        "downloads": 5,
                    }
                ),
                "is_malicious": True,
                "explanation": "Dependency confusion attacks exploit package managers by publishing malicious public packages with names matching internal private packages.",
                "points": 25,
                "is_free": False,
            },
        ]

        for challenge_data in challenges:
            challenge = Challenge(**challenge_data)
            db.add(challenge)

        await db.commit()


# Auth endpoints
@app.post("/api/auth/register", response_model=Token, status_code=status.HTTP_201_CREATED)
async def register(user_data: UserCreate, db: AsyncSession = Depends(get_db)):
    """Register a new user and organization."""
    # Check if user exists
    result = await db.execute(select(User).where(User.email == user_data.email))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    # Create Stripe customer
    customer_id = await create_customer(user_data.email, user_data.organization_name)

    # Create organization
    org = Organization(
        name=user_data.organization_name,
        stripe_customer_id=customer_id,
        subscription_status="trial",
    )
    db.add(org)
    await db.flush()

    # Create user
    user = User(
        email=user_data.email,
        hashed_password=get_password_hash(user_data.password),
        full_name=user_data.full_name,
        is_admin=True,
        organization_id=org.id,
    )
    db.add(user)
    await db.commit()

    # Create access token
    access_token = create_access_token(data={"sub": user.id})
    return {"access_token": access_token, "token_type": "bearer"}


@app.post("/api/auth/login", response_model=Token)
async def login(credentials: UserLogin, db: AsyncSession = Depends(get_db)):
    """Login user."""
    result = await db.execute(select(User).where(User.email == credentials.email))
    user = result.scalar_one_or_none()

    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    user.last_login = datetime.utcnow()
    await db.commit()

    access_token = create_access_token(data={"sub": user.id})
    return {"access_token": access_token, "token_type": "bearer"}


@app.get("/api/auth/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    """Get current user."""
    return current_user


# Organization endpoints
@app.get("/api/organization", response_model=OrganizationResponse)
async def get_organization(
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    """Get organization details."""
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()
    return org


@app.post("/api/organization/invite")
async def invite_member(
    invite: TeamMemberInvite,
    current_user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Invite a team member."""
    # Check if user already exists
    result = await db.execute(select(User).where(User.email == invite.email))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="User already exists")

    # Check seat limit
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()

    result = await db.execute(
        select(func.count(User.id)).where(User.organization_id == org.id)
    )
    user_count = result.scalar()

    if user_count >= org.subscription_seats:
        raise HTTPException(status_code=400, detail="Seat limit reached")

    # Create user with temporary password (in production, send email invite)
    temp_password = "ChangeMe123!"
    user = User(
        email=invite.email,
        hashed_password=get_password_hash(temp_password),
        full_name=invite.full_name,
        is_admin=False,
        organization_id=current_user.organization_id,
    )
    db.add(user)
    await db.commit()

    return {"message": "User invited successfully", "temp_password": temp_password}


@app.get("/api/organization/members", response_model=List[UserResponse])
async def list_members(
    current_user: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)
):
    """List organization members."""
    result = await db.execute(
        select(User).where(User.organization_id == current_user.organization_id)
    )
    users = result.scalars().all()
    return users


# Challenge endpoints
@app.get("/api/challenges", response_model=List[ChallengeResponse])
async def list_challenges(
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    """List available challenges."""
    # Get organization subscription status
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()

    # Show all challenges for active/trial, only free for others
    query = select(Challenge)
    if org.subscription_status not in ["active", "trial"]:
        query = query.where(Challenge.is_free == True)

    result = await db.execute(query)
    challenges = result.scalars().all()
    return challenges


@app.post("/api/challenges/submit", response_model=ChallengeResult)
async def submit_challenge(
    submission: ChallengeSubmit,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Submit a challenge answer."""
    # Get challenge
    result = await db.execute(select(Challenge).where(Challenge.id == submission.challenge_id))
    challenge = result.scalar_one_or_none()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")

    # Check access
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()
    if not challenge.is_free and org.subscription_status not in ["active", "trial"]:
        raise HTTPException(status_code=403, detail="Upgrade to access this challenge")

    # Check existing progress
    result = await db.execute(
        select(UserProgress).where(
            and_(
                UserProgress.user_id == current_user.id,
                UserProgress.challenge_id == challenge.id,
            )
        )
    )
    progress = result.scalar_one_or_none()

    correct = submission.is_malicious == challenge.is_malicious
    points_earned = challenge.points if correct else 0

    if progress:
        progress.attempts += 1
        progress.time_spent_seconds += submission.time_spent_seconds
        if not progress.completed and correct:
            progress.completed = True
            progress.correct = True
            progress.completed_at = datetime.utcnow()
    else:
        progress = UserProgress(
            user_id=current_user.id,
            organization_id=current_user.organization_id,
            challenge_id=challenge.id,
            completed=correct,
            correct=correct,
            attempts=1,
            time_spent_seconds=submission.time_spent_seconds,
            completed_at=datetime.utcnow() if correct else None,
        )
        db.add(progress)

    await db.commit()

    # Post to Slack if configured and correct
    if correct and org.slack_channel_id:
        await slack_service.post_achievement(
            org.slack_channel_id,
            current_user.full_name or current_user.email,
            challenge.title,
            challenge.points,
        )

    return {
        "correct": correct,
        "explanation": challenge.explanation,
        "points_earned": points_earned,
    }


@app.get("/api/progress", response_model=List[UserProgressResponse])
async def get_progress(
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    """Get user progress."""
    result = await db.execute(
        select(UserProgress, Challenge)
        .join(Challenge)
        .where(UserProgress.user_id == current_user.id)
    )
    records = result.all()

    return [
        UserProgressResponse(
            challenge_id=record.UserProgress.challenge_id,
            challenge_title=record.Challenge.title,
            completed=record.UserProgress.completed,
            correct=record.UserProgress.correct,
            attempts=record.UserProgress.attempts,
            time_spent_seconds=record.UserProgress.time_spent_seconds,
            completed_at=record.UserProgress.completed_at,
        )
        for record in records
    ]


# Dashboard endpoints
@app.get("/api/dashboard/stats", response_model=DashboardStats)
async def get_dashboard_stats(
    current_user: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)
):
    """Get dashboard statistics."""
    org_id = current_user.organization_id

    # Total users
    result = await db.execute(select(func.count(User.id)).where(User.organization_id == org_id))
    total_users = result.scalar()

    # Active users (last 7 days)
    week_ago = datetime.utcnow() - timedelta(days=7)
    result = await db.execute(
        select(func.count(User.id)).where(
            and_(User.organization_id == org_id, User.last_login >= week_ago)
        )
    )
    active_users = result.scalar()

    # Challenges completed
    result = await db.execute(
        select(func.count(UserProgress.id)).where(
            and_(UserProgress.organization_id == org_id, UserProgress.completed == True)
        )
    )
    challenges_completed = result.scalar()

    # Completion rate
    result = await db.execute(
        select(func.count(UserProgress.id)).where(UserProgress.organization_id == org_id)
    )
    total_attempts = result.scalar()
    completion_rate = (challenges_completed / total_attempts * 100) if total_attempts > 0 else 0

    # Total training hours
    result = await db.execute(
        select(func.sum(UserProgress.time_spent_seconds)).where(
            UserProgress.organization_id == org_id
        )
    )
    total_seconds = result.scalar() or 0
    total_hours = total_seconds / 3600

    return {
        "total_users": total_users,
        "active_users_7d": active_users,
        "challenges_completed": challenges_completed,
        "avg_completion_rate": completion_rate,
        "total_training_hours": total_hours,
    }


@app.get("/api/dashboard/leaderboard", response_model=List[LeaderboardEntry])
async def get_leaderboard(
    current_user: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)
):
    """Get organization leaderboard."""
    result = await db.execute(
        select(
            User.full_name,
            User.email,
            func.count(UserProgress.id).label("challenges_completed"),
            func.sum(Challenge.points).label("points_earned"),
            func.avg(UserProgress.time_spent_seconds).label("avg_time"),
        )
        .join(UserProgress)
        .join(Challenge)
        .where(
            and_(
                User.organization_id == current_user.organization_id,
                UserProgress.completed == True,
            )
        )
        .group_by(User.id)
        .order_by(func.sum(Challenge.points).desc())
        .limit(10)
    )

    entries = []
    for row in result:
        entries.append(
            LeaderboardEntry(
                user_name=row.full_name or row.email,
                challenges_completed=row.challenges_completed,
                points_earned=row.points_earned or 0,
                avg_time_seconds=int(row.avg_time or 0),
            )
        )

    return entries


# Compliance endpoints
@app.post("/api/compliance/report")
async def generate_report(
    request: ComplianceReportRequest,
    current_user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Generate compliance report PDF."""
    pdf_buffer = await generate_compliance_report(
        db, current_user.organization_id, request.start_date, request.end_date, request.user_ids
    )

    return Response(
        content=pdf_buffer.read(),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=compliance_report_{datetime.utcnow().strftime('%Y%m%d')}.pdf"
        },
    )


# Stripe endpoints
@app.post("/api/billing/checkout")
async def create_checkout(
    plan: str,
    current_user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Create Stripe checkout session."""
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()

    if plan == "seat":
        price_id = settings.stripe_price_id_seat
        quantity = 1
    elif plan == "team":
        price_id = settings.stripe_price_id_team
        quantity = 1
    else:
        raise HTTPException(status_code=400, detail="Invalid plan")

    checkout_url = await create_checkout_session(
        org.stripe_customer_id,
        price_id,
        quantity,
        f"{settings.frontend_url}/dashboard?success=true",
        f"{settings.frontend_url}/dashboard?cancelled=true",
    )

    return {"url": checkout_url}


@app.post("/api/billing/portal")
async def create_portal(
    current_user: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)
):
    """Create Stripe billing portal session."""
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()

    portal_url = await create_billing_portal_session(
        org.stripe_customer_id, f"{settings.frontend_url}/dashboard"
    )

    return {"url": portal_url}


@app.post("/api/webhooks/stripe")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    """Handle Stripe webhooks."""
    payload = await request.body()
    signature = request.headers.get("stripe-signature")

    try:
        event = verify_webhook_signature(payload, signature)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid signature")

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        customer_id = session["customer"]

        # Update organization subscription
        result = await db.execute(
            select(Organization).where(Organization.stripe_customer_id == customer_id)
        )
        org = result.scalar_one_or_none()
        if org:
            org.subscription_status = "active"
            await db.commit()

    elif event["type"] == "customer.subscription.deleted":
        subscription = event["data"]["object"]
        customer_id = subscription["customer"]

        result = await db.execute(
            select(Organization).where(Organization.stripe_customer_id == customer_id)
        )
        org = result.scalar_one_or_none()
        if org:
            org.subscription_status = "cancelled"
            await db.commit()

    return {"status": "success"}


# Slack endpoints
@app.post("/api/slack/connect")
async def connect_slack(
    workspace_id: str,
    channel_id: str,
    current_user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Connect Slack workspace."""
    result = await db.execute(
        select(Organization).where(Organization.id == current_user.organization_id)
    )
    org = result.scalar_one()

    org.slack_workspace_id = workspace_id
    org.slack_channel_id = channel_id
    await db.commit()

    return {"message": "Slack connected successfully"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
