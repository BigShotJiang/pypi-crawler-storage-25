"""Application configuration."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings from environment variables."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Database
    database_url: str = "sqlite+aiosqlite:///./academy.db"

    # Security
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 10080  # 1 week

    # Stripe
    stripe_secret_key: str
    stripe_webhook_secret: str
    stripe_price_id_seat: str
    stripe_price_id_team: str

    # Slack
    slack_bot_token: str = ""
    slack_signing_secret: str = ""

    # Application
    frontend_url: str = "http://localhost:3000"
    backend_url: str = "http://localhost:8000"


settings = Settings()
