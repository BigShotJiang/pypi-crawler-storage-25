"""Supply Chain Security Academy - Enterprise training platform."""
