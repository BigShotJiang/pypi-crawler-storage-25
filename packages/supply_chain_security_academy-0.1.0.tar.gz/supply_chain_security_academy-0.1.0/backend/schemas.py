"""Pydantic schemas for request/response validation."""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field


# Auth schemas
class UserCreate(BaseModel):
    """Schema for creating a new user."""

    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str
    organization_name: str


class UserLogin(BaseModel):
    """Schema for user login."""

    email: EmailStr
    password: str


class Token(BaseModel):
    """Schema for JWT token response."""

    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    """Schema for user data in responses."""

    id: int
    email: str
    full_name: Optional[str]
    is_admin: bool
    organization_id: int

    class Config:
        from_attributes = True


# Organization schemas
class OrganizationResponse(BaseModel):
    """Schema for organization data."""

    id: int
    name: str
    subscription_status: str
    subscription_seats: int
    slack_workspace_id: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class TeamMemberInvite(BaseModel):
    """Schema for inviting team members."""

    email: EmailStr
    full_name: str


# Challenge schemas
class ChallengeResponse(BaseModel):
    """Schema for challenge data."""

    id: int
    title: str
    description: str
    difficulty: str
    category: str
    package_data: str
    points: int
    is_free: bool

    class Config:
        from_attributes = True


class ChallengeSubmit(BaseModel):
    """Schema for submitting a challenge answer."""

    challenge_id: int
    is_malicious: bool
    time_spent_seconds: int


class ChallengeResult(BaseModel):
    """Schema for challenge submission result."""

    correct: bool
    explanation: str
    points_earned: int


# Progress schemas
class UserProgressResponse(BaseModel):
    """Schema for user progress data."""

    challenge_id: int
    challenge_title: str
    completed: bool
    correct: Optional[bool]
    attempts: int
    time_spent_seconds: int
    completed_at: Optional[datetime]

    class Config:
        from_attributes = True


# Dashboard schemas
class DashboardStats(BaseModel):
    """Schema for dashboard statistics."""

    total_users: int
    active_users_7d: int
    challenges_completed: int
    avg_completion_rate: float
    total_training_hours: float


class LeaderboardEntry(BaseModel):
    """Schema for leaderboard entry."""

    user_name: str
    challenges_completed: int
    points_earned: int
    avg_time_seconds: int


# Compliance schemas
class ComplianceReportRequest(BaseModel):
    """Schema for requesting compliance report."""

    start_date: datetime
    end_date: datetime
    user_ids: Optional[List[int]] = None


class ComplianceReportResponse(BaseModel):
    """Schema for compliance report data."""

    organization_name: str
    report_period: str
    total_training_hours: float
    users_trained: int
    challenges_completed: int
    completion_rate: float
    generated_at: datetime
