# supply-chain-security-academy

A B2B SaaS platform that transforms npm-threat-detector-game into an enterprise security training solution with team management, Slack integration, and SOC2-compliant reporting. Targets security teams at Series A+ startups during the 30-day procurement window opened by the Axios NPM breach, converting the existing game into a revenue-generating training platform with $49/seat/year pricing.
