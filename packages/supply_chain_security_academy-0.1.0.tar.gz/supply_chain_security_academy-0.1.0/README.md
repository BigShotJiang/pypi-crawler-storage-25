# Supply Chain Security Academy

Transform your team into supply chain security experts with enterprise-grade training and compliance reporting.

## What is this?

Supply Chain Security Academy is a B2B SaaS platform that gamifies npm supply chain security training for enterprise teams. Built on proven game mechanics from npm-threat-detector-game, it adds team management, Slack integration, and SOC2-compliant reporting—purpose-built for security teams during procurement windows opened by real-world threats like the Axios NPM breach.

## Features

- **Team Management** – Invite users, track progress per seat, manage roles and permissions
- **Interactive Challenges** – 20+ hands-on npm threat detection scenarios and best practices
- **Admin Dashboard** – Real-time completion rates, time-per-challenge analytics, and team leaderboards
- **Slack Integration** – Weekly challenge notifications and achievement celebrations in your workspace
- **Compliance Exports** – SOC2/ISO27001-ready PDF reports documenting training completion hours
- **Flexible Pricing** – Freemium model with free tier (5 challenges, single-player) and Pro tier ($49/seat/year)
- **Stripe Checkout** – Secure billing for individuals and teams

## Quick Start

### Installation

```bash
# Clone the repository
git clone <repo-url>
cd supply-chain-security-academy

# Install dependencies
pip install -e .

# Copy environment template
cp .env.example .env

# Configure your credentials
# Update .env with database URL, Stripe keys, Slack bot token, etc.

# Initialize database
python -m backend.database init

# Run the server
python -m backend.main
```

### Environment Setup

Create a `.env` file with:
```
DATABASE_URL=postgresql://user:password@localhost/academy
STRIPE_SECRET_KEY=sk_...
SLACK_BOT_TOKEN=xoxb-...
JWT_SECRET=your-secret-key
ENVIRONMENT=development
```

## Usage Examples

### Create a Team Account
```bash
POST /api/teams
{
  "name": "Acme Security",
  "email": "security@acme.com",
  "seats": 5
}
```

### Invite Team Members
```bash
POST /api/teams/{team_id}/invitations
{
  "email": "engineer@acme.com",
  "role": "player"
}
```

### Generate Compliance Report
```bash
GET /api/teams/{team_id}/compliance-report?format=pdf
```

### Configure Slack Integration
```bash
POST /api/integrations/slack
{
  "team_id": "team_123",
  "bot_token": "xoxb-...",
  "channel": "#security-training"
}
```

## Tech Stack

- **Backend**: Python 3.11, FastAPI
- **Database**: PostgreSQL
- **Authentication**: JWT
- **Payments**: Stripe
- **Integrations**: Slack API
- **Compliance**: SOC2-ready audit logging
- **ORM**: SQLAlchemy

## License

MIT