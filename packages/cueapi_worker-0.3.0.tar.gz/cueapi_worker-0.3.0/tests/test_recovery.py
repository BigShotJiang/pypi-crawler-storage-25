"""Tests for cueapi_worker.recovery — automatic key recovery."""
from __future__ import annotations

import os
import tempfile
from unittest import mock

import pytest
import yaml

from cueapi_worker.recovery import (
    MAX_RECOVERY_ATTEMPTS,
    _single_recovery_attempt,
    attempt_key_recovery,
)


def _mock_response(status_code=200, json_data=None):
    """Create a mock httpx.Response."""
    resp = mock.MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    return resp


def test_recovery_success():
    """Successful recovery: device-code → email → poll returns new key."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump({"api_key": "cue_sk_old", "handlers": {"test": "echo hi"}}, f)
        config_path = f.name

    try:
        responses = [
            # Step 1: create device code
            _mock_response(201, {"verification_url": "http://...", "expires_in": 900}),
            # Step 2: submit email
            _mock_response(200, {"status": "email_sent"}),
            # Step 3: poll — first pending, then approved
            _mock_response(200, {"status": "pending"}),
            _mock_response(200, {"status": "approved", "api_key": "cue_sk_new123", "email": "test@example.com"}),
        ]

        with mock.patch("cueapi_worker.recovery.httpx.post", side_effect=responses):
            with mock.patch("cueapi_worker.recovery.time.sleep"):  # skip sleeps
                result = _single_recovery_attempt(config_path, "test@example.com", "https://api.cueapi.ai")

        assert result == "cue_sk_new123"

        # Verify config was updated
        with open(config_path) as f:
            data = yaml.safe_load(f)
        assert data["api_key"] == "cue_sk_new123"
        assert data["handlers"] == {"test": "echo hi"}  # Preserved
    finally:
        os.unlink(config_path)


def test_recovery_existing_user_returns_none():
    """Existing user response means we can't auto-recover — returns None."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump({"api_key": "cue_sk_old"}, f)
        config_path = f.name

    try:
        responses = [
            _mock_response(201, {"verification_url": "http://...", "expires_in": 900}),
            _mock_response(200, {"status": "email_sent"}),
            _mock_response(200, {"status": "approved", "existing_user": True, "email": "test@example.com"}),
        ]

        with mock.patch("cueapi_worker.recovery.httpx.post", side_effect=responses):
            with mock.patch("cueapi_worker.recovery.time.sleep"):
                result = _single_recovery_attempt(config_path, "test@example.com", "https://api.cueapi.ai")

        assert result is None

        # Config should NOT be changed
        with open(config_path) as f:
            data = yaml.safe_load(f)
        assert data["api_key"] == "cue_sk_old"
    finally:
        os.unlink(config_path)


def test_recovery_expired_returns_none():
    """Expired device code returns None."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump({"api_key": "cue_sk_old"}, f)
        config_path = f.name

    try:
        responses = [
            _mock_response(201, {"verification_url": "http://...", "expires_in": 900}),
            _mock_response(200, {"status": "email_sent"}),
            _mock_response(200, {"status": "expired"}),
        ]

        with mock.patch("cueapi_worker.recovery.httpx.post", side_effect=responses):
            with mock.patch("cueapi_worker.recovery.time.sleep"):
                result = _single_recovery_attempt(config_path, "test@example.com", "https://api.cueapi.ai")

        assert result is None
    finally:
        os.unlink(config_path)


def test_recovery_network_error_returns_none():
    """Network error on device code creation returns None."""
    import httpx

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump({"api_key": "cue_sk_old"}, f)
        config_path = f.name

    try:
        with mock.patch("cueapi_worker.recovery.httpx.post", side_effect=httpx.ConnectError("connection refused")):
            with mock.patch("cueapi_worker.recovery.time.sleep"):
                result = _single_recovery_attempt(config_path, "test@example.com", "https://api.cueapi.ai")

        assert result is None
    finally:
        os.unlink(config_path)


def test_attempt_key_recovery_retries():
    """attempt_key_recovery retries up to MAX_RECOVERY_ATTEMPTS times."""
    call_count = 0

    def mock_single_attempt(config_path, email, api_base):
        nonlocal call_count
        call_count += 1
        return None  # Always fail

    with mock.patch("cueapi_worker.recovery._single_recovery_attempt", side_effect=mock_single_attempt):
        with mock.patch("cueapi_worker.recovery.time.sleep"):
            result = attempt_key_recovery("/tmp/test.yaml", "test@example.com", "https://api.cueapi.ai")

    assert result is None
    assert call_count == MAX_RECOVERY_ATTEMPTS


def test_attempt_key_recovery_stops_on_success():
    """attempt_key_recovery stops retrying after first success."""
    call_count = 0

    def mock_single_attempt(config_path, email, api_base):
        nonlocal call_count
        call_count += 1
        if call_count == 2:
            return "cue_sk_recovered"
        return None

    with mock.patch("cueapi_worker.recovery._single_recovery_attempt", side_effect=mock_single_attempt):
        with mock.patch("cueapi_worker.recovery.time.sleep"):
            result = attempt_key_recovery("/tmp/test.yaml", "test@example.com", "https://api.cueapi.ai")

    assert result == "cue_sk_recovered"
    assert call_count == 2  # Stopped after success on attempt 2
