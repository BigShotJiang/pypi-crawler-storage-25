"""Tests for cueapi_worker.executor.

Covers:
  - resolve_template (inherited from earlier phases)
  - execute_handler basic success/failure/timeout/env flow
  - Chain-pattern credential injection (CUEAPI_API_KEY / CUEAPI_BASE_URL)
  - CUEAPI_OUTCOME_FILE end-to-end: creation, parsing, validation,
    cleanup, size cap, malformed JSON, unknown-field dropping.
  - execute_handler now returns a 3-tuple:
    (exit_success, output, outcome_info).
"""
from __future__ import annotations

import json
import os
import tempfile

import pytest

from cueapi_worker.config import HandlerConfig
from cueapi_worker.executor import (
    MAX_OUTCOME_FILE_BYTES,
    _read_outcome_file,
    _validate_outcome_payload,
    execute_handler,
    resolve_template,
)


# ── resolve_template tests ───────────────────────────────────────


def test_resolve_template_simple():
    result = resolve_template(
        "Hello {{ payload.name }}, your task is {{ payload.task }}",
        {"name": "Alice", "task": "backup"},
    )
    assert result == "Hello Alice, your task is backup"


def test_resolve_template_nested():
    result = resolve_template(
        "Fetch from {{ payload.context.url }}",
        {"context": {"url": "https://example.com"}},
    )
    assert result == "Fetch from https://example.com"


def test_resolve_template_missing_key():
    result = resolve_template(
        "Value: {{ payload.missing }}!",
        {"name": "test"},
    )
    assert result == "Value: !"


# ── execute_handler basic flow ────────────────────────────────────


def _call(handler, **kwargs):
    """Invoke execute_handler with sensible defaults for tests that
    don't care about ids or the outcome-file contents."""
    defaults = dict(
        payload={},
        execution_id="exec-test",
        cue_id="cue-test",
        cue_name="cue-name",
        worker_id="worker-test",
    )
    defaults.update(kwargs)
    return execute_handler(handler=handler, **defaults)


def test_handler_success():
    """Exit 0 with no outcome file → exit_success=True, outcome_info=None."""
    exit_success, output, outcome_info = _call(
        HandlerConfig(cmd="echo 'hello world'", timeout=10)
    )
    assert exit_success is True
    assert "hello world" in output
    assert outcome_info is None


def test_handler_failure():
    """Exit != 0 with no outcome file → exit_success=False, outcome_info=None."""
    exit_success, output, outcome_info = _call(
        HandlerConfig(cmd="exit 1", timeout=10),
        execution_id="exec-2",
    )
    assert exit_success is False
    assert outcome_info is None


def test_handler_timeout():
    """Timeout returns (False, timeout-msg, None)."""
    exit_success, output, outcome_info = _call(
        HandlerConfig(cmd="sleep 10", timeout=1),
        execution_id="exec-3",
    )
    assert exit_success is False
    assert "timed out" in output.lower()
    # Timeout means we distrust any partial file the handler left.
    assert outcome_info is None


def test_handler_env_with_template():
    exit_success, output, _ = _call(
        HandlerConfig(
            cmd='echo "$MY_VAR"',
            timeout=10,
            env={"MY_VAR": "{{ payload.value }}"},
        ),
        payload={"value": "injected_value"},
        execution_id="exec-4",
    )
    assert exit_success is True
    assert "injected_value" in output


# ── chain-pattern credential injection tests ────────────────────


def test_handler_env_includes_api_credentials_when_provided():
    handler = HandlerConfig(
        cmd='echo "KEY=$CUEAPI_API_KEY BASE=$CUEAPI_BASE_URL"',
        timeout=10,
    )
    exit_success, output, _ = _call(
        handler,
        execution_id="exec-5",
        api_key="cue_sk_testkey_abc123",
        api_base="https://staging.api.cueapi.ai",
    )
    assert exit_success is True
    assert "KEY=cue_sk_testkey_abc123" in output
    assert "BASE=https://staging.api.cueapi.ai" in output


def test_handler_env_omits_api_credentials_when_not_provided():
    for key in ("CUEAPI_API_KEY", "CUEAPI_BASE_URL"):
        os.environ.pop(key, None)

    handler = HandlerConfig(
        cmd=(
            'if [ -z "${CUEAPI_API_KEY+x}" ]; then echo "KEY=unset"; '
            'else echo "KEY=set"; fi; '
            'if [ -z "${CUEAPI_BASE_URL+x}" ]; then echo "BASE=unset"; '
            'else echo "BASE=set"; fi'
        ),
        timeout=10,
    )
    exit_success, output, _ = _call(handler, execution_id="exec-6")
    assert exit_success is True, output
    assert "KEY=unset" in output
    assert "BASE=unset" in output


# ── CUEAPI_OUTCOME_FILE: env exposure + cleanup ────────────────


def test_outcome_file_env_var_is_exposed():
    """Every handler receives a CUEAPI_OUTCOME_FILE path."""
    exit_success, output, _ = _call(
        HandlerConfig(cmd='echo "FILE=$CUEAPI_OUTCOME_FILE"', timeout=10)
    )
    assert exit_success is True
    assert "FILE=" in output
    # Path should look like a tempfile: contains our prefix + .json suffix
    assert "cueapi-outcome-" in output
    assert ".json" in output


def test_outcome_file_deleted_after_read():
    """Temp file is removed after the handler returns, even on success."""
    # Run the handler, capture the path it was given, then assert the
    # path no longer exists.
    handler = HandlerConfig(
        cmd='echo "$CUEAPI_OUTCOME_FILE"',
        timeout=10,
    )
    exit_success, output, _ = _call(handler)
    assert exit_success is True
    path = output.strip()
    assert path  # not empty
    assert not os.path.exists(path), f"temp file {path} leaked"


def test_outcome_file_deleted_even_on_timeout():
    """Timeout path must still delete the temp file."""
    handler = HandlerConfig(
        # Capture the path then sleep past the timeout.
        cmd='echo "$CUEAPI_OUTCOME_FILE"; sleep 10',
        timeout=1,
    )
    exit_success, output, _ = _call(handler)
    assert exit_success is False
    # `output` on timeout is the timeout message, not the echo. We need
    # another way to get the path. Scan /tmp for stragglers matching
    # our prefix — should be zero left after a clean run.
    leftover = [
        p
        for p in os.listdir(tempfile.gettempdir())
        if p.startswith("cueapi-outcome-") and p.endswith(".json")
    ]
    # Race: this test intentionally runs the handler to timeout, and
    # the finally-block does the cleanup. Leftovers here would indicate
    # the finally didn't fire.
    assert not leftover, f"outcome files leaked: {leftover}"


# ── CUEAPI_OUTCOME_FILE: payload reading ─────────────────────────


def test_outcome_file_success_true_with_evidence_fields():
    """Handler writes a valid JSON payload; outcome_info returns the
    validated fields."""
    handler = HandlerConfig(
        cmd=(
            'cat > "$CUEAPI_OUTCOME_FILE" <<EOF\n'
            '{"success": true, "external_id": "tweet:123", '
            '"result_url": "https://twitter.com/u/status/123", '
            '"summary": "posted"}\n'
            "EOF"
        ),
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert outcome_info is not None
    assert outcome_info["parse_error"] is None
    assert outcome_info["dropped_fields"] == []
    payload = outcome_info["payload"]
    assert payload["success"] is True
    assert payload["external_id"] == "tweet:123"
    assert payload["result_url"] == "https://twitter.com/u/status/123"
    assert payload["summary"] == "posted"


def test_outcome_file_success_false_is_validated_as_bool():
    """success=false round-trips as a boolean."""
    handler = HandlerConfig(
        cmd='echo \'{"success": false, "error": "upstream refused"}\' > "$CUEAPI_OUTCOME_FILE"',
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True  # the shell exit is 0
    payload = outcome_info["payload"]
    assert payload["success"] is False
    assert payload["error"] == "upstream refused"


def test_outcome_file_empty_is_treated_as_opt_out():
    """Empty file → outcome_info is None (same as not writing anything)."""
    handler = HandlerConfig(
        cmd='true',  # doesn't touch the outcome file
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert outcome_info is None


def test_outcome_file_malformed_json_falls_back():
    """Non-JSON contents → payload=None, parse_error populated."""
    handler = HandlerConfig(
        cmd='echo "not json at all" > "$CUEAPI_OUTCOME_FILE"',
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert outcome_info is not None
    assert outcome_info["payload"] is None
    assert outcome_info["parse_error"] is not None
    assert "malformed" in outcome_info["parse_error"]


def test_outcome_file_exceeds_10kb_falls_back():
    """Files larger than MAX_OUTCOME_FILE_BYTES are rejected."""
    # Write ~11 KB of valid-ish JSON. Use `yes` to generate bytes
    # quickly; head to bound the size. Size must exceed 10 KB.
    size_bytes = MAX_OUTCOME_FILE_BYTES + 1024
    handler = HandlerConfig(
        cmd=(
            f'python3 -c "import sys; sys.stdout.write(\\"a\\"*{size_bytes})" '
            f'> "$CUEAPI_OUTCOME_FILE"'
        ),
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert outcome_info is not None
    assert outcome_info["payload"] is None
    assert "too_large" in outcome_info["parse_error"]


def test_outcome_file_unknown_fields_dropped():
    """Valid JSON with unknown keys → keys dropped, known fields kept."""
    handler = HandlerConfig(
        cmd=(
            'cat > "$CUEAPI_OUTCOME_FILE" <<EOF\n'
            '{"success": true, "external_id": "ok", '
            '"frobnicator": "???", "whatever": 42}\n'
            "EOF"
        ),
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert outcome_info["payload"]["success"] is True
    assert outcome_info["payload"]["external_id"] == "ok"
    assert "frobnicator" in outcome_info["dropped_fields"]
    assert "whatever" in outcome_info["dropped_fields"]
    # Unknowns must not leak into the validated payload.
    assert "frobnicator" not in outcome_info["payload"]
    assert "whatever" not in outcome_info["payload"]


def test_outcome_file_result_url_must_be_http():
    """result_url values that aren't http(s) are dropped."""
    handler = HandlerConfig(
        cmd=(
            'cat > "$CUEAPI_OUTCOME_FILE" <<EOF\n'
            '{"success": true, "result_url": "file:///etc/passwd"}\n'
            "EOF"
        ),
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert "result_url" in outcome_info["dropped_fields"]
    assert "result_url" not in outcome_info["payload"]


def test_outcome_file_oversize_string_dropped():
    """A too-long string field (e.g. summary > 500 chars) is dropped
    individually without rejecting the whole file."""
    long_summary = "x" * 501
    handler = HandlerConfig(
        cmd=(
            f"""python3 -c "import json, os; open(os.environ['CUEAPI_OUTCOME_FILE'], 'w').write(json.dumps({{'success': True, 'summary': '{long_summary}', 'external_id': 'ok'}}))" """
        ),
        timeout=10,
    )
    exit_success, _, outcome_info = _call(handler)
    assert exit_success is True
    assert "summary" in outcome_info["dropped_fields"]
    # Other valid fields are kept.
    assert outcome_info["payload"]["external_id"] == "ok"
    assert outcome_info["payload"]["success"] is True


# ── _validate_outcome_payload: direct unit coverage ─────────────


def test_validate_outcome_payload_non_dict_rejected():
    out, dropped = _validate_outcome_payload(["a list, not a dict"])
    assert out == {}
    assert dropped  # non-empty explanation


def test_validate_outcome_payload_wrong_types_dropped():
    out, dropped = _validate_outcome_payload(
        {
            "success": "true",  # string, not bool
            "external_id": 123,  # int, not str
            "artifacts": {"not": "a list"},
            "metadata": [1, 2, 3],  # list, not dict
        }
    )
    assert out == {}
    assert set(dropped) == {"success", "external_id", "artifacts", "metadata"}


def test_validate_outcome_payload_int_is_not_bool():
    """Python's bool-is-subclass-of-int quirk must not leak in."""
    out, dropped = _validate_outcome_payload({"success": 1})
    assert "success" in dropped
    assert out == {}
