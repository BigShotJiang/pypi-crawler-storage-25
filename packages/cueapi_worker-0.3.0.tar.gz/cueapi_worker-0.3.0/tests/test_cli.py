"""Tests for cueapi_worker.cli — 9 tests."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import yaml
from click.testing import CliRunner

from cueapi_worker.cli import main


def test_version():
    """Test --version flag."""
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.3.0" in result.output


def test_start_missing_config():
    """Test start command with non-existent config file."""
    runner = CliRunner()
    result = runner.invoke(main, ["start", "--config", "/nonexistent/config.yaml"])
    assert result.exit_code != 0


def test_help():
    """Test help output lists all commands."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "start" in result.output
    assert "status" in result.output
    assert "install-service" in result.output
    assert "uninstall-service" in result.output
    assert "regenerate-key" in result.output
    assert "login" in result.output


# --- regenerate-key tests ---


def _make_config(tmp_path, api_key="cue_sk_testkey123"):
    """Create a minimal config YAML for testing."""
    cfg = {
        "api_key": api_key,
        "api_base": "https://api.cueapi.ai",
        "handlers": {"test_task": "echo hello"},
    }
    path = tmp_path / "worker.yaml"
    path.write_text(yaml.dump(cfg))
    return str(path)


def test_regenerate_key_success(tmp_path):
    """regenerate-key with valid key returns new key and updates config."""
    config_path = _make_config(tmp_path)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"api_key": "cue_sk_newkey456", "previous_key_revoked": True}

    with patch("cueapi_worker.cli.httpx.post", return_value=mock_resp) as mock_post:
        runner = CliRunner()
        result = runner.invoke(main, ["regenerate-key", "--config", config_path])

    assert result.exit_code == 0
    assert "Key regenerated" in result.output
    assert "Restart the worker" in result.output

    # Verify config was updated
    with open(config_path) as f:
        data = yaml.safe_load(f)
    assert data["api_key"] == "cue_sk_newkey456"
    # Verify other fields preserved
    assert data["handlers"]["test_task"] == "echo hello"

    # Verify correct headers sent
    call_kwargs = mock_post.call_args
    headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
    assert headers["X-Confirm-Destructive"] == "true"
    assert "Bearer cue_sk_testkey123" in headers["Authorization"]


def test_regenerate_key_invalid_key(tmp_path):
    """regenerate-key with 401 suggests login command."""
    config_path = _make_config(tmp_path)

    mock_resp = MagicMock()
    mock_resp.status_code = 401
    mock_resp.text = "Unauthorized"

    with patch("cueapi_worker.cli.httpx.post", return_value=mock_resp):
        runner = CliRunner()
        result = runner.invoke(main, ["regenerate-key", "--config", config_path])

    assert result.exit_code == 1
    assert "invalid" in result.output.lower() or "invalid" in (result.output + getattr(result, 'stderr', '')).lower()


def test_regenerate_key_server_error(tmp_path):
    """regenerate-key with 500 shows error."""
    config_path = _make_config(tmp_path)

    mock_resp = MagicMock()
    mock_resp.status_code = 500
    mock_resp.text = "Internal server error"

    with patch("cueapi_worker.cli.httpx.post", return_value=mock_resp):
        runner = CliRunner()
        result = runner.invoke(main, ["regenerate-key", "--config", config_path])

    assert result.exit_code == 1
    assert "500" in result.output or "Error" in result.output


# --- login tests ---


def test_login_success(tmp_path):
    """login flow: device-code → submit-email → poll approved → config updated."""
    config_path = str(tmp_path / "worker.yaml")
    # Create a minimal existing config (no api_key)
    (tmp_path / "worker.yaml").write_text(yaml.dump({"handlers": {"my_task": "echo hi"}}))

    responses = [
        # 1. POST /v1/auth/device-code → 200
        MagicMock(status_code=200, json=MagicMock(return_value={"verification_url": "https://api.cueapi.ai/v1/auth/verify", "expires_in": 900})),
        # 2. POST /v1/auth/device-code/submit-email → 200
        MagicMock(status_code=200, json=MagicMock(return_value={"status": "email_sent"})),
        # 3. POST /v1/auth/device-code/poll → approved
        MagicMock(status_code=200, json=MagicMock(return_value={"status": "approved", "api_key": "cue_sk_fromlogin789", "email": "test@example.com"})),
    ]

    with patch("cueapi_worker.cli.httpx.post", side_effect=responses):
        with patch("cueapi_worker.cli.time.sleep"):  # Skip actual sleep
            runner = CliRunner()
            result = runner.invoke(main, ["login", "--email", "test@example.com", "--config", config_path])

    assert result.exit_code == 0
    assert "Authenticated" in result.output
    assert "Restart the worker" in result.output

    # Verify config updated with key
    with open(config_path) as f:
        data = yaml.safe_load(f)
    assert data["api_key"] == "cue_sk_fromlogin789"
    assert data["handlers"]["my_task"] == "echo hi"


def test_login_expired(tmp_path):
    """login flow: device code expires → error message."""
    config_path = str(tmp_path / "worker.yaml")
    (tmp_path / "worker.yaml").write_text(yaml.dump({"handlers": {"t": "echo x"}}))

    responses = [
        MagicMock(status_code=200, json=MagicMock(return_value={"verification_url": "...", "expires_in": 900})),
        MagicMock(status_code=200, json=MagicMock(return_value={"status": "email_sent"})),
        MagicMock(status_code=200, json=MagicMock(return_value={"status": "expired"})),
    ]

    with patch("cueapi_worker.cli.httpx.post", side_effect=responses):
        with patch("cueapi_worker.cli.time.sleep"):
            runner = CliRunner()
            result = runner.invoke(main, ["login", "--email", "test@example.com", "--config", config_path])

    assert result.exit_code == 1
    assert "expired" in result.output.lower()


def test_login_creates_new_config(tmp_path):
    """login creates config file if it doesn't exist."""
    config_path = str(tmp_path / "new_worker.yaml")

    responses = [
        MagicMock(status_code=200, json=MagicMock(return_value={"verification_url": "...", "expires_in": 900})),
        MagicMock(status_code=200, json=MagicMock(return_value={"status": "email_sent"})),
        MagicMock(status_code=200, json=MagicMock(return_value={"status": "approved", "api_key": "cue_sk_brand_new", "email": "new@example.com"})),
    ]

    with patch("cueapi_worker.cli.httpx.post", side_effect=responses):
        with patch("cueapi_worker.cli.time.sleep"):
            runner = CliRunner()
            result = runner.invoke(main, ["login", "--email", "new@example.com", "--config", config_path])

    assert result.exit_code == 0
    assert "Authenticated" in result.output

    # File should now exist with the key
    with open(config_path) as f:
        data = yaml.safe_load(f)
    assert data["api_key"] == "cue_sk_brand_new"
