"""Tests for cueapi_worker.daemon.

Covers:
  - The poll cycle (claim, execute, report-outcome, failures).
  - Auth-failure recovery hooks.
  - Outcome conflict-resolution rules (_resolve_outcome pure helper):
    exit code vs. CUEAPI_OUTCOME_FILE semantics, evidence field
    merging, malformed-file diagnostics. See the inline comments
    in WorkerDaemon._execute_and_report for the full decision table.
"""
from __future__ import annotations

from unittest import mock

import pytest

from cueapi_worker.client import AuthenticationError
from cueapi_worker.config import HandlerConfig, WorkerConfig
from cueapi_worker.daemon import WorkerDaemon


def _make_config(**overrides) -> WorkerConfig:
    """Create a test WorkerConfig."""
    defaults = {
        "api_key": "cue_sk_test",
        "api_base": "http://localhost:8000",
        "worker_id": "test-worker",
        "poll_interval": 1,
        "heartbeat_interval": 30,
        "max_concurrent": 2,
        "handlers": {
            "backup": HandlerConfig(cmd="echo backup done", timeout=10),
            "report": HandlerConfig(cmd="echo report done", timeout=10),
        },
    }
    defaults.update(overrides)
    return WorkerConfig(**defaults)


def test_poll_cycle_claims_and_executes():
    """Test that poll cycle fetches, claims, and executes matching tasks."""
    config = _make_config()
    daemon = WorkerDaemon(config)

    # Mock the client
    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-1",
            "cue_id": "cue-1",
            "cue_name": "my-backup",
            "task": "backup",
            "payload": {"task": "backup"},
        }
    ]
    daemon._client.claim.return_value = {"claimed": True, "execution_id": "exec-1", "lease_seconds": 900}

    # Run one poll cycle
    daemon._poll_cycle()

    # Verify claim was called
    daemon._client.claim.assert_called_once_with("exec-1", "test-worker")

    # Wait for the executor to finish
    for future in daemon._active_futures:
        future.result(timeout=10)

    # Verify outcome was reported
    daemon._client.report_outcome.assert_called_once()
    call_kwargs = daemon._client.report_outcome.call_args
    assert call_kwargs.kwargs.get("execution_id") == "exec-1" or call_kwargs[1].get("execution_id") == "exec-1"


def test_poll_cycle_skips_unknown_task():
    """Test that poll cycle skips executions with no matching handler."""
    config = _make_config()
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-1",
            "cue_id": "cue-1",
            "cue_name": "unknown-cue",
            "task": "unknown_task",
            "payload": {"task": "unknown_task"},
        }
    ]

    daemon._poll_cycle()

    # Claim should NOT be called for unknown task
    daemon._client.claim.assert_not_called()


def test_poll_cycle_respects_max_concurrent():
    """Test that poll cycle stops claiming when at max_concurrent."""
    config = _make_config(max_concurrent=1)
    daemon = WorkerDaemon(config)

    # Simulate one active future
    future = mock.MagicMock()
    future.done.return_value = False
    daemon._active_futures.add(future)

    daemon._client = mock.MagicMock()

    daemon._poll_cycle()

    # Should not even call get_claimable
    daemon._client.get_claimable.assert_not_called()


def test_poll_cycle_reports_failure():
    """Test that handler failure gets reported as failed outcome."""
    config = _make_config(
        handlers={"fail_task": HandlerConfig(cmd="exit 1", timeout=10)}
    )
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-fail",
            "cue_id": "cue-1",
            "cue_name": "fail-cue",
            "task": "fail_task",
            "payload": {"task": "fail_task"},
        }
    ]
    daemon._client.claim.return_value = {"claimed": True, "execution_id": "exec-fail", "lease_seconds": 900}

    daemon._poll_cycle()

    # Wait for the executor to finish
    for future in daemon._active_futures:
        future.result(timeout=10)

    # Verify failure was reported
    daemon._client.report_outcome.assert_called_once()
    call_args = daemon._client.report_outcome.call_args
    # Check that success=False was passed
    assert call_args.kwargs.get("success") is False or (len(call_args.args) > 1 and call_args.args[1] is False)


def test_poll_cycle_handles_claim_failure():
    """Test that claim failure (409) is handled gracefully."""
    config = _make_config()
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-race",
            "cue_id": "cue-1",
            "cue_name": "race-cue",
            "task": "backup",
            "payload": {"task": "backup"},
        }
    ]
    daemon._client.claim.return_value = None  # Claim failed (409)

    daemon._poll_cycle()

    # Claim was attempted but no execution should be submitted
    daemon._client.claim.assert_called_once()
    assert len(daemon._active_futures) == 0


def test_daemon_recovers_on_401():
    """Test that daemon attempts recovery when auth fails and email is configured."""
    config = _make_config(email="test@example.com")
    daemon = WorkerDaemon(config, config_path="/tmp/test-config.yaml")
    daemon._running = True  # Simulate running state

    # Mock recovery to succeed (patching at source since daemon imports lazily)
    with mock.patch("cueapi_worker.recovery.attempt_key_recovery", return_value="cue_sk_recovered") as mock_recover:
        # _handle_auth_failure should recover and NOT raise SystemExit
        daemon._handle_auth_failure("API key is invalid")

    mock_recover.assert_called_once_with(
        config_path="/tmp/test-config.yaml",
        email="test@example.com",
        api_base="http://localhost:8000",
    )
    assert daemon._config.api_key == "cue_sk_recovered"
    assert daemon._running is True  # Should still be running after recovery


def test_daemon_exits_without_email():
    """Test that daemon exits immediately on 401 when no email is configured."""
    config = _make_config()  # No email
    daemon = WorkerDaemon(config, config_path="/tmp/test-config.yaml")
    daemon._running = True

    with pytest.raises(SystemExit) as exc_info:
        daemon._handle_auth_failure("API key is invalid")

    assert exc_info.value.code == 1


# ── _resolve_outcome: conflict-rule matrix ─────────────────────────
#
# These tests pin every combination of (exit_code, outcome_file_payload)
# against the rules documented in the inline comment on
# _execute_and_report. They exercise the pure helper directly so they
# don't depend on subprocess timing.


def _resolve(exit_success, output="handler output", outcome_info=None, effective_timeout=300):
    return WorkerDaemon._resolve_outcome(
        exit_success=exit_success,
        output=output,
        outcome_info=outcome_info,
        effective_timeout=effective_timeout,
    )


def test_no_outcome_file_exit_0():
    """Exit 0, no file → success=True, no evidence, no metadata."""
    success, result, error, evidence, metadata = _resolve(
        exit_success=True, output="did stuff", outcome_info=None
    )
    assert success is True
    assert result == "did stuff"
    assert error is None
    assert evidence == {}
    assert metadata is None


def test_no_outcome_file_exit_nonzero():
    """Exit != 0, no file → success=False, error from stdout, no evidence."""
    success, result, error, evidence, metadata = _resolve(
        exit_success=False, output="traceback: KeyError 'x'", outcome_info=None
    )
    assert success is False
    assert result is None
    assert "KeyError" in error
    assert evidence == {}
    assert metadata is None


def test_outcome_file_success_true_exit_0_merges_evidence():
    """Exit 0, file says success=True + evidence → success, evidence merged."""
    outcome_info = {
        "payload": {
            "success": True,
            "external_id": "tweet:123",
            "result_url": "https://twitter.com/u/status/123",
            "result_type": "tweet",
            "summary": "posted the brief",
            "artifacts": [{"path": "out.md"}],
        },
        "parse_error": None,
        "dropped_fields": [],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=True, output="ok", outcome_info=outcome_info
    )
    assert success is True
    assert error is None
    assert evidence == {
        "external_id": "tweet:123",
        "result_url": "https://twitter.com/u/status/123",
        "result_type": "tweet",
        "summary": "posted the brief",
        "artifacts": [{"path": "out.md"}],
    }
    # No diagnostics → no metadata added.
    assert metadata is None


def test_outcome_file_success_false_exit_0_file_wins():
    """Exit 0, file says success=False → FILE WINS: success=False,
    error from file if provided."""
    outcome_info = {
        "payload": {
            "success": False,
            "error": "downstream API returned 503",
            "external_id": "partial:abc",  # evidence still merged
        },
        "parse_error": None,
        "dropped_fields": [],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=True,  # shell says OK
        output="graceful shutdown",
        outcome_info=outcome_info,
    )
    assert success is False
    assert error == "downstream API returned 503"
    assert result is None
    # Evidence is merged regardless of success/failure.
    assert evidence == {"external_id": "partial:abc"}


def test_outcome_file_success_true_exit_nonzero_exit_code_wins():
    """Exit != 0, file says success=True → EXIT CODE WINS: crash trumps
    whatever the file wrote, because the file record is stale."""
    outcome_info = {
        "payload": {
            "success": True,
            "external_id": "tweet:did-not-really-happen",
        },
        "parse_error": None,
        "dropped_fields": [],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=False,
        output="segfault",
        outcome_info=outcome_info,
    )
    assert success is False
    # stdout/stderr (or file.error if present) becomes the error text.
    assert "segfault" in (error or "")
    # Evidence still merged — even a crashing process can have produced
    # real side effects we want recorded (e.g. a partial commit SHA).
    assert evidence == {"external_id": "tweet:did-not-really-happen"}


def test_outcome_file_absent_field_means_exit_code_decides_success():
    """Exit 0, file has evidence but no `success` field → default to
    exit-code-says-success (True). Handlers that only want to attach
    evidence shouldn't need to also write success=true explicitly."""
    outcome_info = {
        "payload": {
            "external_id": "charge_abc",
            "result_type": "stripe_charge",
        },
        "parse_error": None,
        "dropped_fields": [],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=True, output="done", outcome_info=outcome_info
    )
    assert success is True
    assert evidence == {"external_id": "charge_abc", "result_type": "stripe_charge"}


def test_outcome_file_malformed_falls_back_to_exit_code():
    """Unparseable file → payload=None → exit code decides, AND the
    parse error is surfaced in metadata for debugging."""
    outcome_info = {
        "payload": None,
        "parse_error": "outcome_file_malformed_json: Expecting value",
        "dropped_fields": [],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=True, output="ok", outcome_info=outcome_info
    )
    assert success is True
    assert evidence == {}
    # Parse error surfaced under the reserved namespace.
    assert metadata == {
        "_cueapi_worker": {
            "outcome_file_parse_error": "outcome_file_malformed_json: Expecting value",
        }
    }


def test_outcome_file_dropped_fields_surfaced_in_metadata():
    """Valid file with unknown/invalid fields → fields dropped, names
    surfaced under _cueapi_worker metadata."""
    outcome_info = {
        "payload": {"success": True, "external_id": "ok"},
        "parse_error": None,
        "dropped_fields": ["frobnicator", "whatever"],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=True, output="ok", outcome_info=outcome_info
    )
    assert success is True
    assert evidence == {"external_id": "ok"}
    assert metadata == {
        "_cueapi_worker": {
            "outcome_file_dropped_fields": ["frobnicator", "whatever"],
        }
    }


def test_user_metadata_merges_with_diagnostics():
    """User-supplied metadata is preserved alongside _cueapi_worker
    diagnostics."""
    outcome_info = {
        "payload": {"success": True, "metadata": {"user_field": 42}},
        "parse_error": None,
        "dropped_fields": ["unknown_key"],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=True, output="ok", outcome_info=outcome_info
    )
    assert success is True
    assert metadata == {
        "user_field": 42,
        "_cueapi_worker": {
            "outcome_file_dropped_fields": ["unknown_key"],
        },
    }


def test_timeout_renders_nice_error_regardless_of_file():
    """Timeout → exit code wins, error message uses the effective
    timeout value even if the file had its own error string."""
    outcome_info = {
        "payload": {"success": True, "error": "stale pre-timeout message"},
        "parse_error": None,
        "dropped_fields": [],
    }
    success, result, error, evidence, metadata = _resolve(
        exit_success=False,
        output="Handler timed out after 30s",  # matches the timeout template
        outcome_info=outcome_info,
        effective_timeout=30,
    )
    assert success is False
    assert error == "Handler timeout exceeded (30s)"


# ── _execute_and_report end-to-end: evidence plumbed to client ────


def test_execute_and_report_threads_evidence_to_client():
    """Full path: a handler writes a valid outcome file, daemon calls
    report_outcome with the evidence fields as keyword arguments.
    Integration test that exercises the executor → daemon → mock client
    pipeline without needing a real CueAPI server."""
    config = _make_config(
        handlers={
            "post_tweet": HandlerConfig(
                cmd=(
                    'cat > "$CUEAPI_OUTCOME_FILE" <<EOF\n'
                    '{"success": true, "external_id": "tweet:999", '
                    '"result_url": "https://twitter.com/u/status/999", '
                    '"result_type": "tweet", "summary": "posted"}\n'
                    "EOF"
                ),
                timeout=10,
            )
        }
    )
    daemon = WorkerDaemon(config)
    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-tweet",
            "cue_id": "cue-1",
            "cue_name": "daily-post",
            "task": "post_tweet",
            "payload": {},
        }
    ]
    daemon._client.claim.return_value = {
        "claimed": True,
        "execution_id": "exec-tweet",
        "lease_seconds": 900,
    }

    daemon._poll_cycle()
    for future in daemon._active_futures:
        future.result(timeout=10)

    daemon._client.report_outcome.assert_called_once()
    kwargs = daemon._client.report_outcome.call_args.kwargs
    assert kwargs["execution_id"] == "exec-tweet"
    assert kwargs["success"] is True
    assert kwargs["external_id"] == "tweet:999"
    assert kwargs["result_url"] == "https://twitter.com/u/status/999"
    assert kwargs["result_type"] == "tweet"
    assert kwargs["summary"] == "posted"
