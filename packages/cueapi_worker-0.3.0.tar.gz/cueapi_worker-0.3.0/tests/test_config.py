"""Tests for cueapi_worker.config — 5 tests."""
from __future__ import annotations

import os
import json
import textwrap
from pathlib import Path
from unittest import mock

import pytest
import yaml

from cueapi_worker.config import load_config, _resolve_api_key, _default_worker_id


@pytest.fixture
def tmp_config(tmp_path):
    """Helper to write a config YAML and return its path."""
    def _write(data: dict) -> str:
        path = tmp_path / "worker.yaml"
        path.write_text(yaml.dump(data))
        return str(path)
    return _write


def test_load_config_basic(tmp_config):
    """Test loading a valid config with api_key and handlers."""
    path = tmp_config({
        "api_key": "cue_sk_test123",
        "api_base": "http://localhost:8000",
        "worker_id": "test-worker",
        "poll_interval": 10,
        "max_concurrent": 2,
        "handlers": {
            "backup": "pg_dump mydb",
            "report": {
                "cmd": "python3 report.py",
                "timeout": 60,
                "cwd": "/tmp",
                "env": {"FOO": "bar"},
            },
        },
    })

    cfg = load_config(path)
    assert cfg.api_key == "cue_sk_test123"
    assert cfg.api_base == "http://localhost:8000"
    assert cfg.worker_id == "test-worker"
    assert cfg.poll_interval == 10
    assert cfg.max_concurrent == 2
    assert len(cfg.handlers) == 2
    assert cfg.handlers["backup"].cmd == "pg_dump mydb"
    assert cfg.handlers["backup"].timeout == 300  # default
    assert cfg.handlers["report"].cmd == "python3 report.py"
    assert cfg.handlers["report"].timeout == 60
    assert cfg.handlers["report"].cwd == "/tmp"
    assert cfg.handlers["report"].env == {"FOO": "bar"}


def test_load_config_missing_api_key_raises(tmp_config):
    """Test that missing API key raises ValueError."""
    path = tmp_config({
        "handlers": {"test": "echo hello"},
    })

    # Clear env var if set
    with mock.patch.dict(os.environ, {}, clear=True):
        # Also patch home to avoid reading real credentials
        with mock.patch("cueapi_worker.config.Path.home", return_value=Path("/nonexistent")):
            with pytest.raises(ValueError, match="No API key found"):
                load_config(path)


def test_load_config_env_override(tmp_config):
    """Test that CUEAPI_API_KEY env var overrides missing config key."""
    path = tmp_config({
        "handlers": {"test": "echo hello"},
    })

    with mock.patch.dict(os.environ, {"CUEAPI_API_KEY": "cue_sk_from_env"}):
        cfg = load_config(path)
        assert cfg.api_key == "cue_sk_from_env"


def test_load_config_default_worker_id(tmp_config):
    """Test that worker_id defaults to hostname when not specified."""
    path = tmp_config({
        "api_key": "cue_sk_test",
        "handlers": {"test": "echo hello"},
    })

    cfg = load_config(path)
    assert cfg.worker_id == _default_worker_id()
    assert len(cfg.worker_id) > 0


def test_load_config_handler_defaults(tmp_config):
    """Test handler default values (timeout=300, cwd=None, env=None)."""
    path = tmp_config({
        "api_key": "cue_sk_test",
        "handlers": {
            "simple": "echo hello",
        },
    })

    cfg = load_config(path)
    handler = cfg.handlers["simple"]
    assert handler.cmd == "echo hello"
    assert handler.timeout == 300
    assert handler.cwd is None
    assert handler.env is None
