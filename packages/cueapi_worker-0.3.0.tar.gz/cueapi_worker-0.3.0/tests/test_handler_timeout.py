"""Tests for handler_timeout global config and timeout enforcement in daemon."""
from __future__ import annotations

from unittest import mock

import pytest

from cueapi_worker.config import HandlerConfig, WorkerConfig, load_config
from cueapi_worker.daemon import WorkerDaemon


def _make_config(**overrides) -> WorkerConfig:
    """Create a test WorkerConfig."""
    defaults = {
        "api_key": "cue_sk_test",
        "api_base": "http://localhost:8000",
        "worker_id": "test-worker",
        "poll_interval": 1,
        "heartbeat_interval": 30,
        "max_concurrent": 2,
        "handler_timeout": 300,
        "handlers": {
            "fast_task": HandlerConfig(cmd="echo done", timeout=10),
            "slow_task": HandlerConfig(cmd="sleep 10", timeout=600),
        },
    }
    defaults.update(overrides)
    return WorkerConfig(**defaults)


# ── Config tests ────────────────────────────────────────────────


def test_handler_timeout_default():
    """WorkerConfig has handler_timeout=300 by default."""
    config = WorkerConfig(api_key="test", handlers={"t": HandlerConfig(cmd="echo")})
    assert config.handler_timeout == 300


def test_handler_timeout_custom():
    """handler_timeout can be set to custom value."""
    config = _make_config(handler_timeout=60)
    assert config.handler_timeout == 60


def test_load_config_reads_handler_timeout(tmp_path):
    """load_config parses handler_timeout from YAML."""
    config_file = tmp_path / "worker.yaml"
    config_file.write_text("""
api_key: cue_sk_test
handler_timeout: 120
handlers:
  test_task: "echo hello"
""")
    config = load_config(str(config_file))
    assert config.handler_timeout == 120


def test_load_config_handler_timeout_default(tmp_path):
    """load_config uses 300 when handler_timeout not specified."""
    config_file = tmp_path / "worker.yaml"
    config_file.write_text("""
api_key: cue_sk_test
handlers:
  test_task: "echo hello"
""")
    config = load_config(str(config_file))
    assert config.handler_timeout == 300


def test_load_config_handler_inherits_global_timeout(tmp_path):
    """Simple handler strings use global handler_timeout."""
    config_file = tmp_path / "worker.yaml"
    config_file.write_text("""
api_key: cue_sk_test
handler_timeout: 60
handlers:
  simple_task: "echo hello"
""")
    config = load_config(str(config_file))
    assert config.handlers["simple_task"].timeout == 60


def test_load_config_handler_override_timeout(tmp_path):
    """Handler with explicit timeout overrides global handler_timeout."""
    config_file = tmp_path / "worker.yaml"
    config_file.write_text("""
api_key: cue_sk_test
handler_timeout: 60
handlers:
  custom_task:
    cmd: "echo hello"
    timeout: 30
""")
    config = load_config(str(config_file))
    assert config.handlers["custom_task"].timeout == 30


# ── Daemon timeout enforcement tests ────────────────────────────


def test_daemon_caps_handler_timeout():
    """Daemon should cap handler timeout to global handler_timeout."""
    config = _make_config(handler_timeout=5)
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-slow",
            "cue_id": "cue-1",
            "cue_name": "slow-cue",
            "task": "slow_task",  # timeout=600, but global is 5
            "payload": {"task": "slow_task"},
        }
    ]
    daemon._client.claim.return_value = {
        "claimed": True, "execution_id": "exec-slow", "lease_seconds": 900,
    }

    daemon._poll_cycle()

    # Wait for execution to complete
    for future in daemon._active_futures:
        future.result(timeout=30)

    # Should have reported failure due to timeout
    daemon._client.report_outcome.assert_called_once()
    call_kwargs = daemon._client.report_outcome.call_args
    assert call_kwargs.kwargs.get("success") is False
    error_msg = call_kwargs.kwargs.get("error", "")
    assert "timeout" in error_msg.lower()


def test_daemon_uses_handler_timeout_when_lower():
    """If handler timeout < global, handler timeout is used."""
    config = _make_config(handler_timeout=600)  # Global is high
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-fast",
            "cue_id": "cue-1",
            "cue_name": "fast-cue",
            "task": "fast_task",  # timeout=10, global is 600
            "payload": {"task": "fast_task"},
        }
    ]
    daemon._client.claim.return_value = {
        "claimed": True, "execution_id": "exec-fast", "lease_seconds": 900,
    }

    daemon._poll_cycle()

    for future in daemon._active_futures:
        future.result(timeout=30)

    # Should succeed (echo done runs instantly)
    daemon._client.report_outcome.assert_called_once()
    call_kwargs = daemon._client.report_outcome.call_args
    assert call_kwargs.kwargs.get("success") is True


def test_daemon_timeout_reports_handler_timeout_exceeded():
    """When handler times out, error message should say 'Handler timeout exceeded'."""
    config = _make_config(
        handler_timeout=1,
        handlers={"sleepy": HandlerConfig(cmd="sleep 30", timeout=1)},
    )
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-timeout",
            "cue_id": "cue-1",
            "cue_name": "timeout-cue",
            "task": "sleepy",
            "payload": {},
        }
    ]
    daemon._client.claim.return_value = {
        "claimed": True, "execution_id": "exec-timeout", "lease_seconds": 900,
    }

    daemon._poll_cycle()

    for future in daemon._active_futures:
        future.result(timeout=30)

    call_kwargs = daemon._client.report_outcome.call_args
    assert call_kwargs.kwargs.get("success") is False
    error_msg = call_kwargs.kwargs.get("error", "")
    assert "handler timeout exceeded" in error_msg.lower()
