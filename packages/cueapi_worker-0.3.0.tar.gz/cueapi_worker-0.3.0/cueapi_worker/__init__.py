"""CueAPI Worker — local pull-based daemon for executing scheduled tasks."""

__version__ = "0.3.0"
