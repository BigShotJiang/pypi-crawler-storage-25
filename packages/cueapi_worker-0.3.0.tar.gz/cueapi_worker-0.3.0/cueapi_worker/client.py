"""HTTP client for CueAPI worker endpoints."""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Raised when API returns 401 — API key invalid or rotated."""

    def __init__(self, message: str, error_code: str = "invalid_api_key"):
        super().__init__(message)
        self.error_code = error_code


class WorkerAPIClient:
    """Thin wrapper around httpx for CueAPI worker API calls."""

    def __init__(self, api_key: str, api_base: str, timeout: float = 30.0):
        self._api_key = api_key
        self._api_base = api_base.rstrip("/")
        self._timeout = timeout

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    def _check_response(self, resp: httpx.Response, context: str = "") -> Optional[httpx.Response]:
        """Check response for auth failures and rate limiting.

        Raises AuthenticationError on 401.
        Returns None on 429 (after sleeping for retry-after).
        Returns the response otherwise.
        """
        if resp.status_code == 401:
            # Try to extract error code for rotated key detection
            error_code = "invalid_api_key"
            message = "API key is invalid. Check your configuration."
            try:
                body = resp.json()
                error_code = body.get("error", {}).get("code", "invalid_api_key")
                if error_code == "key_rotated":
                    message = "API key was rotated. Get your new key from the dashboard."
            except Exception:
                pass

            raise AuthenticationError(
                f"AUTH FAILURE ({context}): {message} "
                "Worker stopping immediately. "
                "Regenerate key and restart: cueapi-worker start",
                error_code=error_code,
            )

        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", "60"))
            logger.warning("Rate limited (%s). Waiting %ds before retry.", context, retry_after)
            time.sleep(retry_after)
            return None  # Signal caller to retry or skip

        return resp

    def get_claimable(self, task: Optional[str] = None) -> List[Dict[str, Any]]:
        """GET /v1/executions/claimable — list pending worker executions.

        Args:
            task: Optional task name filter.

        Returns:
            List of claimable execution dicts.

        Raises:
            AuthenticationError: If API returns 401.
        """
        params = {}
        if task:
            params["task"] = task

        try:
            resp = httpx.get(
                f"{self._api_base}/v1/executions/claimable",
                headers=self._headers(),
                params=params,
                timeout=self._timeout,
            )
            checked = self._check_response(resp, "get_claimable")
            if checked is None:
                return []  # Rate limited, skip this cycle
            checked.raise_for_status()
            return checked.json().get("executions", [])
        except AuthenticationError:
            raise
        except httpx.HTTPStatusError as e:
            logger.error("Failed to get claimable: %s %s", e.response.status_code, e.response.text)
            return []
        except httpx.RequestError as e:
            logger.error("Request error getting claimable: %s", e)
            return []

    def claim(self, execution_id: str, worker_id: str) -> Optional[Dict[str, Any]]:
        """POST /v1/executions/{id}/claim — claim an execution.

        Returns:
            Claim response dict if successful, None if claim failed (409 or error).

        Raises:
            AuthenticationError: If API returns 401.
        """
        try:
            resp = httpx.post(
                f"{self._api_base}/v1/executions/{execution_id}/claim",
                headers=self._headers(),
                json={"worker_id": worker_id},
                timeout=self._timeout,
            )
            checked = self._check_response(resp, "claim")
            if checked is None:
                return None  # Rate limited
            if checked.status_code == 409:
                logger.debug("Execution %s already claimed", execution_id)
                return None
            checked.raise_for_status()
            return checked.json()
        except AuthenticationError:
            raise
        except httpx.HTTPStatusError as e:
            logger.error("Failed to claim %s: %s %s", execution_id, e.response.status_code, e.response.text)
            return None
        except httpx.RequestError as e:
            logger.error("Request error claiming %s: %s", execution_id, e)
            return None

    def report_outcome(
        self,
        execution_id: str,
        success: bool,
        result: Optional[str] = None,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        *,
        external_id: Optional[str] = None,
        result_url: Optional[str] = None,
        result_ref: Optional[str] = None,
        result_type: Optional[str] = None,
        summary: Optional[str] = None,
        artifacts: Optional[List[Any]] = None,
    ) -> bool:
        """POST /v1/executions/{id}/outcome — report execution result.

        Evidence fields (external_id, result_url, result_ref, result_type,
        summary, artifacts) let worker handlers satisfy evidence-based
        verification modes (require_external_id, require_result_url,
        require_artifacts). Handlers provide them via the
        CUEAPI_OUTCOME_FILE pattern — see the daemon and README.

        Returns:
            True if outcome was recorded, False otherwise.

        Raises:
            AuthenticationError: If API returns 401.
        """
        body: Dict[str, Any] = {"success": success}
        if result is not None:
            body["result"] = result
        if error is not None:
            body["error"] = error
        if metadata is not None:
            body["metadata"] = metadata
        if external_id is not None:
            body["external_id"] = external_id
        if result_url is not None:
            body["result_url"] = result_url
        if result_ref is not None:
            body["result_ref"] = result_ref
        if result_type is not None:
            body["result_type"] = result_type
        if summary is not None:
            body["summary"] = summary
        if artifacts is not None:
            body["artifacts"] = artifacts

        try:
            resp = httpx.post(
                f"{self._api_base}/v1/executions/{execution_id}/outcome",
                headers=self._headers(),
                json=body,
                timeout=self._timeout,
            )
            checked = self._check_response(resp, "report_outcome")
            if checked is None:
                return False  # Rate limited
            checked.raise_for_status()
            return True
        except AuthenticationError:
            raise
        except httpx.HTTPStatusError as e:
            logger.error(
                "Failed to report outcome for %s: %s %s",
                execution_id,
                e.response.status_code,
                e.response.text,
            )
            return False
        except httpx.RequestError as e:
            logger.error("Request error reporting outcome for %s: %s", execution_id, e)
            return False

    def heartbeat(self, worker_id: str, handlers: Optional[List[str]] = None) -> bool:
        """POST /v1/worker/heartbeat — register/update worker.

        Returns:
            True if heartbeat acknowledged, False otherwise.

        Raises:
            AuthenticationError: If API returns 401.
        """
        body: Dict[str, Any] = {"worker_id": worker_id}
        if handlers is not None:
            body["handlers"] = handlers

        try:
            resp = httpx.post(
                f"{self._api_base}/v1/worker/heartbeat",
                headers=self._headers(),
                json=body,
                timeout=self._timeout,
            )
            checked = self._check_response(resp, "heartbeat")
            if checked is None:
                return False  # Rate limited
            checked.raise_for_status()
            return True
        except AuthenticationError:
            raise
        except httpx.HTTPStatusError as e:
            logger.error("Heartbeat failed: %s %s", e.response.status_code, e.response.text)
            return False
        except httpx.RequestError as e:
            logger.error("Heartbeat request error: %s", e)
            return False
