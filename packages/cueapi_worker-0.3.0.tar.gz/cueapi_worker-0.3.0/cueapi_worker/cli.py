"""CLI entry point for cueapi-worker."""
from __future__ import annotations

import logging
import platform
import secrets
import string
import sys
import time
from pathlib import Path

import click
import httpx
import yaml

from cueapi_worker import __version__


def _update_config_key(config_path: str, new_key: str) -> None:
    """Update the api_key in a YAML config file, preserving other fields."""
    path = Path(config_path)
    if path.exists():
        with open(path) as f:
            data = yaml.safe_load(f) or {}
    else:
        data = {}
    if not isinstance(data, dict):
        data = {}
    data["api_key"] = new_key
    with open(path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)


@click.group()
@click.version_option(version=__version__, prog_name="cueapi-worker")
def main():
    """CueAPI Worker — local pull-based daemon for executing scheduled tasks."""
    pass


def _check_service_installed() -> None:
    """Check if a system service is installed for the worker.

    On macOS, checks for launchd plist. On Linux, checks for systemd unit.
    Shows a warning if no service is detected, since the worker will stop
    when the terminal closes.
    """
    system = platform.system()
    if system == "Darwin":
        plist_path = Path.home() / "Library" / "LaunchAgents" / "ai.cueapi.worker.plist"
        if not plist_path.exists():
            click.echo(click.style(
                "⚠️  No launchd service detected. Your worker will stop if this terminal closes.",
                fg="yellow",
            ))
            click.echo(click.style(
                "    Run: cueapi-worker install-service -c <config>",
                fg="yellow",
            ))
            click.echo(click.style(
                "    To keep your worker running 24/7.",
                fg="yellow",
            ))
            click.echo()
    elif system == "Linux":
        unit_path = Path.home() / ".config" / "systemd" / "user" / "cueapi-worker.service"
        if not unit_path.exists():
            click.echo(click.style(
                "⚠️  No systemd service detected. Your worker will stop if this terminal closes.",
                fg="yellow",
            ))
            click.echo(click.style(
                "    Run: cueapi-worker install-service -c <config>",
                fg="yellow",
            ))
            click.echo(click.style(
                "    To keep your worker running 24/7.",
                fg="yellow",
            ))
            click.echo()


@main.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose (DEBUG) logging.")
def start(config: str, verbose: bool):
    """Start the worker daemon.

    Polls CueAPI for claimable executions, matches them to handlers
    defined in the config file, and executes them locally.
    """
    # Configure logging
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    from cueapi_worker.config import load_config
    from cueapi_worker.daemon import WorkerDaemon

    try:
        cfg = load_config(config)
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    click.echo(f"CueAPI Worker v{__version__}")
    click.echo(f"  Worker ID:    {cfg.worker_id}")
    click.echo(f"  API Base:     {cfg.api_base}")
    click.echo(f"  Handlers:     {', '.join(cfg.handler_names())}")
    click.echo(f"  Poll interval: {cfg.poll_interval}s")
    click.echo(f"  Max concurrent: {cfg.max_concurrent}")
    click.echo()

    # Warn if no system service is installed (worker will stop when terminal closes)
    _check_service_installed()

    daemon = WorkerDaemon(cfg, config_path=config)
    daemon.run()


@main.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
def status(config: str):
    """Check worker status by sending a heartbeat.

    Verifies connectivity to the CueAPI server and reports
    whether the worker can authenticate and communicate.
    """
    from cueapi_worker.client import WorkerAPIClient
    from cueapi_worker.config import load_config

    try:
        cfg = load_config(config)
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    client = WorkerAPIClient(api_key=cfg.api_key, api_base=cfg.api_base)
    ok = client.heartbeat(cfg.worker_id, cfg.handler_names())

    if ok:
        click.echo(f"Worker '{cfg.worker_id}' is connected and authenticated.")
        click.echo(f"  Handlers: {', '.join(cfg.handler_names())}")
    else:
        click.echo("Failed to connect to CueAPI. Check your API key and network.", err=True)
        sys.exit(1)


@main.command("install-service")
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
def install_service(config: str):
    """Install worker as a system service (launchd on macOS, systemd on Linux)."""
    from cueapi_worker.service import install_launchd, install_systemd

    system = platform.system()
    try:
        if system == "Darwin":
            path = install_launchd(config)
            click.echo(f"Installed launchd service: {path}")
            click.echo("The worker will start automatically on login.")
        elif system == "Linux":
            path = install_systemd(config)
            click.echo(f"Installed systemd service: {path}")
            click.echo("The worker is now running and will start on boot.")
        else:
            click.echo(f"Unsupported platform: {system}. Use 'cueapi-worker start' directly.", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error installing service: {e}", err=True)
        sys.exit(1)


@main.command("uninstall-service")
def uninstall_service():
    """Uninstall the worker system service."""
    from cueapi_worker.service import uninstall_launchd, uninstall_systemd

    system = platform.system()
    try:
        if system == "Darwin":
            ok = uninstall_launchd()
        elif system == "Linux":
            ok = uninstall_systemd()
        else:
            click.echo(f"Unsupported platform: {system}", err=True)
            sys.exit(1)

        if ok:
            click.echo("Service uninstalled successfully.")
        else:
            click.echo("Service not found. Nothing to uninstall.")
    except Exception as e:
        click.echo(f"Error uninstalling service: {e}", err=True)
        sys.exit(1)


@main.command("regenerate-key")
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
def regenerate_key(config: str):
    """Regenerate the API key. Old key is instantly revoked.

    Requires the current key to still be valid. If the key is already
    invalid, use 'cueapi-worker login' instead.
    """
    from cueapi_worker.config import load_config

    try:
        cfg = load_config(config)
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    try:
        resp = httpx.post(
            f"{cfg.api_base}/v1/auth/key/regenerate",
            headers={
                "Authorization": f"Bearer {cfg.api_key}",
                "X-Confirm-Destructive": "true",
            },
            timeout=15,
        )
    except httpx.RequestError as e:
        click.echo(f"Network error: {e}", err=True)
        sys.exit(1)

    if resp.status_code == 401:
        click.echo(
            "Current key is invalid. Use 'cueapi-worker login' to authenticate.",
            err=True,
        )
        sys.exit(1)

    if resp.status_code != 200:
        click.echo(f"Error ({resp.status_code}): {resp.text}", err=True)
        sys.exit(1)

    new_key = resp.json()["api_key"]
    _update_config_key(config, new_key)
    click.echo("Key regenerated. Worker config updated. Restart the worker.")


@main.command()
@click.option(
    "--email",
    required=True,
    help="Email address for authentication.",
)
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(),
    help="Path to worker config YAML file (created if it doesn't exist).",
)
def login(email: str, config: str):
    """Authenticate via email magic link (no browser needed).

    Creates a device code, sends a magic link to your email, and polls
    until you click the link. The API key is saved to the config file.
    """
    alphabet = string.ascii_lowercase + string.digits
    device_code = "".join(secrets.choice(alphabet) for _ in range(8))

    # Detect api_base from existing config or default
    api_base = "https://api.cueapi.ai"
    path = Path(config)
    if path.exists():
        try:
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            if isinstance(data, dict) and data.get("api_base"):
                api_base = data["api_base"]
        except Exception:
            pass

    # Step 1: Create device code
    try:
        resp = httpx.post(
            f"{api_base}/v1/auth/device-code",
            json={"device_code": device_code},
            timeout=15,
        )
    except httpx.RequestError as e:
        click.echo(f"Network error: {e}", err=True)
        sys.exit(1)

    if resp.status_code not in (200, 201):
        click.echo(f"Error creating device code ({resp.status_code}): {resp.text}", err=True)
        sys.exit(1)

    # Step 2: Submit email
    try:
        resp = httpx.post(
            f"{api_base}/v1/auth/device-code/submit-email",
            json={"device_code": device_code, "email": email},
            timeout=15,
        )
    except httpx.RequestError as e:
        click.echo(f"Network error: {e}", err=True)
        sys.exit(1)

    if resp.status_code != 200:
        click.echo(f"Error submitting email ({resp.status_code}): {resp.text}", err=True)
        sys.exit(1)

    click.echo(f"Magic link sent to {email}. Click the link in your email.")
    click.echo("Waiting for verification", nl=False)

    # Step 3: Poll until approved or expired (max 15 minutes)
    deadline = time.time() + 900
    while time.time() < deadline:
        time.sleep(5)
        click.echo(".", nl=False)

        try:
            resp = httpx.post(
                f"{api_base}/v1/auth/device-code/poll",
                json={"device_code": device_code},
                timeout=15,
            )
        except httpx.RequestError:
            continue

        if resp.status_code != 200:
            continue

        data = resp.json()
        status = data.get("status")

        if status == "approved":
            click.echo()
            api_key = data.get("api_key")
            if api_key:
                _update_config_key(config, api_key)
                click.echo("Authenticated. Key saved to config. Restart the worker.")
            elif data.get("existing_user"):
                click.echo("Email verified (existing account). Your current API key is unchanged.")
                click.echo("If your key is invalid, use 'cueapi-worker regenerate-key' to get a new one.")
            else:
                click.echo("Email verified but API key was unavailable.")
                click.echo("Use 'cueapi-worker regenerate-key' to get a new key.")
            return

        if status == "expired":
            click.echo()
            click.echo("Device code expired. Run 'cueapi-worker login' again.", err=True)
            sys.exit(1)

        if status == "claimed":
            # Another client (e.g. verify page) already claimed the result.
            click.echo()
            api_key_claimed = data.get("api_key")
            if api_key_claimed:
                _update_config_key(config, api_key_claimed)
                click.echo("Email verified (login completed in browser). Key saved to config.")
            else:
                click.echo("Email verified (login completed in browser). Your current API key is unchanged.")
                click.echo("If your key is invalid, use 'cueapi-worker regenerate-key' to get a new one.")
            return

    click.echo()
    click.echo("Timed out waiting for verification.", err=True)
    sys.exit(1)


if __name__ == "__main__":
    main()
