"""Heartbeat thread — sends periodic heartbeat to CueAPI server."""
from __future__ import annotations

import logging
import threading
from typing import List, Optional

from cueapi_worker.client import AuthenticationError, WorkerAPIClient

logger = logging.getLogger(__name__)


class HeartbeatThread:
    """Daemon thread that sends heartbeat at regular intervals.

    Keeps the worker registered with the server so stale-recovery
    logic doesn't reclaim its claimed executions.

    On 401 auth failure, sets auth_failed flag instead of killing
    the process. The main daemon loop checks this flag and handles
    recovery (single recovery path, not two).
    """

    def __init__(
        self,
        client: WorkerAPIClient,
        worker_id: str,
        handlers: Optional[List[str]] = None,
        interval: int = 30,
    ):
        self._client = client
        self._worker_id = worker_id
        self._handlers = handlers
        self._interval = interval
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._auth_failed = False

    @property
    def auth_failed(self) -> bool:
        """True if heartbeat received a 401 response."""
        return self._auth_failed

    def start(self) -> None:
        """Start the heartbeat thread."""
        if self._thread and self._thread.is_alive():
            return

        self._stop_event.clear()
        self._auth_failed = False
        self._thread = threading.Thread(
            target=self._run,
            name="cueapi-heartbeat",
            daemon=True,
        )
        self._thread.start()
        logger.info("Heartbeat thread started (interval=%ds)", self._interval)

    def stop(self) -> None:
        """Signal the heartbeat thread to stop."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            logger.info("Heartbeat thread stopped")

    def _run(self) -> None:
        """Heartbeat loop — send immediately, then every interval seconds."""
        # Send first heartbeat immediately
        self._send()

        while not self._stop_event.wait(timeout=self._interval):
            if self._auth_failed:
                break  # Stop sending heartbeats, let daemon handle recovery
            self._send()

    def _send(self) -> None:
        """Send a single heartbeat."""
        try:
            ok = self._client.heartbeat(self._worker_id, self._handlers)
            if ok:
                logger.debug("Heartbeat sent for worker=%s", self._worker_id)
            else:
                logger.warning("Heartbeat failed for worker=%s", self._worker_id)
        except AuthenticationError as e:
            logger.warning("Heartbeat auth failure: %s", e)
            # Set flag for daemon to detect — daemon handles recovery
            self._auth_failed = True
            self._stop_event.set()
