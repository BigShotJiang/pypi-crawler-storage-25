"""Task handler executor — runs shell commands for matched tasks."""
from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from cueapi_worker.config import HandlerConfig

logger = logging.getLogger(__name__)

# Max bytes to capture from stdout/stderr
MAX_OUTPUT_BYTES = 4096

# Max size of the optional CUEAPI_OUTCOME_FILE the handler may write.
# Matches the server's /outcome metadata cap. Files larger than this are
# rejected and the run falls back to exit-code-only behavior.
MAX_OUTCOME_FILE_BYTES = 10 * 1024  # 10 KB

# Schema of the outcome file, keyed by field name. Each entry describes
# the expected Python type and (where applicable) an extra length or
# URL-shape check applied after the type check.
#
# Fields absent from this table are silently DROPPED with a WARNING log
# during parsing. Fields present but failing validation are dropped the
# same way — the file as a whole is NOT rejected for one bad field.
_OUTCOME_FILE_SCHEMA: Dict[str, Dict[str, Any]] = {
    "success":     {"type": bool, "max_len": None},
    "error":       {"type": str,  "max_len": 2000},
    "result":      {"type": str,  "max_len": 2000},
    "external_id": {"type": str,  "max_len": 500},
    "result_url":  {"type": str,  "max_len": 2000, "is_url": True},
    "result_ref":  {"type": str,  "max_len": 500},
    "result_type": {"type": str,  "max_len": 100},
    "summary":     {"type": str,  "max_len": 500},
    "artifacts":   {"type": list, "max_len": None},
    "metadata":    {"type": dict, "max_len": None},
}


def _validate_outcome_payload(raw: Any) -> Tuple[Dict[str, Any], List[str]]:
    """Validate a parsed outcome-file JSON payload against the schema.

    Drops fields that fail type/length/URL checks, returning a sanitized
    dict plus a list of dropped-field names (for logging). Always
    returns — never raises.

    Args:
        raw: Result of json.loads() on the outcome file contents.

    Returns:
        (validated_fields, dropped_fields). validated_fields contains
        only schema-compliant entries. dropped_fields names the keys
        that were rejected (unknown keys, wrong types, over-length
        strings, non-http URLs).
    """
    if not isinstance(raw, dict):
        return {}, ["<whole file was not a JSON object>"]

    out: Dict[str, Any] = {}
    dropped: List[str] = []
    for key, value in raw.items():
        spec = _OUTCOME_FILE_SCHEMA.get(key)
        if spec is None:
            dropped.append(key)
            continue
        if not isinstance(value, spec["type"]):
            # bool is a subclass of int in Python, but we don't accept
            # ints where bools are specified. Reject explicitly.
            if spec["type"] is bool and isinstance(value, bool):
                pass  # already isinstance-matched above; defensive
            else:
                dropped.append(key)
                continue
        # The isinstance check for bool passes on int 1/0 in some edge
        # cases because bool is a subclass of int. Guard explicitly.
        if spec["type"] is bool and not isinstance(value, bool):
            dropped.append(key)
            continue
        if spec.get("max_len") is not None and len(value) > spec["max_len"]:
            dropped.append(key)
            continue
        if spec.get("is_url"):
            if not isinstance(value, str) or not (
                value.startswith("http://") or value.startswith("https://")
            ):
                dropped.append(key)
                continue
        out[key] = value
    return out, dropped


def _read_outcome_file(path: str, execution_id: str) -> Optional[Dict[str, Any]]:
    """Read, size-check, parse, and validate the handler's outcome file.

    Return shape:
      None
        if the file doesn't exist or is empty (handler opted out — the
        common case)
      { "payload": {...validated fields...},
        "parse_error": Optional[str],
        "dropped_fields": List[str] }
        on any file present — even if rejected. When the file was
        unparseable or too big, `payload` is None and `parse_error` is
        populated; daemon.py uses this to surface a diagnostic
        breadcrumb in the reported metadata.
    """
    try:
        st = os.stat(path)
    except FileNotFoundError:
        return None  # Handler opted out of structured reporting
    except OSError as e:
        logger.warning(
            "Outcome file stat failed: path=%s, error=%s, execution_id=%s",
            path, e, execution_id,
        )
        return None

    if st.st_size == 0:
        return None  # Handler created a blank file; treat as opt-out

    if st.st_size > MAX_OUTCOME_FILE_BYTES:
        logger.warning(
            "Outcome file exceeds %d byte cap (actual %d); falling back "
            "to exit-code-only. execution_id=%s",
            MAX_OUTCOME_FILE_BYTES, st.st_size, execution_id,
        )
        return {
            "payload": None,
            "parse_error": f"outcome_file_too_large: {st.st_size} > {MAX_OUTCOME_FILE_BYTES}",
            "dropped_fields": [],
        }

    try:
        with open(path, "rb") as f:
            raw_bytes = f.read(MAX_OUTCOME_FILE_BYTES + 1)
    except OSError as e:
        logger.warning(
            "Outcome file read failed: path=%s, error=%s, execution_id=%s",
            path, e, execution_id,
        )
        return None

    try:
        decoded = raw_bytes.decode("utf-8")
    except UnicodeDecodeError as e:
        logger.warning(
            "Outcome file is not valid UTF-8: execution_id=%s, error=%s",
            execution_id, e,
        )
        return {
            "payload": None,
            "parse_error": f"outcome_file_not_utf8: {e!s}"[:200],
            "dropped_fields": [],
        }

    try:
        raw = json.loads(decoded)
    except json.JSONDecodeError as e:
        logger.warning(
            "Outcome file JSON parse failed: execution_id=%s, error=%s",
            execution_id, e,
        )
        return {
            "payload": None,
            "parse_error": f"outcome_file_malformed_json: {e.msg}"[:200],
            "dropped_fields": [],
        }

    validated, dropped = _validate_outcome_payload(raw)
    if dropped:
        logger.warning(
            "Outcome file had invalid/unknown fields dropped: execution_id=%s, fields=%s",
            execution_id, dropped,
        )
    return {
        "payload": validated,
        "parse_error": None,
        "dropped_fields": dropped,
    }


def resolve_template(template: str, payload: Dict[str, Any]) -> str:
    """Replace {{ payload.field }} placeholders with values from payload.

    Supports nested access via dot notation: {{ payload.context.url }}
    Missing keys resolve to empty string.

    Args:
        template: String with {{ payload.field }} placeholders.
        payload: Payload dict to resolve values from.

    Returns:
        Template with placeholders replaced.
    """

    def _replace(match: re.Match) -> str:
        path = match.group(1).strip()
        # Remove leading "payload." if present
        if path.startswith("payload."):
            path = path[len("payload."):]

        # Walk the nested dict
        value: Any = payload
        for part in path.split("."):
            if isinstance(value, dict):
                value = value.get(part)
            else:
                return ""
            if value is None:
                return ""
        return str(value)

    return re.sub(r"\{\{\s*(.*?)\s*\}\}", _replace, template)


def execute_handler(
    handler: HandlerConfig,
    payload: Dict[str, Any],
    execution_id: str,
    cue_id: str,
    cue_name: str,
    worker_id: str,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """Execute a handler command as a subprocess.

    Builds environment with:
    - Built-in CUEAPI_* variables (execution_id, cue_id, cue_name,
      worker_id, CUEAPI_OUTCOME_FILE, and — when provided — api_key
      and base_url)
    - Handler-specific env vars with template resolution
    - Inherits current process env

    A unique temp file is created before the subprocess runs and its
    path exposed as CUEAPI_OUTCOME_FILE. The handler MAY optionally
    write a JSON object to that file before exit to surface evidence
    fields (external_id, result_url, result_type, summary, artifacts,
    etc.) and/or an explicit success boolean. The daemon applies the
    conflict-resolution rules in `_execute_and_report`. The file is
    ALWAYS deleted after the subprocess returns, even on exception.

    Args:
        handler: Handler configuration with cmd, cwd, timeout, env.
        payload: Execution payload dict.
        execution_id: ID of the execution being processed.
        cue_id: ID of the parent cue.
        cue_name: Name of the parent cue.
        worker_id: ID of this worker.
        api_key: CueAPI API key. When provided, exposed to the handler
            via CUEAPI_API_KEY so handlers can fire follow-up cues, list
            executions, or otherwise call the API without re-reading
            config from disk. Optional so tests that don't care about
            auth can omit it; the daemon always passes the live value.
        api_base: CueAPI API base URL. Exposed via CUEAPI_BASE_URL.
            Optional for the same reason as api_key.

    Returns:
        (exit_success, output, outcome_info):
          - exit_success (bool): True iff the subprocess exited 0.
          - output (str): Captured stdout+stderr, truncated to 4 KB.
            On timeout, the timeout message.
          - outcome_info (Optional[dict]): None when the handler wrote
            nothing or an empty file. Otherwise a dict with keys
            `payload` (validated fields or None), `parse_error`
            (str or None), and `dropped_fields` (list of rejected
            keys). The daemon consumes this to apply conflict rules
            and forward evidence to report_outcome.
    """
    # Build environment: inherit current + add CUEAPI_* + handler env
    env = os.environ.copy()

    # Built-in variables
    env["CUEAPI_EXECUTION_ID"] = execution_id
    env["CUEAPI_CUE_ID"] = cue_id
    env["CUEAPI_CUE_NAME"] = cue_name
    env["CUEAPI_WORKER_ID"] = worker_id

    # API credentials — only inject when provided so tests that don't
    # exercise the auth surface don't get phantom empty env vars.
    if api_key is not None:
        env["CUEAPI_API_KEY"] = api_key
    if api_base is not None:
        env["CUEAPI_BASE_URL"] = api_base

    # Add payload as JSON string
    env["CUEAPI_PAYLOAD"] = json.dumps(payload or {})

    # Create the optional outcome file. Handler writes to this path if
    # it wants to surface evidence or override the exit-code-derived
    # success value. Closed immediately — we only need the path.
    tmp = tempfile.NamedTemporaryFile(
        mode="w",
        delete=False,
        suffix=".json",
        prefix="cueapi-outcome-",
        encoding="utf-8",
    )
    outcome_path = tmp.name
    tmp.close()
    env["CUEAPI_OUTCOME_FILE"] = outcome_path

    # Handler-specific env vars with template resolution
    if handler.env:
        for key, value in handler.env.items():
            env[key] = resolve_template(str(value), payload or {})

    # Resolve command template
    cmd = resolve_template(handler.cmd, payload or {})

    # Working directory
    cwd = handler.cwd
    if cwd:
        cwd = os.path.expanduser(cwd)

    logger.info(
        "Executing handler: cmd=%s, cwd=%s, timeout=%d, execution_id=%s, outcome_file=%s",
        cmd,
        cwd,
        handler.timeout,
        execution_id,
        outcome_path,
    )

    try:
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                cwd=cwd,
                env=env,
                capture_output=True,
                text=True,
                timeout=handler.timeout,
            )

            # Combine stdout + stderr, truncate to 4KB
            output = ""
            if result.stdout:
                output += result.stdout
            if result.stderr:
                if output:
                    output += "\n--- stderr ---\n"
                output += result.stderr
            output = output[:MAX_OUTPUT_BYTES]

            exit_success = result.returncode == 0

            if exit_success:
                logger.info("Handler exited 0: execution_id=%s", execution_id)
            else:
                logger.warning(
                    "Handler exited %d: execution_id=%s",
                    result.returncode,
                    execution_id,
                )

            outcome_info = _read_outcome_file(outcome_path, execution_id)
            return exit_success, output, outcome_info

        except subprocess.TimeoutExpired:
            msg = f"Handler timed out after {handler.timeout}s"
            logger.error("%s: execution_id=%s", msg, execution_id)
            # Timeout means the handler may have left a partial outcome
            # file behind. Don't trust it — treat as opt-out.
            return False, msg, None

        except Exception as e:
            msg = f"Handler execution error: {e}"
            logger.error("%s: execution_id=%s", msg, execution_id)
            return False, msg, None

    finally:
        # Always clean up the outcome temp file, regardless of what
        # happened above. os.unlink can race with the handler if we're
        # interrupted mid-subprocess; ignore ENOENT.
        try:
            os.unlink(outcome_path)
        except FileNotFoundError:
            pass
        except OSError as e:
            logger.warning(
                "Failed to delete outcome file %s: %s", outcome_path, e
            )
