"""Automatic key recovery via device-code flow.

When a worker hits a 401, it can attempt to recover by running the
device-code login flow automatically — sending a magic link to the
configured email and polling for a new API key.
"""
from __future__ import annotations

import logging
import secrets
import string
import time
from typing import Optional

import httpx

from cueapi_worker.cli import _update_config_key

logger = logging.getLogger(__name__)

MAX_RECOVERY_ATTEMPTS = 3
POLL_INTERVAL = 5  # seconds
POLL_TIMEOUT = 900  # 15 minutes
BACKOFF_BETWEEN_ATTEMPTS = 30  # seconds


def _generate_device_code() -> str:
    """Generate a random 8-char alphanumeric device code."""
    alphabet = string.ascii_lowercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(8))


def _single_recovery_attempt(
    config_path: str,
    email: str,
    api_base: str,
) -> Optional[str]:
    """Run one device-code recovery attempt.

    Returns the new API key on success, None on failure.
    """
    device_code = _generate_device_code()
    api_base = api_base.rstrip("/")

    # Step 1: Create device code
    try:
        resp = httpx.post(
            f"{api_base}/v1/auth/device-code",
            json={"device_code": device_code},
            timeout=15,
        )
        if resp.status_code != 201:
            logger.warning("Recovery: failed to create device code (%d)", resp.status_code)
            return None
    except httpx.RequestError as e:
        logger.warning("Recovery: network error creating device code: %s", e)
        return None

    # Step 2: Submit email
    try:
        resp = httpx.post(
            f"{api_base}/v1/auth/device-code/submit-email",
            json={"device_code": device_code, "email": email},
            timeout=15,
        )
        if resp.status_code != 200:
            logger.warning("Recovery: failed to submit email (%d)", resp.status_code)
            return None
    except httpx.RequestError as e:
        logger.warning("Recovery: network error submitting email: %s", e)
        return None

    logger.info("Recovery: magic link sent to %s. Waiting for verification...", email)

    # Step 3: Poll until approved or expired
    deadline = time.time() + POLL_TIMEOUT
    while time.time() < deadline:
        time.sleep(POLL_INTERVAL)

        try:
            resp = httpx.post(
                f"{api_base}/v1/auth/device-code/poll",
                json={"device_code": device_code},
                timeout=15,
            )
        except httpx.RequestError:
            continue

        if resp.status_code != 200:
            continue

        data = resp.json()
        status = data.get("status")

        if status == "approved":
            if data.get("existing_user"):
                # Existing user — server didn't issue a new key.
                # The worker's key is invalid but the server thinks
                # the old key should still work. Can't auto-recover.
                logger.warning(
                    "Recovery: email verified but no new key issued "
                    "(existing user). Use 'cueapi-worker regenerate-key' manually."
                )
                return None

            new_key = data.get("api_key")
            if new_key:
                _update_config_key(config_path, new_key)
                return new_key

        if status == "expired":
            logger.warning("Recovery: device code expired before verification.")
            return None

    logger.warning("Recovery: timed out waiting for email verification.")
    return None


def attempt_key_recovery(
    config_path: str,
    email: str,
    api_base: str,
) -> Optional[str]:
    """Attempt automatic key recovery with retries.

    Tries up to MAX_RECOVERY_ATTEMPTS times with backoff between attempts.
    Each attempt sends a new magic link email and polls for verification.

    Args:
        config_path: Path to worker YAML config file.
        email: Account email for device-code flow.
        api_base: CueAPI base URL.

    Returns:
        New API key string on success, None if all attempts fail.
    """
    for attempt in range(1, MAX_RECOVERY_ATTEMPTS + 1):
        logger.info(
            "Key recovery attempt %d/%d (email: %s)",
            attempt, MAX_RECOVERY_ATTEMPTS, email,
        )

        result = _single_recovery_attempt(config_path, email, api_base)
        if result:
            return result

        if attempt < MAX_RECOVERY_ATTEMPTS:
            logger.info(
                "Recovery attempt %d failed. Retrying in %ds...",
                attempt, BACKOFF_BETWEEN_ATTEMPTS,
            )
            time.sleep(BACKOFF_BETWEEN_ATTEMPTS)

    logger.error(
        "All %d recovery attempts failed. Worker cannot authenticate. "
        "Manual intervention required: run 'cueapi-worker login --email %s --config <path>' "
        "or 'cueapi-worker regenerate-key --config <path>'.",
        MAX_RECOVERY_ATTEMPTS, email,
    )
    return None
