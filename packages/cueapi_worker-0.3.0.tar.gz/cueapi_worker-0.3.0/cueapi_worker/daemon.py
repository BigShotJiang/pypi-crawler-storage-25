"""Worker daemon — main poll loop that claims and executes tasks."""
from __future__ import annotations

import logging
import signal
import time
from concurrent.futures import ThreadPoolExecutor, Future, TimeoutError as FuturesTimeoutError
from typing import Any, Dict, Optional, Set

from cueapi_worker.client import AuthenticationError, WorkerAPIClient
from cueapi_worker.config import WorkerConfig
from cueapi_worker.executor import execute_handler
from cueapi_worker.heartbeat import HeartbeatThread

logger = logging.getLogger(__name__)


class WorkerDaemon:
    """Main worker daemon.

    Poll loop: get_claimable -> match handler -> claim -> execute in
    ThreadPoolExecutor -> report outcome. Respects max_concurrent.
    Handles SIGINT/SIGTERM gracefully. Auto-recovers on 401 if email
    is configured.
    """

    def __init__(self, config: WorkerConfig, config_path: Optional[str] = None):
        self._config = config
        self._config_path = config_path
        self._client = WorkerAPIClient(
            api_key=config.api_key,
            api_base=config.api_base,
        )
        self._heartbeat = HeartbeatThread(
            client=self._client,
            worker_id=config.worker_id,
            handlers=config.handler_names(),
            interval=config.heartbeat_interval,
        )
        self._executor = ThreadPoolExecutor(
            max_workers=config.max_concurrent,
            thread_name_prefix="cueapi-handler",
        )
        self._running = False
        self._active_futures: Set[Future] = set()

    def run(self) -> None:
        """Start the daemon and run until interrupted."""
        self._running = True

        # Install signal handlers
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

        logger.info(
            "Worker daemon starting: worker_id=%s, handlers=%s, poll_interval=%ds, max_concurrent=%d",
            self._config.worker_id,
            self._config.handler_names(),
            self._config.poll_interval,
            self._config.max_concurrent,
        )

        # Start heartbeat thread
        self._heartbeat.start()

        try:
            while self._running:
                # Check if heartbeat detected an auth failure
                if self._heartbeat.auth_failed:
                    self._handle_auth_failure("Heartbeat detected invalid API key.")
                    if not self._running:
                        break
                    continue

                try:
                    self._poll_cycle()
                except AuthenticationError as e:
                    self._handle_auth_failure(str(e))
                    if not self._running:
                        break
                    continue

                if self._running:
                    time.sleep(self._config.poll_interval)
        finally:
            self._shutdown()

    def _handle_auth_failure(self, message: str) -> None:
        """Handle a 401 auth failure: attempt recovery or exit.

        If email is configured and config_path is known, attempts automatic
        key recovery via device-code flow. On success, rebuilds the client
        and heartbeat with the new key and resumes. On failure, shuts down.
        """
        if self._config.email and self._config_path:
            logger.warning(
                "API key invalid. Attempting automatic recovery via email %s...",
                self._config.email,
            )

            from cueapi_worker.recovery import attempt_key_recovery

            new_key = attempt_key_recovery(
                config_path=self._config_path,
                email=self._config.email,
                api_base=self._config.api_base,
            )

            if new_key:
                logger.info("Key recovered automatically. Resuming worker.")
                self._config.api_key = new_key

                # Rebuild client with new key
                self._client = WorkerAPIClient(
                    api_key=new_key,
                    api_base=self._config.api_base,
                )

                # Restart heartbeat with new client
                self._heartbeat.stop()
                self._heartbeat = HeartbeatThread(
                    client=self._client,
                    worker_id=self._config.worker_id,
                    handlers=self._config.handler_names(),
                    interval=self._config.heartbeat_interval,
                )
                self._heartbeat.start()
                return  # Resume poll loop
            else:
                logger.critical(
                    "Auto-recovery failed after all attempts. "
                    "Manual intervention needed. Run: "
                    "'cueapi-worker login --email %s --config %s' or "
                    "'cueapi-worker regenerate-key --config %s'",
                    self._config.email,
                    self._config_path,
                    self._config_path,
                )
        else:
            if not self._config.email:
                logger.critical(
                    "API key invalid and no email configured for auto-recovery. "
                    "Add 'email: you@example.com' to your config file, or run: "
                    "'cueapi-worker login --email <email> --config <path>'"
                )
            else:
                logger.critical(
                    "API key invalid. %s", message,
                )

        self._running = False
        self._shutdown()
        raise SystemExit(1)

    def _poll_cycle(self) -> None:
        """Run one poll cycle: fetch claimable, match, claim, execute."""
        # Clean up completed futures
        done = {f for f in self._active_futures if f.done()}
        self._active_futures -= done

        # Check available capacity
        available = self._config.max_concurrent - len(self._active_futures)
        if available <= 0:
            logger.debug("At max concurrent (%d), skipping poll", self._config.max_concurrent)
            return

        # Fetch claimable executions
        executions = self._client.get_claimable()
        if not executions:
            return

        claimed = 0
        for exec_data in executions:
            if claimed >= available:
                break

            task = exec_data.get("task")
            execution_id = exec_data.get("execution_id")

            # Match handler
            handler_config = self._config.handlers.get(task) if task else None
            if handler_config is None:
                logger.debug(
                    "No handler for task=%s, skipping execution=%s",
                    task,
                    execution_id,
                )
                continue

            # Claim
            claim_result = self._client.claim(execution_id, self._config.worker_id)
            if claim_result is None:
                logger.debug("Failed to claim execution=%s", execution_id)
                continue

            claimed += 1
            logger.info(
                "Claimed execution=%s task=%s cue=%s",
                execution_id,
                task,
                exec_data.get("cue_name"),
            )

            # Submit to thread pool
            future = self._executor.submit(
                self._execute_and_report,
                handler_config,
                exec_data,
            )
            self._active_futures.add(future)

        if claimed > 0:
            logger.info("Poll cycle: claimed %d executions", claimed)

    def _execute_and_report(self, handler_config, exec_data: Dict) -> None:
        """Execute a handler and report the outcome. Runs in thread pool.

        The handler's per-handler timeout (or global handler_timeout default)
        is enforced by subprocess.run(). This method provides the outer
        reporting layer.
        """
        execution_id = exec_data.get("execution_id", "")
        cue_id = exec_data.get("cue_id", "")
        cue_name = exec_data.get("cue_name", "")
        payload = exec_data.get("payload", {})

        # Enforce handler_timeout as hard ceiling (overrides per-handler if lower)
        effective_timeout = min(handler_config.timeout, self._config.handler_timeout)
        # Apply the effective timeout to the handler config for this execution
        from cueapi_worker.config import HandlerConfig
        capped_handler = HandlerConfig(
            cmd=handler_config.cmd,
            cwd=handler_config.cwd,
            timeout=effective_timeout,
            env=handler_config.env,
        )

        try:
            exit_success, output, outcome_info = execute_handler(
                handler=capped_handler,
                payload=payload,
                execution_id=execution_id,
                cue_id=cue_id,
                cue_name=cue_name,
                worker_id=self._config.worker_id,
                # Read from config (not the client) so handlers spawned
                # after an auto-recovery event (see _handle_auth_failure)
                # receive the new API key; self._config.api_key is the
                # canonical source that gets rewritten on recovery.
                api_key=self._config.api_key,
                api_base=self._config.api_base,
            )

            # Resolve the final outcome using the conflict-resolution
            # rules documented in the CUEAPI_OUTCOME_FILE design:
            #
            #   - No file / empty / unparseable file: exit code decides.
            #     (Also surface a diagnostic breadcrumb in metadata when
            #     the file was present but rejected.)
            #   - Exit code != 0: EXIT CODE WINS. Whatever the file
            #     claimed is considered stale because the process
            #     crashed.
            #   - Exit code == 0, file says success=False: FILE WINS.
            #     The handler knows more than the shell.
            #   - Exit code == 0, file says success=True or omits
            #     success: success.
            #
            # Evidence fields are always merged (regardless of which
            # side wins on success), because they describe what the
            # handler produced — even a partially-failing handler may
            # have legitimately created artifacts before failing.
            (
                final_success,
                final_result,
                final_error,
                evidence,
                report_metadata,
            ) = self._resolve_outcome(
                exit_success=exit_success,
                output=output,
                outcome_info=outcome_info,
                effective_timeout=effective_timeout,
            )

            self._client.report_outcome(
                execution_id=execution_id,
                success=final_success,
                result=final_result,
                error=final_error,
                metadata=report_metadata,
                **evidence,
            )

        except Exception as e:
            logger.error("Unhandled error executing %s: %s", execution_id, e)
            self._client.report_outcome(
                execution_id=execution_id,
                success=False,
                error=f"Worker error: {e}",
            )

    @staticmethod
    def _resolve_outcome(
        *,
        exit_success: bool,
        output: str,
        outcome_info: Optional[Dict],
        effective_timeout: int,
    ):
        """Apply the exit-code vs outcome-file conflict rules.

        See the inline design comment in `_execute_and_report`. Returns
        a 5-tuple:
          (final_success, final_result, final_error, evidence, metadata)
        where `evidence` is a dict of keyword-ready arguments for
        `WorkerAPIClient.report_outcome` (only present-fields) and
        `metadata` is the metadata dict to forward (or None).

        Kept as a pure helper so unit tests can pin every conflict
        combination without driving a subprocess.
        """
        # Unpack outcome_info
        payload: Optional[Dict] = None
        parse_error: Optional[str] = None
        dropped_fields: list = []
        if outcome_info is not None:
            payload = outcome_info.get("payload")
            parse_error = outcome_info.get("parse_error")
            dropped_fields = outcome_info.get("dropped_fields") or []

        # Build evidence kwargs from any payload fields that match the
        # client's supported evidence surface. Always merged, regardless
        # of success/failure path taken below.
        evidence: Dict[str, Any] = {}
        if payload:
            for field in (
                "external_id",
                "result_url",
                "result_ref",
                "result_type",
                "summary",
                "artifacts",
            ):
                if payload.get(field) is not None:
                    evidence[field] = payload[field]

        # Timeout detection for the nicer error message. Checked against
        # the output string that execute_handler returned on timeout.
        timeout_msg = f"timed out after {effective_timeout}s"
        is_timeout = timeout_msg.lower() in (output or "").lower()

        # Conflict resolution.
        if not exit_success:
            # EXIT CODE WINS on crashes. Even if the handler wrote
            # success=True to the file before crashing, that record is
            # stale.
            final_success = False
            file_error = payload.get("error") if payload else None
            if is_timeout:
                final_error = f"Handler timeout exceeded ({effective_timeout}s)"
            else:
                final_error = file_error or (output or "handler failed")
            final_result = None
        else:
            # Exit 0. File-provided success takes precedence; if the
            # file is absent or omits the field, exit 0 means success.
            file_success: Any = payload.get("success") if payload else None
            if file_success is False:
                # FILE WINS on semantic failure.
                final_success = False
                final_error = (payload.get("error") if payload else None) or (
                    output or "handler reported failure"
                )
                final_result = None
            else:
                final_success = True
                final_error = None
                final_result = (
                    (payload.get("result") if payload else None)
                    or output
                    or "completed"
                )

        # Metadata: forward any user-supplied metadata from the outcome
        # file. Surface diagnostic breadcrumbs when the file was
        # present-but-rejected or had fields dropped — these go under
        # a reserved `_cueapi_worker` key so they never collide with
        # user metadata.
        report_metadata: Optional[Dict[str, Any]] = None
        if payload and isinstance(payload.get("metadata"), dict):
            report_metadata = dict(payload["metadata"])
        diagnostics: Dict[str, Any] = {}
        if parse_error:
            diagnostics["outcome_file_parse_error"] = parse_error
        if dropped_fields:
            diagnostics["outcome_file_dropped_fields"] = dropped_fields
        if diagnostics:
            if report_metadata is None:
                report_metadata = {}
            report_metadata["_cueapi_worker"] = diagnostics

        return final_success, final_result, final_error, evidence, report_metadata

    def _handle_signal(self, signum: int, frame) -> None:
        """Handle SIGINT/SIGTERM gracefully."""
        sig_name = signal.Signals(signum).name
        logger.info("Received %s, shutting down gracefully...", sig_name)
        self._running = False

    def _shutdown(self) -> None:
        """Clean shutdown: stop heartbeat, wait for active tasks."""
        logger.info("Shutting down worker daemon...")

        # Stop heartbeat
        self._heartbeat.stop()

        # Wait for active tasks to complete
        if self._active_futures:
            logger.info("Waiting for %d active tasks to complete...", len(self._active_futures))
            for future in self._active_futures:
                try:
                    future.result(timeout=30)
                except Exception as e:
                    logger.error("Task error during shutdown: %s", e)

        self._executor.shutdown(wait=False)
        logger.info("Worker daemon stopped")
