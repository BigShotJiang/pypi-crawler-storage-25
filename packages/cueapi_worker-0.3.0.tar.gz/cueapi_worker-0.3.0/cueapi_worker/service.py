"""System service installation for cueapi-worker (launchd + systemd)."""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

LAUNCHD_LABEL = "ai.cueapi.worker"
SYSTEMD_SERVICE = "cueapi-worker"


def _find_executable() -> str:
    """Find the cueapi-worker executable path."""
    # Check if installed via pip
    exe = shutil.which("cueapi-worker")
    if exe:
        return exe
    # Fallback to python -m
    return f"{sys.executable} -m cueapi_worker.cli"


# ── launchd (macOS) ──────────────────────────────────────────────

def install_launchd(config_path: str) -> str:
    """Install cueapi-worker as a macOS launchd service.

    Args:
        config_path: Absolute path to the worker config YAML file.

    Returns:
        Path to the installed plist file.
    """
    config_path = os.path.abspath(config_path)
    exe = _find_executable()

    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_dir.mkdir(parents=True, exist_ok=True)
    plist_path = plist_dir / f"{LAUNCHD_LABEL}.plist"

    log_dir = Path.home() / "Library" / "Logs" / "cueapi-worker"
    log_dir.mkdir(parents=True, exist_ok=True)

    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{LAUNCHD_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{exe}</string>
        <string>start</string>
        <string>--config</string>
        <string>{config_path}</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir / "stdout.log"}</string>
    <key>StandardErrorPath</key>
    <string>{log_dir / "stderr.log"}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
    </dict>
</dict>
</plist>
"""

    plist_path.write_text(plist_content)
    logger.info("Wrote plist to %s", plist_path)

    # Load the service
    subprocess.run(["launchctl", "load", str(plist_path)], check=True)
    logger.info("Loaded launchd service %s", LAUNCHD_LABEL)

    return str(plist_path)


def uninstall_launchd() -> bool:
    """Uninstall the cueapi-worker launchd service.

    Returns:
        True if uninstalled, False if not found.
    """
    plist_path = Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"

    if not plist_path.exists():
        logger.warning("Plist not found at %s", plist_path)
        return False

    # Unload the service
    subprocess.run(["launchctl", "unload", str(plist_path)], check=False)
    plist_path.unlink()
    logger.info("Uninstalled launchd service %s", LAUNCHD_LABEL)
    return True


# ── systemd (Linux) ─────────────────────────────────────────────

def install_systemd(config_path: str) -> str:
    """Install cueapi-worker as a systemd user service.

    Args:
        config_path: Absolute path to the worker config YAML file.

    Returns:
        Path to the installed unit file.
    """
    config_path = os.path.abspath(config_path)
    exe = _find_executable()

    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_path = unit_dir / f"{SYSTEMD_SERVICE}.service"

    unit_content = f"""[Unit]
Description=CueAPI Worker Daemon
After=network.target

[Service]
Type=simple
ExecStart={exe} start --config {config_path}
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
"""

    unit_path.write_text(unit_content)
    logger.info("Wrote systemd unit to %s", unit_path)

    # Reload and enable
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", SYSTEMD_SERVICE], check=True)
    subprocess.run(["systemctl", "--user", "start", SYSTEMD_SERVICE], check=True)
    logger.info("Enabled and started systemd service %s", SYSTEMD_SERVICE)

    return str(unit_path)


def uninstall_systemd() -> bool:
    """Uninstall the cueapi-worker systemd service.

    Returns:
        True if uninstalled, False if not found.
    """
    unit_path = Path.home() / ".config" / "systemd" / "user" / f"{SYSTEMD_SERVICE}.service"

    if not unit_path.exists():
        logger.warning("Unit file not found at %s", unit_path)
        return False

    subprocess.run(["systemctl", "--user", "stop", SYSTEMD_SERVICE], check=False)
    subprocess.run(["systemctl", "--user", "disable", SYSTEMD_SERVICE], check=False)
    unit_path.unlink()
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    logger.info("Uninstalled systemd service %s", SYSTEMD_SERVICE)
    return True
