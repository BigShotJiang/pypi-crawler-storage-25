# sentisec-sdk

Public Python SDK for [Sentisec](https://sentisec.ch).

`sentisec-sdk` is a thin client. You install it with `pip`, point it at
your workspace, and wrap your existing OpenAI / Anthropic client. Your
agent's tool calls then flow through Sentisec's hosted control plane,
where they are evaluated and either allowed, rewritten, or blocked
before they reach the world.

## Install

```sh
pip install sentisec-sdk
```

Python 3.11+ is required.

## Quick start

```python
from sentisec_sdk import Monitor

monitor = Monitor()  # picks up ~/.sentisec/credentials.toml after `sentisec login`
client = monitor.wrap_openai(...)
client = monitor.wrap_anthropic(...)
```

The `sentisec` CLI is shipped in the same wheel:

```sh
sentisec login
sentisec status
sentisec demo run
sentisec logout
```

> Note (alpha): the public surface is being assembled across a small
> set of release tasks. Calling `Monitor()` / `Session()` in this
> alpha pre-release raises `NotImplementedError` pointing at the
> tracking task — install the `0.1.0` (non-alpha) release for the
> working client.
>
> From `0.1.0a4` onwards `SENTISEC_WORKSPACE_ID` is OPTIONAL — the
> Sentisec proxy resolves the workspace from the API key prefix, so
> a one-env-var setup (`SENTISEC_API_KEY` only) is sufficient for
> the `wrap_anthropic` / `wrap_openai` path.

## Documentation

- Product overview: <https://sentisec.ch>
- Developer docs: <https://docs.sentisec.ch>
- Dashboard: <https://app.sentisec.ch>
- Support: <mailto:support@sentisec.ch>

## Building the standalone CLI

For shipping channels that cannot rely on a working `pip` on the user's
box (curl installer, npm postinstall, GitHub Releases tarball), the
`sentisec` console-script entry is bundled as a single
[`shiv`](https://github.com/linkedin/shiv) zipapp:

```sh
# one-time: install the build-only extra
uv pip install --system shiv          # or: pipx install shiv

# build
./scripts/build-cli.sh                # → dist/sentisec (executable)

# (optional) verify the build is reproducible
VERIFY_DETERMINISM=1 ./scripts/build-cli.sh
```

The build script:

- runs `shiv --console-script sentisec --output-file dist/sentisec
  --reproducible --compressed --python "/usr/bin/env python3" .`,
- smoke-tests `./dist/sentisec --version` and asserts the output equals
  `sentisec <version-from-pyproject>`,
- when `VERIFY_DETERMINISM=1`, rebuilds into a tempdir and `diff`s the
  two artifacts byte-for-byte (shiv's `--reproducible` flag pins all
  zip-entry timestamps to a fixed value).

**Platform caveat.** The resulting `dist/sentisec` shebangs to
`/usr/bin/env python3`, but its bundled wheels include the native
`pydantic-core` extension for the **builder's** `(os, arch,
python-minor)` tuple. The artifact therefore runs on hosts matching
that tuple only. The release pipeline (P-INST-02) matrix-builds one
artifact per supported tuple and uploads each as a separate GitHub
Release asset.

## License

Apache License 2.0. See [LICENSE](./LICENSE).
