"""Edge installer — idempotent, reversible system wiring.

The wizard (:mod:`sentisec_sdk.edge.wizard`) drives the user-facing flow;
this module is the pure mechanism it calls to actually touch the machine.
Every operation here is:

- **idempotent** — running it twice is a no-op the second time;
- **reversible** — a paired ``remove_*`` / ``unmerge_*`` restores the
  pre-install state with no residue;
- **marker-fenced** — every block this module writes into a file the user
  also owns (``~/.claude/settings.json``, a shell profile) is fenced by a
  Sentisec marker so the remover can find and excise exactly its own
  bytes without clobbering user content.

The three wiring surfaces for the Claude track (Option B):

1. **Claude hooks** — :func:`merge_claude_hooks` /
   :func:`unmerge_claude_hooks` merge the verified transport-matrix hook
   block into ``~/.claude/settings.json`` (hot-reloaded, no restart).
2. **The transparent ``claude`` shim** — :func:`install_claude_shim` /
   :func:`uninstall_claude_shim` write ``~/.sentisec/bin/claude`` (a
   shell script that exports the verified ``OTEL_*`` env, lazy-starts the
   daemon, then ``exec``s the real ``claude``) and prepend
   ``~/.sentisec/bin`` to ``PATH`` via a marked block in the user's shell
   profile(s).
3. **The daemon background service** — :func:`generate_launchd_plist` /
   :func:`generate_systemd_unit` emit the user-level service definition;
   :func:`install_daemon_service` / :func:`uninstall_daemon_service` place
   / remove the file.

Codex provider (Wave-Codex — LOCAL token-custody-safe passthrough)
=================================================================

The installer also writes a Codex model-provider block
(:func:`write_codex_provider` / :func:`remove_codex_provider`). Codex's
ChatGPT-subscription token-custody tension is resolved by the LOCAL thin
passthrough (:mod:`sentisec_sdk.edge.codex_proxy`): Codex is pointed at a
local proxy that forwards the ChatGPT bearer box-to-backend (never to the
hosted plane) and sends only a token-REDACTED ``{request, response}`` to
the hosted analyze endpoint. The provider block here is the user-level
``~/.codex/config.toml`` wiring that points Codex at that local proxy
port. Both writers are idempotent + reversible: the merge preserves every
other ``[model_providers.*]`` and the remove excises exactly Sentisec's
own block, restoring the prior ``model_provider`` selection.

This shim/service runner targets ``python -m sentisec_sdk.edge.daemon``
(the thin daemon in THIS package), NOT the platform ``sentisec.edge``.

No network. No engine imports. The only I/O is the filesystem.
"""

from __future__ import annotations

import json
import os
import platform
import stat
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path

import tomli_w

__all__ = [
    "CODEX_PROVIDER_NAME",
    "CODEX_PROVIDER_SLOT",
    "HOOK_EVENTS_HTTP",
    "PATH_BLOCK_BEGIN",
    "PATH_BLOCK_END",
    "SENTISEC_HOOK_MARKER",
    "ShimPaths",
    "claude_settings_path",
    "codex_config_path",
    "default_home",
    "default_shim_dir",
    "generate_launchd_plist",
    "generate_shim_script",
    "generate_systemd_unit",
    "install_claude_shim",
    "install_daemon_service",
    "merge_claude_hooks",
    "otel_env_block",
    "remove_codex_provider",
    "remove_path_block",
    "service_file_path",
    "uninstall_claude_shim",
    "uninstall_daemon_service",
    "unmerge_claude_hooks",
    "write_codex_provider",
    "write_path_block",
]


# ---------------------------------------------------------------------------
# Markers — every byte this module writes into a user-owned file is fenced.
# ---------------------------------------------------------------------------

#: Marker key stamped on the Sentisec hook block inside ``settings.json``.
#: ``unmerge_claude_hooks`` removes only the hook-config entries whose
#: command/url carry this marker, leaving any pre-existing user hooks
#: untouched. The marker is also the idempotency key — a second
#: :func:`merge_claude_hooks` recognises its own block and replaces it
#: rather than appending a duplicate.
SENTISEC_HOOK_MARKER = "__sentisec_edge__"

#: The fence lines bracketing the PATH block in a shell profile.
#: :func:`remove_path_block` deletes everything between (and including)
#: these two lines, so a clean uninstall leaves the profile byte-for-byte
#: as it was before install (modulo the block).
PATH_BLOCK_BEGIN = "# >>> sentisec edge (managed) >>>"
PATH_BLOCK_END = "# <<< sentisec edge (managed) <<<"

#: The Claude hook events we wire as ``http`` POST -> ``/hooks``. (transport
#: matrix). ``SessionStart`` is DELIBERATELY ABSENT — it supports only
#: ``command``/``mcp_tool``, never ``http`` (verified); session-open is
#: keyed off the first event / OTel ``prompt.id`` instead. ``PreToolUse``
#: gets two matchers: ``*`` (all tools) AND a dedicated ``mcp__.*`` (MCP
#: tool calls), per the matrix.
HOOK_EVENTS_HTTP: tuple[str, ...] = (
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    "UserPromptSubmit",
    "Stop",
    "SubagentStop",
    "SessionEnd",
)


# ---------------------------------------------------------------------------
# Path resolution — every path resolves against $HOME so tests redirect it.
# ---------------------------------------------------------------------------


def default_home() -> Path:
    """Return the user home directory, honouring ``$HOME`` (test-friendly).

    Tests redirect the entire install surface by setting ``$HOME`` to a
    temp dir; every path helper resolves through this function so a fake
    home reaches every sub-path.
    """
    return Path(os.path.expanduser("~"))


def claude_settings_path(home: Path | None = None) -> Path:
    """Resolve ``~/.claude/settings.json`` under ``home``."""
    base = home if home is not None else default_home()
    return base / ".claude" / "settings.json"


def default_shim_dir(home: Path | None = None) -> Path:
    """Resolve ``~/.sentisec/bin`` (the dir prepended to PATH)."""
    base = home if home is not None else default_home()
    return base / ".sentisec" / "bin"


# ---------------------------------------------------------------------------
# Claude hooks: idempotent JSON merge into settings.json
# ---------------------------------------------------------------------------


def _sentisec_hook_entry(port: int, matcher: str) -> dict[str, object]:
    """Build one Sentisec hook config entry (the verified http shape).

    The entry carries the :data:`SENTISEC_HOOK_MARKER` so the remover +
    the idempotency check can recognise Sentisec's own entries among any
    user-authored hooks sharing the same event.
    """
    return {
        "matcher": matcher,
        "hooks": [
            {
                "type": "http",
                "url": f"http://127.0.0.1:{port}/hooks",
                "marker": SENTISEC_HOOK_MARKER,
            }
        ],
    }


def _sentisec_event_entries(event: str, port: int) -> list[dict[str, object]]:
    """Return the Sentisec hook entries for one event.

    ``PreToolUse`` gets two matchers (``*`` and ``mcp__.*`` per the
    transport matrix); every other wired event gets a single ``*``
    matcher.
    """
    if event == "PreToolUse":
        return [
            _sentisec_hook_entry(port, "*"),
            _sentisec_hook_entry(port, "mcp__.*"),
        ]
    return [_sentisec_hook_entry(port, "*")]


def _is_sentisec_entry(entry: object) -> bool:
    """Return True if ``entry`` is a Sentisec-authored hook entry.

    Recognises the entry by the :data:`SENTISEC_HOOK_MARKER` on any of its
    nested ``hooks`` items — so a user's own hook on the same event is
    never mistaken for ours.
    """
    if not isinstance(entry, dict):
        return False
    hooks = entry.get("hooks")
    if not isinstance(hooks, list):
        return False
    return any(
        isinstance(h, dict) and h.get("marker") == SENTISEC_HOOK_MARKER
        for h in hooks
    )


def _load_settings(path: Path) -> dict[str, object]:
    """Read settings.json into a dict (empty dict if absent/empty)."""
    if not path.is_file():
        return {}
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return {}
    data = json.loads(text)
    if not isinstance(data, dict):
        # A non-object settings.json is malformed; we refuse to clobber it
        # silently. The wizard surfaces this as an error.
        raise ValueError(f"{path} is not a JSON object")
    return data


def _write_settings(path: Path, data: dict[str, object]) -> None:
    """Write settings.json (2-space indent, trailing newline)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def merge_claude_hooks(settings_path: Path, port: int) -> None:
    """Idempotently merge the Sentisec hook block into ``settings.json``.

    Reads the existing settings (preserving every user key + every
    user-authored hook), inserts the verified transport-matrix hook
    entries (:data:`HOOK_EVENTS_HTTP`) under ``hooks.<event>``, and writes
    it back. The merge is:

    - **non-clobbering** — user keys + user hooks on the same event are
      preserved; Sentisec entries are appended alongside them.
    - **idempotent** — a second call strips the prior Sentisec entries
      (recognised by :data:`SENTISEC_HOOK_MARKER`) before re-adding, so the
      file never accumulates duplicates and a port change is applied
      cleanly.

    Parameters
    ----------
    settings_path:
        Path to ``~/.claude/settings.json`` (resolve via
        :func:`claude_settings_path`). Created (with parent dirs) if
        absent.
    port:
        The daemon port the hook URLs point at
        (``http://127.0.0.1:<port>/hooks``).
    """
    data = _load_settings(settings_path)
    hooks_obj = data.get("hooks")
    hooks: dict[str, object] = hooks_obj if isinstance(hooks_obj, dict) else {}

    for event in HOOK_EVENTS_HTTP:
        existing = hooks.get(event)
        # Keep only the user's own entries; drop any prior Sentisec ones
        # (idempotency — re-merge replaces, never duplicates).
        user_entries: list[object] = (
            [e for e in existing if not _is_sentisec_entry(e)]
            if isinstance(existing, list)
            else []
        )
        hooks[event] = user_entries + list(_sentisec_event_entries(event, port))

    data["hooks"] = hooks
    _write_settings(settings_path, data)


def unmerge_claude_hooks(settings_path: Path) -> None:
    """Remove every Sentisec hook entry from ``settings.json``.

    The reverse of :func:`merge_claude_hooks`. Deletes only the entries
    carrying :data:`SENTISEC_HOOK_MARKER`; user-authored hooks on the same
    events survive. An event left with no entries is removed from the
    ``hooks`` map, and an empty ``hooks`` map is removed entirely — so a
    clean uninstall restores the file to (modulo formatting) its
    pre-install shape. A missing file is a no-op.
    """
    if not settings_path.is_file():
        return
    data = _load_settings(settings_path)
    hooks_obj = data.get("hooks")
    if not isinstance(hooks_obj, dict):
        return

    for event in list(hooks_obj):
        entries = hooks_obj.get(event)
        if not isinstance(entries, list):
            continue
        kept = [e for e in entries if not _is_sentisec_entry(e)]
        if kept:
            hooks_obj[event] = kept
        else:
            del hooks_obj[event]

    if hooks_obj:
        data["hooks"] = hooks_obj
    else:
        data.pop("hooks", None)
    _write_settings(settings_path, data)


# ---------------------------------------------------------------------------
# The transparent ``claude`` shim + PATH block
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ShimPaths:
    """Resolved paths for the shim install (test-friendly bundle)."""

    bin_dir: Path
    shim_path: Path


def otel_env_block(port: int, wire_dir: str) -> list[str]:
    """Return the verified ``OTEL_*`` export lines the shim sets.

    These env vars are read by ``claude`` AT LAUNCH and are NOT inherited
    by subprocesses (hooks, bash, MCP) — which is exactly why they must
    live in the launch wrapper (the shim), not in the daemon or a hook's
    env.

    - ``CLAUDE_CODE_ENABLE_TELEMETRY=1`` — the documented enable flag.
      [verify] in live testing.
    - ``OTEL_LOGS_EXPORTER=otlp`` — events ride the logs signal.
    - ``OTEL_EXPORTER_OTLP_PROTOCOL`` / ``..._LOGS_PROTOCOL`` =
      ``http/protobuf`` — the receiver mounts an http/protobuf endpoint.
    - ``OTEL_EXPORTER_OTLP_LOGS_ENDPOINT=http://127.0.0.1:<port>/v1/logs``
      — the daemon's embedded OTLP receiver.
    - ``OTEL_LOG_RAW_API_BODIES=file:<wire_dir>`` — file mode -> the full,
      untruncated ``/v1/messages`` request+response bodies land on disk
      (the OTLP event carries a ``body_ref`` path).
    - ``OTEL_LOG_USER_PROMPTS=1`` / ``OTEL_LOG_TOOL_DETAILS=1`` — flip the
      default-off prompt + tool-detail content flags.
    """
    endpoint = f"http://127.0.0.1:{port}"
    return [
        # [verify] CLAUDE_CODE_ENABLE_TELEMETRY is the documented enable
        # flag — confirm the exact name against a live `claude` in founder
        # testing.
        'export CLAUDE_CODE_ENABLE_TELEMETRY="1"',
        'export OTEL_LOGS_EXPORTER="otlp"',
        'export OTEL_EXPORTER_OTLP_PROTOCOL="http/protobuf"',
        'export OTEL_EXPORTER_OTLP_LOGS_PROTOCOL="http/protobuf"',
        f'export OTEL_EXPORTER_OTLP_LOGS_ENDPOINT="{endpoint}/v1/logs"',
        f'export OTEL_EXPORTER_OTLP_ENDPOINT="{endpoint}"',
        f'export OTEL_LOG_RAW_API_BODIES="file:{wire_dir}"',
        'export OTEL_LOG_USER_PROMPTS="1"',
        'export OTEL_LOG_TOOL_DETAILS="1"',
    ]


def generate_shim_script(
    port: int,
    wire_dir: str,
    *,
    python_executable: str | None = None,
) -> str:
    """Render the ``~/.sentisec/bin/claude`` shim shell script.

    The shim is a ``/bin/sh`` script that:

    1. exports the verified :func:`otel_env_block` (env that must be set
       at ``claude`` launch and is not inheritable by subprocesses);
    2. ensures the daemon is up — checks ``/healthz`` and lazy-starts the
       THIN daemon (``python -m sentisec_sdk.edge.daemon``) in the
       background if the check fails (the lazy-start fallback);
    3. ``exec``s the REAL ``claude``, resolved by stripping
       ``~/.sentisec/bin`` from ``PATH`` and re-running ``command -v`` so
       the shim never re-invokes itself.

    The real-binary resolution is the load-bearing correctness point: we
    remove our own dir from ``PATH`` and ask the shell to find ``claude``
    again, which yields the user's actual binary past the shim.

    ``python_executable`` defaults to :data:`sys.executable` so the
    lazy-start uses the same interpreter the wizard ran under.
    """
    py = python_executable or sys.executable
    env_lines = "\n".join(otel_env_block(port, wire_dir))
    bin_dir = str(default_shim_dir())
    # The shim must locate the real `claude` past itself: drop our bin dir
    # from PATH, then `command -v claude`.
    return f"""#!/bin/sh
# Sentisec Edge — transparent `claude` shim ({SENTISEC_HOOK_MARKER}).
# Managed file: do not edit. `sentisec edge uninstall` removes it cleanly.
#
# Sets the verified OTEL_* launch env (not inheritable by subprocesses, so
# it MUST live here), ensures the local thin daemon is up, then execs the
# real `claude` resolved past this shim.

{env_lines}

SENTISEC_DAEMON_PORT="{port}"
SENTISEC_BIN_DIR="{bin_dir}"

# 1) Ensure the daemon is up (lazy-start fallback). The launchd/systemd
#    user service is the primary; this catches the "service not loaded
#    yet / new login" gap so `claude` is never ungated by a cold daemon.
if ! curl -fsS "http://127.0.0.1:${{SENTISEC_DAEMON_PORT}}/healthz" \
        >/dev/null 2>&1; then
    "{py}" -m sentisec_sdk.edge.daemon >/dev/null 2>&1 &
    # Give the daemon a moment to bind before claude reads the hooks.
    i=0
    while [ "$i" -lt 20 ]; do
        if curl -fsS "http://127.0.0.1:${{SENTISEC_DAEMON_PORT}}/healthz" \
                >/dev/null 2>&1; then
            break
        fi
        sleep 0.25
        i=$((i + 1))
    done
fi

# 2) Resolve the REAL `claude` past this shim: strip our bin dir from PATH
#    so `command -v` returns the user's actual binary.
_sentisec_clean_path=""
_IFS_SAVE="$IFS"
IFS=":"
for _p in $PATH; do
    if [ "$_p" != "${{SENTISEC_BIN_DIR}}" ]; then
        if [ -z "$_sentisec_clean_path" ]; then
            _sentisec_clean_path="$_p"
        else
            _sentisec_clean_path="${{_sentisec_clean_path}}:${{_p}}"
        fi
    fi
done
IFS="$_IFS_SAVE"

_real_claude="$(PATH="$_sentisec_clean_path" command -v claude 2>/dev/null)"
if [ -z "$_real_claude" ]; then
    echo "sentisec: could not find the real 'claude' on PATH" >&2
    exit 127
fi

# 3) Hand off — exec replaces this process so claude sees the OTEL env.
exec "$_real_claude" "$@"
"""


def install_claude_shim(
    port: int,
    wire_dir: str,
    *,
    home: Path | None = None,
    python_executable: str | None = None,
) -> ShimPaths:
    """Write ``~/.sentisec/bin/claude`` and mark it executable.

    Creates ``~/.sentisec/bin`` (resolved under ``home``), writes the
    :func:`generate_shim_script` content, and ``chmod 0755``s it.
    Idempotent — re-running overwrites the shim with the current port /
    wire dir. Returns the resolved :class:`ShimPaths` so the wizard /
    tests can assert on the bin dir + shim path.

    This function does NOT touch the shell profile — that is
    :func:`write_path_block`'s job, kept separate so a re-install can
    refresh the shim without re-editing every profile.
    """
    base = home if home is not None else default_home()
    bin_dir = base / ".sentisec" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim_path = bin_dir / "claude"
    shim_path.write_text(
        generate_shim_script(port, wire_dir, python_executable=python_executable),
        encoding="utf-8",
    )
    shim_path.chmod(
        stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH
    )
    return ShimPaths(bin_dir=bin_dir, shim_path=shim_path)


def uninstall_claude_shim(home: Path | None = None) -> None:
    """Remove the shim file (and the bin dir if it is then empty).

    The reverse of :func:`install_claude_shim`. A missing shim is a no-op.
    The PATH block in the shell profile is removed separately by
    :func:`remove_path_block` (the wizard calls both on uninstall).
    """
    base = home if home is not None else default_home()
    bin_dir = base / ".sentisec" / "bin"
    shim_path = bin_dir / "claude"
    if shim_path.exists():
        shim_path.unlink()
    # Remove the bin dir only if our removal left it empty (never delete a
    # dir holding other files the user put there).
    if bin_dir.is_dir() and not any(bin_dir.iterdir()):
        bin_dir.rmdir()


def _shell_profiles(home: Path) -> list[Path]:
    """Return the candidate shell profile paths to write the PATH block.

    Covers zsh (``.zshrc``), bash (``.bashrc`` + ``.bash_profile``), and
    fish (``.config/fish/config.fish``). We write the marked block to
    every profile path so a fresh shell picks the block up regardless of
    which RC the user's terminal sources. Fish uses a different export
    syntax — :func:`write_path_block` branches on the filename.
    """
    return [
        home / ".zshrc",
        home / ".bashrc",
        home / ".bash_profile",
        home / ".config" / "fish" / "config.fish",
    ]


def _path_block_body(bin_dir: Path, *, fish: bool) -> str:
    """Render the PATH-prepend block body for posix-sh or fish."""
    export = (
        f'set -gx PATH "{bin_dir}" $PATH'
        if fish
        else f'export PATH="{bin_dir}:$PATH"'
    )
    return f"{PATH_BLOCK_BEGIN}\n{export}\n{PATH_BLOCK_END}\n"


def write_path_block(
    bin_dir: Path,
    *,
    home: Path | None = None,
    profiles: list[Path] | None = None,
) -> list[Path]:
    """Prepend ``bin_dir`` to PATH via a marked block in shell profiles.

    Writes the :data:`PATH_BLOCK_BEGIN`...:data:`PATH_BLOCK_END`-fenced
    block to each profile in ``profiles`` (default: the standard zsh /
    bash / fish set from :func:`_shell_profiles`). The block is:

    - **idempotent** — if a profile already contains the marked block it is
      replaced (so a re-install refreshes the bin dir cleanly rather than
      stacking duplicates);
    - **marker-fenced** — :func:`remove_path_block` excises exactly this
      block, leaving the rest of the profile untouched.

    Fish profiles get fish ``set -gx`` syntax; everything else gets posix
    ``export``. Returns the list of profile paths actually written.
    """
    base = home if home is not None else default_home()
    targets = profiles if profiles is not None else _shell_profiles(base)
    written: list[Path] = []
    for profile in targets:
        is_fish = profile.name == "config.fish"
        block = _path_block_body(bin_dir, fish=is_fish)
        profile.parent.mkdir(parents=True, exist_ok=True)
        existing = (
            profile.read_text(encoding="utf-8") if profile.is_file() else ""
        )
        stripped = _strip_path_block(existing)
        # Ensure exactly one trailing newline before appending the block.
        prefix = stripped.rstrip("\n")
        new_content = (prefix + "\n\n" if prefix else "") + block
        profile.write_text(new_content, encoding="utf-8")
        written.append(profile)
    return written


def _strip_path_block(content: str) -> str:
    """Return ``content`` with the Sentisec PATH block excised.

    Removes everything between (and including) the begin/end fence lines.
    Content with no block is returned unchanged. Tolerates the block
    appearing once (the only shape :func:`write_path_block` produces).
    """
    if PATH_BLOCK_BEGIN not in content:
        return content
    lines = content.splitlines(keepends=True)
    out: list[str] = []
    skipping = False
    for line in lines:
        if line.strip() == PATH_BLOCK_BEGIN:
            skipping = True
            continue
        if line.strip() == PATH_BLOCK_END:
            skipping = False
            continue
        if not skipping:
            out.append(line)
    return "".join(out)


def remove_path_block(
    *,
    home: Path | None = None,
    profiles: list[Path] | None = None,
) -> list[Path]:
    """Excise the Sentisec PATH block from every profile.

    The reverse of :func:`write_path_block`. Reads each profile, strips the
    marked block, and writes the remainder back (preserving every other
    line). A profile without the block, or a missing profile, is skipped.
    Returns the list of profiles actually modified.

    Cleans up any blank-line residue our block-with-surrounding-newlines
    left, so an uninstall leaves no Sentisec footprint.
    """
    base = home if home is not None else default_home()
    targets = profiles if profiles is not None else _shell_profiles(base)
    modified: list[Path] = []
    for profile in targets:
        if not profile.is_file():
            continue
        content = profile.read_text(encoding="utf-8")
        if PATH_BLOCK_BEGIN not in content:
            continue
        stripped = _strip_path_block(content)
        # Collapse the doubled blank line our block left behind, and
        # normalise to a single trailing newline (or empty file).
        cleaned = stripped.replace("\n\n\n", "\n\n").rstrip("\n")
        profile.write_text(cleaned + "\n" if cleaned else "", encoding="utf-8")
        modified.append(profile)
    return modified


# ---------------------------------------------------------------------------
# Daemon background service (launchd / systemd-user)
# ---------------------------------------------------------------------------

#: launchd service label (macOS). Reverse-DNS per Apple convention; the
#: plist filename mirrors it (``ch.sentisec.edge.plist``).
LAUNCHD_LABEL = "ch.sentisec.edge"

#: systemd-user unit name (Linux).
SYSTEMD_UNIT_NAME = "sentisec-edge.service"


def _daemon_program_arguments(
    py: str, entrypoint: str | None
) -> list[str]:
    """Resolve the daemon launch argv for a service file / spawn.

    The launch form is the load-bearing fix for the curl/zipapp install
    (P-INST). For a pip/pipx install ``python -m sentisec_sdk.edge.daemon``
    works because ``sentisec_sdk`` is importable by a bare ``python``. For
    the self-contained zipapp at ``~/.local/bin/sentisec`` it is NOT —
    ``sentisec_sdk`` lives INSIDE the zipapp, invisible to a bare
    ``python``, so the ``-m`` form dies with ``ModuleNotFoundError``.

    The fix: launch via the installed ``sentisec`` ENTRYPOINT instead —
    ``python <entrypoint> edge __daemon``. For a zipapp this runs the
    bundled CLI (all deps present) → the daemon starts; for pip/pipx the
    same form runs the console-script. We fall back to the ``-m`` form ONLY
    when the entrypoint could not be resolved (no ``sentisec`` on PATH and
    no usable ``argv[0]``), which still works for pip/pipx installs.
    """
    if entrypoint:
        return [py, entrypoint, "edge", "__daemon"]
    return [py, "-m", "sentisec_sdk.edge.daemon"]


def generate_launchd_plist(
    *,
    python_executable: str | None = None,
    home: Path | None = None,
    entrypoint: str | None = None,
) -> str:
    """Render the macOS launchd plist for the daemon user agent.

    The agent runs the daemon via the ``sentisec`` entrypoint
    (``python <entrypoint> edge __daemon``) when ``entrypoint`` is given —
    the form that works for the zipapp install — falling back to ``python
    -m sentisec_sdk.edge.daemon`` (pip/pipx only) when it is ``None``.
    ``RunAtLoad`` + ``KeepAlive`` so it starts at login and is restarted if
    it crashes ("survives logout/reboot"). Logs go to
    ``~/.sentisec/daemon.log``. The caller installs this at
    ``~/Library/LaunchAgents/ch.sentisec.edge.plist`` and ``launchctl
    load``s it (the wizard's job, not this pure renderer's).
    """
    py = python_executable or sys.executable
    base = home if home is not None else default_home()
    log_path = base / ".sentisec" / "daemon.log"
    arg_lines = "\n".join(
        f"        <string>{arg}</string>"
        for arg in _daemon_program_arguments(py, entrypoint)
    )
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" \
"http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{LAUNCHD_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
{arg_lines}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_path}</string>
    <key>StandardErrorPath</key>
    <string>{log_path}</string>
</dict>
</plist>
"""


def generate_systemd_unit(
    *,
    python_executable: str | None = None,
    entrypoint: str | None = None,
) -> str:
    """Render the Linux systemd-user unit for the daemon.

    ``ExecStart`` launches the daemon via the ``sentisec`` entrypoint
    (``python <entrypoint> edge __daemon``) when ``entrypoint`` is given —
    the form that works for the zipapp install — falling back to ``python
    -m sentisec_sdk.edge.daemon`` (pip/pipx only) when it is ``None``.
    ``Restart=always`` mirrors launchd ``KeepAlive``; ``WantedBy=
    default.target`` enables it for the user session so it starts on login.
    The caller installs this at
    ``~/.config/systemd/user/sentisec-edge.service`` and ``systemctl
    --user enable --now``s it (the wizard's job).
    """
    py = python_executable or sys.executable
    exec_start = " ".join(_daemon_program_arguments(py, entrypoint))
    return f"""[Unit]
Description=Sentisec Edge daemon (subscription demo mode)
After=network.target

[Service]
ExecStart={exec_start}
Restart=always
RestartSec=2

[Install]
WantedBy=default.target
"""


def service_file_path(home: Path | None = None) -> Path:
    """Return the per-OS user-service file path under ``home``.

    macOS -> ``~/Library/LaunchAgents/ch.sentisec.edge.plist``; everything
    else (Linux) -> ``~/.config/systemd/user/sentisec-edge.service``.
    """
    base = home if home is not None else default_home()
    if platform.system() == "Darwin":
        return base / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
    return base / ".config" / "systemd" / "user" / SYSTEMD_UNIT_NAME


def install_daemon_service(
    *,
    home: Path | None = None,
    python_executable: str | None = None,
    system: str | None = None,
    entrypoint: str | None = None,
) -> Path:
    """Write the per-OS user-service file and return its path.

    Selects launchd (macOS) or systemd-user (Linux) by ``system``
    (defaults to :func:`platform.system`), renders the matching unit, and
    writes it to :func:`service_file_path`. This is the FILE-WRITE half
    only — it deliberately does NOT ``launchctl load`` / ``systemctl
    --user enable`` (that side effect belongs to the wizard and is never
    run in tests). Idempotent: re-writing refreshes the file. Returns the
    written path.

    ``entrypoint`` is the resolved installed ``sentisec`` path. When given,
    the service launches the daemon via ``python <entrypoint> edge
    __daemon`` — the form that makes the curl/zipapp install self-sufficient
    (no ``pip install`` required). When ``None`` the service falls back to
    ``python -m sentisec_sdk.edge.daemon`` (works for pip/pipx only).
    """
    sysname = system if system is not None else platform.system()
    base = home if home is not None else default_home()
    if sysname == "Darwin":
        path = base / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
        content = generate_launchd_plist(
            python_executable=python_executable,
            home=base,
            entrypoint=entrypoint,
        )
    else:
        path = base / ".config" / "systemd" / "user" / SYSTEMD_UNIT_NAME
        content = generate_systemd_unit(
            python_executable=python_executable, entrypoint=entrypoint
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def uninstall_daemon_service(
    *,
    home: Path | None = None,
    system: str | None = None,
) -> None:
    """Remove the per-OS user-service file (no-op if absent).

    The reverse of :func:`install_daemon_service`. Like its installer twin
    it touches only the file — unloading the running service (``launchctl
    unload`` / ``systemctl --user disable``) is the wizard's
    responsibility and never happens in tests.
    """
    sysname = system if system is not None else platform.system()
    base = home if home is not None else default_home()
    if sysname == "Darwin":
        path = base / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
    else:
        path = base / ".config" / "systemd" / "user" / SYSTEMD_UNIT_NAME
    if path.exists():
        path.unlink()


# ---------------------------------------------------------------------------
# Codex provider — idempotent, reversible TOML merge (LOCAL passthrough).
# ---------------------------------------------------------------------------

#: The ``model_provider`` value Codex selects when Sentisec Edge is wired
#: — also the table key under ``[model_providers.<slot>]``. Codex reads
#: ``model_provider`` to pick which provider block to use; setting it to
#: our slot routes Codex's traffic through the LOCAL passthrough proxy
#: (:mod:`sentisec_sdk.edge.codex_proxy`).
CODEX_PROVIDER_SLOT = "sentisec-edge"

#: Human-readable provider name surfaced in Codex's UI.
CODEX_PROVIDER_NAME = "Sentisec Edge"

#: Top-level key we stash the user's pre-install ``model_provider`` under
#: so :func:`remove_codex_provider` can restore the user's prior default
#: provider on uninstall. Namespaced so it never collides with a real
#: Codex config key. Absent when the user had no ``model_provider`` set
#: before Sentisec wired itself (remove then deletes the key entirely).
_CODEX_PRIOR_PROVIDER_KEY = "x_sentisec_prior_model_provider"


def codex_config_path(home: Path | None = None) -> Path:
    """Resolve the user-level ``~/.codex/config.toml`` under ``home``.

    Codex reads provider config from the USER-level config only
    (project-local files are ignored for provider keys, design §2), so
    this is the single file the writer touches.
    """
    base = home if home is not None else default_home()
    return base / ".codex" / "config.toml"


def _load_codex_config(path: Path) -> dict[str, object]:
    """Read ``config.toml`` into a dict (empty dict if absent/empty)."""
    if not path.is_file():
        return {}
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return {}
    return tomllib.loads(text)


def _codex_provider_block(port: int, workspace_key: str) -> dict[str, object]:
    """Build the ``[model_providers.sentisec-edge]`` table (design §4.4).

    Emits the verified Codex provider shape::

        name = "Sentisec Edge"
        base_url = "http://127.0.0.1:<port>/v1"
        wire_api = "responses"
        requires_openai_auth = true
        http_headers = { "X-Sentisec-Workspace-Key" = "sk_sentisec_…" }

    ``base_url`` ends in ``/v1`` so Codex POSTs to ``/v1/responses`` (the
    route :mod:`sentisec_sdk.edge.codex_proxy` serves); the local proxy
    resolves the workspace from the ``X-Sentisec-Workspace-Key`` header.
    ``requires_openai_auth`` makes Codex attach its ChatGPT bearer, which
    the proxy forwards box-to-backend (never persisted, never sent to the
    hosted plane — design §9).
    """
    return {
        "name": CODEX_PROVIDER_NAME,
        "base_url": f"http://127.0.0.1:{port}/v1",
        "wire_api": "responses",
        "requires_openai_auth": True,
        "http_headers": {"X-Sentisec-Workspace-Key": workspace_key},
    }


def write_codex_provider(
    port: int,
    workspace_key: str,
    *,
    home: Path | None = None,
    path: Path | None = None,
) -> Path:
    """Merge the Sentisec Edge provider block into ``~/.codex/config.toml``.

    Idempotent + reversible. The merge:

    - **preserves the user's existing codex config** — every top-level
      key + every other ``[model_providers.*]`` block survives;
    - **records the prior ``model_provider``** under
      :data:`_CODEX_PRIOR_PROVIDER_KEY` (only on the FIRST install, so a
      re-run does not overwrite the saved original with our own slot) so
      :func:`remove_codex_provider` can restore it;
    - **sets ``model_provider = "sentisec-edge"``** so Codex routes
      through the local passthrough proxy;
    - **idempotent** — a second call with a new port/key refreshes our
      block in place without duplicating it or re-saving a stale prior.

    Parameters
    ----------
    port:
        The local codex proxy port (``daemon_port + 1``; see
        :func:`sentisec_sdk.edge.codex_proxy.codex_proxy_port`). The
        provider ``base_url`` is ``http://127.0.0.1:<port>/v1``.
    workspace_key:
        The ``sk_sentisec_*`` workspace key written into the provider's
        ``http_headers`` block as ``X-Sentisec-Workspace-Key``. This is
        Sentisec's identity — NOT a provider token.
    home / path:
        Override the home dir / the exact config path (tests). ``path``
        wins; otherwise resolved via :func:`codex_config_path`.

    Returns the written config path.
    """
    cfg_path = path if path is not None else codex_config_path(home)
    data = _load_codex_config(cfg_path)

    # Record the user's prior model_provider exactly once (first install)
    # so a re-run with a refreshed port/key does not clobber the saved
    # original with our own slot.
    if _CODEX_PRIOR_PROVIDER_KEY not in data:
        prior = data.get("model_provider")
        if isinstance(prior, str) and prior != CODEX_PROVIDER_SLOT:
            data[_CODEX_PRIOR_PROVIDER_KEY] = prior

    providers_obj = data.get("model_providers")
    providers: dict[str, object] = (
        providers_obj if isinstance(providers_obj, dict) else {}
    )
    providers[CODEX_PROVIDER_SLOT] = _codex_provider_block(port, workspace_key)
    data["model_providers"] = providers
    data["model_provider"] = CODEX_PROVIDER_SLOT

    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    with cfg_path.open("wb") as fh:
        tomli_w.dump(data, fh)
    return cfg_path


def remove_codex_provider(
    *,
    home: Path | None = None,
    path: Path | None = None,
) -> None:
    """Excise the Sentisec Edge provider block from ``config.toml``.

    The reverse of :func:`write_codex_provider`. Removes the
    ``[model_providers.sentisec-edge]`` block and restores the user's
    prior ``model_provider`` (recorded at install time under
    :data:`_CODEX_PRIOR_PROVIDER_KEY`):

    - if a prior provider was recorded → restore it as ``model_provider``;
    - else → delete ``model_provider`` entirely (the user had none);
    - if removing our block empties ``model_providers`` → drop the table.

    Every other top-level key + other ``[model_providers.*]`` survives.
    A missing file, or a config without our block, is a no-op (with the
    one exception that a leftover ``model_provider = "sentisec-edge"`` is
    still reset so the user is never left pointed at a removed provider).
    """
    cfg_path = path if path is not None else codex_config_path(home)
    if not cfg_path.is_file():
        return
    data = _load_codex_config(cfg_path)

    providers_obj = data.get("model_providers")
    if isinstance(providers_obj, dict):
        providers_obj.pop(CODEX_PROVIDER_SLOT, None)
        if providers_obj:
            data["model_providers"] = providers_obj
        else:
            data.pop("model_providers", None)

    # Restore the prior model_provider (or drop it). Only act when our
    # slot is the current selection so we never override a user who
    # re-pointed model_provider at something else after install.
    prior = data.pop(_CODEX_PRIOR_PROVIDER_KEY, None)
    if data.get("model_provider") == CODEX_PROVIDER_SLOT:
        if isinstance(prior, str):
            data["model_provider"] = prior
        else:
            data.pop("model_provider", None)

    with cfg_path.open("wb") as fh:
        tomli_w.dump(data, fh)
