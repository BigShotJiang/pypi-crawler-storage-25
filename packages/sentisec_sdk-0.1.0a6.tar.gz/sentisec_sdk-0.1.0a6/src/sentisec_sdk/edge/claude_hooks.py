"""Claude Code hook handlers — thin gate forward + capture.

Claude Code's native hook system POSTs a JSON envelope to the daemon's
``/hooks`` endpoint for every configured ``hook_event_name``. This module
turns those envelopes into:

- **PreToolUse** -> forward the RAW payload to the HOSTED gate
  (``POST /v1/edge/gate`` via :mod:`sentisec_sdk.edge.gate_client`), wrap
  the flat verdict into Claude Code's ``hookSpecificOutput`` shape, and
  enqueue the ``tool_call`` + ``verdict`` capture events. The gate runs
  the engines SERVER-SIDE; this client holds none.
- **PostToolUse / PostToolUseFailure / UserPromptSubmit / Stop /
  SubagentStop / SessionEnd** -> standard Sentisec capture events
  (:mod:`sentisec_sdk.edge.events`) pushed onto the upload buffer.

Thin client — NO engines
========================

Unlike the platform package's ``sentisec.edge.claude_hooks`` (which ran
the server-side analysis engines locally), this thin handler does NO
mapping, NO pipeline, NO risk synthesis on the client. The PreToolUse
decision is the hosted gate's flat verdict, wrapped. The capture events
are built from the RAW hook payload + the gate response strings.

The PreToolUse hook contract (200 reply)::

    {"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": "Sentisec: <rule-id> — <why>"}}

``permissionDecision`` is the hosted gate's ``allow`` / ``deny`` / ``ask``.
A gate fault fails open to ``allow`` (see
:func:`sentisec_sdk.edge.gate_client.call_gate`).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .events import (
    build_assistant_turn_event,
    build_session_closed_event,
    build_tool_call_event,
    build_user_prompt_event,
    build_verdict_event,
)
from .gate_client import call_gate, wrap_pretooluse_output

if TYPE_CHECKING:
    from .daemon import SessionTracker

__all__ = [
    "handle_hook",
    "handle_pretooluse",
]


def _extract_assistant_text(payload: dict[str, Any]) -> str:
    """Best-effort extract assistant turn text from a Stop payload.

    Claude Code's ``Stop`` hook does not carry the assistant text inline
    in a documented field; the transcript path / OTel
    ``api_response_body`` are the authoritative sources. We read a
    ``text`` / ``message`` field if present (forward-compat with a richer
    payload) and fall back to the empty string. The OTel enrichment
    refines the forensic turn.
    """
    for key in ("text", "message", "assistant_text"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            return value
    return ""


def handle_pretooluse(
    payload: dict[str, Any], tracker: SessionTracker
) -> dict[str, Any]:
    """Forward one ``PreToolUse`` payload to the hosted gate and wrap it.

    Flow (Option B — thin client):

    1. Open the session (emit the one-per-session ``session_started`` if
       this is the first event for the ``session_id``).
    2. Forward the RAW payload to ``POST /v1/edge/gate`` via the tracker's
       gate client. The server runs the analysis engines + risk synthesis
       and returns a flat allow/deny/ask verdict (or the client fails open).
    3. Enqueue the ``tool_call`` + ``verdict`` capture events (built from
       the raw payload + the flat gate response).
    4. Return the wrapped ``hookSpecificOutput`` the CLI enforces.

    The session id is taken from ``payload["session_id"]``; a missing id
    falls back to the empty string (a single-bucket session for a
    malformed call).
    """
    session_id = str(payload.get("session_id", ""))
    tracker.open_session(session_id)

    decision = call_gate(
        payload,
        control_plane_url=tracker.control_plane_url,
        workspace_key=tracker.workspace_key,
        client=tracker.gate_client,
    )

    # Capture: a tool_call event (from the raw payload) + the verdict
    # event (from the flat gate response). step_idx is owned server-side
    # for the gate; the tracker keeps a local counter purely for the
    # dashboard timeline ordering of the capture events.
    step_idx = tracker.next_step(session_id)
    tracker.push(
        build_tool_call_event(
            session_id=session_id,
            step_idx=step_idx,
            tool_name=str(payload.get("tool_name", "") or ""),
            tool_input=payload.get("tool_input"),
        )
    )
    tracker.push(
        build_verdict_event(
            session_id=session_id,
            verdict=decision.verdict,
            intervention=decision.intervention,
            step_idx=step_idx,
        )
    )

    return wrap_pretooluse_output(decision)


def handle_hook(
    payload: dict[str, Any], tracker: SessionTracker
) -> dict[str, Any]:
    """Dispatch a hook event on ``hook_event_name`` to its handler.

    ``PreToolUse`` is the synchronous gate (returns a
    ``permissionDecision``). Every other event is a capture event and
    returns an empty ``{}`` body — Claude Code ignores the response body
    for non-PreToolUse hooks; a 2xx with ``{}`` is the canonical
    "captured, nothing to enforce" reply.

    Unknown / missing ``hook_event_name`` -> ``{}`` (captured nothing;
    fail-open — a malformed event must never block a tool call).
    """
    event = str(payload.get("hook_event_name", ""))
    if event == "PreToolUse":
        return handle_pretooluse(payload, tracker)
    _record_capture(payload, tracker)
    return {}


def _record_capture(payload: dict[str, Any], tracker: SessionTracker) -> None:
    """Build + enqueue capture events for a non-PreToolUse hook.

    Handles ``PostToolUse`` / ``PostToolUseFailure`` / ``UserPromptSubmit``
    / ``Stop`` / ``SubagentStop`` / ``SessionEnd``. Session open is keyed
    off the first event seen for a ``session_id`` (no http
    ``SessionStart``) — touching the tracker here emits the
    ``session_started`` event if this is the first event for the session.
    """
    session_id = str(payload.get("session_id", ""))
    tracker.open_session(session_id)

    event = str(payload.get("hook_event_name", ""))
    if event == "UserPromptSubmit":
        prompt = str(payload.get("prompt", ""))
        # FIX-D: hand the REAL prompt text to the OTLP turn correlation.
        # The OTLP ``user_prompt`` record body is the event name, not the
        # text — so the model_request projection sourced a placeholder.
        # The ``UserPromptSubmit`` hook ``prompt`` IS the real text; the
        # receiver stamps it onto the next turn's request.
        tracker.set_user_prompt(session_id, prompt)
        tracker.push(
            build_user_prompt_event(session_id=session_id, prompt=prompt)
        )
    elif event in ("Stop", "SubagentStop"):
        text = _extract_assistant_text(payload)
        tracker.push(
            build_assistant_turn_event(session_id=session_id, text=text)
        )
    elif event == "SessionEnd":
        tracker.push(build_session_closed_event(session_id=session_id))
    # PostToolUse / PostToolUseFailure carry the tool RESULT; the gate's
    # tool_call + verdict events are authoritative for the dashboard
    # timeline, and the OTel enrichment path attaches the tool result to
    # the forensic record — so these are a captured no-op here. Unknown
    # event types are also captured (session opened) but produce no
    # specific event (fail-open).
