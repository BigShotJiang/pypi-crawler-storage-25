"""Hosted-gate HTTP client for the thin edge daemon (Option B core).

The thin daemon holds NO Sentisec engines. When Claude Code fires a
``PreToolUse`` hook, the daemon forwards the RAW hook payload to the
HOSTED gate (``POST {control_plane_url}/v1/edge/gate``) which runs the
real engines server-side and returns a flat allow/deny/ask verdict. This
module is that forward-and-wrap client.

The gate contract (coded against ``platform/sentisec/proxy/edge_gate.py``)
====================================================================

Request
-------
``POST {control_plane_url}/v1/edge/gate``
- Header: ``Authorization: Bearer <sk_sentisec_workspace_key>`` (the gate
  also accepts ``X-Sentisec-Workspace-Key``; we send the Bearer form).
- Body: the raw Claude Code hook payload —
  ``{hook_event_name, tool_name, tool_input, session_id, cwd?,
  transcript_path?, task?}``.

Response
--------
- ``200``: ``{"permissionDecision": "allow"|"deny"|"ask",
  "permissionDecisionReason": "Sentisec: ...", "verdict": "...",
  "intervention": "..."}``.
- ``401``: ``{"error": "invalid_workspace_key"}``.

The daemon WRAPS the flat 200 response into the Claude Code hook shape it
returns to the CLI::

    {"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": <decision>,
        "permissionDecisionReason": <reason>}}

Fail-open (load-bearing)
========================

The daemon blocks on this call synchronously before the tool runs, so a
gate that is unreachable / times out / returns non-2xx must NEVER hang or
deny the tool call. Matching the proxy's own fail-open posture
(``_fail_open_response`` in ``edge_gate.py``), every error path here
returns an ``allow`` decision. A tool call is never hung by a network
fault.

NO engines, NO ``sentisec.*`` import — only ``httpx`` + stdlib.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import httpx

__all__ = [
    "GATE_PATH",
    "GateDecision",
    "call_gate",
    "wrap_pretooluse_output",
]

_logger = logging.getLogger("sentisec_sdk.edge.gate_client")

#: The hosted gate route. Joined onto ``control_plane_url`` (default
#: ``https://api.sentisec.ch``).
GATE_PATH = "/v1/edge/gate"

#: The three Claude Code permission-decision literals.
_ALLOW = "allow"
_ASK = "ask"
_DENY = "deny"

#: Default request timeout for the synchronous gate call. Kept tight: the
#: daemon blocks the user's tool call on this, so a slow gate fails open
#: fast rather than freezing the CLI.
_GATE_TIMEOUT_S = 8.0


@dataclass(frozen=True)
class GateDecision:
    """The parsed flat verdict the hosted gate returned (or a fail-open).

    Carries the four flat fields the gate's 200 body holds. ``failed_open``
    is ``True`` when this decision was synthesised locally because the gate
    was unreachable / errored — the daemon allows the call but the field
    lets the capture path / tests distinguish a real ``allow`` from a
    fail-open ``allow``.
    """

    permission_decision: str
    permission_decision_reason: str
    verdict: str
    intervention: str
    failed_open: bool = False


def _fail_open(reason: str) -> GateDecision:
    """Build a fail-open ``allow`` decision (gate unreachable / errored)."""
    return GateDecision(
        permission_decision=_ALLOW,
        permission_decision_reason=reason,
        verdict="NOMINAL",
        intervention="PROCEED",
        failed_open=True,
    )


def call_gate(
    payload: dict[str, Any],
    *,
    control_plane_url: str,
    workspace_key: str,
    client: httpx.Client | None = None,
    timeout_s: float = _GATE_TIMEOUT_S,
) -> GateDecision:
    """Forward a ``PreToolUse`` payload to the hosted gate. Never raises.

    Posts the RAW hook ``payload`` to ``{control_plane_url}/v1/edge/gate``
    with the workspace key as ``Authorization: Bearer``. Parses the flat
    200 body into a :class:`GateDecision`. Any failure — no workspace key,
    transport error, timeout, non-2xx, malformed body — returns a
    fail-open ``allow`` :class:`GateDecision` (``failed_open=True``), so
    the daemon never hangs or denies a tool call on a gate fault.

    Parameters
    ----------
    payload:
        The raw Claude Code hook payload (``hook_event_name`` /
        ``tool_name`` / ``tool_input`` / ``session_id`` / ...). Forwarded
        as-is — the server does the mapping + risk synthesis.
    control_plane_url:
        The Sentisec cloud base (default ``https://api.sentisec.ch``).
    workspace_key:
        The ``sk_sentisec_*`` key. Empty -> fail-open allow (pre-login
        mode: the daemon gates nothing until login mints a key).
    client:
        Injected :class:`httpx.Client` (tests pass a
        ``httpx.MockTransport``-backed client). Created + closed
        internally when ``None``.
    timeout_s:
        Per-call timeout. The daemon blocks on this; kept tight.
    """
    if not workspace_key:
        # Pre-login: no key to authenticate the gate. The daemon still
        # captures events to the buffer, but it cannot gate — fail open so
        # the user's CLI is never blocked before they log in.
        return _fail_open(
            "Sentisec: not logged in — run `sentisec edge` (allowing)"
        )

    url = control_plane_url.rstrip("/") + GATE_PATH
    headers = {"Authorization": f"Bearer {workspace_key}"}
    owns_client = client is None
    cl = client if client is not None else httpx.Client(timeout=timeout_s)
    try:
        try:
            resp = cl.post(url, json=payload, headers=headers)
        except httpx.HTTPError as exc:
            _logger.warning(
                "event=edge_gate_unreachable url=%s err=%r — failing OPEN",
                url,
                exc,
            )
            return _fail_open(
                "Sentisec: gate unreachable — failing open (allow)"
            )
        if resp.status_code == 401:
            # Bad / unknown / expired workspace key. We CANNOT gate, but a
            # 401 must not hang the user's tool call — fail open with a
            # diagnostic so the status panel / logs surface the auth gap.
            _logger.warning(
                "event=edge_gate_unauthorized url=%s — workspace key "
                "rejected; failing OPEN (re-run `sentisec edge` to re-pair)",
                url,
            )
            return _fail_open(
                "Sentisec: workspace key rejected — failing open (allow); "
                "re-run `sentisec edge` to re-pair"
            )
        if not (200 <= resp.status_code < 300):
            _logger.warning(
                "event=edge_gate_non_2xx status=%d — failing OPEN",
                resp.status_code,
            )
            return _fail_open(
                f"Sentisec: gate returned HTTP {resp.status_code} — "
                "failing open (allow)"
            )
        try:
            body = resp.json()
        except ValueError:
            _logger.warning("event=edge_gate_bad_json — failing OPEN")
            return _fail_open(
                "Sentisec: gate returned a non-JSON body — failing open (allow)"
            )
    finally:
        if owns_client:
            cl.close()

    return _parse_gate_body(body)


def _parse_gate_body(body: Any) -> GateDecision:
    """Parse a gate 200 body into a :class:`GateDecision` (fail-open on junk).

    A body missing the decision field, or carrying a decision outside the
    three literals, is treated as a fault -> fail-open allow. This keeps a
    server-side contract divergence from accidentally hanging or
    hard-denying a tool call.
    """
    if not isinstance(body, dict):
        return _fail_open(
            "Sentisec: gate returned an unexpected body — failing open (allow)"
        )
    decision = body.get("permissionDecision")
    if decision not in (_ALLOW, _ASK, _DENY):
        return _fail_open(
            "Sentisec: gate returned no decision — failing open (allow)"
        )
    reason = body.get("permissionDecisionReason")
    return GateDecision(
        permission_decision=str(decision),
        permission_decision_reason=(
            str(reason) if isinstance(reason, str) and reason else "Sentisec: gated"
        ),
        verdict=str(body.get("verdict", "NOMINAL") or "NOMINAL"),
        intervention=str(body.get("intervention", "PROCEED") or "PROCEED"),
        failed_open=False,
    )


def wrap_pretooluse_output(decision: GateDecision) -> dict[str, Any]:
    """Wrap a :class:`GateDecision` in the Claude Code ``hookSpecificOutput``.

    This is the exact shape Claude Code's ``PreToolUse`` hook expects on a
    200 reply — the daemon returns it verbatim so the CLI enforces the
    decision before the tool runs (a ``deny`` overrides
    ``bypassPermissions`` / ``--dangerously-skip-permissions``).
    """
    return {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": decision.permission_decision,
            "permissionDecisionReason": decision.permission_decision_reason,
        }
    }
