"""Edge daemon configuration — ``~/.sentisec/edge.toml``.

The thin edge daemon is configured by a single TOML file under the
user's home directory. This module is the typed read/write surface for
that file. It is deliberately dependency-light: stdlib ``tomllib`` for
reading, ``tomli_w`` for writing, and **no** network or engine imports
(config-load only).

The config carries the fields the thin daemon needs to boot plus the
two dashboard-link fields the wizard persists at login:

- ``workspace_key`` — the ``sk_sentisec_*`` key minted by the wizard's
  login flow. Empty string until login completes. The daemon forwards it
  to the hosted gate (``POST /v1/edge/gate``) and the events route
  (``POST /v1/edge/events``) as ``Authorization: Bearer`` /
  ``X-Sentisec-Workspace-Key``.
- ``daemon_port`` — the local HTTP port the daemon binds for the hook
  endpoint + OTLP receiver. Default ``45711``.
- ``wire_dir`` — the directory ``OTEL_LOG_RAW_API_BODIES=file:<dir>``
  writes untruncated model bodies into. Default ``~/.sentisec/wire``.
- ``control_plane_url`` — the Sentisec cloud target the daemon forwards
  gate calls + uploads events to. Default ``https://api.sentisec.ch``;
  overridable for self-hosted / dev planes.
- ``workspace_id`` — the workspace **UUID** returned by the pairing
  response (``POST /v1/sdk/pair/complete``). The dashboard routes every
  view by this UUID (``/w/<uuid>/...``), so the wizard's watch link must
  use it, not the key's short-id segment. Empty string when unknown (the
  paste-key fallback never calls the pairing endpoint, so the UUID is not
  available there).
- ``dashboard_url`` — an explicit dashboard origin override
  (``--dashboard-url`` / ``SENTISEC_DASHBOARD_URL``). Empty string by
  default; when set it is used verbatim as the base for the pairing +
  watch links. This is the local escape hatch (e.g.
  ``http://localhost:3001``) for when the dashboard is on a different
  host/port than the control plane.

Missing-file semantics: ``EdgeConfig.load`` raises the custom
:class:`EdgeConfigMissing` (not a bare ``FileNotFoundError``) so the
wizard can distinguish "first run, no config yet -> run setup" from a
genuine I/O error.

This module is a near-verbatim port of the platform package's
``sentisec.edge.config`` — it was already engine-free.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import asdict, dataclass
from pathlib import Path

import tomli_w

__all__ = [
    "DEFAULT_CONTROL_PLANE_URL",
    "DEFAULT_DAEMON_PORT",
    "EdgeConfig",
    "EdgeConfigMissing",
]


# Canonical control-plane target. The edge demo points at the hosted
# plane by default; overrides land via the wizard / ``control_plane_url``
# field, not here.
DEFAULT_CONTROL_PLANE_URL = "https://api.sentisec.ch"

# Default local daemon port. Chosen high in the ephemeral range to
# minimise collision.
DEFAULT_DAEMON_PORT = 45711


class EdgeConfigMissing(Exception):  # noqa: N818 — name pinned by config contract
    """Raised by :meth:`EdgeConfig.load` when the config file is absent.

    A named exception (not a bare ``FileNotFoundError``) so the wizard
    can branch "no config -> run first-time setup" cleanly without
    swallowing unrelated I/O errors. Carries the resolved path so the
    caller can surface it.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        super().__init__(
            f"edge config not found at {path!s} — run `sentisec edge` to set up"
        )


def _default_wire_dir() -> str:
    """Resolve the default wire directory ``~/.sentisec/wire`` (expanded).

    ``os.path.expanduser`` resolves ``~`` against ``$HOME`` so tests can
    redirect it with a fake home; the returned value is an absolute
    string path (the daemon hands it to ``OTEL_LOG_RAW_API_BODIES`` as a
    string, so we store a string not a ``Path``).
    """
    return os.path.expanduser(os.path.join("~", ".sentisec", "wire"))


@dataclass(frozen=True)
class EdgeConfig:
    """Typed view of ``~/.sentisec/edge.toml``.

    Frozen — the daemon reads it once at boot and never mutates it in
    place; a config change goes through the wizard re-writing the file
    and the daemon reloading.

    The first four fields are the daemon's boot surface; ``workspace_id``
    and ``dashboard_url`` are the wizard-only dashboard-link fields (both
    default to ``""`` and are optional, so a config written before they
    existed still loads).
    """

    workspace_key: str
    daemon_port: int
    wire_dir: str
    control_plane_url: str
    workspace_id: str = ""
    dashboard_url: str = ""

    @classmethod
    def default(cls) -> EdgeConfig:
        """Construct the pre-login default config.

        ``daemon_port=45711``, ``wire_dir=~/.sentisec/wire`` (expanded),
        empty ``workspace_key`` (login not yet performed), the canonical
        control-plane URL, and empty ``workspace_id`` / ``dashboard_url``
        (filled in at login / via ``--dashboard-url``).
        """
        return cls(
            workspace_key="",
            daemon_port=DEFAULT_DAEMON_PORT,
            wire_dir=_default_wire_dir(),
            control_plane_url=DEFAULT_CONTROL_PLANE_URL,
            workspace_id="",
            dashboard_url="",
        )

    @classmethod
    def load(cls, path: str | Path) -> EdgeConfig:
        """Read + parse ``edge.toml`` from ``path``.

        Reads via stdlib :mod:`tomllib`. Missing fields fall back to the
        :meth:`default` values, so a partially-written config (e.g. one
        the wizard wrote before minting a workspace key) still loads.

        Raises
        ------
        EdgeConfigMissing
            When ``path`` does not exist. Deliberately NOT a bare
            ``FileNotFoundError`` so the wizard's "first run" branch is
            unambiguous.
        """
        p = Path(path)
        if not p.is_file():
            raise EdgeConfigMissing(p)
        with p.open("rb") as fh:
            raw = tomllib.load(fh)
        defaults = cls.default()
        return cls(
            workspace_key=str(raw.get("workspace_key", defaults.workspace_key)),
            daemon_port=int(raw.get("daemon_port", defaults.daemon_port)),
            wire_dir=str(raw.get("wire_dir", defaults.wire_dir)),
            control_plane_url=str(
                raw.get("control_plane_url", defaults.control_plane_url)
            ),
            workspace_id=str(raw.get("workspace_id", defaults.workspace_id)),
            dashboard_url=str(raw.get("dashboard_url", defaults.dashboard_url)),
        )

    def save(self, path: str | Path) -> None:
        """Write this config to ``path`` as TOML, creating parent dirs.

        Writes via :mod:`tomli_w`. Round-trips with :meth:`load` — the
        paired test asserts ``load(save(cfg)) == cfg``. Parent
        directories are created so the wizard can write to a fresh
        ``~/.sentisec/`` on first run.
        """
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("wb") as fh:
            tomli_w.dump(asdict(self), fh)
