"""In-daemon event model + upload queue (thin client).

The thin edge daemon does NOT import the cloud
:class:`~sentisec.proxy.event_bus.EventBus` (that lives server-side), and
— unlike the platform package's edge module — it does NOT import the
platform ``types.py`` (``ToolCall`` / ``MonitoringVerdict``) either. The
thin client ships NO engine types. Instead it builds standard Sentisec
event **dicts** directly from the RAW Claude Code hook payload + the flat
gate-response strings, buffers them on an :class:`asyncio.Queue`, and
lets the upload client drain the queue to the cloud's
``POST /v1/edge/events`` route — which republishes them onto the real
EventBus server-side, so the worker persistor + forensic assembler
render edge sessions identically to proxy sessions.

Event dict shape
================
Every event is a flat dict with an ``event_type`` discriminator plus the
keyword arguments of the matching EventBus ``publish_*`` method (the
exact keys ``POST /v1/edge/events`` consumes — see
``platform/sentisec/proxy/edge_ingest.py``):

- ``session_started`` -> ``session_id`` / ``task`` / ``agent_kind`` /
  ``integration`` / ``model`` / ``policy`` **plus** ``source`` — the
  ``edge_claude_subscription`` badge the dashboard renders. The daemon
  emits exactly one ``session_started`` per ``session_id``.
- ``tool_call`` -> ``session_id`` / ``step_idx`` / ``tool_name`` /
  ``args_preview``.
- ``verdict`` -> ``session_id`` / ``verdict`` / ``intervention`` /
  ``contributing_signals`` / ``forensic_id`` / ``step_idx``.
- ``user_prompt`` -> the prompt text captured from ``UserPromptSubmit``.
- ``assistant_turn`` -> the assistant turn text captured from ``Stop``.
- ``session_closed`` -> ``session_id`` / ``status``.

``workspace_id`` is NOT carried on the dict — the upload client
authenticates with the workspace key and the ingest route resolves the
workspace from that key, so an event dict cannot spoof another
workspace's id.

NO PROVIDER TOKENS. The event dicts carry only tool names, risk levels,
verdicts, prompt/assistant text, and rule ids — never an
``Authorization`` header, an ``sk-ant-`` key, or ChatGPT token material.
The upload guard test asserts this.
"""

from __future__ import annotations

import asyncio
from typing import Any

__all__ = [
    "EDGE_CLAUDE_SOURCE",
    "MODEL_REQUEST_PREVIEW_MAX",
    "EventBuffer",
    "args_preview_from_tool_input",
    "build_assistant_turn_event",
    "build_model_request_event",
    "build_session_closed_event",
    "build_session_started_event",
    "build_tool_call_event",
    "build_user_prompt_event",
    "build_verdict_event",
]

#: The session ``source`` badge the dashboard renders for Claude-Code
#: subscription-mode edge sessions. Carried on the ``session_started``
#: event dict; the ingest route forwards it to
#: :meth:`EventBus.publish_session_started`.
EDGE_CLAUDE_SOURCE = "edge_claude_subscription"

#: How many characters of the user prompt / assistant response land in
#: the bounded previews carried on a ``model_request`` event. Full raw
#: bodies stay LOCAL under ``~/.sentisec/wire/`` (design §9 token / data
#: custody) — only these bounded previews ride to the cloud, so a large
#: turn never bloats the wire and the operator still gets a one-screen
#: cue. The cloud worker projects these into ``prompt_messages_json`` /
#: ``response_content_json``.
MODEL_REQUEST_PREVIEW_MAX = 2000

#: How many characters of a tool-call arg string land in
#: ``args_preview`` — mirrors the proxy's preview-truncation posture so a
#: large command/file does not bloat the event payload.
_ARGS_PREVIEW_MAX = 512


def args_preview_from_tool_input(tool_input: Any) -> str:
    """Build a human-readable args preview from a raw ``tool_input`` dict.

    The Claude Code hook payload carries the tool arguments as
    ``tool_input`` (e.g. ``{"file_path": "src/app.py"}`` for ``Read``,
    ``{"command": "ls"}`` for ``Bash``). We concatenate the
    ``name=value`` pairs (sorted, truncated) so the dashboard's timeline
    row has a one-line preview. A non-dict ``tool_input`` contributes its
    ``str()`` form; ``None`` / empty -> empty string.
    """
    if not tool_input:
        return ""
    if not isinstance(tool_input, dict):
        text = str(tool_input)
        return _truncate(text)
    parts: list[str] = []
    for name in sorted(tool_input):
        parts.append(f"{name}={tool_input[name]}")
    return _truncate(" ".join(parts))


def _truncate(preview: str) -> str:
    """Truncate a preview to :data:`_ARGS_PREVIEW_MAX` with an ellipsis."""
    if len(preview) > _ARGS_PREVIEW_MAX:
        return preview[: _ARGS_PREVIEW_MAX - 1] + "…"
    return preview


def build_session_started_event(
    *,
    session_id: str,
    task: str = "",
    model: str = "",
    policy: str = "",
    source: str = EDGE_CLAUDE_SOURCE,
) -> dict[str, Any]:
    """Build a ``session_started`` event dict.

    Carries the ``source`` badge so the dashboard tags the session as
    Claude-Code subscription mode. ``agent_kind`` / ``integration`` are
    fixed to the edge identity so the persistor renders a stable label.
    Keys mirror :meth:`EventBus.publish_session_started`.
    """
    return {
        "event_type": "session_started",
        "session_id": session_id,
        "task": task,
        "agent_kind": "claude-code",
        "integration": "edge-subscription",
        "model": model,
        "policy": policy,
        "source": source,
    }


def build_tool_call_event(
    *,
    session_id: str,
    step_idx: int,
    tool_name: str,
    tool_input: Any = None,
    args_preview: str | None = None,
) -> dict[str, Any]:
    """Build a ``tool_call`` event dict from RAW hook fields.

    The thin client never constructs a platform ``ToolCall`` — it builds
    the preview directly from the hook payload's ``tool_input``. The
    server-side analysis engines compute the per-tool risk level on the
    hosted plane; the thin client does not carry that number on the event
    (the dashboard timeline reads it from the server-side projection).
    Keys mirror :meth:`EventBus.publish_tool_call`: ``step_idx`` /
    ``tool_name`` / ``args_preview``.

    When ``args_preview`` is supplied (the Codex track passes the
    server-computed, already-token-scrubbed preview the analyze endpoint
    returned), it is used verbatim — the client never re-derives a
    preview the server already bounded + scrubbed. When ``None`` (the
    Claude track) the preview is built from ``tool_input`` via
    :func:`args_preview_from_tool_input`. Either way no provider token
    can enter the preview: the Claude path reads only the hook
    ``tool_input`` (never a header), and the Codex path's string was
    scrubbed server-side.
    """
    preview = (
        args_preview
        if args_preview is not None
        else args_preview_from_tool_input(tool_input)
    )
    return {
        "event_type": "tool_call",
        "session_id": session_id,
        "step_idx": step_idx,
        "tool_name": tool_name,
        "args_preview": preview,
    }


def build_verdict_event(
    *,
    session_id: str,
    verdict: str,
    intervention: str,
    contributing_signals: list[str] | None = None,
    forensic_id: str | None = None,
    step_idx: int | None = None,
) -> dict[str, Any]:
    """Build a ``verdict`` event dict from the flat gate-response strings.

    The hosted gate returns ``{"verdict": ..., "intervention": ...}`` (and
    the daemon may carry the fired-rule signals); the thin client forwards
    those strings as-is. Keys mirror :meth:`EventBus.publish_verdict`:
    ``verdict`` / ``intervention`` / ``contributing_signals`` /
    ``forensic_id`` / ``step_idx``.
    """
    return {
        "event_type": "verdict",
        "session_id": session_id,
        "verdict": verdict,
        "intervention": intervention,
        "contributing_signals": list(contributing_signals or []),
        "forensic_id": forensic_id or None,
        "step_idx": step_idx,
    }


def build_user_prompt_event(
    *, session_id: str, prompt: str
) -> dict[str, Any]:
    """Build a ``user_prompt`` event dict (captured from UserPromptSubmit)."""
    return {
        "event_type": "user_prompt",
        "session_id": session_id,
        "prompt": prompt,
    }


def build_assistant_turn_event(
    *, session_id: str, text: str
) -> dict[str, Any]:
    """Build an ``assistant_turn`` event dict (captured from Stop)."""
    return {
        "event_type": "assistant_turn",
        "session_id": session_id,
        "text": text,
    }


def _bounded(text: str | None, *, limit: int = MODEL_REQUEST_PREVIEW_MAX) -> str:
    """Return ``text`` truncated to ``limit`` chars with an ellipsis marker.

    Empty / ``None`` → empty string. The truncation marker is a single
    ellipsis so the cloud projection can detect "this is a preview, not
    the full body" without a second heuristic. Full raw bodies stay local
    (design §9).
    """
    if not text:
        return ""
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def build_model_request_event(
    *,
    session_id: str,
    turn_idx: int,
    model: str | None = None,
    provider: str = "anthropic",
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    total_tokens: int | None = None,
    latency_ms: int | None = None,
    stop_reason: str | None = None,
    status: str = "success",
    tool_uses_count: int = 0,
    prompt_preview: str | None = None,
    response_preview: str | None = None,
    source: str = EDGE_CLAUDE_SOURCE,
    source_event_id: str | None = None,
    system_prompt: str | None = None,
    messages: list[Any] | None = None,
    tools: list[Any] | None = None,
    tool_choice: Any | None = None,
    decoding_params: dict[str, Any] | None = None,
    response_content: list[Any] | None = None,
    raw_request: str | None = None,
    raw_response: str | None = None,
) -> dict[str, Any]:
    """Build a ``model_request`` event dict — one per completed Claude turn.

    Carries the per-turn USAGE telemetry the gateway Dashboard / Logs /
    Traces pages need (tokens, latency, model, stop_reason) plus BOUNDED
    previews of the prompt + response. The cloud worker persistor projects
    this into a ``llm_request_logs`` row with
    ``source="edge_claude_subscription"`` (the ingest route maps the
    ``event_type`` to :meth:`EventBus.publish_model_request`).

    Content-capture wave: when the daemon captured the full structured
    content (``capture_full`` posture — see :mod:`sentisec_sdk.edge.capture`)
    the structured fields ride too — ``system_prompt``, the BARE
    ``messages`` array, ``tools`` / ``tool_choice`` / ``decoding_params``,
    the ``response_content`` blocks, and the token-scrubbed
    ``raw_request`` / ``raw_response`` drawers — so the dashboard renders
    subscription rows identically to BYOK rows. Absent on a preview-only
    event (all ``None``), in which case the cloud persistor falls back to
    the synthetic-from-preview projection. The cloud
    ``sentisec.proxy.edge_ingest`` route already consumes every one of
    these keys.

    Token-custody invariant (design §9): this event NEVER carries a
    provider OAuth token, an ``Authorization`` header, or an UN-scrubbed
    raw body. ``prompt_preview`` / ``response_preview`` are bounded to
    :data:`MODEL_REQUEST_PREVIEW_MAX` chars; the structured content +
    ``raw_request`` / ``raw_response`` are token-scrubbed at extraction
    (:func:`sentisec_sdk.edge.content.scrub_content`) AND re-scrubbed at
    the upload choke point.

    ``turn_idx`` is the monotonic per-session turn ordinal (0-based). The
    persistor uses ``(session_id, turn_idx)`` as the idempotency key so a
    redelivered batch never double-projects a turn. ``source_event_id``
    (the receiver's stable per-turn seed) is the belt-and-braces second
    idempotency key so a redelivered batch never double-projects.
    """
    event: dict[str, Any] = {
        "event_type": "model_request",
        "session_id": session_id,
        "turn_idx": turn_idx,
        "model": model,
        "provider": provider,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": total_tokens,
        "latency_ms": latency_ms,
        "stop_reason": stop_reason,
        "status": status,
        "tool_uses_count": tool_uses_count,
        "prompt_preview": _bounded(prompt_preview),
        "response_preview": _bounded(response_preview),
        # ``source`` tags the projected ``llm_request_logs`` row as a
        # Claude-Code subscription turn (the persistor sets the column).
        "source": source,
    }
    # Stable per-turn idempotency seed (the receiver's
    # ``Turn.source_event_id``) so a redelivered batch never double-projects.
    if source_event_id is not None:
        event["source_event_id"] = source_event_id
    # Structured content rides ONLY when present (full-capture posture).
    # A preview-only event omits these keys entirely so the persistor's
    # fallback-from-preview path stays byte-identical to the pre-wave shape.
    if system_prompt is not None:
        event["system_prompt"] = system_prompt
    if messages is not None:
        event["messages"] = messages
    if tools is not None:
        event["tools"] = tools
    if tool_choice is not None:
        event["tool_choice"] = tool_choice
    if decoding_params is not None:
        event["decoding_params"] = decoding_params
    if response_content is not None:
        event["response_content"] = response_content
    if raw_request is not None:
        event["raw_request"] = raw_request
    if raw_response is not None:
        event["raw_response"] = raw_response
    return event


def build_session_closed_event(
    *, session_id: str, status: str = "COMPLETED"
) -> dict[str, Any]:
    """Build a ``session_closed`` event dict (captured from SessionEnd)."""
    return {
        "event_type": "session_closed",
        "session_id": session_id,
        "status": status,
    }


class EventBuffer:
    """An :class:`asyncio.Queue`-backed buffer for outbound edge events.

    The capture handlers (:mod:`sentisec_sdk.edge.claude_hooks`) push
    event dicts here; the upload client drains them to the cloud. The
    buffer is sync-pushable (``put_nowait``) so the hook handlers — which
    run inside the Starlette request and must respond fast — never block
    on the queue. Draining is async.

    A ``maxsize`` of 0 (default) makes the queue unbounded; a bounded
    queue can be passed to apply backpressure under a flood, in which
    case :meth:`push` drops the event rather than blocking the gate
    (fail-open: capture is best-effort; the gate must not stall on a full
    queue).
    """

    def __init__(self, *, maxsize: int = 0) -> None:
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(
            maxsize=maxsize
        )

    @property
    def queue(self) -> asyncio.Queue[dict[str, Any]]:
        """The underlying queue (exposed for the upload-client drain)."""
        return self._queue

    def push(self, event: dict[str, Any]) -> bool:
        """Enqueue an event without blocking. Returns False if dropped.

        Uses :meth:`asyncio.Queue.put_nowait` so a hook handler never
        awaits. On a bounded full queue the event is dropped (capture is
        best-effort — the synchronous gate decision has already been
        returned to Claude Code; a dropped capture event only degrades
        the forensic record, never the gate).
        """
        try:
            self._queue.put_nowait(event)
            return True
        except asyncio.QueueFull:
            return False

    def qsize(self) -> int:
        """Current number of buffered events (for health / tests)."""
        return self._queue.qsize()

    async def drain(self) -> list[dict[str, Any]]:
        """Drain every currently-buffered event (non-blocking).

        Returns all events available *now*; does not wait for more. The
        upload client calls this on its flush cadence.
        """
        return self.drain_sync()

    def drain_sync(self) -> list[dict[str, Any]]:
        """Synchronous drain of every currently-buffered event.

        :meth:`asyncio.Queue.get_nowait` does not touch the event loop,
        so draining is safe from a synchronous context. The upload client
        (:class:`~sentisec_sdk.edge.event_upload.EventUploader`) is
        synchronous (httpx ``Client`` + ``time.sleep`` backoff) and calls
        this directly; the async :meth:`drain` delegates here so both
        surfaces share one drain implementation.
        """
        out: list[dict[str, Any]] = []
        while True:
            try:
                out.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        return out
