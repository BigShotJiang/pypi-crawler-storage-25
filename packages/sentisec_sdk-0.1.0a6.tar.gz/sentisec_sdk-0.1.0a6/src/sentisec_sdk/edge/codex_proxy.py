"""Local Codex passthrough proxy — thin client (token-custody-safe).

Codex in ChatGPT-subscription mode is pointed (via the user-level
``~/.codex/config.toml`` provider the installer writes — see
:func:`sentisec_sdk.edge.installer.write_codex_provider`) at a LOCAL URL:
``base_url = "http://127.0.0.1:<codex_port>/v1"``. Codex therefore POSTs
to ``/v1/responses`` with:

- ``Authorization: Bearer <ChatGPT access token>`` — the user's
  subscription bearer;
- ``X-Sentisec-Workspace-Key: sk_sentisec_…`` — Sentisec's identity
  (the workspace key from ``~/.sentisec/edge.toml``);
- the Codex CLI headers (``ChatGPT-Account-ID``, ``originator``,
  ``User-Agent``, ``session-id``, ``thread-id``, ``OpenAI-Beta`` /
  ``X-OAI-Attestation`` if present).

What this module does (the four steps, design §2 / §4.4 / §9)
=============================================================

1. **Receive** the Codex ``/v1/responses`` request (ChatGPT bearer +
   ``X-Sentisec-Workspace-Key`` + Codex headers).
2. **Forward to ``https://chatgpt.com/backend-api/codex/responses``
   LOCALLY** with the ChatGPT bearer + the allowlisted Codex headers
   **unchanged** — the token NEVER leaves the box / never goes to
   Sentisec cloud. (Bare ``/backend-api/codex/responses`` target — no
   ``/v1`` — even though Codex's ``base_url`` ends in ``/v1``.)
3. **Send a token-REDACTED copy** of ``{request, response}`` to the
   hosted analyze endpoint (``POST {control_plane_url}/v1/edge/codex/
   analyze``) for the verdict, authenticated with the ``sk_sentisec_*``
   workspace key (NEVER the ChatGPT token).
4. **Enforce** the verdict (``deny`` / HALT -> blocked or
   ``sanitized_response`` body returned to Codex; else relay the
   chatgpt response verbatim) **and** upload events
   (``source=edge_codex_subscription``).

THE TOKEN-CUSTODY INVARIANT (load-bearing)
==========================================

The ChatGPT bearer appears ONLY in the chatgpt.com forward (step 2). It
must NEVER appear in the analyze request (step 3), the event upload
(step 4), or anything else sent to ``*.sentisec.ch``. The analyze body
is built from a token-REDACTED copy of the inbound request (the
``Authorization`` header is dropped; any nested token material is
scrubbed via :func:`sentisec_sdk.edge.event_upload.scrub_event`). A
dedicated test asserts this.

Streaming posture (chosen + documented, not a TODO)
===================================================

Codex requests the ``responses`` wire API and may set ``stream: true``
for SSE. This proxy uses the **buffer-then-analyze-then-return** posture
for BOTH the streaming and non-streaming case:

- The chatgpt.com response (SSE or JSON) is read in full on the box.
- The analyze verdict runs on the complete request+response BEFORE
  anything is handed back to Codex.
- On ``allow`` the buffered chatgpt response is replayed to Codex
  byte-for-byte (same status, same ``Content-Type``, including the SSE
  ``text/event-stream`` body so Codex's SSE parser still works).
- On ``deny`` / HALT the dangerous response is replaced with a blocked
  body (or the analyze ``sanitized_response``) so the dangerous action
  never reaches Codex.

This is deliberate: buffering is what makes a REAL-TIME block possible
(the dangerous tool call in the response is never delivered). The cost
is that Codex sees the response only once chatgpt.com has finished — an
acceptable demo trade for a hard block, and the same posture the
server's ``sse_gating`` takes in spirit. There is no pass-through-then-
post-hoc fallback in this thin build: the box is co-located with Codex,
so the buffer latency is the network round-trip we already pay.

Engine-free — NO ``sentisec.*`` (platform) import. Only ``httpx`` +
``starlette`` + stdlib + the sibling thin-client modules.
"""

from __future__ import annotations

import logging
from typing import Any, Protocol

import httpx
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from .capture import capture_full_enabled
from .config import EdgeConfig
from .event_upload import contains_provider_token_material, scrub_event
from .events import (
    EventBuffer,
    args_preview_from_tool_input,
    build_session_started_event,
    build_tool_call_event,
    build_verdict_event,
)

__all__ = [
    "CHATGPT_CODEX_RESPONSES_URL",
    "CODEX_ANALYZE_PATH",
    "CODEX_PROXY_PORT_OFFSET",
    "CODEX_SUBSCRIPTION_SOURCE",
    "FORWARDED_CODEX_HEADERS",
    "AnalyzeVerdict",
    "build_analyze_request",
    "build_codex_proxy_app",
    "codex_proxy_port",
    "forward_to_chatgpt",
    "run",
]

_logger = logging.getLogger("sentisec_sdk.edge.codex_proxy")

#: The codex proxy binds at ``daemon_port + CODEX_PROXY_PORT_OFFSET`` so
#: it never collides with the Claude hook/OTLP daemon port. Codex's
#: ``config.toml`` ``base_url`` points at this port (e.g. 45712 when the
#: daemon is on 45711).
CODEX_PROXY_PORT_OFFSET = 1

#: The ChatGPT codex backend the bearer is forwarded to box-to-backend.
#: Note the BARE ``/backend-api/codex/responses`` — no ``/v1`` — even
#: though Codex's provider ``base_url`` ends in ``/v1`` (design §2).
CHATGPT_CODEX_RESPONSES_URL = "https://chatgpt.com/backend-api/codex/responses"

#: The hosted analyze route. Joined onto ``control_plane_url``. The
#: ``sk_sentisec_*`` workspace key authenticates it as ``Authorization:
#: Bearer`` — NEVER the ChatGPT token.
CODEX_ANALYZE_PATH = "/v1/edge/codex/analyze"

#: The session ``source`` badge the dashboard renders for Codex
#: ChatGPT-subscription edge sessions.
CODEX_SUBSCRIPTION_SOURCE = "edge_codex_subscription"

#: The Codex CLI request headers forwarded UNCHANGED to chatgpt.com
#: (design §2). ``Authorization`` rides separately (it is the bearer and
#: the most sensitive — see :func:`forward_to_chatgpt`). Lower-cased for
#: case-insensitive matching against httpx's header map; the outbound
#: value preserves whatever Codex sent.
FORWARDED_CODEX_HEADERS: tuple[str, ...] = (
    "authorization",
    "chatgpt-account-id",
    "originator",
    "user-agent",
    "session-id",
    "thread-id",
    "openai-beta",
    "x-oai-attestation",
    "content-type",
)

#: Header Codex sends Sentisec's identity in (matches the provider config
#: ``http_headers`` block + ``event_upload._WORKSPACE_KEY_HEADER``). This
#: is the ONLY credential that authenticates the analyze call — never the
#: ChatGPT bearer.
_WORKSPACE_KEY_HEADER = "X-Sentisec-Workspace-Key"

#: Per-call timeout for the chatgpt.com forward. Generous: a real Codex
#: turn (tool planning + generation) can take a while; a buffered SSE
#: stream is read to completion within this budget.
_FORWARD_TIMEOUT_S = 120.0

#: Per-call timeout for the hosted analyze call. Tight: a slow analyze
#: must fail OPEN fast rather than stalling Codex's turn.
_ANALYZE_TIMEOUT_S = 8.0

#: The three permission-decision literals (mirrors the Claude gate).
_ALLOW = "allow"
_ASK = "ask"
_DENY = "deny"


class _HeaderGetter(Protocol):
    """Case-insensitive header lookup shared by httpx + starlette Headers.

    Both :class:`httpx.Headers` and :class:`starlette.datastructures.Headers`
    expose a case-insensitive ``get(name) -> str | None``; the header
    helpers here type against this minimal protocol so they accept either
    (the inbound request carries Starlette headers; the chatgpt forward
    reuses them).
    """

    def get(self, key: str, /) -> str | None: ...


def codex_proxy_port(daemon_port: int) -> int:
    """Return the local port the codex proxy binds on (daemon_port + 1)."""
    return daemon_port + CODEX_PROXY_PORT_OFFSET


class AnalyzeVerdict:
    """The parsed verdict the hosted analyze endpoint returned (or fail-open).

    Carries the analyze response fields plus ``failed_open`` (True when
    synthesised locally because analyze was unreachable / errored — the
    proxy then RELAYS the chatgpt response unmodified so a turn is never
    hung or blocked by an analyze fault). ``sanitized_response`` is an
    optional replacement body to hand Codex instead of the chatgpt
    response (an analyze-driven scrub). ``tool_calls`` is the per-call
    detail array the analyze endpoint returns (one entry per extracted +
    gated proposed tool call) so the proxy can emit a ``tool_call`` event
    per entry — dashboard parity with the Claude track. It is empty on a
    text-only turn or a fail-open allow (nothing was gated).
    """

    __slots__ = (
        "verdict",
        "intervention",
        "permission_decision",
        "permission_decision_reason",
        "sanitized_response",
        "tool_calls",
        "failed_open",
    )

    def __init__(
        self,
        *,
        verdict: str = "NOMINAL",
        intervention: str = "PROCEED",
        permission_decision: str = _ALLOW,
        permission_decision_reason: str = "Sentisec: clean",
        sanitized_response: Any | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
        failed_open: bool = False,
    ) -> None:
        self.verdict = verdict
        self.intervention = intervention
        self.permission_decision = permission_decision
        self.permission_decision_reason = permission_decision_reason
        self.sanitized_response = sanitized_response
        self.tool_calls = tool_calls if tool_calls is not None else []
        self.failed_open = failed_open

    @property
    def blocks(self) -> bool:
        """True when the verdict denies the response (a hard block)."""
        return self.permission_decision == _DENY


def _fail_open(reason: str) -> AnalyzeVerdict:
    """Build a fail-open ``allow`` verdict (analyze unreachable / errored)."""
    return AnalyzeVerdict(
        permission_decision=_ALLOW,
        permission_decision_reason=reason,
        failed_open=True,
    )


# ---------------------------------------------------------------------------
# Step 2 — forward to chatgpt.com (the ONLY place the bearer appears)
# ---------------------------------------------------------------------------


def _outbound_chatgpt_headers(inbound: _HeaderGetter) -> dict[str, str]:
    """Select the allowlisted Codex headers to forward to chatgpt.com.

    Copies ONLY the headers in :data:`FORWARDED_CODEX_HEADERS` (incl.
    ``Authorization`` — the ChatGPT bearer) verbatim from the inbound
    request. The ``X-Sentisec-Workspace-Key`` is DELIBERATELY NOT
    forwarded (it is Sentisec's identity, not for chatgpt.com), and any
    hop-by-hop / host header is dropped by omission (allowlist, not
    denylist).
    """
    out: dict[str, str] = {}
    for name in FORWARDED_CODEX_HEADERS:
        value = inbound.get(name)
        if value is not None:
            # Preserve the canonical header name casing chatgpt.com
            # expects for the well-known ones; httpx normalises on send.
            out[name] = value
    return out


def forward_to_chatgpt(
    request_body: bytes,
    inbound_headers: _HeaderGetter,
    *,
    client: httpx.Client,
    url: str = CHATGPT_CODEX_RESPONSES_URL,
) -> httpx.Response:
    """POST the Codex request to chatgpt.com with bearer + headers unchanged.

    This is the ONLY function that sends the ChatGPT bearer anywhere. The
    raw ``request_body`` bytes are forwarded as-is (Codex already
    serialised the ``/v1/responses`` JSON); the allowlisted Codex headers
    — including ``Authorization`` — ride along unchanged. The response is
    read in FULL (``client.post`` buffers the body, SSE included) so the
    analyze step can run on the complete response before Codex sees it.

    The injected :class:`httpx.Client` is backed by a real transport in
    production and an :class:`httpx.MockTransport` in tests (so no live
    network). Raises :class:`httpx.HTTPError` on a transport failure —
    the caller maps that to a fail-open relay-error response.
    """
    headers = _outbound_chatgpt_headers(inbound_headers)
    return client.post(url, content=request_body, headers=headers)


# ---------------------------------------------------------------------------
# Step 3 — build the token-REDACTED analyze request (the invariant)
# ---------------------------------------------------------------------------


#: The Codex ``/v1/responses`` request key carrying the model's tool
#: catalog (the full tool *definitions* — name + JSON schema). The cloud
#: analyze endpoint reads this EXACT key
#: (:func:`sentisec.proxy.edge_codex_analyze._codex_tools` →
#: ``request.get("tools")``) and forwards it into ``tools_json`` verbatim
#: when present, only synthesising a degraded fallback from the proposed
#: calls when it is absent. The thin client MUST forward this key (gated
#: by capture posture) so the cloud gets the REAL schemas instead of the
#: degraded fallback.
_REQUEST_TOOLS_KEY = "tools"


def build_analyze_request(
    *,
    session_id: str,
    request_json: Any,
    response_json: Any,
    model: str,
    capture_full: bool = True,
) -> dict[str, Any]:
    """Build the analyze body with ALL token material redacted.

    The body shape matches the analyze contract::

        {"session_id", "request", "response", "model"}

    ``request`` is a token-REDACTED copy of the Codex ``/v1/responses``
    request JSON — :func:`scrub_event` drops any ``Authorization`` key
    and redacts any nested ``Bearer``/JWT/``sk-ant-`` material, so the
    ChatGPT bearer can NEVER ride to the hosted plane even if a future
    request shape nested it in the body. ``response`` is the chatgpt
    response (also scrubbed defensively — it should hold no token, but
    the scrub is the single choke point).

    A non-dict request/response (e.g. a raw SSE string we could not
    parse) is wrapped under a ``raw`` key so :func:`scrub_event` can
    still walk + redact it.

    Tool-catalog forwarding (the durable tools_json fix)
    ====================================================

    The Codex request carries the model's tool catalog under
    :data:`_REQUEST_TOOLS_KEY` (``tools`` — name + JSON schema per tool).
    The cloud analyze endpoint reads that EXACT key and forwards it into
    ``tools_json`` verbatim when present, only synthesising a degraded
    fallback from the proposed calls when absent. So the catalog rides
    automatically inside the scrubbed request copy — but ONLY when the
    capture posture permits it:

    - ``capture_full=True`` — the tool catalog rides (scrubbed via the
      SAME :func:`scrub_event` path as every other content field; tool
      *definitions* are not secrets, but the redaction path is applied
      for consistency + defence-in-depth). The cloud gets real schemas.
    - ``capture_full=False`` — the tool catalog is STRIPPED from the
      forwarded request copy (matching how the Claude track suppresses
      full structured content under preview posture). The cloud then
      falls back to its degraded synthesis. The gate verdict is
      unaffected either way (the proposed calls in ``response`` are what
      the cloud gates; ``tools`` only enriches the projected catalog).

    The token-custody invariant is independent of this gate: tokens never
    ride in EITHER mode (the scrub is the single choke point).
    """
    scrubbed_request = scrub_event(_as_scrubbable(request_json))
    if not capture_full and isinstance(scrubbed_request, dict):
        # Preview posture: drop the full tool catalog so only the bounded
        # signal rides. The cloud's degraded synthesis then names the
        # proposed tools without their full schemas.
        scrubbed_request.pop(_REQUEST_TOOLS_KEY, None)
    scrubbed_response = scrub_event(_as_scrubbable(response_json))
    return {
        "session_id": session_id,
        "request": scrubbed_request,
        "response": scrubbed_response,
        "model": model,
    }


def _as_scrubbable(value: Any) -> dict[str, Any]:
    """Wrap a non-dict value so :func:`scrub_event` can walk it.

    ``scrub_event`` recurses dicts/lists/strings. A top-level dict is
    returned as-is; anything else (a raw SSE string, a list, ``None``) is
    nested under ``raw`` so the recursive scrub still reaches every
    string for token redaction.
    """
    if isinstance(value, dict):
        return value
    return {"raw": value}


def call_analyze(
    body: dict[str, Any],
    *,
    control_plane_url: str,
    workspace_key: str,
    client: httpx.Client,
    timeout_s: float = _ANALYZE_TIMEOUT_S,
) -> AnalyzeVerdict:
    """POST the redacted analyze body to the hosted endpoint. Never raises.

    Authenticates with the ``sk_sentisec_*`` workspace key as
    ``Authorization: Bearer`` (NEVER the ChatGPT token). Any failure —
    transport error, timeout, non-2xx, malformed body — returns a
    fail-open ``allow`` :class:`AnalyzeVerdict` (``failed_open=True``) so
    a Codex turn is never hung or blocked by an analyze fault (design
    §10 fail-open posture).

    The ``body`` is assumed already token-redacted by
    :func:`build_analyze_request`; this function additionally re-checks
    the serialised body for token material as a belt-and-suspenders guard
    and refuses to send (fail-open) if any leaked through — the ChatGPT
    token must never reach the hosted plane.
    """
    if contains_provider_token_material(body):  # pragma: no cover — guard
        _logger.error(
            "event=codex_analyze_token_material_blocked — refusing to send "
            "an analyze body that still carries provider-token material; "
            "failing OPEN (relay chatgpt response unmodified)"
        )
        return _fail_open(
            "Sentisec: analyze body carried token material — failing open"
        )

    url = control_plane_url.rstrip("/") + CODEX_ANALYZE_PATH
    headers = {"Authorization": f"Bearer {workspace_key}"}
    try:
        resp = client.post(url, json=body, headers=headers, timeout=timeout_s)
    except httpx.HTTPError as exc:
        _logger.warning(
            "event=codex_analyze_unreachable url=%s err=%r — failing OPEN",
            url,
            exc,
        )
        return _fail_open("Sentisec: analyze unreachable — relaying (allow)")
    if not (200 <= resp.status_code < 300):
        _logger.warning(
            "event=codex_analyze_non_2xx status=%d — failing OPEN",
            resp.status_code,
        )
        return _fail_open(
            f"Sentisec: analyze returned HTTP {resp.status_code} — relaying"
        )
    try:
        parsed = resp.json()
    except ValueError:
        _logger.warning("event=codex_analyze_bad_json — failing OPEN")
        return _fail_open("Sentisec: analyze returned non-JSON — relaying")
    return _parse_analyze_body(parsed)


def _parse_analyze_body(body: Any) -> AnalyzeVerdict:
    """Parse an analyze 200 body into an :class:`AnalyzeVerdict` (fail-open junk).

    A body missing the decision field, or carrying a decision outside the
    three literals, is treated as a fault -> fail-open allow, so an
    analyze contract divergence never accidentally hard-blocks a Codex turn.
    """
    if not isinstance(body, dict):
        return _fail_open("Sentisec: analyze returned an unexpected body — relaying")
    decision = body.get("permissionDecision")
    if decision not in (_ALLOW, _ASK, _DENY):
        return _fail_open("Sentisec: analyze returned no decision — relaying")
    reason = body.get("permissionDecisionReason")
    return AnalyzeVerdict(
        verdict=str(body.get("verdict", "NOMINAL") or "NOMINAL"),
        intervention=str(body.get("intervention", "PROCEED") or "PROCEED"),
        permission_decision=str(decision),
        permission_decision_reason=(
            str(reason) if isinstance(reason, str) and reason else "Sentisec: gated"
        ),
        sanitized_response=body.get("sanitized_response"),
        tool_calls=_parse_tool_calls(body.get("tool_calls")),
        failed_open=False,
    )


def _parse_tool_calls(raw: Any) -> list[dict[str, Any]]:
    """Coerce the analyze ``tool_calls`` field into a list of dict entries.

    Defensive: a missing / non-list value yields an empty list (an older
    analyze deployment that predates the per-call array, or a malformed
    body, simply emits no ``tool_call`` events — the session still shows
    ``session_started`` + ``verdict``). Non-dict list items are dropped
    so a contract divergence can never push a malformed event.
    """
    if not isinstance(raw, list):
        return []
    return [item for item in raw if isinstance(item, dict)]


# ---------------------------------------------------------------------------
# Step 4 — enforcement (the response handed back to Codex)
# ---------------------------------------------------------------------------

#: HTTP status the blocked response carries. 403 (not 5xx) so Codex
#: surfaces it as a refusal rather than a transient server error it would
#: retry — the dangerous action is rejected, not deferred.
_BLOCKED_STATUS = 403


def _blocked_response(verdict: AnalyzeVerdict) -> Response:
    """Build the response handed to Codex on a ``deny`` verdict.

    Prefers the analyze ``sanitized_response`` (a scrubbed replacement
    body) when present; otherwise a JSON error body Codex renders as a
    refusal. Either way the dangerous chatgpt response is NOT delivered.
    """
    if verdict.sanitized_response is not None:
        return JSONResponse(verdict.sanitized_response, status_code=200)
    return JSONResponse(
        {
            "error": {
                "type": "sentisec_blocked",
                "message": verdict.permission_decision_reason,
            }
        },
        status_code=_BLOCKED_STATUS,
    )


def _relay_response(upstream: httpx.Response) -> Response:
    """Replay the buffered chatgpt response to Codex byte-for-byte.

    Preserves the upstream status code + ``Content-Type`` (so an SSE
    ``text/event-stream`` body is handed back as a stream Codex's parser
    accepts). Hop-by-hop headers are dropped by reconstructing only the
    content type — the body is the authoritative payload.
    """
    media_type = upstream.headers.get("content-type")
    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        media_type=media_type,
    )


# ---------------------------------------------------------------------------
# Response parsing helpers (best-effort — never raise into the hot path)
# ---------------------------------------------------------------------------


def _parse_response_for_analyze(upstream: httpx.Response) -> Any:
    """Best-effort decode of the chatgpt response for the analyze body.

    A JSON ``Content-Type`` is parsed to a dict/list; an SSE / non-JSON
    body is decoded to text (the accumulated stream). The analyze
    endpoint accepts either shape; the scrub walks both. A decode failure
    yields the empty string (analyze still runs on the request side).
    """
    content_type = upstream.headers.get("content-type", "")
    if "application/json" in content_type:
        try:
            return upstream.json()
        except ValueError:
            pass
    try:
        return upstream.text
    except Exception:  # pragma: no cover — defensive
        return ""


def _model_of(request_json: Any) -> str:
    """Extract the ``model`` from the request JSON (best-effort)."""
    if isinstance(request_json, dict):
        model = request_json.get("model")
        if isinstance(model, str):
            return model
    return ""


# ---------------------------------------------------------------------------
# The ASGI app — POST /v1/responses + GET /healthz
# ---------------------------------------------------------------------------


def build_codex_proxy_app(
    config: EdgeConfig,
    *,
    events: EventBuffer | None = None,
    chatgpt_client: httpx.Client | None = None,
    analyze_client: httpx.Client | None = None,
    capture_full: bool | None = None,
) -> Starlette:
    """Build the local Codex passthrough Starlette app.

    Routes:

    - ``POST /v1/responses`` — the Codex passthrough (steps 1-4).
    - ``GET /healthz`` — liveness for the wizard self-test / status panel.

    Parameters
    ----------
    config:
        The loaded :class:`EdgeConfig` (workspace key + control-plane url).
    events:
        Optional :class:`EventBuffer`. When provided, a
        ``session_started`` (once per ``session_id``) + a ``verdict``
        capture event are enqueued per turn — drained by the daemon's
        uploader to ``POST /v1/edge/events`` with
        ``source=edge_codex_subscription``. When ``None`` capture is a
        no-op (the pure-passthrough unit-test shape).
    chatgpt_client:
        Injected :class:`httpx.Client` for the chatgpt.com forward (tests
        pass an :class:`httpx.MockTransport`-backed client). Created +
        owned internally when ``None``.
    analyze_client:
        Injected :class:`httpx.Client` for the hosted analyze call (tests
        pass a mock-backed client). Created + owned internally when
        ``None``.
    capture_full:
        Content-capture posture for the analyze body's forwarded request
        copy. ``True`` rides the full tool catalog (token-scrubbed) to
        the cloud so it projects the REAL tool schemas; ``False`` strips
        the catalog so only the bounded signal rides (the cloud falls
        back to its degraded synthesis). ``None`` (the default) resolves
        the posture from the config's ``control_plane_url`` +
        ``SENTISEC_EDGE_CAPTURE_CONTENT`` via
        :func:`~sentisec_sdk.edge.capture.capture_full_enabled` — the
        SAME gate the Claude track uses. The gate verdict is unaffected
        by this posture; it only governs content richness.

    Token custody: the chatgpt forward is the ONLY place the inbound
    ``Authorization`` bearer is sent; the analyze call + the event upload
    carry only the ``sk_sentisec_*`` key + token-redacted bodies. Tokens
    never ride in EITHER capture posture.
    """
    resolved_capture_full = (
        capture_full
        if capture_full is not None
        else capture_full_enabled(config.control_plane_url)
    )
    owns_chatgpt = chatgpt_client is None
    owns_analyze = analyze_client is None
    cg_client = (
        chatgpt_client
        if chatgpt_client is not None
        else httpx.Client(timeout=_FORWARD_TIMEOUT_S)
    )
    az_client = (
        analyze_client
        if analyze_client is not None
        else httpx.Client(timeout=_ANALYZE_TIMEOUT_S)
    )
    opened: set[str] = set()

    def _open_session(session_id: str) -> None:
        """Emit a one-per-session ``session_started`` (Codex source badge)."""
        if events is None or session_id in opened:
            return
        opened.add(session_id)
        events.push(
            build_session_started_event(
                session_id=session_id,
                source=CODEX_SUBSCRIPTION_SOURCE,
            )
        )

    def _capture_verdict(
        session_id: str, verdict: AnalyzeVerdict, request_json: Any
    ) -> None:
        """Enqueue the per-turn ``verdict`` capture event (no token material).

        The event carries only the verdict/intervention strings + a
        token-redacted args preview built from the request — never the
        bearer or response bodies (those stay on the box).
        """
        if events is None:
            return
        _ = args_preview_from_tool_input(
            request_json.get("input") if isinstance(request_json, dict) else None
        )
        events.push(
            build_verdict_event(
                session_id=session_id,
                verdict=verdict.verdict,
                intervention=verdict.intervention,
            )
        )

    def _capture_tool_calls(session_id: str, verdict: AnalyzeVerdict) -> None:
        """Enqueue one ``tool_call`` event per analyze ``tool_calls`` entry.

        Dashboard parity (Codex track): the hosted analyze endpoint
        extracts + gates each proposed tool call and returns a per-call
        ``tool_calls`` array; the proxy forwards each as a ``tool_call``
        event so Codex sessions render per-tool timeline rows IDENTICALLY
        to Claude sessions. The preview the analyze endpoint computed was
        bounded + token-scrubbed SERVER-SIDE, so it is forwarded verbatim
        (never re-derived from the on-box request, which still holds the
        bearer). No provider token can enter these events — the analyze
        body never carried one, and the preview was scrubbed.
        """
        if events is None or not verdict.tool_calls:
            return
        for entry in verdict.tool_calls:
            events.push(
                build_tool_call_event(
                    session_id=session_id,
                    step_idx=int(entry.get("step_idx", 0) or 0),
                    tool_name=str(entry.get("tool_name", "") or ""),
                    args_preview=str(entry.get("args_preview", "") or ""),
                )
            )

    async def responses_endpoint(request: Request) -> Response:
        request_body = await request.body()
        inbound_headers = request.headers
        workspace_key = inbound_headers.get(_WORKSPACE_KEY_HEADER, "") or (
            config.workspace_key
        )

        # Step 2 — forward to chatgpt.com (the ONLY bearer egress).
        try:
            upstream = forward_to_chatgpt(
                request_body, inbound_headers, client=cg_client
            )
        except httpx.HTTPError as exc:
            # chatgpt.com unreachable — surface the upstream failure to
            # Codex (we have no response to relay). This is NOT an analyze
            # fault, so it is not "fail open"; it is a genuine upstream
            # outage Codex should see + retry.
            _logger.warning(
                "event=codex_chatgpt_unreachable err=%r", exc
            )
            return JSONResponse(
                {
                    "error": {
                        "type": "upstream_unreachable",
                        "message": "Sentisec: could not reach chatgpt.com",
                    }
                },
                status_code=502,
            )

        # Parse the request + response for the (token-redacted) analyze
        # body. Best-effort — a parse failure still analyses what it can.
        try:
            request_json: Any = httpx.Response(200, content=request_body).json()
        except ValueError:
            request_json = request_body.decode("utf-8", errors="replace")
        response_json = _parse_response_for_analyze(upstream)
        session_id = _session_id_of(request_json, inbound_headers)
        _open_session(session_id)

        # Step 3 — analyze on a TOKEN-REDACTED copy. The request copy
        # carries the model's tool catalog (gated by the capture posture)
        # so the cloud projects real tool schemas instead of its degraded
        # fallback.
        analyze_body = build_analyze_request(
            session_id=session_id,
            request_json=request_json,
            response_json=response_json,
            model=_model_of(request_json),
            capture_full=resolved_capture_full,
        )
        verdict = call_analyze(
            analyze_body,
            control_plane_url=config.control_plane_url,
            workspace_key=workspace_key,
            client=az_client,
        )

        # Step 4 — enforce + capture. Emit the per-call ``tool_call``
        # events BEFORE the ``verdict`` so the dashboard timeline orders
        # the tool rows ahead of the turn verdict (Claude-track parity).
        _capture_tool_calls(session_id, verdict)
        _capture_verdict(session_id, verdict, request_json)
        if verdict.blocks:
            return _blocked_response(verdict)
        return _relay_response(upstream)

    async def healthz_endpoint(_request: Request) -> JSONResponse:
        return JSONResponse(
            {
                "status": "ok",
                "codex_proxy_port": codex_proxy_port(config.daemon_port),
                "control_plane_url": config.control_plane_url,
                "buffered_events": events.qsize() if events is not None else 0,
            }
        )

    import contextlib
    from collections.abc import AsyncIterator

    @contextlib.asynccontextmanager
    async def lifespan(_app: Starlette) -> AsyncIterator[None]:
        try:
            yield
        finally:
            if owns_chatgpt:
                cg_client.close()
            if owns_analyze:
                az_client.close()

    app = Starlette(
        routes=[
            Route("/v1/responses", responses_endpoint, methods=["POST"]),
            Route("/healthz", healthz_endpoint, methods=["GET"]),
        ],
        lifespan=lifespan,
    )
    app.state.config = config
    app.state.events = events
    return app


def _session_id_of(request_json: Any, headers: _HeaderGetter) -> str:
    """Resolve the session id for a Codex turn (header > body > empty).

    Prefers the Codex ``session-id`` header (the stable per-session id),
    falling back to a ``session_id`` in the request body, then the empty
    string (a single-bucket session for a malformed call). Never carries
    token material — only the opaque session id.
    """
    header_sid = headers.get("session-id")
    if header_sid:
        return header_sid
    if isinstance(request_json, dict):
        body_sid = request_json.get("session_id")
        if isinstance(body_sid, str) and body_sid:
            return body_sid
    return ""


def run(
    *,
    config: EdgeConfig | None = None,
    daemon_port: int | None = None,
) -> None:  # pragma: no cover — process entry, not unit-tested
    """Serve the codex proxy app with uvicorn (the daemon / wizard entry).

    Binds ``127.0.0.1:<codex_proxy_port(daemon_port)>``. Not exercised by
    unit tests (those drive the ASGI app via the Starlette ``TestClient``);
    the wizard / a daemon runner invoke this when Codex is wired.
    """
    import uvicorn

    cfg = config if config is not None else _load_config()
    port = codex_proxy_port(
        daemon_port if daemon_port is not None else cfg.daemon_port
    )
    events = EventBuffer()
    app = build_codex_proxy_app(cfg, events=events)
    uvicorn.run(app, host="127.0.0.1", port=port)


def _load_config() -> EdgeConfig:  # pragma: no cover — process entry
    import os

    path = os.path.expanduser(os.path.join("~", ".sentisec", "edge.toml"))
    try:
        return EdgeConfig.load(path)
    except Exception:
        return EdgeConfig.default()


if __name__ == "__main__":  # pragma: no cover — module entry
    run()
