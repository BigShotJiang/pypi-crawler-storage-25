"""Per-turn usage extraction from the OTel-captured model wire.

Edge-subscription-demo (Gateway visibility wave). Claude Code's
OpenTelemetry integration writes the full ``/v1/messages``
request/response JSON to disk (``OTEL_LOG_RAW_API_BODIES=file:<dir>``)
and the :class:`~sentisec_sdk.edge.otel_receiver.OTLPReceiver` correlates
the request + response bodies into one :class:`Turn` per ``prompt.id``.
The raw bodies carry everything the gateway Dashboard / Logs / Traces
pages need per turn — ``usage.input_tokens`` / ``usage.output_tokens``,
the ``model``, the ``stop_reason``, and the count of ``tool_use`` blocks
— but the receiver does not parse them out today.

This module is the parse step. It reads the JSON the receiver attached
to a turn (which is LOCAL on the user's disk; design §9) and produces a
:class:`TurnUsage` the daemon turns into a ``model_request`` event. The
event carries the parsed numbers + BOUNDED previews; the full raw bodies
NEVER leave the machine.

Honest gaps (plan §6)
=====================

- Extended-thinking content is redacted by the OTel integration itself
  (inherent gap) — we never see those tokens broken out; ``output_tokens``
  is whatever the provider's ``usage`` block reports.
- A response body the provider truncated (e.g. a network drop mid-stream)
  may carry no ``usage`` block; we return ``None`` for the missing
  numbers rather than fabricating them.

We NEVER invent token numbers. A missing / unparseable ``usage`` block
yields ``None`` for that field; the cloud projection lands NULL and the
gateway shows "—" rather than a fake count.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

__all__ = [
    "TurnUsage",
    "parse_turn_usage",
]


@dataclass(frozen=True)
class TurnUsage:
    """Parsed per-turn usage from a Claude ``/v1/messages`` turn.

    Every numeric field is optional — a turn whose response body carried
    no ``usage`` block (a truncated / errored response) yields ``None``
    for the missing numbers rather than a fabricated zero. ``status`` is
    ``"success"`` when the response parsed cleanly, ``"error"`` when the
    response body carried an ``error`` object or could not be parsed at
    all.
    """

    model: str | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    stop_reason: str | None = None
    tool_uses_count: int = 0
    status: str = "success"


def _maybe_int(value: object) -> int | None:
    """Coerce a JSON number to ``int`` or ``None`` (never a fabricated 0)."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return None


def _load(raw: str | None) -> dict[str, object] | None:
    """Parse a raw JSON body string into a dict, or ``None`` on failure."""
    if not raw:
        return None
    try:
        obj = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None
    return obj if isinstance(obj, dict) else None


def _count_tool_uses(content: object) -> int:
    """Count ``tool_use`` blocks in an Anthropic response ``content`` array."""
    if not isinstance(content, list):
        return 0
    return sum(
        1
        for block in content
        if isinstance(block, dict) and block.get("type") == "tool_use"
    )


def parse_turn_usage(
    *, request_body: str | None, response_body: str | None
) -> TurnUsage:
    """Parse a turn's request/response JSON into a :class:`TurnUsage`.

    ``model`` is read from the response body first (the provider echoes
    the resolved model id, including the date suffix) and falls back to
    the request body. ``usage.input_tokens`` / ``usage.output_tokens``
    come from the Anthropic Messages ``usage`` block; ``total_tokens`` is
    their sum when both are present. ``stop_reason`` and the
    ``tool_use``-block count come from the response.

    A response body carrying an ``error`` object (a provider 4xx/5xx the
    OTel integration still logged) or a body that cannot be parsed at all
    yields ``status="error"`` — the numbers are whatever could still be
    read (usually ``None``). We never fabricate counts.
    """
    req = _load(request_body)
    resp = _load(response_body)

    status = "success"
    if resp is None:
        # No parseable response — treat as an errored / incomplete turn
        # but do NOT fabricate numbers. (A request-only turn the OTel
        # batch has not yet completed should not reach here; the daemon
        # only emits when both bodies are present.)
        status = "error"
    elif "error" in resp:
        status = "error"

    # ---- model ---------------------------------------------------------
    model: str | None = None
    if resp is not None and isinstance(resp.get("model"), str):
        model = str(resp["model"])
    elif req is not None and isinstance(req.get("model"), str):
        model = str(req["model"])

    # ---- usage ---------------------------------------------------------
    input_tokens: int | None = None
    output_tokens: int | None = None
    if resp is not None and isinstance(resp.get("usage"), dict):
        usage = resp["usage"]
        assert isinstance(usage, dict)  # narrow for mypy
        input_tokens = _maybe_int(usage.get("input_tokens"))
        output_tokens = _maybe_int(usage.get("output_tokens"))

    total_tokens: int | None = None
    if input_tokens is not None and output_tokens is not None:
        total_tokens = input_tokens + output_tokens

    # ---- stop_reason + tool_use count ----------------------------------
    stop_reason: str | None = None
    tool_uses_count = 0
    if resp is not None:
        if isinstance(resp.get("stop_reason"), str):
            stop_reason = str(resp["stop_reason"])
        tool_uses_count = _count_tool_uses(resp.get("content"))

    return TurnUsage(
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        stop_reason=stop_reason,
        tool_uses_count=tool_uses_count,
        status=status,
    )
