"""Sentisec Edge — the thin subscription-mode client (Option B).

This sub-package is the THIN edge client published inside the
``sentisec-sdk`` wheel. It wires Claude Code's native hooks to a local
daemon that forwards every ``PreToolUse`` to the HOSTED gate
(``POST /v1/edge/gate`` on ``api.sentisec.ch``) and uploads forensic
events to ``POST /v1/edge/events``.

Architecture (founder decision: Option B — thin client + hosted gate)
=====================================================================

The Sentisec analysis engines and policy bundles run SERVER-SIDE and are
NEVER shipped to a user's disk. This package holds only:

- the hook adapter (:mod:`sentisec_sdk.edge.claude_hooks`),
- the gate HTTP client (:mod:`sentisec_sdk.edge.gate_client`),
- the OTel receiver (:mod:`sentisec_sdk.edge.otel_receiver`),
- the Codex passthrough proxy (:mod:`sentisec_sdk.edge.codex_proxy`),
- the event-dict builders + buffer (:mod:`sentisec_sdk.edge.events`),
- the event uploader (:mod:`sentisec_sdk.edge.event_upload`),
- the local daemon (:mod:`sentisec_sdk.edge.daemon`),
- the system installer (:mod:`sentisec_sdk.edge.installer`),
- the guided wizard (:mod:`sentisec_sdk.edge.wizard`).

It imports NOTHING from the ``sentisec`` (platform) package — no
server-side analysis engines, no mapping, no policy YAML. Verified by the
``test_no_platform_import`` grep + test in ``tests/unit/edge/``.

Two tracks, both token-custody-safe. Claude (subscription) is wired via
hooks + OTel + the transparent shim. Codex (ChatGPT subscription) is
wired via a LOCAL passthrough proxy that forwards the ChatGPT bearer
box-to-backend (never to the hosted plane) and analyses a token-redacted
``{request, response}`` copy. The ChatGPT token never leaves the box.
"""

from __future__ import annotations

__all__ = [
    "EDGE_CLAUDE_SOURCE",
    "EdgeConfig",
    "EdgeConfigMissing",
]

from .config import EdgeConfig, EdgeConfigMissing
from .events import EDGE_CLAUDE_SOURCE
