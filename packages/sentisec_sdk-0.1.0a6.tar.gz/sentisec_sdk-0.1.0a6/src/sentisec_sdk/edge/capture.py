"""Capture-posture resolution for edge subscription content (founder decision).

Edge-subscription-demo (Gateway visibility — content-capture wave). The
thin daemon decides per turn whether to ride the FULL structured prompt /
tool / response content to the cloud, or only the two bounded previews.

The posture is governed by the ``SENTISEC_EDGE_CAPTURE_CONTENT`` env var
plus an auto-detected default keyed off where the daemon uploads:

- ``full``    — ride the full structured content (token-scrubbed).
- ``preview`` — ride only the two bounded previews (the pre-wave shape).

Default (when the env var is unset / blank):

- **LOCAL / self-hosted backend => ``full``.** The user owns the plane;
  the full content never leaves their trust boundary, so the dashboard
  shows everything by default. "Local" = the configured
  ``control_plane_url`` host is ``localhost`` / ``127.0.0.1`` / ``::1``
  / a ``*.local`` mDNS name / a private-range IP, OR the URL is
  unparseable / empty (a half-configured dev plane).
- **Sentisec cloud (or any other remote) => ``preview``.** A turn's full
  prompt + tool + response content is not uploaded to the hosted plane
  unless the operator explicitly opts in with
  ``SENTISEC_EDGE_CAPTURE_CONTENT=full`` (safe default — content custody
  stays local unless asked).

An explicit env value ALWAYS wins over the auto-detected default. An
unrecognised env value falls back to the auto-detected default (we do
not silently treat a typo as ``full``).

The token-custody invariant is independent of this posture: provider
tokens NEVER ride in ANY mode (see
:func:`sentisec_sdk.edge.content.scrub_content` +
:func:`sentisec_sdk.edge.event_upload.scrub_event`). The flag only
governs prompt/tool/response CONTENT.

This module is a near-verbatim port of the platform package's
``sentisec.edge.capture`` — it was already engine-free (stdlib only).
"""

from __future__ import annotations

import ipaddress
import os
from urllib.parse import urlsplit

__all__ = [
    "ENV_CAPTURE_CONTENT",
    "capture_full_enabled",
    "is_local_control_plane",
]

#: The env var an operator sets to force the capture posture. Pinned as a
#: constant so a rename is grep-able and the compose / setup scripts wire
#: the same name.
ENV_CAPTURE_CONTENT = "SENTISEC_EDGE_CAPTURE_CONTENT"

#: Hostnames that are unambiguously the local machine.
_LOCAL_HOSTS = frozenset({"localhost", "127.0.0.1", "::1", "0.0.0.0"})


def is_local_control_plane(control_plane_url: str) -> bool:
    """Return ``True`` when ``control_plane_url`` targets a LOCAL/self-hosted plane.

    Local means the upload host is the loopback interface, a ``*.local``
    mDNS name, or a private-range IP (RFC-1918 / unique-local). An empty
    or unparseable URL is treated as local (a half-configured dev plane —
    safe to capture full because nothing left a hosted boundary).

    The hosted plane (``api.sentisec.ch`` or any other public host)
    returns ``False``.
    """
    if not control_plane_url or not control_plane_url.strip():
        return True
    try:
        parts = urlsplit(control_plane_url.strip())
    except ValueError:
        return True
    host = (parts.hostname or "").lower()
    if not host:
        # No host parsed (e.g. a bare path) — treat as local dev.
        return True
    if host in _LOCAL_HOSTS:
        return True
    if host.endswith(".local") or host.endswith(".localhost"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        # Not an IP literal — a public hostname like api.sentisec.ch.
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local


def capture_full_enabled(
    control_plane_url: str, *, env: dict[str, str] | None = None
) -> bool:
    """Return ``True`` when this daemon should ride FULL structured content.

    An explicit ``SENTISEC_EDGE_CAPTURE_CONTENT`` value wins:

    - ``full`` (any casing, whitespace-trimmed) -> ``True``;
    - ``preview`` / ``previews`` / ``off`` / ``none`` -> ``False``.

    Any other value (unset / blank / typo) falls back to the
    auto-detected default: ``True`` for a local/self-hosted plane,
    ``False`` for the hosted plane (:func:`is_local_control_plane`).

    ``env`` is injectable for tests; it defaults to :data:`os.environ`.
    """
    source = os.environ if env is None else env
    raw = (source.get(ENV_CAPTURE_CONTENT) or "").strip().lower()
    if raw == "full":
        return True
    if raw in {"preview", "previews", "off", "none"}:
        return False
    # Unset / blank / unrecognised -> auto-detect from the upload target.
    return is_local_control_plane(control_plane_url)
