"""Full structured prompt + tool content extraction from local Claude bodies.

Edge-subscription-demo (Gateway visibility — content-capture wave). The
gateway SPA's Traces / Logs render the SAME columns for every row,
filled by the BYOK middleware server-side: ``system_prompt``,
``prompt_messages_json`` (the messages array), ``tools_json`` /
``tool_choice_json`` / ``decoding_params_json``,
``response_content_json`` (the Anthropic content array), and the RAW
JSON drawers (``stored_raw_request`` / ``stored_raw_response``).

Subscription-mode Claude traffic previously rode only two 2000-char
previews, so the dashboard could not render the same columns. This module
is the parse step: it reads the LOCAL Anthropic ``/v1/messages``
request/response bodies (already on the user's disk via
``OTEL_LOG_RAW_API_BODIES``) and produces the structured fields the
cloud worker persistor INSERTs into ``llm_request_logs`` so the dashboard
renders subscription rows identically to BYOK rows.

Token-custody invariant (design §9, relaxed to CONTENT only)
============================================================

The capture flag (:mod:`sentisec_sdk.edge.capture` /
``SENTISEC_EDGE_CAPTURE_CONTENT``) decides whether the FULL prompt /
tool / response CONTENT rides to the cloud. It NEVER relaxes the token
invariant: provider tokens / ``Authorization`` / ``x-api-key`` /
``sk-ant-`` / ``Bearer`` material is scrubbed out of every field this
module returns, in ANY capture mode. Only prompt/tool/response CONTENT
may ride — never a credential.

The structured fields produced here are additionally scrubbed at the
upload choke point (:func:`sentisec_sdk.edge.event_upload.scrub_event`),
but this module scrubs at extraction time too (defense in depth) so a
republish path that bypasses the uploader cannot leak a token either.

This is a thin-client port of the platform package's
``sentisec.edge.content`` (the SDK ships no engines; only the scrub
constants are shared with :mod:`sentisec_sdk.edge.event_upload`).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from .event_upload import (
    _FORBIDDEN_KEYS,
    _FORBIDDEN_VALUE_PREFIXES,
    _REDACTED,
)

__all__ = [
    "ModelRequestContent",
    "extract_claude_content",
    "scrub_content",
]


def _drop_token_keys(value: Any) -> Any:
    """Return a deep copy of ``value`` with token-named keys removed entirely.

    :func:`scrub_content` redacts the VALUE of a token-shaped key but
    keeps the key; for the RAW drawer (and the structured body we store in
    ``prompt_messages_json``) we DROP the key entirely so the serialised
    body matches the BYOK posture, where credential headers never appear
    in the stored body at all. Walks dicts + lists.
    """
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, sub in value.items():
            if isinstance(key, str) and key.lower() in _FORBIDDEN_KEYS:
                continue
            out[key] = _drop_token_keys(sub)
        return out
    if isinstance(value, list):
        return [_drop_token_keys(item) for item in value]
    return value


def scrub_content(value: Any) -> Any:
    """Return a deep copy of ``value`` with provider-token material removed.

    Token-absence guard (load-bearing — content capture must never carry
    a provider token). Mirrors
    :func:`sentisec_sdk.edge.event_upload.scrub_event` semantics so the
    two choke points agree:

    - any dict key in :data:`~sentisec_sdk.edge.event_upload._FORBIDDEN_KEYS`
      (``authorization`` / ``x-api-key`` / ``api_key`` / ``apikey``) is
      redacted;
    - any string value carrying a forbidden prefix (``sk-ant-`` /
      ``Bearer `` / a JWT header ``eyJ``) is replaced with the
      :data:`~sentisec_sdk.edge.event_upload._REDACTED` sentinel;
    - dicts + lists are walked recursively.

    The original is not mutated — a fresh structure is returned.
    """
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, sub in value.items():
            if isinstance(key, str) and key.lower() in _FORBIDDEN_KEYS:
                out[key] = _REDACTED
                continue
            out[key] = scrub_content(sub)
        return out
    if isinstance(value, list):
        return [scrub_content(item) for item in value]
    if isinstance(value, str):
        if any(prefix in value for prefix in _FORBIDDEN_VALUE_PREFIXES):
            return _REDACTED
        return value
    return value


@dataclass(frozen=True)
class ModelRequestContent:
    """Full structured content parsed from one Claude ``/v1/messages`` turn.

    Every field mirrors the column shape the BYOK middleware writes so the
    cloud worker persistor's INSERT lands rows the gateway log-detail
    projector reads with zero changes:

    - ``system_prompt`` — joined system text (``system_prompt`` column).
    - ``messages`` — the BARE messages ARRAY ``[{role, content}]``
      (content = string or Anthropic content-block array). Stored in
      ``prompt_messages_json``. The pinned event contract requires the
      bare array so the projector reads it identically to the BYOK
      ``prompt_messages_json`` shape; ``system`` and ``tools`` ride in
      their OWN fields below.
    - ``tools`` / ``tool_choice`` / ``decoding_params`` — the request's
      tool definitions, tool-choice directive, and decoding params
      (``tools_json`` / ``tool_choice_json`` / ``decoding_params_json``).
    - ``response_content`` — the FULL Anthropic ``content`` array (text +
      ``tool_use`` blocks) so the projector renders tool calls
      (``response_content_json``).
    - ``raw_request`` / ``raw_response`` — token-scrubbed full bodies for
      the RAW JSON drawers (``stored_raw_request`` / ``stored_raw_response``).

    All fields are optional — a body that did not parse, or a turn with
    no tools, yields ``None`` for the missing field rather than a
    fabricated empty shape.
    """

    system_prompt: str | None = None
    messages: list[Any] | None = None
    tools: list[Any] | None = None
    tool_choice: Any | None = None
    decoding_params: dict[str, Any] | None = None
    response_content: list[Any] | None = None
    raw_request: str | None = None
    raw_response: str | None = None


#: Anthropic ``/v1/messages`` flat decoding-param keys we project — the
#: same set the BYOK middleware pulls for the ``anthropic`` provider.
_ANTHROPIC_DECODING_KEYS: tuple[str, ...] = (
    "max_tokens",
    "temperature",
    "top_p",
    "top_k",
    "stop_sequences",
    "metadata",
    "stream",
)


def _system_prompt(body: dict[str, Any]) -> str | None:
    """Join the Anthropic top-level ``system`` field into a single string.

    ``system`` may be a plain string OR an array of
    ``{type:"text", text:...}`` blocks. Mirrors the BYOK middleware's
    anthropic branch so the projected ``system_prompt`` column matches the
    BYOK shape. Returns ``None`` when absent.
    """
    sys = body.get("system")
    if isinstance(sys, str):
        return sys or None
    if isinstance(sys, list):
        pieces: list[str] = []
        for block in sys:
            if isinstance(block, dict) and isinstance(block.get("text"), str):
                pieces.append(block["text"])
            elif isinstance(block, str):
                pieces.append(block)
        return "\n".join(pieces) if pieces else None
    return None


def _decoding_params(body: dict[str, Any]) -> dict[str, Any] | None:
    out: dict[str, Any] = {}
    for key in _ANTHROPIC_DECODING_KEYS:
        value = body.get(key)
        if value is not None:
            out[key] = value
    return out or None


def extract_claude_content(
    *,
    request_body: str | None,
    response_body: str | None,
    capture_full: bool,
) -> ModelRequestContent:
    """Parse full structured content from the LOCAL Claude request/response.

    When ``capture_full`` is ``False`` (preview-only posture — typically
    when targeting Sentisec cloud), returns an empty
    :class:`ModelRequestContent`; the daemon then rides only the bounded
    previews exactly as before (backward-compatible). When ``True``, the
    full structured fields are parsed and TOKEN-SCRUBBED.

    Every returned field has passed through :func:`scrub_content`, so no
    provider token can ride even if the local body carried an
    ``Authorization`` header / ``sk-ant-...`` key. A body that does not
    parse as a JSON object contributes ``None`` for its side.
    """
    if not capture_full:
        return ModelRequestContent()

    req = _parse_json_object(request_body)
    resp = _parse_json_object(response_body)

    system_prompt: str | None = None
    messages: list[Any] | None = None
    tools: list[Any] | None = None
    tool_choice: Any | None = None
    decoding_params: dict[str, Any] | None = None
    raw_request: str | None = None
    if req is not None:
        # Redact token VALUES then DROP token-named keys entirely so the
        # stored body matches the BYOK posture (no ``authorization`` key
        # at all, not just a redacted value).
        scrubbed_req = _drop_token_keys(scrub_content(req))
        if isinstance(scrubbed_req, dict):
            system_prompt = _system_prompt(scrubbed_req)
            # Emit the BARE messages ARRAY for ``prompt_messages_json``
            # (the pinned event contract). The ``system`` / ``tools`` ride
            # in their own fields below — the projector reads
            # ``prompt_messages_json`` as a messages array, exactly like
            # the BYOK path.
            raw_messages = scrubbed_req.get("messages")
            if isinstance(raw_messages, list):
                messages = raw_messages
            raw_tools = scrubbed_req.get("tools")
            if isinstance(raw_tools, list) and raw_tools:
                tools = raw_tools
            tc = scrubbed_req.get("tool_choice")
            if tc is not None:
                tool_choice = tc
            decoding_params = _decoding_params(scrubbed_req)
            # Serialize the SCRUBBED body so the RAW drawer never shows a
            # token either (the BYOK path stores the verbatim body; the
            # subscription path stores the token-scrubbed body — the only
            # safe form, design §9).
            raw_request = json.dumps(scrubbed_req, separators=(",", ":"))

    response_content: list[Any] | None = None
    raw_response: str | None = None
    if resp is not None:
        scrubbed_resp = _drop_token_keys(scrub_content(resp))
        if isinstance(scrubbed_resp, dict):
            content = scrubbed_resp.get("content")
            if isinstance(content, list):
                response_content = content
            raw_response = json.dumps(scrubbed_resp, separators=(",", ":"))

    return ModelRequestContent(
        system_prompt=system_prompt,
        messages=messages,
        tools=tools,
        tool_choice=tool_choice,
        decoding_params=decoding_params,
        response_content=response_content,
        raw_request=raw_request,
        raw_response=raw_response,
    )


def _parse_json_object(raw: str | None) -> dict[str, Any] | None:
    """Best-effort parse of ``raw`` into a dict. ``None`` on any failure."""
    if not raw:
        return None
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return None
    return obj if isinstance(obj, dict) else None
