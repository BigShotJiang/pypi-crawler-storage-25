"""Edge event upload client — drains the buffer to the cloud.

The daemon's capture handlers push standard Sentisec event dicts onto an
:class:`~sentisec_sdk.edge.events.EventBuffer`. This module drains that
buffer and POSTs the events, in batches, to the cloud's
``POST /v1/edge/events`` ingestion route, authenticated with the
``sk_sentisec_*`` workspace key.

Token-custody guard (load-bearing)
==================================

Sentisec cloud NEVER receives a user's provider credentials. The Claude
track gates + captures via hooks + OTel and never touches the OAuth
token; the event dicts the daemon builds carry only tool names, risk
levels, verdicts, prompt/assistant text, and rule ids. This client adds a
DEFENSIVE scrub (:func:`scrub_event`) that strips any ``Authorization``
field, any ``sk-ant-...`` Anthropic key material, and any ChatGPT token
material from every event before it goes on the wire — so a future
capture-handler regression that accidentally enqueued a token can never
leak it to the cloud. The guard test asserts the uploaded payload
contains NONE of these.

Offline spool
=============

When the cloud is unreachable (connection error / non-2xx after
retries), the drained batch is appended to a local spool file under
``~/.sentisec/`` (one JSON object per line — JSONL) rather than dropped.
A subsequent successful :meth:`EventUploader.flush` replays the spool
first, then the live batch, so the dashboard's session history backfills
once connectivity returns. The spool stays local — it is the same
NO-token Sentisec events, never provider credentials.

This module is a near-verbatim port of the platform package's
``sentisec.edge.event_upload`` — it was already engine-free; only the
``EventBuffer`` import is repointed to the thin events module.
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any

import httpx

from .events import EventBuffer

__all__ = [
    "DEFAULT_SPOOL_PATH",
    "EventUploader",
    "contains_provider_token_material",
    "scrub_event",
]

_logger = logging.getLogger("sentisec_sdk.edge.event_upload")

#: Header the cloud ingest route reads identity from (matches
#: ``sentisec.proxy.edge_ingest._WORKSPACE_KEY_HEADER``). The workspace
#: key is the ONLY credential that goes on the wire.
_WORKSPACE_KEY_HEADER = "X-Sentisec-Workspace-Key"

#: The event-dict keys + value-prefixes the defensive scrub strips.
#: ``Authorization`` (any casing) is removed outright; any string value
#: containing a provider-token prefix is redacted. These are NEVER
#: legitimately present on a Sentisec event dict — the scrub is a
#: belt-and-suspenders guard against a capture-handler regression.
_FORBIDDEN_KEYS = frozenset({"authorization", "x-api-key", "api_key", "apikey"})

#: Provider token material prefixes. ``sk-ant-`` = Anthropic API key;
#: ``Bearer `` / ``eyJ`` (a JWT header) cover relayed OAuth / ChatGPT
#: access tokens. A string value carrying any of these is redacted.
_FORBIDDEN_VALUE_PREFIXES = ("sk-ant-", "Bearer ", "bearer ", "eyJ")

#: Default spool file — JSONL, one event per line, under ``~/.sentisec``.
DEFAULT_SPOOL_PATH = os.path.expanduser(
    os.path.join("~", ".sentisec", "edge-spool.jsonl")
)

#: Hard cap on spooled events during a prolonged control-plane outage
#: (FIX-D). The original spool grew unboundedly while the cloud was down
#: (the daemon.log showed ~20 consecutive transport errors); a long outage
#: could pin disk + memory. When the spool would exceed this, the OLDEST
#: events are dropped (a stale session matters less than a fresh one) and a
#: warning is logged. Generous enough to cover a normal restart window.
DEFAULT_MAX_SPOOL_EVENTS = 10_000

#: Sentinel a redacted value is replaced with — visible in logs / the
#: dashboard so an operator notices the (should-be-impossible) leak
#: attempt rather than the value silently vanishing.
_REDACTED = "[REDACTED:provider-token]"


def contains_provider_token_material(value: Any) -> bool:
    """Return True if ``value`` looks like provider-token material.

    Used by the scrub + the guard test. Recurses into dicts / lists so a
    nested string carrying ``sk-ant-...`` / a JWT / a Bearer token is
    caught regardless of nesting depth.
    """
    if isinstance(value, str):
        return any(prefix in value for prefix in _FORBIDDEN_VALUE_PREFIXES)
    if isinstance(value, dict):
        for k, v in value.items():
            if isinstance(k, str) and k.lower() in _FORBIDDEN_KEYS:
                return True
            if contains_provider_token_material(v):
                return True
        return False
    if isinstance(value, (list, tuple)):
        return any(contains_provider_token_material(item) for item in value)
    return False


def scrub_event(event: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of ``event`` with any provider-token material removed.

    - Drops any key in :data:`_FORBIDDEN_KEYS` (``Authorization`` etc.).
    - Replaces any string value carrying a forbidden prefix with
      :data:`_REDACTED`.
    - Recurses into nested dicts / lists.

    The ``sk_sentisec_*`` workspace key is NOT touched by this scrub — it
    never appears inside an event dict (it rides on the request header),
    and it does not match any forbidden prefix.
    """
    out: dict[str, Any] = {}
    for key, value in event.items():
        if isinstance(key, str) and key.lower() in _FORBIDDEN_KEYS:
            _logger.warning(
                "event=edge_upload_scrub_dropped_key key=%s — provider "
                "token material must never reach the cloud",
                key,
            )
            continue
        out[key] = _scrub_value(value)
    return out


def _scrub_value(value: Any) -> Any:
    """Recursively scrub a single value (helper for :func:`scrub_event`)."""
    if isinstance(value, str):
        if any(prefix in value for prefix in _FORBIDDEN_VALUE_PREFIXES):
            _logger.warning(
                "event=edge_upload_scrub_redacted_value — provider token "
                "material redacted before upload"
            )
            return _REDACTED
        return value
    if isinstance(value, dict):
        return scrub_event(value)
    if isinstance(value, list):
        return [_scrub_value(item) for item in value]
    return value


class EventUploader:
    """Drains an :class:`EventBuffer` and POSTs batches to the cloud route.

    The uploader is constructed with the cloud target + the workspace key
    + an httpx client (injectable so tests pass a
    ``httpx.MockTransport``-backed client without network I/O). It owns NO
    daemon lifecycle — :meth:`flush` is called on a cadence by the
    daemon's background task.

    Retry / backoff: :meth:`flush` retries a failed POST up to
    ``max_retries`` with exponential backoff; on final failure the batch
    is spooled to disk (:attr:`spool_path`) and re-attempted on the next
    flush. Every batch is scrubbed (:func:`scrub_event`) before the wire.
    """

    def __init__(
        self,
        *,
        buffer: EventBuffer,
        control_plane_url: str,
        workspace_key: str,
        client: httpx.Client | None = None,
        spool_path: str | None = None,
        max_retries: int = 3,
        backoff_base_s: float = 0.5,
        sleep: Any = time.sleep,
        max_spool_events: int = DEFAULT_MAX_SPOOL_EVENTS,
    ) -> None:
        self._buffer = buffer
        self._url = control_plane_url.rstrip("/") + "/v1/edge/events"
        self._workspace_key = workspace_key
        self._client = client if client is not None else httpx.Client(timeout=10.0)
        self._owns_client = client is None
        self._spool_path = Path(spool_path or DEFAULT_SPOOL_PATH)
        self._max_retries = max_retries
        self._backoff_base_s = backoff_base_s
        self._sleep = sleep
        self._max_spool_events = max_spool_events

    @property
    def spool_path(self) -> Path:
        """The local JSONL spool file used when the cloud is unreachable."""
        return self._spool_path

    def close(self) -> None:
        """Close the owned httpx client (no-op for an injected client)."""
        if self._owns_client:
            self._client.close()

    # ------------------------------------------------------------------
    # Wire shape

    def _post_batch(self, events: list[dict[str, Any]]) -> bool:
        """POST one scrubbed batch. Returns True on a 2xx, False otherwise.

        Never raises on a transport error — returns False so the caller
        spools. The scrub is applied here (the single choke point) so NO
        un-scrubbed event can reach :meth:`httpx.Client.post`.
        """
        scrubbed = [scrub_event(e) for e in events]
        payload = {"events": scrubbed}
        headers = {_WORKSPACE_KEY_HEADER: self._workspace_key}
        try:
            response = self._client.post(self._url, json=payload, headers=headers)
        except httpx.HTTPError as exc:
            _logger.warning("event=edge_upload_transport_error err=%r", exc)
            return False
        if 200 <= response.status_code < 300:
            return True
        _logger.warning(
            "event=edge_upload_non_2xx status=%d body=%.200s",
            response.status_code,
            response.text,
        )
        return False

    def _post_with_retry(self, events: list[dict[str, Any]]) -> bool:
        """POST a batch with exponential backoff. Returns True on success."""
        if not events:
            return True
        for attempt in range(self._max_retries):
            if self._post_batch(events):
                return True
            if attempt < self._max_retries - 1:
                self._sleep(self._backoff_base_s * (2**attempt))
        return False

    # ------------------------------------------------------------------
    # Spool

    def _spool(self, events: list[dict[str, Any]]) -> None:
        """Rewrite the spool file (JSONL) with the newest events, capped.

        FIX-D: the spool is REWRITTEN (not appended) with the most recent
        :attr:`_max_spool_events` events. Because :meth:`flush` already
        drained the existing spool into ``events`` before this call, a
        rewrite is correct (no double-write) and lets us enforce the cap:
        on a prolonged outage the OLDEST events are dropped so the spool
        cannot grow unboundedly. Events are scrubbed BEFORE landing on disk
        so the spool — like the wire — never holds provider-token material.
        """
        if not events:
            return
        dropped = 0
        if len(events) > self._max_spool_events:
            dropped = len(events) - self._max_spool_events
            events = events[-self._max_spool_events :]
        self._spool_path.parent.mkdir(parents=True, exist_ok=True)
        with self._spool_path.open("w", encoding="utf-8") as fh:
            for event in events:
                fh.write(json.dumps(scrub_event(event), separators=(",", ":")))
                fh.write("\n")
        if dropped:
            _logger.warning(
                "event=edge_upload_spool_capped dropped_oldest=%d cap=%d "
                "— control plane unreachable too long; oldest edge events "
                "dropped to bound the spool",
                dropped,
                self._max_spool_events,
            )
        _logger.info(
            "event=edge_upload_spooled count=%d path=%s",
            len(events),
            self._spool_path,
        )

    def _drain_spool(self) -> list[dict[str, Any]]:
        """Read + delete the spool file, returning the spooled events.

        Returns an empty list when no spool exists. Deletes the file so a
        successful replay does not double-upload; if the replay fails,
        :meth:`flush` re-spools.
        """
        if not self._spool_path.is_file():
            return []
        events: list[dict[str, Any]] = []
        with self._spool_path.open(encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    _logger.warning("event=edge_upload_spool_bad_line line=%.120s", line)
        self._spool_path.unlink()
        return events

    # ------------------------------------------------------------------
    # Flush

    def flush(self) -> int:
        """Drain the buffer (+ any spool) and upload. Returns events uploaded.

        Order: replay the spool first (oldest events), then the live
        buffer drain. On a final upload failure the combined batch is
        spooled for the next flush. Returns the number of events
        successfully uploaded this call (0 when offline -> all spooled).
        """
        spooled = self._drain_spool()
        live = self._buffer.drain_sync()
        batch = spooled + live
        if not batch:
            return 0
        if self._post_with_retry(batch):
            return len(batch)
        self._spool(batch)
        return 0
