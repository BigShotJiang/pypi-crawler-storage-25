"""The ``sentisec edge`` guided wizard — login -> detect -> confirm -> wire.

This is the single command a friend / early user runs to secure their
Claude Code subscription session. On first run (no ``~/.sentisec/edge.toml``)
it walks the guided setup; afterwards it shows a compact status panel. The
user never types per-tool subcommands — the wizard logs in, detects the
installed agents, confirms one thing, and does all the wiring behind the
scenes via :mod:`sentisec_sdk.edge.installer`.

Command surface (mounted as the ``sentisec edge`` group)::

    sentisec edge            # first run: guided setup; afterwards: status
    sentisec edge status     # the status panel
    sentisec edge off        # pause protection (keeps config)
    sentisec edge on         # resume protection
    sentisec edge uninstall  # remove shim + PATH block, hooks, daemon

The wizard is structured as small, individually-testable units:

- :func:`login` — D-015 pairing flow against the control plane (reuses
  ``POST /v1/sdk/pair/complete`` + a direct paste-key fallback). Only the
  Sentisec workspace key is stored — never a provider token.
- :func:`detect_agents` — pure detection of ``claude`` / ``codex`` install
  + auth mode over the current ``$HOME`` / ``$PATH``.
- :func:`render_confirm_summary` — the one-line "Secure it?" summary.
- :func:`wire_claude` — orchestrates the installer (hooks + shim + PATH +
  daemon service) for the Claude track.
- :func:`self_test` + :func:`render_status_panel` — the synthetic
  PreToolUse round-trip + the status panel.

Claude AND Codex tracks
=======================

Claude (subscription) is wired via hooks + OTel + the transparent shim.
Codex (ChatGPT-subscription, ``~/.codex/auth.json`` ``auth_mode ==
"chatgpt"``) is wired via the user-level ``~/.codex/config.toml``
provider that points Codex at the LOCAL passthrough proxy
(:mod:`sentisec_sdk.edge.codex_proxy`) — which forwards the ChatGPT
bearer box-to-backend (never to the hosted plane) and analyses a
token-redacted copy. Codex in ``apikey`` mode or not installed is
skipped gracefully with a clear message.

The Typer app (:data:`app`) is mounted onto the top-level ``sentisec``
CLI as the ``edge`` subcommand group by ``sentisec_sdk.cli``.
"""

from __future__ import annotations

import contextlib
import json
import os
import platform
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Protocol

import httpx
import typer
from rich.console import Console
from rich.panel import Panel

from .codex_proxy import codex_proxy_port
from .config import EdgeConfig, EdgeConfigMissing
from .installer import (
    LAUNCHD_LABEL,
    SYSTEMD_UNIT_NAME,
    claude_settings_path,
    install_claude_shim,
    install_daemon_service,
    merge_claude_hooks,
    remove_codex_provider,
    remove_path_block,
    service_file_path,
    uninstall_claude_shim,
    uninstall_daemon_service,
    unmerge_claude_hooks,
    write_codex_provider,
    write_path_block,
)

__all__ = [
    "AgentDetection",
    "AuthMode",
    "ClaudeDetection",
    "CodexDetection",
    "Detection",
    "app",
    "activate_daemon_service",
    "config_path",
    "deactivate_daemon_service",
    "detect_agents",
    "ensure_control_plane_alignment",
    "login",
    "pair_url",
    "paused_marker_path",
    "render_confirm_summary",
    "render_status_panel",
    "resolve_entrypoint",
    "self_test",
    "session_link",
    "should_wire_codex",
    "wait_for_daemon_ready",
    "wire_claude",
    "wire_codex",
]

#: Environment-variable fallback for the control-plane target. Lets a
#: local end-to-end test point uploads at a dev plane without a flag and
#: without hand-editing ``edge.toml`` (``SENTISEC_CONTROL_PLANE_URL=...
#: sentisec edge``). Precedence is: explicit ``--control-plane-url`` flag
#: > this env var > the existing ``edge.toml`` value > the canonical
#: default. The flag/env override is plumbed through :func:`login`, which
#: persists it.
_CONTROL_PLANE_ENV = "SENTISEC_CONTROL_PLANE_URL"

#: Environment-variable fallback for the dashboard origin. The dashboard
#: app is a different host/port from the control-plane proxy (dev
#: ``:3001`` vs ``:8080``), so a local end-to-end test sets this to point
#: the pairing + watch links at the real dashboard
#: (``SENTISEC_DASHBOARD_URL=http://localhost:3001 sentisec edge``).
#: Precedence: explicit ``--dashboard-url`` flag > this env var > the
#: existing ``edge.toml`` value > "" (derived from the control plane).
#: Plumbed through :func:`login`, which persists it.
_DASHBOARD_URL_ENV = "SENTISEC_DASHBOARD_URL"

#: Bounded readiness-poll budget for the post-activate daemon healthz
#: wait. Short interval, ~5s ceiling — long enough for a freshly
#: bootstrapped launchd/systemd daemon to bind its port, short enough that
#: a genuinely-dead daemon falls through to the warning quickly.
_READY_TIMEOUT_S = 5.0
_READY_INTERVAL_S = 0.2

console = Console()


class _CommandRunner(Protocol):
    def __call__(
        self,
        args: list[str],
        *,
        check: bool = False,
        stdout: int | None = None,
        stderr: int | None = None,
    ) -> subprocess.CompletedProcess[Any]: ...


def config_path(home: Path | None = None) -> Path:
    """Resolve ``~/.sentisec/edge.toml`` under ``home`` (or ``$HOME``)."""
    base = home if home is not None else Path(os.path.expanduser("~"))
    return base / ".sentisec" / "edge.toml"


def paused_marker_path(home: Path | None = None) -> Path:
    """Resolve the ``~/.sentisec/paused`` marker file.

    ``sentisec edge off`` writes this marker (protection paused, config
    kept); ``sentisec edge on`` removes it. Its presence is what the
    status panel reports as "paused".
    """
    base = home if home is not None else Path(os.path.expanduser("~"))
    return base / ".sentisec" / "paused"


def _run_service_command(
    args: list[str],
    *,
    runner: _CommandRunner = subprocess.run,
) -> bool:
    """Run a service-manager command without surfacing local manager errors."""
    try:
        result = runner(
            args,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except (FileNotFoundError, OSError):
        return False
    return result.returncode == 0


def resolve_entrypoint() -> str | None:
    """Resolve the installed ``sentisec`` entrypoint path, or ``None``.

    The daemon must be launchable in a way that works for the curl/zipapp
    install as well as pip/pipx. ``python -m sentisec_sdk.edge.daemon`` only
    works when ``sentisec_sdk`` is importable by a bare ``python`` — TRUE
    for pip/pipx, FALSE for the self-contained zipapp at
    ``~/.local/bin/sentisec`` (the package lives INSIDE the zipapp). The
    portable form is ``python <sentisec-entrypoint> edge __daemon``, which
    runs the bundled/installed CLI either way.

    Resolution order:

    1. ``shutil.which("sentisec")`` — the installed console-script / zipapp
       on ``PATH`` (the curl-install drops the zipapp here);
    2. ``sys.argv[0]`` — the path the running ``sentisec edge`` was invoked
       as, when it points at a real file (covers a zipapp invoked by an
       absolute path not yet on ``PATH``);
    3. ``None`` — neither resolved; the caller falls back to the ``-m`` form
       (pip/pipx only).
    """
    import shutil

    which = shutil.which("sentisec")
    if which:
        return which
    argv0 = sys.argv[0] if sys.argv else ""
    # Only trust argv[0] when it names an actual file (a zipapp / script),
    # not a bare "python" / "-c" / an interpreter the user launched us with.
    if argv0 and os.path.basename(argv0) != "python" and Path(argv0).is_file():
        return os.path.abspath(argv0)
    return None


def _spawn_daemon_process() -> bool:
    """Last-resort background daemon start when launchd/systemd is absent.

    Launches via the ``sentisec`` entrypoint (``python <entrypoint> edge
    __daemon``) when one resolves — the form that works for the zipapp
    install (where a bare ``python -m sentisec_sdk.edge.daemon`` cannot see
    the bundled package) AND for pip/pipx. Only when no entrypoint resolves
    do we fall back to the ``-m`` form (pip/pipx only).
    """
    entrypoint = resolve_entrypoint()
    if entrypoint:
        argv = [sys.executable, entrypoint, "edge", "__daemon"]
    else:
        argv = [sys.executable, "-m", "sentisec_sdk.edge.daemon"]
    try:
        subprocess.Popen(
            argv,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except (FileNotFoundError, OSError):
        return False
    return True


def activate_daemon_service(
    *,
    home: Path | None = None,
    system: str | None = None,
    runner: _CommandRunner = subprocess.run,
) -> bool:
    """Best-effort start/enable of the user daemon service.

    File installation is deterministic and tested separately. This helper
    performs the OS service-manager side effect that makes the daemon
    available immediately after ``sentisec edge`` finishes, which matters
    for Codex because it has no launch shim.
    """
    sysname = system if system is not None else platform.system()
    if sysname == "Darwin":
        uid = os.getuid()
        target = f"gui/{uid}/{LAUNCHD_LABEL}"
        plist = str(service_file_path(home))
        # If a prior loaded job exists, refresh it so a rewritten plist is
        # honored. bootout commonly fails on a fresh install; that is OK.
        _run_service_command(["launchctl", "bootout", f"gui/{uid}", plist], runner=runner)
        # Re-enable the label first: `sentisec edge uninstall` runs
        # `launchctl disable`, and a disabled label silently refuses
        # `bootstrap` — which would strand every re-install on the Popen
        # fallback (unmanaged, no KeepAlive). `enable` is a harmless no-op
        # when the label was never disabled.
        _run_service_command(["launchctl", "enable", target], runner=runner)
        bootstrapped = _run_service_command(
            ["launchctl", "bootstrap", f"gui/{uid}", plist], runner=runner
        )
        kicked = _run_service_command(
            ["launchctl", "kickstart", "-k", target], runner=runner
        )
        return bootstrapped or kicked or _spawn_daemon_process()

    _run_service_command(["systemctl", "--user", "daemon-reload"], runner=runner)
    started = _run_service_command(
        ["systemctl", "--user", "enable", "--now", SYSTEMD_UNIT_NAME],
        runner=runner,
    )
    return started or _spawn_daemon_process()


def _kill_daemon_processes(*, runner: _CommandRunner = subprocess.run) -> None:
    """Reap any lingering edge daemon / codex-proxy processes by pattern.

    The service is installed with launchd ``KeepAlive`` / systemd
    ``Restart=always``, so a bare kill is undone by the supervisor until
    the job is unloaded. Callers MUST unload the job first (bootout /
    ``disable --now``); this then reaps the process the supervisor already
    spawned — including the Popen fallback daemon, which no service manager
    tracks. ``pkill`` exists on macOS and Linux; a missing binary is a safe
    no-op via :func:`_run_service_command`.
    """
    for pattern in ("sentisec_sdk.edge.daemon", "sentisec_sdk.edge.codex_proxy"):
        _run_service_command(["pkill", "-f", pattern], runner=runner)


def deactivate_daemon_service(
    *,
    home: Path | None = None,
    system: str | None = None,
    runner: _CommandRunner = subprocess.run,
) -> bool:
    """Best-effort stop/disable of the user daemon service before uninstall.

    Hardened against the KeepAlive respawn that previously left an orphaned
    launchd job LOADED after ``sentisec edge uninstall`` (plist deleted but
    the in-memory job still supervising + respawning the daemon on 45711):

    - boot the job out by BOTH its target label and its plist-path form
      (the form ``bootstrap`` used), so a job bootstrapped from the file is
      unloaded even if the target form misses it;
    - ``disable`` the label so a stale plist cannot silently re-enable it;
    - then reap any process the supervisor already spawned.

    Returns True when the primary unload step reported success.
    """
    sysname = system if system is not None else platform.system()
    if sysname == "Darwin":
        uid = os.getuid()
        target = f"gui/{uid}/{LAUNCHD_LABEL}"
        plist = str(service_file_path(home))
        booted = _run_service_command(
            ["launchctl", "bootout", target], runner=runner
        )
        _run_service_command(
            ["launchctl", "bootout", f"gui/{uid}", plist], runner=runner
        )
        _run_service_command(["launchctl", "disable", target], runner=runner)
        _kill_daemon_processes(runner=runner)
        return booted
    stopped = _run_service_command(
        ["systemctl", "--user", "disable", "--now", SYSTEMD_UNIT_NAME],
        runner=runner,
    )
    _kill_daemon_processes(runner=runner)
    return stopped


def session_link(config: EdgeConfig) -> str:
    """Build the live-session dashboard link from the edge config.

    The dashboard routes every workspace view by the workspace **UUID**
    (``/w/<uuid>/...`` — the same id every proxy call uses), NOT by the
    key's short-id segment. So when ``config.workspace_id`` is known
    (the pairing path persists it) we build
    ``<dashboard-base>/w/<uuid>/sessions`` — a link that actually
    resolves. The dashboard base is plane-aware + ``--dashboard-url``-
    aware via :func:`_dashboard_base_for` (prod ``api.`` → ``app.``;
    local → the explicit dashboard origin).

    Only when ``workspace_id`` is empty — the paste-key fallback, which
    never calls the pairing endpoint and so never learns the UUID — do we
    degrade to the legacy ``ws-short`` form parsed from the key. A key
    that does not parse either falls back to the bare sessions root.
    """
    base = _dashboard_base_for(config.control_plane_url, config.dashboard_url)
    if config.workspace_id:
        return f"{base}/w/{config.workspace_id}/sessions"
    parts = config.workspace_key.split("_")
    # sk_sentisec_<ws-short>_<rand> -> index 2 is the ws-short segment.
    if len(parts) >= 4 and parts[0] == "sk" and parts[1] == "sentisec":
        ws_short = parts[2]
        return f"{base}/w/{ws_short}/sessions"
    return f"{base}/sessions"


# ---------------------------------------------------------------------------
# Login: D-015 pairing flow -> sk_sentisec_* workspace key -> edge.toml
# ---------------------------------------------------------------------------


class LoginError(Exception):
    """Raised when the pairing flow fails to obtain a workspace key."""


#: The dashboard page the wizard opens in the browser so the user can mint
#: a workspace key (the happy path) or a pairing code. Points at the CLI
#: setup surface (``/settings/cli-setup``), which is a real dashboard route
#: (the old ``/cli/pair`` 404'd — it was never served). That page links to
#: the workspace's API-keys page where the user mints the ``sk_sentisec_*``
#: workspace key the wizard's paste-key path accepts. The control-plane API
#: base (``api.sentisec.ch``) and the dashboard app base
#: (``app.sentisec.ch``) are distinct hosts; this page lives on the app host.
DASHBOARD_PAIR_PATH = "/settings/cli-setup"
CANONICAL_DASHBOARD_BASE = "https://app.sentisec.ch"

#: The shape-prefix every Sentisec workspace key carries. Used to detect a
#: direct paste-key (the SSH-only fallback) vs a short-lived pair code.
_WORKSPACE_KEY_PREFIX = "sk_sentisec_"


def _dashboard_base_for(
    control_plane_url: str, dashboard_url: str = ""
) -> str:
    """Resolve the dashboard app base URL — used by BOTH link builders.

    The pairing page AND the watch link live on the dashboard host, which
    is a DIFFERENT origin from the control-plane API host. Resolution
    order (highest precedence first):

    1. an explicit ``dashboard_url`` (``--dashboard-url`` /
       ``SENTISEC_DASHBOARD_URL`` / persisted config) → used verbatim;
    2. a control plane on the canonical ``api.`` host → swap the
       subdomain to ``app.`` (prod: ``api.sentisec.ch`` →
       ``app.sentisec.ch``);
    3. otherwise (local / self-hosted with no ``dashboard_url``) → fall
       back to the control-plane origin. Same-origin dashboards resolve;
       a local plane where the dashboard is on a different port (dev
       ``:3001`` vs proxy ``:8080``) does NOT, but we never crash — the
       caller surfaces a short "dashboard may be on a different port"
       note and the user can pass ``--dashboard-url`` to fix it.
    """
    explicit = dashboard_url.rstrip("/")
    if explicit:
        return explicit
    plane = control_plane_url.rstrip("/")
    if "://api." in plane:
        return plane.replace("://api.", "://app.", 1)
    if plane.startswith("https://api.sentisec.ch"):
        return CANONICAL_DASHBOARD_BASE
    return plane


def _dashboard_base_is_derived_local(
    control_plane_url: str, dashboard_url: str = ""
) -> bool:
    """Return True when the dashboard base is a local/self-hosted guess.

    True only when there is NO explicit ``dashboard_url`` AND the control
    plane is not the canonical ``api.`` host — i.e. the resolved base is
    the control-plane origin itself, which may be the wrong port for the
    dashboard. Callers use this to print the "may be on a different port"
    note (and ONLY then).
    """
    if dashboard_url.rstrip("/"):
        return False
    plane = control_plane_url.rstrip("/")
    if "://api." in plane:
        return False
    if plane.startswith("https://api.sentisec.ch"):
        return False
    return True


def pair_url(control_plane_url: str, dashboard_url: str = "") -> str:
    """Build the dashboard CLI-setup URL the wizard opens in the browser.

    ``dashboard_url`` (when set) overrides the derived base so a local
    plane points the page at the actual dashboard origin (e.g.
    ``http://localhost:3001/settings/cli-setup``) instead of the proxy
    port.
    """
    base = _dashboard_base_for(control_plane_url, dashboard_url)
    return f"{base}{DASHBOARD_PAIR_PATH}"


def _looks_like_workspace_key(value: str) -> bool:
    """Return True when ``value`` is a pasted ``sk_sentisec_*`` key.

    The direct paste-key fallback (SSH-only path) lets a user paste a
    workspace key copied from the dashboard instead of a pair code. A value
    starting with the workspace-key prefix is treated as a key (persisted
    as-is); anything else is a pair code (redeemed via
    ``/v1/sdk/pair/complete``).
    """
    return value.startswith(_WORKSPACE_KEY_PREFIX)


def _complete_pairing(
    client: httpx.Client, control_plane_url: str, code: str
) -> tuple[str, str]:
    """Redeem a pair code via ``POST /v1/sdk/pair/complete`` (D-015).

    Posts ``{"code": "<pair_code>"}`` and returns ``(api_key,
    workspace_id)`` from the pairing response body (``{api_key,
    workspace_id, tier, expires_at}``). A 410 (unknown / consumed /
    expired code), a non-2xx, or a missing ``api_key`` raises
    :class:`LoginError`.

    The ``workspace_id`` is the workspace **UUID** the dashboard routes
    by (``/w/<uuid>/...``); the key's short-id segment is NOT a routable
    id, so :func:`session_link` needs this UUID to build a link that
    resolves. A response without ``workspace_id`` returns ``""`` for it
    (the caller degrades to the short-id form rather than failing).

    Token custody: the response carries ONLY the Sentisec workspace key
    + the workspace UUID — no provider token is ever returned or stored.
    """
    try:
        resp = client.post(
            f"{control_plane_url}/v1/sdk/pair/complete",
            json={"code": code},
        )
    except httpx.HTTPError as exc:
        raise LoginError(f"could not reach the control plane: {exc}") from exc
    if resp.status_code == 410:
        raise LoginError(
            "that pairing code is unknown, already used, or expired — "
            "re-run `sentisec edge` to get a fresh code"
        )
    if resp.status_code != 200:
        raise LoginError(
            f"pairing failed: {resp.status_code} {resp.text[:200]}"
        )
    body = resp.json()
    key = str(body.get("api_key", "")) if isinstance(body, dict) else ""
    if not key:
        raise LoginError("control plane returned an empty workspace key")
    workspace_id = (
        str(body.get("workspace_id", "")) if isinstance(body, dict) else ""
    )
    return key, workspace_id


def login(
    *,
    home: Path | None = None,
    control_plane_url: str | None = None,
    dashboard_url: str | None = None,
    client: httpx.Client | None = None,
    open_browser: Any = None,
    prompt: Any = None,
) -> EdgeConfig:
    """Run the D-015 pairing flow and persist the workspace key.

    Flow (the workspace-key paste path is the happy path):

    1. Open the dashboard CLI-setup page
       (``app.sentisec.ch/settings/cli-setup``) in the browser. The user
       is already Clerk-authenticated there and mints a ``sk_sentisec_*``
       workspace key on the API-keys page (the happy path), or — for the
       device-code flow — a short-lived pair code.
    2. The user pastes the workspace key (or a pair code) into the CLI
       prompt.
    3. A pasted ``sk_sentisec_*`` key is taken verbatim; a pair code is
       redeemed via ``POST /v1/sdk/pair/complete`` for the workspace key.
       Either way the key is written into ``~/.sentisec/edge.toml`` via
       :meth:`EdgeConfig.save`.

    Token custody: the ONLY credential this flow stores is the Sentisec
    workspace key. No provider OAuth/ChatGPT token is ever requested,
    returned, or persisted.

    The pairing path also persists the workspace **UUID**
    (``workspace_id``) returned in the response so the watch link
    (:func:`session_link`) can route by the dashboard's canonical id
    instead of the non-routable key short-id. The paste-key fallback
    never calls the pairing endpoint, so ``workspace_id`` stays ``""``
    there (the link degrades to the short-id form).

    Parameters
    ----------
    home / control_plane_url:
        Override the home dir / control-plane target (tests + self-hosted
        planes). ``control_plane_url`` defaults to the config's value (or
        the canonical plane).
    dashboard_url:
        Explicit dashboard origin override (``--dashboard-url`` /
        ``SENTISEC_DASHBOARD_URL``). Defaults to the config's value (or
        ``""`` → derived from the control plane). Persisted so the watch
        link is stable across re-runs. The local escape hatch for when
        the dashboard is on a different host/port than the control plane.
    client:
        An injected :class:`httpx.Client` (tests pass one backed by a
        :class:`httpx.MockTransport` stub). Created + closed internally
        when ``None``.
    open_browser:
        Callable invoked with the pairing URL. Defaults to
        :func:`webbrowser.open`; tests pass a no-op / recorder.
    prompt:
        Callable returning the user-pasted code / key string. Defaults to
        :func:`typer.prompt`; tests inject a stub returning a fixed value.
        The value is stripped before use.
    """
    cfg_path = config_path(home)
    # Preserve any existing config values (e.g. a custom port the wizard
    # already chose); only the workspace key changes on login.
    try:
        existing = EdgeConfig.load(cfg_path)
    except EdgeConfigMissing:
        existing = EdgeConfig.default()
    plane = (control_plane_url or existing.control_plane_url).rstrip("/")
    # Dashboard override precedence: flag/env (dashboard_url arg) > the
    # value already in the config > "" (derived from the control plane).
    dash = (
        dashboard_url
        if dashboard_url is not None
        else existing.dashboard_url
    ).rstrip("/")
    url = pair_url(plane, dash)

    if open_browser is None:
        import webbrowser

        open_browser = webbrowser.open
    with contextlib.suppress(Exception):
        # Headless / no browser — the user can still open the URL manually
        # on another device and use the paste-key fallback.
        open_browser(url)
    console.print(
        "Open this page and sign in, then mint a workspace key on the "
        "API keys page and paste it here:\n"
        f"  {url}\n"
        "Your workspace key looks like `sk_sentisec_…`. "
        "(Have a short-lived pairing code instead? Paste that — it works too.)"
    )

    if prompt is None:
        prompt = lambda: typer.prompt(  # noqa: E731
            "Paste your workspace key (sk_sentisec_…) or a pairing code"
        )
    pasted = str(prompt()).strip()
    if not pasted:
        raise LoginError("no pairing code or key was entered")

    if _looks_like_workspace_key(pasted):
        # Direct paste-key fallback (SSH-only): the user copied their
        # workspace key from the dashboard — take it verbatim. This path
        # never calls the pairing endpoint, so the workspace UUID is
        # unknown ("") and the watch link degrades to the short-id form.
        key = pasted
        workspace_id = ""
    else:
        owns_client = client is None
        cl = client if client is not None else httpx.Client(timeout=10.0)
        try:
            key, workspace_id = _complete_pairing(cl, plane, pasted)
        finally:
            if owns_client:
                cl.close()

    saved = EdgeConfig(
        workspace_key=key,
        daemon_port=existing.daemon_port,
        wire_dir=existing.wire_dir,
        control_plane_url=plane,
        workspace_id=workspace_id,
        dashboard_url=dash,
    )
    saved.save(cfg_path)
    return saved


# ---------------------------------------------------------------------------
# Detect: pure detection of claude / codex install + auth mode
# ---------------------------------------------------------------------------


class AuthMode(str, Enum):
    """The detected auth mode of an agent CLI.

    ``SUBSCRIPTION`` is the demo's target (Claude Pro/Max OAuth session /
    Codex ChatGPT login); ``API_KEY`` means the user has a provider key
    configured; ``NOT_INSTALLED`` / ``NOT_LOGGED_IN`` are the two "nothing
    to secure yet" states.
    """

    SUBSCRIPTION = "subscription"
    API_KEY = "api_key"
    NOT_LOGGED_IN = "not_logged_in"
    NOT_INSTALLED = "not_installed"


@dataclass(frozen=True)
class AgentDetection:
    """Detection result for one agent CLI."""

    installed: bool
    auth_mode: AuthMode
    binary_path: str | None = None


# Backwards-friendly aliases — the two agent detections share the shape.
ClaudeDetection = AgentDetection
CodexDetection = AgentDetection


@dataclass(frozen=True)
class Detection:
    """The full detection result (both agents)."""

    claude: AgentDetection
    codex: AgentDetection


def _detect_claude(home: Path) -> AgentDetection:
    """Detect Claude Code install + auth mode over ``home`` / PATH.

    Install is ``shutil.which("claude")``. Auth mode:

    - ``ANTHROPIC_API_KEY`` set in the environment -> ``API_KEY``;
    - else a Claude OAuth session on disk
      (``~/.claude/.credentials.json`` or a ``oauthAccount`` in
      ``~/.claude.json``) -> ``SUBSCRIPTION``;
    - else ``NOT_LOGGED_IN``.

    A not-installed CLI short-circuits to ``NOT_INSTALLED``.
    """
    import shutil

    binary = shutil.which("claude")
    if binary is None:
        return AgentDetection(
            installed=False, auth_mode=AuthMode.NOT_INSTALLED
        )
    # API key beats subscription detection — if the user has a key set,
    # claude uses it (and the demo's hooks+OTel path still works, but the
    # confirm prompt names it so the user can choose).
    if os.environ.get("ANTHROPIC_API_KEY"):
        return AgentDetection(
            installed=True, auth_mode=AuthMode.API_KEY, binary_path=binary
        )
    if _claude_has_oauth_session(home):
        return AgentDetection(
            installed=True,
            auth_mode=AuthMode.SUBSCRIPTION,
            binary_path=binary,
        )
    return AgentDetection(
        installed=True, auth_mode=AuthMode.NOT_LOGGED_IN, binary_path=binary
    )


def _claude_has_oauth_session(home: Path) -> bool:
    """Return True when a Claude OAuth/subscription session is on disk.

    Claude Code stores its login state under ``~/.claude``. We accept
    either a ``~/.claude/.credentials.json`` file (the credential store) or
    an ``oauthAccount`` object inside ``~/.claude.json`` (the
    config-with-account shape). Best-effort + tolerant: a malformed file is
    treated as "no session".
    """
    creds = home / ".claude" / ".credentials.json"
    if creds.is_file():
        return True
    config = home / ".claude.json"
    if config.is_file():
        try:
            data = json.loads(config.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return False
        if isinstance(data, dict) and data.get("oauthAccount"):
            return True
    return False


def _detect_codex(home: Path) -> AgentDetection:
    """Detect Codex install + auth mode over ``home`` / PATH.

    Install is ``shutil.which("codex")``. Auth mode reads
    ``~/.codex/auth.json`` ``auth_mode`` (``chatgpt`` -> ``SUBSCRIPTION``,
    ``apikey`` -> ``API_KEY``); a missing/empty auth file ->
    ``NOT_LOGGED_IN``. A not-installed CLI -> ``NOT_INSTALLED``.

    A ``SUBSCRIPTION`` (``chatgpt``-mode) Codex is WIRED by the wizard via
    the local passthrough proxy (:func:`wire_codex`); an ``apikey``-mode /
    not-logged-in / not-installed Codex is skipped (:func:`should_wire_codex`).
    """
    import shutil

    binary = shutil.which("codex")
    if binary is None:
        return AgentDetection(
            installed=False, auth_mode=AuthMode.NOT_INSTALLED
        )
    auth_file = home / ".codex" / "auth.json"
    if not auth_file.is_file():
        return AgentDetection(
            installed=True,
            auth_mode=AuthMode.NOT_LOGGED_IN,
            binary_path=binary,
        )
    try:
        data = json.loads(auth_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return AgentDetection(
            installed=True,
            auth_mode=AuthMode.NOT_LOGGED_IN,
            binary_path=binary,
        )
    mode = data.get("auth_mode") if isinstance(data, dict) else None
    if mode == "chatgpt":
        return AgentDetection(
            installed=True,
            auth_mode=AuthMode.SUBSCRIPTION,
            binary_path=binary,
        )
    if mode == "apikey":
        return AgentDetection(
            installed=True, auth_mode=AuthMode.API_KEY, binary_path=binary
        )
    return AgentDetection(
        installed=True, auth_mode=AuthMode.NOT_LOGGED_IN, binary_path=binary
    )


def detect_agents(home: Path | None = None) -> Detection:
    """Detect both agent CLIs — pure over ``$HOME`` / ``$PATH``.

    No side effects, no network. ``shutil.which`` reads ``$PATH``;
    ``$HOME`` (or ``home``) anchors the on-disk auth-state lookups. Tests
    drive every branch by setting ``$PATH`` / ``$HOME`` and stubbing
    ``shutil.which``.
    """
    base = home if home is not None else Path(os.path.expanduser("~"))
    return Detection(claude=_detect_claude(base), codex=_detect_codex(base))


# ---------------------------------------------------------------------------
# Confirm prompt: the one-line "Secure it? [Enter]" summary
# ---------------------------------------------------------------------------


def should_wire_codex(det: AgentDetection) -> bool:
    """Return True when Codex should be wired (installed + ChatGPT-subscription).

    The local passthrough proxy is for the ChatGPT-subscription path only
    (``~/.codex/auth.json`` ``auth_mode == "chatgpt"`` ->
    :attr:`AuthMode.SUBSCRIPTION`). An ``apikey``-mode Codex already has a
    provider key (it is not the demo's no-key path), and a not-logged-in /
    not-installed Codex has nothing to secure — all three are skipped.
    """
    return det.installed and det.auth_mode == AuthMode.SUBSCRIPTION


def _claude_phrase(det: AgentDetection) -> str | None:
    """Render the Claude clause for the confirm summary, or None.

    Returns ``"Claude Code (subscription)"`` etc., or ``None`` when Claude
    is not installed (it is omitted from the summary).
    """
    if not det.installed:
        return None
    label = {
        AuthMode.SUBSCRIPTION: "subscription",
        AuthMode.API_KEY: "API key",
        AuthMode.NOT_LOGGED_IN: "not logged in",
    }.get(det.auth_mode, "")
    return f"Claude Code ({label})"


def render_confirm_summary(detection: Detection) -> str:
    """Render the one-line confirm summary for a detection.

    Examples (the exact strings the tests assert):

    - Claude only ->
      ``"I found Claude Code (subscription). Secure it? [Enter]"``
    - Claude + a ChatGPT-subscription Codex ->
      ``"I found Claude Code (subscription) and Codex (ChatGPT
      subscription). Secure them? [Enter]"``
    - Claude absent ->
      ``"I didn't find Claude Code installed. Install it, then re-run
      `sentisec edge`."``

    Codex appears in the wired summary ONLY when it is wireable
    (:func:`should_wire_codex` — installed + ChatGPT subscription mode); an
    ``apikey``-mode / not-logged-in Codex is omitted from the "secure it"
    line (it gets a separate skipped note in the setup flow).
    """
    phrase = _claude_phrase(detection.claude)
    if phrase is None:
        return (
            "I didn't find Claude Code installed. "
            "Install it, then re-run `sentisec edge`."
        )
    if should_wire_codex(detection.codex):
        return (
            f"I found {phrase} and Codex (ChatGPT subscription). "
            "Secure them? [Enter]"
        )
    return f"I found {phrase}. Secure it? [Enter]"


# ---------------------------------------------------------------------------
# Wiring orchestration — installer calls for the Claude track
# ---------------------------------------------------------------------------


def wire_claude(
    config: EdgeConfig,
    *,
    home: Path | None = None,
    python_executable: str | None = None,
    system: str | None = None,
    entrypoint: str | None = None,
) -> None:
    """Wire the Claude track: hooks + shim + PATH + daemon service.

    Orchestrates the four idempotent installer steps for the loaded
    ``config``:

    1. :func:`merge_claude_hooks` — the transport-matrix hook block into
       ``~/.claude/settings.json`` (hot-reloaded);
    2. :func:`install_claude_shim` — ``~/.sentisec/bin/claude`` (OTEL env +
       lazy daemon start + exec real claude);
    3. :func:`write_path_block` — prepend ``~/.sentisec/bin`` to PATH;
    4. :func:`install_daemon_service` — the launchd/systemd-user file (file
       write only; the wizard ``launchctl load``s separately).

    The daemon service is written to launch via the installed ``sentisec``
    entrypoint (``python <entrypoint> edge __daemon``) so the curl/zipapp
    install is self-sufficient (no ``pip install`` needed). ``entrypoint``
    defaults to :func:`resolve_entrypoint` (the running ``sentisec`` during
    setup); a ``None`` resolution falls back to the ``-m`` form (pip/pipx).

    Pure orchestration — every step is idempotent + reversible, so
    re-running ``wire_claude`` after a port change is safe.
    """
    base = home
    resolved_entrypoint = (
        entrypoint if entrypoint is not None else resolve_entrypoint()
    )
    merge_claude_hooks(claude_settings_path(base), config.daemon_port)
    shim = install_claude_shim(
        config.daemon_port,
        config.wire_dir,
        home=base,
        python_executable=python_executable,
    )
    write_path_block(shim.bin_dir, home=base)
    install_daemon_service(
        home=base,
        python_executable=python_executable,
        system=system,
        entrypoint=resolved_entrypoint,
    )


def wire_codex(
    config: EdgeConfig,
    *,
    home: Path | None = None,
) -> Path:
    """Wire the Codex track: write the local-passthrough provider config.

    Writes the user-level ``~/.codex/config.toml`` provider block
    (:func:`installer.write_codex_provider`) pointing Codex at the LOCAL
    passthrough proxy on ``codex_proxy_port(config.daemon_port)`` (=
    ``daemon_port + 1``). Codex then sends its ChatGPT bearer +
    ``X-Sentisec-Workspace-Key`` to that local port; the proxy forwards
    the bearer box-to-backend (never to the hosted plane) and analyses a
    token-redacted copy.

    Idempotent + reversible (the provider writer preserves every other
    Codex provider + records the prior ``model_provider``). The codex
    proxy process itself is started by the daemon runner / the launch
    flow; this function only writes the config that points Codex at it.
    Returns the written config path.
    """
    port = codex_proxy_port(config.daemon_port)
    return write_codex_provider(port, config.workspace_key, home=home)


def unwire_all(
    *,
    home: Path | None = None,
    system: str | None = None,
) -> None:
    """Reverse every wiring step — the ``sentisec edge uninstall`` mechanism.

    Removes the Claude hooks, the shim, the PATH block, the daemon
    service file, AND the Codex provider block (restoring the user's prior
    ``model_provider``), leaving no residue. Each removal is independently
    no-op-safe, so an uninstall after a partial install still completes.
    Config (``edge.toml``) is left for the caller to delete —
    :func:`uninstall` removes it last so a re-run starts fresh.
    """
    base = home
    unmerge_claude_hooks(claude_settings_path(base))
    uninstall_claude_shim(home=base)
    remove_path_block(home=base)
    uninstall_daemon_service(home=base, system=system)
    remove_codex_provider(home=base)


# ---------------------------------------------------------------------------
# Self-test + status panel
# ---------------------------------------------------------------------------

#: The synthetic PreToolUse payload the self-test round-trips through the
#: daemon — a benign Read of a project file. With the hosted gate
#: reachable this returns the gate's verdict; with it unreachable the
#: daemon fails open to ``allow``. Either way the response must be a
#: well-formed ``hookSpecificOutput`` — that is what the self-test asserts
#: (the daemon -> gate path is wired end-to-end).
_SELFTEST_PAYLOAD: dict[str, Any] = {
    "hook_event_name": "PreToolUse",
    "tool_name": "Read",
    "tool_input": {"file_path": "src/app.py"},
    "session_id": "__sentisec_selftest__",
    "cwd": "/proj",
    "transcript_path": "/tmp/selftest.jsonl",
}


def daemon_health(
    port: int, *, client: httpx.Client | None = None
) -> dict[str, Any] | None:
    """Check ``GET /healthz`` and return its body, or None if unreachable.

    Used by both the self-test and the status panel. A connection error /
    non-2xx returns ``None`` (the daemon is down) — the caller renders that
    as a health warning rather than crashing.
    """
    url = f"http://127.0.0.1:{port}/healthz"
    owns = client is None
    cl = client if client is not None else httpx.Client(timeout=2.0)
    try:
        resp = cl.get(url)
        if resp.status_code != 200:
            return None
        body = resp.json()
        return body if isinstance(body, dict) else None
    except (httpx.HTTPError, json.JSONDecodeError):
        return None
    finally:
        if owns:
            cl.close()


def self_test(port: int, *, client: httpx.Client | None = None) -> bool:
    """Round-trip a synthetic PreToolUse through the thin daemon.

    POSTs the benign :data:`_SELFTEST_PAYLOAD` to ``/hooks`` and asserts
    the daemon returns a well-formed ``hookSpecificOutput`` with a valid
    ``permissionDecision`` (``allow`` / ``deny`` / ``ask``). This proves
    the daemon -> hosted-gate path is wired end-to-end: the hook endpoint
    parses, forwards to the gate (or fails open), and wraps the verdict.
    Returns ``True`` on a well-formed decision, ``False`` on any failure
    (the wizard surfaces a warning rather than crashing).

    NOTE: unlike the fat client, this does NOT assert ``allow`` — the
    decision now comes from the hosted gate (which may legitimately deny or
    fail open). The self-test's contract is "the daemon answers with a
    valid wrapped decision", not "the benign call is allowed".

    ``client`` is injectable (tests pass a Starlette ``TestClient`` /
    ``httpx.MockTransport``-backed client) so the round-trip never needs a
    live daemon process.
    """
    url = f"http://127.0.0.1:{port}/hooks"
    owns = client is None
    cl = client if client is not None else httpx.Client(timeout=5.0)
    try:
        resp = cl.post(url, json=_SELFTEST_PAYLOAD)
        if resp.status_code != 200:
            return False
        body = resp.json()
        decision = (
            body.get("hookSpecificOutput", {}).get("permissionDecision")
            if isinstance(body, dict)
            else None
        )
        return decision in ("allow", "deny", "ask")
    except (httpx.HTTPError, json.JSONDecodeError):
        return False
    finally:
        if owns:
            cl.close()


_HealthCheck = Callable[..., dict[str, Any] | None]
_ActivateFn = Callable[..., bool]


def wait_for_daemon_ready(
    port: int,
    *,
    health: _HealthCheck = daemon_health,
    sleep: Callable[[float], None] = time.sleep,
    timeout: float = _READY_TIMEOUT_S,
    interval: float = _READY_INTERVAL_S,
) -> dict[str, Any] | None:
    """Poll ``GET /healthz`` until the daemon answers, or the budget runs out.

    Condition-based readiness wait — NOT a fixed sleep. After
    :func:`activate_daemon_service` boots the daemon, the freshly
    bootstrapped launchd/systemd process needs a moment to bind its port;
    running :func:`self_test` immediately races that startup and yields the
    "could not reach the daemon yet" warning even on a healthy install.
    This helper closes that race: it checks :func:`daemon_health` on a
    short ``interval`` until it returns a body (the daemon is up) or
    ``timeout`` elapses.

    Returns the ``/healthz`` body on success (so the caller can read
    ``control_plane_url`` for the version-skew guard) or ``None`` on a genuine
    timeout (the caller surfaces the warning branch). ``health`` / ``sleep``
    are injectable so tests drive the poll without a live process or real
    wall-clock waits.
    """
    deadline = timeout
    elapsed = 0.0
    while True:
        body = health(port)
        if body is not None:
            return body
        if elapsed >= deadline:
            return None
        sleep(interval)
        elapsed += interval


def ensure_control_plane_alignment(
    config: EdgeConfig,
    health_body: dict[str, Any] | None,
    *,
    activate: _ActivateFn = activate_daemon_service,
    wait: Callable[..., dict[str, Any] | None] = wait_for_daemon_ready,
    home: Path | None = None,
    warn: Callable[[str], None] | None = None,
) -> bool:
    """Restart the daemon once if it is serving a stale ``control_plane_url``.

    The daemon reads ``edge.toml`` ONCE at boot (:class:`EdgeConfig` is
    frozen). If a launchd/systemd daemon was already running when the
    wizard rewrote ``control_plane_url`` (e.g. a local-dev re-run pointing
    at ``http://127.0.0.1:8080``), the live daemon is still on the OLD
    plane until it is restarted. This guard compares the config's
    ``control_plane_url`` against the value the daemon reports in its
    ``/healthz`` body; on a mismatch it kickstarts the service once more
    (reusing :func:`activate_daemon_service`) and re-polls.

    Returns ``True`` when the daemon is aligned (either it already matched
    or the restart fixed it). Returns ``False`` and emits a one-line
    warning naming BOTH URLs when the daemon still mismatches after the
    restart — the user must restart the daemon by hand. ``activate`` /
    ``wait`` / ``warn`` are injectable for tests.
    """
    if warn is None:
        warn = lambda msg: console.print(f"[yellow]{msg}[/yellow]")  # noqa: E731
    want = config.control_plane_url.rstrip("/")
    got = (
        str(health_body.get("control_plane_url", "")).rstrip("/")
        if isinstance(health_body, dict)
        else ""
    )
    if got == want:
        return True
    # Stale config in the live daemon — kickstart once and re-poll.
    activate(home=home)
    refreshed = wait(config.daemon_port)
    got = (
        str(refreshed.get("control_plane_url", "")).rstrip("/")
        if isinstance(refreshed, dict)
        else ""
    )
    if got == want:
        return True
    warn(
        "Daemon is running stale config: it is uploading to "
        f"{got or '(unknown)'} but your setup configured {want}. "
        "Restart the daemon to pick up the new control-plane URL "
        "(re-run `sentisec edge`, or restart the edge service)."
    )
    return False


def render_status_panel(
    config: EdgeConfig,
    detection: Detection,
    *,
    health: dict[str, Any] | None,
    paused: bool,
) -> str:
    """Render the compact status panel body.

    Returns the plain-text panel body (the wizard wraps it in a rich
    :class:`Panel` for display; tests assert on this string). It reports:

    - what's protected (Claude Code + Codex when wired);
    - daemon health (up/down + port, from the ``/healthz`` body);
    - the workspace (the key's ``ws-short`` segment);
    - the live-session link;
    - the pause state when paused;
    - a note when Codex is detected but NOT wireable (apikey mode / not
      logged in).
    """
    lines: list[str] = []
    protected: list[str] = []
    if detection.claude.installed:
        protected.append("Claude Code")
    if should_wire_codex(detection.codex):
        protected.append("Codex (ChatGPT subscription)")
    lines.append(
        "Protected: " + (", ".join(protected) if protected else "(none detected)")
    )
    if detection.codex.installed and not should_wire_codex(detection.codex):
        lines.append(
            "Codex: detected but not secured — only ChatGPT-subscription "
            "mode is wired (yours is in API-key mode or not logged in)"
        )

    if paused:
        lines.append("Status: PAUSED (run `sentisec edge on` to resume)")
    elif health is not None:
        lines.append(
            f"Daemon: healthy on port {health.get('daemon_port', config.daemon_port)}"
        )
    else:
        lines.append(
            f"Daemon: not reachable on port {config.daemon_port} "
            "(run `sentisec edge` to restart)"
        )

    ws_short = "?"
    parts = config.workspace_key.split("_")
    if len(parts) >= 4:
        ws_short = parts[2]
    lines.append(f"Workspace: {ws_short}")
    lines.append(f"Watch live: {session_link(config)}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Typer app — the user-facing command surface (mounted as `sentisec edge`)
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="edge",
    help="Sentisec Edge — secure your Claude subscription sessions.",
    add_completion=False,
    no_args_is_help=False,
)


def _load_config_or_none(home: Path | None = None) -> EdgeConfig | None:
    """Load the edge config, returning None on first run (no config)."""
    try:
        return EdgeConfig.load(config_path(home))
    except EdgeConfigMissing:
        return None


def _resolve_control_plane_url(
    flag: str | None, *, home: Path | None = None
) -> str | None:
    """Resolve the effective control-plane override for setup.

    Precedence (highest first):

    1. the explicit ``--control-plane-url`` flag;
    2. the ``SENTISEC_CONTROL_PLANE_URL`` environment variable;
    3. the value already in ``edge.toml`` (preserved across a re-run);
    4. ``None`` — let :func:`login` fall back to its config/default chain
       (the canonical :data:`DEFAULT_CONTROL_PLANE_URL`).

    Returning the resolved string (vs ``None``) is what makes
    ``sentisec edge --control-plane-url http://127.0.0.1:8080`` land that
    value in ``edge.toml`` at setup — no ``sed``. ``None`` is returned
    only when there is no flag, no env var, AND no existing config, so a
    fresh prod install keeps the default unchanged.
    """
    if flag:
        return flag.strip()
    env = os.environ.get(_CONTROL_PLANE_ENV)
    if env and env.strip():
        return env.strip()
    try:
        existing = EdgeConfig.load(config_path(home))
    except EdgeConfigMissing:
        return None
    return existing.control_plane_url


def _resolve_dashboard_url(
    flag: str | None, *, home: Path | None = None
) -> str | None:
    """Resolve the effective dashboard-origin override for setup.

    Precedence (highest first):

    1. the explicit ``--dashboard-url`` flag;
    2. the ``SENTISEC_DASHBOARD_URL`` environment variable;
    3. ``None`` — let :func:`login` fall back to its config/derived chain
       (the existing ``edge.toml`` value, else ``""`` → derived from the
       control plane via :func:`_dashboard_base_for`).

    Unlike :func:`_resolve_control_plane_url` this does NOT read the
    existing config: ``login`` already defaults ``dashboard_url`` to the
    persisted value when this returns ``None`` (``dashboard_url is
    None`` → keep existing), so a bare re-run preserves a previously-set
    dashboard origin without us re-reading it here. Returning ``None``
    when there is neither a flag nor an env var keeps the prod default
    (derived ``app.`` host) untouched.
    """
    if flag:
        return flag.strip()
    env = os.environ.get(_DASHBOARD_URL_ENV)
    if env and env.strip():
        return env.strip()
    return None


def _daemon_log_path(home: Path | None = None) -> Path:
    """Resolve the daemon log path the launchd/systemd service writes to."""
    base = home if home is not None else Path(os.path.expanduser("~"))
    return base / ".sentisec" / "daemon.log"


def _report_daemon_down(config: EdgeConfig, *, home: Path | None = None) -> None:
    """Print a CLEAR, actionable error when the daemon did not come up.

    Replaces the old soft "it will start on your next `claude`" message
    (which falsely implied success). A daemon that fails to bind its port
    breaks the whole edge path: Codex sees ``error sending request to
    127.0.0.1:<proxy-port>`` and Claude capture is dead. So we name what
    failed and exactly how to diagnose it — check the daemon log, then try
    starting it by hand to see the real traceback.

    The hand-start command is the SAME entrypoint form the service uses
    (``<sentisec> edge __daemon``) so the user reproduces the exact failure
    the service hit. We resolve the installed entrypoint; if none resolves
    we show the running interpreter as a best-effort.
    """
    log_path = _daemon_log_path(home)
    entrypoint = resolve_entrypoint()
    if entrypoint:
        hand_start = f"{entrypoint} edge __daemon"
    else:
        hand_start = f"{sys.executable} -m sentisec_sdk.edge.daemon"
    console.print(
        "[red]✗ Setup wired the files, but the Sentisec daemon did NOT "
        f"start (no reply on port {config.daemon_port}).[/red]\n"
        "Until it starts, your Claude/Codex traffic is not protected.\n"
        "To fix it:\n"
        f"  1. Check the daemon log:  cat {log_path}\n"
        f"  2. Try starting it by hand to see the error:  {hand_start}\n"
        "  3. Then re-run `sentisec edge`.\n"
        "If the hand-start prints a Python error, share that output."
    )


def _run_setup(
    yes: bool,
    home: Path | None = None,
    *,
    control_plane_url: str | None = None,
    dashboard_url: str | None = None,
) -> None:
    """First-run guided setup: login -> detect -> confirm -> wire -> self-test.

    The default ``sentisec edge`` invocation when no config exists. Each
    step is the tested unit above; this is the thin orchestration the Typer
    callback delegates to.

    ``control_plane_url`` is the resolved override (flag > env > existing
    config) threaded into :func:`login` so the chosen plane is persisted to
    ``edge.toml`` at setup. ``dashboard_url`` is the parallel dashboard
    override (flag > env, else ``None`` → ``login`` keeps the existing /
    derives) threaded the same way so the pairing + watch links point at
    the right origin and the value is persisted. After the daemon is
    activated we wait for it to be ready (closing the self-test race) and
    verify it is serving the same control plane the config names (the
    version-skew guard).
    """
    console.print("[bold]Sentisec Edge — first-time setup[/bold]")
    plane = _resolve_control_plane_url(control_plane_url, home=home)
    dash = _resolve_dashboard_url(dashboard_url, home=home)
    config = login(home=home, control_plane_url=plane, dashboard_url=dash)
    detection = detect_agents(home)
    summary = render_confirm_summary(detection)
    console.print(summary)
    if not detection.claude.installed:
        # Without Claude there is nothing the Claude track can secure;
        # Codex alone is not yet a standalone setup path.
        raise typer.Exit(code=1)
    wire_codex_now = should_wire_codex(detection.codex)
    if detection.codex.installed and not wire_codex_now:
        # Codex present but in apikey mode / not logged in — skip it
        # gracefully with a clear reason (the demo's no-key path is the
        # ChatGPT-subscription mode only).
        console.print(
            "[yellow]Codex detected but not secured — only ChatGPT-"
            "subscription mode is wired (yours is in API-key mode or not "
            "logged in).[/yellow]"
        )
    if not yes:
        typer.confirm("Proceed?", default=True, abort=True)
    wire_claude(config, home=home)
    secured = ["claude"]
    if wire_codex_now:
        wire_codex(config, home=home)
        secured.append("codex")
    activate_daemon_service(home=home)
    # Wait for the daemon to bind its port BEFORE the self-test instead of
    # racing its startup. The healthz body also feeds the version-skew guard.
    health_body = wait_for_daemon_ready(config.daemon_port)
    if health_body is not None:
        # The daemon reads edge.toml once at boot; if a prior daemon was
        # already running it may be on a stale control plane — fix it once.
        ensure_control_plane_alignment(config, health_body, home=home)
    ok = self_test(config.daemon_port) if health_body is not None else False
    use = " and ".join(f"`{name}`" for name in secured)
    if ok:
        console.print(
            f"[green]✓ You're protected. Use {use} as before.[/green]"
        )
    else:
        # PREFLIGHT FAILURE: the daemon did not answer /healthz within the
        # readiness budget (health_body is None) or the self-test could not
        # round-trip. This is NOT a soft "it'll start later" — a dead daemon
        # means ports 45711/45712 are closed, Codex gets "error sending
        # request to 127.0.0.1:45712", and Claude capture is broken. Print a
        # CLEAR, actionable error instead of a false success.
        _report_daemon_down(config, home=home)
    console.print(f"Watch live: {session_link(config)}")
    if _dashboard_base_is_derived_local(
        config.control_plane_url, config.dashboard_url
    ):
        # No explicit --dashboard-url + a non-canonical (local/self-hosted)
        # control plane: the watch link reuses the proxy origin, which may
        # be the wrong port for the dashboard (dev :3001 vs proxy :8080).
        # Surface a short, non-fatal hint instead of crashing.
        console.print(
            "[yellow]Note: the dashboard may be on a different port than "
            "the control plane. If the link above 404s, re-run with "
            "`--dashboard-url <your-dashboard-origin>` (e.g. "
            "http://localhost:3001).[/yellow]"
        )


def _show_status(config: EdgeConfig, home: Path | None = None) -> None:
    """Render + print the status panel for a configured install."""
    detection = detect_agents(home)
    health = daemon_health(config.daemon_port)
    paused = paused_marker_path(home).is_file()
    body = render_status_panel(
        config, detection, health=health, paused=paused
    )
    console.print(Panel(body, title="Sentisec Edge", expand=False))


@app.callback(invoke_without_command=True)
def default(
    ctx: typer.Context,
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Skip the confirm prompt (CI/non-interactive)."
    ),
    control_plane_url: str | None = typer.Option(
        None,
        "--control-plane-url",
        help=(
            "Point uploads + gate calls at this control plane (e.g. "
            "http://127.0.0.1:8080 for a local end-to-end test). Persisted "
            "to ~/.sentisec/edge.toml. Falls back to "
            "$SENTISEC_CONTROL_PLANE_URL, then the existing config, then "
            "the hosted default."
        ),
    ),
    dashboard_url: str | None = typer.Option(
        None,
        "--dashboard-url",
        help=(
            "Point the pairing + watch links at this dashboard origin "
            "(e.g. http://localhost:3001 when the dashboard runs on a "
            "different port than the control-plane proxy). Persisted to "
            "~/.sentisec/edge.toml. Falls back to $SENTISEC_DASHBOARD_URL, "
            "then the existing config, then the origin derived from the "
            "control plane (prod api. -> app.)."
        ),
    ),
) -> None:
    """Default: first run -> guided setup; afterwards -> status panel."""
    if ctx.invoked_subcommand is not None:
        return
    config = _load_config_or_none()
    if config is None or not config.workspace_key:
        _run_setup(
            yes,
            control_plane_url=control_plane_url,
            dashboard_url=dashboard_url,
        )
    else:
        _show_status(config)


@app.command()
def status() -> None:
    """Show the Sentisec Edge status panel."""
    config = _load_config_or_none()
    if config is None or not config.workspace_key:
        console.print(
            "Sentisec Edge is not set up yet — run `sentisec edge` to start."
        )
        raise typer.Exit(code=1)
    _show_status(config)


@app.command()
def off() -> None:
    """Pause protection (keeps config). Resume with `sentisec edge on`."""
    marker = paused_marker_path()
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text("paused\n", encoding="utf-8")
    console.print(
        "[yellow]Protection paused.[/yellow] Run `sentisec edge on` to resume."
    )


@app.command()
def on() -> None:
    """Resume protection paused by `sentisec edge off`."""
    marker = paused_marker_path()
    if marker.exists():
        marker.unlink()
    console.print("[green]Protection resumed.[/green]")


@app.command(name="__daemon", hidden=True)
def daemon_command() -> None:
    """Run the thin edge daemon in the foreground (hidden process entry).

    This is the ENTRYPOINT-form daemon launcher: ``sentisec edge __daemon``
    runs :func:`sentisec_sdk.edge.daemon.run`. It exists so the daemon can
    be started via the installed ``sentisec`` console-script / zipapp
    (``python <sentisec> edge __daemon``) rather than ``python -m
    sentisec_sdk.edge.daemon`` — the ``-m`` form only works for pip/pipx
    installs (where ``sentisec_sdk`` is importable by a bare ``python``),
    NOT for the self-contained curl/zipapp install (where the package lives
    inside the zipapp, invisible to a bare ``python``). The launchd plist,
    systemd unit, and the wizard's Popen fallback all dispatch here.

    Hidden from ``--help`` — it is a machine-facing process entry, never a
    user command. Imported lazily so the user-facing edge commands do not
    pay the daemon's uvicorn/starlette import cost.
    """
    from . import daemon

    daemon.run()


@app.command()
def uninstall() -> None:
    """Remove the shim, PATH block, hooks, and daemon service — clean."""
    deactivate_daemon_service()
    unwire_all()
    # Remove the pause marker + config last so a re-run starts fresh.
    marker = paused_marker_path()
    if marker.exists():
        marker.unlink()
    cfg = config_path()
    if cfg.exists():
        cfg.unlink()
    console.print("[green]Sentisec Edge uninstalled — no residue left.[/green]")
