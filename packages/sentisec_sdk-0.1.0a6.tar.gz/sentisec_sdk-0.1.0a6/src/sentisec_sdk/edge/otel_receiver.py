"""Embedded OTLP/HTTP log receiver + raw-body file reader.

Claude Code's OpenTelemetry integration emits the model wire — the full
``/v1/messages`` request/response JSON, user prompts, and tool results —
as OTLP **log records** over ``http/protobuf`` to ``/v1/logs``. With
``OTEL_LOG_RAW_API_BODIES=file:<dir>`` the untruncated bodies are written
to disk under ``<dir>`` and the log record carries a ``body_ref``
attribute naming the file. This module decodes those log records,
correlates the ``api_request_body`` + ``api_response_body`` records into
one :class:`Turn`, and resolves ``body_ref`` files (bounded to
``wire_dir``) so the forensic record can carry the real model wire —
never touching the user's OAuth token.

Correlation: WIRE-DIR AS GROUND TRUTH (FIX-D)
=============================================
The original receiver keyed every turn on ``prompt.id`` and only emitted
when BOTH the request and response shared one ``prompt.id``. Empirically
(285 real ``~/.sentisec/wire`` bodies, May 2026) that join is UNRELIABLE
for the MAIN agent turn: Claude Code's ``api_request_body`` and
``api_response_body`` records for an opus/sonnet turn do NOT reliably
share a ``prompt.id`` — only the small non-streamed haiku
title-generation sidecar does. The result was that ONLY the title-gen
sidecar ever completed a turn; the real conversation never projected.

The fix correlates by a robust two-tier key:

1. **``prompt.id`` (primary).** When the request and response records
   carry the same ``prompt.id`` we pair them on it — the well-behaved
   case (title-gen + any future Claude build that fixes its semantics).
2. **``session.id`` FIFO (fallback).** When a response record's
   ``prompt.id`` has no pending request (or no ``prompt.id`` at all), we
   pair it to the oldest unpaired request in the SAME ``session.id``.
   Empirically per-session FIFO pairs api_request -> api_response with
   ~99.4% model-family agreement (2 / 319 mismatches, all concurrent
   sub-agent calls) — vastly better than global FIFO (6 / 337) because
   ``session.id`` removes the cross-session interleave. Both records
   carry ``session.id``, so this needs no body parse.

The real user-prompt TEXT does NOT come from the OTLP ``user_prompt``
record — that record's body is the OTLP EVENT NAME
(``claude_code.user_prompt``), not the prompt. The prompt text is
sourced from the ``UserPromptSubmit`` hook payload by the daemon and
attached via :meth:`OTLPReceiver.set_user_prompt`; a value equal to the
OTLP event name is rejected (:func:`_is_event_name_placeholder`).

Verified OTLP facts encoded here
================================
- Transport: ``http/protobuf``, path ``/v1/logs``. The body is a
  serialized :class:`ExportLogsServiceRequest`; the response is a
  serialized :class:`ExportLogsServiceResponse` with
  ``content-type: application/x-protobuf``, status ``200``.
- Each ``LogRecord`` carries ``.attributes`` (repeated
  ``KeyValue{key, value(AnyValue)}``), a ``.body`` (``AnyValue``), a
  ``.time_unix_nano``, and an event name from EITHER the newer
  ``LogRecord.event_name`` field OR an attribute keyed ``event.name``
  (older / Claude). We resolve robustly from both.
- Standard attributes include ``session.id``, ``user.email``, and
  ``prompt.id``. ``session.id`` is the durable join; ``prompt.id`` is
  the per-call join when present.
- The events we care about: ``api_request_body`` / ``api_response_body``
  (full ``/v1/messages`` JSON; file-mode -> ``body_ref`` path under
  ``wire_dir``), ``user_prompt``, ``tool_result``.

The decode is deliberately defensive — a malformed record never raises
out of :meth:`handle_export` (a partial OTLP batch must not 500 and break
the user's session). Filesystem access is bounded to ``wire_dir``: a
``body_ref`` that resolves outside ``wire_dir`` is refused (path-
traversal guard).
"""

from __future__ import annotations

import json
import os
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TypeAlias

from opentelemetry.proto.collector.logs.v1.logs_service_pb2 import (
    ExportLogsServiceRequest,
    ExportLogsServiceResponse,
)
from opentelemetry.proto.common.v1.common_pb2 import AnyValue
from opentelemetry.proto.logs.v1.logs_pb2 import LogRecord
from starlette.responses import Response

__all__ = [
    "DecodedLogRecord",
    "OTLPReceiver",
    "Turn",
    "TurnCompleteCallback",
    "decode_export_request",
    "is_sidecar_turn",
]

#: Fired once per turn the first time both the request and response
#: bodies are attached. The daemon wires this to the ``model_request``
#: emit path. Forward reference to :class:`Turn` resolved at runtime via
#: the deferred annotation.
TurnCompleteCallback: TypeAlias = Callable[["Turn"], None]

#: The OTLP EVENT NAMES Claude Code emits in the record ``body`` for the
#: prompt / turn events. These are the EVENT NAME, never the prompt text —
#: a ``user_prompt`` whose "text" equals one of these is the placeholder
#: bug FIX-D fixes (the daemon must source the real text from the
#: ``UserPromptSubmit`` hook instead). Used by
#: :func:`_is_event_name_placeholder` to reject the placeholder.
_OTLP_EVENT_NAME_PLACEHOLDERS = frozenset(
    {
        "claude_code.user_prompt",
        "claude_code.api_request",
        "claude_code.api_response",
        "claude_code.tool_result",
        "user_prompt",
        "api_request_body",
        "api_response_body",
        "tool_result",
    }
)


def _is_event_name_placeholder(value: str | None) -> bool:
    """True when ``value`` is an OTLP event-name placeholder, not real text.

    Claude Code's ``user_prompt`` OTLP record carries the event NAME
    (``claude_code.user_prompt``) in its body — NOT the prompt text. The
    real text rides on the ``UserPromptSubmit`` hook. Any candidate
    user-prompt string equal to a known event name is rejected so the
    placeholder never reaches the projected ``prompt_messages_json``.
    """
    if not value:
        return True
    return value.strip() in _OTLP_EVENT_NAME_PLACEHOLDERS


def _safe_json_obj(raw: str | None) -> dict[str, object] | None:
    """Best-effort parse ``raw`` into a dict; ``None`` on any failure."""
    if not raw:
        return None
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return None
    return obj if isinstance(obj, dict) else None


def is_sidecar_turn(*, request_body: str | None, response_body: str | None) -> bool:
    """True when a turn is a Claude Code utility sidecar, not the agent turn.

    Claude Code fires small utility model calls alongside the main agent
    loop — most visibly the haiku TITLE-GENERATION call that returns a
    ``{"title": "..."}`` JSON blob, plus other single-message no-tool
    helper calls. Empirically (real ``~/.sentisec/wire`` bodies) these are
    distinguishable from the MAIN opus/sonnet agent turn by:

    - a ``haiku`` model id, AND
    - a single-message request with NO ``tools`` catalog, OR a response
      whose only text block is a ``{"title": ...}`` JSON object.

    The MAIN agent turn is opus/sonnet with a multi-tool catalog and many
    messages. Returning ``True`` here lets the daemon SKIP projecting the
    sidecar as the conversation turn (it was masquerading as the whole
    session in the DB). A turn we cannot classify is treated as NOT a
    sidecar (fail toward projecting — better a stray helper row than a
    dropped real turn).
    """
    req = _safe_json_obj(request_body)
    resp = _safe_json_obj(response_body)

    model = ""
    resp_model = resp.get("model") if resp is not None else None
    req_model = req.get("model") if req is not None else None
    if isinstance(resp_model, str):
        model = resp_model
    elif isinstance(req_model, str):
        model = req_model

    is_haiku = "haiku" in model.lower()

    # Title-gen marker: the response's first/only text block is a
    # ``{"title": ...}`` JSON object. Model-independent (robust even if a
    # future build uses a different model for title-gen).
    if resp is not None:
        content = resp.get("content")
        if isinstance(content, list):
            text_blocks: list[str] = []
            for b in content:
                if isinstance(b, dict) and b.get("type") == "text":
                    text = b.get("text")
                    if isinstance(text, str):
                        text_blocks.append(text)
            if len(text_blocks) == 1 and text_blocks[0].lstrip().startswith(
                '{"title"'
            ):
                return True

    # Haiku helper call with a single message and no tool catalog — the
    # one-shot summarisation / quota / title sidecars. The main agent turn
    # always carries the tool catalog.
    if is_haiku and req is not None:
        messages = req.get("messages")
        has_tools = isinstance(req.get("tools"), list) and bool(req.get("tools"))
        single_msg = isinstance(messages, list) and len(messages) <= 1
        if single_msg and not has_tools:
            return True

    return False

_PROTOBUF_CONTENT_TYPE = "application/x-protobuf"

# Attribute keys we lift onto the decoded record. ``event.name`` is the
# fallback event-name carrier for proto versions / Claude builds that
# don't set ``LogRecord.event_name``.
_ATTR_EVENT_NAME = "event.name"
_ATTR_PROMPT_ID = "prompt.id"
_ATTR_SESSION_ID = "session.id"
_ATTR_USER_EMAIL = "user.email"
_ATTR_BODY_REF = "body_ref"


def _anyvalue_to_python(value: AnyValue) -> object:
    """Flatten an OTLP ``AnyValue`` to a plain Python value.

    Covers the scalar variants (string / bool / int / double / bytes) and
    recurses one level into array / kvlist. Returns ``None`` for an unset
    value.
    """
    which = value.WhichOneof("value")
    if which == "string_value":
        return value.string_value
    if which == "bool_value":
        return value.bool_value
    if which == "int_value":
        return value.int_value
    if which == "double_value":
        return value.double_value
    if which == "bytes_value":
        return value.bytes_value
    if which == "array_value":
        return [_anyvalue_to_python(v) for v in value.array_value.values]
    if which == "kvlist_value":
        return {
            kv.key: _anyvalue_to_python(kv.value)
            for kv in value.kvlist_value.values
        }
    return None


def _flatten_attributes(record: LogRecord) -> dict[str, object]:
    """Flatten a ``LogRecord``'s repeated ``KeyValue`` attrs to a dict."""
    out: dict[str, object] = {}
    for kv in record.attributes:
        out[kv.key] = _anyvalue_to_python(kv.value)
    return out


@dataclass
class DecodedLogRecord:
    """A single decoded OTLP log record, flattened to the fields we use.

    ``event_name`` is resolved from ``LogRecord.event_name`` first, then
    the ``event.name`` attribute. ``body`` is the record body's string
    form (the inline-mode raw body, or a small marker in file-mode).
    ``attributes`` is the full flattened attr dict for forward-compat.
    """

    event_name: str
    prompt_id: str | None
    session_id: str | None
    user_email: str | None
    body_ref: str | None
    body: str | None
    time_unix_nano: int
    attributes: dict[str, object] = field(default_factory=dict)


def _decode_record(record: LogRecord) -> DecodedLogRecord:
    """Decode one ``LogRecord`` into a :class:`DecodedLogRecord`."""
    attrs = _flatten_attributes(record)

    # Event name: prefer the newer field, fall back to the attribute.
    event_name = record.event_name or ""
    if not event_name:
        attr_event = attrs.get(_ATTR_EVENT_NAME)
        if isinstance(attr_event, str):
            event_name = attr_event

    def _str_attr(key: str) -> str | None:
        v = attrs.get(key)
        return v if isinstance(v, str) and v else None

    body_str: str | None = None
    if record.HasField("body"):
        body_val = _anyvalue_to_python(record.body)
        if isinstance(body_val, str):
            body_str = body_val
        elif body_val is not None:
            body_str = str(body_val)

    return DecodedLogRecord(
        event_name=event_name,
        prompt_id=_str_attr(_ATTR_PROMPT_ID),
        session_id=_str_attr(_ATTR_SESSION_ID),
        user_email=_str_attr(_ATTR_USER_EMAIL),
        body_ref=_str_attr(_ATTR_BODY_REF),
        body=body_str,
        time_unix_nano=record.time_unix_nano,
        attributes=attrs,
    )


def decode_export_request(body: bytes) -> list[DecodedLogRecord]:
    """Decode an OTLP ``ExportLogsServiceRequest`` to flat records.

    Walks ``resource_logs[].scope_logs[].log_records[]`` and decodes each
    record. A malformed protobuf body returns an empty list rather than
    raising — :meth:`OTLPReceiver.handle_export` must always reply ``200``
    (a 500 would surface to the user's Claude session).
    """
    try:
        request = ExportLogsServiceRequest.FromString(body)
    except Exception:
        return []

    records: list[DecodedLogRecord] = []
    for resource_logs in request.resource_logs:
        for scope_logs in resource_logs.scope_logs:
            for record in scope_logs.log_records:
                records.append(_decode_record(record))
    return records


@dataclass
class Turn:
    """The correlated model-wire for one Claude turn.

    Built incrementally as OTLP records arrive (they can arrive out of
    order across batches). ``request_body`` / ``response_body`` carry the
    resolved raw ``/v1/messages`` JSON (read from the ``body_ref`` file in
    file-mode, or inline). ``user_prompt`` carries the prompt text —
    sourced from the ``UserPromptSubmit`` hook by the daemon, NOT the OTLP
    ``user_prompt`` record (whose body is the event name, not the text).
    ``tool_results`` accumulates ``tool_result`` bodies.

    ``correlation_key`` is the stable per-turn key the receiver indexes on
    — the ``prompt.id`` when present, else a synthesised
    ``session.id``-FIFO key (FIX-D). It doubles as the ``source_event_id``
    idempotency seed.
    """

    #: The stable per-turn correlation key (``prompt.id`` or a synthesised
    #: ``session.id``-FIFO key). Renamed from the old ``prompt_id`` since
    #: the join is no longer always a ``prompt.id`` (FIX-D).
    correlation_key: str
    #: The ``prompt.id`` attribute when the records carried one (kept for
    #: forensics / debugging); ``None`` when the turn was paired by the
    #: ``session.id`` FIFO fallback.
    prompt_id: str | None = None
    session_id: str | None = None
    user_email: str | None = None
    user_prompt: str | None = None
    request_body: str | None = None
    response_body: str | None = None
    tool_results: list[str] = field(default_factory=list)
    #: ``time_unix_nano`` of the ``api_request_body`` / ``api_response_body``
    #: records — the per-turn latency is ``(response_ts - request_ts)``.
    #: Both ``None`` until the respective record arrives; the latency is
    #: only computed when both are present (see :meth:`Turn.latency_ms`).
    request_ts_nano: int | None = None
    response_ts_nano: int | None = None
    #: Flips ``True`` once the turn has been emitted as a ``model_request``
    #: event so a redelivered OTLP batch (the same turn arriving twice)
    #: does not re-emit. Belt-and-braces with the persistor's
    #: ``(session_id, turn_idx)`` idempotency.
    emitted: bool = False

    @property
    def source_event_id(self) -> str:
        """Stable idempotency id for this turn — ``session:correlation_key``.

        The cloud persistor uses this (with ``(session_id, turn_idx)``) so a
        redelivered batch never double-projects the same turn.
        """
        return f"{self.session_id or 'nosession'}:{self.correlation_key}"

    @property
    def is_sidecar(self) -> bool:
        """True when this turn is a Claude Code utility sidecar (title-gen ...).

        Delegates to :func:`is_sidecar_turn` on the resolved bodies so the
        daemon can SKIP projecting the sidecar as the conversation turn
        (FIX-D — the haiku title-gen was masquerading as the whole
        session in the DB).
        """
        return is_sidecar_turn(
            request_body=self.request_body, response_body=self.response_body
        )

    @property
    def is_complete(self) -> bool:
        """True once BOTH the request and response bodies are attached."""
        return self.request_body is not None and self.response_body is not None

    @property
    def latency_ms(self) -> int | None:
        """Per-turn latency in ms, or ``None`` when either timestamp is absent.

        Computed from the OTLP record ``time_unix_nano`` deltas. A
        negative delta (clock skew across batches) is clamped to ``None``
        rather than returning a nonsense negative latency.
        """
        if self.request_ts_nano is None or self.response_ts_nano is None:
            return None
        delta_ns = self.response_ts_nano - self.request_ts_nano
        if delta_ns < 0:
            return None
        return int(delta_ns / 1_000_000)


class OTLPReceiver:
    """Embedded OTLP/HTTP receiver + bounded ``body_ref`` file reader.

    Holds a per-turn :class:`Turn` index keyed on a stable
    ``correlation_key`` (``prompt.id`` when present, else a synthesised
    ``session.id``-FIFO key). Records arriving on ``/v1/logs`` are decoded
    and folded into the matching turn; file-mode ``body_ref`` paths are
    resolved (bounded to ``wire_dir``) and the raw body attached.

    Correlation (FIX-D, see module docstring)
    -----------------------------------------
    - ``api_request_body`` opens (or reuses) a turn. It is queued in its
      ``session.id`` FIFO so a later un-matched response can pair to it.
    - ``api_response_body`` pairs to a turn by ``prompt.id`` when that key
      already has a request; otherwise it pops the oldest unpaired request
      in the SAME ``session.id`` (the per-session FIFO fallback). This is
      what fixes the MAIN agent turn never completing — its request and
      response do not reliably share a ``prompt.id``.

    Filesystem access is bounded: a ``body_ref`` whose normalised real
    path is not under ``wire_dir`` is refused (path-traversal guard).
    """

    def __init__(
        self,
        *,
        wire_dir: str,
        on_turn_complete: TurnCompleteCallback | None = None,
    ) -> None:
        # Normalise wire_dir once so the per-record traversal guard is a
        # cheap prefix check.
        self._wire_dir = os.path.abspath(wire_dir)
        self._turns: dict[str, Turn] = {}
        #: Per-``session.id`` FIFO of correlation keys for turns that have a
        #: request body but not yet a response. A response with no
        #: ``prompt.id`` match pops the oldest entry here for its session.
        #: ``OrderedDict`` keyed by correlation_key gives O(1) FIFO + O(1)
        #: removal when a ``prompt.id`` match consumes a mid-queue entry.
        self._pending_requests: dict[str, OrderedDict[str, None]] = {}
        #: Monotonic counter making the synthesised FIFO correlation key
        #: unique even when ``session.id`` is absent / repeated.
        self._synth_seq = 0
        #: Latest real user-prompt text per ``session.id`` (set via
        #: :meth:`set_user_prompt` from the ``UserPromptSubmit`` hook),
        #: stamped onto the next turn's request body arrival.
        self._latest_prompt: dict[str, str] = {}
        #: Optional callback fired EXACTLY ONCE per turn, the first time
        #: the turn has both its request and response bodies attached. The
        #: daemon wires this to the ``model_request`` emit path (per-turn
        #: usage → event buffer → cloud projection). ``None`` (the
        #: forensic-only / pure-decode shape the receiver unit tests use)
        #: means turns are correlated but no event fires.
        self._on_turn_complete = on_turn_complete

    @property
    def wire_dir(self) -> str:
        return self._wire_dir

    def turns(self) -> dict[str, Turn]:
        """Return the per-turn index keyed on ``correlation_key`` (read-only)."""
        return self._turns

    def set_user_prompt(self, session_id: str, prompt: str) -> None:
        """Attach the real user-prompt TEXT (from the ``UserPromptSubmit`` hook).

        FIX-D: the OTLP ``user_prompt`` record carries the event NAME, not
        the prompt text. The daemon sources the real text from the
        ``UserPromptSubmit`` hook and calls this so the NEXT turn opened
        for ``session_id`` carries it. A value equal to an OTLP event-name
        placeholder is rejected (never overwrites a real prompt with the
        bug's placeholder).

        We stash the latest prompt per session and stamp it onto a turn
        when that turn's request body arrives (a turn is the model call
        that follows the user's prompt). The most recent prompt for a
        session wins until consumed by the next request.
        """
        if _is_event_name_placeholder(prompt):
            return
        self._latest_prompt[session_id] = prompt

    def _consume_prompt(self, session_id: str | None) -> str | None:
        """Pop + return the latest real user prompt for ``session_id``."""
        if not session_id:
            return None
        return self._latest_prompt.pop(session_id, None)

    def handle_export(self, body: bytes) -> Response:
        """Decode an OTLP export body, ingest it, and return the 200 reply.

        Always returns a serialized empty :class:`ExportLogsServiceResponse`
        with status ``200`` and ``content-type: application/x-protobuf`` —
        the OTLP success contract. Decode / file-read failures are
        swallowed (the user's session must never break on a telemetry
        hiccup; fail-open posture).

        After folding every record, any turn that just became complete
        (both bodies present) AND has not yet been emitted fires the
        :data:`on_turn_complete` callback once — this is the per-turn
        ``model_request`` emit seam. The callback runs inside its own
        fail-open guard so a projection error never breaks the 200 reply.
        """
        records = decode_export_request(body)
        for record in records:
            try:
                self._ingest(record)
            except Exception:
                # Per-record fail-open — one bad record never drops the
                # whole batch's reply.
                continue
        self._emit_completed_turns()
        return Response(
            content=ExportLogsServiceResponse().SerializeToString(),
            media_type=_PROTOBUF_CONTENT_TYPE,
        )

    def _emit_completed_turns(self) -> None:
        """Fire the completion callback for newly-complete, un-emitted turns.

        A turn becomes complete when both its request and response bodies
        are attached (they can arrive in separate OTLP batches). Each turn
        emits at most once — :attr:`Turn.emitted` is the guard so a
        redelivered batch never re-fires. No callback wired → no-op.
        """
        if self._on_turn_complete is None:
            return
        for turn in self._turns.values():
            if turn.is_complete and not turn.emitted:
                turn.emitted = True
                try:
                    self._on_turn_complete(turn)
                except Exception:
                    # Fail-open: a projection error must not break the
                    # user's session. The turn stays marked emitted so we
                    # do not retry-storm on a persistent error.
                    continue

    def _ingest(self, record: DecodedLogRecord) -> None:
        """Fold one decoded record into a turn (FIX-D correlation).

        Dispatches on the OTLP event name:

        - ``api_request_body`` opens a turn (keyed on ``prompt.id`` when
          present, else a synthesised key) and queues it in its
          ``session.id`` FIFO so a later un-matched response can pair to it.
          The latest real user prompt for the session (from the
          ``UserPromptSubmit`` hook) is stamped here.
        - ``api_response_body`` pairs to a turn by ``prompt.id`` if that key
          has a pending request, else pops the oldest pending request in
          the SAME ``session.id`` (the per-session FIFO fallback).
        - ``user_prompt`` is IGNORED for the prompt text (its body is the
          OTLP event name, not the text — the daemon supplies the real
          text via :meth:`set_user_prompt`).
        - ``tool_result`` appends to whatever turn is currently open for
          the session (best-effort forensic enrichment).
        """
        event = record.event_name

        # Resolve the raw body once: file-mode body_ref takes precedence;
        # fall back to the inline body when no body_ref is present.
        raw_body = self._resolve_body(record)

        if event == "api_request_body":
            self._ingest_request(record, raw_body)
        elif event == "api_response_body":
            self._ingest_response(record, raw_body)
        elif event == "user_prompt":
            # The OTLP user_prompt body is the EVENT NAME, not the prompt
            # text (FIX-D). Do NOT use it as the prompt. The real text
            # arrives via set_user_prompt() from the UserPromptSubmit hook.
            return
        elif event == "tool_result":
            self._ingest_tool_result(record, raw_body)

    def _ingest_request(
        self, record: DecodedLogRecord, raw_body: str | None
    ) -> None:
        """Fold an ``api_request_body`` record — opens / reuses a turn."""
        key = record.prompt_id or self._synth_key(record.session_id)
        turn = self._turns.get(key)
        if turn is None:
            turn = Turn(
                correlation_key=key,
                prompt_id=record.prompt_id,
                session_id=record.session_id,
            )
            self._turns[key] = turn
        if record.session_id and turn.session_id is None:
            turn.session_id = record.session_id
        if record.user_email and turn.user_email is None:
            turn.user_email = record.user_email

        turn.request_body = raw_body
        if record.time_unix_nano:
            turn.request_ts_nano = record.time_unix_nano

        # Stamp the latest real user prompt for this session (from the
        # UserPromptSubmit hook). The first model call after a prompt is
        # the turn that carries it; sub-calls in the same turn get None
        # (the consume pops it) which is correct — they are not user turns.
        prompt = self._consume_prompt(turn.session_id)
        if prompt is not None:
            turn.user_prompt = prompt

        # Queue this turn in its session FIFO so an un-matched response can
        # pair to it. Skip if it already has a response (request re-delivered).
        if turn.response_body is None:
            queue = self._pending_requests.setdefault(
                turn.session_id or "", OrderedDict()
            )
            queue[key] = None

    def _ingest_response(
        self, record: DecodedLogRecord, raw_body: str | None
    ) -> None:
        """Fold an ``api_response_body`` record — pairs to a pending request.

        Primary join: ``prompt.id`` (when that key already has a pending
        request). Fallback: pop the oldest pending request in the same
        ``session.id`` (per-session FIFO). When no pending request exists
        at all (response arrived first), open a response-only turn so the
        request can attach to it later.
        """
        session = record.session_id or ""
        queue = self._pending_requests.get(session)

        turn: Turn | None = None
        # Primary: prompt.id match against a pending request.
        if record.prompt_id and record.prompt_id in self._turns:
            cand = self._turns[record.prompt_id]
            if cand.response_body is None:
                turn = cand
                if queue is not None:
                    queue.pop(record.prompt_id, None)
        # Fallback: per-session FIFO — oldest unpaired request in session.
        if turn is None and queue:
            oldest_key, _ = queue.popitem(last=False)
            turn = self._turns.get(oldest_key)
        # Last resort: response with no pending request — open a
        # response-only turn keyed on prompt.id or a synth key.
        if turn is None:
            key = record.prompt_id or self._synth_key(record.session_id)
            turn = self._turns.get(key)
            if turn is None:
                turn = Turn(
                    correlation_key=key,
                    prompt_id=record.prompt_id,
                    session_id=record.session_id,
                )
                self._turns[key] = turn

        if record.session_id and turn.session_id is None:
            turn.session_id = record.session_id
        if record.user_email and turn.user_email is None:
            turn.user_email = record.user_email
        turn.response_body = raw_body
        if record.time_unix_nano:
            turn.response_ts_nano = record.time_unix_nano

    def _ingest_tool_result(
        self, record: DecodedLogRecord, raw_body: str | None
    ) -> None:
        """Append a ``tool_result`` body to the open turn for the session.

        Best-effort forensic enrichment: attach to the oldest pending
        request's turn for the session, else the most recently created
        turn for the session, else drop. tool_result correlation is not
        load-bearing for the model_request projection.
        """
        body = raw_body if raw_body is not None else record.body
        if body is None:
            return
        session = record.session_id or ""
        queue = self._pending_requests.get(session)
        if queue:
            # oldest pending request's turn
            oldest_key = next(iter(queue))
            turn = self._turns.get(oldest_key)
            if turn is not None:
                turn.tool_results.append(body)
                return
        # Fall back to the latest turn for this session.
        for turn in reversed(list(self._turns.values())):
            if turn.session_id == record.session_id:
                turn.tool_results.append(body)
                return

    def _synth_key(self, session_id: str | None) -> str:
        """Make a unique synthesised correlation key for a prompt-less turn."""
        self._synth_seq += 1
        return f"synth:{session_id or 'nosession'}:{self._synth_seq}"

    def _resolve_body(self, record: DecodedLogRecord) -> str | None:
        """Resolve a record's raw body — file-mode ``body_ref`` or inline.

        File-mode: read the ``body_ref`` file (bounded to ``wire_dir``).
        Inline: return ``record.body``. Returns ``None`` when neither is
        available or the file read fails / is out of bounds.
        """
        if record.body_ref:
            content = self._read_body_ref(record.body_ref)
            if content is not None:
                return content
        return record.body

    def _read_body_ref(self, body_ref: str) -> str | None:
        """Read a ``body_ref`` file, bounded to ``wire_dir``.

        Refuses any path whose real (abspath-normalised) form is not under
        ``wire_dir`` — a path-traversal guard so a malformed / hostile
        ``body_ref`` cannot read arbitrary disk. Returns the file's UTF-8
        text, or ``None`` on any failure (missing file, out-of-bounds,
        decode error). The guard NEVER raises.
        """
        try:
            # The body_ref may be absolute (file-mode writes the full
            # path) or relative to wire_dir.
            if os.path.isabs(body_ref):
                candidate = os.path.abspath(body_ref)
            else:
                candidate = os.path.abspath(
                    os.path.join(self._wire_dir, body_ref)
                )
            # Path-traversal guard: the resolved path must be under
            # wire_dir. Compare with a trailing-sep prefix so
            # ``/wire_dir_evil`` does not pass for ``/wire_dir``.
            wire_prefix = self._wire_dir.rstrip(os.sep) + os.sep
            if not candidate.startswith(wire_prefix) and candidate != self._wire_dir:
                return None
            if not os.path.isfile(candidate):
                return None
            with open(candidate, encoding="utf-8") as fh:
                return fh.read()
        except Exception:
            return None
