"""Sentisec Edge thin daemon — local HTTP server (Option B).

The daemon is the only new long-running process the edge demo adds; it
runs entirely on the user's machine (``127.0.0.1``). It exposes:

- ``POST /hooks`` — the Claude Code hook endpoint. Dispatches on
  ``hook_event_name``: ``PreToolUse`` forwards the raw payload to the
  HOSTED gate (``POST /v1/edge/gate``) and wraps the verdict; the rest
  are capture events buffered for upload.
- ``POST /v1/logs`` — the embedded OTLP/HTTP (``http/protobuf``) receiver
  for ``OTEL_LOG_RAW_API_BODIES`` enrichment.
- ``GET /healthz`` — liveness, surfaced to the wizard self-test + the
  shim's "is the daemon up?" check.

Thin client — NO engines
========================

Unlike the platform package's ``sentisec.edge.daemon`` (which constructed
an :class:`EdgePipeline` per session — the real server-side analysis
engines), this daemon holds NO engines and NO per-session pipeline. The
PreToolUse decision comes from the HOSTED gate over HTTP; the only
per-session state the daemon keeps is a :class:`SessionTracker` — the
session-opened flag (so ``session_started`` is emitted once) and a local
step counter for capture-event ordering. It imports NOTHING from the
``sentisec`` (platform) package.

This module owns process lifecycle + the ASGI app factory
(:func:`build_daemon_app`) and a thin process entry (:func:`run`). The
gate-forward logic lives in :mod:`sentisec_sdk.edge.claude_hooks` +
:mod:`sentisec_sdk.edge.gate_client`; the event dicts in
:mod:`sentisec_sdk.edge.events`; the OTLP decode in
:mod:`sentisec_sdk.edge.otel_receiver`.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import httpx
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from .capture import capture_full_enabled
from .config import EdgeConfig
from .content import extract_claude_content
from .event_upload import EventUploader
from .events import (
    EventBuffer,
    build_model_request_event,
    build_session_started_event,
)
from .usage import parse_turn_usage

if TYPE_CHECKING:
    from .otel_receiver import OTLPReceiver, Turn

__all__ = [
    "DRAIN_INTERVAL_S",
    "SessionTracker",
    "build_daemon_app",
    "codex_wired",
    "drain_once",
    "run",
]

_logger = logging.getLogger("sentisec_sdk.edge.daemon")

#: How often the background drain task flushes the :class:`EventBuffer` to
#: the cloud. Small so the dashboard shows edge sessions near-live; the
#: uploader's own retry/backoff + offline spool absorb a flap, so a tight
#: interval here is cheap (an empty drain is a no-op httpx call).
DRAIN_INTERVAL_S = 1.5


class SessionTracker:
    """Per-``session_id`` thin state: open flag + step counter + gate deps.

    The thin daemon holds one tracker. It owns NO engine objects — the
    only per-session state it keeps is:

    - whether the one-per-session ``session_started`` event has been
      emitted (keyed off the first event seen for a ``session_id``);
    - a monotonic step counter per session (so the capture ``tool_call`` /
      ``verdict`` events render in order on the dashboard timeline).

    It also carries the config-derived gate target (``control_plane_url``
    + ``workspace_key``) and an optional injected gate
    :class:`httpx.Client`, which the hook handler reads to forward
    ``PreToolUse`` to the hosted gate.

    When constructed without an :class:`EventBuffer` (the pure-gate unit
    tests) the capture pushes are no-ops — the gate forward still works,
    nothing is enqueued.
    """

    def __init__(
        self,
        config: EdgeConfig,
        *,
        events: EventBuffer | None = None,
        gate_client: httpx.Client | None = None,
        receiver: OTLPReceiver | None = None,
    ) -> None:
        self._config = config
        self._events = events
        self._gate_client = gate_client
        self._opened: set[str] = set()
        self._steps: dict[str, int] = {}
        #: Monotonic per-``session_id`` ``model_request`` turn ordinal.
        #: Each completed OTel turn (one ``api_request_body`` +
        #: ``api_response_body`` pair) is assigned the next value; the
        #: cloud persistor uses ``(session_id, turn_idx)`` as the
        #: projection idempotency key so a redelivered batch never
        #: double-projects.
        self._turn_idx: dict[str, int] = {}
        #: The OTLP receiver, so the ``UserPromptSubmit`` capture can hand
        #: the real prompt TEXT to the turn correlation (FIX-D — the OTLP
        #: ``user_prompt`` body is the event name, not the text). Wired
        #: after construction by :func:`build_daemon_app` (the receiver
        #: needs the tracker's ``record_model_request`` callback first, so
        #: the two are wired in two steps).
        self._receiver = receiver

    @property
    def config(self) -> EdgeConfig:
        return self._config

    @property
    def events(self) -> EventBuffer | None:
        return self._events

    def set_receiver(self, receiver: OTLPReceiver) -> None:
        """Wire the OTLP receiver after construction (FIX-D prompt hand-off)."""
        self._receiver = receiver

    def set_user_prompt(self, session_id: str, prompt: str) -> None:
        """Hand the REAL user-prompt TEXT to the OTLP turn correlation.

        FIX-D: the OTLP ``user_prompt`` record body is the event NAME, not
        the text, so the model_request projection sourced a placeholder.
        The ``UserPromptSubmit`` hook ``prompt`` IS the real text; the
        receiver stamps it onto the next turn's request. A no-op when no
        receiver is wired (the pure-gate / pre-wiring shape) or the prompt
        is empty.
        """
        if self._receiver is not None and prompt:
            self._receiver.set_user_prompt(session_id, prompt)

    @property
    def control_plane_url(self) -> str:
        return self._config.control_plane_url

    @property
    def workspace_key(self) -> str:
        return self._config.workspace_key

    @property
    def gate_client(self) -> httpx.Client | None:
        """The injected gate :class:`httpx.Client` (None -> per-call client)."""
        return self._gate_client

    def push(self, event: dict[str, Any]) -> bool:
        """Enqueue a capture event (no-op when no buffer is wired)."""
        if self._events is None:
            return False
        return self._events.push(event)

    def open_session(self, session_id: str) -> None:
        """Emit the one-per-session ``session_started`` event (once).

        Keyed off the first event seen for a ``session_id``. A no-op on
        subsequent events for the same session, and a no-op when no event
        buffer is wired.
        """
        if session_id in self._opened:
            return
        self._opened.add(session_id)
        if self._events is None:
            return
        self._events.push(
            build_session_started_event(session_id=session_id)
        )

    def next_step(self, session_id: str) -> int:
        """Return + advance the per-session step counter (0-based)."""
        step = self._steps.get(session_id, 0)
        self._steps[session_id] = step + 1
        return step

    def record_model_request(self, turn: Turn) -> None:
        """Build + enqueue a ``model_request`` event from a completed OTel turn.

        Wired as the :class:`~sentisec_sdk.edge.otel_receiver.OTLPReceiver`
        ``on_turn_complete`` callback (Gateway visibility wave). When a
        turn has both its ``api_request_body`` and ``api_response_body``
        attached, this parses the per-turn USAGE (tokens / model /
        stop_reason / tool_use count / latency) from the LOCAL raw bodies
        and enqueues a ``model_request`` event carrying that usage +
        BOUNDED previews. The full raw bodies NEVER leave the machine
        (design §9).

        Token-custody invariant: the parsed usage + the bounded previews
        are the ONLY data that rides to the cloud. The event carries no
        ``Authorization`` header, no provider token, and no full raw body —
        :func:`~sentisec_sdk.edge.events.build_model_request_event` only
        takes scalar usage fields + the two bounded preview strings.

        No-op when no event buffer is wired (pure-gate unit tests) or the
        turn has no resolvable ``session_id``.
        """
        if self._events is None:
            return
        session_id = turn.session_id
        if not session_id:
            return
        # FIX-D: SKIP Claude Code utility sidecars (the haiku title-gen +
        # one-shot helper calls). Before the fix the title-gen sidecar was
        # the ONLY turn that completed, so the DB showed ``{"title": ...}``
        # as the whole conversation. The real opus/sonnet agent turns now
        # complete via the session-FIFO correlation; the sidecars must not
        # masquerade as conversation turns, so they are dropped here.
        if turn.is_sidecar:
            return
        # Open the session if this turn is the first event seen for it
        # (the gateway-visibility path can fire before any hook capture).
        self.open_session(session_id)

        turn_idx = self._turn_idx.get(session_id, 0)
        self._turn_idx[session_id] = turn_idx + 1

        usage = parse_turn_usage(
            request_body=turn.request_body,
            response_body=turn.response_body,
        )
        # FIX-D: the prompt preview is the REAL user prompt (from the
        # UserPromptSubmit hook, stamped onto the turn) or, failing that,
        # the last user message text from the request body — NEVER the OTLP
        # event-name placeholder.
        prompt_preview = turn.user_prompt or _request_text_preview(
            turn.request_body
        )
        response_preview = _response_text_preview(turn.response_body)

        # Content-capture posture (founder decision): full structured
        # content rides only when the configured upload target is local /
        # self-hosted (or the operator forced it with
        # ``SENTISEC_EDGE_CAPTURE_CONTENT=full``). Otherwise only the
        # bounded previews ride — the pre-wave shape. The token invariant
        # is independent of this flag: the parsed content is token-scrubbed
        # regardless (design §9), and the upload choke point re-scrubs.
        capture_full = capture_full_enabled(self._config.control_plane_url)
        content = extract_claude_content(
            request_body=turn.request_body,
            response_body=turn.response_body,
            capture_full=capture_full,
        )

        self._events.push(
            build_model_request_event(
                session_id=session_id,
                turn_idx=turn_idx,
                model=usage.model,
                provider="anthropic",
                input_tokens=usage.input_tokens,
                output_tokens=usage.output_tokens,
                total_tokens=usage.total_tokens,
                latency_ms=turn.latency_ms,
                stop_reason=usage.stop_reason,
                status=usage.status,
                tool_uses_count=usage.tool_uses_count,
                prompt_preview=prompt_preview,
                response_preview=response_preview,
                system_prompt=content.system_prompt,
                messages=content.messages,
                tools=content.tools,
                tool_choice=content.tool_choice,
                decoding_params=content.decoding_params,
                response_content=content.response_content,
                raw_request=content.raw_request,
                raw_response=content.raw_response,
                source_event_id=turn.source_event_id,
            )
        )


def _request_text_preview(request_body: str | None) -> str:
    """Best-effort last-user-message text from a Claude request body.

    Reads ``messages[-1].content`` (string or content-block array) from
    the LOCAL ``api_request_body`` JSON so the ``model_request`` preview
    shows what the user actually asked when the OTel ``user_prompt`` event
    was absent. Returns the empty string on any parse failure — a preview
    is best-effort; the full body stays local.
    """
    import json as _json

    if not request_body:
        return ""
    try:
        body = _json.loads(request_body)
    except (ValueError, TypeError):
        return ""
    if not isinstance(body, dict):
        return ""
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        return ""
    last = messages[-1]
    if not isinstance(last, dict):
        return ""
    content = last.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and isinstance(block.get("text"), str):
                parts.append(block["text"])
        return " ".join(parts)
    return ""


def _response_text_preview(response_body: str | None) -> str:
    """Best-effort assistant text from a Claude response body.

    Concatenates the ``text`` of every ``text`` block in the response
    ``content`` array (LOCAL ``api_response_body`` JSON). Returns the
    empty string on any parse failure. The bounded form is what rides to
    the cloud; the full body stays local (design §9).
    """
    import json as _json

    if not response_body:
        return ""
    try:
        body = _json.loads(response_body)
    except (ValueError, TypeError):
        return ""
    if not isinstance(body, dict):
        return ""
    content = body.get("content")
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text")
            if isinstance(text, str):
                parts.append(text)
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Upload drain — close the buffer->cloud loop
# ---------------------------------------------------------------------------


async def drain_once(uploader: EventUploader) -> int:
    """Drain the buffer (+ spool) and upload once. Returns events uploaded.

    The :class:`EventUploader` is synchronous (httpx ``Client`` +
    ``time.sleep`` backoff), so its :meth:`EventUploader.flush` is run off
    the event loop via :func:`asyncio.to_thread` so a slow or retrying
    upload never stalls the daemon's gate endpoint.

    This is the single "drain once + upload" unit the background task
    loops on and the tests call directly (no timer, no real network).
    """
    return await asyncio.to_thread(uploader.flush)


async def _drain_loop(uploader: EventUploader) -> None:
    """Periodically drain + upload until cancelled (the background task).

    Loops :func:`drain_once` every :data:`DRAIN_INTERVAL_S`. A failed
    upload is NOT fatal — the uploader spools offline batches to disk and
    replays them on the next drain — so this loop only ever exits on
    cancellation (daemon shutdown). Any unexpected error is logged and
    swallowed so a single bad cycle does not kill the uploader.
    """
    while True:
        try:
            await asyncio.sleep(DRAIN_INTERVAL_S)
            await drain_once(uploader)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover — defensive
            _logger.warning("event=edge_drain_cycle_error err=%r", exc)


# ---------------------------------------------------------------------------
# ASGI app factory
# ---------------------------------------------------------------------------


def build_daemon_app(
    config: EdgeConfig,
    *,
    events: EventBuffer | None = None,
    gate_client: httpx.Client | None = None,
) -> Starlette:
    """Build the thin daemon's Starlette ASGI app.

    Routes:

    - ``POST /hooks`` — Claude Code hook dispatch (gate forward + capture).
    - ``POST /v1/logs`` — OTLP/HTTP receiver.
    - ``GET /healthz`` — liveness.

    The app stashes the :class:`SessionTracker` + the OTLP receiver on
    ``app.state`` so the route handlers + the wizard self-test can reach
    them.

    Parameters
    ----------
    config:
        The loaded :class:`EdgeConfig` (port, wire dir, workspace key,
        control-plane url).
    events:
        Optional :class:`EventBuffer`. When provided, capture events are
        enqueued for the upload client; when ``None`` the daemon is a
        pure-gate-forward server (capture is a no-op) — the shape the gate
        unit tests use.
    gate_client:
        Optional injected gate :class:`httpx.Client` (tests pass a
        ``httpx.MockTransport``-backed client so ``PreToolUse`` forwards
        never hit the network). When ``None``, the hook handler creates a
        per-call client.

    Upload lifecycle
    ----------------
    When an ``events`` buffer is wired AND ``config.workspace_key`` is
    non-empty, a Starlette lifespan starts a background drain task that
    flushes the buffer to ``config.control_plane_url`` every
    :data:`DRAIN_INTERVAL_S` (via :class:`EventUploader`, which owns the
    scrub + offline spool + retry). On shutdown the task is cancelled and
    a final best-effort drain runs so a clean stop does not strand
    captured events. When ``workspace_key`` is empty (pre-login mode) the
    uploader is NOT started — the daemon still buffers, and a one-line
    warning notes events will not upload until login mints a key. When
    ``events is None`` (the pure-gate unit-test shape) there is nothing to
    drain and the lifespan is a no-op.
    """
    # Local import — the OTLP receiver imports opentelemetry-proto, which
    # we keep out of the daemon module's import-time graph until the app
    # is actually built.
    from .otel_receiver import OTLPReceiver

    tracker = SessionTracker(config, events=events, gate_client=gate_client)
    # Wire the OTel receiver's per-turn completion callback to the
    # tracker's ``model_request`` emit path (Gateway visibility wave).
    # When a turn completes (request + response bodies present), the
    # receiver fires this with the LOCAL raw bodies; the tracker parses
    # usage + bounded previews and enqueues a ``model_request`` event for
    # the cloud projection (-> ``llm_request_logs``). In pure-gate mode
    # (events=None) the tracker method is a no-op, so wiring it
    # unconditionally is safe.
    receiver = OTLPReceiver(
        wire_dir=config.wire_dir,
        on_turn_complete=tracker.record_model_request,
    )
    # Two-step wiring (FIX-D): the receiver needs the tracker's callback,
    # and the tracker needs the receiver so the UserPromptSubmit capture
    # can hand the real prompt text to the turn correlation.
    tracker.set_receiver(receiver)
    uploader_active = events is not None and bool(config.workspace_key)

    @contextlib.asynccontextmanager
    async def lifespan(app: Starlette) -> AsyncIterator[None]:
        # Pure-gate (events=None) or pre-login (empty workspace_key): do
        # not start the uploader. The gate forward + capture-to-buffer
        # path still runs; nothing drains to the cloud.
        if events is None:
            app.state.uploader = None
            yield
            return
        if not config.workspace_key:
            _logger.warning(
                "event=edge_uploader_disabled reason=no_workspace_key — "
                "captured events will buffer but NOT upload until login "
                "mints a workspace key (run `sentisec edge` to log in)"
            )
            app.state.uploader = None
            yield
            return

        uploader = EventUploader(
            buffer=events,
            control_plane_url=config.control_plane_url,
            workspace_key=config.workspace_key,
        )
        app.state.uploader = uploader
        task = asyncio.create_task(_drain_loop(uploader))
        _logger.info(
            "event=edge_uploader_started target=%s interval_s=%s",
            config.control_plane_url,
            DRAIN_INTERVAL_S,
        )
        try:
            yield
        finally:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
            # Best-effort final drain so a clean shutdown does not strand
            # whatever was captured since the last cycle. A failure here
            # spools to disk for the next daemon boot — never raises.
            with contextlib.suppress(Exception):
                await drain_once(uploader)
            uploader.close()

    async def hooks_endpoint(request: Request) -> JSONResponse:
        from .claude_hooks import handle_hook

        try:
            payload = await request.json()
        except Exception:
            # Malformed body — fail-open (never block a tool call on a
            # parse error). An empty PreToolUse forwards a benign payload
            # the gate allows / fails open on.
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        output = handle_hook(payload, tracker)
        return JSONResponse(output)

    async def logs_endpoint(request: Request) -> Response:
        body = await request.body()
        return receiver.handle_export(body)

    async def healthz_endpoint(_request: Request) -> JSONResponse:
        buffered = events.qsize() if events is not None else 0
        return JSONResponse(
            {
                "status": "ok",
                "daemon_port": config.daemon_port,
                "wire_dir": config.wire_dir,
                "control_plane_url": config.control_plane_url,
                "buffered_events": buffered,
                # "active" once the lifespan started the drain task;
                # "disabled" in pure-gate (events=None) or pre-login
                # (empty workspace_key) mode. Lets the wizard self-test
                # confirm the founder's events will actually upload.
                "uploader": "active" if uploader_active else "disabled",
            }
        )

    app = Starlette(
        routes=[
            Route("/hooks", hooks_endpoint, methods=["POST"]),
            Route("/v1/logs", logs_endpoint, methods=["POST"]),
            Route("/healthz", healthz_endpoint, methods=["GET"]),
        ],
        lifespan=lifespan,
    )
    app.state.tracker = tracker
    app.state.receiver = receiver
    app.state.events = events
    # Default until the lifespan runs; the lifespan replaces it with the
    # live EventUploader (active mode) or leaves it None (disabled mode).
    app.state.uploader = None
    return app


def codex_wired(home_config_path: str | None = None) -> bool:
    """Return True when Codex is wired (the provider config block exists).

    The Codex passthrough proxy is started on ``daemon_port + 1`` ONLY
    when the user wired Codex (the wizard wrote the ``sentisec-edge``
    provider into ``~/.codex/config.toml``). This keeps the codex proxy
    off the box for Claude-only users. Engine-free check: read the codex
    config and look for the provider slot — no network, no platform
    import. A missing / unreadable config -> not wired.
    """
    import tomllib
    from pathlib import Path

    from .installer import CODEX_PROVIDER_SLOT, codex_config_path

    path = codex_config_path() if home_config_path is None else Path(home_config_path)
    if not path.is_file():
        return False
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return False
    providers = data.get("model_providers")
    return isinstance(providers, dict) and CODEX_PROVIDER_SLOT in providers


def run() -> None:  # pragma: no cover — process entry, not unit-tested
    """Process entry — load config, build the app(s), serve with uvicorn.

    Serves the Claude hook/OTLP daemon on ``config.daemon_port``. When
    Codex is wired (:func:`codex_wired`), ALSO serves the Codex
    passthrough proxy on ``codex_proxy_port(daemon_port)`` (= +1) as a
    second in-process uvicorn server. Both bind ``127.0.0.1`` only.

    Not exercised by unit tests (those drive the ASGI apps via the
    Starlette ``TestClient``). The wizard / launchd service invoke this
    via ``python -m sentisec_sdk.edge.daemon``.
    """
    import asyncio

    import uvicorn

    try:
        config = EdgeConfig.load(_default_config_path())
    except Exception:
        config = EdgeConfig.default()

    events = EventBuffer()
    app = build_daemon_app(config, events=events)
    daemon_server = uvicorn.Server(
        uvicorn.Config(app, host="127.0.0.1", port=config.daemon_port)
    )

    if not codex_wired():
        # Claude-only: a single server, the simple path.
        daemon_server.run()
        return

    # Codex wired: run both servers concurrently in one event loop.
    # Both apps must share the same EventBuffer. The daemon lifespan
    # owns the single EventUploader that drains this buffer to
    # /v1/edge/events; a separate Codex-only buffer would collect
    # events but never upload them.
    from .codex_proxy import build_codex_proxy_app, codex_proxy_port

    codex_app = build_codex_proxy_app(config, events=events)
    codex_server = uvicorn.Server(
        uvicorn.Config(
            codex_app,
            host="127.0.0.1",
            port=codex_proxy_port(config.daemon_port),
        )
    )

    async def _serve_both() -> None:
        await asyncio.gather(daemon_server.serve(), codex_server.serve())

    asyncio.run(_serve_both())


def _default_config_path() -> str:  # pragma: no cover — process entry
    import os

    return os.path.expanduser(os.path.join("~", ".sentisec", "edge.toml"))


if __name__ == "__main__":  # pragma: no cover — module entry
    run()
