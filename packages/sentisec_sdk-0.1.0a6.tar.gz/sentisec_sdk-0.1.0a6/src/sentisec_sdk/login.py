"""``sentisec login`` — browser and headless pairing for the public SDK.

The default flow is intentionally dashboard-first:

1. The CLI binds a one-shot HTTP server on a free localhost port in
   the range 8765-8800.

2. The CLI opens the user's default browser to
   ``https://app.sentisec.ch/sdk-pair?callback=http://localhost:<port>/callback``.

3. The dashboard authenticates the user, mints SDK credentials
   server-side, then redirects the browser to
   ``http://localhost:<port>/callback?api_key=...&workspace_id=...&tier=...&endpoint=...``.

4. The CLI's local server accepts the GET, parses the query string,
   writes ``~/.sentisec/credentials.toml`` with mode ``0o600``, and
   exits 0. A 200 OK browser-visible page tells the user to return
   to their terminal.

Headless users can copy a pair code from the dashboard and run
``sentisec login --code <code>``. That path redeems the dashboard-minted
code with ``POST <endpoint>/v1/sdk/pair/complete`` and writes the same
credentials file locally.

Timeouts and error paths
------------------------

- The local server waits ``LOGIN_TIMEOUT_S`` (default 120s) for a
  callback. If the timeout expires, the CLI prints a clean error and
  exits 1 with no credentials file written.

- If the user cancels in the browser, the dashboard redirects to
  ``http://localhost:<port>/callback?error=cancelled``. The CLI
  surfaces the error string and exits 1.

- ``--print-url-only`` prints the launch URL and exits 0 without
  binding a port, opening a browser, or calling the control plane.
  Useful for CI smoke tests and for users on machines without a
  graphical browser.

Why a local-callback flow rather than a polling flow
----------------------------------------------------

A polling client would also work, but the callback shape keeps the CLI
small and gives the user immediate feedback:

- The dashboard owns authentication and credential minting; the CLI
  does not need to call an authenticated endpoint before browser auth.
- A localhost callback gives an immediate signal with no busy-wait,
  no fixed poll cadence to tune, and no extra rate-limit pressure.
- The credentials never travel through a third party — ``localhost``
  is bound to ``127.0.0.1`` and the dashboard 302's the browser
  directly to it.

This module never touches an LLM provider and never exposes the
control-plane internals. It is a thin pairing client.
"""

from __future__ import annotations

import argparse
import http.server
import os
import secrets
import sys
import threading
import urllib.parse
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Final

import httpx

from .credentials import (
    DEFAULT_CREDENTIALS_PATH,
    DEFAULT_ENDPOINT,
    DEFAULT_PROFILE,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Default URL of the dashboard's pair-confirmation page. The CLI opens
#: the user's default browser here with ``?callback=...``.
DEFAULT_PAIR_URL: Final[str] = "https://app.sentisec.ch/sdk-pair"

#: Inclusive port range the local-callback server binds. This avoids
#: common dev ports (3000/8000/8080) while
#: staying high enough to not require sudo on any platform.
LOCAL_PORT_MIN: Final[int] = 8765
LOCAL_PORT_MAX: Final[int] = 8800

#: Maximum time (seconds) the CLI waits for a browser callback.
LOGIN_TIMEOUT_S: Final[float] = 120.0

#: HTTP request timeout for the headless ``pair/complete`` redeem call.
PAIR_COMPLETE_TIMEOUT_S: Final[float] = 10.0

#: User-Agent reported by the SDK on outbound HTTP. Plain, no
#: signal-family jargon.
USER_AGENT: Final[str] = "sentisec-sdk-cli"


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class SentisecLoginError(Exception):
    """Raised when ``sentisec login`` cannot complete.

    Carries a single-line message; the CLI prints it on stderr and
    exits 1. Subclassing keeps the test surface small — every login
    failure mode raises this same type with a distinguishing message.
    """


# ---------------------------------------------------------------------------
# Callback result
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CallbackResult:
    """Parsed query string from the dashboard's redirect to localhost.

    Either ``api_key`` is set (success) or ``error`` is set (cancel /
    failure). Never both.

    ``code`` is the CSRF nonce the CLI minted before opening the
    browser; the dashboard's ``/api/sdk/pair/complete`` route echoes
    it back in the redirect. The CLI verifies it matches the
    expected nonce before writing credentials.
    """

    api_key: str | None
    workspace_id: str | None
    tier: str | None
    endpoint: str | None
    error: str | None
    code: str | None = None


@dataclass(frozen=True)
class PairCredentials:
    """Credentials returned by the dashboard callback or code redemption."""

    api_key: str
    workspace_id: str
    tier: str
    endpoint: str


# ---------------------------------------------------------------------------
# Local-callback HTTP server
# ---------------------------------------------------------------------------


class _CallbackState:
    """Mutable container the request handler writes the result into.

    Using a class (rather than a closure variable) keeps the typing
    explicit and lets the handler set fields without needing a
    ``nonlocal`` dance through the BaseHTTPRequestHandler subclass.
    """

    def __init__(self) -> None:
        self.result: CallbackResult | None = None
        self.event = threading.Event()


def _build_handler(state: _CallbackState) -> type[http.server.BaseHTTPRequestHandler]:
    """Return a handler class bound to ``state``.

    Defining the class inline lets us close over ``state`` without
    using a global. The handler accepts exactly one GET on
    ``/callback`` and ignores everything else.
    """

    class _Handler(http.server.BaseHTTPRequestHandler):
        # Silence the default stderr access log; the CLI owns user I/O.
        def log_message(
            self, format: str, *args: object
        ) -> None:  # noqa: A002, ARG002
            return

        def do_GET(self) -> None:  # noqa: N802 — http.server contract
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"not found")
                return

            qs = urllib.parse.parse_qs(parsed.query)

            def _one(key: str) -> str | None:
                values = qs.get(key)
                if not values:
                    return None
                return values[0] or None

            result = CallbackResult(
                api_key=_one("api_key"),
                workspace_id=_one("workspace_id"),
                tier=_one("tier"),
                endpoint=_one("endpoint"),
                error=_one("error"),
                code=_one("code"),
            )
            state.result = result
            state.event.set()

            # User-visible page. No signals named, no internals.
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            if result.error is not None:
                body = (
                    "<!doctype html><html><head><meta charset=\"utf-8\">"
                    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                    "<title>Sentisec login</title>"
                    "<script>history.replaceState(null,'','/callback');</script>"
                    "<style>"
                    "body{margin:0;font:16px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"
                    "'Segoe UI',sans-serif;background:#f7f1e5;color:#101010}"
                    "main{min-height:100vh;display:grid;place-items:center;padding:24px}"
                    "section{max-width:440px;border:2px solid #111;background:#fff;padding:24px;"
                    "box-shadow:6px 6px 0 #111}"
                    "h1{margin:0 0 8px;font-size:24px;line-height:1.15}"
                    "p{margin:0 0 16px;color:#444}"
                    "button{border:2px solid #111;background:#111;color:#fff;padding:10px 14px;"
                    "font:inherit;cursor:pointer}"
                    "</style></head><body><main><section>"
                    "<h1>Sentisec login: error</h1>"
                    f"<p>{html_escape(result.error)}</p>"
                    "<button type=\"button\" onclick=\"window.close()\">Close tab</button>"
                    "</section></main></body></html>"
                )
            else:
                body = (
                    "<!doctype html><html><head><meta charset=\"utf-8\">"
                    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                    "<title>Sentisec login complete</title>"
                    "<script>history.replaceState(null,'','/callback');</script>"
                    "<style>"
                    "body{margin:0;font:16px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"
                    "'Segoe UI',sans-serif;background:#f7f1e5;color:#101010}"
                    "main{min-height:100vh;display:grid;place-items:center;padding:24px}"
                    "section{max-width:440px;border:2px solid #111;background:#fff;padding:24px;"
                    "box-shadow:6px 6px 0 #111}"
                    "h1{margin:0 0 8px;font-size:24px;line-height:1.15}"
                    "p{margin:0 0 16px;color:#444}"
                    "button{border:2px solid #111;background:#111;color:#fff;padding:10px 14px;"
                    "font:inherit;cursor:pointer}"
                    "</style></head><body><main><section>"
                    "<h1>Sentisec login: complete</h1>"
                    "<p>Your API key was saved. Return to your terminal to continue.</p>"
                    "<button type=\"button\" onclick=\"window.close()\">Close tab</button>"
                    "</section></main></body></html>"
                )
            self.wfile.write(body.encode("utf-8"))

    return _Handler


def html_escape(value: str) -> str:
    """Minimal HTML escape for the in-page error message.

    Imported nowhere else; defined here to keep the module
    dependency-free beyond ``httpx``.
    """
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _bind_local_server(
    state: _CallbackState,
    port_min: int = LOCAL_PORT_MIN,
    port_max: int = LOCAL_PORT_MAX,
) -> tuple[http.server.HTTPServer, int]:
    """Bind a one-shot HTTP server on a free port in ``[min, max]``.

    Tries each port in order and returns the first that binds. Raises
    :class:`SentisecLoginError` if every port is occupied.
    """
    handler_cls = _build_handler(state)
    last_err: OSError | None = None
    for port in range(port_min, port_max + 1):
        try:
            server = http.server.HTTPServer(("127.0.0.1", port), handler_cls)
        except OSError as exc:
            last_err = exc
            continue
        return server, port
    raise SentisecLoginError(
        f"could not bind a local callback port in {port_min}-{port_max}: "
        f"{last_err}"
    )


# ---------------------------------------------------------------------------
# Pair-code redemption
# ---------------------------------------------------------------------------


def _complete_pair_code(
    *,
    endpoint: str,
    code: str,
    transport: httpx.BaseTransport | None = None,
) -> PairCredentials:
    """Redeem a dashboard-minted pair code and return credentials.

    This is the supported headless path. The code itself is created by
    the authenticated dashboard; the CLI only redeems it.
    """
    normalized = code.strip()
    if not normalized:
        raise SentisecLoginError("pair code is empty")

    url = endpoint.rstrip("/") + "/v1/sdk/pair/complete"
    client_kwargs: dict[str, object] = {"timeout": PAIR_COMPLETE_TIMEOUT_S}
    if transport is not None:
        client_kwargs["transport"] = transport
    with httpx.Client(**client_kwargs) as client:  # type: ignore[arg-type]
        try:
            resp = client.post(
                url,
                headers={"User-Agent": USER_AGENT},
                json={"code": normalized},
            )
        except httpx.HTTPError as exc:
            raise SentisecLoginError(
                f"could not reach control plane at {endpoint}: {exc}"
            ) from exc
    if resp.status_code != 200:
        raise SentisecLoginError(
            f"pair/complete returned HTTP {resp.status_code} from {endpoint}"
        )
    try:
        body = resp.json()
    except ValueError as exc:
        raise SentisecLoginError(
            f"pair/complete returned non-JSON body from {endpoint}: {exc}"
        ) from exc

    if isinstance(body, dict) and isinstance(body.get("credentials"), dict):
        data = body["credentials"]
    else:
        data = body
    if not isinstance(data, dict):
        raise SentisecLoginError(
            f"pair/complete response missing credentials from {endpoint}"
        )

    api_key = data.get("api_key")
    workspace_id = data.get("workspace_id")
    tier = data.get("tier", "free")
    response_endpoint = data.get("endpoint", endpoint)
    if not isinstance(api_key, str) or not api_key:
        raise SentisecLoginError(
            f"pair/complete response missing 'api_key' from {endpoint}"
        )
    if not isinstance(workspace_id, str) or not workspace_id:
        raise SentisecLoginError(
            f"pair/complete response missing 'workspace_id' from {endpoint}"
        )
    if not isinstance(tier, str) or not tier:
        tier = "free"
    if not isinstance(response_endpoint, str) or not response_endpoint:
        response_endpoint = endpoint
    return PairCredentials(
        api_key=api_key,
        workspace_id=workspace_id,
        tier=tier,
        endpoint=response_endpoint,
    )


# ---------------------------------------------------------------------------
# Credentials persistence
# ---------------------------------------------------------------------------


def _write_credentials(
    *,
    path: Path,
    profile: str,
    api_key: str,
    workspace_id: str,
    tier: str,
    endpoint: str,
) -> None:
    """Write ``credentials.toml`` with mode 0o600.

    Atomic-ish: write to a sibling tmp file, then rename. The rename
    inherits the tmp file's mode, so we set 0o600 BEFORE rename. We
    do not chmod the destination after rename because doing so would
    race with a concurrent reader.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    body = (
        f"[{profile}]\n"
        f'api_key = "{_toml_escape(api_key)}"\n'
        f'workspace_id = "{_toml_escape(workspace_id)}"\n'
        f'tier = "{_toml_escape(tier)}"\n'
        f'endpoint = "{_toml_escape(endpoint)}"\n'
    )

    tmp = path.with_suffix(path.suffix + f".tmp.{secrets.token_hex(4)}")
    # Open with restrictive mode from the start. ``os.open`` lets us
    # set the mode atomically; ``Path.write_text`` does not.
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(tmp, flags, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(body)
    except Exception:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass
        raise

    os.replace(tmp, path)
    if os.name == "posix":
        # Defensive: ensure final mode is 0o600 even if umask altered
        # the open() mode.
        os.chmod(path, 0o600)


def _toml_escape(value: str) -> str:
    """Escape a string for inclusion inside a TOML basic string.

    TOML basic strings forbid raw backslash and double-quote. The
    credentials we write are short opaque tokens + URL-safe ids, so
    the escape table is small.
    """
    return value.replace("\\", "\\\\").replace('"', '\\"')


# ---------------------------------------------------------------------------
# Login orchestration
# ---------------------------------------------------------------------------


def _build_pair_url(
    *,
    pair_url_base: str,
    callback_url: str,
    code: str,
) -> str:
    """Compose the dashboard pair-confirmation URL.

    Per D-015, the dashboard's ``/sdk-pair`` page requires both
    ``code`` (CLI-minted nonce, used as a CSRF token round-tripped
    via the localhost callback) and ``callback`` (the localhost URL
    the dashboard 303's to with the minted API key). Sending only
    ``callback`` produces the user-visible "This URL is missing the
    `code` query parameter" error (live discovery 2026-05-12).
    """
    qs = urllib.parse.urlencode({"code": code, "callback": callback_url})
    return f"{pair_url_base}?{qs}"


@dataclass(frozen=True)
class LoginConfig:
    """All knobs the login flow accepts. Defaults match production."""

    endpoint: str = DEFAULT_ENDPOINT
    pair_url: str = DEFAULT_PAIR_URL
    credentials_path: Path | None = None
    profile: str = DEFAULT_PROFILE
    timeout_s: float = LOGIN_TIMEOUT_S
    print_url_only: bool = False
    code: str | None = None
    # Test seam: inject a mocked browser launcher.
    open_browser: bool = True


def login(
    config: LoginConfig | None = None,
    *,
    transport: httpx.BaseTransport | None = None,
    browser_open: Callable[[str], bool] | None = None,
) -> Path | None:
    """Run the ``sentisec login`` flow.

    Returns the path the credentials were written to on success, or
    ``None`` when ``--print-url-only`` short-circuited (no file
    written). Raises :class:`SentisecLoginError` on any failure.

    Parameters
    ----------
    config:
        Knobs (endpoint, paths, timeout, flags). Defaults are
        production-shaped.
    transport:
        Optional ``httpx.BaseTransport`` used for the ``pair/complete``
        headless redemption. Tests inject ``httpx.MockTransport`` here.
    browser_open:
        Optional callable that takes the launch URL and returns
        ``True`` on successful launch. Tests inject a no-op or a
        callback simulator here. When ``None``, ``webbrowser.open``
        is used.
    """
    cfg = config if config is not None else LoginConfig()
    creds_path = (
        cfg.credentials_path
        if cfg.credentials_path is not None
        else DEFAULT_CREDENTIALS_PATH.expanduser()
    )

    if cfg.code is not None:
        credentials = _complete_pair_code(
            endpoint=cfg.endpoint,
            code=cfg.code,
            transport=transport,
        )
        _write_credentials(
            path=creds_path,
            profile=cfg.profile,
            api_key=credentials.api_key,
            workspace_id=credentials.workspace_id,
            tier=credentials.tier,
            endpoint=credentials.endpoint,
        )
        return creds_path

    # Step 1: bind a localhost server so the dashboard can redirect
    # minted credentials back to this process.
    state = _CallbackState()
    if not cfg.print_url_only:
        server, port = _bind_local_server(state)
    else:
        server, port = None, LOCAL_PORT_MIN  # placeholder for URL-only mode

    # Step 2: mint a CSRF nonce ("code") + build the launch URL. The
    # dashboard requires both code + callback per D-015; the dashboard
    # echoes ``code`` back in the 303 redirect so step 5 can verify
    # the callback came from the same login attempt and not from a
    # racing browser tab. ``secrets.token_urlsafe(32)`` produces a
    # 43-character URL-safe nonce — 256 bits of entropy.
    expected_code = secrets.token_urlsafe(32)
    callback_url = f"http://localhost:{port}/callback"
    launch_url = _build_pair_url(
        pair_url_base=cfg.pair_url,
        callback_url=callback_url,
        code=expected_code,
    )

    # ``--print-url-only``: no port bind, no browser.
    if cfg.print_url_only:
        print(launch_url)
        return None

    # Step 4: serve and open the browser.
    assert server is not None  # for mypy
    serve_thread = threading.Thread(target=server.serve_forever, daemon=True)
    serve_thread.start()
    opener = browser_open if browser_open is not None else webbrowser.open
    if cfg.open_browser:
        try:
            opener(launch_url)
        except Exception as exc:  # noqa: BLE001 — webbrowser raises broad
            server.shutdown()
            server.server_close()
            raise SentisecLoginError(
                f"could not open browser: {exc}"
            ) from exc
    else:
        # Test mode: caller will hit the callback themselves.
        pass

    # Step 5: serve until the callback fires or we time out.
    try:
        got_it = state.event.wait(timeout=cfg.timeout_s)
    finally:
        server.shutdown()
        server.server_close()

    if not got_it:
        raise SentisecLoginError(
            f"timed out waiting for browser callback after "
            f"{int(cfg.timeout_s)}s"
        )

    result = state.result
    assert result is not None  # state.event was set ⇒ result is set

    if result.error is not None:
        raise SentisecLoginError(
            f"login cancelled: {result.error}"
        )
    if not (
        result.api_key
        and result.workspace_id
    ):
        raise SentisecLoginError(
            "callback missing api_key or workspace_id"
        )
    # CSRF: the code echoed back must match the nonce we sent. A
    # mismatch means either an unrelated request hit our local port
    # or someone is replaying an older callback URL. Refuse to write
    # credentials in either case. ``secrets.compare_digest`` is
    # constant-time; the alternative ``==`` would be fine here too
    # (nonces are not secret) but the constant-time form documents
    # intent.
    if not result.code or not secrets.compare_digest(
        result.code, expected_code
    ):
        raise SentisecLoginError(
            "callback code mismatch — refusing to write credentials "
            "(re-run `sentisec login` to start a fresh pairing)"
        )

    # Step 6: persist credentials.
    _write_credentials(
        path=creds_path,
        profile=cfg.profile,
        api_key=result.api_key,
        workspace_id=result.workspace_id,
        tier=result.tier or "free",
        endpoint=result.endpoint or cfg.endpoint,
    )
    return creds_path


# ---------------------------------------------------------------------------
# CLI argparse entry — wired up by sentisec_sdk.cli
# ---------------------------------------------------------------------------


def build_login_argparser() -> argparse.ArgumentParser:
    """Construct the argparse parser for ``sentisec login``.

    Exported so the top-level CLI can mount it as a subparser.
    """
    parser = argparse.ArgumentParser(
        prog="sentisec login",
        description=(
            "Pair this machine with a Sentisec workspace. Opens your "
            "default browser to https://app.sentisec.ch/sdk-pair, then "
            "writes ~/.sentisec/credentials.toml on success."
        ),
    )
    parser.add_argument(
        "--endpoint",
        default=DEFAULT_ENDPOINT,
        help=(
            "Control-plane endpoint used to redeem --code. "
            f"Default: {DEFAULT_ENDPOINT}."
        ),
    )
    parser.add_argument(
        "--code",
        default=None,
        help=(
            "Redeem a dashboard-generated pair code without opening a "
            "browser."
        ),
    )
    parser.add_argument(
        "--profile",
        default=DEFAULT_PROFILE,
        help=(
            f"Credentials-file profile section. Default: "
            f"{DEFAULT_PROFILE!r}."
        ),
    )
    parser.add_argument(
        "--credentials-path",
        default=None,
        type=Path,
        help=(
            "Override credentials file path. Default: "
            "~/.sentisec/credentials.toml."
        ),
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=LOGIN_TIMEOUT_S,
        help=(
            f"Seconds to wait for the browser callback. Default: "
            f"{int(LOGIN_TIMEOUT_S)}."
        ),
    )
    parser.add_argument(
        "--print-url-only",
        action="store_true",
        help=(
            "Print the pair URL and exit without launching a browser. "
            "Useful for CI and headless machines."
        ),
    )
    return parser


def login_from_args(argv: list[str] | None = None) -> int:
    """Entry-point used by ``sentisec login`` in the top-level CLI.

    Returns an exit code: 0 on success, 1 on user-visible failure.
    """
    parser = build_login_argparser()
    args = parser.parse_args(argv)
    cfg = LoginConfig(
        endpoint=args.endpoint,
        credentials_path=args.credentials_path,
        profile=args.profile,
        timeout_s=args.timeout,
        print_url_only=args.print_url_only,
        code=args.code,
    )
    try:
        result = login(cfg)
    except SentisecLoginError as exc:
        print(f"sentisec: login failed: {exc}", file=sys.stderr)
        return 1
    if result is not None:
        print(f"sentisec: credentials written to {result}")
    return 0


__all__ = [
    "DEFAULT_PAIR_URL",
    "LOCAL_PORT_MAX",
    "LOCAL_PORT_MIN",
    "LOGIN_TIMEOUT_S",
    "CallbackResult",
    "LoginConfig",
    "PairCredentials",
    "PAIR_COMPLETE_TIMEOUT_S",
    "SentisecLoginError",
    "build_login_argparser",
    "login",
    "login_from_args",
]
