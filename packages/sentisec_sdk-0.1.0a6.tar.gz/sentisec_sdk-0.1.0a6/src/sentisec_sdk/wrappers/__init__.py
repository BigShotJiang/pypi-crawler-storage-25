"""Provider-specific client wrappers for the Sentisec SDK.

Each module under this package targets one upstream LLM client:

- ``sentisec_sdk.wrappers.openai`` — :func:`wrap_openai`
- ``sentisec_sdk.wrappers.anthropic`` — :func:`wrap_anthropic`

Both wrappers do exactly two things:

1. Rewrite the wrapped client's ``base_url`` so subsequent calls flow
   through the Sentisec control plane.
2. Replace the wrapped client's ``api_key`` (and matching auth
   headers) with the Sentisec API key resolved from
   ``~/.sentisec/credentials.toml``. The control plane forwards the
   call upstream using the workspace's stored provider key.

The wrappers are pass-through. They never inspect, mutate, log, or
otherwise touch the user's request payload. The control plane is the
single point of evaluation; the wrappers are mechanical adapters.
"""

from __future__ import annotations

from .anthropic import wrap_anthropic
from .openai import wrap_openai

__all__ = ["wrap_anthropic", "wrap_openai"]
