"""``wrap_openai`` — adapt an OpenAI client to flow through Sentisec.

The wrapper does exactly two things to the user-supplied OpenAI client:

1. Rewrite ``client.base_url`` to point at the Sentisec control plane's
   OpenAI-shaped proxy endpoint (default
   ``https://api.sentisec.ch/v1/proxy/openai``).
2. Rewrite ``client.api_key`` (and the matching ``Authorization`` header
   on the client's underlying http transport) to the Sentisec API key
   resolved from ``~/.sentisec/credentials.toml``. The control plane
   forwards the call to OpenAI using the workspace's stored upstream
   key.

The wrapper is intentionally a pass-through. It does not:

- inspect, mutate, log, or otherwise touch the user's request payload;
- introspect the response;
- depend on the OpenAI SDK at import time (the dependency is optional).

The OpenAI Python SDK exposes ``base_url`` and ``api_key`` as mutable
attributes on the ``OpenAI`` / ``AsyncOpenAI`` client. Both names are
documented public API as of openai>=1.0; the wrapper assigns to them
directly. For non-standard clients (e.g., a stub or a third-party
client that mimics the shape) the wrapper accepts any object exposing
those two attributes.

References
----------

- https://github.com/openai/openai-python — the public client.
- https://docs.sentisec.ch — the control-plane OpenAI proxy reference.
"""

from __future__ import annotations

from typing import TypeVar

from ..credentials import Credentials, resolve_credentials

#: Path component appended to the control-plane endpoint to reach the
#: OpenAI-shaped proxy. Pinned so a sibling change to ``Credentials``
#: cannot silently re-target the wrapped client.
OPENAI_PROXY_PATH: str = "/v1/proxy/openai"

_T = TypeVar("_T")


def _proxy_base_url(endpoint: str) -> str:
    """Compose the control-plane proxy URL the wrapped client targets.

    Strips trailing slash from the endpoint so the joined URL has a
    single ``/`` between host and path.
    """
    return endpoint.rstrip("/") + OPENAI_PROXY_PATH


def wrap_openai(client: _T, *, credentials: Credentials | None = None) -> _T:
    """Mutate ``client`` in place so its calls flow through Sentisec.

    Parameters
    ----------
    client:
        An OpenAI client instance (``openai.OpenAI`` or
        ``openai.AsyncOpenAI``), or any duck-typed object exposing
        ``base_url`` and ``api_key`` attributes.
    credentials:
        Optional pre-resolved credentials. When ``None``, credentials
        are resolved with ``resolve_credentials()`` (env / file /
        defaults).

    Returns
    -------
    The same ``client`` reference, now reconfigured. Returning the same
    object lets callers write the idiomatic
    ``client = wrap_openai(client)`` while keeping reference identity
    for code that has already captured ``client`` elsewhere.

    The function never copies request data, never adds headers beyond
    the ones the OpenAI SDK already sends, and never names internal
    Sentisec mechanisms in any header it does send.
    """
    creds = credentials if credentials is not None else resolve_credentials()
    target = _proxy_base_url(creds.endpoint)

    # The OpenAI SDK's ``base_url`` is a ``httpx.URL`` once normalized;
    # the assignment goes through a property that re-normalizes, so a
    # plain string is the right input. ``api_key`` is a plain str.
    setattr(client, "base_url", target)
    setattr(client, "api_key", creds.api_key)
    return client


__all__ = ["OPENAI_PROXY_PATH", "wrap_openai"]
