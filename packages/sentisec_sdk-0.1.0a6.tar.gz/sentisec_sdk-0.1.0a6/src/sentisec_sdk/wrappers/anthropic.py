"""``wrap_anthropic`` — adapt an Anthropic client to flow through Sentisec.

Symmetric to :mod:`sentisec_sdk.wrappers.openai`. The wrapper rewrites
the wrapped client's ``base_url`` to the Anthropic-shaped proxy
endpoint on the Sentisec control plane (default
``https://api.sentisec.ch/v1/proxy/anthropic``) and rewrites
``api_key`` to the Sentisec key resolved from
``~/.sentisec/credentials.toml``.

The Anthropic Python SDK (``anthropic>=0.40``) exposes ``base_url``
and ``api_key`` as mutable attributes on the ``Anthropic`` /
``AsyncAnthropic`` client. The wrapper assigns to them directly.

The wrapper does NOT depend on the ``anthropic`` package at import
time; the dependency is declared optional in ``pyproject.toml``. Any
duck-typed object exposing the two attributes is accepted.

References
----------

- https://github.com/anthropics/anthropic-sdk-python — the client.
- https://docs.sentisec.ch — the control-plane Anthropic proxy reference.
"""

from __future__ import annotations

from typing import TypeVar

from ..credentials import Credentials, resolve_credentials

#: Path component appended to the endpoint to reach the
#: Anthropic-shaped proxy. Distinct from
#: ``OPENAI_PROXY_PATH`` so the proxy can disambiguate provider on
#: the URL alone.
ANTHROPIC_PROXY_PATH: str = "/v1/proxy/anthropic"

_T = TypeVar("_T")


def _proxy_base_url(endpoint: str) -> str:
    """Compose the control-plane proxy URL the wrapped client targets."""
    return endpoint.rstrip("/") + ANTHROPIC_PROXY_PATH


def wrap_anthropic(client: _T, *, credentials: Credentials | None = None) -> _T:
    """Mutate ``client`` in place so its calls flow through Sentisec.

    See :func:`sentisec_sdk.wrappers.openai.wrap_openai` for the
    contract; this is the Anthropic counterpart with the same
    pass-through semantics. The Anthropic SDK ships its own
    ``Authorization`` header derivation from ``api_key``, so setting
    ``api_key`` is sufficient — the wrapper does not touch the
    transport's default headers.

    Parameters
    ----------
    client:
        An Anthropic client instance, or any duck-typed object exposing
        ``base_url`` and ``api_key`` attributes.
    credentials:
        Optional pre-resolved credentials. When ``None``, credentials
        are resolved with ``resolve_credentials()``.

    Returns
    -------
    The same ``client`` reference, reconfigured.
    """
    creds = credentials if credentials is not None else resolve_credentials()
    target = _proxy_base_url(creds.endpoint)
    setattr(client, "base_url", target)
    setattr(client, "api_key", creds.api_key)
    return client


__all__ = ["ANTHROPIC_PROXY_PATH", "wrap_anthropic"]
