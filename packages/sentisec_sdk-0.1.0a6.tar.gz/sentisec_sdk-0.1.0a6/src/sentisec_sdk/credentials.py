"""Credential resolution for the Sentisec public SDK.

This module is the SDK-side credential loader. It resolves the API key
+ workspace + endpoint a Sentisec ``Monitor`` instance will use, in
the precedence order::

    explicit constructor arg  >  environment variable  >  file

The file format is the canonical ``credentials.toml`` written by
``sentisec login``, located at ``~/.sentisec/credentials.toml`` by
default. The file format::

    [default]
    api_key      = "sk_sentisec_<ws-short>_<rand32>"
    workspace_id = "<uuid>"
    tier         = "free"
    endpoint     = "https://api.sentisec.ch"

Public surface
--------------

::

    from sentisec_sdk.credentials import (
        Credentials,                   # frozen dataclass: api_key,
                                        #  workspace_id, tier, endpoint
        SentisecAuthError,             # raised on missing credentials
        resolve_credentials,           # the precedence-aware resolver
        DEFAULT_CREDENTIALS_PATH,      # Path("~/.sentisec/credentials.toml")
        DEFAULT_ENDPOINT,              # "https://api.sentisec.ch"
        DEFAULT_PROFILE,               # "default"
    )

Design notes
------------

1. **Stdlib ``tomllib`` only.** Python 3.11+ ships ``tomllib`` in the
   stdlib; we never add a third-party TOML parser.

2. **Precedence is strict.** ``arg > env > file``. Each layer is
   checked independently for each field — a caller that passes
   ``api_key=...`` but lets workspace_id default still picks up
   workspace_id from env or file.

3. **Missing credentials raises ``SentisecAuthError``.** No silent
   fallback to "anonymous mode" — the SDK is not useful without an
   API key. The error message names ``"Run 'sentisec login' first"``
   as the recovery path.

4. **File mode is checked but not enforced.** ``sentisec login``
   writes the file with mode ``0o600``; this loader logs a warning if
   the mode is broader on POSIX systems but does not refuse to read.
   Refusing would force CI environments (where ``$HOME`` is shared)
   to special-case mode 0o644 — too aggressive for an MVP.

5. **No network.** Resolution is purely local I/O + stdlib parsing.

This module has no network side effects. It only reads local
configuration and environment variables.
"""

from __future__ import annotations

import os
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Final

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

#: Default credentials-file path. Resolved with ``Path.expanduser()``
#: so it tracks the caller's HOME, including tests that monkeypatch
#: ``$HOME``.
DEFAULT_CREDENTIALS_PATH: Final[Path] = Path("~/.sentisec/credentials.toml")

#: Default control-plane endpoint when no override is set.
DEFAULT_ENDPOINT: Final[str] = "https://api.sentisec.ch"

#: Default profile section name within ``credentials.toml``.
DEFAULT_PROFILE: Final[str] = "default"

#: Environment variable for the API key.
ENV_API_KEY: Final[str] = "SENTISEC_API_KEY"

#: Environment variable for the workspace id.
ENV_WORKSPACE_ID: Final[str] = "SENTISEC_WORKSPACE_ID"

#: Environment variable for the tier.
ENV_TIER: Final[str] = "SENTISEC_TIER"

#: Environment variable for the endpoint.
ENV_ENDPOINT: Final[str] = "SENTISEC_ENDPOINT"


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class SentisecAuthError(Exception):
    """Raised when SDK credentials cannot be resolved.

    The error message names ``"Run 'sentisec login' first"`` as the
    canonical hint.
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)


# ---------------------------------------------------------------------------
# Frozen credentials value
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Credentials:
    """The resolved credential set the SDK uses on its first call.

    Fields are typed; ``tier`` defaults to ``"free"`` only if no source
    supplied a value (a permissive default — the proxy enforces the
    actual tier via the workspace's subscription row, so a stale tier
    here is at most a UX hint).

    ``workspace_id`` is optional from v0.1.0a4 onwards. The Sentisec
    proxy resolves the calling workspace from the API key itself
    (the key's 8-char prefix is ``sha256(workspace_uuid)[:8]`` — see
    ``platform/sentisec/auth/api_keys.py:_workspace_short`` — and
    ``verify_proxy_api_key`` returns the ``ApiKey`` row whose
    ``workspace_id`` column is authoritative). The SDK never sends
    ``workspace_id`` over the wire; the field is preserved as an
    explicit-pin convenience for callers who want it surfaced in
    logs or who run against the workspace-scoped routes
    (``/ws/<id>/v1/messages``). Empty string means "resolve from
    key on the proxy side".
    """

    api_key: str
    workspace_id: str = ""
    tier: str = "free"
    endpoint: str = DEFAULT_ENDPOINT


# ---------------------------------------------------------------------------
# File loader
# ---------------------------------------------------------------------------


def _load_file_profile(
    path: Path, profile: str
) -> dict[str, str] | None:
    """Read ``path`` and return the named ``[profile]`` section dict.

    Returns ``None`` if the file does not exist. Raises
    :class:`SentisecAuthError` if the file exists but is malformed
    (unreadable, invalid TOML, missing the named profile). Malformed
    file is a different failure mode from "no file" — surface it loudly.

    String coercion is defensive: TOML supports non-string scalars
    (numbers, booleans, dates) but every credential field is a string
    by contract. We coerce or reject at the boundary so the dataclass
    constructor sees only strings.
    """
    if not path.exists():
        return None

    try:
        with path.open("rb") as fh:
            data = tomllib.load(fh)
    except OSError as exc:
        raise SentisecAuthError(
            f"Could not read credentials file at {path}: {exc}. "
            "Run 'sentisec login' first."
        ) from exc
    except tomllib.TOMLDecodeError as exc:
        raise SentisecAuthError(
            f"credentials file at {path} is not valid TOML: {exc}. "
            "Run 'sentisec login' first."
        ) from exc

    if not isinstance(data, dict) or profile not in data:
        return None
    section = data[profile]
    if not isinstance(section, dict):
        return None

    # Coerce all values to strings; drop non-stringish fields.
    out: dict[str, str] = {}
    for key, value in section.items():
        if isinstance(value, str):
            out[key] = value
    return out


def _maybe_warn_file_mode(path: Path) -> None:
    """Emit a stderr warning if ``path`` has broader-than-0600 mode.

    Only runs on POSIX. Windows file ACLs are out of scope for this
    check; sentisec login on Windows places the file under ``%APPDATA%``
    where the mode bits are not meaningful. The warning is a one-line
    advisory; we never refuse to read.
    """
    if os.name != "posix":
        return
    try:
        mode = path.stat().st_mode & 0o777
    except OSError:
        return
    if mode & 0o077:
        sys.stderr.write(
            f"warning: {path} has permissive mode {oct(mode)}; "
            "expected 0o600. Run `chmod 600 {path}` to harden.\n"
        )


# ---------------------------------------------------------------------------
# Resolver — the public entry-point
# ---------------------------------------------------------------------------


def resolve_credentials(
    *,
    api_key: str | None = None,
    workspace_id: str | None = None,
    tier: str | None = None,
    endpoint: str | None = None,
    profile: str = DEFAULT_PROFILE,
    credentials_path: Path | None = None,
) -> Credentials:
    """Resolve credentials with strict ``arg > env > file`` precedence.

    Parameters
    ----------
    api_key, workspace_id, tier, endpoint:
        Explicit overrides; each takes precedence over both env and
        file for that single field. ``None`` means "fall through".
    profile:
        TOML section name; defaults to ``"default"``. Forward-looking
        for the multi-profile ``[work]`` / ``[personal]`` shape the
        SDK CLI may add later.
    credentials_path:
        Path to the credentials file. Defaults to
        :data:`DEFAULT_CREDENTIALS_PATH` expanded against ``$HOME``.

    Returns
    -------
    Credentials
        Frozen dataclass with all four fields populated.

    Raises
    ------
    SentisecAuthError
        ``api_key`` cannot be resolved from any source. ``workspace_id``
        cannot be resolved from any source. The error message names
        ``Run 'sentisec login' first``.
    """
    if credentials_path is None:
        credentials_path = DEFAULT_CREDENTIALS_PATH.expanduser()

    file_section: dict[str, str] | None = _load_file_profile(
        credentials_path, profile
    )
    if file_section is not None:
        _maybe_warn_file_mode(credentials_path)

    def _pick(
        arg_value: str | None,
        env_name: str,
        file_key: str,
    ) -> str | None:
        if arg_value is not None:
            return arg_value
        env_value = os.environ.get(env_name)
        if env_value:
            return env_value
        if file_section is not None:
            return file_section.get(file_key)
        return None

    resolved_api_key = _pick(api_key, ENV_API_KEY, "api_key")
    resolved_workspace_id = _pick(
        workspace_id, ENV_WORKSPACE_ID, "workspace_id"
    )
    resolved_tier = _pick(tier, ENV_TIER, "tier") or "free"
    resolved_endpoint = (
        _pick(endpoint, ENV_ENDPOINT, "endpoint") or DEFAULT_ENDPOINT
    )

    if not resolved_api_key:
        raise SentisecAuthError(
            "Sentisec API key not found "
            f"(checked arg, ${ENV_API_KEY}, and {credentials_path}). "
            "Run 'sentisec login' first."
        )
    # ``workspace_id`` is OPTIONAL from v0.1.0a4 onwards — the proxy
    # resolves the workspace from the API key prefix
    # (``sha256(workspace_uuid)[:8]``; see ``Credentials`` docstring).
    # Missing workspace_id is NOT an auth failure; the field falls back
    # to "" and the wrappers route to the legacy single-tenant
    # ``/v1/proxy/anthropic/v1/messages`` mount where the proxy reads
    # the workspace off the key. Callers can still pin a workspace
    # explicitly to drive the ``/ws/<id>/...`` workspace-scoped routes.
    return Credentials(
        api_key=resolved_api_key,
        workspace_id=resolved_workspace_id or "",
        tier=resolved_tier,
        endpoint=resolved_endpoint,
    )


__all__ = [
    "DEFAULT_CREDENTIALS_PATH",
    "DEFAULT_ENDPOINT",
    "DEFAULT_PROFILE",
    "ENV_API_KEY",
    "ENV_ENDPOINT",
    "ENV_TIER",
    "ENV_WORKSPACE_ID",
    "Credentials",
    "SentisecAuthError",
    "resolve_credentials",
]
