"""Top-level ``sentisec`` CLI.

Entry-point declared in ``pyproject.toml`` as
``[project.scripts] sentisec = "sentisec_sdk.cli:main"``. The CLI
exposes five subcommands plus ``--help`` and ``--version``:

- ``sentisec login`` — pair this machine with a Sentisec workspace.
  Delegates to :func:`sentisec_sdk.login.login_from_args`.

- ``sentisec status`` — print the resolved workspace + tier from
  ``~/.sentisec/credentials.toml`` (or ``unauthenticated`` if no
  credentials are present). Optionally ping the control plane to
  verify the API key is still valid.

- ``sentisec demo run`` — run a pre-canned hosted demo scenario
  against the configured control plane. Wraps
  :mod:`sentisec_sdk.cli.demo`; see that module for the scenario
  contract, the ``/v1/sdk/demo/step`` request shape, and the
  free-tier 429 path.

- ``sentisec logout`` — delete the local credentials file.

- ``sentisec edge`` — secure your Claude Code subscription session: wire
  the local thin daemon to the hosted Sentisec gate. Guided setup-or-
  status, plus ``edge status`` / ``edge off`` / ``edge on`` /
  ``edge uninstall``. This subcommand hands off to the Typer edge app
  (:data:`sentisec_sdk.edge.wizard.app`) — see "CLI unification" below.

CLI unification (GAP-2/3 — the ``sentisec`` name collision)
===========================================================

The historical SDK CLI (``login`` / ``status`` / ``demo`` / ``logout``)
is ``argparse``-based (stdlib only); the edge wizard is built on Typer.
Rather than rewrite either, the top-level ``main`` stays argparse and the
``edge`` subcommand captures the REMAINING argv with
``argparse.REMAINDER`` and forwards it to the Typer edge app. So the
SINGLE ``sentisec`` binary owns the whole surface — ``sentisec login`` is
the original argparse path; ``sentisec edge ...`` runs the Typer app with
``["edge", ...]`` stripped to ``[...]``. Bare ``sentisec`` still prints
help listing both groups.

The CLI core uses ``argparse`` (stdlib only); the ``edge`` subcommand
lazily imports the Typer app (and its ``typer`` / ``rich`` deps) only
when actually invoked, so ``sentisec login`` etc. never pay the Typer
import cost.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Sequence

import httpx

from .. import __version__
from ..credentials import (
    DEFAULT_CREDENTIALS_PATH,
    DEFAULT_PROFILE,
    SentisecAuthError,
    resolve_credentials,
)
from ..login import build_login_argparser, login_from_args

#: Default control-plane health endpoint the ``status`` command pings
#: when ``--ping`` is set. Kept on a public path so a free-tier user
#: with a stale key still gets a meaningful response.
HEALTH_PATH: str = "/v1/sdk/health"

#: HTTP timeout for the optional ``status --ping`` call.
PING_TIMEOUT_S: float = 5.0


# ---------------------------------------------------------------------------
# Argparse construction
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    """Construct the top-level ``sentisec`` argparse parser.

    The parser is exported so tests can introspect the subcommand
    surface without invoking it.
    """
    parser = argparse.ArgumentParser(
        prog="sentisec",
        description=(
            "Sentisec command-line interface. Pair this machine with a "
            "Sentisec workspace, check status, run a hosted demo, log out, "
            "or secure a Claude subscription session with `sentisec edge`. "
            "See https://docs.sentisec.ch for the full reference."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"sentisec {__version__}",
    )

    subparsers = parser.add_subparsers(
        dest="command",
        metavar="{login,status,demo,logout,edge}",
        title="commands",
    )

    # login — delegate to the login module's existing parser.
    login_parser = build_login_argparser()
    # ``add_parser`` requires the parser to be constructed by the same
    # subparsers object, so we register a fresh one and copy the
    # arguments. Doing it this way (rather than passing ``parents=``)
    # keeps the ``sentisec login --help`` heading correct.
    sub_login = subparsers.add_parser(
        "login",
        help="Pair this machine with a Sentisec workspace.",
        description=login_parser.description,
    )
    for action in login_parser._actions:  # noqa: SLF001 — controlled use
        if isinstance(action, argparse._HelpAction):  # noqa: SLF001
            continue
        # Copy each argument over to the subparser. The dispatcher reads
        # them off ``args`` by destination name.
        kwargs: dict[str, object] = {
            "dest": action.dest,
            "help": action.help,
        }
        if action.default is not argparse.SUPPRESS:
            kwargs["default"] = action.default
        if action.type is not None:
            kwargs["type"] = action.type
        if isinstance(action, argparse._StoreTrueAction):  # noqa: SLF001
            kwargs["action"] = "store_true"
            kwargs.pop("type", None)
        sub_login.add_argument(*action.option_strings, **kwargs)  # type: ignore[arg-type]

    # status
    sub_status = subparsers.add_parser(
        "status",
        help="Show the resolved workspace and tier from credentials.",
        description=(
            "Read credentials from ~/.sentisec/credentials.toml (or the "
            "configured override) and print the resolved workspace and "
            "tier. Exits 0 when credentials resolve, 1 otherwise."
        ),
    )
    sub_status.add_argument(
        "--credentials-path",
        default=None,
        type=Path,
        help=(
            "Override credentials file path. Default: "
            "~/.sentisec/credentials.toml."
        ),
    )
    sub_status.add_argument(
        "--profile",
        default=DEFAULT_PROFILE,
        help=f"Credentials profile name. Default: {DEFAULT_PROFILE!r}.",
    )
    sub_status.add_argument(
        "--ping",
        action="store_true",
        help=(
            "Also ping the control plane's health endpoint to verify "
            "the API key is still valid."
        ),
    )

    # demo
    sub_demo = subparsers.add_parser(
        "demo",
        help="Run a hosted Sentisec demo (subcommand: run).",
        description=(
            "Run a pre-canned hosted Sentisec demo scenario against the "
            "configured control plane. Run 'sentisec demo run --help' "
            "for the scenario flag surface."
        ),
    )
    demo_subs = sub_demo.add_subparsers(
        dest="demo_command",
        metavar="{run}",
        title="demo subcommands",
    )
    # Mirror the flag surface of build_demo_run_parser() exactly so the
    # parent CLI exposes the same flags as ``python -m
    # sentisec_sdk.cli.demo``. We do not pass ``parents=[...]`` because
    # that produces a doubled --help; instead we walk the template's
    # actions and copy them, the same pattern used for ``login`` above.
    from .demo import build_demo_run_parser as _build_demo_run_parser

    _demo_run_template = _build_demo_run_parser()
    demo_run = demo_subs.add_parser(
        "run",
        help="Run a pre-canned demo scenario against the control plane.",
        description=_demo_run_template.description,
    )
    for action in _demo_run_template._actions:  # noqa: SLF001 — controlled use
        if isinstance(action, argparse._HelpAction):  # noqa: SLF001
            continue
        demo_kwargs: dict[str, object] = {
            "dest": action.dest,
            "help": action.help,
        }
        if action.default is not argparse.SUPPRESS:
            demo_kwargs["default"] = action.default
        if isinstance(action, argparse._StoreTrueAction):  # noqa: SLF001
            demo_kwargs["action"] = "store_true"
        elif action.type is not None:
            demo_kwargs["type"] = action.type
        demo_run.add_argument(*action.option_strings, **demo_kwargs)  # type: ignore[arg-type]

    # logout
    sub_logout = subparsers.add_parser(
        "logout",
        help="Delete the local credentials file.",
        description=(
            "Remove ~/.sentisec/credentials.toml (or the configured "
            "override). Exits 0 whether or not the file existed; the "
            "post-condition is 'no credentials on this machine'."
        ),
    )
    sub_logout.add_argument(
        "--credentials-path",
        default=None,
        type=Path,
        help=(
            "Override credentials file path. Default: "
            "~/.sentisec/credentials.toml."
        ),
    )

    # edge — secure a Claude Code subscription session via the local thin
    # daemon + the hosted Sentisec gate. The full flag/subcommand surface
    # lives in the Typer edge app; we capture everything after ``edge``
    # with REMAINDER and forward it (see ``_dispatch_edge``). This keeps
    # the argparse parser stdlib-only — Typer is imported lazily only when
    # ``edge`` is actually run.
    sub_edge = subparsers.add_parser(
        "edge",
        help=(
            "Secure your Claude subscription session (guided setup or "
            "status). Subcommands: status, off, on, uninstall."
        ),
        description=(
            "Sentisec Edge wires the local thin daemon to the hosted "
            "Sentisec gate so your Claude Code subscription session is "
            "monitored without an API key. Run `sentisec edge` for guided "
            "setup (or the status panel once set up), `sentisec edge "
            "status`, `sentisec edge off` / `on`, or `sentisec edge "
            "uninstall`."
        ),
        add_help=False,  # the Typer app owns --help for the edge surface
    )
    sub_edge.add_argument(
        "edge_args",
        nargs=argparse.REMAINDER,
        help="Arguments forwarded to the edge wizard (e.g. status, --help).",
    )

    return parser


# ---------------------------------------------------------------------------
# Subcommand dispatchers
# ---------------------------------------------------------------------------


def _dispatch_login(args: argparse.Namespace) -> int:
    """Dispatch ``sentisec login`` to ``login_from_args``.

    The login module already exposes a ``login_from_args(argv)`` entry,
    so we re-marshal the parsed args back into a small argv list and
    forward. This keeps the login flow's argument names canonical in
    one place.
    """
    argv: list[str] = []
    if args.endpoint is not None:
        argv += ["--endpoint", str(args.endpoint)]
    if getattr(args, "code", None) is not None:
        argv += ["--code", str(args.code)]
    if args.profile is not None:
        argv += ["--profile", str(args.profile)]
    if args.credentials_path is not None:
        argv += ["--credentials-path", str(args.credentials_path)]
    if args.timeout is not None:
        argv += ["--timeout", str(args.timeout)]
    if getattr(args, "print_url_only", False):
        argv += ["--print-url-only"]
    return login_from_args(argv)


def _dispatch_status(args: argparse.Namespace) -> int:
    """Dispatch ``sentisec status``.

    Prints either ``workspace=<id> tier=<tier>`` or ``unauthenticated``
    on stdout. Exit code 0 when credentials resolve (or, with
    ``--ping``, when the health check also succeeds), 1 otherwise.
    """
    creds_path = (
        args.credentials_path
        if args.credentials_path is not None
        else DEFAULT_CREDENTIALS_PATH.expanduser()
    )
    try:
        creds = resolve_credentials(
            profile=args.profile,
            credentials_path=creds_path,
        )
    except SentisecAuthError as exc:
        print("unauthenticated")
        print(f"  hint: {exc}", file=sys.stderr)
        return 1

    print(f"workspace={creds.workspace_id} tier={creds.tier}")
    print(f"  endpoint={creds.endpoint}")

    if args.ping:
        url = creds.endpoint.rstrip("/") + HEALTH_PATH
        try:
            with httpx.Client(timeout=PING_TIMEOUT_S) as client:
                resp = client.get(
                    url,
                    headers={"Authorization": f"Bearer {creds.api_key}"},
                )
        except httpx.HTTPError as exc:
            print(
                f"  ping: failed ({exc})",
                file=sys.stderr,
            )
            return 1
        print(f"  ping: HTTP {resp.status_code}")
        if resp.status_code >= 400:
            return 1
    return 0


def _dispatch_demo(args: argparse.Namespace) -> int:
    """Dispatch ``sentisec demo …`` to the demo runner.

    The ``run`` subcommand walks a pinned scenario chain against the
    configured control plane and prints a final HALT verdict. See
    :mod:`sentisec_sdk.cli.demo` for the protocol details.
    """
    if args.demo_command != "run":
        print(
            "usage: sentisec demo run [--scenario SCENARIO] [--list] [--json]\n"
            "Run 'sentisec demo run --help' for the full flag surface.",
            file=sys.stderr,
        )
        return 2
    from .demo import dispatch as _demo_dispatch

    return _demo_dispatch(args)


def _dispatch_logout(args: argparse.Namespace) -> int:
    """Dispatch ``sentisec logout``.

    Removes the credentials file if it exists. Exits 0 either way; the
    post-condition is 'no credentials on this machine'.
    """
    creds_path = (
        args.credentials_path
        if args.credentials_path is not None
        else DEFAULT_CREDENTIALS_PATH.expanduser()
    )
    if creds_path.exists():
        try:
            os.remove(creds_path)
        except OSError as exc:
            print(
                f"sentisec: could not remove {creds_path}: {exc}",
                file=sys.stderr,
            )
            return 1
        print(f"sentisec: removed {creds_path}")
    else:
        print(f"sentisec: no credentials at {creds_path}")
    return 0


def _dispatch_edge(edge_args: Sequence[str]) -> int:
    """Dispatch ``sentisec edge ...`` to the Typer edge app.

    ``edge_args`` is everything after the ``edge`` token (``["status"]``
    for ``sentisec edge status``, ``["--help"]`` for ``sentisec edge
    --help``, ``[]`` for bare ``sentisec edge`` — its guided-setup-or-
    status callback). We forward it verbatim to the Typer edge app.

    Why ``main`` intercepts ``edge`` BEFORE argparse: ``argparse`` cannot
    cleanly forward an edge surface that includes its own ``--help`` /
    options (``argparse.REMAINDER`` drops a leading ``--help``), so the
    top-level ``main`` peels off the ``edge`` token itself and hands the
    rest straight here. The ``edge`` subparser still exists purely so
    ``sentisec --help`` lists the group.

    Typer's app raises ``SystemExit`` on completion (including ``--help``
    and ``--abort``); we translate it to an int return so the top-level
    ``main`` contract (returns an exit code) holds and tests can assert.

    Imported lazily — ``typer`` / ``rich`` / the edge stack load only when
    ``edge`` is actually invoked, so the other subcommands stay cheap.
    """
    from ..edge.wizard import app as edge_app

    try:
        # ``prog_name`` makes Typer's --help banner read "sentisec edge"
        # rather than the host interpreter's argv[0].
        edge_app(args=list(edge_args), prog_name="sentisec edge")
    except SystemExit as exc:
        code = exc.code
        if code is None:
            return 0
        if isinstance(code, int):
            return code
        # A non-int exit code (a message string) — print + non-zero.
        print(str(code), file=sys.stderr)
        return 1
    return 0


# ---------------------------------------------------------------------------
# Entry-point
# ---------------------------------------------------------------------------


def main(argv: Sequence[str] | None = None) -> int:
    """``sentisec`` CLI entry-point. Returns an exit code.

    Argv defaults to ``sys.argv[1:]`` when ``None``. Returning the
    exit code (rather than calling ``sys.exit``) lets tests invoke
    ``main([...])`` directly and assert.
    """
    raw_argv = list(sys.argv[1:] if argv is None else argv)

    # Intercept ``edge`` BEFORE argparse: the edge surface carries its own
    # ``--help`` / options that ``argparse.REMAINDER`` cannot forward
    # cleanly. When the first token is ``edge`` we peel it off and hand the
    # rest straight to the Typer edge app. (``-h`` / ``--help`` / a typo
    # appearing BEFORE ``edge`` still falls through to argparse below — the
    # interception is positional-first only.)
    if raw_argv and raw_argv[0] == "edge":
        return _dispatch_edge(raw_argv[1:])

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return 0
    if args.command == "login":
        return _dispatch_login(args)
    if args.command == "status":
        return _dispatch_status(args)
    if args.command == "demo":
        return _dispatch_demo(args)
    if args.command == "logout":
        return _dispatch_logout(args)
    if args.command == "edge":
        # Reached only if ``edge`` was not the first token (e.g. behind a
        # global flag argparse consumed). Forward the captured REMAINDER.
        return _dispatch_edge(list(getattr(args, "edge_args", []) or []))
    # argparse rejects unknown subcommands before we get here, so this is
    # unreachable. Defensive return keeps mypy strict happy.
    parser.print_help()
    return 2


__all__ = [
    "HEALTH_PATH",
    "PING_TIMEOUT_S",
    "build_parser",
    "main",
]


if __name__ == "__main__":  # pragma: no cover — exercised by entry-point
    raise SystemExit(main())
