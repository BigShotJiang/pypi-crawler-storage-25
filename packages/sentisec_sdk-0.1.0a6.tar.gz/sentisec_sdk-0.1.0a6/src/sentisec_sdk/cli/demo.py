"""``sentisec demo run`` — hosted demo runner for the public SDK.

The runner walks a pinned scenario chain (see
:mod:`sentisec_sdk.cli._scenarios`) against a Sentisec control plane.
For each step it POSTs ``/v1/sdk/demo/step`` with ``{scenario,
step_index, tool_call}`` and receives ``{verdict, level,
rule_id}``. The chain stops when the control plane returns a
non-``ALLOW`` verdict; the runner asserts the verdict matches the
manifest's ``expected_verdict`` (regression contract from
T-DIST-DEMO-SCENARIOS) and exits 0 on match, 1 on mismatch.

Public surface
--------------

::

    sentisec demo run --scenario portfolio-exfil
    sentisec demo run --scenario web-fetch-shell --json
    sentisec demo run --list
    sentisec demo run --scenario portfolio-exfil --proxy-base-url http://localhost:8000

Network discipline
------------------

* Default proxy base URL is the endpoint resolved from local
  credentials (i.e. ``https://api.sentisec.ch`` per
  ``wiki/decisions/d-013-default-control-plane-target.md``).
* ``--proxy-base-url`` overrides the resolved endpoint. The flag
  exists for tests and for power users running a local proxy. It
  does NOT bypass authentication: the CLI still resolves credentials
  for the API key.
* Free-tier 429 — the runner prints the canonical
  ``Free tier limit reached, run 'sentisec status' to upgrade``
  message and exits 1.

Refs:
  docs/PROD_DEPLOY_DECISIONS.md §1.6 — locked v0.1 scenario set
  wiki/decisions/d-013-default-control-plane-target.md
  platform/TASKS_PROD_DEPLOY.md T-DIST-DEMO-CLI, T-DIST-DEMO-SCENARIOS
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from typing import Any

import httpx

from ..credentials import (
    DEFAULT_CREDENTIALS_PATH,
    DEFAULT_ENDPOINT,
    DEFAULT_PROFILE,
    Credentials,
    SentisecAuthError,
    resolve_credentials,
)
from ._scenarios import (
    SCENARIO_IDS,
    Scenario,
    all_scenarios,
    format_scenario_list,
    format_unknown_scenario_message,
    get_scenario,
)

#: Path on the control plane the demo runner posts each step to.
DEMO_STEP_PATH: str = "/v1/sdk/demo/step"

#: Default per-step HTTP timeout. Each step is one POST; the runner
#: caps the wait at this many seconds before surfacing a clear error.
DEFAULT_STEP_TIMEOUT_S: float = 15.0

#: Canonical free-tier 429 message. Pinned by the T-DIST-DEMO-CLI
#: acceptance test.
FREE_TIER_429_MESSAGE: str = (
    "Free tier limit reached, run 'sentisec status' to upgrade"
)


@dataclass(frozen=True)
class StepResult:
    """One control-plane decision, recorded for the final summary."""

    step_index: int
    tool_call: str
    verdict: str
    level: int
    rule_id: str | None


@dataclass(frozen=True)
class DemoRunSummary:
    """Outcome of one ``sentisec demo run --scenario <id>`` invocation.

    ``mismatch`` is True iff the final verdict diverged from the
    scenario's pinned ``expected_verdict``; the CLI exits 1 in that
    case (T-DIST-DEMO-SCENARIOS regression contract).
    """

    scenario_id: str
    expected_verdict: str
    actual_verdict: str
    expected_rule_id: str
    actual_rule_id: str | None
    halt_on_step: int
    actual_halt_step: int | None
    steps: tuple[StepResult, ...]
    mismatch: bool


# ---------------------------------------------------------------------------
# Argparse
# ---------------------------------------------------------------------------


def build_demo_run_parser() -> argparse.ArgumentParser:
    """Construct the ``sentisec demo run`` subparser.

    Exported so the top-level CLI can register it under
    ``demo`` → ``run`` and so tests can introspect the flag surface.
    """
    parser = argparse.ArgumentParser(
        prog="sentisec demo run",
        description=(
            "Run a pre-canned Sentisec demo scenario against the "
            "configured control plane. The control plane runs the "
            "monitored agent chain server-side; this CLI walks the "
            "pinned tool-call sequence and prints the final verdict."
        ),
    )
    parser.add_argument(
        "--scenario",
        default=None,
        help=(
            "Scenario id to run. Required unless --list is set. "
            f"Available: {', '.join(SCENARIO_IDS)}."
        ),
    )
    parser.add_argument(
        "--list",
        action="store_true",
        dest="list_scenarios",
        help="List the available scenarios and exit 0.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Emit machine-readable JSON output for CI piping.",
    )
    parser.add_argument(
        "--proxy-base-url",
        default=None,
        help=(
            "Override the control-plane base URL. Default is the "
            "endpoint resolved from credentials (typically "
            "https://api.sentisec.ch). Tests use this flag to point "
            "at a local mock control plane."
        ),
    )
    parser.add_argument(
        "--credentials-path",
        default=None,
        help=(
            "Override credentials file path. Default: "
            "~/.sentisec/credentials.toml."
        ),
    )
    parser.add_argument(
        "--profile",
        default=DEFAULT_PROFILE,
        help=f"Credentials profile name. Default: {DEFAULT_PROFILE!r}.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_STEP_TIMEOUT_S,
        help=(
            f"Per-step HTTP timeout in seconds. "
            f"Default: {DEFAULT_STEP_TIMEOUT_S}."
        ),
    )
    return parser


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def _build_client(timeout: float) -> httpx.Client:
    """Construct the httpx client. Factored out so tests can patch it."""
    return httpx.Client(timeout=timeout)


def _post_step(
    client: httpx.Client,
    *,
    base_url: str,
    api_key: str,
    workspace_id: str,
    scenario_id: str,
    step_index: int,
    tool_call: str,
) -> httpx.Response:
    """POST one step to the control plane. Returns the raw response.

    Network-level errors are surfaced by httpx's own exception
    hierarchy (``httpx.HTTPError``); the caller renders them.
    """
    url = base_url.rstrip("/") + DEMO_STEP_PATH
    payload = {
        "scenario": scenario_id,
        "workspace_id": workspace_id,
        "step_index": step_index,
        "tool_call": tool_call,
    }
    return client.post(
        url,
        json=payload,
        headers={"Authorization": f"Bearer {api_key}"},
    )


def run_scenario(
    scenario: Scenario,
    *,
    base_url: str,
    api_key: str,
    workspace_id: str,
    timeout: float = DEFAULT_STEP_TIMEOUT_S,
    client: httpx.Client | None = None,
) -> DemoRunSummary | None:
    """Walk one scenario's chain against the control plane.

    Returns the :class:`DemoRunSummary` on a normal completion
    (verdict was either ALLOW for every step or HALT/REVIEW at some
    step). Returns ``None`` if the run aborted because the control
    plane returned a 429 free-tier limit; the caller is expected to
    print :data:`FREE_TIER_429_MESSAGE` and exit 1.

    The function does NOT raise on a verdict mismatch — it records
    the mismatch on the summary and returns. The CLI dispatcher
    converts that into an exit code.
    """
    own_client = client is None
    if client is None:
        client = _build_client(timeout)
    try:
        results: list[StepResult] = []
        actual_verdict = "ALLOW"
        actual_rule_id: str | None = None
        actual_halt_step: int | None = None
        for idx, tool_call in enumerate(scenario.steps, start=1):
            resp = _post_step(
                client,
                base_url=base_url,
                api_key=api_key,
                workspace_id=workspace_id,
                scenario_id=scenario.id,
                step_index=idx,
                tool_call=tool_call,
            )
            if resp.status_code == 429:
                return None
            resp.raise_for_status()
            data: dict[str, Any] = resp.json()
            verdict = str(data.get("verdict", "ALLOW")).upper()
            level_raw = data.get("level", 0)
            try:
                level = int(level_raw)
            except (TypeError, ValueError):
                level = 0
            rule_id_raw = data.get("rule_id")
            rule_id = str(rule_id_raw) if rule_id_raw is not None else None
            results.append(
                StepResult(
                    step_index=idx,
                    tool_call=tool_call,
                    verdict=verdict,
                    level=level,
                    rule_id=rule_id,
                )
            )
            if verdict != "ALLOW":
                actual_verdict = verdict
                actual_rule_id = rule_id
                actual_halt_step = idx
                break
    finally:
        if own_client:
            client.close()

    mismatch = (
        actual_verdict != scenario.expected_verdict
        or (
            scenario.expected_rule_id != ""
            and actual_rule_id != scenario.expected_rule_id
        )
        or actual_halt_step != scenario.halt_on_step
    )
    return DemoRunSummary(
        scenario_id=scenario.id,
        expected_verdict=scenario.expected_verdict,
        actual_verdict=actual_verdict,
        expected_rule_id=scenario.expected_rule_id,
        actual_rule_id=actual_rule_id,
        halt_on_step=scenario.halt_on_step,
        actual_halt_step=actual_halt_step,
        steps=tuple(results),
        mismatch=mismatch,
    )


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------


def render_summary_human(summary: DemoRunSummary) -> str:
    """Render the human-readable summary the CLI prints by default."""
    lines = [f"scenario: {summary.scenario_id}"]
    for step in summary.steps:
        rule = f" rule_id={step.rule_id}" if step.rule_id else ""
        lines.append(
            f"  step {step.step_index}: {step.tool_call}\n"
            f"    -> verdict={step.verdict} level={step.level}"
            f"{rule}"
        )
    final = (
        f"\nfinal: verdict={summary.actual_verdict} "
        f"rule_id={summary.actual_rule_id} "
        f"halted_on_step={summary.actual_halt_step}"
    )
    lines.append(final)
    if summary.mismatch:
        lines.append(
            "WARNING: actual verdict / rule / step diverged from the "
            f"manifest expectation (expected verdict="
            f"{summary.expected_verdict}, rule_id="
            f"{summary.expected_rule_id}, halt_on_step="
            f"{summary.halt_on_step})."
        )
    return "\n".join(lines)


def render_summary_json(summary: DemoRunSummary) -> str:
    """Render the machine-readable JSON summary for ``--json``."""
    payload = {
        "scenario_id": summary.scenario_id,
        "expected_verdict": summary.expected_verdict,
        "actual_verdict": summary.actual_verdict,
        "expected_rule_id": summary.expected_rule_id,
        "actual_rule_id": summary.actual_rule_id,
        "halt_on_step": summary.halt_on_step,
        "actual_halt_step": summary.actual_halt_step,
        "mismatch": summary.mismatch,
        "steps": [
            {
                "step_index": s.step_index,
                "tool_call": s.tool_call,
                "verdict": s.verdict,
                "level": s.level,
                "rule_id": s.rule_id,
            }
            for s in summary.steps
        ],
    }
    return json.dumps(payload, indent=2)


# ---------------------------------------------------------------------------
# Top-level dispatcher used by sentisec_sdk.cli
# ---------------------------------------------------------------------------


def _resolve_credentials_for_demo(
    args: argparse.Namespace,
) -> Credentials | None:
    """Resolve credentials with the same precedence as ``status``.

    Returns ``None`` if no credentials are present and the caller has
    not pointed at a local mock via ``--proxy-base-url``. The caller
    is expected to print a clear error and exit 1.
    """
    creds_path = args.credentials_path
    if creds_path is not None:
        from pathlib import Path as _Path

        creds_path = _Path(str(creds_path)).expanduser()
    else:
        creds_path = DEFAULT_CREDENTIALS_PATH.expanduser()
    try:
        return resolve_credentials(
            profile=args.profile,
            credentials_path=creds_path,
        )
    except SentisecAuthError:
        return None


def dispatch(args: argparse.Namespace) -> int:
    """Top-level dispatcher for ``sentisec demo run``.

    Returns the CLI exit code. Pulled out of :func:`main` so the
    parent ``sentisec`` CLI can invoke it directly without spawning a
    subprocess (the entry-point in ``sentisec_sdk.cli.__init__`` calls
    ``dispatch`` with the parsed namespace).
    """
    if args.list_scenarios:
        print(format_scenario_list(all_scenarios()))
        return 0

    if args.scenario is None:
        sys.stderr.write(
            "sentisec demo run: --scenario is required (or pass --list).\n"
            f"Available scenarios: {', '.join(SCENARIO_IDS)}.\n"
        )
        return 2

    try:
        scenario = get_scenario(args.scenario)
    except KeyError:
        sys.stderr.write(format_unknown_scenario_message(args.scenario) + "\n")
        return 2

    proxy_base_url = args.proxy_base_url
    api_key: str
    workspace_id: str
    if proxy_base_url is not None:
        # Honour test override even when no credentials file exists.
        creds = _resolve_credentials_for_demo(args)
        if creds is not None:
            api_key = creds.api_key
            workspace_id = creds.workspace_id
        else:
            api_key = "sk_demo_local"
            workspace_id = "ws-demo-local"
    else:
        creds = _resolve_credentials_for_demo(args)
        if creds is None:
            sys.stderr.write(
                "sentisec demo run: no credentials found. "
                "Run 'sentisec login' first, or pass --proxy-base-url "
                "to point at a local mock control plane.\n"
            )
            return 1
        proxy_base_url = creds.endpoint or DEFAULT_ENDPOINT
        api_key = creds.api_key
        workspace_id = creds.workspace_id

    try:
        summary = run_scenario(
            scenario,
            base_url=proxy_base_url,
            api_key=api_key,
            workspace_id=workspace_id,
            timeout=args.timeout,
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 401:
            sys.stderr.write(
                "sentisec demo run: control-plane rejected the Sentisec "
                "API key (401). If you just ran `sentisec login`, check "
                "for stale SENTISEC_API_KEY or SENTISEC_WORKSPACE_ID "
                "environment variables overriding "
                "~/.sentisec/credentials.toml.\n"
            )
            return 1
        sys.stderr.write(
            f"sentisec demo run: control-plane request failed: {exc}\n"
        )
        return 1
    except httpx.HTTPError as exc:
        sys.stderr.write(
            f"sentisec demo run: control-plane request failed: {exc}\n"
        )
        return 1

    if summary is None:
        # 429 free-tier path.
        print(FREE_TIER_429_MESSAGE)
        return 1

    if args.json_output:
        print(render_summary_json(summary))
    else:
        print(render_summary_human(summary))

    if summary.mismatch:
        return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    """Standalone entry-point: ``python -m sentisec_sdk.cli.demo``.

    Mirrors :func:`dispatch` so the module is invokable as a script for
    debugging without going through the top-level ``sentisec`` CLI.
    """
    parser = build_demo_run_parser()
    args = parser.parse_args(argv)
    return dispatch(args)


__all__ = [
    "DEFAULT_STEP_TIMEOUT_S",
    "DEMO_STEP_PATH",
    "DemoRunSummary",
    "FREE_TIER_429_MESSAGE",
    "StepResult",
    "build_demo_run_parser",
    "dispatch",
    "main",
    "render_summary_human",
    "render_summary_json",
    "run_scenario",
]


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
