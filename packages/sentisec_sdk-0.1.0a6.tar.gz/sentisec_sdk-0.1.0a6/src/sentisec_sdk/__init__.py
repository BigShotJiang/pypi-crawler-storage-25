"""Sentisec public Python SDK — thin client.

This package is the public distribution surface published to PyPI as
``sentisec-sdk``. It ships only the client-side primitives an end-user
agent loop needs: a transport, a credentials loader, ``login`` /
``logout`` helpers, ``Monitor`` / ``Session`` types, and ``wrap_openai``
/ ``wrap_anthropic`` adapters that route subsequent client calls through
the Sentisec control plane.

The control-plane computation itself runs server-side and is not part
of this wheel. See https://docs.sentisec.ch for the public reference.

Public surface
--------------

::

    from sentisec_sdk import (
        Monitor,
        Session,
        wrap_openai,
        wrap_anthropic,
        __version__,
    )

Importing the public names always succeeds. The ``Monitor`` constructor
resolves credentials lazily and raises a clear error when none are
present, naming ``sentisec login`` as the recovery path.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _pkg_version

from .monitor import Monitor
from .session import Session
from .wrappers import wrap_anthropic, wrap_openai

__all__ = [
    "Monitor",
    "Session",
    "__version__",
    "wrap_anthropic",
    "wrap_openai",
]

# Single source of truth: ``[project].version`` in ``pyproject.toml``.
# At import time we read the version Pip recorded in the installed
# distribution's METADATA. A release only bumps the version in ONE
# place (pyproject.toml) — the wheel filename, the PyPI release name,
# and ``sentisec_sdk.__version__`` all derive from it.
#
# ``PackageNotFoundError`` only fires when the package is being run
# from an uninstalled source checkout (e.g. ``python -c 'import
# sentisec_sdk'`` with ``PYTHONPATH=src``); in that case we fall back
# to a sentinel that is obviously not a release.
try:
    __version__: str = _pkg_version("sentisec-sdk")
except PackageNotFoundError:  # pragma: no cover — only hit in uninstalled-source mode
    __version__ = "0.0.0+local"
