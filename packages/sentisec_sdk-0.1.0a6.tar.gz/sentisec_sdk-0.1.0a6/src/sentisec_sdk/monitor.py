"""``sentisec_sdk.Monitor`` — the public SDK entrypoint.

A ``Monitor`` resolves credentials once on construction, then exposes
two thin client adapters: ``wrap_openai`` and ``wrap_anthropic``. Each
adapter rewrites the underlying SDK client's ``base_url`` so subsequent
calls flow through the Sentisec control plane, and arranges for the
proxy to authenticate the call with the resolved API key.

Construction is cheap and side-effect-free: it touches the local
filesystem (to read ``~/.sentisec/credentials.toml``) and the process
environment, but does NOT issue any network call. The first network
call happens when the wrapped client is actually invoked.

Public surface
--------------

::

    from sentisec_sdk import Monitor

    monitor = Monitor()
    client = monitor.wrap_openai(my_openai_client)
    client = monitor.wrap_anthropic(my_anthropic_client)

The ``Monitor`` class is the documented entry-point; the
provider-specific helpers in ``sentisec_sdk.wrappers`` are also
exposed at the package root for users who want to skip the Monitor
construction.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .credentials import Credentials, resolve_credentials


class Monitor:
    """Sentisec SDK entrypoint.

    Resolves credentials in the standard ``arg > env > file`` order on
    construction. The resolved credentials are exposed as ``api_key``
    / ``workspace_id`` / ``tier`` / ``endpoint`` for callers that want
    to introspect, and are consumed by ``wrap_openai`` /
    ``wrap_anthropic`` to configure the wrapped clients.

    Parameters
    ----------
    api_key:
        Optional explicit API key. Overrides env + file.
    workspace_id:
        Optional explicit workspace id. Overrides env + file.
    tier:
        Optional explicit tier. Overrides env + file.
    endpoint:
        Optional explicit control-plane URL. Overrides env + file.
    profile:
        TOML profile name. Default ``"default"``.
    credentials_path:
        Override credentials file path. Default
        ``~/.sentisec/credentials.toml``.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        workspace_id: str | None = None,
        tier: str | None = None,
        endpoint: str | None = None,
        profile: str = "default",
        credentials_path: Path | None = None,
    ) -> None:
        self._credentials: Credentials = resolve_credentials(
            api_key=api_key,
            workspace_id=workspace_id,
            tier=tier,
            endpoint=endpoint,
            profile=profile,
            credentials_path=credentials_path,
        )

    # -- accessors ---------------------------------------------------

    @property
    def credentials(self) -> Credentials:
        """The resolved credentials this Monitor will pass to wrappers."""
        return self._credentials

    @property
    def api_key(self) -> str:
        return self._credentials.api_key

    @property
    def workspace_id(self) -> str:
        return self._credentials.workspace_id

    @property
    def tier(self) -> str:
        return self._credentials.tier

    @property
    def endpoint(self) -> str:
        return self._credentials.endpoint

    # -- wrappers ----------------------------------------------------

    def wrap_openai(self, client: Any) -> Any:
        """Wrap an OpenAI client to flow through the control plane.

        Mutates the client in place and returns the same reference,
        matching the OpenAI SDK's own pattern of in-place
        ``client.base_url = ...`` reassignment.
        """
        from .wrappers.openai import wrap_openai

        return wrap_openai(client, credentials=self._credentials)

    def wrap_anthropic(self, client: Any) -> Any:
        """Wrap an Anthropic client to flow through the control plane.

        Mutates the client in place and returns the same reference.
        """
        from .wrappers.anthropic import wrap_anthropic

        return wrap_anthropic(client, credentials=self._credentials)


__all__ = ["Monitor"]
