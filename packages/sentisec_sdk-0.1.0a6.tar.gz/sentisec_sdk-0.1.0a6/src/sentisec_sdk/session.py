"""``sentisec_sdk.Session`` — public session value type.

A ``Session`` is the user-visible record of a single agent run as
observed by the Sentisec control plane. The fields here are the
client-shipped subset; richer forensic detail stays server-side and is
viewable from the Sentisec dashboard.

The class is intentionally tiny — a frozen dataclass plus a
``from_response_headers`` adapter the wrappers use to populate session
state from a wrapped client's response.

Public surface
--------------

::

    from sentisec_sdk import Session

    s = Session(
        session_id="ses_xxx",
        workspace_id="ws_yyy",
    )
    print(s.session_id)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Session:
    """A single Sentisec session as the SDK sees it.

    Fields
    ------
    session_id:
        Opaque identifier minted by the control plane on first call.
        Echoed back via the ``x-sentisec-session-id`` response header.
    workspace_id:
        Workspace the session belongs to. Pinned at construction time
        from the resolved credentials.
    started_at:
        ISO-8601 timestamp of the first observed call. ``None`` if the
        session is constructed before the first call lands.
    ended_at:
        ISO-8601 timestamp of the session close. ``None`` while the
        session is still open.
    decision:
        Coarse outcome label the dashboard surfaces. One of
        ``"open"`` / ``"clean"`` / ``"intervened"`` / ``"halted"``.
        The wrappers ship sessions in the ``"open"`` state; the
        control plane is the source of truth on transition.
    """

    session_id: str
    workspace_id: str
    started_at: str | None = None
    ended_at: str | None = None
    decision: str = "open"


__all__ = ["Session"]
