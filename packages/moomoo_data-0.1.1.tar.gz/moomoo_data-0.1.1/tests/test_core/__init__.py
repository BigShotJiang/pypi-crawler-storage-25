"""Tests for core module."""
