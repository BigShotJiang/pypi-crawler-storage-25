"""Version information for moomoo-data."""

__version__ = "0.1.1"
__version_tuple__ = (0, 1, 1)
