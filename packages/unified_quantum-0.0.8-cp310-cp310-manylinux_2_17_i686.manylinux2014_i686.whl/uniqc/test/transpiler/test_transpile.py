from uniqc.test._utils import uniq_test
from uniqc.compile.timeline import format_result, create_time_line_table, plot_time_line
from uniqc.compile import plot_time_line as plot_time_line_exported
import json


@uniq_test('Test Transpile.PlotTimeLine')
def run_test_transpile_plot_time_line():
    pulse_sequence = '''[{"RPhi":[25,0.0,90.0,0]},{"RPhi":[26,180.0,90.0,0]},{"RPhi":[27,180.0,90.0,0]},{"RPhi":[28,180.0,90.0,0]},{"RPhi":[29,0.0,90.0,0]},{"RPhi":[25,176.8084520478672,90.0,30]},{"RPhi":[26,359.1759778286208,90.0,30]},{"RPhi":[27,305.14741508480088,90.0,30]},{"RPhi":[28,339.4245991356841,90.0,30]},{"RPhi":[29,115.70026006739696,90.0,30]},{"RPhi":[26,269.17597782862085,90.0,60]},{"RPhi":[28,249.4245991356841,90.0,60]},{"CZ":[25,26,90]},{"CZ":[27,28,90]},{"RPhi":[26,149.06068473909554,90.0,130]},{"RPhi":[28,321.1126575441533,90.0,130]},{"RPhi":[25,109.35370990881589,90.0,160]},{"RPhi":[27,19.476598469673438,90.0,160]},{"RPhi":[29,205.700260067397,90.0,160]},{"RPhi":[25,220.0517189739886,90.0,190]},{"CZ":[26,27,190]},{"CZ":[28,29,190]},{"RPhi":[26,339.0696260425817,90.0,230]},{"RPhi":[27,199.15574210440026,90.0,230]},{"RPhi":[28,42.29155136981484,90.0,230]},{"RPhi":[29,195.14022698483644,90.0,230]},{"RPhi":[26,156.55175040680769,90.0,260]},{"RPhi":[27,109.15574210440025,90.0,260]},{"RPhi":[28,124.77798548788978,90.0,260]},{"RPhi":[29,105.14022698483645,90.0,260]},{"RPhi":[26,66.55175040680799,90.0,290]},{"RPhi":[27,202.48893592604845,90.0,290]},{"RPhi":[28,214.7779854878898,90.0,290]},{"RPhi":[29,246.7727688542387,90.0,290]},{"CZ":[25,26,320]},{"CZ":[27,28,320]},{"RPhi":[26,306.4364573172824,90.0,360]},{"RPhi":[28,286.4660438963588,90.0,360]},{"RPhi":[25,152.59697683493745,90.0,390]},{"RPhi":[27,96.81811931092088,90.0,390]},{"RPhi":[29,336.7727688542386,90.0,390]},{"RPhi":[25,164.809782146384,90.0,420]},{"CZ":[26,27,420]},{"CZ":[28,29,420]},{"RPhi":[26,316.4453986207685,90.0,460]},{"RPhi":[27,276.4972629456473,90.0,460]},{"RPhi":[28,7.644937722020551,90.0,460]},{"RPhi":[29,326.212735771678,90.0,460]},{"RPhi":[26,334.4785779323604,90.0,490]},{"RPhi":[27,186.4972629456473,90.0,490]},{"RPhi":[28,173.87318722134314,90.0,490]},{"RPhi":[29,236.21273577167805,90.0,490]},{"RPhi":[26,64.47857793236041,90.0,520]},{"RPhi":[27,336.5108538253065,90.0,520]},{"RPhi":[28,263.8731872213429,90.0,520]},{"RPhi":[29,38.34190024631248,90.0,520]},{"CZ":[25,26,550]},{"CZ":[27,28,550]},{"RPhi":[26,304.3632848428349,90.0,590]},{"RPhi":[28,335.5612456298116,90.0,590]},{"RPhi":[25,97.35504000733246,90.0,620]},{"RPhi":[27,230.84003721017914,90.0,620]},{"RPhi":[29,128.3419002463122,90.0,620]},{"RPhi":[25,145.14322682862918,90.0,650]},{"CZ":[26,27,650]},{"CZ":[28,29,650]},{"RPhi":[26,314.37222614632096,90.0,690]},{"RPhi":[27,50.51918084490556,90.0,690]},{"RPhi":[28,236.74013945547297,90.0,690]},{"RPhi":[29,117.78186716375169,90.0,690]},{"RPhi":[26,39.83823846951509,90.0,720]},{"RPhi":[27,320.5191808449052,90.0,720]},{"RPhi":[28,34.098638457970697,90.0,720]},{"RPhi":[29,27.78186716375135,90.0,720]},{"RPhi":[26,129.83823846951578,90.0,750]},{"RPhi":[27,128.09646978610398,90.0,750]},{"RPhi":[28,304.0986384579707,90.0,750]},{"RPhi":[29,108.3855825935067,90.0,750]},{"CZ":[25,26,780]},{"CZ":[27,28,780]},{"RPhi":[26,9.722945379990833,90.0,820]},{"RPhi":[28,15.786696866440052,90.0,820]},{"RPhi":[27,22.425653170975936,90.0,850]},{"RPhi":[29,198.38558259350737,90.0,850]},{"CZ":[26,27,880]},{"CZ":[28,29,880]},{"RPhi":[27,202.1047968057033,90.0,920]},{"RPhi":[29,187.82554951094657,90.0,920]},{"RPhi":[31,270.0,90.0,950]},{"RPhi":[33,270.0,90.0,950]},{"RPhi":[35,270.0,90.0,950]},{"CZ":[25,31,980]},{"CZ":[27,33,980]},{"CZ":[29,35,980]},{"RPhi":[31,249.9016083459824,90.0,1020]},{"RPhi":[33,213.96430671790609,90.0,1020]},{"RPhi":[35,254.2546988715056,90.0,1020]},{"RPhi":[32,270.0,90.0,1050]},{"RPhi":[34,270.0,90.0,1050]},{"RPhi":[36,270.0,90.0,1050]},{"CZ":[26,32,1080]},{"CZ":[28,34,1080]},{"CZ":[30,36,1080]},{"RPhi":[32,305.4484778664446,90.0,1120]},{"RPhi":[34,200.57131474384017,90.0,1120]},{"RPhi":[36,322.85493568251908,90.0,1120]},{"Measure":[[36,35,34,33,32,31,30,29,28,27,26,25],1150]}]'''

    data = json.loads(pulse_sequence)
    plot_time_line(pulse_sequence)


@uniq_test('Test Transpile.Timeline.format_result')
def run_test_format_result():
    """Test format_result function with various gate types."""
    # Test with RPhi90 gates
    pulse_rphi90 = json.dumps([
        {"RPhi": [0, 45.0, 90.0, 0]},
        {"RPhi": [1, 90.0, 90.0, 10]}
    ])
    gate_layers, qubit_list, time_line = format_result(pulse_rphi90)
    assert 0 in qubit_list and 1 in qubit_list
    assert 0 in time_line and 10 in time_line
    print(f"RPhi90 parsed: qubits={qubit_list}, timeline={time_line}")

    # Test with RPhi180 gates (covers lines 41-45)
    pulse_rphi180 = json.dumps([
        {"RPhi": [0, 45.0, 180.0, 0]},
        {"RPhi": [1, 90.0, 180.0, 10]}
    ])
    gate_layers, qubit_list, time_line = format_result(pulse_rphi180)
    # Check that RPhi180 gates are correctly categorized
    for layer, gates in gate_layers.items():
        for gate_name, qubit, angle, time in gates:
            assert gate_name == 'RPhi180'
    print(f"RPhi180 parsed: qubits={qubit_list}, timeline={time_line}")

    # Test with CZ gates
    pulse_cz = json.dumps([
        {"CZ": [0, 1, 100]}
    ])
    gate_layers, qubit_list, time_line = format_result(pulse_cz)
    assert 0 in qubit_list and 1 in qubit_list
    print(f"CZ parsed: qubits={qubit_list}")

    # Test with Measure gates
    pulse_measure = json.dumps([
        {"Measure": [[0, 1, 2], 200]}
    ])
    gate_layers, qubit_list, time_line = format_result(pulse_measure)
    assert 0 in qubit_list and 1 in qubit_list and 2 in qubit_list
    print(f"Measure parsed: qubits={qubit_list}")


@uniq_test('Test Transpile.Timeline.create_time_line_table')
def run_test_create_time_line_table():
    """Test create_time_line_table function."""
    # Create a simple layer dict
    layer_dict = {
        0: [('RPhi90', 0, 45.0, 0), ('RPhi90', 1, 90.0, 0)],
        1: [('CZ', [0, 1], 0, 10)],
        2: [('Measure', [0, 1], 0, 100)]
    }
    qubit_list = [0, 1]
    time_line = [0, 10, 100]

    table = create_time_line_table(layer_dict, qubit_list, time_line)
    assert len(table) == 2  # 2 qubits
    assert len(table.columns) == 3  # 3 time steps
    print(f"Table created with shape {table.shape}")


if __name__ == '__main__':
    run_test_transpile_plot_time_line()
    run_test_format_result()
    run_test_create_time_line_table()