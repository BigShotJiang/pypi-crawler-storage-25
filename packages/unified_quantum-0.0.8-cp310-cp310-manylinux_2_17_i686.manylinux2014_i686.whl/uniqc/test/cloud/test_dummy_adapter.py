"""Tests for the dummy_adapter module."""

from __future__ import annotations

import importlib

import pytest


@pytest.mark.requires_cpp
class TestDummyAdapter:
    """Tests for DummyAdapter."""

    @pytest.fixture
    def adapter(self):
        """Create a DummyAdapter instance."""
        from uniqc.backend_adapter.task.adapters.dummy_adapter import DummyAdapter
        return DummyAdapter()

    def test_name(self, adapter):
        """Test adapter name."""
        assert adapter.name == "dummy"

    def test_is_available(self, adapter):
        """Test is_available returns True."""
        assert adapter.is_available()

    def test_translate_circuit(self, adapter):
        """Test translate_circuit returns circuit unchanged."""
        circuit = "QINIT 2\nH q[0]"
        result = adapter.translate_circuit(circuit)
        assert result == circuit

    def test_query_returns_result(self, adapter):
        """Test query returns a result dict."""
        circuit = "QINIT 2\nCREG 2\nH q[0]\nMEASURE q[0], c[0]"
        task_id = adapter.submit(circuit, shots=1000)

        result = adapter.query(task_id)

        assert "status" in result
        assert result["status"] == "success"
        assert "result" in result

    def test_query_nonexistent_task(self, adapter):
        """Test query for nonexistent task returns failed."""
        result = adapter.query("nonexistent-task-id")

        assert result["status"] == "failed"
        assert "error" in result

    def test_deterministic_task_id(self, adapter):
        """Test that same circuit produces same task ID."""
        circuit = "QINIT 2\nCREG 2\nH q[0]\nMEASURE q[0], c[0]"

        task_id1 = adapter.submit(circuit)
        task_id2 = adapter.submit(circuit)

        assert task_id1 == task_id2

    def test_different_circuits_different_ids(self, adapter):
        """Test that different circuits produce different task IDs."""
        circuit1 = "QINIT 2\nCREG 2\nH q[0]\nMEASURE q[0], c[0]"
        circuit2 = "QINIT 2\nCREG 2\nX q[0]\nMEASURE q[0], c[0]"

        task_id1 = adapter.submit(circuit1)
        task_id2 = adapter.submit(circuit2)

        assert task_id1 != task_id2

    def test_submit_batch(self, adapter):
        """Test submitting multiple circuits."""
        circuits = [
            "QINIT 2\nCREG 2\nH q[0]\nMEASURE q[0], c[0]",
            "QINIT 2\nCREG 2\nX q[0]\nMEASURE q[0], c[0]",
        ]

        task_ids = adapter.submit_batch(circuits, shots=1000)

        assert len(task_ids) == 2
        assert all(isinstance(tid, str) for tid in task_ids)

    def test_query_batch(self, adapter):
        """Test querying multiple tasks."""
        circuits = [
            "QINIT 2\nCREG 2\nH q[0]\nMEASURE q[0], c[0]",
            "QINIT 2\nCREG 2\nX q[0]\nMEASURE q[0], c[0]",
        ]
        task_ids = adapter.submit_batch(circuits, shots=1000)

        result = adapter.query_batch(task_ids)

        assert result["status"] == "success"
        assert len(result["result"]) == 2

    def test_clear_cache(self, adapter):
        """Test clearing the cache."""
        circuit = "QINIT 2\nCREG 2\nH q[0]\nMEASURE q[0], c[0]"
        task_id = adapter.submit(circuit)

        adapter.clear_cache()

        result = adapter.query(task_id)
        assert result["status"] == "failed"


class TestUniqcDummyEnv:
    """Tests for UNIQC_DUMMY environment variable."""

    def test_env_variable_true(self, monkeypatch):
        """Test UNIQC_DUMMY=true is recognized."""
        monkeypatch.setenv("UNIQC_DUMMY", "true")
        # Re-import to pick up new env var
        import uniqc.backend_adapter.task.adapters.dummy_adapter as dummy_mod
        importlib.reload(dummy_mod)

        assert dummy_mod.UNIQC_DUMMY is True

    def test_env_variable_false(self, monkeypatch):
        """Test UNIQC_DUMMY=false is recognized as false."""
        monkeypatch.setenv("UNIQC_DUMMY", "false")
        import uniqc.backend_adapter.task.adapters.dummy_adapter as dummy_mod
        importlib.reload(dummy_mod)

        assert dummy_mod.UNIQC_DUMMY is False

    def test_env_variable_1(self, monkeypatch):
        """Test UNIQC_DUMMY=1 is recognized as true."""
        monkeypatch.setenv("UNIQC_DUMMY", "1")
        import uniqc.backend_adapter.task.adapters.dummy_adapter as dummy_mod
        importlib.reload(dummy_mod)

        assert dummy_mod.UNIQC_DUMMY is True
