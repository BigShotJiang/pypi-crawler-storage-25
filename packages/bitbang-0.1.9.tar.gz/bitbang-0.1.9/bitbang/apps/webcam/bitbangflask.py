"""BitBang Webcam adapter - extends PsiWSGI with webcam video track.

This module provides WebcamPsiWSGI which adds a webcam video track
to the base PsiWSGI adapter. It uses MediaRelay to share a single
webcam source across multiple clients.

Usage:
    from flask import Flask
    from bitbangflask import WebcamBitBang

    app = Flask(__name__)

    @app.route('/')
    def index():
        return open('index.html').read()

    adapter = WebcamBitBang(app)
    adapter.run()
"""

from bitbang import BitBangWSGI
from aiortc.contrib.media import MediaPlayer, MediaRelay


class WebcamBitBang(BitBangWSGI):
    """BitBang Webcam adapter - adds webcam video track to connections.

    Extends BitBangWSGI to capture video from /dev/video0 and share it
    with all connected clients using MediaRelay.
    """

    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)
        self.player = None
        self.relay = MediaRelay()

    def setup_peer_connection(self, pc, client_id):
        """Add webcam video track to peer connection."""
        if not self.player:
            self.player = MediaPlayer('/dev/video0', format='v4l2', options={
                'video_size': '640x480',
                'framerate': '30'
            })
            print("Created webcam player")

        if self.player.video:
            pc.addTrack(self.relay.subscribe(self.player.video))
            print(f"Added relayed webcam video track for {client_id}")

    def get_stream_metadata(self):
        """Return stream name for video track."""
        if self.player and self.player.video:
            return {"0": "webcam"}
        return {}

    async def close(self):
        """Close peer connections and media player."""
        await super().close()

        if self.player:
            if self.player.video:
                self.player.video.stop()
            self.player = None
