from bitbang import BitBangWSGI
from flask import Flask, render_template

app = Flask(__name__, template_folder=".", static_folder="static")

@app.route('/')
def index():
    return render_template('index.html')


if __name__ == '__main__':
    adapter = BitBangWSGI(app)
    adapter.run()
