# bitbang/__main__.py
import sys

def main():
    if len(sys.argv) < 2:
        print("Usage: python -m bitbang <command>")
        print("Commands: webcam, files, send")
        sys.exit(1)
    
    cmd = sys.argv[1]
    if cmd == "webcam":
        from bitbang.examples.webcam import run
        run()
    elif cmd == "send":
        from bitbang.examples.send import run
        run()
    # etc

if __name__ == "__main__":
    main()
