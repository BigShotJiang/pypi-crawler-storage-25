# fasr-asr-fun

基于 `fun_asr_nano.py` 的 `funasr.AutoModel` 推理方式封装，为 fasr 提供 Fun-ASR-Nano 无时间戳识别能力。

## 安装

```bash
pip install fasr-asr-fun
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `fun_asr_nano` | `FunASRNanoForASR` | `FunAudioLLM/Fun-ASR-Nano-2512` | Fun-ASR-Nano，无时间戳输出 |

## 使用方式

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="fun_asr_nano")
    .add_pipe("sentencizer", model="ct_transformer")
)
```

### 单独使用模型

模型实例化时会自动执行 `download_checkpoint()` + `load_checkpoint()`：

```python
from fasr.config import registry

model = registry.asr_models.get("fun_asr_nano")(device="cuda:0")
# or model.load_checkpoint("/path/to/custom/fun_asr")
```

## 运行期 / 会话参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint` | `str \| None` | `"FunAudioLLM/Fun-ASR-Nano-2512"` | 远程 repo_id；非空时实例化会自动下载 |
| `cache_dir` | `str \| Path \| None` | `None` | 缓存目录，`None` 使用 `fasr.utils.get_cache_dir()` |
| `endpoint` | `Literal["modelscope", "huggingface", "hf-mirror"]` | `"modelscope"` | 下载端点 |
| `device` | `str` | `"cuda:0"` | 推理设备 |
| `trust_remote_code` | `bool` | `True` | 是否信任远程代码 |
| `language` | `str` | `"中文"` | 默认识别语言 |
| `itn` | `bool` | `True` | 是否执行逆文本规范化 |
| `batch_size` | `int` | `1` | generate 批大小 |

`transcribe` 支持通过 `kwargs` 覆盖 `hotwords`、`language`、`itn`、`batch_size`。

## 输出说明

- 当前模型不返回词级/字级时间戳。
- fasr 中会把整段识别文本作为一个 `AudioToken` 返回。
