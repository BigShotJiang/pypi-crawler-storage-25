from __future__ import annotations

from typing import Optional, Any

import pypandoc

from .base import BaseFile


class DocumentFile(BaseFile):
    """Document file with conversion methods via pandoc."""

    def _load(self) -> None:
        pass

    def _convert_to(self, fmt: str, output_path: Optional[str] = None, **kwargs: Any) -> str:
        output_path = self._output_path(fmt, output_path)
        pypandoc.convert_file(self.path, fmt, outputfile=output_path, **kwargs)
        return output_path

    def to_pdf(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as PDF."""
        return self._convert_to("pdf", output_path, **kwargs)

    def to_docx(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as DOCX."""
        return self._convert_to("docx", output_path, **kwargs)

    def to_html(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as HTML."""
        return self._convert_to("html", output_path, **kwargs)

    def to_md(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as Markdown."""
        return self._convert_to("md", output_path, **kwargs)

    def to_txt(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as plain text."""
        return self._convert_to("plain", output_path, **kwargs)

    def to_odt(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as ODT."""
        return self._convert_to("odt", output_path, **kwargs)

    def to_rtf(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as RTF."""
        return self._convert_to("rtf", output_path, **kwargs)

    def to_latex(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as LaTeX."""
        return self._convert_to("latex", output_path, **kwargs)

    def to_rst(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as reStructuredText."""
        return self._convert_to("rst", output_path, **kwargs)

    def to_asciidoc(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as AsciiDoc."""
        return self._convert_to("asciidoc", output_path, **kwargs)

    def to_mediawiki(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as MediaWiki markup."""
        return self._convert_to("mediawiki", output_path, **kwargs)

    def to_org(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as Org mode."""
        return self._convert_to("org", output_path, **kwargs)

    def to_xml(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as DocBook XML."""
        return self._convert_to("docbook", output_path, **kwargs)

    def to_pptx(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as PowerPoint."""
        return self._convert_to("pptx", output_path, **kwargs)

    def to_epub(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as EPUB."""
        return self._convert_to("epub", output_path, **kwargs)

    def to_csv(self, output_path: Optional[str] = None, **kwargs: Any) -> str:
        """Export as CSV. Only meaningful for tabular sources (e.g. CSV→CSV copy, or HTML tables).

        For arbitrary documents this falls back to pandoc's CSV writer, which extracts
        the first table found. For multi-sheet/tabular data, use the Spreadsheet API.
        """
        if self.format == "csv":
            output_path = self._output_path("csv", output_path)
            import shutil as sh
            sh.copy2(self.path, output_path)
            return output_path
        return self._convert_to("csv", output_path, **kwargs)
