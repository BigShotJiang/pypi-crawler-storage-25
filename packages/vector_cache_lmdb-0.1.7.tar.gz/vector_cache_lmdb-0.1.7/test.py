from sentence_transformers import SentenceTransformer

from vector_cache_lmdb import (
    VectorCache,
    get_embeddings_with_cache,
    make_sentence_transformers_embed_fn,
)

encoder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
cache = VectorCache("./vec-cache", max_gb=10)
embed_fn = make_sentence_transformers_embed_fn(encoder)

texts = ["first string", "second string", "first string", "fourth string", "second string"]
embeddings = get_embeddings_with_cache(
    texts=texts,
    cache=cache,
    embed_fn=embed_fn,
)