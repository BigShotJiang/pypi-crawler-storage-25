use std::fs;
use std::path::PathBuf;
use std::sync::Arc;

use heed::types::Bytes;
use heed::{Database, Env, EnvOpenOptions, WithoutTls};
use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;

type ByteDb = Database<Bytes, Bytes>;

const STATS_COUNT_KEY: &[u8] = b"count";
const STATS_CLOCK_KEY: &[u8] = b"clock";
const STATS_BYTES_TOTAL_KEY: &[u8] = b"bytes_total";
const STATS_VECTOR_DIM_KEY: &[u8] = b"vector_dim";
const BYTES_PER_GB: f64 = 1024.0 * 1024.0 * 1024.0;

#[derive(Clone, Copy)]
enum CapacityLimit {
    Items(u64),
    Bytes(u64),
}

fn pyerr<E: std::fmt::Display>(e: E) -> PyErr {
    PyRuntimeError::new_err(e.to_string())
}

fn hash_text(text: &str) -> [u8; 32] {
    // BLAKE3 is extremely fast while still collision-resistant.
    *blake3::hash(text.as_bytes()).as_bytes()
}

fn encode_f32_vec(values: &[f32]) -> Vec<u8> {
    let mut out = Vec::with_capacity(values.len() * 4);
    for &value in values {
        out.extend_from_slice(&value.to_le_bytes());
    }
    out
}

fn decode_f32_vec(bytes: &[u8]) -> Result<Vec<f32>, String> {
    if bytes.len() % 4 != 0 {
        return Err("corrupt vector payload: byte length is not divisible by 4".to_owned());
    }

    let mut out = Vec::with_capacity(bytes.len() / 4);
    for chunk in bytes.chunks_exact(4) {
        let arr = [chunk[0], chunk[1], chunk[2], chunk[3]];
        out.push(f32::from_le_bytes(arr));
    }
    Ok(out)
}

fn decode_u64_le(bytes: &[u8]) -> Result<u64, String> {
    if bytes.len() != 8 {
        return Err("corrupt u64 payload".to_owned());
    }
    let arr = [
        bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
    ];
    Ok(u64::from_le_bytes(arr))
}

#[pyclass]
pub struct VectorCache {
    env: Arc<Env<WithoutTls>>,
    vectors: ByteDb,
    meta: ByteDb,
    lru: ByteDb,
    stats: ByteDb,
    capacity_limit: CapacityLimit,
}

impl VectorCache {
    fn over_limit(&self, count: u64, bytes_total: u64) -> bool {
        match self.capacity_limit {
            CapacityLimit::Items(max_items) => count > max_items,
            CapacityLimit::Bytes(max_bytes) => bytes_total > max_bytes,
        }
    }

    fn read_stat_u64_rw(&self, txn: &heed::RwTxn<'_>, stat_key: &[u8]) -> PyResult<Option<u64>> {
        let raw = self.stats.get(txn, stat_key).map_err(pyerr)?;
        match raw {
            Some(bytes) => Ok(Some(decode_u64_le(bytes).map_err(pyerr)?)),
            None => Ok(None),
        }
    }

    fn read_stat_u64_ro(&self, txn: &heed::RoTxn<'_>, stat_key: &[u8]) -> PyResult<Option<u64>> {
        let raw = self.stats.get(txn, stat_key).map_err(pyerr)?;
        match raw {
            Some(bytes) => Ok(Some(decode_u64_le(bytes).map_err(pyerr)?)),
            None => Ok(None),
        }
    }

    fn write_stat_u64(
        &self,
        txn: &mut heed::RwTxn<'_>,
        stat_key: &[u8],
        value: u64,
    ) -> PyResult<()> {
        self.stats
            .put(txn, stat_key, &value.to_le_bytes())
            .map_err(pyerr)
    }

    fn ensure_dimension_for_bytes_mode(
        &self,
        txn: &mut heed::RwTxn<'_>,
        vector_dim: usize,
    ) -> PyResult<()> {
        if !matches!(self.capacity_limit, CapacityLimit::Bytes(_)) {
            return Ok(());
        }

        let stored = self.read_stat_u64_rw(txn, STATS_VECTOR_DIM_KEY)?;
        match stored {
            Some(dim) => {
                if dim != vector_dim as u64 {
                    return Err(PyValueError::new_err(format!(
                        "max_gb mode requires fixed vector dimension; expected {}, got {}",
                        dim, vector_dim
                    )));
                }
            }
            None => {
                self.write_stat_u64(txn, STATS_VECTOR_DIM_KEY, vector_dim as u64)?;
            }
        }

        Ok(())
    }

    fn touch_key(&self, txn: &mut heed::RwTxn<'_>, key: &[u8]) -> PyResult<()> {
        let next_clock = self.read_stat_u64_rw(txn, STATS_CLOCK_KEY)?.unwrap_or(0) + 1;
        self.write_stat_u64(txn, STATS_CLOCK_KEY, next_clock)?;

        self.meta
            .put(txn, key, &next_clock.to_le_bytes())
            .map_err(pyerr)?;

        // Big-endian keeps lexical key ordering aligned with numeric ordering.
        self.lru
            .put(txn, &next_clock.to_be_bytes(), key)
            .map_err(pyerr)?;

        Ok(())
    }

    fn evict_if_needed(&self, txn: &mut heed::RwTxn<'_>) -> PyResult<()> {
        let mut count = self.read_stat_u64_rw(txn, STATS_COUNT_KEY)?.unwrap_or(0);
        let mut bytes_total = self
            .read_stat_u64_rw(txn, STATS_BYTES_TOTAL_KEY)?
            .unwrap_or(0);

        while self.over_limit(count, bytes_total) {
            let oldest = {
                let mut iter = self.lru.iter(txn).map_err(pyerr)?;
                iter.next().transpose().map_err(pyerr)?
            };

            let Some((seq_key, item_key)) = oldest else {
                break;
            };

            let seq_key_vec = seq_key.to_vec();
            let item_key_vec = item_key.to_vec();

            self.lru.delete(txn, &seq_key_vec).map_err(pyerr)?;

            let seq = u64::from_be_bytes(
                seq_key_vec
                    .as_slice()
                    .try_into()
                    .map_err(|_| pyerr("corrupt LRU sequence key"))?,
            );

            let maybe_latest = self.meta.get(txn, &item_key_vec).map_err(pyerr)?;
            let is_latest = match maybe_latest {
                Some(meta_bytes) => decode_u64_le(meta_bytes).map_err(pyerr)? == seq,
                None => false,
            };

            if is_latest {
                let prev_len = self
                    .vectors
                    .get(txn, &item_key_vec)
                    .map_err(pyerr)?
                    .map(|b| b.len() as u64)
                    .unwrap_or(0);

                let deleted = self.vectors.delete(txn, &item_key_vec).map_err(pyerr)?;
                self.meta.delete(txn, &item_key_vec).map_err(pyerr)?;
                if deleted {
                    count = count.saturating_sub(1);
                    bytes_total = bytes_total.saturating_sub(prev_len);
                }
            }
        }

        self.write_stat_u64(txn, STATS_COUNT_KEY, count)?;
        self.write_stat_u64(txn, STATS_BYTES_TOTAL_KEY, bytes_total)?;
        Ok(())
    }
}

#[pymethods]
impl VectorCache {
    #[new]
    #[pyo3(signature = (path, map_size_bytes = 1 << 40, max_readers = 2048, max_items = None, max_gb = None))]
    fn new(
        path: String,
        map_size_bytes: usize,
        max_readers: u32,
        max_items: Option<u64>,
        max_gb: Option<f64>,
    ) -> PyResult<Self> {
        if max_items.is_some() && max_gb.is_some() {
            return Err(PyValueError::new_err(
                "choose either max_items or max_gb, but not both",
            ));
        }

        let capacity_limit = match (max_items, max_gb) {
            (Some(items), None) => {
                if items == 0 {
                    return Err(PyValueError::new_err("max_items must be greater than zero"));
                }
                CapacityLimit::Items(items)
            }
            (None, Some(gb)) => {
                if gb <= 0.0 {
                    return Err(PyValueError::new_err("max_gb must be greater than zero"));
                }
                let max_bytes = (gb * BYTES_PER_GB).round() as u64;
                if max_bytes == 0 {
                    return Err(PyValueError::new_err(
                        "max_gb is too small and rounds to zero bytes",
                    ));
                }
                CapacityLimit::Bytes(max_bytes)
            }
            (None, None) => CapacityLimit::Items(5_000_000),
            (Some(_), Some(_)) => unreachable!(),
        };

        let path = PathBuf::from(path);

        if !path.exists() {
            fs::create_dir_all(&path).map_err(pyerr)?;
        } else if !path.is_dir() {
            return Err(PyValueError::new_err(
                "path must be a directory for the LMDB environment",
            ));
        }

        // SAFETY: heed requires `unsafe` because filesystem/runtime guarantees are external.
        let env = unsafe {
            let mut options = EnvOpenOptions::new().read_txn_without_tls();
            options.map_size(map_size_bytes);
            options.max_dbs(4);
            options.max_readers(max_readers);
            options.open(&path).map_err(pyerr)?
        };

        let mut wtxn = env.write_txn().map_err(pyerr)?;
        let vectors = env
            .create_database(&mut wtxn, Some("vectors"))
            .map_err(pyerr)?;
        let meta = env
            .create_database(&mut wtxn, Some("meta"))
            .map_err(pyerr)?;
        let lru = env
            .create_database(&mut wtxn, Some("lru"))
            .map_err(pyerr)?;
        let stats = env
            .create_database(&mut wtxn, Some("stats"))
            .map_err(pyerr)?;

        let has_count = stats.get(&wtxn, STATS_COUNT_KEY).map_err(pyerr)?.is_some();
        let has_bytes = stats
            .get(&wtxn, STATS_BYTES_TOTAL_KEY)
            .map_err(pyerr)?
            .is_some();

        if !has_count || !has_bytes {
            let mut count = 0_u64;
            let mut bytes_total = 0_u64;
            let mut detected_dim: Option<u64> = None;

            for entry in vectors.iter(&wtxn).map_err(pyerr)? {
                let (_, value): (&[u8], &[u8]) = entry.map_err(pyerr)?;
                if value.len() % 4 != 0 {
                    return Err(PyRuntimeError::new_err(
                        "corrupt vector payload detected during initialization",
                    ));
                }

                let dim = (value.len() / 4) as u64;
                count += 1;
                bytes_total += value.len() as u64;

                if matches!(capacity_limit, CapacityLimit::Bytes(_)) {
                    match detected_dim {
                        Some(existing) if existing != dim => {
                            return Err(PyValueError::new_err(
                                "existing data uses multiple vector dimensions; max_gb mode requires a fixed dimension",
                            ));
                        }
                        Some(_) => {}
                        None => detected_dim = Some(dim),
                    }
                }
            }

            self::VectorCache::write_stat_u64_static(&stats, &mut wtxn, STATS_COUNT_KEY, count)?;
            self::VectorCache::write_stat_u64_static(
                &stats,
                &mut wtxn,
                STATS_BYTES_TOTAL_KEY,
                bytes_total,
            )?;
            if let Some(dim) = detected_dim {
                self::VectorCache::write_stat_u64_static(&stats, &mut wtxn, STATS_VECTOR_DIM_KEY, dim)?;
            }
        }

        if stats.get(&wtxn, STATS_CLOCK_KEY).map_err(pyerr)?.is_none() {
            self::VectorCache::write_stat_u64_static(&stats, &mut wtxn, STATS_CLOCK_KEY, 0)?;
        }

        wtxn.commit().map_err(pyerr)?;

        Ok(Self {
            env: Arc::new(env),
            vectors,
            meta,
            lru,
            stats,
            capacity_limit,
        })
    }

    fn put(&self, text: &str, vector: Vec<f32>) -> PyResult<()> {
        let key = hash_text(text);
        let vector_dim = vector.len();
        let value = encode_f32_vec(&vector);

        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        self.ensure_dimension_for_bytes_mode(&mut wtxn, vector_dim)?;

        let existing = self.vectors.get(&wtxn, &key[..]).map_err(pyerr)?;
        let prev_len = existing.map(|b| b.len() as u64).unwrap_or(0);
        let existed = existing.is_some();

        self.vectors.put(&mut wtxn, &key[..], &value).map_err(pyerr)?;
        self.touch_key(&mut wtxn, &key[..])?;

        let mut count = self.read_stat_u64_rw(&wtxn, STATS_COUNT_KEY)?.unwrap_or(0);
        let mut bytes_total = self
            .read_stat_u64_rw(&wtxn, STATS_BYTES_TOTAL_KEY)?
            .unwrap_or(0);

        bytes_total = bytes_total.saturating_sub(prev_len) + value.len() as u64;
        if !existed {
            count += 1;
        }

        self.write_stat_u64(&mut wtxn, STATS_COUNT_KEY, count)?;
        self.write_stat_u64(&mut wtxn, STATS_BYTES_TOTAL_KEY, bytes_total)?;

        self.evict_if_needed(&mut wtxn)?;
        wtxn.commit().map_err(pyerr)?;
        Ok(())
    }

    fn put_multi(&self, texts: Vec<String>, vectors: Vec<Vec<f32>>) -> PyResult<()> {
        if texts.len() != vectors.len() {
            return Err(PyValueError::new_err(
                "texts and vectors must have the same length",
            ));
        }

        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        let mut count = self.read_stat_u64_rw(&wtxn, STATS_COUNT_KEY)?.unwrap_or(0);
        let mut bytes_total = self
            .read_stat_u64_rw(&wtxn, STATS_BYTES_TOTAL_KEY)?
            .unwrap_or(0);

        for (text, vector) in texts.iter().zip(vectors.iter()) {
            self.ensure_dimension_for_bytes_mode(&mut wtxn, vector.len())?;

            let key = hash_text(text);
            let value = encode_f32_vec(vector);

            let existing = self.vectors.get(&wtxn, &key[..]).map_err(pyerr)?;
            let prev_len = existing.map(|b| b.len() as u64).unwrap_or(0);
            let existed = existing.is_some();

            self.vectors.put(&mut wtxn, &key[..], &value).map_err(pyerr)?;
            self.touch_key(&mut wtxn, &key[..])?;

            bytes_total = bytes_total.saturating_sub(prev_len) + value.len() as u64;
            if !existed {
                count += 1;
            }
        }

        self.write_stat_u64(&mut wtxn, STATS_COUNT_KEY, count)?;
        self.write_stat_u64(&mut wtxn, STATS_BYTES_TOTAL_KEY, bytes_total)?;

        self.evict_if_needed(&mut wtxn)?;
        wtxn.commit().map_err(pyerr)?;
        Ok(())
    }

    fn get(&self, text: &str) -> PyResult<Option<Vec<f32>>> {
        let key = hash_text(text);

        // True LRU needs write-access to update recency metadata.
        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        let raw = self.vectors.get(&wtxn, &key[..]).map_err(pyerr)?;
        let out = match raw {
            Some(bytes) => {
                let decoded = decode_f32_vec(bytes).map_err(pyerr)?;
                self.touch_key(&mut wtxn, &key[..])?;
                Some(decoded)
            }
            None => None,
        };

        wtxn.commit().map_err(pyerr)?;
        Ok(out)
    }

    fn get_multi(&self, texts: Vec<String>) -> PyResult<Vec<Option<Vec<f32>>>> {
        // One write transaction for the whole batch keeps overhead low.
        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        let mut out = Vec::with_capacity(texts.len());

        for text in texts {
            let key = hash_text(&text);
            let raw = self.vectors.get(&wtxn, &key[..]).map_err(pyerr)?;
            match raw {
                Some(bytes) => {
                    let decoded = decode_f32_vec(bytes).map_err(pyerr)?;
                    self.touch_key(&mut wtxn, &key[..])?;
                    out.push(Some(decoded));
                }
                None => out.push(None),
            }
        }

        wtxn.commit().map_err(pyerr)?;
        Ok(out)
    }

    fn delete(&self, text: &str) -> PyResult<bool> {
        let key = hash_text(text);

        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        let prev_len = self
            .vectors
            .get(&wtxn, &key[..])
            .map_err(pyerr)?
            .map(|b| b.len() as u64)
            .unwrap_or(0);

        let deleted = self.vectors.delete(&mut wtxn, &key[..]).map_err(pyerr)?;
        self.meta.delete(&mut wtxn, &key[..]).map_err(pyerr)?;

        if deleted {
            let count = self
                .read_stat_u64_rw(&wtxn, STATS_COUNT_KEY)?
                .unwrap_or(0)
                .saturating_sub(1);
            let bytes_total = self
                .read_stat_u64_rw(&wtxn, STATS_BYTES_TOTAL_KEY)?
                .unwrap_or(0)
                .saturating_sub(prev_len);
            self.write_stat_u64(&mut wtxn, STATS_COUNT_KEY, count)?;
            self.write_stat_u64(&mut wtxn, STATS_BYTES_TOTAL_KEY, bytes_total)?;
        }

        wtxn.commit().map_err(pyerr)?;
        Ok(deleted)
    }

    fn delete_multi(&self, texts: Vec<String>) -> PyResult<Vec<bool>> {
        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        let mut out = Vec::with_capacity(texts.len());
        let mut count = self.read_stat_u64_rw(&wtxn, STATS_COUNT_KEY)?.unwrap_or(0);
        let mut bytes_total = self
            .read_stat_u64_rw(&wtxn, STATS_BYTES_TOTAL_KEY)?
            .unwrap_or(0);

        for text in texts {
            let key = hash_text(&text);
            let prev_len = self
                .vectors
                .get(&wtxn, &key[..])
                .map_err(pyerr)?
                .map(|b| b.len() as u64)
                .unwrap_or(0);

            let deleted = self.vectors.delete(&mut wtxn, &key[..]).map_err(pyerr)?;
            self.meta.delete(&mut wtxn, &key[..]).map_err(pyerr)?;

            if deleted {
                count = count.saturating_sub(1);
                bytes_total = bytes_total.saturating_sub(prev_len);
            }
            out.push(deleted);
        }

        self.write_stat_u64(&mut wtxn, STATS_COUNT_KEY, count)?;
        self.write_stat_u64(&mut wtxn, STATS_BYTES_TOTAL_KEY, bytes_total)?;

        wtxn.commit().map_err(pyerr)?;
        Ok(out)
    }

    fn reset(&self) -> PyResult<()> {
        let mut wtxn = self.env.write_txn().map_err(pyerr)?;
        self.vectors.clear(&mut wtxn).map_err(pyerr)?;
        self.meta.clear(&mut wtxn).map_err(pyerr)?;
        self.lru.clear(&mut wtxn).map_err(pyerr)?;
        self.write_stat_u64(&mut wtxn, STATS_COUNT_KEY, 0)?;
        self.write_stat_u64(&mut wtxn, STATS_CLOCK_KEY, 0)?;
        self.write_stat_u64(&mut wtxn, STATS_BYTES_TOTAL_KEY, 0)?;
        self.stats
            .delete(&mut wtxn, STATS_VECTOR_DIM_KEY)
            .map_err(pyerr)?;
        wtxn.commit().map_err(pyerr)?;
        Ok(())
    }

    fn len(&self) -> PyResult<u64> {
        let rtxn = self.env.read_txn().map_err(pyerr)?;
        let value = self.read_stat_u64_ro(&rtxn, STATS_COUNT_KEY)?.unwrap_or(0);
        rtxn.commit().map_err(pyerr)?;
        Ok(value)
    }

    fn bytes_len(&self) -> PyResult<u64> {
        let rtxn = self.env.read_txn().map_err(pyerr)?;
        let value = self
            .read_stat_u64_ro(&rtxn, STATS_BYTES_TOTAL_KEY)?
            .unwrap_or(0);
        rtxn.commit().map_err(pyerr)?;
        Ok(value)
    }
}

impl VectorCache {
    fn write_stat_u64_static(
        stats: &ByteDb,
        txn: &mut heed::RwTxn<'_>,
        stat_key: &[u8],
        value: u64,
    ) -> PyResult<()> {
        stats
            .put(txn, stat_key, &value.to_le_bytes())
            .map_err(pyerr)
    }
}

#[pymodule]
fn vector_cache_lmdb(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<VectorCache>()?;
    Ok(())
}
