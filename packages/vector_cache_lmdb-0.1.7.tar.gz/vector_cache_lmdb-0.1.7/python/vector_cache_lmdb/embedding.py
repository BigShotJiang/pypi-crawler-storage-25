from __future__ import annotations

from typing import Any, Callable, Sequence

Embedding = list[float]
Embeddings = list[Embedding]


def _to_text_list(texts: Sequence[str]) -> list[str]:
    return list(texts)


def _cache_hits(cache, texts: Sequence[str]) -> list[Embedding | None]:
    return cache.get_multi(list(texts))


def _miss_indices(values: Sequence[Embedding | None]) -> list[int]:
    return [i for i, value in enumerate(values) if value is None]


def _pick(values: Sequence[Any], indices: Sequence[int]) -> list[Any]:
    return [values[i] for i in indices]


def _as_embeddings(value: Any) -> Embeddings:
    if not isinstance(value, list):
        raise RuntimeError("embed_fn must return list[list[float]]")
    return [list(v) for v in value]


def _fill_holes(
    cached: Sequence[Embedding | None],
    missing_positions: Sequence[int],
    missing_embeddings: Sequence[Embedding],
) -> Embeddings:
    out = list(cached)
    for pos, emb in zip(missing_positions, missing_embeddings):
        out[pos] = list(emb)
    return out  # type: ignore[return-value]


def get_embeddings_with_cache(
    texts: Sequence[str],
    cache,
    embed_fn: Callable[[list[str]], Embeddings],
) -> Embeddings:
    """Generic cache wrapper.

    - Reads all keys from cache.
    - Sends only misses to `embed_fn`.
    - Writes misses back with `put_multi`.
    - Returns embeddings aligned to original input order.
    """
    texts = _to_text_list(texts)
    if not texts:
        return []

    cached = _cache_hits(cache, texts)
    missing_positions = _miss_indices(cached)
    if not missing_positions:
        return cached  # type: ignore[return-value]

    missing_texts = _pick(texts, missing_positions)
    missing_embeddings = _as_embeddings(embed_fn(missing_texts))

    if len(missing_embeddings) != len(missing_texts):
        raise RuntimeError("embed_fn returned a different number of embeddings than input texts")

    cache.put_multi(missing_texts, missing_embeddings)
    return _fill_holes(cached, missing_positions, missing_embeddings)


def _load_dotenv_if_present() -> None:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass


def _build_openai_client():
    _load_dotenv_if_present()
    from openai import OpenAI

    return OpenAI()


def _parse_openai_embeddings_response(response: Any, expected_count: int) -> Embeddings:
    data = getattr(response, "data", None)
    if data is None:
        raise RuntimeError("OpenAI embedding response is missing 'data'")

    out: list[Embedding | None] = [None] * expected_count
    for idx, item in enumerate(data):
        item_index = getattr(item, "index", idx)
        emb = getattr(item, "embedding", None)
        if emb is None:
            raise RuntimeError("OpenAI embedding item is missing 'embedding'")
        if item_index < 0 or item_index >= expected_count:
            raise RuntimeError("OpenAI embedding item index out of range")
        out[item_index] = list(emb)

    if any(v is None for v in out):
        raise RuntimeError("OpenAI response is missing one or more embeddings")

    return out  # type: ignore[return-value]


def make_openai_embed_fn(
    model: str,
    *,
    client=None,
    request_kwargs: dict[str, Any] | None = None,
) -> Callable[[list[str]], Embeddings]:
    """Return `embed_fn(texts) -> list[list[float]]` backed by OpenAI embeddings."""
    client = client or _build_openai_client()
    request_kwargs = request_kwargs or {}

    def _embed(texts: list[str]) -> Embeddings:
        response = client.embeddings.create(model=model, input=texts, **request_kwargs)
        return _parse_openai_embeddings_response(response, len(texts))

    return _embed


def make_sentence_transformers_embed_fn(
    model_or_encoder,
    *,
    encode_kwargs: dict[str, Any] | None = None,
) -> Callable[[list[str]], Embeddings]:
    """Return `embed_fn(texts) -> list[list[float]]` backed by sentence-transformers.

    `model_or_encoder` can be:
    - a `SentenceTransformer`-like object exposing `.encode(...)`
    - a model name string (lazy imports and constructs SentenceTransformer)
    """
    encode_kwargs = encode_kwargs or {}

    if isinstance(model_or_encoder, str):
        from sentence_transformers import SentenceTransformer

        encoder = SentenceTransformer(model_or_encoder)
    else:
        encoder = model_or_encoder

    def _embed(texts: list[str]) -> Embeddings:
        vectors = encoder.encode(texts, **encode_kwargs)
        if hasattr(vectors, "tolist"):
            vectors = vectors.tolist()
        return _as_embeddings(vectors)

    return _embed
