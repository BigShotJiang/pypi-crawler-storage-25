import multiprocessing as mp
from pathlib import Path

import pytest

from vector_cache_lmdb import VectorCache


def _cache(tmp_path: Path, **kwargs) -> VectorCache:
    return VectorCache(str(tmp_path / "db"), **kwargs)


def _assert_vec(actual, expected):
    assert actual is not None
    assert len(actual) == len(expected)
    for a, e in zip(actual, expected):
        assert a == pytest.approx(e, rel=1e-6, abs=1e-6)


def test_put_get_delete_reset_and_len(tmp_path: Path):
    cache = _cache(tmp_path, max_items=100)

    assert cache.len() == 0
    assert cache.get("missing") is None

    cache.put("k1", [0.1, 0.2, 0.3])
    assert cache.len() == 1
    _assert_vec(cache.get("k1"), [0.1, 0.2, 0.3])

    # overwrite should not increase cardinality
    cache.put("k1", [9.0])
    assert cache.len() == 1
    _assert_vec(cache.get("k1"), [9.0])

    assert cache.delete("k1") is True
    assert cache.delete("k1") is False
    assert cache.len() == 0

    cache.put("a", [1.0])
    cache.put("b", [2.0])
    assert cache.len() == 2
    cache.reset()
    assert cache.len() == 0
    assert cache.get("a") is None
    assert cache.get("b") is None


def test_put_multi_get_multi_delete_multi(tmp_path: Path):
    cache = _cache(tmp_path, max_items=100)

    cache.put_multi(
        ["a", "b", "c"],
        [[1.0, 2.0], [3.0], [4.5, 5.5, 6.5]],
    )
    assert cache.len() == 3

    out = cache.get_multi(["a", "b", "missing", "c"])
    assert out[2] is None
    _assert_vec(out[0], [1.0, 2.0])
    _assert_vec(out[1], [3.0])
    _assert_vec(out[3], [4.5, 5.5, 6.5])

    deleted = cache.delete_multi(["a", "missing", "c"])
    assert deleted == [True, False, True]
    assert cache.len() == 1
    _assert_vec(cache.get("b"), [3.0])


def test_put_multi_length_validation(tmp_path: Path):
    cache = _cache(tmp_path, max_items=100)
    with pytest.raises(ValueError, match="texts and vectors must have the same length"):
        cache.put_multi(["a"], [[1.0], [2.0]])


def test_new_requires_directory_path(tmp_path: Path):
    file_path = tmp_path / "not_a_dir"
    file_path.write_text("x", encoding="utf-8")
    with pytest.raises(ValueError, match="path must be a directory"):
        VectorCache(str(file_path))


def test_new_validates_max_items(tmp_path: Path):
    with pytest.raises(ValueError, match="max_items must be greater than zero"):
        _cache(tmp_path, max_items=0)


def test_new_rejects_both_max_items_and_max_gb(tmp_path: Path):
    with pytest.raises(ValueError, match="either max_items or max_gb"):
        _cache(tmp_path, max_items=10, max_gb=0.001)


def test_lru_eviction_drops_least_recently_used(tmp_path: Path):
    cache = _cache(tmp_path, max_items=3)

    cache.put("a", [1.0])
    cache.put("b", [2.0])
    cache.put("c", [3.0])
    assert cache.len() == 3

    # touch a so b becomes LRU
    _assert_vec(cache.get("a"), [1.0])

    cache.put("d", [4.0])
    assert cache.len() == 3

    assert cache.get("b") is None
    _assert_vec(cache.get("a"), [1.0])
    _assert_vec(cache.get("c"), [3.0])
    _assert_vec(cache.get("d"), [4.0])


def test_max_gb_eviction_uses_payload_bytes(tmp_path: Path):
    # 16 bytes budget => exactly two vectors of dimension 2 (2 * 4 bytes each).
    max_gb = 16.0 / (1024.0 * 1024.0 * 1024.0)
    cache = _cache(tmp_path, max_gb=max_gb)

    cache.put("a", [1.0, 1.0])  # 8 bytes
    cache.put("b", [2.0, 2.0])  # 8 bytes
    assert cache.bytes_len() == 16

    cache.put("c", [3.0, 3.0])  # +8 bytes => evict least-recently-used
    assert cache.bytes_len() <= 16

    assert cache.get("a") is None
    _assert_vec(cache.get("b"), [2.0, 2.0])
    _assert_vec(cache.get("c"), [3.0, 3.0])


def test_max_gb_requires_fixed_dimension(tmp_path: Path):
    max_gb = 64.0 / (1024.0 * 1024.0 * 1024.0)
    cache = _cache(tmp_path, max_gb=max_gb)

    cache.put("a", [1.0, 2.0, 3.0])
    with pytest.raises(ValueError, match="fixed vector dimension"):
        cache.put("b", [1.0, 2.0])


def _writer_proc(db_path: str, start: int, count: int) -> int:
    cache = VectorCache(db_path, max_items=10_000)
    for i in range(start, start + count):
        cache.put(f"k{i}", [float(i)])
    return count


def _reader_proc(db_path: str, keys: list[str]) -> int:
    cache = VectorCache(db_path, max_items=10_000)
    hit = 0
    for k in keys:
        if cache.get(k) is not None:
            hit += 1
    return hit


def test_multiprocess_shared_storage(tmp_path: Path):
    db_path = str(tmp_path / "shared_db")
    cache = VectorCache(db_path, max_items=10_000)
    cache.reset()

    ctx = mp.get_context("spawn")
    with ctx.Pool(processes=4) as pool:
        writes = pool.starmap(
            _writer_proc,
            [
                (db_path, 0, 50),
                (db_path, 50, 50),
            ],
        )
        assert writes == [50, 50]

        # parallel readers over the same storage path
        reader_hits = pool.starmap(
            _reader_proc,
            [
                (db_path, [f"k{i}" for i in range(0, 50)]),
                (db_path, [f"k{i}" for i in range(50, 100)]),
            ],
        )

    assert cache.len() == 100
    assert reader_hits == [50, 50]
