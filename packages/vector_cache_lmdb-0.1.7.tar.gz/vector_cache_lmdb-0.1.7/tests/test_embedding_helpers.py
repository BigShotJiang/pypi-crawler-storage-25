import random
from pathlib import Path
from types import SimpleNamespace

from vector_cache_lmdb import (
    VectorCache,
    get_embeddings_with_cache,
    make_openai_embed_fn,
    make_sentence_transformers_embed_fn,
)


def _cache(tmp_path: Path) -> VectorCache:
    return VectorCache(str(tmp_path / "db"), max_items=1_000)


def test_generic_wrapper_fills_holes_in_order_and_caches(tmp_path: Path):
    cache = _cache(tmp_path)
    cache.put("hit", [9.0])

    def embed_fn(texts: list[str]) -> list[list[float]]:
        return [[float(len(t))] for t in texts]

    out = get_embeddings_with_cache(["hit", "aa", "bbb", "hit"], cache, embed_fn)

    assert out == [[9.0], [2.0], [3.0], [9.0]]
    assert cache.get("aa") == [2.0]
    assert cache.get("bbb") == [3.0]


def test_generic_wrapper_all_hits_skips_embed_fn(tmp_path: Path):
    cache = _cache(tmp_path)
    cache.put_multi(["a", "b"], [[1.0], [2.0]])

    calls = {"n": 0}

    def embed_fn(_texts: list[str]) -> list[list[float]]:
        calls["n"] += 1
        return [[0.0]]

    out = get_embeddings_with_cache(["a", "b", "a"], cache, embed_fn)
    assert out == [[1.0], [2.0], [1.0]]
    assert calls["n"] == 0


def test_openai_embed_fn_parses_indexed_response(tmp_path: Path):
    cache = _cache(tmp_path)

    class _FakeEmbeddings:
        def create(self, *, model, input, **kwargs):
            assert model == "text-embedding-3-small"
            assert kwargs == {"dimensions": 3}
            data = [
                SimpleNamespace(index=1, embedding=[2.0]),
                SimpleNamespace(index=0, embedding=[1.0]),
            ]
            assert input == ["a", "bb"]
            return SimpleNamespace(data=data)

    class _FakeClient:
        embeddings = _FakeEmbeddings()

    embed_fn = make_openai_embed_fn(
        "text-embedding-3-small",
        client=_FakeClient(),
        request_kwargs={"dimensions": 3},
    )

    out = get_embeddings_with_cache(["a", "bb"], cache, embed_fn)
    assert out == [[1.0], [2.0]]


def test_sentence_transformers_embed_fn_with_encoder_object(tmp_path: Path):
    cache = _cache(tmp_path)

    class _Encoder:
        def encode(self, texts, **kwargs):
            assert kwargs == {"normalize_embeddings": True}
            return [[float(len(t)), 0.5] for t in texts]

    embed_fn = make_sentence_transformers_embed_fn(
        _Encoder(),
        encode_kwargs={"normalize_embeddings": True},
    )

    out = get_embeddings_with_cache(["x", "yyyy"], cache, embed_fn)
    assert out == [[1.0, 0.5], [4.0, 0.5]]


def _vec_for_text(text: str) -> list[float]:
    return [float(len(text)), float(sum(ord(c) for c in text) % 997), float(text.count("a"))]


def test_generic_wrapper_randomized_ordering_and_holes(tmp_path: Path):
    rng = random.Random(20260410)
    text_pool = [f"text-{i}" for i in range(40)]

    for round_idx in range(40):
        cache = VectorCache(str(tmp_path / f"db-{round_idx}"), max_items=5_000)

        prefilled = set(rng.sample(text_pool, rng.randint(0, 20)))
        if prefilled:
            cache.put_multi(list(prefilled), [_vec_for_text(t) for t in prefilled])

        query = [rng.choice(text_pool) for _ in range(rng.randint(1, 150))]
        expected = [_vec_for_text(t) for t in query]
        expected_misses = [t for t in query if t not in prefilled]

        calls: list[list[str]] = []

        def embed_fn(miss_texts: list[str]) -> list[list[float]]:
            calls.append(list(miss_texts))
            return [_vec_for_text(t) for t in miss_texts]

        out = get_embeddings_with_cache(query, cache, embed_fn)
        assert out == expected
        assert calls == ([expected_misses] if expected_misses else [])

        # Running the same query again must be all hits with identical ordering.
        calls.clear()
        out2 = get_embeddings_with_cache(query, cache, embed_fn)
        assert out2 == expected
        assert calls == []


def test_generic_wrapper_duplicate_misses_preserve_exact_positions(tmp_path: Path):
    cache = _cache(tmp_path)
    query = ["dup", "dup", "x", "dup", "x", "dup"]
    expected = [[3.0], [3.0], [1.0], [3.0], [1.0], [3.0]]
    calls: list[list[str]] = []

    def embed_fn(miss_texts: list[str]) -> list[list[float]]:
        calls.append(list(miss_texts))
        return [[float(len(t))] for t in miss_texts]

    out = get_embeddings_with_cache(query, cache, embed_fn)
    assert out == expected
    assert calls == [query]


def test_openai_embed_fn_large_shuffled_index_response(tmp_path: Path):
    cache = _cache(tmp_path)
    rng = random.Random(42)
    create_calls = {"n": 0}

    class _FakeEmbeddings:
        def create(self, *, model, input, **kwargs):
            assert model == "text-embedding-3-small"
            assert kwargs == {}
            create_calls["n"] += 1

            data = [
                SimpleNamespace(index=i, embedding=[float(i), float(len(text))])
                for i, text in enumerate(input)
            ]
            rng.shuffle(data)
            return SimpleNamespace(data=data)

    class _FakeClient:
        embeddings = _FakeEmbeddings()

    embed_fn = make_openai_embed_fn("text-embedding-3-small", client=_FakeClient())
    query = [f"item-{i}" for i in range(200)]

    out = get_embeddings_with_cache(query, cache, embed_fn)
    assert out == [[float(i), float(len(query[i]))] for i in range(len(query))]
    assert create_calls["n"] == 1

    # Second call should be entirely cache hits.
    out2 = get_embeddings_with_cache(query, cache, embed_fn)
    assert out2 == out
    assert create_calls["n"] == 1


def test_sentence_transformers_ordering_with_hits_and_duplicates(tmp_path: Path):
    cache = _cache(tmp_path)
    cache.put("hit", [100.0, 1.0])

    class _Encoder:
        def encode(self, texts, **kwargs):
            assert kwargs == {}
            return [[float(i), float(len(t))] for i, t in enumerate(texts)]

    embed_fn = make_sentence_transformers_embed_fn(_Encoder())
    query = ["hit", "m1", "m1", "hit", "m2", "m1"]

    out = get_embeddings_with_cache(query, cache, embed_fn)
    assert out[0] == [100.0, 1.0]
    assert out[3] == [100.0, 1.0]
    assert out[1:] == [
        [0.0, 2.0],
        [1.0, 2.0],
        [100.0, 1.0],
        [2.0, 2.0],
        [3.0, 2.0],
    ]
