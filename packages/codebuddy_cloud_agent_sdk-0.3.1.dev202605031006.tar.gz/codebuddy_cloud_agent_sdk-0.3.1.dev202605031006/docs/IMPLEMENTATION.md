# Cloud Agent SDK (Python) — 实施计划

> 本文档描述 `tencent-ai-cloud-agent-sdk`（Python 版）的实施方案。
> 目标：与 `@tencent-ai/cloud-agent-sdk@0.3.x`（Node.js 版，源码位于 `packages/cloud-agent-sdk/src/v1/`）**功能等价**。
> 设计规格见 `docs/agentos/sdk/` 目录，Node 版实施备忘见 `packages/cloud-agent-sdk/IMPLEMENTATION.md`。

## 1. 目标

在 `packages/cloud-agent-sdk-python/` 中实现 `CloudAgentClient` 的 Python 版客户端 SDK。

**核心指标**：

- 4 行代码从 0 到 prompt（与 Node 版一致）
- 功能与 Node v1 版本**完全对齐**，不多做、不少做
- Python 3.10+
- 运行时依赖仅：`httpx` + `pydantic` + `agent-client-protocol`（官方 ACP Python SDK，提供 Pydantic schema）
- 只服务于**服务端**场景（不考虑浏览器，Node 版的 "baseUrl 代理" 模式在 Python 场景下自然通过 `base_url` + `headers` 支持）

## 2. 现状

```
目标目录（将创建）：
  packages/cloud-agent-sdk-python/
    src/cloud_agent_sdk/
    examples/
    pyproject.toml
    README.md

已存在参考：
  packages/cloud-agent-sdk/src/v1/       ← TS 源码，严格对齐对象
  packages/cloud-agent-sdk/IMPLEMENTATION.md
  docs/agentos/sdk/                      ← 设计规格

外部发布：
  tencent-ai-cloud-agent-sdk v0.1.0（计划首发，PyPI）
```

## 3. 方案概要

### 3.1 目录结构

```
packages/cloud-agent-sdk-python/
├── pyproject.toml                     ← PEP 621，主名 tencent-ai-cloud-agent-sdk
├── README.md                          ← API 速览 + 示例 + 与 JS 版差异
├── IMPLEMENTATION.md                  ← 本文件
├── LICENSE
│
├── src/cloud_agent_sdk/
│   ├── __init__.py                    ← 对齐 Node src/index.ts 的公共导出
│   ├── client.py                      ← CloudAgentClient
│   ├── runtime.py                     ← Runtime
│   ├── session.py                     ← Session
│   ├── manifest.py                    ← ManifestBuilder
│   ├── opts.py                        ← ConnectionOptions 及全部 *Options
│   ├── errors.py                      ← APIError 家族（API 前缀避免遮蔽内建名）
│   ├── types.py                       ← 控制面 DTO（Runtime/Session/Manifest…）
│   ├── acp/
│   │   ├── __init__.py                ← 文档占位（不 re-export 官方类型）
│   │   ├── transport.py               ← Streamable HTTP transport（GET SSE + POST + 重连 + 心跳）
│   │   └── client.py                  ← AcpClient 包装官方 ClientSideConnection + 订阅分发 + 串行化
│   ├── rest/
│   │   ├── __init__.py
│   │   └── client.py                  ← RestClient（httpx + 重试 + 解包 + 脱敏）
│   └── internal/
│       ├── __init__.py
│       ├── log.py                     ← logger_for（按 Python 社区标准，不造 LogLevel 也不设级别、不自造日志 ID）
│       └── redact.py                  ← 敏感 headers/body 脱敏
│
└── examples/                          ← 端到端可运行脚本，对齐 Node examples/v1/
    ├── test_internal.py               ← 基础设施（manifest / logger / redact / errors），无网络
    ├── test_rest.py                   ← 控制面 REST 全覆盖（41 用例，respx mock）
    ├── test_acp_transport.py          ← ACP Streamable HTTP transport 冒烟（ASGI mock）
    ├── test_acp_session.py            ← ACP Session 端到端（connect/prompt/subscribe/cancel/串行化）
    ├── test_smoke.py                  ← 4 行到 prompt 冒烟（真实后端，需 CLOUD_AGENT_API_KEY）
    ├── test_multi_session.py          ← 多 session 并发（真实后端）
    ├── test_content_blocks.py         ← 多模态输入
    ├── test_error_handling.py         ← 错误场景
    ├── test_reconnect.py              ← SSE 断线重连
    └── run_all.sh
```

**注**：没有 `acp/protocol.py`——JSON-RPC 层完全复用官方 `acp.client.ClientSideConnection`
（包括方法路由、Pydantic 校验、request_id 匹配），SDK 只写 Streamable HTTP transport 和
业务语义层。详见 §4.3 / §4.4。

> **不单独建 `tests/` 目录** —— 与 Node 版保持一致（Node 版也只有 `examples/v1/`）。
> `examples/` 下的脚本用 `pytest` + `asyncio.run()` 两用：
> - `test_internal.py` / `test_error_handling.py` 不依赖网络，`pytest examples/` 可跑；
> - `test_smoke.py` / `test_api_coverage.py` / 等依赖 `CLOUD_AGENT_API_KEY`，作为端到端脚本单独跑（`python examples/test_smoke.py`），通过 `pytest.mark.skipif(not os.environ.get("CLOUD_AGENT_API_KEY"))` 在 CI 中跳过。
>
> 复杂 mock（respx / aresponses）仅在 `test_internal.py` 里集中使用，避免过度工程化。

### 3.2 核心依赖

```toml
# pyproject.toml
[project]
name = "tencent-ai-cloud-agent-sdk"
requires-python = ">=3.10,<3.15"
dependencies = [
    "httpx>=0.27",
    "pydantic>=2.6",
    "agent-client-protocol>=0.9,<1.0",   # 官方 ACP SDK，提供 Pydantic schema + JSON-RPC 基类
]

[project.optional-dependencies]
dev = ["pytest>=8", "pytest-asyncio>=0.23", "respx>=0.21", "mypy>=1.10", "ruff>=0.5"]
```

**`agent-client-protocol` 复用**：

| 官方 SDK 资源 | 我们用来做什么 |
|-------------|---------------|
| `acp.schema.*ContentBlock` / `SessionNotification` / `PromptResponse` / `InitializeRequest/Response` / `LoadSessionRequest/Response` / `CancelNotification` 等 Pydantic 类型 | 消费方和 SDK 内部都直接用 |
| **`acp.client.ClientSideConnection`** | JSON-RPC 请求/响应匹配 + Pydantic schema 校验 + 方法路由（`initialize` / `new_session` / `load_session` / `prompt` / `cancel` / `set_session_mode` / `set_session_model` / `ext_method`）全部复用；SDK **不自写** JSON-RPC 层 |
| `acp.Client` Protocol | SDK 内部实现一个 `_NotificationRouter` 类，接 `session_update` 并转发到用户订阅器 |

**不重导出**：SDK 不把官方类型 alias 到 `cloud_agent_sdk.*` 下（避免二次封装）。用户需要时直接 `from acp.schema import ...`。

`Session.prompt()` 支持字符串输入（内部自动包装成 `TextContentBlock`），**大多数场景下用户不需要手动构造 block**。

**不复用**：官方 SDK 的 stdio transport（ACP 规范本身面向 stdio 场景，CodeBuddy 需要的是 **Streamable HTTP**，和 Node 版一样必须**自己实现**）。

### 3.3 认证模型

```
服务端场景：
  ConnectionOptions.api_key → x-api-key header（控制面）
  runtime.acp_token → Authorization: Bearer（数据面，SDK 自动获取/刷新）

业务代理场景（可选）：
  ConnectionOptions.base_url 指向业务后端代理
  代理层注入 api_key 并校验业务登录态
  SDK 通过 headers 透传业务登录态（如 Authorization: Bearer <userJWT>）
```

## 4. 核心模块说明

### 4.1 `__init__.py` — 公共导出（对齐 Node `src/index.ts`）

```python
from cloud_agent_sdk.client import CloudAgentClient
from cloud_agent_sdk.runtime import Runtime
from cloud_agent_sdk.session import Session
from cloud_agent_sdk.manifest import ManifestBuilder

from cloud_agent_sdk.errors import (
    APIError, APINetworkError, APITimeoutError,
    APIAuthError, APINotFoundError, APIValidationError, AcpProtocolError,
)

from cloud_agent_sdk.opts import (
    ConnectionOptions, RequestOptions, RuntimeCreateOptions, RuntimeConnectOptions,
    SessionCreateOptions, PromptOptions, RetryOptions, RetryContext,
    RuntimeListOptions, SessionListOptions, Logger,
)

from cloud_agent_sdk.types import (
    # Manifest
    AgentManifest, ManifestRule, ManifestSkill, ManifestSubagent,
    ManifestSlashCommand, ManifestPlugin, ManifestMcp, ManifestWorkspace,
    ManifestEnv, ManifestSecret,
    # Runtime / Session
    RuntimeStatus, RuntimeInfo, RuntimeLinks, AcpLink, SandboxLink, SandboxSpec,
    SessionStatus, SessionInfo, SessionBrief,
    # 控制面请求体
    CreateRuntimeRequest, UpdateRuntimeRequest,
    CreateSessionRequest, UpdateSessionRequest,
    # 通用
    Pagination, PageResult, DeleteResult, OpenApiHealth,
)

# ACP 协议类型 —— 用户按需**直接从官方 SDK 导入**，SDK 不做 re-export::
#   from acp.schema import TextContentBlock, SessionNotification, PromptResponse

# 默认重试判定（允许用户自定义 retry_on 时 fallback）
from cloud_agent_sdk.rest.client import default_retry_on
```

### 4.2 `rest/client.py` — REST 客户端（基于 httpx）

**职责**（1:1 对齐 Node `v1/rest/client.ts`）：

- 基于 `httpx.AsyncClient`（可由 `ConnectionOptions.http_client` 注入替换 — 对齐 Node 的 `fetch` 钩子）
- 注入 headers：`x-api-key` / `X-Source-App` / `X-Source-Tenant-Id` / `X-User-Id` / `X-Request-Id`
- 统一解包 `{code, msg, data, requestId}`，`code != 0` 抛 `APIError`
- 超时：`httpx.Timeout` + `asyncio.wait_for`
- 重试：指数退避 + ±20% 抖动（最大 30s）；默认 `default_retry_on` 规则与 Node 完全一致
- 单 ID 日志（对齐 Anthropic Python SDK）：只暴露服务端 `request_id`，
  "第几次重试" 通过独立告警行 `"Retrying request to ... (attempt 2/3): ..."` 表达
- 脱敏：`on_request`/`on_response` hook 和 debug 日志的 headers/body 都通过 `internal/redact` 处理

**HTTP 状态码映射**（与 Node 一致）：

| 状态 | 错误类型 |
|------|---------|
| 400 | `APIValidationError` |
| 401 / 403 | `APIAuthError` |
| 404 | `APINotFoundError` |
| 408 / 504 | `APITimeoutError` |
| 429 / 5xx | `APINetworkError` |

**业务 code 映射**（与 Node 一致）：

| code | 错误类型 |
|------|---------|
| 10001 | `APIValidationError` |
| 10034 / 10085 | `APIAuthError` |
| 10064 / 10065 / 10067 / 10000 | `APINetworkError` |
| 10084 | `APINotFoundError` |
| 10094 | `APITimeoutError` |

### 4.3 `acp/transport.py` — Streamable HTTP Transport

对齐 Node `v1/acp/transport.ts`。**官方 Python SDK 没有该 transport，必须自己实现**。

**协议流程**：

1. `GET {endpoint}` 建立 SSE，响应头 `Acp-Connection-Id` 为连接 ID
2. POST JSON-RPC 请求时必须带 `Acp-Connection-Id` header + `Authorization: Bearer`
3. 通知经 GET SSE 推送；RPC 响应经 POST SSE（或 POST JSON body）回

**稳定性特性**（照搬 Node 实现）：

- 心跳检测（默认 60s，`asyncio` 定时器）
- 自动重连（指数退避 + ±25% jitter，默认 `initial_delay=1000ms`, `max_delay=30000ms`, `max_retries=无限`）
- `Last-Event-ID` 断点续传
- POST 超时（默认 30s）、连接建立超时（默认 30s）
- `connection_version` 防竞态（老的重连回调不污染新连接）

**对外接口**（关键设计决策）：`StreamableHttpTransport.reader` / `.writer` 暴露
一对**真正的** `asyncio.StreamReader` / `asyncio.StreamWriter`，可以**直接传给
官方 `acp.client.ClientSideConnection`**——官方做 JSON-RPC 路由、Pydantic 校验，
SDK 完全不写 JSON-RPC 层：

```python
transport = StreamableHttpTransport(TransportOptions(endpoint=..., auth_token=...))
await transport.start()
conn = ClientSideConnection(router, transport.writer, transport.reader)
await conn.initialize(protocol_version=1)
await conn.prompt(session_id=..., prompt=[...])
```

**实现要点**：

- SSE 消息 → `StreamReader.feed_data(json + b"\n")` → 官方 Connection 通过
  `readline()` 消费
- `StreamWriter` 写入的字节 → 伪 `WriteTransport`（`_PostingTransport`）拦截 →
  按行切分 JSON 后异步 POST 发出
- 两个方向桥接，官方完全感知不到底层是 HTTP 还是 stdio

### 4.4 `acp/client.py` — AcpClient（订阅模型 + 业务语义层）

包装官方 `ClientSideConnection`，加 **CodeBuddy 业务语义**：

- **状态机**：`INITIAL → CONNECTING → OPEN → CLOSING → CLOSED`
- `connect(url, token, opts)`：建 transport → 构造 `ClientSideConnection` → `initialize`
- `set_token_refresher(fn)` 支持 token 快过期前刷新（由 `Runtime.refresh_token` 注入）
- **订阅分发**：`subscribe(session_id, listener) -> unsubscribe`
  - 内部 `_NotificationRouter` 实现 `acp.Client` Protocol 的 `session_update`
  - 收到消息后按 `session_id` 多路分发给订阅者
  - listener 抛异常时**静默吞**（不影响其他订阅者）
- **per-session 串行化**：同一 `session_id` 的 `prompt()` 必须排队（ACP 协议要求）
  - 实现：`defaultdict(asyncio.Lock)` + `async with lock`
- **取消语义**（Pythonic）：
  - 调用方 `task.cancel()` → `asyncio.CancelledError` 自然传播，SDK 在 finally 里
    向服务端发 `session/cancel`
  - 也可以用 `cancel_event: asyncio.Event` 从外部触发（`asyncio.wait` 监听）
  - 尽力而为：`cancel` RPC 失败不抛
- **连接事件**：`on("open" | "error" | "close", handler)` 供高级诊断

**JSON-RPC `-32602`（Invalid params）静默**：官方 Python SDK 的 `Connection`
在 notification handler 外层用 `contextlib.suppress(Exception)` 包了，**所有**
notification 校验失败都静默——比 Node 版更彻底。

### 4.5 `client.py` / `runtime.py` / `session.py` — 顶层对象

**`CloudAgentClient`**：

```python
class CloudAgentClient:
    def __init__(self, opts: ConnectionOptions | None = None): ...
    def with_(self, overrides: ConnectionOptions) -> "CloudAgentClient": ...  # 避开 with 关键字

    class Runtimes:
        async def create(self, opts: RuntimeCreateOptions) -> Runtime: ...
        async def get(self, runtime_id: str, opts: RequestOptions | None = None) -> Runtime: ...
        async def list(self, opts: RuntimeListOptions | None = None) -> PageResult[RuntimeInfo]: ...

    runtimes: Runtimes  # 实例属性
```

**`Runtime`**：

```python
class Runtime:
    id: str
    runtime_info: RuntimeInfo
    acp_url: str | None
    acp_token: str | None
    sandbox_id: str | None
    sandbox_domain: str | None

    async def update(self, req: UpdateRuntimeRequest, opts=None) -> RuntimeInfo: ...
    async def delete(self, opts=None) -> DeleteResult: ...
    async def refresh_token(self, opts=None) -> str: ...

    class Sessions:
        async def create(self, opts: SessionCreateOptions) -> Session: ...
        async def get(self, session_id: str, opts=None) -> Session: ...
        async def list(self, opts: SessionListOptions | None = None) -> PageResult[SessionInfo]: ...
        def default(self) -> Session: ...

    sessions: Sessions
```

**`Session`**：

```python
class Session:
    id: str
    runtime_id: str

    @property
    def status(self) -> SessionStatus | None: ...
    @property
    def connected(self) -> bool: ...

    # 控制面
    async def info(self, opts=None) -> SessionInfo: ...
    async def update(self, req: UpdateSessionRequest, opts=None) -> SessionInfo: ...
    async def delete(self, opts=None) -> DeleteResult: ...

    # 数据面
    async def connect(self, opts: RuntimeConnectOptions | None = None) -> None: ...
    async def disconnect(self) -> None: ...
    async def prompt(
        self,
        input: str | list[ContentBlock],
        opts: PromptOptions | None = None,
    ) -> PromptResponse: ...
    def subscribe(self, listener: NotificationListener) -> Callable[[], None]: ...
    async def cancel(self) -> None: ...
```

### 4.6 `manifest.py` — ManifestBuilder

Fluent API，1:1 对齐 Node `v1/manifest.ts`：

```python
manifest = (
    ManifestBuilder()
        .id("my-agent")
        .name("My Agent")
        .version("1.0")
        .system_prompt("You are a helpful assistant.")
        .skills("code-reviewer", "test-writer")
        .secrets(ManifestSecret(key="OPENAI_API_KEY", value="..."))
        .envs(ManifestEnv(key="LOG_LEVEL", value="info"))
        .build()
)
```

校验：`id` / `name` / `version` 必填；`system_prompt` 与 `system_prompt_file` 互斥。

### 4.7 取消原语（不造轮子）

**Python 原生能力已经够用**，SDK 不引入自建 `CancelToken`。

- **调用方直接取消**：`task.cancel()` 会把 `asyncio.CancelledError` 传播进 SDK 的 `await` 点，httpx 中止在途请求；`Session.prompt()` 在 `finally` 里向服务端发 `session/cancel`
- **外部事件触发**：`RequestOptions.cancel: asyncio.Event | None`、`PromptOptions.cancel: asyncio.Event | None`。SDK 内部用 `asyncio.wait` 监听，`event.set()` 触发后和 `task.cancel()` 语义一致
- **超时**：`RequestOptions.timeout_ms` 用 `asyncio.wait_for` 实现，超时抛 `APITimeoutError`

对比 Node 的 `AbortSignal`——TS 必须自建（标准库没有统一的取消原语），Python 不需要。

## 5. 对外 API 快速预览

```python
# === 4 行代码到 prompt ===
import asyncio
from cloud_agent_sdk import CloudAgentClient

async def main():
    client = CloudAgentClient(api_key="ck_xxx")
    rt = await client.runtimes.create(runtime_name="demo")
    session = rt.sessions.default()
    response = await session.prompt("hello")
    print(response.stop_reason)

asyncio.run(main())
```

```python
# === 流式打印 + 最终结果 ===
from acp.schema import SessionNotification       # 官方 SDK，不做 re-export
from cloud_agent_sdk import CloudAgentClient

async def main():
    client = CloudAgentClient(api_key="ck_xxx")
    rt = await client.runtimes.create(runtime_name="demo")
    session = rt.sessions.default()
    await session.connect()

    def on_chunk(n: SessionNotification):
        update = n.update
        if update.session_update == "agent_message_chunk" and update.content.type == "text":
            print(update.content.text, end="", flush=True)

    unsub = session.subscribe(on_chunk)
    try:
        response = await session.prompt("write a poem")
        print(f"\n[done] stop_reason={response.stop_reason}")
    finally:
        unsub()

asyncio.run(main())
```

完整 API 见 `docs/agentos/sdk/05-api-surface.md`（Python 版 API surface 按同表重镜像）。

## 6. 实施步骤

**当前进度**：Phase 0~3 全部完成（75 用例全绿），Phase 4/5 进行中。

### Phase 0：工程骨架（0.5 天）✅

- [x] 创建目录骨架、空文件
- [x] `pyproject.toml`（PEP 621 + 依赖 + 可选 dev 组）
- [x] 配置 `ruff` + `mypy --strict` + `pytest`
- [ ] CI 基础（仓库流水线接入，待后续）

### Phase 1：基础设施（1 天）✅

- [x] `errors.py` — `APIError` 家族（6 个错误类 + 服务端 `request_id` 定位字段，API 前缀避免遮蔽内建名）
- [x] `opts.py` — 全部 `*Options` dataclass（取消字段用 `asyncio.Event`）
- [x] `types.py` — Manifest / Runtime / Session / 请求体 DTO（Pydantic）
- [x] `internal/log.py` — `logger_for(opts)` 直接返回 `logging.getLogger('cloud_agent_sdk')` 或用户 logger；不自造 ID
- [x] `internal/redact.py` — headers + `agentManifest.secrets[].value` 脱敏
- [x] `manifest.py` — `ManifestBuilder` fluent API
- [x] 验证脚本：`examples/test_internal.py`（26 用例，无网络）

### Phase 2：REST 控制面（2 天）✅

- [x] `rest/client.py` — httpx 封装
  - headers 注入（认证 + 身份 + 自定义 + `X-Request-Id`）
  - 响应解包 `{code, msg, data, requestId}`
  - 超时（`asyncio.wait_for` + `httpx.Timeout`）
  - 重试（`with_retry` + `default_retry_on`，与 Node 判定表完全一致）
  - 日志（对齐 Anthropic：单服务端 request_id + 独立重试告警行）
  - `on_request` / `on_response` hook（脱敏）
- [x] `client.py` — `CloudAgentClient.runtimes.{create, get, list}` + `with_`
- [x] `runtime.py` — `update / delete / refresh_token` + `sessions.{create, get, list, default}`
- [x] `session.py` 控制面部分 — `info / update / delete`
- [x] 验证脚本：`examples/test_rest.py`（41 用例，respx mock）

### Phase 3：ACP 数据面（2 天）✅

- [x] `acp/transport.py` — Streamable HTTP transport
  - GET SSE 建连 + `Acp-Connection-Id` 捕获
  - POST JSON-RPC（带 connection id）
  - 心跳 / 重连 / Last-Event-ID
  - 输出 `(StreamReader, StreamWriter)` 对接官方 `ClientSideConnection`
- [x] ~~`acp/protocol.py`~~ — **已砍掉**。JSON-RPC 层完全复用官方 `ClientSideConnection`
- [x] `acp/client.py` — `AcpClient`（包装 `ClientSideConnection`）
  - `_NotificationRouter` 实现 `acp.Client` Protocol 并按 session_id 多路分发
  - per-session 串行化（`defaultdict(asyncio.Lock)`）
  - token 刷新 hook
  - 连接事件 open/error/close
- [x] `session.py` 数据面 — `connect / disconnect / prompt / subscribe / cancel`
  - `prompt(str)` 自动包装成 `TextContentBlock`
  - 合并 `cancel` 事件与 `timeout_ms`
  - `on_turn_start` / `on_turn_end` / `on_chunk` 回调
- [x] 验证脚本：`examples/test_acp_transport.py`（3 用例，ASGI mock）+ `examples/test_acp_session.py`（7 用例，端到端）

### Phase 4：集成 + 示例（1 天）

### Phase 4：集成 + 真实后端示例（1 天）

- [ ] `examples/test_smoke.py` — 4 行代码到 prompt（真实后端，`CLOUD_AGENT_API_KEY`）
- [ ] `examples/test_multi_session.py` — 多 session 并发
- [ ] `examples/test_content_blocks.py` — 多模态输入（text / image / resource_link）
- [ ] `examples/test_error_handling.py` — 错误场景（无权限 / 超时 / 不存在）
- [ ] `examples/test_reconnect.py` — SSE 断线重连（mock SSE）
- [ ] `examples/run_all.sh` — 一键跑脚本

### Phase 5：文档 + 发布（1 天）

- [ ] `README.md` — API 速览 + 示例 + 与 JS 版差异点
- [ ] 更新 `docs/agentos/sdk/`（若需 Python 专属章节）
- [ ] `pyproject.toml` metadata 完善
- [ ] 构建 wheel / sdist；（可选）发 TestPyPI 验证
- [ ] 发 PyPI v0.1.0

### Phase 6（可选）：同步 API 包装

- [ ] `SyncCloudAgentClient` / `SyncRuntime` / `SyncSession`
- [ ] 内部用专用 event loop / `asyncio.run` 包装

## 7. 与 Node 版的必要差异

这些不是"少做"，而是语言惯例适配 —— **凡是 Python 有原生能力的，绝不二次封装**。

| 项 | Node | Python |
|----|------|--------|
| 异步原语 | `Promise` | `async/await` (`asyncio`) |
| **取消** | `AbortSignal` / `AbortController` | `asyncio.CancelledError`（调用方 `task.cancel()` 直接传播）+ `asyncio.Event`（`RequestOptions.cancel`）。**不再提供** `CancelToken` 自建类型 |
| **日志器** | 鸭子类型 Logger + `LeveledLogger` 包装 | `logging.getLogger('cloud_agent_sdk')`（命名隔离，`__init__` 里挂 `NullHandler`）。**SDK 不设级别、不加 handler**；级别由用户通过 `logging.getLogger("cloud_agent_sdk").setLevel(...)` 配置（对齐 urllib3 / httpx / openai 社区标准做法） |
| 字段命名 | camelCase | snake_case（Pydantic `alias_generator=to_camel` + `populate_by_name=True`，保留后端 camelCase 契约） |
| HTTP 客户端 | `fetch` | `httpx` |
| 构造类型 | TypeScript interface | Pydantic `BaseModel` / `dataclass` / `TypedDict` |
| 超时 | `AbortSignal.timeout` | `asyncio.wait_for` |
| 派生实例方法名 | `with()` | `with_()`（避免关键字） |
| 入口方法 | `main()` 异步顶层 | `asyncio.run(main())` |
| Logger 方法名 | `warn / info / debug / error` | `warning / info / debug / error`（对齐 `logging.Logger`）|

**设计原则**：
- **不重复发明轮子**：Python 有 `asyncio.Event` / `asyncio.CancelledError` 就不造 `CancelToken`；有 `logging.Logger` 就不搞 `LeveledLogger`
- **不二次封装官方 SDK**：官方 `agent-client-protocol` 的 Pydantic 类型（`TextContentBlock` / `SessionNotification` / `PromptResponse` 等）直接让用户 `from acp.schema import ...`，SDK 不做 re-export alias 层
- **直接透出底层对象**：`logger_for(opts)` 返回原始 `logging.Logger`，业务可以照常接 OTel Logs Bridge / structlog / loguru 等生态
- **Pydantic 构造器 + fluent builder 双入口**：既支持 `AgentManifest(id=..., name=..., ...)`，也支持 `ManifestBuilder().id("...").name("...").build()`

**语义上完全等价**，API 按 Python 习惯命名。

## 8. 严格对齐要点（不可忽略）

以下与 Node 版**逐点对齐**，否则属于"少做"：

1. **默认 `base_url`**：`https://www.codebuddy.cn/v2/agentos`
2. **默认 `timeout_ms`**：30_000
3. **默认重试**：`max_attempts=3, backoff_ms=300, factor=2, jitter=±20%`，最大退避 30s
4. **`default_retry_on` 规则**：
   - `CancelledError` → 不重试
   - `APIAuthError` / `APINotFoundError` / `APIValidationError` / `AcpProtocolError` → 不重试
   - `APITimeoutError` → 仅 `GET` 重试（非幂等方法超时不重试，避免副作用）
   - `APINetworkError` → 全部方法重试
   - 其他未知 → 保守重试
5. **HTTP 状态码映射表**：400→Validation, 401/403→Auth, 404→NotFound, 408/504→Timeout, 429→Network, 5xx→Network
6. **业务 code 映射表**：10001→Validation, 10034/10085→Auth, 10064/10065/10067/10000→Network, 10084→NotFound, 10094→Timeout
7. **每请求一个 `X-Request-Id`**（调用方传入则透传）
8. **身份 header**：`X-Source-App` / `X-Source-Tenant-Id` / `X-User-Id`
9. **脱敏 header 集**：`authorization` / `cookie` / `set-cookie` / `x-api-key`
10. **脱敏 body 字段**：`agent_manifest.secrets[].value`（保留 `name`）
11. **日志 ID 策略（对齐 Anthropic）**：SDK 不自造本地 ID，只暴露服务端 `request_id`（`body.request_id` 优先于 `x-request-id` header）；重试通过独立告警行 `"Retrying request to ... (attempt N/M)"` 表达；业务维度（session/runtime/connection）通过日志前缀 + 用户用 `ContextVar` + `logging.Filter` 自主串联
12. **`Session.prompt()` 返回值仅含 `stop_reason`**（`_meta` / `user_message_id` / `usage` 等字段服务端尚未稳定，保留不暴露）
13. **`prompt(str)` 自动包装成 `TextContentBlock`**；支持 `list[TextContentBlock | ImageContentBlock | ...]` 多模态
14. **per-session 串行化**：同 `session_id` 并发 prompt 排队
15. **subscribe 独立于 prompt 生命周期**；单 session 支持多订阅器；订阅器异常静默吞
16. **`on_chunk` 便利钩子**：等价于 "prompt 开始时 subscribe、prompt 结束自动 unsubscribe"
17. **`Session.cancel()` 尽力而为**：服务端 RPC 失败打 warn 不抛
18. **`refresh_token()`** 通过 `GET /runtimes/{id}` 拉最新 `RuntimeInfo` 并更新 `acp_link`
19. **`default()`** 使用 `info.sessions[0].session_id`，不存在时 fallback 到 `runtime.id`
20. **控制面请求体字段 camelCase**：Pydantic `model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)`
21. **JSON-RPC `-32602`（Invalid params）静默**：对齐 Node 的 noise patch 策略

## 9. OpenTelemetry / 可观测性接入

业务侧通常会在服务里跑 OTel（trace + metrics）。SDK **不内置 OTel 依赖**（保持零侵入、零运行时依赖膨胀），而是提供三个挂载点，让业务在自己的 OTel 配置里把 SDK 行为串进去。这个策略和 Node 版完全一致（Node 在 `ConnectionOpts.fetch` 注释里也是这么写的）。

### 9.1 三个挂载点

| 挂载点 | 作用 | 等价于 Node |
|-------|------|------------|
| `ConnectionOptions.http_client` | 注入一个**已被 OTel instrument 过**的 `httpx.AsyncClient`（或 `httpx.Client`），控制面 REST + 数据面 ACP 的 POST/SSE 全部走它，自动产生 HTTP span | `ConnectionOpts.fetch`（注入 instrumented fetch） |
| `RequestOptions.headers` + `ConnectionOptions.headers` | 业务把 W3C Trace Context（`traceparent` / `tracestate` / `baggage`）塞进 per-request 或全局 headers，SDK 原样透传 | `RequestOpts.headers` 透传 `traceparent` |
| `ConnectionOptions.on_request` / `on_response` | 请求/响应钩子，业务可在此打点自定义 span 或 metric（headers 已脱敏） | `onRequest` / `onResponse` hook |

**重点原则**：
- SDK **自己不创建 span**（避免给业务的 trace 树污染 SDK 私有节点）
- SDK **自己不注入 `traceparent`**（这是业务 OTel SDK 的职责，我们别越位）
- 但 SDK 会**原样透传**业务塞进来的任何 header
- 脱敏规则（`Authorization` / `x-api-key` / `Cookie` / `agent_manifest.secrets[].value`）作用于 **日志 + hook 的副本**，不影响真实发出的 header（所以 `traceparent` 不会被误伤）

### 9.2 控制面（REST）接入

最简单，直接注入一个被 `opentelemetry-instrumentation-httpx` 包好的 client：

```python
import httpx
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from cloud_agent_sdk import CloudAgentClient

HTTPXClientInstrumentor().instrument()        # 全局 instrument httpx
# 或者只 instrument 这个 client:
http = httpx.AsyncClient()
HTTPXClientInstrumentor().instrument_client(http)

client = CloudAgentClient(
    api_key="ck_xxx",
    http_client=http,      # 控制面 REST 全部走这个 instrumented client
)
```

效果：每个 `runtimes.create / get / list`、`sessions.*`、`refresh_token` 都会产生一个 HTTP 子 span，自动继承当前 OTel 上下文，并自动把 `traceparent` 注入到出站请求头（httpx instrumentation 会做）。

### 9.3 数据面（ACP SSE + POST）接入

`acp/transport.py` 内部**使用同一个** `ConnectionOptions.http_client`：

- **GET SSE** 连接也走 instrumented client → 产生一个长连接 span（业务可以按 span duration 监控 SSE 生命周期）
- **POST JSON-RPC**（initialize / load_session / prompt / cancel）每次走同一个 client → 各自一个短 span

这样不用单独给 ACP 写 instrumentation，和控制面共享一套。

**额外自定义**：如果业务希望给**每轮 prompt** 打一个自己的 span（对应一次完整 turn 从发出到收到 `stop_reason`），可以在应用层自己包：

```python
from opentelemetry import trace

tracer = trace.get_tracer("my-app")

async with tracer.start_as_current_span("agent.prompt") as span:
    span.set_attribute("agent.session_id", session.id)
    response = await session.prompt("hello")
    span.set_attribute("agent.stop_reason", response.stop_reason)
```

SDK 不主动做这件事，因为"一个 prompt 应该是 span 还是 event"是业务决策。

### 9.4 Trace Context 透传到沙箱

当业务希望**沙箱内部的工具调用**（LSP / Bash / WebFetch 等）也出现在同一条 trace 上时：

```python
from opentelemetry.propagate import inject

async def prompt_with_trace(session, text):
    carrier: dict[str, str] = {}
    inject(carrier)                       # 注入 traceparent / tracestate / baggage
    return await session.prompt(text, headers=carrier)
    # ↑ Node 版完全一致：RequestOpts.headers 透传，由服务端带到沙箱
```

`PromptOptions` 不直接暴露 `headers` 字段（保持与 Node `PromptOpts` 一致），但 **`Session.prompt()` 的底层 ACP POST** 会继承 `ConnectionOptions.headers`——所以更常见的做法是在**每次请求前用 `client.with_(headers=carrier)`** 派生一次性 client：

```python
carrier: dict[str, str] = {}
inject(carrier)
scoped = client.with_(headers={**(client.opts.headers or {}), **carrier})
rt = await scoped.runtimes.get(runtime_id)
response = await rt.sessions.default().prompt("hello")
```

> ⚠️ Node 版的 `PromptOpts` 也不含 `headers` —— 这是有意的：prompt 是数据面 RPC，在 ACP 协议层面 header 只影响 **transport**，不影响 **RPC 语义**。如果业务强需求"per-prompt trace context"，我们再考虑在 `RuntimeConnectOptions` 上加 `headers` 字段（控制 SSE 建连时塞 header），与 Node 同步演进。

### 9.5 Metrics（OpenTelemetry 或 Prometheus）

SDK 不暴露内置 metrics，但通过 `on_request` / `on_response` 钩子可以 0 代码侵入接入：

```python
from opentelemetry import metrics

meter = metrics.get_meter("cloud-agent-sdk")
req_counter = meter.create_counter("cloud_agent_sdk.http.requests")
lat_hist    = meter.create_histogram("cloud_agent_sdk.http.latency_ms", unit="ms")

_start: dict[str, float] = {}

def on_request(req):
    _start[req["headers"]["X-Request-Id"]] = time.monotonic()

def on_response(res):
    rid = res["headers"].get("x-request-id") or res["headers"].get("X-Request-Id")
    if rid and rid in _start:
        lat_hist.record((time.monotonic() - _start.pop(rid)) * 1000,
                        attributes={"status": str(res["status"]), "url": res["url"]})
    req_counter.add(1, attributes={"status": str(res["status"])})

client = CloudAgentClient(
    api_key="ck_xxx",
    on_request=on_request,
    on_response=on_response,
)
```

### 9.6 日志（OTel Logs Bridge）

`ConnectionOptions.logger` 接受任何符合 `Logger` Protocol 的对象。更常见的做法是**不传 `logger`**（让 SDK 用默认的 `logging.getLogger("cloud_agent_sdk")`），然后通过标准 Python `logging` 接口把它接进 OTel Logs pipeline：

```python
import logging
from opentelemetry.sdk._logs import LoggingHandler
from cloud_agent_sdk import CloudAgentClient

# 给 SDK 的 logger 挂上 OTel handler + 设级别 —— 标准 Python 做法
sdk_logger = logging.getLogger("cloud_agent_sdk")
sdk_logger.addHandler(LoggingHandler())
sdk_logger.setLevel(logging.DEBUG)

client = CloudAgentClient(api_key="ck_xxx")   # 不用传 logger 参数
```

也可以给自己的命名 logger 配好后传入 SDK：

```python
my_logger = logging.getLogger("myapp.agent")
my_logger.addHandler(LoggingHandler())
my_logger.setLevel(logging.DEBUG)
client = CloudAgentClient(api_key="ck_xxx", logger=my_logger)
```

SDK 的每条日志（含服务端 `request_id` / 重试 attempt）都会带到 OTel Logs 后端。业务侧想把 SDK 日志和业务请求串起来，用 `contextvars.ContextVar` + `logging.Filter` 把业务 id 注入到所有 `cloud_agent_sdk` logger 产生的日志即可。

### 9.7 接入对照表

| 业务诉求 | 方法 |
|---------|------|
| HTTP span 自动产生（控制面 + 数据面） | `http_client=instrumented_httpx_client` |
| `traceparent` 透传到服务端 / 沙箱 | 全局：`headers={"traceparent": ...}`；或用 httpx instrumentation 自动注入 |
| 自定义 prompt 级 span | 应用层 `tracer.start_as_current_span`，SDK 不介入 |
| HTTP metrics（RED 指标） | `on_request` / `on_response` 钩子 |
| 日志接入 OTel Logs | `logging.getLogger("cloud_agent_sdk").addHandler(LoggingHandler())` |
| Debug 时看 SDK 内部重试 / SSE 状态迁移 | `logging.getLogger("cloud_agent_sdk").setLevel(logging.DEBUG)` |

## 10. 验证矩阵

全部验证脚本位于 `examples/`，与 Node 版 `examples/v1/` 风格一致（端到端可执行脚本，不做 tests/ vs examples/ 两套）。

**当前状态**：75 用例全绿（mock 场景），不依赖后端的部分全部跑通；依赖后端的脚本通过 `CLOUD_AGENT_API_KEY` 判断跳过。

| 维度 | 覆盖位置 | 用例数 | 是否依赖真实后端 |
|------|--------|------|---------------|
| 基础设施（Manifest / Logger / Redact / Errors） | `examples/test_internal.py` | 26 | 否 |
| 控制面 REST 全覆盖（API + 错误映射 + 重试 + 取消 + hooks + 脱敏） | `examples/test_rest.py` | 41 | 否（respx mock） |
| ACP Streamable HTTP transport | `examples/test_acp_transport.py` | 3 | 否（ASGI mock） |
| ACP Session 端到端（connect / prompt / subscribe / cancel / 串行化） | `examples/test_acp_session.py` | 7 | 否（ASGI mock） |
| 4 行到 prompt 冒烟 | `examples/test_smoke.py` | — | 是（`CLOUD_AGENT_API_KEY`） |
| 多 session 并发 + 串行化 | `examples/test_multi_session.py` | — | 是 |
| 多模态输入 | `examples/test_content_blocks.py` | — | 是 |
| 错误场景 | `examples/test_error_handling.py` | — | 是 |
| SSE 断线重连 | `examples/test_reconnect.py` | — | 否（mock SSE）|
| 类型检查 | 全包 | — | — |
| 代码风格 | 全包 | — | — |

**运行约定**：
- `pytest examples/ --timeout=15` 跑全部 mock 测试（当前 75 passed in ~4s）
- 依赖后端的自动 skip（通过 `pytest.mark.skipif(not os.environ.get("CLOUD_AGENT_API_KEY"))`）
- `bash examples/run_all.sh` 跑全部脚本（要求设置 `CLOUD_AGENT_API_KEY`）
- `mypy --strict src/` 全绿
- `ruff check` 全绿

## 11. 风险与缓解

| 风险 | 缓解 |
|------|------|
| 官方 `agent-client-protocol` 的 Pydantic schema 与 TS SDK schema 漂移 | 在 `acp/schema.py` 中包一层"能跑就行"适配（例如宽松字段），并在 CI 中 pin 住小版本 |
| Streamable HTTP transport 在 Python/httpx 下的 SSE 行为边界 | `examples/test_reconnect.py` 模拟断线；在 `transport.py` 里集中处理 `httpx.ReadTimeout` / `httpx.RemoteProtocolError` 等异常 |
| 控制面 int64 大数（Node 用正则转字符串） | Python `int` 无精度问题，但 `id` / `current_version_id` 仍声明为 `str` 对齐跨语言契约，由 Pydantic validator 统一转换 |
| per-session prompt 串行化在 asyncio 下的死锁风险 | 使用 `asyncio.Queue` + `Task` 而非 `Lock`；发 RPC 前 `ensure_future` 再排队 |
| Python 3.10 之前的用户无法使用 | 明确写进 `pyproject.toml` + README |

## 12. 成功标准

- [ ] `pip install tencent-ai-cloud-agent-sdk` 后运行时依赖仅 `httpx` + `pydantic` + `agent-client-protocol`
- [ ] 服务端 4 行代码完成 `create → prompt → 拿到回复`
- [ ] Node `examples/v1/*` 全部等价示例在 Python 端可复现
- [ ] 与 Node 版的 API surface 逐项打勾（产出 `API_PARITY.md` 对照表）
- [ ] `pytest examples/` 全绿（不依赖后端的 mock 场景全部通过）
- [ ] `mypy --strict` 全绿

## 13. 附：与官方 Python ACP SDK 的边界

| 能力 | 来源 |
|------|------|
| `ContentBlock` / `SessionNotification` / `PromptResponse` 等 Pydantic schema | **官方** `agent-client-protocol` |
| stdio JSON-RPC 基类 / 生命周期管理 | **官方**（但我们不用，因为需要 HTTP transport） |
| Streamable HTTP transport（GET SSE + POST） | **自研**（和 Node 版一样，官方两边都没提供） |
| 订阅模型 / per-session 串行化 / token 刷新 | **自研**（CloudAgent 的业务语义层） |
| 控制面 REST 客户端 | **自研** |

**底线**：即使完全不依赖 `agent-client-protocol`（自己写 schema），功能也能交付；但引入官方 SDK 能换 spec parity + 维护性，代价只是一个额外依赖。
