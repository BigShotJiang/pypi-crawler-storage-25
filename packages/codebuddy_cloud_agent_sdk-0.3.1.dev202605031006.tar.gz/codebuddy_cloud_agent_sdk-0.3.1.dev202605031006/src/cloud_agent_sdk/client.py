"""
CloudAgentClient — SDK 顶层入口（对齐 Node v1/client.ts）

持有 ``ConnectionOptions``，提供 ``runtimes`` 子命名空间（仅控制面集合操作）。
本身不发起网络请求、不持有连接。
"""

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING

from cloud_agent_sdk.internal.log import logger_for
from cloud_agent_sdk.opts import ConnectionOptions
from cloud_agent_sdk.rest.client import RestClient
from cloud_agent_sdk.runtime import Runtime
from cloud_agent_sdk.types import (
    AgentManifest,
    CreateRuntimeRequest,
    ManifestSecret,
    PageResult,
    RuntimeInfo,
)

if TYPE_CHECKING:
    from cloud_agent_sdk.opts import RequestOptions, RuntimeCreateOptions, RuntimeListOptions

__all__ = ["CloudAgentClient", "Runtimes"]


# Secret key 名（服务端 `manifest/constants.go` SecretKeyCodebuddyAPIKey）。
_CODEBUDDY_API_KEY_SECRET = "CODEBUDDY_API_KEY"


def _inject_api_key_secret(
    manifest: AgentManifest | None,
    api_key: str | None,
    connection_opts: ConnectionOptions,
) -> AgentManifest | None:
    """按需注入 ``CODEBUDDY_API_KEY`` secret 的兜底逻辑。

    沙箱里的 agent 进程调大模型网关需要这个 secret（见服务端 ``sandbox_builder.go``）。
    SDK 只负责一件事：**把 ``ConnectionOptions.api_key`` 透传到沙箱 agent** ——
    这个 credential 本来就是调用方已经提供过的，用户不应该被迫在 manifest 里再写一遍。

    规则（按优先级）：

    1. ``manifest.secrets`` 已显式声明 ``CODEBUDDY_API_KEY`` → 保留用户值，不覆盖
    2. ``manifest`` 根本没传 → 原样返回 ``None``，让服务端按 "manifest 必填字段缺失"
       报明确错误（SDK 不编造 ``id`` / ``name`` / ``manifest_version`` 等用户的业务语义）
    3. ``api_key`` 为空 → 无从兜底，原样返回 manifest
    4. 其他情况（用户传了 manifest 但没 ``CODEBUDDY_API_KEY``，且 client 有 ``api_key``）
       → 追加 secret，**不 mutate 入参**（Pydantic ``model_copy``）

    设计取舍：SDK **不探查** ``opts.metadata.CODEBUDDY_API_KEY`` —— metadata 是
    AgentOS 与上游网关之间的内部协议，不是 SDK 用户的常规使用通道。即便用户在
    metadata 里塞了 key，服务端自身的优先级会用 metadata 值覆盖 manifest 里注入
    的那条，行为仍然正确。
    """
    # Case 1: 用户已显式声明
    if manifest is not None and manifest.secrets and any(
        s.key == _CODEBUDDY_API_KEY_SECRET for s in manifest.secrets
    ):
        return manifest

    # Case 2: 用户根本没传 manifest —— SDK 不越界编造业务字段
    if manifest is None:
        return None

    # Case 3: 无 api_key 可兜底
    if not api_key:
        return manifest

    # Case 4: 兜底注入（纯函数，不 mutate 入参）
    logger_for(connection_opts).debug(
        "[runtimes.create] auto-injected %s secret from ConnectionOptions.api_key "
        "(no explicit value in agent_manifest.secrets)",
        _CODEBUDDY_API_KEY_SECRET,
    )

    existing = manifest.secrets or []
    new_secrets = [
        *existing,
        ManifestSecret(key=_CODEBUDDY_API_KEY_SECRET, value=api_key),
    ]
    return manifest.model_copy(update={"secrets": new_secrets})


class Runtimes:
    """``CloudAgentClient.runtimes`` 命名空间。"""

    def __init__(self, client: CloudAgentClient) -> None:
        self._client = client

    async def create(self, opts: RuntimeCreateOptions) -> Runtime:
        """创建 Runtime（同步接口，返回时沙箱已 RUNNING）。

        返回 ``Runtime`` 实例，可直接操作 sessions。

        **自动注入 ``CODEBUDDY_API_KEY``**：沙箱内 agent 调大模型网关需要这个
        secret（见服务端 ``sandbox_builder.go``）。SDK 兜底逻辑：

        - 如果 ``opts.agent_manifest.secrets`` 已显式声明 ``CODEBUDDY_API_KEY``
          → 保留用户值
        - 否则若 ``opts.agent_manifest`` 已传 **且** ``ConnectionOptions.api_key``
          存在 → 追加一条 ``CODEBUDDY_API_KEY`` secret（不 mutate 入参）

        这样用户只需在 ``CloudAgentClient(api_key=...)`` 里提供一次，不必在每次
        ``runtimes.create`` 里重复声明同一个 key。

        注意：SDK 不会在用户完全没传 ``agent_manifest`` 时帮他编造
        ``id`` / ``name`` / ``manifest_version`` 等业务字段——那些是用户自己的
        agent 身份标识，必须显式指定。
        """
        body = CreateRuntimeRequest(
            runtime_name=opts.runtime_name,
            agent_manifest=_inject_api_key_secret(
                opts.agent_manifest,
                self._client._opts.api_key,
                self._client._opts,
            ),
            sandbox_template_id=opts.sandbox_template_id,
            sandbox_spec=opts.sandbox_spec,
            sandbox_type=opts.sandbox_type,
            visibility=opts.visibility,
            metadata=dict(opts.metadata) if opts.metadata is not None else None,
        ).model_dump(by_alias=True, exclude_none=True)

        # 创建 Runtime 的默认超时放宽到 120s（对齐 Node）
        timeout_ms = opts.timeout_ms if opts.timeout_ms is not None else 120_000
        # 构造一个 RequestOptions 副本，只覆盖 timeout（保留 headers/retry/signal/request_id）
        req_opts = dataclasses.replace(opts, timeout_ms=timeout_ms)

        raw = await self._client._rest.post("/runtimes", body, req_opts)
        info = RuntimeInfo.model_validate(raw)
        return Runtime(self._client._rest, self._client._opts, info)

    async def get(self, runtime_id: str, opts: RequestOptions | None = None) -> Runtime:
        """获取 Runtime（返回实例）。"""
        raw = await self._client._rest.get(f"/runtimes/{runtime_id}", None, opts)
        info = RuntimeInfo.model_validate(raw)
        return Runtime(self._client._rest, self._client._opts, info)

    async def list(self, opts: RuntimeListOptions | None = None) -> PageResult[RuntimeInfo]:
        """分页列表（返回纯数据）。"""
        import json as _json

        params: dict[str, str] = {}
        if opts is not None:
            if opts.page is not None:
                params["page"] = str(opts.page)
            if opts.page_size is not None:
                params["pageSize"] = str(opts.page_size)
            if opts.metadata:
                params["metadata"] = _json.dumps(dict(opts.metadata))
        raw = await self._client._rest.get("/runtimes", params, opts)
        return PageResult[RuntimeInfo].model_validate(raw)


class CloudAgentClient:
    """SDK 顶层客户端。线程安全：同一实例可被多个协程并发使用。"""

    def __init__(self, opts: ConnectionOptions | None = None, **kwargs: object) -> None:
        """构造（同步，不发网络请求）。

        允许两种传参姿势（等价）::

            CloudAgentClient(ConnectionOptions(api_key="ck_xxx"))
            CloudAgentClient(api_key="ck_xxx")

        认证策略由调用方决定：

        - 后端：提供 ``api_key``
        - 代理 / 业务登录态：通过 ``base_url`` + ``headers`` 携带

        这里不做强校验，请求失败时服务端会返回 401/403。
        """
        if opts is not None and kwargs:
            raise TypeError("Pass either a ConnectionOptions instance OR keyword args, not both")
        if opts is None:
            opts = ConnectionOptions(**kwargs)  # type: ignore[arg-type]
        self._opts = opts
        self._rest = RestClient(opts)
        self.runtimes = Runtimes(self)

    def with_(self, **overrides: object) -> CloudAgentClient:
        """派生新实例（覆盖部分 ``ConnectionOptions``，如切换 ``source_app``）。

        新实例**不共享** ``RestClient``（会重建一个，以便应用新的 headers / api_key）。
        但可通过显式传入 ``http_client=existing_client`` 让底层 httpx 连接池复用。
        """
        new_opts = dataclasses.replace(self._opts, **overrides)  # type: ignore[arg-type]
        return CloudAgentClient(new_opts)

    @property
    def opts(self) -> ConnectionOptions:
        """返回当前 ``ConnectionOptions``（只读快照）。"""
        return self._opts

    # ─── 生命周期 ────────────────────────────────

    async def aclose(self) -> None:
        """关闭 SDK 持有的资源（仅关闭 SDK 自己创建的 httpx client）。"""
        await self._rest.aclose()

    async def __aenter__(self) -> CloudAgentClient:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()
