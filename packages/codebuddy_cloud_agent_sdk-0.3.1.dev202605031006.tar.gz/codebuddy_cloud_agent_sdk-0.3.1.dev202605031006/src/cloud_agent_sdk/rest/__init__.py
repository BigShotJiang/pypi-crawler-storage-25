"""REST 控制面（Phase 2 实施）。"""
