"""
敏感信息脱敏（对齐 Node v1/internal/redact.ts）

范围：headers + 特定已知的 body 字段（白名单 path，非启发式猜测）。
脱敏仅作用于日志打印和钩子回调，不影响实际发送的请求。

详见 docs/agentos/sdk/07-error-retry.md § 4.5。
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

__all__ = ["REDACTED", "is_sensitive_header", "redact_body", "redact_headers"]


# 需要脱敏的 header 名（小写）
_SENSITIVE_HEADER_NAMES: frozenset[str] = frozenset(
    {"authorization", "cookie", "set-cookie", "x-api-key"}
)

REDACTED = "***"


def is_sensitive_header(name: str) -> bool:
    """判断给定 header 名是否属于敏感名（小写比较）。"""
    return name.lower() in _SENSITIVE_HEADER_NAMES


def redact_headers(headers: Mapping[str, str] | None) -> dict[str, str]:
    """返回脱敏后的 headers 副本。

    - 键按原样保留（大小写不变）
    - 值按键名（小写后）匹配敏感列表时替换为 ``'***'``
    - 纯函数，不修改入参
    """
    if not headers:
        return {}
    return {name: REDACTED if is_sensitive_header(name) else value for name, value in headers.items()}


# ─── Body 脱敏 ────────────────────────────────
#
# 与 OpenAI / Anthropic 官方 SDK 不同：它们的 body 只含 prompt / messages / tools
# 等业务内容，没有高敏感字段，所以不脱敏。
#
# 我们的 ``runtimes.create`` / ``sessions.create`` body 里会携带
# ``agent_manifest.secrets[].value``—— 用户业务下发到 sandbox 的真实密钥
# （数据库密码、第三方 API Key 等），泄露后果远超 apiKey
# （apiKey 泄露只影响当前调用方，secret 泄露影响用户业务的下游）。
#
# 策略：
# - **白名单**：只处理已知的、明确含密钥的字段（而非启发式猜测字段名）
# - **浅复制 + 定向深复制**：不修改原始 body，只在日志 / 钩子里使用脱敏副本
# - **未来扩展**：新增敏感字段时显式加到本文件


def redact_body(body: Any) -> Any:
    """给定对象做**浅复制 + 定向脱敏**，返回安全的日志副本。

    不修改入参。若入参不是 ``dict``（string / list / primitive），原样返回。

    已处理字段：
    - ``agent_manifest.secrets[].value`` → ``'***'``（保留 ``name``，只脱 ``value``）
    - 同时兼容服务端 camelCase 命名：``agentManifest.secrets[].value``
    """
    if body is None or not isinstance(body, dict):
        return body

    out: dict[str, Any] = dict(body)

    for manifest_key in ("agent_manifest", "agentManifest"):
        manifest = body.get(manifest_key)
        if isinstance(manifest, dict):
            secrets = manifest.get("secrets")
            if isinstance(secrets, list) and all(isinstance(s, dict) for s in secrets):
                new_secrets = [
                    ({**s, "value": REDACTED} if "value" in s else dict(s)) for s in secrets
                ]
                out[manifest_key] = {**manifest, "secrets": new_secrets}

    return out
