"""
日志工具

按 Python 社区标准做法（对齐 ``urllib3`` / ``httpx`` / ``openai`` / ``requests``
/ ``anthropic``）：

- SDK 使用 ``logging.getLogger('cloud_agent_sdk')``（命名隔离）
- **不设级别、不加自己的 handler**（除了 ``NullHandler`` 兜底 —— 在包 ``__init__``
  里添加，防止用户没配任何 handler 时出现 "No handlers could be found" 警告）
- 级别和输出由**用户**通过标准 ``logging`` 配置控制::

      logging.getLogger("cloud_agent_sdk").setLevel(logging.DEBUG)
      # 或
      logging.basicConfig(level=logging.DEBUG)

- 用户也可以通过 ``ConnectionOptions.logger`` 塞入任何 ``Logger`` Protocol
  实现（``logging.Logger`` / structlog / loguru / 自己写的适配器）

**日志 ID 策略**（对齐 Anthropic Python SDK）：

- SDK 日志**不自造本地 ID**。唯一的定位 ID 是服务端返回的 ``request_id``
  （``x-request-id`` 响应头 / 业务 ``body.request_id``），会以独立 debug 行
  ``"request_id: <id>"`` 打出，也会挂在 ``APIError.request_id`` 上。
- 重试链路可读性：通过 ``"Retrying request to ... in Nms (attempt 2/3): ..."``
  这种独立告警行表达"第几次重试"，无需额外 ID。
- 业务维度定位（session / runtime / connection）：通过**日志前缀**带上
  业务上下文（如 ``[acp conn=xxx]`` / ``[session sess_yyy] ...``）。
- 用户想把 SDK 日志和自己业务日志串起来：用标准的
  ``contextvars.ContextVar`` + ``logging.Filter`` 注入业务 ID，
  所有 ``cloud_agent_sdk`` logger 产生的日志都会带上（示例见文档）。

本模块只暴露一个函数：

- ``logger_for(opts)``：返回 ``opts.logger`` 或默认 ``logging.getLogger('cloud_agent_sdk')``
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cloud_agent_sdk.opts import ConnectionOptions, Logger

__all__ = [
    "logger_for",
    "SDK_LOGGER_NAME",
]


SDK_LOGGER_NAME = "cloud_agent_sdk"
"""SDK 默认 logger 的名字。用户可通过 ``logging.getLogger(SDK_LOGGER_NAME)`` 配置。"""


def logger_for(opts: ConnectionOptions) -> Logger:
    """返回 SDK 要用的 Logger。

    - 传了 ``opts.logger``：直接返回（SDK 不修改任何状态）
    - 未传：返回 ``logging.getLogger('cloud_agent_sdk')``（Python 标准做法）

    级别和输出由用户通过标准 logging 接口配置，SDK 不干预。
    """
    if opts.logger is not None:
        return opts.logger
    return logging.getLogger(SDK_LOGGER_NAME)  # type: ignore[return-value]
