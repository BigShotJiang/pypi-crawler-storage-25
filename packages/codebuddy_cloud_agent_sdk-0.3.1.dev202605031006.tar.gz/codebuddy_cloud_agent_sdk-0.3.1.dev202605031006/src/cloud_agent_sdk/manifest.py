"""
ManifestBuilder — Agent Manifest 构造器（对齐 Node v1/manifest.ts）

按 manifest-spec.md v1.0 的 4 大类提供 fluent API。纯本地，不发网络请求。

示例::

    from cloud_agent_sdk import ManifestBuilder, ManifestSecret, ManifestEnv

    manifest = (
        ManifestBuilder()
            .id("my-agent")
            .name("My Agent")
            .version("1.0")
            .system_prompt("You are a helpful assistant.")
            .skills("code-reviewer", "test-writer")
            .secrets(ManifestSecret(key="OPENAI_API_KEY", value="..."))
            .envs(ManifestEnv(key="LOG_LEVEL", value="info"))
            .build()
    )
"""

from __future__ import annotations

from typing import Any

from cloud_agent_sdk.errors import APIValidationError
from cloud_agent_sdk.types import (
    AgentManifest,
    ManifestEnv,
    ManifestMcp,
    ManifestPlugin,
    ManifestRule,
    ManifestSecret,
    ManifestSkill,
    ManifestSlashCommand,
    ManifestSubagent,
    ManifestWorkspace,
)

__all__ = ["ManifestBuilder"]


class ManifestBuilder:
    """Agent Manifest 构造器。所有方法返回 ``self`` 支持链式调用。"""

    def __init__(self) -> None:
        # ─── 基础配置 ────────────────────────────────
        self._id: str | None = None
        self._name: str | None = None
        self._version: str | None = None
        self._system_prompt: str | None = None
        self._system_prompt_file: str | None = None
        self._use_workspace_root: bool | None = None
        self._isolate_config_dir: bool | None = None
        self._settings: str | None = None

        # ─── 能力与规范 ──────────────────────────────
        self._rules: list[ManifestRule] = []
        self._skills: list[ManifestSkill] = []
        self._subagents: list[ManifestSubagent] = []
        self._slash_commands: list[ManifestSlashCommand] = []
        self._plugins: list[ManifestPlugin] = []
        self._mcp: list[ManifestMcp] = []

        # ─── 工作空间 ────────────────────────────────
        self._workspaces: list[ManifestWorkspace] = []

        # ─── 环境配置 ────────────────────────────────
        self._secrets: list[ManifestSecret] = []
        self._envs: list[ManifestEnv] = []

        # ─── 扩展字段 ────────────────────────────────
        self._extra: dict[str, Any] = {}

    # ============================================================
    # 基础配置
    # ============================================================

    def id(self, id: str) -> ManifestBuilder:
        """设置 Manifest ID（必填）。"""
        self._id = id
        return self

    def name(self, name: str) -> ManifestBuilder:
        """设置 Manifest 名称（必填）。"""
        self._name = name
        return self

    def version(self, version: str) -> ManifestBuilder:
        """设置 Manifest 版本（必填，如 ``'1.0'``）。"""
        self._version = version
        return self

    def system_prompt(self, prompt: str) -> ManifestBuilder:
        """设置 system prompt（与 ``system_prompt_file`` 互斥）。"""
        self._system_prompt = prompt
        self._system_prompt_file = None
        return self

    def system_prompt_file(self, url: str) -> ManifestBuilder:
        """设置 system prompt 的下载地址（与 ``system_prompt`` 互斥）。"""
        self._system_prompt_file = url
        self._system_prompt = None
        return self

    def use_workspace_root(self, value: bool = True) -> ManifestBuilder:
        """是否使用 workspace 根目录作为工作目录。"""
        self._use_workspace_root = value
        return self

    def isolate_config_dir(self, value: bool = True) -> ManifestBuilder:
        """是否隔离配置目录。"""
        self._isolate_config_dir = value
        return self

    def settings(self, url: str) -> ManifestBuilder:
        """settings.json 下载地址。"""
        self._settings = url
        return self

    # ============================================================
    # 能力与规范（统一复数，接受单个或可变参数）
    # ============================================================

    def rules(self, *rules: ManifestRule) -> ManifestBuilder:
        """追加规则配置。"""
        self._rules.extend(rules)
        return self

    def skills(self, *skills: ManifestSkill | str) -> ManifestBuilder:
        """追加技能配置。字符串视为仅提供 ``name`` 的简写。"""
        for s in skills:
            self._skills.append(ManifestSkill(name=s) if isinstance(s, str) else s)
        return self

    def subagents(self, *subagents: ManifestSubagent | str) -> ManifestBuilder:
        """追加子代理配置。字符串视为仅提供 ``name`` 的简写。"""
        for s in subagents:
            self._subagents.append(ManifestSubagent(name=s) if isinstance(s, str) else s)
        return self

    def slash_commands(self, *cmds: ManifestSlashCommand | str) -> ManifestBuilder:
        """追加 slash command 配置。字符串视为仅提供 ``name`` 的简写。"""
        for c in cmds:
            self._slash_commands.append(
                ManifestSlashCommand(name=c) if isinstance(c, str) else c
            )
        return self

    def plugins(self, *plugins: ManifestPlugin) -> ManifestBuilder:
        """追加插件配置。"""
        self._plugins.extend(plugins)
        return self

    def mcp(self, *mcps: ManifestMcp) -> ManifestBuilder:
        """追加 MCP 配置。"""
        self._mcp.extend(mcps)
        return self

    # ============================================================
    # 工作空间 / 环境
    # ============================================================

    def workspaces(self, *wss: ManifestWorkspace) -> ManifestBuilder:
        """追加工作空间配置。"""
        self._workspaces.extend(wss)
        return self

    def secrets(self, *secrets: ManifestSecret) -> ManifestBuilder:
        """追加密钥（SDK 日志中 ``value`` 自动脱敏）。"""
        self._secrets.extend(secrets)
        return self

    def envs(self, *envs: ManifestEnv) -> ManifestBuilder:
        """追加环境变量。"""
        self._envs.extend(envs)
        return self

    # ============================================================
    # 扩展
    # ============================================================

    def raw(self, key: str, value: Any) -> ManifestBuilder:
        """设置任意扩展字段（对齐 Node 的 ``extra``）。"""
        self._extra[key] = value
        return self

    # ============================================================
    # 构建
    # ============================================================

    def build(self) -> AgentManifest:
        """校验必填字段并构建 ``AgentManifest``。

        Raises:
            APIValidationError: 当 ``id`` / ``name`` / ``version`` 缺失，或
                ``system_prompt`` 与 ``system_prompt_file`` 同时设置时。
        """
        if not self._id:
            raise APIValidationError("manifest.id is required")
        if not self._name:
            raise APIValidationError("manifest.name is required")
        if not self._version:
            raise APIValidationError("manifest.manifestVersion is required")
        if self._system_prompt and self._system_prompt_file:
            raise APIValidationError(
                "system_prompt and system_prompt_file are mutually exclusive"
            )

        data: dict[str, Any] = {
            "id": self._id,
            "name": self._name,
            "manifest_version": self._version,
        }

        # 基础配置
        if self._system_prompt:
            data["system_prompt"] = self._system_prompt
        if self._system_prompt_file:
            data["system_prompt_file"] = self._system_prompt_file
        if self._use_workspace_root is not None:
            data["use_workspace_root"] = self._use_workspace_root
        if self._isolate_config_dir is not None:
            data["isolate_config_dir"] = self._isolate_config_dir
        if self._settings:
            data["settings"] = self._settings

        # 能力与规范
        if self._rules:
            data["rules"] = list(self._rules)
        if self._skills:
            data["skills"] = list(self._skills)
        if self._subagents:
            data["subagents"] = list(self._subagents)
        if self._slash_commands:
            data["slash_commands"] = list(self._slash_commands)
        if self._plugins:
            data["plugins"] = list(self._plugins)
        if self._mcp:
            data["mcp"] = list(self._mcp)

        # 工作空间
        if self._workspaces:
            data["workspaces"] = list(self._workspaces)

        # 环境配置
        if self._secrets:
            data["secrets"] = list(self._secrets)
        if self._envs:
            data["envs"] = list(self._envs)

        # 扩展字段
        data.update(self._extra)

        return AgentManifest.model_validate(data)
