"""
ConnectionOptions 及其子 Options 定义

与 Node v1/opts.ts 功能等价，但使用 Python 原语：

- Logger：方法名 ``debug / info / warning / error``（对齐 ``logging.Logger``）
- 取消：用 ``asyncio.Event``（以及用户可以直接 ``task.cancel()``）
- HTTP 客户端：``httpx.AsyncClient``

**类的分工 / 继承关系**（与 Node 代码对齐；注意 Node 版顶部注释声称
``ConnectionOpts → RequestOpts`` 有继承，但实际代码没有，这里按代码为准）::

    # 客户端级配置 —— 全局，整个 CloudAgentClient 生命周期不变
    ConnectionOptions

    # 请求级配置 —— 每次 HTTP 调用都可覆盖
    RequestOptions
      ├── RuntimeCreateOptions   （create runtime 这次请求的参数 + 通用请求字段）
      ├── RuntimeConnectOptions  （ACP 连接参数 + 通用请求字段，也走一次 HTTP）
      ├── SessionCreateOptions   （create session 参数 + 通用请求字段）
      ├── RuntimeListOptions     （list runtimes 分页参数 + 通用请求字段）
      └── SessionListOptions     （list sessions 分页参数 + 通用请求字段）

    # 独立配置 —— 不在 HTTP 请求链路上
    PromptOptions    （走已建立的 ACP SSE 连接，没有 retry / request_id 概念）
    RetryOptions     （重试策略，嵌在 ConnectionOptions / RequestOptions 里）

**为什么 ``ConnectionOptions`` 不是根**：
全局配置（``api_key`` / ``base_url`` / ``logger`` / ``http_client`` /
``on_request`` / ``on_response``）应该**在 client 构造时一次性确定**，不希望被
per-request 覆盖。物理上保持独立可以从类型层面阻止误用。

**Logger Protocol 为什么放这里（而不是 internal/log.py）**：
``Logger`` 是**公共 API 契约**（业务要构造 ``ConnectionOptions(logger=my_logger)``
就必须知道接口），和 ``RetryOn`` / ``RequestHook`` 等同属 opts 的辅助类型。
``internal/log.py`` 只放 SDK 内部实现（``logger_for`` 等），业务永远不 import 它。
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, Protocol, TypeAlias

if TYPE_CHECKING:
    import httpx
    from acp.schema import PromptResponse, SessionNotification

    from cloud_agent_sdk.types import AgentManifest, SandboxSpec

__all__ = [
    "Logger",
    "RetryContext",
    "RetryOn",
    "RetryOptions",
    "ConnectionOptions",
    "RequestOptions",
    "RuntimeCreateOptions",
    "RuntimeConnectOptions",
    "SessionCreateOptions",
    "PromptOptions",
    "RuntimeListOptions",
    "SessionListOptions",
    "RequestHook",
    "ResponseHook",
    "RequestHookInfo",
    "ResponseHookInfo",
]


# ============================================================
# 辅助类型
# ============================================================


class Logger(Protocol):
    """日志器接口，方法名对齐 ``logging.Logger``。

    SDK 内部调用 ``debug / info / warning / error``（用 printf-style 参数）。
    ``logging.Logger`` 原生实现此 Protocol，也兼容 structlog / loguru 等。

    ``msg`` 类型声明为 ``object`` 以匹配 ``logging.Logger`` 的 stub
    （实际 SDK 内部传入的都是 str，但标准库把 msg 当作任意对象）。
    """

    def debug(self, msg: object, *args: object, **kwargs: object) -> object: ...
    def info(self, msg: object, *args: object, **kwargs: object) -> object: ...
    def warning(self, msg: object, *args: object, **kwargs: object) -> object: ...
    def error(self, msg: object, *args: object, **kwargs: object) -> object: ...


@dataclass(frozen=True)
class RetryContext:
    """重试决策的上下文信息（传给 ``RetryOptions.retry_on``）。"""

    attempt: int
    """当前重试次数（首次尝试为 1）。"""

    method: str
    """HTTP 方法（``GET`` / ``POST`` / ``PATCH`` / ``DELETE``）。"""

    url: str
    """完整请求 URL。"""


RetryOn: TypeAlias = Callable[[BaseException, RetryContext], bool]
"""自定义重试判定。

返回 ``True`` 则按 ``max_attempts`` 继续重试，返回 ``False`` 则立即抛错给调用方。
传入 ``RetryOptions.retry_on`` 会**完全替换** SDK 内置默认判定（不叠加）。
"""


@dataclass
class RetryOptions:
    """重试策略。"""

    max_attempts: int = 3
    """最大尝试次数（含首次）。"""

    backoff_ms: int = 300
    """首次退避毫秒。"""

    backoff_factor: float = 2.0
    """退避指数因子。"""

    jitter: bool = True
    """是否加 ±20% 抖动。"""

    retry_on: RetryOn | None = None
    """自定义判定。不传时使用 SDK 内置 ``default_retry_on``：

    - ``APIAuthError`` / ``APINotFoundError`` / ``APIValidationError`` / ``AcpProtocolError`` → 不重试
    - ``APITimeoutError`` → 仅 ``GET`` 方法重试（非幂等方法超时可能导致重复副作用）
    - ``APINetworkError`` → 全部方法重试
    - ``CancelledError`` → 不重试
    - 其他（httpx 原生异常等）→ 重试
    """


# ============================================================
# 钩子类型
# ============================================================


@dataclass(frozen=True)
class RequestHookInfo:
    """``on_request`` 钩子收到的请求信息（headers 已脱敏）。"""

    method: str
    url: str
    headers: Mapping[str, str]


@dataclass(frozen=True)
class ResponseHookInfo:
    """``on_response`` 钩子收到的响应信息（headers 已脱敏）。"""

    status: int
    url: str
    headers: Mapping[str, str]


RequestHook: TypeAlias = Callable[[RequestHookInfo], None]
ResponseHook: TypeAlias = Callable[[ResponseHookInfo], None]


# ============================================================
# ConnectionOptions — 根
# ============================================================


@dataclass
class ConnectionOptions:
    """SDK 根选项。构造 ``CloudAgentClient`` 时传入。"""

    # ─── 认证 ────────────────────────────────────────
    api_key: str | None = None
    """发送为 ``x-api-key`` header。

    业务代理 / 浏览器场景下通常不传；通过 ``base_url`` 指向业务后端代理由代理注入
    鉴权，业务登录态通过 ``headers`` 携带（如 ``Authorization: Bearer``）。
    """

    # ─── 身份 ────────────────────────────────────────
    base_url: str | None = None
    """默认 ``https://www.codebuddy.cn/v2/agentos``。"""

    source_app: str | None = None
    source_tenant_id: str | None = None
    user_id: str | None = None

    # ─── 传输 ────────────────────────────────────────
    timeout_ms: int = 30_000
    headers: Mapping[str, str] | None = None

    # ─── 行为 ────────────────────────────────────────
    retry: RetryOptions | Literal[False] | None = None
    """重试配置。传 ``False`` 关闭重试；不传用 SDK 默认。"""

    logger: Logger | None = None
    """自定义日志器。不传时 SDK 使用 ``logging.getLogger('cloud_agent_sdk')``。

    传入任何实现了 ``debug / info / warning / error`` 四个方法的对象即可。

    **SDK 永远不修改 logger 的级别、handler、formatter**（对齐 Python 社区标准
    做法：``urllib3`` / ``httpx`` / ``openai`` 等）—— 级别和输出 100% 由用户配置。

    **两种常用接入姿势**：

    1. **用 SDK 默认 logger**（不传 ``logger``，最简）::

        import logging
        logging.getLogger("cloud_agent_sdk").setLevel(logging.DEBUG)
        # 或通过 basicConfig 全局开
        logging.basicConfig(level=logging.DEBUG)

        CloudAgentClient(api_key="...")   # 不用传 logger 参数

    2. **接入自己的 logging 基础设施**（业务有 OTel Logs Bridge / JSON 格式器等时）::

        import logging
        my_logger = logging.getLogger("myapp.agent")
        my_logger.setLevel(logging.DEBUG)
        my_logger.addHandler(my_otel_handler)
        CloudAgentClient(api_key="...", logger=my_logger)

    3. **接入 loguru / structlog**（非标准 logging 体系）::

        from loguru import logger
        logger.add(sys.stderr, level="DEBUG")
        CloudAgentClient(api_key="...", logger=logger)
    """

    # ─── 钩子 ────────────────────────────────────────
    http_client: httpx.AsyncClient | None = None
    """替换底层 HTTP 客户端。常见用法：

    - 接入 OpenTelemetry：注入被 ``opentelemetry-instrumentation-httpx`` 包过的 client
    - 自定义代理 / 拦截 / mock

    不传时 SDK 内部创建默认 ``httpx.AsyncClient()``。

    注：SDK 不拥有传入的 client 生命周期（不会自动 ``aclose()``），由调用方负责关闭。
    """

    on_request: RequestHook | None = None
    """请求发出前回调。``headers`` 已脱敏（敏感字段替换为 ``'***'``）。"""

    on_response: ResponseHook | None = None
    """响应到达后回调。``headers`` 已脱敏。"""


# ============================================================
# RequestOptions — 逐请求覆盖
# ============================================================


@dataclass
class RequestOptions:
    """逐请求覆盖配置。"""

    timeout_ms: int | None = None
    headers: Mapping[str, str] | None = None
    """附加自定义 header（业务可塞 ``traceparent`` 等，SDK 原样透传）。"""

    retry: RetryOptions | Literal[False] | None = None

    cancel: asyncio.Event | None = None
    """可选的取消事件。``event.set()`` 触发时 SDK 会中止正在进行的请求。

    更常见的做法：直接 ``task.cancel()`` 调用方 Task，SDK 会正确传播
    ``CancelledError``。本字段主要给"我已经 await 住了但想从外部取消"的场景。
    """

    request_id: str | None = None
    """发送为 ``X-Request-Id``；业务自定义 ID 可用此字段。"""


# ============================================================
# RuntimeCreateOptions
# ============================================================


@dataclass
class RuntimeCreateOptions(RequestOptions):
    """``CloudAgentClient.runtimes.create(...)`` 选项。"""

    runtime_name: str = ""
    """必填：Runtime 业务名。"""

    agent_manifest: AgentManifest | None = None
    sandbox_template_id: str | None = None
    sandbox_spec: SandboxSpec | None = None
    sandbox_type: str | None = None
    visibility: Literal["PRIVATE", "PUBLIC"] | None = None
    metadata: Mapping[str, str] | None = None


# ============================================================
# RuntimeConnectOptions
# ============================================================


@dataclass
class RuntimeConnectOptions(RequestOptions):
    """``Session.connect(...)`` 选项（ACP 连接层）。"""

    acp_token: str | None = None
    auto_refresh_token: bool = True
    reconnect_max_attempts: float = float("inf")
    reconnect_backoff_ms: int = 300
    reconnect_max_backoff_ms: int = 30_000
    heartbeat_timeout_ms: int = 45_000
    initialize: bool = True
    last_event_id: str | None = None


# ============================================================
# SessionCreateOptions
# ============================================================


@dataclass
class SessionCreateOptions(RequestOptions):
    """``runtime.sessions.create(...)`` 选项。"""

    session_id: str | None = None
    session_name: str | None = None
    agent_manifest: AgentManifest | None = None


# ============================================================
# PromptOptions
# ============================================================

# 便利钩子签名
_TurnStartHook: TypeAlias = Callable[[], None | Awaitable[None]]
_TurnEndHook: TypeAlias = Callable[["PromptResponse"], None | Awaitable[None]]
_ChunkHook: TypeAlias = Callable[["SessionNotification"], None | Awaitable[None]]


@dataclass
class PromptOptions:
    """``Session.prompt(...)`` 选项。

    与 ``ConnectionOptions`` 解耦 —— prompt 走已建立的 ACP 连接，不涉及控制面
    传输配置。
    """

    cancel: asyncio.Event | None = None
    """取消事件。``event.set()`` 时 SDK 会向服务端发 ``session/cancel`` 并中止等待。

    也可以直接 ``task.cancel()`` 调用方 Task，SDK 会正确传播 ``CancelledError``
    并发送 ``session/cancel``。
    """

    timeout_ms: int | None = None
    """超时毫秒（默认无限）。"""

    include_thinking: bool | None = None
    model: str | None = None

    on_turn_start: _TurnStartHook | None = None
    """Prompt 开始后触发一次（已自动 connect 完成、RPC 即将发出）。"""

    on_turn_end: _TurnEndHook | None = None
    """Prompt 结束后触发一次，收到 ``PromptResponse``。失败时不触发（错误由
    ``prompt()`` 抛出传递）。
    """

    on_chunk: _ChunkHook | None = None
    """便利钩子：prompt 期间每条上游 ``SessionNotification`` 都会触发一次。

    内部实现等价于"prompt 开始时临时 ``session.subscribe(fn)``，prompt 结束
    时自动 unsubscribe"。跨 prompt 持续订阅请直接用 ``session.subscribe()``。
    """


# ============================================================
# 列表查询选项
# ============================================================


@dataclass
class RuntimeListOptions(RequestOptions):
    """``CloudAgentClient.runtimes.list(...)`` 查询参数。"""

    page: int | None = None
    page_size: int | None = None
    metadata: Mapping[str, str] | None = None


@dataclass
class SessionListOptions(RequestOptions):
    """``runtime.sessions.list(...)`` 查询参数。"""

    page: int | None = None
    page_size: int | None = None
    session_status: str | None = None
