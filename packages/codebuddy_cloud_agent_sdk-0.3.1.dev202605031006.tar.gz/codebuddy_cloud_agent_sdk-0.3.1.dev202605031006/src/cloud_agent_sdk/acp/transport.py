"""
Streamable HTTP Transport for ACP

对应 Node 版 ``v1/acp/transport.ts``，实现 CodeBuddy AgentOS 的 Streamable HTTP
协议。本模块的输出是**一对 ``asyncio.StreamReader`` / ``asyncio.StreamWriter``**，
可以直接传给官方 ``acp.client.ClientSideConnection``，由官方做 JSON-RPC 路由 +
Pydantic 校验。

协议流程：

1. Client 建立 ``GET {endpoint}`` SSE 连接，响应头 ``Acp-Connection-Id`` 为连接 ID
2. Client 通过 ``POST {endpoint}`` 发送 JSON-RPC 请求（带 ``Acp-Connection-Id``）
3. 通知通过 GET SSE 推送，RPC 响应可能通过 POST body（JSON）或 POST SSE 返回

稳定性保证（对齐 Node）：

- 指数退避自动重连 + ±25% jitter
- ``Last-Event-ID`` 断点续传
- ``Acp-Connection-Id`` 复用
- 心跳超时检测（默认 60s）
- connection_version 防竞态
- POST SSE 后台处理（防死锁）

**架构**（Python 化）：

- SSE 消息 → ``StreamReader.feed_data(json + b"\\n")``
- 官方 ``ClientSideConnection`` 通过 ``StreamReader.readline()`` 消费
- 官方写入 ``StreamWriter`` 的字节 → 被 ``_PostingTransport`` 截获 → 异步 POST
- 两个方向桥接，官方完全感知不到底层是 HTTP 还是 stdio
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field

import httpx

__all__ = [
    "StreamableHttpTransport",
    "TransportOptions",
    "TransportClosedError",
    "TransportConnectError",
]


logger = logging.getLogger("cloud_agent_sdk")


# ─── Options ────────────────────────────────


@dataclass
class TransportOptions:
    """Transport 配置。对齐 Node ``StreamableHttpTransportOptions``。"""

    endpoint: str
    """ACP endpoint URL（``https://{sandbox}/acp``）。"""

    auth_token: str | None = None
    """Bearer token（会注入到 ``Authorization`` header）。不传时不加认证 header。"""

    headers: Mapping[str, str] = field(default_factory=dict)
    """额外自定义 header（例如 ``traceparent``）。"""

    heartbeat_timeout_ms: int = 60_000
    """SSE 心跳超时。超过此时间未收到任何数据则触发重连。0 表示禁用。"""

    connection_timeout_ms: int = 30_000
    """GET SSE 建连超时。"""

    post_timeout_ms: int = 30_000
    """POST 请求超时。"""

    reconnect_enabled: bool = True
    reconnect_initial_delay_ms: int = 1_000
    reconnect_max_delay_ms: int = 30_000
    reconnect_max_retries: float = float("inf")
    reconnect_jitter: bool = True

    http_client: httpx.AsyncClient | None = None
    """复用外部 ``httpx.AsyncClient``（典型用法：OTel instrumented）。不传时 SDK 内建。"""


# ─── 错误 ────────────────────────────────


class TransportClosedError(Exception):
    """Transport 已关闭时触发。"""


class TransportConnectError(Exception):
    """GET SSE 建连失败超过重试上限。"""


# ─── 假 transport：让 StreamWriter 写入被 POST 发出 ────────────────


class _PostingTransport(asyncio.WriteTransport):
    """伪 ``asyncio.WriteTransport``，接管 ``StreamWriter.write(bytes)`` 并异步 POST。

    官方 ``acp.connection`` 发送 JSON-RPC 消息的格式是 ``{JSON}\\n``（newline-delimited
    JSON）。我们按行切分后每条调用 ``send_message(dict)`` 发出。
    """

    def __init__(
        self,
        send_message: Callable[[dict[str, object]], Awaitable[None]],
        get_connection_id: Callable[[], str | None],
    ) -> None:
        super().__init__()
        self._send_message = send_message
        self._get_connection_id = get_connection_id
        self._buffer = b""
        self._closing = False
        # 后台 POST 任务池（失败不影响其他消息）
        self._pending: set[asyncio.Task[None]] = set()

    def write(self, data: bytes | bytearray | memoryview) -> None:
        """官方 sender 会调这个接口写 ``{JSON}\\n``。"""
        if self._closing:
            return
        self._buffer += bytes(data)
        while b"\n" in self._buffer:
            line, self._buffer = self._buffer.split(b"\n", 1)
            if not line.strip():
                continue
            try:
                msg = json.loads(line.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                logger.warning(
                    "[acp-transport conn=%s] drop invalid JSON from connection: %r",
                    self._get_connection_id() or "-",
                    line,
                )
                continue
            task = asyncio.create_task(self._dispatch(msg))
            self._pending.add(task)
            task.add_done_callback(self._pending.discard)

    async def _dispatch(self, msg: dict[str, object]) -> None:
        try:
            await self._send_message(msg)
        except Exception as e:
            logger.debug(
                "[acp-transport conn=%s] POST failed: %s: %s",
                self._get_connection_id() or "-",
                type(e).__name__,
                e,
            )

    def is_closing(self) -> bool:
        return self._closing

    def close(self) -> None:
        self._closing = True

    def get_extra_info(self, name: str, default: object = None) -> object:
        return default


# ─── StreamableHttpTransport ────────────────────────────────


class StreamableHttpTransport:
    """Streamable HTTP transport，输出 ``(reader, writer)`` 供官方 ACP connection 消费。

    用法::

        transport = StreamableHttpTransport(TransportOptions(endpoint=..., auth_token=...))
        await transport.start()
        reader, writer = transport.reader, transport.writer

        # 直接交给官方
        from acp.client import ClientSideConnection
        conn = ClientSideConnection(my_client_impl, writer, reader)
        await conn.initialize(protocol_version=1)

        # 用完
        await transport.aclose()
    """

    def __init__(self, opts: TransportOptions) -> None:
        self._opts = opts
        self._owned_http = opts.http_client is None
        self._http = opts.http_client if opts.http_client is not None else httpx.AsyncClient()

        # 连接状态
        self._connection_id: str | None = None
        self._last_event_id: str | None = None
        self._connection_version = 0
        self._reconnect_attempts = 0

        # 生命周期
        self._closed = False
        self._sse_task: asyncio.Task[None] | None = None
        self._ready = asyncio.Event()
        self._ready_error: BaseException | None = None

        # 心跳
        self._last_activity = 0.0
        self._heartbeat_task: asyncio.Task[None] | None = None

        # 后台 task 池（POST SSE 响应消费等），避免被 GC 回收
        self._background_tasks: set[asyncio.Task[None]] = set()

        # Reader（SSE 消息入口）
        self._reader = asyncio.StreamReader()

        # Writer（JSON-RPC 出口）—— 构造时延迟，需要 running loop
        self._writer: asyncio.StreamWriter | None = None
        self._writer_transport: _PostingTransport | None = None

    # ─── 属性 ────────────────────────────────

    @property
    def reader(self) -> asyncio.StreamReader:
        """接收消息的 StreamReader（交给官方 Connection 做 readline）。"""
        return self._reader

    @property
    def writer(self) -> asyncio.StreamWriter:
        """发送消息的 StreamWriter（交给官方 Connection 做 write）。start() 后可用。"""
        if self._writer is None:
            raise TransportClosedError("Transport not started; call await transport.start() first")
        return self._writer

    @property
    def connection_id(self) -> str | None:
        """当前 Acp-Connection-Id。未连接时为 ``None``。"""
        return self._connection_id

    @property
    def is_connected(self) -> bool:
        return self._ready.is_set() and self._connection_id is not None and not self._closed

    # ─── 生命周期 ────────────────────────────────

    async def start(self) -> None:
        """建立 SSE 连接并等待 ``Acp-Connection-Id`` 返回。

        Raises:
            TransportConnectError: 建连失败（网络错误 / 服务端不返回 connection id）。
        """
        if self._closed:
            raise TransportClosedError("Transport already closed")
        if self._sse_task is not None:
            # 已 start 过，等就绪即可（幂等）
            await self._wait_ready()
            return

        # 构造 writer
        loop = asyncio.get_running_loop()
        self._writer_transport = _PostingTransport(
            self._send_message,
            get_connection_id=lambda: self._connection_id,
        )
        # StreamWriter 需要一个 StreamReaderProtocol（构造契约，我们不从 transport 读，所以给空 reader）
        protocol = asyncio.StreamReaderProtocol(asyncio.StreamReader(loop=loop), loop=loop)
        self._writer = asyncio.StreamWriter(self._writer_transport, protocol, None, loop)

        # 启动 SSE 后台循环
        self._sse_task = asyncio.create_task(self._sse_loop(), name="acp-transport-sse")

        await self._wait_ready()

    async def aclose(self) -> None:
        """优雅关闭：向服务端发 DELETE 释放连接，停止 SSE 循环。幂等。"""
        if self._closed:
            return
        self._closed = True

        # 停 writer
        if self._writer_transport is not None:
            self._writer_transport.close()
        if self._writer is not None:
            try:
                self._writer.close()
            except Exception:
                pass

        # 向服务端释放 connection（best effort）
        if self._connection_id is not None:
            try:
                await self._http.request(
                    "DELETE",
                    self._opts.endpoint,
                    headers=self._build_headers(with_connection_id=True),
                    timeout=5.0,
                )
            except Exception as e:
                logger.debug(
                    "[acp-transport conn=%s] DELETE failed (ignored): %s",
                    self._connection_id or "-",
                    e,
                )

        # 停止 SSE 后台循环
        if self._sse_task is not None:
            self._sse_task.cancel()
            try:
                await self._sse_task
            except (asyncio.CancelledError, Exception):
                pass

        # 取消后台 task（POST SSE 消费等）
        for t in list(self._background_tasks):
            t.cancel()
        for t in list(self._background_tasks):
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._background_tasks.clear()

        # 关 reader
        self._reader.feed_eof()

        # 关 SDK 自建的 http client
        if self._owned_http:
            await self._http.aclose()

    async def _wait_ready(self) -> None:
        """等待首次连接就绪。"""
        await self._ready.wait()
        if self._ready_error is not None:
            raise self._ready_error

    # ─── 内部：header 构建 ────────────────────────────────

    def _build_headers(
        self,
        *,
        with_connection_id: bool = False,
        with_last_event_id: bool = False,
    ) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self._opts.auth_token:
            headers["Authorization"] = f"Bearer {self._opts.auth_token}"
        for k, v in self._opts.headers.items():
            headers[k] = v
        if with_connection_id and self._connection_id:
            headers["Acp-Connection-Id"] = self._connection_id
        if with_last_event_id and self._last_event_id:
            headers["Last-Event-ID"] = self._last_event_id
        return headers

    # ─── SSE 循环 ────────────────────────────────

    async def _sse_loop(self) -> None:
        """GET SSE 连接 + 自动重连。"""
        while not self._closed:
            try:
                await self._run_sse_once()
            except asyncio.CancelledError:
                return
            except Exception as e:
                logger.debug(
                    "[acp-transport conn=%s] sse error: %s: %s",
                    self._connection_id or "-",
                    type(e).__name__,
                    e,
                )
                # 首次就失败 → 让 start() 抛错退出
                if not self._ready.is_set():
                    self._ready_error = TransportConnectError(
                        f"SSE connection failed: {type(e).__name__}: {e}"
                    )
                    self._ready.set()
                    return

            if self._closed or not self._opts.reconnect_enabled:
                return

            # SSE 流断开（异常或服务端关流）→ 进入重连前清 ready，
            # 让 _send_message 里的 `await self._ready.wait()` 阻塞，
            # 避免 POST 带着旧的 Acp-Connection-Id 发出（对齐 Node transport.ts
            # "重连时 reset connectionReady Promise" 的竞态保护）。
            #
            # _connection_id 故意保留：`_send_message` 会在 `_ready.wait()` 返回
            # 之后才读 `_connection_id`，那时已经被 `_run_sse_once` 更新为新值。
            # 保留旧值也便于"重连中间态"的可观测性（用户 / 测试能看到"上一次的 id"）。
            self._ready.clear()

            self._reconnect_attempts += 1
            if self._reconnect_attempts > self._opts.reconnect_max_retries:
                logger.warning(
                    "[acp-transport conn=%s] reconnect exhausted after %d attempts",
                    self._connection_id or "-",
                    self._reconnect_attempts - 1,
                )
                # 拿不到新连接了 —— 通知等待方抛错，避免 POST 永远挂住
                self._ready_error = TransportConnectError(
                    f"SSE reconnect exhausted after {self._reconnect_attempts - 1} attempts"
                )
                self._ready.set()
                return

            delay = self._backoff_delay(self._reconnect_attempts)
            logger.debug(
                "[acp-transport conn=%s] reconnecting in %dms (attempt %d)",
                self._connection_id or "-",
                delay,
                self._reconnect_attempts,
            )
            try:
                await asyncio.sleep(delay / 1000.0)
            except asyncio.CancelledError:
                return

    async def _run_sse_once(self) -> None:
        """单次 GET SSE 连接。正常结束（服务端关流）返回，异常则抛出让外层重连。"""
        headers = self._build_headers(with_connection_id=True, with_last_event_id=True)
        headers["Accept"] = "text/event-stream"

        timeout = httpx.Timeout(
            connect=self._opts.connection_timeout_ms / 1000.0,
            read=None,  # SSE 是长连接，不设读超时（心跳判死）
            write=self._opts.connection_timeout_ms / 1000.0,
            pool=self._opts.connection_timeout_ms / 1000.0,
        )

        async with self._http.stream(
            "GET",
            self._opts.endpoint,
            headers=headers,
            timeout=timeout,
        ) as response:
            if response.status_code != 200:
                body = await response.aread()
                raise TransportConnectError(
                    f"GET {self._opts.endpoint} returned {response.status_code}: "
                    f"{body[:200].decode('utf-8', errors='replace')}"
                )

            new_conn_id = response.headers.get("Acp-Connection-Id")
            if not new_conn_id:
                raise TransportConnectError(
                    "Server did not return Acp-Connection-Id header"
                )

            self._connection_version += 1
            self._connection_id = new_conn_id
            self._reconnect_attempts = 0
            self._last_activity = asyncio.get_running_loop().time()
            # 连接成功 → 清掉上次的 ready_error（如果有）
            self._ready_error = None
            self._ready.set()
            logger.debug("[acp-transport conn=%s] connected", new_conn_id)

            # 启心跳检查
            self._start_heartbeat()

            try:
                await self._consume_sse(response)
            finally:
                self._stop_heartbeat()
                # 连接断开 —— 但 connection_id 保留，下次重连会带 Last-Event-ID
                logger.debug(
                    "[acp-transport conn=%s] SSE stream ended",
                    self._connection_id or "-",
                )

    async def _consume_sse(self, response: httpx.Response) -> None:
        """消费 SSE 流，解析事件投递到 reader。"""
        event_type: str | None = None
        event_data_lines: list[str] = []
        event_id: str | None = None

        async for raw_line in response.aiter_lines():
            self._last_activity = asyncio.get_running_loop().time()

            if raw_line == "":
                # 空行 = 事件结束
                if event_data_lines:
                    data = "\n".join(event_data_lines)
                    if event_id is not None:
                        self._last_event_id = event_id
                    # 只处理 "message" 事件（或无 type 的默认事件）
                    if event_type is None or event_type == "message":
                        self._dispatch_sse_data(data)
                event_type = None
                event_data_lines = []
                event_id = None
                continue

            if raw_line.startswith(":"):
                # 注释行（心跳）—— 已更新 last_activity
                continue

            if ":" not in raw_line:
                continue
            field_name, _, value = raw_line.partition(":")
            if value.startswith(" "):
                value = value[1:]

            if field_name == "event":
                event_type = value
            elif field_name == "data":
                event_data_lines.append(value)
            elif field_name == "id":
                event_id = value

    def _dispatch_sse_data(self, data: str) -> None:
        """把 SSE 的 data 作为 JSON-RPC 消息塞进 reader。"""
        try:
            msg = json.loads(data)
        except ValueError:
            logger.warning(
                "[acp-transport conn=%s] drop non-JSON SSE event: %r",
                self._connection_id or "-",
                data[:200],
            )
            return
        if not isinstance(msg, dict) or "jsonrpc" not in msg:
            logger.debug(
                "[acp-transport conn=%s] drop non-JSON-RPC message: %r",
                self._connection_id or "-",
                msg,
            )
            return
        # 喂到 reader（官方 Connection 通过 readline 消费 ``{JSON}\n`` 行）
        payload = (json.dumps(msg, separators=(",", ":")) + "\n").encode("utf-8")
        self._reader.feed_data(payload)

    # ─── POST 发送 ────────────────────────────────

    async def _send_message(self, msg: dict[str, object]) -> None:
        """POST 一条 JSON-RPC 消息。响应如果是 JSON，直接 enqueue；如果是 SSE，后台消费。"""
        if self._closed:
            raise TransportClosedError("Transport is closed")

        # 等待连接就绪（防止 initialize 请求在 GET SSE 建连完成前发出）
        if not self._ready.is_set():
            await self._ready.wait()
        if self._ready_error is not None:
            raise self._ready_error

        headers = self._build_headers(with_connection_id=True)
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json, text/event-stream"

        timeout = httpx.Timeout(
            connect=self._opts.post_timeout_ms / 1000.0,
            read=None,  # 响应是 SSE 时不能设读超时
            write=self._opts.post_timeout_ms / 1000.0,
            pool=self._opts.post_timeout_ms / 1000.0,
        )

        # 用 stream() 拿到可流式读取的响应（兼容 SSE 回传）
        content = json.dumps(msg, separators=(",", ":")).encode("utf-8")
        req = self._http.build_request(
            "POST",
            self._opts.endpoint,
            headers=headers,
            content=content,
            timeout=timeout,
        )
        response = await self._http.send(req, stream=True)

        try:
            if response.status_code >= 400:
                body = await response.aread()
                raise httpx.HTTPStatusError(
                    f"POST {self._opts.endpoint} returned {response.status_code}: "
                    f"{body[:200].decode('utf-8', errors='replace')}",
                    request=response.request,
                    response=response,
                )

            content_type = response.headers.get("Content-Type", "")
            if "text/event-stream" in content_type:
                # POST 返回 SSE 流（RPC 响应通过 SSE 推回）—— 后台消费不阻塞
                consume_task = asyncio.create_task(
                    self._consume_sse_and_close(response),
                    name="acp-transport-post-sse",
                )
                self._background_tasks.add(consume_task)
                consume_task.add_done_callback(self._background_tasks.discard)
                # 不 close response，交给后台 task
                return
            if "application/json" in content_type:
                body_bytes = await response.aread()
                try:
                    data = json.loads(body_bytes)
                except ValueError:
                    return
                if isinstance(data, dict) and "jsonrpc" in data:
                    payload = (
                        json.dumps(data, separators=(",", ":")) + "\n"
                    ).encode("utf-8")
                    self._reader.feed_data(payload)
        finally:
            # 非 SSE 响应需要关闭；SSE 响应由后台 task 负责关闭
            if "text/event-stream" not in response.headers.get("Content-Type", ""):
                await response.aclose()

    async def _consume_sse_and_close(self, response: httpx.Response) -> None:
        """后台消费 POST 返回的 SSE 流，读完后关闭响应。"""
        try:
            await self._consume_sse(response)
        except Exception as e:
            logger.debug(
                "[acp-transport conn=%s] POST SSE stream error (ignored): %s",
                self._connection_id or "-",
                e,
            )
        finally:
            try:
                await response.aclose()
            except Exception:
                pass

    # ─── 心跳 ────────────────────────────────

    def _start_heartbeat(self) -> None:
        if self._opts.heartbeat_timeout_ms <= 0:
            return
        self._heartbeat_task = asyncio.create_task(
            self._heartbeat_loop(), name="acp-transport-heartbeat"
        )

    def _stop_heartbeat(self) -> None:
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

    async def _heartbeat_loop(self) -> None:
        """定期检查 last_activity，超时则取消 SSE 触发重连。"""
        timeout_s = self._opts.heartbeat_timeout_ms / 1000.0
        check_interval_s = min(10.0, timeout_s / 2)
        while not self._closed:
            try:
                await asyncio.sleep(check_interval_s)
            except asyncio.CancelledError:
                return
            loop = asyncio.get_running_loop()
            if loop.time() - self._last_activity > timeout_s:
                logger.warning(
                    "[acp-transport conn=%s] heartbeat timeout (no activity for %.1fs), triggering reconnect",
                    loop.time() - self._last_activity,
                )
                # 取消 SSE 任务，外层 _sse_loop 会自动重连
                if self._sse_task is not None:
                    self._sse_task.cancel()
                return

    # ─── 退避 ────────────────────────────────

    def _backoff_delay(self, attempt: int) -> int:
        """计算重连退避（ms）。指数 + ±25% jitter。"""
        base = min(
            self._opts.reconnect_initial_delay_ms * (2 ** (attempt - 1)),
            self._opts.reconnect_max_delay_ms,
        )
        if not self._opts.reconnect_jitter:
            return int(base)
        jitter = 0.25 * (random.random() * 2 - 1)
        return max(0, int(base * (1 + jitter)))
