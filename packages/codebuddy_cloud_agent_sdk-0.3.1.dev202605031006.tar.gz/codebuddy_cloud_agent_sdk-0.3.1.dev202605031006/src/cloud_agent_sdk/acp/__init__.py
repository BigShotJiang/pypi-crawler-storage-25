"""
ACP 数据面实现（Phase 3 实施）。

本子包将包含 SDK 自建的 Streamable HTTP transport（``transport.py``）+
JSON-RPC 协议封装（``protocol.py``）+ 订阅模型客户端（``client.py``）。

**不重导出 ACP 协议类型**——用户直接从官方 SDK 导入::

    from acp.schema import (
        TextContentBlock, ImageContentBlock, AudioContentBlock,
        ResourceContentBlock, EmbeddedResourceContentBlock,
        SessionNotification, PromptResponse, CancelNotification,
        # ...
    )

``Session.prompt()`` 支持字符串输入（SDK 内部自动包装成 ``TextContentBlock``），
所以大多数场景下用户不需要手动构造 block。
"""
