"""
AcpClient — ACP 数据面客户端

对齐 Node 版 ``v1/acp/client.ts`` 的订阅模型：

- **RPC 通道**：``prompt(session_id, blocks)`` / ``cancel(session_id)`` 等转发到
  官方 ``ClientSideConnection`` 的同名方法
- **Notification 通道**：``subscribe(session_id, listener)`` 注册订阅者，
  每条 session/update 按 ``session_id`` 多路分发给所有订阅者
- **per-session 串行化**：同一 session 的多次 ``prompt()`` 会排队（ACP 协议要求）
- **token 刷新钩子**：``set_token_refresher()`` 注入，重连时可以拿新 token
- **连接事件**：``on("open"|"error"|"close", handler)`` 供高级诊断

本模块只包装**CodeBuddy 业务语义**，JSON-RPC 层完全交给官方 ``ClientSideConnection``。
"""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict, deque
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any, Literal

from cloud_agent_sdk.acp.transport import (
    StreamableHttpTransport,
    TransportConnectError,
    TransportOptions,
)
from cloud_agent_sdk.errors import AcpProtocolError, APINetworkError

if TYPE_CHECKING:
    from acp.schema import PromptResponse, SessionNotification

    from cloud_agent_sdk.opts import RuntimeConnectOptions


__all__ = [
    "AcpClient",
    "AcpConnectionState",
    "NotificationListener",
    "ConnectionEvent",
]


logger = logging.getLogger("cloud_agent_sdk")


AcpConnectionState = Literal["INITIAL", "CONNECTING", "OPEN", "CLOSING", "CLOSED"]

NotificationListener = Callable[["SessionNotification"], None]
"""订阅者签名：收到上游 ``SessionNotification`` 时被同步调用。"""

ConnectionEvent = Literal["open", "error", "close"]
_ConnectionEventHandler = Callable[..., None]


# ─── 内部：实现 acp.Client Protocol 的最小客户端 ────────────────


class _NotificationRouter:
    """实现官方 ``acp.Client`` Protocol 的最小客户端。

    只关心 ``session_update`` 和 ``ext_notification``（扩展消息），其余全部
    **按 JSON-RPC 协议合规地拒绝**，由 ``AcpClient`` 持有并分发到用户订阅器。

    **方法签名说明**：官方 router 对 notification handler 做 Pydantic 校验后
    **按字段展开**传给 handler（``func(**fields)``），所以 ``session_update``
    的签名必须是 ``(session_id, update, **kwargs)`` —— 跟 ``SessionNotification``
    的字段名一一对应。

    **服务端 → 客户端 RPC 的处理策略**：

    沙箱里的 agent 可能向客户端发 ``session/request_permission`` /
    ``fs/read_text_file`` / 终端系列 RPC。Cloud Agent SDK 不暴露这些能力给 agent
    （我们是 "请求代理" 而非 "本地 IDE"），**必须按 ACP 协议返回 JSON-RPC
    error / 合法拒绝**，不能抛 Python 异常。否则：

    - 原先 ``NotImplementedError`` 会被 vendor 包成 ``-32603 internal error``，
      语义错（应该是 ``-32601 method not found`` 表示 "不支持此能力"）
    - ``request_permission`` 被拒会让 agent 陷入 "等待 permission 回执" 状态，
      需要返回合法的 "拒绝" outcome（``DeniedOutcome`` with ``outcome='cancelled'``）

    按协议规范，Client 没在 ``ClientCapabilities`` 里声明的能力，Agent 根本
    不应该调。如果 Agent 还是调了，这里回 method-not-found 是对方的 bug 信号。
    """

    def __init__(
        self,
        dispatch: Callable[[Any], None],
        get_connection_id: Callable[[], str | None] | None = None,
    ) -> None:
        self._dispatch = dispatch
        self._get_connection_id = get_connection_id

    def _conn_tag(self) -> str:
        """返回当前 connection_id（日志前缀用）；未连接时返回 ``-``。"""
        if self._get_connection_id is None:
            return "-"
        cid = self._get_connection_id()
        return cid if cid else "-"

    async def session_update(
        self, session_id: str, update: Any, **_kwargs: Any
    ) -> None:
        """每条 session/update notification 都走这里。

        注意：官方 router 已经把 payload 展开为字段，这里重新组装成一个
        ``SessionNotification`` 实例供用户订阅者消费（保留 Pydantic 类型安全）。
        """
        from acp.schema import SessionNotification

        notification = SessionNotification(session_id=session_id, update=update)
        self._dispatch(notification)

    async def ext_notification(self, method: str, params: Any) -> None:
        """扩展通知（如 _codebuddy.ai/* ）—— 当前忽略。"""
        logger.debug(
            "[acp conn=%s] ignore ext_notification: method=%s",
            self._conn_tag(),
            method,
        )

    # ─── 服务端 → 客户端 RPC（当前 CodeBuddy 场景 Cloud SDK 不代理这些能力）─────
    #
    # 对 `request_permission`：返回 ACP 规范的 DeniedOutcome（outcome='cancelled'），
    # 让 agent 以 "用户取消" 的语义结束对应的 tool call —— 比 method-not-found
    # 更友好，agent 不会因为客户端不支持 permission capability 就崩。
    #
    # 对其余 fs / 终端 RPC：抛 `RequestError.method_not_found`。vendor 会翻译成
    # JSON-RPC `-32601`，告诉 agent "客户端没声明这些 capability"（事实如此）。

    async def request_permission(self, **_kwargs: Any) -> Any:
        """服务端发 request_permission 时返回 "用户取消"（协议合法拒绝）。"""
        from acp.schema import DeniedOutcome, RequestPermissionResponse

        logger.debug(
            "[acp conn=%s] request_permission received but no permission handler configured "
            "— responding with cancelled outcome",
            self._conn_tag(),
        )
        return RequestPermissionResponse(outcome=DeniedOutcome(outcome="cancelled"))

    async def read_text_file(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("fs/read_text_file")

    async def write_text_file(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("fs/write_text_file")

    async def create_terminal(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("terminal/create")

    async def terminal_output(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("terminal/output")

    async def release_terminal(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("terminal/release")

    async def wait_for_terminal_exit(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("terminal/wait_for_exit")

    async def kill_terminal(self, **_kwargs: Any) -> Any:
        _raise_method_not_found("terminal/kill")

    async def ext_method(self, method: str, params: Any) -> Any:
        _raise_method_not_found(f"_ext/{method}")


def _raise_method_not_found(method: str) -> None:
    """抛 ACP 标准的 ``-32601 method not found``（由 vendor 翻成 JSON-RPC error）。"""
    from acp.exceptions import RequestError

    raise RequestError.method_not_found(method)


# ─── AcpClient ────────────────────────────────


class AcpClient:
    """ACP 数据面客户端（订阅模型）。"""

    def __init__(self) -> None:
        self._state: AcpConnectionState = "INITIAL"

        self._transport: StreamableHttpTransport | None = None
        self._conn: Any = None  # acp.client.ClientSideConnection
        self._initialize_result: Any = None

        self._token_refresher: Callable[[], Awaitable[str]] | None = None

        # session_id -> set[listener]
        self._subscribers: dict[str, set[NotificationListener]] = defaultdict(set)

        # per-session 串行化队列
        self._prompt_locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._active_prompts: set[str] = set()

        # 连接级事件监听器
        self._conn_listeners: dict[ConnectionEvent, set[_ConnectionEventHandler]] = {
            "open": set(),
            "error": set(),
            "close": set(),
        }

        # 已 session_load 的 session_id（避免重复 load）
        self._loaded_sessions: set[str] = set()

    # ─── 属性 ────────────────────────────────

    @property
    def state(self) -> AcpConnectionState:
        return self._state

    @property
    def connection_id(self) -> str | None:
        return self._transport.connection_id if self._transport else None

    @property
    def initialized(self) -> bool:
        return self._initialize_result is not None

    def set_token_refresher(self, fn: Callable[[], Awaitable[str]]) -> None:
        """注入 token 刷新函数。连接抖动 / token 过期时 SDK 会调用拿新 token。"""
        self._token_refresher = fn

    def _conn_tag(self) -> str:
        """返回当前 connection_id（日志前缀用）；未连接时返回 ``-``。"""
        cid = self.connection_id
        return cid if cid else "-"

    # ─── 连接管理 ────────────────────────────────

    async def connect(
        self,
        acp_url: str,
        token: str,
        opts: RuntimeConnectOptions | None = None,
        *,
        http_client: Any = None,
    ) -> None:
        """建立 ACP 连接。

        内部流程：建立 SSE → 初始化官方 ClientSideConnection → initialize RPC。
        后续 ``session_load`` / ``prompt`` / ``cancel`` 交给上层 ``Session``。

        幂等：已连接时直接返回。并发调用会被内部 ``asyncio.Lock`` 串行化。
        """
        if self._state in ("OPEN", "CONNECTING"):
            return
        self._state = "CONNECTING"

        # 从 RuntimeConnectOptions 读重连 / 心跳参数
        heartbeat_ms = opts.heartbeat_timeout_ms if opts is not None else 60_000
        reconnect_init_ms = opts.reconnect_backoff_ms if opts is not None else 1_000
        reconnect_max_ms = opts.reconnect_max_backoff_ms if opts is not None else 30_000
        reconnect_max = opts.reconnect_max_attempts if opts is not None else float("inf")

        logger.debug("[acp conn=-] connecting to %s", acp_url)

        transport = StreamableHttpTransport(
            TransportOptions(
                endpoint=acp_url,
                auth_token=token,
                headers=dict(opts.headers) if opts is not None and opts.headers else {},
                heartbeat_timeout_ms=heartbeat_ms,
                reconnect_initial_delay_ms=reconnect_init_ms,
                reconnect_max_delay_ms=reconnect_max_ms,
                reconnect_max_retries=reconnect_max,
                http_client=http_client,
            )
        )

        try:
            await transport.start()
        except TransportConnectError as e:
            self._state = "CLOSED"
            raise APINetworkError(f"ACP connect failed: {e}", cause=e) from e

        # 连上 SSE → 构造官方 ClientSideConnection
        # 运行时 import 避免 circular / 未装 agent-client-protocol 时 crash 太早
        from typing import cast

        from acp import Client
        from acp.client import ClientSideConnection

        router = _NotificationRouter(
            self._dispatch_notification,
            get_connection_id=lambda: transport.connection_id,
        )
        try:
            conn = ClientSideConnection(
                cast(Client, router), transport.writer, transport.reader
            )
        except Exception as e:
            self._state = "CLOSED"
            await transport.aclose()
            raise AcpProtocolError(f"Failed to build ACP connection: {e}", cause=e) from e

        self._transport = transport
        self._conn = conn
        self._emit("open")

        # initialize RPC（默认要做；由 RuntimeConnectOptions.initialize 决定）
        should_initialize = opts.initialize if opts is not None else True
        if should_initialize:
            try:
                self._initialize_result = await self._conn.initialize(protocol_version=1)
            except Exception as e:
                self._state = "CLOSED"
                await transport.aclose()
                raise AcpProtocolError(f"ACP initialize failed: {e}", cause=e) from e

        self._state = "OPEN"
        logger.debug("[acp conn=%s] connected", transport.connection_id or "-")

    async def disconnect(self) -> None:
        """优雅断开。清空订阅器和队列；幂等。"""
        if self._state in ("CLOSED", "CLOSING"):
            return
        self._state = "CLOSING"

        # 先记住 id —— transport 清空后就拿不到了，但日志希望带断开前的 id
        last_conn_id = self._conn_tag()

        if self._conn is not None:
            try:
                await self._conn.close()
            except Exception as e:
                logger.debug("[acp conn=%s] conn.close error (ignored): %s", last_conn_id, e)
            self._conn = None

        if self._transport is not None:
            try:
                await self._transport.aclose()
            except Exception as e:
                logger.debug(
                    "[acp conn=%s] transport.aclose error (ignored): %s", last_conn_id, e
                )
            self._transport = None

        self._subscribers.clear()
        self._prompt_locks.clear()
        self._active_prompts.clear()
        self._loaded_sessions.clear()
        self._initialize_result = None
        self._state = "CLOSED"
        logger.debug("[acp conn=%s] disconnected", last_conn_id)
        self._emit("close")

    # ─── 协议方法（转发官方 Connection）────────────────────────────────

    async def session_load(self, session_id: str, *, cwd: str = "/workspace") -> None:
        """加载一个已有 session（在控制面创建后要绑定到数据面）。幂等。"""
        if self._conn is None:
            raise AcpProtocolError("Not connected")
        if session_id in self._loaded_sessions:
            return
        await self._conn.load_session(cwd=cwd, session_id=session_id, mcp_servers=[])
        self._loaded_sessions.add(session_id)

    async def prompt(
        self,
        session_id: str,
        blocks: list[Any],
        *,
        cancel_event: asyncio.Event | None = None,
    ) -> PromptResponse:
        """发 prompt。

        - 本次 prompt 期间的 notifications 由 ``subscribe()`` 订阅器独立接收
        - 同 session_id 的多次 prompt 会排队（ACP 协议要求）
        - ``cancel_event.set()`` 或 ``task.cancel()`` 触发时向服务端发 ``session/cancel``
        """
        if self._conn is None:
            raise AcpProtocolError("Not connected")

        lock = self._prompt_locks[session_id]
        async with lock:
            self._active_prompts.add(session_id)
            try:
                # 构造主任务：调官方 prompt RPC
                rpc_task = asyncio.ensure_future(
                    self._conn.prompt(session_id=session_id, prompt=blocks)
                )
                # 如果有 cancel_event，监控它
                cancel_task: asyncio.Task[bool] | None = None
                if cancel_event is not None:
                    cancel_task = asyncio.ensure_future(cancel_event.wait())

                try:
                    if cancel_task is None:
                        response = await rpc_task
                    else:
                        done, _pending = await asyncio.wait(
                            {rpc_task, cancel_task},
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                        if cancel_task in done and rpc_task not in done:
                            # 用户触发 cancel → 发 session/cancel + 取消 rpc
                            await self._send_cancel_best_effort(session_id)
                            rpc_task.cancel()
                            try:
                                await rpc_task
                            except (asyncio.CancelledError, Exception):
                                pass
                            raise asyncio.CancelledError()
                        response = rpc_task.result()
                except asyncio.CancelledError:
                    # 调用方 task.cancel() 传播进来
                    if not rpc_task.done():
                        await self._send_cancel_best_effort(session_id)
                        rpc_task.cancel()
                        try:
                            await rpc_task
                        except (asyncio.CancelledError, Exception):
                            pass
                    raise
                finally:
                    if cancel_task is not None and not cancel_task.done():
                        cancel_task.cancel()
                        try:
                            await cancel_task
                        except (asyncio.CancelledError, Exception):
                            pass

                return response  # type: ignore[no-any-return]
            finally:
                self._active_prompts.discard(session_id)

    async def session_cancel(self, session_id: str) -> None:
        """发 session/cancel 通知（幂等，尽力而为）。"""
        if self._conn is None:
            return
        await self._send_cancel_best_effort(session_id)

    async def _send_cancel_best_effort(self, session_id: str) -> None:
        if self._conn is None:
            return
        try:
            await self._conn.cancel(session_id=session_id)
        except Exception as e:
            logger.debug(
                "[acp conn=%s session=%s] cancel RPC failed (ignored): %s",
                self._conn_tag(),
                session_id,
                e,
            )

    # ─── Notification 订阅 ────────────────────────────────

    def subscribe(
        self, session_id: str, listener: NotificationListener
    ) -> Callable[[], None]:
        """订阅指定 session 的 notifications。返回 unsubscribe 函数。

        一个 session 可以有多个 listener，按注册顺序同步调用（异常静默吞）。
        """
        self._subscribers[session_id].add(listener)

        def unsubscribe() -> None:
            self._subscribers.get(session_id, set()).discard(listener)

        return unsubscribe

    def _dispatch_notification(self, notification: Any) -> None:
        """把上游 notification 按 session_id 分发给订阅者。不做任何转换。"""
        # notification 是 Pydantic SessionNotification，有 session_id 属性
        sid = getattr(notification, "session_id", None)
        if sid is None:
            return
        subs = self._subscribers.get(sid)
        if not subs:
            return
        for listener in list(subs):
            try:
                listener(notification)
            except Exception:
                # 订阅者抛错不影响其他订阅者
                pass

    # ─── 连接级事件 ────────────────────────────────

    def on(self, event: ConnectionEvent, handler: _ConnectionEventHandler) -> None:
        self._conn_listeners[event].add(handler)

    def off(self, event: ConnectionEvent, handler: _ConnectionEventHandler) -> None:
        self._conn_listeners[event].discard(handler)

    def _emit(self, event: ConnectionEvent, *args: Any) -> None:
        for handler in list(self._conn_listeners[event]):
            try:
                handler(*args)
            except Exception:
                pass


# ─── 语义说明 ────────────────────────────────
# _loaded_sessions 去重 + 串行化队列见 Node 版 client.ts 第 107-109 行。
# per-session asyncio.Lock 是 Python 版简化（Node 用 Set + Map[deque]）；
# 语义等价：同一 session_id 的 prompt 必须串行。
_ = deque  # 保留给未来需要显式队列时使用
