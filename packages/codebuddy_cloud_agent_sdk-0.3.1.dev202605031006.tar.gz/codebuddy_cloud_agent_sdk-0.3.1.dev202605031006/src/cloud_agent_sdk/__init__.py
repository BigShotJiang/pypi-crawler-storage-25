"""
tencent-ai-cloud-agent-sdk — Python 版入口

最简用法（4 行到 prompt）::

    import asyncio
    from cloud_agent_sdk import CloudAgentClient

    async def main():
        client = CloudAgentClient(api_key="ck_xxx")
        rt = await client.runtimes.create(runtime_name="demo")
        session = rt.sessions.default()
        response = await session.prompt("hello")
        print(response.stop_reason)

    asyncio.run(main())

流式消费（订阅模型）::

    session = rt.sessions.default()
    await session.connect()
    unsub = session.subscribe(lambda n: ...)
    response = await session.prompt("hello")
    unsub()

与 Node 版 ``@tencent-ai/cloud-agent-sdk@0.3.x`` 的对应关系见 IMPLEMENTATION.md。
"""

from __future__ import annotations

import logging as _logging

from cloud_agent_sdk._version import __version__
from cloud_agent_sdk.client import CloudAgentClient
from cloud_agent_sdk.errors import (
    AcpProtocolError,
    APIAuthError,
    APIError,
    APINetworkError,
    APINotFoundError,
    APITimeoutError,
    APIValidationError,
)
from cloud_agent_sdk.manifest import ManifestBuilder
from cloud_agent_sdk.opts import (
    ConnectionOptions,
    Logger,
    PromptOptions,
    RequestOptions,
    RetryContext,
    RetryOn,
    RetryOptions,
    RuntimeConnectOptions,
    RuntimeCreateOptions,
    RuntimeListOptions,
    SessionCreateOptions,
    SessionListOptions,
)
from cloud_agent_sdk.rest.client import default_retry_on
from cloud_agent_sdk.runtime import Runtime
from cloud_agent_sdk.session import Session
from cloud_agent_sdk.types import (
    AcpLink,
    AgentManifest,
    CreateRuntimeRequest,
    CreateSessionRequest,
    DeleteResult,
    ManifestEnv,
    ManifestMcp,
    ManifestPlugin,
    ManifestRule,
    ManifestSecret,
    ManifestSkill,
    ManifestSlashCommand,
    ManifestSubagent,
    ManifestWorkspace,
    OpenApiHealth,
    PageResult,
    Pagination,
    RuntimeInfo,
    RuntimeLinks,
    RuntimeStatus,
    SandboxLink,
    SandboxSpec,
    SessionBrief,
    SessionInfo,
    SessionStatus,
    UpdateRuntimeRequest,
    UpdateSessionRequest,
)

__all__ = [
    "__version__",
    # 核心对象
    "CloudAgentClient",
    "Runtime",
    "Session",
    # 构造器 / 工具
    "ManifestBuilder",
    "default_retry_on",
    # 错误
    "APIError",
    "APINetworkError",
    "APITimeoutError",
    "APIAuthError",
    "APINotFoundError",
    "APIValidationError",
    "AcpProtocolError",
    # 配置
    "ConnectionOptions",
    "RequestOptions",
    "RuntimeCreateOptions",
    "RuntimeConnectOptions",
    "SessionCreateOptions",
    "PromptOptions",
    "RetryOptions",
    "RetryContext",
    "RetryOn",
    "RuntimeListOptions",
    "SessionListOptions",
    "Logger",
    # 类型：Manifest
    "AgentManifest",
    "ManifestRule",
    "ManifestSkill",
    "ManifestSubagent",
    "ManifestSlashCommand",
    "ManifestPlugin",
    "ManifestMcp",
    "ManifestWorkspace",
    "ManifestEnv",
    "ManifestSecret",
    # 类型：Runtime / Session
    "RuntimeStatus",
    "RuntimeInfo",
    "RuntimeLinks",
    "AcpLink",
    "SandboxLink",
    "SandboxSpec",
    "SessionStatus",
    "SessionInfo",
    "SessionBrief",
    # 类型：请求体
    "CreateRuntimeRequest",
    "UpdateRuntimeRequest",
    "CreateSessionRequest",
    "UpdateSessionRequest",
    # 类型：通用
    "Pagination",
    "PageResult",
    "DeleteResult",
    "OpenApiHealth",
]


# ─── 社区标准做法：给 SDK 自己的 logger 挂 NullHandler ────────────────
#
# 防止用户没配任何 handler 时出现 "No handlers could be found for logger
# cloud_agent_sdk" 警告。用户想看日志时按标准姿势开启即可::
#
#     import logging
#     logging.getLogger("cloud_agent_sdk").setLevel(logging.DEBUG)
#     logging.basicConfig()   # 或加自己的 handler
#
# 对齐 urllib3 / httpx / openai / requests 等主流库的 __init__ 做法。
_logging.getLogger("cloud_agent_sdk").addHandler(_logging.NullHandler())
