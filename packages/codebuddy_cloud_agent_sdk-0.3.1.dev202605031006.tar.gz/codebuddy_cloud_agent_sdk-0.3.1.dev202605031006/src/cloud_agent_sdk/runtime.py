"""
Runtime — 一个云端沙箱实例（对齐 Node v1/runtime.ts）

由 ``CloudAgentClient.runtimes.create()`` 或 ``.get()`` 返回。
返回时已持有控制面 info（status、metadata）和数据面连接信息（acpLink、sandboxId）。

Runtime 实例方法覆盖自身的控制面操作（update/delete/refresh_token）。
通过 ``sessions`` 子命名空间管理 Session 的控制面 CRUD。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cloud_agent_sdk.session import Session
from cloud_agent_sdk.types import (
    CreateSessionRequest,
    DeleteResult,
    PageResult,
    RuntimeInfo,
    SessionInfo,
    UpdateRuntimeRequest,
)

if TYPE_CHECKING:
    from cloud_agent_sdk.opts import (
        ConnectionOptions,
        RequestOptions,
        SessionCreateOptions,
        SessionListOptions,
    )
    from cloud_agent_sdk.rest.client import RestClient

__all__ = ["Runtime", "Sessions"]


class Sessions:
    """``Runtime.sessions`` 命名空间。"""

    def __init__(self, runtime: Runtime, rest_client: RestClient) -> None:
        self._runtime = runtime
        self._rest = rest_client

    async def create(self, opts: SessionCreateOptions) -> Session:
        """创建新 Session（控制面），返回 ``Session`` 实例。

        注意：session 层**不自动注入** ``CODEBUDDY_API_KEY``。服务端
        ``mergeKeyedArray`` 会按 key 合并 session manifest 与 runtime manifest，
        runtime 层已注入的 secret 会自动继承。用户如果在 session 自定义 manifest
        里传了 secrets，那是他自己负责（想覆盖 runtime 的就显式传同名 key）。
        """
        body = CreateSessionRequest(
            session_id=opts.session_id,
            session_name=opts.session_name,
            agent_manifest=opts.agent_manifest,
        ).model_dump(by_alias=True, exclude_none=True)
        raw = await self._rest.post(
            f"/runtimes/{self._runtime.id}/sessions",
            body,
            opts,
        )
        info = SessionInfo.model_validate(raw)
        return Session(info.session_id, self._runtime, self._rest)

    async def get(self, session_id: str, opts: RequestOptions | None = None) -> Session:
        """获取 Session（返回 ``Session`` 实例）。"""
        # 验证 session 存在（发请求），然后返回实例
        raw = await self._rest.get(
            f"/runtimes/{self._runtime.id}/sessions/{session_id}",
            None,
            opts,
        )
        info = SessionInfo.model_validate(raw)
        return Session(info.session_id, self._runtime, self._rest)

    async def list(self, opts: SessionListOptions | None = None) -> PageResult[SessionInfo]:
        """分页列出 runtime 下的所有 session。"""
        params: dict[str, str] = {}
        if opts is not None:
            if opts.page is not None:
                params["page"] = str(opts.page)
            if opts.page_size is not None:
                params["pageSize"] = str(opts.page_size)
            if opts.session_status:
                params["sessionStatus"] = opts.session_status
        raw = await self._rest.get(
            f"/runtimes/{self._runtime.id}/sessions",
            params,
            opts,
        )
        return PageResult[SessionInfo].model_validate(raw)

    def default(self) -> Session:
        """默认 session（Runtime 创建时自动生成的）。

        使用 ``RuntimeInfo.sessions[0].session_id``，不存在时 fallback 到 ``runtime.id``。
        """
        default_id = self._runtime._default_session_id
        return Session(default_id or self._runtime.id, self._runtime, self._rest)


class Runtime:
    """云端沙箱实例。"""

    id: str

    def __init__(
        self,
        rest_client: RestClient,
        connection_opts: ConnectionOptions,
        info: RuntimeInfo,
    ) -> None:
        self.id = info.id
        self._info = info
        self._rest = rest_client
        # 数据面 ACP 连接信息
        sandbox = info.links.sandbox_link if info.links is not None else None
        acp = info.links.acp_link if info.links is not None else None
        self.sandbox_id: str | None = sandbox.sandbox_id if sandbox is not None else None
        self.sandbox_domain: str | None = sandbox.endpoint if sandbox is not None else None
        self._acp_url: str | None = acp.url if acp is not None else None
        self._acp_token: str | None = acp.token if acp is not None else None
        # 默认 session
        self._default_session_id: str | None = (
            info.sessions[0].session_id if info.sessions else None
        )
        # Phase 3 会用到：持有 ConnectionOptions（给 AcpClient 构造时读 logger / http_client）
        self._connection_opts = connection_opts
        self.sessions = Sessions(self, rest_client)

    # ─── 公共属性 ────────────────────────────────

    @property
    def runtime_info(self) -> RuntimeInfo:
        return self._info

    @property
    def acp_url(self) -> str | None:
        return self._acp_url

    @property
    def acp_token(self) -> str | None:
        return self._acp_token

    # ============================================================
    # Runtime 自身操作（控制面）
    # ============================================================

    async def update(
        self,
        req: UpdateRuntimeRequest,
        opts: RequestOptions | None = None,
    ) -> RuntimeInfo:
        """更新 Runtime 元数据。"""
        body = req.model_dump(by_alias=True, exclude_none=True)
        raw = await self._rest.post(f"/runtimes/{self.id}/update", body, opts)
        info = RuntimeInfo.model_validate(raw)
        self._info = info
        return info

    async def delete(self, opts: RequestOptions | None = None) -> DeleteResult:
        """软删除。"""
        raw = await self._rest.post(f"/runtimes/{self.id}/delete", None, opts)
        return DeleteResult.model_validate(raw)

    async def refresh_token(self, opts: RequestOptions | None = None) -> str:
        """刷新 token —— 拉最新 ``RuntimeInfo``，更新 ``acp_link``。

        返回新的 ACP token（若无则返回空字符串）。
        """
        raw = await self._rest.get(f"/runtimes/{self.id}", None, opts)
        info = RuntimeInfo.model_validate(raw)
        self._info = info
        if info.links is not None and info.links.acp_link is not None:
            self._acp_url = info.links.acp_link.url
            self._acp_token = info.links.acp_link.token
        return self._acp_token or ""
