"""
错误类型体系

对齐 Anthropic / OpenAI Python SDK 的做法 —— 只暴露**服务端 request_id**
这一个定位 ID。SDK 内部日志通过 logger name (``cloud_agent_sdk``) 和
业务上下文（session_id / connection_id / runtime_id）做定位，用户侧想把
SDK 日志和业务日志串起来的标准姿势是 ``contextvars.ContextVar`` +
``logging.Filter``（见 ``docs`` 里的指南）。

重试决策**不**挂在错误类上。是否重试由 ``RetryOptions.retry_on(err, ctx)`` 统一
决定（见 ``rest/client.py`` 里的 ``default_retry_on``）。这样决策只有一个入口，
用户可以通过 ``retry=RetryOptions(retry_on=...)`` 完全覆盖。

**命名约定**：对齐 OpenAI / Anthropic Python SDK，异常类名带 ``API`` 前缀，避免
遮蔽 Python 内建 ``TimeoutError`` / ``ConnectionError``（Node 版没这个问题）。
"""

from __future__ import annotations

__all__ = [
    "APIError",             # 基类
    "APIAuthError",
    "APINetworkError",
    "APINotFoundError",
    "APITimeoutError",
    "APIValidationError",
    "AcpProtocolError",     # ACP 协议层错误（SDK 自己的领域名词，不加 API 前缀）
]


class APIError(Exception):
    """SDK 错误基类。

    Attributes:
        code: 业务 code（服务端 ``body.code``，未知时为 ``-1``）。
        http_status: HTTP 状态码（业务错时可能不存在）。
        request_id: 服务端 ``x-request-id`` 响应头或 ``body.request_id``。
            贴给服务端团队排障用。网络错 / 超时时可能为 ``None``（请求还没
            到服务端），此时排查靠客户端日志（logger ``cloud_agent_sdk``）。

    原始异常通过标准 ``__cause__`` 访问（``raise APIError(...) from original``
    的标准语义，也可以从构造时 ``cause=`` 参数传入）。
    """

    def __init__(
        self,
        message: str,
        *,
        code: int = -1,
        http_status: int | None = None,
        request_id: str | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.http_status = http_status
        self.request_id = request_id
        if cause is not None:
            self.__cause__ = cause

    def __repr__(self) -> str:  # pragma: no cover
        parts = [f"code={self.code}"]
        if self.http_status is not None:
            parts.append(f"http_status={self.http_status}")
        if self.request_id:
            parts.append(f"request_id={self.request_id!r}")
        return f"{type(self).__name__}({str(self)!r}, {', '.join(parts)})"


class APINetworkError(APIError):
    """网络错误：连接失败、5xx、429，以及 httpx 层原生异常。默认重试。"""


class APITimeoutError(APIError):
    """超时错误：``asyncio.wait_for`` / httpx 超时、HTTP 408/504。

    **仅 GET 方法默认重试**（非幂等方法超时可能已经在服务端成功执行，重试会造成重复
    副作用，如重复创建 Runtime）。
    """


class APIAuthError(APIError):
    """认证/授权错误：HTTP 401/403，或业务 code 10034/10085。不重试。"""


class APINotFoundError(APIError):
    """资源不存在：HTTP 404，或业务 code 10084。不重试。"""


class APIValidationError(APIError):
    """参数/输入校验失败：HTTP 400，或业务 code 10001，或 SDK 本地校验（Manifest 必填等）。不重试。"""


class AcpProtocolError(APIError):
    """ACP 协议层错误：握手失败、RPC method not found、连接未建立时调用 RPC 等。不重试。"""
