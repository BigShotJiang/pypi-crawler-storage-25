"""
Session — 对话上下文

控制面（REST）：``info`` / ``update`` / ``delete``
数据面（ACP）：``connect`` / ``disconnect`` / ``prompt`` / ``subscribe`` / ``cancel``

订阅模型（对齐 ACP 协议原生形态）：

- ``prompt(input)`` 返回 ``PromptResponse`` —— 一轮的终局
- ``subscribe(listener)`` —— 流式 notifications 由 listener 异步接收
- 两条通道独立、不聚合、无队列

典型用法::

    await session.connect()

    # 场景 A：只要最终结果
    response = await session.prompt("hello")
    print(response.stop_reason)

    # 场景 B：流式打印 + 最终结果
    unsub = session.subscribe(lambda n: print(n))
    response = await session.prompt("hello")
    unsub()

    # 场景 C：便利钩子（等价于 B 但不需手动 unsub）
    response = await session.prompt("hello", PromptOptions(on_chunk=lambda n: print(n)))
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from cloud_agent_sdk.acp.client import AcpClient
from cloud_agent_sdk.errors import APIValidationError
from cloud_agent_sdk.types import DeleteResult, SessionInfo, SessionStatus, UpdateSessionRequest

if TYPE_CHECKING:
    from collections.abc import Callable

    from acp.schema import (
        AudioContentBlock,
        EmbeddedResourceContentBlock,
        ImageContentBlock,
        PromptResponse,
        ResourceContentBlock,
        SessionNotification,
        TextContentBlock,
    )

    from cloud_agent_sdk.opts import PromptOptions, RequestOptions, RuntimeConnectOptions
    from cloud_agent_sdk.rest.client import RestClient
    from cloud_agent_sdk.runtime import Runtime

    # 官方 ACP SDK 的 ContentBlock union —— 在 PromptRequest.prompt 字段就是这个。
    # SDK 内部需要时本地定义一个别名；不重导出到公共 API（避免二次封装）。
    _ContentBlock = (
        TextContentBlock
        | ImageContentBlock
        | AudioContentBlock
        | ResourceContentBlock
        | EmbeddedResourceContentBlock
    )

__all__ = ["Session"]


logger = logging.getLogger("cloud_agent_sdk")


class Session:
    """对话上下文。由 ``Runtime.sessions.create/get/default`` 构造。"""

    id: str
    runtime_id: str

    def __init__(self, session_id: str, runtime: Runtime, rest_client: RestClient) -> None:
        self.id = session_id
        self.runtime_id = runtime.id
        self._runtime = runtime
        self._rest = rest_client
        self._status: SessionStatus | None = None

        # 数据面 ACP 客户端（connect 后可用）
        self._acp: AcpClient | None = None
        # connect 幂等锁
        self._connect_lock = asyncio.Lock()

    # ============================================================
    # 状态
    # ============================================================

    @property
    def status(self) -> SessionStatus | None:
        """最近一次 ``info()`` / ``update()`` 返回的 session 状态。"""
        return self._status

    @property
    def connected(self) -> bool:
        """ACP 连接是否已建立。"""
        return self._acp is not None and self._acp.state == "OPEN"

    # ============================================================
    # 控制面（REST）
    # ============================================================

    async def info(self, opts: RequestOptions | None = None) -> SessionInfo:
        """拉最新 session 元数据。"""
        raw = await self._rest.get(
            f"/runtimes/{self.runtime_id}/sessions/{self.id}",
            None,
            opts,
        )
        parsed = SessionInfo.model_validate(raw)
        self._status = parsed.session_status
        return parsed

    async def update(
        self,
        req: UpdateSessionRequest,
        opts: RequestOptions | None = None,
    ) -> SessionInfo:
        """更新 session name / manifest。"""
        body = req.model_dump(by_alias=True, exclude_none=True)
        raw = await self._rest.post(
            f"/runtimes/{self.runtime_id}/sessions/{self.id}/update",
            body,
            opts,
        )
        parsed = SessionInfo.model_validate(raw)
        self._status = parsed.session_status
        return parsed

    async def delete(self, opts: RequestOptions | None = None) -> DeleteResult:
        """软删除 session。先断开 ACP 再发 REST。"""
        await self.disconnect()
        raw = await self._rest.post(
            f"/runtimes/{self.runtime_id}/sessions/{self.id}/delete",
            None,
            opts,
        )
        return DeleteResult.model_validate(raw)

    # ============================================================
    # 数据面（ACP）
    # ============================================================

    async def connect(self, opts: RuntimeConnectOptions | None = None) -> None:
        """建立到沙箱的 ACP 连接。

        流程：建立 SSE → initialize RPC → session/load。
        幂等：已连接时直接返回；并发调用被内部 Lock 串行化。
        """
        async with self._connect_lock:
            if self.connected:
                return

            acp_url = self._runtime.acp_url
            acp_token = self._runtime.acp_token

            # token 缺失或需要刷新 → 调用 Runtime 刷新
            if not acp_url or not acp_token:
                acp_token = await self._runtime.refresh_token()
                acp_url = self._runtime.acp_url
                if not acp_url or not acp_token:
                    raise APIValidationError(
                        "Runtime does not have ACP link. Is it in RUNNING state?"
                    )

            acp = AcpClient()
            # 注入 token 刷新钩子（重连时可以拿新 token）
            acp.set_token_refresher(self._runtime.refresh_token)

            await acp.connect(
                acp_url,
                acp_token,
                opts,
                http_client=self._runtime._connection_opts.http_client,
            )

            # session/load：把控制面创建的 session 绑定到数据面
            await acp.session_load(self.id)

            self._acp = acp

    async def disconnect(self) -> None:
        """断开 ACP 连接。所有订阅器被自动清除。幂等。"""
        if self._acp is None:
            return
        acp = self._acp
        self._acp = None
        await acp.disconnect()

    async def prompt(
        self,
        input: str | list[_ContentBlock],
        opts: PromptOptions | None = None,
    ) -> PromptResponse:
        """发送 prompt 并等待 ``PromptResponse``。

        - 未 connect 时自动 connect
        - 纯文本字符串自动包装成 ``TextContentBlock``
        - 同 session 并发 prompt 会被内部串行化（ACP 协议要求）
        - ``opts.on_chunk`` / ``opts.on_turn_start`` / ``opts.on_turn_end`` 便利钩子
        - ``opts.cancel.set()`` 或 ``task.cancel()`` 中止 prompt（发 ``session/cancel``）
        """
        if not self.connected:
            await self.connect()
        assert self._acp is not None

        # 字符串 → TextContentBlock
        blocks = _coerce_prompt_input(input)

        # on_chunk 便利钩子：临时订阅，prompt 结束自动 unsub
        unsub_chunk: Callable[[], None] | None = None
        if opts is not None and opts.on_chunk is not None:
            on_chunk = opts.on_chunk
            unsub_chunk = self._acp.subscribe(self.id, _make_sync_listener(on_chunk))

        # 合并用户 cancel 事件与 timeout_ms
        cancel_event = opts.cancel if opts is not None else None
        timeout_task: asyncio.Task[None] | None = None
        timeout_event: asyncio.Event | None = None
        if opts is not None and opts.timeout_ms is not None and opts.timeout_ms > 0:
            timeout_event = asyncio.Event()
            timeout_task = asyncio.create_task(
                _fire_after_timeout(opts.timeout_ms / 1000.0, timeout_event),
                name="cloud-agent-sdk-prompt-timeout",
            )
            if cancel_event is not None:
                # 两个 event 合并：任一触发即取消
                cancel_event = _merge_events(cancel_event, timeout_event)
            else:
                cancel_event = timeout_event

        # on_turn_start
        if opts is not None and opts.on_turn_start is not None:
            await _maybe_await(opts.on_turn_start())

        try:
            response = await self._acp.prompt(
                self.id, blocks, cancel_event=cancel_event
            )
        finally:
            if unsub_chunk is not None:
                unsub_chunk()
            if timeout_task is not None:
                timeout_task.cancel()
                try:
                    await timeout_task
                except (asyncio.CancelledError, Exception):
                    pass

        # on_turn_end
        if opts is not None and opts.on_turn_end is not None:
            await _maybe_await(opts.on_turn_end(response))

        return response

    def subscribe(
        self,
        listener: Callable[[SessionNotification], None],
    ) -> Callable[[], None]:
        """订阅该 session 所有上游 notifications。

        Listener 收到的是上游 ``SessionNotification`` 原样。独立于 prompt 生命周期
        —— 一个 session 支持任意多个订阅者。

        Returns:
            unsubscribe 函数。
        """
        if self._acp is None or not self.connected:
            raise APIValidationError("Session not connected. Call connect() first.")
        return self._acp.subscribe(self.id, listener)

    async def cancel(self) -> None:
        """取消当前运行的 prompt。

        向服务端发 ``session/cancel`` notification，服务端会以
        ``stop_reason='cancelled'`` 结束当前 prompt。

        **尽力而为**：服务端 RPC 失败时打 warn 吞掉，不抛给调用方。
        """
        if self._acp is None:
            return
        try:
            await self._acp.session_cancel(self.id)
        except Exception as e:
            logger.warning("[session %s] cancel failed: %s", self.id, e)


# ─── 工具函数 ────────────────────────────────


def _coerce_prompt_input(value: str | list[_ContentBlock]) -> list[_ContentBlock]:
    """字符串自动包装成 ``TextContentBlock``；list 原样返回。"""
    if isinstance(value, str):
        from acp.schema import TextContentBlock

        return [TextContentBlock(type="text", text=value)]
    return value


def _make_sync_listener(
    user_fn: Callable[[SessionNotification], object],
) -> Callable[[SessionNotification], None]:
    """用户钩子可能是 sync 或 async；统一成 sync listener（async 丢给事件循环）。"""
    # 保存 async listener 产生的后台 task，避免被 GC 提前回收
    bg_tasks: set[asyncio.Task[object]] = set()

    def listener(n: SessionNotification) -> None:
        try:
            ret = user_fn(n)
        except Exception:
            return
        if asyncio.iscoroutine(ret):
            task = asyncio.ensure_future(ret)
            bg_tasks.add(task)
            task.add_done_callback(bg_tasks.discard)

    return listener


async def _maybe_await(value: object) -> None:
    """如果是 coroutine 就 await，否则直接返回。"""
    if asyncio.iscoroutine(value):
        await value


async def _fire_after_timeout(seconds: float, event: asyncio.Event) -> None:
    try:
        await asyncio.sleep(seconds)
        event.set()
    except asyncio.CancelledError:
        pass


def _merge_events(a: asyncio.Event, b: asyncio.Event) -> asyncio.Event:
    """两个 event 合并：任一触发则返回的 event 也触发。"""
    merged = asyncio.Event()
    bg_tasks: set[asyncio.Task[None]] = set()

    async def watch(src: asyncio.Event) -> None:
        await src.wait()
        merged.set()

    for src in (a, b):
        t = asyncio.ensure_future(watch(src))
        bg_tasks.add(t)
        t.add_done_callback(bg_tasks.discard)
    return merged
