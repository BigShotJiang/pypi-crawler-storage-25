# 更新日志

codebuddy-cloud-agent-sdk 的所有重要更新都会记录在这里。

遵循 [语义化版本](https://semver.org/spec/v2.0.0.html)。

## [未发布]

## [0.3.1] - 2026-05-03

### 🎉 新功能

- **`RuntimeConnectOptions.headers` 透传到 ACP 连接**：自定义 header（如 `traceparent`、业务灰度 tag）现会随 ACP SSE GET 一起发出，支持分布式追踪跨数据面传播

### 🐛 问题修复

- **ACP 重连时不会丢失连接 ID**：重连中间态不会让正在等待 `_ready` 的 POST 请求使用旧 connection ID

### 兼容性

- Python 3.10+（3.10 / 3.11 / 3.12 / 3.13 / 3.14）
- 依赖：`httpx>=0.27` / `pydantic>=2.6` / `agent-client-protocol>=0.9,<1.0`
