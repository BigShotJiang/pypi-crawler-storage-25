"""Bridge setup between DuckDB connections with permission-based access control."""

import threading
from typing import Optional

import duckdb

from n6k_duckdb.extension import load_extension


def bridge(
    source: duckdb.DuckDBPyConnection,
    target: duckdb.DuckDBPyConnection,
    name: str,
    *,
    permissions: dict[str, str],
    lock: Optional[threading.Lock] = None,
) -> None:
    """Set up a bridge from *source* to *target* with per-table permissions.

    Args:
        source: DuckDB connection with privileged access to the data.
        target: DuckDB connection that will be given restricted access.
        name: Catalog name visible on the target connection.
        permissions: Dict mapping table names to permission levels
            (``'read'`` or ``'readwrite'``).
        lock: Optional lock to serialise access to the source connection.
            Pass a shared ``threading.Lock`` when calling ``bridge()``
            concurrently against the same *source* from multiple threads.

    Raises:
        ValueError: If *permissions* is empty or contains invalid values.

    Example::

        cfg = {"allow_unsigned_extensions": "true"}
        source = duckdb.connect(config=cfg)
        target = duckdb.connect(config=cfg)
        bridge(source, target, "app",
               permissions={"users": "readwrite", "logs": "read"})
        target.sql('SELECT * FROM app.users')
    """
    if not permissions:
        raise ValueError("permissions cannot be empty")

    valid_perms = {"read", "readwrite"}
    for table, perm in permissions.items():
        if perm not in valid_perms:
            raise ValueError(f"Invalid permission '{perm}' for table '{table}'. Valid: {valid_perms}")

    load_extension(source)
    load_extension(target)

    if lock is not None:
        lock.acquire()
    try:
        token_result = source.sql(
            "SELECT n6k_bridge_register_source($1, $2::MAP(VARCHAR, VARCHAR))",
            params=[name, permissions],
        ).fetchone()
        if token_result is None:
            raise RuntimeError("n6k_bridge_register_source returned no result")
        token = token_result[0]
    finally:
        if lock is not None:
            lock.release()

    target.sql(
        "SELECT n6k_bridge_setup_bridge($1, $2)",
        params=[name, token],
    ).fetchone()

    target.sql(f"ATTACH ':memory:' AS \"{_escape_ident(name)}\" (TYPE n6k_bridge)")


def _escape_ident(s: str) -> str:
    return s.replace('"', '""')
