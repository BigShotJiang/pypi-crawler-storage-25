"""Single-function dispatcher for `causal_conv1d_bwd_full_cpu` (split out of `causal_conv1d_native.mojo` so each entry
point compiles to its own .so and is imported lazily on
first call from the Python wrapper)."""

from std.itertools import product
from std.os import abort
from std.python import PythonObject
from std.python.bindings import PythonModuleBuilder
from layout import TileTensor, Idx, TensorLayout
from layout.tile_layout import Layout

from kernel import bwd_kernel_cpu

comptime _BOOLS = [False, True]
comptime _WIDTHS = [2, 3, 4]


def causal_conv1d_bwd_full_cpu(
    mut py_self: PythonObject,
    mut args: PythonObject,
) raises -> PythonObject:
    """CPU fused backward. dtype + width are dispatched at runtime.

    Caller must zero `dweight_acc` (and `dbias_acc` if `has_bias=1`)
    before this call. Same arg layout as the GPU launcher minus the
    `cuda_stream_handle`.

    Python tuple positional args (29):
        0  x_data_ptr  (int)
        1  weight_data_ptr  (int)
        2  bias_data_ptr  (int) — pass 0 if `has_bias=0`
        3  dout_data_ptr  (int)
        4  dx_data_ptr  (int)
        5  dweight_acc_data_ptr  (int, fp32)
        6  dbias_acc_data_ptr  (int, fp32) — pass 0 if `has_bias=0`
        7  batch  (int)
        8  dim    (int)
        9  seqlen (int)
        10 x_batch_stride  (int)
        11 x_c_stride      (int)
        12 x_l_stride      (int)
        13 weight_c_stride (int)
        14 weight_w_stride (int)
        15 dout_batch_stride  (int)
        16 dout_c_stride      (int)
        17 dout_l_stride      (int)
        18 dx_batch_stride  (int)
        19 dx_c_stride      (int)
        20 dx_l_stride      (int)
        21 has_bias (int, 0 or 1)
        22 apply_silu (int, 0 or 1) — 1 ⇒ silu/swish was applied on fwd
        23 dtype_code (int) — 0=fp16, 1=bf16, 2=fp32
        24 width (int) — supported: 2, 3, 4
        25 has_seq_idx (int, 0 or 1)
        26 seq_idx_data_ptr (int, int32) — pass 0 if `has_seq_idx=0`
        27 seq_idx_batch_stride (int)
        28 seq_idx_l_stride (int)
        29 has_initial_states (int, 0 or 1)
        30 initial_states_data_ptr (int) — pass 0 if `has_initial_states=0`
        31 initial_states_batch_stride (int)
        32 initial_states_c_stride (int)
        33 initial_states_l_stride (int)
        34 dinitial_states_data_ptr (int) — pass 0 if `has_initial_states=0`
        35 dinitial_states_batch_stride (int)
        36 dinitial_states_c_stride (int)
        37 dinitial_states_l_stride (int)
    """
    var x_addr: Int = Int(py=args[0])
    var w_addr: Int = Int(py=args[1])
    var b_addr: Int = Int(py=args[2])
    var dout_addr: Int = Int(py=args[3])
    var dx_addr: Int = Int(py=args[4])
    var dweight_acc_addr: Int = Int(py=args[5])
    var dbias_acc_addr: Int = Int(py=args[6])

    var batch_int: Int = Int(py=args[7])
    var dim_int: Int = Int(py=args[8])
    var seqlen_int: Int = Int(py=args[9])
    var x_b_stride: Int = Int(py=args[10])
    var x_c_stride: Int = Int(py=args[11])
    var x_l_stride: Int = Int(py=args[12])
    var w_c_stride: Int = Int(py=args[13])
    var w_w_stride: Int = Int(py=args[14])
    var dout_b_stride: Int = Int(py=args[15])
    var dout_c_stride: Int = Int(py=args[16])
    var dout_l_stride: Int = Int(py=args[17])
    var dx_b_stride: Int = Int(py=args[18])
    var dx_c_stride: Int = Int(py=args[19])
    var dx_l_stride: Int = Int(py=args[20])
    var has_bias_rt: Bool = Int(py=args[21]) != 0
    var apply_silu_rt: Bool = Int(py=args[22]) != 0
    var dtype_code: Int = Int(py=args[23])
    var width_rt: Int = Int(py=args[24])
    var has_seq_idx_rt: Bool = Int(py=args[25]) != 0
    var seq_idx_addr: Int = Int(py=args[26])
    var seq_idx_b_stride: Int = Int(py=args[27])
    var seq_idx_l_stride: Int = Int(py=args[28])
    var has_initial_states_rt: Bool = Int(py=args[29]) != 0
    var initial_states_addr: Int = Int(py=args[30])
    var initial_states_b_stride: Int = Int(py=args[31])
    var initial_states_c_stride: Int = Int(py=args[32])
    var initial_states_l_stride: Int = Int(py=args[33])
    var dinitial_states_addr: Int = Int(py=args[34])
    var dinitial_states_b_stride: Int = Int(py=args[35])
    var dinitial_states_c_stride: Int = Int(py=args[36])
    var dinitial_states_l_stride: Int = Int(py=args[37])

    var dweight_acc_ptr = UnsafePointer[Float32, MutAnyOrigin](
        unsafe_from_address=dweight_acc_addr
    )
    var dbias_acc_ptr = UnsafePointer[Float32, MutAnyOrigin](
        unsafe_from_address=dbias_acc_addr
    )

    @parameter
    def run[dtype: DType]() raises:
        var x_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=x_addr
        )
        var w_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=w_addr
        )
        var b_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=b_addr
        )
        var dout_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=dout_addr
        )
        var seq_idx_ptr = UnsafePointer[Int32, MutAnyOrigin](
            unsafe_from_address=seq_idx_addr
        )
        var initial_states_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=initial_states_addr
        )
        var dx_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=dx_addr
        )
        var dinitial_states_ptr = UnsafePointer[Scalar[dtype], MutAnyOrigin](
            unsafe_from_address=dinitial_states_addr
        )

        @parameter
        def dispatch[
            width: Int,
            has_bias: Bool,
            has_seq_idx: Bool,
            has_initial_states: Bool,
            apply_silu: Bool,
        ]() raises:
            var x_tt = TileTensor(
                x_ptr,
                Layout(
                    (Idx(batch_int), Idx(dim_int), Idx(seqlen_int)),
                    (Idx(x_b_stride), Idx(x_c_stride), Idx(x_l_stride)),
                ),
            )
            var w_tt = TileTensor(
                w_ptr,
                Layout(
                    (Idx(dim_int), Idx[width]()),
                    (Idx(w_c_stride), Idx(w_w_stride)),
                ),
            )
            var dout_tt = TileTensor(
                dout_ptr,
                Layout(
                    (Idx(batch_int), Idx(dim_int), Idx(seqlen_int)),
                    (Idx(dout_b_stride), Idx(dout_c_stride), Idx(dout_l_stride)),
                ),
            )
            var dx_tt = TileTensor(
                dx_ptr,
                Layout(
                    (Idx(batch_int), Idx(dim_int), Idx(seqlen_int)),
                    (Idx(dx_b_stride), Idx(dx_c_stride), Idx(dx_l_stride)),
                ),
            )
            bwd_kernel_cpu[
                dtype,
                width,
                has_bias,
                has_seq_idx,
                has_initial_states,
                apply_silu,
                type_of(x_tt).LayoutType,
                type_of(w_tt).LayoutType,
                type_of(dout_tt).LayoutType,
                type_of(dx_tt).LayoutType,
            ](
                batch_int,
                dim_int,
                seqlen_int,
                x_tt.as_immut(),
                w_tt.as_immut(),
                b_ptr,
                dout_tt.as_immut(),
                seq_idx_ptr,
                initial_states_ptr,
                dx_tt,
                dweight_acc_ptr,
                dbias_acc_ptr,
                dinitial_states_ptr,
                seq_idx_b_stride,
                seq_idx_l_stride,
                initial_states_b_stride,
                initial_states_c_stride,
                initial_states_l_stride,
                dinitial_states_b_stride,
                dinitial_states_c_stride,
                dinitial_states_l_stride,
            )

        @parameter
        def dispatch_w[width: Int]() raises:
            comptime for hb, hs, hi, silu in product(
                _BOOLS, _BOOLS, _BOOLS, _BOOLS
            ):
                if (
                    hb == has_bias_rt
                    and hs == has_seq_idx_rt
                    and hi == has_initial_states_rt
                    and silu == apply_silu_rt
                ):
                    dispatch[width, hb, hs, hi, silu]()

        comptime for w in _WIDTHS:
            if width_rt == w:
                dispatch_w[w]()
                return
        raise Error("unsupported width (only 2, 3, 4 are supported)")

    if dtype_code == 0:
        run[DType.float16]()
    elif dtype_code == 1:
        run[DType.bfloat16]()
    else:
        run[DType.float32]()

    return PythonObject(None)


@export
def PyInit_dispatch() -> PythonObject:
    try:
        var m = PythonModuleBuilder("dispatch")
        m.def_py_function[causal_conv1d_bwd_full_cpu]("causal_conv1d_bwd_full_cpu")
        return m.finalize()
    except e:
        abort(String("failed to create Python module: ", e))
