"""Core Graph class — the main public API for DEG."""

from __future__ import annotations

import json
from collections import deque
from datetime import date, datetime
from pathlib import Path
from typing import Any

import yaml

from deg.schemas import (
    Alternative,
    ChangelogEntry,
    CompletedSearch,
    ContinueResearch,
    Decision,
    Evidence,
    EvidenceSource,
    Revalidation,
    RevalidationTrigger,
    State,
)
from deg.compiler import compile_graph, load_compiled, parse_frontmatter
from deg.state import read_state, write_state, close_session
from deg.temporal import is_valid, supersede, cascade_impact
from deg.triggers import evaluate_triggers, compute_stale_alerts


class Graph:
    """Decision-Evidence Graph: traceable, challengeable decision provenance."""

    def __init__(self, project_root: str | Path | None = None):
        self.root = Path(project_root) if project_root else self._find_root()
        self._nodes: dict = {}
        self._edges: list[dict] = []
        self._successors: dict[str, list[str]] = {}
        self._load()

    def _find_root(self) -> Path:
        """Walk up from CWD looking for .deg/ or decisions/ directory."""
        cwd = Path.cwd()
        for parent in [cwd, *cwd.parents]:
            if (parent / ".deg").exists() or (parent / "decisions").exists():
                return parent
        return cwd

    def _load(self) -> None:
        """Load compiled graph if available, otherwise compile from source."""
        deg_dir = self.root / ".deg"
        if (deg_dir / "nodes.jsonl").exists():
            self._nodes, self._edges, self._successors = load_compiled(self.root)
        elif (self.root / "decisions").exists():
            self.compile()

    # --- Write Operations ---

    def decide(
        self,
        title: str,
        evidence: list[str] | None = None,
        alternatives: list[dict] | None = None,
        revalidation_days: int = 30,
        scope: str = "",
        context: str = "",
        depends_on: list[str] | None = None,
        continue_research: dict | None = None,
    ) -> str:
        """Record a decision with full provenance. Returns the decision ID."""
        today = date.today()
        seq = self._next_seq("D")
        deg_id = f"D-{today.isoformat().replace('-', '')}-{seq:03d}"
        slug = "".join(c if c.isalnum() or c == "-" else "-" for c in title.lower().replace(" ", "-"))[:40].rstrip("-")

        alts = []
        if alternatives:
            for a in alternatives:
                alts.append(Alternative(
                    option=a.get("option", ""),
                    why=a.get("why", a.get("why_rejected", "")),
                    reconsider_if=a.get("reconsider_if"),
                ))

        decision = Decision(
            deg_id=deg_id,
            title=title,
            created=today,
            valid_from=today,
            scope=scope or None,
            context=context or None,
            informed_by=evidence or [],
            depends_on=depends_on or [],
            rejected=alts,
            revalidation=Revalidation(
                last_verified=today,
                triggers=[
                    RevalidationTrigger(type="temporal_expiry", review_after_days=revalidation_days),
                ] + ([
                    RevalidationTrigger(type="dependency_change", watch=evidence)
                ] if evidence else []),
            ),
            continue_research=ContinueResearch(**continue_research) if continue_research else None,
        )

        self._write_node("decisions", deg_id, slug, decision)
        self._append_changelog(ChangelogEntry(
            date=datetime.utcnow(),
            type="decision_made",
            id=deg_id,
            summary=title,
            evidence=evidence or [],
        ))
        self.compile()
        self._check_contradictions(deg_id)
        return deg_id

    def evidence(
        self,
        claim: str,
        source: str = "",
        confidence: float = 0.8,
        search_terms: list[str] | None = None,
        papers_consulted: list[str] | None = None,
        source_type: str = "literature",
        invalidates: str | None = None,
        informs: list[str] | None = None,
    ) -> str:
        """Record an evidence node. Returns the evidence ID."""
        today = date.today()
        seq = self._next_seq("E")
        deg_id = f"E-{today.isoformat().replace('-', '')}-{seq:03d}"
        slug = "".join(c if c.isalnum() or c == "-" else "-" for c in claim.lower().replace(" ", "-"))[:40].rstrip("-")

        ev = Evidence(
            deg_id=deg_id,
            claim=claim,
            confidence=confidence,
            valid_from=today,
            created_at=today,
            source=EvidenceSource(
                type=source_type,
                ref=source,
                search_terms=search_terms or [],
                papers_consulted=papers_consulted or [],
            ),
            informs=informs or [],
            revalidation=Revalidation(
                last_verified=today,
                triggers=[RevalidationTrigger(type="temporal_expiry", review_after_days=14)],
            ),
        )

        self._write_node("evidence", deg_id, slug, ev)
        self._append_changelog(ChangelogEntry(
            date=datetime.utcnow(),
            type="evidence_added",
            id=deg_id,
            summary=claim,
        ))

        if invalidates:
            self._invalidate(invalidates, deg_id)

        self.compile()
        self._check_contradictions(deg_id)
        return deg_id

    def reject(self, option: str, decision_id: str, because: str, reconsider_if: str | None = None) -> None:
        """Add a rejected alternative to an existing decision."""
        dec_file = self._find_node_file("decisions", decision_id)
        if not dec_file:
            raise ValueError(f"Decision {decision_id} not found")

        meta = parse_frontmatter(dec_file)
        rejected = meta.get("rejected", [])
        rejected.append({"option": option, "why": because, "reconsider_if": reconsider_if})
        meta["rejected"] = rejected

        self._rewrite_node(dec_file, meta)
        self._append_changelog(ChangelogEntry(
            date=datetime.utcnow(),
            type="alternative_rejected",
            id=decision_id,
            summary=f"Rejected '{option}': {because}",
        ))
        self.compile()

    # --- Read Operations ---

    def status(self) -> dict:
        """Get project state + computed stale alerts + integrity issues."""
        state = read_state(self.root)
        stale = self._compute_stale()
        state.stale_alerts = stale

        # Collect active decisions
        active = [nid for nid, n in self._nodes.items()
                  if n.get("type") == "decision" and n.get("status") == "active"]
        state.active_decisions = active

        result = state.model_dump(exclude_none=True, mode="json")

        # Run integrity self-checks (lightweight, pure Python)
        try:
            from deg.integrity import check_integrity
            issues = check_integrity(self._nodes, self._edges)
            if issues:
                result["integrity_issues"] = [
                    {"type": i.type, "severity": i.severity, "node_ids": i.node_ids,
                     "message": i.message, "auto_fix": i.auto_fix}
                    for i in issues
                ]
        except ImportError:
            pass

        return result

    def trace(self, node_id: str, max_depth: int = 10) -> list[dict]:
        """Trace provenance chain upstream from a node."""
        from deg.retrieval import trace_provenance
        return trace_provenance(node_id, self._nodes, self._edges, max_depth)

    def challenge(self, decision_id: str) -> dict:
        """Full revalidation assessment for a decision.

        Returns: validity status, evidence health (trust-weighted), alternatives,
        triggers fired, cascade impact, and decision health score (WLNK).
        """
        from deg.trust import decision_health

        node_raw = self._nodes.get(decision_id)
        if not node_raw:
            return {"error": f"Node {decision_id} not found"}

        # Parse into model for trigger evaluation
        node = self._to_model(node_raw)
        all_models = {nid: self._to_model(n) for nid, n in self._nodes.items()}

        # Check triggers
        fired = evaluate_triggers(node, all_models)

        # Check evidence validity + collect evidence nodes for health check
        evidence_status = {}
        evidence_nodes = []
        # Get evidence from node's informed_by field
        evidence_ids = list(node_raw.get("informed_by", []))
        # Also find evidence that 'informs' this decision via edges
        for edge in self._edges:
            if edge.get("type") == "informs" and edge.get("to") == decision_id:
                eid = edge.get("from")
                if eid and eid not in evidence_ids:
                    evidence_ids.append(eid)
        for ev_id in evidence_ids:
            ev = self._nodes.get(ev_id)
            if ev:
                ev_model = self._to_model(ev)
                evidence_status[ev_id] = {
                    "valid": is_valid(ev_model),
                    "confidence": ev.get("confidence", 0),
                    "claim": ev.get("claim", ""),
                }
                evidence_nodes.append(ev)

        # Compute decision health (WLNK: weakest link aggregation)
        health = decision_health(evidence_nodes)

        # Check alternatives
        alternatives_status = {}
        for alt in node_raw.get("rejected", []):
            alternatives_status[alt.get("option", "")] = {
                "reconsider_if": alt.get("reconsider_if"),
                "reconsider_now": False,
            }

        # Cascade impact
        affected = cascade_impact(decision_id, self._successors, all_models)

        is_stale = len(fired) > 0
        any_evidence_invalid = any(not v["valid"] for v in evidence_status.values())

        result = {
            "decision_id": decision_id,
            "title": node_raw.get("title", ""),
            "status": "needs_review" if (is_stale or any_evidence_invalid) else "valid",
            "health": health,
            "triggers_fired": fired,
            "evidence_validity": evidence_status,
            "alternatives": alternatives_status,
            "cascade_if_changed": affected,
        }

        # Also check for contradictions involving this decision
        try:
            from deg.contradiction import detect_contradictions, load_rules
            rules = load_rules(self.root)
            all_contradictions = detect_contradictions(self._nodes, self._edges, rules)
            relevant = [c for c in all_contradictions if decision_id in c.decision_ids]
            if relevant:
                result["contradictions"] = [
                    {"type": c.type, "with": [id for id in c.decision_ids if id != decision_id], "message": c.message}
                    for c in relevant
                ]
        except (ImportError, Exception):
            pass

        return result

    def impact(self, node_id: str) -> list[dict]:
        """Get all downstream nodes affected if this node changes."""
        from deg.retrieval import cascade_impact_bfs
        return cascade_impact_bfs(node_id, self._successors, self._nodes)

    def search(self, query: str, k: int = 5) -> list[dict]:
        """Hybrid search: semantic (FAISS) + keyword + graph PPR. Falls back to keyword-only if no index."""
        if not self._nodes:
            self.compile()
        try:
            from deg.retrieval import hybrid_search
            return hybrid_search(query, self.root, self._nodes, self._edges, self._successors, k=k)
        except (ImportError, Exception):
            # Fallback: keyword-only search
            query_lower = query.lower()
            results = []
            for nid, node in self._nodes.items():
                text = f"{node.get('title', '')} {node.get('claim', '')} {node.get('scope', '')} {node.get('context', '')}".lower()
                if query_lower in text:
                    results.append({"id": nid, **_summary(node)})
            return results[:k]

    def continue_research(self, decision_id: str) -> dict | None:
        """Get research continuation directives for a decision."""
        node = self._nodes.get(decision_id)
        if not node:
            return None
        cr = node.get("continue_research")
        if not cr:
            return {"decision_id": decision_id, "message": "No continue_research directives recorded"}
        return {"decision_id": decision_id, **cr}

    # --- Lifecycle ---

    def compile(self) -> dict:
        """Rebuild .deg/ from source markdown files. Builds FAISS index if sentence-transformers available."""
        result = compile_graph(self.root)
        self._nodes, self._edges, self._successors = load_compiled(self.root)

        # Build semantic index if deps available and nodes exist
        if self._nodes:
            try:
                from deg.embeddings import build_index
                build_index(self.root, self._nodes)
                result["index"] = "built"
            except ImportError:
                result["index"] = "skipped (install deg[search])"

        return result

    def close_session(self, summary: str, next_actions: list[str] | None = None, agent: str = "") -> dict:
        """Update STATE.yaml for session handoff."""
        active = [nid for nid, n in self._nodes.items()
                  if n.get("type") == "decision" and n.get("status") == "active"]
        state = close_session(self.root, summary, next_actions, agent, active)
        return state.model_dump(exclude_none=True, mode="json")

    def init(self, project_goal: str = "", current_phase: str = "") -> None:
        """Initialize DEG structure in project root."""
        # Refuse to overwrite existing state
        state_file = self.root / ".deg" / "STATE.yaml"
        if state_file.exists():
            import yaml as _y
            existing = _y.safe_load(state_file.read_text()) or {}
            if existing.get("project_goal"):
                return  # Already initialized with real data — don't overwrite

        (self.root / "decisions").mkdir(exist_ok=True)
        (self.root / "evidence").mkdir(exist_ok=True)
        deg_dir = self.root / ".deg"
        deg_dir.mkdir(exist_ok=True)

        state = State(project_goal=project_goal, current_phase=current_phase)
        write_state(self.root, state)

        changelog = self.root / ".deg" / "CHANGELOG.yaml"
        if not changelog.exists():
            changelog.write_text("# DEG Changelog (append-only)\n---\nevents: []\n")

    # --- Internal helpers ---

    def _next_seq(self, prefix: str) -> int:
        """Get next sequence number for today's nodes."""
        today_str = date.today().isoformat().replace("-", "")
        existing = [nid for nid in self._nodes if nid.startswith(f"{prefix}-{today_str}")]
        return len(existing) + 1

    def _write_node(self, directory: str, deg_id: str, slug: str, model) -> Path:
        """Write a node as YAML-frontmatter markdown."""
        dir_path = self.root / directory
        dir_path.mkdir(exist_ok=True)
        filename = f"{deg_id}-{slug}.md"
        filepath = dir_path / filename

        data = model.model_dump(exclude_none=True, mode="json")
        frontmatter = yaml.dump(data, default_flow_style=False, sort_keys=False)
        filepath.write_text(f"---\n{frontmatter}---\n", encoding="utf-8")
        return filepath

    def _find_node_file(self, directory: str, node_id: str) -> Path | None:
        """Find the markdown file for a node by ID."""
        dir_path = self.root / directory
        if not dir_path.exists():
            return None
        for f in dir_path.glob("*.md"):
            if f.name.startswith(node_id):
                return f
        return None

    def _rewrite_node(self, filepath: Path, meta: dict) -> None:
        """Rewrite a node file with updated metadata."""
        body = meta.pop("_body", "")
        meta.pop("_file", None)
        frontmatter = yaml.dump(meta, default_flow_style=False, sort_keys=False)
        filepath.write_text(f"---\n{frontmatter}---\n{body}\n", encoding="utf-8")

    def _invalidate(self, old_id: str, new_id: str) -> None:
        """Write-time cascade with confidence-gated supersession.

        1. Check if new evidence CAN supersede old (confidence-weighted, FPF WLNK)
        2. If yes: mark old as superseded, compute impact delta
        3. Only cascade if impact delta > 0.25 (significance filter)
        4. Multi-hop BFS for cascade propagation (WorldDB + EditPropBench)

        Sources:
        - WorldDB (arXiv:2604.18478): write-time edge programs
        - FPF (arXiv:2601.21116): WLNK confidence model
        - EditPropBench (arXiv:2605.02083): cascade with protected nodes
        """
        from deg.trust import can_supersede, compute_impact, should_cascade, VALIDITY_SUPERSEDED, VALIDITY_ACTIVE

        old_file = self._find_node_file("evidence", old_id)
        if not old_file:
            return
        old_meta = parse_frontmatter(old_file)
        if not old_meta:
            return

        # Get confidence values
        old_confidence = float(old_meta.get("confidence", 0.5))
        # Find new evidence confidence from the node we just created
        new_file = self._find_node_file("evidence", new_id)
        new_confidence = 0.5
        if new_file:
            new_meta = parse_frontmatter(new_file)
            if new_meta:
                new_confidence = float(new_meta.get("confidence", 0.5))

        # Check: can the new evidence actually supersede the old?
        old_created = None
        created_str = old_meta.get("created_at") or old_meta.get("created")
        if created_str:
            try:
                old_created = date.fromisoformat(str(created_str))
            except (ValueError, TypeError):
                pass

        allowed, reason = can_supersede(new_confidence, old_confidence, old_created)

        if not allowed:
            # LOW-CONFIDENCE BLOCKED: record the attempt but don't supersede
            # Add a note to the new evidence that it tried but failed
            if new_file:
                new_meta = parse_frontmatter(new_file)
                if new_meta:
                    new_meta.setdefault("_blocked_supersession", [])
                    new_meta["_blocked_supersession"].append({
                        "target": old_id,
                        "reason": reason,
                    })
                    self._rewrite_node(new_file, new_meta)
            return  # No cascade — blocked by confidence gate

        # ALLOWED: Mark old as superseded
        old_impact = compute_impact(old_confidence, VALIDITY_ACTIVE, created_at=old_created)
        old_meta["expired_at"] = datetime.utcnow().isoformat()
        old_meta["superseded_by"] = new_id
        old_meta["status"] = "superseded"
        self._rewrite_node(old_file, old_meta)

        new_impact = compute_impact(new_confidence, VALIDITY_ACTIVE)

        # Cascade condition: evidence was superseded = decision's basis changed
        # Even if new evidence is stronger, the decision should be reviewed
        # because it was made based on OLD evidence that is now invalid
        # The should_cascade check is for PARTIAL updates (weakening), not full supersession
        # Full supersession always cascades — the decision's foundation was replaced

        # Multi-hop cascade: BFS through downstream dependencies
        flagged_ids = set()
        decisions_dir = self.root / "decisions"
        if not decisions_dir.exists():
            return

        for dec_file in decisions_dir.glob("*.md"):
            dec_meta = parse_frontmatter(dec_file)
            if not dec_meta:
                continue
            if old_id in dec_meta.get("informed_by", []):
                if dec_meta.get("status") == "active":
                    dec_meta["status"] = "under_review"
                    self._rewrite_node(dec_file, dec_meta)
                    flagged_ids.add(dec_meta.get("deg_id", dec_file.stem))

        # Multi-hop propagation
        changed = True
        while changed:
            changed = False
            for dec_file in decisions_dir.glob("*.md"):
                dec_meta = parse_frontmatter(dec_file)
                if not dec_meta:
                    continue
                dec_id = dec_meta.get("deg_id", dec_file.stem)
                if dec_id in flagged_ids:
                    continue
                if dec_meta.get("status") != "active":
                    continue
                for dep_id in dec_meta.get("depends_on", []):
                    if dep_id in flagged_ids:
                        dec_meta["status"] = "under_review"
                        self._rewrite_node(dec_file, dec_meta)
                        flagged_ids.add(dec_id)
                        changed = True
                        break

    def _append_changelog(self, entry: ChangelogEntry) -> None:
        """Append an event to the changelog."""
        changelog_file = self.root / ".deg" / "CHANGELOG.yaml"
        changelog_file.parent.mkdir(exist_ok=True)

        data = entry.model_dump(exclude_none=True, mode="json")
        data["date"] = data["date"].isoformat() if hasattr(data["date"], "isoformat") else str(data["date"])

        # Load existing events list (or start fresh)
        events = []
        if changelog_file.exists():
            try:
                existing = yaml.safe_load(changelog_file.read_text())
                if isinstance(existing, dict) and isinstance(existing.get("events"), list):
                    events = existing["events"]
                elif isinstance(existing, list):
                    events = existing
            except (yaml.YAMLError, ValueError):
                events = []

        # Append new entry and write valid YAML
        events.append(data)
        changelog_file.write_text(yaml.dump({"events": events}, default_flow_style=False, sort_keys=False))

    def _check_contradictions(self, new_node_id: str) -> None:
        """Run contradiction detection after a write. Non-blocking — stores findings."""
        try:
            from deg.contradiction import detect_contradictions, load_rules
            rules = load_rules(self.root)
            conflicts = detect_contradictions(self._nodes, self._edges, rules)
            if conflicts:
                import json
                contradictions_file = self.root / ".deg" / "contradictions.json"
                existing = []
                if contradictions_file.exists():
                    try:
                        existing = json.loads(contradictions_file.read_text())
                    except (json.JSONDecodeError, ValueError):
                        existing = []
                for c in conflicts:
                    existing.append({
                        "detected_at": date.today().isoformat(),
                        "triggered_by": new_node_id,
                        "type": c.type,
                        "decision_ids": c.decision_ids,
                        "message": c.message,
                        "severity": c.severity,
                    })
                contradictions_file.write_text(json.dumps(existing, indent=2))
        except ImportError:
            pass
        except Exception:
            pass

    def _compute_stale(self) -> list[dict]:
        """Compute stale alerts for all active nodes."""
        models = {nid: self._to_model(n) for nid, n in self._nodes.items()}
        active = {nid: m for nid, m in models.items()
                  if getattr(m, "status", "active") == "active"}
        return compute_stale_alerts(active, models)

    def _to_model(self, raw: dict):
        """Convert raw node dict to appropriate Pydantic model."""
        node_type = raw.get("type", "")
        try:
            if node_type == "decision":
                return Decision(**{k: v for k, v in raw.items() if not k.startswith("_") and k != "id"})
            elif node_type == "evidence":
                return Evidence(**{k: v for k, v in raw.items() if not k.startswith("_") and k != "id"})
        except Exception:
            pass
        # Fallback: return a simple object with status attribute
        class _Node:
            pass
        n = _Node()
        for k, v in raw.items():
            setattr(n, k, v)
        return n


def _summary(node: dict) -> dict:
    """Extract a short summary from a raw node dict."""
    return {
        "type": node.get("type", ""),
        "title": node.get("title", node.get("claim", "")),
        "status": node.get("status", ""),
        "confidence": node.get("confidence", ""),
        "created": node.get("created", node.get("created_at", "")),
    }
