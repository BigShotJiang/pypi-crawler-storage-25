"""DEG: Decision-Evidence Graph — traceable, challengeable decision provenance for AI agents."""

from deg.graph import Graph
from deg.schemas import Decision, Evidence, State

__version__ = "1.0.5"
__all__ = ["Graph", "Decision", "Evidence", "State"]
