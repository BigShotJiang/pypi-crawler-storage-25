"""
Self-maintenance engine for DEG decision graphs.

Based on YAGO 4.5 cleanup pipeline patterns. Pure stdlib implementation.
Operates on compiled graph format: nodes dict + edges list.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from difflib import SequenceMatcher


@dataclass
class MaintenanceFinding:
    category: str  # "orphan", "duplicate", "merge_candidate", "cycle", "assumption_invalid", "stale"
    severity: str  # "info", "warning", "action_needed"
    node_ids: list[str] = field(default_factory=list)
    message: str = ""
    suggestion: str = ""


# --- Helpers ---

_NEGATION_TOKENS = frozenset(
    {"not", "no", "deprecated", "removed", "replaced", "rejected", "instead", "rather"}
)

_SEVERITY_ORDER = {"action_needed": 0, "warning": 1, "info": 2}


def _title_similarity(a: str, b: str) -> float:
    """SequenceMatcher ratio between two titles."""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def _extract_keywords(text: str) -> set[str]:
    """Extract lowercase alpha tokens >= 3 chars."""
    return {w for w in re.findall(r"[a-z]{3,}", text.lower())}


def _get_node_type(node: dict) -> str:
    return node.get("type", "unknown")


def _get_title(node: dict) -> str:
    return node.get("title", node.get("name", ""))


def _get_status(node: dict) -> str:
    return node.get("status", "active")


def _get_created(node: dict) -> datetime | None:
    raw = node.get("created") or node.get("created_at") or node.get("timestamp")
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _get_last_verified(node: dict) -> datetime | None:
    raw = node.get("last_verified") or node.get("verified_at")
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


# --- Maintenance Operations ---


def find_orphaned_evidence(nodes: dict[str, dict], edges: list[dict]) -> list[MaintenanceFinding]:
    """Evidence nodes with zero inbound edges (no decision references them).

    Excludes high-confidence experiment/milestone evidence (>=0.9 confidence with
    source_type 'experiment') as these are legitimately standalone verification records.
    """
    evidence_ids = {nid for nid, n in nodes.items() if _get_node_type(n) == "evidence"}
    if not evidence_ids:
        return []

    # Collect all evidence that has ANY edge (inbound OR outbound)
    has_connection = set()
    for edge in edges:
        target = edge.get("target") or edge.get("to")
        source = edge.get("source") or edge.get("from")
        if target in evidence_ids:
            has_connection.add(target)
        if source in evidence_ids:
            has_connection.add(source)  # Has outbound edge — not orphaned

    findings = []
    # Orphans are evidence with ZERO connections (neither inbound nor outbound)
    for eid in sorted(evidence_ids - has_connection):
        node = nodes[eid]
        # Skip standalone milestone/verification evidence (high confidence experiments)
        source_type = node.get("source_type", "")
        confidence = node.get("confidence", 0.5)
        if source_type in ("experiment", "observation") and confidence >= 0.7:
            continue
        title = node.get("claim") or node.get("title") or "(untitled)"
        findings.append(MaintenanceFinding(
            category="orphan",
            severity="info",
            node_ids=[eid],
            message=f"Evidence '{title}' ({eid}) has no inbound edges — nothing references it.",
            suggestion="This evidence isn't referenced by any decision. If it supports a decision, link it. If it's a standalone observation, this is fine to ignore.",
        ))
    return findings


def find_duplicates(nodes: dict[str, dict]) -> list[MaintenanceFinding]:
    """Find nodes with highly similar titles within the same type (ratio > 0.85)."""
    by_type: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for nid, n in nodes.items():
        ntype = _get_node_type(n)
        title = _get_title(n)
        if title:
            by_type[ntype].append((nid, title))

    findings = []
    seen_pairs: set[tuple[str, str]] = set()

    for ntype, items in by_type.items():
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                id_a, title_a = items[i]
                id_b, title_b = items[j]
                pair = (min(id_a, id_b), max(id_a, id_b))
                if pair in seen_pairs:
                    continue
                ratio = _title_similarity(title_a, title_b)
                if ratio > 0.85:
                    seen_pairs.add(pair)
                    findings.append(MaintenanceFinding(
                        category="duplicate",
                        severity="warning",
                        node_ids=[id_a, id_b],
                        message=f"Likely duplicate {ntype}s: '{title_a}' and '{title_b}' ({ratio:.0%} similarity).",
                        suggestion=f"Consider merging {id_a} and {id_b} ({ratio:.0%} title similarity)",
                    ))
    return findings


def find_merge_candidates(nodes: dict[str, dict], edges: list[dict]) -> list[MaintenanceFinding]:
    """Composite score: title_sim * 0.4 + shared_evidence * 0.4 + same_scope * 0.2. Threshold > 0.70."""
    decision_ids = [nid for nid, n in nodes.items() if _get_node_type(n) == "decision"]
    if len(decision_ids) < 2:
        return []

    # Build evidence adjacency: decision -> set of evidence it links to
    evidence_of: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        src = edge.get("source") or edge.get("from")
        tgt = edge.get("target") or edge.get("to")
        if src in nodes and tgt in nodes:
            if _get_node_type(nodes.get(tgt, {})) == "evidence":
                evidence_of[src].add(tgt)
            if _get_node_type(nodes.get(src, {})) == "evidence":
                evidence_of[tgt].add(src)

    findings = []
    seen: set[tuple[str, str]] = set()

    for i in range(len(decision_ids)):
        for j in range(i + 1, len(decision_ids)):
            id_a, id_b = decision_ids[i], decision_ids[j]
            pair = (min(id_a, id_b), max(id_a, id_b))
            if pair in seen:
                continue

            n_a, n_b = nodes[id_a], nodes[id_b]
            title_sim = _title_similarity(_get_title(n_a), _get_title(n_b))

            # Shared evidence ratio (Jaccard)
            ev_a, ev_b = evidence_of.get(id_a, set()), evidence_of.get(id_b, set())
            union = ev_a | ev_b
            shared_ev = len(ev_a & ev_b) / len(union) if union else 0.0

            # Same scope
            scope_a = n_a.get("scope", n_a.get("context", ""))
            scope_b = n_b.get("scope", n_b.get("context", ""))
            same_scope = 1.0 if (scope_a and scope_a == scope_b) else 0.0

            composite = title_sim * 0.4 + shared_ev * 0.4 + same_scope * 0.2
            if composite > 0.70:
                seen.add(pair)
                findings.append(MaintenanceFinding(
                    category="merge_candidate",
                    severity="info",
                    node_ids=[id_a, id_b],
                    message=f"Merge candidates: '{_get_title(n_a)}' and '{_get_title(n_b)}' (score {composite:.2f}).",
                    suggestion=f"{id_a} and {id_b} may cover the same concern",
                ))
    return findings


def detect_cycles(edges: list[dict], edge_type: str) -> list[MaintenanceFinding]:
    """Iterative DFS to find back edges (cycles) on a specific edge type."""
    # Build adjacency for the given edge type
    adj: dict[str, list[str]] = defaultdict(list)
    all_nodes: set[str] = set()
    for edge in edges:
        if edge.get("type") == edge_type or edge.get("label") == edge_type:
            src = edge.get("source") or edge.get("from")
            tgt = edge.get("target") or edge.get("to")
            if src and tgt:
                adj[src].append(tgt)
                all_nodes.add(src)
                all_nodes.add(tgt)

    if not all_nodes:
        return []

    # Iterative DFS with coloring (WHITE=0, GRAY=1, BLACK=2)
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = {n: WHITE for n in all_nodes}
    parent: dict[str, str | None] = {}
    cycles: list[list[str]] = []

    for start in all_nodes:
        if color[start] != WHITE:
            continue
        stack: list[tuple[str, int]] = [(start, 0)]
        parent[start] = None
        while stack:
            node, idx = stack.pop()
            if idx == 0:
                color[node] = GRAY
            neighbors = adj.get(node, [])
            if idx < len(neighbors):
                stack.append((node, idx + 1))
                nxt = neighbors[idx]
                if color.get(nxt, WHITE) == GRAY:
                    # Back edge found — reconstruct cycle
                    cycle = [nxt, node]
                    cur = node
                    while cur != nxt and cur is not None:
                        cur = parent.get(cur)
                        if cur and cur != nxt:
                            cycle.append(cur)
                    cycle.append(nxt)
                    cycle.reverse()
                    cycles.append(cycle)
                elif color.get(nxt, WHITE) == WHITE:
                    parent[nxt] = node
                    stack.append((nxt, 0))
            else:
                color[node] = BLACK

    severity = "action_needed" if edge_type == "supersedes" else "warning"
    findings = []
    for cycle in cycles:
        ids = [n for n in cycle if n]
        path_str = " -> ".join(ids)
        findings.append(MaintenanceFinding(
            category="cycle",
            severity=severity,
            node_ids=list(dict.fromkeys(ids)),  # dedupe, preserve order
            message=f"Circular {edge_type} dependency detected: {path_str}",
            suggestion=f"Circular dependency: {path_str}. Break the cycle.",
        ))
    return findings


def detect_invalidated_assumptions(nodes: dict[str, dict], edges: list[dict]) -> list[MaintenanceFinding]:
    """Check if newer active nodes contain negation tokens about the same topic."""
    active_nodes = [
        (nid, n) for nid, n in nodes.items()
        if _get_status(n) == "active" and _get_title(n)
    ]

    # Sort by created time (oldest first)
    def sort_key(item):
        dt = _get_created(item[1])
        return dt if dt else datetime.min
    active_nodes.sort(key=sort_key)

    findings = []
    seen_pairs: set[tuple[str, str]] = set()

    for i in range(len(active_nodes)):
        id_old, n_old = active_nodes[i]
        kw_old = _extract_keywords(_get_title(n_old))
        if not kw_old:
            continue
        created_old = _get_created(n_old)

        for j in range(i + 1, len(active_nodes)):
            id_new, n_new = active_nodes[j]
            created_new = _get_created(n_new)

            # Must be newer (or at least not the same)
            if created_old and created_new and created_new <= created_old:
                continue

            title_new = _get_title(n_new).lower()
            kw_new = _extract_keywords(title_new)
            if not kw_new:
                continue

            # Keyword overlap ratio (relative to older node)
            overlap = len(kw_old & kw_new) / len(kw_old) if kw_old else 0.0
            if overlap <= 0.25:
                continue

            # Check negation tokens in newer title
            title_tokens = set(re.findall(r"[a-z]+", title_new))
            if not title_tokens & _NEGATION_TOKENS:
                continue

            pair = (min(id_old, id_new), max(id_old, id_new))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)

            findings.append(MaintenanceFinding(
                category="assumption_invalid",
                severity="warning",
                node_ids=[id_old, id_new],
                message=f"'{_get_title(n_old)}' ({id_old}) may be invalidated by newer '{_get_title(n_new)}' ({id_new}).",
                suggestion=f"{id_old} may be invalidated by newer {id_new} which discusses the same topic with negation",
            ))
    return findings


def find_stale_unreviewed(nodes: dict[str, dict]) -> list[MaintenanceFinding]:
    """Active decisions older than 60 days with no last_verified update."""
    now = datetime.now()
    threshold = timedelta(days=60)
    findings = []

    for nid, n in nodes.items():
        if _get_node_type(n) != "decision":
            continue
        if _get_status(n) != "active":
            continue

        created = _get_created(n)
        if created is None:
            continue

        # Strip timezone for comparison if needed
        created_naive = created.replace(tzinfo=None) if created.tzinfo else created
        age = now - created_naive
        if age <= threshold:
            continue

        last_verified = _get_last_verified(n)
        if last_verified is not None:
            continue

        findings.append(MaintenanceFinding(
            category="stale",
            severity="info",
            node_ids=[nid],
            message=f"Decision '{_get_title(n)}' ({nid}) is {age.days} days old and never reviewed.",
            suggestion=f"{nid} is {age.days} days old and never reviewed. Consider running deg challenge {nid}",
        ))
    return findings


# --- Main Entry Point ---


def run_maintenance(nodes: dict[str, dict], edges: list[dict], project_root: "Path | None" = None) -> list[MaintenanceFinding]:
    """Run all 6 maintenance checks. Returns list of findings sorted by severity."""
    all_findings: list[MaintenanceFinding] = []

    all_findings.extend(find_orphaned_evidence(nodes, edges))
    all_findings.extend(find_duplicates(nodes))
    all_findings.extend(find_merge_candidates(nodes, edges))
    all_findings.extend(detect_cycles(edges, "supersedes"))
    all_findings.extend(detect_cycles(edges, "depends_on"))
    all_findings.extend(detect_invalidated_assumptions(nodes, edges))
    all_findings.extend(find_stale_unreviewed(nodes))

    if project_root:
        from deg.dismissed import filter_dismissed
        all_findings = filter_dismissed(project_root, all_findings)

    all_findings.sort(key=lambda f: _SEVERITY_ORDER.get(f.severity, 99))
    return all_findings
