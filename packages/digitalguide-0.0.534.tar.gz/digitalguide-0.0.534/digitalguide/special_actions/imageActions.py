
from io import BytesIO

from configparser import ConfigParser
from time import sleep
import requests
import logging


def generate_gif(im1, im2):
    from PIL import Image

    config = ConfigParser()
    config.read("config.ini")

    im1 = im1.resize((512, 512))
    im2 = im2.resize((512, 512))

    im2 = im2.convert(im1.mode)


    images = []
    frames = 5

    for i in range(frames+1):
        im = Image.blend(im1, im2, i/frames)
        images.append(im)

    for i in range(frames+1):
        im = Image.blend(im1, im2, 1-i/frames)
        images.append(im)

    bio = BytesIO()
    bio.name = 'image.webp'

    images[0].save(bio, 'webp', save_all=True,
                   append_images=images[1:], duration=500, loop=0, optimize=True, quality=50, minimize_size=True)
    bio.seek(0)
    return bio


def overlay_images(background, foreground, x_position="left", y_position="up", resize=True):
    x_scale_ratio = foreground.size[0]/background.size[0]
    y_scale_ratio = foreground.size[1]/background.size[1]

    if x_scale_ratio >= y_scale_ratio:
        scale_ratio = foreground.size[0]/background.size[0]
        background = background.resize(
            (foreground.size[0], round(background.size[1]*scale_ratio)))
    elif x_scale_ratio < y_scale_ratio:
        scale_ratio = foreground.size[1]/background.size[1]
        background = background.resize(
            (round(background.size[0]*scale_ratio), foreground.size[1]))

    if x_position=="left":
        x_coordinate = 0
    elif x_position=="right":
        x_coordinate = background.size[0] - foreground.size[0]
    elif x_position=="middle":
        x_coordinate = background.size[0]/2 - foreground.size[0]/2

    if y_position =="up":
        y_coordinate = 0
    elif y_position =="middle":
        y_coordinate = background.size[1]/2 - foreground.size[1]/2
    elif y_position == "bottom":
        y_coordinate = background.size[1] - foreground.size[1]

    background.paste(foreground, (x_coordinate, y_coordinate), foreground)
    return background

def whatsapp_eval_image_overlay(client, update, context, picture, x_position="left", y_position="up", resize="x"):
    from PIL import Image

    config = ConfigParser()
    config.read("config.ini")

    if resize in ["False", "false"]:
        resize = False

    media_url_obj = client.get_media_url(update.image.id)
    content = client.download_media(url=media_url_obj.url, in_memory=True)
    im1 = Image.open(BytesIO(content))
    im2 = Image.open(picture)

    new_im = overlay_images(im1, im2, x_position, y_position, resize)

    bio = BytesIO()
    bio.name = 'image.png'
    new_im.save(bio, 'PNG')
    bio.seek(0)

    import boto3
    import os
    import time
    session = boto3.session.Session()
    s3_client = session.client('s3',
                           region_name=config["space"]["region_name"],
                           endpoint_url=config["space"]["endpoint_url"],
                           aws_access_key_id=os.getenv('SPACES_KEY'),
                           aws_secret_access_key=os.getenv('SPACES_SECRET'))

    time_str = str(round(time.time() * 1000))

    s3_client.put_object(Bucket=config["space"]["bucket"],
                            Key=time_str + "_" + str(client.phone_id) + '.png',
                            Body=bio,
                            ACL='public-read',
                            ContentType='image/png'
                            )

    client.send_image(to=update.from_user.wa_id,
                      image=config["space"]["url"] + "/" + time_str + "_" + str(client.phone_id) + '.png')


def whatsapp_eval_multi_image_overlay(client, update, context, overlay_top_left=None, overlay_top_right=None, overlay_bottom_left=None, overlay_bottom_right=None):
    try:
        from PIL import Image
        config = ConfigParser()
        config.read("config.ini")

        media_url_obj = client.get_media_url(update.image.id)
        content = client.download_media(url=media_url_obj.url, in_memory=True)
        im1 = Image.open(BytesIO(content))

        if overlay_top_left:
            im2 = Image.open(BytesIO(requests.get(config["space"]["url"] + "/" + overlay_top_left).content))
            im1 = overlay_images(im1, im2, "left","up", True)
        if overlay_top_right:
            im2 = Image.open(BytesIO(requests.get(config["space"]["url"] + "/" + overlay_top_right).content))
            im1 = overlay_images(im1, im2, "right","up", True)
        if overlay_bottom_left:
            im2 = Image.open(BytesIO(requests.get(config["space"]["url"] + "/" + overlay_bottom_left).content))
            im1 = overlay_images(im1, im2, "left","bottom", True)
        if overlay_bottom_right:
            im2 = Image.open(BytesIO(requests.get(config["space"]["url"] + "/" + overlay_bottom_right).content))
            im1 = overlay_images(im1, im2, "right","bottom", True)

        bio = BytesIO()
        bio.name = 'image.png'
        im1.save(bio, 'PNG')
        bio.seek(0)

        import boto3
        import os
        import time
        session = boto3.session.Session()
        s3_client = session.client('s3',
                            region_name=config["space"]["region_name"],
                            endpoint_url=config["space"]["endpoint_url"],
                            aws_access_key_id=os.getenv('SPACES_KEY'),
                            aws_secret_access_key=os.getenv('SPACES_SECRET'))

        time_str = str(round(time.time() * 1000))

        s3_client.put_object(Bucket=config["space"]["bucket"],
                                Key=time_str + "_" + str(client.phone_id) + '.png',
                                Body=bio,
                                ACL='public-read',
                                ContentType='image/png'
                                )

        client.send_image(to=update.from_user.wa_id,
                          image=config["space"]["url"] + "/" + time_str + "_" + str(client.phone_id) + '.png')
        sleep(2)
    except Exception as e:
        client.send_message(to=update.from_user.wa_id, text="{}".format(e))


def whatsapp_eval_gif_generation(client, update, context, picture):
    from PIL import Image

    config = ConfigParser()
    config.read("config.ini")

    try:
        media_url_obj = client.get_media_url(update.image.id)
        content = client.download_media(url=media_url_obj.url, in_memory=True)
        im1 = Image.open(BytesIO(content))
        im2 = Image.open(picture)

        bio = generate_gif(im1, im2)
    except Exception as e:
        client.send_message(to=update.from_user.wa_id, text="{}".format(e))
        return

    import boto3
    import os
    import time
    session = boto3.session.Session()
    s3_client = session.client('s3',
                               region_name=config["space"]["region_name"],
                               endpoint_url=config["space"]["endpoint_url"],
                               aws_access_key_id=os.getenv('SPACES_KEY'),
                               aws_secret_access_key=os.getenv('SPACES_SECRET'))

    time_str = str(round(time.time() * 1000))

    s3_client.put_object(Bucket=config["space"]["bucket"],
                            Key=time_str + "_" + str(client.phone_id) + '.webp',
                            Body=bio,
                            ACL='public-read',
                            ContentType='image/webp'
                            )

    client.send_sticker(to=update.from_user.wa_id,
                        sticker=config["space"]["url"] + "/" + time_str + "_" + str(client.phone_id) + '.webp')
    sleep(2)


def whatsapp_function_eval_image_overlay(client, update, context, overlay_top_left=None, overlay_top_right=None, overlay_bottom_left=None, overlay_bottom_right=None):
    payload = {
        "phone_id": client.phone_id,
        "message_id": update.id,
        "from": update.from_user.wa_id,
        "media_id": update.image.id,
        "overlay_top_left": overlay_top_left,
        "overlay_top_right": overlay_top_right,
        "overlay_bottom_left": overlay_bottom_left,
        "overlay_bottom_right": overlay_bottom_right,
    }

    logging.info(f"Sending payload to image overlay: {payload}")
    res = requests.post("https://tiergarten-bot.blauedaecher.com/tiergarten/image_overlay", json=payload)
    logging.info(f"Response from image overlay: {res.status_code} - {res.text}")


whatsapp_action_functions = {"eval_image_overlay": whatsapp_eval_image_overlay,
                             "eval_multi_image_overlay": whatsapp_function_eval_image_overlay,
                             "eval_gif_generation": whatsapp_eval_gif_generation
                             }
