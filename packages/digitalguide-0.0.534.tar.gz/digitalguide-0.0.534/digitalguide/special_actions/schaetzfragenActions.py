from digitalguide.pattern import JAHRESZAHL_PATTERN, KOMMAZAHL_PATTERN
from digitalguide.wa_utils import get_message_text
import re

import logging
logging.getLogger(__name__).addHandler(logging.NullHandler())

def whatsapp_eval_jahreszahl(client, update, context, echter_wert, richtig_text, vorher_singular_text, vorher_plural_text, spaeter_singular_text, spaeter_plural_text):
    echter_wert = int(echter_wert)
    schaetzung = int(re.findall(JAHRESZAHL_PATTERN, get_message_text(update))[0])
    if schaetzung == echter_wert:
        client.send_message(to=update.from_user.wa_id, text=richtig_text)

    differenz = schaetzung - echter_wert
    if differenz == -1:
        client.send_message(to=update.from_user.wa_id, text=spaeter_singular_text)

    elif differenz < -1:
        client.send_message(to=update.from_user.wa_id, text=spaeter_plural_text.format(abs(differenz)))

    elif differenz == 1:
        client.send_message(to=update.from_user.wa_id, text=vorher_singular_text)

    elif differenz > 1:
        client.send_message(to=update.from_user.wa_id, text=vorher_plural_text.format(abs(differenz)))


def whatsapp_eval_kommazahl(client, update, context, echter_wert, richtig_text, vorher_singular_text, vorher_plural_text, spaeter_singular_text, spaeter_plural_text):
    echter_wert = float(echter_wert)
    match = re.search(KOMMAZAHL_PATTERN, get_message_text(update))

    if match:
        if match.group('vorkomma'):
            schaetzung = int(match.group('vorkomma'))
        else:
            schaetzung = 0

        if match.group('nachkomma'):
            schaetzung += float("0." + match.group('nachkomma'))

        if schaetzung == echter_wert:
            client.send_message(to=update.from_user.wa_id, text=richtig_text)

        differenz = schaetzung - echter_wert

        if differenz % 1 == 0:
            differenz = int(differenz)

        if differenz == -1:
            client.send_message(to=update.from_user.wa_id, text=spaeter_singular_text)

        elif differenz < -1 or (-1 < differenz < 0):
            client.send_message(to=update.from_user.wa_id, text=spaeter_plural_text.format(abs(differenz)))

        elif differenz == 1:
            client.send_message(to=update.from_user.wa_id, text=vorher_singular_text)

        elif differenz > 1 or (0 < differenz < 1):
            client.send_message(to=update.from_user.wa_id, text=vorher_plural_text.format(abs(differenz)))

whatsapp_action_functions = {"eval_jahreszahl": whatsapp_eval_jahreszahl,
                             "eval_kommazahl": whatsapp_eval_kommazahl,
                             }
