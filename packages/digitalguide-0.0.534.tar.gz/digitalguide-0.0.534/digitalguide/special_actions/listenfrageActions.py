from digitalguide.generateActions import Action


def whatsapp_loop_list(client, update, context, key, value, doppelte_antwort):
    if key not in context:
        context[key] = []

    if value in context[key]:
        Action(doppelte_antwort)(client, update, context)
        return "{}_FRAGE".format(key.upper())
    else:
        context[key].append(value)


def whatsapp_loop_list_fertig(client, update, context, key, answer_id_list, fertig_antwort):
    if set(answer_id_list).issubset(set(context[key])):
        Action(fertig_antwort)(client, update, context)


def whatsapp_eval_list(client, update, context, answer_id_name_list, poi, response_text):
    if poi not in context:
        context[poi] = []

    response_text += "\n"

    for id, name in answer_id_name_list:
        if id in context[poi]:
            response_text += "✅ {}\n".format(name)
        else:
            response_text += "◽ {}\n".format(name)

    client.send_message(to=update.from_user.wa_id, text=response_text)


whatsapp_action_functions = {"loop_list": whatsapp_loop_list,
                             "eval_list": whatsapp_eval_list,
                             "loop_list_fertig": whatsapp_loop_list_fertig
                             }
