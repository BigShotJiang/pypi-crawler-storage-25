from digitalguide.wa_utils import get_message_text


def whatsapp_default_name(client, update, context):
    context["name"] = update.from_user.name


def whatsapp_save_text_to_context(client, update, context, key):
    context[key] = get_message_text(update)


def whatsapp_save_value_to_context(client, update, context, key, value):
    context[key] = value


whatsapp_action_functions = {"default_name": whatsapp_default_name,
                           "save_text_to_context": whatsapp_save_text_to_context,
                           "save_value_to_context": whatsapp_save_value_to_context
                           }
