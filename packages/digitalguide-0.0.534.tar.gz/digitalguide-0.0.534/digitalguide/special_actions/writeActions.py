import mimetypes
import os
from datetime import datetime

from pywa.types import MessageType
from digitalguide.wa_utils import get_message_text


def init_space():
    import boto3
    from configparser import ConfigParser

    config = ConfigParser()
    config.read("config.ini")

    session = boto3.session.Session()
    s3_client = session.client('s3',
                            region_name=config["space"]["region_name"],
                            endpoint_url=config["space"]["endpoint_url"],
                            aws_access_key_id=os.getenv('SPACES_KEY'),
                            aws_secret_access_key=os.getenv('SPACES_SECRET'))
    return s3_client


def whatsapp_write_photo(client, update, context, bucket, folder):
    media_url_obj = client.get_media_url(update.image.id)
    content = client.download_media(url=media_url_obj.url, in_memory=True)
    mime_type = media_url_obj.mime_type
    extension = (mimetypes.guess_extension(mime_type) or ".jpg").lstrip(".")

    s3_client = init_space()
    user_id = update.from_user.wa_id

    s3_client.put_object(Bucket=bucket,
                    Key=folder + "/" + str(datetime.now()) + "_" + str(user_id) + "." + extension,
                    Body=content,
                    ContentType=mime_type,
                    ACL='private')


def whatsapp_write_message(client, update, context, bucket, folder):
    message = get_message_text(update)

    s3_client = init_space()
    user_id = update.from_user.wa_id

    s3_client.put_object(Bucket=bucket,
                    Key=folder + "/" + str(datetime.now()) + "_" + str(user_id) + ".txt",
                    Body=message,
                    ContentType="text/plain",
                    ACL='private')


def whatsapp_write_voice(client, update, context, bucket, folder):
    media_url_obj = client.get_media_url(update.audio.id)
    content = client.download_media(url=media_url_obj.url, in_memory=True)
    mime_type = media_url_obj.mime_type
    extension = (mimetypes.guess_extension(mime_type) or ".ogg").lstrip(".")

    s3_client = init_space()
    user_id = update.from_user.wa_id

    s3_client.put_object(Bucket=bucket,
                    Key=folder + "/" + str(datetime.now()) + "_" + str(user_id) + "." + extension,
                    Body=content,
                    ContentType=mime_type,
                    ACL='private')


def whatsapp_write_document(client, update, context, bucket, folder):
    media_url_obj = client.get_media_url(update.document.id)
    content = client.download_media(url=media_url_obj.url, in_memory=True)
    mime_type = media_url_obj.mime_type
    extension = update.document.filename.split(".")[-1]

    s3_client = init_space()
    user_id = update.from_user.wa_id

    s3_client.put_object(Bucket=bucket,
                    Key=folder + "/" + str(datetime.now()) + "_" + str(user_id) + "." + extension,
                    Body=content,
                    ContentType=mime_type,
                    ACL='private')


def whatsapp_write_video(client, update, context, bucket, folder):
    media_url_obj = client.get_media_url(update.video.id)
    content = client.download_media(url=media_url_obj.url, in_memory=True)
    mime_type = media_url_obj.mime_type
    extension = (mimetypes.guess_extension(mime_type) or ".mp4").lstrip(".")

    s3_client = init_space()
    user_id = update.from_user.wa_id

    s3_client.put_object(Bucket=bucket,
                    Key=folder + "/" + str(datetime.now()) + "_" + str(user_id) + "." + extension,
                    Body=content,
                    ContentType=mime_type,
                    ACL='private')


def whatsapp_write(client, update, context, bucket, folder):
    if update.type == MessageType.AUDIO:
        whatsapp_write_voice(client, update, context, bucket, folder)
    elif update.type == MessageType.IMAGE:
        whatsapp_write_photo(client, update, context, bucket, folder)
    elif update.type == MessageType.DOCUMENT:
        whatsapp_write_document(client, update, context, bucket, folder)
    elif update.type == MessageType.VIDEO:
        whatsapp_write_video(client, update, context, bucket, folder)
    elif get_message_text(update) != "":
        whatsapp_write_message(client, update, context, bucket, folder)
    else:
        raise NotImplementedError("This type of update can not be saved")


whatsapp_action_functions = {"write_photo": whatsapp_write_photo,
                             "write_message": whatsapp_write_message,
                             "write_voice": whatsapp_write_voice,
                             "write_document": whatsapp_write_document,
                             "write": whatsapp_write
                             }
