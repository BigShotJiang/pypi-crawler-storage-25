import logging
from types import SimpleNamespace

from pywa import types


def send_interactive_list(client, recipient_id, body_text, button_text, sections,
                          header_text=None, footer_text=None):
    section_objs = [
        types.SectionList.Section(
            title=s["title"],
            rows=[
                types.SectionList.Section.Row(
                    title=r["title"],
                    callback_data=r["id"],
                    description=r.get("description", "")
                )
                for r in s["rows"]
            ]
        )
        for s in sections
    ]
    logging.info(f"Sending interactive list to {recipient_id}")
    return client.send_message(
        to=recipient_id,
        text=body_text,
        header=header_text,
        footer=footer_text,
        buttons=types.SectionList(button_title=button_text, sections=section_objs)
    )


def send_carousel(client, recipient_id: str, body_text: str, cards: list):
    new_cards = []
    for i, card in enumerate(cards):
        new_card = {
            "card_index": i,
            "type": "cta_url",
            "header": {
                "type": "image",
                "image": {
                    "link": card["header"]
                }
            },
            "body": {
                "text": card["body"]
            },
            "action": {
                "name": "cta_url",
                "parameters": {
                    "display_text": card["action_text"],
                    "url": card["action_url"]
                }
            }
        }
        new_cards.append(new_card)

    carousel_dict = {
        "type": "carousel",
        "body": {
            "text": body_text
        },
        "action": {
            "cards": new_cards
        }
    }

    data = {
        "messaging_product": "whatsapp",
        "to": recipient_id,
        "type": "interactive",
        "recipient_type": "individual",
        "interactive": carousel_dict,
    }

    logging.info(f"Sending carousel to {recipient_id}")
    r = client.api.send_raw_request("POST", f"/{client.phone_id}/messages", json=data)
    if r and "messages" in r:
        return SimpleNamespace(id=r["messages"][0]["id"])
    logging.info(f"Carousel not sent to {recipient_id}")
    return None


def send_sticker(client, sticker: str, recipient_id: str, link=True):
    logging.info(f"Sending sticker to {recipient_id}")
    if link:
        return client.send_sticker(to=recipient_id, sticker=sticker)
    return client.send_sticker(to=recipient_id, sticker=types.MediaId(sticker))


def send_typing_indicator(client, message_id: str, recipient_id: str):
    client.indicate_typing(message_id)
