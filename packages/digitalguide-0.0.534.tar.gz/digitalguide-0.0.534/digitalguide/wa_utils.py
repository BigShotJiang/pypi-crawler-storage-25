from pywa.types import Message, CallbackButton, CallbackSelection, MessageType


def get_message_text(update: Message | CallbackButton | CallbackSelection) -> str:
    if isinstance(update, Message):
        if update.type == MessageType.TEXT:
            return update.text or ""
        return ""
    elif isinstance(update, CallbackButton):
        return update.title
    elif isinstance(update, CallbackSelection):
        if update.description:
            return f"{update.title} {update.description}"
        return update.title
    return ""
