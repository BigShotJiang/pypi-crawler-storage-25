from digitalguide.send_utils import send_interactive_list, send_sticker, send_typing_indicator, send_carousel
from digitalguide.db_objects import WhatsAppInteraction, WhatsAppUser
from digitalguide.wa_utils import get_message_text
from pywa import types
from time import sleep

import logging
logging.getLogger(__name__).addHandler(logging.NullHandler())

class Action():
    def __init__(self, actions, action_functions={}):
        self.actions = actions
        self.action_functions = action_functions

    def __call__(self, client, update, context, r_unsend_messages=None):
        logging.info("Before sending typing indicator")
        send_typing_indicator(client, update.id, update.from_user.wa_id)

        logging.info("Before Whatsapp User creation")
        wa_user = WhatsAppUser.objects(WaId=update.from_user.wa_id).first()
        if not wa_user:
            wa_user = WhatsAppUser(ProfileName=update.from_user.name,
                                   WaId=update.from_user.wa_id)

        logging.info("Before Whatsapp Interaction creation")
        wa_interaction = WhatsAppInteraction(
                            ProfileName=update.from_user.name,
                            WaId=update.from_user.wa_id,
                            text=get_message_text(update),
                            state=context["state"]
                            )

        for item in self.actions:
            if item["type"] == "return":
                return item["state"]

            max_wait_itteration = 100
            first_iter = True
            for i in range(max_wait_itteration):
                if not r_unsend_messages.get(update.from_user.wa_id):
                    logging.info("Previous messages were send within {} s.".format(i * 0.1))
                    break
                if first_iter:
                    first_iter = False
                    send_typing_indicator(client, update.id, update.from_user.wa_id)
                sleep(0.1)
            else:
                logging.info("Previous messages were not send within {} s.".format(max_wait_itteration * 0.1))

            try:
                result = None
                if item["type"] == "message":
                    placeholder_dict = {**context}
                    placeholder_dict["profile_name"] = update.from_user.name
                    placeholder_dict["echo"] = get_message_text(update)

                    if "reply_buttons" in item.keys():
                        result = client.send_message(
                            to=update.from_user.wa_id,
                            text=item["text"].format(**placeholder_dict),
                            footer=item.get("footer"),
                            buttons=[
                                types.Button(title=btn["text"], callback_data=btn["id"])
                                for btn in item["reply_buttons"]
                            ]
                        )

                    elif "button" in item.keys() and "section_title" in item.keys():
                        section_dict = [
                            {
                                "title": item["section_title"],
                                "rows": [],
                            }
                        ]

                        for row in item["rows"]:
                            row_dict = {"id": row["id"],
                                        "title": row["title"],
                                        "description": row.get("description", "")}
                            section_dict[0]["rows"].append(row_dict)

                        result = send_interactive_list(client,
                                            recipient_id=update.from_user.wa_id,
                                            body_text=item["text"].format(**placeholder_dict),
                                            button_text=item["button"],
                                            sections=section_dict,
                                            header_text=item.get("header", None),
                                            footer_text=item.get("footer", None))

                    else:
                        client.send_message(
                            to=update.from_user.wa_id,
                            text=item["text"].format(**placeholder_dict)
                        )

                elif item["type"] == "carousel":
                    result = send_carousel(client,
                        recipient_id=update.from_user.wa_id,
                        body_text=item["text"],
                        cards=item["cards"]
                    )

                elif item["type"] == "venue":
                    result = client.send_location(
                        to=update.from_user.wa_id,
                        latitude=item["latitude"],
                        longitude=item["longitude"],
                        name=item["title"],
                        address=item["address"],
                    )

                elif item["type"] == "photo":
                    caption = item.get("caption")
                    if "url" in item.keys():
                        result = client.send_image(
                            to=update.from_user.wa_id,
                            image=item["url"],
                            caption=caption
                        )
                    else:
                        result = client.send_image(
                            to=update.from_user.wa_id,
                            image=types.MediaId(item["id"]),
                            caption=caption
                        )

                elif item["type"] == "video":
                    result = client.send_video(
                        to=update.from_user.wa_id,
                        video=item["url"]
                    )

                elif item["type"] == "sticker":
                    result = send_sticker(client,
                        item["url"],
                        update.from_user.wa_id
                    )

                elif item["type"] == "media_group":
                    pass

                elif item["type"] == "audio" or item["type"] == "voice":
                    if "url" in item.keys():
                        result = client.send_audio(
                            to=update.from_user.wa_id,
                            audio=item["url"]
                        )
                    else:
                        result = client.send_audio(
                            to=update.from_user.wa_id,
                            audio=types.MediaId(item["id"])
                        )

                elif item["type"] == "poll":
                    message = item["question"] + "\n"
                    for option in item["options"]:
                        message += option + "\n"
                    result = client.send_message(to=update.from_user.wa_id, text=message)

                elif item["type"] == "function":
                    arguments = {i: item[i]
                                for i in item if i != 'type' and i != 'func'}
                    if item["func"] in self.action_functions.keys():
                        self.action_functions[item["func"]](
                            client, update, context, **arguments)
                    else:
                        module, function = item["func"].split(":")

                        if module == "contextActions":
                            from digitalguide.special_actions import contextActions
                            contextActions.whatsapp_action_functions[function](client, update, context, **arguments)
                        elif module == "imageActions":
                            from digitalguide.special_actions import imageActions
                            imageActions.whatsapp_action_functions[function](client, update, context, **arguments)
                        elif module == "listenfrageActions":
                            from digitalguide.special_actions import listenfrageActions
                            listenfrageActions.whatsapp_action_functions[function](client, update, context, **arguments)
                        elif module == "schaetzfragenActions":
                            from digitalguide.special_actions import schaetzfragenActions
                            schaetzfragenActions.whatsapp_action_functions[function](client, update, context, **arguments)
                        elif module == "writeActions":
                            from digitalguide.special_actions import writeActions
                            writeActions.whatsapp_action_functions[function](client, update, context, **arguments)

                if result:
                    r_unsend_messages.set(update.from_user.wa_id, result.id, ex=10)
            except Exception:
                logging.exception("Error during the Execution of action: {item}")

        wa_interaction.save()
