<div align="center">

# NanoIndex

**Turn any PDF into searchable trees and visual knowledge graphs.**
**Ask questions, get answers with page citations.**

<p>
  <a href="https://github.com/nanonets/nanoindex"><img src="https://img.shields.io/badge/GitHub-NanoIndex-181717?style=for-the-badge&logo=github&logoColor=white" /></a>
  <a href="https://nanonets.com/research/nanonets-ocr-3"><img src="https://img.shields.io/badge/Built%20on-Nanonets%20OCR--3-546FFF?style=for-the-badge" /></a>
  <a href="https://www.apache.org/licenses/LICENSE-2.0"><img src="https://img.shields.io/badge/License-Apache%202.0-20C997?style=for-the-badge" /></a>
</p>

<p>
  <a href="https://docstrange.nanonets.com/app"><img src="https://img.shields.io/badge/Get%20API%20Key-Free%2010K%20Pages-FCC419?style=for-the-badge" /></a>
  <a href="#get-started-in-3-steps"><img src="https://img.shields.io/badge/Quick%20Start-3%20Steps-FF6B6B?style=for-the-badge" /></a>
</p>

| Benchmark | Documents | Avg Pages | Accuracy |
|---|---|---|---|
| FinanceBench (SEC 10-K filings) | 84 | 143 | **94.5%** |
| DocBench Legal (court filings, legislation) | 51 | 54 | **96.0%** |

</div>

No vector databases. No chunk tuning. No embeddings.

NanoIndex reads your document, understands its structure (headings, sections, tables, figures), and builds a tree you can search with plain English. Built on [Nanonets OCR-3](https://nanonets.com/research/nanonets-ocr-3) for extraction. Fully open source.

---

## Get Started in 3 Steps

### 1. Install

```bash
pip install nanoindex
```

### 2. Get your free API key

Go to [docstrange.nanonets.com/app](https://docstrange.nanonets.com/app) and create an API key.

Extract first 10,000 pages for free. After that, $0.01 per page.

```bash
export NANONETS_API_KEY=your_key_here
```

### 3. Ask a question

```python
import nanoindex

tree = nanoindex.index("report.pdf")
answer = nanoindex.ask("What was the revenue?", tree)

print(answer.content)
print(answer.citations)  # page numbers + section references
```

That's it. Three lines to go from PDF to cited answer.

---

## How It Works

### Indexing: PDF to tree + graph

<p align="center">
  <img src="assets/ingestion-pipeline.png" alt="Ingestion Pipeline" width="800"/>
</p>

### Querying: Fast Mode (default)

<p align="center">
  <img src="assets/query-fast.png" alt="Query Pipeline — Fast Mode" width="800"/>
</p>

### Querying: Agentic Mode (highest accuracy)

<p align="center">
  <img src="assets/query-agentic.png" alt="Query Pipeline — Agentic Mode" width="800"/>
</p>

---

## What Can You Do With It

### Ask questions about documents

```python
answer = nanoindex.ask("What was Q3 gross margin?", tree)
print(answer.content)    # "Gross margin was 42.3% in Q3..."
print(answer.citations)  # [Citation(title="Income Statement", pages=[45, 46])]
```

### Use the command line

```bash
nanoindex ask report.pdf "What was the revenue?"
nanoindex index report.pdf -o tree.json
nanoindex search tree.json "capital expenditure"
```

### Save and reuse trees

```python
from nanoindex.utils.tree_ops import save_tree, load_tree

save_tree(tree, "my_tree.json")
tree = load_tree("my_tree.json")  # instant, no re-extraction
```

### Visualize your tree

```python
nanoindex.visualize(tree)  # opens interactive dashboard in browser
```

Or from the command line:

```bash
nanoindex viz tree.json
```

### Use any LLM for answering

NanoIndex uses Nanonets OCR-3 for extraction. For the reasoning step, just pass a model name. Provider URLs and API keys are auto-detected from environment variables.

```python
from nanoindex import NanoIndex

# OpenAI — reads OPENAI_API_KEY from env
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="gpt-4o")

# Anthropic — reads ANTHROPIC_API_KEY from env
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="claude-sonnet-4-6")

# Google Gemini — reads GOOGLE_API_KEY from env
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="gemini-2.5-flash")

# Groq (Llama) — reads GROQ_API_KEY from env
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="llama-3.3-70b-versatile")

# Or pass keys explicitly
ni = NanoIndex(
    nanonets_api_key="...",
    reasoning_llm_model="gpt-4o",
    reasoning_llm_api_key="sk-...",
)
```

Works with any OpenAI-compatible endpoint (Ollama, vLLM, Together, etc.) by passing `reasoning_llm_base_url`.

### Search across multiple documents

```python
from nanoindex import NanoIndex, DocumentStore

ni = NanoIndex(nanonets_api_key="...")
store = DocumentStore()

for pdf in ["q1.pdf", "q2.pdf", "q3.pdf"]:
    tree = ni.index(pdf)
    store.add(tree)

answer = ni.multi_ask("Compare revenue across quarters", store)
```

---

## Query Modes

When you call `nanoindex.index()`, the tree, entity graph, and embeddings are all built automatically. Queries use the graph by default for fast, cheap retrieval.

| Mode | Retrieval | Answer | Best for |
|---|---|---|---|
| `fast` (default) | Embedding + graph pre-filter, LLM sees ~20 nodes | Text | Most queries, cheapest |
| `fast_vision` | Same | Text + page images | Charts, figures, layouts |
| `agentic` | LLM navigates full tree, multiple rounds | Text | Complex multi-step questions |
| `agentic_vision` | Same | Text + page images | Highest accuracy, most expensive |

```python
# Default — fast, uses entity graph (cheapest)
answer = ni.ask("What was revenue?", tree)

# With page images for visual content
answer = ni.ask("Describe Figure 3", tree, mode="fast_vision", pdf_path="report.pdf")

# Maximum accuracy — LLM reads the full tree
answer = ni.ask("Compare Q3 margins across segments", tree, mode="agentic_vision", pdf_path="report.pdf")
```

---

## Entity Graph

Every indexed document gets an entity graph built automatically. The graph extracts entities (companies, metrics, dates, people) and their relationships from every section.

At query time: embedding search finds candidate nodes, the graph expands to related sections, and the LLM only reads ~20 nodes instead of 300+. This makes the default `fast` mode 3x cheaper than sending the full tree.

You can visualize the graph in the dashboard under the "Entities" tab.

---

## Open-Source Mode (No API Key for Parsing)

NanoIndex can also work without Nanonets OCR-3, using PyMuPDF for extraction:

```python
ni = NanoIndex(parser="pymupdf")
tree = ni.index("report.pdf")  # no API key needed for parsing
```

PyMuPDF gives you basic text and table extraction. The tree will be simpler (no heading detection, no hierarchy), but it works for quick experiments. For production quality, use Nanonets OCR-3.

---

## Benchmarks

Tested on real-world documents with LLM-as-judge evaluation:

| Benchmark | Documents | Avg Pages | Accuracy |
|---|---|---|---|
| FinanceBench (SEC 10-K filings) | 84 | 143 | **94.5%** |
| DocBench Legal (court filings, legislation) | 51 | 54 | **96.0%** |

Evidence page retrieval accuracy: **93.3%**

### FinanceBench Evaluation Architecture

<p align="center">
  <img src="assets/financebench-architecture.png" alt="FinanceBench Architecture" width="800"/>
</p>

---

## How It Compares

| | Traditional RAG | NanoIndex |
|---|---|---|
| Indexing | Chunk + embed + vector DB | Extract + build tree |
| Retrieval | Similarity search | LLM reasons over structure |
| Tables | Poorly handled | Natively extracted |
| Figures | Not supported | Vision mode |
| Scanned docs | Needs separate OCR | Built-in |
| Structure-aware | No | Yes |
| Citations | Approximate | Exact page + bounding box |

---

## Project Structure

```
nanoindex/
  __init__.py         # Public API: index(), search(), ask(), visualize()
  cli.py              # Command line interface
  models.py           # Data models (TreeNode, DocumentTree, Entity, etc.)
  config.py           # Configuration

  core/
    extractor.py      # Nanonets OCR-3 extraction
    tree_builder.py   # Deterministic tree construction
    enricher.py       # LLM summary generation
    retriever.py      # Tree search
    generator.py      # Answer generation (text + vision)
    agentic.py        # Multi-round retrieval
    fast_retriever.py # Embedding + graph retrieval
    entity_extractor.py   # Entity/relationship extraction
    graph_builder.py      # NetworkX graph operations
    embedder.py           # Node embedding + cosine search
    parsers/              # Pluggable parsers (nanonets, pymupdf)
    modal_processors/     # Image + table processing for graph

  utils/
    tree_ops.py       # Save, load, traverse trees
    tokens.py         # Token counting
    pdf.py            # PDF page rendering

viz/                  # Interactive visualization dashboard (Next.js)
examples/             # Usage examples
benchmarks/           # Evaluation scripts
```

---

## Development

```bash
git clone https://github.com/nanonets/nanoindex.git
cd nanoindex
pip install -e ".[dev]"
pytest
```

---

## License

Apache 2.0 — see [LICENSE](LICENSE).
