"""Agent_BRICK - A lightweight HTTP client for BRICK Knowledge Graph API."""

__version__ = "0.1.3"

# 延迟加载，避免循环导入
__all__ = ["query_relation", "rank", "enrich", "read_graph", "save_graph", "data2nxg", "combine_graph"]

def __getattr__(name):
    if name == "query_relation":
        from querygraph import query_relation
        return query_relation
    elif name == "rank":
        from rankgraph import rank
        return rank
    elif name == "enrich":
        from rankgraph import enrich
        return enrich
    elif name == "read_graph":
        from graphadapter import read_graph
        return read_graph
    elif name == "save_graph":
        from graphadapter import save_graph
        return save_graph
    elif name == "data2nxg":
        from graphadapter import data2nxg
        return data2nxg
    elif name == "combine_graph":
        from graphadapter import combine_graph
        return combine_graph
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
