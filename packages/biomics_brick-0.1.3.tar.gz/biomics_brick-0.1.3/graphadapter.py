"""Agent_BRICK graph adapter module - Unified graph conversion and I/O.

Consolidates BRICK preprocess.py graph functions into 4 unified APIs:
- read_graph:  Read graph files (.svg, .pkl, .graphml)
- save_graph:  Save graphs to files (.pkl, .svg, .pdf, .graphml)
- data2nxg:    Convert data (DataFrame/AnnData/PAGA) to NetworkX graph
- combine_graph: Combine omics and knowledge graphs
"""

import os
import argparse
import sys
import pickle
import xml.etree.ElementTree as ET
from typing import Optional

import networkx as nx
import pandas as pd
from networkx.drawing.nx_pydot import to_pydot
from scipy import sparse


# ─── Internal helpers ────────────────────────────────────────────────

def _remove_namespace(tree):
    """Remove namespaces from XML tags for easier SVG parsing."""
    for elem in tree.iter():
        if '}' in elem.tag:
            elem.tag = elem.tag.split('}', 1)[1]
    return tree


def _query_df2nxg(df, directed=False, reverse_direct=False):
    """Convert query result DataFrame (entity-entity pairs) to NetworkX graph."""
    nxg = nx.DiGraph() if directed else nx.Graph()

    for x, y in zip(df['path.0.name'], df['path.0.type']):
        nxg.add_node(x, type=y if y == 'Gene' else "KG_" + y)

    for x, y in zip(df['path.2.name'], df['path.2.type']):
        nxg.add_node(x, type=y if y == 'Gene' else "KG_" + y)

    for x, y in zip(df['path.0.name'], df['path.2.name']):
        if reverse_direct:
            nxg.add_edge(y, x)
        else:
            nxg.add_edge(x, y)
    return nxg


def _count_df2nxg(df, directed=False, reverse_direct=False):
    """Convert count DataFrame (gene-list → entity) to NetworkX graph."""
    nxg = nx.DiGraph() if directed else nx.Graph()

    tmp = set()
    for x in df['path.0.name']:
        for y in x:
            tmp.add(y)
    for x in tmp:
        nxg.add_node(x, type='Gene')

    for x, y in zip(df['path.2.name'], df['path.2.type']):
        nxg.add_node(x, type="KG_" + y)

    for x, y in zip(df['path.0.name'], df['path.2.name']):
        for z in x:
            if reverse_direct:
                nxg.add_edge(y, z)
            else:
                nxg.add_edge(z, y)
    return nxg


def _read_svg_graph(svg_file, node_class='node', edge_class='edge',
                    default_node_color='black', default_edge_color='black'):
    """Parse SVG file into NetworkX MultiDiGraph."""
    tree = ET.parse(svg_file)
    tree = _remove_namespace(tree)
    root = tree.getroot()

    G = nx.MultiDiGraph()

    for node in root.findall(f".//g[@class='{node_class}']"):
        title = node.find('title')
        title_text = title.text.strip() if title is not None else None
        shape, color = None, default_node_color
        for shape_tag in ['ellipse', 'polygon', 'circle', 'rect']:
            element = node.find(shape_tag)
            if element is not None:
                shape = shape_tag
                color = element.attrib.get('stroke', default_node_color)
                break
        if title_text:
            G.add_node(title_text, shape=shape, color=color)

    for edge in root.findall(f".//g[@class='{edge_class}']"):
        title = edge.find('title')
        title_text = title.text.strip() if title is not None else None
        path = edge.find('path')
        color = default_edge_color
        if path is not None:
            color = path.attrib.get('stroke', default_edge_color)
        if title_text and '->' in title_text:
            source, target = map(str.strip, title_text.split('->'))
            G.add_edge(source, target, color=color)

    return G


# ─── Public API ──────────────────────────────────────────────────────

def read_graph(file_path, **kwargs):
    """
    Read a graph file and return a NetworkX graph object.

    Supports .svg, .pkl, .graphml formats.
    For .svg files, optional kwargs: node_class, edge_class,
    default_node_color, default_edge_color.

    Args:
        file_path: Path to the graph file.
        **kwargs: Additional parameters (for SVG: node_class, edge_class,
                  default_node_color, default_edge_color).

    Returns:
        networkx.Graph or networkx.DiGraph or networkx.MultiDiGraph:
            The parsed graph object.

    Raises:
        ValueError: If file format is unsupported.
    """
    ext = os.path.splitext(file_path)[-1].lower()
    if ext == '.svg':
        return _read_svg_graph(file_path, **kwargs)
    elif ext == '.pkl':
        with open(file_path, 'rb') as f:
            return pickle.load(f)
    elif ext == '.graphml':
        return nx.read_graphml(file_path)
    else:
        raise ValueError(f"Unsupported file format: {ext}. Use .svg, .pkl, or .graphml")


def save_graph(graph, file_name):
    """
    Save a NetworkX graph to file.

    Supports .pkl, .svg, .pdf, .graphml formats.
    Automatically handles edge styling for visual formats (svg/pdf).

    Args:
        graph: NetworkX graph object.
        file_name: Output file name with extension (e.g., 'network.pkl').

    Raises:
        ValueError: If file format is unsupported.
    """
    file_format = file_name.split(".")[-1]

    # Apply edge styling for visual formats
    for u, v, data in graph.edges(data=True):
        if "color" in data:
            if data["color"] == "green":
                data["arrowhead"] = "normal"
            else:
                data["arrowhead"] = "none"

    if file_format == "pkl":
        with open(file_name, "wb") as f:
            pickle.dump(graph, f)
    elif file_format == "svg":
        to_pydot(graph).write_svg(file_name)
    elif file_format == "pdf":
        to_pydot(graph).write_pdf(file_name)
    elif file_format == "graphml":
        nx.write_graphml(graph, file_name)
    else:
        raise ValueError(f"Unsupported format: {file_format}. Use 'pkl', 'svg', 'pdf', or 'graphml'.")

    print(f"Graph successfully saved to {file_name}")


def data2nxg(data, data_type='df', directed=False, reverse_direct=False,
             cell_neighbor=False, **kwargs):
    """
    Convert data to a NetworkX graph.

    Unified interface covering DataFrame, AnnData, and PAGA conversions.

    Args:
        data: Input data object.
        data_type: Type of input data:
            - 'df': DataFrame from query results (covers df2nxg).
                    Auto-detects entity-entity vs gene-list format.
            - 'adata': AnnData single-cell object (covers adata2nxg).
            - 'paga': AnnData with PAGA results (covers paga2nx).
        directed: Whether to create a directed graph (for 'df' and 'adata').
        reverse_direct: Whether to reverse edge direction (for 'df' and 'adata').
        cell_neighbor: Whether to add cell-cell adjacency edges
                       from adata.obsp['connectivities'] (for 'adata' only).
        **kwargs: Reserved for future extensions.

    Returns:
        networkx.Graph or networkx.DiGraph or networkx.MultiDiGraph:
            The converted graph.

    Raises:
        ValueError: If data_type is unsupported.
    """
    if data_type == 'df':
        tmp = list(data['path.0.name'])[0]
        if isinstance(tmp, list):
            return _count_df2nxg(data, directed=directed, reverse_direct=reverse_direct)
        else:
            return _query_df2nxg(data, directed=directed, reverse_direct=reverse_direct)

    elif data_type == 'adata':
        nxg = nx.DiGraph() if directed else nx.Graph()

        if sparse.issparse(data.X):
            expr = data.X.tocoo()
        else:
            expr = sparse.coo_array(data.X)
            print('adata.X seems not a sparse matrix, please check whether it is raw count or log normalized count')

        celllist = data.obs_names
        genelist = data.var_names

        for x in genelist:
            nxg.add_node(x, type='Gene')
        for x in celllist:
            nxg.add_node(x, type='Omics_Cell')

        for x, y in zip(expr.row, expr.col):
            if reverse_direct:
                nxg.add_edge(genelist[y], celllist[x])
            else:
                nxg.add_edge(celllist[x], genelist[y])

        if cell_neighbor:
            if 'connectivities' in data.obsp:
                neighbor = data.obsp['connectivities'].tocoo()
                for x, y in zip(neighbor.row, neighbor.col):
                    nxg.add_edge(celllist[x], celllist[y])
            else:
                print('adata must run sc.pp.neighbors first when cell_neighbor=True, skipping cell neighbor edges')

        return nxg

    elif data_type == 'paga':
        baseline_size_max = 10
        baseline_size = 20
        baseline_weight_max = 5
        baseline_weight = 10

        adj = pd.DataFrame(data.uns['paga']['connectivities_tree'].todense())
        group = data.uns['paga']['groups']
        categories = data.obs[group].cat.categories

        adj.columns = categories
        adj.index = categories
        adj = adj.loc[categories, categories]

        G = nx.from_pandas_adjacency(adj, create_using=nx.MultiDiGraph)

        name2color = {x: y for x, y in zip(categories, data.uns[f'{group}_colors'])}

        tmp = data.obs.copy()
        tmp['0'] = 0
        name2size = tmp[[group, '0']].groupby(group).count().to_dict()['0']
        max_size = max(name2size.values())
        name2size = {x: y * baseline_size_max / max_size + baseline_size
                     for x, y in name2size.items()}

        for x in G.nodes:
            G.nodes[x]['original_name'] = x
            G.nodes[x]['color'] = name2color[x]
            G.nodes[x]['size'] = name2size[x]

        for edge in G.edges:
            e = G.edges[edge]
            e['weight'] = e['weight'] * baseline_weight_max + baseline_weight
            e['color'] = 'black'
            e['arrows'] = False

        return G

    else:
        raise ValueError(f"Unsupported data_type: {data_type}. Use 'df', 'adata', or 'paga'")


def combine_graph(adata, df, directed=False, omics_reverse_direct=False,
                  kg_reverse_direct=False, cell_neighbor=False):
    """
    Construct an integrated network graph by combining single-cell omics
    data (adata) and a knowledge graph (df).

    Args:
        adata: AnnData object containing single-cell transcriptomics data.
        df: DataFrame containing edge data from a knowledge graph.
        directed: Whether to create a directed graph.
        omics_reverse_direct: Whether to reverse edge direction in the
                              omics network.
        kg_reverse_direct: Whether to reverse edge direction in the
                           knowledge graph network.
        cell_neighbor: Whether to include cell-cell adjacency information.

    Returns:
        networkx.Graph or networkx.DiGraph: Combined graph merging
            single-cell data and knowledge graph.
    """
    Omics_Graph = data2nxg(adata, data_type='adata', directed=directed,
                           reverse_direct=omics_reverse_direct,
                           cell_neighbor=cell_neighbor)
    KG_Graph = data2nxg(df, data_type='df', directed=directed,
                        reverse_direct=kg_reverse_direct)
    return nx.compose(Omics_Graph, KG_Graph)


# ─── CLI ─────────────────────────────────────────────────────────────

def _cli_main():
    """CLI entry point for BRICK_ga command."""
    parser = argparse.ArgumentParser(
        description="BRICK_ga - Graph adapter: read, convert, save, and combine graphs",
        usage='BRICK_ga <command> [options]'
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # --- read command ---
    read_parser = subparsers.add_parser('read', help='Read a graph file and display info')
    read_parser.add_argument("-i", "--input", required=True,
                             help="Input graph file (.svg/.pkl/.graphml)")

    # --- convert command ---
    convert_parser = subparsers.add_parser('convert',
                                           help='Convert graph file to another format')
    convert_parser.add_argument("-i", "--input", required=True,
                                help="Input graph file")
    convert_parser.add_argument("-o", "--output", required=True,
                                help="Output graph file (.pkl/.svg/.pdf/.graphml)")

    # --- df2nxg command ---
    df_parser = subparsers.add_parser('df2nxg',
                                      help='Convert DataFrame CSV to NetworkX graph file')
    df_parser.add_argument("-i", "--input", required=True,
                           help="Input CSV file (query result DataFrame)")
    df_parser.add_argument("-o", "--output", required=True,
                           help="Output graph file (.pkl/.svg/.graphml)")
    df_parser.add_argument("--directed", action="store_true",
                           help="Create directed graph")
    df_parser.add_argument("--reverse", action="store_true",
                           help="Reverse edge direction")

    # --- info command ---
    info_parser = subparsers.add_parser('info', help='Show graph file details')
    info_parser.add_argument("-i", "--input", required=True,
                             help="Input graph file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    try:
        if args.command == 'read':
            G = read_graph(args.input)
            print(f"Graph loaded: {args.input}")
            print(f"  Nodes: {G.number_of_nodes()}")
            print(f"  Edges: {G.number_of_edges()}")

        elif args.command == 'convert':
            G = read_graph(args.input)
            print(f"Read graph from {args.input} "
                  f"({G.number_of_nodes()} nodes, {G.number_of_edges()} edges)")
            save_graph(G, args.output)

        elif args.command == 'df2nxg':
            df = pd.read_csv(args.input)
            if df.empty:
                print("Error: Input DataFrame is empty", file=sys.stderr)
                sys.exit(1)
            print(f"Loaded {len(df)} rows from {args.input}")
            G = data2nxg(df, data_type='df',
                         directed=args.directed, reverse_direct=args.reverse)
            print(f"Converted to graph: {G.number_of_nodes()} nodes, "
                  f"{G.number_of_edges()} edges")
            save_graph(G, args.output)

        elif args.command == 'info':
            G = read_graph(args.input)
            print(f"File: {args.input}")
            print(f"  Type: {type(G).__name__}")
            print(f"  Nodes: {G.number_of_nodes()}")
            print(f"  Edges: {G.number_of_edges()}")
            if G.number_of_nodes() > 0:
                sample_nodes = list(G.nodes(data=True))[:5]
                print(f"  Sample nodes: {sample_nodes}")
            if G.number_of_edges() > 0:
                sample_edges = list(G.edges(data=True))[:5]
                print(f"  Sample edges: {sample_edges}")

    except FileNotFoundError as e:
        print(f"Error: File not found - {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    _cli_main()
