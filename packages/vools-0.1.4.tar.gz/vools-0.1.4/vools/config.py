"""
vools 配置文件

基于 config.template.py 创建
"""

# 数据库配置（如果需要）
DATABASE_CONFIG = {
    'host': None,              # 数据库主机，需要填写
    'port': None,              # 数据库端口，需要填写
    'user': None,              # 数据库用户，需要填写
    'password': None,          # 数据库密码，需要填写
    'database': None,          # 数据库名称，需要填写
}

# 其他配置
OTHER_CONFIG = {
    'cache_duration': 3,       # 缓存持续时间（秒）
    'max_workers': 10,         # 最大工作线程数
    'retry_times': 3,          # 重试次数
    'default_force_when': None, # 默认强制刷新条件,应用于 cache.py persist 装饰器
    'default_target_folder': None, # 默认目标文件夹,应用于 cache.py persist 装饰器
    'NONE_is_None': False, # 是否将 NONE 视为 None,应用于 seq.py Seq 类
}

# 敏感路径配置
PATHS = {
    'base_path': None,         # 基础路径，需要填写
    'data_path': None,         # 数据路径，需要填写
    'output_path': None,       # 输出路径，需要填写
}

# 配置管理器
class ConfigManager:
    """配置管理器"""
    
    def __init__(self):
        self.database = DATABASE_CONFIG
        self.other = OTHER_CONFIG
        self.paths = PATHS

# 全局配置实例
config = ConfigManager()
