"""
DeltaCAT REST client — lightweight SDK for cross-cloud job execution.

Provides type-safe wrappers for the DeltaCAT REST API with automatic
credential refresh and background heartbeating. Workers on any cloud
or on-prem network use this to interact with the DeltaCAT API server
without needing the full DeltaCAT catalog internals installed.

Usage::

    from deltacat_client import DeltaCATClient

    client = DeltaCATClient("https://deltacat-api.example.com")

    job = client.claim_job()
    if job is not None:
        client.heartbeat(job.job_id, progress=0.5, message="halfway")
        client.complete(job.job_id, records_processed=1000)

Dependencies: stdlib + requests only.
"""

from deltacat_client.client import DeltaCATClient
from deltacat_client.models import ClaimedJob, JobStatus

__all__ = ["DeltaCATClient", "ClaimedJob", "JobStatus"]
