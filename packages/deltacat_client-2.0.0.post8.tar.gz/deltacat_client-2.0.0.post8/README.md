# DeltaCAT Client

`deltacat-client` is a lightweight REST client SDK for the DeltaCAT API server.

It is intended for workers and external integrations that need to:

- claim jobs
- heartbeat progress
- report completion or failure
- inspect job status

without installing the full DeltaCAT compute, storage, or server runtime stack.

## Usage

```python
from deltacat_client import DeltaCATClient

client = DeltaCATClient("https://deltacat-api.example.com")

job = client.claim_job()
if job is not None:
    client.heartbeat(job.job_id, progress=0.5, message="halfway")
    client.complete(job.job_id, records_processed=1000)
```
