"""
Admin interface for MQTT plugin models.
"""

from django.contrib import admin
from .models import MQTTConfiguration


@admin.register(MQTTConfiguration)
class MQTTConfigurationAdmin(admin.ModelAdmin):
    list_display = [
        "name",
        "enabled",
        "broker_host",
        "broker_port",
        "use_hmac",
        "connection_status",
        "created_at",
    ]
    list_filter = ["enabled", "use_hmac", "log_level", "created_at"]
    search_fields = ["name", "broker_host", "client_id"]
    readonly_fields = ["created_at", "updated_at", "connection_status"]

    fieldsets = (
        ("Basic Settings", {"fields": ("name", "enabled", "connection_status")}),
        (
            "Broker Connection",
            {"fields": ("broker_host", "broker_port", "keepalive", "client_id")},
        ),
        (
            "Authentication",
            {"fields": ("username", "password"), "classes": ("collapse",)},
        ),
        (
            "HMAC Message Authentication",
            {"fields": ("use_hmac", "hmac_secret_key"), "classes": ("collapse",)},
        ),
        (
            "Message Settings",
            {
                "fields": (
                    "topic_prefix",
                    "qos_level",
                    "retain_messages",
                    "clean_session",
                )
            },
        ),
        (
            "Connection Management",
            {
                "fields": (
                    "auto_reconnect",
                    "reconnect_delay",
                    "max_reconnect_attempts",
                ),
                "classes": ("collapse",),
            },
        ),
        (
            "Logging",
            {"fields": ("log_messages", "log_level"), "classes": ("collapse",)},
        ),
        (
            "Timestamps",
            {"fields": ("created_at", "updated_at"), "classes": ("collapse",)},
        ),
    )

    def connection_status(self, obj):
        """Display current connection status"""
        if not obj.enabled:
            return "Disabled"
        try:
            from .signals import signal_handler

            if signal_handler.db_publisher:
                if signal_handler.db_publisher.is_available():
                    return "PostgreSQL Connected (Bridge Required)"
                else:
                    return "PostgreSQL Unavailable"
            else:
                return "Not Initialized"
        except Exception:
            return "Unknown"

    connection_status.short_description = "Connection Status"


