from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.metadata_additional import MetadataAdditional
    from ..models.page_structure import PageStructure


T = TypeVar("T", bound="Metadata")


@_attrs_define
class Metadata:
    """Document metadata — aligned with kreuzberg::Metadata.

    Attributes:
        abstract_text (None | str | Unset):
        additional (MetadataAdditional | Unset):
        authors (list[str] | Unset):
        category (None | str | Unset):
        created_at (None | str | Unset):
        created_by (None | str | Unset):
        document_version (None | str | Unset):
        extraction_duration_ms (int | None | Unset):
        keywords (list[str] | Unset):
        language (None | str | Unset):
        modified_at (None | str | Unset):
        modified_by (None | str | Unset):
        output_format (None | str | Unset):
        pages (None | PageStructure | Unset):
        subject (None | str | Unset):
        tags (list[str] | Unset):
        title (None | str | Unset):
    """

    abstract_text: None | str | Unset = UNSET
    additional: MetadataAdditional | Unset = UNSET
    authors: list[str] | Unset = UNSET
    category: None | str | Unset = UNSET
    created_at: None | str | Unset = UNSET
    created_by: None | str | Unset = UNSET
    document_version: None | str | Unset = UNSET
    extraction_duration_ms: int | None | Unset = UNSET
    keywords: list[str] | Unset = UNSET
    language: None | str | Unset = UNSET
    modified_at: None | str | Unset = UNSET
    modified_by: None | str | Unset = UNSET
    output_format: None | str | Unset = UNSET
    pages: None | PageStructure | Unset = UNSET
    subject: None | str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    title: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.page_structure import PageStructure

        abstract_text: None | str | Unset
        if isinstance(self.abstract_text, Unset):
            abstract_text = UNSET
        else:
            abstract_text = self.abstract_text

        additional: dict[str, Any] | Unset = UNSET
        if not isinstance(self.additional, Unset):
            additional = self.additional.to_dict()

        authors: list[str] | Unset = UNSET
        if not isinstance(self.authors, Unset):
            authors = self.authors

        category: None | str | Unset
        if isinstance(self.category, Unset):
            category = UNSET
        else:
            category = self.category

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        created_by: None | str | Unset
        if isinstance(self.created_by, Unset):
            created_by = UNSET
        else:
            created_by = self.created_by

        document_version: None | str | Unset
        if isinstance(self.document_version, Unset):
            document_version = UNSET
        else:
            document_version = self.document_version

        extraction_duration_ms: int | None | Unset
        if isinstance(self.extraction_duration_ms, Unset):
            extraction_duration_ms = UNSET
        else:
            extraction_duration_ms = self.extraction_duration_ms

        keywords: list[str] | Unset = UNSET
        if not isinstance(self.keywords, Unset):
            keywords = self.keywords

        language: None | str | Unset
        if isinstance(self.language, Unset):
            language = UNSET
        else:
            language = self.language

        modified_at: None | str | Unset
        if isinstance(self.modified_at, Unset):
            modified_at = UNSET
        else:
            modified_at = self.modified_at

        modified_by: None | str | Unset
        if isinstance(self.modified_by, Unset):
            modified_by = UNSET
        else:
            modified_by = self.modified_by

        output_format: None | str | Unset
        if isinstance(self.output_format, Unset):
            output_format = UNSET
        else:
            output_format = self.output_format

        pages: dict[str, Any] | None | Unset
        if isinstance(self.pages, Unset):
            pages = UNSET
        elif isinstance(self.pages, PageStructure):
            pages = self.pages.to_dict()
        else:
            pages = self.pages

        subject: None | str | Unset
        if isinstance(self.subject, Unset):
            subject = UNSET
        else:
            subject = self.subject

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if abstract_text is not UNSET:
            field_dict["abstract_text"] = abstract_text
        if additional is not UNSET:
            field_dict["additional"] = additional
        if authors is not UNSET:
            field_dict["authors"] = authors
        if category is not UNSET:
            field_dict["category"] = category
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if document_version is not UNSET:
            field_dict["document_version"] = document_version
        if extraction_duration_ms is not UNSET:
            field_dict["extraction_duration_ms"] = extraction_duration_ms
        if keywords is not UNSET:
            field_dict["keywords"] = keywords
        if language is not UNSET:
            field_dict["language"] = language
        if modified_at is not UNSET:
            field_dict["modified_at"] = modified_at
        if modified_by is not UNSET:
            field_dict["modified_by"] = modified_by
        if output_format is not UNSET:
            field_dict["output_format"] = output_format
        if pages is not UNSET:
            field_dict["pages"] = pages
        if subject is not UNSET:
            field_dict["subject"] = subject
        if tags is not UNSET:
            field_dict["tags"] = tags
        if title is not UNSET:
            field_dict["title"] = title

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.metadata_additional import MetadataAdditional
        from ..models.page_structure import PageStructure

        d = dict(src_dict)

        def _parse_abstract_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        abstract_text = _parse_abstract_text(d.pop("abstract_text", UNSET))

        _additional = d.pop("additional", UNSET)
        additional: MetadataAdditional | Unset
        if isinstance(_additional, Unset):
            additional = UNSET
        else:
            additional = MetadataAdditional.from_dict(_additional)

        authors = cast("list[str]", d.pop("authors", UNSET))

        def _parse_category(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        category = _parse_category(d.pop("category", UNSET))

        def _parse_created_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        created_at = _parse_created_at(d.pop("created_at", UNSET))

        def _parse_created_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        created_by = _parse_created_by(d.pop("created_by", UNSET))

        def _parse_document_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        document_version = _parse_document_version(d.pop("document_version", UNSET))

        def _parse_extraction_duration_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("int | None | Unset", data)

        extraction_duration_ms = _parse_extraction_duration_ms(d.pop("extraction_duration_ms", UNSET))

        keywords = cast("list[str]", d.pop("keywords", UNSET))

        def _parse_language(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        language = _parse_language(d.pop("language", UNSET))

        def _parse_modified_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        modified_at = _parse_modified_at(d.pop("modified_at", UNSET))

        def _parse_modified_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        modified_by = _parse_modified_by(d.pop("modified_by", UNSET))

        def _parse_output_format(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        output_format = _parse_output_format(d.pop("output_format", UNSET))

        def _parse_pages(data: object) -> None | PageStructure | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError
                pages_type_1 = PageStructure.from_dict(data)

                return pages_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast("None | PageStructure | Unset", data)

        pages = _parse_pages(d.pop("pages", UNSET))

        def _parse_subject(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        subject = _parse_subject(d.pop("subject", UNSET))

        tags = cast("list[str]", d.pop("tags", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        title = _parse_title(d.pop("title", UNSET))

        metadata = cls(
            abstract_text=abstract_text,
            additional=additional,
            authors=authors,
            category=category,
            created_at=created_at,
            created_by=created_by,
            document_version=document_version,
            extraction_duration_ms=extraction_duration_ms,
            keywords=keywords,
            language=language,
            modified_at=modified_at,
            modified_by=modified_by,
            output_format=output_format,
            pages=pages,
            subject=subject,
            tags=tags,
            title=title,
        )

        metadata.additional_properties = d
        return metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
