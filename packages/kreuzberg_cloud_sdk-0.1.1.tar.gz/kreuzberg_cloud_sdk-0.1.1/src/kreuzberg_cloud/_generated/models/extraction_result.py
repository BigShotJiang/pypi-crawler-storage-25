from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chunk import Chunk
    from ..models.extracted_image import ExtractedImage
    from ..models.metadata import Metadata
    from ..models.page_content import PageContent
    from ..models.processing_warning import ProcessingWarning
    from ..models.table import Table


T = TypeVar("T", bound="ExtractionResult")


@_attrs_define
class ExtractionResult:
    """Extraction result — aligned with kreuzberg::ExtractionResult.

    Attributes:
        chunks (list[Chunk] | Unset): Text chunks (when chunking is enabled)
        content (str | Unset): Full extracted text content
        detected_languages (list[str] | Unset): Detected document languages
        images (list[ExtractedImage] | Unset): Extracted images (base64 encoded)
        metadata (Metadata | None | Unset):
        mime_type (str | Unset): Content MIME type (e.g., "text/plain", "text/markdown")
        pages (list[PageContent] | Unset): Per-page content (when page extraction is enabled)
        processing_warnings (list[ProcessingWarning] | Unset): Non-fatal processing warnings
        quality_score (float | None | Unset): Document quality score (0.0-1.0)
        tables (list[Table] | Unset): Extracted tables
    """

    chunks: list[Chunk] | Unset = UNSET
    content: str | Unset = UNSET
    detected_languages: list[str] | Unset = UNSET
    images: list[ExtractedImage] | Unset = UNSET
    metadata: Metadata | None | Unset = UNSET
    mime_type: str | Unset = UNSET
    pages: list[PageContent] | Unset = UNSET
    processing_warnings: list[ProcessingWarning] | Unset = UNSET
    quality_score: float | None | Unset = UNSET
    tables: list[Table] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.metadata import Metadata

        chunks: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.chunks, Unset):
            chunks = []
            for chunks_item_data in self.chunks:
                chunks_item = chunks_item_data.to_dict()
                chunks.append(chunks_item)

        content = self.content

        detected_languages: list[str] | Unset = UNSET
        if not isinstance(self.detected_languages, Unset):
            detected_languages = self.detected_languages

        images: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.images, Unset):
            images = []
            for images_item_data in self.images:
                images_item = images_item_data.to_dict()
                images.append(images_item)

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, Metadata):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        mime_type = self.mime_type

        pages: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.pages, Unset):
            pages = []
            for pages_item_data in self.pages:
                pages_item = pages_item_data.to_dict()
                pages.append(pages_item)

        processing_warnings: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.processing_warnings, Unset):
            processing_warnings = []
            for processing_warnings_item_data in self.processing_warnings:
                processing_warnings_item = processing_warnings_item_data.to_dict()
                processing_warnings.append(processing_warnings_item)

        quality_score: float | None | Unset
        if isinstance(self.quality_score, Unset):
            quality_score = UNSET
        else:
            quality_score = self.quality_score

        tables: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.tables, Unset):
            tables = []
            for tables_item_data in self.tables:
                tables_item = tables_item_data.to_dict()
                tables.append(tables_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if chunks is not UNSET:
            field_dict["chunks"] = chunks
        if content is not UNSET:
            field_dict["content"] = content
        if detected_languages is not UNSET:
            field_dict["detected_languages"] = detected_languages
        if images is not UNSET:
            field_dict["images"] = images
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if mime_type is not UNSET:
            field_dict["mime_type"] = mime_type
        if pages is not UNSET:
            field_dict["pages"] = pages
        if processing_warnings is not UNSET:
            field_dict["processing_warnings"] = processing_warnings
        if quality_score is not UNSET:
            field_dict["quality_score"] = quality_score
        if tables is not UNSET:
            field_dict["tables"] = tables

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.chunk import Chunk
        from ..models.extracted_image import ExtractedImage
        from ..models.metadata import Metadata
        from ..models.page_content import PageContent
        from ..models.processing_warning import ProcessingWarning
        from ..models.table import Table

        d = dict(src_dict)
        _chunks = d.pop("chunks", UNSET)
        chunks: list[Chunk] | Unset = UNSET
        if _chunks is not UNSET:
            chunks = []
            for chunks_item_data in _chunks:
                chunks_item = Chunk.from_dict(chunks_item_data)

                chunks.append(chunks_item)

        content = d.pop("content", UNSET)

        detected_languages = cast("list[str]", d.pop("detected_languages", UNSET))

        _images = d.pop("images", UNSET)
        images: list[ExtractedImage] | Unset = UNSET
        if _images is not UNSET:
            images = []
            for images_item_data in _images:
                images_item = ExtractedImage.from_dict(images_item_data)

                images.append(images_item)

        def _parse_metadata(data: object) -> Metadata | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError
                metadata_type_1 = Metadata.from_dict(data)

                return metadata_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast("Metadata | None | Unset", data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        mime_type = d.pop("mime_type", UNSET)

        _pages = d.pop("pages", UNSET)
        pages: list[PageContent] | Unset = UNSET
        if _pages is not UNSET:
            pages = []
            for pages_item_data in _pages:
                pages_item = PageContent.from_dict(pages_item_data)

                pages.append(pages_item)

        _processing_warnings = d.pop("processing_warnings", UNSET)
        processing_warnings: list[ProcessingWarning] | Unset = UNSET
        if _processing_warnings is not UNSET:
            processing_warnings = []
            for processing_warnings_item_data in _processing_warnings:
                processing_warnings_item = ProcessingWarning.from_dict(processing_warnings_item_data)

                processing_warnings.append(processing_warnings_item)

        def _parse_quality_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("float | None | Unset", data)

        quality_score = _parse_quality_score(d.pop("quality_score", UNSET))

        _tables = d.pop("tables", UNSET)
        tables: list[Table] | Unset = UNSET
        if _tables is not UNSET:
            tables = []
            for tables_item_data in _tables:
                tables_item = Table.from_dict(tables_item_data)

                tables.append(tables_item)

        extraction_result = cls(
            chunks=chunks,
            content=content,
            detected_languages=detected_languages,
            images=images,
            metadata=metadata,
            mime_type=mime_type,
            pages=pages,
            processing_warnings=processing_warnings,
            quality_score=quality_score,
            tables=tables,
        )

        extraction_result.additional_properties = d
        return extraction_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
