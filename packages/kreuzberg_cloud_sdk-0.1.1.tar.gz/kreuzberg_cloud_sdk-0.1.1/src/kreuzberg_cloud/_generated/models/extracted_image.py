from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.bounding_box import BoundingBox


T = TypeVar("T", bound="ExtractedImage")


@_attrs_define
class ExtractedImage:
    """Extracted image with base64-encoded data.

    Attributes:
        bounding_box (BoundingBox | None | Unset):
        data (str | Unset): Base64-encoded image data
        description (None | str | Unset): Image description
        format_ (str | Unset): Image format (e.g., "PNG", "JPEG")
        height (int | None | Unset): Image height in pixels
        image_index (int | Unset): Image index within the document
        page_number (int | None | Unset): Page number the image was found on
        width (int | None | Unset): Image width in pixels
    """

    bounding_box: BoundingBox | None | Unset = UNSET
    data: str | Unset = UNSET
    description: None | str | Unset = UNSET
    format_: str | Unset = UNSET
    height: int | None | Unset = UNSET
    image_index: int | Unset = UNSET
    page_number: int | None | Unset = UNSET
    width: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.bounding_box import BoundingBox

        bounding_box: dict[str, Any] | None | Unset
        if isinstance(self.bounding_box, Unset):
            bounding_box = UNSET
        elif isinstance(self.bounding_box, BoundingBox):
            bounding_box = self.bounding_box.to_dict()
        else:
            bounding_box = self.bounding_box

        data = self.data

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        format_ = self.format_

        height: int | None | Unset
        if isinstance(self.height, Unset):
            height = UNSET
        else:
            height = self.height

        image_index = self.image_index

        page_number: int | None | Unset
        if isinstance(self.page_number, Unset):
            page_number = UNSET
        else:
            page_number = self.page_number

        width: int | None | Unset
        if isinstance(self.width, Unset):
            width = UNSET
        else:
            width = self.width

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if bounding_box is not UNSET:
            field_dict["bounding_box"] = bounding_box
        if data is not UNSET:
            field_dict["data"] = data
        if description is not UNSET:
            field_dict["description"] = description
        if format_ is not UNSET:
            field_dict["format"] = format_
        if height is not UNSET:
            field_dict["height"] = height
        if image_index is not UNSET:
            field_dict["image_index"] = image_index
        if page_number is not UNSET:
            field_dict["page_number"] = page_number
        if width is not UNSET:
            field_dict["width"] = width

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.bounding_box import BoundingBox

        d = dict(src_dict)

        def _parse_bounding_box(data: object) -> BoundingBox | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError
                bounding_box_type_1 = BoundingBox.from_dict(data)

                return bounding_box_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast("BoundingBox | None | Unset", data)

        bounding_box = _parse_bounding_box(d.pop("bounding_box", UNSET))

        data = d.pop("data", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("None | str | Unset", data)

        description = _parse_description(d.pop("description", UNSET))

        format_ = d.pop("format", UNSET)

        def _parse_height(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("int | None | Unset", data)

        height = _parse_height(d.pop("height", UNSET))

        image_index = d.pop("image_index", UNSET)

        def _parse_page_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("int | None | Unset", data)

        page_number = _parse_page_number(d.pop("page_number", UNSET))

        def _parse_width(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("int | None | Unset", data)

        width = _parse_width(d.pop("width", UNSET))

        extracted_image = cls(
            bounding_box=bounding_box,
            data=data,
            description=description,
            format_=format_,
            height=height,
            image_index=image_index,
            page_number=page_number,
            width=width,
        )

        extracted_image.additional_properties = d
        return extracted_image

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
