from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="PageContent")


@_attrs_define
class PageContent:
    """Per-page content.

    Attributes:
        page_number (int): Page number (0-indexed)
        content (str | Unset): Extracted text for this page
        is_blank (bool | None | Unset): Whether the page is blank
    """

    page_number: int
    content: str | Unset = UNSET
    is_blank: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        page_number = self.page_number

        content = self.content

        is_blank: bool | None | Unset
        if isinstance(self.is_blank, Unset):
            is_blank = UNSET
        else:
            is_blank = self.is_blank

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "page_number": page_number,
            }
        )
        if content is not UNSET:
            field_dict["content"] = content
        if is_blank is not UNSET:
            field_dict["is_blank"] = is_blank

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        page_number = d.pop("page_number")

        content = d.pop("content", UNSET)

        def _parse_is_blank(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast("bool | None | Unset", data)

        is_blank = _parse_is_blank(d.pop("is_blank", UNSET))

        page_content = cls(
            page_number=page_number,
            content=content,
            is_blank=is_blank,
        )

        page_content.additional_properties = d
        return page_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
