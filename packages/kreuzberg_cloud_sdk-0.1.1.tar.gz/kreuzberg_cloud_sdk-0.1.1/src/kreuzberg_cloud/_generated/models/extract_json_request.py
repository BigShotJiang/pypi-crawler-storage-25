from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.document_input import DocumentInput
    from ..models.extraction_options import ExtractionOptions
    from ..models.webhook_config import WebhookConfig


T = TypeVar("T", bound="ExtractJsonRequest")


@_attrs_define
class ExtractJsonRequest:
    """JSON body for `POST /v1/extract`

    Attributes:
        documents (list[DocumentInput]): Documents to process
        options (ExtractionOptions | None | Unset):
        webhook (None | Unset | WebhookConfig):
    """

    documents: list[DocumentInput]
    options: ExtractionOptions | None | Unset = UNSET
    webhook: None | Unset | WebhookConfig = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.extraction_options import ExtractionOptions
        from ..models.webhook_config import WebhookConfig

        documents = []
        for documents_item_data in self.documents:
            documents_item = documents_item_data.to_dict()
            documents.append(documents_item)

        options: dict[str, Any] | None | Unset
        if isinstance(self.options, Unset):
            options = UNSET
        elif isinstance(self.options, ExtractionOptions):
            options = self.options.to_dict()
        else:
            options = self.options

        webhook: dict[str, Any] | None | Unset
        if isinstance(self.webhook, Unset):
            webhook = UNSET
        elif isinstance(self.webhook, WebhookConfig):
            webhook = self.webhook.to_dict()
        else:
            webhook = self.webhook

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "documents": documents,
            }
        )
        if options is not UNSET:
            field_dict["options"] = options
        if webhook is not UNSET:
            field_dict["webhook"] = webhook

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.document_input import DocumentInput
        from ..models.extraction_options import ExtractionOptions
        from ..models.webhook_config import WebhookConfig

        d = dict(src_dict)
        documents = []
        _documents = d.pop("documents")
        for documents_item_data in _documents:
            documents_item = DocumentInput.from_dict(documents_item_data)

            documents.append(documents_item)

        def _parse_options(data: object) -> ExtractionOptions | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError
                options_type_1 = ExtractionOptions.from_dict(data)

                return options_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast("ExtractionOptions | None | Unset", data)

        options = _parse_options(d.pop("options", UNSET))

        def _parse_webhook(data: object) -> None | Unset | WebhookConfig:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError
                webhook_type_1 = WebhookConfig.from_dict(data)

                return webhook_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast("None | Unset | WebhookConfig", data)

        webhook = _parse_webhook(d.pop("webhook", UNSET))

        extract_json_request = cls(
            documents=documents,
            options=options,
            webhook=webhook,
        )

        extract_json_request.additional_properties = d
        return extract_json_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
