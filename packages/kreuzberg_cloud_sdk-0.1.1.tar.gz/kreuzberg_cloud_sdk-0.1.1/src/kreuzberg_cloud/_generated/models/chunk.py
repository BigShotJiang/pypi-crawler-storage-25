from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chunk_metadata import ChunkMetadata


T = TypeVar("T", bound="Chunk")


@_attrs_define
class Chunk:
    """Text chunk with optional embedding.

    Attributes:
        content (str | Unset): Chunk text content
        embedding (list[float] | Unset): Embedding vector (when embedding is enabled)
        metadata (ChunkMetadata | None | Unset):
    """

    content: str | Unset = UNSET
    embedding: list[float] | Unset = UNSET
    metadata: ChunkMetadata | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chunk_metadata import ChunkMetadata

        content = self.content

        embedding: list[float] | Unset = UNSET
        if not isinstance(self.embedding, Unset):
            embedding = self.embedding

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, ChunkMetadata):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if content is not UNSET:
            field_dict["content"] = content
        if embedding is not UNSET:
            field_dict["embedding"] = embedding
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.chunk_metadata import ChunkMetadata

        d = dict(src_dict)
        content = d.pop("content", UNSET)

        embedding = cast("list[float]", d.pop("embedding", UNSET))

        def _parse_metadata(data: object) -> ChunkMetadata | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError
                metadata_type_1 = ChunkMetadata.from_dict(data)

                return metadata_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast("ChunkMetadata | None | Unset", data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        chunk = cls(
            content=content,
            embedding=embedding,
            metadata=metadata,
        )

        chunk.additional_properties = d
        return chunk

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
