import os
import posixpath
import re
from typing import Optional, Tuple, cast
from uuid import UUID

from prodigy_teams_pam_sdk import models as pam_models
from prodigy_teams_pam_sdk.recipe_client import Client

# Place this close to the function for convenience.
# TODO: This will have trouble with escaped curlies right?
_PATH_RE = re.compile(r"^(?:\{(\w+)\}:)?(?:\{(\w+)\}/?)?([^{}]*)$")

_BUILTIN_PATH_ENV_VARS = {
    "__nfs__": "PRODIGY_TEAMS_BUILTIN_PATH_NFS",
    "__data__": "PRODIGY_TEAMS_BUILTIN_PATH_DATA",
    "__envs__": "PRODIGY_TEAMS_BUILTIN_PATH_ENVS",
    "__execs__": "PRODIGY_TEAMS_BUILTIN_PATH_EXECS",
    "__tmp__": "PRODIGY_TEAMS_BUILTIN_PATH_TMP",
    "__unpacks__": "PRODIGY_TEAMS_BUILTIN_PATH_UNPACKS",
    "__wheelhouse__": "PRODIGY_TEAMS_BUILTIN_PATH_WHEELHOUSE",
}


def _parse_remote_path(path: str) -> Tuple[Optional[str], Optional[str], str]:
    match_obj = _PATH_RE.match(path)
    if match_obj is None:
        raise ValueError(f"Cannot parse path {path}")
    groups = match_obj.groups()
    if len(groups) != 3:
        raise ValueError(f"Cannot parse path {path}")
    return groups


def _resolve_remote_path(
    client: Client, remote: str, broker_id: UUID
) -> Tuple[Optional[pam_models.BrokerPathSummary], str, str]:
    path_parts = _parse_remote_path(remote)
    path_name = path_parts[1]
    subpath = path_parts[2]
    if path_name is None:
        return None, subpath, subpath
    builtin_root = _resolve_builtin_path(path_name)
    if builtin_root is not None:
        joined = posixpath.join(builtin_root, subpath)
        return None, subpath, joined
    query = pam_models.BrokerPathReading(
        broker_id=broker_id,
        name=path_name,
        id=None,
        path=None,
    )
    result = cast(pam_models.BrokerPathSummary, client.broker_path.read(query))
    # These paths should always be treated as unix paths since they are remote.
    # Some consumers may also expect trailing slashes to be preserved.
    joined = posixpath.join(result.path, subpath)
    return result, subpath, joined


def resolve_remote_path(client: Client, remote: str, broker_id: UUID) -> str:
    _, _, joined = _resolve_remote_path(client, remote, broker_id)
    return joined


def _resolve_builtin_path(path_name: str) -> Optional[str]:
    env_var = _BUILTIN_PATH_ENV_VARS.get(path_name)
    if env_var is None:
        return None
    return os.getenv(env_var)
