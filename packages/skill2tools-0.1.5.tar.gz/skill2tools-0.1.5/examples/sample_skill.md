---
name: data-pipeline
description: Build and manage data ingestion pipelines. Use when creating ETL workflows, processing CSV/JSON files, or setting up data transformations.
license: Apache-2.0
metadata:
  author: skill2tools-example
  version: "1.0"
compatibility: Requires Python 3.11+ and access to filesystem
allowed-tools: Bash(python:*) Read
---

# Data Pipeline Skill

## When to use this skill
Use this skill when the user needs to:
- Ingest data from CSV, JSON, or API sources
- Transform and clean datasets
- Load data into a target database or file
- Schedule recurring data pipelines

## Steps

1. **Analyze the data source** — Determine the input format (CSV, JSON, API endpoint) and schema
2. **Validate the data** — Check for missing fields, type mismatches, and duplicates using pandas
3. **Transform the data** — Apply cleaning rules, type conversions, and computed fields
4. **Load the output** — Write to the target (PostgreSQL via psycopg2, or output CSV/Parquet)
5. **Verify the pipeline** — Run a sample batch and compare input/output row counts

## Tools needed
- **pandas** — DataFrame operations for data manipulation
- **psycopg2** — PostgreSQL database connector
- **requests** — HTTP client for API data sources
- **schedule** — Cron-like job scheduling
- **jsonschema** — Schema validation for JSON inputs
- **great_expectations** — Data quality validation framework
- **slack_sdk** — Send pipeline status notifications to Slack
- **dbt** — Data transformation tool (MCP server integration)

## Output format
Pipeline results should be a JSON report:
```json
{
  "status": "success",
  "rows_processed": 1000,
  "rows_failed": 3,
  "duration_seconds": 12.5,
  "output_path": "/data/output/result.parquet"
}
```

## Edge cases
- Handle files larger than available memory with chunked reading
- Retry failed API calls with exponential backoff
- Log all transformation errors to a separate error file
