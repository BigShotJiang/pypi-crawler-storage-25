---
name: skill-name
description: >-
  This skill should be used when the user asks to "action phrase 1",
  "action phrase 2", "action phrase 3", or discusses topic-area.
  Provide enough trigger phrases to avoid undertriggering.
version: "1.0"
license: Apache-2.0
compatibility: Requires Python 3.11+ and access to filesystem
allowed-tools: Bash(python:*) Read Grep
metadata:
  author: your-name
  version: "1.0"
---

# Skill Name

Brief overview of what this skill does and the domain it operates in (2-3 sentences).

## When to Use

Use this skill when the task involves:
- Specific scenario or trigger 1
- Specific scenario or trigger 2
- Specific scenario or trigger 3

Do NOT use this skill for:
- Out-of-scope scenario 1
- Out-of-scope scenario 2

## Key Directives

- **MUST** follow directive 1 — critical constraint or safety requirement
- **MUST** follow directive 2 — non-negotiable rule for this domain

## Workflow

1. **Analyze inputs** — Determine the input format, schema, and constraints
2. **Validate** — Check for missing fields, type mismatches, and edge cases
3. **Process** — Apply the core transformation or operation
4. **Verify** — Run validation on the output to confirm correctness
5. **Report** — Produce structured output with status and metrics

## Tools Needed

- **tool-name-1** — What it does and when to use it
- **tool-name-2** — What it does and when to use it
- **tool-name-3** — What it does and when to use it

## Output Format

Produce results as a structured JSON report:

```json
{
  "status": "success | failure",
  "summary": "Human-readable summary of what was done",
  "metrics": {
    "items_processed": 0,
    "items_failed": 0,
    "duration_seconds": 0.0
  },
  "output_path": "/path/to/output"
}
```

## Edge Cases

- Handle case 1 with strategy X
- Handle case 2 with strategy Y
- Log all errors to a separate error report

## Additional Resources

### Reference Files

For detailed patterns and domain knowledge, consult:
- **`references/patterns.md`** — Common patterns and recipes
- **`references/api-docs.md`** — API specifications and schemas

### Example Files

Working examples in `examples/`:
- **`examples/basic-usage.md`** — Minimal working example
- **`examples/advanced-usage.md`** — Complex real-world scenario

### Scripts

Utility scripts in `scripts/`:
- **`scripts/validate.sh`** — Validate inputs before processing
