#!/usr/bin/env bash
# publish.sh — Build and publish skill2tools to PyPI
#
# Usage:
#   ./publish.sh                      # Build and upload to PyPI
#   ./publish.sh --test               # Build and upload to TestPyPI first
#   ./publish.sh --build-only         # Build without uploading
#   ./publish.sh --obfuscate          # Build with PyArmor obfuscation and upload
#   ./publish.sh --obfuscate --test   # Obfuscate + TestPyPI
#   ./publish.sh --obfuscate --build-only
#
# Your original source code is NEVER modified — obfuscation works on a temp copy.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
step()  { echo -e "${CYAN}[STEP]${NC} $*"; }

# Auto-increment build number and read version
VERSION=$(python3 "$SCRIPT_DIR/bump_version.py")
info "Bumped version to ${VERSION}"

# Temp build directory (cleaned up on exit)
BUILD_TMP=""
cleanup() {
    if [[ -n "$BUILD_TMP" && -d "$BUILD_TMP" ]]; then
        rm -rf "$BUILD_TMP"
        info "Cleaned up temp directory"
    fi
}
trap cleanup EXIT

# Ensure build tools are installed
ensure_tools() {
    local need_obfuscate="$1"
    local missing=()

    if ! python3 -m build --version &>/dev/null 2>&1; then
        missing+=("build")
    fi

    if ! python3 -m twine --version &>/dev/null 2>&1; then
        missing+=("twine")
    fi

    if [[ "$need_obfuscate" == "true" ]] && ! command -v pyarmor &>/dev/null 2>&1; then
        missing+=("pyarmor")
    fi

    if [[ ${#missing[@]} -gt 0 ]]; then
        info "Installing missing tools: ${missing[*]}..."
        python3 -m pip install "${missing[@]}" --quiet
    fi
}

# Clean previous build artifacts
clean() {
    step "Cleaning previous build artifacts..."
    rm -rf "$SCRIPT_DIR/dist/"*.tar.gz "$SCRIPT_DIR/dist/"*.whl
    rm -rf "$SCRIPT_DIR/build/lib"
    rm -rf "$SCRIPT_DIR"/*.egg-info
    rm -rf "$SCRIPT_DIR/skill2tools"/*.egg-info
}

# Create a temp copy and obfuscate the source
obfuscate() {
    step "Creating temporary copy of project..."
    BUILD_TMP=$(mktemp -d)
    info "Temp directory: $BUILD_TMP"

    # Copy only the files needed for building
    cp -r "$SCRIPT_DIR/skill2tools" "$BUILD_TMP/skill2tools"
    cp "$SCRIPT_DIR/pyproject.toml" "$BUILD_TMP/pyproject.toml"
    cp "$SCRIPT_DIR/README.md" "$BUILD_TMP/README.md"
    cp "$SCRIPT_DIR/LICENSE" "$BUILD_TMP/LICENSE"

    step "Obfuscating source with PyArmor..."
    cd "$BUILD_TMP"

    # Preserve __init__.py (contains __version__ needed by hatchling)
    cp "$BUILD_TMP/skill2tools/__init__.py" "$BUILD_TMP/__init__.py.bak"

    # Obfuscate all .py files in the package, output replaces the originals
    pyarmor gen \
        --output "$BUILD_TMP/skill2tools_obf" \
        "$BUILD_TMP/skill2tools"

    # Replace the original package with the obfuscated version
    rm -rf "$BUILD_TMP/skill2tools"
    mv "$BUILD_TMP/skill2tools_obf/skill2tools" "$BUILD_TMP/skill2tools"

    # Restore the original __init__.py so hatchling can read __version__
    cp "$BUILD_TMP/__init__.py.bak" "$BUILD_TMP/skill2tools/__init__.py"
    rm "$BUILD_TMP/__init__.py.bak"

    # PyArmor generates a runtime package — move it inside the package
    if [[ -d "$BUILD_TMP/skill2tools_obf/pyarmor_runtime" ]]; then
        cp -r "$BUILD_TMP/skill2tools_obf/pyarmor_runtime"* "$BUILD_TMP/skill2tools/"
    fi
    rm -rf "$BUILD_TMP/skill2tools_obf"

    info "Obfuscation complete"
    cd "$SCRIPT_DIR"
}

# Build sdist and wheel
build() {
    local build_dir="$1"

    if [[ "$build_dir" == "$SCRIPT_DIR" ]]; then
        step "Building skill2tools v${VERSION}..."
    else
        step "Building skill2tools v${VERSION} (obfuscated)..."
    fi

    cd "$build_dir"
    python3 -m build
    cd "$SCRIPT_DIR"

    # If built from temp dir, copy artifacts back
    if [[ "$build_dir" != "$SCRIPT_DIR" ]]; then
        mkdir -p "$SCRIPT_DIR/dist"
        cp "$build_dir/dist/"*.tar.gz "$SCRIPT_DIR/dist/" 2>/dev/null || true
        cp "$build_dir/dist/"*.whl "$SCRIPT_DIR/dist/" 2>/dev/null || true
    fi

    info "Built artifacts:"
    ls -lh "$SCRIPT_DIR/dist/"*.tar.gz "$SCRIPT_DIR/dist/"*.whl 2>/dev/null
}

# Validate the built distributions
check() {
    step "Checking distributions with twine..."
    python3 -m twine check "$SCRIPT_DIR/dist/"*.tar.gz "$SCRIPT_DIR/dist/"*.whl
}

# Set PyPI credentials (API token)
setup_credentials() {
    export TWINE_USERNAME="__token__"
    export TWINE_PASSWORD="pypi-AgEIcHlwaS5vcmcCJDZlNzEzNzk4LWVmMjAtNDI4ZS04M2IxLWQ2ZTQ3MmU3ZTU5NQACE1sxLFsic2tpbGwydG9vbHMiXV0AAixbMixbImQ2NGJjMTRlLTFmYzQtNDhiZS1iZmZiLWE1MWRlMGE4OWEwMSJdXQAABiBNItrDF6ZkLgYn8pRSQ6LuN12OaVEFyInyhc-MmEhJEw"
}

# Upload to TestPyPI
upload_test() {
    setup_credentials
    step "Uploading to TestPyPI..."
    python3 -m twine upload --repository testpypi "$SCRIPT_DIR/dist/"*.tar.gz "$SCRIPT_DIR/dist/"*.whl

    info ""
    info "Uploaded to TestPyPI. Test install with:"
    info "  pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ skill2tools==${VERSION}"
}

# Upload to PyPI
upload_pypi() {
    setup_credentials
    step "Uploading to PyPI..."
    python3 -m twine upload "$SCRIPT_DIR/dist/"*.tar.gz "$SCRIPT_DIR/dist/"*.whl

    info ""
    info "Published skill2tools v${VERSION} to PyPI."
    info "Install with: pip install skill2tools"
}

# Main
main() {
    local use_obfuscate=false
    local mode="publish"

    # Parse arguments
    for arg in "$@"; do
        case "$arg" in
            --obfuscate) use_obfuscate=true ;;
            --build-only|--test) mode="$arg" ;;
            *) error "Unknown option: $arg"; echo "Usage: $0 [--obfuscate] [--test | --build-only]"; exit 1 ;;
        esac
    done

    info "skill2tools v${VERSION}"
    if [[ "$use_obfuscate" == "true" ]]; then
        info "Obfuscation: ENABLED"
    else
        info "Obfuscation: disabled (use --obfuscate to enable)"
    fi
    info ""

    ensure_tools "$use_obfuscate"
    clean

    if [[ "$use_obfuscate" == "true" ]]; then
        obfuscate
        build "$BUILD_TMP"
    else
        build "$SCRIPT_DIR"
    fi

    check

    case "$mode" in
        --build-only)
            info ""
            info "Build complete. Artifacts in dist/"
            info "To upload manually: python3 -m twine upload dist/*.tar.gz dist/*.whl"
            ;;
        --test)
            upload_test
            ;;
        publish)
            echo ""
            warn "You are about to publish skill2tools v${VERSION} to PyPI."
            read -rp "Continue? [y/N] " confirm
            if [[ "$confirm" =~ ^[Yy]$ ]]; then
                upload_pypi
            else
                info "Aborted. Artifacts remain in dist/"
            fi
            ;;
    esac
}

main "$@"
