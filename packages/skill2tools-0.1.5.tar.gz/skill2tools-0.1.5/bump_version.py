#!/usr/bin/env python3
"""Bump the build number in skill2tools/__init__.py.

Version format: major.minor.build
- major/minor are changed manually
- build is auto-incremented on each build

Usage:
    python3 bump_version.py          # bump build number
    python3 bump_version.py --minor  # bump minor, reset build to 0
    python3 bump_version.py --major  # bump major, reset minor and build to 0
"""

import re
import sys
from datetime import datetime, timezone
from pathlib import Path

INIT_FILE = Path(__file__).parent / "skill2tools" / "__init__.py"
VERSION_RE = re.compile(r'^__version__\s*=\s*"(\d+)\.(\d+)\.(\d+)"', re.MULTILINE)
TIMESTAMP_RE = re.compile(r'^__build_timestamp__\s*=\s*"[^"]*"', re.MULTILINE)


def bump(part: str = "build") -> str:
    content = INIT_FILE.read_text(encoding="utf-8")
    match = VERSION_RE.search(content)
    if not match:
        print("ERROR: could not find __version__ in", INIT_FILE, file=sys.stderr)
        sys.exit(1)

    major, minor, build = int(match.group(1)), int(match.group(2)), int(match.group(3))

    if part == "major":
        major += 1
        minor = 0
        build = 0
    elif part == "minor":
        minor += 1
        build = 0
    else:
        build += 1

    new_version = f"{major}.{minor}.{build}"
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    content = VERSION_RE.sub(f'__version__ = "{new_version}"', content)
    content = TIMESTAMP_RE.sub(f'__build_timestamp__ = "{now}"', content)

    INIT_FILE.write_text(content, encoding="utf-8")
    return new_version


if __name__ == "__main__":
    part = "build"
    if "--major" in sys.argv:
        part = "major"
    elif "--minor" in sys.argv:
        part = "minor"

    version = bump(part)
    print(version)
