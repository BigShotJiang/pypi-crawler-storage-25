#!/usr/bin/env bash
# skill2tools — launcher script
# Usage: ./skill2tools.sh [--skill SKILL.md] [--agent agent.yaml] [--resume] [--model MODEL]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check for Python 3.11+
if ! command -v python3 &>/dev/null; then
    echo "Error: python3 is required but not found" >&2
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PY_MAJOR=$(echo "$PY_VERSION" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VERSION" | cut -d. -f2)

if [[ "$PY_MAJOR" -lt 3 ]] || { [[ "$PY_MAJOR" -eq 3 ]] && [[ "$PY_MINOR" -lt 11 ]]; }; then
    echo "Error: Python 3.11+ is required (found $PY_VERSION)" >&2
    exit 1
fi

# Auto-install if not yet installed
if ! python3 -c "import skill2tools" &>/dev/null 2>&1; then
    echo "Installing skill2tools..."
    python3 -m pip install -e "$SCRIPT_DIR" --quiet
fi

# Load .env if present
if [[ -f "$SCRIPT_DIR/.env" ]]; then
    export "$(grep -v '^#' "$SCRIPT_DIR/.env" | xargs)"
fi

# Check if a provider is already configured
# The project dir defaults to cwd (same as --project-dir default in the app)
if [[ ! -f "$(pwd)/.skill2tools/config.yaml" ]] && [[ -z "${OPENROUTER_API_KEY:-}" ]]; then
    echo "Note: No AI provider configured yet. The app will guide you through setup." >&2
fi

# Launch the TUI
exec python3 -m skill2tools --project-dir "$(pwd)" "$@"
