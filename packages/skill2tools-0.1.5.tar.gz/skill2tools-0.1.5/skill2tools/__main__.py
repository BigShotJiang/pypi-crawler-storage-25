"""CLI entry point for skill2tools."""

import argparse
import os
import sys

from skill2tools import __version__, __build_timestamp__


def _version_string() -> str:
    v = f"skill2tools {__version__}"
    if __build_timestamp__:
        v += f" (built {__build_timestamp__})"
    return v


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="skill2tools",
        description="Extract, classify, assemble, and test tools from Agent Skill definitions",
    )
    parser.add_argument("--skill", type=str, help="Path to SKILL.md file")
    parser.add_argument("--agent", type=str, default=None, help="Path to agent.yaml file (optional)")
    parser.add_argument("--resume", action="store_true", help="Resume from existing project state")
    parser.add_argument("--openrouter-key", type=str, default=None, help="OpenRouter API key (or set OPENROUTER_API_KEY)")
    parser.add_argument("--model", type=str, default="anthropic/claude-sonnet-4", help="Model ID")
    parser.add_argument("--provider", type=str, choices=["openrouter", "vllm"], default=None, help="AI provider (openrouter or vllm)")
    parser.add_argument("--vllm-url", type=str, default=None, help="vLLM server base URL (e.g., http://localhost:8000)")
    parser.add_argument("--project-dir", type=str, default=".", help="Project directory (default: current)")
    parser.add_argument("--version", action="version", version=_version_string())

    args = parser.parse_args()

    if args.openrouter_key:
        os.environ["OPENROUTER_API_KEY"] = args.openrouter_key

    from skill2tools.app import Skill2ToolsApp

    app = Skill2ToolsApp(
        skill_path=args.skill,
        agent_path=args.agent,
        resume=args.resume,
        model=args.model,
        project_dir=args.project_dir,
    )
    app.run()


if __name__ == "__main__":
    main()
