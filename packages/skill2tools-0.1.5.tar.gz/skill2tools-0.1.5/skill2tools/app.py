"""Skill2Tools Textual App — main application shell."""

from __future__ import annotations

import os

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Header, Footer

from skill2tools.models.config import ProviderConfig
from skill2tools.state.manager import StateManager
from skill2tools.models.project import Phase, ProjectState


class Skill2ToolsApp(App):
    """TUI app to extract, classify, assemble, and test tools from skill definitions."""

    TITLE = "skill2tools"
    SUB_TITLE = "Skill to Tools Pipeline"
    CSS_PATH = "styles.tcss"

    BINDINGS = [
        Binding("q", "quit_app", "Quit", show=True),
        Binding("ctrl+s", "save_state", "Save", show=True),
        Binding("c", "show_config", "Config", show=True),
        Binding("question_mark", "help", "Help", show=True),
    ]

    def __init__(
        self,
        skill_path: str | None = None,
        agent_path: str | None = None,
        resume: bool = False,
        model: str = "anthropic/claude-sonnet-4",
        project_dir: str = ".",
    ) -> None:
        super().__init__()
        self.skill_path = skill_path
        self.agent_path = agent_path
        self.resume = resume
        self.model = model
        self.state_manager = StateManager(project_dir)
        self.project_state: ProjectState | None = None
        self.provider_config: ProviderConfig | None = None
        self.openrouter_key = os.environ.get("OPENROUTER_API_KEY", "")

    def compose(self) -> ComposeResult:
        yield Header()

    def on_mount(self) -> None:
        """Decide which screen to show based on config and resume state."""
        # Initialize file logger
        from skill2tools.services.logger import setup_logger, log
        setup_logger(self.state_manager.state_dir)
        log("App started")

        # Load existing provider config if available
        if self.state_manager.has_config:
            self.provider_config = self.state_manager.load_config()
            self.model = self.provider_config.model
            log(f"Config loaded: provider={self.provider_config.provider.value} model={self.model}")
            # Config exists — skip setup
            if self.resume and self.state_manager.has_existing_state:
                self.project_state = self.state_manager.load_state()
                log(f"Resumed project: {self.project_state.project_name} phase={self.project_state.phase.value}")
                self._push_screen_for_phase(self.project_state.phase)
            else:
                self._push_welcome()
        else:
            log("No config found — showing setup screen")
            # No config yet — show setup screen first
            self._push_setup()

    def _push_setup(self) -> None:
        from skill2tools.screens.setup import SetupScreen
        self.push_screen(SetupScreen())

    def _push_welcome(self) -> None:
        from skill2tools.screens.welcome import WelcomeScreen
        self.push_screen(WelcomeScreen())

    def _push_screen_for_phase(self, phase: Phase) -> None:
        """Push the appropriate screen for the given phase."""
        from skill2tools.screens.welcome import WelcomeScreen
        from skill2tools.screens.analysis import AnalysisScreen
        from skill2tools.screens.classification import ClassificationScreen
        from skill2tools.screens.assembly import AssemblyScreen
        from skill2tools.screens.testing import TestingScreen
        from skill2tools.screens.summary import SummaryScreen

        screen_map = {
            Phase.INIT: WelcomeScreen,
            Phase.ANALYSIS: AnalysisScreen,
            Phase.CLASSIFICATION: ClassificationScreen,
            Phase.ASSEMBLY: AssemblyScreen,
            Phase.TESTING: TestingScreen,
            Phase.COMPLETE: SummaryScreen,
        }

        screen_cls = screen_map.get(phase, WelcomeScreen)
        self.push_screen(screen_cls())

    def advance_to(self, phase: Phase) -> None:
        """Advance the pipeline to the next phase."""
        from skill2tools.services.logger import log
        log(f"Advancing to phase: {phase.value}")
        if self.project_state:
            self.state_manager.update_phase(self.project_state, phase)
        self._push_screen_for_phase(phase)

    def create_llm_client(self):
        """Create an LLM client from the current provider config."""
        from skill2tools.services.llm import LLMClient
        if self.provider_config:
            return LLMClient(self.provider_config)
        # Fallback: legacy OpenRouter-only path
        from skill2tools.models.config import ProviderConfig, ProviderType
        config = ProviderConfig(
            provider=ProviderType.OPENROUTER,
            api_key=self.openrouter_key,
            model=self.model,
        )
        return LLMClient(config)

    def action_quit_app(self) -> None:
        from skill2tools.services.logger import log
        log("App quit")
        if self.project_state:
            self.state_manager.save_state(self.project_state)
        self.exit()

    def action_save_state(self) -> None:
        if self.project_state:
            self.state_manager.save_state(self.project_state)
            self.notify("State saved", severity="information")

    def action_show_config(self) -> None:
        from skill2tools.screens.config import ConfigScreen
        self.push_screen(ConfigScreen())

    def action_help(self) -> None:
        self.notify(
            "skill2tools: Extract tools from skills, classify, assemble, and test.\n"
            "Keys: q=Quit, Ctrl+S=Save, c=Config, ?=Help",
            title="Help",
            severity="information",
        )
