"""StateManager — handles project directory I/O, state persistence, and global config."""

from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path

import yaml

from skill2tools.models.config import ProviderConfig
from skill2tools.models.project import Phase, ProjectState
from skill2tools.models.tool import Tool


class StateManager:
    """Manages the project directory and all state files.

    Global configuration (provider/API keys) is stored in ~/.skill2tools/config.yaml.
    Project files (skill/, tools/, flow/, etc.) are stored directly in the project directory.
    """

    GLOBAL_CONFIG_DIR = ".skill2tools"
    STATE_FILE = "skill2tools.yaml"
    CONFIG_FILE = "config.yaml"

    def __init__(self, project_dir: str | Path) -> None:
        self.project_dir = Path(project_dir).resolve()
        # Project state lives directly in project_dir (no .skill2tools subdirectory)
        self.state_dir = self.project_dir
        # Global config lives in ~/.skill2tools/
        self.global_config_dir = Path.home() / self.GLOBAL_CONFIG_DIR

    @property
    def has_existing_state(self) -> bool:
        return (self.state_dir / self.STATE_FILE).exists()

    @property
    def has_config(self) -> bool:
        return (self.global_config_dir / self.CONFIG_FILE).exists()

    def load_config(self) -> ProviderConfig:
        """Load provider config from ~/.skill2tools/config.yaml."""
        config_file = self.global_config_dir / self.CONFIG_FILE
        data = yaml.safe_load(config_file.read_text(encoding="utf-8")) or {}
        return ProviderConfig.from_dict(data)

    def save_config(self, config: ProviderConfig) -> None:
        """Write provider config to ~/.skill2tools/config.yaml."""
        self.global_config_dir.mkdir(parents=True, exist_ok=True)
        config_file = self.global_config_dir / self.CONFIG_FILE
        config_file.write_text(
            yaml.dump(config.to_dict(), default_flow_style=False), encoding="utf-8"
        )

    def initialize_project(
        self,
        name: str,
        skill_path: str,
        agent_path: str | None = None,
        model: str = "anthropic/claude-sonnet-4",
    ) -> ProjectState:
        """Create the project directory tree and initialize state."""
        dirs = [
            self.state_dir / "skill",
            self.state_dir / "agent",
            self.state_dir / "tools",
            self.state_dir / "flow",
            self.state_dir / "status",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)

        # Copy input files
        skill_src = Path(skill_path).resolve()
        skill_dest = self.state_dir / "skill" / "SKILL.md"
        shutil.copy2(skill_src, skill_dest)

        if agent_path:
            agent_src = Path(agent_path).resolve()
            agent_dest = self.state_dir / "agent" / "agent.yaml"
            shutil.copy2(agent_src, agent_dest)

        state = ProjectState(
            project_name=name,
            phase=Phase.INIT,
            skill_path=str(skill_src),
            agent_path=str(Path(agent_path).resolve()) if agent_path else "",
            model=model,
        )

        self.save_state(state)
        self._write_flow("init", "project_initialized")
        return state

    def load_state(self) -> ProjectState:
        """Load project state from skill2tools.yaml + tool files."""
        state_file = self.state_dir / self.STATE_FILE
        data = yaml.safe_load(state_file.read_text(encoding="utf-8")) or {}

        tools = self._load_tools()
        return ProjectState.from_dict(data, tools=tools)

    def save_state(self, state: ProjectState) -> None:
        """Write project state to skill2tools.yaml and all tool.yaml files."""
        state.touch()
        state_file = self.state_dir / self.STATE_FILE
        state_file.write_text(yaml.dump(state.to_dict(), default_flow_style=False), encoding="utf-8")

        for tool in state.tools:
            self.save_tool(tool)

    def save_tool(self, tool: Tool) -> None:
        """Write a single tool's state to its tool.yaml."""
        tool_dir = self.state_dir / "tools" / tool.name
        tool_dir.mkdir(parents=True, exist_ok=True)

        for subdir in ["implementation", "integration", "tests"]:
            (tool_dir / subdir).mkdir(exist_ok=True)

        tool_file = tool_dir / "tool.yaml"
        tool_file.write_text(yaml.dump(tool.to_dict(), default_flow_style=False), encoding="utf-8")

    def save_tools_md(self, tools: list[Tool]) -> None:
        """Generate the camp-format tools.md catalog."""
        lines = ["# Tools Catalog", ""]
        for tool in tools:
            lines.append(tool.to_tools_md_entry())
            lines.append("")
            lines.append("---")
            lines.append("")

        tools_md = self.state_dir / "tools" / "tools.md"
        tools_md.write_text("\n".join(lines), encoding="utf-8")

    def update_phase(self, state: ProjectState, phase: Phase) -> None:
        """Update the project phase and persist."""
        state.phase = phase
        self.save_state(state)
        self._write_flow(phase.value, "phase_entered")

    def save_test_result(self, tool_name: str, result: dict) -> None:
        """Write test results.json for a tool."""
        results_file = self.state_dir / "tools" / tool_name / "tests" / "results.json"
        results_file.parent.mkdir(parents=True, exist_ok=True)
        import json
        results_file.write_text(json.dumps(result, indent=2), encoding="utf-8")

    def save_implementation(self, tool_name: str, filename: str, content: str) -> None:
        """Write an implementation file for a BIN tool."""
        impl_dir = self.state_dir / "tools" / tool_name / "implementation"
        impl_dir.mkdir(parents=True, exist_ok=True)
        (impl_dir / filename).write_text(content, encoding="utf-8")

    def save_integration(self, tool_name: str, filename: str, content: str) -> None:
        """Write an integration config file for an MCP/API tool."""
        integ_dir = self.state_dir / "tools" / tool_name / "integration"
        integ_dir.mkdir(parents=True, exist_ok=True)
        (integ_dir / filename).write_text(content, encoding="utf-8")

    def save_test_file(self, tool_name: str, content: str) -> None:
        """Write the auto-generated test file for a tool."""
        test_dir = self.state_dir / "tools" / tool_name / "tests"
        test_dir.mkdir(parents=True, exist_ok=True)
        (test_dir / "test_tool.py").write_text(content, encoding="utf-8")

    def get_tool_dir(self, tool_name: str) -> Path:
        return self.state_dir / "tools" / tool_name

    def update_status_files(self, tools: list[Tool]) -> None:
        """Update status/implementation.yaml and status/testing.yaml."""
        status_dir = self.state_dir / "status"
        status_dir.mkdir(parents=True, exist_ok=True)

        impl_status = {}
        test_status = {}
        for t in tools:
            impl_status[t.name] = {
                "classification": t.classification.value if t.classification else "pending",
                "status": t.status.value,
            }
            if t.test_result:
                test_status[t.name] = t.test_result

        (status_dir / "implementation.yaml").write_text(
            yaml.dump(impl_status, default_flow_style=False), encoding="utf-8"
        )
        (status_dir / "testing.yaml").write_text(
            yaml.dump(test_status or {"no_results_yet": True}, default_flow_style=False), encoding="utf-8"
        )

    # --- Private helpers ---

    def _load_tools(self) -> list[Tool]:
        """Load all tool.yaml files from tools/*/tool.yaml."""
        tools_dir = self.state_dir / "tools"
        tools = []
        if not tools_dir.exists():
            return tools

        for tool_dir in sorted(tools_dir.iterdir()):
            tool_file = tool_dir / "tool.yaml"
            if tool_file.exists():
                data = yaml.safe_load(tool_file.read_text(encoding="utf-8")) or {}
                tools.append(Tool.from_dict(data))

        return tools

    def _write_flow(self, phase: str, event: str) -> None:
        """Update flow/execution.yaml and append to flow/history.yaml."""
        flow_dir = self.state_dir / "flow"
        flow_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now(timezone.utc).isoformat()

        # execution.yaml — current state
        execution = {
            "current_phase": phase,
            "last_event": event,
            "updated_at": now,
        }
        (flow_dir / "execution.yaml").write_text(
            yaml.dump(execution, default_flow_style=False), encoding="utf-8"
        )

        # history.yaml — append-only
        history_file = flow_dir / "history.yaml"
        history = []
        if history_file.exists():
            history = yaml.safe_load(history_file.read_text(encoding="utf-8")) or []
        history.append({"timestamp": now, "phase": phase, "event": event})
        history_file.write_text(yaml.dump(history, default_flow_style=False), encoding="utf-8")
