"""Tool model — core data model with classification and status enums."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ToolClassification(Enum):
    AVAILABLE = "available"
    MCP = "mcp"
    API = "api"
    BIN = "bin"


class ToolStatus(Enum):
    PENDING = "pending"
    CLASSIFYING = "classifying"
    CLASSIFIED = "classified"
    ASSEMBLING = "assembling"
    ASSEMBLED = "assembled"
    TESTING = "testing"
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"


@dataclass
class ToolParameter:
    name: str
    type: str
    description: str = ""
    required: bool = True

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "type": self.type,
            "description": self.description,
            "required": self.required,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ToolParameter:
        return cls(
            name=data.get("name", ""),
            type=data.get("type", "string"),
            description=data.get("description", ""),
            required=data.get("required", True),
        )


@dataclass
class Tool:
    name: str
    description: str
    classification: ToolClassification | None = None
    classification_confidence: float = 0.0
    classification_reasoning: str = ""
    status: ToolStatus = ToolStatus.PENDING
    type_hint: str = ""  # database, computation, api, mcp, bin
    data_source: str = ""
    permissions: list[str] = field(default_factory=list)
    parameters: list[ToolParameter] = field(default_factory=list)
    context7_match: str | None = None
    context7_docs: str | None = None
    test_result: dict | None = None
    implementation_lang: str = ""  # python, shell, or empty

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "classification": self.classification.value if self.classification else None,
            "classification_confidence": self.classification_confidence,
            "classification_reasoning": self.classification_reasoning,
            "status": self.status.value,
            "type_hint": self.type_hint,
            "data_source": self.data_source,
            "permissions": self.permissions,
            "parameters": [p.to_dict() for p in self.parameters],
            "context7_match": self.context7_match,
            "test_result": self.test_result,
            "implementation_lang": self.implementation_lang,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Tool:
        classification = None
        if data.get("classification"):
            classification = ToolClassification(data["classification"])

        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            classification=classification,
            classification_confidence=data.get("classification_confidence", 0.0),
            classification_reasoning=data.get("classification_reasoning", ""),
            status=ToolStatus(data.get("status", "pending")),
            type_hint=data.get("type_hint", ""),
            data_source=data.get("data_source", ""),
            permissions=data.get("permissions") or [],
            parameters=[ToolParameter.from_dict(p) for p in (data.get("parameters") or [])],
            context7_match=data.get("context7_match"),
            test_result=data.get("test_result"),
            implementation_lang=data.get("implementation_lang", ""),
        )

    @property
    def classification_label(self) -> str:
        if self.classification is None:
            return "PENDING"
        return self.classification.value.upper()

    @property
    def status_label(self) -> str:
        return self.status.value.upper()

    def to_tools_md_entry(self) -> str:
        """Generate a camp-format tools.md entry for this tool."""
        lines = [f"## {self.name}", "", self.description, ""]
        lines.append(f"**Type:** {self.type_hint or self.classification_label.lower()}")
        if self.data_source:
            lines.append(f"**Data source:** {self.data_source}")
        if self.permissions:
            lines.append(f"**Permissions:** {', '.join(self.permissions)}")
        if self.parameters:
            params_str = ", ".join(f"{p.name} ({p.type})" for p in self.parameters)
            lines.append(f"**Parameters:** {params_str}")
        if self.classification:
            lines.append(f"**Classification:** {self.classification_label}")
        return "\n".join(lines)
