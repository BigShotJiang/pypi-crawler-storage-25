"""AgentConfig model — parses agent.yaml files."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class AgentConfig:
    agent_id: str
    name: str
    description: str
    version: str = "1.0"
    domain: str = ""
    primary_zone: str = ""
    processing_pattern: str = ""
    primary_model: str = ""
    fallback_model: str = ""
    supported_intents: list[str] = field(default_factory=list)
    complexity_class: str = ""
    tool_categories: list[str] = field(default_factory=list)
    tool_names: list[str] = field(default_factory=list)
    source_path: str | None = None

    @classmethod
    def from_file(cls, path: str | Path) -> AgentConfig:
        path = Path(path)
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        return cls.from_dict(data, source_path=str(path))

    @classmethod
    def from_dict(cls, data: dict, source_path: str | None = None) -> AgentConfig:
        return cls(
            agent_id=data.get("agent_id", ""),
            name=data.get("name", ""),
            description=data.get("description", ""),
            version=str(data.get("version", "1.0")),
            domain=data.get("domain", ""),
            primary_zone=data.get("primary_zone", ""),
            processing_pattern=data.get("processing_pattern", ""),
            primary_model=data.get("primary_model", ""),
            fallback_model=data.get("fallback_model", ""),
            supported_intents=data.get("supported_intents") or [],
            complexity_class=data.get("complexity_class", ""),
            tool_categories=data.get("tool_categories") or [],
            tool_names=data.get("tool_names") or [],
            source_path=source_path,
        )

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "domain": self.domain,
            "primary_zone": self.primary_zone,
            "processing_pattern": self.processing_pattern,
            "primary_model": self.primary_model,
            "fallback_model": self.fallback_model,
            "supported_intents": self.supported_intents,
            "complexity_class": self.complexity_class,
            "tool_categories": self.tool_categories,
            "tool_names": self.tool_names,
        }
