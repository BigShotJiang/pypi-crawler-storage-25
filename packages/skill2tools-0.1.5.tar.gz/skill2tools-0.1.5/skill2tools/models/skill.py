"""SkillDocument model — parses SKILL.md files following the Agent Skills spec."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class SkillDocument:
    name: str
    description: str
    body: str
    license: str | None = None
    compatibility: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)
    allowed_tools: list[str] = field(default_factory=list)
    source_path: str | None = None

    @classmethod
    def from_file(cls, path: str | Path) -> SkillDocument:
        path = Path(path)
        text = path.read_text(encoding="utf-8")
        return cls.from_text(text, source_path=str(path))

    @classmethod
    def from_text(cls, text: str, source_path: str | None = None) -> SkillDocument:
        text = text.strip()

        if text.startswith("---"):
            # Parse YAML frontmatter
            try:
                end = text.index("---", 3)
            except ValueError:
                raise ValueError("SKILL.md has opening --- but no closing ---")
            frontmatter_raw = text[3:end].strip()
            body = text[end + 3:].strip()
            fm = yaml.safe_load(frontmatter_raw) or {}
        else:
            # Plain markdown — no frontmatter
            fm = {}
            body = text

        # Derive name from frontmatter or filename
        name = fm.get("name", "")
        if not name and source_path:
            name = Path(source_path).stem.replace("_", "-").lower()

        # Extract first paragraph as description if not in frontmatter
        description = fm.get("description", "")
        if not description and body:
            first_line = body.split("\n", 1)[0].strip().lstrip("#").strip()
            if first_line:
                description = first_line

        allowed_tools_raw = fm.get("allowed-tools", "")
        allowed_tools = allowed_tools_raw.split() if isinstance(allowed_tools_raw, str) else []

        return cls(
            name=name,
            description=description,
            body=body,
            license=fm.get("license"),
            compatibility=fm.get("compatibility"),
            metadata=fm.get("metadata") or {},
            allowed_tools=allowed_tools,
            source_path=source_path,
        )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "license": self.license,
            "compatibility": self.compatibility,
            "metadata": self.metadata,
            "allowed_tools": self.allowed_tools,
            "source_path": self.source_path,
        }

    @property
    def full_text(self) -> str:
        """Return the complete skill document (frontmatter + body) for AI consumption."""
        parts = ["---"]
        parts.append(f"name: {self.name}")
        parts.append(f"description: {self.description}")
        if self.license:
            parts.append(f"license: {self.license}")
        if self.compatibility:
            parts.append(f"compatibility: {self.compatibility}")
        parts.append("---")
        parts.append("")
        parts.append(self.body)
        return "\n".join(parts)
