"""AI provider configuration model."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ProviderType(Enum):
    OPENROUTER = "openrouter"
    VLLM = "vllm"


@dataclass
class ProviderConfig:
    provider: ProviderType = ProviderType.OPENROUTER
    base_url: str = ""
    api_key: str = ""
    model: str = "anthropic/claude-sonnet-4"

    def to_dict(self) -> dict:
        return {
            "provider": self.provider.value,
            "base_url": self.base_url,
            "api_key": self.api_key,
            "model": self.model,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ProviderConfig:
        return cls(
            provider=ProviderType(data.get("provider", "openrouter")),
            base_url=data.get("base_url", ""),
            api_key=data.get("api_key", ""),
            model=data.get("model", "anthropic/claude-sonnet-4"),
        )
