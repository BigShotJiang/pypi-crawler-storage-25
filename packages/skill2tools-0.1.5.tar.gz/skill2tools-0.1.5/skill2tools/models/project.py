"""ProjectState model — master state tracking for the skill2tools pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum

from skill2tools.models.tool import Tool


class Phase(Enum):
    INIT = "init"
    ANALYSIS = "analysis"
    CLASSIFICATION = "classification"
    ASSEMBLY = "assembly"
    TESTING = "testing"
    COMPLETE = "complete"

    @property
    def screen_name(self) -> str:
        mapping = {
            Phase.INIT: "welcome",
            Phase.ANALYSIS: "analysis",
            Phase.CLASSIFICATION: "classification",
            Phase.ASSEMBLY: "assembly",
            Phase.TESTING: "testing",
            Phase.COMPLETE: "summary",
        }
        return mapping[self]


@dataclass
class ProjectState:
    project_name: str
    phase: Phase = Phase.INIT
    skill_path: str = ""
    agent_path: str = ""
    model: str = "anthropic/claude-sonnet-4"
    tools: list[Tool] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self) -> None:
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now

    def touch(self) -> None:
        self.updated_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        return {
            "project_name": self.project_name,
            "phase": self.phase.value,
            "skill_path": self.skill_path,
            "agent_path": self.agent_path,
            "model": self.model,
            "tools_count": len(self.tools),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict, tools: list[Tool] | None = None) -> ProjectState:
        return cls(
            project_name=data.get("project_name", ""),
            phase=Phase(data.get("phase", "init")),
            skill_path=data.get("skill_path", ""),
            agent_path=data.get("agent_path", ""),
            model=data.get("model", "anthropic/claude-sonnet-4"),
            tools=tools or [],
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
        )
