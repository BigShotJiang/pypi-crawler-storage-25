"""ConfigScreen — view and edit current AI provider configuration."""

from __future__ import annotations

import asyncio

from textual import work
from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal
from textual.screen import Screen
from textual.widgets import Header, Static, Input, Button, Label, RadioSet, RadioButton, RichLog, Select

from skill2tools.models.config import ProviderConfig, ProviderType


class ConfigScreen(Screen):
    """Display and edit the current AI provider configuration."""

    DEFAULT_CSS = """
    ConfigScreen { layout: vertical; }
    .config-title {
        text-align: center; color: $primary;
        width: 100%; text-style: bold;
        margin: 1 0;
    }
    .config-form { margin: 0 2; height: auto; }
    .config-radio { height: auto; margin: 0 0 1 0; }
    #config-vllm-fields { height: auto; display: none; }
    #config-openrouter-fields { height: auto; }
    .config-field-label { height: 1; margin: 0 0 0 1; color: $text-muted; }
    .config-model-row { height: auto; layout: horizontal; }
    .config-model-row Select { width: 1fr; }
    .config-model-row Button { min-width: 12; margin: 0 0 0 1; }
    .config-buttons {
        height: 3; dock: bottom;
        layout: horizontal; align: center middle;
        background: $surface-darken-1;
    }
    .config-buttons Button { margin: 0 1; min-width: 14; }
    #config-status { margin: 0 2; height: 1; text-align: center; }
    #config-log { height: 1fr; min-height: 4; margin: 0 2; border: solid $primary-darken-2; }
    .status-ok { color: $success; }
    .status-err { color: $error; }
    .status-info { color: $warning; }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("Configuration", classes="config-title")
        with Vertical(classes="config-form"):
            with RadioSet(id="config-provider-select", classes="config-radio"):
                yield RadioButton("OpenRouter (cloud)", id="config-radio-openrouter")
                yield RadioButton("vLLM (local)", id="config-radio-vllm")
            with Vertical(id="config-openrouter-fields"):
                yield Label("API Key", classes="config-field-label")
                yield Input(placeholder="sk-or-...", password=True, id="config-openrouter-key")
                yield Label("Model", classes="config-field-label")
                yield Input(value="anthropic/claude-sonnet-4", id="config-openrouter-model")
            with Vertical(id="config-vllm-fields"):
                yield Label("Base URL", classes="config-field-label")
                yield Input(value="http://localhost:8000", id="config-vllm-url")
                yield Label("API Key (optional)", classes="config-field-label")
                yield Input(placeholder="Leave blank if not required", password=True, id="config-vllm-key")
                yield Label("Model", classes="config-field-label")
                with Horizontal(classes="config-model-row"):
                    yield Select([], prompt="Select a model", id="config-vllm-model-select")
                    yield Button("Fetch", variant="warning", id="config-vllm-fetch-btn")
        yield Label("", id="config-status")
        yield RichLog(id="config-log", highlight=True, markup=True)
        with Horizontal(classes="config-buttons"):
            yield Button("Test", variant="warning", id="config-test-btn")
            yield Button("Save", variant="primary", id="config-save-btn")
            yield Button("Back", variant="default", id="config-back-btn")

    def on_mount(self) -> None:
        config: ProviderConfig | None = getattr(self.app, "provider_config", None)
        if not config:
            self._log("Ready. Configure your AI provider and click Test.")
            return

        if config.provider == ProviderType.OPENROUTER:
            self.query_one("#config-radio-openrouter", RadioButton).value = True
            self.query_one("#config-openrouter-key", Input).value = config.api_key
            self.query_one("#config-openrouter-model", Input).value = config.model
            self.query_one("#config-openrouter-fields").display = True
            self.query_one("#config-vllm-fields").display = False
        else:
            self.query_one("#config-radio-vllm", RadioButton).value = True
            self.query_one("#config-vllm-url", Input).value = config.base_url
            self.query_one("#config-vllm-key", Input).value = config.api_key
            select = self.query_one("#config-vllm-model-select", Select)
            select.set_options([(config.model, config.model)])
            select.value = config.model
            self.query_one("#config-openrouter-fields").display = False
            self.query_one("#config-vllm-fields").display = True

        self._log("Ready. Configure your AI provider and click Test.")

    def _log(self, text: str) -> None:
        self.query_one("#config-log", RichLog).write(text)
        import re
        clean = re.sub(r"\[/?[a-z]+\]", "", text)
        from skill2tools.services.logger import log
        log(clean)

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        is_openrouter = event.radio_set.pressed_index == 0
        self.query_one("#config-openrouter-fields").display = is_openrouter
        self.query_one("#config-vllm-fields").display = not is_openrouter

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "config-save-btn":
            self._save_config()
        elif event.button.id == "config-back-btn":
            self.app.pop_screen()
        elif event.button.id == "config-test-btn":
            self._run_test()
        elif event.button.id == "config-vllm-fetch-btn":
            self._fetch_models()

    def _get_vllm_model(self) -> str:
        select = self.query_one("#config-vllm-model-select", Select)
        return str(select.value) if select.value != Select.BLANK else ""

    def _build_config(self):
        """Build a ProviderConfig from current form values. Returns (config, error_msg)."""
        radio_set = self.query_one("#config-provider-select", RadioSet)
        is_openrouter = radio_set.pressed_index == 0

        if is_openrouter:
            api_key = self.query_one("#config-openrouter-key", Input).value.strip()
            model = self.query_one("#config-openrouter-model", Input).value.strip()
            if not api_key:
                return None, "API key is required"
            if not model:
                return None, "Model is required"
            return ProviderConfig(provider=ProviderType.OPENROUTER, api_key=api_key, model=model), None
        else:
            base_url = self.query_one("#config-vllm-url", Input).value.strip()
            api_key = self.query_one("#config-vllm-key", Input).value.strip()
            model = self._get_vllm_model()
            if not base_url:
                return None, "Base URL is required"
            if not model:
                return None, "Model is required — click Fetch to load available models"
            return ProviderConfig(provider=ProviderType.VLLM, base_url=base_url, api_key=api_key, model=model), None

    def _set_status(self, text: str, cls: str = "status-info") -> None:
        label = self.query_one("#config-status", Label)
        label.update(text)
        label.set_classes(cls)

    @work(thread=True)
    def _fetch_models(self) -> None:
        """Fetch available models from the vLLM server."""
        import httpx

        base_url = self.query_one("#config-vllm-url", Input).value.strip()
        if not base_url:
            self.app.call_from_thread(self._set_status, "Base URL is required", "status-err")
            return

        api_key = self.query_one("#config-vllm-key", Input).value.strip()

        self.app.call_from_thread(self._set_status, "Fetching models...", "status-info")
        self.app.call_from_thread(self._log, f"Fetching models from {base_url}/v1/models")

        url = f"{base_url.rstrip('/')}/v1/models"
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        try:
            with httpx.Client(timeout=10.0) as client:
                resp = client.get(url, headers=headers)
                resp.raise_for_status()
                data = resp.json()

            models = []
            for m in data.get("data", []):
                model_id = m.get("id", "")
                if model_id:
                    models.append(model_id)

            if not models:
                self.app.call_from_thread(self._set_status, "No models found on server", "status-err")
                self.app.call_from_thread(self._log, "[red]No models returned by server[/red]")
                return

            self.app.call_from_thread(self._log, f"[green]Found {len(models)} model(s):[/green] {', '.join(models)}")
            self.app.call_from_thread(self._set_status, f"Found {len(models)} model(s)", "status-ok")

            options = [(m, m) for m in models]

            def _update_select():
                select = self.query_one("#config-vllm-model-select", Select)
                select.set_options(options)
                if len(models) == 1:
                    select.value = models[0]

            self.app.call_from_thread(_update_select)

        except Exception as e:
            msg = str(e)[:150]
            self.app.call_from_thread(self._log, f"[red]Fetch error:[/red] {msg}")
            self.app.call_from_thread(self._set_status, f"Fetch failed: {msg[:80]}", "status-err")

    @work(thread=True)
    def _run_test(self) -> None:
        config, err = self._build_config()
        if err:
            self.app.call_from_thread(self._set_status, err, "status-err")
            self.app.call_from_thread(self._log, f"[red]Validation error:[/red] {err}")
            return

        provider = config.provider.value
        self.app.call_from_thread(self._log, "[bold]--- Test started ---[/bold]")
        self.app.call_from_thread(self._log, f"Provider: {provider}  Model: {config.model}")
        if config.base_url:
            self.app.call_from_thread(self._log, f"URL: {config.base_url}")
        self.app.call_from_thread(self._set_status, "Testing connection...", "status-info")

        from skill2tools.services.llm import LLMClient
        client = LLMClient(config, timeout=15.0)
        self.app.call_from_thread(self._log, "Sending: 'Say OK'")

        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(
                client.chat([{"role": "user", "content": "Say OK"}])
            )
            reply = result.strip()[:120]
            self.app.call_from_thread(self._log, f"[green]Response:[/green] {reply}")
            self.app.call_from_thread(self._set_status, f"Connected — {reply[:80]}", "status-ok")
        except Exception as e:
            msg = str(e)
            self.app.call_from_thread(self._log, f"[red]Error:[/red] {msg}")
            self.app.call_from_thread(self._set_status, f"Failed: {msg[:100]}", "status-err")
        finally:
            loop.run_until_complete(client.close())
            loop.close()
            self.app.call_from_thread(self._log, "[bold]--- Test finished ---[/bold]")

    def _save_config(self) -> None:
        config, err = self._build_config()
        if err:
            self._set_status(err, "status-err")
            self._log(f"[red]Cannot save:[/red] {err}")
            return

        from skill2tools.services.logger import log

        app = self.app
        try:
            app.state_manager.save_config(config)
            app.provider_config = config
            app.model = config.model
            self._log(f"[green]Saved.[/green] {config.provider.value}: {config.model}")
            self._set_status("Configuration saved", "status-ok")
            log(f"Config saved: provider={config.provider.value} model={config.model}")
        except Exception as e:
            self._set_status(f"Error: {e}", "status-err")
            self._log(f"[red]Save error:[/red] {e}")
            log(f"Config save error: {e}", level="error")
