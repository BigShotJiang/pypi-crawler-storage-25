"""FolderPreviewScreen — shows the project folder structure before creation."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal, VerticalScroll
from textual.screen import Screen
from textual.widgets import Header, Static, Button, Label

from skill2tools.models.project import Phase


class FolderPreviewScreen(Screen):
    """Preview the folder structure that will be created for the project."""

    DEFAULT_CSS = """
    FolderPreviewScreen { layout: vertical; }
    .preview-title {
        text-align: center; color: $primary;
        width: 100%; text-style: bold;
        margin: 1 0;
    }
    .preview-subtitle {
        text-align: center; color: $text-muted;
        width: 100%;
        margin: 0 0 1 0;
    }
    .preview-tree-container {
        margin: 0 4; height: 1fr;
        border: solid $primary-darken-2;
        padding: 1 2;
    }
    .preview-tree {
        color: $text;
    }
    .tree-folder { color: dodgerblue; text-style: bold; }
    .tree-file { color: $text; }
    .tree-desc { color: $text-muted; }
    .preview-info {
        margin: 1 4; height: auto;
        color: $text-muted;
    }
    .preview-buttons {
        height: 3; dock: bottom;
        layout: horizontal; align: center middle;
        background: $surface-darken-1;
    }
    .preview-buttons Button { margin: 0 1; min-width: 14; }
    """

    def __init__(
        self,
        project_name: str,
        skill_path: str,
        agent_path: str | None = None,
    ) -> None:
        super().__init__()
        self.project_name = project_name
        self.skill_path = skill_path
        self.agent_path = agent_path

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("skill2tools — Folder Structure Preview", classes="preview-title")
        yield Static(
            f"The following structure will be created in: {self.app.state_manager.project_dir}",
            classes="preview-subtitle",
        )
        with VerticalScroll(classes="preview-tree-container"):
            yield Static(self._build_tree(), classes="preview-tree")
        yield Static(
            "Global configuration is stored in: ~/.skill2tools/config.yaml",
            classes="preview-info",
        )
        with Horizontal(classes="preview-buttons"):
            yield Button("Back", variant="default", id="preview-back-btn")
            yield Button("Create & Continue", variant="primary", id="preview-create-btn")

    def _build_tree(self) -> str:
        """Build an ASCII tree representation of the folder structure."""
        base = self.app.state_manager.project_dir
        skill_filename = Path(self.skill_path).name

        lines = [
            f"[bold dodgerblue]{base.name}/[/bold dodgerblue]",
            f"  [dodgerblue]skill/[/dodgerblue]",
            f"    {skill_filename}                [dim]# Input skill document[/dim]",
        ]

        if self.agent_path:
            agent_filename = Path(self.agent_path).name
            lines.append(f"  [dodgerblue]agent/[/dodgerblue]")
            lines.append(f"    {agent_filename}              [dim]# Agent configuration[/dim]")
        else:
            lines.append(f"  [dodgerblue]agent/[/dodgerblue]                      [dim]# Agent configuration (empty)[/dim]")

        lines.extend([
            f"  [dodgerblue]tools/[/dodgerblue]",
            f"    [dim]<tool_name>/[/dim]",
            f"      tool.yaml              [dim]# Tool metadata[/dim]",
            f"      [dodgerblue]implementation/[/dodgerblue]      [dim]# Generated code[/dim]",
            f"      [dodgerblue]integration/[/dodgerblue]         [dim]# Config files (MCP/API)[/dim]",
            f"      [dodgerblue]tests/[/dodgerblue]",
            f"        test_tool.py         [dim]# Auto-generated tests[/dim]",
            f"        results.json         [dim]# Test results[/dim]",
            f"    tools.md                 [dim]# Final tools catalog[/dim]",
            f"  [dodgerblue]flow/[/dodgerblue]",
            f"    execution.yaml           [dim]# Current phase state[/dim]",
            f"    history.yaml             [dim]# Execution event log[/dim]",
            f"  [dodgerblue]status/[/dodgerblue]",
            f"    implementation.yaml      [dim]# Classification status[/dim]",
            f"    testing.yaml             [dim]# Test results summary[/dim]",
            f"  skill2tools.yaml           [dim]# Project state[/dim]",
            f"  skill2tools.log            [dim]# Application log[/dim]",
        ])

        return "\n".join(lines)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "preview-back-btn":
            self.app.pop_screen()
        elif event.button.id == "preview-create-btn":
            self._create_and_continue()

    def _create_and_continue(self) -> None:
        from skill2tools.services.logger import log

        app = self.app
        try:
            log(f"Initializing project: {self.project_name} skill={self.skill_path} agent={self.agent_path}")
            state = app.state_manager.initialize_project(
                name=self.project_name,
                skill_path=self.skill_path,
                agent_path=self.agent_path,
                model=app.model,
            )
            app.project_state = state
            log(f"Project initialized: {self.project_name}")
            app.advance_to(Phase.ANALYSIS)
        except Exception as e:
            self.notify(f"Error: {e}", severity="error")
            log(f"Project init error: {e}", level="error")
