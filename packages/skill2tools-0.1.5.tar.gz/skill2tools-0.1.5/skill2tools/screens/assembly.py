"""AssemblyScreen — build/integrate each tool based on classification."""

from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Button, ProgressBar

from skill2tools.models.project import Phase
from skill2tools.services.assembler import AssemblerService
from skill2tools.widgets.log_panel import LogPanel
from skill2tools.widgets.phase_indicator import PhaseIndicator
from skill2tools.widgets.tool_table import ToolTable


class AssemblyScreen(Screen):
    """Assemble tools: validate AVAILABLE, generate configs, build BIN tools."""

    DEFAULT_CSS = """
    AssemblyScreen {
        layout: vertical;
    }
    .assembly-header {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin: 1 0;
        width: 100%;
    }
    .assembly-info {
        margin: 0 2;
        color: $text-muted;
        height: auto;
    }
    #assembly-progress {
        margin: 0 2;
        height: 3;
    }
    #continue-test-btn {
        margin: 1 2;
        dock: bottom;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield PhaseIndicator(Phase.ASSEMBLY)

        yield Static("Tool Assembly", classes="assembly-header")
        yield Static("Assembling tools...", classes="assembly-info", id="assembly-status")
        yield ProgressBar(total=100, show_eta=True, id="assembly-progress")
        yield ToolTable(show_classification=True, show_status=True, id="assembly-tools")
        yield LogPanel(title="Assembly Log", id="assembly-log")
        yield Button("Continue to Testing", variant="primary", id="continue-test-btn", disabled=True)

        yield Footer()

    def on_mount(self) -> None:
        state = self.app.project_state
        tool_table = self.query_one("#assembly-tools", ToolTable)
        tool_table.update_tools(state.tools)

        progress = self.query_one("#assembly-progress", ProgressBar)
        progress.update(total=len(state.tools), progress=0)

        self._run_assembly()

    @work(thread=True)
    def _run_assembly(self) -> None:
        import asyncio
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(self._assemble())
        finally:
            loop.close()

    async def _assemble(self) -> None:
        app = self.app
        state = app.project_state
        tools = state.tools

        client = app.create_llm_client()

        log_panel = self.query_one("#assembly-log", LogPanel)
        tool_table = self.query_one("#assembly-tools", ToolTable)
        progress = self.query_one("#assembly-progress", ProgressBar)
        status_text = self.query_one("#assembly-status", Static)

        assembled_count = 0

        def on_status(msg: str) -> None:
            self.app.call_from_thread(log_panel.write_line, msg)

        try:
            assembler = AssemblerService(client, app.state_manager)

            for i, tool in enumerate(tools):
                on_status(f"\n[{i + 1}/{len(tools)}] Assembling: {tool.name}")

                await assembler.assemble_tool(tool, on_status=on_status)
                assembled_count += 1

                self.app.call_from_thread(progress.advance, 1)
                self.app.call_from_thread(tool_table.update_tools, tools)

            # Save all state
            app.state_manager.save_state(state)
            app.state_manager.update_status_files(tools)

            self.app.call_from_thread(
                status_text.update,
                f"Assembly complete. {assembled_count}/{len(tools)} tools assembled.",
            )

            continue_btn = self.query_one("#continue-test-btn", Button)
            self.app.call_from_thread(setattr, continue_btn, "disabled", False)

        except Exception as e:
            self.app.call_from_thread(
                status_text.update, f"Error: {e}"
            )
            self.app.call_from_thread(
                log_panel.write_line, f"\n[red]Error: {e}[/red]"
            )
        finally:
            await client.close()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "continue-test-btn":
            self.app.advance_to(Phase.TESTING)
