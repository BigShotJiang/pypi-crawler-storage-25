"""ClassificationScreen — review and override tool classifications."""

from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Button, Select, Label
from textual.containers import Horizontal, Vertical

from skill2tools.models.project import Phase
from skill2tools.models.tool import Tool, ToolClassification, ToolStatus
from skill2tools.services.classifier import ClassifierService
from skill2tools.services.context7 import Context7Client
from skill2tools.widgets.log_panel import LogPanel
from skill2tools.widgets.phase_indicator import PhaseIndicator
from skill2tools.widgets.tool_table import ToolTable


CLASSIFICATION_OPTIONS = [
    ("AVAILABLE — Existing library/package", ToolClassification.AVAILABLE),
    ("MCP — MCP server integration", ToolClassification.MCP),
    ("API — External API integration", ToolClassification.API),
    ("BIN — Custom script/binary", ToolClassification.BIN),
]


class ClassificationScreen(Screen):
    """Review AI classifications, override if needed, then proceed."""

    DEFAULT_CSS = """
    ClassificationScreen {
        layout: vertical;
    }
    .classification-header {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin: 1 0;
        width: 100%;
    }
    .classification-info {
        margin: 0 2;
        color: $text-muted;
        height: auto;
    }
    .override-bar {
        dock: bottom;
        height: 5;
        layout: horizontal;
        padding: 0 2;
        background: $surface-darken-1;
    }
    .override-bar Label {
        margin: 1 1 0 0;
        width: auto;
    }
    .override-bar Select {
        width: 40;
        margin: 0 1;
    }
    .override-bar Button {
        margin: 0 1;
    }
    #accept-btn {
        margin: 1 2;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._selected_tool_name: str | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield PhaseIndicator(Phase.CLASSIFICATION)

        yield Static("Tool Classification", classes="classification-header")
        yield Static(
            "AI is classifying tools. Review and override if needed.",
            classes="classification-info",
            id="class-status",
        )
        yield ToolTable(show_classification=True, show_status=True, id="class-tools")
        yield LogPanel(title="Classification Log", id="class-log")

        with Horizontal(classes="override-bar"):
            yield Label("Override selected:")
            yield Select(
                [(label, val) for label, val in CLASSIFICATION_OPTIONS],
                id="class-select",
                allow_blank=True,
                prompt="Select classification",
            )
            yield Button("Apply", variant="warning", id="apply-override")
            yield Button("Accept & Continue", variant="primary", id="accept-btn", disabled=True)

        yield Footer()

    def on_mount(self) -> None:
        state = self.app.project_state
        tools = state.tools

        # Check if tools are already classified
        all_classified = all(t.status.value in ("classified", "assembled", "passed", "failed") for t in tools)
        if all_classified and tools:
            self._show_classified(tools)
        else:
            self._run_classification()

    def _show_classified(self, tools: list[Tool]) -> None:
        tool_table = self.query_one("#class-tools", ToolTable)
        tool_table.update_tools(tools)
        status = self.query_one("#class-status", Static)
        status.update(f"All {len(tools)} tools classified. Review and continue.")
        accept_btn = self.query_one("#accept-btn", Button)
        accept_btn.disabled = False

    @work(thread=True)
    def _run_classification(self) -> None:
        import asyncio
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(self._classify())
        finally:
            loop.close()

    async def _classify(self) -> None:
        app = self.app
        state = app.project_state
        tools = state.tools

        client = app.create_llm_client()
        context7 = Context7Client()

        log_panel = self.query_one("#class-log", LogPanel)
        tool_table = self.query_one("#class-tools", ToolTable)
        status_text = self.query_one("#class-status", Static)

        def on_status(msg: str) -> None:
            self.app.call_from_thread(log_panel.write_line, msg)

        try:
            classifier = ClassifierService(client, context7)
            await classifier.classify_all(tools, on_status=on_status)

            # Save state
            app.state_manager.save_state(state)

            # Update UI
            self.app.call_from_thread(tool_table.update_tools, tools)
            self.app.call_from_thread(
                status_text.update,
                f"Classification complete. {len(tools)} tools classified.",
            )

            accept_btn = self.query_one("#accept-btn", Button)
            self.app.call_from_thread(setattr, accept_btn, "disabled", False)

        except Exception as e:
            self.app.call_from_thread(
                status_text.update, f"Error: {e}"
            )
            self.app.call_from_thread(
                log_panel.write_line, f"\n[red]Error: {e}[/red]"
            )
        finally:
            await client.close()

    def on_data_table_row_selected(self, event) -> None:
        if event.row_key and event.row_key.value:
            self._selected_tool_name = event.row_key.value

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "apply-override":
            self._apply_override()
        elif event.button.id == "accept-btn":
            self.app.advance_to(Phase.ASSEMBLY)

    def _apply_override(self) -> None:
        if not self._selected_tool_name:
            self.notify("Select a tool row first", severity="warning")
            return

        select = self.query_one("#class-select", Select)
        if select.value is Select.BLANK:
            self.notify("Select a classification", severity="warning")
            return

        new_classification = select.value
        state = self.app.project_state

        for tool in state.tools:
            if tool.name == self._selected_tool_name:
                tool.classification = new_classification
                tool.classification_confidence = 1.0
                tool.classification_reasoning = "Manual override by user"
                break

        self.app.state_manager.save_state(state)
        tool_table = self.query_one("#class-tools", ToolTable)
        tool_table.update_tools(state.tools)
        self.notify(f"Override: {self._selected_tool_name} -> {new_classification.value.upper()}")
