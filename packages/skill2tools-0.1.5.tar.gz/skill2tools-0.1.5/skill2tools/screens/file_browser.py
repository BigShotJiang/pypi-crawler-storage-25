"""FileBrowserScreen — modal file browser using Textual's DirectoryTree."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Header, Static, Button, Label, DirectoryTree


class FilteredDirectoryTree(DirectoryTree):
    """DirectoryTree that filters files by allowed extensions."""

    def __init__(self, path: str, extensions: list[str] | None = None, **kwargs) -> None:
        super().__init__(path, **kwargs)
        self.extensions = [e.lower() for e in (extensions or [])]

    def filter_paths(self, paths: list[Path]) -> list[Path]:
        if not self.extensions:
            return paths
        result = []
        for p in paths:
            if p.is_dir():
                result.append(p)
            elif p.suffix.lower() in self.extensions:
                result.append(p)
        return result


class FileBrowserScreen(ModalScreen[str | None]):
    """Modal screen for browsing and selecting a file."""

    DEFAULT_CSS = """
    FileBrowserScreen {
        align: center middle;
    }
    #browser-dialog {
        width: 80%;
        height: 80%;
        border: thick $primary;
        background: $surface;
        padding: 1 2;
    }
    #browser-title {
        text-align: center;
        text-style: bold;
        color: $primary;
        width: 100%;
        height: 1;
        margin: 0 0 1 0;
    }
    #browser-tree {
        height: 1fr;
        border: solid $primary-darken-2;
        margin: 0 0 1 0;
    }
    #browser-selected {
        height: 1;
        margin: 0 0 1 0;
        color: $text-muted;
    }
    #browser-buttons {
        height: 3;
        layout: horizontal;
        align: center middle;
    }
    #browser-buttons Button {
        margin: 0 1;
        min-width: 16;
    }
    """

    def __init__(
        self,
        start_path: str = ".",
        extensions: list[str] | None = None,
        title: str = "Select a file",
    ) -> None:
        super().__init__()
        self.start_path = str(Path(start_path).resolve())
        self.extensions = extensions
        self.browser_title = title
        self._selected_path: str | None = None

    def compose(self) -> ComposeResult:
        with Vertical(id="browser-dialog"):
            yield Static(self.browser_title, id="browser-title")
            yield FilteredDirectoryTree(
                self.start_path,
                extensions=self.extensions,
                id="browser-tree",
            )
            yield Label("No file selected", id="browser-selected")
            with Horizontal(id="browser-buttons"):
                yield Button("Select", variant="primary", id="browser-select-btn", disabled=True)
                yield Button("Cancel", variant="default", id="browser-cancel-btn")

    def on_directory_tree_file_selected(self, event: DirectoryTree.FileSelected) -> None:
        self._selected_path = str(event.path)
        label = self.query_one("#browser-selected", Label)
        label.update(str(event.path))
        self.query_one("#browser-select-btn", Button).disabled = False

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "browser-select-btn" and self._selected_path:
            self.dismiss(self._selected_path)
        elif event.button.id == "browser-cancel-btn":
            self.dismiss(None)
