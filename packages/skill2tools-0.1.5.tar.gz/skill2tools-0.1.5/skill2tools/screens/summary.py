"""SummaryScreen — final dashboard showing all tools, status, and readiness."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Button, TabbedContent, TabPane

from skill2tools.models.project import Phase
from skill2tools.models.tool import ToolClassification, ToolStatus
from skill2tools.widgets.phase_indicator import PhaseIndicator
from skill2tools.widgets.tool_table import ToolTable


class SummaryScreen(Screen):
    """Final dashboard: all tools, their status, test results, readiness %."""

    DEFAULT_CSS = """
    SummaryScreen {
        layout: vertical;
    }
    .summary-header {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin: 1 0;
        width: 100%;
    }
    .summary-stats {
        layout: horizontal;
        height: 5;
        margin: 1 2;
    }
    .stat-box {
        width: 1fr;
        height: 100%;
        content-align: center middle;
        border: solid $primary;
        margin: 0 1;
    }
    .stat-box.success {
        border: solid $success;
        color: $success;
    }
    .stat-box.error {
        border: solid $error;
        color: $error;
    }
    .stat-box.warning {
        border: solid $warning;
        color: $warning;
    }
    .stat-box.info {
        border: solid $primary;
        color: $primary;
    }
    .btn-row {
        dock: bottom;
        height: 3;
        layout: horizontal;
        align: right middle;
        padding: 0 2;
        background: $surface-darken-1;
    }
    .btn-row Button {
        margin: 0 1;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield PhaseIndicator(Phase.COMPLETE)

        yield Static("Pipeline Summary", classes="summary-header")

        # Stats boxes
        with Horizontal(classes="summary-stats"):
            yield Static("", id="stat-total", classes="stat-box info")
            yield Static("", id="stat-passed", classes="stat-box success")
            yield Static("", id="stat-failed", classes="stat-box error")
            yield Static("", id="stat-readiness", classes="stat-box warning")

        # Tabbed details
        with TabbedContent():
            with TabPane("All Tools", id="tab-all"):
                yield ToolTable(show_classification=True, show_status=True, id="summary-all-tools")
            with TabPane("By Classification", id="tab-class"):
                yield Static("", id="classification-breakdown")
            with TabPane("Test Results", id="tab-tests"):
                yield Static("", id="test-results-detail")
            with TabPane("Project Info", id="tab-project"):
                yield Static("", id="project-info")

        with Horizontal(classes="btn-row"):
            yield Button("Export tools.md", variant="primary", id="export-btn")
            yield Button("Exit", variant="default", id="exit-btn")

        yield Footer()

    def on_mount(self) -> None:
        state = self.app.project_state
        tools = state.tools

        # Update stats
        total = len(tools)
        passed = sum(1 for t in tools if t.status == ToolStatus.PASSED)
        failed = sum(1 for t in tools if t.status in (ToolStatus.FAILED, ToolStatus.ERROR))
        readiness = (passed / total * 100) if total > 0 else 0

        self.query_one("#stat-total", Static).update(f"Total\n{total}")
        self.query_one("#stat-passed", Static).update(f"Passed\n{passed}")
        self.query_one("#stat-failed", Static).update(f"Failed\n{failed}")
        self.query_one("#stat-readiness", Static).update(f"Ready\n{readiness:.0f}%")

        # All tools table
        tool_table = self.query_one("#summary-all-tools", ToolTable)
        tool_table.update_tools(tools)

        # Classification breakdown
        class_lines = []
        for cls in ToolClassification:
            cls_tools = [t for t in tools if t.classification == cls]
            if cls_tools:
                class_lines.append(f"\n[bold]{cls.value.upper()}[/bold] ({len(cls_tools)} tools):")
                for t in cls_tools:
                    status_color = "green" if t.status == ToolStatus.PASSED else "red" if t.status in (ToolStatus.FAILED, ToolStatus.ERROR) else "yellow"
                    class_lines.append(f"  [{status_color}]{t.status_label}[/{status_color}] {t.name} — {t.description[:50]}")
        self.query_one("#classification-breakdown", Static).update("\n".join(class_lines) or "No tools")

        # Test results detail
        test_lines = []
        for t in tools:
            if t.test_result:
                result = t.test_result
                status = "PASS" if result.get("success") else "FAIL"
                color = "green" if result.get("success") else "red"
                test_lines.append(
                    f"[{color}]{status}[/{color}] {t.name}: "
                    f"passed={result.get('passed', 0)}, "
                    f"failed={result.get('failed', 0)}, "
                    f"errors={result.get('errors', 0)}, "
                    f"skipped={result.get('skipped', 0)}"
                )
            else:
                test_lines.append(f"[yellow]SKIP[/yellow] {t.name}: no test results")
        self.query_one("#test-results-detail", Static).update("\n".join(test_lines) or "No test results")

        # Project info
        info_lines = [
            f"[bold]Project:[/bold] {state.project_name}",
            f"[bold]Skill:[/bold] {state.skill_path}",
            f"[bold]Agent:[/bold] {state.agent_path or 'None'}",
            f"[bold]Model:[/bold] {state.model}",
            f"[bold]Created:[/bold] {state.created_at}",
            f"[bold]Updated:[/bold] {state.updated_at}",
            f"[bold]State dir:[/bold] {self.app.state_manager.state_dir}",
        ]
        self.query_one("#project-info", Static).update("\n".join(info_lines))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "export-btn":
            self._export()
        elif event.button.id == "exit-btn":
            self.app.exit()

    def _export(self) -> None:
        state = self.app.project_state
        self.app.state_manager.save_tools_md(state.tools)
        self.app.state_manager.update_status_files(state.tools)
        tools_md_path = self.app.state_manager.state_dir / "tools" / "tools.md"
        self.notify(f"Exported to {tools_md_path}", severity="information")
