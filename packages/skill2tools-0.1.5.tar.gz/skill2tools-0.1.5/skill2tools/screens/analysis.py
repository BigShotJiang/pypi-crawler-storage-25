"""AnalysisScreen — AI tool extraction with streaming output."""

from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal
from textual.screen import Screen
from textual.widgets import Header, Static, Button

from skill2tools.models.project import Phase
from skill2tools.models.skill import SkillDocument
from skill2tools.models.agent import AgentConfig
from skill2tools.services.extractor import ExtractorService
from skill2tools.widgets.log_panel import LogPanel
from skill2tools.widgets.tool_table import ToolTable


class AnalysisScreen(Screen):
    """Extract tools from the skill document using AI."""

    DEFAULT_CSS = """
    AnalysisScreen { layout: vertical; }
    .analysis-title {
        text-align: center; color: $primary;
        width: 100%; text-style: bold;
        margin: 1 0;
    }
    #status-text {
        margin: 0 2; height: 1; color: $text-muted;
    }
    #ai-log {
        height: 5; border: solid $primary-darken-2;
        margin: 0 2;
    }
    #extracted-tools {
        height: 1fr; max-height: 10;
        margin: 0 2;
    }
    .analysis-buttons {
        height: 3; dock: bottom;
        layout: horizontal; align: center middle;
        background: $surface-darken-1;
    }
    .analysis-buttons Button { margin: 0 1; min-width: 14; }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("Tool Extraction", classes="analysis-title")
        yield Static("Analyzing skill document...", id="status-text")
        yield LogPanel(title="AI Output", id="ai-log")
        yield ToolTable(show_classification=False, show_status=False, id="extracted-tools")
        with Horizontal(classes="analysis-buttons"):
            yield Button("Next", variant="primary", id="continue-btn", disabled=True)

    def on_mount(self) -> None:
        self._run_extraction()

    @work(thread=True)
    def _run_extraction(self) -> None:
        """Run tool extraction in a background thread."""
        import asyncio

        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(self._extract())
        finally:
            loop.close()

    async def _extract(self) -> None:
        from skill2tools.services.logger import log

        app = self.app
        state = app.project_state

        skill_path = state.skill_path
        skill = SkillDocument.from_file(skill_path)

        agent = None
        if state.agent_path:
            agent = AgentConfig.from_file(state.agent_path)

        client = app.create_llm_client()

        log_panel = self.query_one("#ai-log", LogPanel)
        status_text = self.query_one("#status-text", Static)

        def on_chunk(chunk: str) -> None:
            self.app.call_from_thread(log_panel.write, chunk)

        try:
            log(f"Extraction started: skill={skill.name}")
            self.app.call_from_thread(
                status_text.update, "Extracting tools from skill document..."
            )
            self.app.call_from_thread(
                log_panel.write_line, f"[bold]Model:[/bold] {state.model}"
            )
            self.app.call_from_thread(
                log_panel.write_line, f"[bold]Skill:[/bold] {skill.name} — {skill.description}\n"
            )

            extractor = ExtractorService(client)
            tools = await extractor.extract_tools(skill, agent, on_chunk=on_chunk)

            state.tools = tools
            app.state_manager.save_state(state)

            log(f"Extraction complete: {len(tools)} tools found")
            self.app.call_from_thread(
                status_text.update,
                f"Extracted {len(tools)} tools",
            )

            tool_table = self.query_one("#extracted-tools", ToolTable)
            self.app.call_from_thread(tool_table.update_tools, tools)

            continue_btn = self.query_one("#continue-btn", Button)
            self.app.call_from_thread(setattr, continue_btn, "disabled", False)

        except Exception as e:
            log(f"Extraction error: {e}", level="error")
            self.app.call_from_thread(
                status_text.update, f"Error: {e}"
            )
            self.app.call_from_thread(
                log_panel.write_line, f"\n[red]Error: {e}[/red]"
            )
        finally:
            await client.close()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "continue-btn":
            self.app.advance_to(Phase.CLASSIFICATION)
