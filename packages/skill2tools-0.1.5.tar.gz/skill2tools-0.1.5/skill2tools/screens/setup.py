"""SetupScreen — AI provider selection and configuration."""

from __future__ import annotations

import asyncio

from textual import work
from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal
from textual.screen import Screen
from textual.widgets import Header, Static, Input, Button, Label, RadioSet, RadioButton, RichLog, Select


class SetupScreen(Screen):
    """Initial setup screen: choose between OpenRouter and vLLM providers."""

    DEFAULT_CSS = """
    SetupScreen { layout: vertical; }
    .setup-title {
        text-align: center; color: $primary;
        width: 100%; text-style: bold;
        margin: 1 0;
    }
    .setup-form { margin: 0 2; height: auto; }
    .provider-radio { height: auto; margin: 0 0 1 0; }
    #vllm-fields { height: auto; display: none; }
    #openrouter-fields { height: auto; }
    .setup-field-label { height: 1; margin: 0 0 0 1; color: $text-muted; }
    .setup-model-row { height: auto; layout: horizontal; }
    .setup-model-row Select { width: 1fr; }
    .setup-model-row Button { min-width: 12; margin: 0 0 0 1; }
    .setup-buttons {
        height: 3; dock: bottom;
        layout: horizontal; align: center middle;
        background: $surface-darken-1;
    }
    .setup-buttons Button { margin: 0 1; min-width: 14; }
    #setup-status { margin: 0 2; height: 1; text-align: center; }
    #setup-log { height: 1fr; min-height: 4; margin: 0 2; border: solid $primary-darken-2; }
    .status-ok { color: $success; }
    .status-err { color: $error; }
    .status-info { color: $warning; }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("AI Provider Setup", classes="setup-title")
        with Vertical(classes="setup-form"):
            with RadioSet(id="provider-select", classes="provider-radio"):
                yield RadioButton("OpenRouter (cloud)", value=True, id="radio-openrouter")
                yield RadioButton("vLLM (local)", id="radio-vllm")
            with Vertical(id="openrouter-fields"):
                yield Label("API Key", classes="setup-field-label")
                yield Input(placeholder="sk-or-...", password=True, id="openrouter-key")
                yield Label("Model", classes="setup-field-label")
                yield Input(value="anthropic/claude-sonnet-4", id="openrouter-model")
            with Vertical(id="vllm-fields"):
                yield Label("Base URL", classes="setup-field-label")
                yield Input(value="http://localhost:8000", id="vllm-url")
                yield Label("API Key (optional)", classes="setup-field-label")
                yield Input(placeholder="Leave blank if not required", password=True, id="vllm-key")
                yield Label("Model", classes="setup-field-label")
                with Horizontal(classes="setup-model-row"):
                    yield Select([], prompt="Select a model", id="vllm-model-select")
                    yield Button("Fetch", variant="warning", id="vllm-fetch-btn")
        yield Label("", id="setup-status")
        yield RichLog(id="setup-log", highlight=True, markup=True)
        with Horizontal(classes="setup-buttons"):
            yield Button("Test", variant="warning", id="setup-test-btn")
            yield Button("Next", variant="primary", id="setup-next-btn")

    def on_mount(self) -> None:
        app = self.app
        config = getattr(app, "provider_config", None)
        if config:
            from skill2tools.models.config import ProviderType
            if config.provider == ProviderType.VLLM:
                self.query_one("#radio-vllm", RadioButton).value = True
                self.query_one("#vllm-url", Input).value = config.base_url
                self.query_one("#vllm-key", Input).value = config.api_key
                # Set the select with the saved model
                select = self.query_one("#vllm-model-select", Select)
                select.set_options([(config.model, config.model)])
                select.value = config.model
            else:
                self.query_one("#openrouter-key", Input).value = config.api_key
                self.query_one("#openrouter-model", Input).value = config.model
        elif hasattr(app, "openrouter_key") and app.openrouter_key:
            self.query_one("#openrouter-key", Input).value = app.openrouter_key
        self._log("Ready. Configure your AI provider and click Test.")

    def _log(self, text: str) -> None:
        self.query_one("#setup-log", RichLog).write(text)
        import re
        clean = re.sub(r"\[/?[a-z]+\]", "", text)
        from skill2tools.services.logger import log
        log(clean)

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        is_openrouter = event.radio_set.pressed_index == 0
        self.query_one("#openrouter-fields").display = is_openrouter
        self.query_one("#vllm-fields").display = not is_openrouter

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "setup-next-btn":
            self._save_and_next()
        elif event.button.id == "setup-test-btn":
            self._run_test()
        elif event.button.id == "vllm-fetch-btn":
            self._fetch_models()

    def _get_vllm_model(self) -> str:
        """Get the selected vLLM model from the Select widget."""
        select = self.query_one("#vllm-model-select", Select)
        return str(select.value) if select.value != Select.BLANK else ""

    def _build_config(self):
        """Build a ProviderConfig from current form values. Returns (config, error_msg)."""
        from skill2tools.models.config import ProviderConfig, ProviderType

        radio_set = self.query_one("#provider-select", RadioSet)
        is_openrouter = radio_set.pressed_index == 0

        if is_openrouter:
            api_key = self.query_one("#openrouter-key", Input).value.strip()
            model = self.query_one("#openrouter-model", Input).value.strip()
            if not api_key:
                return None, "API key is required"
            if not model:
                return None, "Model is required"
            return ProviderConfig(provider=ProviderType.OPENROUTER, api_key=api_key, model=model), None
        else:
            base_url = self.query_one("#vllm-url", Input).value.strip()
            api_key = self.query_one("#vllm-key", Input).value.strip()
            model = self._get_vllm_model()
            if not base_url:
                return None, "Base URL is required"
            if not model:
                return None, "Model is required — click Fetch to load available models"
            return ProviderConfig(provider=ProviderType.VLLM, base_url=base_url, api_key=api_key, model=model), None

    def _set_status(self, text: str, cls: str = "status-info") -> None:
        label = self.query_one("#setup-status", Label)
        label.update(text)
        label.set_classes(cls)

    @work(thread=True)
    def _fetch_models(self) -> None:
        """Fetch available models from the vLLM server."""
        import httpx
        import json

        base_url = self.query_one("#vllm-url", Input).value.strip()
        if not base_url:
            self.app.call_from_thread(self._set_status, "Base URL is required", "status-err")
            return

        api_key = self.query_one("#vllm-key", Input).value.strip()

        self.app.call_from_thread(self._set_status, "Fetching models...", "status-info")
        self.app.call_from_thread(self._log, f"Fetching models from {base_url}/v1/models")

        url = f"{base_url.rstrip('/')}/v1/models"
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        try:
            with httpx.Client(timeout=10.0) as client:
                resp = client.get(url, headers=headers)
                resp.raise_for_status()
                data = resp.json()

            models = []
            for m in data.get("data", []):
                model_id = m.get("id", "")
                if model_id:
                    models.append(model_id)

            if not models:
                self.app.call_from_thread(self._set_status, "No models found on server", "status-err")
                self.app.call_from_thread(self._log, "[red]No models returned by server[/red]")
                return

            self.app.call_from_thread(self._log, f"[green]Found {len(models)} model(s):[/green] {', '.join(models)}")
            self.app.call_from_thread(self._set_status, f"Found {len(models)} model(s)", "status-ok")

            options = [(m, m) for m in models]

            def _update_select():
                select = self.query_one("#vllm-model-select", Select)
                select.set_options(options)
                if len(models) == 1:
                    select.value = models[0]

            self.app.call_from_thread(_update_select)

        except Exception as e:
            msg = str(e)[:150]
            self.app.call_from_thread(self._log, f"[red]Fetch error:[/red] {msg}")
            self.app.call_from_thread(self._set_status, f"Fetch failed: {msg[:80]}", "status-err")

    @work(thread=True)
    def _run_test(self) -> None:
        config, err = self._build_config()
        if err:
            self.app.call_from_thread(self._set_status, err, "status-err")
            self.app.call_from_thread(self._log, f"[red]Validation error:[/red] {err}")
            return

        provider = config.provider.value
        self.app.call_from_thread(self._log, f"[bold]--- Test started ---[/bold]")
        self.app.call_from_thread(self._log, f"Provider: {provider}  Model: {config.model}")
        if config.base_url:
            self.app.call_from_thread(self._log, f"URL: {config.base_url}")
        self.app.call_from_thread(self._set_status, "Testing connection...", "status-info")

        from skill2tools.services.llm import LLMClient
        client = LLMClient(config, timeout=15.0)
        self.app.call_from_thread(self._log, "Sending: 'Say OK'")

        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(
                client.chat([{"role": "user", "content": "Say OK"}])
            )
            reply = result.strip()[:120]
            self.app.call_from_thread(self._log, f"[green]Response:[/green] {reply}")
            self.app.call_from_thread(self._set_status, f"Connected — {reply[:80]}", "status-ok")
        except Exception as e:
            msg = str(e)
            self.app.call_from_thread(self._log, f"[red]Error:[/red] {msg}")
            self.app.call_from_thread(self._set_status, f"Failed: {msg[:100]}", "status-err")
        finally:
            loop.run_until_complete(client.close())
            loop.close()
            self.app.call_from_thread(self._log, "[bold]--- Test finished ---[/bold]")

    def _save_and_next(self) -> None:
        config, err = self._build_config()
        if err:
            self._set_status(err, "status-err")
            self._log(f"[red]Cannot proceed:[/red] {err}")
            return

        app = self.app
        try:
            app.state_manager.save_config(config)
            app.provider_config = config
            app.model = config.model
            self._log(f"[green]Saved.[/green] {config.provider.value}: {config.model}")
            app.pop_screen()
            app._push_welcome()
        except Exception as e:
            self._set_status(f"Error: {e}", "status-err")
            self._log(f"[red]Save error:[/red] {e}")
