"""TestingScreen — run automated tests per tool, show pass/fail."""

from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Button, ProgressBar

from skill2tools.models.project import Phase
from skill2tools.models.tool import ToolStatus
from skill2tools.services.test_generator import TestGeneratorService
from skill2tools.services.test_runner import TestRunnerService
from skill2tools.widgets.log_panel import LogPanel
from skill2tools.widgets.phase_indicator import PhaseIndicator
from skill2tools.widgets.tool_table import ToolTable


class TestingScreen(Screen):
    """Generate and run automated tests for each assembled tool."""

    DEFAULT_CSS = """
    TestingScreen {
        layout: vertical;
    }
    .testing-header {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin: 1 0;
        width: 100%;
    }
    .testing-info {
        margin: 0 2;
        color: $text-muted;
        height: auto;
    }
    #testing-progress {
        margin: 0 2;
        height: 3;
    }
    #view-summary-btn {
        margin: 1 2;
        dock: bottom;
    }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield PhaseIndicator(Phase.TESTING)

        yield Static("Tool Testing", classes="testing-header")
        yield Static("Generating and running tests...", classes="testing-info", id="testing-status")
        yield ProgressBar(total=100, show_eta=True, id="testing-progress")
        yield ToolTable(show_classification=True, show_status=True, id="testing-tools")
        yield LogPanel(title="Test Output", id="testing-log")
        yield Button("View Summary", variant="primary", id="view-summary-btn", disabled=True)

        yield Footer()

    def on_mount(self) -> None:
        state = self.app.project_state
        tool_table = self.query_one("#testing-tools", ToolTable)
        tool_table.update_tools(state.tools)

        progress = self.query_one("#testing-progress", ProgressBar)
        progress.update(total=len(state.tools) * 2, progress=0)  # 2 steps: generate + run

        self._run_testing()

    @work(thread=True)
    def _run_testing(self) -> None:
        import asyncio
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(self._test_all())
        finally:
            loop.close()

    async def _test_all(self) -> None:
        app = self.app
        state = app.project_state
        tools = state.tools

        client = app.create_llm_client()

        log_panel = self.query_one("#testing-log", LogPanel)
        tool_table = self.query_one("#testing-tools", ToolTable)
        progress = self.query_one("#testing-progress", ProgressBar)
        status_text = self.query_one("#testing-status", Static)

        def on_output(msg: str) -> None:
            self.app.call_from_thread(log_panel.write_line, msg)

        passed_count = 0
        failed_count = 0

        try:
            test_gen = TestGeneratorService(client, app.state_manager)
            test_runner = TestRunnerService(app.state_manager)

            for i, tool in enumerate(tools):
                on_output(f"\n{'='*60}")
                on_output(f"[{i + 1}/{len(tools)}] {tool.name}")
                on_output(f"{'='*60}")

                # Step 1: Generate test
                on_output(f"Generating test for {tool.name}...")
                try:
                    await test_gen.generate_test(tool)
                    on_output(f"Test generated successfully")
                except Exception as e:
                    on_output(f"[red]Test generation failed: {e}[/red]")
                    tool.status = ToolStatus.ERROR
                    tool.test_result = {"error": str(e)}
                    self.app.call_from_thread(progress.advance, 2)
                    self.app.call_from_thread(tool_table.update_tools, tools)
                    failed_count += 1
                    continue

                self.app.call_from_thread(progress.advance, 1)

                # Step 2: Run test
                on_output(f"Running test for {tool.name}...")
                result = await test_runner.run_test(tool, on_output=on_output)

                if result.success:
                    passed_count += 1
                    on_output(f"[green]PASSED[/green] ({result.passed} tests passed)")
                else:
                    failed_count += 1
                    on_output(f"[red]FAILED[/red] (passed={result.passed}, failed={result.failed}, errors={result.errors})")

                self.app.call_from_thread(progress.advance, 1)
                self.app.call_from_thread(tool_table.update_tools, tools)

            # Save final state
            app.state_manager.save_state(state)
            app.state_manager.update_status_files(tools)
            app.state_manager.save_tools_md(tools)

            self.app.call_from_thread(
                status_text.update,
                f"Testing complete. {passed_count} passed, {failed_count} failed out of {len(tools)} tools.",
            )

            view_btn = self.query_one("#view-summary-btn", Button)
            self.app.call_from_thread(setattr, view_btn, "disabled", False)

        except Exception as e:
            self.app.call_from_thread(
                status_text.update, f"Error: {e}"
            )
            self.app.call_from_thread(
                log_panel.write_line, f"\n[red]Error: {e}[/red]"
            )
        finally:
            await client.close()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "view-summary-btn":
            self.app.advance_to(Phase.COMPLETE)
