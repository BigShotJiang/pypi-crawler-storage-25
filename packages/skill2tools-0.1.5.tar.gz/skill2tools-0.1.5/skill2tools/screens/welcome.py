"""WelcomeScreen — file selection, project name, initialization."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Vertical, Horizontal
from textual.screen import Screen
from textual.widgets import Header, Static, Input, Button, Label

from skill2tools.widgets.file_picker import FilePicker


class WelcomeScreen(Screen):
    """Select skill file, optional agent file, and project name."""

    _auto_filled_name: bool = False

    DEFAULT_CSS = """
    WelcomeScreen { layout: vertical; }
    .welcome-title {
        text-align: center; color: dodgerblue;
        width: 100%; text-style: bold;
        margin: 1 0;
    }
    .welcome-form { margin: 0 2; height: auto; }
    .welcome-form FilePicker { margin: 0 0; }
    .welcome-field-label { height: 1; margin: 0 0 0 1; color: $text-muted; }
    .welcome-buttons {
        height: 3; dock: bottom;
        layout: horizontal; align: center middle;
        background: $surface-darken-1;
    }
    .welcome-buttons Button { margin: 0 1; min-width: 14; }
    #error-label { color: $error; margin: 0 2; height: 1; }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("skill2tools — Project Setup", classes="welcome-title")
        with Vertical(classes="welcome-form"):
            yield Label("SKILL.md (required)", classes="welcome-field-label")
            yield FilePicker(
                label="SKILL.md",
                placeholder="e.g., ./examples/sample_skill.md",
                required=True,
                extensions=[".md"],
                show_label=False,
                id="skill-picker",
            )
            yield Label("agent.yaml (optional)", classes="welcome-field-label")
            yield FilePicker(
                label="agent.yaml",
                placeholder="e.g., ./examples/sample_agent.yaml",
                required=False,
                extensions=[".yaml", ".yml"],
                show_label=False,
                id="agent-picker",
            )
            yield Label("Project Name", classes="welcome-field-label")
            yield Input(placeholder="Auto-filled from skill file", id="project-name")
        yield Label("", id="error-label")
        with Horizontal(classes="welcome-buttons"):
            yield Button("Back", variant="default", id="welcome-back-btn")
            yield Button("Settings", variant="default", id="welcome-settings-btn")
            yield Button("Next", variant="primary", id="welcome-next-btn")

    def on_mount(self) -> None:
        app = self.app
        if hasattr(app, "skill_path") and app.skill_path:
            picker = self.query_one("#skill-picker", FilePicker)
            picker.query_one("#fp-input", Input).value = app.skill_path
        if hasattr(app, "agent_path") and app.agent_path:
            picker = self.query_one("#agent-picker", FilePicker)
            picker.query_one("#fp-input", Input).value = app.agent_path

    def on_input_changed(self, event: Input.Changed) -> None:
        """Auto-fill project name from skill filename."""
        skill_picker = self.query_one("#skill-picker", FilePicker)
        try:
            skill_input = skill_picker.query_one("#fp-input", Input)
        except Exception:
            return
        if event.input is skill_input:
            project_input = self.query_one("#project-name", Input)
            if not project_input.value.strip() or self._auto_filled_name:
                value = event.value.strip()
                if value:
                    name = Path(value).stem.replace("_", "-").lower()
                    if name:
                        self._auto_filled_name = True
                        project_input.value = name

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "welcome-next-btn":
            self._start()
        elif event.button.id == "welcome-back-btn":
            self.app.pop_screen()
            self.app._push_setup()
        elif event.button.id == "welcome-settings-btn":
            from skill2tools.screens.config import ConfigScreen
            self.app.push_screen(ConfigScreen())

    def _start(self) -> None:
        error_label = self.query_one("#error-label", Label)
        error_label.update("")

        skill_picker = self.query_one("#skill-picker", FilePicker)
        agent_picker = self.query_one("#agent-picker", FilePicker)
        project_name_input = self.query_one("#project-name", Input)

        if not skill_picker.is_valid:
            error_label.update("Please provide a valid SKILL.md path")
            return

        skill_path = skill_picker.resolved_path
        agent_path = agent_picker.resolved_path if agent_picker.is_valid else None

        project_name = project_name_input.value.strip()
        if not project_name:
            project_name = Path(skill_path).stem.replace("_", "-").lower()

        from skill2tools.screens.folder_preview import FolderPreviewScreen
        self.app.push_screen(FolderPreviewScreen(
            project_name=project_name,
            skill_path=skill_path,
            agent_path=agent_path,
        ))
