"""Prompts for AI-powered tool classification."""

from __future__ import annotations

from skill2tools.models.tool import Tool

SYSTEM_PROMPT = """\
You are a tool classifier for an AI agent tool pipeline. Given a tool specification, \
classify it into exactly one of these categories:

- **AVAILABLE**: The tool is a well-known, installable library/package (e.g., pandas, requests, \
psycopg2). It can be used by simply installing it via pip/npm/etc.
- **MCP**: The tool requires integration with an MCP (Model Context Protocol) server. \
MCP servers expose tools over a JSON-RPC protocol. Examples: database query servers, \
code execution servers, documentation servers like Context7.
- **API**: The tool requires calling an external REST/GraphQL HTTP API. Examples: \
Slack API, GitHub API, Stripe API, weather APIs.
- **BIN**: The tool requires building a custom script or binary. It doesn't exist as \
a pre-built package and needs to be implemented from scratch.

Consider these signals:
- If the tool name matches a known Python/JS package → AVAILABLE
- If the description mentions "MCP server" or "protocol server" → MCP
- If the description mentions REST API, HTTP endpoint, webhook → API
- If the tool is highly custom or domain-specific with no existing package → BIN

Return a JSON object with:
{
  "classification": "available|mcp|api|bin",
  "confidence": 0.0-1.0,
  "reasoning": "Brief explanation of why this classification was chosen",
  "implementation_lang": "python|shell|" (only for BIN tools, empty otherwise)
}"""


def build_classification_messages(tool: Tool, context7_info: str | None = None) -> list[dict]:
    """Build messages for classifying a single tool."""
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    user_content = f"""# Tool to Classify

**Name:** {tool.name}
**Description:** {tool.description}
**Type hint:** {tool.type_hint}
**Data source:** {tool.data_source}
**Permissions:** {', '.join(tool.permissions) if tool.permissions else 'none specified'}
**Parameters:** {', '.join(f'{p.name} ({p.type})' for p in tool.parameters) if tool.parameters else 'none'}
"""

    if context7_info:
        user_content += f"""
# Context7 Library Lookup Result
The following was found in the Context7 library catalog:
{context7_info}
"""

    user_content += "\nClassify this tool. Return JSON."
    messages.append({"role": "user", "content": user_content})
    return messages
