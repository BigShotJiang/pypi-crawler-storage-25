"""Prompts for AI-powered tool extraction from skill documents."""

from __future__ import annotations

from skill2tools.models.skill import SkillDocument
from skill2tools.models.agent import AgentConfig

SYSTEM_PROMPT = """\
You are a tool extraction specialist. Given an Agent Skill document (SKILL.md), \
identify every discrete tool the skill needs to function.

For each tool, determine:
- name: A snake_case identifier (e.g., pandas_processor, slack_notifier)
- description: What the tool does (1-2 sentences)
- type_hint: One of: database, computation, api, mcp, bin
  - database: Queries or writes to a database
  - computation: Local data processing, calculations, transformations
  - api: Calls an external HTTP API
  - mcp: Interacts with an MCP (Model Context Protocol) server
  - bin: A standalone script/binary to be built
- data_source: Where the tool gets/puts data (e.g., "PostgreSQL", "REST API", "filesystem")
- permissions: What access the tool needs (e.g., read_data, write_db, network_access)
- parameters: List of parameters with name and type

Return a JSON object with a single key "tools" containing an array of tool objects.

Example output:
{
  "tools": [
    {
      "name": "csv_reader",
      "description": "Reads and parses CSV files into structured data",
      "type_hint": "computation",
      "data_source": "filesystem",
      "permissions": ["read_filesystem"],
      "parameters": [
        {"name": "file_path", "type": "string", "description": "Path to CSV file", "required": true},
        {"name": "delimiter", "type": "string", "description": "Column delimiter", "required": false}
      ]
    }
  ]
}

Be thorough: extract ALL tools mentioned or implied by the skill document. \
Include libraries, APIs, database connectors, notification systems, and any \
custom scripts the skill would need. Each tool should be a discrete, testable unit."""


def build_extraction_messages(
    skill: SkillDocument,
    agent: AgentConfig | None = None,
) -> list[dict]:
    """Build the messages list for the tool extraction OpenRouter call."""
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    user_content = f"# Skill Document\n\n{skill.full_text}"

    if agent:
        user_content += "\n\n# Agent Context\n\n"
        user_content += f"Agent: {agent.name} ({agent.agent_id})\n"
        user_content += f"Domain: {agent.domain}\n"
        if agent.tool_names:
            user_content += f"Known tool names: {', '.join(agent.tool_names)}\n"
        if agent.tool_categories:
            user_content += f"Tool categories: {', '.join(agent.tool_categories)}\n"
        if agent.supported_intents:
            user_content += f"Supported intents: {', '.join(agent.supported_intents)}\n"

    user_content += "\n\nPlease extract all tools from this skill document. Return JSON."

    messages.append({"role": "user", "content": user_content})
    return messages
