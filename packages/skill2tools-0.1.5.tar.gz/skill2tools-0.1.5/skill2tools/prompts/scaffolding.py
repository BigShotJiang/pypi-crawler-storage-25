"""Prompts for generating BIN tool implementations."""

from __future__ import annotations

from skill2tools.models.tool import Tool

SYSTEM_PROMPT_PYTHON = """\
You are a Python tool developer. Generate a complete, self-contained Python script \
for the tool described below.

Requirements:
- The script must have a main() function as entry point
- Use argparse for CLI argument parsing
- Output results as JSON to stdout
- Include proper error handling with sys.exit(1) on failure
- Add a brief docstring at the top
- Import only from the standard library or well-known packages
- The script should be immediately runnable: python tool.py --arg value

Return ONLY the Python code, no markdown fencing or explanation."""

SYSTEM_PROMPT_SHELL = """\
You are a shell script developer. Generate a complete, self-contained bash script \
for the tool described below.

Requirements:
- Start with #!/usr/bin/env bash
- Use set -euo pipefail
- Parse arguments with getopts or positional params
- Output results as JSON to stdout (use jq if needed)
- Include proper error handling
- Add a brief comment header describing the tool
- The script should be immediately runnable: bash tool.sh --arg value

Return ONLY the shell script, no markdown fencing or explanation."""


def build_scaffolding_messages(tool: Tool) -> list[dict]:
    """Build messages for generating a BIN tool implementation."""
    lang = tool.implementation_lang or "python"
    system = SYSTEM_PROMPT_PYTHON if lang == "python" else SYSTEM_PROMPT_SHELL

    messages = [{"role": "system", "content": system}]

    params_desc = ""
    if tool.parameters:
        params_desc = "\n".join(
            f"  - {p.name} ({p.type}): {p.description}" + (" [required]" if p.required else " [optional]")
            for p in tool.parameters
        )

    user_content = f"""# Tool Specification

**Name:** {tool.name}
**Description:** {tool.description}
**Data source:** {tool.data_source}
**Parameters:**
{params_desc or '  None'}

Generate the complete implementation."""

    messages.append({"role": "user", "content": user_content})
    return messages


def build_api_config_messages(tool: Tool) -> list[dict]:
    """Build messages for generating an API integration config."""
    messages = [
        {
            "role": "system",
            "content": (
                "You are an API integration specialist. Given a tool that requires "
                "an external API, generate a YAML configuration for the API integration.\n\n"
                "Return a YAML document with these fields:\n"
                "  base_url: the API base URL\n"
                "  endpoint: the specific endpoint path\n"
                "  method: HTTP method (GET, POST, etc.)\n"
                "  auth_type: none, api_key, bearer, oauth2\n"
                "  auth_header: header name for auth (if applicable)\n"
                "  headers: additional headers (dict)\n"
                "  request_schema: expected request body fields\n"
                "  response_schema: expected response fields\n"
                "  rate_limit: requests per minute (estimate)\n\n"
                "Return ONLY the YAML, no markdown fencing."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Tool: {tool.name}\n"
                f"Description: {tool.description}\n"
                f"Data source: {tool.data_source}\n"
                f"Parameters: {', '.join(f'{p.name} ({p.type})' for p in tool.parameters)}\n\n"
                "Generate the API integration YAML config."
            ),
        },
    ]
    return messages


def build_mcp_config_messages(tool: Tool) -> list[dict]:
    """Build messages for generating an MCP integration config."""
    messages = [
        {
            "role": "system",
            "content": (
                "You are an MCP integration specialist. Given a tool that requires "
                "an MCP server, generate a YAML configuration for the MCP integration.\n\n"
                "Return a YAML document with these fields:\n"
                "  server_name: human-readable server name\n"
                "  server_url: the MCP server endpoint URL (or 'TBD' if unknown)\n"
                "  transport: streamable-http or stdio\n"
                "  tool_name: the tool name as registered in the MCP server\n"
                "  auth_type: none, api_key, bearer\n"
                "  auth_env_var: environment variable name for auth\n"
                "  input_schema: expected tool input parameters\n"
                "  description: what this MCP tool does\n\n"
                "Return ONLY the YAML, no markdown fencing."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Tool: {tool.name}\n"
                f"Description: {tool.description}\n"
                f"Data source: {tool.data_source}\n"
                f"Parameters: {', '.join(f'{p.name} ({p.type})' for p in tool.parameters)}\n\n"
                "Generate the MCP integration YAML config."
            ),
        },
    ]
    return messages
