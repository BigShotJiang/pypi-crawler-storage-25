"""Prompts for AI-powered test case generation."""

from __future__ import annotations

from skill2tools.models.tool import Tool, ToolClassification

SYSTEM_PROMPT = """\
You are a test engineer. Generate a pytest test file for a tool based on its \
classification and specification.

The test file must:
- Import pytest
- Be self-contained and runnable with: python -m pytest test_file.py -v
- Use descriptive test function names
- Include at least 2 test functions
- Handle the case where the tool/dependency is not available gracefully (skip, not fail)

Return ONLY the Python test code, no markdown fencing or explanation."""

AVAILABLE_TEMPLATE = """\
Generate pytest tests for an AVAILABLE tool (existing library/package).

Tests should:
1. test_import() — Verify the package can be imported
2. test_has_expected_interface() — Check the package has expected classes/functions
3. test_basic_usage() — Verify basic functionality with minimal input

If the package isn't installed, use pytest.importorskip() to skip gracefully."""

MCP_TEMPLATE = """\
Generate pytest tests for an MCP tool (Model Context Protocol server integration).

Tests should:
1. test_config_exists() — Verify the MCP config YAML is valid and has required fields
2. test_config_fields() — Check server_url, tool_name, transport fields exist
3. test_connection() — If server URL is available, attempt a basic connection (with timeout)

Use pytest.mark.skipif for network-dependent tests."""

API_TEMPLATE = """\
Generate pytest tests for an API tool (external REST/GraphQL endpoint).

Tests should:
1. test_config_exists() — Verify the API config YAML is valid
2. test_config_fields() — Check base_url, endpoint, method fields
3. test_endpoint_reachable() — HTTP HEAD/GET to the base URL (with timeout)
4. test_response_format() — If reachable, verify response is valid JSON

Use pytest.mark.skipif for network-dependent tests. Use httpx or requests for HTTP."""

BIN_TEMPLATE = """\
Generate pytest tests for a BIN tool (custom-built script).

Tests should:
1. test_script_exists() — Verify the implementation file exists
2. test_script_syntax() — Verify the script has valid syntax (py_compile or bash -n)
3. test_help_flag() — Run the script with --help and check exit code 0
4. test_basic_execution() — Run with minimal valid input and check structured output

Use subprocess.run() to execute the script."""


def build_test_generation_messages(tool: Tool, impl_content: str = "") -> list[dict]:
    """Build messages for generating test cases for a tool."""
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    # Select template based on classification
    template = {
        ToolClassification.AVAILABLE: AVAILABLE_TEMPLATE,
        ToolClassification.MCP: MCP_TEMPLATE,
        ToolClassification.API: API_TEMPLATE,
        ToolClassification.BIN: BIN_TEMPLATE,
    }.get(tool.classification, BIN_TEMPLATE)

    user_content = f"""{template}

# Tool Specification

**Name:** {tool.name}
**Description:** {tool.description}
**Classification:** {tool.classification_label}
**Type:** {tool.type_hint}
**Data source:** {tool.data_source}
**Parameters:** {', '.join(f'{p.name} ({p.type})' for p in tool.parameters) if tool.parameters else 'none'}
"""

    if impl_content:
        user_content += f"""
# Implementation Code (for reference)
```
{impl_content[:3000]}
```
"""

    # Add tool directory context
    user_content += f"""
# File Paths
- Tool directory: tools/{tool.name}/
- Implementation: tools/{tool.name}/implementation/
- Integration: tools/{tool.name}/integration/
- Tests: tools/{tool.name}/tests/

Generate the pytest test file. Return ONLY Python code."""

    messages.append({"role": "user", "content": user_content})
    return messages
