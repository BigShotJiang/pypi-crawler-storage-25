"""TestGeneratorService — AI-powered test case generation for tools."""

from __future__ import annotations

from skill2tools.models.tool import Tool, ToolClassification
from skill2tools.prompts.test_generation import build_test_generation_messages
from skill2tools.services.llm import LLMClient
from skill2tools.state.manager import StateManager


class TestGeneratorService:
    """Generates pytest test files for tools using AI."""

    def __init__(
        self,
        openrouter: LLMClient,
        state_manager: StateManager,
    ) -> None:
        self.openrouter = openrouter
        self.state_manager = state_manager

    async def generate_test(self, tool: Tool) -> str:
        """Generate a pytest test file for a tool.

        Returns the test code as a string.
        """
        # Read implementation content if available (for BIN tools)
        impl_content = ""
        if tool.classification == ToolClassification.BIN:
            impl_content = self._read_implementation(tool)

        messages = build_test_generation_messages(tool, impl_content)
        response = await self.openrouter.chat(messages)

        test_code = self._clean_response(response)

        # Save the test file
        self.state_manager.save_test_file(tool.name, test_code)

        return test_code

    def _read_implementation(self, tool: Tool) -> str:
        """Read the generated implementation file for a BIN tool."""
        tool_dir = self.state_manager.get_tool_dir(tool.name)
        impl_dir = tool_dir / "implementation"

        for ext in (".py", ".sh"):
            impl_file = impl_dir / f"{tool.name}{ext}"
            if impl_file.exists():
                return impl_file.read_text(encoding="utf-8")

        return ""

    def _clean_response(self, response: str) -> str:
        """Strip markdown fencing from the response."""
        response = response.strip()
        if response.startswith("```python"):
            response = response[9:]
        elif response.startswith("```"):
            response = response[3:]
        if response.endswith("```"):
            response = response[:-3]
        return response.strip()
