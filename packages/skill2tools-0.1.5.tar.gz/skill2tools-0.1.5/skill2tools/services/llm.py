"""Unified LLM client — dispatches to OpenRouter or vLLM based on provider config."""

from __future__ import annotations

import json
from typing import AsyncIterator

import httpx

from skill2tools.models.config import ProviderConfig, ProviderType


class LLMClient:
    """Unified async client for chat completions via OpenRouter or vLLM."""

    OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
    VLLM_PATH = "/v1/chat/completions"

    def __init__(self, config: ProviderConfig, timeout: float = 120.0) -> None:
        self.config = config
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def _base_url(self) -> str:
        if self.config.provider == ProviderType.OPENROUTER:
            return self.OPENROUTER_URL
        # vLLM: user-supplied base_url + path
        base = self.config.base_url.rstrip("/")
        return f"{base}{self.VLLM_PATH}"

    def _build_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.config.provider == ProviderType.OPENROUTER:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
            headers["HTTP-Referer"] = "https://github.com/skill2tools"
            headers["X-Title"] = "skill2tools"
        elif self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers=self._build_headers(),
                timeout=self.timeout,
            )
        return self._client

    def _normalize_messages(self, messages: list[dict]) -> list[dict]:
        """Normalize messages for vLLM: merge system role into first user message.

        Many models served via vLLM (e.g., Mistral) require alternating
        user/assistant roles and don't support a system role.
        """
        if self.config.provider != ProviderType.VLLM:
            return messages

        system_parts = []
        other_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_parts.append(msg["content"])
            else:
                other_messages.append(msg)

        if not system_parts:
            return messages

        # Prepend system content to the first user message
        system_text = "\n\n".join(system_parts)
        if other_messages and other_messages[0]["role"] == "user":
            other_messages[0] = {
                "role": "user",
                "content": f"{system_text}\n\n{other_messages[0]['content']}",
            }
        else:
            # No user message to merge into — add as user message
            other_messages.insert(0, {"role": "user", "content": system_text})

        return other_messages

    async def chat(
        self,
        messages: list[dict],
        json_mode: bool = False,
        model: str | None = None,
    ) -> str:
        """Single-shot completion. Returns the content string."""
        from skill2tools.services.logger import log
        used_model = model or self.config.model
        log(f"LLM chat: provider={self.config.provider.value} model={used_model} messages={len(messages)}")

        normalized = self._normalize_messages(messages)
        client = await self._get_client()
        body: dict = {
            "model": used_model,
            "messages": normalized,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        response = await self._request_with_retry(client, body)
        content = response["choices"][0]["message"]["content"]
        log(f"LLM response: {len(content)} chars")
        return content

    async def stream(
        self,
        messages: list[dict],
        model: str | None = None,
    ) -> AsyncIterator[str]:
        """Streaming completion. Yields content chunks."""
        normalized = self._normalize_messages(messages)
        client = await self._get_client()
        body = {
            "model": model or self.config.model,
            "messages": normalized,
            "stream": True,
        }
        url = self._base_url
        async with client.stream("POST", url, json=body) as response:
            if response.status_code >= 400:
                error_body = await response.aread()
                try:
                    detail = json.loads(error_body)
                    msg = detail.get("error", {}).get("message", "") or detail.get("detail", "") or error_body.decode()[:200]
                except Exception:
                    msg = error_body.decode()[:200]
                raise RuntimeError(f"{response.status_code}: {msg}")
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    delta = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
                    if delta:
                        yield delta
                except (json.JSONDecodeError, IndexError, KeyError):
                    continue

    async def _request_with_retry(
        self, client: httpx.AsyncClient, body: dict, max_retries: int = 3
    ) -> dict:
        """POST with exponential backoff on 429/5xx."""
        import asyncio

        url = self._base_url
        last_error: Exception | None = None
        for attempt in range(max_retries):
            try:
                response = await client.post(url, json=body)
                if response.status_code == 429 or response.status_code >= 500:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                    continue
                if response.status_code >= 400:
                    # Include the server's error message in the exception
                    try:
                        detail = response.json()
                        msg = detail.get("error", {}).get("message", "") or detail.get("detail", "") or response.text[:200]
                    except Exception:
                        msg = response.text[:200]
                    raise RuntimeError(f"{response.status_code}: {msg}")
                return response.json()
            except httpx.HTTPStatusError as e:
                last_error = e
                if e.response.status_code == 429 or e.response.status_code >= 500:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                    continue
                raise
            except httpx.RequestError as e:
                last_error = e
                wait = 2 ** attempt
                await asyncio.sleep(wait)

        raise last_error or RuntimeError("Max retries exceeded")

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
