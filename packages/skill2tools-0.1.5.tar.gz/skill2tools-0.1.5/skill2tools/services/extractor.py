"""ExtractorService — AI-powered tool extraction from skill documents."""

from __future__ import annotations

import json
from typing import Callable

from skill2tools.models.agent import AgentConfig
from skill2tools.models.skill import SkillDocument
from skill2tools.models.tool import Tool, ToolParameter, ToolStatus
from skill2tools.prompts.extraction import build_extraction_messages
from skill2tools.services.llm import LLMClient


class ExtractorService:
    """Extracts tools from a skill document using AI."""

    def __init__(self, client: LLMClient) -> None:
        self.client = client

    async def extract_tools(
        self,
        skill: SkillDocument,
        agent: AgentConfig | None = None,
        on_chunk: Callable[[str], None] | None = None,
    ) -> list[Tool]:
        """Extract tools from the skill document.

        Args:
            skill: The parsed skill document.
            agent: Optional agent config for additional context.
            on_chunk: Optional callback for streaming chunks (for UI).

        Returns:
            List of extracted Tool objects.
        """
        messages = build_extraction_messages(skill, agent)

        if on_chunk:
            # Use streaming for UI feedback
            full_response = ""
            async for chunk in self.client.stream(messages):
                full_response += chunk
                on_chunk(chunk)
        else:
            full_response = await self.client.chat(messages, json_mode=True)

        return self._parse_response(full_response)

    def _parse_response(self, response: str) -> list[Tool]:
        """Parse the AI response into Tool objects."""
        # Try to extract JSON from the response
        response = response.strip()

        # Handle markdown code blocks
        if "```json" in response:
            start = response.index("```json") + 7
            end = response.index("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.index("```") + 3
            end = response.index("```", start)
            response = response[start:end].strip()

        try:
            data = json.loads(response)
        except json.JSONDecodeError:
            # Try to find JSON object in the response
            brace_start = response.find("{")
            brace_end = response.rfind("}") + 1
            if brace_start >= 0 and brace_end > brace_start:
                data = json.loads(response[brace_start:brace_end])
            else:
                raise ValueError(f"Could not parse AI response as JSON: {response[:200]}")

        tools_data = data.get("tools", [])
        if not isinstance(tools_data, list):
            raise ValueError(f"Expected 'tools' array, got: {type(tools_data)}")

        tools = []
        for td in tools_data:
            params = [
                ToolParameter.from_dict(p)
                for p in (td.get("parameters") or [])
            ]
            tool = Tool(
                name=td.get("name", "unknown"),
                description=td.get("description", ""),
                type_hint=td.get("type_hint", ""),
                data_source=td.get("data_source", ""),
                permissions=td.get("permissions") or [],
                parameters=params,
                status=ToolStatus.PENDING,
            )
            tools.append(tool)

        return tools
