"""OpenRouter API client — async HTTP client for AI completions."""

from __future__ import annotations

import json
import os
from typing import AsyncIterator

import httpx


class OpenRouterClient:
    """Client for the OpenRouter chat completions API."""

    BASE_URL = "https://openrouter.ai/api/v1/chat/completions"

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "anthropic/claude-sonnet-4",
        timeout: float = 120.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("OPENROUTER_API_KEY", "")
        self.model = model
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://github.com/skill2tools",
                    "X-Title": "skill2tools",
                },
                timeout=self.timeout,
            )
        return self._client

    async def chat(
        self,
        messages: list[dict],
        json_mode: bool = False,
        model: str | None = None,
    ) -> str:
        """Single-shot completion. Returns the content string."""
        client = await self._get_client()

        body: dict = {
            "model": model or self.model,
            "messages": messages,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        response = await self._request_with_retry(client, body)
        return response["choices"][0]["message"]["content"]

    async def stream(
        self,
        messages: list[dict],
        model: str | None = None,
    ) -> AsyncIterator[str]:
        """Streaming completion. Yields content chunks."""
        client = await self._get_client()

        body = {
            "model": model or self.model,
            "messages": messages,
            "stream": True,
        }

        async with client.stream("POST", self.BASE_URL, json=body) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    delta = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
                    if delta:
                        yield delta
                except (json.JSONDecodeError, IndexError, KeyError):
                    continue

    async def _request_with_retry(
        self, client: httpx.AsyncClient, body: dict, max_retries: int = 3
    ) -> dict:
        """POST with exponential backoff on 429/5xx."""
        import asyncio

        last_error: Exception | None = None
        for attempt in range(max_retries):
            try:
                response = await client.post(self.BASE_URL, json=body)
                if response.status_code == 429 or response.status_code >= 500:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                    continue
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                last_error = e
                if e.response.status_code == 429 or e.response.status_code >= 500:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                    continue
                raise
            except httpx.RequestError as e:
                last_error = e
                wait = 2 ** attempt
                await asyncio.sleep(wait)

        raise last_error or RuntimeError("Max retries exceeded")

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
