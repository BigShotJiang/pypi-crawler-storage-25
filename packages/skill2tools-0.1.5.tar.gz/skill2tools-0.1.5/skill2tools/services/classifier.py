"""ClassifierService — Context7 validation + AI-powered tool classification."""

from __future__ import annotations

import json
from typing import Callable

from skill2tools.models.tool import Tool, ToolClassification, ToolStatus
from skill2tools.prompts.classification import build_classification_messages
from skill2tools.services.context7 import Context7Client
from skill2tools.services.llm import LLMClient


class ClassifierService:
    """Classifies tools using Context7 catalog lookup + AI fallback."""

    def __init__(
        self,
        openrouter: LLMClient,
        context7: Context7Client | None = None,
    ) -> None:
        self.openrouter = openrouter
        self.context7 = context7

    async def classify_tool(
        self,
        tool: Tool,
        on_status: Callable[[str], None] | None = None,
    ) -> Tool:
        """Classify a single tool. Modifies and returns the tool."""
        tool.status = ToolStatus.CLASSIFYING

        if on_status:
            on_status(f"Classifying {tool.name}...")

        # Step 1: Try Context7 lookup
        context7_info = None
        if self.context7:
            if on_status:
                on_status(f"  Checking Context7 catalog for '{tool.name}'...")
            match = await self.context7.resolve_library(
                library_name=tool.name,
                query=tool.description,
            )
            if match and match.score > 50:
                tool.context7_match = match.library_id
                tool.classification = ToolClassification.AVAILABLE
                tool.classification_confidence = min(0.95, match.score / 100)
                tool.classification_reasoning = (
                    f"Found in Context7 catalog: {match.name} "
                    f"(ID: {match.library_id}, score: {match.score})"
                )
                tool.status = ToolStatus.CLASSIFIED
                if on_status:
                    on_status(f"  -> AVAILABLE (Context7 match: {match.library_id})")

                # Optionally fetch docs for later use
                docs = await self.context7.query_docs(
                    match.library_id,
                    f"usage example for {tool.name}",
                )
                if docs:
                    tool.context7_docs = docs[:2000]  # Truncate to save space

                return tool
            elif match:
                context7_info = (
                    f"Partial match found: {match.name} (ID: {match.library_id}, "
                    f"score: {match.score}, reputation: {match.reputation})"
                )

        # Step 2: AI classification via OpenRouter
        if on_status:
            on_status(f"  AI classifying '{tool.name}'...")

        messages = build_classification_messages(tool, context7_info)
        response = await self.openrouter.chat(messages, json_mode=True)

        result = self._parse_classification(response)
        tool.classification = result["classification"]
        tool.classification_confidence = result["confidence"]
        tool.classification_reasoning = result["reasoning"]
        tool.implementation_lang = result.get("implementation_lang", "")
        tool.status = ToolStatus.CLASSIFIED

        if on_status:
            on_status(f"  -> {tool.classification_label} ({tool.classification_confidence:.0%})")

        return tool

    async def classify_all(
        self,
        tools: list[Tool],
        on_status: Callable[[str], None] | None = None,
    ) -> list[Tool]:
        """Classify all tools sequentially."""
        for i, tool in enumerate(tools):
            if on_status:
                on_status(f"\n[{i + 1}/{len(tools)}] Processing: {tool.name}")
            await self.classify_tool(tool, on_status=on_status)
        return tools

    def _parse_classification(self, response: str) -> dict:
        """Parse the AI classification response."""
        response = response.strip()

        # Handle markdown code blocks
        if "```json" in response:
            start = response.index("```json") + 7
            end = response.index("```", start)
            response = response[start:end].strip()
        elif "```" in response:
            start = response.index("```") + 3
            end = response.index("```", start)
            response = response[start:end].strip()

        try:
            data = json.loads(response)
        except json.JSONDecodeError:
            brace_start = response.find("{")
            brace_end = response.rfind("}") + 1
            if brace_start >= 0 and brace_end > brace_start:
                data = json.loads(response[brace_start:brace_end])
            else:
                return {
                    "classification": ToolClassification.BIN,
                    "confidence": 0.5,
                    "reasoning": "Could not parse AI response, defaulting to BIN",
                }

        classification_str = data.get("classification", "bin").lower()
        try:
            classification = ToolClassification(classification_str)
        except ValueError:
            classification = ToolClassification.BIN

        return {
            "classification": classification,
            "confidence": float(data.get("confidence", 0.5)),
            "reasoning": data.get("reasoning", ""),
            "implementation_lang": data.get("implementation_lang", ""),
        }
