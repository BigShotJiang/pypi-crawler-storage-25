"""Context7 MCP client — library validation via JSON-RPC over HTTP."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass

import httpx


@dataclass
class LibraryMatch:
    library_id: str
    name: str
    description: str
    snippets: int = 0
    reputation: str = "Unknown"
    score: float = 0.0


class Context7Client:
    """Client for Context7 MCP server — validates libraries exist in their catalog."""

    MCP_ENDPOINT = "https://mcp.context7.com/mcp"

    def __init__(self, api_key: str | None = None, timeout: float = 30.0) -> None:
        self.api_key = api_key or os.environ.get("CONTEXT7_API_KEY", "")
        self.timeout = timeout
        self._request_id = 0

    async def resolve_library(self, library_name: str, query: str) -> LibraryMatch | None:
        """Search Context7 for a library by name.

        Returns a LibraryMatch if found, None otherwise.
        """
        try:
            result = await self._call_tool(
                "resolve-library-id",
                {"libraryName": library_name, "query": query},
            )
            if result:
                return self._parse_library_result(result)
        except Exception:
            return None
        return None

    async def query_docs(self, library_id: str, query: str) -> str | None:
        """Retrieve documentation for a library from Context7.

        Returns documentation text or None if unavailable.
        """
        try:
            result = await self._call_tool(
                "query-docs",
                {"libraryId": library_id, "query": query},
            )
            return result if result else None
        except Exception:
            return None

    async def _call_tool(self, tool_name: str, arguments: dict) -> str | None:
        """Make a JSON-RPC call to the Context7 MCP server."""
        self._request_id += 1

        payload = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments,
            },
            "id": self._request_id,
        }

        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["CONTEXT7_API_KEY"] = self.api_key

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                self.MCP_ENDPOINT,
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
            data = response.json()

            if "error" in data:
                return None

            result = data.get("result", {})
            # MCP tool results have content array
            content = result.get("content", [])
            if content and isinstance(content, list):
                text_parts = [
                    c.get("text", "") for c in content if c.get("type") == "text"
                ]
                return "\n".join(text_parts) if text_parts else None

            return str(result) if result else None

    def _parse_library_result(self, text: str) -> LibraryMatch | None:
        """Parse the resolve-library-id response text into a LibraryMatch."""
        # The response is typically formatted text with library details
        lines = text.strip().split("\n")

        library_id = ""
        name = ""
        description = ""
        score = 0.0
        reputation = "Unknown"

        for line in lines:
            line = line.strip()
            if not line:
                continue
            # Look for Context7-compatible library ID patterns like /org/project
            if line.startswith("/") or "library ID:" in line.lower():
                parts = line.split(":")
                if len(parts) > 1:
                    library_id = parts[-1].strip()
                elif line.startswith("/"):
                    library_id = line.split()[0] if " " in line else line
            if "Context7-compatible library ID:" in line:
                library_id = line.split(":")[-1].strip()
            if "- Title:" in line:
                name = line.split(":", 1)[-1].strip()
            if "- Description:" in line:
                description = line.split(":", 1)[-1].strip()
            if "Benchmark Score:" in line:
                try:
                    score = float(line.split(":")[-1].strip())
                except ValueError:
                    pass
            if "Source Reputation:" in line:
                reputation = line.split(":")[-1].strip()

        if library_id:
            return LibraryMatch(
                library_id=library_id,
                name=name or library_id,
                description=description,
                score=score,
                reputation=reputation,
            )
        return None
