"""File logger — writes timestamped log entries to <project_dir>/skill2tools.log."""

from __future__ import annotations

import logging
from pathlib import Path


_logger: logging.Logger | None = None


def setup_logger(log_dir: str | Path) -> logging.Logger:
    """Initialize the file logger. Call once at app startup."""
    global _logger

    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "skill2tools.log"

    _logger = logging.getLogger("skill2tools")
    _logger.setLevel(logging.DEBUG)

    # Avoid adding duplicate handlers on re-init
    if not _logger.handlers:
        handler = logging.FileHandler(log_file, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        _logger.addHandler(handler)

    _logger.info("Logger initialized — %s", log_file)
    return _logger


def get_logger() -> logging.Logger:
    """Get the app logger. Falls back to a basic logger if setup_logger was not called."""
    global _logger
    if _logger is None:
        _logger = logging.getLogger("skill2tools")
        _logger.setLevel(logging.DEBUG)
    return _logger


def log(message: str, level: str = "info") -> None:
    """Convenience function to log a message."""
    logger = get_logger()
    getattr(logger, level, logger.info)(message)
