"""TestRunnerService — execute generated tests and collect results."""

from __future__ import annotations

import asyncio
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from skill2tools.models.tool import Tool, ToolStatus
from skill2tools.state.manager import StateManager


@dataclass
class TestResult:
    passed: int = 0
    failed: int = 0
    errors: int = 0
    skipped: int = 0
    total: int = 0
    output: str = ""
    success: bool = False

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "failed": self.failed,
            "errors": self.errors,
            "skipped": self.skipped,
            "total": self.total,
            "success": self.success,
        }


class TestRunnerService:
    """Executes pytest tests for each tool and collects results."""

    def __init__(self, state_manager: StateManager) -> None:
        self.state_manager = state_manager

    async def run_test(
        self,
        tool: Tool,
        on_output: Callable[[str], None] | None = None,
    ) -> TestResult:
        """Run pytest for a single tool's test file."""
        tool.status = ToolStatus.TESTING

        test_dir = self.state_manager.get_tool_dir(tool.name) / "tests"
        test_file = test_dir / "test_tool.py"
        results_file = test_dir / "results.json"

        if not test_file.exists():
            result = TestResult(output="No test file found", success=False)
            tool.status = ToolStatus.ERROR
            return result

        if on_output:
            on_output(f"Running tests for {tool.name}...")

        # Build pytest command
        cmd = [
            sys.executable, "-m", "pytest",
            str(test_file),
            "-v",
            "--tb=short",
            "--no-header",
            f"--rootdir={test_dir}",
        ]

        # Try to use json-report if available
        try:
            import pytest_jsonreport  # noqa: F401
            cmd.extend([
                "--json-report",
                f"--json-report-file={results_file}",
            ])
            use_json_report = True
        except ImportError:
            use_json_report = False

        # Run pytest as subprocess
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(test_dir),
        )

        output_lines = []
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            decoded = line.decode("utf-8", errors="replace").rstrip()
            output_lines.append(decoded)
            if on_output:
                on_output(decoded)

        await process.wait()
        full_output = "\n".join(output_lines)

        # Parse results
        if use_json_report and results_file.exists():
            result = self._parse_json_report(results_file, full_output)
        else:
            result = self._parse_text_output(full_output, process.returncode)

        # Update tool status
        if result.success:
            tool.status = ToolStatus.PASSED
        elif result.failed > 0 or result.errors > 0:
            tool.status = ToolStatus.FAILED
        else:
            tool.status = ToolStatus.ERROR

        tool.test_result = result.to_dict()

        # Save results
        self.state_manager.save_test_result(tool.name, result.to_dict())
        self.state_manager.save_tool(tool)

        return result

    async def run_all_tests(
        self,
        tools: list[Tool],
        on_output: Callable[[str], None] | None = None,
    ) -> dict[str, TestResult]:
        """Run tests for all tools."""
        results = {}
        for i, tool in enumerate(tools):
            if on_output:
                on_output(f"\n{'='*60}")
                on_output(f"[{i + 1}/{len(tools)}] Testing: {tool.name}")
                on_output(f"{'='*60}")

            result = await self.run_test(tool, on_output)
            results[tool.name] = result

            if on_output:
                status = "PASSED" if result.success else "FAILED"
                on_output(f"Result: {status} (passed={result.passed}, failed={result.failed}, errors={result.errors})")

        return results

    def _parse_json_report(self, report_file: Path, output: str) -> TestResult:
        """Parse pytest-json-report output."""
        try:
            data = json.loads(report_file.read_text(encoding="utf-8"))
            summary = data.get("summary", {})
            return TestResult(
                passed=summary.get("passed", 0),
                failed=summary.get("failed", 0),
                errors=summary.get("error", 0),
                skipped=summary.get("skipped", 0),
                total=summary.get("total", 0),
                output=output,
                success=summary.get("failed", 0) == 0 and summary.get("error", 0) == 0,
            )
        except (json.JSONDecodeError, KeyError):
            return self._parse_text_output(output, 1)

    def _parse_text_output(self, output: str, returncode: int) -> TestResult:
        """Parse pytest text output for pass/fail counts."""
        passed = failed = errors = skipped = 0

        for line in output.split("\n"):
            line = line.strip()
            # Look for the summary line like "3 passed, 1 failed"
            if "passed" in line or "failed" in line or "error" in line:
                parts = line.split(",")
                for part in parts:
                    part = part.strip()
                    if "passed" in part:
                        try:
                            passed = int(part.split()[0])
                        except (ValueError, IndexError):
                            pass
                    elif "failed" in part:
                        try:
                            failed = int(part.split()[0])
                        except (ValueError, IndexError):
                            pass
                    elif "error" in part:
                        try:
                            errors = int(part.split()[0])
                        except (ValueError, IndexError):
                            pass
                    elif "skipped" in part:
                        try:
                            skipped = int(part.split()[0])
                        except (ValueError, IndexError):
                            pass

        total = passed + failed + errors + skipped
        return TestResult(
            passed=passed,
            failed=failed,
            errors=errors,
            skipped=skipped,
            total=total,
            output=output,
            success=returncode == 0 and failed == 0 and errors == 0,
        )
