"""AssemblerService — builds/integrates tools based on their classification."""

from __future__ import annotations

import importlib
import py_compile
import subprocess
import tempfile
from typing import Callable

from skill2tools.models.tool import Tool, ToolClassification, ToolStatus
from skill2tools.prompts.scaffolding import (
    build_api_config_messages,
    build_mcp_config_messages,
    build_scaffolding_messages,
)
from skill2tools.services.llm import LLMClient
from skill2tools.state.manager import StateManager


class AssemblerService:
    """Assembles tools: validates AVAILABLE, generates configs for MCP/API, builds BIN."""

    def __init__(
        self,
        openrouter: LLMClient,
        state_manager: StateManager,
    ) -> None:
        self.openrouter = openrouter
        self.state_manager = state_manager

    async def assemble_tool(
        self,
        tool: Tool,
        on_status: Callable[[str], None] | None = None,
    ) -> Tool:
        """Assemble a single tool based on its classification."""
        tool.status = ToolStatus.ASSEMBLING

        if on_status:
            on_status(f"Assembling {tool.name} ({tool.classification_label})...")

        try:
            if tool.classification == ToolClassification.AVAILABLE:
                await self._assemble_available(tool, on_status)
            elif tool.classification == ToolClassification.MCP:
                await self._assemble_mcp(tool, on_status)
            elif tool.classification == ToolClassification.API:
                await self._assemble_api(tool, on_status)
            elif tool.classification == ToolClassification.BIN:
                await self._assemble_bin(tool, on_status)
            else:
                tool.status = ToolStatus.ERROR
                if on_status:
                    on_status(f"  [red]No classification for {tool.name}[/red]")
                return tool

            tool.status = ToolStatus.ASSEMBLED
            if on_status:
                on_status(f"  -> Assembled successfully")
        except Exception as e:
            tool.status = ToolStatus.ERROR
            if on_status:
                on_status(f"  [red]Error: {e}[/red]")

        self.state_manager.save_tool(tool)
        return tool

    async def assemble_all(
        self,
        tools: list[Tool],
        on_status: Callable[[str], None] | None = None,
    ) -> list[Tool]:
        """Assemble all tools sequentially."""
        for i, tool in enumerate(tools):
            if tool.status in (ToolStatus.ASSEMBLED, ToolStatus.PASSED):
                if on_status:
                    on_status(f"\n[{i + 1}/{len(tools)}] {tool.name} — already assembled, skipping")
                continue
            if on_status:
                on_status(f"\n[{i + 1}/{len(tools)}] Assembling: {tool.name}")
            await self.assemble_tool(tool, on_status)
        return tools

    async def _assemble_available(self, tool: Tool, on_status: Callable | None) -> None:
        """Validate an AVAILABLE tool by checking if the package is importable."""
        package_name = tool.name.replace("-", "_").replace(" ", "_").lower()

        if on_status:
            on_status(f"  Checking if '{package_name}' is importable...")

        try:
            importlib.import_module(package_name)
            install_status = "installed"
            if on_status:
                on_status(f"  Package '{package_name}' is already installed")
        except ImportError:
            install_status = "not_installed"
            if on_status:
                on_status(f"  Package '{package_name}' is NOT installed — pip install {package_name}")

        # Write requirements.txt
        self.state_manager.save_implementation(
            tool.name, "requirements.txt", f"{package_name}\n"
        )

        # Write tool.yaml metadata
        import yaml
        config = {
            "package_name": package_name,
            "install_command": f"pip install {package_name}",
            "install_status": install_status,
            "context7_id": tool.context7_match or "",
        }
        self.state_manager.save_integration(
            tool.name, "package_config.yaml", yaml.dump(config, default_flow_style=False)
        )

    async def _assemble_mcp(self, tool: Tool, on_status: Callable | None) -> None:
        """Generate MCP integration config."""
        if on_status:
            on_status(f"  Generating MCP integration config...")

        messages = build_mcp_config_messages(tool)
        response = await self.openrouter.chat(messages)

        # Clean response
        config_text = self._clean_yaml_response(response)
        self.state_manager.save_integration(tool.name, "mcp_config.yaml", config_text)

        if on_status:
            on_status(f"  MCP config written to integration/mcp_config.yaml")

    async def _assemble_api(self, tool: Tool, on_status: Callable | None) -> None:
        """Generate API integration config."""
        if on_status:
            on_status(f"  Generating API integration config...")

        messages = build_api_config_messages(tool)
        response = await self.openrouter.chat(messages)

        config_text = self._clean_yaml_response(response)
        self.state_manager.save_integration(tool.name, "api_config.yaml", config_text)

        if on_status:
            on_status(f"  API config written to integration/api_config.yaml")

    async def _assemble_bin(self, tool: Tool, on_status: Callable | None) -> None:
        """Generate BIN tool implementation."""
        lang = tool.implementation_lang or "python"
        if on_status:
            on_status(f"  Generating {lang} implementation...")

        messages = build_scaffolding_messages(tool)
        response = await self.openrouter.chat(messages)

        code = self._clean_code_response(response)

        if lang == "python":
            filename = f"{tool.name}.py"
            self.state_manager.save_implementation(tool.name, filename, code)
            # Syntax check
            impl_path = self.state_manager.get_tool_dir(tool.name) / "implementation" / filename
            try:
                py_compile.compile(str(impl_path), doraise=True)
                if on_status:
                    on_status(f"  Syntax check passed")
            except py_compile.PyCompileError as e:
                if on_status:
                    on_status(f"  [yellow]Syntax warning: {e}[/yellow]")
        else:
            filename = f"{tool.name}.sh"
            self.state_manager.save_implementation(tool.name, filename, code)
            # Shell syntax check
            impl_path = self.state_manager.get_tool_dir(tool.name) / "implementation" / filename
            result = subprocess.run(
                ["bash", "-n", str(impl_path)],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                if on_status:
                    on_status(f"  Shell syntax check passed")
            else:
                if on_status:
                    on_status(f"  [yellow]Shell syntax warning: {result.stderr}[/yellow]")

        if on_status:
            on_status(f"  Implementation written to implementation/{filename}")

    def _clean_yaml_response(self, response: str) -> str:
        """Strip markdown fencing from YAML responses."""
        response = response.strip()
        if response.startswith("```yaml"):
            response = response[7:]
        elif response.startswith("```yml"):
            response = response[6:]
        elif response.startswith("```"):
            response = response[3:]
        if response.endswith("```"):
            response = response[:-3]
        return response.strip()

    def _clean_code_response(self, response: str) -> str:
        """Strip markdown fencing from code responses."""
        response = response.strip()
        for prefix in ("```python", "```bash", "```sh", "```"):
            if response.startswith(prefix):
                response = response[len(prefix):]
                break
        if response.endswith("```"):
            response = response[:-3]
        return response.strip()
