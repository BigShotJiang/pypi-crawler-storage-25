"""skill2tools — Extract, classify, assemble, and test tools from Agent Skill definitions."""

__version__ = "0.1.5"
__build_timestamp__ = "2026-04-13T20:58:58Z"
