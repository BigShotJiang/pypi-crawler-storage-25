"""File picker widget — input with path validation and file browser."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Input, Label, Button


class FilePicker(Widget):
    """A file path input with real-time validation and browse button."""

    DEFAULT_CSS = """
    FilePicker { height: auto; }
    FilePicker .fp-label { margin: 0 0 0 1; color: $text; }
    FilePicker .fp-row { height: auto; layout: horizontal; }
    FilePicker .fp-row Input { width: 1fr; }
    FilePicker .fp-row Button { min-width: 10; margin: 0 0 0 1; }
    FilePicker .fp-status { margin: 0 0 0 1; height: 1; }
    FilePicker .fp-error { color: $error; }
    FilePicker .fp-ok { color: $success; }
    """

    value: reactive[str] = reactive("")
    is_valid: reactive[bool] = reactive(False)

    class FileSelected(Message):
        """Posted when a file is selected via the browser."""
        def __init__(self, path: str, picker_id: str) -> None:
            super().__init__()
            self.path = path
            self.picker_id = picker_id

    def __init__(
        self,
        label: str = "",
        placeholder: str = "",
        required: bool = True,
        extensions: list[str] | None = None,
        show_label: bool = True,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.label_text = label
        self.placeholder = placeholder
        self.required = required
        self.extensions = extensions or []
        self.show_label = show_label

    def compose(self) -> ComposeResult:
        if self.show_label and self.label_text:
            yield Label(self.label_text, classes="fp-label")
        with Horizontal(classes="fp-row"):
            yield Input(placeholder=self.placeholder, id="fp-input")
            yield Button("Browse", id="fp-browse-btn")
        yield Label("", id="fp-status", classes="fp-status")

    def on_input_changed(self, event: Input.Changed) -> None:
        self.value = event.value.strip()
        self._validate()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "fp-browse-btn":
            self._open_browser()

    def _open_browser(self) -> None:
        from skill2tools.screens.file_browser import FileBrowserScreen

        start = "."
        if self.value:
            p = Path(self.value).expanduser()
            if p.exists() and p.is_dir():
                start = str(p)
            elif p.parent.exists():
                start = str(p.parent)

        def on_result(result: str | None) -> None:
            if result:
                fp_input = self.query_one("#fp-input", Input)
                fp_input.value = result

        self.app.push_screen(
            FileBrowserScreen(
                start_path=start,
                extensions=self.extensions if self.extensions else None,
                title=f"Select: {self.label_text or 'file'}",
            ),
            callback=on_result,
        )

    def _validate(self) -> None:
        status = self.query_one("#fp-status", Label)

        if not self.value:
            if self.required:
                status.update("Required")
                status.set_classes("fp-status fp-error")
                self.is_valid = False
            else:
                status.update("")
                status.set_classes("fp-status fp-ok")
                self.is_valid = True
            return

        path = Path(self.value).expanduser()
        if not path.exists():
            status.update(f"Not found: {self.value}")
            status.set_classes("fp-status fp-error")
            self.is_valid = False
            return

        if not path.is_file():
            status.update("Not a file")
            status.set_classes("fp-status fp-error")
            self.is_valid = False
            return

        if self.extensions and path.suffix not in self.extensions:
            status.update(f"Expected: {', '.join(self.extensions)}")
            status.set_classes("fp-status fp-error")
            self.is_valid = False
            return

        status.update(f"OK: {path.name}")
        status.set_classes("fp-status fp-ok")
        self.is_valid = True

    @property
    def resolved_path(self) -> str | None:
        if self.is_valid and self.value:
            return str(Path(self.value).expanduser().resolve())
        return None
