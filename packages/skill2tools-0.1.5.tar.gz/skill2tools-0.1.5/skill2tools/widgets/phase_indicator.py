"""Phase indicator widget — shows pipeline progress."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widget import Widget
from textual.widgets import Static

from skill2tools.models.project import Phase

PHASE_LABELS = [
    (Phase.INIT, "1. Setup"),
    (Phase.ANALYSIS, "2. Analysis"),
    (Phase.CLASSIFICATION, "3. Classify"),
    (Phase.ASSEMBLY, "4. Assemble"),
    (Phase.TESTING, "5. Testing"),
    (Phase.COMPLETE, "6. Summary"),
]

PHASE_ORDER = [p for p, _ in PHASE_LABELS]


class PhaseIndicator(Widget):
    """Horizontal bar showing which pipeline phase is active."""

    DEFAULT_CSS = """
    PhaseIndicator {
        height: 3;
        background: $surface-darken-1;
        layout: horizontal;
        padding: 0 1;
    }
    PhaseIndicator .phase-step {
        width: 1fr;
        content-align: center middle;
        color: $text-muted;
    }
    PhaseIndicator .phase-step.active {
        color: $success;
        text-style: bold;
    }
    PhaseIndicator .phase-step.completed {
        color: $primary;
    }
    """

    def __init__(self, current_phase: Phase = Phase.INIT, **kwargs) -> None:
        super().__init__(**kwargs)
        self.current_phase = current_phase

    def compose(self) -> ComposeResult:
        with Horizontal():
            current_idx = PHASE_ORDER.index(self.current_phase)
            for i, (phase, label) in enumerate(PHASE_LABELS):
                css_class = "phase-step"
                if i < current_idx:
                    css_class += " completed"
                    marker = "[*]"
                elif i == current_idx:
                    css_class += " active"
                    marker = "[>]"
                else:
                    marker = "[ ]"
                yield Static(f"{marker} {label}", classes=css_class)

    def update_phase(self, phase: Phase) -> None:
        self.current_phase = phase
        self.refresh(recompose=True)
