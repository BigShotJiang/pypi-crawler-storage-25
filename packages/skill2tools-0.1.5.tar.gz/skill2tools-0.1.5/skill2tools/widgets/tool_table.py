"""Tool table widget — DataTable wrapper for tool listings."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import DataTable

from skill2tools.models.tool import Tool


class ToolTable(Widget):
    """DataTable displaying tools with their status and classification."""

    DEFAULT_CSS = """
    ToolTable {
        height: 1fr;
        margin: 1 0;
    }
    """

    def __init__(self, tools: list[Tool] | None = None, show_classification: bool = True, show_status: bool = True, **kwargs) -> None:
        super().__init__(**kwargs)
        self._tools = tools or []
        self._show_classification = show_classification
        self._show_status = show_status

    def compose(self) -> ComposeResult:
        table = DataTable(id="tool-data-table")
        table.cursor_type = "row"
        yield table

    def on_mount(self) -> None:
        self._build_table()

    def _build_table(self) -> None:
        table = self.query_one("#tool-data-table", DataTable)
        table.clear(columns=True)

        columns = ["#", "Name", "Description"]
        if self._show_classification:
            columns.append("Classification")
            columns.append("Confidence")
        if self._show_status:
            columns.append("Status")

        table.add_columns(*columns)

        for i, tool in enumerate(self._tools, 1):
            row = [str(i), tool.name, tool.description[:60]]
            if self._show_classification:
                row.append(tool.classification_label)
                row.append(f"{tool.classification_confidence:.0%}" if tool.classification_confidence else "-")
            if self._show_status:
                row.append(tool.status_label)
            table.add_row(*row, key=tool.name)

    def update_tools(self, tools: list[Tool]) -> None:
        self._tools = tools
        self._build_table()

    def update_tool_row(self, tool: Tool) -> None:
        """Update a single tool's row in the table."""
        table = self.query_one("#tool-data-table", DataTable)
        try:
            idx = next(i for i, t in enumerate(self._tools) if t.name == tool.name)
            self._tools[idx] = tool
        except StopIteration:
            self._tools.append(tool)
        self._build_table()
