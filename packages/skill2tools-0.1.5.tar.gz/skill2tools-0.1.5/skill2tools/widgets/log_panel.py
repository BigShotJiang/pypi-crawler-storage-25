"""Log panel widget — RichLog wrapper for streaming output."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import RichLog


class LogPanel(Widget):
    """A bordered RichLog for displaying streaming AI/test output."""

    DEFAULT_CSS = """
    LogPanel {
        height: 1fr;
        border: solid $primary;
        margin: 1 0;
    }
    """

    def __init__(self, title: str = "Output", **kwargs) -> None:
        super().__init__(**kwargs)
        self.title_text = title

    def compose(self) -> ComposeResult:
        yield RichLog(id="log-output", highlight=True, markup=True)

    @property
    def log(self) -> RichLog:
        return self.query_one("#log-output", RichLog)

    def write(self, text: str) -> None:
        self.log.write(text)

    def write_line(self, text: str) -> None:
        self.log.write(text)

    def clear(self) -> None:
        self.log.clear()
