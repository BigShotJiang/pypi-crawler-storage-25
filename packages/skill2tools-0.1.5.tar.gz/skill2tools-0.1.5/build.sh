#!/usr/bin/env bash
# build.sh — Build skill2tools distributions for Linux, macOS, and Windows
# Uses PyInstaller to create standalone executables.
#
# Usage:
#   ./build.sh              # Build for current platform
#   ./build.sh --all        # Build for all platforms (requires cross-compilation or CI)
#   ./build.sh --platform linux|macos|windows
#
# Output: dist/<platform>/skill2tools[.exe]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="skill2tools"
ENTRY_POINT="skill2tools/__main__.py"
DIST_DIR="$SCRIPT_DIR/dist"
BUILD_DIR="$SCRIPT_DIR/build"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

# Detect current platform
detect_platform() {
    case "$(uname -s)" in
        Linux*)  echo "linux" ;;
        Darwin*) echo "macos" ;;
        MINGW*|MSYS*|CYGWIN*) echo "windows" ;;
        *)       echo "unknown" ;;
    esac
}

CURRENT_PLATFORM=$(detect_platform)

# Ensure pyinstaller is installed
ensure_pyinstaller() {
    if ! python3 -c "import PyInstaller" &>/dev/null 2>&1; then
        info "Installing PyInstaller..."
        python3 -m pip install pyinstaller --quiet
    fi
}

# Ensure project dependencies are installed
ensure_deps() {
    if ! python3 -c "import skill2tools" &>/dev/null 2>&1; then
        info "Installing skill2tools dependencies..."
        python3 -m pip install -e "." --quiet
    fi
}

# Collect textual CSS and data files
collect_data_files() {
    local data_args=""

    # Include the styles.tcss file (use absolute path)
    local styles_path="${SCRIPT_DIR}/skill2tools/styles.tcss"
    if [[ -f "$styles_path" ]]; then
        data_args="--add-data ${styles_path}:skill2tools"
    fi

    # Include textual's CSS (required for widget rendering)
    local textual_path
    textual_path=$(python3 -c "import textual; import os; print(os.path.dirname(textual.__file__))" 2>/dev/null || true)
    if [[ -n "$textual_path" && -d "$textual_path/css" ]]; then
        data_args="$data_args --add-data ${textual_path}/css:textual/css"
    fi

    echo "$data_args"
}

# Build for a specific platform
build_platform() {
    local platform="$1"
    local output_dir="$DIST_DIR/${platform}"
    local exe_name="$APP_NAME"

    if [[ "$platform" == "windows" ]]; then
        exe_name="${APP_NAME}.exe"
    fi

    info "Building ${APP_NAME} v${VERSION} for ${platform}..."

    mkdir -p "$output_dir"

    local data_files
    data_files=$(collect_data_files)

    local hidden_imports=(
        --hidden-import=skill2tools
        --hidden-import=skill2tools.app
        --hidden-import=skill2tools.screens.welcome
        --hidden-import=skill2tools.screens.analysis
        --hidden-import=skill2tools.screens.classification
        --hidden-import=skill2tools.screens.assembly
        --hidden-import=skill2tools.screens.testing
        --hidden-import=skill2tools.screens.summary
        --hidden-import=skill2tools.screens.setup
        --hidden-import=skill2tools.screens.config
        --hidden-import=skill2tools.screens.folder_preview
        --hidden-import=skill2tools.screens.file_browser
        --hidden-import=skill2tools.models.skill
        --hidden-import=skill2tools.models.agent
        --hidden-import=skill2tools.models.tool
        --hidden-import=skill2tools.models.project
        --hidden-import=skill2tools.models.config
        --hidden-import=skill2tools.services.openrouter
        --hidden-import=skill2tools.services.llm
        --hidden-import=skill2tools.services.context7
        --hidden-import=skill2tools.services.extractor
        --hidden-import=skill2tools.services.classifier
        --hidden-import=skill2tools.services.assembler
        --hidden-import=skill2tools.services.test_generator
        --hidden-import=skill2tools.services.test_runner
        --hidden-import=skill2tools.widgets.file_picker
        --hidden-import=skill2tools.widgets.tool_table
        --hidden-import=skill2tools.widgets.log_panel
        --hidden-import=skill2tools.widgets.phase_indicator
        --hidden-import=skill2tools.prompts.extraction
        --hidden-import=skill2tools.prompts.classification
        --hidden-import=skill2tools.prompts.scaffolding
        --hidden-import=skill2tools.prompts.test_generation
        --hidden-import=textual
        --hidden-import=textual.app
        --hidden-import=textual.screen
        --hidden-import=textual.widgets
        --hidden-import=httpx
        --hidden-import=yaml
        --hidden-import=rich
    )

    # shellcheck disable=SC2086
    python3 -m PyInstaller \
        --name "$APP_NAME" \
        --onefile \
        --console \
        --clean \
        --distpath "$output_dir" \
        --workpath "$BUILD_DIR/${platform}" \
        --specpath "$BUILD_DIR" \
        --paths . \
        ${data_files} \
        "${hidden_imports[@]}" \
        --noconfirm \
        "$ENTRY_POINT"

    if [[ -f "$output_dir/$exe_name" ]]; then
        local size
        size=$(du -h "$output_dir/$exe_name" | cut -f1)
        info "Built: $output_dir/$exe_name ($size)"
    else
        error "Build failed for ${platform}"
        return 1
    fi
}

# Create archive for distribution
create_archive() {
    local platform="$1"
    local output_dir="$DIST_DIR/${platform}"
    local archive_name="${APP_NAME}-${VERSION}-${platform}"

    info "Creating archive: ${archive_name}..."

    cd "$DIST_DIR"
    if [[ "$platform" == "windows" ]]; then
        if command -v zip &>/dev/null; then
            zip -j "${archive_name}.zip" "${platform}/${APP_NAME}.exe"
            info "Archive: $DIST_DIR/${archive_name}.zip"
        fi
    else
        tar -czf "${archive_name}.tar.gz" -C "${platform}" "${APP_NAME}"
        info "Archive: $DIST_DIR/${archive_name}.tar.gz"
    fi
    cd "$SCRIPT_DIR"
}

# Main
main() {
    local target_platform="${1:-current}"

    ensure_deps
    ensure_pyinstaller

    # Auto-increment build number
    info "Bumping build number..."
    VERSION=$(python3 "$SCRIPT_DIR/bump_version.py")
    info "Version: ${VERSION}"

    case "$target_platform" in
        --all)
            if [[ "$CURRENT_PLATFORM" != "linux" && "$CURRENT_PLATFORM" != "macos" ]]; then
                warn "Cross-compilation is not directly supported by PyInstaller."
                warn "Build on each target OS, or use CI (GitHub Actions) for multi-platform builds."
                warn "Building for current platform only: ${CURRENT_PLATFORM}"
            fi
            build_platform "$CURRENT_PLATFORM"
            create_archive "$CURRENT_PLATFORM"
            info ""
            info "For cross-platform builds, use the GitHub Actions workflow:"
            info "  .github/workflows/build.yml"
            ;;
        --platform)
            local plat="${2:-$CURRENT_PLATFORM}"
            if [[ "$plat" != "$CURRENT_PLATFORM" ]]; then
                warn "PyInstaller cannot cross-compile. Building for current: ${CURRENT_PLATFORM}"
                plat="$CURRENT_PLATFORM"
            fi
            build_platform "$plat"
            create_archive "$plat"
            ;;
        current|"")
            build_platform "$CURRENT_PLATFORM"
            create_archive "$CURRENT_PLATFORM"
            ;;
        *)
            error "Unknown option: $target_platform"
            echo "Usage: $0 [--all | --platform linux|macos|windows]"
            exit 1
            ;;
    esac

    info ""
    info "Build complete! Artifacts in: $DIST_DIR/"
    ls -lah "$DIST_DIR/" 2>/dev/null || true
}

main "$@"
