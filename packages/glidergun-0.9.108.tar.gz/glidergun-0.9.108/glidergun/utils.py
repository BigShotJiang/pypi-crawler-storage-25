import logging
from functools import wraps

import numpy as np
from numpy import ndarray
from rasterio.crs import CRS
from rasterio.drivers import driver_from_extension
from rasterio.io import MemoryFile
from rasterio.warp import transform

logger = logging.getLogger(__name__)


def get_crs(crs: int | str | CRS):
    if isinstance(crs, str):
        try:
            return CRS.from_string(crs)
        except Exception:
            return CRS.from_wkt(crs)
    return CRS.from_epsg(crs) if isinstance(crs, int) else crs


def project(x: float, y: float, from_crs: int | str | CRS, to_crs: int | str | CRS):
    [x], [y], *_ = transform(get_crs(from_crs), get_crs(to_crs), [x], [y])
    return x, y


def get_driver(file: str | MemoryFile):
    if not isinstance(file, str) or file.lower().endswith(".tif"):
        return "COG"
    return driver_from_extension(file)


def format_type(data: ndarray):
    if data.dtype == "float64":
        return np.asanyarray(data, dtype="float32")
    if data.dtype == "int64":
        return np.asanyarray(data, dtype="int32")
    if data.dtype == "uint64":
        return np.asanyarray(data, dtype="uint32")
    return data


def get_nodata_value(dtype: str) -> float | int | None:
    if dtype == "bool" or dtype == "uint8":
        return None
    if dtype.startswith("float"):
        return float(np.finfo(dtype).min)
    if dtype.startswith("uint"):
        return np.iinfo(dtype).max
    return np.iinfo(dtype).min


def is_image_format(file: str | MemoryFile) -> bool:
    return isinstance(file, str) and file.lower().endswith((".jpg", ".kml", ".kmz", ".png"))


def is_tile_url(url: str) -> bool:
    return url.startswith(("http://", "https://")) and "{" in url and "}" in url


def with_agg_backend(func):
    import matplotlib.pyplot as plt

    @wraps(func)
    def wrapped(*args, **kwargs):
        old_backend = plt.get_backend()

        # Normalize for comparison
        is_agg = "agg" in old_backend.lower()

        if not is_agg:
            plt.switch_backend("Agg")
            logger.info(f"Switched matplotlib backend from {old_backend} to Agg.")
        try:
            return func(*args, **kwargs)
        finally:
            if not is_agg:
                plt.switch_backend(old_backend)
                logger.info(f"Restored matplotlib backend to {old_backend}.")

    return wrapped
