"""Preflight checks for services targeted by csrd-utils feature augmentation."""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DoctorReport:
    """Structured doctor output."""

    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def run_doctor(service_root: Path) -> DoctorReport:
    """Validate that a service is compatible with feature augmentation."""
    root = service_root.resolve()
    errors: list[str] = []
    warnings: list[str] = []

    required_dirs: list[str] = []
    required_files = ["requirements.txt", "pyproject.toml"]

    compose_candidates = [root / "docker-compose.yml"]
    if root.parent.name == "src" and (root.parent.parent / ".csrd-workspace").is_file():
        compose_candidates.append(root.parent.parent / "docker-compose.yml")

    for rel in required_dirs:
        if not (root / rel).is_dir():
            errors.append(f"Missing required directory: {rel}")

    for rel in required_files:
        if not (root / rel).is_file():
            errors.append(f"Missing required file: {rel}")

    if not any(path.is_file() for path in compose_candidates):
        errors.append("Missing required file: docker-compose.yml")

    # Find the service package dir — check src/ layout first, then flat layout
    src_dir = root / "src"
    pkg_dir = None
    if src_dir.is_dir():
        pkg_dir = next(
            (
                p
                for p in src_dir.iterdir()
                if p.is_dir() and not p.name.startswith(".") and (p / "__init__.py").is_file()
            ),
            None,
        )
    if pkg_dir is None:
        pkg_dir = next(
            (
                p
                for p in root.iterdir()
                if p.is_dir()
                and not p.name.startswith(".")
                and p.name not in {"tests", "src"}
                and (p / "__init__.py").is_file()
            ),
            None,
        )

    marker_files: dict[str, str] = {}
    if pkg_dir is not None:
        marker_files[f"{pkg_dir.name}/settings.py"] = "# [INSERT: fields]"
    workspace_root = None
    if root.parent.name == "src" and (root.parent.parent / ".csrd-workspace").is_file():
        workspace_root = root.parent.parent

    if workspace_root is not None and pkg_dir is not None:
        marker_files[f"tests/acceptance/{pkg_dir.name}/conftest.py"] = "# [INSERT: fixtures]"
    else:
        marker_files["tests/conftest.py"] = "# [INSERT: fixtures]"

    for rel, marker in marker_files.items():
        path = (
            (workspace_root / rel)
            if workspace_root is not None and rel.startswith("tests/")
            else (root / rel)
        )
        if path.exists():
            text = path.read_text(encoding="utf-8")
            if marker not in text:
                warnings.append(f"Optional insertion marker missing in {rel}: {marker}")

    return DoctorReport(ok=not errors, errors=errors, warnings=warnings)
