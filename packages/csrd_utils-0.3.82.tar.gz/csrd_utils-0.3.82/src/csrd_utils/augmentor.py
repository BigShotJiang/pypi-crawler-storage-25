"""Core augmentor logic for adding features to existing services."""

import shutil
import tempfile
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from .fragments import (
    ConfTestMerger,
    DockerComposeMerger,
    FragmentMergeError,
    ManifestLoader,
    RequirementsMerger,
    SettingsMerger,
)


class ServiceAugmentor:
    """Add features to an existing service."""

    def __init__(self, service_root: Path, feature_lib: Path):
        """
        Initialize augmentor.

        Parameters
        ----------
        service_root : Path
            Root directory of the service to augment
        feature_lib : Path
            Root directory containing feature manifests
        """
        self.service_root = service_root.resolve()
        self.feature_lib = feature_lib.resolve()
        self.manifest: dict[str, Any] = {}
        self.applied_changes: list[str] = []
        self.backups: dict[str, str] = {}

    @property
    def _pkg_dir(self) -> Path:
        """Return the service package directory — src/ layout first, then flat."""
        src_dir = self.service_root / "src"
        if src_dir.is_dir():
            candidate = next(
                (
                    p
                    for p in src_dir.iterdir()
                    if p.is_dir() and not p.name.startswith(".") and (p / "__init__.py").is_file()
                ),
                None,
            )
            if candidate is not None:
                return candidate
        # Flat layout fallback
        candidate = next(
            (
                p
                for p in self.service_root.iterdir()
                if p.is_dir()
                and not p.name.startswith(".")
                and p.name not in {"tests", "src"}
                and (p / "__init__.py").is_file()
            ),
            None,
        )
        return candidate if candidate is not None else self.service_root / "src" / "app"

    @property
    def _workspace_root(self) -> Path | None:
        parent = self.service_root.parent
        if parent.name == "src" and (parent.parent / ".csrd-workspace").is_file():
            return parent.parent
        return None

    @property
    def _tests_dir(self) -> Path:
        workspace_root = self._workspace_root
        if workspace_root is not None:
            return workspace_root / "tests"
        return self.service_root / "tests"

    @property
    def _pkg_import_name(self) -> str:
        return self._pkg_dir.name

    def _rewrite_src_app_refs(self, content: str) -> str:
        """Map legacy feature fragment imports to the concrete service package name."""
        pkg = self._pkg_import_name
        return content.replace("src.app.", f"{pkg}.").replace("src.app", pkg)

    def load_feature(self, feature_name: str) -> bool:
        """
        Load and validate feature manifest.

        Parameters
        ----------
        feature_name : str
            Feature name (e.g., "workers")

        Returns
        -------
        bool
            True if valid, False otherwise
        """
        manifest_path = self.feature_lib / feature_name / "manifest.yaml"

        try:
            self.manifest = ManifestLoader.load(manifest_path)
        except FileNotFoundError as e:
            print(f"❌ {e}")
            return False

        errors = ManifestLoader.validate(self.manifest)
        if errors:
            print("❌ Manifest validation failed:")
            for err in errors:
                print(f"   - {err}")
            return False

        return True

    def validate_service(self) -> bool:
        """
        Validate that service has required structure.

        Checks for <pkg>/, docker-compose.yml, etc.

        Returns
        -------
        bool
            True if valid
        """
        required_dirs = [str(self._pkg_dir.relative_to(self.service_root))]
        required_files = ["requirements.txt"]

        for d in required_dirs:
            if not (self.service_root / d).is_dir():
                print(f"❌ Missing required directory: {d}")
                return False

        for f in required_files:
            if not (self.service_root / f).is_file():
                print(f"❌ Missing required file: {f}")
                return False

        if not self._docker_compose_path().is_file():
            print("❌ Missing required file: docker-compose.yml")
            return False

        return True

    def _docker_compose_path(self) -> Path:
        local = self.service_root / "docker-compose.yml"
        if local.is_file():
            return local

        parent = self.service_root.parent
        if parent.name == "src" and (parent.parent / ".csrd-workspace").is_file():
            workspace_compose = parent.parent / "docker-compose.yml"
            if workspace_compose.is_file():
                return workspace_compose
        return local

    def validate_requirements(self) -> list[str]:
        """
        Validate that feature requirements are met.

        Returns
        -------
        list[str]
            List of validation errors (empty if all met)
        """
        errors: list[str] = []
        requires = self.manifest.get("requires", {})

        # Check dependencies
        for dep_type, _deps in requires.items():
            if dep_type == "dependencies":
                # Would check if packages are installed
                pass
            elif dep_type == "external_services":
                # Could check if services are available in docker-compose
                pass
            elif dep_type == "settings":
                # Would check if settings exist
                pass

        return errors

    def backup_file(self, file_path: Path) -> None:
        """
        Create backup of file before modification.

        Parameters
        ----------
        file_path : Path
            File to backup
        """
        if file_path.exists():
            with tempfile.NamedTemporaryFile(mode="w", suffix=".backup", delete=False) as backup:
                backup.write(file_path.read_text())
                self.backups[str(file_path)] = backup.name

    def merge_requirements(self, feature_name: str) -> bool:
        """
        Merge requirements.txt fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "requirements.fragment"

        if not fragment_path.exists():
            return True  # Not required

        try:
            req_path = self.service_root / "requirements.txt"
            self.backup_file(req_path)

            base = req_path.read_text()
            fragment = fragment_path.read_text()
            merged = RequirementsMerger.merge(base, fragment)

            req_path.write_text(merged)
            self.applied_changes.append(f"Merged {feature_name} requirements")
            print("✓ Merged requirements.txt")
            return True
        except Exception as e:
            print(f"❌ Failed to merge requirements: {e}")
            return False

    def merge_docker_compose(self, feature_name: str) -> bool:
        """
        Merge docker-compose.yml fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "docker-compose.fragment.yaml"

        if not fragment_path.exists():
            return True  # Not required

        if self._workspace_root is not None:
            # Workspace compose is generated from cluster spec, not merged via legacy fragments.
            print("✓ Skipped docker-compose.yml fragment merge (workspace-managed compose)")
            return True

        try:
            dc_path = self._docker_compose_path()
            self.backup_file(dc_path)

            # Load YAMLs
            with open(dc_path) as f:
                base = yaml.safe_load(f) or {}
            with open(fragment_path) as f:
                fragment = yaml.safe_load(f) or {}

            merged = DockerComposeMerger.merge(base, fragment)

            with open(dc_path, "w") as f:
                yaml.dump(merged, f, default_flow_style=False, sort_keys=False)
            self.applied_changes.append(f"Merged {feature_name} docker-compose")
            print("✓ Merged docker-compose.yml")
            return True
        except Exception as e:
            print(f"❌ Failed to merge docker-compose: {e}")
            return False

    def merge_settings(self, feature_name: str) -> bool:
        """
        Merge settings.py fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "settings.fragment.py"

        if not fragment_path.exists():
            return True  # Not required

        try:
            settings_path = self._pkg_dir / "settings.py"
            if not settings_path.exists():
                print("⚠ settings.py not found, skipping")
                return True

            self.backup_file(settings_path)

            base = settings_path.read_text()
            fragment = fragment_path.read_text()
            merged = SettingsMerger.merge(base, fragment)

            settings_path.write_text(merged)
            self.applied_changes.append(f"Merged {feature_name} settings")
            print("✓ Merged settings.py")
            return True
        except FragmentMergeError as e:
            print(f"⚠ {e}")
            return True  # Non-fatal; feature still usable
        except Exception as e:
            print(f"❌ Failed to merge settings: {e}")
            return False

    def merge_conftest(self, feature_name: str) -> bool:
        """
        Merge conftest.py fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "conftest.fragment.py"

        if not fragment_path.exists():
            return True  # Not required

        try:
            if self._workspace_root is not None:
                conftest_path = (
                    self._tests_dir / "acceptance" / self.service_root.name / "conftest.py"
                )
            else:
                conftest_path = self._tests_dir / "conftest.py"
            if not conftest_path.exists():
                print("⚠ conftest.py not found, skipping")
                return True

            self.backup_file(conftest_path)

            base = conftest_path.read_text()
            fragment = self._rewrite_src_app_refs(fragment_path.read_text())
            merged = ConfTestMerger.merge(base, fragment)

            conftest_path.write_text(merged)
            self.applied_changes.append(f"Merged {feature_name} conftest")
            print("✓ Merged conftest.py")
            return True
        except FragmentMergeError as e:
            print(f"⚠ {e}")
            return True  # Non-fatal
        except Exception as e:
            print(f"❌ Failed to merge conftest: {e}")
            return False

    def create_feature_files(self, feature_name: str) -> bool:
        """
        Create feature-specific files (templates).

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        feature_dir = self.feature_lib / feature_name / "src" / "app"

        if not feature_dir.exists():
            # No template files to create
            return True

        try:
            # Copy entire tree into the service package directory
            for src_file in feature_dir.rglob("*"):
                if src_file.is_file():
                    rel_path = src_file.relative_to(feature_dir)
                    dest_file = self._pkg_dir / rel_path

                    # Create parent dirs
                    dest_file.parent.mkdir(parents=True, exist_ok=True)

                    if src_file.suffix == ".py":
                        rendered = self._rewrite_src_app_refs(src_file.read_text())
                        dest_file.write_text(rendered)
                    else:
                        shutil.copy2(src_file, dest_file)
                    self.applied_changes.append(f"Created {rel_path}")

            print("✓ Created feature files")
            return True
        except Exception as e:
            print(f"❌ Failed to create feature files: {e}")
            return False

    def create_test_files(self, feature_name: str) -> bool:
        """
        Create test files.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        test_dir = self.feature_lib / feature_name / "tests"

        if not test_dir.exists():
            return True

        try:
            for src_file in test_dir.rglob("*"):
                if src_file.is_file():
                    rel_path = src_file.relative_to(test_dir)
                    if self._workspace_root is not None:
                        parts = rel_path.parts
                        if parts and parts[0] in {"unit", "acceptance"}:
                            scoped_rel = Path(parts[0]) / self.service_root.name / Path(*parts[1:])
                        elif rel_path.name == "conftest.py":
                            scoped_rel = Path("acceptance") / self.service_root.name / "conftest.py"
                        else:
                            scoped_rel = Path("acceptance") / self.service_root.name / rel_path
                        dest_file = self._tests_dir / scoped_rel
                    else:
                        dest_file = self._tests_dir / rel_path

                    dest_file.parent.mkdir(parents=True, exist_ok=True)
                    if src_file.suffix == ".py":
                        rendered = self._rewrite_src_app_refs(src_file.read_text())
                        dest_file.write_text(rendered)
                    else:
                        shutil.copy2(src_file, dest_file)
                    self.applied_changes.append(f"Created {rel_path}")

            print("✓ Created test files")
            return True
        except Exception as e:
            print(f"❌ Failed to create test files: {e}")
            return False

    def add_feature(self, feature_name: str, plan: bool = False) -> tuple[bool, list[str]]:
        """
        Add feature to service.

        Parameters
        ----------
        feature_name : str
            Feature name
        plan : bool
            If True, dry-run (show plan without applying)

        Returns
        -------
        tuple[bool, list[str]]
            (success, list of changes applied)
        """
        self.applied_changes = []
        print(f"\n📦 Adding feature: {feature_name}")
        print()

        # Step 1: Load & validate manifest
        if not self.load_feature(feature_name):
            return False, []

        # Step 2: Validate service structure
        if not self.validate_service():
            print("❌ Service validation failed")
            return False, []

        # Step 2.5: Check if feature already applied (idempotency)
        creates = self.manifest.get("creates", [])
        if creates:
            first_created_path = Path(creates[0])
            # Feature manifests use src/app/ prefix — remap to flat pkg layout
            try:
                rel = first_created_path.relative_to("src/app")
                full_path = self._pkg_dir / rel
            except ValueError:
                full_path = self.service_root / first_created_path
            if full_path.exists():
                print(f"✅ Feature '{feature_name}' already applied (detected {creates[0]})")
                return True, []

        # Step 3: Check requirements
        req_errors = self.validate_requirements()
        if req_errors:
            print("❌ Feature requirements not met:")
            for err in req_errors:
                print(f"   - {err}")
            return False, []

        # Step 4: If plan mode, just describe
        if plan:
            print("📋 Plan (dry-run):")
            modifies = self.manifest.get("modifies", [])
            for f in modifies:
                print(f"  • Update {f}")
            creates = self.manifest.get("creates", [])
            for f in creates:
                print(f"  • Create {f}")
            return True, []

        # Step 5: Apply changes
        print("Applying changes...")
        print()

        all_success = True
        all_success &= self.merge_requirements(feature_name)
        all_success &= self.merge_docker_compose(feature_name)
        all_success &= self.merge_settings(feature_name)
        all_success &= self.merge_conftest(feature_name)
        all_success &= self.create_feature_files(feature_name)
        all_success &= self.create_test_files(feature_name)

        if not all_success:
            self.rollback()
        return all_success, self.applied_changes

    def build_plan(self, feature_name: str) -> dict[str, list[str]] | None:
        """Return a structured dry-run plan for feature application."""
        if not self.load_feature(feature_name):
            return None
        return {
            "modifies": list(self.manifest.get("modifies", [])),
            "creates": list(self.manifest.get("creates", [])),
        }

    def rollback(self) -> None:
        """Restore all backups."""
        print("\n🔄 Rolling back changes...")
        for original_path, backup_path in self.backups.items():
            shutil.copy2(backup_path, original_path)
            Path(backup_path).unlink()
            print(f"  Restored {original_path}")
        self.backups.clear()
