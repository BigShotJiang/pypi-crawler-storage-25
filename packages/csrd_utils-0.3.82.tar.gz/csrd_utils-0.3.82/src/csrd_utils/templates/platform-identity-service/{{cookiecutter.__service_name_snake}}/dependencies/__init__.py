from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends

from csrd.repository import PGAdapter

from ..repositories.user_repository import UserRepository
from ..settings import settings


async def user_repository_factory() -> AsyncIterator[UserRepository]:
    adapter = PGAdapter(
        host=settings.db_host,
        port=settings.db_port,
        user=settings.db_user,
        password=settings.db_password,
        database=settings.db_name,
    )
    await adapter.connect()
    repo = UserRepository(adapter)
    await repo._init_schema()
    try:
        yield repo
    finally:
        await adapter.close()


UserRepositoryDep = Annotated[UserRepository, Depends(user_repository_factory)]

__all__ = ("UserRepositoryDep", "user_repository_factory")
