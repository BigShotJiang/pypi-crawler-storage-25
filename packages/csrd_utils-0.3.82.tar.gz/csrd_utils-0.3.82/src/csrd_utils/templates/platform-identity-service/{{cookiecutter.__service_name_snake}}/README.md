# {{ cookiecutter.service_name }}

Platform identity service — manages users and credentials.

## Endpoints

- `POST /api/signup` — create a new user
- `GET /api/users/{user_id}` — get user by ID
- `GET /api/users/{user_id}/roles` — get user roles
- `POST /api/users/{user_id}/roles` — assign a role to user
- `POST /api/verify-credentials` — verify username/password (used by auth-service)
- `GET /health` — liveness probe

## Configuration

| Variable | Default | Description |
|---|---|---|
| `DB_HOST` | `localhost` | Postgres host |
| `DB_PORT` | `5432` | Postgres port |
| `DB_USER` | `service_user` | Postgres user |
| `DB_PASSWORD` | `change_me` | Postgres password |
| `DB_NAME` | `service_db` | Postgres database name |

## Run

```bash
pip install -r requirements.txt
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```
