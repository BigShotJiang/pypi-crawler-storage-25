import uuid
from datetime import UTC, datetime
from hashlib import sha256

from csrd.repository import BaseRepository, DBProtocol


class UserRepository(BaseRepository):
    def __init__(self, adapter: DBProtocol) -> None:
        super().__init__(adapter)

    async def _init_schema(self) -> None:
        await self.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        await self.execute(
            """
            CREATE TABLE IF NOT EXISTS user_credentials (
                user_id TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
            """
        )
        await self.execute(
            """
            CREATE TABLE IF NOT EXISTS user_roles (
                user_id TEXT NOT NULL,
                role TEXT NOT NULL,
                PRIMARY KEY (user_id, role),
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
            """
        )

    @staticmethod
    def _hash_password(username: str, password: str) -> str:
        # NOTE: deterministic hash for development only; use salted hashing in production.
        return sha256(f"{username}:{password}".encode()).hexdigest()

    async def create_user(self, username: str) -> dict[str, str]:
        user_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        await self._init_schema()
        await self.execute(
            "INSERT INTO users (id, username, created_at) VALUES (%(id)s, %(username)s, %(created_at)s)",
            {"id": user_id, "username": username, "created_at": created_at},
        )
        return {"id": user_id, "username": username, "created_at": created_at}

    async def get_user(self, user_id: str) -> dict[str, str] | None:
        await self._init_schema()
        row = await self.fetch_one(
            "SELECT id, username, created_at FROM users WHERE id = %(id)s",
            {"id": user_id},
        )
        if row is None:
            return None
        return {
            "id": str(row.get("id", "")),
            "username": str(row.get("username", "")),
            "created_at": str(row.get("created_at", "")),
        }

    async def get_roles(self, user_id: str) -> list[str]:
        await self._init_schema()
        rows = await self.fetch_all(
            "SELECT role FROM user_roles WHERE user_id = %(user_id)s",
            {"user_id": user_id},
        )
        return [str(row["role"]) for row in rows]

    async def assign_role(self, user_id: str, role: str) -> None:
        await self._init_schema()
        await self.execute(
            "INSERT INTO user_roles (user_id, role) VALUES (%(user_id)s, %(role)s) "
            "ON CONFLICT (user_id, role) DO NOTHING",
            {"user_id": user_id, "role": role},
        )

    async def verify_credentials(self, username: str, password: str) -> dict[str, object] | None:
        await self._init_schema()
        row = await self.fetch_one(
            "SELECT u.id, u.username, u.created_at FROM users u "
            "JOIN user_credentials c ON c.user_id = u.id "
            "WHERE u.username = %(username)s AND c.password_hash = %(password_hash)s",
            {"username": username, "password_hash": self._hash_password(username, password)},
        )
        if row is None:
            return None
        user_id = str(row.get("id", ""))
        roles = await self.get_roles(user_id)
        return {
            "id": user_id,
            "username": str(row.get("username", "")),
            "created_at": str(row.get("created_at", "")),
            "roles": roles,
        }

    async def signup(self, username: str, password: str) -> dict[str, str]:
        await self._init_schema()
        existing = await self.fetch_one(
            "SELECT id FROM users WHERE username = %(username)s",
            {"username": username},
        )
        if existing is not None:
            raise ValueError("username already exists")

        user = await self.create_user(username)
        await self.execute(
            "INSERT INTO user_credentials (user_id, password_hash) "
            "VALUES (%(user_id)s, %(password_hash)s)",
            {
                "user_id": user["id"],
                "password_hash": self._hash_password(username, password),
            },
        )
        return user
