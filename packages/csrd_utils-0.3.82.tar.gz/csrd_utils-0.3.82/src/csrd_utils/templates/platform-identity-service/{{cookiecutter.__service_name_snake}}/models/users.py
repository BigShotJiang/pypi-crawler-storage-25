from pydantic import BaseModel


class SignupRequest(BaseModel):
    username: str
    password: str


class VerifyCredentialsRequest(BaseModel):
    username: str
    password: str


class AssignRoleRequest(BaseModel):
    role: str


class UserInfo(BaseModel):
    """User information."""

    id: str
    username: str
    created_at: str


class UserRolesResponse(BaseModel):
    """User roles response."""

    user_id: str
    roles: list[str]


class VerifyCredentialsResponse(BaseModel):
    """Credentials verification response."""

    valid: bool
    user: UserInfo
