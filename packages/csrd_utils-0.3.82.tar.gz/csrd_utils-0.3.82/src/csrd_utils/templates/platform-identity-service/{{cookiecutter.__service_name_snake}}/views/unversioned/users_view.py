from fastapi import APIRouter, HTTPException

from ...dependencies import UserRepositoryDep
from ...models import (
    AssignRoleRequest,
    SignupRequest,
    UserInfo,
    UserRolesResponse,
    VerifyCredentialsRequest,
    VerifyCredentialsResponse,
)

router = APIRouter(prefix="/api", tags=["Identity Endpoints"])

@router.get("/users/{user_id}", response_model=UserInfo)
async def get_user(user_id: str, repo: UserRepositoryDep) -> UserInfo:
    user = await repo.get_user(user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="user not found")
    return UserInfo(**user)


@router.get("/users/{user_id}/roles", response_model=UserRolesResponse)
async def get_user_roles(user_id: str, repo: UserRepositoryDep) -> UserRolesResponse:
    user = await repo.get_user(user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="user not found")
    roles = await repo.get_roles(user_id)
    return UserRolesResponse(user_id=user_id, roles=roles)


@router.post("/users/{user_id}/roles", status_code=204)
async def assign_role(user_id: str, payload: AssignRoleRequest, repo: UserRepositoryDep) -> None:
    user = await repo.get_user(user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="user not found")
    await repo.assign_role(user_id, payload.role)


@router.post("/verify-credentials", response_model=VerifyCredentialsResponse)
async def verify_credentials(
    repo: UserRepositoryDep, payload: VerifyCredentialsRequest
) -> VerifyCredentialsResponse:
    user_data = await repo.verify_credentials(payload.username, payload.password)
    if user_data is None:
        raise HTTPException(status_code=401, detail="invalid credentials")
    return VerifyCredentialsResponse(
        valid=True,
        user=UserInfo(**user_data),
    )


@router.post("/signup", response_model=UserInfo)
async def create_user(repo: UserRepositoryDep, payload: SignupRequest) -> UserInfo:
    try:
        user_data = await repo.signup(payload.username, payload.password)
        return UserInfo(**user_data)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
