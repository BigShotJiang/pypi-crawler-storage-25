# {{ cookiecutter.service_name }}

Platform auth service — issues and verifies JWT tokens.

## Endpoints

- `POST /api/token` — issue a JWT (validates credentials via identity-service)
- `POST /api/verify` — verify a JWT and return claims
- `GET /health` — liveness probe

## Configuration

| Variable | Default | Description |
|---|---|---|
| `JWT_SECRET` | `dev-secret-change-me-please-32-bytes` | Signing key |
| `JWT_ALGORITHM` | `HS256` | JWT algorithm |
| `JWT_ISSUER` | `{{ cookiecutter.service_name }}` | Token issuer |
| `JWT_AUDIENCE` | `cluster` | Token audience |
| `JWT_TTL_SECONDS` | `3600` | Token TTL |
| `DB_HOST` | `localhost` | Postgres host |
| `DB_PORT` | `5432` | Postgres port |
| `DB_USER` | `service_user` | Postgres user |
| `DB_PASSWORD` | `change_me` | Postgres password |
| `DB_NAME` | `service_db` | Postgres database name |
| `IDENTITY_SERVICE_URL` | `{{ cookiecutter.identity_service_url }}` | Identity service URL |

## Run

```bash
pip install -r requirements.txt
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```
