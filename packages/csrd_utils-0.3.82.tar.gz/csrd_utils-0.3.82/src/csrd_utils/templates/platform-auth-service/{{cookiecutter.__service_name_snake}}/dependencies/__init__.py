# Auth service dependencies
from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends

from csrd.repository import PGAdapter

from ..repositories.token_repository import TokenRepository
from ..settings import settings


async def token_repository_factory() -> AsyncIterator[TokenRepository]:
    adapter = PGAdapter(
        host=settings.db_host,
        port=settings.db_port,
        user=settings.db_user,
        password=settings.db_password,
        database=settings.db_name,
    )
    await adapter.connect()
    repo = TokenRepository(adapter)
    await repo._init_schema()
    try:
        yield repo
    finally:
        await adapter.close()


TokenRepositoryDep = Annotated[TokenRepository, Depends(token_repository_factory)]

__all__ = ("TokenRepositoryDep", "token_repository_factory")
