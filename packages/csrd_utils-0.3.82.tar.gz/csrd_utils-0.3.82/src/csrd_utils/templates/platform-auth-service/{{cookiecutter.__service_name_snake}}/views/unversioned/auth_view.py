from datetime import UTC, datetime, timedelta

import httpx
import jwt
from fastapi import APIRouter, HTTPException, Request

from csrd.auth import JWTAuthenticator, StaticKeyProvider

from ...models import TokenRequest, TokenResponse, TokenVerifyResponse, VerifyClaims, VerifyRequest
from ...settings import settings

router = APIRouter(prefix="/api", tags=["Auth Endpoints"])

def _make_verifier() -> JWTAuthenticator:
    return JWTAuthenticator(
        key=StaticKeyProvider(settings.jwt_secret),
        algorithms=[settings.jwt_algorithm],
        audience=settings.jwt_audience,
        issuer=settings.jwt_issuer,
    )


async def _validate_credentials(username: str, password: str) -> list[str]:
    """Validate username/password against identity-service; raises 401 on failure.
    Returns the list of roles assigned to the user."""
    if not settings.identity_service_url:
        return []  # identity not configured — allow any username (fallback)

    async with httpx.AsyncClient(timeout=5.0) as client:
        try:
            response = await client.post(
                f"{settings.identity_service_url}/api/verify-credentials",
                json={"username": username, "password": password},
            )
        except httpx.ConnectError as exc:
            raise HTTPException(status_code=503, detail="identity service unavailable") from exc

    if response.status_code == 401:
        raise HTTPException(status_code=401, detail="invalid credentials")

    if response.status_code != 200:
        raise HTTPException(status_code=502, detail="identity service error")

    data = response.json()
    user = data.get("user", {})
    return list(user.get("roles", []))


@router.post("/token", response_model=TokenResponse)
async def issue_token(payload: TokenRequest) -> TokenResponse:
    roles = await _validate_credentials(payload.username, payload.password)

    now = datetime.now(UTC)
    claims = {
        "sub": payload.username,
        "iss": settings.jwt_issuer,
        "aud": settings.jwt_audience,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=settings.jwt_ttl_seconds)).timestamp()),
        "authorities": roles,
        "roles": roles,
    }
    token = jwt.encode(claims, settings.jwt_secret, algorithm=settings.jwt_algorithm)
    return TokenResponse(
        access_token=token, token_type="bearer", expires_in=settings.jwt_ttl_seconds
    )


@router.post("/verify", response_model=TokenVerifyResponse)
async def verify_token(request: Request, payload: VerifyRequest) -> TokenVerifyResponse:
    verifier = _make_verifier()
    claims = await verifier(request, payload.token)
    return TokenVerifyResponse(
        valid=True,
        claims=VerifyClaims(
            sub=claims.sub,
            user_name=claims.user_name,
            authorities=claims.authorities,
            roles=claims.authorities,
        ),
    )
