from pydantic import BaseModel


class TokenRequest(BaseModel):
    username: str
    password: str


class VerifyRequest(BaseModel):
    token: str


class TokenResponse(BaseModel):
    """JWT token issuance response."""

    access_token: str
    token_type: str
    expires_in: int


class VerifyClaims(BaseModel):
    """JWT claim fields returned by verify endpoint."""

    sub: str
    user_name: str
    authorities: list[str]
    roles: list[str]


class TokenVerifyResponse(BaseModel):
    """Token verification response."""

    valid: bool
    claims: VerifyClaims
