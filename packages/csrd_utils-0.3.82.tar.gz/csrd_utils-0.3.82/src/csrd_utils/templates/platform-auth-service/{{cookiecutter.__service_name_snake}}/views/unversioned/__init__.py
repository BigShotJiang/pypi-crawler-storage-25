from fastapi import FastAPI

from . import auth_view, health_view

unversioned_app = FastAPI(title="{{ cookiecutter.service_name }}")

unversioned_app.include_router(health_view.router)
unversioned_app.include_router(auth_view.router)

__all__ = ("unversioned_app",)
