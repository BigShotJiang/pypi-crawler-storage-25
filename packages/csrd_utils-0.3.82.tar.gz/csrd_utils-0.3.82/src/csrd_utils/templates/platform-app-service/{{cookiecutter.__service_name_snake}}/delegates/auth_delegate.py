from csrd.delegate import BaseDelegate

from ..settings import settings


class AuthDelegate(BaseDelegate):
    def __init__(self) -> None:
        super().__init__(settings.auth_service_url)

    async def login(self, username: str, password: str) -> dict[str, object]:
        return await self.post("/api/token", json={"username": username, "password": password})
