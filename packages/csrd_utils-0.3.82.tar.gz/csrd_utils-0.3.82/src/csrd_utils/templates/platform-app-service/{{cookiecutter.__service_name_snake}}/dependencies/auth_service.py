from typing import Annotated

import httpx
from fastapi import Depends, HTTPException, Security
from fastapi.requests import Request
from fastapi.security import HTTPBearer

from csrd.auth import CallbackAuthenticator, create_bearer_dependency
from csrd.models.claims import UserClaims
from csrd.versioning import find_token

from ..settings import settings


def _map_claims(payload: dict[str, object]) -> UserClaims:
    claims = payload.get("claims") if isinstance(payload.get("claims"), dict) else payload
    if not isinstance(claims, dict):
        raise HTTPException(status_code=502, detail="invalid auth response")

    authorities = claims.get("authorities") or claims.get("roles") or []
    if isinstance(authorities, str):
        authorities = authorities.split()

    sub = str(claims.get("sub", ""))
    user_name = str(claims.get("user_name") or sub)

    return UserClaims(sub=sub, user_name=user_name, authorities=list(authorities))


async def _remote_verify(_: Request, token: str) -> UserClaims:
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{settings.auth_service_url}/api/verify",
                json={"token": token},
            )
    except httpx.ConnectError as exc:
        raise HTTPException(status_code=503, detail="auth service unavailable") from exc

    if response.status_code != 200:
        raise HTTPException(status_code=401, detail="invalid token")

    payload = response.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=502, detail="invalid auth response")
    return _map_claims(payload)


_authenticator = CallbackAuthenticator(callback=_remote_verify)
_bearer_dep = create_bearer_dependency(_authenticator, token_finder=find_token)
_http_bearer_scheme = HTTPBearer()
_router_scheme_dep = Security(_http_bearer_scheme)
_router_claims_dep = Depends(_bearer_dep)

# For use as a route function parameter annotation.
VerifiedTokenDep = Annotated[UserClaims, Security(_bearer_dep)]

async def _router_auth_guard(
    _scheme=_router_scheme_dep,
    _claims=_router_claims_dep,
) -> None:
    """Composite auth dependency for router-level use."""


# Use as `dependencies=[router_auth]` so adding more deps stays explicit.
router_auth = Depends(_router_auth_guard)

__all__ = ("VerifiedTokenDep", "router_auth")
