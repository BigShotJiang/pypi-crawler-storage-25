from fastapi import APIRouter

from ...dependencies import AuthDelegateDep, IdentityDelegateDep
from ...models import LoginRequest, SignupRequest

router = APIRouter(tags=["Auth Service"])

@router.post("/signup")
async def signup(payload: SignupRequest, delegate: IdentityDelegateDep) -> dict[str, object]:
    async with delegate:
        return await delegate.signup(payload.username, payload.password)


@router.post("/login")
async def login(payload: LoginRequest, delegate: AuthDelegateDep) -> dict[str, object]:
    async with delegate:
        return await delegate.login(payload.username, payload.password)
