from fastapi import FastAPI

from csrd.versioning import (
    UNVERSIONED,
    VersionedApiConfig,
    VersionedAppComposeConfig,
    compose_versioned_apps,
)

from .views import unversioned_app


def build_app() -> FastAPI:
    return compose_versioned_apps(
        version_mapping={UNVERSIONED: unversioned_app},
        config=VersionedAppComposeConfig(
            title="{{ cookiecutter.service_name }}",
            api=VersionedApiConfig(prefix="/", include_actuator_endpoints=False),
        ),
    )


__all__ = ("build_app",)
