from pydantic import BaseModel


class CreateItemRequest(BaseModel):
    name: str


class UpdateItemRequest(BaseModel):
    name: str


class ItemResponse(BaseModel):
    id: str
    name: str
    created_at: str


class ItemListResponse(BaseModel):
    items: list[ItemResponse]


class ItemUpdateResponse(BaseModel):
    id: str
    name: str
    updated: bool


class ItemUpsertResponse(BaseModel):
    id: str
    name: str
    rows_affected: int


class ItemDeleteResponse(BaseModel):
    id: str
    deleted: bool
