from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "{{ cookiecutter.service_name }}"
    port: int = {{ cookiecutter.port }}

    db_host: str = "localhost"
    db_port: int = 5432
    db_user: str = "service_user"
    db_password: str = "change_me"
    db_name: str = "service_db"

    auth_service_url: str = "{{ cookiecutter.auth_service_url }}"
    identity_service_url: str = "{{ cookiecutter.identity_service_url }}"


settings = Settings()
