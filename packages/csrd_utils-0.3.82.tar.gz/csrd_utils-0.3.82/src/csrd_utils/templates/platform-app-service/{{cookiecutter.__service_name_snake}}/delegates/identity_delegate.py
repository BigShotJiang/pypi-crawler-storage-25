from csrd.delegate import BaseDelegate

from ..settings import settings


class IdentityDelegate(BaseDelegate):
    def __init__(self) -> None:
        super().__init__(settings.identity_service_url)

    async def signup(self, username: str, password: str) -> dict[str, object]:
        return await self.post("/api/signup", json={"username": username, "password": password})
