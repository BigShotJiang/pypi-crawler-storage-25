from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends

from csrd.repository import PGAdapter

from ..repositories import ItemRepository
from ..settings import settings


async def item_repository_factory() -> AsyncIterator[ItemRepository]:
    adapter = PGAdapter(
        host=settings.db_host,
        port=settings.db_port,
        user=settings.db_user,
        password=settings.db_password,
        database=settings.db_name,
    )
    await adapter.connect()
    repo = ItemRepository(adapter)
    await repo._init_schema()
    try:
        yield repo
    finally:
        await adapter.close()


ItemRepositoryDep = Annotated[ItemRepository, Depends(item_repository_factory)]

__all__ = ("ItemRepositoryDep", "item_repository_factory")
