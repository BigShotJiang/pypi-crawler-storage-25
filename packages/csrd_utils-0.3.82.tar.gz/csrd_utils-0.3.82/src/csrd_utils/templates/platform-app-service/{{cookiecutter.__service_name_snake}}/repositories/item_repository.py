import uuid
from datetime import UTC, datetime

from csrd.repository import BaseRepository, DBProtocol


_CREATE_ITEMS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
)
"""


class ItemRepository(BaseRepository):
    def __init__(self, adapter: DBProtocol) -> None:
        super().__init__(adapter)

    async def _init_schema(self) -> None:
        await self.execute(_CREATE_ITEMS_TABLE_SQL)

    async def create_item(self, name: str) -> dict[str, str]:
        item_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        await self._init_schema()
        await self.insert("items", {"id": item_id, "name": name, "created_at": created_at})
        return {"id": item_id, "name": name, "created_at": created_at}

    async def list_items(self) -> list[dict[str, str]]:
        await self._init_schema()
        rows = await self.fetch_all("SELECT id, name, created_at FROM items ORDER BY created_at DESC")
        return [
            {
                "id": str(row.get("id", "")),
                "name": str(row.get("name", "")),
                "created_at": str(row.get("created_at", "")),
            }
            for row in rows
        ]

    async def get_item(self, item_id: str) -> dict[str, str] | None:
        await self._init_schema()
        row = await self.fetch_one(
            "SELECT id, name, created_at FROM items WHERE id = %(id)s",
            {"id": item_id},
        )
        if row is None:
            return None
        return {
            "id": str(row.get("id", "")),
            "name": str(row.get("name", "")),
            "created_at": str(row.get("created_at", "")),
        }

    async def update_item(self, item_id: str, name: str) -> int:
        await self._init_schema()
        return await super().update("items", {"name": name}, {"id": item_id})

    async def delete_item(self, item_id: str) -> int:
        await self._init_schema()
        return await super().delete("items", {"id": item_id})

    async def upsert_item(self, item_id: str, name: str) -> int:
        await self._init_schema()
        created_at = datetime.now(UTC).isoformat()
        return await super().upsert(
            "items",
            {"name": name, "created_at": created_at},
            {"id": item_id},
        )
