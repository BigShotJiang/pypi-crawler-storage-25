from fastapi import APIRouter, HTTPException

from ...dependencies import ItemRepositoryDep, router_auth
from ...models import (
    CreateItemRequest,
    ItemDeleteResponse,
    ItemListResponse,
    ItemResponse,
    ItemUpdateResponse,
    ItemUpsertResponse,
    UpdateItemRequest,
)

router = APIRouter(prefix="/api", tags=["Items Endpoints"], dependencies=[router_auth])


@router.post("/items", response_model=ItemResponse)
async def create_item(
    payload: CreateItemRequest,
    repo: ItemRepositoryDep,
) -> ItemResponse:
    return await repo.create_item(payload.name)


@router.get("/items", response_model=ItemListResponse)
async def list_items(repo: ItemRepositoryDep) -> ItemListResponse:
    return {"items": await repo.list_items()}


@router.get("/items/{entity_id}", response_model=ItemResponse)
async def get_item(entity_id: str, repo: ItemRepositoryDep) -> ItemResponse:
    item = await repo.get_item(entity_id)
    if item is None:
        raise HTTPException(status_code=404, detail="item not found")
    return item


@router.put("/items/{entity_id}", response_model=ItemUpdateResponse)
async def update_item(
    entity_id: str,
    payload: UpdateItemRequest,
    repo: ItemRepositoryDep,
) -> ItemUpdateResponse:
    rows = await repo.update_item(entity_id, payload.name)
    if rows == 0:
        raise HTTPException(status_code=404, detail="item not found")
    return {"id": entity_id, "name": payload.name, "updated": True}


@router.put("/items/{entity_id}/upsert", response_model=ItemUpsertResponse)
async def upsert_item(
    entity_id: str,
    payload: UpdateItemRequest,
    repo: ItemRepositoryDep,
) -> ItemUpsertResponse:
    rows = await repo.upsert_item(entity_id, payload.name)
    return {"id": entity_id, "name": payload.name, "rows_affected": rows}


@router.delete("/items/{entity_id}", response_model=ItemDeleteResponse)
async def delete_item(
    entity_id: str,
    repo: ItemRepositoryDep,
) -> ItemDeleteResponse:
    rows = await repo.delete_item(entity_id)
    if rows == 0:
        raise HTTPException(status_code=404, detail="item not found")
    return {"id": entity_id, "deleted": True}
