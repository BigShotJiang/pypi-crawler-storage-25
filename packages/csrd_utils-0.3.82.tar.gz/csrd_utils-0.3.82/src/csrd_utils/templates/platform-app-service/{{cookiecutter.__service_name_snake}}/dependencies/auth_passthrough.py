from typing import Annotated

from fastapi import Depends

from ..delegates import AuthDelegate, IdentityDelegate


def auth_delegate_factory() -> AuthDelegate:
    return AuthDelegate()


def identity_delegate_factory() -> IdentityDelegate:
    return IdentityDelegate()


AuthDelegateDep = Annotated[AuthDelegate, Depends(auth_delegate_factory)]
IdentityDelegateDep = Annotated[IdentityDelegate, Depends(identity_delegate_factory)]


__all__ = (
    "AuthDelegateDep",
    "IdentityDelegateDep",
    "auth_delegate_factory",
    "identity_delegate_factory",
)
