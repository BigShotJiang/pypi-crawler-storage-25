"""Unit tests for database settings wiring."""

from {{cookiecutter.__service_name_snake}}.settings import settings


def test_database_settings_enabled() -> None:
    assert settings.has_database is True
    assert settings.db_kind in {"sqlite", "maria", "postgres"}
