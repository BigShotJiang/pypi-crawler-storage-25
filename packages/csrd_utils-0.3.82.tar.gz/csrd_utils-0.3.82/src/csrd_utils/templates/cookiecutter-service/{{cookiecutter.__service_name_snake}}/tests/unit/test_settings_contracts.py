"""Unit tests for settings validator branches and package exports."""

from __future__ import annotations

import importlib
from types import SimpleNamespace

import pytest

from {{cookiecutter.__service_name_snake}}.settings import Settings


def test_validate_db_credentials_returns_self_without_database() -> None:
    candidate = SimpleNamespace(has_database=False)
    assert Settings.validate_db_credentials(candidate) is candidate


def test_validate_db_credentials_returns_self_for_sqlite() -> None:
    candidate = SimpleNamespace(has_database=True, db_kind="sqlite")
    assert Settings.validate_db_credentials(candidate) is candidate


def test_validate_db_credentials_skips_non_production_when_not_enforced() -> None:
    candidate = SimpleNamespace(
        has_database=True,
        db_kind="postgres",
        enforce_strong_db_credentials=False,
        app_env="development",
    )
    assert Settings.validate_db_credentials(candidate) is candidate


def test_validate_db_credentials_accepts_strong_values_in_production() -> None:
    candidate = SimpleNamespace(
        has_database=True,
        db_kind="postgres",
        enforce_strong_db_credentials=True,
        app_env="production",
        db_user="inventory_user",
        db_password="StrongPass123!",
        db_name="inventory_db",
    )
    assert Settings.validate_db_credentials(candidate) is candidate


@pytest.mark.parametrize(
    ("field", "value", "expected"),
    [
        ("db_user", "service_user", "DB_USER"),
        ("db_password", "change_me", "DB_PASSWORD"),
        ("db_name", "service_db", "DB_NAME"),
    ],
)
def test_validate_db_credentials_rejects_weak_defaults(
    field: str,
    value: str,
    expected: str,
) -> None:
    candidate = SimpleNamespace(
        has_database=True,
        db_kind="postgres",
        enforce_strong_db_credentials=True,
        app_env="production",
        db_user="app_user",
        db_password="StrongPass123!",
        db_name="inventory_db",
    )
    setattr(candidate, field, value)

    with pytest.raises(ValueError, match=expected):
        Settings.validate_db_credentials(candidate)


def test_app_package_init_modules_expose_tuple_all() -> None:
    for module_name in [
        "{{cookiecutter.__service_name_snake}}.delegates",
        "{{cookiecutter.__service_name_snake}}.dependencies",
        "{{cookiecutter.__service_name_snake}}.middleware",
        "{{cookiecutter.__service_name_snake}}.repositories",
        "{{cookiecutter.__service_name_snake}}.workers",
    ]:
        module = importlib.import_module(module_name)
        exports = getattr(module, "__all__", ())
        assert isinstance(exports, tuple)
        for exported_name in exports:
            assert hasattr(module, exported_name)
