"""Shared test fixtures for {{ cookiecutter.service_name }}."""

import os
import secrets

import pytest
from fastapi.testclient import TestClient
{%- if cookiecutter.has_auth %}
from fastapi import HTTPException

from csrd.models.claims import UserClaims

from {{cookiecutter.__service_name_snake}}.dependencies import auth_service as auth_dependency
{%- endif %}

from {{cookiecutter.__service_name_snake}} import build_app

HAS_DATABASE = {{"True" if cookiecutter.has_database else "False"}}
DB_KIND = "{{ cookiecutter.database }}"
HAS_AUTH = {{"True" if cookiecutter.has_auth else "False"}}


# [INSERT: fixtures]


{%- if cookiecutter.has_auth %}
@pytest.fixture
def auth_token() -> str:
    # Generate a per-test bearer token value used by auth-guarded endpoints.
    return f"test-token-{secrets.token_hex(8)}"


@pytest.fixture(autouse=True)
def mock_auth_verifier(auth_token: str):
    original_callback = auth_dependency._authenticator.callback

    async def _fake_verify(_request, token: str) -> UserClaims:
        if token != auth_token:
            raise HTTPException(status_code=401, detail="invalid token")
        return UserClaims(sub="test-user", user_name="test-user", authorities=["ROLE_USER"])

    auth_dependency._authenticator.callback = _fake_verify
    try:
        yield
    finally:
        auth_dependency._authenticator.callback = original_callback
{%- endif %}


@pytest.fixture
def client():
    if HAS_DATABASE and DB_KIND == "maria":
        os.environ.setdefault("DB_HOST", "localhost")
        os.environ.setdefault("DB_PORT", "3306")
        os.environ.setdefault("DB_USER", "service_user")
        os.environ.setdefault("DB_PASSWORD", "change_me")
        os.environ.setdefault("DB_NAME", "service_db")
    elif HAS_DATABASE and DB_KIND == "postgres":
        os.environ.setdefault("DB_HOST", "localhost")
        os.environ.setdefault("DB_PORT", "5432")
        os.environ.setdefault("DB_USER", "service_user")
        os.environ.setdefault("DB_PASSWORD", "change_me")
        os.environ.setdefault("DB_NAME", "service_db")

    app = build_app()
    return TestClient(app)
