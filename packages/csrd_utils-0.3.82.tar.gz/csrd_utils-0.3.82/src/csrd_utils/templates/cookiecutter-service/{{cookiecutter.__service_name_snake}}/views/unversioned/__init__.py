from fastapi import FastAPI

from . import health_view, items_view

unversioned_app = FastAPI(title="{{ cookiecutter.service_name }}")

unversioned_app.include_router(health_view.router)
unversioned_app.include_router(items_view.router)

__all__ = ("unversioned_app",)
