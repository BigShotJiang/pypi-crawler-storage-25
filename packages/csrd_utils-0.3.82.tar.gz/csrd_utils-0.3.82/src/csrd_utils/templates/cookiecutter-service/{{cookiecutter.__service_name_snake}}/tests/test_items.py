"""Tests for {{ cookiecutter.service_name }} starter endpoints."""

from fastapi import HTTPException

{%- if cookiecutter.has_auth %}


def _auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}
{%- endif %}


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "{{ cookiecutter.service_name }}"}


{%- if cookiecutter.has_database or not cookiecutter.has_delegates %}
def test_create_item_returns_data(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    create_response = client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        json={"name": "Test Item"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert create_response.status_code == 200
    item = create_response.json()
    assert item["name"] == "Test Item"
    assert "id" in item
    assert "created_at" in item


def test_list_items(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        json={"name": "Item 1"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        json={"name": "Item 2"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )

    response = client.get(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 200
    items = response.json()["{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}"]
    names = {item["name"] for item in items}
    assert "Item 1" in names
    assert "Item 2" in names


def test_get_item_missing_returns_404(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    response = client.get(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/missing-id",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 404


def test_get_item_returns_created_item(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    created = client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        json={"name": "Lookup"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    ).json()
    response = client.get(
        f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{created['id']}",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 200
    assert response.json()["id"] == created["id"]
    assert response.json()["name"] == "Lookup"


def test_update_and_delete_item(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    created = client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        json={"name": "Original"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    ).json()
    item_id = created["id"]

    updated = client.put(
        f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{item_id}",
        json={"name": "Updated"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert updated.status_code == 200
    assert updated.json()["updated"] is True

    deleted = client.delete(
        f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{item_id}",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert deleted.status_code == 200
    assert deleted.json()["deleted"] is True


def test_upsert_item(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    item_id = "custom-upsert-id"
    first = client.put(
        f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{item_id}/upsert",
        json={"name": "Created"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert first.status_code == 200
    assert first.json()["rows_affected"] == 1

    second = client.put(
        f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{item_id}/upsert",
        json={"name": "Updated"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert second.status_code == 200
    assert second.json()["rows_affected"] == 1


def test_update_missing_returns_404(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    response = client.put(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/missing-id",
        json={"name": "Nope"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 404


def test_delete_missing_returns_404(client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    response = client.delete(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/missing-id",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 404
{%- endif %}


{%- if cookiecutter.has_delegates and not cookiecutter.has_database %}
def test_delegate_create_and_list(monkeypatch, client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    calls: list[tuple[str, str]] = []

    async def fake_delegate_request(method: str, path: str, payload=None):
        calls.append((method, path))
        if method == "POST":
            return {"id": "d1", "name": payload["name"], "created_at": "2026-01-01T00:00:00Z"}
        return {"{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}": [{"id": "d1", "name": "X", "created_at": "t"}]}

    monkeypatch.setattr("{{cookiecutter.__service_name_snake}}.views.unversioned.items_view._delegate_request", fake_delegate_request)

    created = client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        json={"name": "X"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert created.status_code == 200
    assert created.json()["id"] == "d1"

    listed = client.get(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert listed.status_code == 200
    assert len(listed.json()["{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}"]) == 1
    assert calls[0][0] == "POST"
    assert calls[1][0] == "GET"


def test_delegate_error_mapping(monkeypatch, client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    async def fake_delegate_request(_method: str, _path: str, payload=None):
        raise HTTPException(status_code=404, detail="not found")

    monkeypatch.setattr("{{cookiecutter.__service_name_snake}}.views.unversioned.items_view._delegate_request", fake_delegate_request)
    response = client.get(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/missing",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 404


def test_delegate_get_update_upsert_delete(monkeypatch, client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    async def fake_delegate_request(method: str, path: str, payload=None):
        if method == "GET":
            return {"id": "d2", "name": "From delegate", "created_at": "2026-01-01T00:00:00Z"}
        if method == "PUT" and path.endswith("/upsert"):
            return {"id": "d2", "name": payload["name"], "rows_affected": 1}
        if method == "PUT":
            return {"id": "d2", "name": payload["name"], "updated": True}
        if method == "DELETE":
            return {"id": "d2", "deleted": True}
        return {}

    monkeypatch.setattr("{{cookiecutter.__service_name_snake}}.views.unversioned.items_view._delegate_request", fake_delegate_request)

    fetched = client.get(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/d2",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert fetched.status_code == 200
    assert fetched.json()["id"] == "d2"

    updated = client.put(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/d2",
        json={"name": "Updated"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert updated.status_code == 200
    assert updated.json()["updated"] is True

    upserted = client.put(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/d2/upsert",
        json={"name": "Upserted"},
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert upserted.status_code == 200
    assert upserted.json()["rows_affected"] == 1

    deleted = client.delete(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/d2",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert deleted.status_code == 200
    assert deleted.json()["deleted"] is True


def test_delegate_list_invalid_payload_returns_502(monkeypatch, client{%- if cookiecutter.has_auth %}, auth_token{% endif %}):
    async def fake_delegate_request(_method: str, _path: str, payload=None):
        return {"{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}": "bad"}

    monkeypatch.setattr("{{cookiecutter.__service_name_snake}}.views.unversioned.items_view._delegate_request", fake_delegate_request)
    response = client.get(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
        {%- if cookiecutter.has_auth %}
        headers=_auth_headers(auth_token),
        {%- endif %}
    )
    assert response.status_code == 502
{%- endif %}
