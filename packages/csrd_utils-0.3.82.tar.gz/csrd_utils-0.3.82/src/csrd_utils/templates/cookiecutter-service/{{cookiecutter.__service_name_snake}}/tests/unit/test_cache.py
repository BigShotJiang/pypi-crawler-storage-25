"""Unit tests for cache dependency wiring."""

import importlib

from {{cookiecutter.__service_name_snake}}.cache import build_cache_client


def test_cache_client_uses_configured_host() -> None:
    cache_client = build_cache_client()
    host = cache_client.connection_pool.connection_kwargs.get("host")
    assert host in {"localhost", "redis"}


def test_cache_client_uses_decode_responses() -> None:
    cache_client = build_cache_client()
    assert cache_client.connection_pool.connection_kwargs.get("decode_responses") is True


def test_cache_client_uses_runtime_cache_url() -> None:
    settings_mod = importlib.import_module("{{cookiecutter.__service_name_snake}}.settings")
    original = settings_mod.settings.cache_url
    try:
        settings_mod.settings.cache_url = "redis://cache-host:6381/2"
        cache_client = build_cache_client()
        kwargs = cache_client.connection_pool.connection_kwargs
        assert kwargs.get("host") == "cache-host"
        assert kwargs.get("port") == 6381
        assert kwargs.get("db") == 2
    finally:
        settings_mod.settings.cache_url = original
