"""Tests for manifest changes: knowledge removal, valid artifact types.

Covers tasks 3.1–3.5 from auto-pull-artifact-dependencies OpenSpec change.
"""

import pytest
import yaml
from beacon.core.exceptions import ValidationError as BeaconValidationError
from beacon.core.manifest.beacon import (
    ArtifactsConfig,
    BeaconManifest,
    BeaconManifestValidator,
)
from pydantic import ValidationError


class TestArtifactsConfig:
    """Task 3.1 + 3.2: ArtifactsConfig schema changes."""

    def test_tc1_knowledge_field_removed(self):
        """TC1: knowledge field is not present on ArtifactsConfig."""
        config = ArtifactsConfig()
        assert not hasattr(config, "knowledge")
        assert "knowledge" not in config.model_dump()

    def test_tc2_agents_field_present(self):
        """TC2: agents field is present on ArtifactsConfig."""
        config = ArtifactsConfig()
        assert hasattr(config, "agents")
        dumped = config.model_dump()
        assert "agents" in dumped
        assert "contexts" in dumped
        assert "skills" in dumped

    def test_tc3_extra_forbid_blocks_knowledge(self):
        """TC3: extra=forbid prevents knowledge from being set."""
        with pytest.raises(ValidationError):
            ArtifactsConfig(knowledge=["knowledge/foo.md"])

    def test_tc4_agents_field_accepted(self):
        """TC4: agents field is accepted on ArtifactsConfig."""
        config = ArtifactsConfig(agents=["agents/foo.md"])
        assert config.agents == ["agents/foo.md"]


class TestLegacyDropHook:
    """Task 3.3: Legacy-drop migration hook in from_yaml."""

    LEGACY_LOG_TEXT = "artifacts.knowledge removed; knowledge is now auto-derived"

    def test_tc1_legacy_yaml_with_populated_knowledge(self, tmp_path, loguru_caplog):
        """TC1: Legacy YAML with populated knowledge list → stripped, exactly one log emitted, manifest valid."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  knowledge:
    - knowledge/foo.md
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest.artifacts, "knowledge")
        assert "knowledge" not in manifest.artifacts.model_dump()
        assert manifest.artifacts.contexts == []
        assert manifest.artifacts.skills == []
        msgs = [r.getMessage() for r in loguru_caplog.records]
        assert msgs.count(self.LEGACY_LOG_TEXT) == 1, msgs

    def test_tc2_legacy_yaml_with_empty_knowledge(self, tmp_path, loguru_caplog):
        """TC2: Legacy YAML with empty knowledge: [] → stripped, exactly one log emitted, manifest valid."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  knowledge: []
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest.artifacts, "knowledge")
        assert "knowledge" not in manifest.artifacts.model_dump()
        assert manifest.artifacts.contexts == []
        assert manifest.artifacts.skills == []
        msgs = [r.getMessage() for r in loguru_caplog.records]
        assert msgs.count(self.LEGACY_LOG_TEXT) == 1, msgs

    def test_tc3_modern_yaml_no_knowledge(self, tmp_path, loguru_caplog):
        """TC3: Modern YAML with no knowledge key → no migration log, manifest valid."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest.artifacts, "knowledge")
        assert "knowledge" not in manifest.artifacts.model_dump()
        assert manifest.artifacts.contexts == []
        assert manifest.artifacts.skills == []
        msgs = [r.getMessage() for r in loguru_caplog.records]
        assert self.LEGACY_LOG_TEXT not in msgs, msgs

    def test_tc4_missing_artifacts_key(self, tmp_path, caplog):
        """TC4: YAML missing artifacts key → existing error path, no migration log."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("knowledge:\n  - foo.md\n")

        with pytest.raises(BeaconValidationError) as exc_info:
            BeaconManifest.from_yaml(str(beacon_file))

        assert "artifacts" in str(exc_info.value).lower()

    def test_tc5_legacy_loaded_twice(self, tmp_path, loguru_caplog):
        """TC5: Legacy YAML loaded twice → file rewritten on first load, no log on second."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  knowledge:
    - knowledge/foo.md
  contexts: []
  skills: []
""")
        # First load: should emit log and rewrite file
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest.artifacts, "knowledge")
        msgs = [r.getMessage() for r in loguru_caplog.records]
        assert msgs.count(self.LEGACY_LOG_TEXT) == 1, msgs

        # Assert file was rewritten without knowledge key
        content = beacon_file.read_text()
        assert "knowledge:" not in content
        assert "contexts:" in content
        assert "skills:" in content

        # Second load: should NOT emit migration log (file is now clean)
        loguru_caplog.clear()
        manifest2 = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest2.artifacts, "knowledge")
        msgs2 = [r.getMessage() for r in loguru_caplog.records]
        assert self.LEGACY_LOG_TEXT not in msgs2, msgs2

    def test_tc6_legacy_rewrites_file_on_disk(self, tmp_path, loguru_caplog):
        """TC6: Legacy YAML with knowledge key is rewritten on disk after load."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  knowledge:
    - knowledge/foo.md
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest.artifacts, "knowledge")
        assert "knowledge" not in manifest.artifacts.model_dump()

        # File on disk should no longer contain knowledge key
        content = beacon_file.read_text()
        assert "knowledge:" not in content
        assert "contexts:" in content
        assert "skills:" in content

        # Second load should not emit migration log
        loguru_caplog.clear()
        manifest2 = BeaconManifest.from_yaml(str(beacon_file))
        assert not hasattr(manifest2.artifacts, "knowledge")
        msgs = [r.getMessage() for r in loguru_caplog.records]
        assert self.LEGACY_LOG_TEXT not in msgs, msgs

    def test_tc7_legacy_plus_extra_key(self, tmp_path):
        """TC7: Legacy YAML with knowledge and unexpected extra key → drops knowledge, extra triggers error."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  knowledge:
    - knowledge/foo.md
  contexts: []
  skills: []
  unknown_type:
    - invalid.md
""")
        with pytest.raises(BeaconValidationError) as exc_info:
            BeaconManifest.from_yaml(str(beacon_file))

        error_str = str(exc_info.value).lower()
        assert (
            "unknown" in error_str or "extra" in error_str or "unexpected" in error_str
        )

    def test_tc8_legacy_with_agents_key(self, tmp_path):
        """TC8: YAML with agents key → accepted as valid artifact type."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  agents:
    - agents/reviewer.md
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        assert manifest.artifacts.agents == ["agents/reviewer.md"]


class TestManifestWriter:
    """Task 3.4: Writer never serializes knowledge or agents keys."""

    def test_tc1_extra_forbid_prevents_knowledge_setattr(self):
        """TC1: setattr with knowledge raises ValidationError due to extra=forbid."""
        with pytest.raises(ValidationError):
            ArtifactsConfig(knowledge=["x"])

    def test_tc2_round_trip_no_knowledge(self, tmp_path):
        """TC2: Round-trip write produces no knowledge line."""
        beacon_file = tmp_path / "beacon.yaml"
        manifest = BeaconManifest(
            artifacts=ArtifactsConfig(
                skills=["skills/foo/"], contexts=["contexts/bar.md"]
            )
        )
        manifest.to_yaml(str(beacon_file))

        content = beacon_file.read_text()
        assert "knowledge:" not in content
        assert "agents:" in content
        assert "skills:" in content
        assert "contexts:" in content

    def test_tc3_defaults_write_clean_yaml(self, tmp_path):
        """TC3: Manifest with defaults writes contexts, skills, and agents keys."""
        beacon_file = tmp_path / "beacon.yaml"
        manifest = BeaconManifest()
        manifest.to_yaml(str(beacon_file))

        data = yaml.safe_load(beacon_file.read_text())
        artifact_keys = set(data["artifacts"].keys())
        assert artifact_keys == {"contexts", "skills", "agents"}


class TestBeaconManifestValidator:
    """Task 3.5: Validator uses updated artifact types."""

    def test_validator_accepts_skills_and_contexts(self):
        """Validator accepts skills and contexts artifact types."""
        manifest = BeaconManifest(artifacts=ArtifactsConfig(skills=["skills/foo/"]))
        validator = BeaconManifestValidator()
        result = validator.validate_structure(manifest)
        assert result.valid is True
        assert result.errors == []

    def test_validator_accepts_agents(self, tmp_path):
        """Validator accepts agents artifact type in from_yaml."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  agents:
    - agents/foo.md
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        validator = BeaconManifestValidator()
        result = validator.validate_structure(manifest)
        assert result.valid is True

    def test_validator_drops_knowledge_on_load(self, tmp_path):
        """Validator no longer knows about knowledge type — loaded from legacy is clean."""
        beacon_file = tmp_path / "beacon.yaml"
        beacon_file.write_text("""
artifacts:
  knowledge:
    - knowledge/foo.md
  contexts: []
  skills: []
""")
        manifest = BeaconManifest.from_yaml(str(beacon_file))
        validator = BeaconManifestValidator()
        result = validator.validate_structure(manifest)
        assert result.valid is True
