"""TDD Test Cases for Task 1.4: Settings objects write themselves (no separate writer needed)

Test Coverage:
- TC1: WorkspaceConfig.from_path() → Validates path, writes TOML, returns settings
- TC2: settings.to_toml() → Writes current settings to file
- TC3: beacon.to_yaml() → Writes beacon settings to YAML
- TC4: Write with relative path → Validator converts to absolute
- TC5: Write with ~ in path → Expands ~ to home directory
- TC6: Write to non-existent .agentic-beacon dir → Creates directory first
- TC7: Write with None or empty path → Pydantic validation error
- TC8: Roundtrip write then read → Read returns exact same path
- TC9: WorkspaceConfig() loads from written file → Pydantic reads TOML
- TC10: BeaconManifest.from_yaml() loads from written file → Manual parser reads YAML
"""

import os
from pathlib import Path

import pytest
from beacon.core.manifest.beacon import BeaconManifest
from beacon.core.manifest.workspace import WorkspaceConfig


class TestSettingsSelfWriting:
    """Test suite for settings self-writing capabilities - Task 1.4"""

    def test_tc1_warehouse_settings_from_path(self, temp_dir):
        """TC1: WorkspaceConfig.from_path() → Validates path, writes TOML, returns settings"""
        warehouse_path = "/absolute/warehouse/path"

        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)

            # Create settings from path
            settings = WorkspaceConfig.from_path(warehouse_path)

            # Verify settings were created correctly
            assert isinstance(settings, WorkspaceConfig)
            assert settings.warehouse.local_path == warehouse_path

            # Verify config.toml was written
            config_file = temp_dir / ".agentic-beacon" / "config.toml"
            assert config_file.exists()
            assert "[warehouse]" in config_file.read_text()
        finally:
            os.chdir(original_cwd)

    def test_tc2_settings_to_toml(self, temp_dir, sample_config_toml_valid):
        """TC2: settings.to_toml() → Writes current settings to file"""
        config_dir = temp_dir / ".agentic-beacon"
        config_dir.mkdir()
        config_file = config_dir / "config.toml"
        config_file.write_text(sample_config_toml_valid)

        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            settings = WorkspaceConfig()

            # Write to a different location
            output_file = temp_dir / "output_config.toml"
            settings.to_toml(str(output_file))

            assert output_file.exists()
            assert "[warehouse]" in output_file.read_text()
        finally:
            os.chdir(original_cwd)

    def test_tc3_beacon_to_yaml(self, temp_dir, sample_beacon_yaml_complete):
        """TC3: beacon.to_yaml() → Writes beacon settings to YAML"""
        beacon_file = temp_dir / "beacon.yaml"
        beacon_file.write_text(sample_beacon_yaml_complete)

        settings = BeaconManifest.from_yaml(str(beacon_file))

        # Write to different location
        output_file = temp_dir / "output_beacon.yaml"
        settings.to_yaml(str(output_file))

        assert output_file.exists()
        assert "artifacts:" in output_file.read_text()

    def test_tc4_relative_path_converted_to_absolute(self, temp_dir):
        """TC4: Write with relative path → Validator converts to absolute"""
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)

            # Relative paths should be rejected by validator
            with pytest.raises(ValueError) as exc_info:
                WorkspaceConfig.from_path("relative/path")

            assert "absolute" in str(exc_info.value).lower()
        finally:
            os.chdir(original_cwd)

    def test_tc5_tilde_expansion(self, temp_dir):
        """TC5: Write with ~ in path → Expands ~ to home directory"""
        import os

        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)

            # Use tilde path
            home = Path.home()
            warehouse_path = "~/test/warehouse"

            settings = WorkspaceConfig.from_path(warehouse_path)

            # Should be expanded to absolute path with home directory
            assert settings.warehouse.local_path == str(home / "test" / "warehouse")
            assert settings.warehouse.local_path.startswith(str(home))
        finally:
            os.chdir(original_cwd)

    def test_tc6_creates_directory_if_missing(self, temp_dir):
        """TC6: Write to non-existent .agentic-beacon dir → Creates directory first"""
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)

            # Ensure directory doesn't exist
            beacon_dir = temp_dir / ".agentic-beacon"
            assert not beacon_dir.exists()

            # Create settings - should create directory
            WorkspaceConfig.from_path("/test/path")

            # Verify directory was created
            assert beacon_dir.exists()
            assert beacon_dir.is_dir()
        finally:
            os.chdir(original_cwd)

    def test_tc7_none_or_empty_path_raises_error(self, temp_dir):
        """TC7: Write with None or empty path → Pydantic validation error"""
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)

            # Empty path should raise error
            with pytest.raises(ValueError) as exc_info:
                WorkspaceConfig.from_path("")

            assert (
                "empty" in str(exc_info.value).lower()
                or "path" in str(exc_info.value).lower()
            )
        finally:
            os.chdir(original_cwd)

    def test_tc8_roundtrip_preserves_data(self, temp_dir, sample_beacon_yaml_complete):
        """TC8: Roundtrip write then read → Read returns exact same data"""
        beacon_file = temp_dir / "beacon.yaml"
        beacon_file.write_text(sample_beacon_yaml_complete)

        # Load
        settings1 = BeaconManifest.from_yaml(str(beacon_file))

        # Write
        output_file = temp_dir / "output.yaml"
        settings1.to_yaml(str(output_file))

        # Read back
        settings2 = BeaconManifest.from_yaml(str(output_file))

        # Should be identical
        assert settings1.artifacts.skills == settings2.artifacts.skills
        assert settings1.artifacts.contexts == settings2.artifacts.contexts

    def test_tc9_warehouse_loads_from_written_file(
        self, temp_dir, sample_config_toml_valid
    ):
        """TC9: WorkspaceConfig() loads from written file → Pydantic reads TOML"""
        config_dir = temp_dir / ".agentic-beacon"
        config_dir.mkdir()
        config_file = config_dir / "config.toml"

        # Write manually
        config_file.write_text(sample_config_toml_valid)

        # Load via Pydantic
        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            settings = WorkspaceConfig()
            assert settings.warehouse.local_path == "/absolute/path/to/warehouse"
        finally:
            os.chdir(original_cwd)

    def test_tc10_beacon_loads_from_written_file(
        self, temp_dir, sample_beacon_yaml_complete
    ):
        """TC10: BeaconManifest.from_yaml() loads from written file → Manual parser reads YAML"""
        beacon_file = temp_dir / "beacon.yaml"

        # First create settings and write
        beacon_file.write_text(sample_beacon_yaml_complete)
        settings1 = BeaconManifest.from_yaml(str(beacon_file))

        output_file = temp_dir / "written.yaml"
        settings1.to_yaml(str(output_file))

        # Load from written file
        settings2 = BeaconManifest.from_yaml(str(output_file))
        assert len(settings2.artifacts.skills) == len(settings1.artifacts.skills)

    def test_tc11_to_yaml_emits_ignore_when_non_empty(self, temp_dir):
        """TC11: to_yaml includes ignore section when ignore.skills is non-empty."""
        settings = BeaconManifest(
            artifacts={"skills": [], "contexts": []},
            ignore={"skills": ["openspec-*", "opsx-*"]},
        )
        output_file = temp_dir / "beacon.yaml"
        settings.to_yaml(str(output_file))

        content = output_file.read_text()
        assert "ignore" in content
        assert "openspec-*" in content
        assert "opsx-*" in content

    def test_tc12_to_yaml_omits_ignore_when_empty(self, temp_dir):
        """TC12: to_yaml omits ignore section when ignore.skills is empty."""
        settings = BeaconManifest(
            artifacts={"skills": [], "contexts": []},
        )
        output_file = temp_dir / "beacon.yaml"
        settings.to_yaml(str(output_file))

        content = output_file.read_text()
        assert "ignore" not in content

    def test_tc13_roundtrip_preserves_ignore_skills(self, temp_dir):
        """TC13: Write then read roundtrip preserves ignore.skills values."""
        settings1 = BeaconManifest(
            artifacts={"skills": [], "contexts": []},
            ignore={"skills": ["openspec-*"]},
        )
        output_file = temp_dir / "beacon.yaml"
        settings1.to_yaml(str(output_file))

        settings2 = BeaconManifest.from_yaml(str(output_file))
        assert settings2.ignore.skills == ["openspec-*"]

    def test_tc14_from_path_project_root_returns_config_for_that_root(
        self, tmp_path: Path
    ):
        """TC14: from_path with project_root returns config reflecting that root, not cwd.

        The returned WorkspaceConfig must reflect the path written under project_root,
        even when cwd is a different directory that has no config.toml.
        """
        warehouse_path = str(tmp_path / "warehouse")
        project_root = tmp_path / "project"
        project_root.mkdir()
        unrelated_dir = tmp_path / "unrelated"
        unrelated_dir.mkdir()

        original_cwd = os.getcwd()
        try:
            os.chdir(unrelated_dir)
            result = WorkspaceConfig.from_path(
                warehouse_path, project_root=project_root
            )
        finally:
            os.chdir(original_cwd)

        assert isinstance(result, WorkspaceConfig)
        assert result.warehouse.local_path == warehouse_path
        config_file = project_root / ".agentic-beacon" / "config.toml"
        assert config_file.exists()


class TestWorkspaceConfigMainBranch:
    """main_branch field — configurable default branch for the warehouse."""

    def test_from_path_omits_main_branch_when_unset(self, temp_dir):
        """from_path without main_branch writes config without the field."""
        project_root = temp_dir / "proj"
        project_root.mkdir()

        WorkspaceConfig.from_path(
            "/abs/wh", project_root=project_root, main_branch=None
        )

        toml_text = (project_root / ".agentic-beacon" / "config.toml").read_text()
        assert "main_branch" not in toml_text

    def test_from_path_persists_main_branch(self, temp_dir):
        """from_path with main_branch writes the field to TOML."""
        project_root = temp_dir / "proj"
        project_root.mkdir()

        WorkspaceConfig.from_path(
            "/abs/wh", project_root=project_root, main_branch="dev"
        )

        toml_text = (project_root / ".agentic-beacon" / "config.toml").read_text()
        assert 'main_branch = "dev"' in toml_text

    def test_main_branch_loads_from_toml(self, temp_dir):
        """WorkspaceConfig() reads main_branch from config.toml."""
        config_file = temp_dir / ".agentic-beacon" / "config.toml"
        config_file.parent.mkdir()
        config_file.write_text(
            '[warehouse]\nlocal_path = "/abs/wh"\nmain_branch = "dev"\n'
        )

        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            settings = WorkspaceConfig()
            assert settings.warehouse.main_branch == "dev"
        finally:
            os.chdir(original_cwd)

    def test_main_branch_defaults_to_none(self, temp_dir):
        """When config.toml has no main_branch, the field defaults to None."""
        config_file = temp_dir / ".agentic-beacon" / "config.toml"
        config_file.parent.mkdir()
        config_file.write_text('[warehouse]\nlocal_path = "/abs/wh"\n')

        original_cwd = os.getcwd()
        try:
            os.chdir(temp_dir)
            settings = WorkspaceConfig()
            assert settings.warehouse.main_branch is None
        finally:
            os.chdir(original_cwd)

    def test_empty_main_branch_is_rejected(self):
        """An empty string main_branch fails validation."""
        from beacon.core.manifest.workspace import WarehouseConfig
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            WarehouseConfig(local_path="/abs/wh", main_branch="   ")

    def test_main_branch_rejects_toml_unsafe_chars(self):
        """Characters that would break TOML serialization are rejected."""
        from beacon.core.manifest.workspace import WarehouseConfig
        from pydantic import ValidationError

        for bad in ['dev"main', "dev\\main", "dev main", "dev\nmain"]:
            with pytest.raises(ValidationError):
                WarehouseConfig(local_path="/abs/wh", main_branch=bad)

    def test_main_branch_accepts_valid_git_branch_names(self):
        """Common git branch name patterns are accepted."""
        from beacon.core.manifest.workspace import WarehouseConfig

        for good in ["dev", "main", "release/v1.0", "feature-x", "v2.0.1"]:
            config = WarehouseConfig(local_path="/abs/wh", main_branch=good)
            assert config.main_branch == good

    def test_main_branch_rejects_invalid_git_refs(self):
        """Strings that pass the charset but are not valid git refs are rejected.

        Prevents values like '.' from rendering a destructive 'git checkout .'
        in recovery hints.
        """
        from beacon.core.manifest.workspace import WarehouseConfig
        from pydantic import ValidationError

        invalid_refs = [
            ".",
            "..",
            "@",
            "/foo",
            "foo/",
            "foo.lock",
            "foo..bar",
            "foo//bar",
            ".hidden",
            "release/.bar",
            "release/bar.lock",
            # Leading '-' would be interpreted as a flag by 'git checkout' if it
            # ever made it into the recovery-hint command. Reject at the boundary.
            "-f",
            "-rf",
            "release/-foo",
            # Trailing '.' is rejected by git ref rules
            "foo.",
            "release/foo.",
            # Reserved name
            "HEAD",
        ]
        for bad in invalid_refs:
            with pytest.raises(ValidationError):
                WarehouseConfig(local_path="/abs/wh", main_branch=bad)
