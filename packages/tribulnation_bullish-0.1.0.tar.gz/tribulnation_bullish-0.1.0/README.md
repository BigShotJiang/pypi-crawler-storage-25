# Tribulnation Bullish SDK

> An SDK to connect Bullish with the Tribulnation ecosystem.

🚧 Under construction.