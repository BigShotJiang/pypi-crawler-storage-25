import json
import os
import shutil
import subprocess
import sys
import typer
import git
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.console import Console
from typing import Optional
from typing_extensions import Annotated

app = typer.Typer()
console = Console()
ABS_PATH = os.path.dirname(__file__)


def install_req(repo_path: str, archive: str = "requirements.txt"):
    """Install dependencies from requirements.txt"""
    archive_abs_path = os.path.join(str(repo_path), archive)
    if os.path.exists(archive_abs_path):
        console.print("Installing dependencies ", end=" ", flush=True)
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", archive_abs_path], check=True)
            console.print("[OK]")
        except subprocess.CalledProcessError:
            console.print("[ERROR]")
    else:
        console.print("No dependency file found [OK]")


def remove_garbage(repo_path: str):
    """Remove unnecessary files"""
    console.print("Removing unnecessary files ", end=" ", flush=True)
    try:
        if not os.path.exists(str(repo_path)):
            console.print("[ERROR: Path not found]")
            return
            
        items = os.listdir(repo_path)
        for item in items:
            item_path = os.path.join(repo_path, item)
            if os.path.isfile(item_path):
                os.remove(item_path)
        
        # Remove .git and setup folders if they exist
        for folder in [".git", "setup"]:
            folder_path = os.path.join(repo_path, folder)
            if os.path.exists(folder_path) and os.path.isdir(folder_path):
                shutil.rmtree(folder_path)
        console.print("[OK]")
    except Exception as e:
        console.print(f"[ERROR]: {e}")
        sys.exit(1)


def move_folders(repo_path: str):
    """Move folders to current directory"""
    console.print("Moving repository to current directory ", end=" ", flush=True)
    try:
        if not os.path.exists(str(repo_path)):
            console.print("[ERROR: Path not found]")
            return
            
        items = os.listdir(repo_path)
        for item in items:
            src = os.path.join(repo_path, item)
            dst = os.path.join(os.getcwd(), item)
            if os.path.exists(dst):
                if os.path.isdir(dst):
                    shutil.rmtree(dst)
                else:
                    os.remove(dst)
            shutil.move(src, dst)
        shutil.rmtree(repo_path)
        console.print("[OK]")
    except Exception as e:
        console.print(f"[ERROR]: {e}")
        sys.exit(1)

def update_submodules(repo: git.Repo, verbose: bool = False):
    """Update submodules recursively with optional verbose output"""
    if verbose:
        submodules = repo.submodules
        if not submodules:
            console.print("  No submodules found.")
            return
        
        console.print(f"  Updating {len(submodules)} submodules...")
        for sms in submodules:
            console.print(f"    -> [blue]Submodule:[/blue] {sms.name} ({sms.path})")
            try:
                # Update this specific submodule
                repo.git.submodule('update', '--init', '--recursive', sms.path)
            except Exception as e:
                console.print(f"    [red]Error updating submodule {sms.name}:[/red] {e}")
    else:
        repo.git.submodule('update', '--init', '--recursive')

def git_clone_update(url: str, branch: str = None, token: str = None, repo_path: str = None, verbose: bool = False):
    """Clones or updates a Git repository.
    If there are local changes, it performs a hard reset and pulls.
    """
    url_old = url

    if not repo_path:
        if ".git" in url:
            repo_path = url.split(".git")[0].split("/")[-1]
        else:
            repo_path = url.split("/")[-1]

    if token:
        if "github.com" in url:
            url = url.replace("github.com", f"{token}@github.com")
        elif "gitlab.com" in url:
            url = url.replace("gitlab.com", f"oauth2:{token}@gitlab.com")
        
        if not url.endswith(".git"):
            url += ".git"

    is_update = os.path.exists(str(repo_path)) and os.path.exists(os.path.join(str(repo_path), ".git"))
    
    if is_update:
        message = f"[cyan] Updating {repo_path}... [/cyan]"
    else:
        message = f"[cyan] Cloning {url_old} ({branch if branch else 'default branch'})... [/cyan]"

    if verbose:
        console.print(f"\n[bold blue]Processing {repo_path}[/bold blue]")
        console.print(f"  URL: {url}")
        console.print(f"  Target Branch: {branch if branch else 'Default'}")
        console.print(f"  Is update: {is_update}")

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        task = progress.add_task(description=message, total=None)

        try:
            if is_update:
                repo = git.Repo(repo_path)
                repo.git.update_environment(GIT_TERMINAL_PROMPT="0")
                if verbose: console.print(f"  Resetting {repo_path}...")
                repo.git.reset("--hard")
                if verbose: console.print(f"  Pulling {repo_path}...")
                repo.git.pull()
                
                # Get current branch name for verbose output
                if verbose:
                    try:
                        current_branch = repo.active_branch.name
                        console.print(f"  Active Branch: [green]{current_branch}[/green]")
                    except Exception:
                        console.print("  Active Branch: [yellow]Detached HEAD or unknown[/yellow]")

                if verbose: console.print(f"  Processing submodules...")
                update_submodules(repo, verbose=verbose)
            else:
                if verbose: console.print(f"  Cloning {url} to {repo_path} (recursive)...")
                repo = git.Repo.clone_from(url, repo_path, branch=branch, recursive=True, env={"GIT_TERMINAL_PROMPT": "0"})
                
                # Get current branch name after clone
                if verbose:
                    try:
                        current_branch = repo.active_branch.name
                        console.print(f"  Cloned Branch: [green]{current_branch}[/green]")
                    except Exception:
                        console.print("  Cloned Branch: [yellow]Detached HEAD or unknown[/yellow]")

                if verbose: 
                    console.print(f"  Cloning finished. Processing submodules...")
                    update_submodules(repo, verbose=verbose)

            progress.update(task, description=f"[green]{message} ✔[/green]", completed=1)
            return repo_path

        except Exception as e:
            progress.update(task, description=f"[red]Error in {repo_path} ✖[/red]", completed=1)
            console.print(f"\n[red]Git Error:[/red] {e}")
            sys.exit(1)


def git_update_all(verbose: bool = False):
    """Update all repositories in the current directory"""
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        for carpeta in os.listdir():
            ruta_completa = os.path.join(os.getcwd(), carpeta)
            if os.path.isdir(ruta_completa) and os.path.isdir(os.path.join(ruta_completa, ".git")):
                try:
                    message = f"[cyan] Updating {carpeta}... [/cyan]"
                    task = progress.add_task(description=message, total=None)
                    
                    repo = git.Repo(ruta_completa)
                    repo.git.update_environment(GIT_TERMINAL_PROMPT="0")
                    if verbose: console.print(f"\n[bold blue]Updating {carpeta}[/bold blue]")
                    if verbose: console.print(f"  Pulling {carpeta}...")
                    repo.git.pull()

                    if verbose:
                        try:
                            current_branch = repo.active_branch.name
                            console.print(f"  Active Branch: [green]{current_branch}[/green]")
                        except Exception:
                            console.print("  Active Branch: [yellow]Detached HEAD or unknown[/yellow]")

                    if verbose: console.print(f"  Processing submodules...")
                    update_submodules(repo, verbose=verbose)
                    
                    progress.update(task, description=f"[green]{message} ✔[/green]", completed=1)
                except Exception:
                    progress.update(task, description=f"[red]Error in {carpeta} ✖[/red]", completed=1)

@app.command()
def main(
    url: Annotated[Optional[str], typer.Argument(help="Repository URL")]=None,
    repositories: Annotated[
    Optional[str], typer.Option(help="JSON with repositories to clone"),
    ] = None,
    branch: Annotated[Optional[str], typer.Option(help="Repository branch")] = None,
    requirements : Annotated[
        Optional[bool], typer.Option(help="Do not install dependencies"),
    ] = False,
    # update: Annotated[
    #     Optional[bool], typer.Option(help="Update all repositories"),
    # ] = False,
    # garbage: Annotated[
    #     Optional[bool], typer.Option(help="Do not remove unnecessary files"),
    # ] = True,
    repopath: Annotated[
        Optional[str], typer.Option(help="Repository path"),
    ] = None,
    token: Annotated[
        Optional[str], typer.Option(help="Repository access token"),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Enable verbose output")] = False,
):

    """Utility for cloning Git repositories, removing unnecessary files, and installing dependencies from requirements.txt."""

    # if update:
    #     git_update_all(verbose=verbose)
    #     sys.exit(0)

    if not repositories:
        """Simple cloning of a repository"""
        repo_path_actual = git_clone_update(url=url, branch=branch, token=token, repo_path=repopath, verbose=verbose)

        if requirements:
            install_req(repo_path=repo_path_actual)
        # if garbage:
        #     remove_garbage(repo_path=repo_path_actual)
        # if not repopath:
        #     move_folders(repo_path=repo_path_actual)
    
    if repositories:
        """
        Cloning multiple repositories
        JSON Format:
        [
            {
                "url": "https://github.com/org/repo1",
                "branch": "18.0",
                "repo_path": "repo1",
                "token": "token1"
            },
            {
                "url": "https://github.com/OCA/commission",
                "branch": "18.0",
                "repo_path": "oca/commission"
            }
        ]
        """
        for repo in json.loads(repositories):
            current_branch = branch if branch else repo.get("branch")
            # For multiple repos, we don't strictly require a branch in the JSON if a global one isn't provided, 
            # as it will fall back to the default branch of the repo.
            repo_path = repo.get("repo_path")
            current_token = token if token else repo.get("token")
            git_clone_update(url=repo["url"], branch=current_branch, token=current_token, repo_path=repo_path, verbose=verbose)
        

if __name__ == "__main__":
    app()
