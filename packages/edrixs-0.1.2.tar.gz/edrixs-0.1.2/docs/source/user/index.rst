.. _user:

#################
edrixs User Guide
#################

:Release: |version|
:Date: |today|

.. toctree::
   :maxdepth: 1

   whatisedrixs
   installation
   usedocker
   devcontainer
   quickstart
   basics
   pythontips
   examples
   papers
