.. _basics.rixs:

********
RIXS
********
