.. _basics.ed:

********
ED
********
