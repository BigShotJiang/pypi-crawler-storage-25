.. Packaging Scientific Python documentation master file, created by
   sphinx-quickstart on Thu Jun 28 12:35:56 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

edrixs Documentation
====================

.. toctree::
   :maxdepth: 2

   user/index
   auto_examples/index
   reference/index
   release-history
