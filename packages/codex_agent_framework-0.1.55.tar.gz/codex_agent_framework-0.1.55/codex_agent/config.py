import json
import os
import platform

from modict import modict
from modict.collections_utils import get_nested

from .event import RuntimeStateChangedEvent
from .message import SystemMessage
from .utils import runtime_join, text_content


DEFAULT_SYSTEM_PROMPT_PATH = os.path.join(os.path.dirname(__file__), "prompts", "system_prompt.txt")
DEFAULT_SYSTEM_PROMPT = text_content(DEFAULT_SYSTEM_PROMPT_PATH)


def parse_config_value(value):
    if isinstance(value, bool):
        return value
    if not isinstance(value, str):
        return value

    lowered = value.lower()
    if lowered in ("true", "yes", "on", "1"):
        return True
    if lowered in ("false", "no", "off", "0"):
        return False
    if lowered in ("none", "null"):
        return None
    if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
        return int(value)
    try:
        if any(char in value for char in (".", "e", "E")):
            return float(value)
    except ValueError:
        pass
    if (value.startswith("{") and value.endswith("}")) or (value.startswith("[") and value.endswith("]")):
        return json.loads(value)
    return value


class Config(modict):
    _config = modict.config(enforce_json=True, extra="ignore", validate_default=True)

    def save(self, file_path):
        target = str(file_path)
        if not target:
            raise ValueError(f"No file path configured for {type(self).__name__}")
        parent = os.path.dirname(target)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.dump(target, indent=2, ensure_ascii=False)
        return self

    def set_path(self, path, raw_value):
        path = str(path or "").strip()
        value = parse_config_value(raw_value)
        if not path:
            if not isinstance(value, dict):
                raise ValueError("Root config assignment expects a mapping value")
            self.clear()
            self.update(value)
            return self
        if "." not in path:
            self[path] = value
            return self[path]
        parent_path, _, leaf = path.rpartition(".")
        parent = get_nested(self, parent_path)
        if not isinstance(parent, dict):
            raise TypeError(f"Config path {path!r} does not resolve to a mapping parent")
        parent[leaf] = value
        return get_nested(self, path)

    def get_path(self, path=None, default=None):
        path = str(path or "").strip()
        if not path:
            return self
        return get_nested(self, path, default=default)


class AgentConfig(Config):

    model = "gpt-5.4"
    system = DEFAULT_SYSTEM_PROMPT
    auto_proceed = True
    openai_api_key = None
    validate_openai_api_key = True
    history = None
    name = "Pandora"
    username = "Unknown"
    userage = "Unknown"
    input_token_limit = 200000
    auto_compact = True
    max_input_tokens = 8000
    reasoning = modict.factory(lambda: modict(effort="medium", summary="auto"))
    text = modict.factory(lambda: modict(verbosity="medium"))
    parallel_tool_calls = True
    codex_stream_idle_timeout = 120
    tool_call_timeout = 0
    vision_enabled = True
    max_images = 10
    prune_orphaned_tool_outputs_on_context_build = True
    image_generation_output_format = "png"
    image_generation_size = None
    image_generation_quality = None
    image_generation_background = None
    image_generation_moderation = None
    builtin_plugins = ["files", "environment", "memory", "planner", "scheduler", "context"]
    custom_plugins = None
    exclude_tools = modict.factory(list)
    server_url = "http://127.0.0.1:8765"
    root_dir = modict.factory(lambda: os.path.abspath(os.getcwd()))
    cwd = modict.factory(lambda: os.path.abspath(os.getcwd()))
    workfolder = modict.factory(lambda: runtime_join("workfolder"))

    @modict.computed()
    def runtime_dir(self):
        from . import utils
        return utils.RUNTIME_DIR

    @modict.computed()
    def source_dir(self):
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

    @modict.computed()
    def platform(self):
        return (
            f"{platform.system()} {platform.release()} ({platform.machine()}), "
            f"Python {platform.python_version()}, shell {os.environ.get('SHELL', 'unknown')}"
        )



class PluginConfig(Config):
    _config = modict.config(enforce_json=True, extra="allow", validate_default=True)


def _as_name_set(value):
    if value is None:
        return None
    if isinstance(value, str):
        return {value}
    return {str(item) for item in value}


def _as_modict(value):
    return value if isinstance(value, modict) else modict(value or {})


class ConfigManager:
    def __init__(self, agent):
        self.agent = agent
        self.config = AgentConfig()
        self.configs = modict(agent=self.config)
        self.config_files = modict(agent=self.file)

    @property
    def file(self):
        return runtime_join("agent.config.json")

    def config_file(self, namespace="agent", file=None):
        if file is not None:
            return str(file)
        if namespace == "agent":
            return self.file
        return runtime_join(f"{namespace}_config.json")

    def save(self):
        return self.save_config("agent")

    def save_all(self):
        if self.should_queue_state_command():
            return self.agent.submit("save_config", namespace=None).wait().result
        saved = modict()
        for namespace in list(self.configs):
            saved[namespace] = self.save_config(namespace)
        return saved

    def save_config(self, namespace="agent"):
        if self.should_queue_state_command():
            return self.agent.submit("save_config", namespace=namespace).wait().result
        config = self.get_config(namespace)
        file = self.config_files.get(namespace) or self.config_file(namespace)
        self.config_files[namespace] = file
        if isinstance(config, Config):
            return config.save(file)
        parent = os.path.dirname(file)
        if parent:
            os.makedirs(parent, exist_ok=True)
        config.dump(file, indent=2, ensure_ascii=False)
        return config

    def load(self):
        if os.path.isfile(self.file):
            self.config = AgentConfig.load(self.file)
            self.agent.config = self.config
        self.configs.agent = self.config
        self.config_files.agent = self.file
        return self.config

    def load_config(self, namespace, *, config_class=PluginConfig, file=None, defaults=None):
        namespace = str(namespace)
        file = self.config_file(namespace, file=file)
        if os.path.isfile(file):
            config = config_class.load(file)
        else:
            config = config_class()
        for key, value in _as_modict(defaults).items():
            config.setdefault(key, value)
        self.configs[namespace] = config
        self.config_files[namespace] = file
        return config

    def update(self, config=None, save=True, **kwargs):
        return self.update_config("agent", config=config, save=save, **kwargs)

    def update_config(self, namespace="agent", config=None, save=True, **kwargs):
        if self.should_queue_state_command():
            return self.agent.submit(
                "update_config",
                namespace=namespace,
                config=config,
                save=save,
                kwargs=kwargs,
            ).wait().result
        target = self.get_config(namespace)
        data = modict(config or {})
        data.update(kwargs)
        if data:
            target.update(data)
            if namespace == "agent":
                self.agent.config = target
            if save:
                self.save_config(namespace)
            self.emit_state_changed(
                reason="config_updated",
                namespace="config",
                name=namespace,
                details=data,
            )
        return target

    def get_config(self, namespace="agent"):
        target = self.configs.get(str(namespace))
        if target is None:
            raise KeyError(f"Unknown config namespace: {namespace}")
        return target

    def namespace_path(self, path=None):
        text = str(path or "").strip()
        if not text:
            return None, ""
        namespace, _, remainder = text.partition(".")
        if namespace not in self.configs:
            raise KeyError(f"Unknown config namespace: {namespace}")
        return namespace, remainder

    def get_path(self, path=None, default=None):
        if not path:
            return modict({namespace: config for namespace, config in self.configs.items()})
        namespace, remainder = self.namespace_path(path)
        target = self.get_config(namespace)
        return target.get_path(remainder, default=default) if isinstance(target, Config) else get_nested(target, remainder, default=default)

    def set_path(self, path, raw_value, *, save=False):
        namespace, remainder = self.namespace_path(path)
        target = self.get_config(namespace)
        if isinstance(target, Config):
            result = target.set_path(remainder, raw_value)
        else:
            parsed = parse_config_value(raw_value)
            if not remainder:
                if not isinstance(parsed, dict):
                    raise ValueError("Root config assignment expects a mapping value")
                target.clear()
                target.update(parsed)
                result = target
            else:
                parent_path, _, leaf = remainder.rpartition(".")
                parent = target if not parent_path else get_nested(target, parent_path)
                if not isinstance(parent, dict):
                    raise TypeError(f"Config path {path!r} does not resolve to a mapping parent")
                parent[leaf] = parsed
                result = get_nested(target, remainder)
        if namespace == "agent":
            self.agent.config = self.config
        if save:
            self.save_config(namespace)
        self.emit_state_changed(
            reason="config_updated",
            namespace="config",
            name=namespace,
            details=modict(path=path, value=self.get_path(path)),
        )
        return result

    def export_tree(self):
        return modict({
            namespace: config
            for namespace, config in self.configs.items()
            if namespace == "agent" or bool(config)
        })

    def emit_state_changed(self, **data):
        if hasattr(self.agent, "events"):
            self.agent.emit(RuntimeStateChangedEvent, **data)

    def has_openai_api_key(self):
        return bool(self.config.get("openai_api_key") or os.getenv("OPENAI_API_KEY"))

    def apply_openai_capability_defaults(self):
        """Normalize legacy agent config keys to SDK-shaped request fields."""
        reasoning = self.config.get("reasoning")
        if not isinstance(reasoning, dict):
            reasoning = modict()
        else:
            reasoning = modict(reasoning)
        if "reasoning_effort" in self.config and "effort" not in reasoning:
            reasoning.effort = self.config.get("reasoning_effort")
        if reasoning:
            self.config.reasoning = reasoning
        self.config.pop("reasoning_effort", None)

        text = self.config.get("text")
        if not isinstance(text, dict):
            text = modict()
        else:
            text = modict(text)
        if "verbosity" in self.config and "verbosity" not in text:
            text.verbosity = self.config.get("verbosity")
        if text:
            self.config.text = text
        self.config.pop("verbosity", None)

        # Voice configuration is plugin-scoped; consume old top-level aliases so
        # existing constructors do not leave stale agent-level config behind.
        for key in ("voice_enabled", "voice_model", "voice", "voice_instructions", "voice_buffer_size"):
            self.config.pop(key, None)
        return self.config

    def apply_config_defaults(
        self,
        namespace,
        *,
        file=None,
        config_class=PluginConfig,
        defaults=None,
        legacy_agent_aliases=None,
        legacy_agent_sections=None,
    ):
        config = self.load_config(namespace, config_class=config_class, file=file, defaults=defaults)
        self.agent.config = self.config
        return config

    def system_message(self):
        return SystemMessage(content=self.system_prompt())

    def system_prompt(self):
        if not self.config.get("system"):
            prompt = DEFAULT_SYSTEM_PROMPT
        elif os.path.isfile(self.config.system):
            prompt = text_content(self.config.system)
        elif isinstance(self.config.system, str):
            prompt = self.config.system
        else:
            raise ValueError(
                "Invalid system message configuration. "
                f"Expected path or string, got {type(self.config.system)}"
            )
        sections = [str(prompt or "").strip()]
        plugins_manager = getattr(self.agent, "plugins_manager", None)
        if plugins_manager is not None:
            sections.extend(plugins_manager.get_system_prompt_sections())
        return "\n\n".join(section for section in sections if section)

    def builtin_plugin_names(self):
        return _as_name_set(self.config.get("builtin_plugins"))

    def builtin_plugin_enabled(self, name):
        names = self.builtin_plugin_names()
        if names is None:
            return True
        return str(name) in names

    def custom_plugin_names(self):
        return _as_name_set(self.config.get("custom_plugins"))

    def custom_plugin_enabled(self, name):
        names = self.custom_plugin_names()
        if names is None:
            return True
        return str(name) in names

    def should_queue_state_command(self):
        return (
            hasattr(self.agent, "mainloop_manager")
            and self.agent.mainloop_manager.should_queue_state_command()
        )
