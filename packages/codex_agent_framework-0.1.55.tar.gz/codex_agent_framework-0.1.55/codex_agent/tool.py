import fnmatch
import inspect
import json
from contextvars import ContextVar
from typing import get_args, get_origin, Literal, Union, List

from modict import modict

from .event import RuntimeStateChangedEvent
from .message import DeveloperMessage

TOOL_MARKER = "__codex_agent_tool__"
_current_agent = ContextVar("codex_agent_current_agent", default=None)
_current_call_id = ContextVar("codex_agent_current_call_id", default=None)


def tool(func=None, **options):
    """Mark a function as an agent tool for automatic discovery."""
    if func is None:
        def decorator(f):
            return tool(f, **options)
        return decorator

    setattr(func, TOOL_MARKER, modict(options))
    return func


def tool_options(func):
    options = getattr(func, TOOL_MARKER, None)
    if options is not None:
        return options
    return getattr(getattr(func, "__func__", None), TOOL_MARKER, None)


def get_agent():
    agent = _current_agent.get()
    if agent is None:
        raise RuntimeError("No current agent is available outside an agent tool call.")
    return agent


def get_current_call_id():
    call_id = _current_call_id.get()
    if call_id is None:
        raise RuntimeError("No current call_id is available outside an agent tool call.")
    return call_id


def set_current_agent(agent):
    return _current_agent.set(agent)


def reset_current_agent(token):
    _current_agent.reset(token)


def set_current_call_id(call_id):
    return _current_call_id.set(call_id)


def reset_current_call_id(token):
    _current_call_id.reset(token)


class ServerTool(modict):
    """Responses API server-side tool without a local Python handler."""

    type = None

    def to_response_tool(self):
        return {key: value for key, value in self.items() if value is not None}


class WebSearchTool(ServerTool):
    type = "web_search"


class Tool(modict):
    """Local tool callable exposed to the model."""

    _config = modict.config(require_all="never")

    name = ''
    type = 'tool'
    tool_type = 'function'
    description = ''
    parameters = modict.factory(modict)
    required = modict.factory(list)
    format: dict

    @classmethod
    def from_callable(
        cls,
        obj,
        name=None,
        description=None,
        parameters=None,
        required=None,
        tool_type=None,
        format=None,
    ):
        tool = cls()
        tool.set_attr("obj", obj)
        tool.name = name or getattr(obj, '__name__', None) or obj.__class__.__name__
        tool.update(tool.infer_payload())
        tool.update(tool.parse_doc())
        if description:
            tool.description = description
        if parameters:
            tool.parameters = parameters
        if required:
            tool.required = required
        if format:
            tool.format = format
        tool.pop('mode', None)
        tool.tool_type = tool_type or tool.get('tool_type') or 'function'
        tool.type = 'tool'
        return tool

    def __call__(self, *args, **kwargs):
        obj = self.get_attr("obj", None)
        if obj is None:
            raise TypeError(f"Tool {self.name!r} has no bound callable")
        agent = self.get_attr("agent", None)
        token = set_current_agent(agent) if agent is not None and _current_agent.get() is None else None
        try:
            return obj(*args, **kwargs)
        finally:
            if token is not None:
                reset_current_agent(token)

    def infer_payload(self):
        obj = self.get_attr("obj", None)
        if obj is None:
            return modict()
        try:
            signature = inspect.signature(obj)
        except (TypeError, ValueError):
            return modict()

        parameters = modict()
        required = []
        for name, parameter in signature.parameters.items():
            if name in ("self", "cls"):
                continue
            if parameter.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                continue

            schema = self.annotation_to_schema(parameter.annotation)
            if parameter.default is inspect.Parameter.empty:
                required.append(name)
            else:
                schema["default"] = parameter.default
            parameters[name] = schema

        return modict(parameters=parameters, required=required)

    def annotation_to_schema(self, annotation):
        if annotation is inspect.Parameter.empty:
            return {"type": "string"}

        origin = get_origin(annotation)
        args = get_args(annotation)

        if origin is Literal:
            values = list(args)
            schema = {"enum": values}
            if values:
                schema["type"] = self.json_type(type(values[0]))
            return schema

        if origin in (list, tuple, set):
            item_type = args[0] if args else str
            return {
                "type": "array",
                "items": self.annotation_to_schema(item_type),
            }

        if origin is dict:
            return {"type": "object"}

        if origin is Union:
            non_null_args = [arg for arg in args if arg is not type(None)]
            if len(non_null_args) == 1:
                schema = self.annotation_to_schema(non_null_args[0])
                schema["nullable"] = True
                return schema
            return {"anyOf": [self.annotation_to_schema(arg) for arg in non_null_args]}

        return {"type": self.json_type(annotation)}

    def json_type(self, python_type):
        return {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            dict: "object",
            list: "array",
            tuple: "array",
            set: "array",
        }.get(python_type, "string")

    def parse_doc(self):
        """Parses the YAML docstring of the tool's function to extract metadata.

        Returns:
            modict: Schema containing description, parameters, and required fields.
        """
        import yaml
        from textwrap import dedent

        obj = self.get_attr("obj", None)
        doc = getattr(obj, "__doc__", None)
        if not doc:
            return modict()

        doc_str = dedent(doc).strip().strip('"""').strip("'''").strip()

        try:
            schema = yaml.safe_load(doc_str)
            if not isinstance(schema, dict):
                return modict(description=doc_str)
        except Exception:
            return modict(description=doc_str)

        return modict(schema)

    def to_response_tool(self):
        """Converts the Tool object into a Responses API tool schema."""
        tool = dict(self)
        tool["type"] = tool.pop("tool_type", "function")
        tool["description"] = tool.get("description") or "No description provided"

        if tool["type"] == "custom":
            tool.pop("parameters", None)
            tool.pop("required", None)
            return tool

        properties = {
            name: dict(param) if isinstance(param, dict) else param
            for name, param in tool.pop("parameters", {}).items()
        }
        tool["parameters"] = dict(
            type="object",
            properties=properties,
            required=tool.pop("required", []),
        )
        tool.pop("format", None)
        return tool

    def to_developer_message(self):
        """Convert this tool into a developer message for parsed-tool guidance."""
        schema = json.dumps(self.to_response_tool(), indent=2, ensure_ascii=False)
        return DeveloperMessage(content=f"Tool: {self.name}\nSchema:\n{schema}")


class ToolsManager:
    def __init__(self, agent):
        self.agent = agent
        self.tools = modict()
        self.owners = modict()

    def init_server_tools(self):
        return None

    def add_from_module(self, module, filter=None, owner=None):
        for name, obj in module.__dict__.items():
            if filter is not None and not filter(name, obj):
                continue
            self.add_object(obj, owner=owner)

    def add_from_object(self, obj, owner=None):
        for _, member in inspect.getmembers(obj):
            self.add_object(member, owner=owner)

    def add_object(self, obj, name=None, canonical_name=None, owner=None):
        if isinstance(obj, ServerTool):
            self.add_server_tool(obj, owner=owner)
            return
        options = tool_options(obj)
        if options is not None:
            options = modict(options)
            if name is not None:
                options.name = name
            self.add(obj, canonical_name=canonical_name, owner=owner, **options)

    def add(
        self,
        func=None,
        name=None,
        description=None,
        parameters=None,
        required=None,
        tool_type=None,
        format=None,
        canonical_name=None,
        owner=None,
    ):
        if func is None:
            def decorator(f):
                return self.add(
                    f,
                    name=name,
                    description=description,
                    parameters=parameters,
                    required=required,
                    tool_type=tool_type,
                    format=format,
                    canonical_name=canonical_name,
                    owner=owner,
                )
            return decorator

        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit(
                "add_tool",
                func=func,
                name=name,
                description=description,
                parameters=parameters,
                required=required,
                tool_type=tool_type,
                format=format,
                owner=owner,
            ).wait().result

        tool = Tool.from_callable(
            func,
            name,
            description,
            parameters,
            required,
            tool_type=tool_type,
            format=format,
        )
        tool.set_attr("agent", self.agent)
        if canonical_name:
            tool.set_attr("canonical_name", canonical_name)
        self.tools[tool.name] = tool
        if owner is not None:
            self.owners[tool.name] = owner
        else:
            self.owners.pop(tool.name, None)
        self.agent.emit(
            RuntimeStateChangedEvent,
            reason="tool_added",
            namespace="tools",
            name=tool.name,
            owner=owner or "",
            details=tool,
        )
        return func

    def exclude_tool_specs(self):
        return [str(spec) for spec in (self.agent.config.get("exclude_tools") or [])]

    def tool_match_names(self, tool):
        names = []
        public_name = tool.get("name") or tool.get("type")
        if public_name:
            names.append(public_name)
        canonical_name = tool.get_attr("canonical_name", None)
        if canonical_name:
            names.append(canonical_name)
        return names

    def tool_matches_spec(self, tool, spec):
        return any(fnmatch.fnmatchcase(name, spec) for name in self.tool_match_names(tool))

    def apply_config_exclusions(self):
        exclude = self.exclude_tool_specs()
        if not exclude:
            return self.tools
        for name, tool in list(self.tools.items()):
            if self.tool_is_excluded(tool, exclude):
                self.tools.pop(name, None)
                self.owners.pop(name, None)
        return self.tools

    def tool_is_excluded(self, tool, exclude_specs=None):
        exclude_specs = exclude_specs if exclude_specs is not None else self.exclude_tool_specs()
        return any(self.tool_matches_spec(tool, spec) for spec in exclude_specs)

    def get_tools(self, filter=None) -> List[Tool]:
        filter = filter or (lambda tool: True)
        return [tool for tool in self.tools.values() if filter(tool)]

    def add_server_tool(self, tool=None, owner=None, **kwargs):
        tool = tool or ServerTool(**kwargs)
        if isinstance(tool, type) and issubclass(tool, ServerTool):
            tool = tool(**kwargs)
        elif isinstance(tool, str):
            tool = ServerTool(type=tool, **kwargs)
        elif isinstance(tool, dict):
            tool = ServerTool(**tool)
        self.tools[tool.type] = tool
        if owner is not None:
            self.owners[tool.type] = owner
        else:
            self.owners.pop(tool.type, None)
        self.agent.emit(
            RuntimeStateChangedEvent,
            reason="tool_added",
            namespace="tools",
            name=tool.type,
            owner=owner or "",
            details=tool,
        )
        return tool

    def remove_by_owner(self, owner):
        removed = modict()
        for name, registered_owner in list(self.owners.items()):
            if registered_owner == owner:
                removed[name] = self.tools.pop(name, None)
                self.owners.pop(name, None)
        if removed:
            self.agent.emit(
                RuntimeStateChangedEvent,
                reason="tools_removed",
                namespace="tools",
                owner=owner or "",
                details=removed,
            )
        return removed

    def get_server_tools(self):
        return self.get_tools(filter=lambda tool: tool.type != "tool")

    def server_tool_for_item(self, item):
        item_type = item.get("type") if item else None
        if not item_type:
            return None
        tool_name = item_type.removesuffix("_call")
        return self.tools.get(tool_name) or self.tools.get(item_type)

    def get_response_tools(self):
        return [tool.to_response_tool() for tool in self.get_tools()]
