import threading
import time
from types import SimpleNamespace

import pytest
from modict import modict

from codex_agent.ai import AIClient, AIClientError, MAX_EMBEDDING_INPUT_TOKENS
from codex_agent.message import DeveloperMessage, SystemMessage
from codex_agent.utils import token_count


class FakeEmbeddings:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        count = len(kwargs["input"]) if isinstance(kwargs.get("input"), list) else 1
        return SimpleNamespace(data=[
            SimpleNamespace(embedding=[float(index + 1), 0.0])
            for index in range(count)
        ])


class FakeOpenAIClient:
    def __init__(self):
        self.embeddings = FakeEmbeddings()


class FakeTranscriptions:
    def __init__(self, result="transcribed text"):
        self.calls = []
        self.result = result

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return self.result


class FakeAudio:
    def __init__(self, result="transcribed text"):
        self.transcriptions = FakeTranscriptions(result=result)


class FakeInputTokens:
    def __init__(self):
        self.calls = []

    def count(self, **payload):
        self.calls.append(payload)
        return SimpleNamespace(input_tokens=123)


class FakeResponses:
    def __init__(self):
        self.input_tokens = FakeInputTokens()


class FakeOpenAIClientWithResponses(FakeOpenAIClient):
    def __init__(self):
        super().__init__()
        self.responses = FakeResponses()


class FakeCodexClient:
    def __init__(self):
        self.aborted = False
        self.embeddings = FakeEmbeddings()
        self.audio = FakeAudio()

    def abort(self):
        self.aborted = True


class FakeMainLoopManager:
    def touch_activity(self, phase=None, detail=None):
        return self


class FakeAgent:
    def __init__(self, **config):
        self.config = modict(config)
        self.mainloop_manager = FakeMainLoopManager()


class FakeModels:
    def __init__(self):
        self.calls = 0

    def list(self):
        self.calls += 1
        return []


class FakeOpenAIValidationClient:
    instances = []

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.models = FakeModels()
        self.__class__.instances.append(self)


def test_openai_api_key_validation_is_cached_by_key(monkeypatch):
    AIClient._api_key_validation_cache.clear()
    FakeOpenAIValidationClient.instances = []
    monkeypatch.setattr("codex_agent.ai.OpenAI", FakeOpenAIValidationClient)

    first = AIClient(FakeAgent(openai_api_key="sk-test"))
    second = AIClient(FakeAgent(openai_api_key="sk-test"))

    assert first.client is FakeOpenAIValidationClient.instances[0]
    assert second.client is FakeOpenAIValidationClient.instances[1]
    assert FakeOpenAIValidationClient.instances[0].models.calls == 1
    assert FakeOpenAIValidationClient.instances[1].models.calls == 0


def test_openai_api_key_validation_can_be_disabled(monkeypatch):
    AIClient._api_key_validation_cache.clear()
    FakeOpenAIValidationClient.instances = []
    monkeypatch.setattr("codex_agent.ai.OpenAI", FakeOpenAIValidationClient)

    ai = AIClient(FakeAgent(openai_api_key="sk-test", validate_openai_api_key=False))

    assert ai.client is FakeOpenAIValidationClient.instances[0]
    assert FakeOpenAIValidationClient.instances[0].models.calls == 0


def test_embed_content_truncates_input_to_embedding_token_budget():
    ai = AIClient(agent=None)
    ai._codex_client = FakeCodexClient()
    long_content = "token " * (MAX_EMBEDDING_INPUT_TOKENS + 1000)

    ai.embed_content(long_content)

    embedded_input = ai._codex_client.embeddings.calls[0]["input"]
    assert token_count(embedded_input) <= MAX_EMBEDDING_INPUT_TOKENS


def test_embed_contents_truncates_each_input_to_embedding_token_budget():
    ai = AIClient(agent=None)
    ai._codex_client = FakeCodexClient()
    long_content = "token " * (MAX_EMBEDDING_INPUT_TOKENS + 1000)

    ai.embed_contents([long_content])

    embedded_input = ai._codex_client.embeddings.calls[0]["input"][0]
    assert token_count(embedded_input) <= MAX_EMBEDDING_INPUT_TOKENS


def test_embed_messages_batches_request_and_assigns_embeddings():
    ai = AIClient(agent=None)
    ai._codex_client = FakeCodexClient()
    first = DeveloperMessage(content="first")
    second = DeveloperMessage(content="second")

    embeddings = ai.embed_messages([first, second])

    assert len(ai._codex_client.embeddings.calls) == 1
    assert ai._codex_client.embeddings.calls[0]["input"] == ["first", "second"]
    assert embeddings == [first.embedding, second.embedding]
    assert first.embedding == [1.0, 0.0]
    assert second.embedding == [1.0, 0.0]


def test_embed_messages_skips_empty_content_without_api_error():
    ai = AIClient(agent=None)
    ai._codex_client = FakeCodexClient()
    empty = DeveloperMessage(content="")
    blank = DeveloperMessage(content="   ")
    filled = DeveloperMessage(content=" filled ")

    embeddings = ai.embed_messages([empty, blank, filled], dimensions=2)

    assert len(ai._codex_client.embeddings.calls) == 1
    assert ai._codex_client.embeddings.calls[0]["input"] == ["filled"]
    assert empty.embedding == [0.0, 0.0]
    assert blank.embedding == [0.0, 0.0]
    assert filled.embedding == [1.0, 0.0]
    assert embeddings == [empty.embedding, blank.embedding, filled.embedding]


def test_embed_message_assigns_zero_embedding_for_empty_content():
    ai = AIClient(agent=None)
    ai._codex_client = FakeCodexClient()
    message = DeveloperMessage(content="")

    embedding = ai.embed_message(message, dimensions=2)

    assert embedding == [0.0, 0.0]
    assert message.embedding == [0.0, 0.0]
    assert ai._codex_client.embeddings.calls == []


def test_count_input_tokens_uses_responses_input_tokens_endpoint():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClientWithResponses()

    count = ai.count_input_tokens(model="gpt-5", input="hello", tools=[{"type": "web_search_preview"}])

    assert count == 123
    assert ai._client.responses.input_tokens.calls == [{
        "model": "gpt-5",
        "input": "hello",
        "tools": [{"type": "web_search_preview"}],
    }]


def test_audio_to_text_uses_codex_backend_transcriptions():
    ai = AIClient(agent=None)
    ai._codex_client = FakeCodexClient()

    text = ai.audio_to_text(b"fake-audio", language="fr", prompt="meeting notes")

    assert text == "transcribed text"
    assert ai._codex_client.audio.transcriptions.calls == [{
        "model": "gpt-4o-mini-transcribe",
        "file": ai._codex_client.audio.transcriptions.calls[0]["file"],
        "response_format": "text",
        "temperature": 0.0,
        "language": "fr",
        "prompt": "meeting notes",
    }]
    uploaded = ai._codex_client.audio.transcriptions.calls[0]["file"]
    assert uploaded.getvalue() == b"fake-audio"
    assert uploaded.name == "audio.mp3"


def test_codex_backend_params_move_leading_system_messages_to_instructions():
    ai = AIClient(agent=None)

    params = ai._to_codex_response_params({
        "messages": [
            SystemMessage(content="Base rules."),
            SystemMessage(content="Extra rules."),
            DeveloperMessage(content="visible context"),
            SystemMessage(content="ignored late rules."),
        ],
        "model": "gpt-5.4",
    })

    assert params["instructions"] == "Base rules.\n\nExtra rules."
    assert params["input"] == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "visible context"}],
    }]


def test_codex_stream_idle_timeout_aborts_silent_backend_stream():
    agent = FakeAgent(codex_stream_idle_timeout=0.01)
    ai = AIClient(agent=agent)
    ai._codex_client = FakeCodexClient()
    release = threading.Event()

    def silent_stream():
        release.wait(timeout=1)
        yield "late"

    started_at = time.monotonic()
    with pytest.raises(AIClientError, match="produced no events"):
        list(ai._iter_response_events(silent_stream()))

    assert time.monotonic() - started_at < 0.5
    assert ai._codex_client.aborted is True
    release.set()
