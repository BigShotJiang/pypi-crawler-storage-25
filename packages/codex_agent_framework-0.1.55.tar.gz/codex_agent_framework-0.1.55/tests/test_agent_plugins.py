import json

import pytest

import codex_agent.utils as utils
from modict import modict
from codex_agent import Agent, AssistantTurnEndEvent
from codex_agent.message import DeveloperMessage, ToolResultWrapper


def agent_result(agent, prompt):
    return agent(prompt).result


def test_runtime_state_change_events_exported():
    import codex_agent

    assert codex_agent.RuntimeStateChangedEvent().type == "runtime_state_changed_event"
    assert codex_agent.RealtimeSessionRefreshEvent().type == "realtime_session_refresh_event"


def test_agent_loads_memory_plugin_with_configured_openai_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    agent = Agent(session="new", openai_api_key="sk-test", builtin_plugins=["memory"])

    assert "memory" in agent.plugins
    assert "memory_add" in agent.tools
    assert "retrieved_memory" in agent.providers


def test_agent_loads_minimal_builtin_plugins_by_default():
    agent = Agent(session="new", openai_api_key="sk-test")

    assert set(agent.plugins.keys()) == {"context", "environment", "files", "memory", "planner", "scheduler"}
    assert "read" in agent.tools
    assert "write" in agent.tools
    assert "edit" in agent.tools
    assert "environment_list_plugins" in agent.tools
    assert "memory_add" in agent.tools
    assert "planner_create" in agent.tools
    assert "scheduler_schedule" in agent.tools
    assert "context_status" in agent.tools
    assert "bash" not in agent.tools
    assert "python" not in agent.tools
    assert "view" not in agent.tools
    assert "browser_open" not in agent.tools


def test_agent_config_can_exclude_tools_by_canonical_plugin_name():
    agent = Agent(
        session="new",
        builtin_plugins=["files"],
        exclude_tools=["files.write", "files.edit"],
    )

    assert "read" in agent.tools
    assert "write" not in agent.tools
    assert "edit" not in agent.tools


def test_interface_plugin_exposes_tui_status_provider(monkeypatch):
    import codex_agent.builtin_plugins.interface as interface_plugin
    from modict import modict

    monkeypatch.setattr(interface_plugin, "current_tui", lambda: None)
    agent = Agent(session="new", builtin_plugins=["interface"], custom_plugins=[])

    assert set(agent.plugins) == {"interface"}
    assert "open_tui" in agent.tools
    assert "close_tui" in agent.tools
    assert "tui_status" in agent.providers
    assert agent.providers.tui_status() == "TUI status: closed."

    monkeypatch.setattr(
        interface_plugin,
        "current_tui",
        lambda: modict(pid=1234, base_url="http://127.0.0.1:8765", timestamp="2026-05-13 20:00:00"),
    )

    status = agent.providers.tui_status()
    assert "TUI status: open." in status
    assert "pid=1234" in status
    assert "base_url=http://127.0.0.1:8765" in status
    assert "timestamp=2026-05-13 20:00:00" in status


def test_agent_can_disable_all_builtin_plugins():
    agent = Agent(session="new", openai_api_key="sk-test", builtin_plugins=[])

    assert agent.plugins == {}
    assert "browser_state" not in agent.providers
    assert "current_todos" not in agent.providers
    assert "desktop_run_commands" not in agent.tools
    assert "memory_add" not in agent.tools
    assert "planner_create" not in agent.tools
    assert "scheduler_schedule" not in agent.tools
    assert "read" not in agent.tools
    assert "view" not in agent.tools
    assert "bash" not in agent.tools
    assert "python" not in agent.tools
    assert "open_tui" not in agent.tools
    assert "date_and_time" not in agent.providers


def test_agent_can_select_builtin_plugins_by_name():
    agent = Agent(
        session="new",
        openai_api_key="sk-test",
        builtin_plugins=["files", "content", "bash", "python", "environment", "planner", "scheduler"],
    )

    assert set(agent.plugins.keys()) == {"files", "content", "bash", "python", "environment", "planner", "scheduler"}
    assert "read" in agent.tools
    assert "write" in agent.tools
    assert "edit" in agent.tools
    assert "view" in agent.tools
    assert "observe" in agent.tools
    assert "show" in agent.tools
    assert "bash" in agent.tools
    assert "python" in agent.tools
    assert "date_and_time" in agent.providers
    assert "cwd" in agent.providers
    assert "planner_create" in agent.tools
    assert "scheduler_schedule" in agent.tools
    assert "browser_state" not in agent.providers
    assert "desktop_run_commands" not in agent.tools
    assert "memory_add" not in agent.tools
    assert "open_tui" not in agent.tools


def test_agent_add_plugin_registers_plugin_members_from_root_api():
    from codex_agent import Plugin, provider, tool

    class ProjectPlugin(Plugin):
        name = "project"

        def __init__(self, agent):
            super().__init__(agent)
            self.count = 0

        @tool
        def bump(self, amount: int = 1):
            """
            description: Increment the project counter.
            parameters:
              amount:
                type: integer
                description: Amount to add to the counter.
                default: 1
            required: []
            """
            self.count += amount
            return self.count

        @provider
        def project_context(self):
            return f"count={self.count}"

    agent = Agent(session="new")
    plugin = agent.add_plugin(ProjectPlugin(agent))

    assert plugin is agent.plugins.project
    assert agent.tools.project_bump(amount=2) == 2
    assert agent.providers.project_context() == "count=2"
    assert agent.tools.project_bump.to_response_tool()["description"] == "Increment the project counter."
    assert agent.tools.project_bump.to_response_tool()["parameters"] == {
        "type": "object",
        "properties": {
            "amount": {
                "type": "integer",
                "description": "Amount to add to the counter.",
                "default": 1,
            },
        },
        "required": [],
    }


def test_agent_instantiates_stateful_builtin_plugin_classes():
    import types
    from codex_agent import Plugin, command, event_handler, hook_handler, provider, stream_processor, tool

    module = types.ModuleType("codex_agent.builtin_plugins.fake_stateful")

    class StatefulPlugin(Plugin):
        name = "stateful"

        def __init__(self, agent):
            super().__init__(agent)
            self.counter = 0
            self.events = []
            self.hooks = []

        @tool
        def stateful_tool(self):
            self.counter += 1
            return f"{self.agent.config.name}:{self.counter}"

        @tool
        def ping(self):
            return "pong"

        @provider
        def stateful_context(self):
            return f"counter={self.counter}"

        @command
        def stateful_command(self):
            self.counter += 10
            return self.counter

        @event_handler(AssistantTurnEndEvent)
        def stateful_event_handler(self, event):
            self.events.append((event.type, event.reason))

        @hook_handler("stateful.sample")
        def stateful_hook_handler(self, context):
            self.hooks.append(context.payload.value)
            context.payload.value = "handled"

        @stream_processor("content")
        def stateful_stream_processor(self, stream):
            for chunk in stream:
                yield chunk.upper()

        def get_system_prompt_sections(self):
            return [f"# Stateful Plugin\ncounter={self.counter}"]

    StatefulPlugin.__module__ = module.__name__
    module.StatefulPlugin = StatefulPlugin

    agent = Agent(session="new", name="PluginAgent")
    agent.plugins_manager.add_from_module(module)

    plugin = agent.plugins.stateful
    assert isinstance(plugin, StatefulPlugin)
    assert [method.__name__ for method in plugin.get_tools()] == ["ping", "stateful_tool"]
    assert [method.__name__ for method in plugin.get_providers()] == ["stateful_context"]
    assert [method.__name__ for method in plugin.get_commands()] == ["stateful_command"]
    assert plugin.get_event_handlers() == [(AssistantTurnEndEvent, plugin.stateful_event_handler)]
    assert plugin.get_hook_handlers() == [("stateful.sample", plugin.stateful_hook_handler)]
    assert plugin.get_stream_processors() == [("content", plugin.stateful_stream_processor)]
    assert plugin.get_system_prompt_sections() == ["# Stateful Plugin\ncounter=0"]
    assert "# Stateful Plugin\ncounter=0" in agent.config_manager.system_message().content
    assert "ping" not in agent.tools
    assert agent.tools.stateful_ping() == "pong"
    assert agent.tools.stateful_tool() == "PluginAgent:1"
    assert agent.providers.stateful_context() == "counter=1"
    assert agent.commands.stateful_command() == 11
    assert plugin.counter == 11
    agent.emit(AssistantTurnEndEvent, prompt=None, reason="completed")
    hook_context = agent.run_hook("stateful.sample", value="original")
    assert plugin.events == [("assistant_turn_end_event", "completed")]
    assert plugin.hooks == ["original"]
    assert hook_context.payload.value == "handled"
    assert plugin.stateful_stream_processor in agent.get_stream_processors("content")
    assert list(plugin.stateful_stream_processor(iter(["ok"]))) == ["OK"]


def make_hotplug_module(module_name="codex_agent.builtin_plugins.hotplug_fake", ping_value="pong"):
    import types
    from codex_agent import Plugin, command, event_handler, hook_handler, provider, stream_processor, tool

    module = types.ModuleType(module_name)

    class HotplugPlugin(Plugin):
        name = "hotplug"
        system_prompt = "# Hotplug Plugin"

        def __init__(self, agent):
            super().__init__(agent)
            self.events = []
            self.hooks = []
            self.stopped = False

        def stop(self, timeout=None):
            self.stopped = True
            return self

        @tool
        def ping(self):
            return ping_value

        @provider
        def hotplug_context(self):
            return "hotplug context"

        @command
        def hotplug_command(self):
            return "commanded"

        @event_handler(AssistantTurnEndEvent)
        def on_turn_end(self, event):
            self.events.append(event.reason)

        @hook_handler("hotplug.sample")
        def on_hook(self, context):
            self.hooks.append(context.payload.value)

        @stream_processor("content")
        def process_content(self, stream):
            for chunk in stream:
                yield f"hot:{chunk}"

    HotplugPlugin.__module__ = module.__name__
    module.HotplugPlugin = HotplugPlugin
    return module, HotplugPlugin


def test_agent_unload_plugin_removes_all_registered_surfaces():
    module, _ = make_hotplug_module()
    agent = Agent(session="new")
    agent.plugins_manager.add_from_module(module)
    plugin = agent.plugins.hotplug

    assert agent.tools.hotplug_ping() == "pong"
    assert agent.providers.hotplug_context() == "hotplug context"
    assert agent.commands.hotplug_command() == "commanded"
    assert "# Hotplug Plugin" in agent.config_manager.system_message().content
    agent.emit(AssistantTurnEndEvent, prompt=None, reason="before")
    agent.run_hook("hotplug.sample", value="before")
    assert plugin.events == ["before"]
    assert plugin.hooks == ["before"]
    assert plugin.process_content in agent.get_stream_processors("content")

    result = agent.unload_plugin("hotplug")

    assert result.plugin is plugin
    assert plugin.stopped is True
    assert "hotplug" not in agent.plugins
    assert "hotplug_ping" not in agent.tools
    assert "hotplug_context" not in agent.providers
    assert "hotplug_command" not in agent.commands
    assert "# Hotplug Plugin" not in agent.config_manager.system_message().content
    assert plugin.process_content not in agent.get_stream_processors("content")
    agent.emit(AssistantTurnEndEvent, prompt=None, reason="after")
    agent.run_hook("hotplug.sample", value="after")
    assert plugin.events == ["before"]
    assert plugin.hooks == ["before"]


def test_agent_reload_plugin_replaces_registered_surfaces():
    module, _ = make_hotplug_module(ping_value="first")
    agent = Agent(session="new")
    agent.plugins_manager.add_from_module(module)
    first = agent.plugins.hotplug
    assert agent.tools.hotplug_ping() == "first"

    _, SecondPlugin = make_hotplug_module("codex_agent.builtin_plugins.hotplug_fake_second", ping_value="second")
    replacement = agent.add_plugin(SecondPlugin(agent))

    assert first.stopped is True
    assert replacement is agent.plugins.hotplug
    assert agent.tools.hotplug_ping() == "second"
    assert agent.providers.hotplug_context() == "hotplug context"
    assert first.process_content not in agent.get_stream_processors("content")
    assert replacement.process_content in agent.get_stream_processors("content")

    reloaded = agent.reload_plugin("hotplug")
    assert replacement.stopped is True
    assert reloaded is agent.plugins.hotplug
    assert reloaded is not replacement
    assert agent.tools.hotplug_ping() == "second"


def test_context_plugin_exposes_monitor_control_tools_and_wrapper_pruning():
    agent = Agent(session="new", input_token_limit=10_000)
    persistent = DeveloperMessage(content="persistent")
    wrapper = ToolResultWrapper(content="verbose output", turns_left=2, tool_name="demo", call_id="call_demo")
    second_wrapper = ToolResultWrapper(content="other output", turns_left=2, tool_name="demo", call_id="call_demo_2")
    temporary = DeveloperMessage(content="temporary non-wrapper", turns_left=2)
    agent.session.messages.extend([persistent, wrapper, second_wrapper, temporary])

    assert "context_status_monitor" in agent.providers
    assert "context_status" in agent.tools
    assert "context_decay" not in agent.tools
    assert "context_compact" in agent.tools
    assert "context_list_wrappers" in agent.tools
    assert "context_prune_wrappers" in agent.tools
    assert "environment_context_status" not in agent.tools
    assert "environment_decay_context" not in agent.tools
    assert "environment_compact_context" not in agent.tools

    status = agent.tools.context_status()
    assert status.input_token_limit == 10_000
    assert status.temporary_session_messages >= 3
    monitor = agent.providers.context_status_monitor()
    assert "Context status:" in monitor
    assert "context_prune_wrappers" in monitor

    wrappers = agent.tools.context_list_wrappers()
    assert wrappers.count == 2
    assert [item.wrapper_id for item in wrappers.wrappers] == [wrapper.id, second_wrapper.id]
    assert wrappers.wrappers[0].content_length == len("verbose output")
    assert len(wrappers.wrappers[0].content_preview) <= 80

    pruned = agent.tools.context_prune_wrappers(wrapper.id)
    assert pruned.status == "pruned"
    assert pruned.pruned == 1
    assert pruned.wrappers[0].wrapper_id == wrapper.id
    assert wrapper in agent.session.messages
    assert wrapper.turns_left == 0
    assert second_wrapper in agent.session.messages

    missing = agent.tools.context_prune_wrappers(["missing-wrapper"])
    assert missing.status == "not_found"
    assert missing.missing == ["missing-wrapper"]


def test_environment_plugin_exposes_plugin_catalog_and_control_tools(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "catalog_runtime.py").write_text(
        """
from codex_agent import Plugin, tool

class CatalogRuntimePlugin(Plugin):
    name = "catalog_runtime"
    description = "Runtime catalog test plugin."

    @tool
    def ping(self):
        return "runtime-catalog-pong"
""",
        encoding="utf-8",
    )
    (plugins_dir / "requirements.txt").write_text("httpx\n# ignored\n\nrich\n", encoding="utf-8")

    agent = Agent(session="new", openai_api_key="sk-test", builtin_plugins=["environment"], custom_plugins=[])

    assert set(agent.plugins) == {"environment"}
    assert "environment_list_plugins" in agent.tools
    assert "environment_load_plugin" in agent.tools
    assert "environment_unload_plugin" in agent.tools
    assert "environment_reload_plugin" in agent.tools

    catalog = agent.tools.environment_list_plugins()
    by_name = {info.name: info for info in catalog}
    assert by_name["files"].kind == "builtin"
    assert by_name["files"].loaded is False
    assert by_name["files"].description
    assert by_name["catalog_runtime"].kind == "runtime"
    assert by_name["catalog_runtime"].loaded is False
    assert by_name["catalog_runtime"].description == "Runtime catalog test plugin."
    assert by_name["catalog_runtime"].requirements == ["httpx", "rich"]
    assert by_name["catalog_runtime"].requirements_file.endswith("plugins/requirements.txt")

    status = agent.providers.plugins_status()
    assert "files (builtin, available" in status
    assert "catalog_runtime (runtime, available" in status
    assert "Runtime catalog test plugin." in status

    load_builtin = agent.tools.environment_load_plugin(name="files")
    assert load_builtin["status"] == "loaded"
    assert "files" in agent.plugins
    assert "read" in agent.tools

    load_runtime = agent.tools.environment_load_plugin(name="catalog_runtime")
    assert load_runtime["status"] == "loaded"
    assert "catalog_runtime" in agent.plugins
    assert agent.tools.catalog_runtime_ping() == "runtime-catalog-pong"

    reload_runtime = agent.tools.environment_reload_plugin(name="catalog_runtime")
    assert reload_runtime == {"status": "reloaded", "plugin": "catalog_runtime"}
    assert agent.tools.catalog_runtime_ping() == "runtime-catalog-pong"

    unload_runtime = agent.tools.environment_unload_plugin(name="catalog_runtime")
    assert unload_runtime["status"] == "unloaded"
    assert "catalog_runtime" not in agent.plugins
    assert "catalog_runtime_ping" not in agent.tools

    with pytest.raises(ValueError, match="cannot unload itself"):
        agent.tools.environment_unload_plugin(name="environment")


def test_agent_can_hot_load_builtin_and_runtime_plugins(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "hot_runtime.py").write_text(
        """
from codex_agent import Plugin, provider, tool

class HotRuntimePlugin(Plugin):
    name = "hot_runtime"
    system_prompt = "# Hot Runtime Plugin"

    @tool
    def ping(self):
        return "runtime-pong"

    @provider
    def hot_runtime_context(self):
        return "runtime context"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", builtin_plugins=[] , custom_plugins=[])
    assert "files" not in agent.plugins
    assert "read" not in agent.tools
    assert "hot_runtime" not in agent.plugins

    loaded_builtin = agent.load_builtin_plugin("files")
    assert [plugin.name for plugin in loaded_builtin] == ["files"]
    assert "files" in agent.plugins
    assert "read" in agent.tools

    loaded_runtime = agent.load_runtime_plugin("hot_runtime")
    assert [plugin.name for plugin in loaded_runtime] == ["hot_runtime"]
    assert agent.tools.hot_runtime_ping() == "runtime-pong"
    assert agent.providers.hot_runtime_context() == "runtime context"
    assert "# Hot Runtime Plugin" in agent.config_manager.system_message().content

    agent.unload_plugin("hot_runtime")
    assert "hot_runtime" not in agent.plugins
    assert "hot_runtime_ping" not in agent.tools
    assert "hot_runtime_context" not in agent.providers
    assert "# Hot Runtime Plugin" not in agent.config_manager.system_message().content


def test_agent_creates_runtime_extension_folders(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    Agent(session="new")

    assert not (tmp_path / "tools").exists()
    assert not (tmp_path / "providers").exists()
    assert (tmp_path / "commands").is_dir()
    assert (tmp_path / "plugins").is_dir()


def test_agent_loads_stateful_runtime_plugins(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "custom_plugin.py").write_text(
        """
from codex_agent import Plugin, command, provider, tool

class CustomRuntimePlugin(Plugin):
    name = "custom_runtime"
    system_prompt = "# Custom Runtime Plugin\\nUse custom runtime helpers when useful."

    def __init__(self, agent):
        super().__init__(agent)
        self.count = 0

    @tool
    def ping(self):
        self.count += 1
        return f"{self.agent.config.name}:{self.count}"

    @provider
    def custom_context(self):
        return f"custom-count={self.count}"

    @command
    def custom_command(self):
        self.count += 10
        return self.count
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", name="RuntimeAgent")

    assert "custom_runtime" in agent.plugins
    assert agent.tools.custom_runtime_ping() == "RuntimeAgent:1"
    assert agent.providers.custom_context() == "custom-count=1"
    assert agent.commands.custom_command() == 11
    assert "# Custom Runtime Plugin" in agent.config_manager.system_message().content


def test_agent_loads_runtime_plugin_register_modules(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "registered.py").write_text(
        """
def register(agent):
    @agent.add_tool(name="registered_plugin_tool")
    def registered_plugin_tool():
        return agent.config.name

    @agent.add_provider(name="registered_plugin_context")
    def registered_plugin_context():
        return "registered context"

    @agent.add_command(name="registered_plugin_command")
    def registered_plugin_command(args=""):
        return f"registered:{args}"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", name="RegisteredAgent")

    assert agent.tools.registered_plugin_tool() == "RegisteredAgent"
    assert agent.providers.registered_plugin_context() == "registered context"
    assert agent_result(agent, "/registered_plugin_command hello") == "registered:hello"


def test_agent_can_select_runtime_plugins_by_module_name(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "enabled_plugin.py").write_text(
        """
from codex_agent import Plugin, tool

class EnabledPlugin(Plugin):
    name = "enabled_runtime"

    @tool
    def ping(self):
        return "enabled"
""",
        encoding="utf-8",
    )
    (plugins_dir / "disabled_plugin.py").write_text(
        """
from codex_agent import Plugin, tool

class DisabledPlugin(Plugin):
    name = "disabled_runtime"

    @tool
    def ping(self):
        return "disabled"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", custom_plugins=["enabled_plugin"])

    assert "enabled_runtime" in agent.plugins
    assert agent.tools.enabled_runtime_ping() == "enabled"
    assert "disabled_runtime" not in agent.plugins
    assert "disabled_runtime_ping" not in agent.tools


def test_agent_can_disable_all_runtime_plugins(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "custom_plugin.py").write_text(
        """
from codex_agent import Plugin, tool

class CustomPlugin(Plugin):
    name = "custom_runtime"

    @tool
    def ping(self):
        return "custom"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", custom_plugins=[])

    assert "custom_runtime" not in agent.plugins
    assert "custom_runtime_ping" not in agent.tools


def test_plugin_system_prompt_sections_are_added_to_system_message():
    agent = Agent(session="new", system="Base prompt.", builtin_plugins=["files", "environment", "memory", "planner", "scheduler", "context", "browser", "desktop"])

    assert agent.config_manager.system_message().content.startswith("Base prompt.")
    assert "# Long-Term Memory" in agent.config_manager.system_message().content
    assert "memory_add" in agent.config_manager.system_message().content
    assert "# Planner" in agent.config_manager.system_message().content
    assert "planner tools" in agent.config_manager.system_message().content
    assert "# Browser" in agent.config_manager.system_message().content
    assert "browser_state provider" in agent.config_manager.system_message().content
    assert "# Desktop" in agent.config_manager.system_message().content
    assert "Call desktop_start_session before any desktop action" in agent.config_manager.system_message().content
    assert "desktop_state provider" in agent.config_manager.system_message().content
    assert "Call desktop_run_commands only after desktop_state confirms the live session is active" in agent.config_manager.system_message().content
    assert "# Scheduler" in agent.config_manager.system_message().content
    assert "scheduler_restart_and_wakeup" in agent.config_manager.system_message().content


def test_builtin_capability_instructions_are_plugin_scoped():
    disabled = Agent(session="new", builtin_plugins=[])
    disabled_prompt = disabled.config_manager.system_message().content

    assert "# Modular Plugin Capabilities" in disabled_prompt
    assert "# Python Tool" not in disabled_prompt
    assert "# Bash Tool" not in disabled_prompt
    assert "# File Tools" not in disabled_prompt
    assert "# Content Tools" not in disabled_prompt
    assert "# Runtime Environment" not in disabled_prompt
    assert "# TTS and Conversation tone" not in disabled_prompt

    tts_scoped = Agent(
        session="new",
        builtin_plugins=["tts"],
    )
    assert "# TTS and Conversation tone" in tts_scoped.config_manager.system_message().content

    scoped = Agent(
        session="new",
        builtin_plugins=["python", "files"],
    )
    scoped_prompt = scoped.config_manager.system_message().content

    assert "# Modular Plugin Capabilities" in scoped_prompt
    assert "# Python Tool" in scoped_prompt
    assert "# File Tools" in scoped_prompt
    assert "# Bash Tool" not in scoped_prompt
    assert "# Content Tools" not in scoped_prompt
    assert "# Runtime Environment" not in scoped_prompt
