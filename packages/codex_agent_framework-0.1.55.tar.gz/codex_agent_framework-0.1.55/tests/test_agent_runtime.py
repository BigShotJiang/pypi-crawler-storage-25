from types import SimpleNamespace

from modict import modict

from codex_agent.agent_runtime import AgentRuntime, ProcessAgentRuntime


class FakeRuntime(AgentRuntime):
    def __init__(self):
        self.command_prompts = []
        self.messages = []
        self._busy = False
        self._turn_id = "turn-1"
        self._session_id = "session-1"

    def start(self):
        return self

    def stop(self, timeout=None):
        return self

    def on_event(self, handler):
        return handler

    @property
    def busy(self):
        return self._busy

    @property
    def current_turn_id(self):
        return self._turn_id

    @property
    def current_session_id(self):
        return self._session_id

    def get_status(self):
        return modict()

    def config(self):
        return modict()

    def update_config(self, values=None, save=True, namespace="agent", **kwargs):
        data = modict(values or {})
        data.update(kwargs)
        data.save = save
        data.namespace = namespace
        return data

    def session(self):
        return modict()

    def sessions(self):
        return modict()

    def messages(self):
        return []

    def tools(self):
        return modict()

    def wakeups(self, include_done=True):
        return []

    def start_new_session(self):
        return modict()

    def load_session(self, session_id):
        return modict(id=session_id)

    def delete_session(self, session_id):
        return modict(session_id=session_id)

    def navigate_session(self, direction):
        return modict(direction=direction)

    def interrupt(self, reason="api"):
        return modict(interrupted=True, reason=reason)

    def start_turn(self):
        return "turn-started"

    def submit_command(self, prompt):
        self.command_prompts.append(prompt)
        return "command-turn"

    def submit_message(self, message):
        self.messages.append(message)
        return modict(message=SimpleNamespace(id="message-1"), turn_id="message-turn")

    def schedule_wakeup(self, **kwargs):
        return modict(kwargs)

    def cancel_wakeup(self, job_id):
        return modict(job_id=job_id)

    def delete_wakeup(self, job_id):
        return modict(job_id=job_id)


def test_runtime_submit_prompt_routes_slash_commands_to_submit_command():
    runtime = FakeRuntime()

    result = runtime.submit_prompt("/status")

    assert result.command is True
    assert result.turn_id == "command-turn"
    assert runtime.command_prompts == ["/status"]
    assert runtime.messages == []


def test_runtime_submit_prompt_routes_text_to_submit_message():
    runtime = FakeRuntime()

    result = runtime.submit_prompt("hello")

    assert result.pending_message_id == "message-1"
    assert result.turn_id == "message-turn"
    assert runtime.messages[-1].content == "hello"


def test_process_runtime_update_config_preserves_namespace_cache_boundary(monkeypatch):
    runtime = ProcessAgentRuntime()
    runtime.cache["config"] = modict(model="cached")
    calls = []

    def fake_call(name, payload=None, timeout=None, autostart=True):
        calls.append((name, payload, timeout, autostart))
        return modict(voice="shimmer")

    monkeypatch.setattr(runtime, "call", fake_call)

    result = runtime.update_config({"voice": "shimmer"}, namespace="tts", save=False)

    assert result == {"voice": "shimmer"}
    assert calls[0][0] == "update_config"
    assert calls[0][1]["namespace"] == "tts"
    assert calls[0][1]["values"] == {"voice": "shimmer"}
    assert calls[0][1]["save"] is False
    assert runtime.cache["config"] == {"model": "cached"}
