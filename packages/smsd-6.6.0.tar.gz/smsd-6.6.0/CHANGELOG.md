# Changelog

All notable changes to SMSD Pro are documented in this file.

## [6.6.0] - 2026-03-30

### Breaking
- `McsOptions.timeoutMillis` renamed to `timeoutMs` (Java parity with C++/Python)

### Added
- C++ `McsOptions`: `postFilter` callback and `bondChangeAware` flag
- CIP: Rules 4b-c (like/unlike pairing), Rule 5 (R>S), pseudoasymmetric r/s detection
- Layout: two-phase `reduceCrossings` with individual ring flipping
- Python API: auto-detects native Mol objects, returns native indices, `prefer_rare_heteroatoms`
- New `BondChangeScorer` post-filter for reaction-aware MCS
- New `batchMcsConstrained` for multi-pair MCS with non-overlap constraints

### Performance
- MolGraph cache, domain space cache, ECFP/FCFP cache, pharmacophore features cache
- C++ `GraphBuilder` precomputed compatibility matrix

### Fixed
- Python: fixed roundtrip index correctness (no shared MolGraph across Mol objects)

### Changed
- Removed all competitor toolkit references from C++ headers

---

## [6.5.2] - 2026-03-30

### Added
- Python API: `mcs()`, `mcs_result()`, `map_reaction_aware()` now auto-detect native Mol objects and return native indices
- New `_ensure_mol_ex()` and `_auto_translate()` helpers with element validation
- New `prefer_rare_heteroatoms` parameter in `mcs()` for SAM/ATP heteroatom-weighted scoring

---

## [6.5.1] - 2026-03-30

### Added
- Two-phase `reduceCrossings`: phase 1 system-level crossing minimisation + phase 2 individual ring flipping
- Shared (fusion) atoms used as fixed pivots for individual ring flips
- `@since` tags on layout methods (`forceDirectedLayout`, `stressMajorisation`, `reduceCrossings`)

---

## [6.5.0] - 2026-03-30

### Added
- `ChemOptions.copyOf()` for safe, immutable option cloning
- Heteroatom-seeded MCS now uses charge-relaxed options automatically

### Fixed
- Reaction-aware MCS charge relaxation fix: S+ to S mapping now handled
  correctly (e.g. SAM sulfonium centre maps to neutral sulfur)

### Changed
- Competitor reference cleanup across documentation and build metadata

## [6.4.1] - 2025

- Full Java/C++/Python parity, 32 binding gaps fixed

## [6.4.0] - 2025

- Force-directed layout, reaction-aware MCS, SMACOF stress majorisation

---

Copyright (c) 2018-2026 BioInception PVT LTD. Algorithm Copyright (c) 2009-2026 Syed Asad Rahman.
