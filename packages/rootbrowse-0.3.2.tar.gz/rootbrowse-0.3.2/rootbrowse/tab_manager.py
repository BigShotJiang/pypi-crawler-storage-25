"""标签页管理器"""

from typing import Any

from .exceptions import TabNotFoundError


class TabManager:
    """标签页管理器，管理浏览器标签页（新增、切换、关闭）"""

    def __init__(self, page: Any):
        """
        初始化 TabManager

        Args:
            page: DrissionPage ChromiumPage 实例
        """
        self._page = page
        self._tabs: list[dict[str, str]] = []
        self._current_index = 0

    def new_tab(self, url: str) -> int:
        """
        打开新标签页

        Args:
            url: 目标 URL

        Returns:
            新标签页索引
        """
        self._page.new_tab(url)
        self._tabs.append({"url": url, "title": ""})
        self._current_index = len(self._tabs) - 1
        return self._current_index

    def close_tab(self, index: int | None = None) -> None:
        """
        关闭指定标签页

        Args:
            index: 目标标签页索引，None 表示关闭当前标签页
        """
        if len(self._tabs) <= 1:
            raise TabNotFoundError("Cannot close the last tab")

        target = index if index is not None else self._current_index

        if target < 0 or target >= len(self._tabs):
            raise TabNotFoundError(f"Tab index out of range: {target}")

        # 如果关闭的不是当前标签页，先切换到目标
        if target != self._current_index:
            self._page.to_tab(target)

        self._page.close()
        self._tabs.pop(target)

        # 调整当前索引
        if self._current_index >= len(self._tabs):
            self._current_index = len(self._tabs) - 1
        elif target < self._current_index:
            self._current_index -= 1

    def switch_to_tab(self, index: int) -> None:
        """
        切换到指定标签页

        Args:
            index: 目标标签页索引

        Raises:
            TabNotFoundError: 索引越界
        """
        if index < 0 or index >= len(self._tabs):
            raise TabNotFoundError(f"Tab index out of range: {index}")

        self._page.to_tab(index)
        self._current_index = index

    def tabs_count(self) -> int:
        """
        返回标签页数量

        Returns:
            标签页数量
        """
        return len(self._tabs)

    def current_index(self) -> int:
        """
        返回当前标签页索引

        Returns:
            当前标签页索引
        """
        return self._current_index