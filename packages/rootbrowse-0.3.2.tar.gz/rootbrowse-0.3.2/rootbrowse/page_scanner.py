"""页面扫描器"""

from typing import Any

from .types import Element, ElementPreview, Region, RegionSummary
from .constants import CLICKABLE_TAGS, REF_PREFIX, DEFAULT_LIMIT, DEFAULT_OFFSET, KEY_ATTRS_PREVIEW, REGION_LABEL_KEYWORDS, TAG_LABELS, REGION_NOISE_TAGS
from .exceptions import RegionNotFoundError, ElementNotFoundError


class PageScanner:
    """页面扫描器，获取页面结构化信息（区块、元素摘要、完整元素）"""

    def __init__(self, page: Any):
        """
        初始化 PageScanner

        Args:
            page: DrissionPage ChromiumPage 实例
        """
        self._page = page
        self._element_map: dict[str, Element] = {}
        self._regions: list[Region] = []
        self._element_to_region: dict[str, str] = {}  # ref -> region_id
        self._ref_counter = 1  # 全局 ref 计数器

    def get_regions(self) -> list[Region]:
        """
        返回页面语义区块列表（不扫描元素）

        Returns:
            list[Region]: [{id, label}, ...]
        """
        self._detect_regions()
        return self._regions

    def get_region_summary(self, region_id: str | list[str] | None = None) -> RegionSummary:
        """
        返回区域摘要

        Args:
            region_id: 区域 ID，str 单区域，list 多区域，None 全部区域

        Returns:
            RegionSummary: {count, tag_counts, role_counts, text_preview}

        Raises:
            RegionNotFoundError: 区域不存在
        """
        self._ensure_elements_scanned()

        # 确定要搜索的区域列表
        if region_id is None:
            target_region_ids = [r.id for r in self._regions]
        elif isinstance(region_id, str):
            target_region_ids = [region_id]
        else:
            target_region_ids = region_id

        # 验证所有区域都存在
        for rid in target_region_ids:
            self._find_region(rid)

        # 收集所有目标区域的元素
        all_elements = []
        for rid in target_region_ids:
            all_elements.extend(self._get_elements_in_region(rid))

        # 统计
        tag_counts: dict[str, int] = {}
        role_counts: dict[str, int] = {}
        text_preview = []

        for ele in all_elements:
            tag_counts[ele.tag] = tag_counts.get(ele.tag, 0) + 1
            role_counts[ele.role] = role_counts.get(ele.role, 0) + 1

            if ele.text and len(text_preview) < 10:
                text_preview.append({
                    "tag": ele.tag,
                    "text": ele.text[:50],
                    "ref": ele.ref
                })

        return RegionSummary(
            count=len(all_elements),
            tag_counts=tag_counts,
            role_counts=role_counts,
            text_preview=text_preview
        )

    def match_element(
        self,
        region_id: str | list[str] | None = None,
        query: str | None = None,
        tag: str | None = None,
        role: str | None = None,
        text_contains: str | None = None,
        limit: int = DEFAULT_LIMIT,
        offset: int = DEFAULT_OFFSET
    ) -> list[ElementPreview]:
        """
        按 region/keyword/tag/role/text 筛选元素，返回摘要列表

        Args:
            region_id: 搜索区域，可单选/多选/None（全部）
            query: 关键词搜索
            tag: HTML 标签筛选
            role: ARIA role 筛选
            text_contains: 文字包含筛选
            limit: 最多返回数量
            offset: 分页偏移

        Returns:
            list[ElementPreview]: [{ref, text, attrs_preview}, ...]
        """
        self._ensure_elements_scanned()

        # 确定搜索区域
        if region_id is None:
            target_refs = set(self._element_map.keys())
        elif isinstance(region_id, str):
            target_refs = self._get_refs_in_region(region_id)
        else:
            target_refs = set()
            for rid in region_id:
                target_refs |= self._get_refs_in_region(rid)

        # 筛选
        results = []
        for ref, ele in self._element_map.items():
            if ref not in target_refs:
                continue

            if tag and ele.tag != tag:
                continue
            if role and ele.role != role:
                continue
            if text_contains and text_contains not in ele.text:
                continue
            if query and query not in ele.text and query not in str(ele.attrs):
                continue

            results.append(ElementPreview(
                ref=ele.ref,
                text=ele.text[:100] if ele.text else "",
                attrs_preview=self._get_attrs_preview(ele)
            ))

        # 分页
        return results[offset:offset + limit]

    def get_element(self, locator: str, locator_type: str | None = None) -> Element:
        """
        通过定位符获取完整元素信息

        Args:
            locator: 定位符（ref / xpath / role / text / aria_label）
            locator_type: 定位类型，不指定则自动推断

        Returns:
            Element

        Raises:
            ElementNotFoundError: 元素不存在
        """
        # 自动推断 locator 类型
        if locator_type is None:
            if self._is_ref(locator):
                locator_type = "ref"
            else:
                locator_type = "xpath"

        # ref 查表
        if locator_type == "ref":
            if locator not in self._element_map:
                raise ElementNotFoundError(f"Element not found: {locator}")
            return self._element_map[locator]

        # 其他类型直接查询 DrissionPage
        try:
            if locator_type == "xpath":
                driss_ele = self._page.ele(f'xpath={locator}')
            elif locator_type == "role":
                driss_ele = self._page.ele(f'@role:{locator}')
            elif locator_type == "aria_label":
                driss_ele = self._page.ele(f'@aria-label:{locator}')
            elif locator_type == "text":
                driss_ele = self._page.ele(f'text={locator}')
            else:
                raise ElementNotFoundError(f"Unknown locator type: {locator_type}")

            if driss_ele is None:
                raise ElementNotFoundError(f"Element not found: {locator}")

            # 添加到缓存并返回
            self._ensure_elements_scanned()  # 确保区域已检测
            ref = f"{REF_PREFIX}{self._ref_counter}"
            try:
                ele_xpath = driss_ele.xpath or ""
            except Exception:
                ele_xpath = ""
            region_id = self._regions[0].id if self._regions else "region_1"
            for region in self._regions:
                if ele_xpath.startswith(region.root_xpath):
                    region_id = region.id
                    break

            element = Element(
                ref=ref,
                tag=driss_ele.tag,
                role=driss_ele.attr("role") or "",
                text=driss_ele.text or "",
                xpath=ele_xpath,
                attrs=dict(driss_ele.attrs) if hasattr(driss_ele, 'attrs') else {}
            )
            self._element_map[ref] = element
            self._element_to_region[ref] = region_id
            self._ref_counter += 1
            return element
        except Exception as e:
            if isinstance(e, ElementNotFoundError):
                raise
            raise ElementNotFoundError(f"Element not found: {locator}, error: {e}")

    def find_element(
        self,
        by: str,
        value: str,
        filter: dict | None = None
    ) -> Element | None:
        """
        多维度定位元素

        Args:
            by: 定位方式（xpath / role / aria_label / text）
            value: 定位值
            filter: 额外过滤条件

        Returns:
            Element | None
        """
        self._ensure_elements_scanned()

        try:
            if by == "xpath":
                driss_ele = self._page.ele(f'xpath={value}')
            elif by == "role":
                driss_ele = self._page.ele(f'@role:{value}')
            elif by == "aria_label":
                driss_ele = self._page.ele(f'@aria-label:{value}')
            elif by == "text":
                driss_ele = self._page.ele(f'text={value}')
            else:
                return None

            if driss_ele is None:
                return None

            # 添加到缓存并返回
            ref = f"{REF_PREFIX}{self._ref_counter}"
            try:
                ele_xpath = driss_ele.xpath or ""
            except Exception:
                ele_xpath = ""
            region_id = self._regions[0].id if self._regions else "region_1"
            for region in self._regions:
                if ele_xpath.startswith(region.root_xpath):
                    region_id = region.id
                    break

            element = Element(
                ref=ref,
                tag=driss_ele.tag,
                role=driss_ele.attr("role") or "",
                text=driss_ele.text or "",
                xpath=ele_xpath,
                attrs=dict(driss_ele.attrs) if hasattr(driss_ele, 'attrs') else {}
            )
            self._element_map[ref] = element
            self._element_to_region[ref] = region_id
            self._ref_counter += 1
            return element
        except Exception:
            return None

    def _is_ref(self, locator: str) -> bool:
        """判断是否为 ref 格式（r + 数字）"""
        if not locator:
            return False
        if locator.startswith("r") and locator[1:].isdigit():
            return True
        return False

    def clear_cache(self) -> None:
        """清空缓存，换页面时调用"""
        self._element_map.clear()
        self._element_to_region.clear()
        self._ref_counter = 1  # 重置 ref 计数器

    def _ensure_elements_scanned(self, wait: str = "loaded", timeout: float | None = None) -> None:
        """确保元素已扫描（如果还没扫描过，才扫描）

        Args:
            wait: 等待策略
                - "loaded": 等待页面完全就绪,保证js（默认，推荐）
                - "none": 不等待
            timeout: 等待超时时间（秒），默认 None（无上限）
        """
        if self._element_map:  # 已经有数据了，跳过
            return
        # 确保区域已检测
        if not self._regions:
            self._detect_regions()
        # 等待页面渲染完成，避免动态内容缺失
        if wait == "loaded":
            # 等待文档就绪（兼容 DrissionPage 4.x）
            if timeout:
                self._page.wait.doc_loaded(timeout=timeout)
            else:
                self._page.wait.doc_loaded()
        # wait == "none" 不等待
        self._scan_elements()

    def _scan_elements(self) -> None:
        """扫描可交互元素，建立 ref 映射并记录归属区域（优化版：6次全局查询）"""
        # 1. 用 tag: 做 6 次全局查询（快）
        for tag in CLICKABLE_TAGS:
            for ele in self._page.eles(f'tag:{tag}', timeout=0.5):
                # 2. 用 xpath 前缀匹配判断属于哪个区域
                try:
                    ele_xpath = ele.xpath or ""
                except Exception:
                    ele_xpath = ""
                region_id = self._regions[0].id if self._regions else "region_1"
                for region in self._regions:
                    if ele_xpath.startswith(region.root_xpath):
                        region_id = region.id
                        break

                try:
                    text = ele.text or ""
                except Exception:
                    text = ""

                ref = f"{REF_PREFIX}{self._ref_counter}"
                element = Element(
                    ref=ref,
                    tag=ele.tag,
                    role=ele.attr("role") or "",
                    text=text,
                    xpath=ele_xpath,
                    attrs=dict(ele.attrs) if hasattr(ele, 'attrs') else {}
                )
                self._element_map[ref] = element
                self._element_to_region[ref] = region_id
                self._ref_counter += 1

    def _detect_regions(self) -> None:
        """检测页面语义区域（body 直接子元素）"""
        self._regions.clear()  # 先清空
        try:
            body = self._page.ele('tag:body')
            if body is None:
                self._regions = [Region(id="region_1", label="主内容", root_xpath="")]
                return

            children = body.children()

            region_id = 1
            for child in children:
                tag = child.tag or ""
                if tag in REGION_NOISE_TAGS:
                    continue

                # 生成 region id 和 label
                region_str = f"region_{region_id}"
                region_label = self._guess_region_label(child)
                self._regions.append(Region(
                    id=region_str,
                    label=region_label,
                    root_xpath=child.xpath
                ))
                region_id += 1

            # 如果没检测到任何区域，创建一个默认区域
            if not self._regions:
                self._regions = [Region(id="region_1", label="主内容", root_xpath="")]

        except Exception:
            self._regions = [Region(id="region_1", label="主内容", root_xpath="")]

    def _guess_region_label(self, element: Any) -> str:
        """根据元素属性猜测区域标签"""
        region_id = element.attr('id') or ""
        region_class = element.attr('class') or ""

        combined = (region_id + ' ' + region_class).lower()
        for keyword, label in REGION_LABEL_KEYWORDS.items():
            if keyword in combined:
                return label

        tag = element.tag or '区域'
        return TAG_LABELS.get(tag, tag)

    def _find_region(self, region_id: str) -> Region:
        """查找区域"""
        for region in self._regions:
            if region.id == region_id:
                return region
        raise RegionNotFoundError(f"Region not found: {region_id}")

    def _get_refs_in_region(self, region_id: str) -> set[str]:
        """获取区域内所有元素的 ref"""
        return {ref for ref, rid in self._element_to_region.items() if rid == region_id}

    def _get_elements_in_region(self, region_id: str) -> list[Element]:
        """获取区域内所有元素"""
        refs = self._get_refs_in_region(region_id)
        return [self._element_map[ref] for ref in refs if ref in self._element_map]

    def _get_attrs_preview(self, ele: Element) -> dict:
        """获取元素的属性预览"""
        preview = {}
        for key in KEY_ATTRS_PREVIEW:
            if key in ele.attrs:
                preview[key] = ele.attrs[key]
        return preview