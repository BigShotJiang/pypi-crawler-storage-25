from rootbrowse import Browser
from DrissionPage import ChromiumPage

page = ChromiumPage()
page.wait.doc_loaded()




browser = Browser(headless=False)
browser.get('https://www.bing.com')

print("=== 页面区域 ===")
regions = browser.view.get_regions()
print(regions)

print("\n=== 搜索区域详情 ===")
if regions:
    summary = browser.view.get_region_summary("region_2")
    print(vars(summary))

print("\n=== 内容区域链接 ===")
if len(regions) > 1:
    links = browser.view.match_element(region_id=regions[1].id, tag='a', limit=5)
    for link in links:
        print(f"  {link.ref}: {link.text[:30]} - {link.attrs_preview}")

# browser.close()