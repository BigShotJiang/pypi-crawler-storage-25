import json
import argparse
import sys
import base64
import zlib
import re
import urllib.request
import os
import shutil
import subprocess
import tempfile
import importlib

def _encode_mermaid_ink_pako(mermaid_code):
    graphbytes = mermaid_code.encode("utf8")
    compressed = zlib.compress(graphbytes, 9)
    base64_bytes = base64.urlsafe_b64encode(compressed)
    return "pako:" + base64_bytes.decode("ascii").rstrip("=")

def _encode_mermaid_ink_base64(mermaid_code):
    graphbytes = mermaid_code.encode("utf8")
    base64_bytes = base64.urlsafe_b64encode(graphbytes)
    return base64_bytes.decode("ascii").rstrip("=")

def _fetch_mermaid_ink_image(encoded_payload, output_path, image_type="png"):
    url = f"https://mermaid.ink/img/{encoded_payload}?type={image_type}"
    print(f"Fetching PNG from: {url[:50]}...")
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req) as response:
        output_dir = os.path.dirname(os.path.abspath(output_path))
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
        with open(output_path, 'wb') as f:
            f.write(response.read())

def generate_png_from_mermaid(mermaid_code, output_path):
    try:
        try:
            _fetch_mermaid_ink_image(_encode_mermaid_ink_pako(mermaid_code), output_path, image_type="png")
        except urllib.error.HTTPError as e:
            if e.code not in (400, 414):
                raise
            _fetch_mermaid_ink_image(_encode_mermaid_ink_base64(mermaid_code), output_path, image_type="png")
        print(f"PNG generated at: {output_path}")
        
    except urllib.error.HTTPError as e:
        print(f"HTTP Error generating PNG: {e.code} - {e.reason}", file=sys.stderr)
        if e.code == 414: # URI Too Long
            print("Error: The diagram is too large for the Mermaid.ink API (URI Too Long).", file=sys.stderr)
    except Exception as e:
        print(f"Error generating PNG: {e}", file=sys.stderr)

def _resolve_mmdc_path(mmdc_path):
    if mmdc_path:
        return mmdc_path
    env_path = os.environ.get('MMDC_PATH')
    if env_path:
        return env_path
    resolved = shutil.which('mmdc')
    if resolved:
        return resolved
    raise FileNotFoundError("Mermaid CLI not found (mmdc). Install @mermaid-js/mermaid-cli or provide --mmdc-path.")

def generate_png_from_mermaid_local(mermaid_code, output_path, mmdc_path=None):
    mmdc = _resolve_mmdc_path(mmdc_path)
    output_dir = os.path.dirname(os.path.abspath(output_path))
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmpdir:
        input_path = os.path.join(tmpdir, 'diagram.mmd')
        with open(input_path, 'w', encoding='utf-8') as f:
            f.write(mermaid_code)
        result = subprocess.run(
            [mmdc, '-i', input_path, '-o', output_path],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or '').strip() or "Mermaid CLI failed")
    print(f"PNG generated at: {output_path}")

def _import_mermaid_cli():
    try:
        return importlib.import_module('mermaid_cli')
    except Exception as e:
        raise ImportError("Python dependency 'mermaid-cli' is not available. Install it (see requirements.txt) to use --png-mode python.") from e

def generate_png_from_mermaid_python(mermaid_code, output_path):
    mermaid_cli = _import_mermaid_cli()
    render = getattr(mermaid_cli, 'render_mermaid_file_sync', None)
    if render is None:
        raise AttributeError("mermaid_cli.render_mermaid_file_sync is not available; cannot render with --png-mode python")

    output_dir = os.path.dirname(os.path.abspath(output_path))
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmpdir:
        input_path = os.path.join(tmpdir, 'diagram.mmd')
        with open(input_path, 'w', encoding='utf-8') as f:
            f.write(mermaid_code)
        render(input_file=input_path, output_file=output_path, output_format='png')
    print(f"PNG generated at: {output_path}")

def generate_mermaid_erd(json_data):
    lines = ["erDiagram"]
    
    # Process Tables
    tables = json_data.get("tables", [])
    def _strip_outer_quotes(value):
        if not isinstance(value, str):
            return value
        v = value.strip()
        if len(v) >= 2 and ((v[0] == "'" and v[-1] == "'") or (v[0] == '"' and v[-1] == '"')):
            return v[1:-1]
        return v

    def _first_schema_item(table):
        schema = table.get("schema")
        item = table.get("item") or table.get("table_item")
        if schema and item:
            return schema, item
        partitions = table.get("partitions") or []
        for part in partitions:
            details = (part or {}).get("sourceDetails") or []
            for entry in details:
                if isinstance(entry, dict) and entry.get("schema") and entry.get("item"):
                    return entry["schema"], entry["item"]
        return schema, item

    display_name_by_table = {}
    for table in tables:
        raw_name = table.get("name")
        if not raw_name:
            continue
        schema, item = _first_schema_item(table)
        display = f"{schema}.{item}" if schema and item else raw_name
        if isinstance(display, str):
            display = display.replace('"', "'")
        display_name_by_table[raw_name] = display
        normalized = _strip_outer_quotes(raw_name)
        if normalized and normalized != raw_name:
            display_name_by_table[normalized] = display
    processed_tables = set()
    
    for table in tables:
        table_name = table.get("name")
        if not table_name:
            continue
        lower_table_name = table_name.lower()
        if "datetabletemplate" in lower_table_name or "localdatetable" in lower_table_name:
            continue
        
        processed_tables.add(table_name)
        
        # Sanitize table name for Mermaid
        # We use quotes for table names to handle spaces and special chars
        display_table_name = display_name_by_table.get(table_name, table_name)
        safe_table_name = f'"{display_table_name}"'
        
        lines.append(f"    {safe_table_name} {{")
        
        columns = table.get("columns", [])
        for col in columns:
            col_name = col.get("name")
            raw_data_type = col.get("dataType", "string")
            
            # Map TMDL data types to standard ERD types
            # int64 -> int
            # double -> float
            # dateTime -> datetime
            # string -> string
            # boolean -> boolean
            # decimal -> decimal
            # binary -> blob
            
            dtype_map = {
                "int64": "int",
                "double": "float",
                "dateTime": "datetime",
                "boolean": "boolean",
                "decimal": "decimal",
                "binary": "blob",
                "string": "string"
            }
            
            data_type = dtype_map.get(raw_data_type, raw_data_type)
            
            # Clean up column name for display
            # Mermaid attributes: type name
            # According to ERD.md, attributes are "type name".
            # The name should NOT be quoted unless it contains spaces or special characters?
            # ERD.md examples: string firstName, string custNumber.
            # But what if the name has spaces?
            # ERD.md doesn't explicitly say names with spaces are supported in attributes without quotes, 
            # but usually for Mermaid entity names they are.
            # However, looking at the user request "do not quote field names in tables".
            # This implies we should just output the name directly.
            # But we must handle spaces. In Mermaid ERD, attribute names with spaces are usually problematic or need underscores.
            # Or maybe the user means "don't wrap the whole thing in quotes".
            # Let's try to replace spaces with underscores to be safe and unquoted, 
            # OR just output it as is if it has no spaces.
            # If it has spaces, maybe we SHOULD quote it?
            # Re-reading user input: "see the documentation, do not quote field names in tables"
            # Documentation example:
            #     CUSTOMER {
            #         string name
            #         string custNumber
            #         string sector
            #     }
            # It seems standard attributes don't use quotes.
            # Let's strip quotes if we were adding them, and sanitize the name.
            # If the name has spaces, Mermaid might fail or truncate.
            # Let's assume we should replace spaces with underscores or keep it as is if Mermaid supports it.
            # Actually, standard Mermaid ERD attribute names shouldn't have spaces usually.
            # But in Power BI, column names OFTEN have spaces (e.g. "Order Date").
            # Let's try replacing spaces with underscores for the attribute name in the diagram
            # to ensure valid syntax without quotes.
            
            display_name = col_name
            if display_name is None:
                display_name = ""
            if "=" in display_name:
                display_name = display_name.split("=", 1)[0].strip()
            safe_col_name = re.sub(r"[^0-9A-Za-z_]", "_", display_name)
            safe_col_name = re.sub(r"_+", "_", safe_col_name).strip("_")
            if not safe_col_name:
                safe_col_name = "col"
            if safe_col_name[0].isdigit():
                safe_col_name = "col_" + safe_col_name
            lines.append(f'        {data_type} {safe_col_name}')
            
        lines.append("    }")

    # Process Relationships
    relationships = json_data.get("relationships", [])
    for rel in relationships:
        from_table = rel.get("fromTable")
        to_table = rel.get("toTable")
        
        if not from_table or not to_table:
            continue
        lf = from_table.lower()
        lt = to_table.lower()
        if "datetabletemplate" in lf or "localdatetable" in lf or "datetabletemplate" in lt or "localdatetable" in lt:
            continue
            
        # Ensure tables exist (or at least are referenced safely)
        # If a table in relationship wasn't in "tables" list, we still render the relationship
        # but the table definition might be missing columns.
        
        from_col = rel.get("fromColumnName", "")
        to_col = rel.get("toColumnName", "")
        
        # Determine Cardinality
        # Power BI Default: Many-to-One (from -> to)
        # fromSide: Many
        # toSide: One
        
        # Defaults
        # ERD.md Syntax:
        # }o : Zero or more (no upper limit)
        # || : Exactly one
        # |{ : One or more (no upper limit)
        # |o : Zero or one
        
        # Power BI Relationships:
        # Typically "Many to One" means (*) -> (1)
        # The 'from' side is the Many side.
        # The 'to' side is the One side.
        
        # However, standard Power BI relationships are usually "Zero or More" to "Exactly One" (or "Zero or One" if nullable)
        # For simplicity and typical representation:
        left_card = "}o" # Zero or more
        right_card = "||" # Exactly one
        
        # Check specific cardinality overrides
        if rel.get("toCardinality", "").lower() == "many":
            right_card = "o{" # Zero or more
            
        # Cross filtering behavior could imply other nuances, but structure is primary.
        
        # Relationship Type
        # ERD.md supports identifying (--) and non-identifying (..)
        # Power BI relationships are typically non-identifying in the strict sense (tables exist independently),
        # but often modeled as solid lines in tools.
        # However, to be precise with Mermaid's definition: "non-identifying ... can exist without the other"
        # In PBI, dimensions and facts exist independently.
        # So we should probably use .. (dotted) for non-identifying.
        # But commonly ERDs use solid lines. Let's stick to solid (--) for visual clarity unless requested otherwise,
        # or better, use .. if we want to be semantically strict about "non-identifying".
        # Let's use -- (identifying/solid) as it's the default most users expect for "Foreign Key" style links.
        # But wait, ERD.md says: "non-identifying relationship that we might specify in Mermaid as: ... .. ..."
        # Let's stick to the code's current solid line usage as it matches the previous output which the user saw,
        # unless we want to change to ..
        # The user asked to "use ONLY the prescribed syntax in this document".
        # The document allows both.
        # Let's keep -- as it maps to the standard "relationship" concept in PBI Desktop UI (solid line).
        
        # Wait, PBI uses:
        # Active relationship: Solid line
        # Inactive relationship: Dotted line
        
        # Let's check if relationship is active?
        # The JSON might not have 'isActive' (defaults to true).
        is_active = rel.get("isActive", True)
        
        connector = "--" if is_active else ".."
        
        # Label for the relationship
        # According to ERD.md:
        # <first-entity> [<relationship> <second-entity> : <relationship-label>]
        # The label should be quoted
        label = f"{from_col} to {to_col}".replace('"', "'")
        
        from_display = display_name_by_table.get(from_table, from_table)
        to_display = display_name_by_table.get(to_table, to_table)
        if isinstance(from_display, str):
            from_display = from_display.replace('"', "'")
        if isinstance(to_display, str):
            to_display = to_display.replace('"', "'")
        lines.append(f'    "{from_display}" {left_card}{connector}{right_card} "{to_display}" : "{label}"')

    return "\n".join(lines)

def main():
    parser = argparse.ArgumentParser(description="Generate Mermaid ERD from TMDL JSON output")
    parser.add_argument("input_file", help="Path to the JSON input file")
    parser.add_argument("--output", "-o", help="Path to output Mermaid file (e.g. output.mmd or output.md)")
    parser.add_argument("--png-output", help="Path to output PNG file (e.g. output.png).")
    parser.add_argument("--png-mode", choices=["remote", "local", "python"], default="remote", help="PNG rendering mode: remote (mermaid.ink), local (Mermaid CLI), or python (Python mermaid-cli).")
    parser.add_argument("--mmdc-path", default=None, help="Path to Mermaid CLI executable (mmdc) for --png-mode local.")
    
    args = parser.parse_args()
    
    try:
        with open(args.input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        mermaid_content = generate_mermaid_erd(data)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                # If it's a markdown file, wrap in code block
                if args.output.endswith('.md'):
                    f.write("```mermaid\n")
                    f.write(mermaid_content)
                    f.write("\n```")
                else:
                    f.write(mermaid_content)
            print(f"ERD generated at: {args.output}")
        elif not args.png_output:
            # Print to stdout if no output specified and no png requested
            print(mermaid_content)
            
        if args.png_output:
            if args.png_mode == "local":
                generate_png_from_mermaid_local(mermaid_content, args.png_output, args.mmdc_path)
            elif args.png_mode == "python":
                generate_png_from_mermaid_python(mermaid_content, args.png_output)
            else:
                generate_png_from_mermaid(mermaid_content, args.png_output)
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
