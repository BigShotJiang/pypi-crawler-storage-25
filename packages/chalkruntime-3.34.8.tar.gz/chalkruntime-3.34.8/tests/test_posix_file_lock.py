from __future__ import annotations

import multiprocessing
from pathlib import Path
from queue import Empty

import pytest

from chalkruntime.utils.posix_file_lock import posix_file_lock


def _lock_in_child(lock_path: str, events: multiprocessing.Queue) -> None:
    events.put("started")
    with posix_file_lock(lock_path):
        events.put("acquired")


def test_posix_file_lock_blocks_other_processes(tmp_path: Path):
    lock_path = tmp_path / "redshift.lock"
    context = multiprocessing.get_context("spawn")
    events = context.Queue()
    child = context.Process(target=_lock_in_child, args=(str(lock_path), events))

    try:
        with posix_file_lock(lock_path):
            child.start()
            assert events.get(timeout=2) == "started"
            with pytest.raises(Empty):
                events.get(timeout=0.25)

        assert events.get(timeout=2) == "acquired"
        child.join(timeout=2)
        assert child.exitcode == 0
    finally:
        if child.is_alive():
            child.terminate()
            child.join()


def test_posix_file_lock_releases_after_exception(tmp_path: Path):
    lock_path = tmp_path / "redshift.lock"

    with pytest.raises(RuntimeError, match="release the lock"):
        with posix_file_lock(lock_path):
            raise RuntimeError("release the lock")

    with posix_file_lock(lock_path):
        pass
