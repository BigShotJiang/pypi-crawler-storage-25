import argparse
import os
import pathlib
import shutil
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Launch a Python module with valgrind profiling. Requires that valgrind is installed externally!!"
    )
    parser.add_argument("module", type=str, help='Python module to run (e.g., "mypackage.mymodule")')
    args, remaining = parser.parse_known_args()

    valgrind = shutil.which("valgrind")
    if valgrind is None:
        raise RuntimeError("Cannot startup the valgrind launcher as `which valgrind` did not find anything")

    pid = os.getpid()
    valgrind_log_file_directory = os.environ.get("CHALK_VALGRIND_LAUNCHER_LOG_DIRECTORY", "/tmp")
    valgrind_log_file = pathlib.Path(valgrind_log_file_directory) / f"valgrind-output-{pid}.log"

    # Allow customization of valgrind options via environment variable
    valgrind_opts = os.environ.get("CHALK_VALGRIND_LAUNCHER_OPTS", "--leak-check=full --track-origins=yes").split()

    argv = [
        "valgrind",
        *valgrind_opts,
        f"--log-file={valgrind_log_file}",
        sys.executable,
        "-m",
        args.module,
        *remaining,
    ]

    print(f"Valgrind output will be written to: {valgrind_log_file}", file=sys.stderr)
    sys.stdout.flush()
    sys.stderr.flush()
    os.execvp("valgrind", argv)


if __name__ == "__main__":
    main()
