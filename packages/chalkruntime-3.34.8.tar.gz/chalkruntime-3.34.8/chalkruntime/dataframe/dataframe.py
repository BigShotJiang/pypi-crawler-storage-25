"""Compatibility shims for the legacy ``chalkruntime.dataframe`` package.

This module used to host the engine-facing ``ChalkDataFrame`` type before we
introduced the standalone ``chalkdf`` package.  Some parts of the codebase (and
older integrations) still import ``chalkruntime.dataframe.dataframe`` directly,
so we keep a very small wrapper that simply forwards those imports to the new
implementation.  Keeping this bridge avoids having to update every existing
import site while the migration is in flight.
"""

from __future__ import annotations

from chalkdf import DataFrame as _DataFrame
from chalkdf.debug import chalk_dataframe_debug_context

ChalkDataFrame = _DataFrame

__all__ = ["ChalkDataFrame", "chalk_dataframe_debug_context"]
