"""Compatibility shim for ``chalkruntime.dataframe.lazyframe`` imports."""

from __future__ import annotations

from chalkdf import LazyFrame

__all__ = ["LazyFrame"]
