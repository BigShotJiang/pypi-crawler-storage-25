import json
import os
from typing import Optional


class Env:
    def __init__(self, case_insensitive: bool):
        super().__init__()
        self.case_insensitive = case_insensitive
        self.environ = {k.lower(): v for k, v in os.environ.items()} if case_insensitive else dict(**os.environ)

    def string_optional(self, key: str) -> Optional[str]:
        if self.case_insensitive:
            key = key.lower()
        return self.environ.get(key, None)

    def string(self, key: str, *, default: str | None = None, one_of: tuple[str, ...] | None = None) -> str:
        if self.case_insensitive:
            key = key.lower()

        val = self.environ.get(key)
        if val is None and default is not None:
            val = default
        if val is None:
            raise ValueError(f"Missing required environment variable: {key}")
        if one_of is not None:
            if val in one_of:
                return val
            lower_to_actual = {k.lower(): k for k in one_of}
            if val.lower() in lower_to_actual:
                return lower_to_actual[val.lower()]
            raise ValueError(f"Invalid value for environment variable {key}: {val}. Expected one of {one_of}")
        return val

    def boolean(self, key: str, *, default: bool = False) -> bool:
        if self.case_insensitive:
            key = key.lower()
        val = self.environ.get(key)
        if val is None:
            return default
        return val.lower() in {"1", "true", "yes"}

    def integer(self, key: str, *, default: Optional[int] = None) -> int:
        if self.case_insensitive:
            key = key.lower()
        val = self.environ.get(key)
        if val is None:
            if default is not None:
                return default
            raise ValueError(f"Missing required integer environment variable: {key}")
        try:
            return int(val)
        except ValueError:
            raise ValueError(f"Invalid integer value for environment variable {key}: {val}")

    def integer_optional(self, key: str) -> Optional[int]:
        if self.case_insensitive:
            key = key.lower()
        val = self.environ.get(key)
        if val is None:
            return None
        try:
            return int(val)
        except ValueError:
            raise ValueError(f"Invalid integer value for environment variable {key}: {val}")

    def string_tuple(self, key: str, *, default: Optional[tuple[str, ...]] = ()) -> tuple[str, ...]:
        if self.case_insensitive:
            key = key.lower()
        val = self.environ.get(key)
        if val is None:
            if default is not None:
                return default
            raise ValueError(f"Missing required environment variable: {key}")
        try:
            loaded = json.loads(val)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON list in environment variable {key}: {val}") from e
        if not isinstance(loaded, list):
            raise ValueError(f"Invalid JSON list in environment variable {key}: {val}")
        return tuple(loaded)
