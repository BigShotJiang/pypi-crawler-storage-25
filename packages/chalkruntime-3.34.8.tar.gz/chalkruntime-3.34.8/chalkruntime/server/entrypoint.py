from __future__ import annotations

from chalk._gen.chalk.graph.v1.graph_pb2 import FunctionReferenceCapturedGlobal

# ruff: noqa: E402
# isort: off
# Do open telemetry auto instrument before everything else
from chalkruntime.utils.tracing import configure_tracing

configure_tracing("chalkruntime")
# isort: on

import asyncio
import functools
import gc
import io
import json
import logging
import os
import sys
import threading
import time
import traceback
import urllib.parse
from concurrent.futures import Future
from pathlib import Path
from typing import TYPE_CHECKING, Callable, TypeVar, cast

import boto3
import datadog
import google.auth
import google.auth.credentials
import google.cloud.storage
import pdb_attach
import uvloop
from chalk._gen.chalk.artifacts.v1 import export_pb2
from chalk._gen.chalk.artifacts.v1.export_pb2 import VALIDATION_LOG_SEVERITY_ERROR
from chalk._gen.chalk.common.v1 import chalk_error_pb2
from chalk._gen.chalk.graph.v2 import sources_pb2
from chalk._gen.chalk.python.v1 import types_pb2 as types_pb
from chalk._lsp.error_builder import LSPErrorBuilder
from chalk.client import ChalkError, ChalkException, ErrorCode, ErrorCodeCategory
from chalk.client.serialization.protos import ChalkErrorConverter
from chalk.features.hooks import Hook
from chalk.parsed._proto.export import export_from_registry, get_lsp_proto_or_error
from chalk.parsed._proto.utils import convert_failed_import_to_proto
from chalk.parsed.duplicate_input_gql import FailedImport
from chalk.parsed.to_proto import ToProtoConverter
from chalk.parsed.user_types_to_json import get_registered_types
from chalk.sql._internal.sql_source import BaseSQLSource
from chalk.streams import StreamSource
from chalk.utils.async_helpers import run_coroutine_fn_threadsafe
from chalk.utils.chalk_record_batch import FrozenOrderedSet
from chalk.utils.gcp_project_token import (
    GCPProjectToken,
    get_credentials_from_file_base64,
)
from chalk.utils.log_with_context import (
    add_logging_context,
    configure_logging,
    get_public_logger,
)
from chalk.utils.storage_client import StorageClient
from chalk.utils.threading import ChalkThreadPoolExecutor
from chalk.utils.tracing import safe_trace

from chalkruntime.graph.global_graph import set_global_graph
from chalkruntime.graph.protograph_deserializer import FromProtoConverter
from chalkruntime.graph.variables import get_variables
from chalkruntime.invoker.query_execution_parameters import (
    QueryExecutionParameterFactory,
)
from chalkruntime.loader.importer import (
    download_source,
    get_storage_client_from_bucket_uri,
    import_source,
    run_singleton_augmenter,
)
from chalkruntime.server.config import Config
from chalkruntime.server.service import ImportGraphResult, InvokerService
from chalkruntime.utils.datadog import get_datadog_kwargs

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential
    from azure.core.credentials_async import AsyncTokenCredential

    from libchalk.runtime.server import CppGrpcServer

T = TypeVar("T")

_logger = get_public_logger(__name__)

_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": True,
    "handlers": {
        "json": {"()": "chalkruntime.server.config.get_json_logging_handler"},
    },
    "loggers": {
        "chalk": {
            "level": "INFO",
        },
        "chalkruntime": {
            "level": "INFO",
        },
        "__main__": {
            "level": "INFO",
        },
        "datadog.dogstatsd": {
            # this mutes the test failures4
            "level": "ERROR"
        },
        "py.warnings": {"level": "WARNING"},
    },
    "root": {
        "handlers": ["json"],
    },
}  # TODO

_gc_start_times: dict[int, float] = {}


def _maybe_setup_gc_logging() -> None:
    if not os.environ.get("CHALK_GC_LOGGING"):
        return

    def gc_callback(phase: str, info: dict[str, int]) -> None:
        gen = info["generation"]
        assert isinstance(gen, int)
        if phase == "start":
            _gc_start_times[gen] = time.perf_counter()
        elif phase == "stop":
            dur = (time.perf_counter() - _gc_start_times.pop(gen, 0)) * 1000
            _logger.info(
                "GC gen=%s collected=%s uncollectable=%s duration=%.2fms",
                info["generation"],
                info["collected"],
                info["uncollectable"],
                dur,
            )

    gc.callbacks.append(gc_callback)
    _logger.info("GC logging callback installed (CHALK_GC_LOGGING is set)")


def get_gcs_token(config: Config):
    if config.ENGINE_GCS_CREDS_PATH is None:
        creds, gcp_project_id = google.auth.default()
        creds = cast("google.auth.credentials.Credentials | None", creds)
        if creds is not None:
            _logger.info("Using default gcp credentials")
            return GCPProjectToken(creds, gcp_project_id)
    else:
        _logger.info(f"Using GCP credentials from '{config.ENGINE_GCS_CREDS_PATH}'")
        return get_credentials_from_file_base64(config.ENGINE_GCS_CREDS_PATH)


def get_gcs_client(token_supplier: Callable[[], GCPProjectToken | None]):
    token = token_supplier()
    if token is None:
        raise ValueError("Failed to load gcp token; cannot construct gcs client")
    return google.cloud.storage.Client(
        credentials=token.credentials,
        project=token.project,
    )


@functools.lru_cache(None)
def s3_client_supplier():
    return boto3.client("s3")


def get_sync_azure_creds(cloud_provider: str) -> TokenCredential | None:
    if cloud_provider != "AZURE":
        return None

    from azure.identity import DefaultAzureCredential

    return DefaultAzureCredential()


def get_aio_azure_creds(cloud_provider: str) -> AsyncTokenCredential | None:
    if cloud_provider != "AZURE":
        return None

    from azure.identity.aio import DefaultAzureCredential

    return DefaultAzureCredential()


def _grpc_server_thread(grpc_query_server: CppGrpcServer, finished_event: Future[None]):
    try:
        grpc_query_server.wait()
    except BaseException as e:
        finished_event.set_exception(e)
    else:
        finished_event.set_result(None)


def _export_from_bucket(filename: str, storage_client: StorageClient) -> export_pb2.Export:
    """Download a pre-generated Export proto from cloud storage."""
    buf = io.BytesIO()
    storage_client.download_object(filename, buf)
    buf.seek(0)
    proto_export = export_pb2.Export()
    proto_export.ParseFromString(buf.read())
    return proto_export


def _import_and_validate_graph(
    file_allowlist_json: str | None,
    target_root: str | None,
    check_ignores_when_importing: bool,
    skip_run_hooks: bool,
    ignore_validation_errors: bool,
    loop: asyncio.AbstractEventLoop,
    proto_export_download_uri: str | None = None,
    proto_export_storage_client: StorageClient | None = None,
) -> ImportGraphResult:
    LSPErrorBuilder.lsp = True
    proto_export = export_pb2.Export()

    py_file_allowlist: list[str] | None = None
    sql_file_allowlist: list[str] | None = None
    if file_allowlist_json is not None:
        file_allowlist = json.loads(file_allowlist_json)
        if not isinstance(file_allowlist, dict):
            raise ValueError(f"Expected FILE_ALLOWLIST to be dict, got {file_allowlist_json}")
        if "python" not in file_allowlist or "sql" not in file_allowlist:
            raise ValueError(f"Expected FILE_ALLOWLIST to contain 'python' and 'sql', got {file_allowlist_json}")
        if not isinstance(file_allowlist["python"], list) or not isinstance(file_allowlist["sql"], list):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise ValueError(f"Expected FILE_ALLOWLIST values to be lists, got {file_allowlist_json}")
        py_file_allowlist = file_allowlist["python"]
        sql_file_allowlist = file_allowlist["sql"]

    _logger.info(
        f"Importing source from {target_root}, python allowlist: {py_file_allowlist and f'{len(py_file_allowlist)} items'}, sql allowlist: {sql_file_allowlist and f'{len(sql_file_allowlist)} items'}"
    )

    # 1. Import customer source files
    with safe_trace("import_source"):
        import_errors: list[FailedImport] = []
        try:
            import_errors = import_source(
                target_root=target_root,
                check_ignores=check_ignores_when_importing,
                py_file_allowlist=py_file_allowlist,
                sql_file_allowlist=sql_file_allowlist,
                augment_singletons=False,
                # We run the singleton augmenter manually after calling get_registered_types below
            )
        except Exception as e:
            if not LSPErrorBuilder.promote_exception(e):
                import_errors = [
                    FailedImport(
                        filename="",
                        module="",
                        traceback="".join(traceback.format_exception(e)),
                    )
                ]
    proto_export.failed.extend(convert_failed_import_to_proto(err) for err in import_errors)

    if len(import_errors) > 0:
        _logger.error("Not loading the graph due to import errors:")
        for err in import_errors:
            _logger.error(f"Error importing {err.filename}: {err.traceback}")
        return ImportGraphResult.make_failed(
            proto_export=proto_export,
        )
    # COMMENTED OUT: Don't exit early on LSP errors - we want to continue validation
    # to collect ALL errors, not just the first one found during import
    # if LSPErrorBuilder.has_errors() and not ignore_validation_errors:
    #     # (actual LSP errors will be logged later)
    #     _logger.error("Found LSP errors after importing graph; returning.")
    #     return ImportGraphResult.make_failed(
    #         proto_export=proto_export,
    #     )

    # TODO: ToProtoConverter doesn't produce as nice validation errors as the legacy "convert types to GQL" logic.
    # So, we run the gql conversion to collect any LSP errors then discard the result.
    # In the future we need to make ToProtoConverter's validation as good and get rid of the GQL types.
    with safe_trace("convert_registry_types_to_gql"):
        target_root_scope_to = Path(target_root).absolute() if target_root is not None else Path("/")
        try:
            _ = get_registered_types(scope_to=target_root_scope_to, failed=[])
        except Exception:
            _logger.warning(
                "Got exception when converting registry objects to GQL; Possibly due to validation errors.",
                exc_info=True,
            )
        if LSPErrorBuilder.has_errors() and not ignore_validation_errors:
            _logger.error("Found LSP validation errors when converting registry objects to GQL; returning.")
            return ImportGraphResult.make_failed(
                proto_export=proto_export,
            )

    with safe_trace("augment_singletons"):
        run_singleton_augmenter()

    if proto_export_download_uri is not None and proto_export_storage_client is not None:
        # 3. Download pre-generated Export proto from cloud storage, skipping export_from_registry.
        # Validation still runs below (unless ignore_validation_errors is set).
        _logger.info(f"Using pre-generated export proto from cloud storage: {proto_export_download_uri}")
        with safe_trace("export_from_bucket"):
            proto_export = _export_from_bucket(proto_export_download_uri, proto_export_storage_client)
    else:
        # 3. Extract raw features into proto graph from registry
        with safe_trace("export_from_registry"):
            proto_export = export_from_registry()

    if not ignore_validation_errors:
        # Check validation logs (from validate_artifacts)
        if any(x.severity >= VALIDATION_LOG_SEVERITY_ERROR for x in proto_export.logs):
            _logger.error("Not loading the graph due to Validation Log errors:")
            for l in proto_export.logs:
                if l.severity >= VALIDATION_LOG_SEVERITY_ERROR:
                    _logger.error("%s", l)
            return ImportGraphResult.make_failed(
                proto_export=proto_export,
            )

        # Check LSP diagnostics (includes underscore expression errors from supplement_diagnostics)
        # Note: supplement_diagnostics() adds underscore errors directly to proto_export.lsp.diagnostics,
        # NOT to LSPErrorBuilder.all_errors, so we need to check the proto directly.
        if proto_export.lsp and len(proto_export.lsp.diagnostics) > 0:
            has_lsp_errors = False
            for diagnostic_params in proto_export.lsp.diagnostics:
                for diagnostic in diagnostic_params.diagnostics:
                    # DiagnosticSeverity: 1=Error, 2=Warning, 3=Info, 4=Hint
                    if diagnostic.severity == 1:  # Error
                        has_lsp_errors = True
                        break
                if has_lsp_errors:
                    break

            if has_lsp_errors:
                _logger.error("Not loading the graph due to LSP errors in proto_export.lsp.diagnostics; returning.")
                return ImportGraphResult.make_failed(
                    proto_export=proto_export,
                )

        # Check LSPErrorBuilder (for errors added during validation_from_registries and convert_registry_types_to_gql)
        if LSPErrorBuilder.has_errors():
            # We'll log these later, just return here.
            _logger.error("Found LSP errors after exporting from registry; returning.")
            return ImportGraphResult.make_failed(
                proto_export=proto_export,
            )

    # 3. Parse features into ResolvedGraph
    with safe_trace("convert_graph_from_proto"):
        graph = FromProtoConverter.convert_graph(proto_export.graph)

    # 3.5. Return source secrets, but keep it separate from the export
    with safe_trace("get_source_secrets_from_registry"):
        source_secrets: dict[str, str] = {}
        for source in BaseSQLSource.registry:
            source_secrets |= source._recreate_integration_variables()  # pyright: ignore[reportPrivateUsage]
        for source in StreamSource.registry:
            source_secrets |= source._recreate_integration_variables()  # pyright: ignore[reportPrivateUsage]
        source_secrets_proto: sources_pb2.SourceSecrets = ToProtoConverter.convert_source_secrets(source_secrets)

    # 4. Run hooks (skip if CHALK_SKIP_RUN_HOOKS is set, e.g., for indexing jobs)
    if not skip_run_hooks:
        with safe_trace("run_hooks"):
            run_coroutine_fn_threadsafe(
                loop,
                Hook.async_run_all_before_all,
                os.environ.get("CHALK_ACTIVE_ENVIRONMENT", ""),
                os.environ.get("CHALK_ACTIVE_VENV_NAME", None),
            ).result()
    else:
        _logger.info("Skipping hooks because CHALK_SKIP_HOOKS is set")

    # 5. Capture explicit values of any function-captured global variables
    with safe_trace("get_function_capture_global_variable_values"):
        resolver_captured_global_variables: dict[bytes, types_pb.CodeVariable] = {}
        # Recursively collect variables from all captured globals, including those
        # nested inside helper functions (FunctionGlobalCapturedFunction).
        globals_to_visit: list[FunctionReferenceCapturedGlobal] = [
            glbl for r in proto_export.graph.resolvers for glbl in r.function.captured_globals
        ]
        while globals_to_visit:
            glbl = globals_to_visit.pop()
            if glbl.HasField("variable"):
                variable = types_pb.CodeVariable(name=glbl.variable.name, module=glbl.variable.module)
                resolver_captured_global_variables.setdefault(
                    variable.SerializeToString(deterministic=True),
                    variable,
                )
            elif glbl.HasField("function"):
                globals_to_visit.extend(glbl.function.captured_globals)
        variable_values = get_variables(resolver_captured_global_variables.values())

    return ImportGraphResult.make_successful(
        proto_export=proto_export,
        source_secrets=source_secrets_proto,
        graph=graph,
        captured_global_values=variable_values,
    )


async def import_and_validate_graph(
    file_allowlist_json: str | None,
    target_root: str | None,
    skip_run_hooks: bool,
    check_ignores_when_importing: bool,
    ignore_validation_errors: bool,
    proto_export_download_uri: str | None = None,
    proto_export_storage_client: StorageClient | None = None,
) -> ImportGraphResult:
    """
    Import custom source and validate/parse the graph.
    Any `Exception`'s (i.e. not BaseException) thrown will be caught and converted into a structured error
    in the proto Export.

    These parameters are passed in from the Config.
    :param file_allowlist_json:
    :param target_root:
    :param check_ignores_when_importing:
    :param ignore_validation_errors:

    :return: A tuple (proto Export, ResolvedGraph). The ResolvedGraph is None if any errors occurred while building the graph.
    """
    import_graph_results = ImportGraphResult.make_failed(proto_export=export_pb2.Export())
    try:
        try:
            # Importing/parsing can be expensive and is blocking, run it off of the event loop
            import_graph_results = await asyncio.to_thread(
                _import_and_validate_graph,
                file_allowlist_json=file_allowlist_json,
                target_root=target_root,
                skip_run_hooks=skip_run_hooks,
                check_ignores_when_importing=check_ignores_when_importing,
                ignore_validation_errors=ignore_validation_errors,
                loop=asyncio.get_running_loop(),
                proto_export_download_uri=proto_export_download_uri,
                proto_export_storage_client=proto_export_storage_client,
            )
        except Exception as e:
            if not LSPErrorBuilder.promote_exception(e):
                raise
        finally:
            if LSPErrorBuilder.has_errors():
                if not ignore_validation_errors:
                    _logger.error("Not loading the graph due to LSP errors.")
                    for uri, diagnostics in LSPErrorBuilder.all_errors.items():
                        for dd in diagnostics:
                            _logger.error("%s: %s", uri, dd)
                    import_graph_results = ImportGraphResult.make_failed(
                        proto_export=import_graph_results.proto_export,
                    )
            # We may have collected useful diagnostics, but thrown before we could serialize them into the proto.
            # So, we regenerate the LSP proto here.
            # (get_lsp_proto also converts FailedImports into LSP diagnostics)
            lsp, exc = get_lsp_proto_or_error(import_graph_results.proto_export.failed)
            import_graph_results.proto_export.lsp.CopyFrom(lsp)  # pyright: ignore[reportArgumentType]
            if exc is not None:
                err = ChalkError.create(
                    code=ErrorCode.INTERNAL_SERVER_ERROR,
                    category=ErrorCodeCategory.NETWORK,
                    message=f"Failed to generate LSP diagnostics: {exc.message}",
                    exception=exc,
                )
                import_graph_results.proto_export.conversion_errors.append(ChalkErrorConverter.chalk_error_encode(err))
    except Exception as e:
        # Catch-all for unhandled errors -- usually a bug in our feature validation or LSP serialization code.
        # We still want to make sure it makes it into the Export proto so the customer / our support can see the error.
        # Ideally any error due to a problem with customer code should be marked as an LSP error.
        err = ChalkError.create(
            code=ErrorCode.INTERNAL_SERVER_ERROR,
            category=ErrorCodeCategory.NETWORK,
            message=f"Failed to load feature graph: {e}",
            exception=ChalkException.from_exception(e),
        )
        serialized_error: chalk_error_pb2.ChalkError = ChalkErrorConverter.chalk_error_encode(err)
        _logger.error("Not loading graph due to unhandled exception.", exc_info=True)
        import_graph_results.proto_export.conversion_errors.append(serialized_error)

    return import_graph_results


def _load_secrets_from_file(secrets_path: str = "/var/run/chalk/secrets.env") -> bool:
    """
    Load secrets from a file into os.environ.

    The file should be in KEY=VALUE format, with support for:
    - Empty lines and comments (starting with #)
    - export KEY=VALUE format
    - Quoted values (single or double quotes)

    Returns True if the file exists and was processed, False otherwise.
    """
    if not os.path.exists(secrets_path):
        return False

    try:
        with open(secrets_path) as f:
            for line in f:
                line = line.strip()
                # Skip empty lines and comments
                if not line or line.startswith("#"):
                    continue
                # Handle 'export KEY=VALUE' format
                if line.startswith("export "):
                    line = line[7:]  # Remove 'export '
                # Parse KEY=VALUE
                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    # Remove quotes if present
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    elif value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]
                    os.environ[key] = value
        return True
    except Exception:
        # Can't use logger if called before logging is configured
        print(f"WARNING: Failed to load secrets from {secrets_path}", file=sys.stderr)
        traceback.print_exc()
        return False


def _propagate_trace_context_from_env_vars():
    try:
        from opentelemetry import context, propagate
    except ImportError:
        return

    from libchalk.runtime.server import (
        CHALK_OTEL_TRACEPARENT_ENV_VAR,
        CHALK_OTEL_TRACESTATE_ENV_VAR,
    )

    tracestate: str | None = os.environ.get(CHALK_OTEL_TRACESTATE_ENV_VAR)
    traceparent: str | None = os.environ.get(CHALK_OTEL_TRACEPARENT_ENV_VAR)
    if tracestate is None or traceparent is None:
        return
    headers: dict[str, str] = {"tracestate": tracestate, "traceparent": traceparent}
    env_context = propagate.get_global_textmap().extract(headers)
    if env_context:
        context.attach(env_context)


async def _entrypoint():
    #######################################
    # Step 0: Load secrets from CSI-mounted file if it exists
    #######################################
    secrets_loaded = _load_secrets_from_file()

    #######################################
    # Step 1: Configure logging and tracing
    #######################################
    configure_logging(_LOGGING_CONFIG)
    _maybe_setup_gc_logging()

    # Log secrets loading status now that logging is configured
    if secrets_loaded:
        _logger.info("Loaded secrets from /var/run/chalk/secrets.env")

    _propagate_trace_context_from_env_vars()

    with add_logging_context(
        deployment_id=os.environ.get("CHALK_DEPLOYMENT_ID"), branch_name=os.environ.get("CHALK_BRANCH_ID")
    ):
        with safe_trace("chalk.subprocess_actor.entrypoint"):
            settings = Config.from_environment()

            idle_mode = not settings.TARGET_ROOT or not settings.TARGET_ROOT.strip()
            if idle_mode:
                _logger.info("Starting subprocess in IDLE MODE (no TARGET_ROOT set)")
            else:
                _logger.info(f"Starting subprocess in NORMAL MODE with TARGET_ROOT: {settings.TARGET_ROOT}")

            # Start GRPC Server
            if settings.CHALK_PDB_ATTACH_PORT is not None:
                try:
                    pdb_attach.listen(settings.CHALK_PDB_ATTACH_PORT)
                except:
                    # Could fail because the port is in use or pdb_attach is not installed
                    _logger.error(
                        f"Failed to initialize `pdb-attach` on port {settings.CHALK_PDB_ATTACH_PORT}",
                        exc_info=True,
                    )
            resolver_executor = ChalkThreadPoolExecutor(settings.CHALK_PARALLEL_RESOLVER_THREADS)
            storage_client_executor = ChalkThreadPoolExecutor(settings.OFFLINE_STORAGE_MAX_CONCURRENT_UPLOADS)

            # using logic in engine/chalkengine/utils/datadog.py
            ddog_kwargs = get_datadog_kwargs(
                dd_dogstatsd_url=settings.DD_DOGSTATSD_URL,
                dd_agent_host=settings.DD_AGENT_HOST,
                statsd_port=settings.STATSD_PORT,
                cloud_provider=settings.CLOUD_PROVIDER,
            )
            _logger.info(f"Initializing datadog with kwargs: {ddog_kwargs}")
            datadog.initialize(**ddog_kwargs)
            logging.captureWarnings(True)

            gcp_token_supplier = functools.lru_cache(None)(functools.partial(get_gcs_token, settings))
            gcs_client_supplier = functools.lru_cache(None)(functools.partial(get_gcs_client, gcp_token_supplier))
            azure_creds_supplier = functools.lru_cache(None)(
                lambda: (
                    get_sync_azure_creds(settings.CLOUD_PROVIDER),
                    get_aio_azure_creds(settings.CLOUD_PROVIDER),
                )
            )

            if settings.PARQUET_PLAN_STAGES_STORAGE_BUCKET is None:
                parquet_plan_stages_storage_client = None
            else:
                parquet_plan_stages_storage_client = get_storage_client_from_bucket_uri(
                    settings.PARQUET_PLAN_STAGES_STORAGE_BUCKET,
                    storage_client_executor,
                    gcs_client_supplier=gcs_client_supplier,
                    s3_client_supplier=s3_client_supplier,
                    azure_creds_supplier=azure_creds_supplier,
                )

            # Only download source if not in idle mode
            if settings.CHALK_INVOKER_DOWNLOAD_SOURCE and not idle_mode:
                if settings.TARGET_ROOT is None:
                    _logger.error("Invoker server entrypoint not downloading source as the 'TARGET_ROOT' is not set")
                    sys.exit(1)
                elif settings.BUNDLE_SOURCE is None:
                    _logger.error("Invoker server entrypoint not downloading source as the 'BUNDLE_SOURCE' is not set")
                    sys.exit(1)
                else:
                    source_storage_client = get_storage_client_from_bucket_uri(
                        settings.BUNDLE_SOURCE,
                        storage_client_executor,
                        gcs_client_supplier=gcs_client_supplier,
                        s3_client_supplier=s3_client_supplier,
                        azure_creds_supplier=azure_creds_supplier,
                    )

                    url_split = urllib.parse.urlsplit(settings.BUNDLE_SOURCE)
                    filepath = url_split.path
                    if filepath.startswith("/"):
                        # Strip only the first slash
                        filepath = filepath[1:]
                    download_source(
                        filepath,
                        settings.TARGET_ROOT,
                        source_storage_client,
                    )
            else:
                _logger.info("Skipping source download (idle mode)")

            # Build a storage client for downloading the pre-built export proto, if needed.
            proto_export_storage_client: StorageClient | None = None
            if settings.CHALK_PROTO_EXPORT_DOWNLOAD_URI is not None and settings.BUNDLE_SOURCE is not None:
                proto_export_storage_client = get_storage_client_from_bucket_uri(
                    settings.BUNDLE_SOURCE,
                    storage_client_executor,
                    gcs_client_supplier=gcs_client_supplier,
                    s3_client_supplier=s3_client_supplier,
                    azure_creds_supplier=azure_creds_supplier,
                )

            from libchalk.runtime.server import CppGrpcServer, InvokerGrpcService, StreamingInvokerGrpcService

            ######################
            # Step 3: Prepare for graph loading
            ######################
            # Prepare file allowlist for graph loading
            file_allowlist_json = settings.FILE_ALLOWLIST
            if settings.FILE_ALLOWLIST_PATH is not None:
                if file_allowlist_json is not None:
                    _logger.warning("Both FILE_ALLOWLIST and FILE_ALLOWLIST_PATH provided, using FILE_ALLOWLIST")
                else:
                    with open(settings.FILE_ALLOWLIST_PATH) as f:
                        file_allowlist_json = f.read()

            ###########################
            # Step 4: Build the service
            ###########################
            with safe_trace("start_grpc_server"):
                query_exec_param_factory = QueryExecutionParameterFactory(
                    snowflake_unload_stage=settings.CHALK_SNOWFLAKE_UNLOAD_STAGE,
                    snowflake_storage_integration=settings.CHALK_SNOWFLAKE_STORAGE_INTEGRATION,
                    use_efficient_postgres_for_named_queries=FrozenOrderedSet(
                        settings.USE_EFFICIENT_POSTGRES_FOR_NAMED_QUERIES
                    ),
                    always_use_efficient_postgres_offline=settings.ALWAYS_USE_EFFICIENT_POSTGRES_OFFLINE,
                    use_polars_read_csv_for_named_queries=FrozenOrderedSet(
                        settings.USE_POLARS_READ_CSV_FOR_NAMED_QUERIES
                    ),
                    bigquery_unload_path=settings.CHALK_BIGQUERY_UNLOAD_PATH,
                    num_client_prefetch_threads=settings.CHALK_NUM_CLIENT_PREFETCH_THREADS,
                    max_prefetch_size_bytes=settings.CHALK_MAX_PREFETCH_SIZE_BYTES,
                    force_polars_read_csv=settings.CHALK_FORCE_POLARS_READ_CSV,
                    skip_pg_datetime_zone_cast=settings.CHALK_SKIP_PG_DATETIME_ZONE_CAST,
                    fallback_to_inefficient_execution=settings.CHALK_SQL_SOURCE_FALLBACK_TO_INEFFICIENT_EXECUTION,
                )
                service = InvokerService(
                    file_allowlist_json=file_allowlist_json,
                    target_root=settings.TARGET_ROOT,
                    check_ignores_when_importing=settings.CHECK_IGNORES_WHEN_IMPORTING,
                    ignore_validation_errors=settings.CHALK_TESTING_IGNORE_VALIDATION_ERRORS,
                    resolver_executor=resolver_executor,
                    query_exec_param_factory=query_exec_param_factory,
                    fallback_resource_hint=settings.CHALK_RESOLVER_DEFAULT_RESOURCE_HINT,
                    plan_stages_storage_client=parquet_plan_stages_storage_client,
                    is_idle=idle_mode,
                )

                if not idle_mode:
                    _logger.info("Starting customer code import and graph building")
                    with safe_trace("load_proto_graph_in_subprocess"):
                        startup_trace_path = os.environ.get("CHALK_VIZTRACER_STARTUP")
                        if startup_trace_path:
                            from chalkruntime.utils.viztracer_profiling import viztracer_context

                            with viztracer_context(startup_trace_path):
                                import_graph_results = await import_and_validate_graph(
                                    file_allowlist_json=file_allowlist_json,
                                    target_root=settings.TARGET_ROOT,
                                    skip_run_hooks=settings.CHALK_SKIP_RUN_HOOKS,
                                    check_ignores_when_importing=settings.CHECK_IGNORES_WHEN_IMPORTING,
                                    ignore_validation_errors=settings.CHALK_TESTING_IGNORE_VALIDATION_ERRORS,
                                    proto_export_download_uri=settings.CHALK_PROTO_EXPORT_DOWNLOAD_URI,
                                    proto_export_storage_client=proto_export_storage_client,
                                )
                        else:
                            import_graph_results = await import_and_validate_graph(
                                file_allowlist_json=file_allowlist_json,
                                target_root=settings.TARGET_ROOT,
                                skip_run_hooks=settings.CHALK_SKIP_RUN_HOOKS,
                                check_ignores_when_importing=settings.CHECK_IGNORES_WHEN_IMPORTING,
                                ignore_validation_errors=settings.CHALK_TESTING_IGNORE_VALIDATION_ERRORS,
                                proto_export_download_uri=settings.CHALK_PROTO_EXPORT_DOWNLOAD_URI,
                                proto_export_storage_client=proto_export_storage_client,
                            )
                        service.update_with_graph_result(import_graph_results)
                        if import_graph_results.successful_result is not None:
                            _logger.info("Successfully loaded graph.")
                            set_global_graph(import_graph_results.successful_result.graph)
                        elif not settings.CHALK_IGNORE_IMPORT_ERRORS:
                            _logger.error(
                                "Aborting due to graph load/validation errors and 'CHALK_IGNORE_IMPORT_ERRORS' is not set"
                            )
                            sys.exit(1)
                        # After this point we want to stop collecting LSP errors; we've already generated the graph and this saves some perf
                        # when running chalkpy code
                        LSPErrorBuilder.lsp = False

                    # Set up invocation tracer
                    invocation_trace_path = os.environ.get("CHALK_VIZTRACER_INVOCATIONS")
                    if invocation_trace_path:
                        from chalkruntime.utils.viztracer_profiling import TimedInvocationTracer

                        service.invocation_tracer = TimedInvocationTracer(invocation_trace_path)
                        service.invocation_tracer.start()

                    # Set up slow-call tracer
                    slow_call_ms = os.environ.get("CHALK_VIZTRACER_SLOW_CALL_MS")
                    slow_call_dir = os.environ.get("CHALK_VIZTRACER_SLOW_CALL_DIR", "/tmp/chalk_viztracer")
                    if slow_call_ms:
                        from chalkruntime.utils.viztracer_profiling import SlowCallTracer

                        service.slow_call_tracer = SlowCallTracer(int(slow_call_ms), slow_call_dir)
                        service.slow_call_tracer.start()
                else:
                    _logger.info("Skipping customer code import in idle mode")
                # Waiting for the grpc query server in a background thread
                _logger.info(f"Starting subprocess invoker server with uri '{settings.CHALK_INVOKER_SERVER_HOST_URI}'")
                grpc_service = InvokerGrpcService(service, settings.CHALK_INVOKER_SERVER_CONCURRENT_REQUESTS)
                streaming_grpc_service = StreamingInvokerGrpcService(
                    service, settings.CHALK_INVOKER_SERVER_CONCURRENT_REQUESTS
                )
                grpc_server = CppGrpcServer(
                    [grpc_service, streaming_grpc_service], settings.CHALK_INVOKER_SERVER_HOST_URI
                )
                fut: Future[None] = Future()
                grpc_server_thread = threading.Thread(
                    target=_grpc_server_thread,
                    args=(grpc_server, fut),
                )
                grpc_server_thread.start()

                _logger.info(
                    f"Subprocess invoker server is booted; running forever until shutdown (idle_mode: {idle_mode})"
                )

        await asyncio.wrap_future(fut)
        # Should be ~instant, because we waited for the future
        grpc_server_thread.join()


def main():
    uvloop.install()
    asyncio.run(_entrypoint())


if __name__ == "__main__":
    main()
