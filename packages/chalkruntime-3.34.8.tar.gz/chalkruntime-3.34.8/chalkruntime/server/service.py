from __future__ import annotations

import asyncio
import dataclasses
import functools
import os
import pdb
import signal
import sys
import time
import types
from datetime import datetime, timezone
from threading import Lock
from typing import TYPE_CHECKING, Iterable

from chalk import ChalkContext
from chalk._gen.chalk.artifacts.v1 import export_pb2
from chalk._gen.chalk.graph.v1 import graph_pb2
from chalk._gen.chalk.graph.v2 import sources_pb2
from chalk._gen.chalk.python.v1 import types_pb2
from chalk._gen.chalk.runtime.v1 import (
    python_streaming_resolver_invoker_service_pb2 as streaming_pb2,
)
from chalk.features.resolver import ResourceHint
from chalk.parsed.branch_state import BranchGraphSummary
from chalk.utils.async_helpers import run_coroutine_fn_threadsafe
from chalk.utils.log_with_context import add_logging_context, get_logger, get_operation_log_context
from chalk.utils.storage_client import StorageClient
from chalk.utils.threading import ChalkThreadPoolExecutor

from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.graph_state import GraphState
from chalkruntime.graph.overlay_graph import OverlayGraphInfo, OverlayGraphService

# from chalkruntime.graph.overlay_graph import OverlayGraphInfo
from chalkruntime.invoker.bound_invoker import InvokerConfig, InvokerContext
from chalkruntime.invoker.bound_invoker_cache import ResolverInvokerCache
from chalkruntime.invoker.no_arg_scalar_invoker import NoArgScalarBoundInvoker
from chalkruntime.invoker.one_to_one_invoker import ParallelResolverInvoker
from chalkruntime.invoker.query_execution_parameters import QueryExecutionParameterFactory
from chalkruntime.invoker.resolver_input import LocalResolverInputs
from chalkruntime.invoker.resolver_result import BatchResolverResult
from chalkruntime.server.config import Config
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter

if TYPE_CHECKING:
    from chalkruntime.utils.viztracer_profiling import SlowCallTracer, TimedInvocationTracer
    from libchalk.runtime.server import ResultHandler


_logger = get_logger(__name__)


def handler(sig: int, frame: types.FrameType | None) -> None:
    pdb.set_trace()


try:
    signal.signal(signal.SIGUSR2, handler)
except ValueError:
    # signal.signal() only works in the main thread of the main interpreter
    pass


@dataclasses.dataclass(kw_only=True, slots=True)
class ImportGraphResultSuccessful:
    """
    This object is only created if the subprocess successfully loaded & validated the feature graph and relevant data.
    """

    graph: ResolvedGraph
    source_secrets: sources_pb2.SourceSecrets
    captured_global_values: Iterable[types_pb2.CodeVariableValue]


@dataclasses.dataclass(kw_only=True, slots=True)
class ImportGraphResult:
    """
    proto_export contains any import/validation errors that occurred.
    If there are no errors, `successful_result` contains the graph & other data.
    """

    proto_export: export_pb2.Export
    successful_result: ImportGraphResultSuccessful | None

    @staticmethod
    def make_successful(
        proto_export: export_pb2.Export,
        graph: ResolvedGraph,
        source_secrets: sources_pb2.SourceSecrets,
        captured_global_values: Iterable[types_pb2.CodeVariableValue],
    ) -> ImportGraphResult:
        return ImportGraphResult(
            proto_export=proto_export,
            successful_result=ImportGraphResultSuccessful(
                graph=graph, source_secrets=source_secrets, captured_global_values=captured_global_values
            ),
        )

    @staticmethod
    def make_failed(
        proto_export: export_pb2.Export,
    ) -> ImportGraphResult:
        return ImportGraphResult(proto_export=proto_export, successful_result=None)


class _InvokerServiceState:
    """
    State maintained by the invoker service if and only if the graph was succesfully loaded.
    """

    def __init__(
        self,
        *,
        proto_graph: graph_pb2.Graph,
        results: ImportGraphResultSuccessful,
        invoker_cache: ResolverInvokerCache,
    ):
        super().__init__()
        self.results = results
        self.global_variables = types_pb2.GlobalVariablesInfo(
            code_variables=results.captured_global_values,
            environment_variables={},
        )
        self.overlay_graph_service = OverlayGraphService(
            base_proto_graph=proto_graph,
            base_graph=self.results.graph,
            base_proto_source_secrets=self.results.source_secrets,
        )
        self.invoker_cache = invoker_cache
        self.invoker_cache_lock = Lock()


class InvokerService:
    def __init__(
        self,
        *,
        file_allowlist_json: str | None,
        target_root: str | None,
        check_ignores_when_importing: bool,
        ignore_validation_errors: bool,
        query_exec_param_factory: QueryExecutionParameterFactory,
        resolver_executor: ChalkThreadPoolExecutor,
        fallback_resource_hint: ResourceHint,
        plan_stages_storage_client: StorageClient | None,
        is_idle: bool = False,
    ):
        super().__init__()

        self._export: export_pb2.Export = export_pb2.Export()

        self.loop = asyncio.get_running_loop()

        # Track if this is an idle actor (explicitly passed from entrypoint)
        self._is_idle = is_idle

        # Store constructor parameters for graph loading
        self._file_allowlist_json = file_allowlist_json
        self._target_root = target_root
        self._check_ignores_when_importing = check_ignores_when_importing
        self._ignore_validation_errors = ignore_validation_errors
        self._query_exec_param_factory = query_exec_param_factory
        self._resolver_executor = resolver_executor
        self._fallback_resource_hint: ResourceHint = fallback_resource_hint
        self._plan_stages_storage_client = plan_stages_storage_client

        # State is null until graph is loaded via initialize_with_mainline or initialize_with_deployment
        self._state: _InvokerServiceState | None = None

        # Optional viztracer profiling (set from entrypoint if env vars are configured)
        self.invocation_tracer: TimedInvocationTracer | None = None
        self.slow_call_tracer: SlowCallTracer | None = None

    def _get_state(self) -> _InvokerServiceState:
        if self._state is None:
            if self._is_idle:
                raise RuntimeError(
                    "Graph is not loaded because this is an idle actor waiting for deployment initialization. Use initialize_with_deployment() to load customer code first, or use get_protograph_export_bytes() to get the current (empty) export."
                )
            else:
                raise RuntimeError(
                    "Graph is not loaded in this actor, likely due to import/validation errors at load time. Caller should use `get_protograph_export_bytes()` to get more information about the state of the graph, including LSP errors."
                )
        return self._state

    def _get_results(self) -> ImportGraphResultSuccessful:
        return self._get_state().results

    def get_protograph_export_bytes(self) -> bytes:
        try:
            result = self._export.SerializeToString()
            _logger.debug(f"Serialized export to {len(result)} bytes")
            return result
        except Exception as e:
            _logger.error(f"Failed to serialize export: {e}", exc_info=True)
            # Return empty export as fallback
            from chalk._gen.chalk.artifacts.v1 import export_pb2

            empty_export = export_pb2.Export()
            # Add the serialization error as a conversion error
            from chalk.client import ChalkError, ChalkException, ErrorCode, ErrorCodeCategory
            from chalk.client.serialization.protos import ChalkErrorConverter

            err = ChalkError.create(
                code=ErrorCode.INTERNAL_SERVER_ERROR,
                category=ErrorCodeCategory.NETWORK,
                message=f"Failed to serialize graph export: {e}",
                exception=ChalkException.from_exception(e),
            )
            empty_export.conversion_errors.append(ChalkErrorConverter.chalk_error_encode(err))
            return empty_export.SerializeToString()

    def get_source_secrets_bytes(self) -> bytes:
        if self._state is None:
            return sources_pb2.SourceSecrets().SerializeToString()
        return self._get_results().source_secrets.SerializeToString()

    def has_graph(self) -> bool:
        return self._state is not None

    def has_source_secrets(self) -> bool:
        return self._state is not None

    def has_global_variables(self) -> bool:
        return self._state is not None

    def initialize_with_deployment(
        self, *, target_root: str, environment_id: str, deployment_id: str, branch_id: str
    ) -> ImportGraphResult:
        """Initialize an idle actor with deployment-specific configuration.
        Returns the ImportGraphResult containing the loaded graph or any errors.
        """
        if not self._is_idle:
            raise RuntimeError("Cannot initialize non-idle actor")

        os.environ["TARGET_ROOT"] = target_root
        os.environ["CHALK_DEPLOYMENT_ID"] = deployment_id
        _logger.info(f"Initializing idle actor with deployment {deployment_id}, target_root: {target_root}")
        settings = Config.from_environment()
        # Update logging context with deployment information
        with add_logging_context(deployment_id=deployment_id, branch_name=branch_id):
            from chalkruntime.server.entrypoint import import_and_validate_graph  # noqa: PLC0415

            try:
                import_result = run_coroutine_fn_threadsafe(
                    self.loop,
                    import_and_validate_graph,
                    file_allowlist_json=None,  # No allowlist for branch deployments
                    target_root=target_root,
                    skip_run_hooks=settings.CHALK_SKIP_RUN_HOOKS,
                    check_ignores_when_importing=settings.CHECK_IGNORES_WHEN_IMPORTING,
                    ignore_validation_errors=settings.CHALK_TESTING_IGNORE_VALIDATION_ERRORS,
                ).result()

                self.update_with_graph_result(import_result)

                return import_result
            except Exception as e:
                from chalk._gen.chalk.artifacts.v1 import export_pb2

                from chalkruntime.server.service import ImportGraphResult

                failed_export = export_pb2.Export()
                from chalk.client import ChalkError, ChalkException, ErrorCode, ErrorCodeCategory
                from chalk.client.serialization.protos import ChalkErrorConverter

                err = ChalkError.create(
                    code=ErrorCode.INTERNAL_SERVER_ERROR,
                    category=ErrorCodeCategory.NETWORK,
                    message=f"Actor initialization failed: {e}",
                    exception=ChalkException.from_exception(e),
                )
                failed_export.conversion_errors.append(ChalkErrorConverter.chalk_error_encode(err))
                import_result = ImportGraphResult.make_failed(proto_export=failed_export)
                self.update_with_graph_result(import_result)
                return import_result

    def update_with_graph_result(self, import_result: ImportGraphResult) -> None:
        """Update service state with a loaded graph result."""
        if import_result.successful_result is not None:
            invoker_cache = ResolverInvokerCache(
                graph=import_result.successful_result.graph,
                plan_stages_storage_client=self._plan_stages_storage_client,
                fallback_resource_hint=self._fallback_resource_hint,
                resolver_executor=self._resolver_executor,
                query_exec_param_factory=self._query_exec_param_factory,
            )
            self._state = _InvokerServiceState(
                proto_graph=import_result.proto_export.graph,
                results=import_result.successful_result,
                invoker_cache=invoker_cache,
            )
            self._is_idle = False
        self._export = import_result.proto_export

    def get_global_variables_bytes(self) -> bytes:
        if self._state is None:
            raise RuntimeError(
                "Cannot get global variables: the deployment has likely not been initialized as InvokerServiceState is None"
            )
        return self._get_state().global_variables.SerializeToString()

    def get_graph(self, overlay_proto_and_key: tuple[graph_pb2.OverlayGraph, str] | None = None) -> ResolvedGraph:
        info = self.get_overlay_graph_info(overlay_proto_and_key)
        if info is None:
            return self._get_results().graph
        return info.graph

    def get_overlay_graph_info(
        self, overlay_proto_and_key: tuple[graph_pb2.OverlayGraph, str] | None = None
    ) -> OverlayGraphInfo | None:
        if overlay_proto_and_key is None:
            return None
        proto, key = overlay_proto_and_key
        if not proto:
            return None
        return self._get_state().overlay_graph_service.get_graph_for_query(proto, key)

    @functools.cache
    def get_graph_gql_serialized(self) -> str:
        self._get_state()
        graph_gql = GraphState.get_upsert_graph_gql()
        return BranchGraphSummary(
            # We only really care about the graph here
            current_graph_gql=graph_gql,
            # if we had any import errors, self._maybe_graph would have been none and we would have raised above. This is fine for now,
            # frontend should look at export proto to see what's up
            import_errors=[],
            # Fields below are only used for live resolver/feature updates, which  currently are not implemented.
            blob_history=[],
            blob_feature_classes=set(),
            blob_resolvers=set(),
            # TODO -- confirm that this has a good default in the front-end
            deployment_created=None,
        ).to_json()  # pyright: ignore[reportAttributeAccessIssue]

    def unary_invoke(
        self,
        batch: LocalResolverInputs,
        query_rewriter: QueryRewriter,
        invoker_config: InvokerConfig,
        invoker_context: InvokerContext,
        overlay_graph_info: OverlayGraphInfo | None,
    ) -> BatchResolverResult:
        t0 = time.monotonic()
        res = self._unary_invoke(
            batch, query_rewriter, invoker_config, invoker_context, overlay_graph_info=overlay_graph_info
        )
        elapsed = time.monotonic() - t0
        if self.slow_call_tracer is not None:
            self.slow_call_tracer.log_invoke(batch.resolver_fqns, elapsed)
            self.slow_call_tracer.check_and_dump(batch.resolver_fqns, elapsed)
        return res

    def _unary_invoke(
        self,
        batch: LocalResolverInputs,
        query_rewriter: QueryRewriter,
        invoker_config: InvokerConfig,
        invoker_context: InvokerContext,
        overlay_graph_info: OverlayGraphInfo | None,
    ) -> BatchResolverResult:
        invoker_cache = self._get_state().invoker_cache
        with add_logging_context(
            **get_operation_log_context(
                operation_id=invoker_config.operation_id,
                operation_kind=invoker_config.operation_kind,
                resolver_fqn="<multiple_resolvers>"
                if len(batch.resolver_fqns) != 1
                else next(iter(batch.resolver_fqns)),
                correlation_id=invoker_config.correlation_id,
            )
        ):
            with self._get_state().invoker_cache_lock:
                invoker = invoker_cache.get_invoker(
                    resolver_fqns=frozenset(batch.resolver_fqns),
                    use_one_to_one_invoker=invoker_context.use_one_to_one_invoker,
                    query_name=invoker_config.query_name,
                    query_tags=invoker_config.query_tags,
                    overlay_graph_info=overlay_graph_info,
                )

            with ChalkContext._set_context(invoker_config.query_context):  #  pyright: ignore[reportPrivateUsage]
                if isinstance(invoker, ParallelResolverInvoker):
                    return invoker.sync_call(
                        batch=batch, rewriter=query_rewriter, config=invoker_config, loop=self.loop
                    )
                elif isinstance(invoker, NoArgScalarBoundInvoker):
                    return run_coroutine_fn_threadsafe(
                        self.loop,
                        invoker.single_call,
                        batch=batch,
                        config=invoker_config,
                        rewriter=query_rewriter,
                    ).result()
                else:

                    async def return_only_batch() -> BatchResolverResult:
                        iterator = aiter(invoker(batch, invoker_config, query_rewriter, invoker_context))
                        first_batch = await anext(iterator, None)
                        if first_batch is None:
                            return BatchResolverResult(
                                data=None,
                                result_collector_num_rows=0,
                                ran_at=datetime.now(timezone.utc),
                                errors=[],
                                num_successful_invocations=0,
                                num_failed_invocations=0,
                                num_skipped_invocations=0,
                                num_resolver_timeouts=0,
                                resolver_invocation_secs=0.0,
                            )
                        second_batch = await anext(iterator, None)
                        if second_batch is not None:
                            raise RuntimeError(
                                f"unary_invoke was called on resolver '{batch.resolver_fqns}' which yielded at least two batches"
                            )
                        return first_batch

                    return run_coroutine_fn_threadsafe(
                        self.loop,
                        return_only_batch,
                    ).result()

    def stream_invoke(
        self,
        result_handler: ResultHandler[BatchResolverResult],
        batch: LocalResolverInputs,
        query_rewriter: QueryRewriter,
        invoker_config: InvokerConfig,
        invoker_context: InvokerContext,
        overlay_graph_info: OverlayGraphInfo | None,
    ) -> None:
        _logger.debug("Received stream invoke request inside python")
        invoker_cache = self._get_state().invoker_cache
        with add_logging_context(
            **get_operation_log_context(
                operation_id=invoker_config.operation_id,
                operation_kind=invoker_config.operation_kind,
                resolver_fqn="<multiple_resolvers>"
                if len(batch.resolver_fqns) != 1
                else next(iter(batch.resolver_fqns)),
                correlation_id=invoker_config.correlation_id,
            )
        ):
            _logger.debug("Handling stream invoke call for resolvers %s", str(batch.resolver_fqns))
            with self._get_state().invoker_cache_lock:
                invoker = invoker_cache.get_invoker(
                    resolver_fqns=frozenset(batch.resolver_fqns),
                    query_name=invoker_config.query_name,
                    use_one_to_one_invoker=invoker_context.use_one_to_one_invoker,
                    query_tags=invoker_config.query_tags,
                    overlay_graph_info=overlay_graph_info,
                )

            async def task():
                try:
                    with ChalkContext._set_context(invoker_config.query_context):  # pyright: ignore[reportPrivateUsage]
                        async for b in invoker(batch, invoker_config, query_rewriter, invoker_context):
                            _logger.debug("Calling result handler")
                            await asyncio.wrap_future(result_handler(b))
                finally:
                    ans = sys.exc_info()[1]
                    _logger.debug(f"Calling result handler with {ans}")
                    await asyncio.wrap_future(result_handler(ans))

            # OK to fire and forget
            run_coroutine_fn_threadsafe(self.loop, task)

    def invoke_streaming_resolver_in_batch(
        self,
        request: streaming_pb2.InvokeResolverInBatchOnlyRequest,
    ) -> streaming_pb2.InvokeResolverInBatchOnlyResponse:
        """Server-side handler for PythonStreamingResolverInvokerService.InvokeResolverInBatchOnly.

        State is intentionally not supported, so the request has no state field; if a
        resolver requires state the kernel raises a FatalResolverError that is surfaced
        per-message in the response.
        """
        from chalkruntime.streaming.streaming_invoker_kernel.local_streaming_invoker_kernel import (  # noqa: PLC0415
            LocalStreamingResolverInvokerKernel,
        )

        state = self._get_state()
        with add_logging_context(
            **get_operation_log_context(
                operation_id=request.operation_id,
                operation_kind="streaming",
                resolver_fqn=request.resolver_fqn,
                correlation_id=None,
            )
        ):
            kernel = LocalStreamingResolverInvokerKernel(
                graph=state.results.graph,
                log_invalid_messages=False,
                environment_id=os.environ.get("CHALK_ACTIVE_ENVIRONMENT", ""),
            )
            return kernel.invoke(request)
