import dataclasses
import logging
import sys
from typing import Literal, Optional, cast

from chalk.features.resolver import ResourceHint
from chalk.utils.log_with_context import get_json_logging_formatter
from chalk.utils.threading import DESIRED_CPU_PARALLELISM

from chalkruntime.server.env_helper import Env


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Config:
    TARGET_ROOT: Optional[str]

    FILE_ALLOWLIST: Optional[str]
    """JSON encoded list of python and sql files to import e.x. {'python': [...], 'sql': [...]}"""

    FILE_ALLOWLIST_PATH: Optional[str]
    """Path to local file containing FILE_ALLOWLIST, since it may be too large to pass as an env var"""

    CHECK_IGNORES_WHEN_IMPORTING: bool
    """Whether we want to check our .gitignore and .chalkignore files when importing from TARGET_ROOT"""

    CHALK_RESOLVER_DEFAULT_RESOURCE_HINT: ResourceHint
    """Default resource hint for resolvers, if not otherwise specified. Defaults to io-bound, meaning that resolvers will be executed in a thread pool or asyncio task."""

    CHALK_PARALLEL_RESOLVER_THREADS: int
    """Number of threads to use for running resolvers in parallel. Ideally we'd know whether a resolver is GIL-bound (in which case 1 is the optimal number), CPU non-GIL bound
    (in which case you want OMP_NUM_THREADS), or IO-bound (which can be arbitrarily high). We will set to 32 because most resolvers are io-bound"""

    CHALK_INVOKER_SERVER_HOST_URI: str
    """URI to bind the server. Set by the spawning process"""

    CHALK_INVOKER_SERVER_CONCURRENT_REQUESTS: int
    """Number of concurrent requests which can be processed by the invoker server. Set by the spawning process"""

    CHALK_INVOKER_DOWNLOAD_SOURCE: bool
    """Whether or not to download source. Used for standalone"""

    BUNDLE_SOURCE: Optional[str]
    """Source Bundle URI"""

    CHALK_SNOWFLAKE_UNLOAD_STAGE: Optional[str]
    """The name of the Snowflake stage to use for unloading data. When using native sql, this must be a stage created by CREATE STAGE: an external location will not suffice."""

    CHALK_SNOWFLAKE_STORAGE_INTEGRATION: Optional[str]
    """The name of the Snowflake storage integration to use for unloading data. Applicbale only when the unload stage is set to a cloud resource directly instead of a Snowflake-maintained stage."""

    CHALK_SNOWFLAKE_UNLOAD_URI: Optional[str]
    """The name of the URI to which the Snowflake stage unloads data. Must mirror the settings of the stage in CHALK_SNOWFLAKE_UNLOAD_STAGE. Used by the metaplanner's unload resolver jobs."""

    ALWAYS_USE_EFFICIENT_POSTGRES_OFFLINE: bool
    CHALK_SKIP_PG_DATETIME_ZONE_CAST: bool
    CHALK_SQL_SOURCE_FALLBACK_TO_INEFFICIENT_EXECUTION: bool
    """
    By default we fallback to 'inefficient' execution for SQL sources. Eventually I'd like to make this False and hard-error, since usually falling back
    masks a real error and causes a hang / is intolerably slow so is a failure anyway, from the customer's point of view.

    As far as I can tell the only 'valid' reasons for falling back is when we don't have permissions in the customer's env to create a temporary sql table used for unloading data.
    """

    USE_EFFICIENT_POSTGRES_FOR_NAMED_QUERIES: tuple[str, ...]
    """
    If true, use the efficient postgres query engine for the named queries in this set.
    Supports strings and regexes"""

    USE_POLARS_READ_CSV_FOR_NAMED_QUERIES: tuple[str, ...]
    """If true, use pl.read_csv for the named queries in this set when executing an 'efficient'
    postgres query. Supports strings and regexes"""

    CHALK_BIGQUERY_UNLOAD_PATH: Optional[str]
    """The path (i.e. gs://foo/bar) to use for unloading data for large bigquery source queries"""

    CHALK_MAX_PREFETCH_SIZE_BYTES: int
    """Maximum  number of bytes to prefetch"""

    CHALK_NUM_CLIENT_PREFETCH_THREADS: int
    """Number of threads to use for SQL result prefetching"""

    CHALK_FORCE_POLARS_READ_CSV: bool

    PARQUET_PLAN_STAGES_STORAGE_BUCKET: str | None

    ENGINE_GCS_CREDS_PATH: str | None
    DD_AGENT_HOST: str
    STATSD_PORT: int
    DD_DOGSTATSD_URL: str | None
    """Socket path for redis lightning statsd"""

    STATSD_MAXUDPSIZE: int
    """Taken from dogstatsd source to avoid private import"""

    STATSD_FLUSH_INTERVAL_MS: int
    """Taken from dogstatsd source to avoid private import"""

    CLOUD_PROVIDER: Literal["AWS", "GCP", "AZURE"]
    """Cloud provider, GCP / AWS / AZURE"""

    OFFLINE_STORAGE_MAX_CONCURRENT_UPLOADS: int

    CHALK_PDB_ATTACH_PORT: int | None
    """Port for pdb-attach. useful for debugging"""

    CHALK_SKIP_RUN_HOOKS: bool
    """Whether to run before_all hooks in customer source code."""

    CHALK_IGNORE_IMPORT_ERRORS: bool
    """
    Whether to ignore import/graph errors when starting up. If set to True and the deployment has errors,
    the actor will start up without a valid graph so that clients can get a list of import errors / graph
    validation errors.
    """

    CHALK_TESTING_IGNORE_VALIDATION_ERRORS: bool
    """If true, proceeds to load the graph despite validation errors, if possible. Used for tests."""

    CHALK_PROTO_EXPORT_DOWNLOAD_URI: Optional[str]
    """If set, download a pre-generated Export proto created by the index-deployment step in the build from this path in the source bundle bucket instead of running export_from_registry."""

    @staticmethod
    def from_environment() -> "Config":
        env = Env(case_insensitive=True)
        return Config(
            TARGET_ROOT=env.string_optional("TARGET_ROOT"),
            FILE_ALLOWLIST=env.string_optional("FILE_ALLOWLIST"),
            FILE_ALLOWLIST_PATH=env.string_optional("FILE_ALLOWLIST_PATH"),
            CHALK_SKIP_RUN_HOOKS=env.boolean("CHALK_SKIP_RUN_HOOKS", default=False),
            CHECK_IGNORES_WHEN_IMPORTING=env.boolean("CHECK_IGNORES_WHEN_IMPORTING", default=True),
            CHALK_RESOLVER_DEFAULT_RESOURCE_HINT=cast(
                ResourceHint,
                env.string(
                    "CHALK_RESOLVER_DEFAULT_RESOURCE_HINT",
                    default="io",
                    one_of=("io", "cpu"),
                ),
            ),
            CHALK_PARALLEL_RESOLVER_THREADS=env.integer("CHALK_PARALLEL_RESOLVER_THREADS", default=32),
            CHALK_INVOKER_SERVER_HOST_URI=env.string("CHALK_INVOKER_SERVER_HOST_URI"),
            CHALK_INVOKER_SERVER_CONCURRENT_REQUESTS=env.integer("CHALK_INVOKER_SERVER_CONCURRENT_REQUESTS", default=1),
            CHALK_INVOKER_DOWNLOAD_SOURCE=env.boolean("CHALK_INVOKER_DOWNLOAD_SOURCE", default=False),
            BUNDLE_SOURCE=env.string_optional("BUNDLE_SOURCE"),
            CHALK_SNOWFLAKE_UNLOAD_STAGE=env.string_optional("CHALK_SNOWFLAKE_UNLOAD_STAGE"),
            CHALK_SNOWFLAKE_STORAGE_INTEGRATION=env.string_optional("CHALK_SNOWFLAKE_STORAGE_INTEGRATION"),
            CHALK_SNOWFLAKE_UNLOAD_URI=env.string_optional("CHALK_SNOWFLAKE_UNLOAD_URI"),
            ALWAYS_USE_EFFICIENT_POSTGRES_OFFLINE=env.boolean("ALWAYS_USE_EFFICIENT_POSTGRES_OFFLINE", default=False),
            CHALK_SKIP_PG_DATETIME_ZONE_CAST=env.boolean("CHALK_SKIP_PG_DATETIME_ZONE_CAST", default=False),
            CHALK_SQL_SOURCE_FALLBACK_TO_INEFFICIENT_EXECUTION=env.boolean(
                "CHALK_SQL_SOURCE_FALLBACK_TO_INEFFICIENT_EXECUTION", default=False
            ),
            USE_EFFICIENT_POSTGRES_FOR_NAMED_QUERIES=env.string_tuple(
                "USE_EFFICIENT_POSTGRES_FOR_NAMED_QUERIES", default=()
            ),
            USE_POLARS_READ_CSV_FOR_NAMED_QUERIES=env.string_tuple("USE_POLARS_READ_CSV_FOR_NAMED_QUERIES", default=()),
            CHALK_BIGQUERY_UNLOAD_PATH=env.string_optional("CHALK_BIGQUERY_UNLOAD_PATH"),
            CHALK_MAX_PREFETCH_SIZE_BYTES=env.integer("CHALK_MAX_PREFETCH_SIZE_BYTES", default=1073741824),
            CHALK_NUM_CLIENT_PREFETCH_THREADS=env.integer("CHALK_NUM_CLIENT_PREFETCH_THREADS", default=16),
            CHALK_FORCE_POLARS_READ_CSV=env.boolean("CHALK_FORCE_POLARS_READ_CSV", default=False),
            PARQUET_PLAN_STAGES_STORAGE_BUCKET=env.string_optional("PARQUET_PLAN_STAGES_STORAGE_BUCKET"),
            ENGINE_GCS_CREDS_PATH=env.string_optional("ENGINE_GCS_CREDS_PATH"),
            DD_AGENT_HOST=env.string("DD_AGENT_HOST", default="127.0.0.1"),
            STATSD_PORT=env.integer("STATSD_PORT", default=8125),
            DD_DOGSTATSD_URL=env.string_optional("DD_DOGSTATSD_URL"),
            STATSD_MAXUDPSIZE=env.integer("STATSD_MAXUDPSIZE", default=1432),
            STATSD_FLUSH_INTERVAL_MS=env.integer("STATSD_FLUSH_INTERVAL_MS", default=int(0.3 * 1000)),
            CLOUD_PROVIDER=cast(
                Literal["AWS", "GCP", "AZURE"],
                env.string(
                    "CLOUD_PROVIDER",
                    default="GCP",
                    one_of=("AWS", "GCP", "AZURE"),
                ),
            ),
            OFFLINE_STORAGE_MAX_CONCURRENT_UPLOADS=env.integer(
                "BQ_MAX_CONCURRENT_UPLOADS",
                default=max(DESIRED_CPU_PARALLELISM, 32),
            ),
            CHALK_PDB_ATTACH_PORT=env.integer_optional("CHALK_PDB_ATTACH_PORT"),
            CHALK_IGNORE_IMPORT_ERRORS=env.boolean("CHALK_IGNORE_IMPORT_ERRORS", default=False),
            CHALK_TESTING_IGNORE_VALIDATION_ERRORS=env.boolean("CHALK_TESTING_IGNORE_VALIDATION_ERRORS", default=False),
            CHALK_PROTO_EXPORT_DOWNLOAD_URI=env.string_optional("CHALK_PROTO_EXPORT_DOWNLOAD_URI"),
        )


def get_json_logging_handler() -> logging.Handler:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(get_json_logging_formatter())
    return handler
