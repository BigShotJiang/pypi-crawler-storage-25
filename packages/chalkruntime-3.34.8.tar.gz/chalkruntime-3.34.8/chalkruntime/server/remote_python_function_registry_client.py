"""Client for registering Python functions with a remote RemotePythonFunctionRegistryService."""

from __future__ import annotations

from typing import Any, Callable

import cloudpickle
import grpc
from chalkengine.gen.chalk.pyruntime.v1 import (  # pyright: ignore[reportMissingImports]
    remote_python_function_registry_pb2 as registry_pb2,
)
from chalkengine.gen.chalk.pyruntime.v1 import (  # pyright: ignore[reportMissingImports]
    remote_python_function_registry_pb2_grpc as registry_pb2_grpc,
)


class RemotePythonFunctionRegistryClient:
    """Client for remotely registering Python functions via gRPC.

    This client serializes Python functions using cloudpickle and sends them
    to a remote RemotePythonFunctionRegistryService for registration.
    """

    def __init__(self, channel: grpc.Channel) -> None:  # pyright: ignore[reportAttributeAccessIssue]
        """Initialize the client.

        Args:
            channel: gRPC channel connected to the RemotePythonFunctionRegistryService
        """
        super().__init__()
        self._stub = registry_pb2_grpc.RemotePythonFunctionRegistryServiceStub(channel)

    def register_function(self, name: str, func: Callable[..., Any], allow_overwrite: bool = False) -> None:
        """Register a Python function remotely.

        Args:
            name: Name to register the function under
            func: Python callable to register. Should accept a pyarrow.RecordBatch
                  and return a pyarrow.Array.
            allow_overwrite: If True, allows overwriting an existing function with the same name.
                           If False (default), raises an error if the function already exists.

        Raises:
            grpc.RpcError: If registration fails. The error details are in the exception's
                          status code and message. Common status codes:
                          - INVALID_ARGUMENT: Function could not be deserialized or is not callable
                          - ALREADY_EXISTS: Function already exists and allow_overwrite is False
                          - INTERNAL: Internal error during registration

        Example:
            >>> import pyarrow.compute as pc
            >>> def add_columns(rb):
            ...     return pc.add(rb.column(0), rb.column(1))
            >>> client = RemotePythonFunctionRegistryClient(channel)
            >>> client.register_function("add", add_columns)
            >>> print("Function registered successfully!")
            >>>
            >>> # Update the function
            >>> def new_add_columns(rb):
            ...     return pc.add(rb.column(0), rb.column(1)) * 2
            >>> client.register_function("add", new_add_columns, allow_overwrite=True)
        """
        # Serialize the function using cloudpickle
        pickled_function = cloudpickle.dumps(func)

        # Create the request
        request = registry_pb2.RegisterFunctionRequest(
            name=name,
            pickled_function=pickled_function,
            allow_overwrite=allow_overwrite,
        )

        # Call the service (raises grpc.RpcError on failure)
        self._stub.RegisterFunction(request)

    @classmethod
    def from_address(cls, address: str) -> RemotePythonFunctionRegistryClient:
        """Create a client from a gRPC server address.

        Args:
            address: Address in format "host:port" or "unix:path/to/socket"

        Returns:
            RemotePythonFunctionRegistryClient instance
        """
        channel = grpc.insecure_channel(address)  # type: ignore[attr-defined]
        return cls(channel)
