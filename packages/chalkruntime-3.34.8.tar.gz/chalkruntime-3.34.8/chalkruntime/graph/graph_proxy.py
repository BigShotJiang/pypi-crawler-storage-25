from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Callable,
    Iterable,
    ParamSpec,
    TypeVar,
)

from chalk.sql._internal.sql_source import SQLSourceKind
from pyarrow import Schema as PyArrowSchema

from chalkruntime.graph.graph import ResolvedGraph

if TYPE_CHECKING:
    from chalkruntime.graph.feature import (
        ScalarFeatureType,
    )

T = TypeVar("T")
TSelf = TypeVar("TSelf")
P = ParamSpec("P")


class GraphProxy(ResolvedGraph):
    """GraphProxy wraps an underlying graph and proxies all calls to it.

    This class must be subclassed by other classes that want to augment the graph with features and/or resolvers
    """

    def __init__(self, underlying: ResolvedGraph):
        super().__init__()
        self._underlying = underlying

    @property
    def sql_sources(self):
        return self._underlying.sql_sources

    def get_sql_source_by_name(self, name: str):
        return self._underlying.get_sql_source_by_name(name)

    def get_sql_source(self, kind: SQLSourceKind, name: str | None):
        return self._underlying.get_sql_source(kind, name)

    def get_sql_source_group(self, name: str):
        return self._underlying.get_sql_source_group(name)

    @property
    def online_store_configs(self):
        return self._underlying.online_store_configs

    @property
    def features(
        self,
    ):
        return self._underlying.features

    @property
    def fqn_to_feature(
        self,
    ):
        return self._underlying.fqn_to_feature

    def feature_from_fqn(self, fqn: str):
        return self._underlying.feature_from_fqn(fqn)

    def fqns_to_schema(self, fqns: Iterable[str]) -> PyArrowSchema | None:
        return self._underlying.fqns_to_schema(fqns)

    def get_write_max_staleness(self, f: ScalarFeatureType):
        return self._underlying.get_write_max_staleness(f)

    def get_features_in_namespace(self, namespace: str):
        return self._underlying.get_features_in_namespace(namespace)

    def primary_feature_for_namespace(self, namespace: str):
        return self._underlying.primary_feature_for_namespace(namespace)

    def ts_feature_for_namespace(self, output_namespace: str):
        return self._underlying.ts_feature_for_namespace(output_namespace)

    @property
    def all_namespaces(self):
        return self._underlying.all_namespaces

    @property
    def resolvers(self):
        return self._underlying.resolvers

    @property
    def resolver_id_to_resolver(self):
        return self._underlying.resolver_id_to_resolver

    @property
    def stream_resolvers(self):
        return self._underlying.stream_resolvers

    @property
    def sink_resolvers(self):
        return self._underlying.sink_resolvers

    def resolver_by_name(self, short_name_or_fqn: str):
        return self._underlying.resolver_by_name(short_name_or_fqn)

    def features_for_feature_namespace(self, namespace: str):
        return self._underlying.features_for_feature_namespace(namespace)

    @property
    def feature_to_joined_feature(self):
        return self._underlying.feature_to_joined_feature

    def graph_cached(self, fn: Callable[[], T]):
        return self._underlying.graph_cached(fn)

    def graph_cached_with_graph(self, fn: Callable[[ResolvedGraph], T]):
        return self._underlying.graph_cached_with_graph(fn)
