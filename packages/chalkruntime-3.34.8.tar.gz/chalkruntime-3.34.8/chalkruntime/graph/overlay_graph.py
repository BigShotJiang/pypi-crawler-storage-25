import base64
import collections
import dataclasses
import hashlib
from dataclasses import dataclass

from chalk._gen.chalk.graph.v1 import graph_pb2
from chalk._gen.chalk.graph.v2 import sources_pb2
from chalk.utils.log_with_context import get_logger
from chalk.utils.tracing import PerfTimer

from chalkruntime.graph.convert_chalkpy_underscore import scalar_feature_types_to_resolvers
from chalkruntime.graph.feature import ScalarFeatureType
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.graph_impl import ResolvedGraphImpl
from chalkruntime.graph.protograph_deserializer import FromProtoConverter
from chalkruntime.graph.resolver import ResolverParsed

_logger = get_logger(__name__)


def _get_feature_namespace_from_oneof(ft: graph_pb2.FeatureType) -> str | None:
    field_name = ft.WhichOneof("type")
    if field_name is None:
        return None
    f = getattr(ft, field_name, None)
    if f is None:
        return None
    return getattr(f, "namespace", None)


def add_overlay_to_graph(graph: ResolvedGraphImpl, overlay: graph_pb2.OverlayGraph, old_proto_graph: graph_pb2.Graph):
    """NOTE: This modifies `graph` in-place."""
    old_feature_fqns = set(graph.fqn_to_feature.keys())

    with graph.ensure_transaction() as ctx:
        # Process new feature fields for existing feature sets
        # TODO this is a hack:
        # Our conversion logic currently accepts whole FeatureSets at a time.
        # So, we copy the existing proto FeatureSet and replace its features list w/ a list containing only the new features
        # This should work but we need to refactor the FromProtoConverter a bit to expose a method for
        # "Add only this field to an existing feature class"
        namespace_to_new_fields: dict[str, list[graph_pb2.FeatureType]] = collections.defaultdict(list)
        for ft in overlay.feature_fields:
            ns = _get_feature_namespace_from_oneof(ft)
            if not ns:
                raise ValueError("Failed to get namespace for overlay feature field.")
            namespace_to_new_fields[ns].append(ft)

        namespace_to_old_proto_fs: dict[str, graph_pb2.FeatureSet] = {
            fs.name: fs for fs in old_proto_graph.feature_sets
        }
        dummy_feature_sets: list[graph_pb2.FeatureSet] = []
        for ns, new_fts in namespace_to_new_fields.items():
            old_fs = namespace_to_old_proto_fs.get(ns)
            if old_fs is None:
                continue
            new_fs = graph_pb2.FeatureSet()
            new_fs.CopyFrom(old_fs)
            del new_fs.features[:]
            new_fs.features.extend(new_fts)
            dummy_feature_sets.append(new_fs)

        # Convert the new and 'dummy' feature sets all at once -- since features can reference each other (i.e has-manys), we
        # Want to order features across all namespaces by their types (i.e. convert scalars first, then join features)
        # Thus it's important to call convert_features in one go
        FromProtoConverter.convert_features(
            list(overlay.feature_sets) + dummy_feature_sets, graph, ctx, is_externally_defined=True
        )

        # Convert new resolvers
        resolvers = [
            FromProtoConverter.convert_resolver(r, graph=graph, is_externally_defined=True) for r in overlay.resolvers
        ]
        ctx.upsert_resolvers(resolvers, replace_on_conflict=False)

        # Convert scalar feature types to underscore resolvers
        new_resolvers: list[ResolverParsed] = scalar_feature_types_to_resolvers(
            scalars=[f for f in graph.features if isinstance(f, ScalarFeatureType) and f.fqn not in old_feature_fqns],
            graph=graph,
        )
        ctx.upsert_resolvers(new_resolvers, replace_on_conflict=False)

        # TODO Convert SQL resolvers from SQLStringResult
        # (this logic needs to happen in a subprocess)
        # overlay.generated_sql_resolvers.....


@dataclass(frozen=True, kw_only=True, slots=True)
class OverlayGraphInfo:
    """
    Information re: an "overlay graph", i.e. additional features & resolvers that a client can provide at query time.
    """

    graph: ResolvedGraph = dataclasses.field(compare=False, hash=False, repr=False)
    overlay_graph_proto: graph_pb2.OverlayGraph = dataclasses.field(compare=False, hash=False, repr=False)
    overlay_graph_hash: str


class OverlayGraphService:
    """
    Queries can provide additional features/resolvers to overlay on top of the current deployment's existing graph.
    This service provides a new graph object that can be used in planning for the given query.
    """

    def __init__(
        self,
        base_proto_graph: graph_pb2.Graph,
        base_graph: ResolvedGraph,
        base_proto_source_secrets: sources_pb2.SourceSecrets,
    ):
        """
        :param base_proto_graph:
        :param base_graph: The "default" graph
        """
        super().__init__()
        self._base_graph = base_graph
        self._base_proto_graph = base_proto_graph
        self._base_proto_source_secrets = base_proto_source_secrets
        self._cache: dict[str, OverlayGraphInfo] = {}

    @property
    def source_secrets(self):
        return self._base_proto_source_secrets

    def get_graph_for_query(self, overlay_graph_proto: graph_pb2.OverlayGraph, key: str) -> OverlayGraphInfo:
        # This key may not be the same across processes since proto serialization isn't really deterministic.
        # However it's good enough to avoid re-generating a graph if the same client sends the same overlay graph multiple
        # times during a session.
        if key not in self._cache:
            with PerfTimer() as pt:
                _logger.info("Copying graph and adding overlay features...")
                new_proto_graph = graph_pb2.Graph()
                new_proto_graph.CopyFrom(self._base_proto_graph)
                new_graph = FromProtoConverter.convert_graph(
                    pb_graph=new_proto_graph, source_secrets=self._base_proto_source_secrets
                )
                add_overlay_to_graph(
                    graph=new_graph, overlay=overlay_graph_proto, old_proto_graph=self._base_proto_graph
                )
                _logger.info(f"Created new graph with overlay features in {pt.duration_seconds}s")
                self._cache[key] = OverlayGraphInfo(
                    graph=new_graph, overlay_graph_proto=overlay_graph_proto, overlay_graph_hash=key
                )
        return self._cache[key]

    def get_graph_for_query_from_proto_b64(self, overlay_graph_b64: str) -> OverlayGraphInfo:
        overlay_graph_bytes: bytes = base64.b64decode(overlay_graph_b64)
        return self.get_graph_for_query_from_proto_bytes(overlay_graph_bytes)

    def get_graph_for_query_from_proto_bytes(self, overlay_graph_bytes: bytes) -> OverlayGraphInfo:
        overlay_graph_proto = graph_pb2.OverlayGraph()
        overlay_graph_proto.ParseFromString(overlay_graph_bytes)
        key = hashlib.sha256(overlay_graph_bytes).hexdigest()
        return self.get_graph_for_query(overlay_graph_proto, key)
