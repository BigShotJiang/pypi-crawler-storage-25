import importlib
import os
from typing import Any, Iterable, Mapping

import pyarrow as pa
from chalk._gen.chalk.python.v1 import types_pb2 as types_pb
from chalk.features._encoding.converter import pa_scalar_to_proto


def get_envvars(envvars: set[str]) -> Mapping[str, str | None]:
    return {k: os.getenv(k) for k in envvars}


_any_proto_ty = types_pb.Ty(any=types_pb.EmptyMessage(), nullable=True)


class _HashableTy:
    def __init__(self, msg: types_pb.Ty):
        super().__init__()
        self.msg = msg
        self._serialized = self.msg.SerializeToString(deterministic=True)

    def __eq__(self, other: Any):
        if not isinstance(other, _HashableTy):
            return NotImplemented
        return self._serialized == other._serialized

    def __hash__(self):
        return hash(self._serialized)


def _parse_python_type(value: object) -> types_pb.Ty:
    value_type = type(value)
    if value_type is str:
        return types_pb.Ty(str=types_pb.EmptyMessage(), nullable=False)
    elif value_type is int:
        return types_pb.Ty(int=types_pb.EmptyMessage(), nullable=False)
    elif value_type is float:
        return types_pb.Ty(float=types_pb.EmptyMessage(), nullable=False)
    elif value_type is bool:
        return types_pb.Ty(bool=types_pb.EmptyMessage(), nullable=False)
    elif value is None:
        return types_pb.Ty(none=types_pb.EmptyMessage(), nullable=False)
    elif value_type is set or value_type is list:
        assert isinstance(value, (set, list))
        unique_items = {_HashableTy(_parse_python_type(v)) for v in value}
        items = unique_items.pop().msg if unique_items else _any_proto_ty
        return (
            types_pb.Ty(set=types_pb.TySet(items=items), nullable=False)
            if value_type is set
            else types_pb.Ty(list=types_pb.TyList(items=items), nullable=False)
        )
    return _any_proto_ty


_missing = object()


def get_variables(variables: Iterable[types_pb.CodeVariable]) -> Iterable[types_pb.CodeVariableValue]:
    for variable in variables:
        try:
            module = importlib.import_module(variable.module)
        except ImportError:
            continue
        if (value := getattr(module, variable.name, _missing)) is not _missing:
            ty = _parse_python_type(value)
            try:
                proto_scalar = pa_scalar_to_proto(pa.scalar(value))
            except Exception:
                continue

            yield types_pb.CodeVariableValue(
                variable=variable,
                value=types_pb.SymbolicConst(value=proto_scalar, ty=ty),
            )
