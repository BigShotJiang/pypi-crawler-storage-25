from __future__ import annotations

import collections.abc
import datetime as dt
import enum
import functools
import typing
from typing import TYPE_CHECKING, AbstractSet, Any, Generic, Mapping, Sequence, TypeGuard

import pyarrow as pa
from chalk.features._encoding.converter import PrimitiveFeatureConverter
from chalk.features.dataframe._filters import FilterConverter, StructAdapter, TExpr, dataframe_missing_key_error

from chalkruntime.graph.feature import (
    DataFrameType,
    FilterParsed,
    NamedFeatureType,
    SchemaFeatureType,
    is_schema_feature_type,
)

if TYPE_CHECKING:
    from libchalk.chalktable import ChalkTable, Expr


class FilterParsedConverter(Generic[TExpr]):
    """
    Wraps a FilterConverter and uses it to convert _parsed_ filters into 'TExpr' expressions (where TExpr is a polars expression, libplanner node, etc.)
    Does not use the raw Filter so does not need access to the feature registry/customer code.
    """

    def __init__(self, ff: FilterConverter[TExpr]):
        super().__init__()
        self._ff = ff

    def _parse_feature_or_value(
        self,
        f: SchemaFeatureType | Any,
        timestamp_feature: SchemaFeatureType | None,
        now: dt.datetime | TExpr | None,
        now_column_name: str | None,
    ):
        """Parse a feature or value into the correct type that can be used for filtering."""
        f = self._maybe_convert_timedelta_to_timestamp(f, now, now_column_name)
        f = self._maybe_replace_timestamp_feature(f, timestamp_feature)
        if isinstance(f, enum.Enum):
            f = f.value
        return f

    def _maybe_replace_timestamp_feature(
        self, f: SchemaFeatureType | Any, observed_at_feature: SchemaFeatureType | None
    ) -> SchemaFeatureType:
        """Replace the ``CHALK_TS`` pseudo-feature with the actual timestamp column."""

        if not is_schema_feature_type(f):
            return f
        elif isinstance(f, NamedFeatureType) and f.fqn != "__chalk__.CHALK_TS":
            return f
        if observed_at_feature is not None:
            return observed_at_feature
        raise ValueError("No Timestamp Feature Found")

    def _maybe_convert_timedelta_to_timestamp(
        self,
        f: dt.timedelta | Any,
        now: dt.datetime | TExpr | None,
        now_column_name: str | None = None,
    ) -> TExpr | dt.datetime | Any:
        """Convert timedeltas relative to ``now`` into absolute datetimes."""
        if now is not None and now_column_name is not None:
            raise ValueError(
                (
                    "Can't specify both now and now_column_name -- one or the other must be used as a point of reference for "
                    "the time delta"
                )
            )
        if isinstance(f, dt.timedelta):
            if now is None and now_column_name is None:
                raise ValueError(
                    (
                        "The filter contains a relative timestamp. The current dt.datetime or current date column "
                        "must be provided to evaluate this filter."
                    )
                )
            if now_column_name is not None:
                # creates a polars/pyarrow expression that evaluates to dates that are within the dt.timedelta specified by `f`
                return self._ff.col(now_column_name) + self._ff.lit(f, pa.duration("us"))
            assert now is not None
            if not self._ff._is_expr(now):  # pyright:ignore[reportPrivateUsage]
                now = self._ff.lit(now, pa.timestamp("us", "UTC"))
            return now + self._ff.lit(f, pa.duration("us"))

        return f

    def convert_filters(
        self,
        filters: Sequence[FilterParsed],
        df_schema: Mapping[str, Any],  # We only use the keys, could be a polars or pyarrow schema
        timestamp_feature: SchemaFeatureType | None = None,
        now: dt.datetime | TExpr | None = None,
        now_col_name: str | None = None,
    ) -> TExpr | None:
        if len(filters) == 0:
            return None
        parsed_filters: typing.List[TExpr] = [
            self.convert_filter_parsed_to_expr(f, df_schema.keys(), timestamp_feature, now, now_col_name)
            for f in filters
        ]
        return functools.reduce(lambda a, b: a & b, parsed_filters)

    def convert_filter_parsed_to_expr(
        self,
        f: FilterParsed,
        df_schema: AbstractSet[str],  # We only use the keys, could be a polars or pyarrow schema
        timestamp_feature: SchemaFeatureType | None = None,
        now: dt.datetime | TExpr | None = None,
        now_col_name: str | None = None,
    ) -> TExpr:
        # Passing `now` in explicitly instead of using dt.datetime.dt.datetime.now() so that multiple filters
        # relying on relative timestamps (e.g. before, after) will have the same "now" time.
        def _convert_sub_filter(sub_filter: FilterParsed, side_name: str):
            assert isinstance(sub_filter, FilterParsed), f"{side_name} must be a filter"
            return self.convert_filter_parsed_to_expr(sub_filter, df_schema, timestamp_feature, now, now_col_name)

        if f.operation == "not" or f.operation == "~":  # pyright: ignore[reportUnnecessaryComparison]
            assert isinstance(f.lhs, FilterParsed)
            assert f.rhs is None, "not has just one side"
            return ~_convert_sub_filter(f.lhs, "lhs")
        elif f.operation == "and" or f.operation == "&":  # pyright: ignore[reportUnnecessaryComparison]
            assert isinstance(f.lhs, FilterParsed)
            assert isinstance(f.rhs, FilterParsed)
            return _convert_sub_filter(f.lhs, "lhs") & _convert_sub_filter(f.rhs, "rhs")
        elif f.operation == "or" or f.operation == "|":  # pyright: ignore[reportUnnecessaryComparison]
            assert isinstance(f.lhs, FilterParsed)
            assert isinstance(f.rhs, FilterParsed)
            return _convert_sub_filter(f.lhs, "lhs") | _convert_sub_filter(f.rhs, "rhs")

        lhs = self._parse_feature_or_value(f.lhs, timestamp_feature, now, now_col_name)
        rhs = self._parse_feature_or_value(f.rhs, timestamp_feature, now, now_col_name)

        lhs_converter: PrimitiveFeatureConverter | None = None
        dtype = None
        if is_schema_feature_type(lhs):
            assert not isinstance(
                lhs, DataFrameType
            )  # these don't have a converter, and are not currently used in Filters anyway
            lhs_converter = lhs.underlying.primitive_converter
            col_name = str(lhs)
            key_error_or_none = dataframe_missing_key_error([col_name], tuple(df_schema))
            if key_error_or_none is not None:
                raise key_error_or_none
            lhs = self._ff.col(col_name)
            dtype = lhs_converter.pyarrow_dtype

        rhs_converter: PrimitiveFeatureConverter | None = None
        if is_schema_feature_type(rhs):
            assert not isinstance(
                rhs, DataFrameType
            )  # these don't have a converter, and are not currently used in Filters anyway
            rhs_converter = rhs.underlying.primitive_converter
            col_name = str(rhs)
            key_error_or_none = dataframe_missing_key_error([col_name], tuple(df_schema))
            if key_error_or_none is not None:
                raise key_error_or_none
            rhs = self._ff.col(col_name)
            dtype = rhs_converter.pyarrow_dtype
        assert dtype is not None, "One side must be an expression"

        if lhs_converter is None:
            # LHS is literal. Encode it into the rhs_dtype
            assert rhs_converter is not None, "One side of the filter must be an expression"
            if not self._ff._is_expr(lhs):  # pyright:ignore[reportPrivateUsage]
                lhs_pa_scalar: pa.Scalar = rhs_converter.from_json_to_pyarrow([lhs])[0]  # pyright: ignore
                lhs = self._ff.lit(lhs_pa_scalar.as_py(), rhs_converter.pyarrow_dtype)
        if rhs_converter is None:
            # RHS is literal. Encode it into the lhs_dtype
            assert lhs_converter is not None, "One side of the filter must be an expression"
            if not self._ff._is_expr(rhs):  # pyright:ignore[reportPrivateUsage]
                if f.operation in ("in", "not in"):
                    assert isinstance(rhs, collections.abc.Iterable)
                    rhs = [
                        self._ff.lit(rhs_scalar.as_py(), lhs_converter.pyarrow_dtype)
                        for rhs_scalar in lhs_converter.from_json_to_pyarrow(rhs)  # pyright: ignore
                    ]
                else:
                    rhs_pa_scalar = lhs_converter.from_json_to_pyarrow([rhs])[0]  # pyright: ignore
                    rhs = self._ff.lit(rhs_pa_scalar.as_py(), lhs_converter.pyarrow_dtype)

        assert self._ff._is_expr(lhs) or self._ff._is_expr(rhs)  # pyright:ignore[reportPrivateUsage]
        # pyright is not quite smart enough to know that at this point, at least one of [lhs, rhs] is a TExpr
        if f.operation in ("in", "not in"):
            assert lhs_converter is not None
            assert self._ff._is_expr(lhs)  # pyright:ignore[reportPrivateUsage]
            ret = self._ff._expr_is_in_sequence_lit(lhs, typing.cast(Any, rhs), lhs_converter.pyarrow_dtype)  # pyright:ignore[reportPrivateUsage]
            if f.operation == "not in":
                ret = ~ret
        elif f.operation == "==" or f.operation == "!=":
            if lhs_converter is None or rhs_converter is None:
                # If comparing against a literal value, then use eq_missing
                assert self._ff._is_expr(rhs), "The rhs must be an expression if doing equality"  # pyright:ignore[reportPrivateUsage]
                assert self._ff._is_expr(lhs)  # pyright:ignore[reportPrivateUsage]
                ret = self._ff._eq_missing(lhs, rhs, dtype)  # pyright:ignore[reportPrivateUsage]
            else:
                # If both are not None, then do a normal eq
                ret = lhs == rhs
            if f.operation == "!=":
                # Invert it
                ret = ~ret  # pyright: ignore[reportDeprecated]
        elif f.operation == ">=":
            ret = lhs >= rhs  # pyright: ignore[reportOperatorIssue]
        elif f.operation == ">":
            ret = lhs > rhs  # pyright: ignore[reportOperatorIssue]
        elif f.operation == "<":
            ret = lhs < rhs  # pyright: ignore[reportOperatorIssue]
        elif f.operation == "<=":
            ret = lhs <= rhs  # pyright: ignore[reportOperatorIssue]
        else:
            raise ValueError(f'Unknown operation "{f.operation}"')
        assert self._ff._is_expr(ret)  # pyright:ignore[reportPrivateUsage]
        return ret


class _LibchalkExprStructAdapter(StructAdapter["Expr"]):
    def __init__(self) -> None:
        super().__init__()

    def get_expr_for_field(self, expr: Expr, name: str) -> tuple[Expr, pa.DataType]:
        subfield = expr.get_struct_subfield(name)
        return subfield, subfield.dtype


class LibchalkExprConverter(FilterConverter["Expr"]):
    def __init__(self, tbl: ChalkTable) -> None:
        self._tbl = tbl
        super().__init__()

    def call(self, function_name: str, *args: Expr) -> Expr:
        raise NotImplementedError

    def cast(self, expr: Expr, dtype: pa.DataType) -> Expr:
        if pa.types.is_null(expr.dtype):
            # A null expr must have all nulls, so we can replace with a literal expression of the correct type
            return self.lit(None, dtype)
        return expr.cast(dtype)

    def col(self, name: str) -> Expr:
        return self._tbl.col(name)

    def lit(self, value: Any, dtype: pa.DataType) -> Expr:
        if isinstance(dtype, pa.ExtensionType):
            underlying_scalar = pa.scalar(value, dtype.storage_type)
            scalar = pa.ExtensionScalar.from_storage(dtype, underlying_scalar)
        else:
            scalar = pa.scalar(value, dtype)
        from libchalk.chalktable import Expr

        return Expr.lit(scalar)

    def is_null(self, expr: Expr) -> Expr:
        return expr.is_null()

    def is_not_null(self, expr: Expr) -> Expr:
        return ~self.is_null(expr)

    def if_else(self, cond: Expr, true_case: Expr, false_case: Expr) -> Expr:
        from libchalk.chalktable import Expr

        return Expr.if_else(cond, true_case, false_case)

    def _is_expr(self, o: Any) -> TypeGuard[Expr]:
        from libchalk.chalktable import Expr

        return isinstance(o, Expr)

    def _get_struct_adapter(self, dtype: pa.StructType) -> StructAdapter[Expr]:
        return _LibchalkExprStructAdapter()

    def greatest(self, a: Expr, b: Expr) -> Expr:
        from libchalk.chalktable import Expr

        return Expr.greatest(a, b)

    def least(self, a: Expr, b: Expr) -> Expr:
        from libchalk.chalktable import Expr

        return Expr.least(a, b)

    def fill_null(self, expr: Expr, fill_with: Expr) -> Expr:
        # The implementation inherited from chalkpy instead produces an `if_else`.
        # This is more compact (because it avoids repeating the `expr`).
        from libchalk.chalktable import Expr

        return Expr.coalesce(expr, [fill_with])

    def coalesce(self, a: Expr, b: Expr) -> Expr:
        raise NotImplementedError
