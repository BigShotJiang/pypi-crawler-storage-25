from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Collection, Tuple

import jinja2
import jinja2.nodes
import pyarrow as pa
from _chalk_shared_public.chalk_function_registry import get_chalk_function_registry_overload
from chalk.utils.string import to_snake_case

from chalkruntime.graph.chalk_overload import ChalkFunctionOverloadResolved
from chalkruntime.graph.feature import FeatureTimeFeatureType, HasManyFeatureType, HasOneFeatureType, ScalarFeatureType
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.maybe_named_collection import MaybeNamedCollectionBuilder
from chalkruntime.graph.underscore import (
    FeatureKeySource,
    UnderscoreConstant,
    UnderscoreFeature,
    UnderscoreItemParsed,
    UnderscoreNamespace,
    UnderscoreOperation,
    UnderscoreOperationExpression,
    UnderscoreResultDataFrameType,
    UnderscoreResultScalarType,
    UnderscoreValue,
    get_struct_pack_operation,
)
from chalkruntime.graph.underscore_codec_info import FromCppRegCodecInfo
from libchalk.chalkfunction import DataFrameParameterType


@dataclass(kw_only=True)
class TTrie:
    is_terminal: bool
    children: dict[str, "TTrie"]

    @staticmethod
    def empty() -> TTrie:
        return TTrie(is_terminal=False, children={})


class JinjaInputsSynthesizer:
    """Given a jinja string, synthesize the inputs that are required to render it."""

    def compute_input(
        self, jinja_string: str, namespace: str, graph: ResolvedGraph
    ) -> UnderscoreValue | UnderscoreConstant:
        env = jinja2.Environment()
        parsed = env.parse(jinja_string)
        input_feature_names = {
            child_input for node in parsed.body for child_input in self._compute_input_features_node(node)
        }
        prefix_trie = self._compute_prefix_trie(input_feature_names)
        if prefix_trie.is_terminal:
            raise ValueError("Jinja template referenced empty feature")  # actual bug
        if len(prefix_trie.children) == 0:
            return UnderscoreConstant(value={}, default_pa_type=pa.struct([]))
        if len(prefix_trie.children) > 1:
            raise ValueError(
                f"Jinja template referenced multiple namespaces {prefix_trie.children.keys()}. Only one namespace is allowed."
            )
        ns = next(iter(prefix_trie.children))
        if not namespace.endswith(to_snake_case(ns)):
            raise ValueError(
                f"Jinja template referenced namespace {ns}, but the underscore exists in namespace {namespace}."
            )
        inner_struct = self._compute_underscore_value(prefix_trie.children[ns], namespace, graph, (), namespace)
        if not isinstance(inner_struct.underscore_result_type, UnderscoreResultScalarType):
            raise ValueError(f"Underscore {inner_struct} referenced in jinja template does not return a scalar")
        return UnderscoreOperationExpression(
            original_underscore=None,
            operation=get_struct_pack_operation(names=(ns,), types=(inner_struct.underscore_result_type.scalar_type,)),
            operands=MaybeNamedCollectionBuilder((inner_struct,)),
            args=(ns,),
            expression_id=str(uuid.uuid4()),
        )

    def _compute_input_features_node(self, node: jinja2.nodes.Node) -> Collection[Tuple[str, ...]]:
        identifier = self._parse_identifier_getattr(node)
        if identifier:
            return {identifier}

        if isinstance(node, jinja2.nodes.For):
            has_many_for_loop_inputs = self._compute_inputs_has_many_for_loop(node)
            if has_many_for_loop_inputs:
                return has_many_for_loop_inputs

        return {
            child_input for child in node.iter_child_nodes() for child_input in self._compute_input_features_node(child)
        }

    def _parse_identifier_getattr(self, node: jinja2.nodes.Node) -> Tuple[str, ...] | None:
        """
        In jinja, we allow users to write `UrlBrand.url` referencing the feature url.
        Then we only need to provide the feature UrlBrand.url as input, instead of every feature in UrlBrand.
        None means this pattern does not apply, fallback to usual parsing.
        """
        if isinstance(node, jinja2.nodes.Name):
            return (node.name,)
        elif isinstance(node, jinja2.nodes.Getattr):
            parent_identifier = self._parse_identifier_getattr(node.node)
            if parent_identifier:
                return parent_identifier + (node.attr,)
        return None

    def _compute_inputs_has_many_for_loop(self, node: jinja2.nodes.For) -> Collection[Tuple[str, ...]] | None:
        """
        For loops reference has-many features. For example, in the template:
        ```
        {% for asset in UrlBrand.site_detection_assets %}
        {{ asset.description }}
        {% endfor %}
        ```
        We need to provide the has-many nested scalar `UrlBrand.site_detection_assets.description` as input.
        Again, notice we don't need to provide `UrlBrand.site_detection_assets` as input, only the nested scalar.
        None means this pattern does not apply, fallback to usual parsing.
        """
        if not isinstance(node.target, jinja2.nodes.Name):
            return None
        target = node.target.name
        iter_identifier = self._parse_identifier_getattr(node.iter)
        if not iter_identifier:
            return None
        # replace `target.` with `iter_identifier.` at start of string
        body_inputs = {child_input for child in node.body for child_input in self._compute_input_features_node(child)}
        return {
            iter_identifier + body_input[1:] if body_input[0] == target else body_input for body_input in body_inputs
        }

    def _compute_prefix_trie(self, data: Collection[Tuple[str, ...]]) -> TTrie:
        trie = TTrie.empty()
        for feature in data:
            current = trie
            for part in feature:
                current = current.children.setdefault(part, TTrie.empty())
            current.is_terminal = True
        return trie

    def _compute_underscore_value(
        self,
        trie: TTrie,
        namespace: str,
        graph: ResolvedGraph,
        prefix_has_one: Tuple[HasOneFeatureType, ...],
        rendered_prefix: str,
    ) -> UnderscoreValue:
        if trie.is_terminal:
            raise ValueError(
                f"Jinja template referenced namespace {rendered_prefix} directly. It should only reference features."
            )
        struct_entries: dict[str, UnderscoreValue] = {}
        for child, child_trie in trie.children.items():
            feature = graph.feature_from_fqn(f"{namespace}.{child}")
            if isinstance(feature, (ScalarFeatureType, FeatureTimeFeatureType)):
                struct_entries[child] = UnderscoreFeature(
                    underlying=feature,
                    original_underscore=None,
                    _path=prefix_has_one,
                    expression_id=str(uuid.uuid4()),
                )
            elif isinstance(feature, HasOneFeatureType):
                struct_entries[child] = self._compute_underscore_value(
                    child_trie,
                    feature.foreign_namespace(),
                    graph,
                    prefix_has_one + (feature,),
                    f"{rendered_prefix}.{child}",
                )
            elif isinstance(feature, HasManyFeatureType):
                child_underscore = self._compute_underscore_value(
                    child_trie, feature.foreign_namespace(), graph, (), f"{rendered_prefix}.{child}"
                )
                hasmany_underscore = UnderscoreItemParsed(
                    original_underscore=None,
                    parent=UnderscoreNamespace(
                        original_underscore=None,
                        _path=(feature,),
                    ),
                    feature_keys=[child_underscore],
                    feature_key_source=FeatureKeySource.explicit,
                    filters=(),
                    expression_id=str(uuid.uuid4()),
                )
                assert isinstance(hasmany_underscore.underscore_result_type, UnderscoreResultDataFrameType), (
                    "for pyright"
                )
                if hasmany_underscore.underscore_result_type.column_types == "all_columns":
                    raise ValueError("Unexpected hasmany feature with 'all_columns'")
                input_types = MaybeNamedCollectionBuilder(
                    [
                        DataFrameParameterType(
                            columns={"series": list(hasmany_underscore.underscore_result_type.column_types.values())[0]}
                        )
                    ]
                )
                array_agg_op = get_chalk_function_registry_overload(
                    function_name="array_agg",
                    input_types=input_types,
                )
                if not isinstance(array_agg_op, ChalkFunctionOverloadResolved):
                    raise ValueError(f"Failed to find overload for jinja function: {array_agg_op}")
                array_agg = UnderscoreOperationExpression(
                    original_underscore=None,
                    operation=UnderscoreOperation.from_overload_resolved(
                        resolved_overload=array_agg_op,
                        codec_info=FromCppRegCodecInfo(function_name="array_agg"),
                    ),
                    operands=MaybeNamedCollectionBuilder([hasmany_underscore]),
                    expression_id=str(uuid.uuid4()),
                )
                struct_entries[child] = array_agg
            elif feature is None:
                raise ValueError(
                    f"Jinja template referenced feature {rendered_prefix}.{child} which could not be found in the graph."
                )
            else:
                raise ValueError(
                    f"Jinja template referenced unsupported feature {rendered_prefix}.{child} of type {type(feature)}"
                )

        output_types = list[pa.DataType]()
        for v in struct_entries.values():
            if not isinstance(v.underscore_result_type, UnderscoreResultScalarType):
                raise ValueError(f"Underscore {v} referenced in jinja template does not return a scalar")  # actual bug
            output_types.append(v.underscore_result_type.scalar_type)

        return UnderscoreOperationExpression(
            original_underscore=None,
            operation=get_struct_pack_operation(names=tuple(struct_entries.keys()), types=tuple(output_types)),
            operands=MaybeNamedCollectionBuilder(tuple(struct_entries.values())),
            args=tuple(struct_entries.keys()),
            expression_id=str(uuid.uuid4()),
        )
