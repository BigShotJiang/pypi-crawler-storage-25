from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any, Callable, Sequence, cast

import pyarrow as pa
from chalk import DataFrame, Resolver
from chalk.features import (
    CacheStrategy,
    Feature,
    Features,
    FeatureSetBase,
    FeatureWrapper,
    Filter,
    unwrap_feature,
)
from chalk.sql import FinalizedChalkQuery
from chalk.sql._internal.chalk_query import ChalkQuery
from chalk.sql._internal.string_chalk_query import StringChalkQuery

if TYPE_CHECKING:
    from chalkruntime.graph.feature import ScalarFeatureType

    # Manually defining this when type checking because the import has some issue because of stubgen
    CHALK_SINGLETON_VALUE = 111
else:
    from chalk.features.feature_set_decorator import CHALK_SINGLETON_VALUE

CHALK_FK_SINGLETON_NAME = "__chalk_fk_singleton__"
CHALK_GLOBAL_SINGLETON_ID = "__chalk_singleton_id__"

__all__ = (
    "CHALK_SINGLETON_VALUE",
    "CHALK_FK_SINGLETON_NAME",
    "singleton_relationship_name",
    "singleton_join_feature_fqn",
    "joined_singleton_feature_fqn",
)


@contextlib.contextmanager
def temporarily_disable_feature_set_base_hook():
    prev_hook = FeatureSetBase.hook
    FeatureSetBase.hook = None
    try:
        yield
    finally:
        FeatureSetBase.hook = prev_hook


def singleton_relationship_name(namespace: str) -> str:
    """Maybe it's nicer to hide this, but the command line is so much easier to implement this way."""
    return namespace
    # return f"__chalk_singleton_{namespace}__"


def singleton_join_feature_fqn(non_global_namespace: str, singleton_namespace: str):
    """Finds the fqn for a non-singleton namespace and a singleton namespace"""
    return non_global_namespace + "." + singleton_relationship_name(singleton_namespace)


def joined_singleton_feature_fqn(non_global_namespace: str, feature: "ScalarFeatureType"):
    """Finds the fqn for a non-singleton namespace and a feature on a singleton namespace"""
    return non_global_namespace + "." + singleton_relationship_name(feature.root_namespace) + "." + feature.name


def _add_feature_to_cls(cls: type[Features], feature: Feature) -> None:
    """Add a feature to this feature set."""
    cls.features.append(feature)
    setattr(cls, feature.attribute_name, FeatureWrapper(feature))


class SingletonGraphAugmenter:
    @staticmethod
    def nest_singleton_feature(arg: Feature, root_namespace: str) -> Feature:
        """
        Converts a singleton feature to a has-one feature from root_namespace with the original feature as its underlying.
        e.g. Global.value -> User.__chalk_singleton_Global__.value
        """
        root_cls = FeatureSetBase.registry[root_namespace]
        has_one_name = singleton_relationship_name(arg.namespace)
        global_has_one = next(f for f in root_cls.features if f.name == has_one_name)
        arg_through_has_one = getattr(FeatureWrapper(global_has_one), arg.name)
        return arg_through_has_one

    @staticmethod
    def modify_resolver(r: Resolver):
        """Modify the resolver to replace singleton features (that directly reference the singleton namespace)
        with the synthetic feature from the automatically generated has-one relationship

        This is needed because the planner would complain a resolver takes inputs form multiple namespaces. By replacing the
        feature with the synthetically generated has-one (see the augment_features method below), the planner thinks its
        solving for a normal has-one relationship, which then works as intended.
        """
        for i, arg in enumerate(r.inputs):
            # TODO: (Global1.x, Global2.y) -> (Global1.x, Global1.y)
            if isinstance(arg, Feature) and arg.is_singleton:
                assert r.output is not None
                ns = r.output.features[0].root_namespace
                if ns != arg.namespace:
                    # If this is not a resolver operating only on the singleton namespace,
                    # we need to replace the singleton feature with the has-one feature.
                    arg_through_has_one = SingletonGraphAugmenter.nest_singleton_feature(arg, ns)
                    assert isinstance(r.inputs, list)
                    r.inputs[i] = arg_through_has_one

        if r.output and len(r.output.features) == 1:
            df_type = r.output.features[0]
            if isinstance(df_type, type) and issubclass(df_type, DataFrame):
                df_type = cast(type[DataFrame], df_type)
                fs_base = FeatureSetBase.registry[df_type.namespace]
                if fs_base.__chalk_is_singleton__:
                    pkey = fs_base.__chalk_primary__
                    new_cols = (*df_type.columns, pkey)
                    r._output = Features[DataFrame[new_cols]]  # pyright: ignore[reportPrivateUsage]

                    def modified_fn(
                        *args: Any,
                        __chalk_fnn__: Callable = r.fn,
                        **kwargs: Any,
                    ):
                        res = __chalk_fnn__(*args, **kwargs)
                        if isinstance(res, (ChalkQuery, StringChalkQuery)):
                            res = res.all()
                        if isinstance(res, FinalizedChalkQuery):
                            # TODO: sloppy here.
                            res = res.execute()
                        return res.with_column(  # pyright: ignore[reportAttributeAccessIssue, reportOptionalMemberAccess]
                            pkey,
                            CHALK_SINGLETON_VALUE,
                        )

                    r.fn = modified_fn

    @staticmethod
    def augment_features(new_features: Sequence[Feature]) -> list[Feature]:
        """
        Each non-singleton feature set needs a has-one to
        each singleton so that global features can be
        requested in queries alongside features from a
        non-singleton class.

        The goal of the strategy is to produce these modifications:
        >>> @features
        ... class {cls}:
        ...     __chalk_fk_singleton__: int = feature(dtype=pa.uint8(), default=111)
        ...     __chalk_singleton_{singleton.namespace}__: singleton = has_one(lambda:
        ...         singleton.__chalk_primary__ == cls.__chalk_fk_singleton__
        ...     )

        >>> @features(singleton=True)
        ... class {singleton}:
        ...     __chalk_singleton_id__: int = feature(dtype=pa.uint8(), default=111)
        ...     {cls.namespace}: cls = has_many(lambda:
        ...         cls.__chalk_fk_singleton__ == singleton.__chalk_primary__
        ...     )

        This function returns a list of all the new features it created. It should be called
        only when the FeatureSetBase.hook is patched over to prevent unexpected recursion
        """
        if FeatureSetBase.hook is not None:
            raise RuntimeError("Disable the FeatureSetBase.hook before augmenting features")
        synthesized_features: list[Feature] = []
        for feat in new_features:
            # Add a foreign key every non-singleton class used
            # to link to singleton classes through a has-one relationship.
            # The singleton pkey is always the same (111), so we
            # can share the foreign key for all has-one relationships.
            #
            # Here, we fulfill the first modification:
            #   ...     __chalk_fk_singleton__: int = feature(dtype=pa.uint8(), default=111)
            cls = FeatureSetBase.registry.get(feat.namespace)
            if cls is None:
                continue
            if not cls.__chalk_is_singleton__ and not hasattr(cls, CHALK_FK_SINGLETON_NAME):
                cls_foreign_key = Feature(
                    name=CHALK_FK_SINGLETON_NAME,
                    attribute_name=CHALK_FK_SINGLETON_NAME,
                    namespace=feat.namespace,
                    default=CHALK_SINGLETON_VALUE,
                    is_autogenerated=True,
                    no_display=True,
                    typ=int,
                    pyarrow_dtype=pa.uint8(),
                    max_staleness=None,
                    cache_strategy=CacheStrategy.ALL,
                    etl_offline_to_online=False,
                    features_cls=cls,
                )
                synthesized_features.append(cls_foreign_key)
                _add_feature_to_cls(cls, cls_foreign_key)

        for feat in new_features:
            cls = FeatureSetBase.registry.get(feat.namespace)
            if cls is None:
                continue
            if cls.__chalk_is_singleton__:
                cls_foreign_key = cls.__chalk_primary__
            else:
                cls_foreign_key = unwrap_feature(getattr(cls, CHALK_FK_SINGLETON_NAME))

            for _, singleton in sorted(list(FeatureSetBase.__chalk_singletons__.items())):
                if singleton.__chalk_namespace__ == feat.namespace:
                    # Self-reference isn't necessary
                    continue

                # For each of the singletons, create a has-one relationship
                # using the foreign key we just created.
                # Here, we fulfill the second modification:
                #   ...     __chalk_singleton_{singleton.namespace}__: singleton = has_one(lambda:
                #   ...         singleton.__chalk_primary__ == cls.__chalk_fk_singleton__
                #   ...     )
                name = singleton_relationship_name(singleton.__chalk_namespace__)
                if not hasattr(cls, name):
                    x = Feature(
                        name=name,
                        attribute_name=name,
                        namespace=feat.namespace,
                        typ=singleton,
                        join=Filter(
                            lhs=cls_foreign_key,
                            operation="==",
                            rhs=singleton.__chalk_primary__,
                        ),
                        features_cls=cls,
                        is_autogenerated=True,
                        no_display=True,
                    )
                    synthesized_features.append(x)
                    _add_feature_to_cls(cls, x)

                if not cls.__chalk_is_singleton__:
                    # >>> @features
                    # ... class {singleton}:
                    # ...     __chalk_singleton_{singleton.namespace}__: singleton = has_many(lambda:
                    # ...         singleton.__chalk_primary__ == cls.__chalk_fk_singleton__
                    # ...     )
                    name = singleton_relationship_name(feat.namespace)
                    if not hasattr(singleton, name):
                        x = Feature(
                            name=name,
                            attribute_name=name,
                            namespace=singleton.__chalk_namespace__,
                            typ=DataFrame[cls],
                            max_staleness=None,
                            join=Filter(
                                lhs=singleton.__chalk_primary__,
                                operation="==",
                                rhs=cls_foreign_key,
                            ),
                            is_autogenerated=True,
                            features_cls=singleton,
                            no_display=True,
                        )
                        _add_feature_to_cls(singleton, x)
                        synthesized_features.append(x)
        return synthesized_features
