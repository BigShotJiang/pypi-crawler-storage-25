from typing import Protocol

from chalk.features import Underscore


class PromptService(Protocol):
    def get_prompt_by_id_sync(self, prompt_id: int) -> Underscore | None: ...

    def get_prompt_by_name_sync(self, prompt_name: str) -> Underscore | None: ...
