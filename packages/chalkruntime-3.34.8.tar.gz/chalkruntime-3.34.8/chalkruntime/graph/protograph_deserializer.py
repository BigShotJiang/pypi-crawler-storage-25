import collections
import dataclasses
import functools
import logging
from datetime import timedelta, timezone
from typing import Any, Callable, Dict, Iterable, List, Literal, Mapping, Sequence, Tuple, Type, cast

import frozendict
import pyarrow as pa
from chalk import Cron, CronTab, Duration
from chalk._gen.chalk.arrow.v1 import arrow_pb2 as arrow_pb
from chalk._gen.chalk.artifacts.v1 import export_pb2
from chalk._gen.chalk.expression.v1 import expression_pb2 as expr_pb
from chalk._gen.chalk.graph.v1 import graph_pb2 as pb
from chalk._gen.chalk.graph.v1.graph_pb2 import StreamMessageFormat
from chalk._gen.chalk.graph.v2 import sources_pb2 as sources_pb
from chalk.features import CacheStrategy, TPrimitive, TPrimitiveArrowScalar, Underscore
from chalk.features._encoding.converter import PrimitiveFeatureConverter, proto_to_pa_scalar
from chalk.features._encoding.serialized_rich_type import SerializedRichType
from chalk.features.feature_set_decorator import (
    GENERATED_OBSERVED_AT_NAME,  # pyright: ignore[reportAttributeAccessIssue]
)
from chalk.features.resolver import (
    FunctionCapturedGlobal,
    FunctionCapturedGlobalBuiltin,
    FunctionCapturedGlobalEnum,
    FunctionCapturedGlobalFeatureClass,
    FunctionCapturedGlobalFunction,
    FunctionCapturedGlobalModule,
    FunctionCapturedGlobalModuleMember,
    FunctionCapturedGlobalProto,
    FunctionCapturedGlobalStruct,
    FunctionCapturedGlobalVariable,
)
from chalk.features.underscore import UnderscoreDefinitionLocation
from chalk.operators import StaticOperator
from chalk.parsed._proto.utils import proto_value_to_python
from chalk.parsed.expressions import Operation
from chalk.parsed.to_proto import (
    _CHALK_ANON_SQL_SOURCE_PREFIX,  # pyright: ignore[reportPrivateUsage]
    _CHALK_ANON_STREAM_SOURCE_PREFIX,  # pyright: ignore[reportPrivateUsage]
    ToProtoConverter,
)
from chalk.sql import (
    AthenaSourceImpl,
    BigQuerySourceImpl,
    ClickhouseSourceImpl,
    CloudSQLSourceImpl,
    DatabricksSourceImpl,
    DynamoDBSourceImpl,
    MSSQLSourceImpl,
    MySQLSourceImpl,
    PostgreSQLSourceImpl,
    RedshiftSourceImpl,
    SnowflakeSourceImpl,
    SpannerSourceImpl,
    SQLiteSourceImpl,
    TrinoSourceImpl,
)
from chalk.sql._internal.integrations.duckdb import DuckDBSourceImpl
from chalk.sql._internal.sql_settings import SQLResolverSettings
from chalk.sql._internal.sql_source import (
    _ENABLE_ADD_TO_SQL_SOURCE_REGISTRIES,  # pyright: ignore[reportPrivateUsage]
    BaseSQLSource,
    SQLSourceKind,
)
from chalk.sql._internal.sql_source_group import SQLSourceGroup
from chalk.sql.finalized_query import Finalizer, IncrementalSettings
from chalk.streams import KafkaSource, KinesisSource, PubSubSource, StreamSource, get_name_with_duration
from chalk.utils.collections import FrozenOrderedSet, OrderedSet
from chalk.utils.df_utils import is_list_like
from chalk.utils.duration import CHALK_MAX_TIMEDELTA, timedelta_to_duration
from chalkdf import Schema
from chalkdf.underscore_conversion.convert_underscore_to_expr import convert_underscore_to_expr
from google.protobuf import duration_pb2
from google.protobuf import duration_pb2 as duration_pb
from google.protobuf import message as _message

from chalkruntime.constants import INTERNAL_TTL_MAX
from chalkruntime.graph.convert_chalkpy_underscore import (
    StreamResolverRootUnderscoreBehavior,
    convert_underscore_expression,
    scalar_feature_types_to_resolvers,
)
from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureFqnMarker,
    FeatureTimeFeatureType,
    FeatureValidationsParsed,
    FilterParsed,
    GroupByFeatureType,
    HasManyFeatureType,
    HasOneFeatureType,
    HasOnePathObjParsed,
    InputFeatureType,
    NamedFeatureType,
    RichConverterInfo,
    ScalarFeatureType,
    UnderlyingFeatureType,
    VersionInfoParsed,
    WindowConfig,
    WindowedFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    is_underlying_scalar,
    is_underlying_windowed,
    is_valid_operation,
    strip_version_suffix,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.graph_impl import GraphTransactionContext, ResolvedGraphImpl
from chalkruntime.graph.materializations import (
    MaterializationWindowConfigParsed,
    MaterializedAggregationType,
    expand_legacy_min_max_by_n_aggregate_on,
    parse_materialized_aggregation_type_from_name,
)
from chalkruntime.graph.named_query import NamedQueryParsed, NamedQueryRegistry
from chalkruntime.graph.resolver import (
    CronFilterWithFeatureArgs,
    MainProcOfflineResolver,
    MainProcOnlineResolver,
    OfflineResolverParsed,
    OnlineResolverParsed,
    ResolverArgErrorHandlerParsed,
    ResolverParsed,
    ResourceHintType,
    TResolverFeatureType,
    _LazyStaticOp,  # pyright: ignore[reportPrivateUsage]
)
from chalkruntime.graph.singletons import CHALK_FK_SINGLETON_NAME
from chalkruntime.graph.stream_resolver import (
    STREAM_RESOLVER_MESSAGE_ENVELOPE_TYPE,
    DeduplicationPolicyParsed,
    ParseInfoParsed,
    StreamResolverParamMessageParsed,
    StreamResolverParamMessageWindowParsed,
    StreamResolverParamParsed,
    StreamResolverParsed,
    StreamResolverSignatureParsed,
    StreamSinkConfigParsed,
    TStreamOutputFeatureType,
)
from chalkruntime.graph.underscore import UnderscoreResultScalarType, UnderscoreValue
from chalkruntime.streaming.types import CustomStreamSourceParsed
from chalkruntime.utils.contextvars import contextvar_ctx

NamedFeature = (
    ScalarFeatureType
    | FeatureTimeFeatureType
    | WindowedFeatureType
    | HasOneFeatureType
    | HasManyFeatureType
    | GroupByFeatureType
)


@dataclasses.dataclass(frozen=True)
class LRUCacheConfigParsed:
    max_size: int
    ttl: timedelta
    store_cache_misses: bool


@dataclasses.dataclass(frozen=True)
class OnlineStoreConfigParsed:
    name: str
    lru_cache: LRUCacheConfigParsed | None
    feature_namespaces: tuple[str, ...]


DataFrameColumn = (
    ScalarFeatureType
    | HasManyFeatureType
    | FeatureTimeFeatureType
    | WindowedFeatureType
    | InputFeatureType[ScalarFeatureType | HasManyFeatureType | FeatureTimeFeatureType | WindowedFeatureType]
)
NamespaceToFeatures = dict[str, Sequence[NamedFeature]]
FqnToFeature = dict[str, NamedFeature]
_InputFeature = (
    ScalarFeatureType | HasOneFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType
)
InputFeature = _InputFeature | InputFeatureType[_InputFeature] | DataFrameType

_logger = logging.getLogger(__name__)


def to_internal_duration(duration: duration_pb2.Duration) -> timedelta:
    return min(to_timedelta(duration), INTERNAL_TTL_MAX)


def to_timedelta(duration: duration_pb2.Duration) -> timedelta:
    if duration.seconds * 1_000_000_000 + duration.nanos > CHALK_MAX_TIMEDELTA.total_seconds() * 1_000_000_000:
        return CHALK_MAX_TIMEDELTA
    return duration.ToTimedelta()


def extract(source: _message.Message, key: str, default: Any = None, conv: Callable[[Any], Any] | None = None) -> Any:
    """Extract an optional protobuf field, returning default if the field is not set."""
    if source.HasField(key):
        value = getattr(source, key)
        return conv(value) if conv else value
    return default


@dataclasses.dataclass
class ParsedInputs:
    synthetic_inputs: FrozenOrderedSet[int]
    inputs: tuple[TResolverFeatureType, ...]
    default_args: list[ResolverArgErrorHandlerParsed | None]


class FromProtoConverter:
    @classmethod
    def _get_comparison_against_window_bounds(
        cls,
        fil: expr_pb.LogicalExprNode,
        bound_matcher: Callable[[expr_pb.LogicalExprNode], bool],
    ) -> expr_pb.LogicalExprNode | None:
        """Return the non-bound operand if `fil` is a comparison involving `bound_matcher`, else None."""
        if (
            fil.HasField("call")
            and fil.call.func.HasField("identifier")
            and len(fil.call.args) == 2
            and len(fil.call.kwargs) == 0
        ):
            op = fil.call.func.identifier.name
            lhs, rhs = fil.call.args
        elif fil.HasField("binary_expr") and len(fil.binary_expr.operands) == 2:
            op = fil.binary_expr.op
            lhs, rhs = fil.binary_expr.operands
        else:
            return None
        if op not in (">", ">=", "<", "<="):
            return None
        if bound_matcher(lhs):
            return rhs
        if bound_matcher(rhs):
            return lhs
        return None

    @classmethod
    def _extract_filters_and_bucket_feature(
        cls, filters: Sequence[expr_pb.LogicalExprNode], graph: ResolvedGraph
    ) -> tuple[list[FilterParsed], ScalarFeatureType | FeatureTimeFeatureType | None]:
        def is_chalk_window(expr: expr_pb.LogicalExprNode) -> bool:
            return (
                expr.HasField("get_attribute")
                and expr.get_attribute.parent.HasField("identifier")
                and expr.get_attribute.parent.identifier.name == "_"
                and expr.get_attribute.attribute.name == "chalk_window"
            )

        def is_chalk_now(expr: expr_pb.LogicalExprNode) -> bool:
            return (
                expr.HasField("column")
                and expr.column.HasField("relation")
                and expr.column.name == "now"
                and expr.column.relation.relation == "__chalk__"
            )

        result_filters: list[expr_pb.LogicalExprNode] = []
        bucket_proto = None
        for fil in filters:
            maybe_bucket_proto = cls._get_comparison_against_window_bounds(fil, is_chalk_window)
            if maybe_bucket_proto is not None:
                if bucket_proto is not None:
                    raise ValueError("Can only specify one bucket feature")
                bucket_proto = maybe_bucket_proto
                continue
            if cls._get_comparison_against_window_bounds(fil, is_chalk_now) is not None:
                continue  # stripped — applied dynamically at query time
            result_filters.append(fil)

        bucket_feature = None
        if bucket_proto is not None:
            bucket_ref = cls.convert_filter_node(bucket_proto, graph=graph)
            if isinstance(bucket_ref, pb.FeatureReference):
                bucket_feature = cls.convert_feature_reference(bucket_ref, graph=graph)
            elif isinstance(bucket_ref, (ScalarFeatureType, FeatureTimeFeatureType)):
                bucket_feature = bucket_ref
            else:
                raise ValueError(f"Expected feature reference for bucket feature, got {bucket_ref}")
        if bucket_feature is not None:
            if not isinstance(bucket_feature, (ScalarFeatureType, FeatureTimeFeatureType)):
                raise ValueError(f"Expected bucket feature to be scalar or feature-time, got {type(bucket_feature)}")

        return [cls.convert_filter(f, graph=graph) for f in result_filters], bucket_feature

    @staticmethod
    def should_skip_foreign_feature(feat: NamedFeatureType) -> bool:
        return (
            isinstance(feat, (HasOneFeatureType, HasManyFeatureType))
            or feat.name == CHALK_FK_SINGLETON_NAME
            or feat.name == GENERATED_OBSERVED_AT_NAME
            or feat.name.startswith("__chalk__distance__")
            or feat.name.startswith("__chalklast__")
        )

    @staticmethod
    def construct_dtype(
        feature: NamedFeatureType,
        namespace_to_features: NamespaceToFeatures,
        namespace_to_dtype: dict[str, pa.DataType],
        fqn_to_feature: FqnToFeature,
    ) -> pa.DataType:
        if isinstance(feature, WindowedFeatureType):
            if not feature.windows:
                raise ValueError("Malformed windowed feature - `windows` attribute is empty")
            pseudofeature_fqn = get_name_with_duration(feature.fqn, list(feature.windows)[0])
            if pseudofeature_fqn not in fqn_to_feature:
                raise ValueError(f"Windowed pseudofeature '{pseudofeature_fqn}' not found")
            pseudofeature = fqn_to_feature[pseudofeature_fqn]
            if not isinstance(pseudofeature, ScalarFeatureType):
                raise ValueError(
                    f"Expected windowed pseudofeature '{pseudofeature.fqn}' to be scalar, "
                    + f"got {type(pseudofeature).__name__}"
                )
            res = pseudofeature.pyarrow_dtype
        elif isinstance(feature, HasManyFeatureType):
            if feature.foreign_namespace() in namespace_to_dtype:
                return namespace_to_dtype[feature.foreign_namespace()]
            fields: list[pa.Field] = []
            # There could be duplicates in the foreign features, so we need to dedupe them
            foreign_features = feature.df.columns
            if not foreign_features:
                raise ValueError(f"no features found for the namespace '{feature.namespace}'")
            for f in foreign_features:
                if FromProtoConverter.should_skip_foreign_feature(f):
                    continue
                fields.append(
                    pa.field(
                        name=f.fqn,
                        type=FromProtoConverter.construct_dtype(
                            f,
                            namespace_to_features=namespace_to_features,
                            namespace_to_dtype=namespace_to_dtype,
                            fqn_to_feature=fqn_to_feature,
                        ),
                    )
                )
            res = pa.large_list(pa.struct(fields))
            namespace_to_dtype[feature.foreign_namespace()] = res
        elif isinstance(feature, (ScalarFeatureType, FeatureTimeFeatureType)):
            res = feature.pyarrow_dtype
        else:
            raise ValueError(f"Unexpected feature type: {type(feature).__name__}")

        return res

    @staticmethod
    def get_feature_by_reference(feature_reference: pb.FeatureReference, graph: ResolvedGraph) -> NamedFeature:
        fqn = f"{feature_reference.namespace}.{feature_reference.name}"
        materialized_feature = graph.feature_from_fqn(fqn)
        if materialized_feature is None:
            raise ValueError(f"Feature '{fqn}' not found in the graph")
        assert not isinstance(materialized_feature, InputFeatureType), "The fqn is not an input"

        if feature_reference.HasField("df"):
            if not isinstance(materialized_feature, HasManyFeatureType):
                raise ValueError(
                    f"Expected feature '{materialized_feature}' to be has-many, got '{type(materialized_feature).__name__}'"
                )
            materialized_feature = dataclasses.replace(
                materialized_feature,
                df=FromProtoConverter.convert_dataframe(feature_reference.df, graph),
            )
        return materialized_feature

    @staticmethod
    def feature_ref_to_root_fqn(ref: pb.FeatureReference):
        if len(ref.path) > 0:
            return ref.path[0].namespace + "." + ".".join(x.name for x in ref.path)
        return f"{ref.namespace}.{ref.name}"

    @staticmethod
    def convert_feature_reference(
        ref: pb.FeatureReference,
        graph: ResolvedGraph,
    ) -> NamedFeature | InputFeatureType[NamedFeature]:
        feature = FromProtoConverter.get_feature_by_reference(ref, graph)

        if len(ref.path) > 0:
            path: list[HasOnePathObjParsed] = []
            child = None
            for i in range(len(ref.path)):
                e = ref.path[i]
                parent = child if child else FromProtoConverter.get_feature_by_reference(e, graph)
                if not isinstance(parent, (HasOneFeatureType, HasManyFeatureType)):
                    raise TypeError(f"Expected parent to be a has-one or has-many, got {type(parent).__name__}")
                child = (
                    FromProtoConverter.get_feature_by_reference(ref.path[i + 1], graph)
                    if i < len(ref.path) - 1
                    else feature
                )
                if not isinstance(  # pyright: ignore[reportUnnecessaryIsInstance]
                    child,
                    (
                        ScalarFeatureType,
                        HasManyFeatureType,
                        HasOneFeatureType,
                        FeatureTimeFeatureType,
                        WindowedFeatureType,
                    ),
                ):
                    raise TypeError(f"Expected child to be a scalar, has-many, or has-one, got {type(child).__name__}")
                if not isinstance(
                    child,
                    (
                        HasOneFeatureType,
                        HasManyFeatureType,
                        ScalarFeatureType,
                        FeatureTimeFeatureType,
                    ),
                ):
                    raise ValueError(f"Unexpected feature type: {type(child).__name__}")
                path.append(HasOnePathObjParsed(parent, child))

            return InputFeatureType(
                underlying_ref=path[-1].child,
                path=tuple(path),
                _graph=graph,
            )

        return feature

    @staticmethod
    def convert_foreign_feature_access_node(
        node: expr_pb.LogicalExprNode,
    ) -> pb.FeatureReference:
        if not node.HasField("binary_expr"):
            raise ValueError("Expected binary_expr field in foreign_feature_access node")
        if node.binary_expr.op != "foreign_feature_access":
            raise ValueError("Expected foreign_feature_access operation")

        if len(node.binary_expr.operands) < 2:
            raise ValueError("Expected at least 2 operands for foreign_feature_access")
        path: list[pb.FeatureReference] = []
        for operand in node.binary_expr.operands[:-1]:
            if not operand.HasField("column"):
                raise ValueError("Expected column field in foreign_feature_access")
            if not operand.column.HasField("relation"):
                raise ValueError("Expected relation field in foreign_feature_access")
            path.append(pb.FeatureReference(namespace=operand.column.relation.relation, name=operand.column.name))
        if not node.binary_expr.operands[-1].HasField("column"):
            raise ValueError("Expected column field in foreign_feature_access last operand")
        if not node.binary_expr.operands[-1].column.HasField("relation"):
            raise ValueError("Expected relation field in foreign_feature_access last operand")
        return pb.FeatureReference(
            namespace=node.binary_expr.operands[-1].column.relation.relation,
            name=node.binary_expr.operands[-1].column.name,
            path=path,
        )

    @staticmethod
    def convert_filter_node(
        node: expr_pb.LogicalExprNode, graph: ResolvedGraph
    ) -> (
        TPrimitive
        | FilterParsed
        | ScalarFeatureType
        | FeatureTimeFeatureType
        | pb.FeatureReference
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ):
        if node.HasField("column"):
            if not node.column.HasField("relation"):
                raise ValueError("`relation` missing from protobuf `Column` message")
            ref = pb.FeatureReference(namespace=node.column.relation.relation, name=node.column.name)
            res = FromProtoConverter.convert_feature_reference(ref, graph)
            if not is_underlying_scalar(res) and not is_underlying_feature_time(res):
                raise ValueError(f"Expected scalar or feature-time feature, got {type(res).__name__}")
            return res
        elif node.HasField("binary_expr"):
            if node.binary_expr.op == "foreign_feature_access":
                ref = FromProtoConverter.convert_foreign_feature_access_node(node)
                res = FromProtoConverter.convert_feature_reference(ref, graph)
                if not is_underlying_scalar(res) and not is_underlying_feature_time(res):
                    raise ValueError(f"Expected scalar or feature-time feature, got {type(res).__name__}")
                return res
            return FromProtoConverter.convert_filter(node, graph)
        elif node.HasField("literal"):
            pa_scalar = proto_to_pa_scalar(node.literal)
            pa_arr = pa.nulls(1, pa_scalar.type)
            if pa_scalar.is_valid:
                pa_arr = pa_arr.fill_null(pa_scalar)
            converter = PrimitiveFeatureConverter(name="helper", pyarrow_dtype=pa_arr.type, is_nullable=False)
            prim_vals = converter.from_pyarrow_to_primitive(pa_arr)
            if len(prim_vals) != 1:
                raise ValueError("There should only be 1 primitive value")
            if isinstance(prim_vals[0], list):
                return tuple(prim_vals[0])
            return prim_vals[0]
        else:
            raise ValueError(f"Malformed `LogicalExprNode` protobuf message: {node}")

    @classmethod
    def convert_filter(cls, proto: expr_pb.LogicalExprNode, graph: ResolvedGraph) -> FilterParsed:
        if not proto.HasField("binary_expr"):
            raise ValueError("Filter is a `LogicalExprNode` but does not have `binary_expr` set")

        if not is_valid_operation(proto.binary_expr.op) and proto.binary_expr.op not in [
            "foreign_feature_access",
            "attr",
        ]:
            raise ValueError(f"Invalid operation '{proto.binary_expr.op}'")

        combined_filter = None
        for node in proto.binary_expr.operands:
            if combined_filter is None:
                combined_filter = FromProtoConverter.convert_filter_node(node, graph)
            else:
                lhs = combined_filter
                if isinstance(lhs, pb.FeatureReference):
                    lhs = FeatureFqnMarker(cls.feature_ref_to_root_fqn(lhs), graph)
                rhs = FromProtoConverter.convert_filter_node(node, graph)
                if isinstance(rhs, pb.FeatureReference):
                    rhs = FeatureFqnMarker(cls.feature_ref_to_root_fqn(rhs), graph)
                combined_filter = FilterParsed(
                    lhs=lhs,
                    operation=cast(Operation, proto.binary_expr.op),
                    rhs=rhs,
                )
        if not isinstance(combined_filter, FilterParsed):
            raise ValueError("expected a `FilterParsed` object")
        return combined_filter

    @staticmethod
    def convert_dataframe(pb_df: pb.DataFrameType, graph: ResolvedGraph) -> DataFrameType:
        def convert_columns(
            columns: Sequence[pb.FeatureReference],
        ) -> FrozenOrderedSet[DataFrameColumn]:
            converted = [FromProtoConverter.convert_feature_reference(x, graph) for x in columns]
            flattened: list[DataFrameColumn] = []
            for f in converted:
                if is_underlying_has_one(f):
                    flattened.extend(f.flatten())
                else:
                    assert (
                        is_underlying_scalar(f)
                        or is_underlying_has_many(f)
                        or is_underlying_feature_time(f)
                        or is_underlying_windowed(f)
                    )
                    flattened.append(f)

            return FrozenOrderedSet(flattened)

        optional_cols = convert_columns(pb_df.optional_columns)
        if len(optional_cols) == 0:
            # Special case: If you take everything in the namespace, then the column list will be empty
            optional_cols = FrozenOrderedSet((pb_df.root_namespace,))
        return DataFrameType(
            limit=pb_df.limit if pb_df.HasField("limit") else None,
            filter=(FromProtoConverter.convert_filter(pb_df.filter, graph) if pb_df.HasField("filter") else None),
            required_column_refs=convert_columns(pb_df.required_columns),
            optional_column_refs=optional_cols,
            _graph=graph,
        )

    @staticmethod
    def convert_has_many(
        pb_has_many: pb.HasManyFeatureType,
        graph: ResolvedGraph,
        feature_set_max_staleness: timedelta | None,
        is_externally_defined: bool,
    ) -> HasManyFeatureType:
        if not pb_has_many.HasField("join"):
            raise ValueError(
                f"Join missing from protobuf message for feature {pb_has_many.namespace}.{pb_has_many.name}"
            )

        max_staleness = FromProtoConverter.resolve_max_staleness(
            feature_set_max_staleness=feature_set_max_staleness,
            feature_max_staleness=(
                pb_has_many.max_staleness_duration if pb_has_many.HasField("max_staleness_duration") else None
            ),
        )
        join = FromProtoConverter.convert_filter(pb_has_many.join, graph)

        # Assumes only one foreign namespace (which should always be true)
        def _validate_filter_recurse(filt: FilterParsed):
            if isinstance(filt.lhs, FilterParsed) and isinstance(filt.rhs, FilterParsed) and filt.operation == "and":
                _validate_filter_recurse(filt.lhs)
                return _validate_filter_recurse(filt.rhs)
            assert isinstance(filt.lhs, ScalarFeatureType)
            assert isinstance(filt.rhs, ScalarFeatureType)
            return filt.lhs.namespace if pb_has_many.namespace != filt.lhs.namespace else filt.rhs.namespace

        foreign_ns = _validate_filter_recurse(join)

        df = DataFrameType(
            required_column_refs=FrozenOrderedSet(),
            optional_column_refs=FrozenOrderedSet((foreign_ns,)),
            filter=None,
            limit=None,
            _graph=graph,
        )

        res = HasManyFeatureType(
            name=pb_has_many.name,
            namespace=pb_has_many.namespace,
            autogenerated=pb_has_many.is_autogenerated,
            max_staleness=max_staleness,
            online_store_max_items=pb_has_many.online_store_max_items
            if pb_has_many.HasField("online_store_max_items")
            else None,
            original_python_attribute_name=(
                None
                if pb_has_many.is_autogenerated
                else (pb_has_many.unversioned_attribute_name or pb_has_many.attribute_name or pb_has_many.name or None)
            ),
            attribute_name=pb_has_many.attribute_name or None,
            _graph=graph,
            join=join,
            df=df,
            is_externally_defined=is_externally_defined,
        )

        return res

    @staticmethod
    def convert_has_one(
        pb_has_one: pb.HasOneFeatureType, graph: ResolvedGraph, is_externally_defined: bool
    ) -> HasOneFeatureType:
        if not pb_has_one.HasField("join"):
            raise ValueError("Join missing from protobuf message")
        res = HasOneFeatureType(
            name=pb_has_one.name,
            namespace=pb_has_one.namespace,
            is_has_one_feature_nullable=pb_has_one.is_nullable,
            original_python_attribute_name=(
                None
                if pb_has_one.is_autogenerated
                else (pb_has_one.unversioned_attribute_name or pb_has_one.attribute_name or pb_has_one.name or None)
            ),
            autogenerated=pb_has_one.is_autogenerated,
            _graph=graph,
            join=FromProtoConverter.convert_filter(pb_has_one.join, graph),
            is_externally_defined=is_externally_defined,
            attribute_name=pb_has_one.attribute_name or None,
        )
        return res

    @staticmethod
    def convert_windowed(
        windowed_feature: pb.WindowedFeatureType, graph: ResolvedGraph, is_externally_defined: bool
    ) -> WindowedFeatureType:
        return WindowedFeatureType(
            namespace=windowed_feature.namespace,
            name=windowed_feature.name,
            autogenerated=windowed_feature.is_autogenerated,
            _graph=graph,
            windows=FrozenOrderedSet([int(to_timedelta(t).total_seconds()) for t in windowed_feature.window_durations]),
            is_externally_defined=is_externally_defined,
        )

    @staticmethod
    def convert_feature_time(
        pb_feature_time: pb.FeatureTimeFeatureType, graph: ResolvedGraph, is_externally_defined: bool
    ) -> FeatureTimeFeatureType:
        return FeatureTimeFeatureType(
            name=pb_feature_time.name,
            namespace=pb_feature_time.namespace,
            original_python_attribute_name=None if pb_feature_time.is_autogenerated else pb_feature_time.attribute_name,
            attribute_name=GENERATED_OBSERVED_AT_NAME
            if pb_feature_time.is_autogenerated
            else pb_feature_time.attribute_name,
            autogenerated=pb_feature_time.is_autogenerated,
            _graph=graph,
            is_externally_defined=is_externally_defined,
        )

    @staticmethod
    def resolve_max_staleness(
        feature_set_max_staleness: timedelta | None,
        feature_max_staleness: duration_pb.Duration | None,
    ):
        max_staleness = feature_set_max_staleness
        if max_staleness is None:
            max_staleness = timedelta(0)
        if feature_max_staleness:
            max_staleness = to_internal_duration(feature_max_staleness)

        return max_staleness

    @staticmethod
    def convert_scalar_value(
        value: arrow_pb.ScalarValue,
        *,
        is_arrow_scalar_object: bool,
    ) -> TPrimitive:
        """
        If `is_arrow_scalar_object` is `True`, then the result will be an `pyarrow.Scalar` object.
        Otherwise, it will be unwrapped into some underlying Python value.
        """

        pa_defaults: pa.Scalar = proto_to_pa_scalar(value)

        if is_arrow_scalar_object:
            return TPrimitiveArrowScalar(pa_defaults)

        if pa_defaults.is_valid:
            pa_arr = pa.array([pa_defaults])
        else:
            pa_arr = pa.nulls(1, pa_defaults.type)
        converter = PrimitiveFeatureConverter(name="helper", pyarrow_dtype=pa_defaults.type, is_nullable=False)
        pb_defaults = converter.from_pyarrow_to_primitive(pa_arr)
        if len(pb_defaults) != 1:
            raise ValueError(f"There should 1 default value post-conversion, found {len(pb_defaults)}")
        return pb_defaults[0]

    @classmethod
    def convert_group_by(
        cls, pb_group_by: pb.GroupByFeatureType, graph: ResolvedGraph, is_externally_defined: bool
    ) -> GroupByFeatureType:
        assert pb_group_by.HasField("aggregation")
        assert pb_group_by.aggregation is not None
        aggregation = pb_group_by.aggregation

        parsed_aggregation = parse_materialized_aggregation_type_from_name(aggregation.aggregation)
        if parsed_aggregation is None:
            raise ValueError(
                f"Unable to parse proto for group-by-feature-type operation on namespace {pb_group_by.aggregation.namespace}, because aggregate operation {repr(pb_group_by.aggregation.aggregation)} is not supported"
            )

        non_bucket_filters, bucket_feature = cls._extract_filters_and_bucket_feature(aggregation.filters, graph=graph)
        if bucket_feature is None:
            bucket_feature = graph.ts_feature_for_namespace(aggregation.namespace)
            if bucket_feature is None:
                raise ValueError(f"No bucket feature found for namespace {aggregation.namespace}")

        group_by: list[ScalarFeatureType] = []
        for f in aggregation.group_by:
            feat = cls.convert_feature_reference(f, graph)
            if not isinstance(feat, ScalarFeatureType):
                raise ValueError(f"Group-by feature {feat.fqn} is not a scalar feature: {feat}")
            group_by.append(feat)

        # Prefer the newer repeated field. Fall back to the deprecated singular `aggregate_on`
        # so plans serialized before the multi-column generalization still deserialize.
        agg_on_refs = list(aggregation.aggregate_on_features)
        if not agg_on_refs and aggregation.HasField("aggregate_on"):
            agg_on_refs = [aggregation.aggregate_on]  # pyright: ignore[reportAttributeAccessIssue]
        aggregate_on = list[ScalarFeatureType | FeatureTimeFeatureType]()
        for feature in agg_on_refs:
            converted = cls.convert_feature_reference(feature, graph)
            if not isinstance(converted, (ScalarFeatureType, FeatureTimeFeatureType)):
                raise ValueError(f"Window materialization child feature must be a scalar feature, got {aggregate_on}")
            aggregate_on.append(converted)
        if not agg_on_refs:
            if parsed_aggregation != MaterializedAggregationType.Count:
                raise ValueError(
                    f"Window materialization child feature must be specified for aggregation {repr(aggregation.aggregation)}"
                )
            primary = graph.primary_feature_for_namespace(aggregation.namespace)
            if primary is None:
                raise ValueError(f"Could not find primary feature for namespace {aggregation.namespace}")
            aggregate_on = [primary]

        aggregation_kwargs = []
        if aggregation.HasField("approx_top_k_arg_k"):  # pyright: ignore[reportAttributeAccessIssue]
            aggregation_kwargs.append(("k", aggregation.approx_top_k_arg_k))

        return GroupByFeatureType(
            window_materialization=MaterializationWindowConfigParsed(
                namespace=aggregation.namespace,
                group_by=tuple(group_by),
                bucket_duration=to_timedelta(aggregation.bucket_duration),
                bucket_start=aggregation.bucket_start.ToDatetime(tzinfo=timezone.utc),
                aggregation=parsed_aggregation,
                aggregate_on=expand_legacy_min_max_by_n_aggregate_on(
                    parsed_aggregation,
                    tuple(aggregate_on),
                    bucket_feature,
                ),
                aggregation_kwargs=FrozenOrderedSet(aggregation_kwargs),
                pyarrow_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(aggregation.arrow_type),
                filters=tuple(non_bucket_filters),
                bucket_feature=bucket_feature,
                continuous_buffer_duration=(
                    to_timedelta(aggregation.continuous_buffer_duration)
                    if aggregation.HasField("continuous_buffer_duration")
                    else None
                ),
                backfill_lookback_duration=(
                    to_timedelta(aggregation.backfill_lookback_duration)
                    if aggregation.HasField("backfill_lookback_duration")
                    else None
                ),
                continuous_resolver=aggregation.continuous_resolver
                if aggregation.HasField("continuous_resolver")
                else None,
                backfill_resolver=aggregation.backfill_resolver if aggregation.HasField("backfill_resolver") else None,
                backfill_schedule=aggregation.backfill_schedule if aggregation.HasField("backfill_schedule") else None,
                backfill_start_time=aggregation.backfill_start_time.ToDatetime(tzinfo=timezone.utc)
                if aggregation.HasField("backfill_start_time")
                else None,
            ),
            windows=FrozenOrderedSet(d.ToSeconds() for d in pb_group_by.window_durations),
            name=pb_group_by.name,
            namespace=pb_group_by.namespace,
            attribute_name=pb_group_by.attribute_name or None,
            original_python_attribute_name=pb_group_by.unversioned_attribute_name
            or pb_group_by.attribute_name
            or pb_group_by.name
            or None,
            _graph=graph,
            is_externally_defined=is_externally_defined,
        )

    @classmethod
    def _convert_feature_validations(
        cls, validations: Iterable[pb.FeatureValidation]
    ) -> tuple[FeatureValidationsParsed, ...]:
        """
        Parse feature validations from proto.
        For certain validations ("min", "max", "min_length", "max_length"), the cliet might also include a version that uses arrow scalars
        (min_arrow, max_arrow, etc...), in which case we dedupe & prefer those.
        :param validations:
        :return:
        """

        def _extract_validation_raw(
            v: pb.FeatureValidation, name: Literal["min", "max", "min_length", "max_length"]
        ) -> int | float | None:
            if not v.HasField(name):
                return None
            return getattr(v, name)

        def _extract_validation_arrow(v: pb.FeatureValidation, name: str) -> TPrimitive:
            if not v.HasField(name):
                return None
            scalar = proto_to_pa_scalar(getattr(v, name))
            return scalar.as_py()  # pyright: ignore[reportReturnType]

        def _extract_validation(
            v: pb.FeatureValidation,
            name: Literal[
                "min",
                "max",
                "min_length",
                "max_length",
                "min_arrow",
                "max_arrow",
                "min_length_arrow",
                "max_length_arrow",
            ],
        ) -> int | float | None:
            if name.endswith("_arrow"):
                return _extract_validation_arrow(v, name)  # pyright: ignore[reportReturnType]
            return _extract_validation_raw(v, name)  # pyright: ignore

        # (name, is_strict, val) --> FeatureValidationsParsed
        deduped_validations_by_key: dict[tuple[str, bool, int | float | None], FeatureValidationsParsed] = {}
        final_validations: list[FeatureValidationsParsed] = []
        for v in validations:
            name: str | None = v.WhichOneof("validation")
            if name is None:
                continue

            # special logic for fields that have an arrow and non-arrow proto version (for backwards compat)
            if name in [
                "min",
                "max",
                "min_length",
                "max_length",
                "min_arrow",
                "max_arrow",
                "min_length_arrow",
                "max_length_arrow",
            ]:
                value = _extract_validation(v, name)  # pyright: ignore
                validation_dict: dict[str, int | float | None] = {
                    "min": None,
                    "max": None,
                    "min_length": None,
                    "max_length": None,
                    name.removesuffix("_arrow"): value,
                }
                deduped_validations_by_key[(name, v.strict, value)] = FeatureValidationsParsed(
                    strict=v.strict,
                    contains=...,
                    **validation_dict,  # pyright: ignore[reportArgumentType]
                )
            else:
                # TODO if we support more validations, put logic here
                final_validations.append(
                    FeatureValidationsParsed(
                        min=None,
                        max=None,
                        min_length=None,
                        max_length=None,
                        strict=v.strict,
                        contains=...,  # note: we currently ignore the 'contains' field
                    )
                )

        for (name, is_strict, val), v_parsed in deduped_validations_by_key.items():
            # prefer the arrow version
            if (name + "_arrow", is_strict, val) in deduped_validations_by_key:
                continue
            final_validations.append(v_parsed)
        return tuple(final_validations)

    @classmethod
    def convert_rich_type(cls, rich_type: pb.RichClassType) -> SerializedRichType:
        params = tuple(cls.convert_rich_type(p) for p in rich_type.params)
        return SerializedRichType(module_name=rich_type.module_name, qualname=rich_type.qualname, type_params=params)

    @classmethod
    def convert_scalar(
        cls,
        pb_scalar: pb.ScalarFeatureType,
        has_last: bool,
        feature_set_is_singleton: bool,
        feature_set_max_staleness: timedelta | None,
        feature_set_etl_offline_to_online: bool | None,
        is_externally_defined: bool,
        graph: ResolvedGraph,
    ) -> ScalarFeatureType:
        if not pb_scalar.HasField("arrow_type"):
            raise ValueError("Arrow type missing from protobuf message")

        max_staleness = FromProtoConverter.resolve_max_staleness(
            feature_set_max_staleness=feature_set_max_staleness,
            feature_max_staleness=(
                pb_scalar.max_staleness_duration if pb_scalar.HasField("max_staleness_duration") else None
            ),
        )
        if pb_scalar.HasField("last_for"):
            max_staleness = INTERNAL_TTL_MAX
        if pb_scalar.name == "__chalk_fk_singleton__":
            max_staleness = timedelta(0)

        minimum_write_max_staleness = max_staleness
        if has_last:
            minimum_write_max_staleness = CHALK_MAX_TIMEDELTA

        etl_offline_to_online = feature_set_etl_offline_to_online
        if etl_offline_to_online is None:
            etl_offline_to_online = False
        if pb_scalar.HasField("etl_offline_to_online"):
            etl_offline_to_online = pb_scalar.etl_offline_to_online

        offline_ttl = INTERNAL_TTL_MAX
        if pb_scalar.HasField("offline_ttl_duration"):
            offline_ttl = to_internal_duration(pb_scalar.offline_ttl_duration)

        converter = PrimitiveFeatureConverter(
            name=f"{pb_scalar.namespace}.{pb_scalar.name}",
            pyarrow_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(pb_scalar.arrow_type),
            is_nullable=pb_scalar.is_nullable,
            primitive_default=(
                FromProtoConverter.convert_scalar_value(
                    pb_scalar.default_value,
                    is_arrow_scalar_object=False,
                )
                if pb_scalar.HasField("default_value")
                else ...
            ),
        )
        rich_converter_info: RichConverterInfo
        if pb_scalar.HasField("rich_type_info"):
            info_proto = pb_scalar.rich_type_info
            rich_type: SerializedRichType | None = None
            if info_proto.HasField("rich_type") and (info_proto.rich_type.WhichOneof("type") == "class_type"):
                rich_type = cls.convert_rich_type(info_proto.rich_type.class_type)
            rich_converter_info = RichConverterInfo(
                has_nontrivial_rich_type=not pb_scalar.rich_type_info.rich_type_is_same_as_primitive_type,
                rich_type_name=info_proto.rich_type_name,
                rich_type=rich_type,
            )
        else:
            rich_converter_info = RichConverterInfo(has_nontrivial_rich_type=True)

        validations = cls._convert_feature_validations(pb_scalar.validations)

        window_config: WindowConfig | None = None
        if pb_scalar.HasField("window_info"):
            if not pb_scalar.window_info.HasField("duration"):
                raise ValueError("Window duration missing from protobuf message")
            window_config = WindowConfig(window_duration=to_timedelta(pb_scalar.window_info.duration))
            if pb_scalar.window_info.HasField("aggregation"):
                aggregation = pb_scalar.window_info.aggregation
                # to match
                # https://github.com/chalk-ai/chalk-private/blob/db86588483a4a7b69f0cfa3b8ecdf58728cffb97/chalkruntime/chalkruntime/loader/converter.py#L373-L381
                max_staleness = timedelta(0)
                minimum_write_max_staleness = timedelta(0)
                parsed_aggregation = parse_materialized_aggregation_type_from_name(aggregation.aggregation)
                if parsed_aggregation is None:
                    raise ValueError(
                        f"Unable to parse proto for scalar feature '{pb_scalar.namespace}.{pb_scalar.name}' because the materialized aggregation operation {repr(aggregation.aggregation)} is not supported"
                    )

                non_bucket_filters, bucket_feature = cls._extract_filters_and_bucket_feature(
                    aggregation.filters, graph=graph
                )
                if bucket_feature is None:
                    bucket_feature = graph.ts_feature_for_namespace(aggregation.namespace)
                    if bucket_feature is None:
                        raise ValueError(f"No bucket feature found for namespace {aggregation.namespace}")

                group_by: list[ScalarFeatureType] = []
                for f in aggregation.group_by:
                    feat = cls.convert_feature_reference(f, graph)
                    if not isinstance(feat, ScalarFeatureType):
                        raise ValueError(f"Group-by feature {feat.fqn} is not a scalar feature: {feat}")
                    group_by.append(feat)

                # Prefer the newer repeated field. Fall back to the deprecated singular
                # `aggregate_on` so plans serialized before the multi-column generalization
                # still deserialize.
                agg_on_refs = list(aggregation.aggregate_on_features)
                if not agg_on_refs and aggregation.HasField("aggregate_on"):
                    agg_on_refs = [aggregation.aggregate_on]  # pyright: ignore[reportAttributeAccessIssue]
                aggregate_on = list[ScalarFeatureType | FeatureTimeFeatureType]()
                for feature in agg_on_refs:
                    converted = cls.convert_feature_reference(feature, graph)
                    if not isinstance(converted, (ScalarFeatureType, FeatureTimeFeatureType)):
                        raise ValueError(
                            f"Window materialization child feature must be a scalar feature, got {aggregate_on}"
                        )
                    aggregate_on.append(converted)
                if not agg_on_refs:
                    if parsed_aggregation != MaterializedAggregationType.Count:
                        raise ValueError(
                            f"Window materialization child feature must be specified for aggregation {repr(aggregation.aggregation)}"
                        )
                    primary = graph.primary_feature_for_namespace(aggregation.namespace)
                    if primary is None:
                        raise ValueError(f"Could not find primary feature for namespace {aggregation.namespace}")
                    aggregate_on = [primary]

                aggregation_kwargs = []
                if aggregation.HasField("approx_top_k_arg_k"):  # pyright: ignore[reportAttributeAccessIssue]
                    aggregation_kwargs.append(("k", aggregation.approx_top_k_arg_k))

                window_materialization = MaterializationWindowConfigParsed(
                    namespace=aggregation.namespace,
                    group_by=tuple(group_by),
                    bucket_duration=to_timedelta(aggregation.bucket_duration),
                    bucket_start=aggregation.bucket_start.ToDatetime(tzinfo=timezone.utc),
                    aggregation=parsed_aggregation,
                    aggregate_on=expand_legacy_min_max_by_n_aggregate_on(
                        parsed_aggregation,
                        tuple(aggregate_on),
                        bucket_feature,
                    ),
                    aggregation_kwargs=FrozenOrderedSet(aggregation_kwargs),
                    pyarrow_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(aggregation.arrow_type),
                    filters=tuple(non_bucket_filters),
                    bucket_feature=bucket_feature,
                    continuous_buffer_duration=(
                        to_timedelta(aggregation.continuous_buffer_duration)
                        if aggregation.HasField("continuous_buffer_duration")
                        else None
                    ),
                    backfill_lookback_duration=(
                        to_timedelta(aggregation.backfill_lookback_duration)
                        if aggregation.HasField("backfill_lookback_duration")
                        else None
                    ),
                    continuous_resolver=aggregation.continuous_resolver
                    if aggregation.HasField("continuous_resolver")
                    else None,
                    backfill_resolver=aggregation.backfill_resolver
                    if aggregation.HasField("backfill_resolver")
                    else None,
                    backfill_schedule=aggregation.backfill_schedule
                    if aggregation.HasField("backfill_schedule")
                    else None,
                    backfill_start_time=aggregation.backfill_start_time.ToDatetime(tzinfo=timezone.utc)
                    if aggregation.HasField("backfill_start_time")
                    else None,
                )
                window_config = dataclasses.replace(window_config, materialization_config=window_materialization)

        if pb_scalar.cache_strategy == pb.CACHE_STRATEGY_ALL:
            cache_strategy = CacheStrategy.ALL
        elif pb_scalar.cache_strategy == pb.CACHE_STRATEGY_NO_NULLS:
            cache_strategy = CacheStrategy.NO_NULLS
        elif pb_scalar.cache_strategy == pb.CACHE_STRATEGY_NO_DEFAULTS:
            cache_strategy = CacheStrategy.NO_DEFAULTS
        elif pb_scalar.cache_strategy == pb.CACHE_STRATEGY_NO_NULLS_OR_DEFAULTS:
            cache_strategy = CacheStrategy.NO_NULLS_OR_DEFAULTS
        elif pb_scalar.cache_strategy == pb.CACHE_STRATEGY_EVICT_NULLS:
            cache_strategy = CacheStrategy.EVICT_NULLS
        elif pb_scalar.cache_strategy == pb.CACHE_STRATEGY_EVICT_DEFAULTS:
            cache_strategy = CacheStrategy.EVICT_DEFAULTS
        elif pb_scalar.cache_strategy == pb.CACHE_STRATEGY_EVICT_NULLS_AND_DEFAULTS:
            cache_strategy = CacheStrategy.EVICT_NULLS_AND_DEFAULTS
        else:
            # N.B. CHA-6245: This is a dangerous default.
            _logger.warning("[CHA-6245] Unrecognized cache strategy: %s", pb_scalar.cache_strategy)
            # raise ValueError(f"`cache_strategy` unrecognized: {pb_scalar.cache_strategy}")
            cache_strategy = CacheStrategy.ALL

        underscore_expression: Underscore | None = None
        if pb_scalar.HasField("expression"):
            converted = Underscore._from_proto(pb_scalar.expression)  # pyright: ignore[reportPrivateUsage]
            assert isinstance(converted, Underscore), "Scalar expressions must be underscores"
            underscore_expression = converted

        offline_underscore_expression: Underscore | None = None
        if pb_scalar.HasField("offline_expression"):
            converted = Underscore._from_proto(pb_scalar.offline_expression)  # pyright: ignore[reportPrivateUsage]
            assert isinstance(converted, Underscore), "Scalar expressions must be underscores"
            offline_underscore_expression = converted

        if pb_scalar.HasField("expression_definition_location") and underscore_expression is not None:
            underscore_expression._chalk_definition_location = UnderscoreDefinitionLocation(  # pyright: ignore[reportPrivateUsage]
                file=pb_scalar.expression_definition_location.uri,
                line=pb_scalar.expression_definition_location.range.start.line,
                column=1,  # TODO: Dominic - see if we can maintain more specific line range info
            )

        return ScalarFeatureType(
            name=pb_scalar.name,
            namespace=pb_scalar.namespace,
            original_python_attribute_name=(
                None
                if pb_scalar.is_autogenerated
                else (pb_scalar.unversioned_attribute_name or pb_scalar.attribute_name or pb_scalar.name or None)
            ),
            attribute_name=pb_scalar.attribute_name or None,
            autogenerated=pb_scalar.is_autogenerated,
            converter=converter,
            is_windowed_pseudofeature=pb_scalar.HasField("window_info"),
            is_distance_pseudofeature=pb_scalar.is_distance_pseudofeature,
            is_windowed=False,  # Never is_windowed. That's a WindowedFeatureType.
            is_scalar_feature_nullable=pb_scalar.is_nullable,
            primary=pb_scalar.is_primary,
            description=pb_scalar.description if pb_scalar.description else None,
            owner=pb_scalar.owner if pb_scalar.owner else None,
            tags=FrozenOrderedSet(pb_scalar.tags),
            max_staleness=max_staleness,
            minimum_write_max_staleness=minimum_write_max_staleness,
            offline_ttl=offline_ttl,
            etl_offline_to_online=etl_offline_to_online,
            validations=validations,
            window_config=window_config,
            version=(
                VersionInfoParsed(
                    default=pb_scalar.version.default,
                    maximum=pb_scalar.version.maximum,
                    stripped_fqn=strip_version_suffix(f"{pb_scalar.namespace}.{pb_scalar.name}"),
                )
                if pb_scalar.HasField("version")
                else None
            ),
            is_singleton=feature_set_is_singleton,
            last_for_fqn=(
                (pb_scalar.last_for.namespace + "." + pb_scalar.last_for.name)
                if pb_scalar.HasField("last_for")
                else None
            ),
            is_deprecated=pb_scalar.is_deprecated,
            cache_strategy=cache_strategy,
            store_online=pb_scalar.store_online,
            store_offline=pb_scalar.store_offline,
            underscore_expression=underscore_expression,
            offline_underscore_expression=offline_underscore_expression,
            _graph=graph,
            is_externally_defined=is_externally_defined,
            rich_type_info=rich_converter_info,
        )

    @staticmethod
    def convert_features(
        feature_sets: list[pb.FeatureSet],
        graph: ResolvedGraph,
        ctx: GraphTransactionContext,
        is_externally_defined: bool,
    ) -> None:
        features_with_last: OrderedSet[tuple[str, str]] = OrderedSet()
        for fs in feature_sets:
            for f in fs.features:
                if f.HasField("scalar") and f.scalar.HasField("last_for"):
                    features_with_last.add((f.scalar.last_for.namespace, f.scalar.last_for.name))

        namespace_to_scalars_and_windowed: collections.defaultdict[
            str, list[pb.ScalarFeatureType | pb.WindowedFeatureType]
        ] = collections.defaultdict(list)
        namespace_to_scalars_with_agg: collections.defaultdict[str, list[pb.ScalarFeatureType]] = (
            collections.defaultdict(list)
        )
        namespace_to_feature_times: collections.defaultdict[str, list[pb.FeatureTimeFeatureType]] = (
            collections.defaultdict(list)
        )
        namespace_to_group_bys: collections.defaultdict[str, list[pb.GroupByFeatureType]] = collections.defaultdict(
            list
        )
        namespace_to_has_ones: collections.defaultdict[str, list[pb.HasOneFeatureType]] = collections.defaultdict(list)
        namespace_to_has_manys: collections.defaultdict[str, list[pb.HasManyFeatureType]] = collections.defaultdict(
            list
        )

        """
        Doing one loop to bucket the features into their respective types so that
        we don't use multiple separate loops over all feature sets because that is
        bug prone ala accidentally including a feature in multiple buckets.
        """
        for fs in feature_sets:
            for f in fs.features:
                if f.HasField("scalar"):
                    if f.scalar.HasField("window_info") and f.scalar.window_info.HasField("aggregation"):
                        namespace_to_scalars_with_agg[fs.name].append(f.scalar)
                    else:
                        namespace_to_scalars_and_windowed[fs.name].append(f.scalar)
                elif f.HasField("feature_time"):
                    namespace_to_feature_times[fs.name].append(f.feature_time)
                elif f.HasField("group_by"):
                    namespace_to_group_bys[fs.name].append(f.group_by)
                elif f.HasField("windowed"):
                    namespace_to_scalars_and_windowed[fs.name].append(f.windowed)
                elif f.HasField("has_one"):
                    namespace_to_has_ones[fs.name].append(f.has_one)
                elif f.HasField("has_many"):
                    namespace_to_has_manys[fs.name].append(f.has_many)
                else:
                    raise ValueError(f"Unknown feature type: {f.WhichOneof('type')}")

        def _upsert_scalars_or_windowed(
            feature_set: pb.FeatureSet,
            features: Sequence[pb.ScalarFeatureType | pb.WindowedFeatureType],
        ):
            staleness = (
                to_internal_duration(feature_set.max_staleness_duration)
                if feature_set.HasField("max_staleness_duration")
                else None
            )
            etl_offline_to_online = (
                feature_set.etl_offline_to_online if feature_set.HasField("etl_offline_to_online") else None
            )

            converted_features: list[ScalarFeatureType | WindowedFeatureType] = []
            for feat in features:
                try:
                    if isinstance(feat, pb.ScalarFeatureType):
                        converted_features.append(
                            FromProtoConverter.convert_scalar(
                                feat,
                                has_last=(feat.namespace, feat.name) in features_with_last,
                                feature_set_is_singleton=fs.is_singleton,
                                feature_set_max_staleness=staleness,
                                feature_set_etl_offline_to_online=etl_offline_to_online,
                                graph=graph,
                                is_externally_defined=is_externally_defined,
                            )
                        )
                    else:
                        converted_features.append(
                            FromProtoConverter.convert_windowed(
                                feat, graph, is_externally_defined=is_externally_defined
                            )
                        )
                except Exception as e:
                    raise ValueError(f"error converting feature '{feat.namespace}.{feat.name}'") from e

            ctx.upsert_features(converted_features)

        """
        The order in which we upsert these features into the ResolvedGraph needs to be in
        parity with how `load_graph` does it.
        """

        # Must do scalars first
        for fs in feature_sets:
            _upsert_scalars_or_windowed(fs, namespace_to_scalars_and_windowed[fs.name])

        # Then do feature times
        for fs in feature_sets:
            new_feature_times: list[FeatureTimeFeatureType] = []
            for f in namespace_to_feature_times[fs.name]:
                converted = FromProtoConverter.convert_feature_time(
                    f, graph, is_externally_defined=is_externally_defined
                )
                new_feature_times.append(converted)
            if not new_feature_times:
                new_feature_times.append(
                    FeatureTimeFeatureType(
                        name=GENERATED_OBSERVED_AT_NAME,
                        namespace=fs.name,
                        autogenerated=True,
                        original_python_attribute_name=None,
                        attribute_name=GENERATED_OBSERVED_AT_NAME,
                        _graph=graph,
                        is_externally_defined=is_externally_defined,
                    )
                )
            ctx.upsert_features(new_feature_times)

        # Then do scalars with windowed aggregation
        for fs in feature_sets:
            _upsert_scalars_or_windowed(fs, namespace_to_scalars_with_agg[fs.name])

        # Then do group by
        ctx.upsert_features(
            [
                FromProtoConverter.convert_group_by(f, graph, is_externally_defined=is_externally_defined)
                for fs in feature_sets
                for f in namespace_to_group_bys[fs.name]
            ]
        )

        # Then do has one
        ctx.upsert_features(
            [
                FromProtoConverter.convert_has_one(f, graph, is_externally_defined=is_externally_defined)
                for fs in feature_sets
                for f in namespace_to_has_ones[fs.name]
            ]
        )

        # Then do has-many
        for fs in feature_sets:
            max_staleness = (
                to_internal_duration(fs.max_staleness_duration) if fs.HasField("max_staleness_duration") else None
            )
            ctx.upsert_features(
                [
                    FromProtoConverter.convert_has_many(
                        f,
                        graph=graph,
                        feature_set_max_staleness=max_staleness,
                        is_externally_defined=is_externally_defined,
                    )
                    for f in namespace_to_has_manys[fs.name]
                ]
            )

    @staticmethod
    def _parse_inputs(
        inputs: Sequence[pb.ResolverInput],
        graph: ResolvedGraph,
        is_embedding_resolver: bool,
    ) -> ParsedInputs:
        inputs_and_defaults: list[tuple[TResolverFeatureType, ResolverArgErrorHandlerParsed | None]] = []
        for _i, inp in enumerate(inputs):
            if inp.HasField("feature"):
                converted = FromProtoConverter.convert_feature_reference(inp.feature.feature, graph)
                if not isinstance(  # pyright: ignore[reportUnnecessaryIsInstance]
                    converted,
                    (
                        ScalarFeatureType,
                        HasOneFeatureType,
                        HasManyFeatureType,
                        FeatureTimeFeatureType,
                        WindowedFeatureType,
                        InputFeatureType,
                    ),
                ):
                    raise ValueError(
                        f"Expected feature '{converted}' to be scalar, has-one, has-many, windowed, or feature-time, got {type(converted).__name__}"
                    )
                inputs_and_defaults.append(
                    (
                        cast(TResolverFeatureType, converted),
                        (
                            ResolverArgErrorHandlerParsed(
                                FromProtoConverter.convert_scalar_value(
                                    inp.feature.default_value,
                                    is_arrow_scalar_object=False,
                                )
                            )
                            if inp.feature.HasField("default_value")
                            else None
                        ),
                    )
                )
            elif inp.HasField("df"):
                inputs_and_defaults.append(
                    (
                        FromProtoConverter.convert_dataframe(inp.df, graph),
                        None,
                    )
                )
            elif inp.HasField("state"):
                raise ValueError("State[] resolver parameters are no longer supported.")
            else:
                raise ValueError("unrecognized resolver input protobuf message: ", inp)

        converted_inputs = [x for x, _ in inputs_and_defaults]

        # TODO: This is in parity with the behavior of `json_conversions.py`,
        #       but check whether we should check that the `DataFrameType` is
        #       the sole input, i.e.:
        #       ```
        #       if len(converted_inputs) == 0 and isinstance(converted_inputs[0], DataFrameType):
        #       ```
        if (
            converted_inputs and isinstance(converted_inputs[0], DataFrameType) and not is_embedding_resolver
        ):  # TODO: Unify how we set default args for DataFrameType and then remove `is_embedding_resolver`
            default_args: list[ResolverArgErrorHandlerParsed | None] = [None] * len(converted_inputs[0].columns)
        else:
            default_args: list[ResolverArgErrorHandlerParsed | None] = [y for _, y in inputs_and_defaults]
        return ParsedInputs(
            inputs=tuple(converted_inputs),
            default_args=default_args,
            synthetic_inputs=FrozenOrderedSet(),
        )

    @staticmethod
    def convert_data_source_name(
        ds_name: str,  # sources_pb.DatabaseSourceReference.name
    ) -> str | None:
        if ds_name.startswith(_CHALK_ANON_SQL_SOURCE_PREFIX) or ds_name.startswith(_CHALK_ANON_STREAM_SOURCE_PREFIX):
            # was converted without a name
            return None
        return ds_name or None

    @staticmethod
    def convert_data_source(
        ds: sources_pb.DatabaseSource,
        source_secrets: sources_pb.SourceSecrets | None = None,
    ) -> BaseSQLSource:
        """
        Converts a database source reference back to the SQL source or stream source. For purposes of planning,
        only the name and its type are important.
        """

        # The SQL Source/Source-Group constructors add `self` to the global registry of sources.
        # However for proto conversion we don't want to add the parsed objects, in unit tests/subprocesses this can create duplicate values
        # since the protos correspond to objects that have alreayd been created.
        with contextvar_ctx(_ENABLE_ADD_TO_SQL_SOURCE_REGISTRIES, False):
            secrets = source_secrets.secrets if source_secrets else None
            ds_name = ds.name or None  # empty string in proto implies the default source, which has no name
            ds_type = SQLSourceKind.convert_sql_source_kind(ds.source_type)
            match ds_type:
                case SQLSourceKind.athena:
                    return AthenaSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.bigquery:
                    return BigQuerySourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.cloudsql:
                    return CloudSQLSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.databricks:
                    return DatabricksSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.duckdb:
                    return DuckDBSourceImpl(name=ds_name)
                case SQLSourceKind.dynamodb:
                    return DynamoDBSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.mssql:
                    return MSSQLSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.mysql:
                    return MySQLSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.postgres:
                    return PostgreSQLSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.clickhouse:
                    return ClickhouseSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.redshift:
                    return RedshiftSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.snowflake:
                    return SnowflakeSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.spanner:
                    return SpannerSourceImpl(name=ds_name, integration_variable_override=secrets)
                case SQLSourceKind.sqlite:
                    return SQLiteSourceImpl(name=ds_name)
                case SQLSourceKind.trino:
                    return TrinoSourceImpl(name=ds_name, integration_variable_override=secrets)
            raise ValueError(f"Unknown datasource type for datasource {ds_name}")

    @classmethod
    def convert_stream_source(cls, ds: sources_pb.StreamSource) -> StreamSource:
        """
        Returns None for certain mock StreamSources that are not serializable and used internally for testing.
        """
        source_cls: Type[StreamSource]
        if ds.source_type == "kinesis":
            source_cls = KinesisSource
        elif ds.source_type == "kafka":
            source_cls = KafkaSource
        elif ds.source_type == "pubsub":
            source_cls = PubSubSource
        elif ds.source_type in ["mock", "ReshuffleMockStreamSource", "WindowMockStream"]:
            source_cls = functools.partial(CustomStreamSourceParsed, streaming_type=ds.source_type)  # pyright: ignore
        else:
            raise ValueError(f"Streaming source with name '{ds.name}' has unsupported type '{ds.source_type}'.")
        options_json = {k: proto_value_to_python(v) for k, v in ds.options.items()}
        options_json.pop("name", None)
        # Convert empty string to None to match Python convention (protobuf default for unset string is "")
        return source_cls(name=ds.name or None, **options_json)  # pyright: ignore

    @classmethod
    def convert_online_store_config(cls, config: pb.OnlineStoreConfig) -> OnlineStoreConfigParsed:
        """Convert a protobuf OnlineStoreConfig to a parsed Python dataclass."""
        lru_cache: LRUCacheConfigParsed | None = None
        if config.HasField("lru_cache"):
            lru_cache = LRUCacheConfigParsed(
                max_size=config.lru_cache.max_size,
                ttl=config.lru_cache.ttl.ToTimedelta(),
                store_cache_misses=config.lru_cache.store_cache_misses,
            )
        return OnlineStoreConfigParsed(
            name=config.name,
            lru_cache=lru_cache,
            feature_namespaces=tuple(config.feature_namespaces),
        )

    @classmethod
    def convert_data_source_group(
        cls, group: sources_pb.DatabaseSourceGroup, sources: dict[tuple[str, str | None], BaseSQLSource]
    ) -> SQLSourceGroup:
        # The SQL Source/Source-Group constructors add `self` to the global registry of sources.
        # However for proto conversion we don't want to add the parsed objects, in unit tests/subprocesses this can create duplicate values
        # since the protos correspond to objects that have alreayd been created.
        with contextvar_ctx(_ENABLE_ADD_TO_SQL_SOURCE_REGISTRIES, False):

            def get_source(pb_source: sources_pb.DatabaseSourceReference) -> BaseSQLSource:
                source = sources.get((pb_source.source_type, pb_source.name or None))
                if source is None:
                    raise ValueError(
                        f"Source named '{pb_source.name}' of type '{pb_source.source_type}' not found in sources"
                    )
                return source

            default_source: BaseSQLSource = get_source(group.default_source)
            tagged_sources: dict[str, BaseSQLSource] = {}
            for tag_name, s in group.tagged_sources.items():
                try:
                    tagged_source = get_source(s)
                except Exception as e:
                    raise ValueError(f"cannot get tagged source with tag name '{tag_name}'") from e
                tagged_sources[tag_name] = tagged_source

            return SQLSourceGroup(name=group.name, default=default_source, tagged_sources=tagged_sources)

    @classmethod
    def _convert_window_mode(cls, wm: pb.WindowMode) -> Literal["continuous", "tumbling", "cdc"]:
        if wm == pb.WINDOW_MODE_CONTINUOUS:
            return "continuous"
        if wm == pb.WINDOW_MODE_TUMBLING:
            return "tumbling"
        if wm == pb.WindowMode.WINDOW_MODE_CDC:
            return "cdc"
        if wm == pb.WindowMode.WINDOW_MODE_UNSPECIFIED:
            # Default to tumbling mode
            return "tumbling"
        raise ValueError(f"Unsupported enum value for stream resolver WindowMode: {wm}")

    @classmethod
    def convert_stream_resolver(
        cls, r: pb.StreamResolver, graph: ResolvedGraph, stream_sources: Dict[Tuple[str, str | None], StreamSource]
    ) -> StreamResolverParsed:
        # Resolver outputs
        outputs: list[TResolverFeatureType] = []
        for o in r.outputs:
            if o.HasField("feature"):
                feat = FromProtoConverter.convert_feature_reference(o.feature, graph)
                outputs.append(cast(TResolverFeatureType, feat))
            elif o.HasField("df"):
                outputs.append(FromProtoConverter.convert_dataframe(o.df, graph))
            else:
                raise ValueError("unrecognized resolver output protobuf message: ", o)

        # Keys
        key_refs: dict[str, TStreamOutputFeatureType] | None = None
        if len(r.keys) > 0:
            key_refs = {}
            for k in r.keys:
                f: TStreamOutputFeatureType = cls.convert_feature_reference(ref=k.feature, graph=graph)  # pyright: ignore
                key_refs[k.key] = f

        # Windowed pseudo-features: TODO...

        params = [cls._convert_stream_resolver_param(param) for param in r.params]

        output_feature_fqns: set[str] = set()
        for o in outputs:
            if isinstance(o, DataFrameType):
                output_feature_fqns.update([x.fqn for x in o.columns])
            else:
                output_feature_fqns.add(o.fqn)
        root_namespace: str | None = next(fqn.split(".")[0] for fqn in output_feature_fqns)  # noqa
        signature = StreamResolverSignatureParsed(output_feature_fqns=output_feature_fqns, params=params)
        window_index: int | None = None
        for i, w in enumerate(signature.params):
            if isinstance(w, StreamResolverParamMessageWindowParsed):
                window_index = i
                continue

        source = stream_sources.get((r.source_v2.source_type, r.source_v2.name or None))
        if source is None:
            raise ValueError(
                f"Stream resolver '{r.fqn}' refers to unknown streaming source with type '{r.source_v2.source_type}' and name '{r.source_v2.name}'"
            )

        parse_info: ParseInfoParsed | None = None
        if r.HasField("parse_info"):
            parse_underscore: UnderscoreValue | None = None
            if r.parse_info.WhichOneof("parse_expression") == "underscore_expr":
                underscore_expression = Underscore._from_proto(r.parse_info.underscore_expr)  # pyright: ignore[reportPrivateUsage]
                if not isinstance(underscore_expression, Underscore):
                    raise ValueError(
                        f"Parse expression in stream resolver '{r.fqn}' must be an Underscore, instead got {underscore_expression}"
                    )
                input_message_dtype = (
                    STREAM_RESOLVER_MESSAGE_ENVELOPE_TYPE
                    if r.message_format == StreamMessageFormat.STREAM_MESSAGE_FORMAT_FULL_ENVELOPE
                    else pa.large_binary()
                )
                parse_underscore = convert_underscore_expression(
                    underscore=underscore_expression,
                    for_feature=None,
                    graph=graph,
                    prompt_service=None,
                    root_namespace=root_namespace,
                    root_underscore_behavior=StreamResolverRootUnderscoreBehavior(message_dtype=input_message_dtype),
                    error_message_context=f"parse expression for stream resolver '{r.fqn}'",
                    for_offline_resolver=False,
                )
            parse_info = ParseInfoParsed(
                output_is_optional=r.parse_info.is_parse_function_output_optional,
                input_type_name=r.parse_info.parse_function_input_type_name,
                output_type_name=r.parse_info.parse_function_output_type_name,
                function_name=r.parse_info.parse_function.name,
                parse_expression=parse_underscore,
            )

        # If this resolver is defined using underscore expressions, parse them
        feature_expressions: dict[
            UnderlyingFeatureType[ScalarFeatureType] | UnderlyingFeatureType[FeatureTimeFeatureType], UnderscoreValue
        ] = {}
        if r.feature_expressions:
            # First, parse message schema
            if len(params) != 1:
                raise ValueError(
                    f"Stream resolver '{r.fqn}' has feature expressions defined, so it must have exactly one input parameter. (found {len(params)})"
                )
            message_param = params[0]
            if not isinstance(message_param, StreamResolverParamMessageParsed):
                raise ValueError(
                    f"Stream resolver '{r.fqn}' has feature expressions defined, so it doesn't support any state or window input parameters. (found {params[0]})"
                )
            if message_param.dtype is None:
                raise ValueError(
                    f"Failed to resolve datatype of parameter '{message_param.name}' for stream resolver '{r.fqn}'."
                )

            feature_input_dtype: pa.DataType = message_param.dtype
            if is_list_like(feature_input_dtype):
                # IF a parse function produces list[T], each feature expression operators on a single T
                assert isinstance(feature_input_dtype, pa.LargeListType)
                feature_input_dtype = feature_input_dtype.value_type

            # Then, parse each feature expression
            for feat, expr_proto in r.feature_expressions.items():
                if expr_proto.HasField("underscore_expr"):
                    underscore_expression = Underscore._from_proto(expr_proto.underscore_expr)  # pyright: ignore[reportPrivateUsage]
                    if not isinstance(underscore_expression, Underscore):
                        raise ValueError(
                            f"Column expression in stream resolver '{r.fqn}' for feature '{feat}' must be an Underscore, instead got {underscore_expression}"
                        )
                    feat_parsed = graph.feature_from_fqn(feat)
                    if feat_parsed is None:
                        raise ValueError(f"Output feature '{feat}' for stream resolver '{r.fqn}' not found.")
                    if not (is_underlying_scalar(feat_parsed) or is_underlying_feature_time(feat_parsed)):
                        raise ValueError(
                            f"Stream resolver feature expressions are not supported for non-scalar/non-featuretime feature {feat_parsed}"
                        )
                    underscore_parsed = convert_underscore_expression(
                        underscore=underscore_expression,
                        for_feature=feat_parsed,
                        graph=graph,
                        prompt_service=None,
                        root_namespace=feat_parsed.root_namespace,
                        root_underscore_behavior=StreamResolverRootUnderscoreBehavior(
                            message_dtype=feature_input_dtype
                        ),
                        for_offline_resolver=False,
                    )
                    feature_expressions[feat_parsed] = underscore_parsed
        sink_config: StreamSinkConfigParsed | None = None
        if r.HasField("message_producer"):
            # Parse send_to if present
            send_to: StreamSource | None = None
            if r.message_producer.HasField("send_to"):
                send_to_ref = r.message_producer.send_to
                send_to = stream_sources.get((send_to_ref.source_type, send_to_ref.name or None))
                if send_to is None:
                    raise ValueError(
                        f"Stream resolver '{r.fqn}' has a message producer that refers to unknown streaming source with type '{send_to_ref.source_type}' and name '{send_to_ref.name}'"
                    )

            output_features: list[TResolverFeatureType] = []
            for fqn in r.message_producer.output_features:
                feat = graph.feature_from_fqn(fqn)
                assert not isinstance(feat, GroupByFeatureType)  # for pyright
                if feat is None:
                    raise ValueError(
                        f"Stream resolver '{r.fqn}' has a message producer that references a non-existent output feature: '{fqn}'"
                    )
                output_features.append(feat)
            transformations: dict[
                UnderlyingFeatureType[ScalarFeatureType] | UnderlyingFeatureType[FeatureTimeFeatureType],
                UnderscoreValue,
            ] = {}
            # TODO (rkargon) need to figure out proper parsing for transformation exprs
            # for feat, expr_proto in r.message_producer.feature_expressions.items():
            #     if expr_proto.HasField("underscore_expr"):
            #         underscore_expression = Underscore._from_proto(expr_proto.underscore_expr)  # pyright: ignore[reportPrivateUsage]
            #         if not isinstance(underscore_expression, Underscore):
            #             raise ValueError(
            #                 f"Sink transformation for stream resolver '{r.fqn}' for feature '{feat}' must be a Chalk Expression, instead got {underscore_expression}"
            #             )
            #         feat_parsed = graph.feature_from_fqn(feat)
            #         if feat_parsed is None:
            #             raise ValueError(
            #                 f"Output feature '{feat}' for sink transformation for stream resolver '{r.fqn}' not found."
            #             )
            #         # TODO I think this is overly restrictive and we can fix
            #         if not (is_underlying_scalar(feat_parsed) or is_underlying_feature_time(feat_parsed)):
            #             raise ValueError(
            #                 f"Stream resolver transformation feature expressions are not supported for non-scalar/non-featuretime feature {feat_parsed}"
            #             )
            #         underscore_parsed = convert_underscore_expression(
            #             underscore=underscore_expression,
            #             for_feature=feat_parsed,
            #             graph=graph,
            #             prompt_service=None,
            #             root_namespace=feat_parsed.root_namespace,
            #             # TODO need to think about this -- are these transformations column ops or more like feature resolvers?
            #             # What's the root context here?
            #             root_underscore_behavior=StreamResolverRootUnderscoreBehavior(message_dtype=pa.null()),
            #             # root_underscore_behavior=ResolverRootUnderscoreBehavior(),
            #         )
            #         transformations[feat_parsed] = underscore_parsed
            if r.message_producer.format not in ("json", "ipc_stream"):
                raise ValueError(f"Unrecognized sink output format {r.message_producer.format}")
            sink_config = StreamSinkConfigParsed(
                send_to=send_to,
                output_features=output_features,
                feature_expressions=transformations,
                format=r.message_producer.format,
            )

        header_equality_filters: list[tuple[str, bytes]] = []
        for hf in r.header_filters:
            if hf.WhichOneof("kind") == "equality_check":
                header_equality_filters.append((hf.equality_check.key, hf.equality_check.value))
            else:
                raise ValueError(f"Unsupported message header filter for stream resolver {r.fqn}: {hf}")

        dedup_policy: DeduplicationPolicyParsed | None = None
        if r.HasField("deduplication_strategy"):
            if not feature_expressions:
                raise ValueError("Deduplication policy not supported for non-native streaming resolvers")

            def _expr_dtype(u: UnderscoreValue, name: str) -> pa.DataType:
                u_result = u.underscore_result_type
                if not isinstance(u_result, UnderscoreResultScalarType):
                    raise ValueError(
                        f"Stream resolver expression {u.original_underscore} (for feature '{name}') did not produce a scalar output; can't determine output dtype (result was {u_result})"
                    )
                return u_result.scalar_type

            output_schema = {k.root_fqn: _expr_dtype(v, k.root_fqn) for k, v in feature_expressions.items()}
            dedup_underscore = Underscore._from_proto(r.deduplication_strategy.underscore_expr)  # pyright: ignore[reportPrivateUsage]

            dedup_expr = convert_underscore_to_expr(
                u=dedup_underscore, schema=Schema(frozendict.frozendict(output_schema))
            )
            dedup_ttl = r.deduplication_strategy.window.ToTimedelta()
            dedup_policy = DeduplicationPolicyParsed(
                expr=dedup_expr,
                duration=dedup_ttl,
            )

        return StreamResolverParsed(
            ### StreamResolver-specific fields
            signature_parsed=signature,
            source=source,
            mode=cls._convert_window_mode(r.mode),
            windowed_pseudofeatures_refs={},  # TODO
            window_index=window_index,
            parse_info_parsed=parse_info,
            keys_refs=key_refs,
            updates_materialized_aggregations=r.update_aggregates,
            timestamp=r.timestamp_attribute_name if r.HasField("timestamp_attribute_name") else None,
            #### fields for ResolverParsed base class
            graph=graph,
            output_refs=outputs,
            resource_hint=None,
            resource_group=r.resource_group if r.HasField("resource_group") else None,
            function_definition=r.function.function_definition,
            function_captured_globals=FromProtoConverter.convert_function_captured_globals(r.function.captured_globals),
            filename=r.function.file_name,
            fqn=r.fqn,
            module=r.function.module,
            environment=tuple(r.environments) if r.environments else None,
            underscore_definition=None,
            doc=r.doc if r.HasField("doc") else None,
            machine_type=r.machine_type if r.HasField("machine_type") else None,
            owner=r.owner if r.HasField("owner") else None,
            timeout=to_timedelta(r.timeout_duration) if r.HasField("timeout_duration") else timedelta(),
            unique_on=FrozenOrderedSet(),
            partitioned_by=FrozenOrderedSet(),
            sql_settings=None,
            incremental_settings=None,
            accelerate_python="auto",
            is_total=False,
            tags=tuple(),
            is_generator=False,  # TODO
            source_line=r.function.source_line if r.function.HasField("source_line") else None,
            input_refs=[],
            synthetic_inputs=FrozenOrderedSet(),
            default_args=[],
            data_sources=[],
            is_externally_defined=False,
            feature_expressions=feature_expressions,
            output_row_order=None,
            venv=None,
            stream_sink_config=sink_config,
            postprocessing=None,
            skip_online=r.skip_online,
            skip_offline=r.skip_offline,
            use_message_envelope=(r.message_format == StreamMessageFormat.STREAM_MESSAGE_FORMAT_FULL_ENVELOPE),
            header_equality_filters=header_equality_filters,
            deduplication_policy=dedup_policy,
        )

    @classmethod
    def _convert_stream_resolver_param(cls, p: pb.StreamResolverParam) -> StreamResolverParamParsed:
        type_name = p.WhichOneof("type")
        maybe_arrow_dtype: pa.DataType | None = None
        if type_name == "message":
            if p.message.HasField("arrow_type"):
                maybe_arrow_dtype = PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(p.message.arrow_type)

            captured_message_type: FunctionCapturedGlobal | None = None
            struct_type_name = p.message.WhichOneof("struct_type")
            if struct_type_name == "struct":
                captured_message_type = FunctionCapturedGlobalStruct(
                    name=p.message.struct.name,
                    module=p.message.struct.module,
                    pa_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(p.message.struct.pa_dtype),
                )
            elif struct_type_name == "proto":
                captured_message_type = FunctionCapturedGlobalProto(
                    name=p.message.proto.name,
                    module=p.message.proto.module,
                    serialized_fd=p.message.proto.serialized_fd,
                    full_name=p.message.proto.full_name,
                    pa_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(p.message.proto.pa_dtype),
                )
            return StreamResolverParamMessageParsed(
                name=p.message.name, dtype=maybe_arrow_dtype, captured_message_type=captured_message_type
            )
        if type_name == "message_window":
            if p.message_window.HasField("arrow_type"):
                maybe_arrow_dtype = PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(
                    p.message_window.arrow_type
                )
            return StreamResolverParamMessageWindowParsed(
                name=p.message_window.name,
                dtype=maybe_arrow_dtype,
            )
        if type_name == "state":
            raise ValueError("State[] parameters are no longer supported.")
        else:
            raise ValueError(f"Unsupported variant type for StreamResolverParam: '{type_name}'")

    @staticmethod
    def convert_resolver(r: pb.Resolver, graph: ResolvedGraph, is_externally_defined: bool) -> ResolverParsed:
        parsed_inputs = FromProtoConverter._parse_inputs(
            r.inputs,
            graph,
            is_embedding_resolver=r.fqn.startswith("__chalk__embedding__resolver__namespace__"),
        )

        outputs: list[TResolverFeatureType] = []
        for o in r.outputs:
            if o.HasField("feature"):
                feat = FromProtoConverter.convert_feature_reference(o.feature, graph)
                outputs.append(cast(TResolverFeatureType, feat))
            elif o.HasField("df"):
                outputs.append(FromProtoConverter.convert_dataframe(o.df, graph))
            else:
                raise ValueError("unrecognized resolver output protobuf message: ", o)

        cron: Duration | CronTab | Cron | None = None
        if r.HasField("schedule"):
            if r.schedule.HasField("crontab"):
                cron = r.schedule.crontab
            elif r.schedule.HasField("duration"):
                cron = to_timedelta(r.schedule.duration)
            if r.schedule.HasField("filter") or r.schedule.HasField("sample"):
                assert cron is not None
                cron = Cron(
                    schedule=cron,
                    filter=None,  # TODO: Should populate if we start using for execution
                    sample=None,  # TODO: Should populate if we start using for execution
                )

        cron_filter_with_feature_args = None
        if r.HasField("cron_filter"):
            checked_args: list[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
            ] = []
            for f in [FromProtoConverter.convert_feature_reference(f, graph) for f in r.cron_filter.args]:
                if not is_underlying_scalar(f) and not is_underlying_feature_time(f):
                    raise ValueError(f"Expected scalar or feature-time feature, got {type(f).__name__}")
                checked_args.append(f)
            cron_filter_with_feature_args = CronFilterWithFeatureArgs(
                filter=lambda: True,  # TODO: bogus callable
                feature_args=checked_args,
            )

        def _raise(*args: object, **kargs: object):
            raise RuntimeError(
                "Parsed static resolvers have no callable function - obtain "
                + "the static operation directly from the resolver object"
            )

        if r.is_static:
            if r.HasField("static_operation_dataframe"):
                # Constructing a `DataFrame` table can have side-effects, because we may
                # scan data sources in order to discover schemas.
                #
                # Therefore, we should only do this lazily.

                from chalkdf import DataFrame

                static_op = _LazyStaticOp(
                    _factory=functools.partial(
                        DataFrame.from_lazyframe_proto,
                        r.static_operation_dataframe,
                    )
                )
            else:
                if not r.HasField("static_operation"):
                    raise ValueError("Static resolvers must have a static operation")
                # Constructing a `DataFrame` table can have side-effects, because we may
                # scan data sources in order to discover schemas.
                #
                # Therefore, we should only do this lazily.
                static_op = _LazyStaticOp(
                    _factory=functools.partial(
                        StaticOperator._from_proto,  # pyright: ignore[reportArgumentType, reportPrivateUsage]
                        r.static_operation,
                    )
                )

            if r.kind == pb.RESOLVER_KIND_ONLINE:
                resolver_cls = functools.partial(
                    MainProcOnlineResolver, static_operation=static_op, static=True, fn=_raise
                )
            elif r.kind == pb.RESOLVER_KIND_OFFLINE:
                resolver_cls = functools.partial(
                    MainProcOfflineResolver, static_operation=static_op, static=True, fn=_raise
                )
            else:
                raise ValueError(f"Unsupported static resolver kind: {r.kind}")
        else:
            if r.kind == pb.RESOLVER_KIND_ONLINE:
                resolver_cls = OnlineResolverParsed
            elif r.kind == pb.RESOLVER_KIND_OFFLINE:
                resolver_cls = OfflineResolverParsed
            else:
                raise ValueError(f"Unsupported resolver kind: {r.kind}")

        resource_hint: ResourceHintType | None = None
        if r.resource_hint == pb.RESOURCE_HINT_CPU:
            resource_hint = "cpu"
        elif r.resource_hint == pb.RESOURCE_HINT_IO:
            resource_hint = "io"
        elif r.resource_hint == pb.RESOURCE_HINT_GPU:
            resource_hint = "gpu"
        elif r.resource_hint == pb.RESOLVER_KIND_UNSPECIFIED:
            resource_hint = None
        else:
            raise ValueError(f"Unsupported resource hint: {r.resource_hint}")

        data_sources: list[BaseSQLSource | SQLSourceGroup] = []

        for pb_ds in r.data_sources_v2:
            if pb_ds.source_type == ToProtoConverter._database_source_group_type:  # pyright: ignore[reportPrivateUsage]
                group: SQLSourceGroup | None = graph.get_sql_source_group(pb_ds.name)
                if group is None:
                    raise ValueError(f"No datasource group named '{pb_ds.name}' was found in the graph")
                data_sources.append(group)
            else:
                try:
                    source_kind = SQLSourceKind(pb_ds.source_type)
                except ValueError as e:
                    raise ValueError(f"Source kind {pb_ds.source_type!r} is not supported") from e
                name = pb_ds.name or None
                ds = graph.get_sql_source(source_kind, name)
                if ds is None:
                    raise ValueError(
                        f"No datasource of kind '{source_kind.value}' named '{name}' was found in the graph"
                    )
                data_sources.append(ds)
        source_line: int | None = r.function.source_line if r.function.HasField("source_line") else None
        output_row_order = (
            None if ((not r.HasField("output_row_order")) or r.output_row_order == "") else r.output_row_order
        )
        if output_row_order not in (None, "one-to-one"):
            raise ValueError(f"output_row_order must be either None or 'one-to-one', received {r.output_row_order}")

        postprocessing_expr: Underscore | None = None
        if r.WhichOneof("postprocessing") == "underscore_expr":
            if not r.HasField("sql_settings"):
                raise ValueError("Postprocessing expression only enabled for SQL resolvers.")
            underscore_expr = Underscore._from_proto(r.underscore_expr)  # pyright: ignore[reportPrivateUsage]
            if not isinstance(underscore_expr, Underscore):
                raise ValueError(
                    f"Postprocessing expression in resolver '{r.fqn}' must be an Underscore, instead got {underscore_expr}"
                )
            postprocessing_expr = underscore_expr

        return resolver_cls(
            function_definition=r.function.function_definition,
            source_line=source_line,
            function_captured_globals=FromProtoConverter.convert_function_captured_globals(r.function.captured_globals),
            filename=r.function.file_name,
            fqn=r.fqn,
            module=r.function.module,
            is_generator=r.is_generator,
            underscore_definition=None,
            input_refs=parsed_inputs.inputs,
            synthetic_inputs=parsed_inputs.synthetic_inputs,
            default_args=parsed_inputs.default_args,
            graph=graph,
            output_refs=outputs,
            resource_hint=resource_hint,
            environment=tuple(r.environments) if r.environments else None,
            tags=tuple(r.tags),
            doc=r.doc if r.HasField("doc") else None,
            machine_type=r.machine_type if r.HasField("machine_type") else None,
            owner=r.owner if r.HasField("owner") else None,
            timeout=to_timedelta(r.timeout_duration) if r.HasField("timeout_duration") else timedelta(),
            data_sources=data_sources,
            cron=cron,
            when=(FromProtoConverter.convert_filter(r.when, graph) if r.HasField("when") else None),
            cron_filter=cron_filter_with_feature_args,
            accelerate_python=FromProtoConverter.convert_accelerate_python_enum(r.accelerate_python),
            is_total=r.is_total if len(parsed_inputs.inputs) == 0 else False,
            unique_on=FrozenOrderedSet(r.unique_on),
            partitioned_by=FrozenOrderedSet(r.partitioned_by),
            sql_settings=FromProtoConverter.convert_sql_settings(r.sql_settings)
            if r.HasField("sql_settings")
            else None,
            incremental_settings=FromProtoConverter.convert_incremental_settings(r.incremental_settings)
            if r.HasField("incremental_settings")
            else None,
            is_externally_defined=is_externally_defined,
            output_row_order=output_row_order,
            venv=r.venv if r.HasField("venv") else None,
            postprocessing=postprocessing_expr,
        )

    @classmethod
    def convert_function_captured_globals(
        cls,
        captured_globals: Iterable[pb.FunctionReferenceCapturedGlobal],
    ) -> Mapping[str, FunctionCapturedGlobal]:
        """
        Converts a list of protograph `FunctionReferenceCapturedGlobal` values into the equivalent Chalkpy type.
        Captured values of unrecognized or invalid type are silently skipped.
        """
        out: dict[str, FunctionCapturedGlobal] = {}
        for captured_global in captured_globals:
            if captured_global.HasField("builtin"):
                global_name = captured_global.global_name or captured_global.builtin.builtin_name
                if not global_name:
                    # If neither the global name nor the builtin name are recorded, then the captured
                    # global cannot be deserialized from proto.
                    continue
                out[global_name] = FunctionCapturedGlobalBuiltin(
                    builtin_name=captured_global.builtin.builtin_name,
                )
            elif captured_global.HasField("feature_class"):
                if not captured_global.global_name:
                    # If the global name is not recorded, then the captured
                    # global cannot be deserialized from proto.
                    continue
                out[captured_global.global_name] = FunctionCapturedGlobalFeatureClass(
                    feature_namespace=captured_global.feature_class.feature_class_name,
                )
            elif captured_global.HasField("module"):
                if not captured_global.global_name:
                    # If neither the global name is not recorded, then the captured
                    # global cannot be deserialized from proto.
                    continue
                out[captured_global.global_name] = FunctionCapturedGlobalModule(
                    name=captured_global.module.name,
                )
            elif captured_global.HasField("module_member"):
                if not captured_global.global_name:
                    continue
                out[captured_global.global_name] = FunctionCapturedGlobalModuleMember(
                    module_name=captured_global.module_member.module_name,
                    qualname=captured_global.module_member.qualname,
                )
            elif captured_global.HasField("enum"):
                if not captured_global.global_name:
                    # If neither the global name is not recorded, then the captured
                    # global cannot be deserialized from proto.
                    continue
                out[captured_global.global_name] = FunctionCapturedGlobalEnum(
                    module=captured_global.enum.module,
                    name=captured_global.enum.name,
                    member_map={k: proto_to_pa_scalar(v) for k, v in captured_global.enum.member_map.items()},
                    bases=tuple(
                        PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(x) for x in captured_global.enum.bases
                    ),
                )
            elif captured_global.HasField("struct"):
                if not captured_global.global_name:
                    continue
                out[captured_global.global_name] = FunctionCapturedGlobalStruct(
                    name=captured_global.struct.name,
                    module=captured_global.struct.module,
                    pa_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(captured_global.struct.pa_dtype),
                )
            elif captured_global.HasField("function"):
                if not captured_global.global_name:
                    continue
                inner_captured = cls.convert_function_captured_globals(captured_global.function.captured_globals)
                out[captured_global.global_name] = FunctionCapturedGlobalFunction(
                    source=captured_global.function.source,
                    captured_globals=inner_captured if inner_captured else None,
                    name=captured_global.function.name,
                    module=captured_global.function.module,
                )
            elif captured_global.HasField("variable"):
                out[captured_global.global_name] = FunctionCapturedGlobalVariable(
                    name=captured_global.variable.name,
                    module=captured_global.variable.module,
                )
            elif captured_global.HasField("proto"):
                out[captured_global.global_name] = FunctionCapturedGlobalProto(
                    name=captured_global.proto.name,
                    module=captured_global.proto.module,
                    serialized_fd=captured_global.proto.serialized_fd,
                    full_name=captured_global.proto.full_name,
                    pa_dtype=PrimitiveFeatureConverter.convert_proto_dtype_to_pa_dtype(captured_global.proto.pa_dtype),
                )
            else:
                # Skip over global value with unset or unrecognized captured variable type.
                continue
        return out

    @classmethod
    def convert_graph(
        cls, pb_graph: pb.Graph, source_secrets: sources_pb.SourceSecrets | None = None
    ) -> ResolvedGraphImpl:
        sql_sources: list[BaseSQLSource] = [
            cls.convert_data_source(x, source_secrets) for x in pb_graph.database_sources_v2
        ]
        sql_source_map: dict[tuple[str, str | None], BaseSQLSource] = {(s.kind.value, s.name): s for s in sql_sources}
        sql_source_groups = [cls.convert_data_source_group(x, sql_source_map) for x in pb_graph.database_source_groups]
        online_store_configs = [cls.convert_online_store_config(config) for config in pb_graph.online_store_configs]
        resolved_graph = ResolvedGraphImpl(
            sql_sources=sql_sources, sql_source_groups=sql_source_groups, online_store_configs=online_store_configs
        )

        stream_sources: List[StreamSource] = [cls.convert_stream_source(ss) for ss in pb_graph.stream_sources_v2]
        # (type x name) --> StreamSource
        stream_sources_dict: Dict[Tuple[str, str | None], StreamSource] = {}
        for ss in stream_sources:
            if (ss.streaming_type, ss.name) in stream_sources_dict:
                _logger.warning(f"Found duplicate StreamSource with type '{ss.streaming_type}' and name {ss.name=}.")
                # TODO actually error here once we've squashed these in CI
                # raise ValueError(f"Found duplicate StreamSource with type '{ss.streaming_type}' and name {ss.name=}.")
            stream_sources_dict[(ss.streaming_type, ss.name)] = ss

        with resolved_graph.ensure_transaction() as ctx:
            FromProtoConverter.convert_features(
                list(pb_graph.feature_sets), resolved_graph, ctx, is_externally_defined=False
            )
            converted_resolvers = [
                FromProtoConverter.convert_resolver(r, graph=resolved_graph, is_externally_defined=False)
                for r in pb_graph.resolvers
            ]

            ctx.upsert_resolvers(converted_resolvers, replace_on_conflict=False)

            converted_stream_resolvers = [
                cls.convert_stream_resolver(r, graph=resolved_graph, stream_sources=stream_sources_dict)
                for r in pb_graph.stream_resolvers
            ]
            ctx.upsert_resolvers(converted_stream_resolvers, replace_on_conflict=False)

            new_resolvers: list[ResolverParsed] = scalar_feature_types_to_resolvers(
                scalars=[f for f in resolved_graph.features if isinstance(f, ScalarFeatureType)],
                graph=resolved_graph,
            )
            ctx.upsert_resolvers(new_resolvers, replace_on_conflict=False)

        return resolved_graph

    @staticmethod
    def convert_named_query(source: pb.NamedQuery) -> NamedQueryParsed:
        # Ignoring source.errors when converting named queries because structured errors in named queries
        # prevent that specific query from being used at runtime.

        parsed_duration = {k: timedelta_to_duration(v.ToTimedelta()) for (k, v) in source.staleness.items()}

        try:
            return NamedQueryParsed(
                name=source.name,
                version=extract(source, "query_version"),
                input=tuple(source.input),
                output=tuple(source.output),
                additional_logged_features=tuple(source.additional_logged_features),
                valid_plan_not_required=source.valid_plan_not_required,
                tags=tuple(source.tags),
                owner=extract(source, "owner"),
                staleness=parsed_duration,
                planner_options={**source.planner_options},
            )
        except Exception as e:
            raise ValueError(f"Could not convert named query '{source.name}'") from e

    @staticmethod
    def convert_accelerate_python_enum(accelerate_python: pb.AcceleratePython) -> Literal["require", "auto", "never"]:
        if (
            accelerate_python == pb.AcceleratePython.ACCELERATE_PYTHON_UNSPECIFIED
            or accelerate_python == pb.AcceleratePython.ACCELERATE_PYTHON_AUTO
        ):
            return "auto"
        elif accelerate_python == pb.AcceleratePython.ACCELERATE_PYTHON_REQUIRE:
            return "require"
        elif accelerate_python == pb.AcceleratePython.ACCELERATE_PYTHON_NEVER:
            return "never"
        else:
            raise ValueError(f"unexpected value for accelerate_python: {accelerate_python}")

    @classmethod
    def convert_named_queries(cls, source: pb.Graph) -> NamedQueryRegistry:
        # Ignoring source.errors when converting named queries because structured errors in named queries
        # prevent that specific query from being used at runtime.
        return NamedQueryRegistry(cls.convert_named_query(x) for x in source.named_queries)

    @classmethod
    def convert_sql_settings(cls, source: pb.SQLResolverSettings) -> SQLResolverSettings:
        return SQLResolverSettings(
            finalizer=cls.convert_finalizer(source.finalizer),
            incremental_settings=cls.convert_incremental_settings(source.incremental_settings)
            if source.HasField("incremental_settings")
            else None,
            fields_root_fqn=source.fields_root_fqn,
            params_to_root_fqn=dict(source.escaped_param_name_to_fqn),
            field_types=dict(source.field_types),
        )

    @classmethod
    def convert_finalizer(cls, source: pb.Finalizer) -> Finalizer:
        if source == pb.Finalizer.FINALIZER_ONE_OR_NONE:
            return Finalizer.ONE_OR_NONE
        elif source == pb.Finalizer.FINALIZER_ONE:
            return Finalizer.ONE
        elif source == pb.Finalizer.FINALIZER_FIRST:
            return Finalizer.FIRST
        elif source == pb.Finalizer.FINALIZER_ALL:
            return Finalizer.ALL
        else:
            raise ValueError("Unsupported sql resolver finalizer")

    @classmethod
    def convert_incremental_settings(cls, source: pb.IncrementalSettings) -> IncrementalSettings:
        if source.mode == pb.IncrementalMode.INCREMENTAL_MODE_ROW:
            mode = "row"
        elif source.mode == pb.IncrementalMode.INCREMENTAL_MODE_GROUP:
            mode = "group"
        elif source.mode == pb.IncrementalMode.INCREMENTAL_MODE_PARAMETER:
            mode = "parameter"
        else:
            raise ValueError("Unsupported incremental mode")

        if source.timestamp_mode == pb.IncrementalTimestampMode.INCREMENTAL_TIMESTAMP_MODE_FEATURE_TIME:
            timestamp_mode = "feature_time"
        elif source.timestamp_mode == pb.IncrementalTimestampMode.INCREMENTAL_TIMESTAMP_MODE_RESOLVER_EXECUTION_TIME:
            timestamp_mode = "resolver_execution_time"
        else:
            raise ValueError("Unsupported incremental timestamp mode")

        return IncrementalSettings(
            mode=mode,
            lookback_period=source.lookback_period.ToTimedelta() if source.HasField("lookback_period") else None,
            incremental_column=source.incremental_column if source.HasField("incremental_column") else None,
            incremental_timestamp=timestamp_mode,
        )


def proto_export_has_errors(export: export_pb2.Export) -> bool:
    if len(export.failed) > 0:
        return True
    if len(export.logs) > 0:
        return True
    if len(export.lsp.diagnostics) > 0:
        return True
    if len(export.conversion_errors) > 0:
        return True
    return False


def log_proto_graph_export_errors(export: export_pb2.Export):
    for failed_import in export.failed:
        _logger.error("Failed import: %s", failed_import)
    for log in export.logs:
        _logger.error("Validation error: %s", log)
    for diagnostic in export.lsp.diagnostics:
        _logger.error("Diagnostic: %s", diagnostic)
    for conversion_error in export.conversion_errors:
        _logger.error("Conversion Error: %s", conversion_error)
