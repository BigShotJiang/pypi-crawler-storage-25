from chalkruntime.graph.graph import ResolvedGraph

_global_graph: ResolvedGraph | None = None


def set_global_graph(graph: ResolvedGraph):
    global _global_graph
    if _global_graph is not None:
        raise ValueError("The global graph has already been set; cannot set it again")
    _global_graph = graph


def get_global_graph():
    if _global_graph is None:
        raise ValueError("No global graph has been set")
    return _global_graph
