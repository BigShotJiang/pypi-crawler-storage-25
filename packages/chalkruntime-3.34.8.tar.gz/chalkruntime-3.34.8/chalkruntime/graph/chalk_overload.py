from __future__ import annotations

from typing import TypeVar

from chalkruntime.graph.maybe_named_collection import MaybeNamedCollection
from libchalk.chalkfunction import (
    ArgumentType,
    ChalkFunctionOverload,
    ChalkFunctionOverloadFailed,
    ChalkFunctionOverloadResolved,
    default_arrow_type_promoter,
)

TItem = TypeVar("TItem")
TOther = TypeVar("TOther")


def get_resolved_overload(
    overload: ChalkFunctionOverload,
    input_types: MaybeNamedCollection[ArgumentType],
) -> ChalkFunctionOverloadResolved | ChalkFunctionOverloadFailed:
    return overload.try_resolve(input_types, default_arrow_type_promoter)
