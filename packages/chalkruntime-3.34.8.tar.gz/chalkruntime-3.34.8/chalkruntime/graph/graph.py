from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from functools import cached_property
from typing import (
    TYPE_CHECKING,
    Callable,
    Collection,
    Iterable,
    Mapping,
    ParamSpec,
    Protocol,
    TypeVar,
)

from chalk.sql._internal.sql_source import BaseSQLSource, SQLSourceKind
from chalk.sql._internal.sql_source_group import SQLSourceGroup
from chalk.utils.collections import OrderedSet, get_unique_item
from pyarrow import Schema as PyArrowSchema

from chalkruntime.constants import SpecialResolverFQN
from chalkruntime.graph.singletons import CHALK_FK_SINGLETON_NAME
from chalkruntime.metadata import compute_resolver_id

if TYPE_CHECKING:
    from chalkruntime.graph.feature import (
        FeatureTimeFeatureType,
        FeatureType,
        GroupByFeatureType,
        HasManyFeatureType,
        HasOneFeatureType,
        InputFeatureType,
        ScalarFeatureType,
        WindowedFeatureType,
    )
    from chalkruntime.graph.graph_impl import GraphCached
    from chalkruntime.graph.protograph_deserializer import OnlineStoreConfigParsed
    from chalkruntime.graph.resolver import (
        ResolverParsed,
        SinkResolverParsed,
    )
    from chalkruntime.graph.stream_resolver import StreamResolverParsed

T = TypeVar("T")
TSelf = TypeVar("TSelf")
P = ParamSpec("P")


class ResolvedGraph(Protocol):
    @property
    def sql_sources(self) -> Iterable[BaseSQLSource]:
        """SQL sources that are referenced in the graph"""
        ...

    def get_sql_source_by_name(self, name: str) -> BaseSQLSource | None:
        """Get a SQL source or group if it exists by name, or return None."""
        ...

    def get_sql_source(self, kind: SQLSourceKind, name: str | None) -> BaseSQLSource | None:
        """Get a SQL source if it exists with the name and kind, or return None."""
        ...

    def get_sql_source_group(self, name: str) -> SQLSourceGroup | None:
        """Get a SQL source group if it exists by name, or return None."""
        ...

    @property
    def online_store_configs(self) -> Iterable["OnlineStoreConfigParsed"]:
        """Online store configs that are referenced in the graph"""
        ...

    @property
    def features(
        self,
    ) -> Iterable[
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | GroupByFeatureType
    ]: ...

    @property
    def fqn_to_feature(
        self,
    ) -> Mapping[
        str,
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | GroupByFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | GroupByFeatureType,
    ]: ...

    def feature_from_fqn(
        self, fqn: str
    ) -> (
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | GroupByFeatureType
        | InputFeatureType[
            ScalarFeatureType | HasOneFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType
        ]
        | None
    ): ...

    def fqns_to_schema(self, fqns: Iterable[str]) -> PyArrowSchema | None: ...

    def get_write_max_staleness(self, f: ScalarFeatureType) -> timedelta: ...

    def get_features_in_namespace(
        self, namespace: str
    ) -> Collection[
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | GroupByFeatureType
    ]: ...

    def primary_feature_for_namespace(self, namespace: str) -> ScalarFeatureType | None: ...

    def ts_feature_for_namespace(self, output_namespace: str) -> FeatureTimeFeatureType | None: ...

    @property
    def all_namespaces(self) -> Collection[str]: ...

    @property
    def resolvers(self) -> Collection[ResolverParsed]: ...

    @property
    def resolver_id_to_resolver(self) -> Mapping[int, ResolverParsed]: ...

    @property
    def stream_resolvers(self) -> Collection[StreamResolverParsed]: ...

    @property
    def sink_resolvers(self) -> Collection[SinkResolverParsed]: ...

    def resolver_by_name(self, short_name_or_fqn: str) -> ResolverParsed | None: ...

    def resolver_by_name_or_raise(self, short_name_or_fqn: str) -> ResolverParsed:
        ans = self.resolver_by_name(short_name_or_fqn)
        if ans is None:
            raise RuntimeError(f"Resolver '{short_name_or_fqn}' not found")
        return ans

    # FIXME: We should probably do something smart here to avoid dealing with loading the whole relationship tree
    # strictly. Need to think really hard about this.
    def features_for_feature_namespace(self, namespace: str) -> Collection[FeatureType]: ...

    @property
    def feature_to_joined_feature(
        self,
    ) -> Mapping[ScalarFeatureType, OrderedSet[tuple[ScalarFeatureType, HasOneFeatureType | HasManyFeatureType]]]: ...

    def graph_cached(self, fn: Callable[[], T]) -> GraphCached[T]: ...

    def graph_cached_with_graph(self, fn: Callable[[ResolvedGraph], T]) -> GraphCached[T]: ...

    def get_resolver_id_to_resolver_fqn(self) -> Mapping[int, str]:
        resolver_id_to_resolver_fqn = {k: v.fqn for (k, v) in self.resolver_id_to_resolver.items()}
        resolver_id_to_resolver_fqn |= {
            compute_resolver_id(SpecialResolverFQN.CHALK_QUERY_INPUT): SpecialResolverFQN.CHALK_QUERY_INPUT
        }
        return resolver_id_to_resolver_fqn

    def rooted_primary_feature_for_input_feature(
        self,
        feature: (
            InputFeatureType[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | HasOneFeatureType
                | HasManyFeatureType
                | WindowedFeatureType
            ]
            | ScalarFeatureType
            | FeatureTimeFeatureType
            | GroupByFeatureType
            | HasOneFeatureType
            | HasManyFeatureType
            | WindowedFeatureType
        ),
    ) -> InputFeatureType[ScalarFeatureType] | ScalarFeatureType:
        from chalkruntime.graph.feature import (
            is_underlying_scalar,
        )

        pkey_feature = self.primary_feature_for_namespace(feature.namespace)
        assert pkey_feature is not None
        pkey_root_fqn = f"{feature.root_prefix}.{pkey_feature.name}"
        ft = self.feature_from_fqn(pkey_root_fqn)
        assert is_underlying_scalar(ft)
        return ft

    def all_rooted_primary_features_for_input_feature(
        self,
        feature: (
            InputFeatureType[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | HasOneFeatureType
                | HasManyFeatureType
                | WindowedFeatureType
            ]
            | ScalarFeatureType
            | FeatureTimeFeatureType
            | GroupByFeatureType
            | HasOneFeatureType
            | HasManyFeatureType
            | WindowedFeatureType
        ),
    ) -> Iterable[InputFeatureType[ScalarFeatureType] | ScalarFeatureType]:
        """for a.b.c.d.name, returns a.b.id, a.b.c.id, a.b.c.d.id"""
        from chalkruntime.graph.feature import (
            InputFeatureType,
        )

        while isinstance(feature, InputFeatureType):
            yield self.rooted_primary_feature_for_input_feature(feature)
            feature = feature.pop_suffix()

    def get_stream_resolver(self, fqn: str) -> StreamResolverParsed | None:
        from chalkruntime.graph.stream_resolver import StreamResolverParsed

        resolver = self.resolver_by_name(fqn)
        if resolver is None or not isinstance(resolver, StreamResolverParsed):
            return
        return resolver

    def get_stream_resolver_or_raise(self, fqn: str) -> StreamResolverParsed:
        r = self.get_stream_resolver(fqn)
        if r is not None:
            return r
        raise ValueError(f"Resolver '{fqn}' not found")

    def singleton_fk_for_namespace(self, namespace: str) -> ScalarFeatureType | None:
        from chalkruntime.graph.feature import (
            ScalarFeatureType,
        )

        ans = self.feature_from_fqn(f"{namespace}.{CHALK_FK_SINGLETON_NAME}")
        if ans is None:
            return None
        assert isinstance(ans, ScalarFeatureType)
        return ans

    def resolver_by_id(self, resolver_id: int) -> ResolverParsed:
        return self.resolver_id_to_resolver[resolver_id]

    @cached_property
    def composite_pkey_resolvers(self) -> dict[ScalarFeatureType, list[ResolverParsed]]:
        from chalkruntime.graph.resolver import OfflineResolverParsed

        output = defaultdict(list)
        for resolver in self.resolvers:
            namespaces = resolver.input_root_namespaces
            if len(namespaces) != 1:
                continue
            if resolver.output_is_df or resolver.input_is_df:
                continue
            if isinstance(resolver, OfflineResolverParsed):
                # only online resolvers may compute pkeys
                continue
            pkey_feature = self.primary_feature_for_namespace(get_unique_item(namespaces))
            if pkey_feature is None:
                continue
            if (
                len(resolver.inputs) >= 1
                and pkey_feature in resolver.output_features
                and pkey_feature not in resolver.inputs
            ):
                if pkey_feature not in output:
                    output[pkey_feature] = []
                output[pkey_feature].append(resolver)
        return output
