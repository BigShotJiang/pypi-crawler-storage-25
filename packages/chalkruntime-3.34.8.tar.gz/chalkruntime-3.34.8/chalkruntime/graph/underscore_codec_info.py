import dataclasses

import pyarrow as pa
from frozendict import frozendict

from libchalk.chalkfunction import CallbackType, DataFrameParameterType


@dataclasses.dataclass(frozen=True)
class FrozenCallbackType:
    input_types: tuple[pa.DataType, ...]
    output_type: pa.DataType

    @staticmethod
    def from_unfrozen(cpp_callback: CallbackType) -> "FrozenCallbackType":
        return FrozenCallbackType(input_types=tuple(cpp_callback.input_types), output_type=cpp_callback.output_type)


@dataclasses.dataclass(frozen=True)
class FrozenDataFrameParameterType:
    columns: frozendict[str, pa.DataType]

    @staticmethod
    def from_unfrozen(cpp_df_parameter: DataFrameParameterType) -> "FrozenDataFrameParameterType":
        return FrozenDataFrameParameterType(columns=frozendict(cpp_df_parameter.columns))


@dataclasses.dataclass(frozen=True)
class UnderscoreOperationCodecInfo:
    function_name: str


@dataclasses.dataclass(frozen=True)
class FromCppRegCodecInfo(UnderscoreOperationCodecInfo):
    """
    Information stored in UnderscoreOperation such that calling
    UnderscoreOperation.from_overload_resolved(
        get_chalk_function_registry_overload(
            function_name=self.function_name,
            input_types=self.input_types,
        )
    )
    would yield an identical UnderscoreOperation.
    """


@dataclasses.dataclass(frozen=True)
class FromPythonRegCodecInfo(UnderscoreOperationCodecInfo):
    """
    Information stored in UnderscoreOperation such that calling
    UnderscoreOperationRegistry.resolve(
        function_name=self.function_name,
        params=self.params
    )
    would yield an identical UnderscoreOperation
    """

    # Everything in this dict should be immutable
    params: frozendict[str, object]
