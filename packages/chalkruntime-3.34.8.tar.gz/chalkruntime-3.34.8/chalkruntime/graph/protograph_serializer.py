import collections
import collections.abc
from datetime import timedelta
from typing import Any, Literal, cast

import pyarrow as pa
from chalk._gen.chalk.arrow.v1 import arrow_pb2 as arrow_pb
from chalk._gen.chalk.expression.v1 import expression_pb2 as expr_pb
from chalk._gen.chalk.graph.v1 import graph_pb2 as pb
from chalk.features._encoding.converter import PrimitiveFeatureConverter
from chalk.features.pseudofeatures import PSEUDONAMESPACE
from chalk.parsed.expressions import is_valid_operation
from chalk.utils.collections import get_unique_item

from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureTimeFeatureType,
    FeatureType,
    FilterParsed,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    WindowedFeatureType,
    is_underlying_has_many,
)


class ToProtoConverter:
    @staticmethod
    def convert_feature_to_filter_node(
        raw: ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType],
    ) -> expr_pb.LogicalExprNode:
        if isinstance(raw, InputFeatureType):
            path_converted: list[expr_pb.Column] = []
            for p in raw.path:
                path_converted.append(
                    expr_pb.Column(
                        name=p.parent.name,
                        relation=expr_pb.ColumnRelation(relation=p.parent.namespace),
                    )
                )
            path_converted.append(
                expr_pb.Column(
                    name=raw.name,
                    relation=expr_pb.ColumnRelation(relation=raw.namespace),
                )
            )

            return expr_pb.LogicalExprNode(
                binary_expr=expr_pb.BinaryExprNode(
                    operands=[expr_pb.LogicalExprNode(column=p) for p in path_converted],
                    op="foreign_feature_access",
                )
            )

        return expr_pb.LogicalExprNode(
            column=expr_pb.Column(name=raw.name, relation=expr_pb.ColumnRelation(relation=raw.namespace)),
        )

    @staticmethod
    def _collect_binop_operands(
        f: FilterParsed, parent_op: Literal["and", "or"], operands_list: list[expr_pb.LogicalExprNode]
    ):
        """Collects nested expressions with the same operation into a flat list to decrease the proto depth of the converted message.
        Only copllapses the lhs, ex. and(and(A,B),C) -> and(A,B,C), and(A,and(B,C)) -> and(A,and(B,C))
        This mirrors the behavior of FromProtoConverter
        """
        if f.operation == parent_op:
            if not isinstance(f.lhs, FilterParsed):
                raise ValueError(f"lhs '{f.lhs}' for and/or must be a Filter")
            if not isinstance(f.rhs, FilterParsed):
                raise ValueError(f"rhs '{f.rhs}' for and/or must be a Filter")
            ToProtoConverter._collect_binop_operands(f.lhs, parent_op, operands_list)
            operands_list.append(ToProtoConverter.convert_filter(f.rhs))
        else:
            operands_list.append(ToProtoConverter.convert_filter(f))

    @staticmethod
    def convert_filter(f: FilterParsed) -> expr_pb.LogicalExprNode:
        if not is_valid_operation(f.operation):
            raise ValueError(f"Unknown operation '{f.operation}'")

        if f.operation in ("and", "or"):
            operands: list[expr_pb.LogicalExprNode] = []
            ToProtoConverter._collect_binop_operands(f, f.operation, operands)
            binop = expr_pb.BinaryExprNode(
                operands=operands,
                op=f.operation,
            )
            return expr_pb.LogicalExprNode(
                binary_expr=binop,
            )
        if f.operation == "not":
            if not isinstance(f.lhs, FilterParsed):
                raise ValueError(f"lhs '{f.lhs}' for not must be a Filter")
            return expr_pb.LogicalExprNode(
                binary_expr=expr_pb.BinaryExprNode(
                    operands=[
                        ToProtoConverter.convert_filter(f.lhs),
                    ],
                    op=f.operation,
                ),
            )

        raw_lhs = f.lhs
        raw_rhs = f.rhs

        if isinstance(raw_lhs, FeatureType) and isinstance(raw_rhs, timedelta):
            # This means that the filter was a before() or after()
            converted_lhs = ToProtoConverter.convert_feature_to_filter_node(raw_lhs)
            converted_rhs = expr_pb.LogicalExprNode(
                literal=arrow_pb.ScalarValue(duration_microsecond_value=raw_rhs // timedelta(microseconds=1))
            )
            return expr_pb.LogicalExprNode(
                binary_expr=expr_pb.BinaryExprNode(
                    operands=[converted_lhs, converted_rhs],
                    op=f.operation,
                ),
            )
        if isinstance(raw_rhs, FeatureType) and isinstance(raw_lhs, timedelta):
            # This means that the filter was a before() or after()
            converted_rhs = ToProtoConverter.convert_feature_to_filter_node(raw_rhs)
            converted_lhs = expr_pb.LogicalExprNode(
                literal=arrow_pb.ScalarValue(duration_microsecond_value=raw_lhs // timedelta(microseconds=1))
            )
            return expr_pb.LogicalExprNode(
                binary_expr=expr_pb.BinaryExprNode(
                    operands=[converted_lhs, converted_rhs],
                    op=f.operation,
                ),
            )

        if isinstance(raw_lhs, FeatureType):
            converted_lhs = ToProtoConverter.convert_feature_to_filter_node(raw_lhs)
        else:
            if not isinstance(raw_rhs, FeatureType):
                raise ValueError("One side must be a feature")
            converted_lhs = expr_pb.LogicalExprNode(
                literal=raw_rhs.underlying.primitive_converter.from_primitive_to_protobuf(cast(Any, raw_lhs)),
            )

        if isinstance(raw_rhs, FeatureType):
            converted_rhs = ToProtoConverter.convert_feature_to_filter_node(raw_rhs)
        else:
            if not isinstance(raw_lhs, FeatureType):
                raise ValueError("One side must be a feature")
            if f.operation in ("in", "not in"):
                if not isinstance(raw_rhs, collections.abc.Iterable):
                    raise ValueError("rhs must be an iterable when operation is 'in'/'not in'")
                list_dtype = pa.large_list(raw_lhs.underlying.primitive_converter.pyarrow_dtype)
                list_converter = PrimitiveFeatureConverter(name="helper", is_nullable=False, pyarrow_dtype=list_dtype)
                converted_rhs = expr_pb.LogicalExprNode(
                    literal=list_converter.from_primitive_to_protobuf(raw_rhs),
                )
            else:
                converted_rhs = expr_pb.LogicalExprNode(
                    literal=raw_lhs.underlying.primitive_converter.from_primitive_to_protobuf(cast(Any, raw_rhs))
                )

        return expr_pb.LogicalExprNode(
            binary_expr=expr_pb.BinaryExprNode(
                operands=[converted_lhs, converted_rhs],
                op=f.operation,
            )
        )

    @staticmethod
    def create_feature_reference(
        feature: ScalarFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | InputFeatureType[
            ScalarFeatureType | WindowedFeatureType | FeatureTimeFeatureType | HasOneFeatureType | HasManyFeatureType
        ],
    ) -> pb.FeatureReference:
        df = feature.underlying.df if is_underlying_has_many(feature) else None
        return pb.FeatureReference(
            name=feature.name,
            namespace=feature.namespace,
            path=[]
            if not isinstance(feature, InputFeatureType)
            else [ToProtoConverter.create_feature_reference(path_elem.parent) for path_elem in feature.path],
            df=ToProtoConverter.convert_dataframe(df) if df else None,
        )

    @staticmethod
    def convert_dataframe(df: DataFrameType) -> pb.DataFrameType:
        return pb.DataFrameType(
            root_namespace=get_unique_item(x.root_namespace for x in df.columns if x.root_namespace != PSEUDONAMESPACE),
            optional_columns=[ToProtoConverter.create_feature_reference(c) for c in df.optional_columns],
            # CHA-3177 -- switch to using this syntax
            # optional_columns=() if df.__references_feature_set__ is not None else [ToProtoConverter.create_feature_reference(ensure_feature(c)) for c in df.columns],
            required_columns=[ToProtoConverter.create_feature_reference(c) for c in df.required_columns],
            filter=None if df.filter is None else ToProtoConverter.convert_filter(df.filter),
            limit=df.limit if df.limit is not None else None,
        )
