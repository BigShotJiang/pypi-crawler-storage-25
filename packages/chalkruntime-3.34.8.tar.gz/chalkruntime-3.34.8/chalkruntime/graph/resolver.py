from __future__ import annotations

import dataclasses
import enum
import os
from datetime import timedelta
from typing import (
    Any,
    Callable,
    Collection,
    Literal,
    Mapping,
    Optional,
    Sequence,
    Union,
)

from chalk.df.LazyFramePlaceholder import LazyFramePlaceholder
from chalk.features import Underscore
from chalk.features.pseudofeatures import PSEUDONAMESPACE, Now
from chalk.features.resolver import RESOLVER_REGISTRY, Cron, FunctionCapturedGlobal, MachineType
from chalk.operators import StaticOperator
from chalk.sink import SinkIntegrationProtocol
from chalk.sql import BaseSQLSourceProtocol
from chalk.sql._internal.incremental import IncrementalSettings
from chalk.sql._internal.sql_settings import SQLResolverSettings
from chalk.sql._internal.sql_source import BaseSQLSource
from chalk.sql._internal.sql_source_group import SQLSourceGroup
from chalk.utils.collections import FrozenOrderedSet, OrderedSet, unwrap_optional
from chalk.utils.duration import CronTab, Duration
from chalk.utils.log_with_context import get_logger
from chalkdf.dataframe import DataFrame as ChalkDataFrame

from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureTimeFeatureType,
    FeatureValidationsParsed,
    FilterParsed,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    UnderlyingScalarFeatureType,
    WindowedFeatureType,
    associated_ts_feature,
    is_general_has_many,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    is_underlying_scalar,
    is_underlying_windowed,
    required_features_to_sample,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.graph_impl import graph_cached_property
from chalkruntime.graph.underscore import UnderscoreValue

_logger = get_logger(__name__)


@dataclasses.dataclass
class CronFilterWithFeatureArgs:
    filter: Callable[..., bool]
    feature_args: Sequence[
        ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ]


@dataclasses.dataclass(frozen=True, slots=True)
class ResolverArgErrorHandlerParsed:
    default_value: object


TResolverFeatureType = (
    ScalarFeatureType
    | HasManyFeatureType
    | HasOneFeatureType
    | WindowedFeatureType
    | DataFrameType
    | FeatureTimeFeatureType
    | InputFeatureType[
        ScalarFeatureType | HasManyFeatureType | HasOneFeatureType | WindowedFeatureType | FeatureTimeFeatureType
    ]
)

ResourceHintType = Literal["cpu", "io", "gpu"]


def feature_to_reference(
    f: TResolverFeatureType,
) -> (
    str
    | DataFrameType
    | HasManyFeatureType
    | InputFeatureType[
        HasOneFeatureType | HasManyFeatureType | ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType
    ]
):
    """Converts a parsed feature to a feature reference. Used for building ResolverParsed objects whose input/ouput features can be references to features in a graph
    isntead of a full FeatureType object."""
    if isinstance(f, (InputFeatureType, HasManyFeatureType, DataFrameType)):
        return f
    # Refer to scalar resolvers by their fqn
    return f.root_fqn


class DataFrameResolverType(enum.Enum):
    NO_ARG_DF_RESOLVER = "NO_ARG_DF_RESOLVER"
    """
    This type of DF resolver takes no inputs.
    Primarily used as the 'root node' of a query, e.g. to load input data from a database.
    """

    SAME_NAMESPACE_DF_RESOLVER = "SAME_NAMESPACE_DF_RESOLVER"
    """
    This type of DF resolver maps inputs to outputs that belong to the same root namespace.
    The outputs of this resolver can be joined against the inputs based on a spine of (pkey, __ts__).

    NOTE: These resolvers don't necessarily map input/output rows 1-1:
    e.g.:
    ```
    # (row-by-row, computes a derived feature)
    def get_user_last_name: DF[X.id, X.full_name] -> DF[X.id, X.last_name]

    # (might return 0, 1, or multiple rows per each given ID depending on what's in the DB)
    def get_users_from_db: DF[X.id] -> DF[X.id, X.full_name, X.age, ...]
    ```
    """

    AGGREGATION_RESOLVER = "AGGREGATION_DF_RESOLVER"
    """
    An aggregation resolver is one whose outputs are in a different root namespace than the inputs.
    There is no pkey or join relationship between the outputs & inputs.
    The number of output rows may be different then the number of input rows.
    """

    FLATTENED_HAS_MANY_RETURNING_RESOLVER = "FLATTENED_HAS_MANY_RETURNING_RESOLVER"
    """
    This type of DF resolver takes dataframe inputs and produces outputs in a has-many without struct-packing.
    """


@dataclasses.dataclass(frozen=True, kw_only=True)
class ResolverParsed:
    """
    Args:
        root_ns: The namespace that the resolver is rooted in.
                 Usually, this would be the namespace of the resolver inputs,
                 unless if the resolver takes no inputs and outputs a dataframe,
                 in which case this would be the output namespace.
    """

    function_definition: str = dataclasses.field(compare=False, repr=False)

    module: str | None = dataclasses.field(compare=False, repr=False)
    """
    The module in which the resolver is defined. Only defined for Python resolvers.
    """

    source_line: int | None = dataclasses.field(compare=False, repr=False)
    """
    Line number on which the resolver is defined in the customer source code.
    None if source parsing failed or if the resolver doesn't have a well-defined source location
    """

    function_captured_globals: Mapping[str, FunctionCapturedGlobal] = dataclasses.field(compare=False, repr=False)
    """
    A mapping from the name of a global variable to a description of its value.
    If a global variable is not present in this mapping, then it is unbound, bound to a dynamic value which
    cannot be determined, or is unrecognized.
    """

    underscore_definition: UnderscoreValue | None = dataclasses.field(compare=False, repr=False)
    """
    If the resolver is defined by an underscore feature, then it is made available here to enable
    analysis and optimization in the plan.
    """
    filename: str = dataclasses.field(compare=False, repr=False)
    fqn: str
    doc: str | None = dataclasses.field(compare=False, repr=False)
    graph: ResolvedGraph = dataclasses.field(compare=False, repr=False)
    resource_hint: ResourceHintType | None = dataclasses.field(compare=False, repr=False)
    resource_group: str | None = dataclasses.field(default=None, compare=False, repr=False)

    input_refs: dataclasses.InitVar[Collection[TResolverFeatureType]]
    _input_refs: tuple[
        str
        | DataFrameType
        | HasManyFeatureType
        | InputFeatureType[
            HasOneFeatureType | HasManyFeatureType | ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType
        ],
        ...,
    ] = dataclasses.field(
        init=False,
        repr=False,
        compare=False,
    )
    """Inside the resolver, we do NOT want to store non-nested scalar, feature time, or windowed features, so we represent those as strings. That way,
    if the graph is updated, the Resolver will always reflect the up-to-date features. Input feature types and has-many features already reference the
    underlying features by string, so we can safely store those types directly as part of the resolver."""

    output_refs: dataclasses.InitVar[Collection[TResolverFeatureType]]
    _output_refs: tuple[
        str
        | DataFrameType
        | HasManyFeatureType
        | InputFeatureType[
            HasOneFeatureType | HasManyFeatureType | ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType
        ],
        ...,
    ] = dataclasses.field(
        init=False,
        repr=False,
        compare=False,
    )
    """Same idea as the _input_refs, see comment above"""
    environment: tuple[str, ...] | None = dataclasses.field(compare=False, repr=False)
    tags: tuple[str, ...] = dataclasses.field(compare=False, repr=False)
    machine_type: MachineType | None = dataclasses.field(compare=False, repr=False)
    synthetic_inputs: FrozenOrderedSet[int] = dataclasses.field(compare=False, repr=False)
    default_args: list[ResolverArgErrorHandlerParsed | None] = dataclasses.field(compare=False, repr=False)
    owner: str | None = dataclasses.field(compare=False, repr=False)
    timeout: timedelta | None = dataclasses.field(compare=False, repr=False)
    data_sources: Sequence[BaseSQLSource | SQLSourceGroup] = dataclasses.field(compare=False, repr=False)
    is_total: bool | None = dataclasses.field(compare=False, repr=False)
    """Whether the resolver returns all ids for a given namespace, as per a user's annotation.
    If None, we may assume that the resolver is total in any case."""

    unique_on: FrozenOrderedSet[str] = dataclasses.field(compare=False, repr=False)
    partitioned_by: FrozenOrderedSet[str] = dataclasses.field(compare=False, repr=False)

    # Fields set in post_init
    input_is_df: bool = dataclasses.field(init=False, compare=False, repr=False)
    """Whether are input features are DataFrames. If the resolver takes no inputs, this is set to whether or not
    the output feature(s) are DataFrames."""

    is_now_to_df_resolver: bool = dataclasses.field(init=False, compare=False, repr=False)
    """
    Whether this resolver if of the form (Now) --> DF. i.e. the only input is chalk.Now and the output is a dataframe.
    TODO (CHA-7075) -- in some parts of the planner these are treated similar to 0-arg-taking resolvers (e.g. root resolvers for agg backills) but sometimes
    they're treated more like scalar resolvers (specifically, input_is_df is False in this case). Need to clean this up.
    """

    input_root_namespaces: Collection[str] = dataclasses.field(init=False, compare=False, repr=False)
    """The root namespaces for all input features"""

    unique_input_root_ns: str = dataclasses.field(init=False, compare=False, repr=False)
    """The unique element from ``input_root_namespaces``. Not defined if there are multiple input root namespaces."""

    output_root_ns: str = dataclasses.field(init=False, compare=False, repr=False)
    """The root namespace of the output. Defined if and only if there is an output;
    otherwise (i.e. for sinks), raises an AttributeError."""

    output_is_df: bool = dataclasses.field(init=False, compare=False, repr=False)
    """Whether the output feature is a (naked) DataFrame"""

    unique_df_output: DataFrameType = dataclasses.field(init=False, compare=False, repr=False)
    """If ``output_is_df``, the unique output DataFrame feature. Otherwise, raises an AttributeError."""

    short_name: str = dataclasses.field(init=False, compare=False, repr=False)
    """The resolver name, with the root namespace stripped off"""

    is_generator: bool = dataclasses.field(compare=False, repr=False)
    sql_settings: SQLResolverSettings | None = dataclasses.field(compare=False, repr=False)
    incremental_settings: IncrementalSettings | None = dataclasses.field(compare=False, repr=False)

    is_externally_defined: bool
    """
    Whether this resolver is defined externally (e.g. in a notebook), and thus we don't have access to the underlying python function.
    In this case we want to use the resolver's source code and captured globals to re-create it.
    """

    output_row_order: Literal["one-to-one"] | None = dataclasses.field(compare=False, repr=False)
    """
    If "one-to-one", verify that this is a DF -> DF resolver, and treat it as a bulk scalar operation.
    """

    venv: str | None = dataclasses.field(compare=False, repr=False)
    """
    The venv that the resolver should be run in.
    """

    postprocessing: LazyFramePlaceholder | Underscore | None

    accelerate_python: Literal["require", "auto", "never"] = dataclasses.field(compare=False, repr=False)

    def __post_init__(
        self, input_refs: Collection[TResolverFeatureType], output_refs: Collection[TResolverFeatureType]
    ):
        object.__setattr__(
            self,
            "_input_refs",
            tuple(feature_to_reference(x) for x in input_refs),
        )
        name = self.fqn.split(".")[-1]
        object.__setattr__(self, "short_name", name)
        # Perform some basic validation
        # 1. If given scalars in the inputs, validate that all inputs are in the same root namespace
        # 2. If given scalars in the outputs, validate that all outputs are in the same root namespace
        # 3. No mixing naked dataframes and scalars in the inputs
        # 4. No mixing naked dataframes and scalars in the outputs
        # Set all of the post-init variables defined above

        dataframe_input_features: list[DataFrameType] = []
        scalar_input_features: list[
            ScalarFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | HasManyFeatureType
            | InputFeatureType[HasManyFeatureType | ScalarFeatureType | FeatureTimeFeatureType | HasOneFeatureType]
        ] = []
        for f in self.inputs:
            if isinstance(f, DataFrameType):
                dataframe_input_features.append(f)
            if (
                is_underlying_scalar(f)
                or is_underlying_feature_time(f)
                or is_underlying_has_one(f)
                or is_underlying_has_many(f)
            ):
                scalar_input_features.append(f)

        # we exclude psuedofeatures from consideration, since they're metadata.
        scalar_input_namespaces = FrozenOrderedSet(
            f.root_namespace for f in scalar_input_features if f.root_namespace != PSEUDONAMESPACE
        )

        if len(dataframe_input_features) > 0 and len(scalar_input_namespaces) > 0:
            raise ValueError(
                (
                    f"Resolver '{self.fqn}', which takes both DataFrame and non-DataFrame feature arguments, is not allowed. "
                    "All feature arguments must be either DataFrames or features rooted in a single input namespace"
                    f"For example, the following would be permitted: "
                    f"`def {name}(id: User.id, transactions: User.transactions) -> ...: ...`"
                )
            )

        scalar_input_root_namespaces = FrozenOrderedSet(
            x.root_namespace for x in scalar_input_features if x.root_namespace != PSEUDONAMESPACE
        )
        if len(scalar_input_root_namespaces) > 1:
            namespaces_formatted = ", ".join(f"'{x}'" for x in scalar_input_root_namespaces)
            raise ValueError(
                (
                    f"Resolver '{self.fqn}', which requests features from multiple namespaces "
                    f"({namespaces_formatted}), is not allowed. "
                    "All feature arguments must be rooted in the same input namespace. To fix, reference the feature "
                    "in the foreign namespace using a relationship. For example, the following would be permitted: "
                    f"`def {name}(id: User.id, account_number: User.account.account_number) -> ...: ...`"
                )
            )
        input_root_namespaces = FrozenOrderedSet(
            x.root_namespace for x in self.inputs if x.root_namespace != PSEUDONAMESPACE
        )

        output_dfs = tuple(x for x in output_refs if isinstance(x, DataFrameType))

        if os.getenv("CHALK_LEGACY_TREAT_RESOLVER_DF_OUTPUT_AS_SCALAR") == "1":
            """
            Some of the older customer codebases have resolvers with an invalid signature:

            ```
            @online
            def my_thing(id: MyThing.id) -> DataFrame[MyThing.category, MyThing.is_active]:
                # Always returns one row of data
                return DataFrame([MyThing(category="abc", is_active = id % 2 == 0)])
            ```

            The correct signature for this resolver is:
            ```
            @online
            def my_thing(id: MyThing.id) -> Features[MyThing.category, MyThing.is_active]:
                # Always returns one row of data
                return DataFrame([MyThing(category="abc", is_active = id % 2 == 0)])
            ```

            We now validate this more seriously. Since not all customers have fixed their code,
            we have a legacy environment variable to automatically (heuristically) convert the
            resolver signature to a scalar one.
            """
            if (
                len(output_dfs) == 1
                and len(scalar_input_root_namespaces) == 1
                and (output_df := output_dfs[0]).root_namespace == next(iter(input_root_namespaces))
                and output_df.limit is None
                and output_df.filter is None
            ):
                _logger.warning(
                    f"The resolver '{self.fqn}' declares its output as `DataFrame[...]` but is being interpreted as instead returning a single-row of scalar outputs. If you intend this resolver to always return one row of data, replace the return annotation with `-> Features[...]`. If you intend this resolver to return multiple rows of data, contact Chalk support to reconfigure your environment."
                )
                # We need to do a bit of preprocessing before setting the outputs
                # Some customers have historically done resolvers like `def foo(name: User.name) -> DataFrame[User.address]`
                # This _really_ is a scalar resolver that happens to return a one-row dataframe. We need to modify the resolver definition to "unpack" all of the DF columns
                # so the planner plans it as a scalar resolver. The invoker can handle one-row dataframes as scalars
                output_refs = output_df.columns

        object.__setattr__(
            self,
            "_output_refs",
            tuple(
                (x if isinstance(x, (InputFeatureType, HasManyFeatureType, DataFrameType)) else x.root_fqn)
                for x in output_refs
            ),
        )

        dataframe_output_features: list[DataFrameType] = []
        scalar_output_features: list[
            ScalarFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | HasManyFeatureType
            | InputFeatureType[HasManyFeatureType | ScalarFeatureType | FeatureTimeFeatureType | HasOneFeatureType]
        ] = []

        output_root_ns = None

        for f in self.output:
            if output_root_ns is None:
                output_root_ns = f.root_namespace
            assert output_root_ns is not None
            if output_root_ns != f.root_namespace:
                assert f.root_namespace is not None
                raise ResolverMultipleOutputNamespaceError(
                    resolver=self, previous_output_root_ns=output_root_ns, feature_root_ns=f.root_namespace
                )
            if isinstance(f, DataFrameType):
                dataframe_output_features.append(f)
            if (
                is_underlying_scalar(f)
                or is_underlying_feature_time(f)
                or is_underlying_has_one(f)
                or is_underlying_has_many(f)
            ):
                scalar_output_features.append(f)

        output_is_df = False
        if len(dataframe_output_features) > 1:
            raise ValueError(
                (
                    f"Resolver '{self.fqn}', which returns multiple DataFrames, is not allowed. "
                    "Instead, return multiple relational DataFrames that are rooted in the same features class."
                    f"For example, the following would be permitted: "
                    f"`def {name}(...) -> Features[User.checking_transactions, User.saving_transactions]: ...`"
                )
            )

        unique_df_output = None

        if len(dataframe_output_features) == 1:
            output_is_df = True
            unique_df_output = dataframe_output_features[0]
            if len(scalar_output_features) != 0:
                raise ValueError(
                    (
                        f"Resolver '{self.fqn}', which returns both DataFrame and scalar features, is not allowed. "
                        "Instead, you may return at are rooted in the same features class. "
                        "For example, the following would be permitted: "
                        f"`def {name}(...) -> Features[User.name, User.transactions]: ...`"
                    )
                )

        # In the case of an empty input, we mark whether or not that is a dataframe based on the dataframe-ness of the
        # output.
        # FIXME: use the following instead of checking len(resolver.inputs) == 0 (also need to do this for other parts of the code)
        pseudofeature_input_only = (
            len(scalar_input_namespaces) == 0 and len(dataframe_input_features) == 0 and len(self.inputs) > 0
        )
        now_input_only = (
            pseudofeature_input_only
            and len(self.inputs) == 1
            and isinstance(self.inputs[0], ScalarFeatureType)
            and self.inputs[0].fqn == Now.fqn
        )
        input_is_df = (
            len(scalar_input_namespaces) == 0 and (len(self.inputs) > 0 or output_is_df) and not now_input_only
        )

        # TODO CHA-7075 -- refactor batch_planner so Now --> DF resolvers are considered "input is DF"
        # Or refactor taht flag completely so it's less confusing
        is_now_to_df_resolver = output_is_df and now_input_only

        object.__setattr__(self, "input_is_df", input_is_df)
        object.__setattr__(self, "is_now_to_df_resolver", is_now_to_df_resolver)
        object.__setattr__(self, "input_root_namespaces", input_root_namespaces)
        if len(input_root_namespaces) == 1:
            object.__setattr__(self, "unique_input_root_ns", next(iter(input_root_namespaces)))
        elif len(input_root_namespaces) == 0 and output_root_ns is not None:
            object.__setattr__(self, "unique_input_root_ns", output_root_ns)
        if output_root_ns is not None:
            object.__setattr__(
                self,
                "output_root_ns",
                output_root_ns,
            )
        object.__setattr__(self, "output_is_df", output_is_df)
        if unique_df_output is not None:
            object.__setattr__(self, "unique_df_output", unique_df_output)

        if self.input_is_df:
            input_feats = self.df_inputs()
        else:
            input_feats = self.inputs
        object.__setattr__(
            self,
            "inputs_include_now_pseudofeature",
            any(x.root_fqn == Now.root_fqn for x in input_feats if not isinstance(x, DataFrameType)),
        )

        # Ensure a resolver marked one-to-one is actually one-to-one
        if self.output_row_order == "one-to-one":
            if not self.input_is_df or not self.output_is_df:
                raise ValueError(
                    f"Resolver '{self.fqn}' has output_row_order='one-to-one', but it does not have dataframe inputs and outputs."
                )
            if len(self.inputs) != 1:
                raise ValueError(
                    f"Resolver '{self.fqn}' has output_row_order='one-to-one', but it takes in multiple dataframe inputs."
                )
            assert isinstance(self.inputs[0], DataFrameType), "input must be a dataframe if input_is_df is True"
            df_input: DataFrameType = self.inputs[0]
            id_in_input = self.graph.primary_feature_for_namespace(self.output_root_ns) in df_input.columns
            id_in_output = self.graph.primary_feature_for_namespace(self.output_root_ns) in self.output_features
            if not id_in_input or not id_in_output:
                raise ValueError(
                    f"Resolver '{self.fqn}' has output_row_order='one-to-one', but it does not take in and return the pkey column."
                )

    inputs_include_now_pseudofeature: bool = dataclasses.field(init=False, compare=False, repr=False)

    def get_fn(self):
        chalkpy_resolver = RESOLVER_REGISTRY.get_resolver(self.short_name)
        if chalkpy_resolver is None:
            raise ValueError(f"Resolver '{self.fqn}' not found")
        return chalkpy_resolver.fn

    def _load_features(
        self,
        refs: tuple[
            str
            | HasManyFeatureType
            | DataFrameType
            | InputFeatureType[
                HasManyFeatureType
                | WindowedFeatureType
                | ScalarFeatureType
                | HasOneFeatureType
                | FeatureTimeFeatureType
            ],
            ...,
        ],
    ):
        ans: list[TResolverFeatureType] = []
        for x in refs:
            if isinstance(x, str):
                ft = unwrap_optional(self.graph.feature_from_fqn(x))
                assert isinstance(
                    ft, (ScalarFeatureType, FeatureTimeFeatureType, WindowedFeatureType, HasOneFeatureType)
                )
            else:
                ft = x
                assert isinstance(x, (DataFrameType, HasManyFeatureType, InputFeatureType))
            ans.append(ft)
        return tuple(ans)

    @graph_cached_property
    def strict_validations(self) -> Mapping[UnderlyingScalarFeatureType, list[FeatureValidationsParsed]]:
        validations: dict[InputFeatureType[ScalarFeatureType] | ScalarFeatureType, list[FeatureValidationsParsed]] = {}
        for output in self.output_features:
            if is_underlying_scalar(output):
                feature_validations = output.underlying.validations
                if (
                    feature_validations is not None
                    and len(strict_vds := [validation for validation in feature_validations if validation.strict]) > 0
                ):
                    validations[output] = strict_vds
        return validations

    @graph_cached_property
    def inputs(self) -> tuple[TResolverFeatureType, ...]:
        return self._load_features(self._input_refs)

    @graph_cached_property
    def output(self) -> tuple[TResolverFeatureType, ...]:
        return self._load_features(self._output_refs)

    @graph_cached_property
    def all_scalar_outputs(self) -> FrozenOrderedSet[ScalarFeatureType]:
        scalar_outputs: OrderedSet[ScalarFeatureType] = OrderedSet()

        def _get_features(
            features: FrozenOrderedSet[
                ScalarFeatureType
                | HasOneFeatureType
                | HasManyFeatureType
                | WindowedFeatureType
                | FeatureTimeFeatureType
                | InputFeatureType[
                    ScalarFeatureType
                    | HasManyFeatureType
                    | FeatureTimeFeatureType
                    | HasOneFeatureType
                    | WindowedFeatureType
                ]
            ],
        ):
            for f in features:
                if is_underlying_scalar(f):
                    scalar_outputs.add(f.underlying)
                elif is_underlying_has_many(f):
                    _get_features(f.underlying.all_referenced_features)

        _get_features(self.output_features)
        return FrozenOrderedSet(scalar_outputs)

    @graph_cached_property
    def output_features(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | HasManyFeatureType | FeatureTimeFeatureType | WindowedFeatureType]
    ]:
        output_features: OrderedSet[
            ScalarFeatureType
            | HasManyFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | InputFeatureType[ScalarFeatureType | HasManyFeatureType | FeatureTimeFeatureType | WindowedFeatureType]
        ] = OrderedSet()
        if self.output_is_df:
            features = self.unique_df_output.columns
        else:
            features = self.output
        for x in features:
            if (
                is_underlying_scalar(x)
                or is_underlying_feature_time(x)
                or is_underlying_has_many(x)
                or is_underlying_windowed(x)
            ):
                output_features.add(x)
                # FIXME: Why are dataframe outputs treated differently here?
                if not self.output_is_df and isinstance(x, InputFeatureType) and x.underlying in x.join_path_keys:
                    # CHA-4857
                    output_features.update(x.path[-1].parent.get_local_join_features())
                continue
            if is_underlying_has_one(x):
                output_features.update(x.flatten())
                if not self.output_is_df:
                    # FIXME: Why are dataframe outputs treated differently here?
                    for f in x.flatten():
                        if f.underlying in f.join_path_keys:
                            # CHA-4857
                            output_features.update(f.path[-1].parent.get_local_join_features())
                continue
            raise ValueError(f"Unsupported output feature: {x}")
        return FrozenOrderedSet(output_features)

    @graph_cached_property
    def expected_output_columns(
        self,
    ) -> Mapping[
        str,
        ScalarFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType]
        | WindowedFeatureType,
    ]:
        cols = self.output_features
        ans: dict[
            str,
            ScalarFeatureType
            | FeatureTimeFeatureType
            | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType]
            | WindowedFeatureType,
        ] = {}
        for col in cols:
            assert is_underlying_scalar(col) or is_underlying_feature_time(col) or is_underlying_windowed(col), (
                "Outputs must be scalarish if not a dataframe"
            )
            if col.underlying.autogenerated:
                continue
            ans[col.root_fqn] = col
        return ans

    @graph_cached_property
    def flattened_inputs(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | HasManyFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
    ]:
        """
        Post-explosion input features, including join keys in has-many relationships, features in filters, etc.
        It's probably what you want unless you're writing code to collect results from the resolver.
        """
        if self.input_is_df:
            raise RuntimeError("Resolver.flattened_scalar_features is not applicable for dataframe-taking resolvers")
        flattened_inputs: OrderedSet[
            ScalarFeatureType | HasManyFeatureType | InputFeatureType[ScalarFeatureType | HasManyFeatureType]
        ] = OrderedSet()
        for x in self.inputs:
            if is_underlying_feature_time(x):
                continue
            elif is_underlying_scalar(x):
                flattened_inputs.add(x)
            elif is_general_has_many(x):
                # For a has-many feature like X.y.z, where Y.z is a has-one, we wouldn't want to explode into
                # {X.y.z.cols} since it creates overhead. Instead, the has-many sampling code will flatten it to
                # X.y[{Y.z.cols}], so that only one has-many table needs to be passed around in the PlanBatch.
                flattened_inputs.add(x)
            elif is_underlying_has_one(x):
                for y in x.flatten():
                    if is_underlying_scalar(y):
                        flattened_inputs.add(y)
            else:
                # TODO -- how should windowed features be handled?
                raise TypeError(f"Unsupported input type: {x}")

        # If we ask for an input feature like `User.account.txs` then in order to perform batch partitioning
        # on the `txs` has-many group, we must have `User.account.id` available. Therefore, if we explicitly
        # ask for `User.account.txs` we automatically get `User.account.id` as an additional input here.
        ans = FrozenOrderedSet(s for x in flattened_inputs for s in required_features_to_sample(x))
        return ans

    def input_feature_times(
        self,
        scope_feature_time_to_namespace: bool,
    ) -> FrozenOrderedSet[FeatureTimeFeatureType | InputFeatureType[FeatureTimeFeatureType]]:
        """
        The max value of these feature times (which I'll call "resolver time") will be used as output feature time if not returned.
        This only makes sense for resolvers that take scalar inputs, since we cannot propagate feature time for dataframe resolvers which rearranges the data.
        """
        ans = OrderedSet[FeatureTimeFeatureType | InputFeatureType[FeatureTimeFeatureType]]()
        for input_feature in self.flattened_inputs:
            if is_underlying_scalar(input_feature):
                ft_feature = associated_ts_feature(
                    input_feature, scope_feature_time_to_namespace=scope_feature_time_to_namespace
                )
                if ft_feature is not None:
                    ans.add(ft_feature)
        return ans.freeze()

    @graph_cached_property
    def is_one_to_one_df_resolver(self):
        return self.output_row_order == "one-to-one"

    @graph_cached_property
    def df_inputs_grouped(
        self,
    ) -> Mapping[
        DataFrameType,
        FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | HasManyFeatureType
            | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
        ],
    ]:
        """
        Get the individual input features for a resolver with DataFrame inputs,
        including any features referenced by the DF's filter.
        NOTE: self.input_is_df must be true

        :return: A set of the unique features for each of this resolver's DataFrame inputs' columns.
        """
        assert self.input_is_df, (
            "ResolverParsed.df_inputs() only available for the Resolver's inputs are all DataFrames."
        )
        input_columns = dict[
            DataFrameType,
            FrozenOrderedSet[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | HasManyFeatureType
                | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
            ],
        ]()
        for df_input in self.inputs:
            columns_in_df = OrderedSet[
                ScalarFeatureType
                | HasManyFeatureType
                | FeatureTimeFeatureType
                | InputFeatureType[ScalarFeatureType | HasManyFeatureType | FeatureTimeFeatureType]
            ]()
            # Skip 'Now' and others.
            if isinstance(df_input, ScalarFeatureType) and df_input.namespace == PSEUDONAMESPACE:
                continue
            # all non-psuedofeature inputs are DataFrameType
            assert isinstance(df_input, DataFrameType)
            for ft in df_input.columns:
                if is_underlying_feature_time(ft) or is_underlying_scalar(ft) or is_underlying_has_many(ft):
                    columns_in_df.add(ft)
                else:
                    raise ValueError(f"Invalid column feature type for DF inputs: {ft}")
            if df_input.filter is not None:
                columns_in_df.update(df_input.filter.all_referenced_features())
            input_columns[df_input] = FrozenOrderedSet(s for x in columns_in_df for s in required_features_to_sample(x))
        return input_columns

    def df_inputs(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | HasManyFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
    ]:
        return FrozenOrderedSet(s for x in self.df_inputs_grouped.values() for s in x)

    def df_resolver_type(self) -> DataFrameResolverType:
        if not (self.input_is_df and self.output_is_df):
            raise ValueError(
                "Method `ResolverParsed.df_resolver_type()` only applies to resolvers that take DataFrames as inputs & outputs."
            )
        if len(self.inputs) == 0:
            return DataFrameResolverType.NO_ARG_DF_RESOLVER
        elif len(set(self.input_root_namespaces) | {self.output_root_ns}) == 1:
            if all(is_general_has_many(x) for x in self.output_features):
                return DataFrameResolverType.FLATTENED_HAS_MANY_RETURNING_RESOLVER
            return DataFrameResolverType.SAME_NAMESPACE_DF_RESOLVER
        else:
            return DataFrameResolverType.AGGREGATION_RESOLVER


class ResolverMultipleOutputNamespaceError(RuntimeError):
    def __init__(self, resolver: ResolverParsed, previous_output_root_ns: str, feature_root_ns: str):
        super().__init__(
            (
                f"Resolver '{resolver.fqn}', which returns features in multiple root namespaces ({feature_root_ns}, "
                f"{previous_output_root_ns}), is not allowed. "
                "All output features must be in the same root namespace. To fix, reference the feature in "
                "the foreign namespace using a relationship. For example, the following would be permitted: "
                f"`def {resolver.fqn.split('.')[-1]}(...) -> Features[User.id, User.account.number]: ...`"
            )
        )
        self.resolver = resolver
        self.resolver_fqn = resolver.fqn
        self.feature_root_ns = feature_root_ns
        self.output_root_ns = previous_output_root_ns


@dataclasses.dataclass(frozen=True)
class _CronResolverMixin:
    cron: Union[CronTab, Duration, Cron, None] = dataclasses.field(repr=False, compare=False)
    cron_filter: Optional[CronFilterWithFeatureArgs] = dataclasses.field(repr=False, compare=False)
    when: Optional[FilterParsed] = dataclasses.field(compare=False, repr=False)


@dataclasses.dataclass(frozen=True)
class OnlineResolverParsed(ResolverParsed, _CronResolverMixin): ...


@dataclasses.dataclass(frozen=True)
class OfflineResolverParsed(ResolverParsed, _CronResolverMixin): ...


@dataclasses.dataclass
class _LazyStaticOp:
    """
    Deferred computation of a static operation, evaluated and cached on first access.
    We construct DataFrame objects lazily because constructing them (even without running them)
    can have resource-intensive side-effects, like scanning tables to discover their schema.
    """

    _factory: Callable[[], StaticOperator | ChalkDataFrame] = dataclasses.field(repr=False)
    _cached: StaticOperator | ChalkDataFrame | None = dataclasses.field(default=None, init=False, repr=False)

    def resolve(self) -> StaticOperator | ChalkDataFrame:
        if self._cached is None:
            self._cached = self._factory()
        return self._cached


@dataclasses.dataclass(frozen=True)
class MainProcResolverMixin:
    """Marker to indicate that the resolver should be called in the main process. As such, it has an arbitrary `fn` attached.
    This type of resolver need not be serializable, but it also cannot depend on the user's code."""

    fn: Callable[..., Any] = dataclasses.field(repr=False, compare=False)

    static: bool = dataclasses.field(compare=False, repr=False)
    """Whether this resolver is static -- meaning that its functions should be called at planning time to produce
    libchalk expressions"""

    static_operation: StaticOperator | ChalkDataFrame | _LazyStaticOp | None = dataclasses.field(
        compare=False, repr=False
    )
    """If the resolver is static, this is the operation expression from which to derive a libchalk expression"""

    def get_fn(self):
        return self.fn

    def get_static_operation(self) -> StaticOperator | ChalkDataFrame | None:
        """Return the static operation, computing and caching it if it was deferred."""
        op = self.static_operation
        if not isinstance(op, _LazyStaticOp):
            return op
        result = op.resolve()
        object.__setattr__(self, "static_operation", result)
        return result


@dataclasses.dataclass(frozen=True)
class MainProcOnlineResolver(MainProcResolverMixin, OnlineResolverParsed):
    """Special type of resolver to indicate that it is a synthetic resolver, meaning it is called in the engine's process"""


@dataclasses.dataclass(frozen=True)
class MainProcOfflineResolver(MainProcResolverMixin, OfflineResolverParsed):
    """Special type of resolver to indicate that it is a synthetic resolver, meaning it is called in the engine's process"""


@dataclasses.dataclass(frozen=True)
class SinkResolverParsed(ResolverParsed):
    """Representation of a client's @sink resolver.

    `output` field is ignored for sinkresolvers. If configured, the `sink_integration` field will point to a
     KafkaSource or SQLProtocol to which the user function's return value should be sent"""

    input_is_df: bool = dataclasses.field(repr=False, compare=False)
    buffer_size: Optional[int] = dataclasses.field(repr=False, compare=False)
    debounce: Optional[Duration] = dataclasses.field(repr=False, compare=False)
    max_delay: Optional[Duration] = dataclasses.field(repr=False, compare=False)
    upsert: Optional[bool] = dataclasses.field(repr=False, compare=False)
    integration: Optional[SinkIntegrationProtocol | BaseSQLSourceProtocol]
