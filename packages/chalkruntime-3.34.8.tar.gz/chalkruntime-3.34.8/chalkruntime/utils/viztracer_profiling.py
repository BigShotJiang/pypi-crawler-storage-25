from __future__ import annotations

import logging
import os
import threading
import time
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from typing import Any

_logger = logging.getLogger(__name__)


def make_tracer(**kwargs: Any) -> Any:
    """Create a VizTracer instance with sensible defaults.

    By default, traces C function calls (ignore_c_function=False) so that
    native extension calls (libchalk, pyarrow, polars, etc.) appear in traces
    with their symbol names.
    """
    from viztracer import VizTracer  # pyright: ignore[reportMissingImports]

    defaults: dict[str, Any] = {
        "verbose": 0,
        "ignore_c_function": False,
        "ignore_frozen": False,
    }
    defaults.update(kwargs)
    return VizTracer(**defaults)


@contextmanager
def viztracer_context(output_file: str, **kwargs: Any) -> Iterator[Any]:
    """Start/stop/save a tracer around a block."""
    tracer = make_tracer(**kwargs)
    tracer.start()
    try:
        yield tracer
    finally:
        tracer.stop()
        tracer.save(output_file)
        _logger.info("VizTracer trace saved to %s", output_file)


class SlowCallTracer:
    """Always-on circular buffer tracer for slow-call detection.

    Runs continuously with a fixed-size circular buffer. When a call exceeds
    the threshold, the buffer is dumped to disk (containing a backward-looking
    trace of recent activity), cleared, and restarted.
    """

    def __init__(self, threshold_ms: int, output_dir: str, tracer_entries: int = 1_000_000):
        super().__init__()
        self._threshold_secs = threshold_ms / 1000.0
        self._output_dir = output_dir
        self._tracer_entries = tracer_entries
        self._tracer: Any = None
        self._hooked_threads: set[int] = set()

    def start(self) -> None:
        os.makedirs(self._output_dir, exist_ok=True)
        self._tracer = make_tracer(
            tracer_entries=self._tracer_entries,
            max_stack_depth=-1,
        )
        self._tracer.start()
        _logger.info(
            "SlowCallTracer started (threshold=%.1fms, dir=%s)",
            self._threshold_secs * 1000,
            self._output_dir,
        )

    def log_invoke(self, resolver_fqns: Iterable[str], elapsed_secs: float) -> None:
        """Log an instant event marking a unary_invoke call in the trace."""
        if self._tracer is None:
            return
        # Ensure viztracer's trace hook is installed on the current thread.
        # Threads spawned by native code (e.g. C++ gRPC workers) don't get
        # automatically hooked by viztracer, so we install it on first contact.
        tid = threading.get_ident()
        if tid not in self._hooked_threads:
            self._tracer.enable_thread_tracing()
            self._hooked_threads.add(tid)
        resolver_label = next(iter(resolver_fqns), "unknown") if resolver_fqns else "unknown"
        self._tracer.log_instant(
            f"unary_invoke {resolver_label}",
            args={"resolver": resolver_label, "elapsed_ms": elapsed_secs * 1000},
            scope="p",
        )

    def check_and_dump(self, resolver_fqns: Iterable[str], elapsed_secs: float) -> None:
        if self._tracer is None:
            return
        if elapsed_secs < self._threshold_secs:
            return

        tid = threading.get_ident()
        if tid not in self._hooked_threads:
            self._tracer.enable_thread_tracing()
            self._hooked_threads.add(tid)

        resolver_label = next(iter(resolver_fqns), "unknown") if resolver_fqns else "unknown"
        # Sanitize the resolver name for use in a filename
        safe_label = resolver_label.replace("/", "_").replace(".", "_")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"slow_{safe_label}_{timestamp}.json"
        output_path = os.path.join(self._output_dir, filename)

        try:
            self._tracer.stop()
            self._tracer.save(output_path)
            _logger.warning(
                "Slow call detected (%.1fms, threshold %.1fms) for %s — trace saved to %s",
                elapsed_secs * 1000,
                self._threshold_secs * 1000,
                resolver_label,
                output_path,
            )
        except Exception:
            _logger.exception("Failed to save slow-call trace to %s", output_path)
        finally:
            self._tracer.clear()
            self._tracer.start()
            self._hooked_threads.clear()


class TimedInvocationTracer:
    """Traces invocations for a fixed duration then stops.

    Uses threading.Timer to automatically stop tracing after the configured
    duration (default 10 seconds). The tracer captures all threads.
    """

    def __init__(self, output_file: str, duration_secs: float = 10.0):
        super().__init__()
        self._output_file = output_file
        self._duration_secs = duration_secs
        self._tracer: Any = None
        self._timer: threading.Timer | None = None
        self._active = False
        self._lock = threading.Lock()

    def start(self) -> None:
        self._tracer = make_tracer()
        self._tracer.start()
        self._active = True
        self._timer = threading.Timer(self._duration_secs, self._stop_and_save)
        self._timer.daemon = True
        self._timer.start()
        _logger.info(
            "TimedInvocationTracer started (duration=%.1fs, output=%s)",
            self._duration_secs,
            self._output_file,
        )

    @property
    def is_active(self) -> bool:
        return self._active

    def _stop_and_save(self) -> None:
        with self._lock:
            if not self._active or self._tracer is None:
                return
            self._active = False
            try:
                self._tracer.stop()
                self._tracer.save(self._output_file)
                _logger.info(
                    "TimedInvocationTracer finished — trace saved to %s",
                    self._output_file,
                )
            except Exception:
                _logger.exception("Failed to save timed invocation trace to %s", self._output_file)
