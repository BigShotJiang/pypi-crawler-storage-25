import contextlib
import typing
from contextvars import ContextVar

T = typing.TypeVar("T")


@contextlib.contextmanager
def contextvar_ctx(ctx_var: ContextVar[T], value: T):
    token = ctx_var.set(value)
    try:
        yield
    finally:
        ctx_var.reset(token)
