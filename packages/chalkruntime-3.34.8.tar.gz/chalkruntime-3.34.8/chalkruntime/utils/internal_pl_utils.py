"""
Polars compatibility utilities to handle API changes between versions.
"""

from typing import TYPE_CHECKING, Literal, overload

if TYPE_CHECKING:
    import polars as pl

try:
    # Newer polars versions (>=0.20.0) expose DataType
    from polars import DataType as CompatPlDataType
except ImportError:
    # Older polars versions expose PolarsDataType
    from polars import PolarsDataType as CompatPlDataType  # type: ignore

try:
    # Polars >= 1.33: PanicException in polars.exceptions
    from polars.exceptions import PanicException as PolarsPanicErrorCompat  # type: ignore
except (ImportError, AttributeError):
    try:
        # Polars < 1.0: PolarsPanicError at package level
        from polars import PolarsPanicError as PolarsPanicErrorCompat  # type: ignore
    except (ImportError, AttributeError):
        # Fallback if neither is available
        class PolarsPanicErrorCompat(Exception):  # type: ignore
            """Fallback for PolarsPanicError when not available in polars."""

            pass


# Join coalesce compatibility
# In Polars >= 1.0, the coalesce parameter was added to join()
# Cache whether coalesce is supported to avoid repeated signature checks
_JOIN_SUPPORTS_COALESCE: bool | None = None


def _check_join_supports_coalesce() -> bool:
    """Check if the join method supports the coalesce parameter."""
    global _JOIN_SUPPORTS_COALESCE

    if _JOIN_SUPPORTS_COALESCE is not None:
        return _JOIN_SUPPORTS_COALESCE

    import inspect

    import polars as pl

    # Create a dummy DataFrame to check the join signature
    try:
        dummy_df = pl.DataFrame({"a": [1]})
        join_signature = inspect.signature(dummy_df.join)
        _JOIN_SUPPORTS_COALESCE = "coalesce" in join_signature.parameters  # pyright: ignore[reportConstantRedefinition]
    except Exception:
        # If we can't determine, assume older version without coalesce
        _JOIN_SUPPORTS_COALESCE = False  # pyright: ignore[reportConstantRedefinition]

    return _JOIN_SUPPORTS_COALESCE


def join_compat(
    left: "pl.DataFrame",
    right: "pl.DataFrame",
    on: str | list[str] | None = None,
    how: Literal["inner", "left", "outer", "cross", "semi", "anti"] = "inner",
    left_on: str | list[str] | None = None,
    right_on: str | list[str] | None = None,
    suffix: str = "_right",
    coalesce: bool = False,
) -> "pl.DataFrame":
    """
    Join two DataFrames in a version-compatible way.

    In newer Polars versions (>= 1.0), the coalesce parameter was added to join().
    When coalesce=True, join keys from the right DataFrame are coalesced with
    the left DataFrame's join keys, avoiding duplicate columns.

    This function conditionally uses coalesce based on Polars version.

    Args:
        left: The left DataFrame
        right: The right DataFrame
        on: Column name(s) to join on (used when join keys are the same in both frames)
        how: Join strategy - one of "inner", "left", "outer", "cross", "semi", "anti"
        left_on: Column name(s) from left frame to join on
        right_on: Column name(s) from right frame to join on
        suffix: Suffix to add to duplicate column names from the right frame
        coalesce: Whether to coalesce join keys (only works in Polars >= 1.0)

    Returns:
        The joined DataFrame
    """
    if coalesce and _check_join_supports_coalesce():
        # Newer API: use coalesce parameter
        return left.join(  # type: ignore
            right,
            on=on,
            how=how,
            left_on=left_on,
            right_on=right_on,
            suffix=suffix,
            coalesce=True,  # pyright: ignore
        )
    else:
        # Older API: omit coalesce parameter
        return left.join(  # type: ignore
            right,
            on=on,
            how=how,
            left_on=left_on,
            right_on=right_on,
            suffix=suffix,
        )


@overload
def with_row_index_compat(df: "pl.LazyFrame", name: str) -> "pl.LazyFrame": ...


@overload
def with_row_index_compat(df: "pl.DataFrame", name: str) -> "pl.DataFrame": ...


def with_row_index_compat(df: "pl.LazyFrame | pl.DataFrame", name: str) -> "pl.DataFrame | pl.LazyFrame":
    """
    Add a row index column in a version-compatible way.

    In newer Polars versions, with_row_count() is deprecated in favor of with_row_index().
    Note that the default column name changed from 'row_nr' to 'index'.

    Args:
        df: The DataFrame to add a row index to
        name: The name for the row index column

    Returns:
        A DataFrame with the row index column added
    """
    try:
        # Try newer API first: with_row_index()
        return df.with_row_index(name)  # type: ignore
    except AttributeError:
        # Fall back to older API: with_row_count()
        return df.with_row_count(name)  # type: ignore


__all__ = ["CompatPlDataType", "PolarsPanicErrorCompat", "join_compat", "with_row_index_compat"]
