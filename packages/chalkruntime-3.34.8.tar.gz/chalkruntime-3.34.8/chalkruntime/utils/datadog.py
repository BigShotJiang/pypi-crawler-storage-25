from typing import Any

DEFAULT_STATSD_SOCKET_PATH = "/var/run/datadog/dsd.socket"


def get_statsd_socket_path(statsd_socket_path: str) -> str:
    """
    If the path starts with "unix://", we strip it to get the actual path.
    """
    return statsd_socket_path if not statsd_socket_path.startswith("unix://") else statsd_socket_path[7:]


def get_datadog_kwargs(
    dd_dogstatsd_url: str | None,
    dd_agent_host: str,
    statsd_port: int,
    cloud_provider: str,
) -> dict[str, Any]:
    base_config = {"statsd_disable_buffering": False}
    if dd_dogstatsd_url is not None:
        statsd_socket_path = get_statsd_socket_path(dd_dogstatsd_url)
        ddog_kwargs: dict[str, Any] = {
            **base_config,
            "statsd_socket_path": statsd_socket_path,
            "statsd_host": None,
            "statsd_port": None,
        }
    elif dd_agent_host != "127.0.0.1":
        # if we have set the statsd host to something other than the default, don't use the
        # gcp/aws override logic to redirect it to the aws-specific socket path
        ddog_kwargs: dict[str, Any] = {
            **base_config,
            "statsd_socket_path": None,
            "statsd_host": dd_agent_host,
            "statsd_port": statsd_port,
        }
    else:
        ddog_kwargs: dict[str, Any] = {
            **base_config,
            "statsd_socket_path": (DEFAULT_STATSD_SOCKET_PATH if cloud_provider == "AWS" else None),
            "statsd_host": (dd_agent_host if cloud_provider == "GCP" else None),
            "statsd_port": (statsd_port if cloud_provider == "GCP" else None),
        }
    return ddog_kwargs
