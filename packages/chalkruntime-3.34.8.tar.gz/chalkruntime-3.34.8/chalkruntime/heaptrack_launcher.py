import argparse
import os
import shutil
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Launch a Python module with heaptrack profiling. Requires that heaptrack is installed externally!!"
    )
    parser.add_argument("module", type=str, help='Python module to run (e.g., "mypackage.mymodule")')
    args, remaining = parser.parse_known_args()

    heaptrack = shutil.which("heaptrack")
    if heaptrack is None:
        raise RuntimeError("Cannot startup the heaptrack launcher as `which heaptrack` did not find anything")

    # Appears as /tmp/heaptrack_out.{pid}.gz
    heaptrack_output_path = os.environ.get("CHALK_HEAPTRACK_LAUNCHER_OUTPUT_PATH", "/tmp/heaptrack_out")

    # Allow customization of heaptrack options via environment variable
    heaptrack_opts = os.environ.get("CHALK_HEAPTRACK_LAUNCHER_OPTS", "").split()

    argv = [
        "heaptrack",
        "-o",
        heaptrack_output_path,
        *heaptrack_opts,
        # Python execution
        sys.executable,
        "-m",
        args.module,
        *remaining,
    ]

    os.execvp("heaptrack", argv)


if __name__ == "__main__":
    main()
