from __future__ import annotations

import io
import os
import tarfile
import tempfile
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from chalk.features import Feature, FeatureSetBase
from chalk.features.resolver import RESOLVER_REGISTRY
from chalk.importer import (
    import_all_python_files_from_dir,
    import_sql_file_resolvers,
    run_post_import_fixups,
)
from chalk.parsed.duplicate_input_gql import FailedImport
from chalk.utils.log_with_context import get_logger
from chalk.utils.storage_client import (
    AzureBlobStorageClient,
    GCSStorageClient,
    LocalStorageClient,
    S3StorageClient,
    StorageClient,
)
from chalk.utils.tracing import PerfTimer, safe_add_metrics, safe_trace

from chalkruntime.graph.singletons import SingletonGraphAugmenter, temporarily_disable_feature_set_base_hook

if TYPE_CHECKING:
    import google.cloud.storage
    from azure.core.credentials import TokenCredential
    from azure.core.credentials_async import AsyncTokenCredential
    from chalk.utils.threading import ChalkThreadPoolExecutor
    from mypy_boto3_s3.client import S3Client


_logger = get_logger(__name__)


def import_source(
    check_ignores: bool,
    target_root: str | None,
    py_file_allowlist: list[str] | None = None,
    sql_file_allowlist: list[str] | None = None,
    augment_singletons: bool = True,
) -> list[FailedImport]:
    failed_imports: list[FailedImport] = []
    py_allowlist = [Path(file) for file in py_file_allowlist] if py_file_allowlist is not None else None
    if target_root is not None:
        _logger.info(f"Importing all files from {target_root}, {check_ignores=}...")
        with PerfTimer() as pt:
            failed_imports.extend(
                import_all_python_files_from_dir(
                    Path(target_root), check_ignores=check_ignores, file_allowlist=py_allowlist
                )
            )
        _logger.info(f"Imported all files from {target_root} in {pt.duration_seconds} seconds")

    # Always process SQL file resolvers — both disk .chalk.sql files (when target_root is set)
    # and generated resolvers from make_sql_file_resolver (regardless of target_root).
    has_import_errors = len(failed_imports) > 0
    failed_imports.extend(
        import_sql_file_resolvers(
            path=Path(target_root) if target_root is not None else None,
            file_allowlist=sql_file_allowlist,
            has_import_errors=has_import_errors,
        )
    )

    # If some imports failed, no point in running post-import fixes / graph augmenter since graph will be incomplete anyway
    if len(failed_imports) > 0:
        _logger.warning(f"Failed to import files: {failed_imports}")
        return failed_imports

    if augment_singletons:
        run_singleton_augmenter()

    # The post import process to clean up things like windowed features
    run_post_import_fixups()

    return failed_imports


def run_singleton_augmenter() -> None:
    # Singleton Augmenter cannot be called in the chalkpy post-import fixer upper
    # because Singleton Augmenter is a hack and should not be in chalkpy.
    features: list[Feature] = []
    for fs in FeatureSetBase.registry.values():
        features.extend(list(fs.features))
    with temporarily_disable_feature_set_base_hook():
        SingletonGraphAugmenter.augment_features(features)
    for r in RESOLVER_REGISTRY.get_all_resolvers():
        try:
            if os.getenv("CHALK_SKIP_SINGLETONS", "0") == "1":
                continue
            SingletonGraphAugmenter.modify_resolver(r)
        except Exception as e:
            raise RuntimeError(f"Failed to augment resolver '{r.fqn}'") from e


def download_source(filepath: str, dest: str, source_storage_client: StorageClient):
    """
    Download source from GCS to local filesystem.
    This gets run in multiple threads so we copy to a temp file and then try to rename it to `dest`. If this fails then `dest` likely exists.
    :param filepath: The filepath to the source in the bucket
    :param dest: path on local machine
    """
    file_buffer = io.BytesIO()
    with safe_trace("download_file_from_cloud"):
        source_storage_client.download_object(filepath, file_buffer)
        bytes_written = file_buffer.tell()
        safe_add_metrics({"hot_deploy.bytes_written": bytes_written})
        file_buffer.seek(0)

    # Ensure that the tempdir parent can exist
    parent_dir = os.path.normpath(os.path.join(dest, ".."))
    os.makedirs(parent_dir, exist_ok=True)

    # Creating the tempdir in the same root as the dest, as otherwise we get Invalid cross device link errors
    with (
        tempfile.TemporaryDirectory(dir=parent_dir) as tempdir,
    ):
        dest_temp = os.path.join(tempdir, "source")
        with safe_trace("decompress_file"):
            with tarfile.open(fileobj=file_buffer) as tarred_file:
                tarred_file.extractall(dest_temp)
            try:
                os.replace(dest_temp, dest)
                _logger.info(f"Download deployment source called, bytes_written={bytes_written}")
            except OSError as e:
                _logger.info(f"Not renaming {dest_temp} to {dest}, source dir likely already exists", exc_info=e)


@dataclass
class ParsedBucketUri:
    scheme: str
    storage_account_name: Optional[str]
    bucket: str
    path: str


def parse_bucket_uri(bucket_uri: str) -> ParsedBucketUri:
    uri_split = urllib.parse.urlsplit(bucket_uri)
    scheme = uri_split.scheme
    storage_account_name: Optional[str] = None
    bucket = uri_split.netloc
    path = uri_split.path.lstrip("/")

    if bucket.endswith(".blob.core.windows.net"):
        storage_account_name = bucket.removesuffix(".blob.core.windows.net")
        path_parts = path.split("/", 1)
        bucket = path_parts[0]
        path = path_parts[1] if len(path_parts) > 1 else ""
    elif bucket.endswith(".dfs.core.windows.net"):
        bucket_parts = bucket.removesuffix(".dfs.core.windows.net").split("@", 1)
        storage_account_name = bucket_parts[1]
        bucket = bucket_parts[0]

    return ParsedBucketUri(
        scheme=scheme,
        storage_account_name=storage_account_name,
        bucket=bucket,
        path=path,
    )


def get_storage_client_from_bucket_uri(
    bucket_uri: str,
    executor: ChalkThreadPoolExecutor,
    gcs_client_supplier: Callable[[], google.cloud.storage.Client | None],
    s3_client_supplier: Callable[[], S3Client],
    azure_creds_supplier: Callable[[], tuple[TokenCredential | None, AsyncTokenCredential | None]],
) -> StorageClient:
    parsed_uri = parse_bucket_uri(bucket_uri)
    scheme = parsed_uri.scheme
    bucket = parsed_uri.bucket
    if scheme == "":
        # Backwards compatibility for environs that are just bucket names and not fully-qualified uris
        _logger.info(f"Bucket uri {bucket_uri} was passed with no scheme, assuming gs://")
        scheme = "gs"
        bucket = parsed_uri.path
    if scheme == "gs" or scheme == "gcs":
        if parsed_uri.scheme == "":
            _logger.warning(
                f"DEPRECATED_STORAGE_URI The GCS URI {repr(bucket_uri)} does not specify a scheme; use {repr('gcs://' + bucket)} instead"
            )
        if parsed_uri.path != "" and parsed_uri.scheme != "":
            _logger.warning(
                f"DEPRECATED_STORAGE_URI The GCS URI {repr(bucket_uri)} includes a path component {repr(parsed_uri.path)} which is currently ignored"
            )
        gcs_client = gcs_client_supplier()
        if gcs_client is None:
            raise ValueError("Cannot construct a GCSStorageClient if the GCSClient is None")
        return GCSStorageClient(
            gcs_client,
            executor,
            bucket,
        )
    elif scheme == "s3":
        if parsed_uri.path != "":
            _logger.warning(
                f"DEPRECATED_STORAGE_URI The S3 URI {repr(bucket_uri)} includes a path component {repr(parsed_uri.path)} which is currently ignored"
            )
        return S3StorageClient(
            bucket=bucket,
            s3_client=s3_client_supplier(),
            executor=executor,
        )
    elif parsed_uri.storage_account_name is not None:  # implies azure blob storage
        sync_azure_creds, aio_azure_creds = azure_creds_supplier()
        if sync_azure_creds is None or aio_azure_creds is None:
            raise ValueError("Azure credentials are not set")

        from azure.storage.blob import BlobServiceClient

        blob_service_client = BlobServiceClient(
            account_url=f"https://{parsed_uri.storage_account_name}.blob.core.windows.net",
            credential=sync_azure_creds,
            api_version="2025-11-05",
        )
        return AzureBlobStorageClient(
            blob_service_client=blob_service_client,
            account_name=parsed_uri.storage_account_name,
            container_name=parsed_uri.bucket,
            executor=executor,
            credential=aio_azure_creds,
        )
    elif scheme == "file":
        folder = os.path.join(bucket, parsed_uri.path) if bucket != "" else "/" + parsed_uri.path
        return LocalStorageClient(folder)
    raise ValueError(f"Unknown storage uri {repr(bucket_uri)}")
