from __future__ import annotations

import collections.abc
import copy
import dataclasses
import functools
import inspect
import traceback
import types
from datetime import timedelta
from typing import (
    Any,
    Collection,
    Optional,
    Sequence,
    Type,
    TypeVar,
    Union,
    cast,
    overload,
)

import frozendict
import google.protobuf.message
import pyarrow as pa
from chalk import NamedQuery, Now
from chalk._lsp.error_builder import LSPErrorBuilder
from chalk._validation.feature_validation import FeatureValidation
from chalk.client import ChalkException
from chalk.features import (
    DataFrame,
    Feature,
    Features,
    FeatureWrapper,
    Filter,
    TimeDelta,
    ensure_feature,
    unwrap_feature,
)
from chalk.features._encoding.converter import make_feature_converter
from chalk.features.feature_field import HasOnePathObj
from chalk.features.resolver import (
    Cron,
    FunctionCapturedGlobalProto,
    FunctionCapturedGlobalStruct,
    OfflineResolver,
    OnlineResolver,
    Resolver,
    ResolverArgErrorHandler,
    SinkResolver,
    StreamResolver,
)
from chalk.features.underscore import Underscore, UnderscoreAttr
from chalk.importer import parse_grouped_window
from chalk.operators import StaticOperator
from chalk.operators._utils import ChalkDataFrame as LegacyChalkDataFrame
from chalk.operators._utils import DfPlaceholder, static_resolver_to_operator
from chalk.parsed.duplicate_input_gql import DiagnosticGQL, DiagnosticSeverityGQL, PositionGQL, RangeGQL
from chalk.parsed.expressions import Operation
from chalk.sql._internal.incremental import IncrementalSettings
from chalk.streams.types import (
    StreamResolverParam,
    StreamResolverParamMessage,
    StreamResolverParamMessageWindow,
)
from chalk.utils.collections import FrozenOrderedSet, get_unique_item
from chalk.utils.df_utils import is_list_like
from chalk.utils.duration import CHALK_MAX_TIMEDELTA, CronTab, Duration, parse_chalk_duration
from chalk.utils.log_with_context import get_logger
from chalk.utils.pydanticutil.pydantic_compat import is_pydantic_basemodel
from chalkdf import DataFrame as ChalkDataFrame
from chalkdf import Schema
from chalkdf.underscore_conversion.convert_underscore_to_expr import convert_underscore_to_expr

from chalkruntime.constants import INTERNAL_TTL_MAX
from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureTimeFeatureType,
    FeatureType,
    FeatureValidationsParsed,
    FilterParsed,
    GroupByFeatureType,
    HasManyFeatureType,
    HasOneFeatureType,
    HasOnePathObjParsed,
    InputFeatureType,
    NamedFeatureType,
    RichConverterInfo,
    ScalarFeatureType,
    UnderlyingFeatureType,
    VersionInfoParsed,
    WindowConfig,
    WindowedFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    is_underlying_scalar,
    is_underlying_windowed,
    is_valid_operation,
    strip_version_suffix,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.materializations import (
    MaterializationWindowConfigParsed,
    MaterializedAggregationType,
    expand_legacy_min_max_by_n_aggregate_on,
    parse_materialized_aggregation_type_from_name,
)
from chalkruntime.graph.resolver import (
    CronFilterWithFeatureArgs,
    MainProcOfflineResolver,
    MainProcOnlineResolver,
    OfflineResolverParsed,
    OnlineResolverParsed,
    ResolverArgErrorHandlerParsed,
    ResolverParsed,
    SinkResolverParsed,
    TResolverFeatureType,
)
from chalkruntime.graph.stream_resolver import (
    STREAM_RESOLVER_MESSAGE_ENVELOPE_TYPE,
    DeduplicationPolicyParsed,
    ParseInfoParsed,
    StreamResolverParamMessageParsed,
    StreamResolverParamMessageWindowParsed,
    StreamResolverParamParsed,
    StreamResolverParsed,
    StreamResolverSignatureParsed,
    StreamSinkConfigParsed,
    TStreamOutputFeatureType,
)
from chalkruntime.graph.underscore import UnderscoreResultScalarType, UnderscoreValue


class ConversionExceptionContext:
    """
    Context manager for converting features.
    1. If an exception is raised, wraps it in a ConversionException w/ the relevant context and rethrows
    2. If a ConversionException is thrown, appends this class's info to the exception object's stack and rethrows.

    This lets us build a 'stack trace' of feature conversion errors.
    """

    def __init__(self, obj: object, name: str | None = None):
        super().__init__()
        self.object = obj
        self.source_info = CustomerSourceInfo.from_obj(self.object, name=name)

    def _build_diagnostic(self, exc: BaseException):
        assert isinstance(self.object, Underscore), (
            "LSP Error Builder on conversion errors is only supported for underscores"
        )
        assert self.object.definition_location() is not None, (
            "Definition location must exist for this underscore expression"
        )
        return DiagnosticGQL(
            range=RangeGQL(
                start=PositionGQL(
                    line=self.object.definition_location().line,  # pyright: ignore[reportOptionalMemberAccess]
                    character=self.object.definition_location().column,  # pyright: ignore[reportOptionalMemberAccess]
                ),
                end=PositionGQL(
                    line=self.object.definition_location().line,  # pyright: ignore[reportOptionalMemberAccess]
                    character=self.object.definition_location().column + 1,  # pyright: ignore[reportOptionalMemberAccess]
                ),
            ),
            message=str(exc),
            severity=DiagnosticSeverityGQL.Error,
            code=None,
            codeDescription=None,
            relatedInformation=None,
        )

    def __enter__(self):
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        tb: types.TracebackType | None,
    ) -> None:
        if isinstance(exc_value, ConversionException):
            exc_value.stack.append(self.source_info)
            raise exc_value
        elif exc_value is not None:
            e = ConversionException(stack=[self.source_info], underlying_exception=exc_value)
            if isinstance(self.object, Underscore) and self.object.definition_location() is not None:
                LSPErrorBuilder.all_errors[self.object.definition_location().file].append(self._build_diagnostic(e))  # pyright: ignore[reportOptionalMemberAccess]
                e.is_lsp_error = True
            raise e


class CustomerSourceInfo:
    def __init__(
        self, *, object_type: str, object_id: str, source_filepath: str | None = None, source_linenum: int | None = None
    ):
        super().__init__()
        self.object_type = str(object_type)
        self.object_id = str(object_id)
        self.source_filepath = source_filepath and str(source_filepath)
        self.source_linenum = source_linenum and int(source_linenum)

    @classmethod
    def from_obj(cls, obj: Any, name: str | None = None):
        if isinstance(obj, FeatureWrapper):
            obj = unwrap_feature(obj)
        if isinstance(obj, Feature):
            return cls(
                object_id=name or obj.root_fqn,
                object_type="feature",
                source_filepath=obj.features_cls.__chalk_filename__ if obj.features_cls is not None else None,
            )
        if isinstance(obj, OnlineResolver):
            return cls(
                object_id=name or obj.fqn,
                object_type="online resolver",
                source_filepath=obj.filename,
                source_linenum=obj.source_line,
            )
        if isinstance(obj, OfflineResolver):
            return cls(
                object_id=name or obj.fqn,
                object_type="offline resolver",
                source_filepath=obj.filename,
                source_linenum=obj.source_line,
            )
        if isinstance(obj, HasOnePathObj):
            child_f = obj.child
            return cls(
                object_id=name or obj.parent_to_child_attribute_name,
                object_type="has-one feature path",
                source_filepath=child_f.features_cls.__chalk_filename__ if child_f.features_cls is not None else None,
            )
        if isinstance(obj, StreamResolver):
            return cls(
                object_id=name or obj.fqn,
                object_type="stream resolver",
                source_filepath=obj.filename,
                source_linenum=obj.source_line,
            )
        if isinstance(obj, SinkResolver):
            return cls(
                object_id=name or obj.fqn,
                object_type="sink resolver",
                source_filepath=obj.filename,
                source_linenum=obj.source_line,
            )
        if isinstance(obj, NamedQuery):
            return cls(object_id=name or obj.name, object_type="named query")
        if isinstance(obj, Underscore):
            src_location = obj._chalk_definition_location  # pyright: ignore[reportPrivateUsage]
            return cls(
                object_id=name or "<underscore-expr>",
                object_type="underscore expression",
                source_filepath=src_location and src_location.file,
                source_linenum=src_location and src_location.line,
            )

        raise ValueError(f"Unknown Object: {obj}")


class ConversionException(RuntimeError):
    def __init__(self, underlying_exception: BaseException, stack: list[CustomerSourceInfo]):
        super().__init__(underlying_exception, stack)
        self.stack: list[CustomerSourceInfo] = stack

        # Concat the messages of chained exceptions (i.e. raise ABC from XYZ)
        messages: list[str] = [str(underlying_exception)]
        exc = underlying_exception.__context__
        while exc is not None:
            if len(messages) > 100:
                raise RuntimeError("Max depth exceeded while traversing chained exception.")
            messages.append(str(exc))
            exc = exc.__context__

        self.underlying_exception: ChalkException = ChalkException.create(
            kind=type(underlying_exception).__name__,
            message=": ".join(messages),
            stacktrace="".join(traceback.format_exception(underlying_exception)),
        )
        self.is_lsp_error = False

    def __str__(self):
        def _format(x: CustomerSourceInfo):
            linenum = f":{x.source_linenum}" if x.source_linenum else ""
            filepath = f" ({x.source_filepath}{linenum})" if x.source_filepath else ""
            return f" - In {x.object_type} '{x.object_id}'{filepath}"

        stack = "\n".join([_format(x) for x in self.stack])
        return f"Feature conversion error: {self.underlying_exception.message}.\n{stack}"


_logger = get_logger(__name__)

T = TypeVar("T")
TFeatureType = TypeVar("TFeatureType", bound=FeatureType)


@dataclasses.dataclass(frozen=True)
class ParsedInputs:
    synthetic_inputs: FrozenOrderedSet[int]
    inputs: tuple[
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[
            ScalarFeatureType | HasOneFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType
        ]
        | DataFrameType,
        ...,
    ]


def _get_original_python_attribute_name(f: Feature):
    if f.is_autogenerated:
        return None
    return getattr(f, "unversioned_attribute_name", getattr(f, "attribute_name", getattr(f, "name", None)))


class RegistryConverter:
    def __init__(self, graph: ResolvedGraph):
        super().__init__()
        self._cache: dict[str | Feature, FeatureType] = {}
        """Cache of already-converted features. Caching the scalars, has-ones and has-manys by fqn string instead of feature, as it avoids
        some python interop of calling __hash__ and __eq__. Has-many features are ached by feature since they have custom logic"""
        self._graph = graph

    def remove_feature_from_cache(self, feature: Feature):
        if feature.is_has_many:
            self._cache.pop(feature, None)
        else:
            self._cache.pop(feature.fqn, None)

    def _convert_filter(self, f: Filter | FilterParsed) -> FilterParsed:
        if isinstance(f, FilterParsed):
            return f
        if f.operation in ("and", "or"):
            if not isinstance(f.lhs, Filter):
                raise ValueError(
                    f"Expected Filter for left-hand side of '{f.operation}' comparison, instead got: {f.lhs}. To compare boolean-valued features, use '(feature == True)' instead of 'feature' directly."
                )
            if not isinstance(f.rhs, Filter):
                raise ValueError(
                    f"Expected Filter for right-hand side of '{f.operation}' comparison, instead got: {f.rhs}. To compare boolean-valued features, use '(feature == True)' instead of 'feature' directly."
                )
            return FilterParsed(
                lhs=self._convert_filter(f.lhs),
                operation=f.operation,
                rhs=self._convert_filter(f.rhs),
            )
        if f.operation == "not":
            if not isinstance(f.lhs, Filter):
                raise ValueError(
                    f"Expected Filter for operand side of 'not' comparison, instead got: {f.lhs}. To compare boolean-valued features, use '~(feature == True)' or '(feature == False)' instead of 'feature' directly."
                )
            if f.rhs is not None:
                raise ValueError(f"Expected only one operand for 'not' comparison, instead got 2: {f.lhs=}, {f.rhs=}")
            return FilterParsed(
                lhs=self._convert_filter(f.lhs),
                operation="not",
                rhs=None,
            )

        lhs = f.lhs
        rhs = f.rhs
        if isinstance(lhs, FeatureWrapper):
            lhs = unwrap_feature(lhs)
        if isinstance(rhs, FeatureWrapper):
            rhs = unwrap_feature(rhs)
        if isinstance(lhs, Feature) and isinstance(rhs, TimeDelta):
            # This means that the filter was a before() or after()
            # Timestamp filters should be relative to the root query (i.e. query 1)'s observed at, not the local ts filter
            converted_ts_feature = self.convert_type(lhs)
            if not is_valid_operation(f.operation):
                raise ValueError(f"Unsupported operation: {f.operation}")
            assert isinstance(converted_ts_feature, (ScalarFeatureType, FeatureTimeFeatureType)), (
                "after()/before() filters can only be used with a Scalar or FeatureTime FeatureType."
            )
            return FilterParsed(
                lhs=converted_ts_feature,
                operation=f.operation,
                rhs=rhs.to_std(),
            )

        if isinstance(lhs, Feature):
            lhs = self.convert_type(lhs)
            assert is_underlying_scalar(lhs) or is_underlying_feature_time(lhs)

        if isinstance(rhs, Feature):
            rhs = self.convert_type(rhs)
            assert is_underlying_scalar(rhs) or is_underlying_feature_time(rhs)

        if (isinstance(lhs, (ScalarFeatureType, FeatureTimeFeatureType)) and isinstance(rhs, timedelta)) or (
            isinstance(rhs, (ScalarFeatureType, FeatureTimeFeatureType)) and isinstance(lhs, timedelta)
        ):
            return FilterParsed(lhs=lhs, operation=cast(Operation, f.operation), rhs=rhs)

        if not isinstance(lhs, FeatureType):
            # The LHS must be a literal, rich value if it's not a feature
            # Convert it to a primitive value using the RHS's dtype
            assert is_underlying_scalar(rhs) or is_underlying_feature_time(rhs), "One side must be a feature"
            lhs = rhs.underlying.to_feature().converter.from_rich_to_primitive(lhs)
        if not isinstance(rhs, FeatureType):
            assert is_underlying_scalar(lhs) or is_underlying_feature_time(lhs), "One side must be a feature"
            if f.operation in ("in", "not in"):
                assert isinstance(rhs, collections.abc.Iterable)
                rhs = tuple(lhs.underlying.to_feature().converter.from_rich_to_primitive(x) for x in rhs)
            else:
                rhs = lhs.underlying.to_feature().converter.from_rich_to_primitive(rhs)

        assert isinstance(lhs, FeatureType) or isinstance(rhs, FeatureType), "one side must be a column"
        if not is_valid_operation(f.operation):
            raise ValueError(f"Unsupported operation: {f.operation}")
        return FilterParsed(lhs=cast(Any, lhs), operation=f.operation, rhs=cast(Any, rhs))

    def _convert_windowed_feature(self, f: Feature) -> WindowedFeatureType:
        return WindowedFeatureType(
            name=f.name,
            namespace=f.namespace,
            autogenerated=False,
            windows=FrozenOrderedSet(f.window_durations),
            _graph=self._graph,
            is_externally_defined=False,
        )

    @staticmethod
    def _explode_validations(validations: list[FeatureValidation]) -> tuple[FeatureValidationsParsed, ...]:
        res: list[FeatureValidationsParsed] = []
        for v in validations:
            if v.min is not None:
                res.append(
                    FeatureValidationsParsed(
                        min=v.min,
                        max=None,
                        min_length=None,
                        max_length=None,
                        strict=v.strict,
                        contains=...,
                    )
                )
            if v.max is not None:
                res.append(
                    FeatureValidationsParsed(
                        min=None,
                        max=v.max,
                        min_length=None,
                        max_length=None,
                        strict=v.strict,
                        contains=...,
                    )
                )
            if v.min_length is not None:
                res.append(
                    FeatureValidationsParsed(
                        min=None,
                        max=None,
                        min_length=v.min_length,
                        max_length=None,
                        strict=v.strict,
                        contains=...,
                    )
                )
            if v.max_length is not None:
                res.append(
                    FeatureValidationsParsed(
                        min=None,
                        max=None,
                        min_length=None,
                        max_length=v.max_length,
                        strict=v.strict,
                        contains=...,
                    )
                )

        return tuple(res)

    def _extract_filter_and_bucket_feature(
        self,
        unconverted_filters: Sequence[Filter],
    ) -> tuple[ScalarFeatureType | FeatureTimeFeatureType | None, tuple[FilterParsed, ...]]:
        # raise ValueError("test")
        bucket_feature_type: ScalarFeatureType | FeatureTimeFeatureType | None = None
        converted_filters: list[FilterParsed] = []

        for filt in unconverted_filters:
            bucket_feature, expected_ops = (
                (filt.rhs, ("<", "<=", ">", ">="))
                if isinstance(filt.lhs, UnderscoreAttr) and filt.lhs._chalk__attr == "chalk_window"  # pyright:ignore[reportPrivateUsage]
                else (filt.lhs, (">", ">=", "<", "<="))
                if isinstance(filt.rhs, UnderscoreAttr) and filt.rhs._chalk__attr == "chalk_window"  # pyright:ignore[reportPrivateUsage]
                else (None, ())
            )

            if bucket_feature is None:
                is_now_comparison = filt.lhs == Now or filt.rhs == Now
                # Strip chalk_now comparisons from the stored mat agg definition — they are
                # applied dynamically at query time. Both directions are valid: positive windows
                # filter data *before* chalk_now (e.g. ts < chalk_now) while negative/lookahead
                # windows filter data *after* chalk_now (e.g. check_in >= chalk_now).
                if not is_now_comparison:
                    converted_filters.append(self._convert_filter(filt))
            elif bucket_feature_type is not None:
                raise ValueError("Only one bucket feature can be specified")
            elif not isinstance(bucket_feature, (Feature, FeatureWrapper)):
                raise ValueError(f"Bucket feature must be a feature, got {bucket_feature}")
            elif filt.operation not in expected_ops:
                raise ValueError("Bucket feature must be compared against chalk_window")
            else:
                conv = self.convert_type(bucket_feature)
                if not isinstance(conv, (ScalarFeatureType, FeatureTimeFeatureType)):
                    raise ValueError(f"Bucket feature must be a feature, got {bucket_feature}")
                bucket_feature_type = conv
        return bucket_feature_type, tuple(converted_filters)

    def _convert_scalar_feature(self, ft: Feature) -> ScalarFeatureType:
        assert ft.path == (), "Should not be called on input feature types"
        cached_val = self._cache.get(ft.fqn)
        if cached_val is not None:
            assert isinstance(cached_val, ScalarFeatureType)
            return cached_val

        max_staleness: timedelta = self.convert_raw_duration(None if ft.max_staleness is ... else ft.max_staleness)
        minimum_write_max_staleness: timedelta = max_staleness

        if ft.last is not None:
            minimum_write_max_staleness = CHALK_MAX_TIMEDELTA

        ttl = ft.offline_ttl
        offline_ttl = self.convert_raw_duration(
            "infinity" if ttl is ... or ttl is None else ttl  # pyright: ignore[reportUnnecessaryComparison]
        )
        assert ft.etl_offline_to_online is not None

        if ft.last_for is None:
            last_for = None
        else:
            last_for = self.convert_type(ft.last_for)
            assert isinstance(last_for, ScalarFeatureType)

        window_materialization_engine: MaterializationWindowConfigParsed | None = None
        if (window_materialization_parsed := ft.window_materialization_parsed) is not None:
            # If the window materialization is set, the
            # feature will be read from the online store
            # exclusively.
            max_staleness = timedelta(0)

            # Write max-staleness is set to 0, because
            # the child feature will be written to the
            # timeseries, not the aggregated feature value.
            minimum_write_max_staleness = timedelta(0)

            group_by: list[ScalarFeatureType] = []
            for g in window_materialization_parsed.group_by:
                feat = self.convert_type(g)
                if not isinstance(feat, ScalarFeatureType):
                    raise ValueError(f"Group-by feature {feat.fqn} is not a scalar feature: {feat}")
                group_by.append(feat)

            window_materialized_aggregation = parse_materialized_aggregation_type_from_name(
                window_materialization_parsed.aggregation
            )
            if window_materialized_aggregation is None:
                raise ValueError(
                    f"The feature '{ft.root_fqn}' uses an unsupported materialized aggregation operation {repr(window_materialization_parsed.aggregation)}"
                )

            aggregate_on = list[ScalarFeatureType | FeatureTimeFeatureType]()
            for feat in window_materialization_parsed.aggregate_on:
                converted = self.convert_type(feat)
                if not isinstance(converted, (ScalarFeatureType, FeatureTimeFeatureType)):
                    raise ValueError(
                        f"Window materialization child feature must be a scalar or feature-time feature, got {aggregate_on}"
                    )
                aggregate_on.append(converted)
            if len(aggregate_on) == 0:
                if window_materialized_aggregation != MaterializedAggregationType.Count:
                    raise ValueError(
                        f"Window materialization child feature must be specified for aggregation {repr(window_materialization_parsed.aggregation)}"
                    )
                primary = self._graph.primary_feature_for_namespace(window_materialization_parsed.namespace)
                if primary is None:
                    raise ValueError(
                        f"Could not find primary feature for namespace {window_materialization_parsed.namespace}"
                    )
                aggregate_on = [primary]

            bucket_feature_type, converted_filters = self._extract_filter_and_bucket_feature(
                unconverted_filters=window_materialization_parsed.filters,
            )
            if bucket_feature_type is None:
                bucket_feature_type = self._graph.ts_feature_for_namespace(window_materialization_parsed.namespace)
                if bucket_feature_type is None:
                    raise ValueError(f"No bucket feature found for namespace {window_materialization_parsed.namespace}")

            window_materialization_engine = MaterializationWindowConfigParsed(
                namespace=window_materialization_parsed.namespace,
                group_by=tuple(group_by),
                bucket_duration=timedelta(seconds=window_materialization_parsed.bucket_duration_seconds),
                bucket_start=window_materialization_parsed.bucket_start,
                aggregation=window_materialized_aggregation,
                aggregate_on=expand_legacy_min_max_by_n_aggregate_on(
                    window_materialized_aggregation,
                    tuple(aggregate_on),
                    bucket_feature_type,
                ),
                aggregation_kwargs=window_materialization_parsed.aggregation_kwargs,
                pyarrow_dtype=window_materialization_parsed.pyarrow_dtype,
                filters=converted_filters,
                bucket_feature=bucket_feature_type,
                continuous_buffer_duration=timedelta(
                    seconds=window_materialization_parsed.continuous_buffer_duration_seconds
                )
                if window_materialization_parsed.continuous_buffer_duration_seconds is not None
                else None,
                backfill_lookback_duration=timedelta(
                    seconds=window_materialization_parsed.backfill_lookback_duration_seconds
                )
                if window_materialization_parsed.backfill_lookback_duration_seconds is not None
                else None,
                continuous_resolver=window_materialization_parsed.continuous_resolver,
                backfill_resolver=window_materialization_parsed.backfill_resolver,
                backfill_schedule=window_materialization_parsed.backfill_schedule,
                backfill_start_time=window_materialization_parsed.backfill_start_time,
            )

        # For versioned features with explicitly enumerated versions, use the
        # default version's converter so the graph has the correct dtype.
        _converter_feature: Feature = ft
        if ft.version is not None and ft.version.explicitly_enumerated and ft.version.default in ft.version.reference:
            _ref = ft.version.reference[ft.version.default]
            if isinstance(_ref, Feature):
                _converter_feature = _ref

        converted = ScalarFeatureType(
            name=ft.name,
            namespace=ft.namespace,
            is_externally_defined=False,
            original_python_attribute_name=_get_original_python_attribute_name(ft),
            attribute_name=getattr(ft, "attribute_name", None),
            is_scalar_feature_nullable=ft.typ.is_nullable,
            converter=_converter_feature.converter,
            primary=ft.primary,
            description=ft.description,
            owner=ft.owner,
            tags=FrozenOrderedSet(ft.tags or ()),
            max_staleness=max_staleness,
            minimum_write_max_staleness=minimum_write_max_staleness,
            offline_ttl=offline_ttl,
            cache_strategy=ft.cache_strategy,
            store_online=ft.store_online,
            store_offline=ft.store_offline,
            etl_offline_to_online=ft.etl_offline_to_online,
            autogenerated=ft.is_autogenerated,
            validations=RegistryConverter._explode_validations(  # pyright: ignore[reportPrivateUsage]
                ft._all_validations  # pyright: ignore[reportPrivateUsage]
            ),
            is_windowed_pseudofeature=ft.is_windowed_pseudofeature,
            is_distance_pseudofeature=ft.is_distance_pseudofeature,
            is_windowed=ft.is_windowed,
            window_config=(
                WindowConfig(
                    window_duration=timedelta(seconds=ft.window_duration),
                    materialization_config=window_materialization_engine,
                )
                if ft.window_duration is not None
                else None
            ),
            version=ft.version
            and VersionInfoParsed(
                maximum=ft.version.maximum,
                default=ft.version.default,
                stripped_fqn=strip_version_suffix(ft.fqn),
            ),
            last_for_fqn=None if last_for is None else last_for.fqn,
            is_singleton=ft.is_singleton,
            underscore_expression=ft.underscore_expression,
            offline_underscore_expression=ft.offline_underscore_expression,
            _graph=self._graph,
            is_deprecated=ft.is_deprecated,
            rich_type_info=RichConverterInfo.from_converter(_converter_feature.converter),
        )
        self._cache[ft.fqn] = converted
        return converted

    def _convert_feature_time(self, t: Feature) -> FeatureTimeFeatureType:
        assert t.path == (), "Should not be called on input feature types"
        cached_val = self._cache.get(t.fqn)
        if cached_val is not None:
            assert isinstance(cached_val, FeatureTimeFeatureType)
            return cached_val
        assert t.is_feature_time

        ret = FeatureTimeFeatureType(
            name=t.name,
            namespace=t.namespace,
            autogenerated=t.is_autogenerated,
            is_externally_defined=False,
            original_python_attribute_name=_get_original_python_attribute_name(t),
            attribute_name=t.attribute_name,
            _graph=self._graph,
        )
        self._cache[t.fqn] = ret
        return ret

    def _convert_has_one(self, f: Feature) -> HasOneFeatureType:
        assert f.path == (), "Should not be called on input feature types"
        cached_val = self._cache.get(f.fqn)
        if cached_val is not None:
            assert isinstance(cached_val, HasOneFeatureType)
            return cached_val
        assert f.is_has_one

        if f.join is None:
            raise ValueError(f"Feature missing join {f.namespace}.{f.name}")

        if f.joined_class is None:
            raise ValueError(f"has-one feature {f.fqn} must reference a Features cls")
        filt = self._convert_filter(f.join)
        ret = HasOneFeatureType(
            namespace=f.namespace,
            name=f.name,
            is_externally_defined=False,
            original_python_attribute_name=_get_original_python_attribute_name(f),
            attribute_name=getattr(f, "attribute_name", None),
            is_has_one_feature_nullable=f.typ.is_nullable,
            autogenerated=f.is_autogenerated,
            _graph=self._graph,
            join=filt,
        )
        self._cache[f.fqn] = ret
        return ret

    def _convert_has_many(self, f: Feature) -> HasManyFeatureType:
        assert f.is_has_many
        assert f.path == (), "Should not be called on input feature types"
        cached_val = self._cache.get(f)
        if cached_val is not None:
            assert isinstance(cached_val, HasManyFeatureType)
            return cached_val

        assert f.join is not None, f"has many feature type should have join, but '{f}' is missing one."
        assert f.typ is not None, "type should be defined"
        df = f.typ.parsed_annotation
        assert isinstance(df, type)
        assert issubclass(df, DataFrame)
        converted = self.convert_type(df)
        assert isinstance(converted, DataFrameType)
        ret = HasManyFeatureType(
            namespace=f.namespace,
            name=f.name,
            autogenerated=f.is_autogenerated,
            max_staleness=self.convert_raw_duration(f.max_staleness),
            online_store_max_items=f.online_store_max_items,
            is_externally_defined=False,
            original_python_attribute_name=_get_original_python_attribute_name(f),
            attribute_name=getattr(f, "attribute_name", None),
            _graph=self._graph,
            join=self._convert_filter(f.join),
            df=converted,
        )
        self._cache[f] = ret
        return ret

    def _convert_path(self, o: Feature) -> tuple[HasOnePathObjParsed, ...]:
        return tuple(self._convert_has_one_path_obj(p, is_last=(i == len(o.path) - 1)) for i, p in enumerate(o.path))

    def _convert_has_one_path_obj(self, t: HasOnePathObj, *, is_last: bool) -> HasOnePathObjParsed:
        parent_without_path = copy.copy(t.parent)
        parent_without_path.path = ()
        parent = self.convert_type(parent_without_path)
        assert isinstance(parent, HasOneFeatureType) or isinstance(parent, HasManyFeatureType)
        if isinstance(parent, HasManyFeatureType):
            parent = parent.select(
                required_columns=FrozenOrderedSet(),
                optional_columns=FrozenOrderedSet(parent.get_foreign_join_features()),
            )
        child_without_path = copy.copy(t.child)
        child_without_path.path = ()
        child = self.convert_type(child_without_path)
        assert not isinstance(child, InputFeatureType)
        if isinstance(child, HasManyFeatureType) and not is_last:
            child = child.select(
                required_columns=FrozenOrderedSet(),
                optional_columns=FrozenOrderedSet(child.get_foreign_join_features()),
            )
        return HasOnePathObjParsed(
            parent=parent,
            child=child,
        )

    def _convert_stream_resolver_param(self, p: StreamResolverParam) -> StreamResolverParamParsed:
        dtype: pa.DataType | None = None
        if isinstance(p, (StreamResolverParamMessage, StreamResolverParamMessageWindow)):
            try:
                dtype = make_feature_converter(name="helper", is_nullable=False, rich_type=p.typ).pyarrow_dtype
            except Exception:
                # TODO Some message types (e.g. BaseModel where some fields can be Any/Union) can't quite be represented
                # as arrow dtypes. Ignore for now
                _logger.warning(f"Failed to parse arrow dtype for streaming parameter {p} -- ignoring for now.")
        if isinstance(p, StreamResolverParamMessage):
            captured_message_type: FunctionCapturedGlobalProto | FunctionCapturedGlobalStruct | None = None
            try:
                if issubclass(p.typ, google.protobuf.message.Message):
                    captured_message_type = FunctionCapturedGlobalProto.from_typ(p.typ)
                elif dataclasses.is_dataclass(p.typ):
                    captured_message_type = FunctionCapturedGlobalStruct.from_typ(p.typ)
                elif is_pydantic_basemodel(p.typ):
                    captured_message_type = FunctionCapturedGlobalStruct.from_typ(p.typ)
            except Exception as e:
                _logger.warning(
                    f"Failed to capture message type object {p.typ} for streaming parameter {p}: {e} -- ignoring for now."
                )
            return StreamResolverParamMessageParsed(
                name=p.name, dtype=dtype, captured_message_type=captured_message_type
            )
        if isinstance(p, StreamResolverParamMessageWindow):
            return StreamResolverParamMessageWindowParsed(name=p.name, dtype=dtype)
        raise ValueError(f"Unsupported stream resolver parameter type '{type(p)}'")

    def _convert_stream_resolver(self, r: StreamResolver) -> StreamResolverParsed:
        from chalkruntime.graph.convert_chalkpy_underscore import (
            StreamResolverRootUnderscoreBehavior,
            convert_underscore_expression,
        )

        parsed_inputs = self._get_inputs(r)
        if r.output is None:
            output: list[TResolverFeatureType] = []
        else:
            output = [
                x for x in self.convert_type(r.output) if isinstance(x, DataFrameType) or not x.underlying.autogenerated
            ]
        mode = r.mode
        if mode is None:
            mode = "tumbling"
        if mode not in ("continuous", "tumbling", "cdc"):
            raise ValueError(
                f"The streaming resolver mode must be 'continuous', 'tumbling', or 'cdc'. Got '{r.mode}' for resolver '{r.fqn}'"
            )
        module = inspect.getmodule(r.fn)
        module_name = module.__name__ if module is not None else None

        # Signature
        params = [self._convert_stream_resolver_param(p) for p in r.signature.params]
        signature_parsed = StreamResolverSignatureParsed(
            output_feature_fqns=r.signature.output_feature_fqns, params=params
        )

        # Parse
        parse_info_parsed: ParseInfoParsed | None = None
        if r.parse is not None:
            parse_underscore: UnderscoreValue | None = None
            if r.parse.parse_expression is not None:
                root_namespace: str = get_unique_item(x.root_namespace for x in output)
                underscore_expression = r.parse.parse_expression  # pyright: ignore[reportPrivateUsage]
                if not isinstance(underscore_expression, Underscore):  # pyright: ignore[reportUnnecessaryIsInstance]
                    raise ValueError(
                        f"Parse expression in stream resolver '{r.fqn}' must be an Underscore, instead got {underscore_expression}"
                    )

                input_message_dtype = (
                    STREAM_RESOLVER_MESSAGE_ENVELOPE_TYPE if r.include_message_envelope else pa.large_binary()
                )
                parse_underscore = convert_underscore_expression(
                    underscore=underscore_expression,
                    for_feature=None,
                    graph=self._graph,
                    prompt_service=None,
                    root_namespace=root_namespace,
                    root_underscore_behavior=StreamResolverRootUnderscoreBehavior(message_dtype=input_message_dtype),
                    error_message_context=f"parse expression for stream resolver '{r.fqn}'",
                    for_offline_resolver=False,
                )
            parse_info_parsed = ParseInfoParsed(
                output_is_optional=r.parse.output_is_optional,
                input_type_name=r.parse.input_type.__name__,
                output_type_name=r.parse.output_type.__name__,
                function_name=r.parse.fn.__name__,
                parse_expression=parse_underscore,
            )

        # Keys
        keys_refs: dict[str, TStreamOutputFeatureType] | None = None
        if r.keys is not None:
            keys_refs = {k: self.convert_type(ensure_feature(v)) for k, v in r.keys.items()}  # pyright: ignore

        # Window pseudofeatures
        windowed_pseudofeatures_refs: dict[int, dict[WindowedFeatureType, ScalarFeatureType]] = {}
        for window, feature_map in r.windowed_pseudofeatures.items():
            windowed_pseudofeatures_refs[window] = {}
            for wf, sf in feature_map.items():
                sf_parsed = self.convert_type(ensure_feature(sf))
                assert isinstance(sf_parsed, ScalarFeatureType)
                wf_parsed = self.convert_type(ensure_feature(wf))
                assert isinstance(wf_parsed, WindowedFeatureType)
                windowed_pseudofeatures_refs[window][wf_parsed] = sf_parsed

        parsed_feature_expressions: (
            dict[
                UnderlyingFeatureType[ScalarFeatureType] | UnderlyingFeatureType[FeatureTimeFeatureType],
                UnderscoreValue,
            ]
            | None
        ) = None
        if r.feature_expressions is not None:
            if len(params) != 1:
                raise ValueError(
                    f"Stream resolver '{r.fqn}' has feature expressions defined, so it must have exactly one input parameter. (found {len(params)})"
                )
            message_param = params[0]
            if not isinstance(message_param, StreamResolverParamMessageParsed):
                raise ValueError(
                    f"Stream resolver '{r.fqn}' has feature expressions defined, so it doesn't support any state or window input parameters. (found {params[0]})"
                )
            if message_param.dtype is None:
                raise ValueError(
                    f"Failed to resolve datatype of parameter '{message_param.name}' for stream resolver '{r.fqn}'."
                )

            feature_input_dtype: pa.DataType = message_param.dtype
            if is_list_like(feature_input_dtype):
                assert isinstance(feature_input_dtype, pa.LargeListType)
                feature_input_dtype = feature_input_dtype.value_type
            parsed_feature_expressions = {}
            for raw_feat, raw_underscore in r.feature_expressions.items():
                parsed_feat = self.convert_type(raw_feat)
                if not (is_underlying_scalar(parsed_feat) or is_underlying_feature_time(parsed_feat)):
                    raise ValueError(
                        f"Stream resolver with feature expressions cannot be used for non-scalar feature {raw_feat}."
                    )
                expr = convert_underscore_expression(
                    underscore=raw_underscore,
                    for_feature=parsed_feat,  # pyright: ignore TODO (rkargon) support more feature types here
                    graph=self._graph,
                    prompt_service=None,
                    root_namespace=parsed_feat.root_namespace,
                    root_underscore_behavior=StreamResolverRootUnderscoreBehavior(message_dtype=feature_input_dtype),
                    for_offline_resolver=False,
                )
                parsed_feature_expressions[parsed_feat] = expr  # pyright: ignore  TODO (rkargon) support more feature types here

        # Sink config
        sink_config: StreamSinkConfigParsed | None = None
        if r.message_producer_parsed is not None:
            output_features: list[TResolverFeatureType] = []
            for raw_feat_fqn in r.message_producer_parsed.output_features:
                parsed_feat = self._graph.feature_from_fqn(raw_feat_fqn)
                assert not isinstance(
                    parsed_feat, GroupByFeatureType
                )  # for pyright, these are not a TResolverFeatureType technically
                if not isinstance(parsed_feat, NamedFeatureType):
                    raise ValueError(
                        f"Failed to parse feature '{raw_feat_fqn}' for message producer for stream resolver '{r.fqn}'"
                    )
                output_features.append(parsed_feat)
            if r.message_producer_parsed.format not in ("json", "ipc_stream"):
                raise ValueError(f"Unrecognized sink format {r.message_producer_parsed.format}")

            sink_config = StreamSinkConfigParsed(
                send_to=r.message_producer_parsed.send_to,
                output_features=output_features,
                feature_expressions={},  # TODO
                format=r.message_producer_parsed.format,
            )

        dedup_policy: DeduplicationPolicyParsed | None = None
        if r.deduplication is not None:
            if not parsed_feature_expressions:
                raise ValueError("Deduplication policy not supported for non-native streaming resolvers")

            def _expr_dtype(u: UnderscoreValue, name: str) -> pa.DataType:
                u_result = u.underscore_result_type
                if not isinstance(u_result, UnderscoreResultScalarType):
                    raise ValueError(
                        f"Stream resolver expression {u.original_underscore} (for feature '{name}') did not produce a scalar output; can't determine output dtype (result was {u_result})"
                    )
                return u_result.scalar_type

            output_schema = {k.root_fqn: _expr_dtype(v, k.root_fqn) for k, v in parsed_feature_expressions.items()}
            dedup_underscore = r.deduplication.on
            dedup_expr = convert_underscore_to_expr(
                u=dedup_underscore, schema=Schema(frozendict.frozendict(output_schema))
            )
            dedup_ttl = parse_chalk_duration(r.deduplication.within)
            dedup_policy = DeduplicationPolicyParsed(
                expr=dedup_expr,
                duration=dedup_ttl,
            )

        return StreamResolverParsed(
            signature_parsed=signature_parsed,
            keys_refs=keys_refs,
            window_index=r.window_index,
            parse_info_parsed=parse_info_parsed,
            function_definition=r.function_definition or "",
            source_line=r.source_line,
            function_captured_globals=r.function_captured_globals or {},
            filename=r.filename,
            fqn=r.fqn,
            module=module_name,
            resource_hint=r.resource_hint,
            resource_group=r.resource_group,
            underscore_definition=None,
            graph=self._graph,
            doc=r.doc,
            source=r.source,
            input_refs=parsed_inputs.inputs,
            synthetic_inputs=parsed_inputs.synthetic_inputs,
            output_refs=output,
            windowed_pseudofeatures_refs=windowed_pseudofeatures_refs,
            mode=mode,
            environment=r.environment,
            tags=r.tags or tuple(),
            machine_type=r.machine_type,
            default_args=[xx and self._convert_error_handler(xx) for xx in r.default_args],
            owner=None,
            timeout=None,
            timestamp=r.timestamp,
            data_sources=(),
            accelerate_python=r.accelerate_python or "auto",
            is_total=False,
            unique_on=FrozenOrderedSet(),
            partitioned_by=FrozenOrderedSet(),
            is_generator=inspect.isgeneratorfunction(r.fn) or inspect.isasyncgenfunction(r.fn),
            updates_materialized_aggregations=r.updates_materialized_aggregations,
            sql_settings=r.sql_settings,
            incremental_settings=None,
            is_externally_defined=False,
            feature_expressions=parsed_feature_expressions,
            output_row_order=None,
            venv=None,
            stream_sink_config=sink_config,
            postprocessing=r.postprocessing,
            skip_online=r.skip_online,
            skip_offline=r.skip_offline,
            use_message_envelope=r.include_message_envelope,
            header_equality_filters=r.message_header_filters,
            deduplication_policy=dedup_policy,
        )

    def _convert_sink_resolver(self, r: SinkResolver) -> SinkResolverParsed:
        if r.output is None:
            output = []
        else:
            output = [
                x for x in self.convert_type(r.output) if isinstance(x, DataFrameType) or not x.underlying.autogenerated
            ]
        if r.static:
            raise ValueError("Sink resolvers cannot be static")
        module = inspect.getmodule(r.fn)
        module_name = module.__name__ if module is not None else None
        return SinkResolverParsed(
            function_definition=r.function_definition or "",
            source_line=r.source_line,
            function_captured_globals=r.function_captured_globals or {},
            filename=r.filename,
            fqn=r.fqn,
            module=module_name,
            is_generator=inspect.isgeneratorfunction(r.fn) or inspect.isasyncgenfunction(r.fn),
            graph=self._graph,
            resource_hint=r.resource_hint,
            owner=r.owner,
            doc=r.doc,
            input_refs=[self.convert_type(i) for i in r.inputs],
            output_refs=output,
            synthetic_inputs=FrozenOrderedSet(),
            environment=r.environment,
            tags=r.tags or tuple(),
            machine_type=r.machine_type,
            buffer_size=r.buffer_size,
            debounce=r.debounce,
            max_delay=r.max_delay,
            upsert=r.upsert,
            default_args=[xx and self._convert_error_handler(xx) for xx in r.default_args],
            timeout=None,
            integration=r.integration,
            input_is_df=r.input_is_df,
            data_sources=r.data_sources or (),
            accelerate_python=r.accelerate_python or "auto",
            is_total=False,
            underscore_definition=None,
            unique_on=FrozenOrderedSet(),
            partitioned_by=FrozenOrderedSet(),
            sql_settings=r.sql_settings,
            incremental_settings=None,
            is_externally_defined=False,
            output_row_order=None,
            venv=None,
            postprocessing=r.postprocessing,
        )

    def _convert_cron_filter(
        self, cron: Optional[Union[CronTab, Duration, Cron]]
    ) -> Optional[CronFilterWithFeatureArgs]:
        if cron is not None and isinstance(cron, Cron) and cron.filter is not None:
            sig = inspect.signature(cron.filter)
            filter_features: list[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
            ] = []
            for parameter in sig.parameters.values():
                f = self.convert_type(parameter.annotation)
                assert is_underlying_feature_time(f) or is_underlying_scalar(f), (
                    "Cron filters must be scalars or feature time features"
                )
                filter_features.append(f)
            return CronFilterWithFeatureArgs(
                filter=cron.filter,
                feature_args=filter_features,
            )
        return None

    def _get_inputs(self, r: Resolver[Any, Any]) -> ParsedInputs:
        declared_inputs = tuple(self.convert_type(i) for i in r.inputs)
        return ParsedInputs(
            inputs=declared_inputs,
            synthetic_inputs=FrozenOrderedSet(),
        )

    @staticmethod
    def _convert_error_handler(e: ResolverArgErrorHandler):
        return ResolverArgErrorHandlerParsed(default_value=e.default_value)

    def _convert_offline_resolver(self, r: OfflineResolver) -> OfflineResolverParsed:
        if r.output is None:
            output = []
        else:
            output = [
                x for x in self.convert_type(r.output) if isinstance(x, DataFrameType) or not x.underlying.autogenerated
            ]
        parsed_inputs = self._get_inputs(r)
        if r.static:
            cls = functools.partial(
                MainProcOfflineResolver,
                fn=r.fn,
                static=True,
                static_operation=RegistryConverter._convert_chalkpy_resolver_to_static_operation(r),
            )
        else:
            cls = OfflineResolverParsed
        module = inspect.getmodule(r.fn)
        module_name = module.__name__ if module is not None else None
        return cls(
            function_definition=r.function_definition or "",
            source_line=r.source_line,
            function_captured_globals=r.function_captured_globals or {},
            filename=r.filename,
            module=module_name,
            fqn=r.fqn,
            doc=r.doc,
            input_refs=parsed_inputs.inputs,
            synthetic_inputs=parsed_inputs.synthetic_inputs,
            output_refs=output,
            resource_hint=r.resource_hint,
            graph=self._graph,
            is_generator=inspect.isgeneratorfunction(r.fn) or inspect.isasyncgenfunction(r.fn),
            environment=r.environment,
            tags=r.tags or tuple(),
            cron=r.cron,
            cron_filter=self._convert_cron_filter(r.cron),
            machine_type=r.machine_type,
            when=self._convert_filter(r.when) if r.when is not None else None,
            default_args=[xx and self._convert_error_handler(xx) for xx in r.default_args],
            owner=r.owner,
            timeout=self.convert_raw_duration(r.timeout),
            underscore_definition=None,
            data_sources=r.data_sources or (),
            accelerate_python=r.accelerate_python or "auto",
            is_total=(r.total if len(parsed_inputs.inputs) == 0 else False),
            unique_on=(
                FrozenOrderedSet(self.convert_type(f).root_fqn for f in r.unique_on)
                if r.unique_on is not None
                else FrozenOrderedSet()
            ),
            partitioned_by=(
                FrozenOrderedSet(self.convert_type(f).root_fqn for f in r.partitioned_by)
                if r.partitioned_by is not None
                else FrozenOrderedSet()
            ),
            sql_settings=r.sql_settings,
            incremental_settings=self._convert_incremental_config(r.incremental_settings),
            is_externally_defined=False,
            output_row_order=r.output_row_order,  # pyright: ignore[reportArgumentType]
            venv=r.venv,
            postprocessing=r.postprocessing,
        )

    def _convert_online_resolver(self, r: OnlineResolver[Any, Any]) -> OnlineResolverParsed:
        if r.output is None:
            output = []
        else:
            output = [
                x for x in self.convert_type(r.output) if isinstance(x, DataFrameType) or not x.underlying.autogenerated
            ]
        parsed_inputs = self._get_inputs(r)
        if r.static:
            cls = functools.partial(
                MainProcOnlineResolver,
                fn=r.fn,
                static=True,
                static_operation=RegistryConverter._convert_chalkpy_resolver_to_static_operation(r),
            )
        else:
            cls = OnlineResolverParsed
        module = inspect.getmodule(r.fn)
        module_name = module.__name__ if module is not None else None
        return cls(
            function_definition=r.function_definition or "",
            source_line=r.source_line,
            function_captured_globals=r.function_captured_globals or {},
            filename=r.filename,
            fqn=r.fqn,
            module=module_name,
            is_generator=inspect.isgeneratorfunction(r.fn) or inspect.isasyncgenfunction(r.fn),
            doc=r.doc,
            input_refs=parsed_inputs.inputs,
            synthetic_inputs=parsed_inputs.synthetic_inputs,
            resource_hint=r.resource_hint,
            output_refs=output,
            graph=self._graph,
            environment=r.environment,
            tags=r.tags or tuple(),
            cron=r.cron,
            cron_filter=self._convert_cron_filter(r.cron),
            machine_type=r.machine_type,
            when=self._convert_filter(r.when) if r.when is not None else None,
            default_args=[xx and self._convert_error_handler(xx) for xx in r.default_args],
            owner=r.owner,
            underscore_definition=None,
            timeout=self.convert_raw_duration(r.timeout),
            data_sources=r.data_sources or (),
            accelerate_python=r.accelerate_python or "auto",
            is_total=r.total if len(parsed_inputs.inputs) == 0 else False,
            unique_on=FrozenOrderedSet(self.convert_type(f).root_fqn for f in r.unique_on)
            if r.unique_on is not None
            else FrozenOrderedSet(),
            partitioned_by=(
                FrozenOrderedSet(self.convert_type(f).root_fqn for f in r.partitioned_by)
                if r.partitioned_by is not None
                else FrozenOrderedSet()
            ),
            sql_settings=r.sql_settings,
            incremental_settings=self._convert_incremental_config(r.incremental_settings),
            is_externally_defined=False,
            output_row_order=r.output_row_order,  # pyright: ignore[reportArgumentType]
            venv=r.venv,
            postprocessing=r.postprocessing,
        )

    @staticmethod
    def _convert_incremental_config(config: Any) -> IncrementalSettings | None:
        """Convert a chalkpy IncrementalConfig to an IncrementalSettings for the runtime graph."""
        if config is None:
            return None
        col = config.incremental_column
        return IncrementalSettings(
            mode=config.mode,
            lookback_period=config.lookback_period,
            incremental_column=str(col) if col is not None else None,
            incremental_timestamp=config.incremental_timestamp,
        )

    @overload
    def convert_type(self, t: TFeatureType) -> TFeatureType: ...

    @overload
    def convert_type(self, t: Type[DataFrame]) -> DataFrameType: ...

    @overload
    def convert_type(
        self, t: Type[Features]
    ) -> Collection[
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | InputFeatureType[
            ScalarFeatureType | HasManyFeatureType | HasOneFeatureType | FeatureTimeFeatureType | WindowedFeatureType
        ]
    ]: ...

    @overload
    def convert_type(self, t: Union[OnlineResolver[Any, Any], OnlineResolverParsed]) -> OnlineResolverParsed: ...

    @overload
    def convert_type(self, t: Union[OfflineResolver[Any, Any], OfflineResolverParsed]) -> OfflineResolverParsed: ...

    @overload
    def convert_type(self, t: Union[StreamResolver[Any, Any], StreamResolverParsed]) -> StreamResolverParsed: ...

    @overload
    def convert_type(self, t: Union[SinkResolver[Any, Any], SinkResolverParsed]) -> SinkResolverParsed: ...

    @overload
    def convert_type(self, t: Resolver[Any, Any]) -> ResolverParsed: ...

    @overload
    def convert_type(self, t: Union[HasOnePathObj, HasOnePathObjParsed], *, is_last: bool) -> HasOnePathObjParsed: ...

    @overload
    def convert_type(
        self, t: Feature | FeatureWrapper
    ) -> (
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | InputFeatureType[
            ScalarFeatureType | HasManyFeatureType | HasOneFeatureType | FeatureTimeFeatureType | WindowedFeatureType
        ]
    ): ...

    def convert_type(self, t: Any, **kwargs: Any) -> Any:
        if isinstance(t, type):
            # If called on a Type[DataFrame] or Type[Features], then it must be
            if issubclass(t, DataFrame):
                cols: list[
                    InputFeatureType[
                        HasManyFeatureType | ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType
                    ]
                    | HasManyFeatureType
                    | ScalarFeatureType
                    | FeatureTimeFeatureType
                    | str
                    | WindowedFeatureType
                ] = []
                if t.__references_feature_set__:
                    cols.append(t.__references_feature_set__.namespace)
                else:
                    for f in t.columns:
                        x = self.convert_type(f)
                        if is_underlying_feature_time(x) or is_underlying_scalar(x) or is_underlying_windowed(x):
                            cols.append(x)
                        elif is_underlying_has_one(x):
                            cols.extend(x.flatten())
                        elif is_underlying_has_many(x):
                            cols.append(x)
                        else:
                            raise ValueError(f"Feature '{x}' is not supported for DataFrame columns.")

                combined_filter = None
                for unparsed_filter in t.filters:
                    parsed_filter = self._convert_filter(unparsed_filter)
                    if combined_filter is None:
                        combined_filter = parsed_filter
                    else:
                        combined_filter &= parsed_filter
                return DataFrameType(
                    optional_column_refs=FrozenOrderedSet(cols),
                    required_column_refs=FrozenOrderedSet(),
                    filter=combined_filter,
                    limit=t.__limit__,
                    _graph=self._graph,
                )
            if issubclass(t, Features):
                return tuple(self.convert_type(f) for f in t.features)

        if isinstance(t, FeatureWrapper):
            t = unwrap_feature(t)

        if isinstance(t, Feature):
            assert t.typ is not None
            with ConversionExceptionContext(obj=t):
                t_without_path = t
                if len(t.path) > 0:
                    if t.underlying is not None and not t.is_has_many:
                        # Must copy the has-many features because the underlying does not reflect any columns or filters
                        t_without_path = t.underlying
                    else:
                        t_without_path = copy.copy(t)
                        t_without_path.path = ()

                if t.is_has_one:
                    ans = self._convert_has_one(t_without_path)

                elif t.is_has_many:
                    ans = self._convert_has_many(t_without_path)

                elif t.is_feature_time:
                    ans = self._convert_feature_time(t_without_path)

                elif t.group_by_windowed is not None:
                    ans = self._convert_group_by_windowed_feature(t_without_path)

                elif t.is_windowed:
                    ans = self._convert_windowed_feature(t_without_path)

                elif t.is_scalar:
                    ans = self._convert_scalar_feature(t_without_path)

                else:
                    raise ValueError(f"Unsupported feature type: {t}")

                if len(t.path) < 1:
                    return ans

                return InputFeatureType(
                    underlying_ref=ans,
                    path=self._convert_path(t),
                    _graph=self._graph,
                )

        if isinstance(t, OnlineResolver):
            with ConversionExceptionContext(obj=t):
                return self._convert_online_resolver(t)

        if isinstance(t, OfflineResolver):
            with ConversionExceptionContext(obj=t):
                return self._convert_offline_resolver(t)

        if isinstance(t, HasOnePathObj):
            with ConversionExceptionContext(obj=t):
                return self._convert_has_one_path_obj(t, is_last=kwargs["is_last"])

        if isinstance(t, StreamResolver):
            with ConversionExceptionContext(obj=t):
                return self._convert_stream_resolver(t)

        if isinstance(t, SinkResolver):
            with ConversionExceptionContext(obj=t):
                return self._convert_sink_resolver(t)

        if isinstance(
            t,
            (
                FeatureType,
                HasOnePathObjParsed,
                DataFrameType,
                ResolverParsed,
            ),
        ):
            return t

        raise TypeError(f"Unexpected type: {t}")

    @staticmethod
    def convert_raw_duration(duration: str | timedelta | None) -> timedelta:
        if duration is None:
            duration = timedelta(0)
        if duration == "infinity":
            duration = INTERNAL_TTL_MAX
        if isinstance(duration, timedelta):
            return min(INTERNAL_TTL_MAX, duration)
        else:
            duration = min(INTERNAL_TTL_MAX, parse_chalk_duration(duration))
        return duration

    def _convert_group_by_windowed_feature(self, f: Feature) -> GroupByFeatureType:
        assert f.group_by_windowed is not None
        assert f.path == (), "Should not be called on input feature types"
        cached_val = self._cache.get(f)
        if cached_val is not None:
            assert isinstance(cached_val, GroupByFeatureType)
            return cached_val

        assert f.join is None, "group by feature type should not have join"
        assert f.typ is not None, "type should be defined"
        gbw = f.group_by_windowed
        assert gbw is not None

        if gbw._window_materialization_parsed is None:  # pyright: ignore[reportPrivateUsage]
            f.group_by_windowed._window_materialization_parsed = (  # pyright: ignore[reportPrivateUsage]
                parse_grouped_window(f=f)
            )
        parsed = gbw._window_materialization_parsed  # pyright: ignore[reportPrivateUsage]
        assert parsed is not None

        # assert isinstance(df, type)
        # assert issubclass(df, DataFrame)
        # converted = self.convert_type(df)
        # assert isinstance(converted, DataFrameType)

        group_by: list[ScalarFeatureType] = []
        for g in parsed.group_by:
            feat = self.convert_type(g)
            if not isinstance(feat, ScalarFeatureType):
                raise ValueError(f"Group-by feature {feat.fqn} is not a scalar feature: {feat}")
            group_by.append(feat)

        aggregation = parse_materialized_aggregation_type_from_name(parsed.aggregation)
        if aggregation is None:
            raise ValueError(
                f"The feature '{f.root_fqn}' uses an unsupported materialized aggregation operation {repr(parsed.aggregation)}"
            )

        aggregate_on = list[ScalarFeatureType | FeatureTimeFeatureType]()
        for feat in parsed.aggregate_on:
            converted = self.convert_type(feat)
            if not isinstance(converted, (ScalarFeatureType, FeatureTimeFeatureType)):
                raise ValueError(
                    f"Window materialization child feature must be a scalar or feature-time feature, got {aggregate_on}"
                )
            aggregate_on.append(converted)
        if len(aggregate_on) == 0:
            if aggregation != MaterializedAggregationType.Count:
                raise ValueError(
                    f"Window materialization child feature must be specified for aggregation {repr(parsed.aggregation)}"
                )
            primary = self._graph.primary_feature_for_namespace(parsed.namespace)
            if primary is None:
                raise ValueError(f"Could not find primary feature for namespace {parsed.namespace}")
            aggregate_on = [primary]

        bucket_feature_type, converted_filters = self._extract_filter_and_bucket_feature(
            unconverted_filters=parsed.filters,
        )
        if bucket_feature_type is None:
            bucket_feature_type = self._graph.ts_feature_for_namespace(parsed.namespace)
            if bucket_feature_type is None:
                raise ValueError(f"No bucket feature found for namespace {parsed.namespace}")

        ret = GroupByFeatureType(
            name=f.name,
            namespace=f.namespace,
            is_externally_defined=False,
            original_python_attribute_name=_get_original_python_attribute_name(f),
            attribute_name=getattr(f, "attribute_name", None),
            window_materialization=MaterializationWindowConfigParsed(
                aggregation=aggregation,
                aggregate_on=expand_legacy_min_max_by_n_aggregate_on(
                    aggregation,
                    tuple(aggregate_on),
                    bucket_feature_type,
                ),
                aggregation_kwargs=FrozenOrderedSet(),
                bucket_duration=timedelta(seconds=parsed.bucket_duration_seconds),
                bucket_start=parsed.bucket_start,
                group_by=tuple(group_by),
                namespace=parsed.namespace,
                pyarrow_dtype=parsed.pyarrow_dtype,
                filters=converted_filters,
                bucket_feature=bucket_feature_type,
                backfill_resolver=parsed.backfill_resolver,
                backfill_lookback_duration=timedelta(seconds=parsed.backfill_lookback_duration_seconds)
                if parsed.backfill_lookback_duration_seconds is not None
                else None,
                backfill_start_time=parsed.backfill_start_time,
                backfill_schedule=parsed.backfill_schedule,
                continuous_resolver=parsed.continuous_resolver,
                continuous_buffer_duration=timedelta(seconds=parsed.continuous_buffer_duration_seconds)
                if parsed.continuous_buffer_duration_seconds is not None
                else None,
                # ...
                # retention=timedelta(seconds=max(window_mat.aggregate_on or [0])),
            ),
            windows=FrozenOrderedSet(gbw.buckets_seconds),
            # autogenerated=f.is_autogenerated,
            # max_staleness=self.convert_raw_duration(f.max_staleness),
            _graph=self._graph,
            # join=self._convert_filter(f.join),
            # df=converted,
        )
        self._cache[f] = ret
        return ret

    @staticmethod
    def _convert_chalkpy_resolver_to_static_operation(
        r: OfflineResolver | OnlineResolver,
    ) -> StaticOperator | ChalkDataFrame:
        """
        Gets the `static_operation` for the specified resolver.
        """

        static_operation = static_resolver_to_operator(
            fqn=r.fqn,
            fn=r.fn,
            inputs=r.inputs,
            output=r.output,
        )
        if isinstance(static_operation, (StaticOperator, DfPlaceholder, LegacyChalkDataFrame)):
            return cast(StaticOperator | ChalkDataFrame, static_operation)

        # Convert from LazyFramePlaceholder into Chalk DataFrame
        return ChalkDataFrame.from_lazyframe_proto(static_operation._to_proto())  # pyright: ignore[reportPrivateUsage]
