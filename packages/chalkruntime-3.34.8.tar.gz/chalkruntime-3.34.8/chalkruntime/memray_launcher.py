import argparse
import os
import runpy

from memray import FileDestination, Tracker


def main():
    parser = argparse.ArgumentParser(description="Launch a Python module with memray profiling")
    parser.add_argument("module", type=str, help='Python module to run (e.g., "mypackage.mymodule")')
    args = parser.parse_args()

    pid = os.getpid()
    memray_output_dir = os.environ.get("CHALK_MEMRAY_DIR_DESTINATION", None)

    if memray_output_dir is not None:
        with Tracker(
            destination=FileDestination(f"{memray_output_dir}/memray.{pid}.bin"),
        ):
            runpy.run_module(args.module, run_name="__main__")
    else:
        memray_output_file = os.environ.get("CHALK_MEMRAY_FILE_DESTINATION", "/tmp/memray.bin")

        with Tracker(
            file_name=memray_output_file,
        ):
            runpy.run_module(args.module, run_name="__main__")


if __name__ == "__main__":
    main()
