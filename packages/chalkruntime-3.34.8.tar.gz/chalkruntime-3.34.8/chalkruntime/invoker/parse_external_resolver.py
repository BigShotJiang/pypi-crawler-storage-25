import ast
import dataclasses
import importlib
import textwrap
from typing import Any, Callable, Dict, Mapping, Optional

from chalk._lsp.error_builder import SQLFileResolverErrorBuilder
from chalk.features.feature_set import FeatureRegistryProtocol
from chalk.features.resolver import (
    FunctionCapturedGlobal,
    FunctionCapturedGlobalBuiltin,
    FunctionCapturedGlobalEnum,
    FunctionCapturedGlobalFeatureClass,
    FunctionCapturedGlobalFunction,
    FunctionCapturedGlobalModule,
    FunctionCapturedGlobalModuleMember,
    FunctionCapturedGlobalProto,
    FunctionCapturedGlobalStruct,
    FunctionCapturedGlobalVariable,
)
from chalk.sql import SQLSourceGroup
from chalk.sql._internal.sql_file_resolver import escape_sql_params
from chalk.sql._internal.sql_settings import SQLResolverSettings
from chalk.sql._internal.sql_source import BaseSQLSource
from chalk.sql.finalized_query import Finalizer
from chalk.utils.collections import get_unique_item

from chalkruntime.graph.resolver import ResolverParsed


def _strip_annotations_from_function_def(tree: ast.FunctionDef):
    for arg in tree.args.posonlyargs:
        arg.annotation = None
    for arg in tree.args.args:
        arg.annotation = None
    for arg in tree.args.kwonlyargs:
        arg.annotation = None
    if (arg := tree.args.vararg) is not None:
        arg.annotation = None
    if (arg := tree.args.kwarg) is not None:
        arg.annotation = None
    tree.returns = None
    # Strip the defaults -- they don't show up in inspect.getclosurevars(f), so we can't capture them properly
    # client-side. Anyway, when invoking the resolver we inject default arguments based on info in the ResolverParsed
    tree.args.defaults = []
    tree.args.kw_defaults = []
    return tree


class _Val:
    """Wraps a value extracted from globals. This way Optional[_Val] can distinguish between a valid None value vs us failing to load the value."""

    def __init__(self, value: Any):
        super().__init__()
        self.value = value


def _extract_captured_global(val: FunctionCapturedGlobal, feature_registry: FeatureRegistryProtocol) -> Optional[_Val]:
    if isinstance(val, FunctionCapturedGlobalFeatureClass):
        if (fs := feature_registry.get_feature_sets().get(val.feature_namespace)) is not None:
            return _Val(fs)
        return None
    elif isinstance(val, FunctionCapturedGlobalBuiltin):
        # By default the function code has access to all builtins, so no need to populate manually
        return None
    elif isinstance(val, FunctionCapturedGlobalStruct):
        if val.module and val.module != "__main__":
            module = importlib.import_module(val.module)
            return _Val(getattr(module, val.name))
        return None
    elif isinstance(val, FunctionCapturedGlobalProto):
        if val.module and val.module != "__main__":
            module = importlib.import_module(val.module)
            return _Val(getattr(module, val.name))
        return None
    elif isinstance(val, FunctionCapturedGlobalEnum):
        if val.module and val.module != "__main__":
            module = importlib.import_module(val.module)
            return _Val(getattr(module, val.name))
        return None
    elif isinstance(val, FunctionCapturedGlobalModule):
        return _Val(importlib.import_module(val.name))
    elif isinstance(val, FunctionCapturedGlobalModuleMember):
        module = importlib.import_module(val.module_name)
        return _Val(getattr(module, val.qualname))
    elif isinstance(val, FunctionCapturedGlobalFunction):
        # If this function is defined in an external module, try to import it
        if val.module is not None and val.module != "__main__":
            module = importlib.import_module(val.module)
            return _Val(getattr(module, val.name))
        # TODO: Try to parse helper functions also defined in the notebook
        return None
    elif isinstance(val, FunctionCapturedGlobalVariable):
        if val.module is not None and val.module != "__main__":
            module = importlib.import_module(val.module)
            return _Val(getattr(module, val.name))
        # TODO potentially raise an error here -- this will most likely cause a NameError later
        return None
    else:
        raise ValueError(f"Unexpected global of type {type(val).__name__}: {val}")


def _build_global_namespace_for_resolver(
    captured_globals: Mapping[str, FunctionCapturedGlobal], feature_registry: FeatureRegistryProtocol
) -> dict[str, Any]:
    """
    Returns an object that can be used as the `globals()` for evaluating a function definition.
    This lets us recreate the closure vars of a customer-defined python function.
    :param captured_globals:
    :param feature_registry:
    :return:
    """
    global_namespace: dict[str, Any] = {}

    # TODO: We may want to choose which builtins we allow.
    # global_namespace["__builtins__"] =  ...

    for global_name, global_value in captured_globals.items():
        val = _extract_captured_global(global_value, feature_registry)
        if val is None:
            continue
        global_namespace[global_name] = val.value

    # Patch our resolver-making decorators w/ no-ops so we just return the function w/o processing it
    def noop_decorator(fn: Callable | None = None, *_: Any, **_kwargs: Any):
        def _wrap(fn: Callable):
            return fn

        return _wrap(fn) if fn else _wrap

    for name in ["online", "offline", "stream", "sink"]:
        global_namespace[name] = noop_decorator

    return global_namespace


def _make_sql_resolver_fn(
    sql_source: BaseSQLSource | SQLSourceGroup, sql_string: str, sql_settings: SQLResolverSettings
) -> Callable:
    incremental_settings: Optional[Dict[str, Any]] = None
    finalizer = sql_settings.finalizer
    if sql_settings.incremental_settings is not None:
        incremental_settings = dataclasses.asdict(sql_settings.incremental_settings)

    error_builder = SQLFileResolverErrorBuilder(uri="<external>", sql_string=sql_string, has_import_errors=False)
    escaped = escape_sql_params(sql_string=sql_string, path="<external>", error_builder=error_builder)
    params_dict = sql_settings.params_to_root_fqn
    escaped_sql_string = escaped.escaped_sql_string

    def fn(
        *input_values: Any,
        database: BaseSQLSource | SQLSourceGroup = sql_source,
        sql_query: str = escaped_sql_string,
        field_dict: Mapping[str, str] = sql_settings.fields_root_fqn,
        args_dict: Mapping[str, str] = params_dict,
        incremental: Optional[Dict[str, Any]] = incremental_settings,
    ):
        arg_dict = {arg: input_value for input_value, arg in zip(input_values, args_dict.keys())}
        func = database.query_string(
            query=sql_query,
            fields=field_dict,
            args=arg_dict,
        )
        if incremental:
            func = func.incremental(**incremental)
        elif finalizer == Finalizer.ONE:
            func = func.one()
        elif finalizer == Finalizer.ONE_OR_NONE:
            func = func.one_or_none()
        elif finalizer == Finalizer.ALL:
            func = func.all()
        return func

    return fn


def _make_py_resolver_fn(r: ResolverParsed, feature_registry: FeatureRegistryProtocol) -> Callable:
    """
    Creates a function by exec()'ing the original function definition of the resolver.
    We also attempt to build the closure of variables referenced by the function (e.g. including polars methods, Features classes, etc.)
    based on the parsed "captured globals" of the resolver.

    :param r:
    :param feature_registry: Used to populate the globals() for eval-ing the function code
    :return:
    """
    global_namespace = _build_global_namespace_for_resolver(r.function_captured_globals, feature_registry)
    local_namespace = {}

    # Attempt to strip annotations from the method signature since they might refer to types we haven't currently loaded
    tree = ast.parse(textwrap.dedent(r.function_definition))
    if len(tree.body) > 0 and isinstance(tree.body[0], ast.FunctionDef):
        tree.body[0] = _strip_annotations_from_function_def(tree.body[0])

    try:
        code = compile(tree, filename="__chalk_overlay_resolver__", mode="exec")
        exec(code, global_namespace, local_namespace)
    except Exception as e:
        # TODO error collecting
        raise RuntimeError(f"Failed to load code for external resolver '{r.fqn}': {e}") from e
    return get_unique_item(local_namespace.values())


def load_external_resolver_code(r: ResolverParsed, feature_registry: FeatureRegistryProtocol) -> Callable:
    """
    Turn an externally-defined, parsed resolver into a python function that the invoker can call. This function runs customer code & could refer to customer-defined python objects/features,
    so it should only run in a process that has customer code available (e.g. the invoker subprocess, or main engine process if using the legacy invoker)
    :param r: Parsed resolver
    :param feature_registry: Feature registry to use
    :return:
    """
    if r.sql_settings is not None:
        if len(r.data_sources) != 1:
            raise ValueError(
                f"Can't parse externally-defined SQL resolver {r.fqn}, it has {len(r.data_sources)} associated SQL sources instead of 1."
            )
        return _make_sql_resolver_fn(
            sql_source=r.data_sources[0], sql_string=r.function_definition, sql_settings=r.sql_settings
        )
    return _make_py_resolver_fn(r, feature_registry)
