from __future__ import annotations

import dataclasses
import json
from datetime import date, datetime
from typing import (
    Any,
    AsyncIterator,
    Protocol,
)

from chalk.queries.query_context import ContextJsonDict
from chalk.utils.log_with_context import (
    get_logger,
)

from chalkruntime.invoker.resolver_input import LocalResolverInputs
from chalkruntime.invoker.resolver_result import BatchResolverResult
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter


def _json_default(value: Any) -> Any:
    if isinstance(value, (frozenset, set)):
        try:
            return sorted(value)
        except TypeError:
            return list(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _drop_none(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _drop_none(v) for k, v in value.items() if v is not None}
    if isinstance(value, list):
        return [_drop_none(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_drop_none(v) for v in value)
    return value


def _optional_int(value: Any) -> int | None:
    return None if value is None else int(value)


class PlanTimeInvokerConfig:
    """InvokerConfig that is known at planning time"""

    environment_id: str
    deployment_id: str
    operation_kind: str
    query_name: str | None
    query_name_version: str | None
    query_tags: frozenset[str]
    branch_id: str | None
    store_plan_stages: bool
    use_pa_for_vectorized_args: bool
    needs_pkey_feature_values_in_inputs: bool
    ensure_distinct_resolver_results: bool
    scope_feature_time_to_namespace: bool
    velox_preferred_output_batch_bytes: int
    enable_indexed_has_many_joins: bool
    skip_batch_filter_partitioning_logic: bool
    # TODO: remove (no longer used)
    eager_join_matching: bool
    oom_slim_hm_by_dates: bool
    oom_slim_hm_by_join_keys: bool
    short_circuit_on_no_hm_rows: bool
    oom_max_num_inputs_per_hm_sample: int
    # should correspond to the planner option value
    allow_planner_postponed_has_many_sampling: bool
    invoker_uses_strict_timeouts: bool

    def __init__(
        self,
        *,
        environment_id: str,
        deployment_id: str,
        operation_kind: str,
        query_name: str | None,
        query_name_version: str | None,
        query_tags: frozenset[str] | set[str] | list[str] | tuple[str, ...],
        branch_id: str | None,
        store_plan_stages: bool,
        use_pa_for_vectorized_args: bool,
        needs_pkey_feature_values_in_inputs: bool,
        ensure_distinct_resolver_results: bool,
        scope_feature_time_to_namespace: bool,
        velox_preferred_output_batch_bytes: int,
        enable_indexed_has_many_joins: bool,
        skip_batch_filter_partitioning_logic: bool,
        eager_join_matching: bool,
        oom_slim_hm_by_dates: bool,
        oom_slim_hm_by_join_keys: bool,
        short_circuit_on_no_hm_rows: bool,
        oom_max_num_inputs_per_hm_sample: int,
        allow_planner_postponed_has_many_sampling: bool,
        invoker_uses_strict_timeouts: bool,
        _freeze: bool = True,
    ):
        super().__init__()
        self._frozen = False
        self.environment_id = environment_id
        self.deployment_id = deployment_id
        self.operation_kind = operation_kind
        self.query_name = query_name
        self.query_name_version = query_name_version
        self.query_tags = frozenset(query_tags)
        self.branch_id = branch_id
        self.store_plan_stages = store_plan_stages
        self.use_pa_for_vectorized_args = use_pa_for_vectorized_args
        self.needs_pkey_feature_values_in_inputs = needs_pkey_feature_values_in_inputs
        self.ensure_distinct_resolver_results = ensure_distinct_resolver_results
        self.scope_feature_time_to_namespace = scope_feature_time_to_namespace
        self.velox_preferred_output_batch_bytes = int(velox_preferred_output_batch_bytes)
        self.enable_indexed_has_many_joins = enable_indexed_has_many_joins
        self.skip_batch_filter_partitioning_logic = skip_batch_filter_partitioning_logic
        self.eager_join_matching = eager_join_matching
        self.oom_slim_hm_by_dates = oom_slim_hm_by_dates
        self.oom_slim_hm_by_join_keys = oom_slim_hm_by_join_keys
        self.short_circuit_on_no_hm_rows = short_circuit_on_no_hm_rows
        self.oom_max_num_inputs_per_hm_sample = int(oom_max_num_inputs_per_hm_sample)
        self.allow_planner_postponed_has_many_sampling = allow_planner_postponed_has_many_sampling
        self.invoker_uses_strict_timeouts = invoker_uses_strict_timeouts
        self._frozen = _freeze

    def __setattr__(self, name: str, value: Any) -> None:
        if getattr(self, "_frozen", False):
            raise TypeError(f"{type(self).__name__} is immutable")
        super().__setattr__(name, value)

    def dict(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        data = {
            "environment_id": self.environment_id,
            "deployment_id": self.deployment_id,
            "operation_kind": self.operation_kind,
            "query_name": self.query_name,
            "query_name_version": self.query_name_version,
            "query_tags": self.query_tags,
            "branch_id": self.branch_id,
            "store_plan_stages": self.store_plan_stages,
            "use_pa_for_vectorized_args": self.use_pa_for_vectorized_args,
            "needs_pkey_feature_values_in_inputs": self.needs_pkey_feature_values_in_inputs,
            "ensure_distinct_resolver_results": self.ensure_distinct_resolver_results,
            "scope_feature_time_to_namespace": self.scope_feature_time_to_namespace,
            "velox_preferred_output_batch_bytes": self.velox_preferred_output_batch_bytes,
            "enable_indexed_has_many_joins": self.enable_indexed_has_many_joins,
            "skip_batch_filter_partitioning_logic": self.skip_batch_filter_partitioning_logic,
            "eager_join_matching": self.eager_join_matching,
            "oom_slim_hm_by_dates": self.oom_slim_hm_by_dates,
            "oom_slim_hm_by_join_keys": self.oom_slim_hm_by_join_keys,
            "short_circuit_on_no_hm_rows": self.short_circuit_on_no_hm_rows,
            "oom_max_num_inputs_per_hm_sample": self.oom_max_num_inputs_per_hm_sample,
            "allow_planner_postponed_has_many_sampling": self.allow_planner_postponed_has_many_sampling,
            "invoker_uses_strict_timeouts": self.invoker_uses_strict_timeouts,
        }
        return _drop_none(data) if exclude_none else data

    def json(self, *, exclude_none: bool = False, **kwargs: Any) -> str:
        kwargs.pop("exclude_unset", None)
        kwargs.pop("exclude_defaults", None)
        kwargs.setdefault("default", _json_default)
        return json.dumps(self.dict(exclude_none=exclude_none), **kwargs)

    def copy(self, *, update: dict[str, Any] | None = None, **_: Any) -> Any:
        data = self.dict()
        if update is not None:
            data.update(update)
        return type(self)(**data)

    def __eq__(self, other: object) -> bool:
        if type(self) is not type(other):
            return False
        other_model: Any = other
        return self.dict() == other_model.dict()

    def __hash__(self) -> int:
        raise TypeError(f"unhashable type: '{type(self).__name__}'")


class InvokerConfig(PlanTimeInvokerConfig):
    operation_id: str
    correlation_id: str | None
    query_context: ContextJsonDict | None

    def __init__(
        self,
        *,
        environment_id: str,
        deployment_id: str,
        operation_kind: str,
        query_name: str | None,
        query_name_version: str | None,
        query_tags: frozenset[str] | set[str] | list[str] | tuple[str, ...],
        branch_id: str | None,
        store_plan_stages: bool,
        use_pa_for_vectorized_args: bool,
        needs_pkey_feature_values_in_inputs: bool,
        ensure_distinct_resolver_results: bool,
        scope_feature_time_to_namespace: bool,
        velox_preferred_output_batch_bytes: int,
        enable_indexed_has_many_joins: bool,
        skip_batch_filter_partitioning_logic: bool,
        eager_join_matching: bool,
        oom_slim_hm_by_dates: bool,
        oom_slim_hm_by_join_keys: bool,
        short_circuit_on_no_hm_rows: bool,
        oom_max_num_inputs_per_hm_sample: int,
        allow_planner_postponed_has_many_sampling: bool,
        invoker_uses_strict_timeouts: bool,
        operation_id: str,
        correlation_id: str | None = None,
        query_context: ContextJsonDict | None = None,
    ):
        super().__init__(
            environment_id=environment_id,
            deployment_id=deployment_id,
            operation_kind=operation_kind,
            query_name=query_name,
            query_name_version=query_name_version,
            query_tags=query_tags,
            branch_id=branch_id,
            store_plan_stages=store_plan_stages,
            use_pa_for_vectorized_args=use_pa_for_vectorized_args,
            needs_pkey_feature_values_in_inputs=needs_pkey_feature_values_in_inputs,
            ensure_distinct_resolver_results=ensure_distinct_resolver_results,
            scope_feature_time_to_namespace=scope_feature_time_to_namespace,
            velox_preferred_output_batch_bytes=velox_preferred_output_batch_bytes,
            enable_indexed_has_many_joins=enable_indexed_has_many_joins,
            skip_batch_filter_partitioning_logic=skip_batch_filter_partitioning_logic,
            eager_join_matching=eager_join_matching,
            oom_slim_hm_by_dates=oom_slim_hm_by_dates,
            oom_slim_hm_by_join_keys=oom_slim_hm_by_join_keys,
            short_circuit_on_no_hm_rows=short_circuit_on_no_hm_rows,
            oom_max_num_inputs_per_hm_sample=oom_max_num_inputs_per_hm_sample,
            allow_planner_postponed_has_many_sampling=allow_planner_postponed_has_many_sampling,
            invoker_uses_strict_timeouts=invoker_uses_strict_timeouts,
            _freeze=False,
        )
        self.operation_id = operation_id
        self.correlation_id = correlation_id
        self.query_context = query_context
        self._frozen = True

    def dict(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        data = {
            "environment_id": self.environment_id,
            "deployment_id": self.deployment_id,
            "operation_kind": self.operation_kind,
            "query_name": self.query_name,
            "query_name_version": self.query_name_version,
            "query_tags": self.query_tags,
            "branch_id": self.branch_id,
            "store_plan_stages": self.store_plan_stages,
            "use_pa_for_vectorized_args": self.use_pa_for_vectorized_args,
            "needs_pkey_feature_values_in_inputs": self.needs_pkey_feature_values_in_inputs,
            "ensure_distinct_resolver_results": self.ensure_distinct_resolver_results,
            "scope_feature_time_to_namespace": self.scope_feature_time_to_namespace,
            "velox_preferred_output_batch_bytes": self.velox_preferred_output_batch_bytes,
            "enable_indexed_has_many_joins": self.enable_indexed_has_many_joins,
            "skip_batch_filter_partitioning_logic": self.skip_batch_filter_partitioning_logic,
            "eager_join_matching": self.eager_join_matching,
            "oom_slim_hm_by_dates": self.oom_slim_hm_by_dates,
            "oom_slim_hm_by_join_keys": self.oom_slim_hm_by_join_keys,
            "short_circuit_on_no_hm_rows": self.short_circuit_on_no_hm_rows,
            "oom_max_num_inputs_per_hm_sample": self.oom_max_num_inputs_per_hm_sample,
            "allow_planner_postponed_has_many_sampling": self.allow_planner_postponed_has_many_sampling,
            "invoker_uses_strict_timeouts": self.invoker_uses_strict_timeouts,
            "operation_id": self.operation_id,
            "correlation_id": self.correlation_id,
            "query_context": self.query_context,
        }
        return _drop_none(data) if exclude_none else data


_logger = get_logger(__name__)


class InvokerContext:
    operator_id: str | None
    dfs_id: int | None
    batch_idx: int
    chunk_idx: int | None
    use_one_to_one_invoker: bool

    def __init__(
        self,
        *,
        operator_id: str | None,
        dfs_id: int | None,
        batch_idx: int,
        chunk_idx: int | None,
        use_one_to_one_invoker: bool,
        driver_id: int | None = None,
    ):
        _ = driver_id
        super().__init__()
        self._frozen = False
        self.operator_id = operator_id
        self.dfs_id = _optional_int(dfs_id)
        self.batch_idx = int(batch_idx)
        self.chunk_idx = _optional_int(chunk_idx)
        self.use_one_to_one_invoker = use_one_to_one_invoker
        self._frozen = True

    def __setattr__(self, name: str, value: Any) -> None:
        if getattr(self, "_frozen", False):
            raise TypeError(f"{type(self).__name__} is immutable")
        super().__setattr__(name, value)

    def dict(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        data = {
            "operator_id": self.operator_id,
            "dfs_id": self.dfs_id,
            "batch_idx": self.batch_idx,
            "chunk_idx": self.chunk_idx,
            "use_one_to_one_invoker": self.use_one_to_one_invoker,
        }
        return _drop_none(data) if exclude_none else data

    def json(self, *, exclude_none: bool = False, **kwargs: Any) -> str:
        kwargs.pop("exclude_unset", None)
        kwargs.pop("exclude_defaults", None)
        kwargs.setdefault("default", _json_default)
        return json.dumps(self.dict(exclude_none=exclude_none), **kwargs)

    def copy(self, *, update: dict[str, Any] | None = None, **_: Any) -> InvokerContext:
        data = self.dict()
        if update is not None:
            data.update(update)
        return type(self)(**data)

    def replace(self, *, chunk_idx: int | None) -> InvokerContext:
        return self.copy(update={"chunk_idx": chunk_idx})

    def __eq__(self, other: object) -> bool:
        if type(self) is not type(other):
            return False
        other_context: Any = other
        return self.dict() == other_context.dict()

    def __hash__(self) -> int:
        raise TypeError(f"unhashable type: '{type(self).__name__}'")


@dataclasses.dataclass
class ResolverRunStats:
    num_skipped_invocations: int = 0
    num_successful_invocations: int = 0
    num_failed_invocations: int = 0
    num_resolver_timeouts: int = 0
    resolver_invocation_secs: float = 0.0

    def __add__(self, other: ResolverRunStats):
        return ResolverRunStats(
            num_skipped_invocations=self.num_skipped_invocations + other.num_skipped_invocations,
            num_successful_invocations=self.num_successful_invocations + other.num_successful_invocations,
            num_failed_invocations=self.num_failed_invocations + other.num_failed_invocations,
            num_resolver_timeouts=self.num_resolver_timeouts + other.num_resolver_timeouts,
            resolver_invocation_secs=self.resolver_invocation_secs + other.resolver_invocation_secs,
        )


class BoundInvokerProtocol(Protocol):
    def __call__(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        invoker_context: InvokerContext,
    ) -> AsyncIterator[BatchResolverResult]: ...
