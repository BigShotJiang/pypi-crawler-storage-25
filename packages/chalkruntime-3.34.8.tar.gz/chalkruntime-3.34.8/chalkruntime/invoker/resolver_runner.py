from __future__ import annotations

import asyncio
import dataclasses
import os
import time
from datetime import datetime
from typing import (
    Any,
    AsyncIterator,
    ContextManager,
    Iterable,
    Protocol,
    Sequence,
)

import polars as pl
import pyarrow as pa
from chalk.client.models import ChalkError, ErrorCode
from chalk.features import Feature
from chalk.sql import FinalizedChalkQuery, RedshiftSourceImpl
from chalk.sql._internal.chalk_query import ChalkQuery
from chalk.sql._internal.query_execution_parameters import QueryExecutionParameters
from chalk.sql._internal.string_chalk_query import StringChalkQuery
from chalk.utils.async_helpers import to_async_iterable
from chalk.utils.collections import FrozenOrderedSet
from chalk.utils.environment_parsing import env_var_bool
from chalk.utils.log_with_context import get_logger
from chalk.utils.threading import (
    ChalkThreadPoolExecutor,
)
from chalk.utils.tracing import safe_trace

from chalkruntime.exc.resolver_errors import (
    ResolverErrors,
)
from chalkruntime.exc.wrapped_resolver_exception import WrappedResolverException
from chalkruntime.graph.resolver import (
    OfflineResolverParsed,
    OnlineResolverParsed,
    ResourceHintType,
)
from chalkruntime.invoker.batch_result_collector import (
    ResolverOutputMetadata,
)
from chalkruntime.invoker.query_execution_parameters import attempt_efficient_execution
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter
from chalkruntime.sql_rewriter.query_rewriter_helper import (
    infer_fields_from_resolver_outputs,
)
from chalkruntime.utils.internal_pl_utils import PolarsPanicErrorCompat  # pyright: ignore
from chalkruntime.utils.posix_file_lock import posix_file_lock

_logger = get_logger(__name__)


@dataclasses.dataclass(frozen=True, slots=True)
class Sample:
    index: int | None
    pkey: int | str | None
    execution_ts: datetime | None
    resolver_args_or_error: tuple[Any, ...] | ChalkError


@dataclasses.dataclass(frozen=True, slots=True)
class ResolverResult:
    data: object
    duration_seconds: float
    output_root_fqns: FrozenOrderedSet[str] | None


@dataclasses.dataclass(frozen=True, slots=True)
class ResolverResultWithSample:
    sample: Sample | None
    resolver_result: ResolverResult


class ResolverRunner(Protocol):
    def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]: ...


def get_resolver_runner(
    resolver: OnlineResolverParsed | OfflineResolverParsed,
    resolver_output_metadata: ResolverOutputMetadata,
    resolver_executor: ChalkThreadPoolExecutor,
    effective_resource_hint: ResourceHintType,
) -> ResolverRunner:
    if resolver_output_metadata.is_async:
        if resolver.is_generator:
            return _AsyncGeneratorResolverRunner(
                resolver=resolver,
                resolver_output_metadata=resolver_output_metadata,
                resolver_executor=resolver_executor,
            )
        else:
            return _AsyncResolverRunner(
                resolver=resolver,
                resolver_output_metadata=resolver_output_metadata,
                resolver_executor=resolver_executor,
            )

    elif effective_resource_hint == "cpu":
        if resolver.is_generator:
            return _MainEventLoopGeneratorResolverRunner(
                resolver=resolver,
                resolver_output_metadata=resolver_output_metadata,
                resolver_executor=resolver_executor,
            )
        else:
            return _MainEventLoopResolverRunner(
                resolver=resolver,
                resolver_output_metadata=resolver_output_metadata,
                resolver_executor=resolver_executor,
            )

    elif resolver.is_generator:
        return _ThreadPoolGeneratorResolverRunner(
            resolver=resolver,
            resolver_output_metadata=resolver_output_metadata,
            resolver_executor=resolver_executor,
        )

    elif resolver_output_metadata.is_one_to_one_resolver:
        return _ThreadPoolOneToOneResolverRunner(
            resolver=resolver,
            resolver_output_metadata=resolver_output_metadata,
            resolver_executor=resolver_executor,
        )

    else:
        return _ThreadPoolResolverRunner(
            resolver=resolver,
            resolver_output_metadata=resolver_output_metadata,
            resolver_executor=resolver_executor,
        )


def _rewrite_query(
    resolver_fqn: str,
    query: FinalizedChalkQuery,
    rewriter: QueryRewriter,
    expected_features: Sequence[Feature[Any, Any]] | None,
) -> FinalizedChalkQuery | ChalkError:
    # because the rewriter may change the schema of result (e.g. dropping unused columns),
    # return[1] tells the schema validator to use a different schema instead
    with safe_trace("rewrite_query"):
        try:
            query = infer_fields_from_resolver_outputs(query, expected_features)
        except ValueError as e:
            return ResolverErrors.bad_sql_query(resolver_fqn=resolver_fqn, exception=e)
        return rewriter(query, resolver_fqn)


def _execute_with_redshift_hack(
    result: FinalizedChalkQuery,
    query_execution_parameters: QueryExecutionParameters,
    expected_features: Sequence[Feature[Any, Any]] | None,
):
    start = time.perf_counter()
    with posix_file_lock("/tmp/redshift.lock"):
        _logger.info(
            f"Acquired lock after {time.perf_counter() - start} seconds. Sleeping before executing redshift query to avoid deadlock"
        )
        time.sleep(float(os.getenv("CHALK_REDSHIFT_DELAY_JITTER", "1")))
        return result.execute_to_pyarrow_batches(
            expected_features=expected_features,
            query_execution_parameters=attempt_efficient_execution(
                source=result.source,
                query_execution_parameters=query_execution_parameters,
            ),
        )


async def async_handle_batch(
    resolver: OnlineResolverParsed | OfflineResolverParsed,
    resolver_output_metadata: ResolverOutputMetadata,
    resolver_executor: ChalkThreadPoolExecutor,
    result: object,
    rewriter: QueryRewriter,
    query_execution_parameters: QueryExecutionParameters,
    duration_seconds: float,
) -> AsyncIterator[ResolverResult]:
    output_fqns = None
    start = time.perf_counter() - duration_seconds
    del duration_seconds  # It must be recalculated based on the adjusted start
    if isinstance(result, ChalkError):
        yield ResolverResult(data=result, duration_seconds=time.perf_counter() - start, output_root_fqns=None)
        return
    if isinstance(result, (ChalkQuery, StringChalkQuery)):
        result = result.all()
    if isinstance(result, FinalizedChalkQuery):
        result = _rewrite_query(resolver.fqn, result, rewriter, resolver_output_metadata.expected_features)
        if isinstance(result, ChalkError):
            yield ResolverResult(data=result, duration_seconds=time.perf_counter() - start, output_root_fqns=None)
            return
        if result.is_empty:
            yield ResolverResult(
                data=pa.Table.from_arrays([], []), duration_seconds=time.perf_counter() - start, output_root_fqns=None
            )
            return
        with safe_trace(
            span_id="execute_resolver_sql",
            attributes={"resolver_fqn": resolver.fqn, "is_async": "1"},
        ):
            _logger.debug("Running SQL query from resolver '%s' using blocking execute to pyarrow", resolver.fqn)
            try:
                # HACK Read CHA-2687 for more details.
                do_redshift_hack = isinstance(result.source, RedshiftSourceImpl) and env_var_bool(
                    "CHALK_REDSHIFT_DELAY"
                )
                if do_redshift_hack:
                    result_blocking_iter = _execute_with_redshift_hack(
                        result=result,
                        query_execution_parameters=query_execution_parameters,
                        expected_features=resolver_output_metadata.expected_features,
                    )
                    result_iter = to_async_iterable(
                        iterable=result_blocking_iter,
                        executor=resolver_executor,
                    )
                else:
                    result_iter = result.async_execute_to_pyarrow_batches(
                        expected_features=resolver_output_metadata.expected_features,
                        query_execution_parameters=attempt_efficient_execution(
                            source=result.source,
                            query_execution_parameters=query_execution_parameters,
                        ),
                    )
                yielded = False
                async for batch in result_iter:
                    if len(batch) == 0:
                        continue
                    if yielded and resolver_output_metadata.is_one_to_one_resolver:
                        raise ValueError(
                            f"One-to-one scalar resolver {resolver.fqn} attempted to yield second batch of data"
                        )
                    output_fqns = FrozenOrderedSet(batch.schema.names)
                    midpoint = time.perf_counter()
                    duration_seconds = midpoint - start
                    start = midpoint
                    yield ResolverResult(data=batch, duration_seconds=duration_seconds, output_root_fqns=output_fqns)
                if not yielded and resolver_output_metadata.is_one_to_one_resolver:
                    # All 1:1 resolvers must yield at least one batch. So, if the SQL returned no rows, then synthesize a null row
                    yield ResolverResult(
                        data={k.root_fqn: None for k in resolver_output_metadata.output_schema},
                        duration_seconds=time.perf_counter() - start,
                        output_root_fqns=None,
                    )
                return

            except Exception as e:
                raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
    if isinstance(result, pl.LazyFrame):
        try:
            result = result.collect()
        except (Exception, PolarsPanicErrorCompat) as e:
            raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
    yield ResolverResult(data=result, duration_seconds=time.perf_counter() - start, output_root_fqns=output_fqns)


def sync_handle_batch(
    resolver: OnlineResolverParsed | OfflineResolverParsed,
    resolver_output_metadata: ResolverOutputMetadata,
    result: object,
    rewriter: QueryRewriter,
    query_execution_parameters: QueryExecutionParameters,
    duration_seconds: float,
) -> Iterable[ResolverResult]:
    start = time.perf_counter() - duration_seconds
    del duration_seconds  # It must be recalculated based on the adjusted start
    if isinstance(result, ChalkError):
        yield ResolverResult(result, duration_seconds=time.perf_counter() - start, output_root_fqns=None)
        return
    if isinstance(result, (ChalkQuery, StringChalkQuery)):
        result = result.all()
    if isinstance(result, FinalizedChalkQuery):
        result = _rewrite_query(resolver.fqn, result, rewriter, resolver_output_metadata.expected_features)
        if isinstance(result, ChalkError):
            yield ResolverResult(result, duration_seconds=time.perf_counter() - start, output_root_fqns=None)
            return
        if result.is_empty:
            yield ResolverResult(pa.Table.from_arrays([], []), time.perf_counter() - start, None)
            return
        with safe_trace(
            span_id="execute_resolver_sql",
            attributes={"resolver_fqn": resolver.fqn, "is_async": "0"},
        ):
            _logger.debug("Running SQL query from resolver '%s' using blocking execute to pyarrow", resolver.fqn)
            try:
                # HACK Read CHA-2687 for more details.
                do_redshift_hack = isinstance(result.source, RedshiftSourceImpl) and env_var_bool(
                    "CHALK_REDSHIFT_DELAY"
                )
                if do_redshift_hack:
                    result_iter = _execute_with_redshift_hack(
                        result=result,
                        query_execution_parameters=query_execution_parameters,
                        expected_features=resolver_output_metadata.expected_features,
                    )
                else:
                    result_iter = result.execute_to_pyarrow_batches(
                        expected_features=resolver_output_metadata.expected_features,
                        query_execution_parameters=attempt_efficient_execution(
                            source=result.source,
                            query_execution_parameters=query_execution_parameters,
                        ),
                    )
                yielded = False

                for res in result_iter:
                    if len(res) == 0:
                        # Skip empty batches.
                        continue
                    if yielded and resolver_output_metadata.is_one_to_one_resolver:
                        raise ValueError(
                            f"One-to-one scalar resolver {resolver.fqn} attempted to yield second batch of data"
                        )
                    output_fqns = FrozenOrderedSet(res.schema.names)

                    # Avoid double-counting time: we'll reset the timer going forward
                    midpoint = time.perf_counter()
                    duration_seconds = midpoint - start
                    start = midpoint

                    yield ResolverResult(
                        data=res,
                        # Include the original `duration_seconds` and also the time spent waiting for this most recent batch.
                        duration_seconds=duration_seconds,
                        output_root_fqns=output_fqns,
                    )
                    # We don't want to double-count the initial `duration_seconds`` across each batch, so set it to zero for
                    # each subsequent batch.
                    duration_seconds = 0
                    yielded = True

                if not yielded and resolver_output_metadata.is_one_to_one_resolver:
                    # All 1:1 resolvers must yield at least one batch. So, if the SQL returned no rows, then synthesize a null row
                    yield ResolverResult(
                        {k.root_fqn: None for k in resolver_output_metadata.output_schema},
                        time.perf_counter() - start,
                        None,
                    )
                return

            except Exception as e:
                raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
    if isinstance(result, pl.LazyFrame):
        try:
            result = result.collect()
        except (Exception, PolarsPanicErrorCompat) as e:
            raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
    yield ResolverResult(data=result, duration_seconds=time.perf_counter() - start, output_root_fqns=None)


class _ThreadPoolResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    def _run_blocking_resolver_in_thread_pool(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> Iterable[ResolverResult]:
        # debug logs have cost, even at info log levels!
        # this path is hot: don't forget to comment back out if you uncomment for testing.
        # _logger.debug("Running blocking resolver '%s' in the thread pool", self._resolver.fqn)
        start = time.perf_counter()
        try:
            if execution_context is None:
                result = self._resolver_output_metadata.fn(*resolver_args)
                duration = time.perf_counter() - start
            else:
                with execution_context:
                    result = self._resolver_output_metadata.fn(*resolver_args)
                    duration = time.perf_counter() - start

        except (Exception, PolarsPanicErrorCompat) as e:
            raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
        yield from sync_handle_batch(
            resolver=self._resolver,
            resolver_output_metadata=self._resolver_output_metadata,
            result=result,
            rewriter=rewriter,
            query_execution_parameters=query_execution_parameters,
            duration_seconds=duration,
        )

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        async for x in to_async_iterable(
            self._run_blocking_resolver_in_thread_pool(
                resolver_args=resolver_args,
                rewriter=rewriter,
                execution_context=execution_context,
                query_execution_parameters=query_execution_parameters,
            ),
            self._resolver_executor,
        ):
            yield x


class _ThreadPoolOneToOneResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    def _run_blocking_one_to_one_resolver_in_thread_pool(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> ResolverResult:
        # debug logs have cost, even at info log levels!
        # this path is hot: don't forget to comment back out if you uncomment for testing.
        # _logger.debug("Running blocking one-to-one resolver '%s' in the thread pool", self._resolver.fqn)
        start = time.perf_counter()
        try:
            if execution_context is None:
                result = self._resolver_output_metadata.fn(*resolver_args)
                duration = time.perf_counter() - start
            else:
                with execution_context:
                    result = self._resolver_output_metadata.fn(*resolver_args)
                    duration = time.perf_counter() - start
        except (Exception, PolarsPanicErrorCompat) as e:
            raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)

        if type(result) is ChalkError:
            return ResolverResult(result, duration, None)

        if type(result) not in (ChalkQuery, StringChalkQuery, FinalizedChalkQuery, pl.LazyFrame):
            # No special handling. Using type(...) check because that is faster than isinstance
            return ResolverResult(result, duration, None)

        for x in sync_handle_batch(
            resolver=self._resolver,
            resolver_output_metadata=self._resolver_output_metadata,
            result=result,
            rewriter=rewriter,
            query_execution_parameters=query_execution_parameters,
            duration_seconds=duration,
        ):
            return x

        return ResolverResult(
            ChalkError.create(
                code=ErrorCode.RESOLVER_FAILED,
                message="Expected at least one result from one-to-one resolver",
            ),
            duration,
            None,
        )

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        loop = asyncio.get_running_loop()
        yield await asyncio.wrap_future(
            loop.run_in_executor(
                self._resolver_executor,
                self._run_blocking_one_to_one_resolver_in_thread_pool,
                resolver_args,
                rewriter,
                execution_context,
                query_execution_parameters,
            ),
            loop=loop,
        )


class _ThreadPoolGeneratorResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    def _run_blocking_generator_resolver_in_thread_pool(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> Iterable[ResolverResult]:
        # debug logs have cost, even at info log levels!
        # this path is hot: don't forget to comment back out if you uncomment for testing.
        # _logger.debug("Running blocking resolver '%s' in the thread pool", self._resolver.fqn)
        resolver_iter = iter(self._resolver_output_metadata.fn(*resolver_args))
        while True:
            start = time.perf_counter()
            try:
                if execution_context is None:
                    result = next(resolver_iter, ...)
                    duration = time.perf_counter() - start
                else:
                    with execution_context:
                        result = next(resolver_iter, ...)
                        duration = time.perf_counter() - start
            except (Exception, PolarsPanicErrorCompat) as e:
                raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
            if result is ...:
                return
            yield from sync_handle_batch(
                resolver=self._resolver,
                resolver_output_metadata=self._resolver_output_metadata,
                result=result,
                rewriter=rewriter,
                query_execution_parameters=query_execution_parameters,
                duration_seconds=duration,
            )

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        async for x in to_async_iterable(
            self._run_blocking_generator_resolver_in_thread_pool(
                resolver_args=resolver_args,
                rewriter=rewriter,
                execution_context=execution_context,
                query_execution_parameters=query_execution_parameters,
            ),
            self._resolver_executor,
        ):
            yield x


class _AsyncResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        start = time.perf_counter()
        try:
            if execution_context is None:
                result = await self._resolver_output_metadata.fn(*resolver_args)
                duration = time.perf_counter() - start
            else:
                with execution_context:
                    result = await self._resolver_output_metadata.fn(*resolver_args)
                    duration = time.perf_counter() - start
        except (Exception, PolarsPanicErrorCompat) as e:
            raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
        async for x in async_handle_batch(
            resolver=self._resolver,
            resolver_output_metadata=self._resolver_output_metadata,
            resolver_executor=self._resolver_executor,
            result=result,
            rewriter=rewriter,
            query_execution_parameters=query_execution_parameters,
            duration_seconds=duration,
        ):
            yield x


class _MainEventLoopGeneratorResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        # debug logs have cost, even at info log levels!
        # this path is hot: don't forget to comment back out if you uncomment for testing.
        # _logger.debug("Running blocking resolver '%s' in the main event loop", self._resolver.fqn)
        resolver_iter = iter(self._resolver_output_metadata.fn(*resolver_args))
        start = time.perf_counter()
        while True:
            try:
                if execution_context is None:
                    result = next(resolver_iter, ...)
                    duration = time.perf_counter() - start
                else:
                    with execution_context:
                        result = next(resolver_iter, ...)
                        duration = time.perf_counter() - start
            except (Exception, PolarsPanicErrorCompat) as e:
                raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)
            if result is ...:
                return
            async for res in async_handle_batch(
                resolver=self._resolver,
                resolver_output_metadata=self._resolver_output_metadata,
                resolver_executor=self._resolver_executor,
                result=result,
                rewriter=rewriter,
                query_execution_parameters=query_execution_parameters,
                duration_seconds=duration,
            ):
                yield res


class _MainEventLoopResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        # debug logs have cost, even at info log levels!
        # this path is hot: don't forget to comment back out if you uncomment for testing.
        # _logger.debug("Running blocking resolver '%s' in the main event loop", self._resolver.fqn)
        start = time.perf_counter()
        try:
            if execution_context is None:
                result = self._resolver_output_metadata.fn(*resolver_args)
                duration = time.perf_counter() - start
            else:
                with execution_context:
                    result = self._resolver_output_metadata.fn(*resolver_args)
                    duration = time.perf_counter() - start
        except (Exception, PolarsPanicErrorCompat) as e:
            raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)

        if type(result) is ChalkError:
            yield ResolverResult(result, duration, output_root_fqns=None)
            return

        if type(result) not in (ChalkQuery, StringChalkQuery, FinalizedChalkQuery, pl.LazyFrame):
            # No special handling. Using type(...) check because that is faster than isinstance
            yield ResolverResult(result, duration, None)
            return

        async for res in async_handle_batch(
            resolver=self._resolver,
            resolver_output_metadata=self._resolver_output_metadata,
            resolver_executor=self._resolver_executor,
            result=result,
            rewriter=rewriter,
            query_execution_parameters=query_execution_parameters,
            duration_seconds=duration,
        ):
            yield res


class _AsyncGeneratorResolverRunner(ResolverRunner):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        resolver_output_metadata: ResolverOutputMetadata,
        resolver_executor: ChalkThreadPoolExecutor,
    ):
        super().__init__()
        self._resolver = resolver
        self._resolver_output_metadata = resolver_output_metadata
        self._resolver_executor = resolver_executor

    async def run_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        # debug logs have cost, even at info log levels!
        # this path is hot: don't forget to comment back out if you uncomment for testing.
        # _logger.debug("Running async resolver '%s'", self._resolver.fqn)
        resolver_iter = self._resolver_output_metadata.fn(*resolver_args)
        start = time.perf_counter()
        while True:
            try:
                if execution_context is None:
                    result = await anext(resolver_iter, ...)
                    duration = time.perf_counter() - start
                else:
                    with execution_context:
                        result = await anext(resolver_iter, ...)
                        duration = time.perf_counter() - start
            except (Exception, PolarsPanicErrorCompat) as e:
                raise WrappedResolverException(original_exception=e, duration_seconds=time.perf_counter() - start)

            if result is ...:
                return

            async for res in async_handle_batch(
                resolver=self._resolver,
                resolver_output_metadata=self._resolver_output_metadata,
                resolver_executor=self._resolver_executor,
                result=result,
                rewriter=rewriter,
                query_execution_parameters=query_execution_parameters,
                duration_seconds=duration,
            ):
                yield res
