from __future__ import annotations

import asyncio
import functools
import os
import time
from datetime import datetime, timedelta, timezone
from typing import (
    Any,
    AsyncIterator,
    Callable,
    ContextManager,
    Iterable,
    Iterator,
    Mapping,
    Sequence,
    TypeAlias,
    cast,
)

import aiotools
import polars as pl
import pyarrow as pa
import pyarrow.compute as pc
from chalk.client.models import ChalkError, ErrorCode
from chalk.features import DataFrame, TPrimitive
from chalk.features.filter import freeze_time
from chalk.sql._internal.query_execution_parameters import QueryExecutionParameters
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.collections import unwrap_optional
from chalk.utils.df_utils import pa_table_to_pl_df, to_pylist
from chalk.utils.log_with_context import (
    get_logger,
)
from chalk.utils.pl_helpers import is_new_polars
from chalk.utils.threading import (
    ChalkThreadPoolExecutor,
)
from chalk.utils.tracing import safe_trace

from chalkruntime.constants import (
    INDEX_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.exc.failed_argument import (
    FailedArgument,
)
from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.exc.wrapped_resolver_exception import WrappedResolverException
from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureTimeFeatureType,
    HasManyFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    all_has_many_subfeatures,
    has_many_subfeatures_to_projection,
    is_general_has_many,
    is_has_many_has_many,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    is_underlying_scalar,
    required_features_to_sample,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.resolver import OfflineResolverParsed, OnlineResolverParsed, ResourceHintType
from chalkruntime.invoker.batch_result_collector import (
    ResolverOutputMetadata,
    ResultCollector,
)
from chalkruntime.invoker.bound_invoker import (
    BoundInvokerProtocol,
    InvokerConfig,
    InvokerContext,
    ResolverRunStats,
)
from chalkruntime.invoker.overlay_features import OverlayFeatureRegistry, overlay_registry_ctx
from chalkruntime.invoker.partition_batch import PartitionedGroups, partition_batch
from chalkruntime.invoker.resolver_args_builder import ResolverArgsBuilder
from chalkruntime.invoker.resolver_input import HasManyFeatureEntry, LocalResolverInputs
from chalkruntime.invoker.resolver_input_upload import ResolverInputUploadClient
from chalkruntime.invoker.resolver_result import BatchResolverResult
from chalkruntime.invoker.resolver_runner import (
    ResolverResult,
    ResolverResultWithSample,
    ResolverRunner,
    Sample,
    get_resolver_runner,
)
from chalkruntime.invoker.vectorized_hasmany_sampler import (
    RESOLVER_INPUT_IDX_COL_NAME,
    NestedHasManySampler,
    PolarsVectorizedHasManySampler,
    PyArrowVectorizedHasManySampler,
    VectorizedHasManySampler,
)
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter

_logger = get_logger(__name__)


ScalarsType: TypeAlias = "Mapping[str, TPrimitive | ellipsis]"
RawGroupsType: TypeAlias = (
    "Mapping[HasManyFeatureType | InputFeatureType[HasManyFeatureType] | DataFrameType, ChalkRecordBatch]"
)

GroupsType: TypeAlias = PartitionedGroups
PaGroupsType: TypeAlias = Mapping[HasManyFeatureType | InputFeatureType[HasManyFeatureType], pa.Table]

PKey: TypeAlias = "int | str"


def _df_constructor(
    execution_ts: datetime,
    groups: GroupsType,
    ans: list[
        Callable[
            [
                datetime,
                GroupsType,
            ],
            DataFrame,
        ]
    ],
    is_now_to_df: bool = False,
) -> Sample:
    dfs = tuple(parse_fn(execution_ts, groups) for parse_fn in ans)
    # For Now -> DataFrame resolvers, prepend the execution_ts as the 'now' argument
    if is_now_to_df:
        resolver_args = (execution_ts,) + dfs
    else:
        resolver_args = dfs
    # Index and pkey really aren't applicable to df-taking resolvers
    return Sample(index=None, pkey=None, execution_ts=execution_ts, resolver_args_or_error=resolver_args)


def _parse_df_feature(
    execution_ts: datetime,
    groups: GroupsType,
    graph: ResolvedGraph,
    short_circuit_on_no_hm_rows: bool,
    enable_indexed_has_many_joins: bool,
    oom_slim_hm_by_join_keys: bool,
    oom_slim_hm_by_dates: bool,
    allow_planner_postponed_has_many_sampling_planner_option: bool,
    df_feature: DataFrameType,
):
    resolver_inputs_df_table = groups.raw_df[df_feature].result_and_metadata
    resolver_inputs_df = pa_table_to_pl_df(resolver_inputs_df_table.to_table())
    for hm_ft in df_feature.columns:
        if not is_underlying_has_many(hm_ft):
            continue
        # use groups.raw instead of groups.partitioned, since we don't partition for DF resolvers.
        hm_table = groups.raw_has_many[hm_ft].result_and_metadata
        _hm_pa = hm_table.to_table()
        hm_df = pa_table_to_pl_df(_hm_pa), None
        sampler = PolarsVectorizedHasManySampler(
            resolver_inputs_df=resolver_inputs_df,
            has_many_feature=hm_ft,
            has_many_df=hm_df,
            graph=graph,
            enable_indexed_has_many_joins=enable_indexed_has_many_joins,
            oom_slim_hm_by_dates=oom_slim_hm_by_dates,
            oom_slim_hm_by_join_keys=oom_slim_hm_by_join_keys,
            allow_planner_postponed_has_many_sampling_planner_option=allow_planner_postponed_has_many_sampling_planner_option,
            include_metadata_columns=False,
        )
        resolver_inputs_df = sampler.join_df_and_pack_into_struct()

    expected_cols: list[pl.Expr] = []
    for x in df_feature.columns:
        if is_underlying_feature_time(x):
            expected_cols.append(pl.col(TS_COL_NAME).alias(x.root_fqn))
        else:
            expected_cols.append(pl.col(x.root_fqn))
    return DataFrame(resolver_inputs_df.select(expected_cols))


# Be able to flag off timeouts
RESPECT_TIMEOUT = os.getenv("CHALK_RESPECT_RESOLVER_TIMEOUT", "1").lower() in {"1", "true", "yes", "t", "y"}


class GeneralBoundInvoker(BoundInvokerProtocol):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        pkey_feature: ScalarFeatureType,
        graph: ResolvedGraph,
        resolver_executor: ChalkThreadPoolExecutor,
        resolver_input_upload_client: ResolverInputUploadClient,
        query_execution_parameters: QueryExecutionParameters,
        fallback_resource_hint: ResourceHintType,
        overlay_feature_registry: OverlayFeatureRegistry | None,
    ):
        super().__init__()
        self._registry = overlay_feature_registry
        with overlay_registry_ctx(self._registry):
            resolver_output_metadata = ResolverOutputMetadata.from_resolver(
                resolver=resolver,
                pkey_feature=pkey_feature,
            )
            self._resolver = resolver
            self._query_execution_parameters = query_execution_parameters
            self._must_use_polars_for_batch_to_sample = self._resolver.input_is_df or any(
                is_has_many_has_many(input_ft) for input_ft in self._resolver.inputs
            )
            self._trace_attributes: Mapping[str, str] = {"resolver": self._resolver.fqn}
            self._timeout_seconds: float | None = (
                None
                if self._resolver.timeout is None or self._resolver.timeout <= timedelta(0)
                else self._resolver.timeout.total_seconds()
            )

            if not RESPECT_TIMEOUT:
                self._timeout_seconds = None

            self._pkey_feature = pkey_feature
            self._graph = graph
            self._resolver_executor = resolver_executor
            self._effective_resource_hint: ResourceHintType = (
                fallback_resource_hint if self._resolver.resource_hint is None else self._resolver.resource_hint
            )
            self._resolver_input_upload_client = resolver_input_upload_client
            self._df_resolver_input_constructor_cached: Callable[[datetime, GroupsType], Sample] | None = None
            self._resolver_output_metadata = resolver_output_metadata
            self.resolver_runner = self._get_resolver_runner()
            self._resolver_arg_builder = ResolverArgsBuilder(graph=self._graph)

    async def _stream_to_result_collector(
        self,
        resolver_iter: AsyncIterator[ResolverResultWithSample],
        resolver_output_metadata: ResolverOutputMetadata,
        result_collector: ResultCollector,
        stats: ResolverRunStats,
    ) -> bool:
        """Collects one spin of the resolver_iter to the result_collector. Returns whether there is more data"""
        dispatch_result = await anext(resolver_iter, ...)
        if dispatch_result is ...:
            return False

        if dispatch_result.sample is None:
            index = None
            pkey = None
            exec_ts = None
        else:
            index = dispatch_result.sample.index
            pkey = dispatch_result.sample.pkey
            exec_ts = dispatch_result.sample.execution_ts

        if isinstance(dispatch_result.resolver_result.data, Exception):
            if isinstance(dispatch_result.resolver_result.data, asyncio.TimeoutError):
                assert self._resolver.timeout is not None
                error = ResolverErrors.resolver_timed_out(
                    resolver_fqn=self._resolver.fqn, timeout=self._resolver.timeout
                )
                result_collector.add_error(index, pkey, exec_ts, error)
                stats.num_resolver_timeouts += 1
                stats.resolver_invocation_secs += self._resolver.timeout.total_seconds()
                return True

            if isinstance(dispatch_result.resolver_result.data, WrappedResolverException):
                error = ResolverErrors.resolver_raised_exception(
                    resolver_fqn=self._resolver.fqn,
                    exception=dispatch_result.resolver_result.data.original_exception,
                )
                result_collector.add_error(
                    index=index,
                    pkey=pkey,
                    execution_timestamp=exec_ts,
                    error=error,
                )
                stats.resolver_invocation_secs += dispatch_result.resolver_result.data.duration_seconds
                stats.num_failed_invocations += 1
                return True

            raise dispatch_result.resolver_result.data

        if isinstance(dispatch_result.resolver_result.data, ChalkError):
            result_collector.add_error(index, pkey, exec_ts, dispatch_result.resolver_result.data)
            stats.num_failed_invocations += 1
            return True

        output_root_fqns = dispatch_result.resolver_result.output_root_fqns
        stats.resolver_invocation_secs += dispatch_result.resolver_result.duration_seconds
        if result_collector.override_output_fqns(output_root_fqns):
            # there's a few mutations here, but it's fine because this should only happen
            # once before anything important is done
            assert output_root_fqns is not None
            resolver_output_metadata = resolver_output_metadata.subset(output_root_fqns)
            result_collector._metadata = resolver_output_metadata  # pyright: ignore[reportPrivateUsage]
        stats.num_successful_invocations += 1
        result_collector.add_result(
            index=index,
            pkey=pkey,
            execution_timestamp=exec_ts,
            result=dispatch_result.resolver_result.data,
        )

        return True

    async def _stream_resolver_results(
        self,
        batch: LocalResolverInputs,
        stats: ResolverRunStats,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        invoker_context: InvokerContext,
    ) -> AsyncIterator[ResolverResultWithSample]:
        """Invoke the resolver and stream results, one result at a time."""
        all_samples: list[Sample] = []

        async def _process_sample(sample: Sample) -> AsyncIterator[ResolverResultWithSample]:
            if isinstance(sample.resolver_args_or_error, ChalkError):
                yield ResolverResultWithSample(
                    sample=sample,
                    resolver_result=ResolverResult(
                        ChalkError.create(
                            code=ErrorCode.PARSE_FAILED,
                            message="Encountered a skipped sample",
                        ),
                        duration_seconds=0,
                        output_root_fqns=None,
                    ),
                )
                stats.num_skipped_invocations += 1
                return
            failed_args = tuple(z for z in sample.resolver_args_or_error if isinstance(z, FailedArgument))
            if len(failed_args) > 0:
                yield ResolverResultWithSample(
                    sample=sample,
                    resolver_result=ResolverResult(
                        ResolverErrors.failed_upstream_arguments(
                            self._resolver.fqn,
                            [z.expected_feature for z in failed_args],
                        ),
                        duration_seconds=0,
                        output_root_fqns=None,
                    ),
                )
                stats.num_skipped_invocations += 1
                return
            if config.store_plan_stages:
                all_samples.append(sample)
            try:
                async for result_batch in self._resolver_dispatch(
                    resolver_args=sample.resolver_args_or_error,
                    rewriter=rewriter,
                    execution_context=(freeze_time(sample.execution_ts) if sample.execution_ts is not None else None),
                    query_execution_parameters=self._query_execution_parameters,
                ):
                    yield ResolverResultWithSample(sample=sample, resolver_result=result_batch)
            except Exception as e:
                yield ResolverResultWithSample(
                    sample=sample, resolver_result=ResolverResult(e, duration_seconds=0, output_root_fqns=None)
                )

        with safe_trace("_bound_invoke_for_resolver__get_sample_stream"):
            sample_stream = self._batch_to_sample_stream(batch, config)
        all_samples: list[Sample] = []
        if (
            self._resolver.output_is_df
            or self._resolver.resource_hint == "cpu"
            or batch.scalarish_features is None
            or len(batch.scalarish_features) < 2
        ):
            # No parallelization if output is a DF; need to manage memory
            # Also not parallelizing if it's a DF resolver (no scalarish features),
            # or there are < 2 rows (because there's just one sample anyway).
            # This is required for online query perf.
            for sample in sample_stream:
                async for out in _process_sample(sample):
                    yield out
        else:
            sem = asyncio.Semaphore(self._resolver_executor._max_workers)

            ans: list[list[ResolverResultWithSample]] = []

            async def _sample_task(j: int, s: Sample):
                async with sem:
                    ans[j] = [a async for a in _process_sample(s)]

            async with aiotools.TaskGroup() as tg:
                for sample in sample_stream:  # This should be ~fast
                    # Outputs are scalars, meaning that memory per sample is bounded
                    i = len(ans)
                    ans.append([])
                    tg.create_task(_sample_task(i, sample))
            for x in ans:
                for y in x:
                    yield y

        if config.store_plan_stages:
            with safe_trace("_resolver_dispatch__store_plan_stages"):
                await self._resolver_input_upload_client.upload_resolver_inputs(
                    samples=all_samples,
                    environment_id=config.environment_id,
                    operation_id=config.operation_id,
                    invoker_context=invoker_context,
                )

    async def __call__(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        invoker_context: InvokerContext,
    ) -> AsyncIterator[BatchResolverResult]:
        ran_at = datetime.now(timezone.utc)
        with safe_trace("batch_invoker__call__"):
            with overlay_registry_ctx(self._registry):
                observed_at_fallback = batch.observed_at_fallback
                assert observed_at_fallback is None or observed_at_fallback.utcoffset() == timedelta(0)

                # Here is where we collect resolver results into batches and yield them upstream
                local_stats = ResolverRunStats()
                total_stats = ResolverRunStats()

                result_collector = ResultCollector(
                    resolver_fqn=self._resolver.fqn,
                    strict_validations=self._resolver.strict_validations,
                    resolver_metadata=self._resolver_output_metadata,
                    observed_at_fallback=observed_at_fallback,
                    check_duplicate_rows=config.ensure_distinct_resolver_results,
                    feature_fqn_to_resolver_fqn={},
                    error_on_ellipsis=True,
                )

                resolver_iter = self._stream_resolver_results(
                    batch=batch,
                    stats=local_stats,
                    rewriter=rewriter,
                    config=config,
                    invoker_context=invoker_context,
                )

                offset = 0
                has_any_error = False

                # This style is a bit unconventional, but the idea is that we want to capture
                # exceptions that could be thrown when we call the resolver iterator
                # stream_to_result_collector returns True if there is more data to process
                while await self._stream_to_result_collector(
                    resolver_iter=resolver_iter,
                    resolver_output_metadata=self._resolver_output_metadata,
                    result_collector=result_collector,
                    stats=local_stats,
                ):
                    if (
                        0 < config.velox_preferred_output_batch_bytes
                        and config.velox_preferred_output_batch_bytes <= result_collector.estimated_size_bytes
                    ):
                        ans = await self._collect_results(
                            result_collector=result_collector,
                            stats=local_stats,
                            operation_id=config.operation_id,
                            batch=batch,
                            offset=offset,
                            ran_at=ran_at,
                            resolver_output_metadata=self._resolver_output_metadata,
                        )
                        has_any_error = has_any_error or len(ans.errors) > 0
                        yield ans
                        offset += result_collector.num_collected_rows
                        result_collector = ResultCollector(
                            resolver_fqn=self._resolver.fqn,
                            strict_validations=self._resolver.strict_validations,
                            resolver_metadata=self._resolver_output_metadata,
                            observed_at_fallback=observed_at_fallback,
                            check_duplicate_rows=config.ensure_distinct_resolver_results,
                            feature_fqn_to_resolver_fqn={},
                            error_on_ellipsis=True,
                        )
                        total_stats += local_stats
                        local_stats = ResolverRunStats()

                ans = await self._collect_results(
                    result_collector=result_collector,
                    operation_id=config.operation_id,
                    stats=local_stats,
                    offset=offset,
                    batch=batch,
                    ran_at=ran_at,
                    resolver_output_metadata=self._resolver_output_metadata,
                )
                has_any_error = has_any_error or len(ans.errors) > 0
                yield ans
                total_stats += local_stats
                del offset, result_collector, resolver_iter, local_stats

    async def _collect_results(
        self,
        result_collector: ResultCollector,
        stats: ResolverRunStats,
        offset: int,
        operation_id: str,
        batch: LocalResolverInputs,
        resolver_output_metadata: ResolverOutputMetadata,
        ran_at: datetime,
    ) -> BatchResolverResult:
        """Collect the results in the results collector into a BatchResolverResult"""
        result_table_or_err = result_collector.collect_results()

        errors = [x.error for x in result_collector.errors]
        if isinstance(result_table_or_err, ChalkError):
            errors.append(result_table_or_err)

        if isinstance(result_table_or_err, ChalkError):
            data_tbl = None
        else:
            if resolver_output_metadata.is_one_to_one_resolver:
                # If it's a 1:1 mapping, then the result collector does not track the pkey, index col name, or ts col name
                # Note that the pkey might already be in this table if the resolver returned its input pkey
                assert batch.scalarish_features is not None
                if len(result_table_or_err) != result_collector.num_collected_rows:
                    raise ValueError(
                        f"The number of collected rows {result_collector.num_collected_rows} did not match the length of the result table {len(result_table_or_err)}"
                    )
                scalarish_features = batch.scalarish_features
                sliced_ts = scalarish_features.column(TS_COL_NAME).slice(offset, result_collector.num_collected_rows)
                if len(sliced_ts) != len(result_table_or_err):
                    raise ValueError(
                        f"Input table of length {len(sliced_ts)} does not have enough rows to support slicing with offset {offset} and num collected rows {result_collector.num_collected_rows}"
                    )
                sliced_index = scalarish_features.column(INDEX_COL_NAME).slice(
                    offset, result_collector.num_collected_rows
                )
                new_cols = {
                    TS_COL_NAME: sliced_ts,
                    INDEX_COL_NAME: sliced_index,
                }

                if not result_table_or_err.contains_column_name(self._pkey_feature.fqn):
                    new_cols[self._pkey_feature.fqn] = scalarish_features.column(self._pkey_feature.fqn).slice(
                        offset, result_collector.num_collected_rows
                    )
                result_table_or_err = result_table_or_err.append_columns(new_cols)

            data = result_table_or_err

            data_tbl = data.to_record_batch()
        return BatchResolverResult(
            data=data_tbl,
            errors=errors,
            num_failed_invocations=stats.num_failed_invocations,
            num_successful_invocations=stats.num_successful_invocations,
            resolver_invocation_secs=stats.resolver_invocation_secs,
            ran_at=ran_at,
            num_resolver_timeouts=stats.num_resolver_timeouts,
            num_skipped_invocations=stats.num_skipped_invocations,
            result_collector_num_rows=result_collector.num_collected_rows,
        )

    def _get_resolver_runner(self) -> ResolverRunner:
        return get_resolver_runner(
            resolver=self._resolver,
            resolver_output_metadata=self._resolver_output_metadata,
            resolver_executor=self._resolver_executor,
            effective_resource_hint=self._effective_resource_hint,
        )

    async def _resolver_dispatch(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> AsyncIterator[ResolverResult]:
        # return[2] is the expected schema, which may change due to the rewriter
        resolver_iter = self.resolver_runner.run_resolver(
            resolver_args=resolver_args,
            rewriter=rewriter,
            execution_context=execution_context,
            query_execution_parameters=query_execution_parameters,
        )

        if self._timeout_seconds is None:
            async for batch in resolver_iter:
                yield batch
            return

        # If we have a timeout, then we will run the resolver iterable in another task, and have that task append to a queue
        # Then, we will read from the queue with timeout.
        # If the queue.get() times out, then we will cancel the underlying resolver task
        # This is to avoid having different anext(...) calls be in different tasks, because that leads to issues
        # with contextvars

        # Because the resolver iter is running in another task, it can theoretically "run in the background"
        # while we yield the batch back upstream. The time budget is decremented only when we are blocked on queue.get(),
        # so any work that is completed before queue.get() is called does not

        q: asyncio.Queue[ResolverResult | Exception | ellipsis] = asyncio.Queue(maxsize=2)

        async def _spin_resolver_task():
            with safe_trace("batch_invoker_collect_timeout_resolver_to_queue", self._trace_attributes):
                try:
                    async for b in resolver_iter:
                        await q.put(b)
                    await q.put(...)
                except Exception as e:
                    await q.put(e)

        # nosemgrep: chalk_ai.no_asyncio_create_task
        spin_resolver_task = asyncio.create_task(_spin_resolver_task())
        try:
            exhausted_time_budget = False
            with safe_trace("batch_invoker_yield_from_timeout_resolver_queue", self._trace_attributes):
                while True:
                    # Tracking the timeout as a budget
                    start_time = time.time()
                    # Always giving 0.001 ms for the queue.get() to run
                    if not q.empty():
                        # Optimization: if the background task already produced an answer, then no need await queue.get() with timeout!
                        # We can simply read from the queue. Saves time b/c tasks are not free
                        # We'll use a minimal amount of time between the calls to start_time and end_time
                        next_batch = q.get_nowait()
                    else:
                        next_batch = await asyncio.wait_for(
                            q.get(),
                            timeout=max(0.001, self._timeout_seconds),
                        )
                    if next_batch is ...:
                        # Even if we exhausted the time budget, do not raise an exception
                        break

                    if exhausted_time_budget:
                        # Possible if we exhausted the time budget without even though wait_for
                        # never fired, due to how we measure time
                        raise asyncio.TimeoutError

                    # Mark that we have no more time left. We'll still call get() once more in
                    # case if the iterator is also finished, but otherwise, we'll error if it
                    # still yields data.
                    exhausted_time_budget = (self._timeout_seconds - (time.time() - start_time)) < 0

                    if isinstance(next_batch, Exception):
                        raise next_batch

                    yield next_batch
        finally:
            spin_resolver_task.cancel()

    def _batch_to_sample_stream(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
    ) -> Iterator[Sample]:
        """Iterate over rows in a batch.

        Yields a tuple of (index, pkey, execution_ts, ChalkError | input args)"""
        must_use_polars = self._must_use_polars_for_batch_to_sample or not config.use_pa_for_vectorized_args
        with safe_trace("_batch_to_sample_stream__make_ft_to_tbl_map"):
            table_feature_to_results = partition_batch(
                batch=batch,
                enable_indexed_has_many_joins=config.enable_indexed_has_many_joins,
                skip_batch_filter_partitioning_logic=config.skip_batch_filter_partitioning_logic,
            )

        # Now -> DataFrame resolvers should take the same path as DataFrame resolvers
        if self._resolver.input_is_df or (self._resolver.is_now_to_df_resolver and batch.scalarish_features is None):
            arg_constructor = self._df_resolver_input_constructor(config)
            assert batch.scalarish_features is None, (
                "There should not be any scalarish features if the resolver is dataframe-taking or Now -> DataFrame"
            )
            assert batch.observed_at_fallback is not None
            # Resolver takes only DFs or nothing. Should be called once.
            yield arg_constructor(batch.observed_at_fallback, table_feature_to_results)
        else:
            assert batch.scalarish_features is not None
            assert self._resolver.cron_filter is None, "Resolvers with filters are not supported"

            yield from self._vectorized_sample_generator(
                resolver_inputs=batch,
                feature_to_data_mapping=table_feature_to_results,
                attempt_pa_only=not must_use_polars,
                config=config,
            )

    def _make_resolver_input_sequences(
        self,
        resolver_inputs: LocalResolverInputs,
        feature_to_data_mapping: GroupsType | None,
        attempt_pa_only: bool,
        config: InvokerConfig,
    ) -> tuple[Sequence[int], Sequence[int | str | None], Sequence[datetime | None], list[Iterable[object]]]:
        # Generate pyarrow and polars representations of resolver_inputs. We prefer to work in pyarrow where possible
        # since it's a bit more robust and correct, but still offer the polars dataframe to the
        # self._produce_resolver_args_(...) methods in case they'd like to use polars to perform the vectorized
        # operations instead
        resolver_inputs_table: ChalkRecordBatch = resolver_inputs.to_metadata_data_reconciled_chalk_table()
        # These are needed to generate the Sample instances later
        pkeys = cast(
            list[PKey],
            (
                to_pylist(resolver_inputs_table[self._pkey_feature.fqn])
                if resolver_inputs_table.contains_column_name(self._pkey_feature.fqn)
                else [None] * len(resolver_inputs_table)
            ),
        )
        resolver_inputs_df: None | pl.DataFrame = None
        if any(
            is_has_many_has_many(resolver_input) or (is_general_has_many(resolver_input) and not attempt_pa_only)
            for resolver_input in self._resolver.inputs
        ):
            with safe_trace("_vectorized_sample_generator__to_polars"):
                attempt_pa_only = False
                resolver_inputs_df = pa_table_to_pl_df(resolver_inputs_table.to_table())

        if config.needs_pkey_feature_values_in_inputs and not resolver_inputs_table.contains_column_name(
            self._pkey_feature.fqn
        ):
            raise ValueError("Couldn't find pkey feature!")

        resolver_argument_iterables: list[Iterable[object]] = []

        # For each feature type that is a part of the resolver's inputs, we generate the concrete python objects which
        # are the values for the resolver. We loop through each feature type input for the resolver. For each of those
        # feature types, we use the appropriate self._produce_resolver_args_(...) method to generate a list of
        # arguments for that feature type (in the original ordering of pkeys / arguments as they appeared in
        # resolver_inputs)
        for resolver_arg, resolver_input_feature_type in zip(self._resolver.default_args, self._resolver.inputs):
            if is_underlying_feature_time(resolver_input_feature_type):
                with safe_trace("_vectorized_sample_generator__add_feature_time_arg"):
                    resolver_argument_iterables.append(
                        self._resolver_arg_builder.produce_resolver_args_feature_time(
                            self._resolver.unique_input_root_ns,
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_table=resolver_inputs_table,
                            scope_feature_time_to_namespace=config.scope_feature_time_to_namespace,
                        )
                    )
            # It's possible for hasmany's underlying to be other feature types, so we check for hasmany case first.
            elif is_general_has_many(resolver_input_feature_type):
                if feature_to_data_mapping is None:
                    raise ValueError("has-many features are not supported if using the fastpath")
                with safe_trace("_vectorized_sample_generator__add_has_many_arg"):
                    resolver_argument_iterables.append(
                        self._produce_resolver_args_nestable_has_many(
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_df=resolver_inputs_df,
                            pkeys_list=pkeys,
                            feature_to_data_mapping=feature_to_data_mapping,
                            config=config,
                            resolver_inputs_table=resolver_inputs_table,
                            use_pa_for_vectorized_args=attempt_pa_only,
                        )
                    )
            elif is_underlying_scalar(resolver_input_feature_type):
                with safe_trace("_vectorized_sample_generator__add_scalar_arg"):
                    resolver_argument_iterables.append(
                        self._resolver_arg_builder.produce_resolver_args_scalar(
                            resolver_arg=resolver_arg,
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_table=resolver_inputs_table,
                        )
                    )
            elif is_underlying_has_one(resolver_input_feature_type):
                with safe_trace("_vectorized_sample_generator__add_has_one_arg"):
                    resolver_argument_iterables.append(
                        self._resolver_arg_builder.produce_resolver_args_has_one(
                            self._resolver.unique_input_root_ns,
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_table=resolver_inputs_table,
                            scope_feature_time_to_namespace=config.scope_feature_time_to_namespace,
                        )
                    )
            else:
                raise TypeError(
                    (
                        f"Unsupported feature type {resolver_input_feature_type} for scalar-taking resolver "
                        f"{self._resolver.fqn}!"
                    )
                )
        return (
            cast(list[int], to_pylist(resolver_inputs_table[INDEX_COL_NAME])),
            pkeys,
            cast(list[datetime | None], to_pylist(resolver_inputs_table[TS_COL_NAME])),
            resolver_argument_iterables,
        )

    def _vectorized_sample_generator(
        self,
        resolver_inputs: LocalResolverInputs,
        feature_to_data_mapping: GroupsType,
        attempt_pa_only: bool,
        config: InvokerConfig,
    ) -> Iterator[Sample]:
        indices, pkeys, tses, resolver_input_sequences = self._make_resolver_input_sequences(
            resolver_inputs, feature_to_data_mapping, attempt_pa_only, config
        )

        if len(resolver_input_sequences) == 0:
            for index, ts, pkey in zip(indices, tses, pkeys, strict=True):
                assert isinstance(index, int) or index is None
                assert isinstance(ts, datetime) or ts is None
                yield Sample(
                    index=index,
                    pkey=pkey,
                    execution_ts=ts,
                    resolver_args_or_error=(),
                )
        else:
            for (index, ts, pkey), resolve_python_args in zip(
                zip(indices, tses, pkeys, strict=True),
                zip(*resolver_input_sequences, strict=True),
                strict=True,
            ):
                assert isinstance(index, int) or index is None
                assert isinstance(ts, datetime) or ts is None
                yield Sample(
                    index=index,
                    pkey=pkey,
                    execution_ts=ts,
                    resolver_args_or_error=resolve_python_args,
                )

    def _get_feature_time_arr_for_resolver(
        self,
        resolver_inputs_table: ChalkRecordBatch,
        ft_feature: FeatureTimeFeatureType | InputFeatureType[FeatureTimeFeatureType],
        scope_feature_time_to_namespace: bool,
    ) -> pa.Array:
        """
        Gets the actual FeatureTimeFeatureType values for each resolver run -- each as an item in a pa.Array that
        orders the values in order corresponding to the original input order specified in resolver_inputs_table.
        :param resolver_inputs_table: the inputs table containing the columns / data necessary to generate the actual
        concrete feature values that the resolver uses.
        :return: a pa.Array that orders the FeatureTimeFeatureType values in order corresponding to the original
        input order.
        """
        assert not self._resolver.input_is_df, "Cannot be used for df-taking resolvers"

        if scope_feature_time_to_namespace:
            feature_time_column_name = ft_feature.root_fqn
        else:
            input_ft_feature = self._graph.ts_feature_for_namespace(self._resolver.unique_input_root_ns)
            assert input_ft_feature is not None
            feature_time_column_name = input_ft_feature.root_fqn

        # Fallback to regular TS_COL_NAME if we can't find the feature time feature in the inputs
        if not resolver_inputs_table.contains_column_name(feature_time_column_name):
            feature_time_column_name = TS_COL_NAME

        # If there are any rows with nulls for the feature time column, just default to the value from TS_COL_NAME
        feature_time_arr: pa.Array = pc.fill_null(
            resolver_inputs_table[feature_time_column_name],
            resolver_inputs_table[TS_COL_NAME],
        )
        return feature_time_arr

    def _produce_resolver_args_nestable_has_many(
        self,
        *,
        feature_type: HasManyFeatureType | InputFeatureType,
        resolver_inputs_df: pl.DataFrame | None,
        pkeys_list: list[PKey],
        feature_to_data_mapping: GroupsType,
        resolver_inputs_table: ChalkRecordBatch | None,
        use_pa_for_vectorized_args: bool,
        config: InvokerConfig,
    ) -> Iterable[DataFrame]:
        if (
            len(resolver_inputs_df)
            if resolver_inputs_df is not None
            else unwrap_optional(resolver_inputs_table).num_rows
        ) == 0:
            # There are no inputs, no need to yield anything
            return []

        # we walk up the has-many join path, iteratively packing the deeper layers into lists of structs
        hm_base_subfeatures = all_has_many_subfeatures(feature_type)
        hm_schema_subfeatures = tuple(x for x in required_features_to_sample(feature_type) if is_underlying_has_many(x))
        assert len(hm_base_subfeatures) > 0, f"Expected at least one has-many subfeature for {feature_type}"
        assert len(hm_base_subfeatures) == len(hm_schema_subfeatures), (
            f"hm_base_subfeatures ({hm_base_subfeatures}) and hm_schema_subfeatures ({hm_schema_subfeatures}) must have the same length"
        )

        current_hm_df: tuple[pl.DataFrame, pl.DataFrame | None] | None = None
        hm_entry: HasManyFeatureEntry | None = None
        if feature_to_data_mapping.partitioned_has_many is not None:
            current_hm_feature = hm_base_subfeatures[-1]
            current_hm_df = feature_to_data_mapping.partitioned_has_many[current_hm_feature]
            for base_hm_feature, next_hm_feature in list(zip(hm_base_subfeatures, hm_schema_subfeatures))[-2::-1]:
                # root the current_hm_feature at the foreign namespace of parent_hm_feature, so that the table corresponding to
                # parent_hm_feature behaves like scalars at the root
                relative_hm_feature = cast(InputFeatureType[HasManyFeatureType], current_hm_feature).relative_to(
                    base_hm_feature
                )
                resolver_inputs_df_for_sampler = feature_to_data_mapping.partitioned_has_many[next_hm_feature][0]
                sampler = PolarsVectorizedHasManySampler(
                    resolver_inputs_df=resolver_inputs_df_for_sampler,
                    has_many_feature=relative_hm_feature,
                    graph=self._graph,
                    has_many_df=current_hm_df,
                    oom_slim_hm_by_dates=config.oom_slim_hm_by_dates,
                    oom_slim_hm_by_join_keys=config.oom_slim_hm_by_join_keys,
                    enable_indexed_has_many_joins=config.enable_indexed_has_many_joins,
                    allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                    include_metadata_columns=False,
                )
                current_hm_df = (sampler.join_df_and_pack_into_struct().drop(RESOLVER_INPUT_IDX_COL_NAME), None)
                # now we want select for only the current_hm_feature column to be in resolver inputs, dropping irrelevant columns
                current_hm_feature = has_many_subfeatures_to_projection(base_hm_feature, [relative_hm_feature])
            # Top-down nested HM: if the outer feature's schema declares nested HM columns
            # that are absent from the current table, retrieve their data from the mapping
            # and use NestedHasManySampler top-down so timestamps flow from outer to inner
            # (required for correct online temporal semantics).
            _nested_hm_schema = [
                col for col in current_hm_feature.underlying.df.columns if isinstance(col, HasManyFeatureType)
            ]
            if _nested_hm_schema:
                _current_table_cols = set(current_hm_df[0].columns)
                _missing_nested = [col for col in _nested_hm_schema if col.root_fqn not in _current_table_cols]
                if not _missing_nested:
                    # For "deeply nested" cases (e.g. triple-nested: University → College → Course → Section):
                    # nested HM cols (e.g. college.courses) are already packed in the table, but their packed
                    # structs lack sub-nested data (e.g. course.sections) because the resolver encoding schema
                    # is scalar-only. However, partitioned_has_many already has a separate courses table WITH
                    # course.sections. Drop these cols so the _missing_nested path below picks them up and uses
                    # NestedHasManySampler with the correctly nested data.
                    # Only drop cols where we can actually retrieve the data (same lookup as the _missing_nested
                    # handler below at lines 945-950), to avoid dropping cols that PolarsVectorizedHasManySampler
                    # still needs when data is unavailable through the nested path.
                    _phm = feature_to_data_mapping.partitioned_has_many or {}

                    def _nested_data_available(col: HasManyFeatureType) -> bool:
                        if col in _phm:
                            return True
                        if col in feature_to_data_mapping.raw_has_many:
                            return True
                        return False

                    _deeply_nested = [
                        col
                        for col in _nested_hm_schema
                        if col.root_fqn in _current_table_cols
                        and any(isinstance(x, HasManyFeatureType) for x in col.underlying.df.columns)
                        and _nested_data_available(col)
                    ]
                    if _deeply_nested:
                        _cols_to_drop = [col.root_fqn for col in _deeply_nested]
                        current_hm_df = (current_hm_df[0].drop(_cols_to_drop), current_hm_df[1])
                        _current_table_cols = set(current_hm_df[0].columns)
                        _missing_nested = [col for col in _nested_hm_schema if col.root_fqn not in _current_table_cols]
                if _missing_nested:
                    resolver_inputs_pl = (
                        resolver_inputs_df
                        if resolver_inputs_df is not None
                        else pa_table_to_pl_df(unwrap_optional(resolver_inputs_table).to_table())
                    )
                    nested_levels: list[
                        tuple[HasManyFeatureType | InputFeatureType[HasManyFeatureType], pl.DataFrame]
                    ] = [(current_hm_feature, current_hm_df[0])]
                    for _nested_hm in _missing_nested:
                        _nested_data_raw: pl.DataFrame | None = None
                        if _nested_hm in feature_to_data_mapping.partitioned_has_many:
                            _nested_data_raw = feature_to_data_mapping.partitioned_has_many[_nested_hm][0]
                        elif _nested_hm in feature_to_data_mapping.raw_has_many:
                            _nested_data_raw = pa_table_to_pl_df(
                                feature_to_data_mapping.raw_has_many[_nested_hm].result_and_metadata.to_table()
                            )
                        if _nested_data_raw is not None:
                            # Sections extracted from packed resolver output (via PushHasManyToResult)
                            # inherit the parent's TS_COL_NAME but lack the foreign feature-time
                            # column required by _get_ungrouped_rows' temporal filter.  Use
                            # TS_COL_NAME as a proxy so timestamps flow correctly top-down.
                            _foreign_ts_fqn = getattr(
                                self._graph.ts_feature_for_namespace(_nested_hm.underlying.foreign_namespace()),
                                "fqn",
                                None,
                            )
                            if (
                                _foreign_ts_fqn is not None
                                and _foreign_ts_fqn not in _nested_data_raw.columns
                                and TS_COL_NAME in _nested_data_raw.columns
                            ):
                                _nested_data_raw = _nested_data_raw.with_columns(
                                    pl.col(TS_COL_NAME).alias(_foreign_ts_fqn)
                                )
                            # Pre-pack any sub-nested HM data (bottom-up) to support triple-nested has-many.
                            # For example, when _nested_hm=college.courses, check if course.sections data
                            # is available and pack it into courses_df before NestedHasManySampler runs.
                            _sub_nested_hm_cols = [
                                col for col in _nested_hm.underlying.df.columns if isinstance(col, HasManyFeatureType)
                            ]
                            for _sub_nested_hm in _sub_nested_hm_cols:
                                _sub_nested_fqn = _sub_nested_hm.root_fqn
                                _sub_data: pl.DataFrame | None = None
                                # Direct key lookup first
                                if (
                                    feature_to_data_mapping.partitioned_has_many
                                    and _sub_nested_hm in feature_to_data_mapping.partitioned_has_many
                                ):
                                    _sub_data = feature_to_data_mapping.partitioned_has_many[_sub_nested_hm][0]
                                elif _sub_nested_hm in feature_to_data_mapping.raw_has_many:
                                    _sub_data = pa_table_to_pl_df(
                                        feature_to_data_mapping.raw_has_many[
                                            _sub_nested_hm
                                        ].result_and_metadata.to_table()
                                    )
                                else:
                                    # Look for an InputFeatureType key whose underlying matches _sub_nested_hm.
                                    # After has_many_join_operator propagates nested HM features, entries like
                                    # university.colleges.courses.sections (InputFeatureType) appear in
                                    # partitioned_has_many with underlying=course.sections (HasManyFeatureType).
                                    for _k, _v in (feature_to_data_mapping.partitioned_has_many or {}).items():
                                        if isinstance(_k, InputFeatureType) and _k.underlying == _sub_nested_hm:
                                            _sub_data = _v[0]
                                            break
                                if _sub_data is not None:
                                    # Add foreign ts alias if needed for the sub-nested data
                                    _sub_foreign_ts_fqn = getattr(
                                        self._graph.ts_feature_for_namespace(
                                            _sub_nested_hm.underlying.foreign_namespace()
                                        ),
                                        "fqn",
                                        None,
                                    )
                                    if (
                                        _sub_foreign_ts_fqn is not None
                                        and _sub_foreign_ts_fqn not in _sub_data.columns
                                        and TS_COL_NAME in _sub_data.columns
                                    ):
                                        _sub_data = _sub_data.with_columns(
                                            pl.col(TS_COL_NAME).alias(_sub_foreign_ts_fqn)
                                        )
                                    # Drop the null sub-nested column from _nested_data_raw to avoid
                                    # column conflict when the sub-sampler adds the packed column.
                                    if _sub_nested_fqn in _nested_data_raw.columns:
                                        _nested_data_raw = _nested_data_raw.drop(_sub_nested_fqn)
                                    # Also drop RESOLVER_INPUT_IDX_COL_NAME so the sub-sampler
                                    # assigns a fresh per-row index for the pack operation.
                                    if RESOLVER_INPUT_IDX_COL_NAME in _nested_data_raw.columns:
                                        _nested_data_raw = _nested_data_raw.drop(RESOLVER_INPUT_IDX_COL_NAME)
                                    _sub_sampler = PolarsVectorizedHasManySampler(
                                        resolver_inputs_df=_nested_data_raw,
                                        has_many_feature=_sub_nested_hm,
                                        has_many_df=(_sub_data, None),
                                        graph=self._graph,
                                        oom_slim_hm_by_dates=False,
                                        oom_slim_hm_by_join_keys=False,
                                        enable_indexed_has_many_joins=False,
                                        allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                                        include_metadata_columns=False,
                                    )
                                    _nested_data_raw = _sub_sampler.join_df_and_pack_into_struct().drop(
                                        RESOLVER_INPUT_IDX_COL_NAME
                                    )
                            nested_levels.append((_nested_hm, _nested_data_raw))
                    if len(nested_levels) > 1:
                        return NestedHasManySampler(
                            resolver_inputs_df=resolver_inputs_pl,
                            levels=nested_levels,
                            graph=self._graph,
                            allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                        ).yield_groups_per_row()
        else:
            current_hm_feature = feature_type
            if len(hm_base_subfeatures) > 1 and all(
                k in feature_to_data_mapping.raw_has_many for k in hm_base_subfeatures
            ):
                # Nested has-many in the raw (online/static) path: separate data tables
                # exist in raw_has_many for each level.  Use NestedHasManySampler to pack
                # them bottom-up (innermost first) before yielding groups per resolver row.
                resolver_inputs_pl = (
                    resolver_inputs_df
                    if resolver_inputs_df is not None
                    else pa_table_to_pl_df(unwrap_optional(resolver_inputs_table).to_table())
                )
                levels: list[tuple[HasManyFeatureType | InputFeatureType[HasManyFeatureType], pl.DataFrame]] = []
                for i, base_hm in enumerate(hm_base_subfeatures):
                    entry = feature_to_data_mapping.raw_has_many[base_hm]
                    data_df = pa_table_to_pl_df(entry.result_and_metadata.to_table())
                    # The outermost feature is used as-is; inner features are expressed
                    # relative to their immediate parent so the join keys resolve correctly.
                    feature_for_level = (
                        base_hm
                        if i == 0
                        else cast(InputFeatureType[HasManyFeatureType], base_hm).relative_to(hm_base_subfeatures[i - 1])
                    )
                    levels.append((feature_for_level, data_df))
                return NestedHasManySampler(
                    resolver_inputs_df=resolver_inputs_pl,
                    levels=levels,
                    graph=self._graph,
                    allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                ).yield_groups_per_row()
            hm_entry = feature_to_data_mapping.raw_has_many[current_hm_feature]

        sampler: VectorizedHasManySampler | None = None
        if use_pa_for_vectorized_args:
            resolver_inputs_pa = (
                resolver_inputs_table.to_table()
                if resolver_inputs_table is not None
                else unwrap_optional(resolver_inputs_df).to_arrow()
            )
            if current_hm_df is not None:
                has_many_table = (
                    current_hm_df[0].to_arrow(),
                    None if current_hm_df[1] is None else current_hm_df[1].to_arrow(),
                )
            else:
                assert hm_entry is not None, "hm_entry should not be None if current_hm_df is None"
                has_many_table = (
                    hm_entry.result_and_metadata.to_table(),
                    None if hm_entry.mapping_table is None else hm_entry.mapping_table.to_table(),
                )
            if PyArrowVectorizedHasManySampler.can_use_pyarrow_sampler(
                resolver_inputs_table=resolver_inputs_pa,
                has_many_feature=current_hm_feature,
                has_many_table=has_many_table,
            ):
                sampler = PyArrowVectorizedHasManySampler(
                    resolver_inputs_table=resolver_inputs_pa,
                    has_many_feature=current_hm_feature,
                    has_many_table=has_many_table,
                    graph=self._graph,
                    allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                )
        if sampler is None:
            if resolver_inputs_df is None:
                assert resolver_inputs_table is not None
                resolver_inputs_df = pa_table_to_pl_df(resolver_inputs_table.to_table())
            if current_hm_df is None:
                assert hm_entry is not None, "hm_entry should not be None if current_hm_df is None"
                current_hm_df = (
                    pa_table_to_pl_df(hm_entry.result_and_metadata.to_table()),
                    None if hm_entry.mapping_table is None else pa_table_to_pl_df(hm_entry.mapping_table.to_table()),
                )
            sampler = PolarsVectorizedHasManySampler(
                resolver_inputs_df=resolver_inputs_df,
                has_many_feature=current_hm_feature,
                graph=self._graph,
                has_many_df=current_hm_df,
                oom_slim_hm_by_dates=config.oom_slim_hm_by_dates,
                oom_slim_hm_by_join_keys=config.oom_slim_hm_by_join_keys,
                enable_indexed_has_many_joins=config.enable_indexed_has_many_joins,
                allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                include_metadata_columns=False,
            )

        # now we want to flatten and unpack all the lists of structs into a single dataframe for a better user experience
        # this may seem a bit roundabout, but since there are many syntax for has-many, we might want to support different formats
        # and list-of-struct is most flexible in that we can record data from all levels without repeating data
        if is_has_many_has_many(feature_type) or not is_underlying_has_many(feature_type):

            def unpack_sample(packed_sample: DataFrame):
                packed_lf = packed_sample.to_polars()
                for current_hm_feature, child_hm_feature in zip(hm_base_subfeatures[:-1], hm_base_subfeatures[1:]):
                    child_relative = cast(InputFeatureType[HasManyFeatureType], child_hm_feature).relative_to(
                        current_hm_feature
                    )
                    col = pl.col(child_relative.root_fqn)
                    lengths_expr = (
                        col.list.len() if is_new_polars else col.arr.lengths()  # pyright: ignore -- backwards compat
                    )
                    packed_lf = (
                        packed_lf.filter(lengths_expr > 0)
                        .select(pl.col(child_relative.root_fqn).flatten())
                        .unnest(child_relative.root_fqn)
                    )
                # If there are any has-one still left in path after the last has-many, we need to change the namespace
                if not is_underlying_has_many(feature_type):
                    assert len(hm_base_subfeatures) > 0, f"Expected at least one has-many subfeature for {feature_type}"
                    packed_lf = packed_lf.select(
                        pl.col(column.root_fqn).alias(column.fqn)
                        for column in hm_base_subfeatures[-1].underlying.df.columns
                    )
                return DataFrame(packed_lf)

            return map(unpack_sample, sampler.yield_groups_per_row())
        elif config.oom_max_num_inputs_per_hm_sample <= 0:
            return sampler.yield_groups_per_row()
        else:
            finals = []
            cur_idx = 0
            while cur_idx < len(pkeys_list):
                end_idx = min(len(pkeys_list), cur_idx + len(pkeys_list) // config.oom_max_num_inputs_per_hm_sample)
                finals.extend(sampler.yield_groups_per_row())
                cur_idx = end_idx
            return finals

    def _df_resolver_input_constructor(
        self,
        config: InvokerConfig,
    ) -> Callable[[datetime, GroupsType], Sample]:
        if self._df_resolver_input_constructor_cached is None:
            ans: list[
                Callable[
                    [
                        datetime,
                        GroupsType,
                    ],
                    DataFrame,
                ]
            ] = []
            # For Now -> DataFrame resolvers, inputs contain ScalarFeatureType(__chalk__.now)
            # which should not be treated as a DataFrame input
            for df_feature in self._resolver.inputs:
                if not isinstance(df_feature, DataFrameType):
                    # Skip ScalarFeatureType inputs (the Now parameter for Now -> DataFrame resolvers)
                    if isinstance(df_feature, ScalarFeatureType) and self._resolver.is_now_to_df_resolver:
                        continue
                    # Unexpected case: non-DataFrame, non-Now input
                    raise TypeError(
                        f"Unexpected input type {type(df_feature).__name__} for feature "
                        + f"{getattr(df_feature, 'fqn', df_feature)} in resolver {self._resolver.fqn}. "
                        + "Expected DataFrameType or Now for Now->DataFrame resolvers."
                    )
                ans.append(
                    functools.partial(
                        _parse_df_feature,
                        df_feature=df_feature,
                        graph=self._graph,
                        short_circuit_on_no_hm_rows=config.short_circuit_on_no_hm_rows,
                        enable_indexed_has_many_joins=config.enable_indexed_has_many_joins,
                        oom_slim_hm_by_join_keys=config.oom_slim_hm_by_join_keys,
                        oom_slim_hm_by_dates=config.oom_slim_hm_by_dates,
                        allow_planner_postponed_has_many_sampling_planner_option=config.allow_planner_postponed_has_many_sampling,
                    )
                )

            constructor = functools.partial(_df_constructor, ans=ans, is_now_to_df=self._resolver.is_now_to_df_resolver)
            self._df_resolver_input_constructor_cached = constructor
        return self._df_resolver_input_constructor_cached
