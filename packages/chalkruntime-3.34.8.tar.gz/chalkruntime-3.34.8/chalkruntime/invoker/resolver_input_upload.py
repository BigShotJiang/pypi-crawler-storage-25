from collections.abc import Sequence
from typing import Protocol

import aiotools
import polars as pl
import pyarrow as pa
from chalk.features import DataFrame
from chalk.utils.df_utils import write_table_to_parquet
from chalk.utils.log_with_context import get_logger
from chalk.utils.storage_client import StorageClient

from chalkruntime.constants import (
    ID_FEATURE_COL_NAME,
    INDEX_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.graph.feature import (
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_scalar,
)
from chalkruntime.graph.resolver import OfflineResolverParsed, OnlineResolverParsed
from chalkruntime.invoker.bound_invoker import InvokerContext
from chalkruntime.invoker.resolver_runner import Sample

USE_STRICT_UPLOAD_CLIENT = False

_logger = get_logger(__name__)


class ResolverInputUploadClient(Protocol):
    @property
    def resolver(self) -> OnlineResolverParsed | OfflineResolverParsed: ...

    async def upload_resolver_inputs(
        self, samples: Sequence[Sample], environment_id: str, operation_id: str, invoker_context: InvokerContext
    ) -> None: ...


class StrictResolverInputUploadClient(ResolverInputUploadClient):
    def __init__(self, resolver: OnlineResolverParsed | OfflineResolverParsed, storage_client: StorageClient):
        super().__init__()
        self._resolver = resolver
        self._storage_client = storage_client

    @property
    def resolver(self) -> OnlineResolverParsed | OfflineResolverParsed:
        return self._resolver

    async def upload_resolver_inputs(
        self, samples: Sequence[Sample], environment_id: str, operation_id: str, invoker_context: InvokerContext
    ) -> None:
        # FIXME: optionally thread through the chunk id, batch id and operator id
        # this code happens just before the resolver is called, so all data is already validated
        if invoker_context.operator_id is not None:
            filename_prefix = f"env_{environment_id}/query_{operation_id}/resolver_inputs/operator_{invoker_context.operator_id}/resolver_{self._resolver.fqn}"
        else:
            filename_prefix = f"env_{environment_id}/query_{operation_id}/resolver_inputs/resolver_{self._resolver.fqn}"
        if invoker_context.chunk_idx is not None:
            chunkname = f"batch_{invoker_context.batch_idx}_chunk_{invoker_context.chunk_idx}"
        else:
            chunkname = "all_chunks"
        data = [[] for _ in range(len(self._resolver.inputs))]
        indices, pkeys, ts = [], [], []
        pkey_type = None
        for sample in samples:
            if pkey_type is None:
                pkey_type = "int" if isinstance(sample.pkey, int) else "str"
            indices.append(sample.index)
            pkeys.append(sample.pkey)
            ts.append(sample.execution_ts)
            for arg_idx, arg in enumerate(sample.resolver_args_or_error):
                data[arg_idx].append(arg)

        scalar_arrays: dict[str, pa.Array | pa.ChunkedArray] = {
            INDEX_COL_NAME: pa.array(indices, type=pa.int64()),
            TS_COL_NAME: pa.array(ts, type=pa.timestamp("ns")),
            # need to use uint64 here b/c technically an int pkey can be uint64 or int64.
            ID_FEATURE_COL_NAME: pa.array(pkeys, type=pa.large_utf8() if pkey_type == "str" else pa.uint64()),
        }
        all_arrays = {}
        df_tables: dict[str, pa.Table] = {}
        for arg_idx, feature in enumerate(self._resolver.inputs):
            # We cannot rely on is_underlying_* functions to determine the input types: it is possible to define
            # a resolver that takes in A.b.c, where A has-many B has a feature c, have it mark it as a scalar feature
            # but be a dataframe during sampling. We instead check the type directly
            if data[arg_idx] and isinstance(data[arg_idx][0], DataFrame):
                feature_name = (
                    feature.root_fqn
                    if is_underlying_has_many(feature)
                    or is_underlying_scalar(feature)
                    or is_underlying_feature_time(feature)
                    else f"feature_{arg_idx}"
                )  # dataframe features don't have an fqn
                assert all(isinstance(x, DataFrame) for x in data[arg_idx])
                # If the first is a dataframe, the rest should be too
                df_tables[feature_name] = pa.concat_tables([x.to_pyarrow() for x in data[arg_idx]])
                # we have a list of chalk dataframes that we need to pack back into a series of list struct
                dfs: list[DataFrame] = data[arg_idx]
                try:
                    # Previously stored Python list of Polars Series, which Polars DataFrame wrapped as list elements.
                    # Now use implode() to wrap each DataFrame's rows into a list within Polars, then convert to
                    # PyArrow. This allows using PyArrow for writing the direct file, avoiding Polars panic with
                    # large_string types in nested structures.
                    packed_arr = (
                        pl.concat([df.to_polars().select(pl.struct(pl.all()).implode().alias("packed")) for df in dfs])
                        .collect()
                        .get_column("packed")
                        .to_arrow()
                    )
                    all_arrays[f"{arg_idx}_packed_df"] = packed_arr
                except Exception as e:
                    _logger.error("Arg list packing failed", exc_info=e)
                    all_arrays[f"{arg_idx}"] = pa.array([None] * len(dfs))
            elif is_underlying_scalar(feature) or is_underlying_feature_time(feature):
                arr = feature.underlying.to_feature().converter.from_rich_to_pyarrow(data[arg_idx])
                scalar_arrays[feature.root_fqn] = arr
                all_arrays[f"{arg_idx}"] = arr

        all_arrays["__pkey__"] = scalar_arrays[ID_FEATURE_COL_NAME]
        all_arrays["__ts__"] = scalar_arrays[TS_COL_NAME]

        async with aiotools.TaskGroup() as tg:
            tg.create_task(
                self._storage_client.async_upload_object(
                    f"{filename_prefix}/scalars/{chunkname}.parquet",
                    content_type="application/x-parquet",
                    data=write_table_to_parquet(pa.Table.from_pydict(scalar_arrays)),
                )
            )
            # direct packed args
            tg.create_task(
                self._storage_client.async_upload_object(
                    f"{filename_prefix}/direct/{chunkname}.parquet",
                    content_type="application/x-parquet",
                    data=write_table_to_parquet(pa.Table.from_pydict(all_arrays)),
                )
            )
            for feature_name, df_table in df_tables.items():
                tg.create_task(
                    self._storage_client.async_upload_object(
                        f"{filename_prefix}/df_{feature_name}/{chunkname}.parquet",
                        content_type="application/x-parquet",
                        data=write_table_to_parquet(df_table),
                    )
                )


class PermissiveResolverInputUploadClient(ResolverInputUploadClient):
    def __init__(self, delegate: ResolverInputUploadClient):
        super().__init__()
        self._delegate = delegate

    @property
    def resolver(self) -> OnlineResolverParsed | OfflineResolverParsed:
        return self._delegate.resolver

    async def upload_resolver_inputs(
        self, samples: Sequence[Sample], environment_id: str, operation_id: str, invoker_context: InvokerContext
    ) -> None:
        try:
            await self._delegate.upload_resolver_inputs(samples, environment_id, operation_id, invoker_context)
        except Exception as e:
            _logger.error(f"Error uploading resolver inputs for resolver {self.resolver.fqn}", exc_info=e)


class NoOpResolverInputUploadClient(ResolverInputUploadClient):
    def __init__(self, resolver: OnlineResolverParsed | OfflineResolverParsed):
        super().__init__()
        self._resolver = resolver

    @property
    def resolver(self) -> OnlineResolverParsed | OfflineResolverParsed:
        return self._resolver

    async def upload_resolver_inputs(
        self, samples: Sequence[Sample], environment_id: str, operation_id: str, invoker_context: InvokerContext
    ) -> None:
        pass


def create_resolver_input_upload_client(
    resolver: OnlineResolverParsed | OfflineResolverParsed, storage_client: StorageClient | None
) -> ResolverInputUploadClient:
    if storage_client is None:
        return NoOpResolverInputUploadClient(resolver=resolver)

    strict_resolver_input_upload_client = StrictResolverInputUploadClient(
        resolver=resolver, storage_client=storage_client
    )

    if USE_STRICT_UPLOAD_CLIENT:
        return strict_resolver_input_upload_client
    else:
        return PermissiveResolverInputUploadClient(delegate=strict_resolver_input_upload_client)
