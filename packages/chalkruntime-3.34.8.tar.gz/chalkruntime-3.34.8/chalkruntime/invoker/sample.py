from __future__ import annotations

import dataclasses
from datetime import datetime
from typing import Any, Collection, Mapping, TypeVar, cast

import polars as pl
from chalk.features import TPrimitive
from chalk.features.dataframe._filters import PolarsFilterConverter
from chalk.utils.collections import FrozenOrderedSet, get_unique_item
from chalk.utils.log_with_context import get_logger

from chalkruntime.constants import (
    INDEX_COL_NAME,
    OBSERVED_AT_FEATURE_COL_NAME,
    REPLACED_OBSERVED_AT_FEATURE_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureTimeFeatureType,
    FilterParsed,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    WindowedFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    is_underlying_scalar,
    rewrite_local_join_features_with_input_path,
)
from chalkruntime.graph.filter_conversion import FilterParsedConverter
from chalkruntime.graph.graph import ResolvedGraph

_logger = get_logger(__name__)
_T = TypeVar("_T")


@dataclasses.dataclass(frozen=True)
class Sample:
    pkey: str | int | None
    """The root primary key for the sample"""

    values: Mapping[
        FeatureTimeFeatureType
        | ScalarFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | HasOneFeatureType
        | DataFrameType
        | InputFeatureType[
            FeatureTimeFeatureType | ScalarFeatureType | HasManyFeatureType | HasOneFeatureType | WindowedFeatureType
        ],
        TPrimitive | pl.DataFrame | ellipsis,
    ]
    """Mapping of feature type to the primitive feature values.
    Has-one features are decoded to a Features set instance, and
    has-many features are decoded into a DataFrame.
    The ellipsis literal is used to denote missing feature values"""

    observed_at: datetime | None
    """The observed at timestamp for the sample"""

    execution_timestamp: datetime | None
    """The execution timestamp for the sample"""

    index: int | None
    """The index of the sample in the batch"""


def construct_sample(
    graph: ResolvedGraph,
    feature_values: Mapping[str, TPrimitive | pl.DataFrame],
    features: Collection[
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | InputFeatureType[
            ScalarFeatureType | HasManyFeatureType | HasOneFeatureType | FeatureTimeFeatureType | WindowedFeatureType
        ]
    ],
    pkey_fallback: int | str | None,
    observed_at_fallback: datetime | None,
    has_many_feature_to_results: Mapping[HasManyFeatureType | InputFeatureType[HasManyFeatureType], pl.DataFrame],
    use_ts_col_as_observed_at: bool,
) -> Sample:
    """Reconstruct feature values (recursively) from a key/val dict of encoded feature components.

    Args:
        graph: The resolved graph
        feature_values: A mapping of the foreign namespace and feature fqn (as returned by the query functions) to the
            json-stringified feature value.
        features: The collection of features to construct from the ``feature_values``
        pkey_fallback: The implicit primary key to use, if not included in the resulting ``feature_values``
        observed_at_fallback: The implicit timestamp to use, if not included in the ``feature_values``
        has_many_feature_to_results: Mapping of has-many feature to a dataframe containing all features for
            that has-many relationship. This dataframe will be filtered down to the records that match the join,
            given the `feature_values`
    Returns:
       An ``Sample``, if it was possible to construct all ``required_features``
    """
    # Converting the column names back into root fqns
    pkey_feature = graph.primary_feature_for_namespace(get_unique_item(x.root_namespace for x in features))
    assert pkey_feature is not None
    root_observed_at_feature = graph.ts_feature_for_namespace(pkey_feature.root_namespace)
    assert root_observed_at_feature is not None
    if (
        root_observed_at_feature.root_fqn not in feature_values
        and (oat_val := feature_values.get(OBSERVED_AT_FEATURE_COL_NAME)) is not None
    ):
        feature_values = dict(feature_values)  # shallow copy
        feature_values[root_observed_at_feature.root_fqn] = oat_val
    features = set(features)
    for k in feature_values:
        # Pass through all scalar features
        f = graph.feature_from_fqn(k)
        if f is not None and is_underlying_scalar(f):
            features.add(f)
    features.add(pkey_feature)
    features.add(root_observed_at_feature)
    # Flattening the has-one features, so it's possible to construct the has-ones from the individual components
    # The sample does not include has-ones -- they are unflattened immediately before calling the resolver
    features = {y for x in features for y in (x.flatten() if is_underlying_has_one(x) else [x])}
    # Also include the local has-many join features
    features |= {
        y
        for x in features
        if is_underlying_has_many(x)
        for y in rewrite_local_join_features_with_input_path(x).all_referenced_features()
        if y.root_namespace == pkey_feature.root_namespace
    }
    # Sorting from longest namespace to shortest to ensure that the innermost features are constructed first.
    features = sorted(features, key=lambda f: f.root_prefix, reverse=True)
    root_prefix_to_ts: dict[str, datetime] = {}
    ret: dict[
        FeatureTimeFeatureType
        | ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | DataFrameType
        | InputFeatureType[
            FeatureTimeFeatureType | ScalarFeatureType | HasManyFeatureType | WindowedFeatureType | HasOneFeatureType
        ],
        TPrimitive | pl.DataFrame | ellipsis,
    ] = {}
    for f in features:
        if is_underlying_feature_time(f) or is_underlying_scalar(f):
            ret[f] = _construct_scalar_feature(
                f,
                feature_values=feature_values,
                root_prefix_to_ts=root_prefix_to_ts,
                root_prefix=f.root_prefix,
            )

    for f in features:
        # After all scalarish features are constructed, construct the has-many features
        # (we need all the join keys to be populated first)
        # The timestamp for the has-many features is the spine TS -- this affects what rows in the relationship are sampled
        if is_underlying_has_many(f):
            spine_ts = feature_values.get(
                TS_COL_NAME, feature_values.get(str(root_observed_at_feature), observed_at_fallback)
            )
            assert isinstance(spine_ts, datetime), "To have a has-many feature, the spine TS must not be None"
            # This spine ts will be used for the root observed at
            root_prefix_split = f.root_prefix.split(".")
            for i in range(1, len(root_prefix_split) + 1):
                path_joined = ".".join(root_prefix_split[:i])
                root_prefix_to_ts[path_joined] = spine_ts
            ret[f] = _construct_has_many_feature(
                ts=spine_ts,
                root_values=ret,
                hm_feature=f,
                hm_df=has_many_feature_to_results[f],
                graph=graph,
            )
    # For each namespace, set the ts
    root_prefixes = [x.root_prefix for x in ret.keys() if not isinstance(x, DataFrameType)]
    root_observed_at = None
    for root_prefix in root_prefixes:
        ts = root_prefix_to_ts.get(root_prefix)
        if "." in root_prefix:
            if ts is not None:
                has_one_feature = graph.feature_from_fqn(root_prefix)
                assert has_one_feature is not None
                assert is_underlying_has_one(has_one_feature)
                foreign_namespace = has_one_feature.underlying.foreign_namespace()
                observed_at_feature = graph.ts_feature_for_namespace(foreign_namespace)
                assert observed_at_feature is not None
                observed_at_fqn = f"{root_prefix}.{observed_at_feature.name}"
                rooted_observed_at_feature = graph.feature_from_fqn(observed_at_fqn)
                assert rooted_observed_at_feature is not None
                assert is_underlying_feature_time(rooted_observed_at_feature)
                ret[rooted_observed_at_feature] = ts
        else:
            ts = root_prefix_to_ts.get(root_prefix)
            if ts is not None:
                ret[root_observed_at_feature] = ts
                root_observed_at = ts
            elif use_ts_col_as_observed_at and isinstance((ts_val := feature_values.get(TS_COL_NAME)), datetime):
                ret[root_observed_at_feature] = ts_val
                root_prefix_to_ts[root_prefix] = ts_val
                root_observed_at = ts_val
            elif isinstance((ts_val := feature_values.get(str(root_observed_at_feature))), datetime):
                ret[root_observed_at_feature] = ts_val
                root_prefix_to_ts[root_prefix] = ts_val
                root_observed_at = ts_val
            elif isinstance((ts_val := feature_values.get(OBSERVED_AT_FEATURE_COL_NAME)), datetime):
                ret[root_observed_at_feature] = ts_val
                root_prefix_to_ts[root_prefix] = ts_val
                root_observed_at = ts_val
            elif observed_at_fallback is not None:
                ret[root_observed_at_feature] = observed_at_fallback
                root_prefix_to_ts[root_prefix] = observed_at_fallback
                root_observed_at = observed_at_fallback
    if pkey_feature in ret:
        pkey = ret[pkey_feature]
    else:
        pkey = pkey_fallback
    if pkey is ...:
        pkey = None
    assert isinstance(pkey, (int, str)) or pkey is None, f"Unexpected pkey type: {type(pkey)}"
    execution_ts = feature_values.get(TS_COL_NAME)

    ans = Sample(
        pkey=pkey,
        values=ret,
        observed_at=root_observed_at,
        execution_timestamp=cast(datetime | None, execution_ts),
        index=cast(int | None, feature_values.get(INDEX_COL_NAME)),
    )
    return ans


def _construct_scalar_feature(
    feature: ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType],
    root_prefix: str,
    feature_values: Mapping[str, TPrimitive | pl.DataFrame],
    root_prefix_to_ts: dict[str, datetime],
) -> TPrimitive | pl.DataFrame | ellipsis:
    """Reconstruct a feature value (recursively) from a key/val dict of encoded feature components.

    Args:
        feature: The feature type to reconstruct. The type of this argument determines how features are decoded:

        * `ScalarFeatureType` or :class:`FeatureTimeFeatureType` will be decoded according to the fqn.
        * `InputFeatureType` will be decoded to according to the underlying fqn.

        feature_values: A mapping of the foreign namespace and feature fqn (as returned by the query functions) to the encoded feature value.
            This dictionary also contains `entries ending in ``.__observed_at__`` and ``.__replaced_observed_at__`` denoting
            when this feature value was valid.
        root_prefix_to_ts: A mapping of the root prefix to the (max) timestamp for that root prefix.

    Returns:
        The value for the feature, or "..." if the value is missing
    """
    assert feature.name is not None
    root_fqn = f"{root_prefix}.{feature.name}"

    # The observed_at ts is the max of all observed at's in this namespace ore below
    observed_at_val = None
    if isinstance(feature, FeatureTimeFeatureType):
        if isinstance(ts_val := feature_values.get(root_fqn), datetime):
            observed_at_val = ts_val
    if observed_at_val is not None:
        _update_observed_at(root_prefix, observed_at_val, root_prefix_to_ts)
    if isinstance(feature, FeatureTimeFeatureType):
        if observed_at_val is None:
            return None
        else:
            return observed_at_val
    if isinstance(feature, ScalarFeatureType):
        if feature.primary:
            # Primary features must have a value but not an observed at
            if feature_values.get(root_fqn) is None:
                return None
            else:
                val = feature_values[root_fqn]
                assert not isinstance(val, pl.DataFrame)
                return val
        else:
            # Non-primary features might have a null value but must have an observed at
            if root_fqn not in feature_values:
                return ...
            else:
                val = feature_values[root_fqn]
                if not feature.underlying.is_feature_nullable and val is None:
                    # FIXME: offline storage does not distinguish between null and missing
                    # So, we will assume None is invalid if the feature is non-nulllable; otherwise,
                    # we will assume null is valid
                    val = ...
                assert not isinstance(val, pl.DataFrame)
                return val
    if isinstance(feature, InputFeatureType):  # pyright: ignore[reportUnnecessaryIsInstance]
        # TODO(ravi): The assert statement below will not be true with has-many migrations
        assert root_fqn == feature.root_fqn, "input feature types should be top-level"
        return _construct_scalar_feature(
            feature=feature.underlying,
            feature_values=feature_values,
            root_prefix_to_ts=root_prefix_to_ts,
            root_prefix=root_prefix,
        )
    raise TypeError(f"Unexpected feature type {type(feature)} for query input.")


def _update_observed_at(
    root_prefix: str,
    ts: datetime,
    root_prefix_to_ts: dict[str, datetime],
):
    """Update the ts in ``root_prefix_to_ts``
    Update the parent's root_prefix_to_ts, so it will propagate up to parent relationships
    Since we construct features from the innermost to the outermost (sorted by root prefix)
    This will ensure that the greatest ts of (self, *children) will be reflected for all namespaces
    """
    parent_prefix = ".".join(root_prefix.split(".")[:-1])
    if parent_prefix:
        root_prefix_to_ts[parent_prefix] = max(root_prefix_to_ts.get(parent_prefix, ts), ts)
        # Recurse to propagate the timestamp all the way up
        _update_observed_at(parent_prefix, ts, root_prefix_to_ts)
    # Also update the feature's root prefix, too, since its timestamp could be greater than that of all children
    root_prefix_to_ts[root_prefix] = max(root_prefix_to_ts.get(root_prefix, ts), ts)


def resolve_root_filter_values(x: _T, root_sample: Mapping[str, Any], root_ns: str) -> _T:
    """Resolve all root values in filters across joins by substituting with literal values from ``root_sample``

    If a filter joins columns across dataframes, substitute any features with root namespace matching ``root_ns`` to
    be the literal value in ``root_sample``.
    This function recurses through nested filters (e.g. AND, OR)

    Args:
        x: The filter (or when recursing, feature type)
        root_sample: A dictionary mapping a root fqn to the filter value for the root namespace
        root_ns: The root namespace for the filter

    Returns:
        The same type as ``x``, with all root values substituted with the literal value in ``root_sample``
    """
    if isinstance(x, InputFeatureType):
        if x.underlying.root_namespace == root_ns:
            return root_sample[x.underlying.root_fqn]
        return x.underlying
    if isinstance(
        x, (ScalarFeatureType, FeatureTimeFeatureType, HasManyFeatureType, WindowedFeatureType, HasOneFeatureType)
    ):
        if x.root_namespace == root_ns:
            return root_sample[x.root_fqn]
        return x
    if isinstance(x, FilterParsed):
        # Recurse on each side, as filters could be joined with and/or
        return type(x)(
            resolve_root_filter_values(x.lhs, root_sample, root_ns),
            x.operation,
            resolve_root_filter_values(x.rhs, root_sample, root_ns),
        )
    return x


def _construct_has_many_feature(
    ts: datetime,
    root_values: Mapping[
        FeatureTimeFeatureType
        | ScalarFeatureType
        | HasManyFeatureType
        | DataFrameType
        | WindowedFeatureType
        | HasOneFeatureType
        | InputFeatureType[
            FeatureTimeFeatureType | HasOneFeatureType | ScalarFeatureType | HasManyFeatureType | WindowedFeatureType
        ],
        TPrimitive | pl.DataFrame | ellipsis,
    ],
    hm_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
    hm_df: pl.DataFrame,
    *,
    graph: ResolvedGraph,
) -> pl.DataFrame:
    df_join_filter = rewrite_local_join_features_with_input_path(hm_feature)
    # Each filter could be internal (in the dataframe) or a join across dataframe filters
    # If it is internal (root fqns are the same), then apply the filters
    # If it is a join (root fqns differ), resolve the root (non-df-local) feature to its literal value (which we can look up in the "sample" dict)
    # and then resolve it as if it is a local filter
    df_join_substituted = resolve_root_filter_values(
        df_join_filter,
        {k.root_fqn: v for (k, v) in root_values.items() if not isinstance(k, DataFrameType)},
        hm_feature.root_namespace,
    )

    # unparsed_filter = df_join_substituted.to_filter()

    # Filter to the rows matching the correct timestamp
    # AT most one row per pkey will match this expression
    ts_consistency_expr = (
        (pl.col(OBSERVED_AT_FEATURE_COL_NAME) <= ts) | pl.col(OBSERVED_AT_FEATURE_COL_NAME).is_null()
    ) & ((ts < pl.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME)) | pl.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME).is_null())

    # Apply the filters
    ts_feature_parsed = graph.ts_feature_for_namespace(hm_feature.underlying.foreign_namespace())
    for x in FrozenOrderedSet((*df_join_substituted.all_referenced_features(), *hm_feature.underlying.df.columns)):
        if str(x) not in hm_df and is_underlying_feature_time(x):
            # Batch query does not return nested feature time features
            # But the filters and/or requested has-many dataframe may depend on them
            # So, we'll alias the root feature time feature to whatever feature time columns were requested
            hm_df = hm_df.with_columns(pl.col(OBSERVED_AT_FEATURE_COL_NAME).alias(str(x)))
    expr: pl.Expr | None = FilterParsedConverter(PolarsFilterConverter()).convert_filters(
        [df_join_substituted], df_schema=hm_df.schema, timestamp_feature=ts_feature_parsed, now=ts
    )
    if expr is None:
        expr = ts_consistency_expr
    else:
        expr &= ts_consistency_expr
    expected_cols = [pl.col(x.root_fqn) for x in hm_feature.underlying.df.columns]

    # FIXME: The following two lines are a hack to remove rows with null pkeys from the dataframe
    # Ideally, the planner would never include rows with null pkeys in the dataframes, but we'll fix this bug later
    # See CHA-1454
    pkey_feature = graph.primary_feature_for_namespace(hm_feature.underlying.foreign_namespace())
    assert pkey_feature is not None
    expr &= pl.col(pkey_feature.root_fqn).is_not_null()
    return hm_df.filter(expr).select(expected_cols)
