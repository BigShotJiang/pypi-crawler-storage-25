from __future__ import annotations

import dataclasses
import inspect
from collections import defaultdict
from typing import Any, Callable, Mapping

import pyarrow as pa
from chalk.features import Feature
from chalk.features.feature_set import CURRENT_FEATURE_REGISTRY
from chalk.utils.collections import FrozenOrderedSet, OrderedSet
from chalk.utils.df_utils import estimate_row_size_bytes

from chalkruntime.constants import (
    INDEX_COL_NAME,
    IS_VALID_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    HasManyFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    is_nested_scalar,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_scalar,
)
from chalkruntime.graph.resolver import ResolverParsed
from chalkruntime.invoker.parse_external_resolver import load_external_resolver_code
from chalkruntime.metadata import get_feature_is_missing_col_name


@dataclasses.dataclass(frozen=True, slots=True)
class ResolverOutputMetadata:
    """Useful datastructs about resolver outputs that can be cached and re-used across multiple invocations of the same resolver

    This class must be instantiated ONLY IN THE INVOKER PROCESS,  because it assumes that the chalkpy resolvers and features are available in the registry
    """

    table_schema: Mapping[str, pa.DataType]
    """An (ordered) mapping of the expected schema of the post-processed table of resolver output"""

    pa_schema: pa.Schema
    """The ``table_schema``, as a pyarrow schema object"""

    resolver_output_root_fqns: FrozenOrderedSet[str]
    """The root fqns of the features, as returned by the resolver. Set to ``FrozenOrderedSet(x.root_fqn for x in resolver.output_features)``"""

    resolver_output_fqn_to_root_fqn: Mapping[str, str]
    """Equivalent to ``{x.fqn: x.root_fqn for x in resolver.output_features}``.
    If a fqn has multiple matching root fqns, then that feature is not in this mapping.
    This is for backwards compatibility where we allowed resolvers like this:

    ```python
    def get_credit_report_for_user(
        uid: AUser.id, name: AUser.name, email: AUser.email
    ) -> Features[
        AUser.credit_report.raw_credit_report,
        AUser.credit_report.version,
        AUser.credit_report.user_id,
        AUser.credit_report.id,
    ]:
        # Retuning the CreditReport namespace
        return CreditReport(...)
        # Instead, we should return something like this
        # return AUser(credit_report=CreditReport(...))
    ```
    """

    col_name_to_idx: Mapping[str, int]
    """A mapping of the column name to the index"""

    output_schema: FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | HasManyFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
    ]
    """The feature types corresponding to the columns of the ``table_schema``"""

    cols_with_defaults: Mapping[ScalarFeatureType | InputFeatureType[ScalarFeatureType], pa.Scalar]
    """A mapping from output feature to the default value"""

    cols_without_defaults: FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | HasManyFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
    ]
    """A collection of columns without default values"""

    is_one_to_one_resolver: bool
    """Whether the resolver returns exactly one output row and takes in exactly one input row."""

    single_output_feature: (
        ScalarFeatureType
        | InputFeatureType[ScalarFeatureType]
        | HasManyFeatureType
        | InputFeatureType[HasManyFeatureType]
        | None
    )
    """If the resolver returns exactly one output, what that output is"""

    single_output_feature_default: object
    """The primitive default for the single output feature, or ... if there isn't one"""

    single_output_feature_is_nullable: bool
    """Whether the single output feature is nullable"""

    pkey_feature: ScalarFeatureType
    """The pkey feature"""

    has_many_feature_outputs: dict[str, HasManyFeatureType | InputFeatureType[HasManyFeatureType]]

    estimated_row_size_bytes: int
    """Estimated size of an output row, based on the schema"""

    expected_features: tuple[Feature, ...]

    fn: Callable[..., Any]
    """The function"""

    is_async: bool

    output_is_df: bool

    @classmethod
    def from_resolver(cls, resolver: ResolverParsed, pkey_feature: ScalarFeatureType) -> ResolverOutputMetadata:
        is_one_to_one_resolver = not resolver.input_is_df and not resolver.output_is_df
        output_schema: OrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | HasManyFeatureType
            | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
        ] = OrderedSet()
        table_schema: dict[str, pa.DataType] = {}
        cols_with_defaults: dict[ScalarFeatureType | InputFeatureType[ScalarFeatureType], pa.Scalar] = {}
        cols_without_defaults: OrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | HasManyFeatureType
            | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
        ] = OrderedSet()
        has_many_feature_outputs: dict[str, HasManyFeatureType | InputFeatureType[HasManyFeatureType]] = {}

        for o in resolver.output_features:
            assert is_underlying_feature_time(o) or is_underlying_scalar(o) or is_underlying_has_many(o)
            output_schema.add(o)
            table_schema[o.root_fqn] = o.underlying.pyarrow_dtype

            if is_underlying_scalar(o) and o.underlying.primitive_converter.has_default:
                if (prim_default := o.underlying.primitive_converter.primitive_default) is not None:
                    # If the default is None, then we don't need to do anything special for missing values!
                    cols_with_defaults[o] = pa.scalar(prim_default, o.underlying.pyarrow_dtype)
            elif is_nested_scalar(o) and any(path_item.parent.primitive_converter.has_default for path_item in o.path):
                # The only way a has-one feature can have a primitive default is if it's typed as " | None"
                pass
            else:
                cols_without_defaults.add(o)
            if is_underlying_has_many(o):
                has_many_feature_outputs[o.fqn] = o

        if is_one_to_one_resolver:
            for o in resolver.output_features:
                table_schema[get_feature_is_missing_col_name(o.root_fqn)] = pa.bool_()
            # If we always add an output row for every input row, then we need to keep track of
            # whether the output row is valid
            table_schema[IS_VALID_COL_NAME] = pa.bool_()
        else:
            # Otherwise, if we could have multiple (or 0) output rows per input row, then we should NOT keep track of the "is_valid"
            # bit, but we do need to track the input metadata
            table_schema[TS_COL_NAME] = pa.timestamp("us", "UTC")
            table_schema[INDEX_COL_NAME] = pa.int64()
            table_schema[pkey_feature.root_fqn] = pkey_feature.pyarrow_dtype
            output_schema.add(pkey_feature)
        single_output_feature = None
        if len(resolver.output_features) == 1:
            o = next(iter(resolver.output_features))
            if is_underlying_scalar(o) or is_underlying_has_many(o):
                single_output_feature = o

        pa_schema = pa.schema(table_schema)
        resolver_output_fqn_to_root_fqns: defaultdict[str, OrderedSet[str]] = defaultdict(OrderedSet[str])
        for x in resolver.output_features:
            resolver_output_fqn_to_root_fqns[x.fqn].add(x.root_fqn)
        resolver_output_fqn_to_root_fqn: dict[str, str] = {}
        for k, vs in resolver_output_fqn_to_root_fqns.items():
            assert len(vs) > 0
            if len(vs) == 1:
                resolver_output_fqn_to_root_fqn[k] = next(iter(vs))

        estimated_row_size_bytes = sum(estimate_row_size_bytes(dtype) for dtype in pa_schema.types)

        fn = cls._get_fn_for_resolver(resolver)

        return cls(
            table_schema=table_schema,
            pa_schema=pa_schema,
            single_output_feature=single_output_feature,
            single_output_feature_is_nullable=(
                False
                if single_output_feature is None
                else single_output_feature.underlying.primitive_converter.is_nullable
            ),
            single_output_feature_default=(
                single_output_feature.underlying.primitive_converter.primitive_default
                if single_output_feature and single_output_feature.underlying.primitive_converter.has_default
                else ...
            ),
            cols_with_defaults=cols_with_defaults,
            cols_without_defaults=FrozenOrderedSet(cols_without_defaults),
            is_one_to_one_resolver=is_one_to_one_resolver,
            fn=fn,
            pkey_feature=pkey_feature,
            resolver_output_fqn_to_root_fqn=resolver_output_fqn_to_root_fqn,
            output_schema=FrozenOrderedSet(output_schema),
            resolver_output_root_fqns=FrozenOrderedSet(x.root_fqn for x in resolver.output_features),
            col_name_to_idx={x: i for i, x in enumerate(table_schema)},
            has_many_feature_outputs=has_many_feature_outputs,
            estimated_row_size_bytes=int(estimated_row_size_bytes + 0.5),
            output_is_df=resolver.output_is_df,
            is_async=inspect.iscoroutinefunction(fn) or inspect.isasyncgenfunction(fn),
            expected_features=tuple(x.to_feature() for x in resolver.output_features),
        )

    def subset(self: ResolverOutputMetadata, output_root_fqns: FrozenOrderedSet[str]) -> ResolverOutputMetadata:
        if not output_root_fqns.issubset(self.resolver_output_root_fqns):
            raise ValueError(
                f"FQN list {output_root_fqns} is not a subset of this ResolverOutputMetadata's current FQNs: {self.resolver_output_root_fqns}. Difference: {output_root_fqns - self.resolver_output_root_fqns}"
            )
        table_schema = {
            k: v
            for k, v in self.table_schema.items()
            if k in output_root_fqns or k not in self.resolver_output_root_fqns
        }
        has_many_feature_outputs = {
            k: v
            for k, v in self.has_many_feature_outputs.items()
            if k in output_root_fqns or k not in self.resolver_output_root_fqns
        }
        pa_schema = pa.schema(table_schema)
        return dataclasses.replace(
            self,
            resolver_output_root_fqns=output_root_fqns,
            table_schema=table_schema,
            pa_schema=pa_schema,
            cols_without_defaults={col for col in self.cols_without_defaults if col.root_fqn in output_root_fqns},
            cols_with_defaults={
                col: default for col, default in self.cols_with_defaults.items() if col.root_fqn in output_root_fqns
            },
            col_name_to_idx={x: i for i, x in enumerate(table_schema)},
            has_many_feature_outputs=has_many_feature_outputs,
        )

    @classmethod
    def _get_fn_for_resolver(cls, resolver: ResolverParsed) -> Callable[..., Any]:
        if not resolver.is_externally_defined:
            return resolver.get_fn()

        return load_external_resolver_code(resolver, CURRENT_FEATURE_REGISTRY.get())
