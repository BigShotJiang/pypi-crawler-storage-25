from __future__ import annotations

import dataclasses
from datetime import timedelta
from typing import (
    cast,
)

from chalk.utils.collections import FrozenOrderedSet, get_unique_item, unwrap_optional
from chalk.utils.storage_client import StorageClient
from chalk.utils.threading import (
    ChalkThreadPoolExecutor,
)

from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.overlay_graph import OverlayGraphInfo
from chalkruntime.graph.resolver import (
    MainProcResolverMixin,
    OfflineResolverParsed,
    OnlineResolverParsed,
    ResourceHintType,
)
from chalkruntime.invoker.bound_invoker import (
    BoundInvokerProtocol,
)
from chalkruntime.invoker.general_bound_invoker import GeneralBoundInvoker
from chalkruntime.invoker.no_arg_scalar_invoker import NoArgScalarBoundInvoker
from chalkruntime.invoker.one_to_one_invoker import (
    ParallelResolverInvoker,
)
from chalkruntime.invoker.overlay_features import OverlayFeatureRegistry
from chalkruntime.invoker.query_execution_parameters import QueryExecutionParameterFactory
from chalkruntime.invoker.resolver_input_upload import create_resolver_input_upload_client


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _BoundResolverInvokerCacheKey:
    resolvers: frozenset[str]
    query_name: str | None
    query_tags: frozenset[str]
    use_one_to_one_invoker: bool
    overlay_graph_info: OverlayGraphInfo | None


class ResolverInvokerCache:
    def __init__(
        self,
        graph: ResolvedGraph,
        resolver_executor: ChalkThreadPoolExecutor,
        fallback_resource_hint: ResourceHintType,
        plan_stages_storage_client: StorageClient | None,
        query_exec_param_factory: QueryExecutionParameterFactory,
    ):
        super().__init__()
        self._base_graph = graph
        self._resolver_executor = resolver_executor
        self._fallback_resource_hint: ResourceHintType = fallback_resource_hint
        self._plan_stages_storage_client = plan_stages_storage_client
        self._query_exec_param_factory = query_exec_param_factory
        self._resolver_to_bound_invoke: dict[_BoundResolverInvokerCacheKey, BoundInvokerProtocol] = {}
        self._overlay_registries: dict[str, OverlayFeatureRegistry] = {}

    def _get_overlay_registry(self, overlay_graph_info: OverlayGraphInfo | None) -> OverlayFeatureRegistry | None:
        if overlay_graph_info is None:
            return None
        key = overlay_graph_info.overlay_graph_hash
        if key not in self._overlay_registries:
            self._overlay_registries[key] = OverlayFeatureRegistry(overlay_graph_info=overlay_graph_info)
        return self._overlay_registries[key]

    def _get_invoker(self, key: _BoundResolverInvokerCacheKey) -> BoundInvokerProtocol:
        graph = key.overlay_graph_info.graph if key.overlay_graph_info is not None else self._base_graph
        resolvers = FrozenOrderedSet(graph.resolver_by_name_or_raise(resolver_fqn) for resolver_fqn in key.resolvers)
        query_exec_params = self._query_exec_param_factory.get_parameters_for_query(
            query_name=key.query_name, tags=key.query_tags
        )

        # If necessary, provide an alternative registry of raw feature classes for the invoker to use, e.g. for has-ones/has-manys.
        overlay_registry = self._get_overlay_registry(key.overlay_graph_info)

        if key.use_one_to_one_invoker:
            bound = ParallelResolverInvoker(
                cast(FrozenOrderedSet[OnlineResolverParsed | OfflineResolverParsed], resolvers),
                graph=graph,
                resolver_executor=self._resolver_executor,
                query_execution_params=query_exec_params,
                overlay_feature_registry=overlay_registry,
            )
            return bound

        resolver_fqn = get_unique_item(key.resolvers)
        resolver = graph.resolver_by_name(resolver_fqn)
        if resolver is None:
            raise ValueError(f"The resolver '{resolver_fqn}' was not found in the registry")
        if isinstance(resolver, MainProcResolverMixin) and resolver.static:
            raise ValueError(
                (
                    f"Resolver '{resolver_fqn}' was declared as static, but it was not compiled as part of the plan. "
                    "Please remove the `static=True` as part of the resolver signature."
                )
            )
        if not isinstance(resolver, (OnlineResolverParsed, OfflineResolverParsed)):
            raise ValueError(f"The resolver {resolver.fqn} is not an online or offline resolver.")
        if resolver.input_is_df or not hasattr(resolver, "unique_input_root_ns"):
            pkey_feature = unwrap_optional(graph.primary_feature_for_namespace(resolver.output_root_ns))
        else:
            pkey_feature = unwrap_optional(graph.primary_feature_for_namespace(resolver.unique_input_root_ns))
        is_one_to_one_resolver = not resolver.input_is_df and not resolver.output_is_df
        if (
            is_one_to_one_resolver
            and len(resolver.inputs) == 0
            and (resolver.timeout is None or resolver.timeout <= timedelta())
        ):
            return NoArgScalarBoundInvoker(
                resolver=resolver,
                pkey_feature=pkey_feature,
                fallback_resource_hint=self._fallback_resource_hint,
                resolver_executor=self._resolver_executor,
                query_execution_parameters=query_exec_params,
                overlay_feature_registry=overlay_registry,
            )
        else:
            resolver_input_upload_client = create_resolver_input_upload_client(
                resolver=resolver, storage_client=self._plan_stages_storage_client
            )

            return GeneralBoundInvoker(
                resolver=resolver,
                pkey_feature=pkey_feature,
                graph=graph,
                fallback_resource_hint=self._fallback_resource_hint,
                resolver_executor=self._resolver_executor,
                resolver_input_upload_client=resolver_input_upload_client,
                query_execution_parameters=query_exec_params,
                overlay_feature_registry=overlay_registry,
            )

    def get_invoker(
        self,
        resolver_fqns: frozenset[str],
        query_name: str | None,
        query_tags: frozenset[str],
        use_one_to_one_invoker: bool,
        overlay_graph_info: OverlayGraphInfo | None,
    ) -> BoundInvokerProtocol:
        key = _BoundResolverInvokerCacheKey(
            resolvers=resolver_fqns,
            query_tags=query_tags,
            use_one_to_one_invoker=use_one_to_one_invoker,
            query_name=query_name,
            overlay_graph_info=overlay_graph_info,
        )
        if key not in self._resolver_to_bound_invoke:
            self._resolver_to_bound_invoke[key] = self._get_invoker(key=key)

        return self._resolver_to_bound_invoke[key]
