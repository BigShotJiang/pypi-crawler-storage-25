from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import pyarrow as pa
from chalk.client.models import ChalkError


@dataclass(frozen=True, slots=True, kw_only=True)
class BatchResolverResult:
    data: pa.RecordBatch | None
    """The returned data from the resolver, or ``None`` if there is not a single row"""

    result_collector_num_rows: int | None
    """The number of rows that the result collector contained when this results object
    was made. This should normally be the same as len(data), except when there was an
    error collecting results (in which case data is None or might contain fewer rows)

    If there was no result collector instantiated yet when this BatchResolverResult was
    created, then the result_collector_num_rows is None.
    """

    ran_at: datetime
    """The actual wall-clock time that this batch was produced at. Will be different from the execution timestamp!"""

    errors: list[ChalkError]
    """A list of errors. Note that there can be both non-fatal errors and data."""

    # stats
    num_successful_invocations: int
    """Number of times the resolver was successfully called"""

    num_failed_invocations: int
    """Number of times the resolver raised an exception, or we encountered an exception
    coalescing the results"""

    num_skipped_invocations: int
    """Number of samples that were marked as SKIPPED, so we did not invoke the resolver"""

    num_resolver_timeouts: int
    """Number of times that the resolver timed out"""

    resolver_invocation_secs: float
    """Total number of seconds we spent invoking the resolver to compute this batch"""

    def __post_init__(self):
        if self.data is not None:
            assert len(self.data) == self.result_collector_num_rows, (
                f"The table length {len(self.data)} differs from the reported size of the result collector {self.result_collector_num_rows}"
            )
