import dataclasses
import logging
import operator
import time
from functools import reduce
from typing import Mapping

import polars as pl
from chalk.features.dataframe._validation import validate_nulls
from chalk.utils.df_utils import pa_table_to_pl_df
from chalk.utils.log_with_context import get_logger
from typing_extensions import assert_never

from chalkruntime.constants import (
    CHILD_INDEX_COL_NAME,
    INDEX_COL_NAME,
)
from chalkruntime.graph.feature import (
    DataFrameType,
    FilterParsed,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_scalar,
    rewrite_local_join_features_with_input_path,
)
from chalkruntime.invoker.resolver_input import (
    DataframeFeatureEntry,
    HasManyFeatureEntry,
    LocalResolverInputs,
)

_logger = get_logger(__name__)


@dataclasses.dataclass(frozen=True)
class PartitionedGroups:
    raw_df: Mapping[DataFrameType, DataframeFeatureEntry]

    raw_has_many: Mapping[HasManyFeatureType | InputFeatureType[HasManyFeatureType], HasManyFeatureEntry]
    """
    The raw batch groups; unprocessed. Contains all features for all partitions.
    """

    partitioned_has_many: (
        Mapping[HasManyFeatureType | InputFeatureType[HasManyFeatureType], tuple[pl.DataFrame, pl.DataFrame | None]]
        | None
    )
    """
    Groups restricted to this partition.

    Will be pre-validated for missing values, so no need to re-validate the dfs.

    Will be None if the raw_has_many has not been partitioned
    """


def _local_and_foreign_feats_recurse(
    pre_filt: FilterParsed,
    local_join_feats: tuple[ScalarFeatureType, ...],
    foreign_join_feats: tuple[ScalarFeatureType, ...],
):
    if (
        isinstance(pre_filt.lhs, FilterParsed)
        and isinstance(pre_filt.rhs, FilterParsed)
        and pre_filt.operation == "and"
    ):
        locals1, foreigns1 = _local_and_foreign_feats_recurse(pre_filt.lhs, local_join_feats, foreign_join_feats)
        locals2, foreigns2 = _local_and_foreign_feats_recurse(pre_filt.rhs, local_join_feats, foreign_join_feats)
        locals1.extend(locals2)
        foreigns1.extend(foreigns2)
        return locals1, foreigns1
    assert is_underlying_feature_time(pre_filt.lhs) or is_underlying_scalar(pre_filt.lhs), (
        f"The lhs '{pre_filt.lhs}' is not a feature type"
    )
    assert is_underlying_feature_time(pre_filt.rhs) or is_underlying_scalar(pre_filt.rhs), (
        f"The rhs '{pre_filt.rhs}' is not a feature type"
    )
    if pre_filt.lhs.underlying in local_join_feats and pre_filt.rhs.underlying in foreign_join_feats:
        local, foreign = pre_filt.lhs, pre_filt.rhs
    elif pre_filt.rhs.underlying in local_join_feats and pre_filt.lhs.underlying in foreign_join_feats:
        foreign, local = pre_filt.lhs, pre_filt.rhs
    else:
        raise ValueError(f"Join is unsupported for {pre_filt}")
    return [local], [foreign]


def partition_batch(
    batch: LocalResolverInputs,
    enable_indexed_has_many_joins: bool,
    skip_batch_filter_partitioning_logic: bool,
) -> PartitionedGroups:
    """
    Resolvers are given huge batches of scalars + tables that represent their relationships.
    The tables are oversampled and common to all the batches.

    Turns out, though, that filtering down these tables 1 million times is slow if they're big.
    Fortunately, the batch scalars are relatively small (and we can make them super small by splitting
    more finely.

    That tends to mean that most of the tables can be pruned to be much much smaller, which makes all
    the linear filters much much faster.
    """
    raw_df = batch.df_features
    raw_has_many: dict[HasManyFeatureType | InputFeatureType[HasManyFeatureType], HasManyFeatureEntry] = {}
    partitioned_has_many: dict[
        HasManyFeatureType | InputFeatureType[HasManyFeatureType], tuple[pl.DataFrame, pl.DataFrame | None]
    ] = {}

    if len(batch.has_many_features) == 0:
        return PartitionedGroups(raw_df=raw_df, raw_has_many=raw_has_many, partitioned_has_many=partitioned_has_many)

    start = time.perf_counter()
    scalarish_features = batch.scalarish_features
    scalars_as_pl = None if scalarish_features is None else pa_table_to_pl_df(scalarish_features.to_table())
    batch_table_features = batch.has_many_features
    for k_ft, v in batch_table_features.items():
        assert is_underlying_has_many(k_ft), f"Expected has-many feature type; got {k_ft} of type {type(k_ft)}"
        raw_has_many[k_ft] = v
        table = pa_table_to_pl_df(v.result_and_metadata.to_table())

        if not skip_batch_filter_partitioning_logic:
            mapping_table = None if v.mapping_table is None else pa_table_to_pl_df(v.mapping_table.to_table())

            # Otherwise, we can filter on value, based on the join filter
            pre_filter = rewrite_local_join_features_with_input_path(k_ft, include_filters=False)
            if isinstance(k_ft, (HasManyFeatureType, HasOneFeatureType)):
                local_join_feats = k_ft.get_local_join_features()
                foreign_join_feats = k_ft.get_foreign_join_features()
            elif isinstance(k_ft, InputFeatureType):  # pyright: ignore[reportUnnecessaryIsInstance]
                local_join_feats = k_ft.underlying.get_local_join_features()
                foreign_join_feats = k_ft.underlying.get_foreign_join_features()
            else:
                assert_never(k_ft)

            locals_list, foreigns_list = _local_and_foreign_feats_recurse(
                pre_filter, local_join_feats, foreign_join_feats
            )

            if scalars_as_pl is not None and all([str(local) in scalars_as_pl.columns for local in locals_list]):
                is_nn: bool = k_ft.underlying.get_nearest_neighbor_join_info() is not None  # pyright: ignore[reportAttributeAccessIssue] # graph_cached attrs are weird
                if mapping_table is not None and (enable_indexed_has_many_joins or is_nn):
                    partitioned_mapping_table = mapping_table.filter(
                        pl.col(CHILD_INDEX_COL_NAME).is_in(scalars_as_pl.get_column(CHILD_INDEX_COL_NAME))
                    )
                    partitioned_table = table.filter(
                        pl.col(INDEX_COL_NAME).is_in(partitioned_mapping_table.get_column(INDEX_COL_NAME))
                    )
                else:
                    partitioned_mapping_table = None
                    partitioned_table = table.filter(
                        reduce(
                            operator.and_,
                            [
                                pl.col(str(foreign)).is_in(scalars_as_pl[str(local)])
                                for foreign, local in zip(foreigns_list, locals_list)
                            ],
                        )
                    )
            else:
                # we are >=2 has-many from the root, so we'd have a lot of values in the local key anyway
                partitioned_table = table
                partitioned_mapping_table = None
        else:
            partitioned_table = table
            partitioned_mapping_table = None
        validated_partitioned = validate_nulls(
            underlying=partitioned_table,
            missing_value_strategy="default_or_allow",
            tolerate_missing_features=True,
        )
        partitioned_has_many[k_ft] = (validated_partitioned, partitioned_mapping_table)
        if _logger.getEffectiveLevel() <= logging.DEBUG:
            _logger.debug(
                "Filtered partition from %d -> %d in %dms",
                len(table),
                len(validated_partitioned),
                (time.perf_counter() - start) * 1000,
            )

    return PartitionedGroups(raw_df=raw_df, raw_has_many=raw_has_many, partitioned_has_many=partitioned_has_many)
