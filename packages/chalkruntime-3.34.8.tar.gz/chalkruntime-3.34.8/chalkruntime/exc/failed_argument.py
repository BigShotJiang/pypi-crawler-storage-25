import dataclasses


@dataclasses.dataclass(slots=True, frozen=True)
class FailedArgument:
    expected_feature: str
    value: object
