class WrappedResolverException(Exception):
    def __init__(self, original_exception: BaseException, duration_seconds: float):
        super().__init__(original_exception)
        self.original_exception = original_exception
        self.duration_seconds = duration_seconds
