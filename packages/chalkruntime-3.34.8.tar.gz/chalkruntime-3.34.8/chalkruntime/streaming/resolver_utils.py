import dataclasses
import json
from typing import TYPE_CHECKING, Type

from chalk.client import ChalkError
from chalk.utils.log_with_context import get_logger, get_public_logger
from chalk.utils.pydanticutil.pydantic_compat import (
    is_pydantic_basemodel,
    parse_pydantic_model,
)

from chalkruntime.graph.stream_resolver import StreamResolverParsed

if TYPE_CHECKING:
    from chalkruntime.streaming.types import (
        BaseModelType,
        DataClassAny,
    )


_logger = get_logger(__name__)
_public_logger = get_public_logger(__name__)
FAILURE_RETRY_SLEEP_SECONDS = 5


def coerce_streaming_message_body(
    value_raw: bytes, typ: "Type[BaseModelType | DataClassAny | str | bytes]"
) -> "BaseModelType | DataClassAny | str | bytes":
    if typ is bytes:
        return value_raw
    elif typ is str:
        return value_raw.decode("utf8")
    elif dataclasses.is_dataclass(typ):
        return typ(**json.loads(value_raw.decode("utf8")))
    elif is_pydantic_basemodel(typ):
        return parse_pydantic_model(typ, value_raw)
    else:
        raise TypeError(f"Unsupported message body type {typ}")


def log_resolver_error(resolver: StreamResolverParsed, error: ChalkError, public: bool):
    message = (
        f"{error.exception.kind}: {error.exception.message}\n{error.exception.stacktrace}"
        if error.exception is not None
        else f"exception {error}: {error.message}"
    )

    _logger.debug(f"While evaluating '{resolver.fqn}, received error: {message}")
    if public:
        _public_logger.error(message)
