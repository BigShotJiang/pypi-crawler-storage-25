import orjson


def window_key_for(primitive_keys: list[int | str]) -> str:
    return orjson.dumps([str(key) for key in primitive_keys]).decode("utf-8")


def window_key_from(extracted_key: str) -> list[str]:
    return orjson.loads(extracted_key)
