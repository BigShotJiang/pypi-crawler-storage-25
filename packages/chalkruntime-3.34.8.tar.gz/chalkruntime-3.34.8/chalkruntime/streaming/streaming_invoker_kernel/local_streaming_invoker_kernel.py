"""Streaming-resolver invocation kernel that runs the resolver in-process and emits the
proto response defined by chalk.runtime.v1.PythonStreamingResolverInvokerService.

Lives in chalkruntime so it has zero dependency on chalkengine. chalkengine's
LocalStreamingResolverInvokerKernel adapts this kernel's proto output back into the engine's
StreamingResolverResult shape; chalkruntime's gRPC handler invokes this kernel directly.
"""

from __future__ import annotations

import io
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import pyarrow as pa
import pyarrow.feather as feather
from chalk._gen.chalk.runtime.v1 import data_pb2
from chalk._gen.chalk.runtime.v1 import (
    python_streaming_resolver_invoker_service_pb2 as streaming_pb2,
)
from chalk.client import ErrorCode, ErrorCodeCategory
from chalk.client.models import ChalkError
from chalk.client.serialization.protos import ChalkErrorConverter
from chalk.streams.types import (
    StreamResolverParam,
    StreamResolverParamMessage,
)
from chalk.utils.log_with_context import get_logger, get_public_logger
from datadog import statsd

from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.stream_resolver import StreamResolverParsed
from chalkruntime.invoker.resolver_raw_output_parsing import (
    ImplicitKeyedColumn,
    resolver_raw_output_to_table,
)
from chalkruntime.streaming.exc import FatalResolverError
from chalkruntime.streaming.message_parsing import parse_maybe
from chalkruntime.streaming.resolver_utils import (
    coerce_streaming_message_body,
    log_resolver_error,
)
from chalkruntime.streaming.types import (
    ParsedMessage,
    StreamMessageRaw,
)

_logger = get_logger(__name__)
_public_logger = get_public_logger(__name__)


def _table_to_feather_bytes(table: pa.Table) -> bytes:
    if table.num_rows == 0 and len(table.schema) == 0:
        return b""
    sink = io.BytesIO()
    feather.write_feather(table, sink, compression="uncompressed")
    return sink.getvalue()


def _utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _now_utc() -> datetime:
    return datetime.now(tz=timezone.utc)


def _decode_proto_message(proto: streaming_pb2.StreamMessageRaw) -> StreamMessageRaw:
    if proto.WhichOneof("message_offset") == "int_offset":
        offset: str | int = int(proto.int_offset)
    elif proto.WhichOneof("message_offset") == "string_offset":
        offset = proto.string_offset
    else:
        offset = ""
    message_key = proto.message_key if proto.HasField("message_key") else None
    time_dt = proto.time.ToDatetime() if proto.HasField("time") else _now_utc()
    return StreamMessageRaw(
        time=_utc(time_dt),
        value_raw=proto.value_raw,
        message_key=message_key,
        message_offset=offset,
        stream_id=proto.stream_id,
        partition=proto.partition,
        num_retries=int(proto.num_retries),
        is_test_message=bool(proto.is_test_message),
    )


def decode_messages(request: streaming_pb2.InvokeResolverInBatchOnlyRequest) -> list[StreamMessageRaw]:
    """Decode either the structured `messages` or the opaque `serialized_messages` field of a
    request into chalkruntime StreamMessageRaw dataclasses. The two are interchangeable and
    callers should populate exactly one."""
    out: list[StreamMessageRaw] = []
    for proto in request.messages:
        out.append(_decode_proto_message(proto))
    for blob in request.serialized_messages:
        decoded = streaming_pb2.StreamMessageRaw()
        decoded.ParseFromString(blob)
        out.append(_decode_proto_message(decoded))
    return out


def _build_skipped_proto_result(
    *,
    timestamp: datetime,
    duration: timedelta,
    observed_at_fallback: datetime,
) -> streaming_pb2.StreamingResolverResult:
    proto_result = streaming_pb2.StreamingResolverResult()
    proto_result.timestamp.FromDatetime(_utc(timestamp))
    proto_result.duration.FromTimedelta(duration)
    proto_result.observed_at_fallback.FromDatetime(_utc(observed_at_fallback))
    proto_result.result_table.feather_v2 = b""
    proto_result.num_rows = 0
    proto_result.skipped = True
    return proto_result


def _build_error_proto_result(
    *,
    error: ChalkError,
    timestamp: datetime,
    duration: timedelta,
    observed_at_fallback: datetime,
) -> streaming_pb2.StreamingResolverResult:
    proto_result = streaming_pb2.StreamingResolverResult()
    proto_result.timestamp.FromDatetime(_utc(timestamp))
    proto_result.duration.FromTimedelta(duration)
    proto_result.observed_at_fallback.FromDatetime(_utc(observed_at_fallback))
    proto_result.result_table.feather_v2 = b""
    proto_result.num_rows = 0
    proto_result.error.CopyFrom(ChalkErrorConverter.chalk_error_encode(error))
    return proto_result


def _build_success_proto_result(
    *,
    table: pa.Table,
    num_rows: int,
    timestamp: datetime,
    duration: timedelta,
    observed_at_fallback: datetime,
) -> streaming_pb2.StreamingResolverResult:
    proto_result = streaming_pb2.StreamingResolverResult()
    proto_result.timestamp.FromDatetime(_utc(timestamp))
    proto_result.duration.FromTimedelta(duration)
    proto_result.observed_at_fallback.FromDatetime(_utc(observed_at_fallback))
    proto_result.result_table.feather_v2 = _table_to_feather_bytes(table)
    proto_result.num_rows = int(num_rows)
    return proto_result


def _get_non_windowed_param_value(
    param: StreamResolverParam,
    message: StreamMessageRaw,
    stream_resolver: StreamResolverParsed,
    log_error: bool,
) -> Any:
    if isinstance(param, StreamResolverParamMessage):
        try:
            return coerce_streaming_message_body(message.value_raw, param.typ)
        except ValueError:
            if log_error:
                _logger.error(f"Failed to parse message body: {message.value_raw.decode('utf-8')}")
                _public_logger.warning(f"Failed to parse message body: {message.value_raw.decode('utf-8')}")
            raise

    raise FatalResolverError(
        chalk_error=ResolverErrors.unrecognized_streaming_resolver_arg(stream_resolver.fqn, param.name)
    )


class LocalStreamingResolverInvokerKernel:
    """In-process kernel used by chalkruntime's PythonStreamingResolverInvokerService handler.

    Runs a non-windowed streaming resolver against a batch of raw messages and emits the
    proto response shape directly, with one StreamingResolverResult per input message.
    """

    def __init__(
        self,
        *,
        graph: ResolvedGraph,
        log_invalid_messages: bool,
        environment_id: str,
    ) -> None:
        super().__init__()
        self._graph = graph
        self._log_invalid_messages = log_invalid_messages
        self._environment_id = environment_id

    def invoke(
        self,
        request: streaming_pb2.InvokeResolverInBatchOnlyRequest,
    ) -> streaming_pb2.InvokeResolverInBatchOnlyResponse:
        resolver = self._graph.get_stream_resolver_or_raise(request.resolver_fqn)
        if resolver.is_windowed:
            err = ChalkError(
                code=ErrorCode.INTERNAL_SERVER_ERROR,
                category=ErrorCodeCategory.NETWORK,
                message=(
                    f"Attempt to run windowed resolver '{resolver.fqn}' as a map resolver via "
                    "PythonStreamingResolverInvokerService -- this is not supported."
                ),
                resolver=resolver.fqn,
            )
            log_resolver_error(resolver, err, public=False)
            now_dt = _now_utc()
            single = _build_error_proto_result(
                error=err,
                timestamp=now_dt,
                duration=timedelta(seconds=0),
                observed_at_fallback=now_dt,
            )
            response = streaming_pb2.InvokeResolverInBatchOnlyResponse()
            messages = decode_messages(request) or [None]  # ensure at least one entry
            for _ in messages:
                response.results.append(streaming_pb2.StreamingResolverResult().FromString(single.SerializeToString()))
            return response

        messages = decode_messages(request)
        return self.invoke_decoded(resolver=resolver, messages=messages, operation_id=request.operation_id)

    def invoke_decoded(
        self,
        *,
        resolver: StreamResolverParsed,
        messages: list[StreamMessageRaw],
        operation_id: str,
    ) -> streaming_pb2.InvokeResolverInBatchOnlyResponse:
        _public_logger.debug(f'Executing non-windowed streaming resolver "{resolver.fqn}"')
        graph = resolver.graph
        signature = resolver.raw_resolver.signature
        response = streaming_pb2.InvokeResolverInBatchOnlyResponse()

        for message in messages:
            now = _now_utc()
            parsed_message: ParsedMessage | None = None
            try:
                parsed_message = parse_maybe(
                    message, resolver, operation_id=operation_id, log_error=self._log_invalid_messages
                )
                perf_counter_start_ts = time.perf_counter()
                if resolver.parse_info_parsed is not None:
                    if parsed_message is None:
                        perf_counter_end_ts = time.perf_counter()
                        duration = timedelta(seconds=perf_counter_end_ts - perf_counter_start_ts)
                        response.results.append(
                            _build_skipped_proto_result(
                                timestamp=now,
                                duration=duration,
                                observed_at_fallback=message.time,
                            )
                        )
                        statsd.increment(
                            "chalk.streaming.messages_skipped",
                            tags=[
                                f"resolver_fqn:{resolver.fqn}",
                                f"environment:{self._environment_id}",
                            ],
                        )
                        continue
                    params: list[Any] = [parsed_message.parsed_model]
                else:
                    params = [
                        _get_non_windowed_param_value(
                            param=p,
                            message=message,
                            stream_resolver=resolver,
                            log_error=self._log_invalid_messages,
                        )
                        for p in signature.params
                    ]
                result = resolver.get_fn()(*params)
            except FatalResolverError as e:
                log_resolver_error(resolver, e.chalk_error, public=True)
                response.results.append(
                    _build_error_proto_result(
                        error=e.chalk_error,
                        timestamp=now,
                        duration=timedelta(seconds=0),
                        observed_at_fallback=message.time,
                    )
                )
                continue
            except Exception as e:
                err = ResolverErrors.resolver_raised_exception(resolver_fqn=resolver.fqn, exception=e)
                log_resolver_error(resolver, err, public=True)
                response.results.append(
                    _build_error_proto_result(
                        error=err,
                        timestamp=now,
                        duration=timedelta(seconds=0),
                        observed_at_fallback=message.time,
                    )
                )
                continue

            output_observed_at_feature = graph.ts_feature_for_namespace(resolver.output_root_ns)
            assert output_observed_at_feature is not None

            if isinstance(result, ChalkError):
                log_resolver_error(resolver, result, public=True)
                response.results.append(
                    _build_error_proto_result(
                        error=result,
                        timestamp=now,
                        duration=timedelta(seconds=0),
                        observed_at_fallback=message.time if parsed_message is None else parsed_message.timestamp,
                    )
                )
                continue

            implicit_keyed_columns: list[ImplicitKeyedColumn] | None = None
            if resolver.keys:
                assert parsed_message is not None
                implicit_keyed_columns = []
                for attribute, feature in resolver.keys.items():
                    try:
                        key_value = getattr(parsed_message.parsed_model, attribute)
                        implicit_keyed_columns.append(ImplicitKeyedColumn(feature.fqn, key_value))
                    except AttributeError:
                        _logger.warning(
                            f"Failed to get attribute {attribute} from parsed message {parsed_message.parsed_model}"
                        )

            result_table_or_err, num_rows = resolver_raw_output_to_table(
                raw_result=result,
                resolver=resolver,
                graph=graph,
                missing_value_strategy="default_or_error",
                implicit_keyed_columns=implicit_keyed_columns,
            )

            if isinstance(result_table_or_err, ChalkError):
                log_resolver_error(resolver, result_table_or_err, public=True)
                response.results.append(
                    _build_error_proto_result(
                        error=result_table_or_err,
                        timestamp=now,
                        duration=timedelta(seconds=0),
                        observed_at_fallback=message.time if parsed_message is None else parsed_message.timestamp,
                    )
                )
                continue
            result_table = result_table_or_err
            perf_counter_end_ts = time.perf_counter()
            duration = timedelta(seconds=perf_counter_end_ts - perf_counter_start_ts)
            response.results.append(
                _build_success_proto_result(
                    table=result_table,
                    num_rows=num_rows,
                    timestamp=now,
                    duration=duration,
                    observed_at_fallback=message.time if parsed_message is None else parsed_message.timestamp,
                )
            )

        if __debug__:
            assert len(response.results) == len(messages), (
                f"Expected the same number of results ({len(response.results)}) as messages ({len(messages)})"
            )
        return response


__all__ = [
    "LocalStreamingResolverInvokerKernel",
    "decode_messages",
    "data_pb2",
    "streaming_pb2",
]
