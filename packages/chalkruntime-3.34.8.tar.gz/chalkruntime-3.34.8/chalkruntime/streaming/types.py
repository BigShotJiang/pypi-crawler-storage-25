import dataclasses
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import (
    Any,
    List,
    Optional,
    Protocol,
)

import pyarrow as pa
from chalk.streams import StreamSource
from chalk.utils.json import TJSON
from chalk.utils.log_with_context import get_logger
from typing_extensions import Self

_logger = get_logger(__name__)

CHALK_NULL_STREAM_KEY = "__chalk_null_key__"
"""
A sentinel value that should be used for stream IDs that don't support or choose not to use keys,
to still allow Windowed[] support. It's not always appropriate to use this fallback value
if a message didn't include a key, e.g. for partitioned kafka, since we can't guarantee that all processing
will occur on the same node for messages without keys
"""

DataClassAny = Any
BaseModelType = Any
OffsetType = str | int


@dataclass(frozen=True, slots=True, kw_only=True)
class StreamMessageRaw:
    time: datetime
    value_raw: bytes
    message_key: Optional[str]
    message_offset: OffsetType
    stream_id: str
    partition: str
    num_retries: int = 0
    is_test_message: bool = False

    @classmethod
    def to_arrow(cls, messages: List[Self]) -> pa.RecordBatch:
        # Note: tuples' field order matches `fields`
        messages_tuples = [dataclasses.astuple(m) for m in messages]
        fields: dict[str, Any] = StreamMessageRaw.__dataclass_fields__
        schema = {
            "time": pa.timestamp("us", "UTC"),
            "value_raw": pa.large_binary(),
            "message_key": pa.large_utf8(),
            "message_offset": pa.large_utf8(),
            "stream_id": pa.large_utf8(),
            "partition": pa.large_utf8(),
            "num_retries": pa.int64(),
        }
        assert fields.keys() == schema.keys()
        columns: dict[str, list] = {
            f_name: [messages_tuples[row_idx][f_idx] for row_idx in range(len(messages_tuples))]
            for (f_idx, f_name) in enumerate(fields.keys())
        }
        return pa.RecordBatch.from_pydict(columns, schema=pa.schema(schema))

    @classmethod
    def from_arrow(cls, batch: pa.RecordBatch) -> "List[StreamMessageRaw]":
        rows = batch.to_pylist()
        return [StreamMessageRaw(**r) for r in rows]


FAILURE_RETRY_LIMIT = 5


@dataclass(kw_only=True, slots=True)
class ParsedMessage:
    parsed_bytes: bytes
    """
    Extracted from self.raw_message.value_raw by the `resolver.parse` function, if present, or the
    standard pydantic.BaseModel input parsing logic.
    """

    parsed_model: "BaseModelType | DataClassAny | str | bytes | None"
    """
    The parsed message, passing through resolver.parse if present, or simply the resolver input BaseModel.
    """

    extracted_message_key: str | None
    """
    Either raw_message.key or the extracted key from the parsed message, respecting the resolver's keying strategy.
    """

    raw_message: StreamMessageRaw
    """
    Raw message as received from the underlying stream connector.
    """

    timestamp: datetime
    """
    A timezoned datetime equal to the 'timestamp' field on the incoming message if specified,
    or the time at which the message was received by the stream source if not.
    """


@dataclass(kw_only=True, slots=True)
class WindowScheduleJob:
    stream_id: str
    resolver_fqn: str
    window_size_sec: int
    key: str
    message_delay_sec: int
    range_start_time: str
    range_end_time: str
    bucket_id: str


class WindowComputeScheduler(Protocol):
    async def schedule_window_compute_jobs(self, jobs: list[WindowScheduleJob]): ...


@dataclass(kw_only=True, slots=True)
class WindowComputeJob:
    stream_id: str
    key: str
    resolver_fqn: str
    range_start_time: datetime
    range_end_time: datetime
    window_size_sec: int
    receipt_handle: str


class WindowComputeConsumer(Protocol):
    async def get_one(self, *, max_wait_sec: int) -> WindowComputeJob | None: ...

    async def mark_complete(self, receipt_handle: str): ...


class StreamingMessageFormatError(ValueError): ...


# Helper function for timezone conversion
def convert_timestamp_utc(array: pa.Array | pa.ChunkedArray) -> pa.Array | pa.ChunkedArray:
    _logger.warning(
        "Converting timestamps to utc timezone using Python datetime objects. "
        + "Timestamps should have already been converted to UTC, so this should really not be run."
    )

    if isinstance(array, pa.ChunkedArray):
        # Process each chunk and combine the results
        converted_chunks = [convert_timestamp_chunk(chunk) for chunk in array.chunks]
        return pa.chunked_array(converted_chunks)
    else:
        # It's a regular Array
        return convert_timestamp_chunk(array)


def convert_timestamp_chunk(array: pa.Array) -> pa.Array:
    python_datetimes: list[datetime | None] = array.to_pylist()  # pyright: ignore[reportAttributeAccessIssue]

    target_timezone = timezone.utc

    # Convert each datetime to target timezone
    converted_datetimes: list[datetime | None] = []
    for dt in python_datetimes:
        if dt is None:
            converted_datetimes.append(None)
            continue

        # If datetime has no timezone, assume UTC
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        # Convert to target timezone
        converted_dt = dt.astimezone(target_timezone)
        converted_datetimes.append(converted_dt)

    # Convert back to PyArrow array
    converted_array = pa.array(converted_datetimes, type=pa.timestamp("us", "UTC"))
    assert isinstance(converted_array, pa.Array)
    return converted_array


class CustomStreamSourceParsed(StreamSource):
    """
    Placeholder for serialized stream sources of unrecognized type.
    Currently only used for the mock stream sources created in our engine tests.
    If customer code contains a random stream source, we should raise a validation error.

    However for our unit tests it's necessary to parse the stream sources in order to load the graph,
    even if we don't know what to do with them.
    """

    def __init__(
        self, *, name: str | None, streaming_type: str, stream_or_topic_name: str, dlq_name: str, **kwargs: TJSON
    ):
        super().__init__()
        self._streaming_type = streaming_type
        self._stream_or_topic_name = stream_or_topic_name
        self._dlq_name = dlq_name
        self.name: str | None = name
        self.options = dict(kwargs)

    def with_name(self, name: str) -> "CustomStreamSourceParsed":
        return CustomStreamSourceParsed(
            name=name,
            streaming_type=self.streaming_type,
            stream_or_topic_name=self.stream_or_topic_name,
            dlq_name=self.dlq_name,
            **self.options,
        )

    def config_to_json(self) -> str:
        return json.dumps(self.config_to_dict())

    def config_to_dict(self) -> dict:
        return {
            "streaming_type": self.streaming_type,
            "name": self.name,
            "options": self.options,
        }

    @property
    def streaming_type(self) -> str:
        return self._streaming_type

    @property
    def stream_or_topic_name(self) -> str:
        return self._stream_or_topic_name

    @property
    def dlq_name(self) -> str:
        return self._dlq_name

    def __hash__(self):
        return hash(self.config_to_json())
