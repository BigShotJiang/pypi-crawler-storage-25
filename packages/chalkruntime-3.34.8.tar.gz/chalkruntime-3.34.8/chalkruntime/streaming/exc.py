from chalk.client import ChalkError


class FatalResolverError(Exception):
    """Deprecated -- used by the old invoker to propagate out a ChalkError"""

    def __init__(
        self,
        chalk_error: ChalkError,
        chalk_internal_message: str | None = None,
    ):
        self.chalk_error = chalk_error
        self.chalk_internal_message = chalk_internal_message
        super().__init__(f"display_message={self.chalk_error.message}, internal_message={self.chalk_internal_message}")
