import base64
from collections import defaultdict, deque
from typing import Any, Callable, Generic, Sequence, TypeAlias, TypeVar

from chalk.utils.log_with_context import get_logger

TNode = TypeVar("TNode")

Edge: TypeAlias = tuple[TNode, TNode, Callable]

_logger = get_logger(__name__)


class Path(Generic[TNode]):
    def __init__(self, visited: set[TNode], edges: Sequence[Edge[TNode]], end: TNode):
        super().__init__()
        self.visited = visited
        self.edges = edges
        self.end = end

    def add(self, edge: Edge[TNode]):
        next_visited = self.visited.copy()
        next_visited.add(edge[1])
        return Path(next_visited, [*self.edges, edge], edge[1])


def find_shortest_path(edges: Sequence[Edge[TNode]], start: TNode, end: TNode) -> Sequence[Edge[TNode]]:
    outgoing_edges = defaultdict[TNode, list[Edge[TNode]]](list)
    for edge in edges:
        outgoing_edges[edge[0]].append(edge)

    queue = deque([Path({start}, [], start)])
    while len(queue) > 0:
        path = queue.popleft()
        if end == path.end:
            return path.edges

        for outgoing_edge in outgoing_edges[path.end]:
            if outgoing_edge[1] not in path.visited:
                queue.append(path.add(outgoing_edge))

    raise RuntimeError(f"No suitable path to convert from {start} to {end}")


def convert_format(value: Any, *, edges: Sequence[Edge[TNode]], start_node: TNode, end_node: TNode):
    path = find_shortest_path(edges, start_node, end_node)
    _logger.debug(f"convert_format, {type(value)=} {path=} {value=} ")
    for _, _, converter in path:
        value = converter(value)
    return value


def decode_b64(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))
