import sqlglot
import sqlglot.expressions
from sqlglot import Expression, parse_one
from sqlglot.expressions import Alias, Column, Group, Literal, Select


class UnableToIncrementalizeError(Exception):
    def __init__(self, msg: str):
        super().__init__(self, f"Unable to incrementalize SQL query: {msg}")


def resolve_numeric_aliases(query: Expression, gn: Group, dialect: str | None = None) -> list[str]:
    res: list[str] = []
    for expr in gn.expressions:
        if isinstance(expr, Column):
            res.append(expr.alias_or_name)
        elif isinstance(expr, Alias):
            res.append(expr.alias_or_name)
        elif isinstance(expr, Literal):
            if expr.is_int and isinstance(query, Select):
                res.append(query.named_selects[int(expr.name) - 1])
            else:
                raise ValueError(
                    f"Unhandled group key {expr.sql(dialect=dialect)} or query type: {query.sql(dialect=dialect)}"
                )
    return res


def extract_group_keys(query: Expression) -> list[str] | None:
    gn = query.find(Group, bfs=True)

    if gn is not None:
        assert isinstance(gn, Group)
        return resolve_numeric_aliases(query, gn)

    return None


def get_table_name(q: Expression, *, dialect: str | None) -> str:
    if "joins" in q.args:
        # Any joins, implicit or explicit, will break our ability to select the right value.
        raise UnableToIncrementalizeError("query cannot join multiple tables")
    return q.args["from"].this.sql(dialect=dialect)


def incrementalize_grouped_query(
    query: str, dialect: str | None, updated_at_column: str, bind_param_name: str = "chalk_incremental_timestamp"
) -> str:
    parsed = parse_one(query, read=dialect)
    if parsed is None:  # pyright: ignore[reportUnnecessaryComparison]
        raise UnableToIncrementalizeError("failed to parse select query")
    group_keys = extract_group_keys(parsed)

    if group_keys is None or len(group_keys) == 0:
        raise UnableToIncrementalizeError("failed to identify group-by keys from query")
    group_target = group_keys[0]

    entity_table = get_table_name(parsed, dialect=dialect)

    group_subquery = sqlglot.select(group_target).from_(entity_table).where(f"{updated_at_column} > :{bind_param_name}")
    return parsed.where(f"{group_target} in ({group_subquery.sql(dialect=dialect)})").sql(dialect=dialect)  # pyright: ignore[reportAttributeAccessIssue]
