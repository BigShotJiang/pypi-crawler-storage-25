from __future__ import annotations

import dataclasses
import json
import math
import uuid
from collections.abc import Collection
from datetime import datetime, timedelta
from typing import Any, ClassVar, List, Mapping, Optional, Tuple, Union, cast

import pyarrow as pa
import sqlalchemy
import sqlglot
import sqlglot.expressions as sqlglot_expressions
from chalk.features import Feature, TPrimitive
from chalk.sql import (
    AthenaSourceImpl,
    BigQuerySourceImpl,
    DatabricksSourceImpl,
    FinalizedChalkQuery,
    PostgreSQLSourceImpl,
    SQLSourceGroup,
)
from chalk.sql._internal.integrations.snowflake import SnowflakeSourceImpl
from chalk.sql._internal.sql_source import BaseSQLSource
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.collections import FrozenOrderedSet, OrderedSet
from chalk.utils.df_utils import to_pylist
from chalk.utils.environment_parsing import env_var_bool
from chalk.utils.log_with_context import get_logger
from chalk.utils.tracing import safe_trace
from datadog import statsd
from opentelemetry.trace import get_current_span
from sqlalchemy import literal, select, true
from sqlalchemy.sql.ddl import CreateTable, DropTable
from sqlalchemy.sql.elements import ColumnElement, TextClause, quoted_name
from sqlalchemy.sql.selectable import FromClause, SelectBase
from sqlalchemy.types import TypeEngine
from sqlglot.expressions import to_identifier
from typing_extensions import assert_never

from chalkruntime.graph.feature import (
    FeatureFqnMarker,
    FeatureTimeFeatureType,
    FilterParsed,
    InputFeatureType,
    NamedFeatureType,
    ScalarFeatureType,
    SimpleTemporalFilter,
    is_underlying_feature_time,
    is_underlying_scalar,
)
from chalkruntime.metadata import ResultMetadataSourceType, get_metadata_col_name, parse_metadata_value
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter
from chalkruntime.sql_rewriter.query_rewriter_helper import to_sqlglot

_logger = get_logger(__name__)

LOWER_BOUND_SQL_PARAMETER_NAME = "lower_bound"
UPPER_BOUND_SQL_PARAMETER_NAME = "upper_bound"


def _recursively_apply_on_side(
    subquery: FromClause,
    side: (
        FilterParsed
        | TPrimitive
        | ScalarFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ),
    *,
    min_now: datetime | None,
    max_now: datetime | None,
    had_givens_batch: bool,
    failed_to_rewrite_features: OrderedSet[
        ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ],
) -> ColumnElement[Any] | None:
    if isinstance(side, FilterParsed):
        return _recursively_convert_to_sql_filter(
            subquery,
            side,
            min_now=min_now,
            max_now=max_now,
            had_givens_batch=had_givens_batch,
            failed_to_rewrite_features=failed_to_rewrite_features,
        )
    elif is_underlying_scalar(side) or is_underlying_feature_time(side):
        # TODO handle the feature time features specially?
        # TODO handle the chalk ts feature specially?
        if side.root_fqn not in subquery.c:
            failed_to_rewrite_features.add(side)
            return
        else:
            return subquery.c[side.root_fqn]
    else:
        # side a literal value
        return literal(side)


def _recursively_convert_to_sql_filter(
    subquery: FromClause,
    f: FilterParsed,
    *,
    min_now: datetime | None,
    max_now: datetime | None,
    had_givens_batch: bool,
    failed_to_rewrite_features: OrderedSet[
        ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ],
) -> ColumnElement[Any] | None:
    if is_underlying_feature_time(f.lhs) and isinstance(f.rhs, timedelta):
        # If comparing a feature-time feature to a timedelta, that means it was a before() or after()
        if f.lhs.root_fqn not in subquery.c:
            failed_to_rewrite_features.add(f.lhs)
            return
        if f.operation == ">=":
            if min_now is None:
                if had_givens_batch:
                    return sqlalchemy.false()
                else:
                    return
            filter_ts = min_now
            rhs = f.rhs + filter_ts
            return subquery.c[f.lhs.root_fqn] >= rhs
        elif f.operation == "<=":
            if max_now is None:
                if had_givens_batch:
                    return sqlalchemy.false()
                else:
                    return
            filter_ts = max_now
            rhs = f.rhs + filter_ts
            return subquery.c[f.lhs.root_fqn] <= rhs
        elif f.operation == ">":
            if min_now is None:
                if had_givens_batch:
                    return sqlalchemy.false()
                else:
                    return
            filter_ts = min_now
            rhs = f.rhs + filter_ts
            return subquery.c[f.lhs.root_fqn] > rhs
        elif f.operation == "<":
            if max_now is None:
                if had_givens_batch:
                    return sqlalchemy.false()
                else:
                    return
            filter_ts = max_now
            rhs = f.rhs + filter_ts
            return subquery.c[f.lhs.root_fqn] < rhs
        else:
            raise ValueError(f"Unsupported operation: {f.operation}")

    lhs = _recursively_apply_on_side(
        subquery,
        f.lhs,
        min_now=min_now,
        max_now=max_now,
        had_givens_batch=had_givens_batch,
        failed_to_rewrite_features=failed_to_rewrite_features,
    )
    if f.operation == "not":
        assert f.rhs is None
        return None if lhs is None else ~lhs
    rhs = _recursively_apply_on_side(
        subquery,
        f.rhs,
        min_now=min_now,
        max_now=max_now,
        had_givens_batch=had_givens_batch,
        failed_to_rewrite_features=failed_to_rewrite_features,
    )

    if f.operation in ("==", "!=", ">", "<", "<=", ">=", "in", "not in"):
        if lhs is None or rhs is None:
            # Could not rewrite one of the sides, so can't push down the filter
            return
        if f.operation == "==":
            return lhs == rhs
        if f.operation == "!=":
            return lhs != rhs
        if f.operation == ">":
            return lhs > rhs
        if f.operation == "<":
            return lhs < rhs
        if f.operation == "<=":
            return lhs <= rhs
        if f.operation == ">=":
            return lhs >= rhs
        if f.operation == "in":
            return lhs.in_(rhs)
        if f.operation == "not in":
            return lhs.not_in(rhs)
        assert_never(f.operation)

    if f.operation in ("and", "or"):
        # If it's an AND or OR, it's OK if we weren't able to push down one of the sides.
        # Just treat the other side as "true" so we won't drop data
        # Will filter it later
        if lhs is None:
            lhs = true()
        if rhs is None:
            rhs = true()
        if f.operation == "and":
            return lhs & rhs
        if f.operation == "or":
            return lhs | rhs
    raise ValueError(f"Unsupported op: {f.operation}")


def allowed_sql_parameter(x: TPrimitive):
    # Since we're transpiling between sqlglot and sqlalchemy for text queries, we'll be careful and discard any weird types
    # In particular, we avoid filtering using time information, NaN, infinities, structs
    if isinstance(x, (int, str, bool)):
        return True
    if isinstance(x, float):
        return math.isfinite(x)
    if x is None:
        return True
    return False


def _filter_query_side_to_sqlglot(
    rfqn_to_column: Mapping[str, str],
    side: (
        FilterParsed
        | TPrimitive
        | ScalarFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ),
    failed_to_rewrite_features: OrderedSet[
        ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ],
    *,
    min_now: datetime | None,
    max_now: datetime | None,
    had_givens_batch: bool,
    params: dict[str, Any],
    dialect: str | None,
    json_encoded_cols: Optional[FrozenOrderedSet[str]] = None,
) -> (
    sqlglot_expressions.Condition
    | sqlglot_expressions.Placeholder
    | Tuple[sqlglot_expressions.Placeholder | None, ...]
    | None
):
    """
    Params:
        - now: a list of __ts__ values from the givens batch. We must return any row which matches the filter of at least one input to guarantee a weaker condition.
            If None, it means we have inputs but we don't know what they are, so no before() or after() filters should be pushed down
    Returns:
        - If side is a filter, always returns a sqlglot condition. This condition is guaranteed to be weaker than the original filter.
            If None is returned, it means we failed to rewrite the condition, so no filters should be pushed down. (equivalent to true())
        - If side is a feature, returns a sqlglot column, or None if we failed to find such a column
        - If side is a literal, returns either
            - None if we failed to rewrite the literal
            - a sqlglot placeholder for the literal, modifying the params dict
            - a tuple of placeholders, if the literal is a list or tuple. Null values are represented as "None" in this tuple
    """
    # return a condition if side is filter, a column if side is a feature, and a placeholder/null if side is literal (or a collection if a literal collection)
    if isinstance(side, FilterParsed):
        return filter_query_to_sqlglot(
            rfqn_to_column,
            side,
            failed_to_rewrite_features,
            min_now=min_now,
            max_now=max_now,
            had_givens_batch=had_givens_batch,
            params=params,
            json_encoded_cols=json_encoded_cols,
            dialect=dialect,
        )
    elif is_underlying_scalar(side) or is_underlying_feature_time(side):
        # TODO handle the feature time features specially?
        # TODO handle the chalk ts feature specially?
        if side.root_fqn not in rfqn_to_column:
            failed_to_rewrite_features.add(side)
            return None
        else:
            return sqlglot.column(rfqn_to_column[side.root_fqn])
    else:
        # side a literal value
        if isinstance(side, tuple) or isinstance(side, list):  # for lists we need to generate a list of placeholders
            # we immediately add new params after generating parameter names, ensuring that len(params) is always unique
            # allow lists to be arbitrarily long here because their values are hardcoded by the user
            if not all([allowed_sql_parameter(x) for x in side]):
                return None
            has_null = None in side
            deduped_side: Tuple = tuple(set(filter(lambda x: x is not None, side)))  # remove duplicates
            param_names = [f"static_param_{len(params)}_{i}" for i in range(len(deduped_side))]
            for param_name, param_value in zip(param_names, deduped_side):
                assert param_name not in params, "SQL re-writer created duplicate param name"
                params[param_name] = param_value
            expressions: List[sqlglot_expressions.Placeholder | None] = [
                sqlglot_expressions.Placeholder(this=x) for x in param_names
            ]
            if has_null:
                expressions.append(None)
            return tuple(expressions)
        else:
            if not allowed_sql_parameter(cast(TPrimitive, side)):
                return None
            if side is None:
                return sqlglot_expressions.null()
            param_name = f"static_param_{len(params)}"
            assert param_name not in params, "SQL re-writer created duplicate param name"
            params[param_name] = side
            return sqlglot_expressions.Placeholder(this=param_name)


def filter_query_to_sqlglot(
    rfqn_to_column: Mapping[str, str],
    f: FilterParsed,
    failed_to_rewrite_features: OrderedSet[
        ScalarFeatureType | FeatureTimeFeatureType | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ],
    *,
    min_now: datetime | None,
    max_now: datetime | None,
    had_givens_batch: bool,
    params: dict[str, Any],
    dialect: str | None,
    json_encoded_cols: Optional[FrozenOrderedSet[str]] = None,
) -> sqlglot_expressions.Condition:
    """
    Modifies the arguments failed_to_rewrite_features and params for logging and introducing new placeholders
    :param now: The timestamp for before/after filters.
    :param json_encoded_cols: Hacky, these columns are json encoded, so we can still equality comparison by json encoding the filter values
    Guarantees that the resulting condition will be weaker than the original filter
    """
    json_encoded_cols = FrozenOrderedSet() if json_encoded_cols is None else json_encoded_cols
    if (simple_temporal := SimpleTemporalFilter.match(f)) is not None:
        # If comparing a feature to a timedelta, that means it was a before() or after()
        # doesn't have to be a feature time because we could use after with any datetime feature
        if (
            simple_temporal.feature.root_fqn not in rfqn_to_column
            or rfqn_to_column[simple_temporal.feature.root_fqn] in json_encoded_cols
        ):
            failed_to_rewrite_features.add(simple_temporal.feature)
            return sqlglot_expressions.true()
        param_name = f"static_param_{len(params)}"
        assert param_name not in params, "SQL re-writer created duplicate param name"
        rhs = sqlglot_expressions.Placeholder(this=param_name)
        lhs = sqlglot.column(rfqn_to_column[simple_temporal.feature.root_fqn])
        lhs = maybe_cast_to_ts_tz(lhs, dialect)
        if min_now is None or max_now is None:
            if had_givens_batch:
                return sqlglot_expressions.false()
            else:
                return sqlglot_expressions.true()

        # Take min/max of the target times --
        # if we have many 'nows', we can lower bound >= by the least,
        # and vice-versa for upper bounding <= by max.

        if simple_temporal.operation in {">=", ">"}:
            filter_ts = min_now
        else:
            filter_ts = max_now

        # Apply the timedelta to the 'now' value.
        params[param_name] = simple_temporal.timedelta + filter_ts

        # Apply the filter.
        if simple_temporal.operation == ">=":
            return lhs >= rhs
        elif simple_temporal.operation == "<=":
            return lhs <= rhs
        elif simple_temporal.operation == ">":
            return lhs > rhs
        elif simple_temporal.operation == "<":
            return lhs < rhs
        else:
            assert_never(simple_temporal.operation)

    lhs = _filter_query_side_to_sqlglot(
        rfqn_to_column,
        f.lhs,
        failed_to_rewrite_features,
        min_now=min_now,
        max_now=max_now,
        params=params,
        had_givens_batch=had_givens_batch,
        json_encoded_cols=json_encoded_cols,
        dialect=dialect,
    )
    if f.operation == "not":
        # this function guarantees a weaker filter than original, recursively f.lhs may be weaker than original,
        # which would make ~f.lhs stronger. So instead we push no filter
        return sqlglot_expressions.true()
    rhs = _filter_query_side_to_sqlglot(
        rfqn_to_column,
        f.rhs,
        failed_to_rewrite_features,
        min_now=min_now,
        max_now=max_now,
        params=params,
        had_givens_batch=had_givens_batch,
        json_encoded_cols=json_encoded_cols,
        dialect=dialect,
    )

    if f.operation in ("==", "!=", ">", "<", "<=", ">=", "in", "not in"):
        op = f.operation
        if lhs is None or rhs is None:
            # Could not rewrite one of the sides, so can't push down the filter
            return sqlglot_expressions.true()
        if isinstance(lhs, tuple):
            return sqlglot_expressions.true()
        if isinstance(lhs, sqlglot_expressions.Placeholder):
            if isinstance(rhs, sqlglot_expressions.Placeholder) or isinstance(rhs, tuple):
                return sqlglot_expressions.true()
            if op == "in" or op == "not in":
                return sqlglot_expressions.true()
            op = {"==": "==", "!=": "!=", ">": "<", "<": ">", "<=": ">=", ">=": "<="}[op]
            lhs, rhs = rhs, lhs
        is_json = isinstance(lhs, sqlglot_expressions.Column) and lhs.name in json_encoded_cols
        if isinstance(rhs, sqlglot_expressions.Null):
            if is_json:
                param_name = f"static_param_{len(params)}"
                assert param_name not in params, "SQL re-writer created duplicate param name"
                params[param_name] = "null"
                rhs = sqlglot_expressions.Placeholder(this=param_name)
                if op == "==":
                    return lhs.eq(rhs)
                if op == "!=":
                    return lhs.neq(rhs)
            else:
                if op == "==":
                    return lhs.is_(rhs)
                if op == "!=":
                    return lhs.is_(rhs).not_()
            return sqlglot_expressions.true()
        elif isinstance(rhs, tuple):
            if isinstance(lhs, sqlglot_expressions.Column) and lhs.this in json_encoded_cols:
                return sqlglot_expressions.true()
            has_null = None in rhs
            rhs_filtered = tuple(x for x in rhs if x is not None)
            if is_json:
                for item in rhs_filtered:
                    assert isinstance(item.this, str)
                    params[item.this] = json.dumps(params[item.this])
            in_expr = lhs.isin(*rhs_filtered)
            if has_null:
                if is_json:
                    param_name = f"static_param_{len(params)}"
                    assert param_name not in params, "SQL re-writer created duplicate param name"
                    params[param_name] = "null"
                    in_expr = in_expr | lhs.eq(sqlglot_expressions.Placeholder(this=param_name))
                else:
                    in_expr = in_expr | lhs.is_(sqlglot_expressions.Null())
            if op == "in":
                return in_expr
            if op == "not in":
                return in_expr.not_()
            return sqlglot_expressions.true()
        else:
            if is_json:
                if op not in ("==", "!="):
                    # can only do equality comparison on json encoded columns
                    return sqlglot_expressions.true()
                assert isinstance(rhs.this, str)
                params[rhs.this] = json.dumps(params[rhs.this])
            if op == "==":
                return lhs.eq(rhs)
            if op == "!=":
                return lhs.neq(rhs)
            if op == ">":
                return lhs > rhs
            if op == "<":
                return lhs < rhs
            if op == "<=":
                return lhs <= rhs
            if op == ">=":
                return lhs >= rhs
            return sqlglot_expressions.true()

    if f.operation in ("and", "or"):
        if (
            isinstance(lhs, sqlglot_expressions.Placeholder)
            or isinstance(rhs, sqlglot_expressions.Placeholder)
            or isinstance(lhs, tuple)
            or isinstance(rhs, tuple)
            or lhs is None
            or rhs is None
        ):
            # The side is guaranteed to be a sqlglot expression if it's a filter. Non-filters doesn't make sense.
            return sqlglot_expressions.true()
        if f.operation == "and":
            return lhs & rhs
        if f.operation == "or":
            return lhs | rhs

    # we don't know how to filter this
    return sqlglot_expressions.true()


def maybe_cast_to_ts_tz(expression: sqlglot.Expression, dialect: str | None) -> sqlglot.Expression:
    # SQLite does not have date or time types, so we need to avoid naively casting to numeric.
    # In addition, if in postgres AND skip_datetime_timezone_cast is set in the PostgresQueryExecutionParams,
    # also do nothing
    if dialect == "sqlite" or (dialect == "postgres" and env_var_bool("CHALK_SKIP_PG_DATETIME_ZONE_CAST")):
        return expression
    return sqlglot_expressions.cast(expression, sqlglot_expressions.DataType.Type.TIMESTAMPTZ)


def _remove_unknown_features_from_filter(
    filt: FilterParsed, known_root_fqns: Collection[str]
) -> tuple[FilterParsed | None, bool]:
    """
    Goes through a filter and removes references to features that are not present in `known_root_fqns`.
    Some SQL sources (e.g. BigQuery) error if they are given parameters that are not actually used in the query.

    If the filter is invalid e.g. `(unknown_feature < 3)`, returns None
    If the filter is valid but has some invalid sub-filters, returns a *more general filter* (i.e. one that represents a *superset* of values of the original filter).
    For example, for filter `A AND B`, if A is invalid we can return just `B`. For `A OR B`, if A is invalid the whole filter is invalidated since `B` would be too strict.

    :param filt: A filter that we would like to push down into a query
    :param known_root_fqns: Set of FQNs to check
    :return: None or a modified, less strict filter.
    """
    lhs = filt._lhs  # pyright: ignore[reportPrivateUsage]
    rhs = filt._rhs  # pyright: ignore[reportPrivateUsage]
    op = filt.operation

    if op in ("and", "not", "or"):
        lhs_modified = False
        rhs_modified = False

        if isinstance(lhs, FilterParsed):
            lhs, lhs_modified = _remove_unknown_features_from_filter(lhs, known_root_fqns)
        else:
            raise ValueError(f"Expected left-hand side of '{op}' filter to be a sub-filter, instead got: {lhs}")

        if isinstance(rhs, FilterParsed):
            rhs, rhs_modified = _remove_unknown_features_from_filter(rhs, known_root_fqns)
        elif op != "not":
            raise ValueError(f"Expected right-hand side of '{op}' filter to be a sub-filter, instead got: {rhs}")
        assert rhs is None or isinstance(rhs, FilterParsed)  # for pyright

        if not (lhs_modified or rhs_modified):
            return filt, False

        if op == "and":
            match (lhs, rhs):
                case (None, _):
                    return rhs, True
                case (_, None):
                    return lhs, True
                case _:
                    return FilterParsed(lhs=lhs, rhs=rhs, operation=op), True
        elif op == "or":
            # If one sub-filter is invalid, we can't just apply the other sub-filter because it would be too strict.
            # So instead, mark the whole filter as invalid
            if lhs is None or rhs is None:
                return None, True
            return FilterParsed(lhs=lhs, rhs=rhs, operation=op), True
        elif op == "not":
            if rhs is not None:
                raise ValueError(f"Received filter with operation={op} but right-hand side is not None: {rhs=}")
            # At this point we know `lhs` was modified, meaning it's more general, so the negatin would be more _strict_.
            # Instead, mark the whole filter as invalid.
            assert lhs_modified
            return None, True
        else:
            raise ValueError(f"Unexpected filter operation: {op}")
    else:
        if isinstance(lhs, FilterParsed):
            raise ValueError(
                f"Failed to process filter during query rewriting: operation is {op} but left-hand-side is a sub-filter: {lhs}"
            )
        if isinstance(lhs, FilterParsed):
            raise ValueError(
                f"Failed to process filter during query rewriting: operation is {op} but right-hand-side is a sub-filter: {rhs}"
            )
        for side in [lhs, rhs]:
            if isinstance(side, (NamedFeatureType, FeatureFqnMarker)) and side.root_fqn not in known_root_fqns:
                return None, True
        return filt, False


@dataclasses.dataclass(frozen=True, kw_only=True)
class StaticFilterQueryRewriter(QueryRewriter):
    f: FilterParsed
    min_now: datetime | None
    max_now: datetime | None
    had_givens_batch: bool

    def __call__(self, chalk_query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        with safe_trace("static_filter_rewrite"):
            assert isinstance(chalk_query.source, BaseSQLSource)
            span = get_current_span()
            span.set_attribute("filter", self.f.pprint())
            if isinstance(chalk_query.query, SelectBase):
                # TODO look at the chalk_query.fields to see if we can use that?
                sq = chalk_query.query.subquery()
                failed_to_rewrite_features: OrderedSet[
                    ScalarFeatureType
                    | FeatureTimeFeatureType
                    | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
                ] = OrderedSet()
                sql_filter = _recursively_convert_to_sql_filter(
                    sq,
                    self.f,
                    min_now=self.min_now,
                    max_now=self.max_now,
                    had_givens_batch=self.had_givens_batch,
                    failed_to_rewrite_features=failed_to_rewrite_features,
                )
                if len(failed_to_rewrite_features) > 0:
                    _logger.warning(
                        "Failed to rewrite the following features as they were not found in the query: %s",
                        ", ".join(f"'{x.root_fqn}'" for x in failed_to_rewrite_features),
                    )
                new_q = select(sq)
                if sql_filter is not None:
                    new_q = new_q.filter(sql_filter)
                return FinalizedChalkQuery(
                    query=new_q,
                    params=chalk_query.params,
                    finalizer=chalk_query.finalizer,
                    incremental_settings=chalk_query.incremental_settings,
                    source=chalk_query.source,
                    fields=chalk_query.fields,
                    temp_tables=chalk_query.temp_tables,
                    is_empty=chalk_query.is_empty,
                )

            elif isinstance(chalk_query.query, TextClause):  # pyright: ignore[reportUnnecessaryIsInstance]
                try:
                    chalk_query_normalized = to_sqlglot(chalk_query)
                except Exception:
                    return chalk_query
                new_sql_query = sqlglot.select("*").from_(
                    sqlglot_expressions.alias_(chalk_query_normalized, "temp_table_for_static_filter")
                )
                failed_to_rewrite_features: OrderedSet[
                    ScalarFeatureType
                    | FeatureTimeFeatureType
                    | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
                ] = OrderedSet()
                params = dict(chalk_query.params)
                rfqn_to_column = {v.root_fqn: k for k, v in chalk_query.fields.items()}
                filter_cleaned, was_modified = _remove_unknown_features_from_filter(self.f, rfqn_to_column.keys())
                if was_modified:
                    _logger.debug(f"Removed some features not mentioned in the query: {filter_cleaned=}")
                if filter_cleaned is None:
                    _logger.debug(
                        "Skipping filter rewriting since all clauses refer to columns not present in the query."
                    )
                    return chalk_query
                try:
                    sql_filter = filter_query_to_sqlglot(
                        rfqn_to_column,
                        filter_cleaned,
                        failed_to_rewrite_features,
                        min_now=self.min_now,
                        max_now=self.max_now,
                        had_givens_batch=self.had_givens_batch,
                        params=params,
                        dialect=chalk_query.source.get_sqlglot_dialect(),
                    )
                except Exception:
                    _logger.error(f"Failed to push filter down into {chalk_query.query}", exc_info=True)
                    return chalk_query
                if len(failed_to_rewrite_features) > 0:
                    _logger.warning(
                        "Failed to rewrite the following features as they were not found in the query: %s",
                        ", ".join(f"'{x.root_fqn}'" for x in failed_to_rewrite_features),
                    )
                new_sql_query = new_sql_query.where(sql_filter)
                return FinalizedChalkQuery(
                    query=sqlalchemy.text(new_sql_query.sql(dialect=chalk_query.source.get_sqlglot_dialect())),
                    params=params,
                    finalizer=chalk_query.finalizer,
                    incremental_settings=chalk_query.incremental_settings,
                    source=chalk_query.source,
                    fields=chalk_query.fields,
                    temp_tables=chalk_query.temp_tables,
                    is_empty=chalk_query.is_empty,
                )

            return chalk_query


def prepare_pushdown_query(
    chalk_query: FinalizedChalkQuery,
    *,
    lower_bound: datetime | None,
    upper_bound: datetime | None,
    override_lower_upper_bound_feature: ScalarFeatureType | FeatureTimeFeatureType | None,
    max_samples: int | None,
) -> tuple[dict[str, object], str]:
    # We will need to interpolate the bounds into the new SQL query. We list them here.
    # Any existing parameters must be preserved, otherwise it couldn't execute.
    new_sql_params: dict[str, object] = dict(chalk_query.params)
    # Create the new SQL string, which will include the new parameters.
    # Start by parsing the original SQL so it can be composed.
    assert isinstance(chalk_query.source, (BaseSQLSource, SQLSourceGroup))
    dialect = chalk_query.source.get_sqlglot_dialect()
    assert isinstance(chalk_query.query, TextClause)
    original_sql: sqlglot.Expression = sqlglot.parse_one(chalk_query.query.text, read=dialect)
    # Wrap the SQL in a CTE, using a temporary table.
    # We "SELECT *" from that table to obtain all of its existing columns.
    temporary_table_name = "temp_table_for_time_bounds_filter_pushdown"
    wrapping_sql = sqlglot.select("*").with_(temporary_table_name, as_=original_sql)
    wrapping_sql = wrapping_sql.from_(temporary_table_name)  # pyright: ignore -- pyright doesn't know about from_
    try:
        if override_lower_upper_bound_feature is not None:
            feat = override_lower_upper_bound_feature.to_feature()
            ts_feature_name = next(key for key, value in chalk_query.fields.items() if feat == value)
        else:
            # We need to filter based on the timestamp feature.
            ts_feature_name = _find_ts_feature(chalk_query.fields)

        # Next, add a `WHERE` clause for each of the given identifiers. We just pass in placeholders here.
        if lower_bound is not None:
            # If the lower bound is specified, it must be added as a parameter to the sql.
            assert LOWER_BOUND_SQL_PARAMETER_NAME not in new_sql_params
            new_sql_params[LOWER_BOUND_SQL_PARAMETER_NAME] = str(lower_bound)
            placeholder = maybe_cast_to_ts_tz(
                sqlglot_expressions.Placeholder(this=LOWER_BOUND_SQL_PARAMETER_NAME), dialect=dialect
            )
            wrapping_sql = wrapping_sql.where(sqlglot.condition(sqlglot.column(ts_feature_name)) >= placeholder)
        if upper_bound is not None:
            # If the upper bound is specified, it must be added as a parameter to the sql.
            assert UPPER_BOUND_SQL_PARAMETER_NAME not in new_sql_params
            new_sql_params[UPPER_BOUND_SQL_PARAMETER_NAME] = str(upper_bound)
            placeholder = maybe_cast_to_ts_tz(
                sqlglot_expressions.Placeholder(this=UPPER_BOUND_SQL_PARAMETER_NAME), dialect=dialect
            )
            wrapping_sql = wrapping_sql.where(sqlglot.condition(sqlglot.column(ts_feature_name)) <= placeholder)
    except StopIteration:
        # No feature time
        pass
    if max_samples is not None:
        wrapping_sql = wrapping_sql.limit(max_samples)
    new_sql_string = wrapping_sql.sql(dialect=dialect)
    return new_sql_params, new_sql_string


class NoOpQueryRewriter(QueryRewriter):
    def __call__(self, chalk_query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        return chalk_query


_GIVENS_QUERY_REWRITER_TEMP_TABLE_ADDITIONAL_FILTER_BUFFER = 100
_GIVENS_QUERY_REWRITER_TEMP_TABLE_ADDITIONAL_TEXT_BUFFER = 1000


@dataclasses.dataclass(frozen=True)
class GivensQueryRewriter(QueryRewriter):
    """
    Rewrites the given (text) sql query with an additional WHERE clause to filter down to only
    those rows matching the values specified in the givens.
    """

    givens_scalars: ChalkRecordBatch | None
    join_columns: tuple[str, ...]

    def _corresponding_join_column_idx(self, idx: int) -> int:
        join_col_size = len(self.join_columns)
        return (idx + join_col_size // 2) % join_col_size

    @staticmethod
    def _requires_temp_table_pushdown(
        chalk_query: FinalizedChalkQuery,
        filter_values: list[Any],
    ):
        assert isinstance(chalk_query.source, (BaseSQLSource, SQLSourceGroup))

        if env_var_bool("CHALK_TESTING_FORCE_TEMP_TABLE_PUSHDOWN"):
            return True

        text_filter_limit = 100_000 if isinstance(chalk_query.source, AthenaSourceImpl) else None
        filter_limit = 75_000 if isinstance(chalk_query.source, PostgreSQLSourceImpl) else 10_000
        text_filter_limit_with_buffer = (
            text_filter_limit - _GIVENS_QUERY_REWRITER_TEMP_TABLE_ADDITIONAL_TEXT_BUFFER
            if text_filter_limit is not None
            else None
        )
        filter_limit_with_buffer = filter_limit - _GIVENS_QUERY_REWRITER_TEMP_TABLE_ADDITIONAL_FILTER_BUFFER
        return len(filter_values) > filter_limit_with_buffer or (
            text_filter_limit_with_buffer is not None
            and sum(len(str(value)) for value in filter_values) > text_filter_limit_with_buffer
        )

    def __call__(self, chalk_query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        if self.givens_scalars is None:
            return chalk_query

        with statsd.distributed("chalk.engine.sql.givens_filter_rewrite"):
            if not isinstance(chalk_query.query, TextClause):
                # TODO: Allow us to push filters into non-text queries.
                return chalk_query

            assert isinstance(chalk_query.source, (BaseSQLSource, SQLSourceGroup))
            try:
                chalk_query_normalized = to_sqlglot(chalk_query)
            except Exception as e:
                _logger.error(
                    f"Failed to parse client SQL expression in order to perform filter value pushdown: {e}, query = {repr(chalk_query.query.text)}"
                )
                return chalk_query

            givens_list = self.givens_scalars.to_pydict()
            span = get_current_span()
            span.set_attribute("number_of_pushdown_givens_rows", len(givens_list))

            # We want to find out which columns we can filter by. If possible, we won't just use
            # primary keys, although these are obviously ideal, it's better to use everything available.

            # To use a column, it must be a given feature and it must have a valid scalar type
            # and be an output of this SQL resolver.
            can_filter_columns: list[tuple[str, str, list[Any]]] = []
            for sql_output_column, corresponding_output_feature in chalk_query.fields.items():
                if not corresponding_output_feature.is_scalar:
                    # We can only filter by scalar features.
                    continue
                if corresponding_output_feature.is_feature_time:
                    # We can't filter the feature time by value.
                    continue
                corresponding_output_feature_root_fqn = corresponding_output_feature.root_fqn
                if (
                    corresponding_output_feature_root_fqn not in givens_list
                    and corresponding_output_feature_root_fqn in self.join_columns
                ):
                    assert len(self.join_columns) % 2 == 0, "Expected even number of join columns"
                    # Pick the other join column: find the location of this join column, and pick its corresponding
                    # index.
                    # FIXME: Only do this if the join is equality
                    local_fqn_idx = self.join_columns.index(corresponding_output_feature_root_fqn)
                    foreign_fqn_idx = self._corresponding_join_column_idx(local_fqn_idx)
                    corresponding_output_feature_root_fqn = self.join_columns[foreign_fqn_idx]
                if corresponding_output_feature_root_fqn not in givens_list:
                    # If we don't have the feature as a given, we cannot filter by it.
                    continue
                given_values = givens_list[corresponding_output_feature_root_fqn]
                can_filter_columns.append((sql_output_column, corresponding_output_feature_root_fqn, given_values))

            if len(can_filter_columns) == 0:
                # Since we don't have any columns that we can filter on, can_filter_columnsdo nothing.
                return chalk_query

            # We will have to add multiple new sql query parameters, but we also want to retain
            # any existing ones. Create a new dictionary of the parameters.
            new_sql_params = dict(chalk_query.params)

            new_temp_tables = dict(chalk_query.temp_tables)

            # The new query uses the original query as a table expression, so that we
            # can filter it down without changing its columns' values.
            new_sql_query = sqlglot.select("*").from_(
                sqlglot_expressions.alias_(chalk_query_normalized, "temp_table_for_value_pushdown")
            )
            successfully_filtered = False

            # Only these types will be filtered.
            # Floats are currently excluded because of NaN.
            # None is excluded because of SQL 'NULL' behavior being undesirable.
            # If any value in a given's list doesn't belong to these types, the filter
            # for that column is skipped entirely.
            FILTERABLE_TYPES = {str, int, bool}
            empty_query = False

            span.set_attribute("number_of_pushdown_eligible_columns", len(can_filter_columns))
            for filter_sql_column, filter_feature, filter_values in can_filter_columns:
                if len(filter_values) == 0:
                    # If we have no filter values, this means that we would drop all returned data
                    # adding "where False"
                    new_sql_query = new_sql_query.where("False")
                    successfully_filtered = True
                    empty_query = True
                    break  # there's no need to keep filtering since we already dropped all data

                # there are scary values like missing or unknown in the column, so cannot filter
                filter_metadata = to_pylist(self.givens_scalars.column(get_metadata_col_name(filter_feature)))
                scary_values = False
                has_null = False
                for x, x_metadata in zip(filter_values, filter_metadata):
                    assert x_metadata is None or isinstance(x_metadata, int)
                    if x is None:
                        has_null = True
                        if (
                            x_metadata is None
                            or parse_metadata_value(x_metadata, None)[0] == ResultMetadataSourceType.MISSING
                            or parse_metadata_value(x_metadata, None)[0] == ResultMetadataSourceType.UNKNOWN
                        ):
                            scary_values = True
                            break
                if scary_values:
                    continue
                retrieve_null = has_null and filter_feature not in self.join_columns

                filter_values = [x for x in filter_values if x is not None]

                if len(filter_values) == 0:
                    # Get just nulls
                    assert has_null, "Shouldn't be here because we already handled empty givens"
                    if retrieve_null:
                        new_sql_query = new_sql_query.where(f"{filter_sql_column} IS NULL")
                    else:
                        new_sql_query = new_sql_query.where("False")
                        empty_query = True
                    successfully_filtered = True

                elif len(filter_values) == 1:
                    # Get the only filter value.
                    filter_value = filter_values[0]

                    if type(filter_value) not in FILTERABLE_TYPES:
                        continue

                    # Generate a "WHERE column = :val" clause.

                    filter_param = f"{filter_sql_column}_filter_value"
                    where_clause = f"{filter_sql_column} = :{filter_param}"
                    if retrieve_null:
                        where_clause = f"({where_clause}) OR {filter_sql_column} IS NULL"
                    new_sql_query = new_sql_query.where(where_clause)
                    assert filter_param not in new_sql_params  # It should not already be used, or we have a problem.
                    new_sql_params[filter_param] = filter_value

                    # We added a new filter successfully.
                    successfully_filtered = True
                else:
                    # There are multiple filter values.
                    if not all(type(value) in FILTERABLE_TYPES for value in filter_values):
                        # One of the values is not going to serialize successfully.
                        continue
                    # deduplicate because we have a WHERE IN clause
                    filter_values = list(set(filter_values))
                    if self._requires_temp_table_pushdown(chalk_query, filter_values):
                        use_temp_tables = env_var_bool("CHALK_USE_TEMP_TABLES_FOR_PUSH_DOWN_FILTERS")
                        # For snowflake queries, we put the values into a new temp table and join on it.
                        # I only implemented this for snowflake, we change the line below after implementing temp tables for other sources
                        if (
                            isinstance(
                                chalk_query.source,
                                (BigQuerySourceImpl, SnowflakeSourceImpl, AthenaSourceImpl, DatabricksSourceImpl),
                            )
                            and use_temp_tables
                        ):
                            temp_table_name = "temp_" + str(uuid.uuid4()).replace("-", "_")[:63]
                            if temp_table_name in new_temp_tables:
                                raise ValueError("This shouldn't happen since each temp table has a unique id.")
                            if all([isinstance(value, int) for value in filter_values]):
                                sqlalchemy_type: TypeEngine = sqlalchemy.Integer()
                            elif all([isinstance(value, str) for value in filter_values]):
                                sqlalchemy_type = sqlalchemy.String()
                            elif all([isinstance(value, bool) for value in filter_values]):
                                raise RuntimeError(
                                    "Shouldn't get here. There are only 2 booleans, cannot have 10_000 values."
                                )
                            else:
                                continue  # couldn't find one type for all values

                            # For BigQuery, qualify temp table names with project.dataset so
                            # that references resolve correctly when temp tables live in a
                            # different dataset from the source tables.
                            temp_table_schema = None
                            if isinstance(chalk_query.source, BigQuerySourceImpl):
                                tp = chalk_query.source.temp_project or chalk_query.source.project
                                td = chalk_query.source.temp_dataset or chalk_query.source.dataset
                                if tp and td:
                                    temp_table_schema = f"{tp}.{td}"

                            temp_table_ref = (
                                f'"{temp_table_schema}"."{temp_table_name}"'
                                if temp_table_schema
                                else f'"{temp_table_name}"'
                            )
                            where_clause = f'{filter_sql_column} IN (SELECT "value" FROM {temp_table_ref})'

                            metadata = sqlalchemy.MetaData(schema=temp_table_schema)

                            if not env_var_bool("CHALK_RETAIN_PUSHDOWN_TEMP_TABLES"):
                                # we prepare all the queries here so the code in chalk/ doesn't have a dependency on sqlalchemy
                                temp_table_prefixes = []
                                if isinstance(chalk_query.source, SnowflakeSourceImpl):
                                    temp_table_prefixes = ["TEMPORARY"]
                                elif isinstance(chalk_query.source, BigQuerySourceImpl):
                                    # BQ TEMPORARY tables are session-scoped; each BQ job is a separate session,
                                    # so the temp table wouldn't be visible to the main query job.
                                    temp_table_prefixes = []
                                elif isinstance(chalk_query.source, AthenaSourceImpl):
                                    temp_table_prefixes = ["EXTERNAL"]
                            else:
                                # retain temp tables for debugging if CHALK_RETAIN_PUSHDOWN_TEMP_TABLES=1
                                temp_table_prefixes = []

                            temp_table = sqlalchemy.Table(
                                # avoid name normalization since it's not consistent across API (e.g. snowflake normalized string queries, but not the write_pandas function)
                                quoted_name(temp_table_name, quote=True),
                                metadata,
                                sqlalchemy.Column(quoted_name("value", quote=True), sqlalchemy_type),
                                prefixes=temp_table_prefixes,
                            )

                            new_temp_tables[temp_table_name] = (
                                {"value": sqlalchemy_type},
                                pa.Table.from_pydict({"value": pa.array(filter_values)}),
                                CreateTable(temp_table),
                                temp_table,
                                DropTable(temp_table),
                            )
                            new_sql_query = new_sql_query.where(where_clause)
                            if retrieve_null:
                                where_clause = f"({where_clause}) OR {filter_sql_column} IS NULL"
                            successfully_filtered = True
                        else:
                            # There are too many values, so don't bother filtering them.
                            if env_var_bool("CHALK_DISABLE_SILENT_PUSHDOWN_FAILURE", False):
                                raise ValueError("Failed to add filters to query.")

                    else:
                        # Generate a "WHERE column in (:val1, :val2, :val3, :val4)" clause.

                        # We need a separate sql parameter for each slot in the set of options.
                        filter_parameters = [
                            f"{filter_sql_column}_filter_value_{index}" for index in range(len(filter_values))
                        ]

                        for filter_param, filter_value in zip(filter_parameters, filter_values):
                            # Record the value in the parameters map.
                            assert (
                                filter_param not in new_sql_params
                            )  # It should not already be used, or we have a problem.
                            new_sql_params[filter_param] = filter_value

                        where_clause = f"{filter_sql_column} in ({', '.join(':' + filter_parameter for filter_parameter in filter_parameters)})"
                        if retrieve_null:
                            where_clause = f"({where_clause}) OR {filter_sql_column} IS NULL"
                        new_sql_query = new_sql_query.where(where_clause)

                        # We added a new filter successfully.
                        successfully_filtered = True

            if not successfully_filtered:
                # We didn't successfully add any filters to the query.
                # Therefore, there's no point in applying this transform.
                return chalk_query

            # Return the transformed query.
            # The `query` and `params` fields are updated, but everything else is the same.
            return FinalizedChalkQuery(
                query=sqlalchemy.text(new_sql_query.sql(dialect=chalk_query.source.get_sqlglot_dialect())),
                params=new_sql_params,
                finalizer=chalk_query.finalizer,
                incremental_settings=chalk_query.incremental_settings,
                source=chalk_query.source,
                fields=chalk_query.fields,
                temp_tables=new_temp_tables,
                is_empty=chalk_query.is_empty or empty_query,
            )


def _find_ts_feature(fields: Mapping[str, Union[Feature[Any, Any], Any]]):
    return next(key for key, value in fields.items() if value.is_feature_time)


@dataclasses.dataclass(frozen=True)
class DropFieldsRewriter(QueryRewriter):
    """
    rewrites a query to only return the desired fields
    :param desired_fqns: uses root fqns
    """

    desired_fqns: FrozenOrderedSet[str]

    def __call__(self, chalk_query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        if not isinstance(chalk_query.query, TextClause):
            # unsupported
            return chalk_query
        try:
            normalized_query = to_sqlglot(chalk_query)
        except Exception as e:
            _logger.error(
                f"Failed to parse client SQL expression in order to perform filter value pushdown: {e}, query = {repr(chalk_query.query.text)}"
            )
            return chalk_query
        if not self.desired_fqns.issubset({f.root_fqn for f in chalk_query.fields.values()}):
            # we can't rewrite if we don't know what column names we're looking for
            return chalk_query
        # FIXME (CHA-2768) We have a bug in the planner where we don't always include the feature time feature as a desired feature
        desired_fields = [
            field
            for field, feature in chalk_query.fields.items()
            if feature.root_fqn in self.desired_fqns or feature.is_feature_time
        ]
        if len(desired_fields) == 0:
            _logger.warning(
                "Tried to run a sql query but we are dropping its results. This is certainly a bug. Query: %s",
                chalk_query.query.text,
            )
            return chalk_query
        new_chalk_query = sqlglot.select(*[to_identifier(field) for field in desired_fields]).from_(
            sqlglot_expressions.alias_(normalized_query, "temp_table_for_drop_fields")
        )
        assert isinstance(chalk_query.source, (BaseSQLSource, SQLSourceGroup))
        return FinalizedChalkQuery(
            query=sqlalchemy.text(new_chalk_query.sql(dialect=chalk_query.source.get_sqlglot_dialect())),
            params=chalk_query.params,
            finalizer=chalk_query.finalizer,
            incremental_settings=chalk_query.incremental_settings,
            source=chalk_query.source,
            fields={
                field: feature for field, feature in chalk_query.fields.items() if feature.root_fqn in self.desired_fqns
            },
            temp_tables=chalk_query.temp_tables,
            is_empty=chalk_query.is_empty,
        )


@dataclasses.dataclass(frozen=True)
class LimitOffsetQueryRewriter(QueryRewriter):
    """
    Rewrites a query to apply a limit and/or offset. While we do have the contextual query rewriter with max samples
    which can apply a limit, that one is more for "how do we rewrite the root operator in an offline query".
    This one can be used more generally to apply a limit/offset to any query.
    """

    MAX_LIMIT_OFFSET: ClassVar[int] = 2**31 - 1
    limit: Optional[int]
    offset: Optional[int]

    def __post_init__(self):
        if self.limit is not None and self.limit < 0:
            raise ValueError("limit must be non-negative or None")
        if self.limit is not None and self.limit > self.MAX_LIMIT_OFFSET:
            raise ValueError(f"limit must be less than {self.MAX_LIMIT_OFFSET}")
        if self.offset is not None and self.offset < 0:
            raise ValueError("offset must be non-negative or None")
        if self.offset is not None and self.offset > self.MAX_LIMIT_OFFSET:
            raise ValueError(f"offset must be less than {self.MAX_LIMIT_OFFSET}")

    def __call__(self, chalk_query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        if not isinstance(chalk_query.query, TextClause):
            # TODO: Allow us to push filters into non-text queries.
            return chalk_query
        try:
            normalized_query = to_sqlglot(chalk_query)
        except Exception as e:
            _logger.error(
                f"Failed to parse client SQL expression in order to perform filter value pushdown: {e}, query = {repr(chalk_query.query.text)}"
            )
            return chalk_query
        new_sql_query = sqlglot.select("*").from_(
            sqlglot_expressions.alias_(normalized_query, "temp_table_for_limit_offset")
        )
        if self.limit is not None:
            new_sql_query = new_sql_query.limit(self.limit)
        if self.offset is not None:
            new_sql_query = new_sql_query.offset(self.offset)

        assert isinstance(chalk_query.source, (BaseSQLSource, SQLSourceGroup))
        return FinalizedChalkQuery(
            query=sqlalchemy.text(new_sql_query.sql(dialect=chalk_query.source.get_sqlglot_dialect())),
            params=chalk_query.params,
            finalizer=chalk_query.finalizer,
            incremental_settings=chalk_query.incremental_settings,
            source=chalk_query.source,
            fields=chalk_query.fields,
            temp_tables=chalk_query.temp_tables,
            is_empty=chalk_query.is_empty,
        )
