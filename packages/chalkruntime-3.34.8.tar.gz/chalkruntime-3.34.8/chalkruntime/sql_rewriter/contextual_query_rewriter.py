from __future__ import annotations

import dataclasses
from datetime import datetime

import sqlalchemy
from chalk.sql import FinalizedChalkQuery
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from datadog import statsd
from sqlalchemy.sql.elements import TextClause

from chalkruntime.graph.feature import FeatureTimeFeatureType, ScalarFeatureType
from chalkruntime.sql_rewriter.filter_query_rewriter import (
    prepare_pushdown_query,
)
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter


@dataclasses.dataclass(frozen=True)
class ContextualQueryRewriter(QueryRewriter):
    givens: ChalkRecordBatch | None
    observed_at_lower_bound_value: datetime | None
    observed_at_upper_bound_value: datetime | None
    override_lower_upper_bound_feature: ScalarFeatureType | FeatureTimeFeatureType | None
    max_samples: int | None

    def __call__(self, chalk_query: FinalizedChalkQuery, resolver_id: str) -> FinalizedChalkQuery:
        """
        We have to edit the TextClause with new filter inputs by hand by editing the text itself, sadly.
        Things to consider:
            What if there are multiple resolvers? This can happen if the following is true.
                    query is featureclass.id -> featureclass.a, featureclass.b
                    resolver 1 goes from featureclass.id -> featureclass.a
                    resolver 2 goes from featureclass.id -> featureclass.b
                This should be extremely unlikely in the case of SQL resolvers,
                but we should push the same filters to all resolvers

            What if there are multiple inputs? We'll know by inspecting givens.schema.
                We simply add multiple filters (multiple where and clauses).

            What if there are multiple pkeys? If so, givens.result.to_pylist() will be
                a list of multiple pkeys. In that case, we may have to do an "in" SQL statement.
                We should be aware that the batch of givens could be long.

            new_sql_query = sqlglot.select("*").from_(
                sqlglot_expressions.alias_(chalk_query_normalized, "temp_table_for_value_pushdown")

            When should we push down filters? For now, we'll check if the query is a TextClause.
                In that case, we are sure it is SQL string query.
                We should also check chalk_query.source for some boolean flag.
                Lastly, we should only do this when there are no inputs to the resolver.

        Parameters
        ----------
        chalk_query: FinalizedChalkQuery
            chalk_query.query should be a sqlalchemy TextClause.
            chalk_query.source is our BaseSQLSource
            chalk_query.params must be updated to include filters

        Returns
        -------
        FinalizedChalkQuery

        """
        with statsd.distributed("chalk.engine.sql.time_bounds_filter_rewrite"):
            # TODO if not chalk_query.source.push_query_filters: return chalk_query

            # only supporting text queries for now
            if not isinstance(chalk_query.query, TextClause):
                return chalk_query

            # shouldn't apply max samples if there are givens
            maybe_max_samples = self.max_samples if self.givens is None else None

            if (
                self.observed_at_lower_bound_value is None
                and self.observed_at_upper_bound_value is None
                and maybe_max_samples is None
            ):
                # Since no bounds are provided, we don't have any way to meaningfully transform this query.
                return chalk_query

            new_sql_params, new_sql_string = prepare_pushdown_query(
                chalk_query,
                lower_bound=self.observed_at_lower_bound_value,
                upper_bound=self.observed_at_upper_bound_value,
                override_lower_upper_bound_feature=self.override_lower_upper_bound_feature,
                max_samples=maybe_max_samples,
            )

            # Pass in the new query and params to the query, keeping the rest the same.
            return FinalizedChalkQuery(
                query=sqlalchemy.text(new_sql_string),
                params=new_sql_params,
                finalizer=chalk_query.finalizer,
                incremental_settings=chalk_query.incremental_settings,
                source=chalk_query.source,
                fields=chalk_query.fields,
                temp_tables=chalk_query.temp_tables,
                is_empty=chalk_query.is_empty,
            )
