import functools
from collections import defaultdict
from threading import Lock
from typing import Any, Sequence

# Sqlglot uses lazy imports extensively internally.
# This causes rare deadlocks when its functions are run concurrently
# from multiple threads. To try to mitigate this, we load every
# module eagerly up-front here.
import sqlglot
from chalk.features import Feature
from chalk.sql import BaseSQLSourceProtocol, FinalizedChalkQuery, SQLSourceGroup
from chalk.sql._internal.sql_source import BaseSQLSource
from chalk.utils.collections import get_unique_item
from chalk.utils.log_with_context import get_logger
from chalk.utils.tracing import safe_trace
from datadog import statsd
from sqlalchemy.sql import Select
from sqlalchemy.sql.elements import TextClause
from sqlglot import Expression
from sqlglot import expressions as sqlglot_expressions

_logger = get_logger(__name__)


def _import_all_sqlglot():
    # See the `sqlglot_import_mutex` below for details -
    # eagerly importing all the sqlglot modules to reduce the need
    # to load them dynamically at runtime to try to mitigate a deadlock.

    import sqlglot.dataframe  # pyright: ignore[reportUnusedImport]
    import sqlglot.dataframe.sql
    import sqlglot.dataframe.sql.column
    import sqlglot.dataframe.sql.dataframe
    import sqlglot.dataframe.sql.functions
    import sqlglot.dataframe.sql.group
    import sqlglot.dataframe.sql.normalize
    import sqlglot.dataframe.sql.operations
    import sqlglot.dataframe.sql.readwriter
    import sqlglot.dataframe.sql.session
    import sqlglot.dataframe.sql.transforms
    import sqlglot.dataframe.sql.types
    import sqlglot.dataframe.sql.util
    import sqlglot.dataframe.sql.window
    import sqlglot.dialects
    import sqlglot.dialects.bigquery
    import sqlglot.dialects.clickhouse
    import sqlglot.dialects.databricks
    import sqlglot.dialects.dialect
    import sqlglot.dialects.doris
    import sqlglot.dialects.drill
    import sqlglot.dialects.duckdb
    import sqlglot.dialects.hive
    import sqlglot.dialects.mysql
    import sqlglot.dialects.oracle
    import sqlglot.dialects.postgres
    import sqlglot.dialects.presto
    import sqlglot.dialects.redshift
    import sqlglot.dialects.snowflake
    import sqlglot.dialects.spark
    import sqlglot.dialects.spark2
    import sqlglot.dialects.sqlite
    import sqlglot.dialects.starrocks
    import sqlglot.dialects.tableau
    import sqlglot.dialects.teradata
    import sqlglot.dialects.trino
    import sqlglot.dialects.tsql
    import sqlglot.diff
    import sqlglot.errors
    import sqlglot.executor
    import sqlglot.executor.context
    import sqlglot.executor.env
    import sqlglot.executor.python
    import sqlglot.executor.table
    import sqlglot.expressions
    import sqlglot.generator
    import sqlglot.helper
    import sqlglot.lineage
    import sqlglot.optimizer
    import sqlglot.optimizer.annotate_types
    import sqlglot.optimizer.canonicalize
    import sqlglot.optimizer.eliminate_ctes
    import sqlglot.optimizer.eliminate_joins
    import sqlglot.optimizer.eliminate_subqueries
    import sqlglot.optimizer.isolate_table_selects
    import sqlglot.optimizer.merge_subqueries
    import sqlglot.optimizer.normalize
    import sqlglot.optimizer.normalize_identifiers
    import sqlglot.optimizer.optimize_joins
    import sqlglot.optimizer.optimizer
    import sqlglot.optimizer.pushdown_predicates
    import sqlglot.optimizer.pushdown_projections
    import sqlglot.optimizer.qualify
    import sqlglot.optimizer.qualify_columns
    import sqlglot.optimizer.qualify_tables
    import sqlglot.optimizer.scope
    import sqlglot.optimizer.simplify
    import sqlglot.optimizer.unnest_subqueries
    import sqlglot.parser
    import sqlglot.planner
    import sqlglot.schema
    import sqlglot.serde
    import sqlglot.time
    import sqlglot.tokens
    import sqlglot.transforms
    import sqlglot.trie  # noqa: F401


_import_all_sqlglot()

sqlglot_import_mutex = Lock()
"""
sqlglot uses lazy imports extensively internally.

This causes a rare deadlock when calling functions that load modules concurrently.
To try to mitigate this, we serialize calls to sqlglot functions in this file using
the above mutex, `sqlglot_import_mutex`.

This should be fixed in Python 3.12: https://docs.python.org/3/whatsnew/3.12.html#imp
"""


@functools.lru_cache(maxsize=200)
def cached_sqlglot_parse(sql: str, read: str, write: str) -> Expression:
    with sqlglot_import_mutex:
        # See note on `sqlglot_import_mutex` above.
        transpiled_items = sqlglot.transpile(sql=sql, read=read, write=write)

    transpiled = get_unique_item(transpiled_items)

    with sqlglot_import_mutex:
        # See note on `sqlglot_import_mutex` above.
        parsed = sqlglot.parse(transpiled, read=read)

    return get_unique_item(x for x in parsed if x is not None)


def to_sqlglot(chalk_query: FinalizedChalkQuery, paren: bool = True) -> sqlglot.Expression:
    return inner_to_sqlglot(chalk_query.query, chalk_query.source, paren=paren)


def inner_to_sqlglot(
    query: Select | TextClause, source: BaseSQLSourceProtocol, paren: bool = True
) -> sqlglot.Expression:
    if not isinstance(query, TextClause):
        raise ValueError("Cannot convert non-text query to sqlglot")
    assert isinstance(source, (BaseSQLSource, SQLSourceGroup))
    dialect = source.get_sqlglot_dialect()
    # have to reparse using correct dialect.
    transpiled = cached_sqlglot_parse(sql=query.text, read=dialect, write=dialect)
    if paren:
        return sqlglot_expressions.paren(transpiled)
    return transpiled


def infer_fields_from_resolver_outputs(
    chalk_query: FinalizedChalkQuery, expected_features: Sequence[Feature[Any, Any]] | None
) -> FinalizedChalkQuery:
    """
    Returns a new chalk query with more fields inferred from the resolver output signature.
    Guarantees that the resulting fields remains a subdict of all fields we'll collect and parse by executing the sql query.
    This function should be synchronized with get_col_name_mapping.
    """
    with safe_trace("infer_sql_query_fields"), statsd.distributed("chalk.engine.sql.infer_sql_query_fields"):
        if expected_features is None:
            return chalk_query

        unexpected_rfqns = [x.root_fqn for x in chalk_query.fields.values() if x not in expected_features]
        if len(unexpected_rfqns) > 0:
            raise ValueError(
                f"Fields {unexpected_rfqns} were in the field mapping but are not included in the resolver output signature."
            )

        # inferring fields requires us to parse the sql and find the columns in the select clause
        if not isinstance(chalk_query.query, TextClause):
            return chalk_query
        try:
            with safe_trace("parse_sql_query"):
                sqlglot_query = to_sqlglot(chalk_query, paren=False)
        except Exception:
            _logger.warning("Could not parse query to infer fields", exc_info=True)
            return chalk_query
        if not isinstance(sqlglot_query, sqlglot_expressions.Select):
            return chalk_query

        named_selects_lower = {named_select.lower() for named_select in sqlglot_query.named_selects}
        inferred_fields = defaultdict(list)
        for f in expected_features:
            root_fqn = f.root_fqn
            root_fqn_normalized = root_fqn.lower()
            without_root_ns = ".".join(root_fqn.split(".")[1:])
            for k in root_fqn_normalized, without_root_ns:
                if k not in chalk_query.fields and f not in chalk_query.fields.values() and k in named_selects_lower:
                    inferred_fields[k].append(f)

        new_fields = {**chalk_query.fields, **{k: v[0] for k, v in inferred_fields.items() if len(v) == 1}}

        return FinalizedChalkQuery(
            query=chalk_query.query,
            params=chalk_query.params,
            finalizer=chalk_query.finalizer,
            incremental_settings=chalk_query.incremental_settings,
            source=chalk_query.source,
            fields=new_fields,
            temp_tables=chalk_query.temp_tables,
            is_empty=chalk_query.is_empty,
        )
