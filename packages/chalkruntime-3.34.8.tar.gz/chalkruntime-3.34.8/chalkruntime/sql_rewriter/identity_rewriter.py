from chalk.sql import FinalizedChalkQuery

from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter


class _IdentityQueryRewriter(QueryRewriter):
    def __call__(self, query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        return query

    def __hash__(self) -> int:
        return hash(type(self))

    def __eq__(self, other: object):
        if isinstance(other, _IdentityQueryRewriter):
            return True
        return NotImplemented


IDENTITY_QUERY_REWRITER = _IdentityQueryRewriter()
