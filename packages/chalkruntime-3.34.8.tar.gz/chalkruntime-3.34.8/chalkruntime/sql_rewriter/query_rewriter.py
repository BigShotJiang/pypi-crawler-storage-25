import abc

from chalk.sql.finalized_query import FinalizedChalkQuery


class QueryRewriter(abc.ABC):
    """Implementation of a QueryRewriter. This class is an ABC rather than a Protocol to ensure that all implementations are indeed
    classes and not lambdas"""

    @abc.abstractmethod
    def __call__(self, query: FinalizedChalkQuery, resolver_fqn: str, /) -> FinalizedChalkQuery: ...
