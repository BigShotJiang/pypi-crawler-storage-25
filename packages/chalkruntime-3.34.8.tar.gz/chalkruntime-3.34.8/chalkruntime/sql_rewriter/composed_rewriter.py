import dataclasses

from chalk.sql.finalized_query import FinalizedChalkQuery

from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter


@dataclasses.dataclass(frozen=True)
class ComposedRewriter(QueryRewriter):
    first: QueryRewriter
    then: QueryRewriter

    def __call__(self, query: FinalizedChalkQuery, resolver_fqn: str) -> FinalizedChalkQuery:
        return self.then(self.first(query, resolver_fqn), resolver_fqn)
