# chalkruntime

Runtime support library for Chalk AI's feature computation engine.

This package is an internal component of the Chalk platform and is not intended
to be consumed as a standalone library. See https://chalk.ai for more
information.

Chalkruntime is the runtime support library that powers Chalk's feature computation engine. It loads feature definitions, validates code, executes feature computations via a gRPC server, and handles data transformations across multiple sources.

## Key Components

- **Server** — Main gRPC service that loads, validates, and orchestrates the feature graph execution
- **Graph** — Deserializes feature definitions, manages graph state, and handles materializations
- **Invoker** — Executes resolvers (feature computation functions) with parallelization and batching
- **Loader** — Downloads and imports user-supplied code and dependencies
- **SQL Rewriter** — Optimizes SQL queries for feature computation
- **Streaming** — Handles real-time streaming data sources
