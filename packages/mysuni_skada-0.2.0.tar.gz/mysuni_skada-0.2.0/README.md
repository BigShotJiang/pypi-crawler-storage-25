# mysuni-skada

SKADA QUEST 모의고사 채점 클라이언트.

JupyterLab 컨테이너 (모의고사 모드) 안에서 사용자 답안을 SKADA 평가서버로 제출.

## 사용

```python
from mysuni import skada

# Q13 결과 제출
result = 5
res = skada.submit("q13", result)
print(res)
# {'correct': True, 'score': 15, 'message': '정답입니다.'}
```

리더보드형 챌린지는 정답을 노트북에서 직접 평가하지 않고 CSV를 서버에 제출합니다.
서버가 제출 파일을 보관한 뒤 백그라운드로 채점하고, mysuni는 기본적으로 채점 완료까지
짧게 polling 합니다.

```python
from mysuni import skada

# submission.csv 생성 후 서버 채점 요청
res = skada.submit_file("skada-bank-churn-classification", "submission.csv")
print(res)
```

## 환경변수 (spawner 가 주입)

| key | 설명 |
|---|---|
| `SKADA_EXAM_API_URL` | 백엔드 채점 endpoint base (예: `http://skada-quest/api/exam`) |
| `SKADA_EXAM_TOKEN` | 모의고사 세션 토큰 — backend 가 발급, ExamSession 1:1 매칭 |
| `SKADA_EXAM_ID` | 모의고사 ID (예: `skada-mock-1`) |
| `SKADA_ACCESS_TOKEN` | 선택. 플랫폼 Jupyter에서 주입되는 notebook-scoped JWT. email-only 외부 제출은 없어도 됨 |
| `SKADA_CHALLENGE_API_URL` | 리더보드형 challenge API base (예: `http://skada-quest/api`) |
| `SKADA_SUBMIT_POLL_TIMEOUT_SEC` | 선택. submit_file 채점 대기 시간 기본 120초 |
| `SKADA_SUBMIT_POLL_INTERVAL_SEC` | 선택. submit_file polling 간격 기본 1.5초 |

## 직렬화

`numpy.int*`, `numpy.float*`, `numpy.ndarray`, `pandas.Series`, `pandas.DataFrame` 자동 JSON 호환 타입으로 변환.

## 리더보드형 프로젝트 제출

브라우저 업로드 대신 노트북에서 바로 제출할 때는 email만 있으면 됩니다.
서버는 email이 시스템에 등록된 수강생인지 확인하고, 등록되어 있지 않으면 채점하지 않습니다.
운영 Jupyter에서는 `SKADA_USER_EMAIL`이 자동 주입되고, Colab/로컬에서는 직접 넘기면 됩니다.

```bash
export SKADA_CHALLENGE_API_URL="https://skada.quest/api"
export SKADA_EMAIL="student@example.com"
```

```python
from mysuni import skada

# challenge slug + CSV 파일 경로. 서버가 private solution으로 채점하고 public score만 반환합니다.
result = skada.submit_file("skada-bank-churn-classification", "submission.csv")
print(result)
```

환경변수를 쓰지 않으려면 email을 직접 넘깁니다.

```python
from mysuni import skada

result = skada.submit_file(
    "skada-bank-churn-classification",
    "submission.csv",
    email="student@example.com",
)
print(result)
```

플랫폼 Jupyter에서는 notebook-scoped `SKADA_ACCESS_TOKEN`도 함께 주입될 수 있지만,
외부 Colab/로컬 제출은 email-only로 동작합니다.

객체형 클라이언트도 동일합니다.

```python
from mysuni.skada import SKADA

sk = SKADA(email="student@example.com")
result = sk.submit_file("skada-bank-churn-classification", "submission.csv")
```

즉시 반환만 받고 싶으면:

```python
result = skada.submit_file(
    "skada-bank-churn-classification",
    "submission.csv",
    wait=False,
)
print(result["status"], result["submission_id"])
```

`SKADA_EXAM_ID`/`SKADA_EXAM_TOKEN`이 있는 모의고사 컨테이너에서는 기존처럼 exam submit API를 사용합니다.
