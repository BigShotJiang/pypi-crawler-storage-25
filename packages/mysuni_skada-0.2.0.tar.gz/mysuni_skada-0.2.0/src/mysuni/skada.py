"""SKADA QUEST 모의고사 채점 클라이언트 (lightweight).

JupyterLab 컨테이너 안에서:

    from mysuni import skada
    sk = skada.SKADA(email="student@example.com")
    df = sk.fetch_data("q13")
    sk.submit("q13", value=42)

환경변수 (spawner 가 자동 주입):
    SKADA_USER_EMAIL    이메일 (생성자 인자 미지정 시 fallback)
    SKADA_EXAM_ID       모의고사 meta_id (예: "skada-real-3")
    SKADA_EXAM_TOKEN    ExamSession Bearer 토큰
    SKADA_EXAM_API_URL  backend base URL (default: https://skada.quest/api/exam)
    SKADA_ACCESS_TOKEN  선택. 플랫폼 Jupyter용 notebook-scoped Bearer 토큰
    SKADA_CHALLENGE_API_URL  challenge API base URL (default: https://skada.quest/api)

명시적 인자가 환경변수보다 우선.
"""

from __future__ import annotations

import base64
import csv
import json
import os
import time
import warnings
from datetime import datetime
from io import BytesIO, StringIO
from pathlib import Path
from typing import Any, Dict, Union
from urllib import error as _urlerror
from urllib import parse as _urlparse
from urllib import request as _urlrequest

from . import __version__

DEFAULT_API_URL = "https://skada.quest/api/exam"
DEFAULT_CHALLENGE_API_URL = "https://skada.quest/api"
DEFAULT_TIMEOUT = 30
DEFAULT_CHALLENGE_POLL_TIMEOUT = int(os.environ.get("SKADA_SUBMIT_POLL_TIMEOUT_SEC", "120"))
DEFAULT_CHALLENGE_POLL_INTERVAL = float(os.environ.get("SKADA_SUBMIT_POLL_INTERVAL_SEC", "1.5"))


class SubmissionError(Exception):
    """제출 관련 오류."""


def _value_for_payload(value: Any) -> Any:
    """서버 정확 일치 비교용 — numpy/pandas → Python 원시값."""
    if isinstance(value, (int, float, str, bool, type(None))):
        return value
    if isinstance(value, (list, tuple)):
        return [_value_for_payload(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _value_for_payload(v) for k, v in value.items()}
    # numpy scalar / ndarray / pandas — optional import (이미지엔 항상 있음)
    try:
        import numpy as np  # noqa: WPS433

        if isinstance(value, np.ndarray):
            return value.tolist()
        if hasattr(value, "item") and callable(value.item):
            try:
                return value.item()
            except Exception:
                pass
    except ImportError:
        pass
    try:
        import pandas as pd  # noqa: WPS433

        if isinstance(value, pd.Series):
            return value.tolist()
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
    except ImportError:
        pass
    return value


def serialize_data(data: Any) -> Dict[str, Any]:
    """audit metadata 용 — JSON 직렬화 가능한 dict."""
    try:
        import numpy as np  # noqa: WPS433

        if isinstance(data, np.ndarray):
            return {
                "type": "numpy",
                "content": base64.b64encode(data.tobytes()).decode("utf-8"),
                "dtype": str(data.dtype),
                "shape": list(data.shape),
            }
    except ImportError:
        pass
    try:
        import pandas as pd  # noqa: WPS433

        if isinstance(data, pd.DataFrame):
            return {
                "type": "dataframe",
                "content": data.to_json(orient="records"),
                "columns": list(data.columns),
            }
        if isinstance(data, pd.Series):
            return {"type": "series", "content": data.to_json(), "name": data.name}
    except ImportError:
        pass
    if isinstance(data, (list, tuple)):
        kind = "list" if isinstance(data, list) else "tuple"
        return {"type": kind, "content": [_value_for_payload(x) for x in data]}
    if isinstance(data, dict):
        return {"type": "dict", "content": {k: _value_for_payload(v) for k, v in data.items()}}
    if callable(data):
        return {"type": "function", "name": getattr(data, "__name__", "anonymous")}
    return {"type": "primitive", "content": data}


# =============================================================================
# SKADA 클라이언트
# =============================================================================


class SKADA:
    """SKADA QUEST 자동채점 클라이언트.

    Args:
        email: 사용자 이메일. 미지정 시 env `SKADA_USER_EMAIL` 또는 `SKADA_EMAIL`.
        exam_id: 모의고사 meta_id. 미지정 시 env `SKADA_EXAM_ID`.
        token: ExamSession Bearer 토큰. 미지정 시 env `SKADA_EXAM_TOKEN`.
        api_url: backend base URL. 미지정 시 env `SKADA_EXAM_API_URL`
            또는 `https://skada.quest/api/exam`.
        verbose: 채점 결과 자동 출력 여부.
    """

    def __init__(
        self,
        email: str | None = None,
        *,
        exam_id: str | None = None,
        token: str | None = None,
        api_url: str | None = None,
        verbose: bool = True,
    ) -> None:
        self.email = (
            email
            or os.environ.get("SKADA_USER_EMAIL")
            or os.environ.get("SKADA_EMAIL")
        )
        self.exam_id = exam_id or os.environ.get("SKADA_EXAM_ID")
        self.token = token or os.environ.get("SKADA_EXAM_TOKEN")
        self.access_token = os.environ.get("SKADA_ACCESS_TOKEN") or os.environ.get("SKADA_API_TOKEN")
        self.api_url = (
            api_url or os.environ.get("SKADA_EXAM_API_URL") or DEFAULT_API_URL
        ).rstrip("/")
        self.verbose = verbose

        if not self.email:
            raise SubmissionError(
                "email 이 필요합니다.\n"
                "  · SKADA(email='you@example.com') 으로 명시\n"
                "  · 또는 환경변수 SKADA_USER_EMAIL 설정"
            )
        if self.verbose:
            ctx = self.exam_id or "(no exam_id)"
            print(f"📧 SKADA 클라이언트 준비 — email={self.email} · exam={ctx}")

    # ------------------------------------------------------------------
    def submit(self, qid: str, value: Any) -> Dict[str, Any]:
        """답안 1개 제출 → 채점 결과 dict 반환.

        성공: `{"correct": bool, "score": int, "message": str}`
        실패: `{"error": "..."}`
        """
        if not self.exam_id:
            return _err("SKADA_EXAM_ID 미설정 — 모의고사 컨테이너 안에서 실행하세요.")
        if not self.token:
            return _err("SKADA_EXAM_TOKEN 미설정 — 세션 토큰이 없습니다.")

        payload = {
            "exam_id": self.exam_id,
            "qid": qid,
            "value": _value_for_payload(value),
            "meta": {
                "email": self.email,
                "submitted_at": datetime.utcnow().isoformat() + "Z",
                "client_version": __version__,
            },
        }
        req = _urlrequest.Request(
            f"{self.api_url}/submit",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "content-type": "application/json",
                "authorization": f"Bearer {self.token}",
                "user-agent": f"mysuni-skada/{__version__}",
            },
            method="POST",
        )
        try:
            with _urlrequest.urlopen(req, timeout=DEFAULT_TIMEOUT) as r:  # noqa: S310
                body = r.read().decode("utf-8")
                result: Dict[str, Any] = json.loads(body) if body else {}
        except _urlerror.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")[:200]
            return _err(f"HTTP {e.code}: {err_body}", qid=qid)
        except _urlerror.URLError as e:
            return _err(f"네트워크 오류: {e.reason}")
        except Exception as e:  # noqa: BLE001
            return _err(f"제출 오류: {e}")

        self._print_submit_result(qid, result)
        return result

    # ------------------------------------------------------------------
    def submit_file(
        self,
        qid: str,
        path: str = "submission.csv",
        *,
        email: str | None = None,
        wait: bool = True,
        timeout_sec: int | None = None,
    ) -> Dict[str, Any]:
        """CSV 제출 파일을 서버 채점 요청으로 전송.

        리더보드형 챌린지는 학생 노트북에서 정답을 직접 평가하지 않는다.
        `submission.csv`만 만들고 이 메서드로 서버에 채점 요청을 보낸다.
        서버는 private solution에 접근해 public/private score를 계산한다.
        """
        if _looks_like_challenge_slug(qid):
            return _submit_challenge_file(
                qid,
                path,
                token=self.access_token,
                email=email or self.email,
                url=os.environ.get("SKADA_CHALLENGE_API_URL") or DEFAULT_CHALLENGE_API_URL,
                wait=wait,
                timeout_sec=timeout_sec,
            )
        payload = _csv_submission_payload(path)
        return self.submit(qid, payload)

    # ------------------------------------------------------------------
    def fetch_data(
        self,
        qid: str,
        *,
        fmt: str | None = None,
    ) -> Union["object", Dict[str, Any], bytes]:
        """문항용 데이터셋 다운로드.

        content-type 자동 감지:
          · text/csv          → pd.DataFrame
          · application/json  → dict
          · application/x-parquet → pd.DataFrame
          · 그 외             → raw bytes
        """
        if not self.exam_id:
            raise SubmissionError("SKADA_EXAM_ID 미설정.")
        if not self.token:
            raise SubmissionError("SKADA_EXAM_TOKEN 미설정.")

        url = f"{self.api_url}/data/{self.exam_id}/{qid}"
        if fmt:
            url += f"?format={fmt}"
        req = _urlrequest.Request(
            url,
            headers={
                "authorization": f"Bearer {self.token}",
                "user-agent": f"mysuni-skada/{__version__}",
            },
        )
        try:
            with _urlrequest.urlopen(req, timeout=DEFAULT_TIMEOUT) as r:  # noqa: S310
                content = r.read()
                ctype = (r.headers.get("content-type") or "").lower()
        except _urlerror.HTTPError as e:
            raise SubmissionError(
                f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:200]}"
            ) from e
        except _urlerror.URLError as e:
            raise SubmissionError(f"네트워크 오류: {e.reason}") from e

        if "csv" in ctype:
            import pandas as pd  # noqa: WPS433
            return pd.read_csv(StringIO(content.decode("utf-8")))
        if "parquet" in ctype:
            import pandas as pd  # noqa: WPS433
            return pd.read_parquet(BytesIO(content))
        if "json" in ctype:
            return json.loads(content.decode("utf-8"))
        return content

    # ------------------------------------------------------------------
    def _print_submit_result(self, qid: str, result: Dict[str, Any]) -> None:
        """정/오답·점수는 시험 무결성 차원에서 노출하지 않음.
        서버 기록 확인 후 단순 '제출 완료' 만 출력."""
        if not self.verbose:
            return
        if result.get("received"):
            msg = result.get("message", "제출 완료")
            print(f"📨 {qid}  {msg}")
        elif result.get("error"):
            print(f"❌ {qid}  {result['error']}")
        else:
            # legacy 응답 (correct/score 들어있는 옛 backend) — score 만 가린 채 "제출됨".
            print(f"📨 {qid}  제출됨")

    def __repr__(self) -> str:
        return f"SKADA(email={self.email!r}, exam_id={self.exam_id!r})"


def _err(msg: str, *, qid: str | None = None) -> Dict[str, Any]:
    """채점 응답 형식과 통일된 에러 dict."""
    warnings.warn(msg, stacklevel=2)
    out: Dict[str, Any] = {"error": msg}
    if qid is not None:
        out["qid"] = qid
    return out


# legacy 함수형 API — 환경변수 의존, 기존 노트북 호환용.
DEFAULT_EXAM_ID = os.environ.get("SKADA_EXAM_ID")
DEFAULT_TOKEN = os.environ.get("SKADA_EXAM_TOKEN")
DEFAULT_URL = os.environ.get("SKADA_EXAM_API_URL", DEFAULT_API_URL)


def submit(
    qid: str,
    value: Any,
    *,
    exam_id: str | None = None,
    token: str | None = None,
    url: str | None = None,
) -> Dict[str, Any]:
    """legacy 함수형 — 객체 안 만들고 바로 호출. email 검증 없이 토큰만 사용."""
    eid = exam_id or DEFAULT_EXAM_ID
    tok = token or DEFAULT_TOKEN
    base = (url or DEFAULT_URL).rstrip("/")
    if not eid:
        return _err("SKADA_EXAM_ID 미설정.")
    if not tok:
        return _err("SKADA_EXAM_TOKEN 미설정.")
    payload = {"exam_id": eid, "qid": qid, "value": _value_for_payload(value)}
    req = _urlrequest.Request(
        f"{base}/submit",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "content-type": "application/json",
            "authorization": f"Bearer {tok}",
            "user-agent": f"mysuni-skada/{__version__}",
        },
        method="POST",
    )
    try:
        with _urlrequest.urlopen(req, timeout=DEFAULT_TIMEOUT) as r:  # noqa: S310
            body = r.read().decode("utf-8")
            return json.loads(body) if body else {}
    except _urlerror.HTTPError as e:
        return _err(f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:200]}", qid=qid)
    except _urlerror.URLError as e:
        return _err(f"네트워크 오류: {e.reason}")


def _looks_like_challenge_slug(value: str) -> bool:
    """Challenge slugs are hyphenated IDs such as skada-bank-churn-classification.

    Exam qids are usually q13/q14 or short item IDs. The env token still gates the
    challenge path, so this heuristic preserves exam compatibility.
    """
    return "-" in value and not value.lower().startswith("q")


def _multipart_form_body(
    field_name: str,
    path: Path,
    *,
    fields: dict[str, str | None] | None = None,
) -> tuple[bytes, str]:
    boundary = f"----skada{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}"
    content = path.read_bytes()
    parts: list[bytes] = []
    for name, value in (fields or {}).items():
        if value is None:
            continue
        parts.append(
            (
                f"--{boundary}\r\n"
                f"Content-Disposition: form-data; name=\"{name}\"\r\n\r\n"
                f"{value}\r\n"
            ).encode("utf-8")
        )
    parts.append(
        (
            f"--{boundary}\r\n"
            f"Content-Disposition: form-data; name=\"{field_name}\"; filename=\"{path.name}\"\r\n"
            "Content-Type: text/csv\r\n\r\n"
        ).encode("utf-8")
        + content
        + b"\r\n"
    )
    footer = f"--{boundary}--\r\n".encode("utf-8")
    return b"".join(parts) + footer, boundary


def _resolve_email(email: str | None = None) -> str | None:
    return email or os.environ.get("SKADA_USER_EMAIL") or os.environ.get("SKADA_EMAIL")


def _require_email_for_external_submission(email: str | None) -> str:
    resolved = _resolve_email(email)
    if not resolved:
        raise SubmissionError(
            "email 이 필요합니다. 환경변수 SKADA_USER_EMAIL/SKADA_EMAIL을 설정하거나 "
            "submit_file(..., email='you@example.com')으로 넘겨 주세요."
        )
    return resolved


def _submit_challenge_file(
    slug: str,
    path: str,
    *,
    token: str | None = None,
    email: str | None = None,
    url: str | None = None,
    wait: bool = True,
    timeout_sec: int | None = None,
) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise SubmissionError(f"제출 파일을 찾을 수 없습니다: {path}")
    submitter_email = _require_email_for_external_submission(email)
    body, boundary = _multipart_form_body(
        "file",
        p,
        fields={"email": submitter_email},
    )
    base = (url or DEFAULT_CHALLENGE_API_URL).rstrip("/")
    headers = {
        "content-type": f"multipart/form-data; boundary={boundary}",
        "user-agent": f"mysuni-skada/{__version__}",
    }
    if token:
        headers["authorization"] = f"Bearer {token}"
    req = _urlrequest.Request(
        f"{base}/challenges/{slug}/submissions",
        data=body,
        headers=headers,
        method="POST",
    )
    try:
        with _urlrequest.urlopen(req, timeout=DEFAULT_TIMEOUT) as r:  # noqa: S310
            raw = r.read().decode("utf-8")
            result: Dict[str, Any] = json.loads(raw) if raw else {}
    except _urlerror.HTTPError as e:
        return _err(f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:300]}", qid=slug)
    except _urlerror.URLError as e:
        return _err(f"네트워크 오류: {e.reason}")
    if wait and result.get("status") in {"pending", "scoring"} and result.get("submission_id"):
        result = _poll_challenge_submission(
            slug,
            str(result["submission_id"]),
            token=token,
            email=submitter_email,
            url=base,
            timeout_sec=timeout_sec or DEFAULT_CHALLENGE_POLL_TIMEOUT,
        )
    if result.get("public_score") is not None:
        print(f"🏁 {slug} public score = {result['public_score']}")
    elif result.get("status") in {"pending", "scoring"}:
        print(f"⏳ {slug} 서버 채점 진행 중 — submission_id={result.get('submission_id')}")
    elif result.get("status") == "failed":
        print(f"❌ {slug} 서버 채점 실패 — {result.get('error_message') or result.get('message')}")
    return result


def _poll_challenge_submission(
    slug: str,
    submission_id: str,
    *,
    token: str | None,
    email: str,
    url: str,
    timeout_sec: int,
) -> Dict[str, Any]:
    deadline = time.monotonic() + timeout_sec
    last: Dict[str, Any] = {}
    while time.monotonic() < deadline:
        status_url = (
            f"{url.rstrip('/')}/challenges/{slug}/submissions/{submission_id}"
            f"?{_urlparse.urlencode({'email': email})}"
        )
        headers = {"user-agent": f"mysuni-skada/{__version__}"}
        if token:
            headers["authorization"] = f"Bearer {token}"
        req = _urlrequest.Request(
            status_url,
            headers=headers,
        )
        try:
            with _urlrequest.urlopen(req, timeout=DEFAULT_TIMEOUT) as r:  # noqa: S310
                raw = r.read().decode("utf-8")
                last = json.loads(raw) if raw else {}
        except _urlerror.HTTPError as e:
            return _err(
                f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:300]}",
                qid=slug,
            )
        except _urlerror.URLError as e:
            return _err(f"네트워크 오류: {e.reason}")
        if last.get("status") in {"scored", "failed"}:
            return last
        time.sleep(DEFAULT_CHALLENGE_POLL_INTERVAL)
    last.setdefault("status", "pending")
    last.setdefault("submission_id", submission_id)
    last.setdefault("message", "채점 대기 시간이 초과되었습니다. 잠시 후 상태를 다시 확인하세요.")
    return last


def _csv_submission_payload(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise SubmissionError(f"제출 파일을 찾을 수 없습니다: {path}")
    try:
        import pandas as pd  # noqa: WPS433

        df = pd.read_csv(p)
        return {
            "type": "csv_submission",
            "filename": p.name,
            "columns": list(df.columns),
            "rows": int(len(df)),
            "records": _value_for_payload(df),
        }
    except ImportError:
        with p.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            records = list(reader)
            columns = reader.fieldnames or []
        return {
            "type": "csv_submission",
            "filename": p.name,
            "columns": columns,
            "rows": len(records),
            "records": records,
        }


def submit_file(
    qid: str,
    path: str = "submission.csv",
    *,
    email: str | None = None,
    exam_id: str | None = None,
    token: str | None = None,
    url: str | None = None,
    wait: bool = True,
    timeout_sec: int | None = None,
) -> Dict[str, Any]:
    """legacy 함수형 CSV 제출."""
    access = token or os.environ.get("SKADA_ACCESS_TOKEN") or os.environ.get("SKADA_API_TOKEN")
    if _looks_like_challenge_slug(qid) and not (exam_id or DEFAULT_EXAM_ID):
        return _submit_challenge_file(
            qid,
            path,
            token=access,
            email=email,
            url=url or os.environ.get("SKADA_CHALLENGE_API_URL") or DEFAULT_CHALLENGE_API_URL,
            wait=wait,
            timeout_sec=timeout_sec,
        )
    eid = exam_id or DEFAULT_EXAM_ID
    tok = token or DEFAULT_TOKEN
    base = (url or DEFAULT_URL).rstrip("/")
    if not eid:
        return _err("SKADA_EXAM_ID 미설정.")
    if not tok:
        return _err("SKADA_EXAM_TOKEN 미설정.")
    payload = {
        "exam_id": eid,
        "qid": qid,
        "value": _csv_submission_payload(path),
        "meta": {"email": _resolve_email(email)} if _resolve_email(email) else {},
    }
    req = _urlrequest.Request(
        f"{base}/submit",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "content-type": "application/json",
            "authorization": f"Bearer {tok}",
            "user-agent": f"mysuni-skada/{__version__}",
        },
        method="POST",
    )
    try:
        with _urlrequest.urlopen(req, timeout=DEFAULT_TIMEOUT) as r:  # noqa: S310
            body = r.read().decode("utf-8")
            return json.loads(body) if body else {}
    except _urlerror.HTTPError as e:
        return _err(f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:200]}", qid=qid)
    except _urlerror.URLError as e:
        return _err(f"네트워크 오류: {e.reason}")


__all__ = [
    "SKADA",
    "SubmissionError",
    "serialize_data",
    "submit",
    "submit_file",
]
