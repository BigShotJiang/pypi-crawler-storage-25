"""mysuni — SKADA QUEST 학습 플랫폼 클라이언트.

`from mysuni import skada` 로 모의고사 채점 모듈 사용.
"""

__version__ = "0.2.0"

from . import skada

__all__ = ["skada", "__version__"]
