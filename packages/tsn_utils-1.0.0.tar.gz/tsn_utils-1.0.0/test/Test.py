# Copyright 2025, Niquel Mendoza.
# https://www.mql5.com/es/users/nique_372
# Test.py

from tsn_utils import SimpleLogger
from tsn_utils import Funciones
        
def main():
    obj = SimpleLogger.CLoggerBase()
    obj.EnableAllLogs()
    obj.LogWarning("Advertencia")
    obj.LogError("Error xd")
    obj.LogInfo("Informacion")
    print(obj.IsWarningLogEnabled())
    obj.LogCaution("HOLA")

    lista : list[int] = [1,2,3,4,5]
    
    print(Funciones.array_to_string(lista,",","[","]"))    
        
if __name__ == "__main__":
    main()
