# Copyright 2025, Niquel Mendoza.
# https://www.mql5.com/es/users/nique_372
# Funciones.py

import sys 

def Remover(code : int) -> None:
    sys.exit(code)
        
def string_substr(texto : str, start : int, length : int =-1) -> str:
    if length == -1:
        return texto[start:]
    else:
        return texto[start:start+length]    
    
def array_to_string(array : any, separator : str, initial_sep : str, end_sep : str) -> str:
    string : str = initial_sep
    final_index : int = len(array) - 1
    
    for index, element in enumerate(array):
        
        if(index != final_index):
            string += str(element) + separator
        else: 
            string += str(element) + end_sep
            
    return string           
        