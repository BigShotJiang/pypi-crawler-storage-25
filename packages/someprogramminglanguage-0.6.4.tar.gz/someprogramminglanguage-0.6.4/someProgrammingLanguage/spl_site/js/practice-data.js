(function () {
  /**
   * Grading: server runs 100 trials — 20 fixed edge-case seeds + 80 random
   * (see spl_practice_judge.py). Stdin problems use user.ask.
   */
  window.SPL_PRACTICE = [
    {
      id: "multiply",
      title: "Multiply",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial (including edge cases like zeros). Print <code class=\"text-emerald-300\">math.multiply(a, b)</code>.",
      starter: "print.number(math.multiply(a, b));",
      solution: "print.number(math.multiply(a, b));",
    },
    {
      id: "add42",
      title: "Add two numbers",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial. Print <code class=\"text-emerald-300\">math.add(a, b)</code>.",
      starter: "print.number(math.add(a, b));",
      solution: "print.number(math.add(a, b));",
    },
    {
      id: "loop123",
      title: "Count to three",
      prompt:
        "Use <code class=\"text-emerald-300\">test.forLoop</code> from 1 to 3 and print <code class=\"text-sky-300\">i</code> each time (lines <code class=\"text-slate-400\">1.0</code> … <code class=\"text-slate-400\">3.0</code>).",
      starter: "test.forLoop(1, 3, i):\nend;",
      solution:
        "test.forLoop(1, 3, i):\n    print.number(i);\nend;",
    },
    {
      id: "concat-ab",
      title: "Concatenate",
      prompt:
        "Each trial sets <code class=\"text-sky-300\">c1</code> and <code class=\"text-sky-300\">c2</code> (single letters). Print their concatenation with <code class=\"text-emerald-300\">string.concatenate</code>.",
      starter: "",
      solution: "print.string(string.concatenate(c1, c2));",
    },
    {
      id: "fn-double",
      title: "Double function",
      prompt:
        "Define <code class=\"text-sky-300\">double(x)</code> that doubles its argument. The grader appends <code class=\"text-emerald-300\">print.number(function.double(…))</code> with a random argument (including 0 and negatives).",
      starter: "functionDefine.double(x):\nend;",
      solution:
        "functionDefine.double(x):\n    return.number(math.multiply(x, 2));\nend;",
    },
    {
      id: "mod",
      title: "Modulo",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial. Print <code class=\"text-emerald-300\">math.mod(a, b)</code> (includes <code class=\"text-slate-400\">a = 0</code> cases).",
      starter: "",
      solution: "print.number(math.mod(a, b));",
    },
    {
      id: "subtract99",
      title: "Subtract",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set with <code class=\"text-slate-400\">a ≥ b</code>. Print <code class=\"text-emerald-300\">math.subtract(a, b)</code>.",
      starter: "",
      solution: "print.number(math.subtract(a, b));",
    },
    {
      id: "square36",
      title: "Square",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is set each trial. Print <code class=\"text-emerald-300\">n * n</code> via <code class=\"text-emerald-300\">math.multiply(n, n)</code>.",
      starter: "",
      solution: "print.number(math.multiply(n, n));",
    },
    {
      id: "list-first",
      title: "First in list",
      prompt:
        "Each trial builds <code class=\"text-sky-300\">nums</code> with three integers (including zeros). Print the first element with <code class=\"text-emerald-300\">list.get</code>.",
      starter: "",
      solution: "print.number(list.get(0, nums));",
    },
    {
      id: "uppercase",
      title: "Uppercase",
      prompt:
        "Variable <code class=\"text-sky-300\">s</code> holds a string each trial. Print <code class=\"text-emerald-300\">string.uppercase(s)</code>.",
      starter: "",
      solution: "print.string(string.uppercase(s));",
    },
    {
      id: "strlen",
      title: "String length",
      prompt:
        "Variable <code class=\"text-sky-300\">s</code> is set each trial (including empty). Print <code class=\"text-emerald-300\">string.length(s)</code>.",
      starter: "",
      solution: "print.number(string.length(s));",
    },
    {
      id: "reverse",
      title: "Reverse string",
      prompt:
        "Variable <code class=\"text-sky-300\">s</code> is set each trial. Print <code class=\"text-emerald-300\">string.reverse(s)</code>.",
      starter: "",
      solution: "print.string(string.reverse(s));",
    },
    {
      id: "is-even",
      title: "Even test",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is always an even integer (including 0). If <code class=\"text-emerald-300\">test.isEven(n)</code>, print <code class=\"text-emerald-300\">even</code>.",
      starter: "",
      solution:
        "test.ifTrue(test.isEven(n)):\n    print.string(\"even\");\nend;",
    },
    {
      id: "divide",
      title: "Integer division",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set so <code class=\"text-emerald-300\">a</code> divides evenly by <code class=\"text-emerald-300\">b</code> (including <code class=\"text-slate-400\">a = 0</code>). Print <code class=\"text-emerald-300\">math.div(a, b)</code>.",
      starter: "",
      solution: "print.number(math.div(a, b));",
    },
    {
      id: "floor",
      title: "Floor",
      prompt:
        "Variable <code class=\"text-sky-300\">x</code> holds a fractional number each trial (including negatives). Print <code class=\"text-emerald-300\">math.floor(x)</code>.",
      starter: "",
      solution: "print.number(math.floor(x));",
    },
    {
      id: "ask-double",
      title: "Double stdin",
      prompt:
        "Read one integer with <code class=\"text-emerald-300\">string.convertInt(user.ask(\"\"))</code> into <code class=\"text-sky-300\">n</code>, then print <code class=\"text-emerald-300\">n * 2</code> (use <code class=\"text-emerald-300\">math.multiply(n, 2)</code>). Stdin supplies one line per run (large values and negatives included).",
      starter:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, 2));',
      solution:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, 2));',
    },
    {
      id: "ask-sum2",
      title: "Sum two inputs",
      prompt:
        "Read two integers from two <code class=\"text-emerald-300\">user.ask</code> calls (use <code class=\"text-emerald-300\">string.convertInt</code>), store in <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code>, print <code class=\"text-emerald-300\">math.add(a, b)</code>. Input is two lines per trial.",
      starter:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "print.number(math.add(a, b));",
      solution:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "print.number(math.add(a, b));",
    },
    {
      id: "ask-max",
      title: "Max of two inputs",
      prompt:
        "Read two integers from stdin (two lines). Print the larger using <code class=\"text-emerald-300\">test.ifTrue</code> / <code class=\"text-emerald-300\">test.else</code> and <code class=\"text-emerald-300\">test.isGreater</code> (ties can print either value; reference prints <code class=\"text-sky-300\">b</code> when equal).",
      starter:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(a);\nend;\n" +
        "test.else():\n    print.number(b);\nend;",
      solution:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(a);\nend;\n" +
        "test.else():\n    print.number(b);\nend;",
    },
    {
      id: "ask-hello",
      title: "Hello name (stdin)",
      prompt:
        "Read one line with <code class=\"text-emerald-300\">user.ask(\"\")</code> into <code class=\"text-sky-300\">name</code>, then print <code class=\"text-emerald-300\">string.concatenate(\"Hello, \", name)</code>. Empty lines are tested.",
      starter:
        'name.setVar(user.ask(""));\nprint.string(string.concatenate("Hello, ", name));',
      solution:
        'name.setVar(user.ask(""));\nprint.string(string.concatenate("Hello, ", name));',
    },
    {
      id: "ask-square",
      title: "Square stdin",
      prompt:
        "Read one integer from stdin, then print its square with <code class=\"text-emerald-300\">math.multiply(n, n)</code>.",
      starter:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, n));',
      solution:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, n));',
    },
  ];
})();
