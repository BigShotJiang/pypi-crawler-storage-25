#!/usr/bin/env node
/**
 * Validates spl_site/js/reference-data.js: parses as JS, checks SPL_REFERENCE shape
 * and categoryLabel consistency. Run from repo root:
 *   node someProgrammingLanguage/spl_site/scripts/validate-reference.mjs
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const refPath = path.join(__dirname, "..", "js", "reference-data.js");

const code = fs.readFileSync(refPath, "utf8");
globalThis.window = {};
try {
  eval(code);
} catch (e) {
  console.error("FAIL: reference-data.js does not eval:", e.message);
  process.exit(1);
}

const rows = globalThis.window.SPL_REFERENCE;
if (!Array.isArray(rows)) {
  console.error("FAIL: SPL_REFERENCE is not an array");
  process.exit(1);
}

const labelByCat = {};
const errors = [];

for (let i = 0; i < rows.length; i++) {
  const r = rows[i];
  const prefix = `row ${i}`;
  for (const key of ["category", "categoryLabel", "name", "desc"]) {
    if (typeof r[key] !== "string" || r[key].trim() === "") {
      errors.push(`${prefix}: missing or invalid ${key}`);
    }
  }
  if (typeof r.category === "string") {
    const prev = labelByCat[r.category];
    if (prev !== undefined && prev !== r.categoryLabel) {
      errors.push(
        `${prefix}: category "${r.category}" has conflicting categoryLabel "${r.categoryLabel}" (expected "${prev}")`
      );
    }
    labelByCat[r.category] = r.categoryLabel;
  }
}

if (errors.length) {
  console.error("FAIL: reference validation:\n" + errors.join("\n"));
  process.exit(1);
}

console.log(`OK: ${rows.length} reference rows, ${Object.keys(labelByCat).length} categories.`);
