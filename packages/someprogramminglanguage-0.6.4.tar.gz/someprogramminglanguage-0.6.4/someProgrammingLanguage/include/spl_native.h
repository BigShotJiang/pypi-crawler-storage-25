/*
 * SPL native C/C++ libraries: implement spl_register and link as a shared library.
 * Use extern "C" in C++ so the symbol name is not mangled.
 */
#ifndef SPL_NATIVE_H
#define SPL_NATIVE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef double (*spl_double_fn)(void);

typedef void (*spl_add_double_void_fn)(
    const char *namespace_,
    const char *name,
    spl_double_fn impl);

void spl_register(spl_add_double_void_fn add);

#ifdef __cplusplus
}
#endif

#endif
