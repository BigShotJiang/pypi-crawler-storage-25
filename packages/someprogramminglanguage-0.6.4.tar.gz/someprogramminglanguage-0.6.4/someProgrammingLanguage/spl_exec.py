"""Run SPL source via the packaged interpreter (Codespace / practice judge)."""

from __future__ import annotations

import contextlib
import io
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# Package root: someProgrammingLanguage/ (contains main.py, lib/, spl_site/)
_PKG_ROOT = Path(__file__).resolve().parent
SPL_MAIN = _PKG_ROOT / "main.py"


def _use_inprocess() -> bool:
    """Pyodide/WASM has no real subprocess; optional env for local tests."""
    if os.environ.get("SPL_FORCE_INPROCESS") == "1":
        return True
    return sys.platform == "emscripten"


def strip_spl_banner(stdout: str) -> str:
    lines = stdout.splitlines(keepends=True)
    if lines and lines[0].startswith("---SPL OS"):
        return "".join(lines[1:])
    return stdout


def normalize_output(s: str) -> str:
    return (s or "").replace("\r\n", "\n").rstrip()


def run_spl_source_inprocess(
    code: str,
    *,
    timeout: float = 15.0,
    stdin: str | None = None,
) -> tuple[bool, str, str, int]:
    """
    Run SPL in-process (no subprocess). Used in Pyodide; ``timeout`` is ignored there.
    """
    del timeout  # no reliable wall-clock timeout in browser; interpreter has loop limits
    if not SPL_MAIN.is_file():
        return False, "", f"Interpreter not found: {SPL_MAIN}", -1

    from .main import (
        BreakSignal,
        ContinueSignal,
        Interpreter,
        Parser,
        ReturnSignal,
        SPLException,
        tokenize,
        _print_spl_error,
    )

    old_cwd = os.getcwd()
    old_stdin = sys.stdin
    out_buf = io.StringIO()
    err_buf = io.StringIO()
    try:
        os.chdir(_PKG_ROOT)
        sys.stdin = io.StringIO(stdin) if stdin is not None else io.StringIO()
        with contextlib.redirect_stdout(out_buf), contextlib.redirect_stderr(err_buf):
            interpreter = Interpreter()
            fake_path = str(_PKG_ROOT / "__spl_inline__.spl")
            interpreter._spl_file_stack.append(fake_path)
            try:
                for node in Parser(tokenize(code)).parse():
                    try:
                        interpreter.run(node)
                    except BreakSignal:
                        _print_spl_error("Error: test.break used outside of a loop")
                        return (
                            False,
                            normalize_output(out_buf.getvalue()),
                            err_buf.getvalue(),
                            1,
                        )
                    except ContinueSignal:
                        _print_spl_error("Error: test.continue used outside of a loop")
                        return (
                            False,
                            normalize_output(out_buf.getvalue()),
                            err_buf.getvalue(),
                            1,
                        )
                    except ReturnSignal:
                        _print_spl_error("Error: return outside function")
                        return (
                            False,
                            normalize_output(out_buf.getvalue()),
                            err_buf.getvalue(),
                            1,
                        )
            finally:
                interpreter._spl_file_stack.pop()
    except SPLException as e:
        _print_spl_error(f"Error: {e}")
        return False, normalize_output(out_buf.getvalue()), err_buf.getvalue(), 1
    except Exception as e:
        _print_spl_error(f"Error: {e}")
        return False, normalize_output(out_buf.getvalue()), err_buf.getvalue(), 1
    finally:
        sys.stdin = old_stdin
        try:
            os.chdir(old_cwd)
        except OSError:
            pass

    return True, normalize_output(out_buf.getvalue()), err_buf.getvalue(), 0


def run_spl_source(
    code: str,
    *,
    timeout: float = 15.0,
    stdin: str | None = None,
) -> tuple[bool, str, str, int]:
    """
    Run SPL in a temp file with cwd = package root (so ``lib/`` resolves for ``use``).
    If ``stdin`` is set, it is fed to the process (for ``user.ask`` / ``input``).
    Returns (ok, stdout, stderr, exit_code).
    """
    if _use_inprocess():
        return run_spl_source_inprocess(code, timeout=timeout, stdin=stdin)

    if not SPL_MAIN.is_file():
        return False, "", f"Interpreter not found: {SPL_MAIN}", -1
    tmp_path: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".spl",
            delete=False,
            encoding="utf-8",
            dir=str(_PKG_ROOT),
        ) as tf:
            tf.write(code)
            tmp_path = tf.name
        run_kw: dict = {
            "cwd": str(_PKG_ROOT),
            "capture_output": True,
            "text": True,
            "timeout": timeout,
            "env": {**os.environ, "PYTHONUNBUFFERED": "1"},
        }
        if stdin is not None:
            run_kw["input"] = stdin
        proc = subprocess.run(
            [sys.executable, str(SPL_MAIN), tmp_path],
            **run_kw,
        )
        out = strip_spl_banner(proc.stdout or "")
        err = proc.stderr or ""
        return proc.returncode == 0, out, err, proc.returncode
    except subprocess.TimeoutExpired:
        return False, "", "Interpreter timed out.", -1
    except OSError as e:
        return False, "", str(e), -1
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
