"""
Practice checker: 20 seeded edge-case trials + 80 random trials (100 total).

Supports ``user.ask`` via subprocess stdin. Each problem supplies reference and user SPL per trial.
"""

from __future__ import annotations

import random
import secrets
from collections.abc import Callable
from typing import Any

from .spl_exec import normalize_output, run_spl_source

NUM_SEEDED = 20
NUM_RANDOM = 80
NUM_TRIALS = NUM_SEEDED + NUM_RANDOM

# (user_code, rng, trial_index) -> (reference_spl, user_full_spl, stdin_or_none)
Builder = Callable[[str, random.Random, int], tuple[str, str, str | None]]


def _pick_pair(
    trial: int,
    rng: random.Random,
    seeded: list[tuple[int, int]],
    lo: int,
    hi: int,
) -> tuple[int, int]:
    if trial < len(seeded):
        return seeded[trial]
    return rng.randint(lo, hi), rng.randint(lo, hi)


def _pick_int(trial: int, rng: random.Random, seeded: list[int], lo: int, hi: int) -> int:
    if trial < len(seeded):
        return seeded[trial]
    return rng.randint(lo, hi)


# --- Seeded edge pairs (a, b) for arithmetic harness problems ---
SEED_AB: list[tuple[int, int]] = [
    (0, 0),
    (0, 1),
    (1, 0),
    (1, 1),
    (500, 500),
    (13, 7),
    (2, 3),
    (999, 1),
    (1, 999),
    (100, 200),
    (42, 0),
    (0, 42),
    (250, 250),
    (3, 3),
    (17, 19),
    (20, 20),
    (99, 1),
    (1, 99),
    (123, 456),
    (456, 123),
]


def _multiply(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    a, b = _pick_pair(trial, rng, SEED_AB, 0, 500)
    prefix = f"a.setVar({a});\nb.setVar({b});\n"
    return prefix + "print.number(math.multiply(a, b));", prefix + uc, None


def _add(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    a, b = _pick_pair(trial, rng, SEED_AB, 0, 400)
    prefix = f"a.setVar({a});\nb.setVar({b});\n"
    return prefix + "print.number(math.add(a, b));", prefix + uc, None


def _loop123(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    ref = """test.forLoop(1, 3, i):
    print.number(i);
end;"""
    return ref, uc, None


def _concat(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        pairs = [
            ("a", "b"),
            ("z", "z"),
            ("x", "y"),
            ("m", "n"),
            ("q", "p"),
            ("c", "d"),
            ("e", "f"),
            ("g", "h"),
            ("i", "j"),
            ("k", "l"),
            ("o", "p"),
            ("r", "s"),
            ("t", "u"),
            ("v", "w"),
            ("a", "z"),
            ("b", "y"),
            ("c", "x"),
            ("d", "w"),
            ("e", "v"),
            ("f", "u"),
        ]
        c1, c2 = pairs[trial]
    else:
        c1 = rng.choice("abcdefghijklmnopqrstuvwxyz")
        c2 = rng.choice("abcdefghijklmnopqrstuvwxyz")
    prefix = f'c1.setVar("{c1}");\nc2.setVar("{c2}");\n'
    return prefix + "print.string(string.concatenate(c1, c2));", prefix + uc, None


def _fn_double(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    seed_n = [
        0,
        1,
        -1,
        42,
        500,
        999,
        7,
        8,
        13,
        100,
        200,
        333,
        17,
        19,
        23,
        29,
        31,
        37,
        41,
        43,
    ]
    n = seed_n[trial] if trial < len(seed_n) else rng.randint(-200, 500)
    ref = """functionDefine.double(x):
    return.number(math.multiply(x, 2));
end;
"""
    ref = ref + f"print.number(function.double({n}));"
    u = uc.strip() + f"\nprint.number(function.double({n}));"
    return ref, u, None


def _mod(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        pairs = [
            (0, 5),
            (1, 5),
            (4, 5),
            (17, 5),
            (100, 7),
            (99, 10),
            (50, 25),
            (13, 2),
            (8, 3),
            (9, 4),
            (11, 6),
            (14, 6),
            (15, 7),
            (16, 8),
            (18, 9),
            (20, 11),
            (21, 11),
            (22, 13),
            (24, 13),
            (26, 13),
        ]
        a, b = pairs[trial]
    else:
        b = rng.randint(2, 25)
        a = b * rng.randint(3, 40) + rng.randint(0, b - 1)
    prefix = f"a.setVar({a});\nb.setVar({b});\n"
    return prefix + "print.number(math.mod(a, b));", prefix + uc, None


def _subtract(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    a, b = _pick_pair(trial, rng, SEED_AB, 0, 250)
    if b > a:
        a, b = b, a
    prefix = f"a.setVar({a});\nb.setVar({b});\n"
    return prefix + "print.number(math.subtract(a, b));", prefix + uc, None


def _square(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    n = _pick_int(
        trial,
        rng,
        [0, 1, 2, 99, 100, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 50, 75, 98],
        0,
        99,
    )
    prefix = f"n.setVar({n});\n"
    return prefix + "print.number(math.multiply(n, n));", prefix + uc, None


def _list_first(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        triples = [
            (0, 1, 2),
            (1, 0, 0),
            (999, 1, 2),
            (10, 20, 30),
            (5, 5, 5),
            (100, 200, 300),
            (7, 8, 9),
            (11, 22, 33),
            (44, 55, 66),
            (1, 1, 2),
            (2, 1, 1),
            (3, 4, 5),
            (6, 7, 8),
            (12, 13, 14),
            (15, 16, 17),
            (18, 19, 20),
            (21, 22, 23),
            (24, 25, 26),
            (27, 28, 29),
            (30, 31, 32),
        ]
        a, b, c = triples[trial]
    else:
        a = rng.randint(1, 1000)
        b = rng.randint(1, 1000)
        c = rng.randint(1, 1000)
    prefix = f"list.createList([{a}, {b}, {c}], nums);\n"
    return prefix + "print.number(list.get(0, nums));", prefix + uc, None


def _uppercase(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        strings = [
            "hello",
            "a",
            "z",
            "test",
            "spl",
            "aaa",
            "zzz",
            "abc",
            "xyz",
            "longerstring",
            "qwerty",
            "uiop",
            "asdf",
            "hjkl",
            "mnbv",
            "cxz",
            "lkj",
            "poi",
            "ewq",
            "vbn",
        ]
        s = strings[trial]
    else:
        length = rng.randint(4, 12)
        s = "".join(rng.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(length))
    prefix = f's.setVar("{s}");\n'
    return prefix + "print.string(string.uppercase(s));", prefix + uc, None


def _strlen(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        strings = [
            "a",
            "ab",
            "abc",
            "",
            "hello",
            "x" * 15,
            "spl",
            "12345",
            "zzzz",
            "mmmm",
            "nnnn",
            "oooo",
            "pppp",
            "qqqq",
            "rrrr",
            "ssss",
            "tttt",
            "uuuu",
            "vvvv",
            "wwww",
        ]
        s = strings[trial]
    else:
        length = rng.randint(2, 15)
        s = "".join(rng.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(length))
    prefix = f's.setVar("{s}");\n'
    return prefix + "print.number(string.length(s));", prefix + uc, None


def _reverse(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        strings = [
            "spl",
            "a",
            "ab",
            "racecar",
            "hello",
            "zzzzz",
            "abcde",
            "fedcba",
            "qwert",
            "poiuy",
            "lkjhg",
            "mnbvc",
            "xxxxx",
            "yyyyy",
            "stuvw",
            "nopqr",
            "ijklm",
            "defgh",
            "abcba",
            "xyzzx",
        ]
        s = strings[trial]
    else:
        length = rng.randint(3, 10)
        s = "".join(rng.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(length))
    prefix = f's.setVar("{s}");\n'
    return prefix + "print.string(string.reverse(s));", prefix + uc, None


def _is_even(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        evens = [
            0,
            2,
            4,
            100,
            1000,
            8,
            10,
            12,
            14,
            16,
            18,
            20,
            22,
            24,
            26,
            28,
            30,
            32,
            34,
            36,
        ]
        n = evens[trial]
    else:
        n = rng.randint(0, 500) * 2
    prefix = f"n.setVar({n});\n"
    ref = prefix + """test.ifTrue(test.isEven(n)):
    print.string("even");
end;"""
    return ref, prefix + uc, None


def _divide(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        pairs = [
            (0, 5),
            (10, 2),
            (100, 4),
            (99, 3),
            (1000, 10),
            (14, 7),
            (15, 5),
            (16, 4),
            (18, 6),
            (20, 5),
            (21, 7),
            (22, 11),
            (24, 8),
            (25, 5),
            (27, 9),
            (28, 7),
            (30, 6),
            (32, 8),
            (33, 11),
            (35, 7),
        ]
        a, b = pairs[trial]
    else:
        b = rng.randint(2, 25)
        q = rng.randint(2, 40)
        a = b * q
    prefix = f"a.setVar({a});\nb.setVar({b});\n"
    return prefix + "print.number(math.div(a, b));", prefix + uc, None


def _floor(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < NUM_SEEDED:
        xs = [
            0.7,
            1.1,
            9.99,
            100.001,
            -0.3,
            5.5,
            12.34,
            3.14159,
            2.718,
            1.999,
            4.001,
            8.88,
            7.77,
            6.66,
            11.11,
            13.13,
            15.15,
            17.17,
            19.19,
            21.21,
        ]
        x = xs[trial]
    else:
        whole = rng.randint(1, 200)
        frac = rng.uniform(0.01, 0.99)
        x = whole + frac
    xs = f"{x:.12f}".rstrip("0").rstrip(".")
    prefix = f"x.setVar({xs});\n"
    return prefix + "print.number(math.floor(x));", prefix + uc, None


# --- stdin-based (user.ask) problems: reference and user are full programs ---

REF_ASK_DOUBLE = """n.setVar(string.convertInt(user.ask("")));
print.number(math.multiply(n, 2));"""

REF_ASK_SUM2 = """a.setVar(string.convertInt(user.ask("")));
b.setVar(string.convertInt(user.ask("")));
print.number(math.add(a, b));"""

REF_ASK_MAX = """a.setVar(string.convertInt(user.ask("")));
b.setVar(string.convertInt(user.ask("")));
test.ifTrue(test.isGreater(a, b)):
    print.number(a);
end;
test.else():
    print.number(b);
end;"""

REF_ASK_HELLO = """name.setVar(user.ask(""));
print.string(string.concatenate("Hello, ", name));"""

REF_ASK_SQUARE = """n.setVar(string.convertInt(user.ask("")));
print.number(math.multiply(n, n));"""


def _stdin_for_two_ints(a: int, b: int) -> str:
    return f"{a}\n{b}\n"


SEED_ASK_DOUBLE_LINES = [
    "0",
    "1",
    "-1",
    "42",
    "99999",
    "-500000",
    "7",
    "8",
    "13",
    "100",
    "1000",
    "2147483647",
    "-2147483648",
    "3",
    "4",
    "5",
    "6",
    "9",
    "10",
    "11",
]

SEED_ASK_SUM2_PAIRS = [
    (0, 0),
    (0, 5),
    (-3, 3),
    (100, 200),
    (1, 1),
    (999, 1),
    (1, 999),
    (-10, 10),
    (50, 50),
    (123, 456),
    (7, 8),
    (9, 10),
    (11, 12),
    (13, 14),
    (15, 16),
    (17, 18),
    (19, 20),
    (21, 22),
    (23, 24),
    (25, 26),
]

SEED_ASK_MAX_PAIRS = [
    (0, 0),
    (1, 2),
    (2, 1),
    (-5, -3),
    (100, 99),
    (99, 100),
    (42, 42),
    (7, 8),
    (8, 7),
    (0, 1),
    (1, 0),
    (500, 499),
    (3, 3),
    (10, 20),
    (20, 10),
    (-1, 1),
    (1, -1),
    (33, 44),
    (44, 33),
    (1000, 1000),
]

SEED_ASK_NAMES = [
    "",
    "a",
    "Ada",
    "World",
    "spl",
    "x",
    "test",
    "user",
    "hello",
    "there",
    "abc",
    "xyz",
    "longname",
    "short",
    "n",
    "m",
    "p",
    "q",
    "r",
    "s",
]

SEED_ASK_SQUARE = [
    "0",
    "1",
    "-1",
    "12",
    "99",
    "100",
    "7",
    "8",
    "9",
    "10",
    "11",
    "13",
    "15",
    "17",
    "19",
    "21",
    "23",
    "25",
    "50",
    "77",
]


def _ask_double(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < len(SEED_ASK_DOUBLE_LINES):
        line = SEED_ASK_DOUBLE_LINES[trial]
    else:
        line = str(rng.randint(-500_000, 500_000))
    return REF_ASK_DOUBLE, uc.strip(), line + "\n"


def _ask_sum2(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < len(SEED_ASK_SUM2_PAIRS):
        a, b = SEED_ASK_SUM2_PAIRS[trial]
    else:
        a = rng.randint(-1000, 1000)
        b = rng.randint(-1000, 1000)
    return REF_ASK_SUM2, uc.strip(), _stdin_for_two_ints(a, b)


def _ask_max(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < len(SEED_ASK_MAX_PAIRS):
        a, b = SEED_ASK_MAX_PAIRS[trial]
    else:
        a = rng.randint(-500, 500)
        b = rng.randint(-500, 500)
    return REF_ASK_MAX, uc.strip(), _stdin_for_two_ints(a, b)


def _ask_hello(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < len(SEED_ASK_NAMES):
        name = SEED_ASK_NAMES[trial]
    else:
        length = rng.randint(0, 12)
        name = "".join(rng.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(length))
    return REF_ASK_HELLO, uc.strip(), name + "\n"


def _ask_square(uc: str, rng: random.Random, trial: int) -> tuple[str, str, str | None]:
    if trial < len(SEED_ASK_SQUARE):
        line = SEED_ASK_SQUARE[trial]
    else:
        line = str(rng.randint(-200, 200))
    return REF_ASK_SQUARE, uc.strip(), line + "\n"


PROBLEMS: dict[str, Builder] = {
    "multiply": _multiply,
    "add42": _add,
    "loop123": _loop123,
    "concat-ab": _concat,
    "fn-double": _fn_double,
    "mod": _mod,
    "subtract99": _subtract,
    "square36": _square,
    "list-first": _list_first,
    "uppercase": _uppercase,
    "strlen": _strlen,
    "reverse": _reverse,
    "is-even": _is_even,
    "divide": _divide,
    "floor": _floor,
    "ask-double": _ask_double,
    "ask-sum2": _ask_sum2,
    "ask-max": _ask_max,
    "ask-hello": _ask_hello,
    "ask-square": _ask_square,
}


def judge_practice(problem_id: str, user_code: str) -> dict[str, Any]:
    if problem_id not in PROBLEMS:
        return {"ok": False, "error": "unknown problem", "passed": False}

    builder = PROBLEMS[problem_id]
    rng = random.Random(secrets.randbits(64))
    per_timeout = 2.5

    for trial in range(NUM_TRIALS):
        ref_spl, user_spl, stdin = builder(user_code, rng, trial)
        ok_r, out_r, err_r, _ = run_spl_source(ref_spl, timeout=per_timeout, stdin=stdin)
        if not ok_r:
            return {
                "ok": True,
                "passed": False,
                "testsRun": trial + 1,
                "failedAt": trial + 1,
                "phase": "reference",
                "detail": f"Reference failed (interpreter bug?): {err_r or out_r}",
            }
        ok_u, out_u, err_u, _ = run_spl_source(user_spl, timeout=per_timeout, stdin=stdin)
        if not ok_u:
            return {
                "ok": True,
                "passed": False,
                "testsRun": trial + 1,
                "failedAt": trial + 1,
                "phase": "user",
                "detail": err_u or "(no stderr)",
                "stdout": out_u,
            }
        if normalize_output(out_r) != normalize_output(out_u):
            return {
                "ok": True,
                "passed": False,
                "testsRun": trial + 1,
                "failedAt": trial + 1,
                "phase": "compare",
                "detail": "Output did not match the reference on this trial.",
                "expectedSample": normalize_output(out_r),
                "gotSample": normalize_output(out_u),
            }

    return {
        "ok": True,
        "passed": True,
        "testsRun": NUM_TRIALS,
        "seededTrials": NUM_SEEDED,
        "randomTrials": NUM_RANDOM,
        "failedAt": None,
    }
