"""
Serve the bundled SPL reference site (spl_site/) and POST /api/run, /api/practice-check.

Installed package usage:
  spl-web

Or:
  python -m someProgrammingLanguage.web_server

Works from any working directory after ``pip install someProgrammingLanguage``.
"""

from __future__ import annotations

import json
import os
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

from .practice_judge import judge_practice
from .spl_exec import SPL_MAIN, run_spl_source

_PKG_ROOT = Path(__file__).resolve().parent
SPL_SITE = _PKG_ROOT / "spl_site"

DEFAULT_PORT = 8765


class SplSiteHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(SPL_SITE), **kwargs)

    def log_message(self, format: str, *args) -> None:  # noqa: A003
        sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), format % args))

    def _path_only(self) -> str:
        p = self.path.split("?", 1)[0].split("#", 1)[0]
        if len(p) > 1 and p.endswith("/"):
            p = p[:-1]
        return p or "/"

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self) -> None:  # noqa: N802
        p = self._path_only()
        if p not in ("/api/run", "/api/practice-check"):
            self.send_error(404, "Not Found")
            return
        self.send_response(204)
        self._send_cors_headers()
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()

    def do_POST(self) -> None:  # noqa: N802
        path = self._path_only()
        if path == "/api/practice-check":
            self._handle_practice_check()
            return
        if path == "/api/run":
            self._handle_run()
            return
        self.send_error(404, "Not Found")

    def _handle_run(self) -> None:
        if not SPL_MAIN.is_file():
            self.send_json(
                500,
                {
                    "ok": False,
                    "error": f"Interpreter not found: {SPL_MAIN}",
                    "stdout": "",
                    "stderr": "",
                    "exitCode": -1,
                },
            )
            return
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            self.send_json(400, {"ok": False, "error": "Invalid JSON"})
            return
        code = payload.get("code")
        if not isinstance(code, str):
            self.send_json(400, {"ok": False, "error": "Missing string 'code'"})
            return

        ok, out, err, code_exit = run_spl_source(code, timeout=15.0)
        self.send_json(
            200,
            {
                "ok": ok,
                "stdout": out,
                "stderr": err,
                "exitCode": code_exit,
            },
        )

    def _handle_practice_check(self) -> None:
        if not SPL_MAIN.is_file():
            self.send_json(
                500,
                {"ok": False, "error": f"Interpreter not found: {SPL_MAIN}"},
            )
            return
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            self.send_json(400, {"ok": False, "error": "Invalid JSON"})
            return
        pid = payload.get("problemId")
        code = payload.get("code")
        if not isinstance(pid, str) or not isinstance(code, str):
            self.send_json(400, {"ok": False, "error": "Need string problemId and code"})
            return
        result = judge_practice(pid, code)
        self.send_json(200, result)

    def send_json(self, status: int, obj: dict) -> None:
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)


def _listen_address() -> tuple[str, int]:
    """Local dev: 127.0.0.1 + SPL_PORT. Cloud: 0.0.0.0 + PORT (Render/Railway/Fly)."""
    port = int(os.environ.get("PORT", os.environ.get("SPL_PORT", str(DEFAULT_PORT))))
    explicit = os.environ.get("SPL_BIND", "").strip()
    if explicit:
        bind = explicit
    elif os.environ.get("PORT"):
        bind = "0.0.0.0"
    else:
        bind = "127.0.0.1"
    return bind, port


def main() -> None:
    bind, port = _listen_address()
    if not SPL_MAIN.is_file():
        print(f"error: interpreter missing: {SPL_MAIN}", file=sys.stderr)
        sys.exit(1)
    if not SPL_SITE.is_dir():
        print(f"error: site bundle missing: {SPL_SITE}", file=sys.stderr)
        sys.exit(1)
    server = HTTPServer((bind, port), SplSiteHandler)
    print(f"SPL site + /api/run → http://127.0.0.1:{port}/index.html (bind {bind})")
    print("  (command: spl-web   or   python -m someProgrammingLanguage.web_server)")
    if bind not in ("127.0.0.1", "::1", "localhost"):
        print(f"  (listening on {bind}:{port} — use your host’s public URL over HTTPS when deployed)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
