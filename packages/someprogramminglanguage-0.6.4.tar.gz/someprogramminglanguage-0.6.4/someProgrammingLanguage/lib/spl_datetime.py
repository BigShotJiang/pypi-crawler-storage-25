"""Date/time helpers for SPL (registered via spl_register)."""

reqFileExtension = False;
from datetime import date, datetime, timezone


def spl_register(interpreter):
    def now_iso_utc():
        return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    def now_iso_local():
        return datetime.now().replace(microsecond=0).isoformat()

    def today():
        return date.today().isoformat()

    def time_of_day():
        return datetime.now().time().replace(microsecond=0).isoformat()

    def weekday_index():
        # Monday = 0 .. Sunday = 6 (matches Python weekday())
        return int(date.today().weekday())

    def weekday_name():
        names = [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday",
        ]
        return names[date.today().weekday()]

    def month():
        return int(date.today().month)

    def day_of_month():
        return int(date.today().day)

    def year():
        return int(date.today().year)

    def unix_timestamp():
        return float(datetime.now().timestamp())

    interpreter.library["datetime"] = {
        "nowIsoUtc": now_iso_utc,
        "nowIsoLocal": now_iso_local,
        "today": today,
        "timeOfDay": time_of_day,
        "weekdayIndex": weekday_index,
        "weekdayName": weekday_name,
        "month": month,
        "day": day_of_month,
        "year": year,
        "unixTimestamp": unix_timestamp,
    }
