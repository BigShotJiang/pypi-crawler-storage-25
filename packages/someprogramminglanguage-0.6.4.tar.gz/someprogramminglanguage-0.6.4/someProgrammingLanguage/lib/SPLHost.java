import java.util.function.Supplier;

/** Passed into your public static void splRegister(SPLHost host). */
public interface SPLHost {
    void registerDoubleVoid(String ns, String name, Supplier<Double> impl);
}
