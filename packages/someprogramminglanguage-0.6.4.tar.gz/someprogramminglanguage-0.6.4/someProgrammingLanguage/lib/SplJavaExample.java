/** Example Java SPL library (requires jpype1). See SPLHost.java. */
public class SplJavaExample {
    static boolean reqFileExtension = false;

    public static void splRegister(SPLHost host) {
        host.registerDoubleVoid(
                "javademo",
                "tau",
                () -> Double.valueOf(6.283185307179586));
    }
}
