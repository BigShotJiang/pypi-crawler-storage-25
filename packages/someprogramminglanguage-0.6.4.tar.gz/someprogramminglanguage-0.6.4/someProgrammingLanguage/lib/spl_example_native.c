#include <stdbool.h>
#include "spl_native.h"

bool reqFileExtension = false;

static double pi_impl(void) {
    return 3.14159265358979323846;
}

void spl_register(spl_add_double_void_fn add) {
    add("native", "pi", pi_impl);
}
