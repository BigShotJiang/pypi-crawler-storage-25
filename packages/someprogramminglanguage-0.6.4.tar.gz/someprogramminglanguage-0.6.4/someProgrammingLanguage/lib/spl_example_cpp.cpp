#include "spl_native.h"
#include <cmath>

bool reqFileExtension = false;

static double sqrt2_impl(void) { return std::sqrt(2.0); }

extern "C" void spl_register(spl_add_double_void_fn add) {
    add("native", "sqrt2", sqrt2_impl);
}
