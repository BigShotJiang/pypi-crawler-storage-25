# SPL (`someProgrammingLanguage`)

SPL is a small programming language with an interpreter written in Python. Programs are `.spl` files run on the machine where the package is installed.

## Install and run

```bash
pip install someProgrammingLanguage
run-spl yourprogram.spl
```

## Language reference

Guides and a searchable API table:

**[SPL Language Reference](https://spl-site.netlify.app/)**

## Bundled reference site (`spl-web`)

The package includes an HTML reference (under `someProgrammingLanguage/spl_site/`). To view it locally with **Run** and **Practice** enabled:

```bash
spl-web
```

Open the URL printed in the terminal (often `http://127.0.0.1:8765/`). If `spl-web` is missing from the shell, reinstall or ensure the package scripts are on `PATH`.

Alternate entrypoints:

```bash
python3 -m someProgrammingLanguage.web_server
```

Use `SPL_PORT` to change the port (e.g. `SPL_PORT=8766 spl-web`).

---

Development, hosting the site for others, and validating reference data: **[CONTRIBUTING.md](CONTRIBUTING.md)**.
