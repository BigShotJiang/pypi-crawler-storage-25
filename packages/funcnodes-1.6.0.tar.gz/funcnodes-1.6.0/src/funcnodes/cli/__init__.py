"""CLI helpers for FuncNodes."""
