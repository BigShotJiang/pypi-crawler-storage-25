# pyarrlib

A small Python utility library for working with arrays and nested nested array structures.

This project provides simple helper functions for reversing arrays, computing numeric aggregates, counting nested leaves, flattening nested structures, and solving small systems of linear equations.

## Features

- `reverse_arr(array)` — reverse a one-dimensional sequence
- `sum_arr(array)` — compute the sum of numeric values
- `multiplication_arr(array)` — compute the product of numeric values
- `min(array)` — find the smallest numeric value in a sequence
- `max(array)` — find the largest numeric value in a sequence
- `arifmetic_mean(array)` — compute the arithmetic mean of numeric values
- `leafs(array)` — flatten nested integer arrays
- `num_of_leafs(array)` — count integer leaf nodes in nested arrays
- `len_arr(array)` — count all scalar leaves in nested arrays
- `equation_system(full_matrix)` — solve 2×2 or 3×3 linear systems using determinants

## Installation

From the repository root, install in editable mode:

```bash
python -m pip install -e .
```

If you prefer not to install, you can run code directly from this project by ensuring the repository root is on `PYTHONPATH`.

## Usage

```python
from scr import (
    ArrayTypeError,
    arifmetic_mean,
    equation_system,
    leafs,
    len_arr,
    max,
    min,
    multiplication_arr,
    num_of_leafs,
    reverse_arr,
    sum_arr,
)

print(reverse_arr([1, 'hello', 3, True]))
# [True, 3, 'hello', 1]

print(sum_arr([1, 5, 4, 3, 8]))
# 21

print(multiplication_arr([4, 1, 2, 5, 7]))
# 280

print(min([1, 3, 6, -3, 2]))
# -3

print(arifmetic_mean([2, 4, 6]))
# 4.0

nested = [[1, 2, [3]], [4, [5, 6]]]
print(leafs(nested))
# [1, 2, 3, 4, 5, 6]
print(num_of_leafs(nested))
# 6
print(len_arr(nested))
# 6

system = [
    [2, -1, 1],
    [1, 1, 1],
    [1, 2, -1],
]
print(equation_system([row + [value] for row, value in zip(system, [1, 2, 3])]))
```

## API Reference

### `ArrayTypeError`

A sentinel error type used by numeric functions when an array contains unsupported element types.

### `reverse_arr(array)`

Return a new sequence with the elements in reverse order.

### `sum_arr(array)`

Return the sum of numeric values in the array.

If the array contains a non-numeric element, the function returns the class `ArrayTypeError`.

### `multiplication_arr(array)`

Return the product of numeric values in the array.

If the array contains a non-numeric element, the function returns `ArrayTypeError`.

### `min(array)`

Return the smallest value from a one-dimensional sequence.

### `max(array)`

Return the largest value from a one-dimensional sequence.

### `arifmetic_mean(array)`

Return the arithmetic mean of numeric values in the array.

### `leafs(array)`

Return a flat list containing all integer leaf values from a nested array structure.

### `num_of_leafs(array)`

Count integer leaf nodes recursively in a nested array structure.

### `len_arr(array)`

Count all scalar leaf values in a nested array structure.
Supported scalar types include `int`, `str`, `float`, and `bool`.

### `equation_system(full_matrix)`

Solve a 2×2 or 3×3 system of linear equations supplied as an augmented matrix.
The function returns a list of solution values or the string `"has no solution"` when the determinant is zero.

## Running the included checks

The repository includes a simple assertion-based test file.

```bash
python tests/test.py
```

## Project structure

- `setup.py` — package metadata and build configuration
- `README.md` — project documentation
- `scr/arrpy.py` — array utility functions and error type
- `scr/multidim_arr.py` — nested array traversal functions
- `tests/test.py` — example assertions covering core behavior

## License

This project is licensed under MIT.
