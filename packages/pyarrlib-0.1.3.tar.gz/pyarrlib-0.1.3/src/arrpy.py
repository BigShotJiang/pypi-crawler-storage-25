from ._checks import check

class ArrayTypeError(Exception):
    ...
class IsNotArrayError(Exception):
    ...


def reverse_arr(array):
    return array[::-1]

def sum_arr(array):
    if isinstance(array, (int, str, bool, float)):
        raise IsNotArrayError   
    res = 0
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else: res += i
    return res

def multiplication_arr(array):
    check(array)
    res = 1
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else:
            res *= i
    return res

def min(array):
    if isinstance(array, (int, str, bool, float)):
        raise IsNotArrayError
    res = array[0]
    for i in array:
        if i < res:
            res = i
        elif not isinstance(i, int, float):
            raise ArrayTypeError
        return res
        
def max(array):
    if isinstance(array, (int, str, bool, float)):
        raise IsNotArrayError   
    res = array[0]
    for i in array:
        if i > res:
            res = i
        elif not isinstance(i, int, float):
            raise ArrayTypeError
        return res
def arifmetic_mean(array):
    if isinstance(array, (int, str, bool, float)):
        raise IsNotArrayError
    s = sum_arr(array)
    return s / len(array)