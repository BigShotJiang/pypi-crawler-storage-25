"""RabbitMQ configuration for PolyBus transport."""

from datetime import timedelta
from logging import Logger, getLogger
from typing import Any, Dict, Optional


class RabbitMqConfig:
    """Configuration for RabbitMQ transport."""

    def __init__(self) -> None:
        """Initialize RabbitMQ configuration with default values."""
        self.queue_arguments: Dict[str, Any] = {"x-queue-type": "quorum"}
        self.log: Logger = getLogger(__name__)
        self.network_recovery_interval: timedelta = timedelta(seconds=10)
        self.command_exchange_name: str = "polybus.commands"
        self.delay_delivery: str = "polybus.delay"
        self.direct_exchange_name: str = "polybus.direct"
        self.event_exchange_name: str = "polybus.events"
        self.client_provided_name: Optional[str] = None
        self.connection_string: str = ""
        self.dead_letter_queue_name: Optional[str] = None
        self.queue_name: Optional[str] = None

    async def create(self, builder: Any, bus: Any) -> Any:
        """
        Create a RabbitMQ transport instance.

        Args:
            builder: The PolyBus builder instance
            bus: The PolyBus instance

        Returns:
            A RabbitMqTransport instance
        """
        from .rabbitmq_transport import RabbitMqTransport

        queue_name = self.queue_name or bus.name
        self.log.info(f"Creating RabbitMQ transport for: {queue_name}")
        return RabbitMqTransport(self, bus)
