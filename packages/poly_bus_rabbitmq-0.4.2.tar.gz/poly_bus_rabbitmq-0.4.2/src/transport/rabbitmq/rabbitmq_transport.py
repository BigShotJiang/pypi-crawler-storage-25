"""RabbitMQ transport implementation for PolyBus."""

import asyncio
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse

import pika
from pika.adapters.blocking_connection import BlockingConnection
from pika.channel import Channel
from pika.spec import Basic, BasicProperties

from .rabbitmq_config import RabbitMqConfig


class AsyncChannelAdapter:
    """Async-friendly adapter around pika BlockingChannel."""

    def __init__(self, channel: Channel) -> None:
        self._channel = channel

    async def basic_get(self, *args: Any, **kwargs: Any) -> Any:
        return self._channel.basic_get(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._channel, name)


class RabbitMqTransport:
    """RabbitMQ transport implementation for PolyBus message handling."""

    DELAY_QUEUE_COUNT: int = 27  # MaxNumberOfBitsToUse - 1
    MAX_NUMBER_OF_BITS_TO_USE: int = 28

    def __init__(self, config: RabbitMqConfig, bus: Any) -> None:
        """
        Initialize RabbitMQ transport.

        Args:
            config: RabbitMQ configuration
            bus: PolyBus instance
        """
        self.config = config
        self.bus = bus
        self.channel: Optional[Any] = None
        self.connection: Optional[BlockingConnection] = None
        self.queue_name = config.queue_name or bus.name
        self.dead_letter_endpoint = (
            config.dead_letter_queue_name or f"{bus.name}.dead.letters"
        )
        self._consume_tag: Optional[str] = None
        self._consume_task: Optional[asyncio.Task[None]] = None
        self._in_flight_tasks: Set[asyncio.Task[Any]] = set()

    @property
    def supports_command_messages(self) -> bool:
        """Whether this transport supports command messages."""
        return True

    @property
    def supports_delayed_commands(self) -> bool:
        """Whether this transport supports delayed command delivery."""
        return True

    @property
    def supports_subscriptions(self) -> bool:
        """Whether this transport supports event subscriptions."""
        return True

    async def handle_message(
        self, channel: Channel, method: Basic.Deliver, properties: BasicProperties, body: bytes
    ) -> None:
        """
        Handle incoming RabbitMQ message.

        Args:
            channel: RabbitMQ channel
            method: Delivery method
            properties: Message properties
            body: Message body
        """
        try:
            # Extract headers
            headers: Dict[str, str] = {}
            if properties.headers:
                for key, value in properties.headers.items():
                    if isinstance(value, bytes):
                        headers[key] = value.decode("utf-8")
                    elif isinstance(value, str):
                        headers[key] = value

            # Get message type header
            message_type_header = headers.get("message-type", "")

            # Get message info from header (assuming a function exists in bus.messages)
            message_info = self.bus.messages.get_attribute_from_header(
                message_type_header
            )
            if message_info is None:
                raise ValueError(
                    f"Missing or invalid message header for message on queue: {self.queue_name}"
                )

            # Create incoming message
            incoming_message = self.bus.create_incoming_message(
                body=body.decode("utf-8"), message_info=message_info, headers=headers
            )

            # Create and commit transaction
            transaction = await self.bus.create_incoming_transaction(incoming_message)
            await transaction.commit()

            # Acknowledge message
            channel.basic_ack(delivery_tag=method.delivery_tag)

        except Exception as error:
            self.config.log.error(f"Error handling message: {error}", exc_info=True)

    async def handle(self, transaction: Any) -> None:
        """
        Handle outgoing transaction by publishing messages.

        Args:
            transaction: Transaction containing outgoing messages
        """
        channel = self.channel
        if channel is None:
            self.config.log.error(f"Cannot send message from: {self.queue_name}")
            return

        messages: List[Tuple[BasicProperties, str, str, bytes]] = []

        for outgoing_message in transaction.outgoing_messages:
            # Prepare headers
            header = self.bus.messages.get_header_by_message_info(
                outgoing_message.message_info
            )
            if header:
                outgoing_message.headers["message-type"] = header

            # Create properties
            properties = BasicProperties(headers=outgoing_message.headers)

            # Determine exchange
            exchange = self.config.direct_exchange_name
            if outgoing_message.endpoint is None:
                message_type = str(outgoing_message.message_info.type)
                if message_type.lower() == "command":
                    exchange = self.config.command_exchange_name
                else:
                    exchange = self.config.event_exchange_name

            # Determine routing key
            routing_key = outgoing_message.endpoint or self.get_routing_key(
                subscribe=False, message_info=outgoing_message.message_info
            )

            # Handle delayed delivery
            if outgoing_message.deliver_at is not None:
                receive_time = outgoing_message.deliver_at
                delay = receive_time - datetime.utcnow()
                delay_in_seconds = int(delay.total_seconds())

                if delay_in_seconds > 0:
                    # Convert delay to binary representation
                    bit_array = [(delay_in_seconds >> i) & 1 for i in range(self.DELAY_QUEUE_COUNT + 1)]
                    
                    # Find starting delay queue
                    starting_delay_queue = 0
                    for n in range(self.DELAY_QUEUE_COUNT, -1, -1):
                        if bit_array[n]:
                            starting_delay_queue = n
                            break

                    # Build routing key with bit pattern
                    parts = []
                    for n in range(self.DELAY_QUEUE_COUNT, -1, -1):
                        parts.append("1" if bit_array[n] else "0")
                    parts.append(
                        outgoing_message.endpoint
                        or outgoing_message.message_info.endpoint
                    )

                    routing_key = ".".join(parts)
                    exchange = self.delay_queue_name(starting_delay_queue)

            messages.append(
                (properties, routing_key, exchange, outgoing_message.body.encode("utf-8"))
            )

        # Publish all messages
        for properties, routing_key, exchange, body in messages:
            self.config.log.info(
                f"Publishing to {exchange} using routing key {routing_key}"
            )
            channel.basic_publish(
                exchange=exchange,
                routing_key=routing_key,
                body=body,
                properties=properties,
                mandatory=False,
            )

    async def start(self) -> None:
        """Start the RabbitMQ transport and begin consuming messages."""
        if self.channel is not None:
            self.config.log.error(
                f"RabbitMQ channel is already started for: {self.queue_name}"
            )
            return

        self.config.log.info(f"Starting RabbitMQ channel for: {self.queue_name}")

        # Parse connection string
        connection_url = urlparse(self.config.connection_string)
        
        # Create connection parameters
        credentials = pika.PlainCredentials(
            connection_url.username or "guest",
            connection_url.password or "guest"
        )
        
        vhost = "/" if connection_url.path in ["", "/"] else connection_url.path.lstrip("/")
        
        parameters = pika.ConnectionParameters(
            host=connection_url.hostname or "localhost",
            port=connection_url.port or 5672,
            virtual_host=vhost,
            credentials=credentials,
            # Closest equivalent for .NET NetworkRecoveryInterval in pika's sync client.
            retry_delay=self.config.network_recovery_interval.total_seconds(),
            client_properties={
                "connection_name": self.config.client_provided_name or self.queue_name
            },
        )

        # Create connection (synchronous for pika)
        self.connection = pika.BlockingConnection(parameters)
        self.channel = AsyncChannelAdapter(self.connection.channel())

        # Declare queue
        self.channel.queue_declare(
            queue=self.queue_name,
            durable=True,
            exclusive=False,
            auto_delete=False,
            arguments=self.config.queue_arguments,
        )

        # Declare command, direct, and event exchanges
        self.channel.exchange_declare(
            exchange=self.config.command_exchange_name,
            exchange_type="topic",
            durable=True,
        )
        self.channel.queue_bind(
            queue=self.queue_name,
            exchange=self.config.command_exchange_name,
            routing_key=f"Command.{self.queue_name}.#",
        )

        self.channel.exchange_declare(
            exchange=self.config.direct_exchange_name,
            exchange_type="topic",
            durable=True,
        )
        self.channel.queue_bind(
            queue=self.queue_name,
            exchange=self.config.direct_exchange_name,
            routing_key=self.queue_name,
        )

        self.channel.exchange_declare(
            exchange=self.config.event_exchange_name,
            exchange_type="topic",
            durable=True,
        )

        # Declare dead letter queue
        self.channel.queue_declare(
            queue=self.dead_letter_endpoint,
            durable=True,
            exclusive=False,
            auto_delete=False,
            arguments=self.config.queue_arguments,
        )
        self.channel.queue_bind(
            queue=self.dead_letter_endpoint,
            exchange=self.config.direct_exchange_name,
            routing_key=self.dead_letter_endpoint,
        )

        # Setup delay queues
        await self.setup_delay_queues()

        # Start consuming
        def on_message(
            channel: Channel,
            method: Basic.Deliver,
            properties: BasicProperties,
            body: bytes,
        ) -> None:
            task = asyncio.create_task(
                self.handle_message(channel, method, properties, body)
            )
            self._in_flight_tasks.add(task)
            task.add_done_callback(self._in_flight_tasks.discard)

        self._consume_tag = self.channel.basic_consume(
            queue=self.queue_name,
            on_message_callback=on_message,
            auto_ack=False,
        )
        self._consume_task = asyncio.create_task(self._process_events())

    async def _process_events(self) -> None:
        """Pump BlockingConnection events so callbacks are executed."""
        while self.connection is not None and self.channel is not None:
            try:
                self.connection.process_data_events(time_limit=0)
            except Exception as error:
                self.config.log.error(f"Error while processing RabbitMQ events: {error}")
                break
            await asyncio.sleep(0.01)

    async def stop(self) -> None:
        """Stop the RabbitMQ transport and close connections."""
        if self._consume_task:
            self._consume_task.cancel()
            try:
                await self._consume_task
            except asyncio.CancelledError:
                pass
            self._consume_task = None

        if self._in_flight_tasks:
            await asyncio.gather(*self._in_flight_tasks, return_exceptions=True)
            self._in_flight_tasks.clear()

        # Stop consuming
        if self._consume_tag and self.channel:
            try:
                self.channel.basic_cancel(self._consume_tag)
            except Exception:
                pass
            self._consume_tag = None

        # Close channel
        if self.channel:
            try:
                self.channel.close()
            except Exception:
                pass
            self.channel = None

        # Close connection
        if self.connection:
            try:
                self.connection.close()
            except Exception:
                pass
            self.connection = None

    async def subscribe(self, message_info: Any) -> None:
        """
        Subscribe to messages of a specific type.

        Args:
            message_info: Information about the message type to subscribe to
        """
        if self.channel is None:
            raise RuntimeError("RabbitMQ channel is not initialized")

        # Bind queue to exchange with routing key
        self.channel.queue_bind(
            queue=self.queue_name,
            exchange=self.config.event_exchange_name,
            routing_key=self.get_routing_key(subscribe=True, message_info=message_info),
        )

    async def setup_delay_queues(self) -> None:
        """
        Setup delay queues for delayed message delivery.
        
        Each queue has a TTL of 2^N seconds where N is the index.
        Messages are routed through queues based on binary representation of delay.
        """
        if self.channel is None:
            raise RuntimeError("RabbitMQ channel is not initialized")

        routing_key = "1.#"

        # Create delay queues from highest to lowest
        for n in range(self.DELAY_QUEUE_COUNT, -1, -1):
            queue = self.delay_queue_name(n)
            next_queue = self.delay_queue_name(n - 1)

            # Declare exchange
            self.channel.exchange_declare(
                exchange=queue, exchange_type="topic", durable=True
            )

            # Declare queue with TTL and dead letter exchange
            ttl_ms = int(2**n * 1000)
            dead_letter_exchange = (
                next_queue if n > 0 else self.config.delay_delivery
            )

            self.channel.queue_declare(
                queue=queue,
                durable=True,
                exclusive=False,
                auto_delete=False,
                arguments={
                    "x-queue-type": "quorum",
                    "x-dead-letter-strategy": "at-least-once",
                    "x-overflow": "reject-publish",
                    "x-message-ttl": ttl_ms,
                    "x-dead-letter-exchange": dead_letter_exchange,
                },
            )

            # Bind queue to its exchange
            self.channel.queue_bind(
                queue=queue, exchange=queue, routing_key=routing_key
            )

            routing_key = "*." + routing_key

        # Bind exchanges together
        routing_key = "0.#"
        for n in range(self.DELAY_QUEUE_COUNT, 0, -1):
            queue = self.delay_queue_name(n)
            next_queue = self.delay_queue_name(n - 1)

            self.channel.exchange_bind(
                destination=next_queue, source=queue, routing_key=routing_key
            )

            routing_key = "*." + routing_key

        # Declare final delay delivery exchange
        self.channel.exchange_declare(
            exchange=self.config.delay_delivery, exchange_type="topic", durable=True
        )

        # Bind delay delivery exchange to queue 0
        self.channel.exchange_bind(
            destination=self.config.delay_delivery,
            source=self.delay_queue_name(0),
            routing_key=routing_key,
        )

        # Bind main queue to delay delivery exchange
        self.channel.queue_bind(
            queue=self.queue_name,
            exchange=self.config.delay_delivery,
            routing_key=f"#.{self.queue_name}",
        )

    def get_routing_key(self, subscribe: bool, message_info: Any) -> str:
        """
        Get routing key for message.

        Args:
            subscribe: Whether this is for subscription (wildcard pattern)
            message_info: Message information

        Returns:
            Routing key string
        """
        if subscribe:
            return f"{message_info.type}.{message_info.endpoint}.{message_info.name}.{message_info.major}.#"
        else:
            return f"{message_info.type}.{message_info.endpoint}.{message_info.name}.{message_info.major}.{message_info.minor}.{message_info.patch}"

    def delay_queue_name(self, n: int) -> str:
        """
        Get delay queue name for index.

        Args:
            n: Queue index

        Returns:
            Delay queue name
        """
        return f"{self.config.delay_delivery}.{n:02d}"
