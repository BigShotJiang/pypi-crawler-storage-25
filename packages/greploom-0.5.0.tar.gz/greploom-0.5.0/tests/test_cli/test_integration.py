"""End-to-end CLI integration tests.

Uses click's CliRunner with a fake EmbeddingClient so no ollama instance is needed.
All tests index from the fixture CPG JSON files and exercise the full CLI surface.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from greploom.cli import main

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SMALL_CPG = Path(__file__).parent.parent / "fixtures" / "small_cpg.json"
MEDIUM_CPG = Path(__file__).parent.parent / "fixtures" / "medium_cpg.json"
SMALL_CPG_WITH_SOURCE = Path(__file__).parent.parent / "fixtures" / "small_cpg_with_source.json"


class FakeEmbeddingClient:
    """Deterministic 768-dim embedder that never touches the network."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        pass

    def embed(self, texts: list[str], batch_size: int = 32) -> list[list[float]]:
        return [[0.0] * 768] * len(texts)

    def embed_one(self, text: str) -> list[float]:
        return [0.0] * 768

    def close(self) -> None:
        pass

    def __enter__(self) -> FakeEmbeddingClient:
        return self

    def __exit__(self, *_: object) -> None:
        pass


@pytest.fixture(autouse=True)
def mock_embedder(monkeypatch: pytest.MonkeyPatch) -> None:
    # Patch the class where the index orchestrator imports it
    monkeypatch.setattr("greploom.index.EmbeddingClient", FakeEmbeddingClient)
    # Patch the class where the query command imports it
    monkeypatch.setattr("greploom.cli.query_cmd.EmbeddingClient", FakeEmbeddingClient)


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture()
def indexed_db(tmp_path: Path, runner: CliRunner) -> Path:
    """Return a tmp DB path that has already been indexed from small_cpg.json."""
    db = tmp_path / "test.db"
    result = runner.invoke(main, ["index", str(SMALL_CPG), "--db", str(db)])
    assert result.exit_code == 0, result.output
    return db


@pytest.fixture()
def indexed_db_with_source(tmp_path: Path, runner: CliRunner) -> Path:
    """Return a tmp DB path indexed from small_cpg_with_source.json."""
    db = tmp_path / "test_with_source.db"
    result = runner.invoke(main, ["index", str(SMALL_CPG_WITH_SOURCE), "--db", str(db)])
    assert result.exit_code == 0, result.output
    return db


# ---------------------------------------------------------------------------
# Index command tests
# ---------------------------------------------------------------------------


def test_index_command_succeeds(tmp_path: Path, runner: CliRunner) -> None:
    db = tmp_path / "test.db"
    result = runner.invoke(main, ["index", str(SMALL_CPG), "--db", str(db)])

    assert result.exit_code == 0, result.output
    assert "Indexed" in result.output


def test_index_command_force_reindex(tmp_path: Path, runner: CliRunner) -> None:
    db = tmp_path / "test.db"

    first = runner.invoke(main, ["index", str(SMALL_CPG), "--db", str(db)])
    assert first.exit_code == 0, first.output

    second = runner.invoke(main, ["index", str(SMALL_CPG), "--db", str(db), "--force"])
    assert second.exit_code == 0, second.output
    # --force deletes and re-creates the DB, so all nodes are indexed again — none skipped
    assert "Indexed" in second.output
    assert "skipped, 0" in second.output


def test_index_command_incremental_skips(tmp_path: Path, runner: CliRunner) -> None:
    db = tmp_path / "test.db"

    first = runner.invoke(main, ["index", str(SMALL_CPG), "--db", str(db)])
    assert first.exit_code == 0, first.output

    second = runner.invoke(main, ["index", str(SMALL_CPG), "--db", str(db)])
    assert second.exit_code == 0, second.output
    assert "skipped" in second.output


def test_index_command_missing_file(tmp_path: Path, runner: CliRunner) -> None:
    db = tmp_path / "test.db"
    result = runner.invoke(
        main, ["index", str(tmp_path / "nonexistent.json"), "--db", str(db)]
    )

    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Query command tests
# ---------------------------------------------------------------------------


def test_query_command_no_expansion(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        ["query", "handle request", "--db", str(indexed_db), "--format", "json"],
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert "metadata" in payload, f"Expected 'metadata' key in output: {result.output}"
    assert "results" in payload, f"Expected 'results' key in output: {result.output}"
    assert isinstance(payload["results"], list)


def test_query_command_with_expansion(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "handle request",
            "--db",
            str(indexed_db),
            "--cpg",
            str(SMALL_CPG),
        ],
    )

    assert result.exit_code == 0, result.output
    # The default (context) format emits the text of each context block
    assert len(result.output.strip()) > 0


def test_query_command_json_format(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        ["query", "validate input", "--db", str(indexed_db), "--format", "json"],
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert "metadata" in payload
    assert "results" in payload
    assert isinstance(payload["results"], list)
    # Each hit record should have the expected keys
    if payload["results"]:
        hit = payload["results"][0]
        assert "node_id" in hit
        assert "score" in hit
        assert "name" in hit


# ---------------------------------------------------------------------------
# --node mode tests
# ---------------------------------------------------------------------------

NODE_HANDLE_REQUEST = "function:src/app.py:4:0:2"
NODE_VALIDATE_INPUT = "function:src/app.py:10:0:5"
NODE_PARAM_REQUEST = "parameter:src/app.py:4:15:3"


def test_node_mode_returns_context(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        ["query", "--node", NODE_HANDLE_REQUEST, "--cpg", str(SMALL_CPG), "--db", str(indexed_db)],
    )
    assert result.exit_code == 0, result.output
    assert len(result.output.strip()) > 0


def test_node_mode_multiple_ids(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--node", NODE_VALIDATE_INPUT,
            "--cpg", str(SMALL_CPG),
            "--db", str(indexed_db),
        ],
    )
    assert result.exit_code == 0, result.output
    assert len(result.output.strip()) > 0


def test_node_mode_json_format(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG),
            "--format", "json",
            "--db", str(indexed_db),
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert "metadata" in payload, f"Expected 'metadata' key in output: {result.output}"
    assert "results" in payload, f"Expected 'results' key in output: {result.output}"
    assert len(payload["results"]) > 0
    block = payload["results"][0]
    expected_keys = (
        "node_id", "name", "kind", "file", "line", "relationship",
        "tokens", "text", "source", "structural_context",
    )
    for key in expected_keys:
        assert key in block, f"Missing key {key!r} in block: {block}"


def test_node_mode_unknown_id_returns_empty(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        [
            "query", "--node", "function:nonexistent:0:0:99",
            "--cpg", str(SMALL_CPG), "--db", str(indexed_db),
        ],
    )
    assert result.exit_code == 0, result.output
    # No context assembled — output shows only the metadata header line
    lines = result.output.strip().splitlines()
    assert len(lines) <= 1, f"Expected at most the metadata header, got: {result.output!r}"


# ---------------------------------------------------------------------------
# Metadata in JSON output
# ---------------------------------------------------------------------------


def test_query_json_with_cpg_includes_metadata(indexed_db: Path, runner: CliRunner) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "handle request",
            "--db",
            str(indexed_db),
            "--cpg",
            str(SMALL_CPG),
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert "metadata" in payload, f"Expected 'metadata' key in output: {result.output}"
    assert "results" in payload, f"Expected 'results' key in output: {result.output}"
    assert "embedding_model" in payload["metadata"], (
        f"Expected 'embedding_model' in metadata: {payload['metadata']}"
    )


# ---------------------------------------------------------------------------
# Embedding model mismatch warning
# ---------------------------------------------------------------------------


def test_query_warns_on_model_mismatch(indexed_db: Path, runner: CliRunner) -> None:
    """Query with a different model than the index emits a warning to stderr."""
    result = runner.invoke(
        main,
        [
            "query",
            "handle request",
            "--db",
            str(indexed_db),
            "--model",
            "different-model",
        ],
    )

    assert result.exit_code == 0, f"output: {result.output}"
    # Click 8.2+ mixes stderr into stdout by default (mix_stderr deprecated).
    assert "differs from" in result.output, (
        f"Expected model mismatch warning in output, got: {result.output!r}"
    )
    assert "different-model" in result.output
    assert "nomic-embed-text" in result.output


# ---------------------------------------------------------------------------
# --include-source tests
# ---------------------------------------------------------------------------


def test_node_mode_include_source_emits_source_text(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    """--node + --include-source includes raw source in context output."""
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--include-source",
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    assert "def handle_request" in result.output


def test_node_mode_without_include_source_omits_source_text(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    """--node without --include-source does not include raw source in output."""
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    assert "def handle_request" not in result.output


def test_node_mode_include_source_json_format(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    """--node + --format json + --include-source has source code in the block text field."""
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--format", "json",
            "--include-source",
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert "metadata" in payload
    assert "results" in payload
    assert len(payload["results"]) > 0
    # The first block corresponds to the requested node; its text must contain the source.
    hit_block = next(b for b in payload["results"] if b["node_id"] == NODE_HANDLE_REQUEST)
    assert "def handle_request" in hit_block["text"], (
        f"Expected source in block text, got: {hit_block['text']!r}"
    )


def test_query_include_source_with_search_and_cpg(tmp_path: Path, runner: CliRunner) -> None:
    """Hybrid search + CPG expansion with --include-source emits raw source text."""
    db = tmp_path / "test_with_source.db"
    index_result = runner.invoke(main, ["index", str(SMALL_CPG_WITH_SOURCE), "--db", str(db)])
    assert index_result.exit_code == 0, index_result.output

    result = runner.invoke(
        main,
        [
            "query",
            "handle request",
            "--db",
            str(db),
            "--cpg",
            str(SMALL_CPG_WITH_SOURCE),
            "--include-source",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "def handle_request" in result.output or "def validate_input" in result.output, (
        f"Expected raw source text in output, got: {result.output!r}"
    )


# ---------------------------------------------------------------------------
# source and structural_context JSON output tests
# ---------------------------------------------------------------------------


def test_node_json_has_source_when_include_source(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--format", "json",
            "--include-source",
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    hit = next(b for b in payload["results"] if b["node_id"] == NODE_HANDLE_REQUEST)
    assert hit["source"] is not None
    assert "def handle_request" in hit["source"]


def test_node_json_source_null_without_flag(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--format", "json",
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    hit = next(b for b in payload["results"] if b["node_id"] == NODE_HANDLE_REQUEST)
    assert hit["source"] is None


def test_node_json_has_structural_context(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--format", "json",
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    hit = next(b for b in payload["results"] if b["node_id"] == NODE_HANDLE_REQUEST)
    ctx = hit["structural_context"]
    assert isinstance(ctx, dict)
    for key in ("callers", "callees", "parameters", "parent_class", "data_sources", "imports"):
        assert key in ctx, f"Missing key {key!r} in structural_context"


def test_node_json_structural_context_callees(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    """handle_request calls validate_input — verify callee appears in structural_context."""
    result = runner.invoke(
        main,
        [
            "query",
            "--node", NODE_HANDLE_REQUEST,
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--format", "json",
            "--db", str(indexed_db_with_source),
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    hit = next(b for b in payload["results"] if b["node_id"] == NODE_HANDLE_REQUEST)
    callee_ids = [c["node_id"] for c in hit["structural_context"]["callees"]]
    assert NODE_VALIDATE_INPUT in callee_ids


def test_search_with_cpg_json_has_structural_context(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    result = runner.invoke(
        main,
        [
            "query",
            "handle request",
            "--db", str(indexed_db_with_source),
            "--cpg", str(SMALL_CPG_WITH_SOURCE),
            "--format", "json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert len(payload["results"]) > 0
    for block in payload["results"]:
        assert "structural_context" in block
        assert isinstance(block["structural_context"], dict)


def test_search_without_cpg_json_no_structural_context(
    indexed_db_with_source: Path, runner: CliRunner
) -> None:
    """Search-only mode (no --cpg) has a different schema — no structural_context."""
    result = runner.invoke(
        main,
        [
            "query",
            "handle request",
            "--db", str(indexed_db_with_source),
            "--format", "json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    if payload["results"]:
        assert "structural_context" not in payload["results"][0]
