# PKTron v0.1.7 - Pakistan Quantum Simulator

Pakistan's first quantum simulator. Now with parameterized circuits,
SamplerV2, EstimatorV2, save methods, and BackendV2 compatibility.

## Install
```bash
pip install pktron
```

## New in v0.1.7
- Parameter and ParameterVector classes
- bind_parameters() for VQE/QAOA workflows
- SamplerV2 and EstimatorV2 primitives
- save_statevector(), save_probabilities(), save_expectation_value()
- BackendV2-style backend with properties()
