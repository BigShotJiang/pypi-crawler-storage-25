
import numpy as np
from .quantum import QuantumCircuit

def grover(num_qubits, target, iterations=None):
    """
    Grover's search algorithm — finds target state with high probability.

    Usage:
        result = grover(num_qubits=3, target=5)
        print(result["outcome"])
        print(result["success"])
    """
    n = num_qubits
    qc = QuantumCircuit(n)

    # Optimal number of iterations
    if iterations is None:
        iterations = max(1, int(np.round(np.pi/4 * np.sqrt(2**n))))

    # Step 1: Hadamard on all qubits (uniform superposition)
    for i in range(n):
        qc.h(i)

    target_bits = format(target, f"0{n}b")

    for _ in range(iterations):
        # Step 2: Oracle — flips phase of target state
        # Mark target by flipping X on qubits where target bit is 0
        for i, bit in enumerate(target_bits):
            if bit == "0":
                qc.x(i)
        # Multi-controlled Z (via H + CCX decomposition)
        qc.h(n-1)
        if n == 2:
            qc.cnot(0, 1)
        elif n >= 3:
            qc.toffoli(0, 1, n-1)
        qc.h(n-1)
        for i, bit in enumerate(target_bits):
            if bit == "0":
                qc.x(i)

        # Step 3: Diffusion operator (inversion about average)
        for i in range(n):
            qc.h(i)
            qc.x(i)
        qc.h(n-1)
        if n == 2:
            qc.cnot(0, 1)
        elif n >= 3:
            qc.toffoli(0, 1, n-1)
        qc.h(n-1)
        for i in range(n):
            qc.x(i)
            qc.h(i)

    outcome, probs = qc.measure()
    return {
        "circuit":  qc,
        "outcome":  outcome,
        "probs":    probs,
        "target":   target,
        "success":  (outcome == target),
        "target_prob": float(probs[target]),
    }


def quantum_phase_estimation(unitary_func, num_estimation_qubits, num_target_qubits):
    """
    Quantum Phase Estimation (QPE).
    Estimates the phase phi in U|psi> = e^(2*pi*i*phi)|psi>.

    unitary_func: a function that takes (circuit, control_qubit, target_qubits)
                  and applies the controlled-U gate.

    Usage:
        def my_U(qc, ctrl, targets):
            qc.cz(ctrl, targets[0])

        result = quantum_phase_estimation(my_U, num_estimation_qubits=3, num_target_qubits=1)
        print(result["phase"])
    """
    n_est = num_estimation_qubits
    n_tgt = num_target_qubits
    n_total = n_est + n_tgt
    qc = QuantumCircuit(n_total)

    est_qubits = list(range(n_est))
    tgt_qubits = list(range(n_est, n_total))

    # Superposition on estimation register
    for q in est_qubits:
        qc.h(q)

    # Prepare target in |1> (eigenstate of many common unitaries)
    qc.x(tgt_qubits[0])

    # Controlled-U^(2^k) for each estimation qubit
    for k, ctrl in enumerate(est_qubits):
        for _ in range(2**k):
            unitary_func(qc, ctrl, tgt_qubits)

    # Inverse QFT on estimation register
    for i in range(n_est-1, -1, -1):
        qc.h(est_qubits[i])
        for j in range(i-1, -1, -1):
            angle = -np.pi / (2**(i-j))
            qc.rz(est_qubits[i], angle/2)
            qc.cnot(est_qubits[i], est_qubits[j])
            qc.rz(est_qubits[j], -angle/2)
            qc.cnot(est_qubits[i], est_qubits[j])
            qc.rz(est_qubits[j], angle/2)

    outcome, probs = qc.measure()
    # Read phase from estimation register bits only
    est_outcome = outcome >> n_tgt
    phase = est_outcome / (2**n_est)

    return {
        "circuit":  qc,
        "phase":    phase,
        "outcome":  est_outcome,
        "probs":    probs,
    }


def amplitude_amplification(oracle_func, diffusion_func, num_qubits, iterations=None):
    """
    General Amplitude Amplification (generalized Grover).

    oracle_func:    function(circuit) that marks good states
    diffusion_func: function(circuit) that reflects about initial state

    Usage:
        def oracle(qc):
            qc.z(0)   # marks |1> on qubit 0

        def diffuse(qc):
            for i in range(qc.num_qubits): qc.h(i); qc.x(i)
            qc.h(qc.num_qubits-1)
            qc.cnot(0, qc.num_qubits-1)
            qc.h(qc.num_qubits-1)
            for i in range(qc.num_qubits): qc.x(i); qc.h(i)

        result = amplitude_amplification(oracle, diffuse, num_qubits=2, iterations=1)
    """
    n = num_qubits
    qc = QuantumCircuit(n)

    if iterations is None:
        iterations = max(1, int(np.pi/4 * np.sqrt(2**n)))

    for i in range(n):
        qc.h(i)

    for _ in range(iterations):
        oracle_func(qc)
        diffusion_func(qc)

    outcome, probs = qc.measure()
    return {
        "circuit": qc,
        "outcome": outcome,
        "probs":   probs,
    }
