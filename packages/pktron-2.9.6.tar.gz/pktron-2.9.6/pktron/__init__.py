"""
PKTron v2.9.6 — Pakistan's High-Performance Quantum Computing Framework
=======================================================================
Pure-Python quantum circuit simulator with optional GPU acceleration.

Quick install:
    pip install pktron            # basic (numpy only)
    pip install pktron[full]      # all extras (pennylane, plotly, etc.)
    pip install pktron[gpu]       # GPU support (cupy)

Quick start:
    from pktron import QuantumCircuit
    qc = QuantumCircuit(2)
    qc.h(0); qc.cnot(0, 1)
    print(qc.measure())
"""

__version__ = "2.9.6"
__author__  = "PKTron Team"
__license__ = "MIT"

# ── Core ──────────────────────────────────────────────────────────────────────
from .quantum     import QuantumCircuit
from .parameters  import Parameter, ParameterVector
from .primitives  import SamplerV2, EstimatorV2, SamplerResult, EstimatorResult
from .measurement import ClassicalRegister, measure_all, measure_partial, measure_qubit

# ── Gates (functional API) ────────────────────────────────────────────────────
from .gates import (h, x, y, z, s, sdg, t, tdg,
                    rx, ry, rz, cnot, cz, cy, swap, toffoli)

# ── Fast Gate Math ────────────────────────────────────────────────────────────
from .fast_statevector import (apply_1q, apply_2q, apply_3q,
                                rx_mat, ry_mat, rz_mat,
                                u1_mat, u2_mat, u3_mat)

# ── Backends ──────────────────────────────────────────────────────────────────
from .backend   import (StatevectorSimulator, StabilizerSimulator,
                         MPS_Simulator, execute, BackendV2)
from .simulator import AerSimulator, DensityMatrixSimulator, AerResult

# ── Noise ─────────────────────────────────────────────────────────────────────
from .noise    import (NoiseModel, PauliError, DepolarizingError,
                        AmplitudeDampingError, PhaseDampingError,
                        ThermalRelaxationError)
from .noise_v2 import (BitFlipError, PhaseFlipError,
                        DepolarizingError    as DepolarizingErrorV2,
                        AmplitudeDampingError as AmplitudeDampingErrorV2,
                        PhaseDampingError    as PhaseDampingErrorV2,
                        NoiseModel           as NoiseModelV2)

# ── Transpiler ────────────────────────────────────────────────────────────────
from .transpiler_v2 import (PassManager, UnrollToffoliPass,
                              MergeRotationsPass, CancelInversePass,
                              BasisTranslationPass)

# ── Quantum Info ──────────────────────────────────────────────────────────────
from .quantum_info import (Statevector, DensityMatrix, Operator,
                            Pauli, Clifford, state_fidelity, partial_trace)

# ── Sparse Observables ────────────────────────────────────────────────────────
from .sparse_observable import (SparseObservable, AdvancedEstimatorV2,
                                 AdvancedEstimatorResult, PauliProductMeasurement)

# ── Mid-Circuit / Dynamic Circuits ────────────────────────────────────────────
from .midcircuit import DynamicCircuit

# ── Tensor Networks ───────────────────────────────────────────────────────────
from .tensor_network    import TensorNetworkSimulator, TensorNetworkResult
from .tensor_network_v3 import SmartMPS, SmartMPSResult

# ── GPU Backends (auto-fallback to NumPy when no GPU) ─────────────────────────
from .gpu          import GPUStatevectorSimulator, GPUDensityMatrixSimulator, GPUResult
from .gpu_v2       import BatchedGPUStatevector
from .gpu_primitives import GPUBatchedSampler, GPUBatchedEstimator

# ── Advanced Visualization ────────────────────────────────────────────────────
from .advanced_visualization import (draw_circuit_text, draw_circuit_mpl,
                                      plot_city, plot_hinton,
                                      plot_bloch_multi, EnhancedResult)

# ── Performance & Parallelism ─────────────────────────────────────────────────
from .performance import (FullGPUStatevector, FullGPUDensityMatrix,
                           StabilizerTableau, DecisionDiagramBackend,
                           ParallelExecutor, AutoBackend, PerformanceResult)

# ── Error Mitigation ──────────────────────────────────────────────────────────
from .error_mitigation import (ZeroNoiseExtrapolation,
                                ProbabilisticErrorCancellation,
                                ReadoutErrorMitigation,
                                MitigatedEstimatorV2, MitigationResult)

# ── Fault-Tolerant Primitives ─────────────────────────────────────────────────
from .fault_tolerant import SurfaceCode, LogicalQubit, RepetitionCode, SteaneCode

# ── Algorithms (core) ─────────────────────────────────────────────────────────
from .algorithms import (quantum_flip, super_quantum_dance,
                          quantum_treasure_hunt, quantum_magic_spin,
                          bb84_qkd, grover_search, qft,
                          phase_estimation, shor_period_finding,
                          vqe, qaoa, hhl)
from .algorithms_v2 import (grover, quantum_phase_estimation,
                              amplitude_amplification)

# ── Advanced Algorithms ───────────────────────────────────────────────────────
from .hhl              import hhl_solve, HHLResult
from .qpca             import qpca_fit, QPCAResult
from .bernstein_vazirani import BernsteinVazirani, BVResult, BVOracle
from .simons_algorithm   import SimonsAlgorithm, SimonResult, SimonOracle
from .quantum_counting   import QuantumCounting, QuantumCountResult, AmplitudeEstimator

# ── Hybrid ML (optional — requires torch or tensorflow) ───────────────────────
try:
    from .hybrid_ml import (QuantumLayer, TFQuantumLayer,
                              GradientEstimator, QNNClassifier)
except Exception:
    pass

# ── Qiskit Compatibility ──────────────────────────────────────────────────────
from .qiskit_compat_v2 import to_qasm, from_qasm, to_qiskit, from_qiskit

# ── AI & Debugging Tools ──────────────────────────────────────────────────────
try:
    from .ai_assistant    import generate_circuit, explain_circuit
    from .step_simulator  import run_step_by_step, print_steps, plot_steps
    from .quantum_debugger import QuantumDebugger
except Exception:
    pass

# ── Hardware Emulator ─────────────────────────────────────────────────────────
from .hardware import HardwareEmulator, DEVICE_PROFILES

# ── Quantum Cryptography ──────────────────────────────────────────────────────
from .crypto import BB84Protocol, RECTILINEAR, DIAGONAL

# ── Plugin System ─────────────────────────────────────────────────────────────
from .plugins import GatePlugin, BackendPlugin, AlgorithmPlugin, PluginManager

# ── Benchmarks ────────────────────────────────────────────────────────────────
from .benchmarks import run_benchmarks

# ── Convenience alias ─────────────────────────────────────────────────────────
QC = QuantumCircuit
