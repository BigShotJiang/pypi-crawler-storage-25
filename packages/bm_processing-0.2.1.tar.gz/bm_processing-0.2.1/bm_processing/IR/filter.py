import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# =========================
# DATA PREPARATION
def load_data():
    data = [
        [5, 3, 4, '?'],
        [3, 1, 2, 3],
        [4, 3, 4, 5],
        [3, 3, 1, 5]
    ]

    df = pd.DataFrame(
        data,
        index=['User1', 'User2', 'User3', 'User4'],
        columns=['Item1', 'Item2', 'Item3', 'Item4']
    )

    df = df.mask(df == '?', np.nan).astype(float)
    return df


def mean_center(df):
    user_mean = df.mean(axis=1)
    df_centered = df.sub(user_mean, axis=0)
    return user_mean, df_centered


# =========================
# SIMILARITY FUNCTION
def cosine_similarity(a, b):
    mask = ~np.isnan(a) & ~np.isnan(b)

    if np.sum(mask) == 0:
        return 0

    a, b = a[mask], b[mask]
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))


# =========================
# USER-BASED CF
def predict_user_based(df, user, item):
    target_vector = df.loc[user].values
    similarities = {}

    for other_user in df.index:
        if other_user == user:
            continue

        if not np.isnan(df.loc[other_user, item]):
            sim = cosine_similarity(
                target_vector,
                df.loc[other_user].values
            )
            similarities[other_user] = sim

    print("\nUser Similarities:", similarities)

    num, den = 0, 0
    for u, sim in similarities.items():
        num += sim * df.loc[u, item]
        den += abs(sim)

    return np.nan if den == 0 else num / den


def predict_user_based_mean_centered(df, user, item):
    user_mean = df.mean(axis=1)
    target_vector = df.loc[user].values
    similarities = {}

    for other_user in df.index:
        if other_user == user:
            continue

        if not np.isnan(df.loc[other_user, item]):
            sim = cosine_similarity(
                target_vector,
                df.loc[other_user].values
            )
            similarities[other_user] = sim

    num, den = 0, 0

    for u, sim in similarities.items():
        ru_i = df.loc[u, item]
        ru_mean = user_mean[u]

        num += sim * (ru_i - ru_mean)
        den += abs(sim)

    if den == 0:
        return user_mean[user]

    return user_mean[user] + (num / den)


def predict_user_based_topk(df, user, item, k=2):
    target_vector = df.loc[user].values
    similarities = []

    for other_user in df.index:
        if other_user == user:
            continue

        if not np.isnan(df.loc[other_user, item]):
            sim = cosine_similarity(
                target_vector,
                df.loc[other_user].values
            )
            similarities.append((other_user, sim))

    similarities.sort(key=lambda x: x[1], reverse=True)

    top_k = similarities[:k]
    print(f"\nTop-{k} similar users:", top_k)

    num, den = 0, 0
    for u, sim in top_k:
        num += sim * df.loc[u, item]
        den += abs(sim)

    return np.nan if den == 0 else num / den


# =========================
# ITEM-BASED CF
def predict_item_based(df, user, item):
    target_vector = df[item].values
    similarities = {}

    for other_item in df.columns:
        if other_item == item:
            continue

        if not np.isnan(df.loc[user, other_item]):
            sim = cosine_similarity(
                target_vector,
                df[other_item].values
            )
            similarities[other_item] = sim

    print("\nItem Similarities:", similarities)

    num, den = 0, 0

    for i, sim in similarities.items():
        num += sim * df.loc[user, i]
        den += abs(sim)

    return np.nan if den == 0 else num / den


def predict_item_based_topk(df, user, item, k=2):
    target_vector = df[item].values
    similarities = []

    for other_item in df.columns:
        if other_item == item:
            continue

        if not np.isnan(df.loc[user, other_item]):
            sim = cosine_similarity(
                target_vector,
                df[other_item].values
            )
            similarities.append((other_item, sim))

    similarities.sort(key=lambda x: x[1], reverse=True)
    top_k = similarities[:k]

    print(f"\nTop-{k} similar items:", top_k)

    num, den = 0, 0
    for i, sim in top_k:
        num += sim * df.loc[user, i]
        den += abs(sim)

    return np.nan if den == 0 else num / den


# =========================
# EVALUATION
def evaluate(df):
    actuals, preds = [], []

    for u in df.index:
        for i in df.columns:
            if not np.isnan(df.loc[u, i]):

                temp = df.copy()
                actual = temp.loc[u, i]
                temp.loc[u, i] = np.nan

                p = predict_user_based(temp, u, i)

                if not np.isnan(p):
                    actuals.append(actual)
                    preds.append(p)

    actuals = np.array(actuals)
    preds = np.array(preds)

    rmse = np.sqrt(np.mean((actuals - preds) ** 2))
    mae = np.mean(np.abs(actuals - preds))

    return rmse, mae


# =========================
# VISUALIZATION
def plot_matrix(matrix, title):
    plt.figure()
    plt.imshow(matrix, aspect='auto')
    plt.title(title)
    plt.colorbar()
    plt.show()


# =========================
# MAIN EXECUTION
def main():
    df = load_data()

    print("\nOriginal Matrix:\n", df)

    # Mean Centering
    user_mean, df_centered = mean_center(df)
    print("\nMean Centered Matrix:\n", df_centered)

    # Prediction target
    user = "User1"
    item = "Item4"

    print(f"\nPredicting for {user}, {item}")

    user_pred = predict_user_based(df, user, item)
    item_pred = predict_item_based(df, user, item)

    topk_user_pred = predict_user_based_topk(df, user, item, k=2)
    topk_item_pred = predict_item_based_topk(df, user, item, k=2)

    print("\nUser-Based Prediction:", user_pred)
    print("Item-Based Prediction:", item_pred)
    print("Top-K User-Based Prediction:", topk_user_pred)
    print("Top-K Item-Based Prediction:", topk_item_pred)

    # Evaluation
    rmse, mae = evaluate(df)
    print("\nEvaluation Metrics:")
    print("RMSE =", rmse)
    print("MAE =", mae)

    # Visualization
    plot_matrix(df.fillna(0), "Original Matrix")
    plot_matrix(df_centered.fillna(0), "Mean Centered Matrix")


if __name__ == "__main__":
    main()





def load_data():
    df = pd.read_csv("ratings.csv")

    # Set 'User' column as index
    df.set_index("User", inplace=True)

    print("\nRaw Data:\n", df)

    # Replace '?' with NaN
    df = df.replace('?', np.nan)

    # Convert all to numeric
    df = df.astype(float)

    print("\nAfter Converting to Numeric:\n", df)

    # OPTIONAL: Remove rows with all missing values
    df = df.dropna(how='all')

    # OPTIONAL: Remove columns with all missing values
    df = df.dropna(axis=1, how='all')

    print("\nAfter Cleaning:\n", df)

    return df


def load_data():
    df = pd.read_csv("ratings.csv")

    # Set index
    df.set_index("User", inplace=True)

    print("\nRaw Data:\n", df)

    # Convert to numeric (important)
    df = df.astype(float)

    print("\nAfter Conversion:\n", df)

    # Check missing values
    print("\nMissing Values:\n", df.isna())

    return df


# =============================================================================
# Module __repr__  –  makes  print(filter)  display this file's source code
# =============================================================================
import sys as _sys
import inspect as _inspect
import types as _types

class _PrintableModule(_types.ModuleType):
    """Module subclass whose __repr__ returns the full source of this file."""
    def __repr__(self) -> str:
        try:
            return _inspect.getsource(_sys.modules[__name__])
        except Exception:
            return super().__repr__()

_sys.modules[__name__].__class__ = _PrintableModule