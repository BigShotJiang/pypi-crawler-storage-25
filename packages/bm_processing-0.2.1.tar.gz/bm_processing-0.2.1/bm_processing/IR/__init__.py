"""
bm_processing.IR
~~~~~~~~~~~~~~~~
Information Retrieval subpackage.

Usage
-----
    from bm_processing.IR import filter, pagerank, pca
    print(filter)    # prints the entire source of filter.py
    print(pagerank)  # prints the entire source of pagerank.py
    print(pca)       # prints the entire source of pca.py
"""

from bm_processing.IR import filter, pagerank, pca

__all__ = ["filter", "pagerank", "pca"]
