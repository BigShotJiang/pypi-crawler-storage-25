import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import networkx as nx
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec


if __name__ == "__main__":
    pages = ["A", "B", "C", "D"]
    A = np.array(
        [
            [0, 1, 1, 0],
            [0, 0, 1, 0],
            [1, 0, 0, 0],
            [0, 0, 1, 0],
        ],
        dtype=int,
    )

    d = 0.85
    max_iter = 10
    tol = 1e-8
    n = len(pages)
    base = (1 - d) / n
    adj = pd.DataFrame(A, index=pages, columns=pages)

    incoming = {p: [src for src in pages if adj.loc[src, p] == 1] for p in pages}
    outgoing = {p: int(adj.loc[p].sum())                           for p in pages}

    # Identify dangling nodes (no outgoing links)
    dangling = [p for p in pages if outgoing[p] == 0]

    pr = {p: 1 / n for p in pages}
    print(f"incoming = {incoming}")
    print(f"outgoing = {outgoing}")
    print(f"dangling = {dangling}")

    print(intial_pr := {p: 1/n for p in pages})
    print("Matrix")
    print(adj.to_string())

    #===== Calculating PageRank ====
    history = [pr.copy()]

    for it in range(1, max_iter + 1):
        new_pr = {}
        for p in pages:
            s = 0
            terms, nums = [], []

            for src in incoming[p]:
                c = pr[src] / outgoing[src] if outgoing[src] > 0 else 0
                s += c
                terms.append(f"PR({src})/{outgoing[src]}")
                nums.append(f"{pr[src]:.4f}/{outgoing[src]} = {c:.4f}")

            new_pr[p] = base + d * s

        history.append(new_pr.copy())
        diff = sum(abs(new_pr[p] - pr[p]) for p in pages)
        pr   = new_pr

        print(f"  PageRank after Iteration {it}")

        iter_df = pd.DataFrame({
            "Page": pages,
            f"PR (iter {it})": [f"{pr[p]:.6f}" for p in pages],
            "Rank": pd.Series([pr[p] for p in pages]).rank(ascending=False).astype(int).values,
        })
        print(iter_df.to_string(index=False))

    # ===== Convergence =====

    conv_data = {f"Iter {i}": [round(h[p], 6) for p in pages]
                 for i, h in enumerate(history)}
    conv_df = pd.DataFrame(conv_data, index=pages)
    conv_df.index.name = "Page"
    print(conv_df.to_string())

    # ===== VISUALIZATION =====
    G = nx.DiGraph()
    for i, src in enumerate(pages):
        for j, dst in enumerate(pages):
            if A[i, j] == 1:
                G.add_edge(src, dst)

    fig = plt.figure(figsize=(16, 10))
    gs  = GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

    ax_graph = fig.add_subplot(gs[:, :2])   # left 2/3 — graph


    # ── Graph layout & drawing ─────────────────────────────────────────────────
    pos = nx.spring_layout(G, seed=42, k=2.2)

    pr_vals    = np.array([pr[p] for p in G.nodes()])
    pr_norm    = (pr_vals - pr_vals.min()) / (pr_vals.max() - pr_vals.min() + 1e-9)
    node_sizes = pr_norm * 3500 + 900

    # Node colours scaled by PR using default tab10 cycle
    node_colors = [plt.cm.tab10(i / len(pages)) for i in range(len(list(G.nodes())))]

    # Edges
    nx.draw_networkx_edges(
        G, pos, ax=ax_graph,
        arrows=True, arrowsize=22,
        connectionstyle="arc3,rad=0.12",
        width=1.8,
    )

    # Nodes
    nx.draw_networkx_nodes(
        G, pos, ax=ax_graph,
        node_size=node_sizes,
        node_color=node_colors,
    )

    # Labels: page name + PR value
    labels = {p: f"{p}\n{pr[p]:.4f}" for p in G.nodes()}
    nx.draw_networkx_labels(
        G, pos, labels=labels, ax=ax_graph,
        font_size=10, font_weight="bold",
    )
    ax_graph.set_title("PageRank Graph ")
    plt.show()

    plt.figure()
    x=new_pr.keys()
    y=new_pr.values()
    colors = ['red', 'green', 'blue', 'orange']
    plt.xlabel("Page")
    plt.ylabel("PageRank")
    plt.title("PageRank Graph")
    colors = ['red', 'green', 'blue', 'orange']
    plt.bar(x, y, color=colors)
    plt.show()



    # +=======
    # HITS
    # =======


    pages = ["A", "B", "C", "D"]

    A = np.array([
        [0, 1, 1, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
        [0, 0, 1, 0],
    ])

    n = len(pages)
    a = [0] * n
    h = [1] * n

    max_iter = 5

    for it in range(1, max_iter + 1):

        # --- Authority ---
        for i in range(n):
            a[i] = 0
            for j in range(n):
                if A[j][i] == 1:
                    a[i] += h[j]

        t = sum(a)
        if t != 0:
            for i in range(n):
                a[i] = a[i] / t

        # --- Hub ---
        for i in range(n):
            h[i] = 0
            for j in range(n):
                if A[i][j] == 1:
                    h[i] += a[j]

        t = sum(h)
        if t != 0:
            for i in range(n):
                h[i] = h[i] / t

        # ===== BAR GRAPH =====
        x = np.arange(n)

        plt.figure()

        # hubs (left bars)
        plt.bar(x - 0.2, h, width=0.4, label="Hub")

        # authority (right bars)
        plt.bar(x + 0.2, a, width=0.4, label="Authority")

        plt.xticks(x, pages)
        plt.xlabel("Pages")
        plt.ylabel("Score")
        plt.title(f"HITS Iteration {it}")
        plt.legend()

        plt.show()


# =============================================================================
# Module __repr__  –  makes  print(pagerank)  display this file's source code
# =============================================================================
import sys as _sys
import inspect as _inspect
import types as _types

class _PrintableModule(_types.ModuleType):
    """Module subclass whose __repr__ returns the full source of this file."""
    def __repr__(self) -> str:
        try:
            return _inspect.getsource(_sys.modules[__name__])
        except Exception:
            return super().__repr__()

_sys.modules[__name__].__class__ = _PrintableModule