import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA


if __name__ == "__main__":
    # Read csv
    df = pd.read_csv("")

    # Head
    df.head()

    #info
    df.info()

    #describe
    df.describe()

    #shape
    df.shape()

    #drop entire row if it is null
    df.dropna()

    #null sum
    df.isnull().sum()

    #replce the null value with mean
    df[''] = df[''].fillna(df[''].mean())

    #input as array
    X = np.array([
        [2, 1,5,6],
        [3, 5,7,8],
        [4, 3,9,10],
        [5, 6,11,12],
        [6, 7,13,14],
        [7, 8,15,16]
    ])


    # covert string into integer
    le = LabelEncoder()
    df[''] = le.fit_transform(df[''])

    #selecr required columns
    X = df[[ 'C1', 'C2', 'C3']]

    #PCA
    X = StandardScaler().fit_transform(X)
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)

    #Explained Varience
    print("\nExplained Variance Ratio:", pca.explained_variance_ratio_)



    # graph (n_component=2)
    plt.scatter(X_pca[:,0], X_pca[:,1])
    plt.title("Sklearn PCA")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.legend(["Sklearn"])
    plt.grid()


    #3d Graph (n_components=3)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(
        X_pca[:, 0],
        X_pca[:, 1],
        X_pca[:, 2]
    )
    ax.set_title("Sklearn PCA")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_zlabel("PC3")
    plt.show()



    # ======= MANULA PCA =======


    # ─────────────────────────────
    # STEP 1: MEAN
    # ─────────────────────────────
    mean = np.mean(X, axis=0)
    print("\nStep 1: Mean Vector:")
    print(mean)

    # ─────────────────────────────
    # STEP 2: CENTER DATA
    # ─────────────────────────────
    X_centered = X - mean
    print("\nStep 2: Centered Data:")
    print(X_centered)

    # ─────────────────────────────
    # STEP 3: COVARIANCE MATRIX
    # ─────────────────────────────
    cov_matrix = np.cov(X_centered.T)
    print("\nStep 3: Covariance Matrix:")
    print(cov_matrix)

    # ─────────────────────────────
    # STEP 4: EIGENVALUES & VECTORS
    # ─────────────────────────────
    eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)

    print("\nStep 4: Eigenvalues:")
    print(eigenvalues)

    print("\nStep 4: Eigenvectors:")
    print(eigenvectors)

    # ─────────────────────────────
    # STEP 5: SORT
    # ─────────────────────────────
    idx = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]

    print("\nStep 5: Sorted Eigenvalues:")
    print(eigenvalues)

    print("\nStep 5: Sorted Eigenvectors:")
    print(eigenvectors)

    # ─────────────────────────────
    # STEP 6: PROJECTION
    # ─────────────────────────────
    X_pca_manual = X_centered @ eigenvectors

    print("\nStep 6: Manual PCA Transformed Data:")
    print(X_pca_manual)

    # ─────────────────────────────
    # VARIANCE EXPLAINED (MANUAL)
    # ─────────────────────────────
    var_ratio_manual = eigenvalues / np.sum(eigenvalues)

    print("\nManual Explained Variance Ratio:")
    print(var_ratio_manual)

    cumulative_var_manual = np.cumsum(var_ratio_manual)
    print("\nManual Cumulative Variance Ratio:")
    print(cumulative_var_manual)


# =============================================================================
# Module __repr__  –  makes  print(pca)  display this file's source code
# =============================================================================
import sys as _sys
import inspect as _inspect
import types as _types

class _PrintableModule(_types.ModuleType):
    """Module subclass whose __repr__ returns the full source of this file."""
    def __repr__(self) -> str:
        try:
            return _inspect.getsource(_sys.modules[__name__])
        except Exception:
            return super().__repr__()

_sys.modules[__name__].__class__ = _PrintableModule