# bm-processing

A Python package providing Information Retrieval (IR) and Data Mining (DM) utilities.

## Installation

```bash
pip install bm-processing
```

## Usage

```python
from bm_processing.IR.pagerank import run_pagerank
from bm_processing.IR.filter import apply_filter
from bm_processing.IR.pca import run_pca

run_pagerank()   # Running PageRank algorithm
apply_filter()   # Applying filter to data
run_pca()        # Performing PCA transformation
```

## Modules

### IR (Information Retrieval)

| Module | Function | Description |
|--------|----------|-------------|
| `pagerank` | `run_pagerank()` | Runs the PageRank algorithm |
| `filter` | `apply_filter()` | Applies a filter to data |
| `pca` | `run_pca()` | Performs PCA transformation |

### DM (Data Mining)

Coming soon.
