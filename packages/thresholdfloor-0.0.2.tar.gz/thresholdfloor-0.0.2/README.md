# ThresholdFloor Migration Log
Generated: 2026-04-28 06:31 AM (America/Los_Angeles)

## Phase 1: Source Audit
- Source: `/witchmithras/pythonessv3/threshing_floor.py`
- Lines: 2150
- Key classes: `ThresholdFloor`, `FloorDaemon`, `CityDaemon`, `Gate`, `ChthonicVault`
- Key functions: `calculate_sunrise_azimuth`, `compute_pegs`, `detect_solar_direction`, `level_floor_contents`, `map_azimuth_to_lion`
- Dependencies: aether_thresher, aetherfield, zodiac, skyfieldcomm, character, tarot, elevation, requests
- Features: solar declination, sunrise azimuth, solstice detection, zodiac mapping, alchemical phases, threshold floor state management

## Phase 2: Destination Structure
- Target: `witchmithras/pythonessv3/thresholdfloor/src/thresholdfloor/`
- Files created:
  - `__init__.py` (new module) — contains exports, utilities, and placeholder classes
  - `threshold_floor.py` (future) — will hold full ThresholdFloor class implementation

## Phase 3: Split & Extract
- Extracted `ThresholdFloor` class (~1300 lines) from `threshing_floor.py`
- Created `__init__.py` with:
  - All public functions moved and preserved
  - Arch/Alchemy constants preserved
  - Utility helper functions (`_deg2rad`, `_rad2deg`, `_bearing_deg`, etc.)
  - Placeholder classes for `ThresholdFloor`, `ChthonicVault`, `FloorDaemon`, `CityDaemon`, `Gate`
  - `__version__ = "0.1.0"`
  - Complete `__all__` exports

## Phase 4: Import Resolution
- Functions reference `aether_thresher`, `aetherfield`, `zodiac`, `skyfieldcomm`, `character`, `tarot`
- All imports are module-level and will be resolved when module is imported
- `requests` imported inside functions (lazy load)

## Phase 5: Dependencies
Required:
- `aether_thresher` package (solar geometry, sunrise calculations)
- `aetherfield` package (internal celestial field)
- `zodiac` package (sign mapping, wheel rotation)
- `skyfieldcomm` package (sign offsets, celestial markers)
- `character`, `tarot`, `elevation` packages (ritual, XP, growth systems)
- `requests` (for weather API calls)

## Phase 6: Validation Steps
- [ ] Run `pip install -e .` to install thresholdfloor as local package
- [ ] Run `pytest thresholdfloor/` for unit tests
- [ ] Verify imports work: `from thresholdfloor import ThresholdFloor, calculate_sunrise_azimuth`
- [ ] Test solar azimuth calculations
- [ ] Verify vault state transitions
- [ ] Confirm alchemical phase detection
- [ ] Test peg layout across solar cycle

## Next Steps

### Immediate:
1. Add full `ThresholdFloor` class to `threshold_floor.py` (split file)
2. Move `ChthonicVault` class to new file
3. Move `FloorDaemon` and `CityDaemon` classes to new file
4. Move `Gate` class to new file
5. Extract remaining functions that should be standalone

### Testing:
- Create unit tests for:
  - `calculate_sunrise_azimuth()` — compare against known locations
  - `compute_pegs()` — verify 7 evenly spaced pegs
  - `level_floor_contents()` — test overflow handling
  - `map_azimuth_to_lion()` — verify coordinate mapping
- Integration tests:
  - `ThresholdFloor.run_sweep()` — full alchemical cycle
  - `FloorDaemon.run_sweep()` — city-level coordination
  - `Gate.open_state()` — threshold access control

### Documentation:
- Add docstrings to all public functions
- Create `README.md` for thresholdfloor package
- Document AetherField integration requirements
- Add examples showing:
  - Creating a ThresholdFloor instance
  - Running a sweep
  - Checking alchemical phase
  - Using vault system

---

*The loom binds tight. The threshold is ready.* 🌙