def main() -> None:
    print("Hello from devpanel!")
