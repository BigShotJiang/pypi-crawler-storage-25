"""Tests for the stream module."""

from ...stream import MultiStreamReader, StreamReader


class FakeReader(StreamReader):
    """Minimal StreamReader double capturing lifecycle calls."""

    def __init__(self, streams, batches=()):
        self._streams = streams
        self._batches = list(batches)
        self.entered = False
        self.closed = False

    @property
    def streams(self):
        return self._streams

    def enter(self):
        self.entered = True

    def read(self, *, convert_blocks=False):
        yield from self._batches

    def close(self):
        self.closed = True


class TestMultiStreamReaderStreams:
    def test_merges_streams_from_all_readers(self):
        a = FakeReader({"s-a": ["H1:A"]})
        b = FakeReader({"s-b": ["H1:B"]})
        reader = MultiStreamReader([a, b])
        assert reader.streams == {"s-a": ["H1:A"], "s-b": ["H1:B"]}

    def test_later_readers_override_on_key_collision(self):
        a = FakeReader({"s": ["H1:A"]})
        b = FakeReader({"s": ["H1:B"]})
        reader = MultiStreamReader([a, b])
        assert reader.streams == {"s": ["H1:B"]}

    def test_empty_readers(self):
        assert MultiStreamReader([]).streams == {}


class TestMultiStreamReaderLifecycle:
    def test_enter_propagates_to_all_readers(self):
        readers = [FakeReader({}), FakeReader({})]
        MultiStreamReader(readers).enter()
        assert all(r.entered for r in readers)

    def test_close_propagates_to_all_readers(self):
        readers = [FakeReader({}), FakeReader({})]
        MultiStreamReader(readers).close()
        assert all(r.closed for r in readers)

    def test_context_manager_enters_and_closes(self):
        readers = [FakeReader({}), FakeReader({})]
        with MultiStreamReader(readers):
            assert all(r.entered for r in readers)
        assert all(r.closed for r in readers)


class TestMultiStreamReaderRead:
    def test_yields_from_all_readers(self):
        a = FakeReader({}, batches=[("s-a", "batch-a1"), ("s-a", "batch-a2")])
        b = FakeReader({}, batches=[("s-b", "batch-b1")])
        reader = MultiStreamReader([a, b])
        assert list(reader.read()) == [
            ("s-a", "batch-a1"),
            ("s-a", "batch-a2"),
            ("s-b", "batch-b1"),
        ]

    def test_empty_when_no_readers(self):
        assert list(MultiStreamReader([]).read()) == []
