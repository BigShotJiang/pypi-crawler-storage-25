# mypy: disable-error-code="arg-type"

import json
from unittest.mock import MagicMock, patch

import numpy
import pytest
from pyarrow import flight

from ...client import (
    _construct_stream_reader,
    _endpoint_is_kafka,
    _kafka_endpoint_url,
    _parse_data_types,
)
from ...flight import ChainedFlightReader
from ...kafka import KafkaReader
from ...stream import MultiStreamReader


def test_parse_data_types():
    # null case
    assert _parse_data_types(None) == []

    # list vs. non-list case
    expected = ["float64"]
    assert _parse_data_types(expected) == expected
    assert _parse_data_types(expected[0]) == expected

    # equivalent data types
    expected = ["int32", "float64"]
    assert _parse_data_types(expected) == expected
    assert _parse_data_types([numpy.int32, numpy.float64]) == expected
    assert _parse_data_types([numpy.dtype("int32"), numpy.dtype("float64")]) == expected


def _kafka_endpoint(broker_url, channels):
    """Build a kafka:// FlightEndpoint whose ticket lists the given channels."""
    ticket = flight.Ticket(
        json.dumps({"request": "Stream", "args": {"channels": channels}}).encode()
    )
    return flight.FlightEndpoint(ticket, [flight.Location(f"kafka://{broker_url}")])


def _flight_endpoint(channels):
    ticket = flight.Ticket(
        json.dumps({"request": "Stream", "args": {"channels": channels}}).encode()
    )
    return flight.FlightEndpoint(
        ticket, [flight.Location.for_grpc_tcp("localhost", 31206)]
    )


class TestEndpointHelpers:
    def test_is_kafka_true_for_kafka_scheme(self):
        assert _endpoint_is_kafka(_kafka_endpoint("broker:9092", ["H1:A"]))

    def test_is_kafka_false_for_grpc(self):
        assert not _endpoint_is_kafka(_flight_endpoint(["H1:A"]))

    def test_kafka_endpoint_url_extracts_host_and_port(self):
        ep = _kafka_endpoint("broker.example:9092", ["H1:A"])
        assert _kafka_endpoint_url(ep) == "broker.example:9092"


def _metadata(*channels):
    return {name: MagicMock(name=name) for name in channels}


class TestConstructStreamReader:
    """Endpoint partitioning and reader composition in Client.stream."""

    INITIAL_URL = "grpc://localhost:31206"

    def _build(self, endpoints, channels, *, kafka_url=None):
        # KafkaReader eagerly connects in __init__; patch to avoid that.
        with patch.object(KafkaReader, "__init__", return_value=None) as kafka_init:
            reader = _construct_stream_reader(
                endpoints,
                _metadata(*channels),
                start_ns=0,
                kafka_url=kafka_url,
                initial_url=self.INITIAL_URL,
            )
        return reader, kafka_init

    def test_explicit_kafka_url_overrides_endpoint_discovery(self):
        """Explicit kafka_url short-circuits both kafka and flight discovery."""
        endpoints = [
            _kafka_endpoint("discovered:9092", ["H1:A"]),
            _flight_endpoint(["H1:A"]),
        ]
        reader, kafka_init = self._build(endpoints, ["H1:A"], kafka_url="explicit:9092")
        assert isinstance(reader, KafkaReader)
        assert kafka_init.call_count == 1
        assert kafka_init.call_args.args[0] == "explicit:9092"

    def test_single_kafka_endpoint_yields_lone_kafka_reader(self):
        endpoints = [_kafka_endpoint("broker:9092", ["H1:A", "H1:B"])]
        reader, kafka_init = self._build(endpoints, ["H1:A", "H1:B"])
        assert isinstance(reader, KafkaReader)
        assert kafka_init.call_args.args[0] == "broker:9092"

    def test_multiple_kafka_brokers_yield_reader_per_broker(self):
        endpoints = [
            _kafka_endpoint("broker-a:9092", ["H1:A"]),
            _kafka_endpoint("broker-b:9092", ["H1:B"]),
        ]
        reader, kafka_init = self._build(endpoints, ["H1:A", "H1:B"])
        assert isinstance(reader, MultiStreamReader)
        assert kafka_init.call_count == 2
        brokers = sorted(call.args[0] for call in kafka_init.call_args_list)
        assert brokers == ["broker-a:9092", "broker-b:9092"]

    def test_kafka_endpoints_sharing_broker_merge_into_one_reader(self):
        endpoints = [
            _kafka_endpoint("broker:9092", ["H1:A"]),
            _kafka_endpoint("broker:9092", ["H1:B"]),
        ]
        reader, kafka_init = self._build(endpoints, ["H1:A", "H1:B"])
        assert isinstance(reader, KafkaReader)
        assert kafka_init.call_count == 1
        # second positional is the per-broker metadata dict
        assert set(kafka_init.call_args.args[1]) == {"H1:A", "H1:B"}

    def test_flight_only_yields_single_chained_reader(self):
        endpoints = [_flight_endpoint(["H1:A"]), _flight_endpoint(["H1:B"])]
        reader, _ = self._build(endpoints, ["H1:A", "H1:B"])
        assert isinstance(reader, ChainedFlightReader)

    def test_mixed_kafka_and_flight_combine_into_multistream(self):
        """The motivating case: both reader types in one MultiStreamReader."""
        endpoints = [
            _kafka_endpoint("broker:9092", ["H1:A"]),
            _flight_endpoint(["H1:B"]),
        ]
        reader, kafka_init = self._build(endpoints, ["H1:A", "H1:B"])
        assert isinstance(reader, MultiStreamReader)
        inner_types = {type(r) for r in reader._readers}
        assert inner_types == {KafkaReader, ChainedFlightReader}
        assert kafka_init.call_count == 1

    def test_no_endpoints_raises(self):
        with pytest.raises(RuntimeError, match="No valid endpoints"):
            self._build([], ["H1:A"])
