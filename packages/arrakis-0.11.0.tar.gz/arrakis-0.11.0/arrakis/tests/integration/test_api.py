import numpy
import pytest

import arrakis

from ...block import Time

pytestmark = pytest.mark.integration


def test_count(arrakis_server):
    assert arrakis.count("H1:TEST-CHANNEL*") == 2
    assert arrakis.count("H1:TEST-STATE*") == 1


def test_find(arrakis_server):
    channels = list(arrakis.find("H1:TEST*"))
    assert len(channels) == 3


def test_describe(arrakis_server):
    channels = list(arrakis.describe(["H1:TEST-CHANNEL_COS"]).values())
    assert len(channels) == 1
    channel = channels[0]

    assert channel.domain == "H1"
    assert channel.data_type == "float64"
    assert channel.sample_rate == 16384


def test_server_info(arrakis_server):
    info = arrakis.server_info()
    assert isinstance(info, dict)
    assert "server_version" in info
    assert "arrakis_version" in info
    assert "arrakis_schema_version" in info
    assert "backend" in info
    assert "backend_version" in info
    assert "capabilities" in info
    assert "domains" in info
    assert isinstance(info["capabilities"], list)
    assert "find" in info["capabilities"]
    assert "stream" in info["capabilities"]
    assert isinstance(info["domains"], list)


def test_scope_map(arrakis_server):
    result = arrakis.scope_map()
    assert isinstance(result, dict)
    assert "endpoints" in result
    assert isinstance(result["endpoints"], dict)
    domains = set()
    for endpoint_info in result["endpoints"].values():
        assert "scopes" in endpoint_info
        domains.update(endpoint_info["scopes"].keys())
    assert "H1" in domains


def test_domains(arrakis_server):
    domains = arrakis.domains()
    assert isinstance(domains, list)
    assert "H1" in domains
    assert domains == sorted(domains)


def test_fetch(arrakis_server, arrakis_channels):
    channel = "H1:TEST-STATE_ONES"
    start = 1000000000
    end = 1000000010
    duration = end - start

    expected_channel = arrakis_channels[channel]

    block = arrakis.fetch([channel], start, end)
    series = block[channel]

    assert block.time_ns == start * Time.SECONDS
    assert block.duration_ns == duration * Time.SECONDS
    assert len(block.channels) == 1

    assert series.time_ns == start * Time.SECONDS
    assert series.duration_ns == duration * Time.SECONDS
    assert series.name == channel
    assert series.data_type == expected_channel.data_type
    assert series.sample_rate == expected_channel.sample_rate
    assert series.channel.stride == expected_channel.stride
    assert series.channel.max_latency == expected_channel.max_latency

    expected = numpy.ones(
        duration * int(expected_channel.sample_rate), dtype=numpy.int32
    )
    assert numpy.allclose(series.data, expected)
