# Using the CLI

arrakis includes a command-line interface. It provides subcommands for all
major operations.

## Overview

```bash
arrakis [--url URL] [--ssh-proxy HOST] COMMAND [OPTIONS]
```

Global options:

| Option | Description |
|---|---|
| `--url`, `-u` | Server URL (overrides `ARRAKIS_SERVER`) |
| `--ssh-proxy HOST` | Create an SSH tunnel to HOST for the connection |
| `--version`, `-v` | Print version and exit |
| `--help`, `-h` | Print help and exit |

For detailed help on any command, run `arrakis <command> --help`.

## Finding Channels

```bash
# find all channels matching a pattern
arrakis find "H1:LSC-.*"

# filter by data type and sample rate
arrakis find "H1:.*" --data-type float64 --min_rate 256 --max_rate 4096

# filter by publisher
arrakis find --publisher my_producer
```

Aliases: `search`, `list`

## Counting Channels

```bash
arrakis count "H1:LSC-.*"
```

Accepts the same filter options as `find`.

## Describing Channels

```bash
arrakis describe H1:CAL-DELTAL_EXTERNAL_DQ H1:LSC-POP_A_LF_OUT_DQ
```

Alias: `show`

You can read channel names from stdin:

```bash
echo "H1:CAL-DELTAL_EXTERNAL_DQ" | arrakis describe -
```

## Streaming Data

```bash
# live stream
arrakis stream H1:CAL-DELTAL_EXTERNAL_DQ

# historical stream
arrakis stream H1:CAL-DELTAL_EXTERNAL_DQ --start 1187000000 --end 1187001000

# show latency information
arrakis stream H1:CAL-DELTAL_EXTERNAL_DQ --latency
```

The `--start` and `--end` options accept GPS times or arbitrary date/time
strings.

## Fetching Data

```bash
# fetch with explicit end time
arrakis fetch H1:CAL-DELTAL_EXTERNAL_DQ --start 1187000000 --end 1187001000

# fetch with duration
arrakis fetch H1:CAL-DELTAL_EXTERNAL_DQ --start 1187000000 --duration 1000
```

Either `--end` or `--duration` is required.

## Publishing Data

```bash
# publish a sine wave to a channel
arrakis publish -p my_producer H1:FKE-TEST_CHANNEL1 "sin(t)"

# publish a constant value
arrakis publish -p my_producer H1:FKE-TEST_CHANNEL1 "42"

# list channels for a publisher
arrakis publish -p my_producer --list
```

Arguments are channel name + generator function pairs. Generator functions are
sympy expressions where `t` represents time. Multiple pairs can be provided:

```bash
arrakis publish -p my_producer \
    H1:FKE-TEST_CHANNEL1 "sin(t)" \
    H1:FKE-TEST_CHANNEL2 "cos(t)"
```

!!! note
    The `publish` subcommand requires the `cli` extra (`pip install
    arrakis[cli]`) which installs [SymPy](https://www.sympy.org/) for
    expression parsing.

## Output Formatting

Most subcommands default to table output. Alternative formats are available:

```bash
# default table output
arrakis find "H1:LSC-.*"

# JSON output
arrakis find "H1:LSC-.*" --json

# other formats (varies by formatter availability)
arrakis find "H1:LSC-.*" --repr
```

Use `--table` to explicitly request table formatting.
