# User Guide

arrakis-python is a client library for the Arrakis timeseries data system. It
provides both a Python API and a command-line interface for querying, streaming,
and publishing gravitational wave detector data.

## Core Concepts

**Channel**
:   A channel represents a single data stream from a detector subsystem. Channel
    names follow the convention `<domain>:<subsystem>[-_]<rest>`, for example
    `H1:CAL-DELTAL_EXTERNAL_DQ`. Each channel has a fixed data type and sample
    rate.

**SeriesBlock**
:   A [arrakis.block.SeriesBlock][] is the fundamental data container. It holds
    timeseries data for one or more channels at a given timestamp. When you
    fetch or stream data, you get back `SeriesBlock` objects.

**GPS Time**
:   All timestamps use GPS time. The API accepts GPS seconds as `float` values.
    Internally, arrakis works in nanoseconds for precision, but the user-facing
    API handles the conversion.

**Client**
:   The [arrakis.client.Client][] manages the connection to an Arrakis server using
    Apache Arrow Flight. Top-level functions like `arrakis.fetch()` create a
    client automatically; you can also instantiate one directly for reuse.

## Guide Overview

Each topic builds on the previous, but they can also be read independently:

1. **[Fetching Data](fetch-data.md)** -- Retrieve historical timeseries for a
   GPS time range.
2. **[Streaming Data](stream-data.md)** -- Stream live or historical data as
   it becomes available.
3. **[Finding Channels](find-channels.md)** -- Discover channels by name
   pattern, data type, sample rate, or publisher.
4. **[Publishing Data](publish-data.md)** -- Publish timeseries data into the
   system.
5. **[Working with Series Blocks](series-blocks.md)** -- Inspect, filter,
   concatenate, and handle gaps in data.
6. **[Using the CLI](cli.md)** -- Command-line access to all features.
7. **[Connecting to Servers](connecting.md)** -- Server URLs, environment
   variables, and SSH tunneling.

For a step-by-step introduction, start with the
[Getting Started tutorial](../tutorials/getting-started.md).
