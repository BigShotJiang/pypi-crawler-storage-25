# arrakis-python

Python client library for the Arrakis low-latency timeseries data distribution
platform. Query, stream, and publish timeseries data.

## Installation

With `pip`:

```bash
pip install arrakis
```

With `conda`:

```bash
conda install -c conda-forge arrakis-python
```

??? info "CLI extras"
    The CLI `publish` subcommand requires SymPy for expression parsing.
    Install with:

    ```bash
    pip install arrakis[cli]
    ```

??? info "Developer installation"
    ```bash
    git clone https://git.ligo.org/ngdd/arrakis-python.git
    cd arrakis-python
    pip install -e ".[dev]"
    ```

## Where to Start

- **[Tutorial](tutorials/getting-started.md)** -- New to arrakis? Fetch your
  first timeseries data step by step.
- **[User Guide](user/index.md)** -- Fetching, streaming, channel discovery,
  publishing, the CLI, and more.
- **[Background](background/architecture.md)** -- How the system works: Arrow
  Flight, Kafka, multiplexing, and the data model.
- **[API Reference](reference/)** -- Auto-generated documentation from source
  code.

## Resources

- [Documentation](https://docs.ligo.org/ngdd/arrakis-python)
- [Source Code](https://git.ligo.org/ngdd/arrakis-python)
- [Issue Tracker](https://git.ligo.org/ngdd/arrakis-python/-/issues)
- [PyPI](https://pypi.org/project/arrakis/)
- [conda-forge](https://anaconda.org/conda-forge/arrakis-python)
