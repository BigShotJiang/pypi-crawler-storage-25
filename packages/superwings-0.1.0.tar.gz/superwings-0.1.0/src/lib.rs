use pyo3::prelude::*;

/// Find the nearest airport for the given (lat, lng) coordinates.
///
/// Returns a dict with "code" (e.g. "kr.gmp") and "name" (e.g. "Seoul, Korea"),
/// or a dict with "error" on failure.
#[pyfunction]
fn find_nearest_airport(lat: f64, lng: f64) -> PyResult<PyObject> {
    Python::with_gil(|py| {
        let dict = pyo3::types::PyDict::new(py);
        match airport_finder::find_nearest_airport(lat, lng) {
            Ok((code, name)) => {
                dict.set_item("code", code)?;
                dict.set_item("name", name)?;
            }
            Err(e) => {
                dict.set_item("error", e)?;
            }
        }
        Ok(dict.into())
    })
}

#[pymodule]
fn _superwings(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(find_nearest_airport, m)?)?;
    Ok(())
}
