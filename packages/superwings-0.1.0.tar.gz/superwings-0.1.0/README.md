# superwings

Find the nearest airport from (lat, lng) coordinates.

Pre-built Python wheel — no Rust toolchain needed. Embeds ~10,000 airports and country polygon boundaries with R-tree spatial indexing.

## Install

```bash
pip install superwings
```

## Usage

```python
from superwings import find_nearest_airport

result = find_nearest_airport(37.5665, 126.978)
# {"code": "kr.gmp", "name": "Seoul, Korea"}

result = find_nearest_airport(35.6762, 139.6503)
# {"code": "jp.hnd", "name": "Tokyo, Japan"}
```

## Output format

- `code`: `country_code.iata_code` (e.g., `kr.gmp`, `us.jfk`, `jp.hnd`)
- `name`: `City, Country` (e.g., `Seoul, Korea`)

## License

MIT
