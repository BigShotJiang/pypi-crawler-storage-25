"""Find the nearest airport from (lat, lng) coordinates.

Usage::

    from superwings import find_nearest_airport

    result = find_nearest_airport(37.5665, 126.978)
    # {"code": "kr.gmp", "name": "Seoul, Korea"}
"""

from ._superwings import find_nearest_airport

__all__ = ["find_nearest_airport"]
