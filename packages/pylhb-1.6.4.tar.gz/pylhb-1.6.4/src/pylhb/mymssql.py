'''
模块：myodbc
作者：李生
描述：通过ODBC操作Microsoft SQL Server数据库，包含连接、创建表、增删改查等操作。
注意：
ODBC Driver 17 for SQL Server下载：
https://learn.microsoft.com/zh-cn/sql/connect/odbc/download-odbc-driver-for-sql-server?view=sql-server-ver16
注意，如果是ODBC Driver 18 for SQL Server，那实例化时记得传driver.
'''
import pyodbc
import asyncio
from concurrent.futures import ThreadPoolExecutor

class MyMSSQL:
    """MSSQL管理"""
    def __init__(self,*,server=None,user=None,password=None,database=None,port=1433,timeout=0,autoCommit=False,trusted=False,driver="ODBC Driver 17 for SQL Server",maxWorker=5):
        """
        MYSQL构造
        Args:
            server：服务器名称
            user：用户
            password：密码
            database：数据库
            port：端口号
            timeout：超时时间
            autoCommit：自动提交
            trusted：信任
            driver：驱动
            maxWorker：最大线程数
        """
        self.server=server
        self.user=user
        self.password=password
        self.database=database
        self.port=port
        self.timeout=timeout
        self.autoCommit=autoCommit
        self.trusted=trusted
        self.driver=driver
        self.conn=None
        self.cursor=None
        self.executor = ThreadPoolExecutor(max_workers=maxWorker)
        self.loop = asyncio.get_event_loop()
        
    def getConnectString(self) :
        """获取连接字符串"""
        conn_str = f"DRIVER={{{self.driver}}};SERVER={self.server},{self.port};DATABASE={self.database};"
        
        if self.trusted:
            conn_str += "Trusted_Connection=yes;"
        else:
            if self.user and self.password:
                conn_str += f"UID={self.user};PWD={self.password};"
            if self.timeout>0:
                conn_str += f"Connection Timeout={self.timeout};"
        
        return conn_str
            
    async def connect4Async(self):
        """异步连接数据库"""
        return await self.loop.run_in_executor(
            self.executor, 
            self.connect,
        )
        
    def connect(self):
        """同步连接数据库"""
        try:
            connectString = self.getConnectString()
            self.conn = pyodbc.connect(connectString,autocommit=self.autoCommit)
            self.cursor=self.conn.cursor()
            return True,"OK"
        except Exception as e:
            self.conn=None
            self.cursor=None
            return False,str(e)
            
    @property
    def Connected(self):
        """获取连接状态"""
        return self.conn is not None
        
    def setAutoCommit(self,autoCommit):
        """设置自动提交"""
        if not self.conn:
            return False,"未连接数据库。"
        try:
            self.conn.autocommit=autoCommit
            return True
        except Exception as e:
            return False
            
    @property
    def IsAutoCommit(self):
        """获取是否自动提交"""
        return self.conn.autocommit
        
    async def insert4Async(self, tableName: str, data: dict):
        """
        异步插入记录
        Args:
            tableName：表名
            data：数据字典
        Returns:
            是否成功
            执行结果
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.insert,
            tableName,
            data
        )
        
    def insert(self, tableName: str, data: dict):
        """
        插入记录
        Args:
            tableName：表名
            data：数据字典
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return False,"未连接数据库。"
        try:
            columns = ", ".join(data.keys())
            values = tuple(data.values())
            sql = f"INSERT INTO {tableName} ({columns}) VALUES {values}"
            self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))
            
    async def update4Async(self, table_name: str, data: dict, where: str, params: tuple[any]):
        """
        异步修改记录
        Args:
            tableName：表名
            data：数据字典
            where：条件
            params：条件参数值
        Returns:
            是否成功
            执行结果
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.update,
            table_name,
            data,
            where,
            params
        )
        
    def update(self, tableName: str, data: dict, where: str, params: tuple[any]):
        """
        修改记录
        Args:
            tableName：表名
            data：数据字典
            where：条件
            params：条件参数值
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return False,"未连接数据库。"
        try:
            set_clause = ", ".join([f"{key} = ?" for key in data.keys()])
            values = tuple(data.values()) + params
            sql = f"UPDATE {tableName} SET {set_clause} WHERE {where}"
            self.cursor.execute(sql, values)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))
        
    async def delete4Async(self, tableName: str, where: str, params: tuple[any]):
        """
        异步删除记录
        Args:
            tableName：表名
            where：条件
            params：条件参数值
        Returns:
            是否成功
            执行结果
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.delete,
            tableName,
            where,
            params
        )
        
    def delete(self, tableName: str, where: str, params: tuple[any]):
        """
        删除记录
        Args:
            tableName：表名
            where：条件
            params：条件参数值
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return False,"未连接数据库。"
        try:
            sql = f"DELETE FROM {tableName} WHERE {where}"
            self.cursor.execute(sql, params)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))
            
    async def select4Async(self, tableName, columns: tuple[str] = None, where=None, params: tuple[any]=None,toDict=True):
        """
        异步查询数据
        Args:
            tableName：表名
            columns：列
            where：条件
            params：条件参数值
            toDict：结果是否转为字典
        Returns:
            是否成功
            执行结果
            字典/列表
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.select,
            tableName,
            columns,
            where,
            params,
            toDict
        )
        
    def select(self, tableName, columns: tuple[str] = None, where=None, params: tuple[any]=None,toDict=True):
        """
        查询数据
        Args:
            tableName：表名
            columns：列
            where：条件
            params：条件参数值
            toDict：结果是否转为字典
        Returns:
            是否成功
            执行结果
            字典/列表
        """
        if not self.conn:
            return False,"未连接数据库。",None
        try:
            cols = "*" if columns is None else ", ".join(columns)
            sql = f"SELECT {cols} FROM {tableName}"
            if where:
                sql += f" WHERE {where}"
            print(sql)
            if where and params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            if toDict:
                # 获取列名
                columns = [column[0] for column in self.cursor.description]
                # 转换为字典列表
                data = []
                for row in self.cursor.fetchall():
                    data.append(dict(zip(columns, row)))
                return True,"OK",data
            else:
                data = self.cursor.fetchall()
                return True,"OK",data
        except Exception as e:
            return False,str(e),None
            
    async def get4Async(self,sql,toDict=True):
        """
        异步查询数据
        Args:
            sql：SQL语句
            toDict：结果是否转为字典
        Returns:
            字典/列表
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.get,
            sql,
            toDict
        )
            
    def get(self,sql,toDict=True):
        """
        查询数据
        Args:
            sql：SQL语句
            toDict：结果是否转为字典
        Returns:
            字典/列表
        """
        if not self.conn:
            return None
        try:
            self.cursor.execute(sql)
            if toDict:
                # 获取列名
                columns = [column[0] for column in self.cursor.description]
                # 转换为字典列表
                results = []
                for row in self.cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                return results
            else:
                return self.cursor.fetchall()
        except:
            return None

    async def exec4Async(self,sql):
        """
        异步执行SQ
        Args:
            sql：SQL语句
        Returns:
            是否成功
            执行结果
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.exec,
            sql
        )
        
    def exec(self,sql):
        """
        执行SQL
        Args:
            sql：SQL语句
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return False,"未连接数据库。"
        try:
            self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))

    async def execProc4Async(self,procName,params: tuple[any] = None):
        """
        异步执行存储过程
        Args:
            procName：存储过程名称
            params：参数
        Returns:
            是否成功
            执行结果
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.execProc,
            procName,
            params
        )
        
    def execProc(self,procName,params: tuple[any] = None):
        """
        执行存储过程
        Args:
            procName：存储过程名称
            params：参数
        Returns:
            是否成功
            执行结果
        """
        if not self.conn:
            return (False,"未连接数据库。")
        try:
            if params:
                placeholders = ', '.join(['?' for _ in params])
                sql = f"EXEC {procName} {placeholders}"
                self.cursor.execute(sql, params)
            else:
                sql = f"EXEC {procName}"
                self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))

    async def execProcGet4Async(self,procName,params: list[any] = None):
        """
        异步执行存储过程
        Args:
            procName：存储过程名称
            params：参数
        Returns:
            是否成功
            执行结果
            数据
        """
        return await self.loop.run_in_executor(
            self.executor, 
            self.execProcGet,
            procName,
            params
        )
        
    def execProcGet(self,procName,params: list[any] = None):
        """
        执行存储过程并返回数据
        Args:
            procName：存储过程名称
            params：参数
        Returns:
            是否成功
            执行结果
            数据
        """
        if not self.conn:
            return (False,"未连接数据库。",None)
        try:
            if params:
                placeholders = ', '.join(['?' for _ in params])
                sql = f"EXEC {procName} {placeholders}"
                self.cursor.execute(sql, params)
            else:
                sql = f"EXEC {procName}"
                self.cursor.execute(sql)
                
            datas = []
            if self.cursor.description:
                columns = [desc[0] for desc in self.cursor.description]
                for row in self.cursor.fetchall():
                    datas.append(dict(zip(columns, row)))
                    
            return (True,"OK",datas)
        except Exception as e:
            return (False,str(e),None)

    def commit(self):
        """提交事务"""
        if not self.conn:
            return
        if self.conn.autocommit==True:
            return
        self.conn.commit()

    def rollback(self):
        """回滚事务"""
        if not self.conn:
            return
        self.conn.rollback()

    def close(self):
        """关闭连接"""
        if self.cursor:
            self.cursor.close()
            self.cursor=None
        if self.conn:
            self.conn.close()
            self.conn=None