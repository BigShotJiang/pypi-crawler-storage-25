"""Cluster-key stability: the same logical failure must always produce the
same cluster label across Python versions, capture sources, and traceback
formatting variations."""

from __future__ import annotations

from datetime import datetime, timezone

from cairn.distill.cluster import cluster
from cairn.store.schema import TruthRecord


def _r(content: str, exc: str = "ValueError", source: str = "pytest") -> TruthRecord:
    return TruthRecord(
        source=source,
        domain="test",
        content=content,
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
        exception_type=exc,
    )


class TestInnermostFrameExtraction:
    def test_single_frame_traceback(self) -> None:
        tb = 'File "foo.py", line 42, in parse_config'
        key = list(cluster([_r(tb)]).keys())[0]
        assert key == "ValueError::parse_config"

    def test_multi_frame_picks_innermost(self) -> None:
        tb = (
            'File "a.py", line 10, in outer\n'
            'File "b.py", line 20, in middle\n'
            'File "c.py", line 30, in innermost_fn'
        )
        key = list(cluster([_r(tb)]).keys())[0]
        assert key == "ValueError::innermost_fn"

    def test_qualified_name_uses_trailing_component(self) -> None:
        tb = 'File "x.py", line 5, in MyClass.method_name'
        key = list(cluster([_r(tb)]).keys())[0]
        assert key == "ValueError::method_name"

    def test_dunder_frame(self) -> None:
        tb = 'File "x.py", line 5, in <module>'
        key = list(cluster([_r(tb)]).keys())[0]
        # <module> is accepted as a frame name
        assert key.startswith("ValueError::")

    def test_chained_exception_picks_final_frame(self) -> None:
        """During handling of another exception, the final traceback frame
        (not the original one) should drive the cluster."""
        tb = (
            'File "original.py", line 1, in first_cause\n'
            '\nDuring handling of the above exception, another occurred:\n\n'
            'File "final.py", line 99, in final_handler'
        )
        key = list(cluster([_r(tb)]).keys())[0]
        assert key == "ValueError::final_handler"

    def test_monitor_raise_content(self) -> None:
        key = list(cluster([_r("RAISE acme.foo.bar ValueError: bad", source="monitor")]).keys())[0]
        assert key == "ValueError::bar"

    def test_monitor_call_content(self) -> None:
        key = list(cluster([_r("CALL acme.foo.handler", source="monitor")]).keys())[0]
        assert key == "ValueError::handler"

    def test_unparseable_content_falls_back_to_exception_only(self) -> None:
        key = list(cluster([_r("something totally unexpected")]).keys())[0]
        assert key == "ValueError"


class TestClusterStability:
    def test_same_content_same_key(self) -> None:
        tb = 'File "foo.py", line 42, in parse_config'
        k1 = list(cluster([_r(tb)]).keys())[0]
        k2 = list(cluster([_r(tb)]).keys())[0]
        assert k1 == k2

    def test_whitespace_variation_doesnt_fragment_clusters(self) -> None:
        """Trailing whitespace / CRLF shouldn't produce a different key."""
        a = 'File "foo.py", line 42, in parse_config'
        b = 'File "foo.py", line 42, in parse_config   '
        c = 'File "foo.py", line 42, in parse_config\r\n'
        keys = {
            list(cluster([_r(a)]).keys())[0],
            list(cluster([_r(b)]).keys())[0],
            list(cluster([_r(c)]).keys())[0],
        }
        assert len(keys) == 1

    def test_line_number_variation_doesnt_fragment(self) -> None:
        """Same function, different line — one cluster."""
        a = 'File "x.py", line 10, in fn'
        b = 'File "x.py", line 11, in fn'
        key_a = list(cluster([_r(a)]).keys())[0]
        key_b = list(cluster([_r(b)]).keys())[0]
        assert key_a == key_b
