"""Tests for structured assertion capture + flaky detection."""

from __future__ import annotations

from datetime import datetime, timezone

from cairn.capture.assertions import (
    append_structured_assertion,
    flaky_tests,
    parse_assertion,
)
from cairn.store.schema import TruthRecord


def _fail(nodeid: str, rhs: str) -> TruthRecord:
    return TruthRecord(
        source="pytest",
        domain="t",
        content=f"FAIL {nodeid}\nexception: AssertionError\nAssertionError: 1 == {rhs}",
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
        exception_type="AssertionError",
    )


class TestParseAssertion:
    def test_numeric_equality(self) -> None:
        p = parse_assertion("AssertionError: 42 == 43")
        assert p is not None
        assert p.op == "=="
        assert p.lhs_type == "int"
        assert p.numeric_delta == 1.0

    def test_float_delta(self) -> None:
        p = parse_assertion("AssertionError: 1.5 == 2.0")
        assert p is not None
        assert abs(p.numeric_delta - 0.5) < 1e-9

    def test_string_inequality(self) -> None:
        p = parse_assertion("AssertionError: 'foo' != 'bar'")
        assert p is not None
        assert p.op == "!="
        assert p.lhs_type == "str"
        assert p.numeric_delta is None

    def test_unrecognised_returns_none(self) -> None:
        assert parse_assertion("some other error") is None

    def test_assert_in(self) -> None:
        p = parse_assertion("AssertionError: 'x' in ['a', 'b', 'x']")
        assert p is not None and p.op == "in"
        assert p.lhs == "'x'"
        assert "'a', 'b', 'x'" in p.rhs

    def test_assert_not_in(self) -> None:
        p = parse_assertion("AssertionError: 'z' not in ['a', 'b']")
        assert p is not None and p.op == "not in"

    def test_approx(self) -> None:
        p = parse_assertion("AssertionError: assert 1.0 == 1.01 ± 0.001")
        assert p is not None and p.op == "approx"
        assert p.numeric_delta is not None and abs(p.numeric_delta - 0.01) < 1e-9
        assert "±" in p.rhs

    def test_approx_plus_minus_variant(self) -> None:
        p = parse_assertion("AssertionError: assert 3.14 == 3.1415 +/- 0.01")
        assert p is not None and p.op == "approx"

    def test_did_not_raise(self) -> None:
        p = parse_assertion("Failed: DID NOT RAISE <class 'ValueError'>")
        assert p is not None
        assert p.op == "did_not_raise"
        assert p.rhs == "ValueError"


class TestAppendTrailer:
    def test_idempotent(self) -> None:
        msg = "FAIL x\nAssertionError: 1 == 2"
        once = append_structured_assertion(msg)
        twice = append_structured_assertion(once)
        assert once == twice
        assert "cairn-assert:" in once

    def test_no_match_passes_through(self) -> None:
        msg = "FAIL x\nValueError: broken"
        assert append_structured_assertion(msg) == msg


class TestFlakyTests:
    def test_flags_test_with_multiple_distinct_rhs(self) -> None:
        records = [
            _fail("test_a", "2"),
            _fail("test_a", "3"),
            _fail("test_a", "4"),
        ]
        flakes = flaky_tests(records)
        assert len(flakes) == 1
        assert flakes[0].test_id == "test_a"
        assert set(flakes[0].distinct_rhs) == {"2", "3", "4"}

    def test_ignores_single_rhs(self) -> None:
        records = [_fail("test_stable", "2"), _fail("test_stable", "2")]
        assert flaky_tests(records) == []

    def test_ignores_non_pytest(self) -> None:
        r = TruthRecord(
            source="monitor",
            domain="t",
            content="RAISE x AssertionError: 1 == 2",
            confidence=1.0,
            occurred_at=datetime.now(tz=timezone.utc),
        )
        assert flaky_tests([r]) == []
