"""Adversarial corpus + light fuzz for the secret/PII scrubber.

The signature-based scrubber is conservative — false positives cost
signal quality, false negatives leak credentials into agent prompts.
This module pins both ends of the trade-off:

  - SHOULD_REDACT: every entry MUST be unrecognisable in the output.
  - SHOULD_PASS_THROUGH: every entry must round-trip unchanged.
  - fuzz: random key/secret combinations exercised against the kv rule
    so a regression in _KV_ASSIGN doesn't silently widen the gap.
"""

from __future__ import annotations

import random
import string

import pytest

from cairn.capture.scrub import scrub

# ---------------------------------------------------------------------------
# Things that MUST be redacted — leaking any of these into an agent prompt
# is a real security incident.
# ---------------------------------------------------------------------------

SHOULD_REDACT: list[tuple[str, str]] = [
    # --- Prefixed sensitive-suffix variants (v0.3.4 gap closure) ---
    ("aws_secret=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY", "wJalrXUtnFEMI/K7MDENG"),
    ("aws_secret_access_key: abcdef1234567890+/ZYXW0987", "abcdef1234567890"),
    ("stripe_key=sk_live_abc" + "X" * 40, "sk_live_abc"),
    ("db_password=hunter2", "hunter2"),
    ("_authToken=abcdef1234567890", "abcdef1234567890"),
    ("apiKey: myInHouseTokenValue", "myInHouseTokenValue"),
    ("GITHUB_TOKEN=ghs_xxxxxxxxxxxx", "ghs_xxxxxxxxxxxx"),
    ("sessionID: abc123sessionvalue", "abc123sessionvalue"),
    # --- Original v0.3.1 corpus ---
    # (input, substring that MUST NOT appear in the output)
    ("password=hunter2", "hunter2"),
    ("PASSWORD: 'super-secret-value'", "super-secret-value"),
    ('api_key="sk-abc123def456"', "sk-abc123def456"),
    ("API_KEY=AKIAIOSFODNN7EXAMPLE", "AKIAIOSFODNN7EXAMPLE"),
    ("authorization: Bearer ghp_" + "A" * 36, "ghp_" + "A" * 36),
    ("token=" + "x" * 50, "x" * 50),
    ("client_secret: 'oauth-secret-payload'", "oauth-secret-payload"),
    ("private_key=BEGIN_KEY_DATA", "BEGIN_KEY_DATA"),
    ("session_id: abc123sessionvalue", "abc123sessionvalue"),
    ("cookie=jsessionid=ABCDEF1234", "ABCDEF1234"),

    # Token shapes — keys can be innocuous, value should still be flagged.
    ("nothing_special=AKIAIOSFODNN7EXAMPLE", "AKIAIOSFODNN7EXAMPLE"),
    ("note: ghp_" + "B" * 40, "ghp_" + "B" * 40),
    ("inline sk-ant-" + "z" * 30 + " in logs", "sk-ant-" + "z" * 30),
    ("see eyJhbGciOi" + "A" * 25 + "." + "B" * 25 + "." + "C" * 25,
     "eyJhbGciOi" + "A" * 25 + "." + "B" * 25 + "." + "C" * 25),
    ("got xoxb-1234567890-abcdefghijkl from slack",
     "xoxb-1234567890-abcdefghijkl"),

    # PEM blocks
    (
        "key: -----BEGIN RSA PRIVATE KEY-----\nMIIE\n-----END RSA PRIVATE KEY-----",
        "MIIE",
    ),

    # PII shapes
    ("user alice.smith@example.com errored", "alice.smith"),
    ("from 10.0.0.1", "10.0.0.1"),
    ("card 4111 1111 1111 1111 declined", "4111 1111 1111 1111"),
]


# ---------------------------------------------------------------------------
# Things the scrubber MUST leave alone — false positives waste agent context.
# ---------------------------------------------------------------------------

SHOULD_PASS_THROUGH: list[str] = [
    "FAIL test_foo: AssertionError: 42 != 43",
    "RAISE acme.foo.bar ValueError: bad config",
    "broad_except: line 42 in src/foo.py uses bare except",
    "PASS tests/test_a.py::x",
    "untested_branch: line 17 in foo.py not executed by test suite",
    "name=alice age=30",  # short, clearly non-secret values
    "version=1.2.3",
    "url=https://github.com/Cope-Labs/cairn",
    "python>=3.10",
]


# ---------------------------------------------------------------------------
# Hard-fail leak corpus
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw,must_not_appear",
    SHOULD_REDACT,
    ids=lambda v: v[:30] if isinstance(v, str) else "",
)
def test_must_redact(raw: str, must_not_appear: str) -> None:
    out = scrub(raw)
    assert must_not_appear not in out, (
        f"LEAK: scrubber failed to redact {must_not_appear!r}\n"
        f"  input:  {raw!r}\n"
        f"  output: {out!r}"
    )


@pytest.mark.parametrize("raw", SHOULD_PASS_THROUGH)
def test_must_pass_through(raw: str) -> None:
    """False positives degrade signal quality — these clean strings must
    round-trip unchanged."""
    assert scrub(raw) == raw


# ---------------------------------------------------------------------------
# Light deterministic fuzz — exercise the kv rule against random
# key/secret combinations so regressions in _KV_ASSIGN can't slip past.
# ---------------------------------------------------------------------------

_SENSITIVE_KEYS = [
    "password", "PASSWORD", "Password",
    "api_key", "API_KEY", "ApiKey",
    "secret", "client_secret",
    "token", "auth_token", "refresh_token",
    "authorization", "bearer",
    "cookie", "session", "sessionid",
    "private_key", "privateKey",
    # v0.3.4 prefixed variants
    "aws_secret", "stripe_key", "db_password", "_authToken", "GITHUB_TOKEN",
    "app.pwd", "some-service-token",
]

_SEPARATORS = ["=", ": ", " = ", "='", "=\""]


def _rand_secret(rng: random.Random, length: int = 20) -> str:
    alphabet = string.ascii_letters + string.digits + "-_"
    return "".join(rng.choice(alphabet) for _ in range(length))


@pytest.mark.parametrize("seed", range(50))
def test_fuzz_kv_redaction(seed: int) -> None:
    rng = random.Random(seed)
    key = rng.choice(_SENSITIVE_KEYS)
    sep = rng.choice(_SEPARATORS)
    secret = _rand_secret(rng, length=rng.randint(12, 40))
    raw = f"context: {key}{sep}{secret}"
    out = scrub(raw)
    assert secret not in out, (
        f"fuzz seed={seed}: leaked {secret!r} from input {raw!r}\n"
        f"  output: {out!r}"
    )


@pytest.mark.parametrize("seed", range(20))
def test_fuzz_clean_text_unchanged(seed: int) -> None:
    """Random words that don't match a sensitive pattern should pass through.

    Uses a small fixed vocabulary of clearly-innocuous tokens to prove the
    scrubber doesn't redact arbitrary text just because it has '=' in it.
    """
    rng = random.Random(seed)
    words = ["foo", "bar", "baz", "qux", "value", "count", "size", "name"]
    pieces = []
    for _ in range(rng.randint(2, 5)):
        k = rng.choice(words)
        v = str(rng.randint(0, 9999))
        pieces.append(f"{k}={v}")
    raw = " ".join(pieces)
    assert scrub(raw) == raw, f"false positive on {raw!r} → {scrub(raw)!r}"
