"""Tests for ruff-config diffing in distill.rules."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from cairn.distill.rules import required_codes, ruff_config_diff
from cairn.store.schema import TruthRecord


def _ast(check: str) -> TruthRecord:
    return TruthRecord(
        source="ast",
        domain="test",
        content=f"{check}: caught at foo.py:42",
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
        source_file="src/foo.py",
    )


class TestRequiredCodes:
    def test_maps_ast_checks_to_ruff_codes(self) -> None:
        codes = required_codes([_ast("broad_except"), _ast("mutable_default")])
        assert codes == {"BLE001", "B006"}

    def test_ignores_unknown_checks(self) -> None:
        codes = required_codes([_ast("nonexistent_check")])
        assert codes == set()

    def test_ignores_non_ast_records(self) -> None:
        pytest_rec = TruthRecord(
            source="pytest",
            domain="t",
            content="FAIL x",
            confidence=1.0,
            occurred_at=datetime.now(tz=timezone.utc),
        )
        assert required_codes([pytest_rec]) == set()


class TestRuffConfigDiff:
    def test_missing_codes_identified(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[tool.ruff.lint]\nselect = ["E", "F"]\n',
            encoding="utf-8",
        )
        diff = ruff_config_diff(
            [_ast("broad_except"), _ast("mutable_default")],
            project_root=tmp_path,
        )
        assert diff["missing"] == {"BLE001", "B006"}
        assert diff["current"] == {"E", "F"}

    def test_ruff_toml_at_root_used(self, tmp_path: Path) -> None:
        (tmp_path / "ruff.toml").write_text(
            'lint = { select = ["BLE001"] }\n',
            encoding="utf-8",
        )
        diff = ruff_config_diff([_ast("broad_except")], project_root=tmp_path)
        assert diff["missing"] == set()
        assert diff["current"] == {"BLE001"}

    def test_no_config_returns_empty_current(self, tmp_path: Path) -> None:
        diff = ruff_config_diff([_ast("broad_except")], project_root=tmp_path)
        assert diff["config_path"] is None
        assert diff["current"] == set()
        assert diff["missing"] == {"BLE001"}
