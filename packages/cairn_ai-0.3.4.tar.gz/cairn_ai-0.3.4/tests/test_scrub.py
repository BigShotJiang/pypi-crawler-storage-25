"""Tests for the secret / PII scrubber."""

from __future__ import annotations

from datetime import datetime, timezone

from cairn.capture.scrub import scrub, scrub_record
from cairn.store.schema import TruthRecord


def _rec(content: str) -> TruthRecord:
    return TruthRecord(
        source="pytest",
        domain="test",
        content=content,
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
    )


class TestScrubPrimitives:
    def test_redacts_password_kv(self) -> None:
        out = scrub("password=hunter2 foo=bar")
        assert "hunter2" not in out
        assert "<redacted:sensitive-key>" in out
        assert "foo=bar" in out

    def test_redacts_api_key_kv(self) -> None:
        out = scrub('api_key: "abc123xyz"')
        assert "abc123xyz" not in out

    def test_redacts_github_token(self) -> None:
        out = scrub("token=ghp_" + "A" * 40)
        assert "ghp_" not in out
        assert "<redacted:" in out

    def test_redacts_openai_key(self) -> None:
        out = scrub("key: sk-" + "a" * 48)
        assert "sk-" not in out or "<redacted" in out

    def test_redacts_anthropic_key(self) -> None:
        out = scrub("auth=sk-ant-" + "x" * 40)
        assert "sk-ant-" not in out

    def test_redacts_aws_access_key(self) -> None:
        out = scrub("AKIAIOSFODNN7EXAMPLE found in logs")
        assert "AKIA" not in out

    def test_redacts_jwt(self) -> None:
        jwt = "eyJhbGciOi" + "A" * 20 + "." + "B" * 20 + "." + "C" * 20
        out = scrub(f"Authorization: Bearer {jwt}")
        assert jwt not in out

    def test_redacts_pem_block(self) -> None:
        pem = (
            "-----BEGIN RSA PRIVATE KEY-----\n"
            "MIIEpAIBAAKCAQEA...\n"
            "-----END RSA PRIVATE KEY-----"
        )
        out = scrub(f"key material: {pem}")
        assert "MIIEpAIBAAKCAQEA" not in out

    def test_masks_email(self) -> None:
        out = scrub("user foo.bar@example.com failed auth")
        assert "foo.bar" not in out
        assert "example.com" in out

    def test_redacts_ipv4(self) -> None:
        out = scrub("connection from 192.168.1.42 refused")
        assert "192.168.1.42" not in out

    def test_idempotent(self) -> None:
        once = scrub("password=secret")
        twice = scrub(once)
        assert once == twice

    def test_none_and_empty_passthrough(self) -> None:
        assert scrub(None) is None  # type: ignore[arg-type]
        assert scrub("") == ""

    def test_clean_text_unchanged(self) -> None:
        msg = "FAIL test_foo: AssertionError: 42 != 43"
        assert scrub(msg) == msg


class TestScrubRecord:
    def test_mutates_content_and_rehashes_id(self) -> None:
        r1 = _rec("pytest FAIL locals: {'api_key': 'sk-abcd1234'}")
        original_id = r1.id
        scrub_record(r1)
        assert r1.id != original_id
        assert "sk-abcd1234" not in r1.content

    def test_two_records_differ_only_by_secret_collapse(self) -> None:
        r1 = _rec("auth: password=hunter2")
        r2 = _rec("auth: password=correcthorsebattery")
        scrub_record(r1)
        scrub_record(r2)
        assert r1.id == r2.id
        assert r1.content == r2.content

    def test_clean_record_id_unchanged(self) -> None:
        r = _rec("FAIL test_ok: AssertionError")
        original_id = r.id
        scrub_record(r)
        assert r.id == original_id


class TestScrubEnvValues:
    def test_env_value_scrubbed(self, monkeypatch) -> None:
        # Manually refresh the module-level cache after setting the env var.
        monkeypatch.setenv("MY_API_KEY", "literalsecretvalue_1234567890")
        import cairn.capture.scrub as scrub_mod
        monkeypatch.setattr(scrub_mod, "_ENV_SECRETS", scrub_mod._env_secrets())
        out = scrub_mod.scrub("oops: literalsecretvalue_1234567890 leaked")
        assert "literalsecretvalue_1234567890" not in out
