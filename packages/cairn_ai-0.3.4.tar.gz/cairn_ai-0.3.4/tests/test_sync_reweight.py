"""Tests for `cairn sync` reweighting + tagging behaviour."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from click.testing import CliRunner

from cairn.cli import main
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer, get_all


def _r(content: str, conf: float = 1.0) -> TruthRecord:
    return TruthRecord(
        source="pytest",
        domain="t",
        content=content,
        confidence=conf,
        occurred_at=datetime.now(tz=timezone.utc),
    )


def test_sync_tags_pattern_cluster(tmp_path: Path) -> None:
    src = tmp_path / "src.db"
    dst = tmp_path / "dst.db"
    with Writer(src) as w:
        w.write(_r("PASS foo"))
    runner = CliRunner()
    result = runner.invoke(
        main, ["sync", str(src), "--db", str(dst), "--source-tag", "commons"],
    )
    assert result.exit_code == 0, result.output
    assert get_all(dst)[0].pattern_cluster == "commons"


def test_sync_reweight_preserves_stored_confidence(tmp_path: Path) -> None:
    """Reweight updates contributor_count; stored confidence stays at MAX."""
    src = tmp_path / "src.db"
    dst = tmp_path / "dst.db"
    rec = _r("PASS foo", conf=1.0)
    with Writer(src) as w:
        w.write(rec)
    with Writer(dst) as w:
        w.write(rec)
    runner = CliRunner()
    result = runner.invoke(main, ["sync", str(src), "--db", str(dst)])
    assert result.exit_code == 0
    stored = get_all(dst)[0]
    assert stored.confidence == 1.0
    assert stored.contributor_count == 2
    assert "1 already present" in result.output


def test_decay_downweights_multi_contributor_records(tmp_path: Path) -> None:
    """At read time, broadly-reported patterns are dampened.

    Uses the logarithmic dampener 1/(1+log2(contrib)): contributor_count=1
    is a no-op, larger counts rank below project-specific records but
    stay above min_confidence=0.05 well past contrib=100 so commons data
    doesn't silently disappear from build_context."""
    from cairn.distill.decay import decayed_confidence
    from datetime import datetime, timezone

    now = datetime.now(tz=timezone.utc)
    local = _r("FAIL local", conf=1.0)
    local.occurred_at = now
    common = _r("FAIL common", conf=1.0)
    common.occurred_at = now
    common.contributor_count = 5

    # Direct captures unchanged
    assert decayed_confidence(local, as_of=now) == 1.0
    # Multi-contributor downweighted but well above 0.05 pruning threshold
    eff = decayed_confidence(common, as_of=now)
    assert eff < 1.0
    assert eff > 0.05, f"contributor_count=5 dropped below pruning threshold: {eff}"

    # Even extreme contributor counts stay above the threshold
    common.contributor_count = 100
    assert decayed_confidence(common, as_of=now) > 0.05


def test_sync_reweight_increments_contributor_count(tmp_path: Path) -> None:
    """Each sync with --reweight increments contributor_count on duplicates."""
    src_a = tmp_path / "a.db"
    src_b = tmp_path / "b.db"
    dst = tmp_path / "dst.db"
    rec = _r("FAIL shared_pattern", conf=1.0)
    for src in (src_a, src_b):
        with Writer(src) as w:
            w.write(rec)
    runner = CliRunner()
    # Seed dst from a
    r1 = runner.invoke(main, ["sync", str(src_a), "--db", str(dst)])
    assert r1.exit_code == 0
    assert get_all(dst)[0].contributor_count == 1
    # Second project reports same pattern
    r2 = runner.invoke(main, ["sync", str(src_b), "--db", str(dst)])
    assert r2.exit_code == 0
    stored = get_all(dst)[0]
    assert stored.contributor_count == 2
    # Writer keeps MAX stored confidence, but the incoming was halved
    # by reweight. First sync carried 1.0; stored is still 1.0.
    assert stored.confidence == 1.0


def test_sync_no_reweight_flag_preserves_incoming(tmp_path: Path) -> None:
    src = tmp_path / "src.db"
    dst = tmp_path / "dst.db"
    with Writer(src) as w:
        w.write(_r("PASS bar", conf=1.0))
    runner = CliRunner()
    result = runner.invoke(
        main, ["sync", str(src), "--db", str(dst), "--no-reweight"],
    )
    assert result.exit_code == 0
    assert "reweight=off" in result.output
