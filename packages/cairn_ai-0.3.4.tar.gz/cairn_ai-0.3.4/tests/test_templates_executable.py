"""Templates feedback-loop validation.

`cairn templates` writes pytest-collectable stubs into
tests/cairn_generated/. Until v0.3.1, nothing actually verified that the
generated source compiles or runs — exactly the orphan-output problem
the audit flagged. These tests close the loop:

  - Generated stubs MUST be syntactically valid Python (compile cleanly)
  - When pytest is invoked against a generated stub it must collect, not
    error out at import time
  - At least one stub must produce a runnable test scaffold (CALL records
    → @pytest.mark.skip("TODO") body or actual import)
"""

from __future__ import annotations

import ast
import subprocess
import sys
import textwrap
from datetime import datetime, timezone
from pathlib import Path

import pytest

from cairn.distill.templates import generate_stubs
from cairn.store.schema import TruthRecord


def _monitor(content: str, source_file: str = "/tmp/proj/example.py") -> TruthRecord:
    return TruthRecord(
        source="monitor",
        domain="t",
        content=content,
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
        source_file=source_file,
    )


@pytest.fixture
def call_return_records() -> list[TruthRecord]:
    """A realistic set of CALL+RETURN records for one function."""
    return [
        _monitor("CALL example.parse_value"),
        _monitor("RETURN example.parse_value → 42"),
        _monitor("CALL example.parse_value"),
        _monitor("RETURN example.parse_value → 100"),
    ]


class TestGeneratedStubsAreValidPython:
    def test_compiles(self, call_return_records: list[TruthRecord]) -> None:
        stubs = generate_stubs(call_return_records)
        assert stubs, "generate_stubs produced no output for valid CALL/RETURN records"
        for stem, source in stubs.items():
            try:
                ast.parse(source)
            except SyntaxError as e:
                pytest.fail(
                    f"Stub for {stem!r} is not valid Python:\n{source}\n"
                    f"SyntaxError: {e}"
                )

    def test_pytest_collects_without_import_error(
        self,
        tmp_path: Path,
        call_return_records: list[TruthRecord],
    ) -> None:
        """Write the stubs to disk and run `pytest --collect-only`. If the
        stubs reference modules that don't exist we expect a collection
        warning, not a hard import error / syntax error."""
        stubs = generate_stubs(call_return_records)
        target_dir = tmp_path / "tests"
        target_dir.mkdir()
        # Avoid auto-loading the cairn pytest plugin in the subprocess —
        # it tries to write to .cairn/store.db and complicates the result.
        for stem, source in stubs.items():
            (target_dir / f"test_{stem}_cairn.py").write_text(source, encoding="utf-8")

        result = subprocess.run(
            [sys.executable, "-m", "pytest", "--collect-only",
             "-p", "no:cacheprovider", "-q", str(target_dir)],
            capture_output=True, text=True, timeout=30,
            env={"PYTHONDONTWRITEBYTECODE": "1", "PATH": ""},
        )
        # collection may report errors for missing modules — but a clean
        # parse + pytest invocation must not produce a SyntaxError or
        # InternalError.
        out = result.stdout + result.stderr
        assert "SyntaxError" not in out, out
        assert "INTERNALERROR" not in out, out


class TestStubMatchesObservation:
    def test_function_name_appears_in_stub(
        self, call_return_records: list[TruthRecord],
    ) -> None:
        stubs = generate_stubs(call_return_records)
        body = next(iter(stubs.values()))
        assert "parse_value" in body, body

    def test_call_count_documented(
        self, call_return_records: list[TruthRecord],
    ) -> None:
        stubs = generate_stubs(call_return_records)
        body = next(iter(stubs.values()))
        assert "2" in body or "calls" in body.lower(), body


class TestEmptyOrIrrelevantInputs:
    def test_empty_records_produce_empty_dict(self) -> None:
        assert generate_stubs([]) == {}

    def test_only_pytest_records_produces_empty_dict(self) -> None:
        rec = TruthRecord(
            source="pytest",
            domain="t",
            content="FAIL test_x",
            confidence=1.0,
            occurred_at=datetime.now(tz=timezone.utc),
        )
        assert generate_stubs([rec]) == {}
