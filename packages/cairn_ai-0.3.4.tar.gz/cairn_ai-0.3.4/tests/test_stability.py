"""Tests for the success-signal module."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from cairn.distill.stability import (
    module_stability,
    rollback_candidates,
    success_summary,
)
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer


def _r(
    content: str,
    at: datetime,
    source: str = "pytest",
    source_file: str | None = "src/app/core.py",
) -> TruthRecord:
    return TruthRecord(
        source=source,
        domain="test",
        content=content,
        confidence=1.0,
        occurred_at=at,
        source_file=source_file,
    )


class TestModuleStability:
    def test_groups_passes_by_module(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(_r("PASS tests/test_a.py::x", now, source_file="src/app/a.py"))
            w.write(_r("PASS tests/test_a.py::y", now, source_file="src/app/a.py"))
            w.write(_r("FAIL tests/test_b.py::z", now, source_file="src/app/b.py"))
        mods = module_stability(db)
        by_mod = {m.module: m for m in mods}
        assert by_mod["src/app"].pass_count == 2
        assert by_mod["src/app"].fail_count == 1

    def test_sorts_by_pass_rate_then_streak(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(_r("PASS a", now, source_file="src/stable/x.py"))
            w.write(_r("PASS b", now, source_file="src/stable/x.py"))
            w.write(_r("PASS c", now, source_file="src/flaky/y.py"))
            w.write(_r("FAIL d", now, source_file="src/flaky/y.py"))
        mods = module_stability(db)
        assert mods[0].module == "src/stable"
        assert mods[1].module == "src/flaky"

    def test_streak_days_after_recovery(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(_r("FAIL old", now - timedelta(days=5), source_file="src/x/y.py"))
            w.write(_r("PASS new", now, source_file="src/x/y.py"))
        mods = module_stability(db)
        assert abs(mods[0].streak_days - 5) < 0.1


class TestRollbackCandidates:
    def test_flags_commit_followed_by_failure_spike(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        commit_time = now - timedelta(days=5)
        with Writer(db) as w:
            w.write(_r(
                "abc1234 Refactor config parser",
                commit_time,
                source="git",
                source_file=None,
            ))
            # Zero failures before, four after
            for i in range(4):
                w.write(_r(
                    f"FAIL test_cfg_{i}",
                    commit_time + timedelta(days=i + 1),
                    source_file=f"src/cfg/m{i}.py",
                ))
        cands = rollback_candidates(db, window_days=14, min_delta=2)
        assert len(cands) == 1
        assert cands[0].commit_sha == "abc1234"
        assert cands[0].delta == 4

    def test_skips_commits_without_spike(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(_r(
                "fedc987 Unrelated tweak",
                now - timedelta(days=3),
                source="git",
                source_file=None,
            ))
            w.write(_r(
                "FAIL test_x",
                now - timedelta(days=1),
                source_file="src/x.py",
            ))
        assert rollback_candidates(db, window_days=14, min_delta=2) == []


class TestPytestNodeidHandling:
    def test_strips_pytest_nodeid_suffix(self, tmp_path: Path) -> None:
        """source_file can carry a full pytest nodeid (path::test[params])
        from commons stores — the module key must drop the suffix so every
        parametrized case doesn't become its own module."""
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(_r(
                "PASS tests/test_utils.py::test_thing[a]",
                now,
                source_file="tests/test_utils.py::test_thing[a]",
            ))
            w.write(_r(
                "PASS tests/test_utils.py::test_thing[b]",
                now,
                source_file="tests/test_utils.py::test_thing[b]",
            ))
        mods = module_stability(db)
        assert len(mods) == 1
        assert mods[0].module == "tests"
        assert mods[0].pass_count == 2

    def test_drops_modules_with_no_pass_or_fail(self, tmp_path: Path) -> None:
        """Non-pytest records with a source_file must not create empty
        module entries."""
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(TruthRecord(
                source="ast", domain="t",
                content="broad_except: foo", confidence=1.0,
                occurred_at=now, source_file="src/pkg/foo.py",
            ))
        assert module_stability(db) == []


class TestSuccessSummary:
    def test_empty_store_returns_empty_string(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        assert success_summary(db) == ""

    def test_markdown_lists_stable_modules(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        with Writer(db) as w:
            w.write(_r("PASS a", now, source_file="src/ok/x.py"))
            w.write(_r("PASS b", now, source_file="src/ok/x.py"))
        out = success_summary(db)
        assert "Stable modules" in out
        assert "src/ok" in out
