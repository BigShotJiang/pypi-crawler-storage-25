"""v0.3.3 audit follow-ups.

  - rollback_candidates reads what link_commits writes (round-trip)
  - apply_ruff_patch handles multi-line select arrays + standalone ruff.toml
  - commons smoke: each shipped *.db opens and every consumer produces
    a sensible (non-crashing) result
"""

from __future__ import annotations

import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from cairn.capture.git_linker import link_commits
from cairn.distill.rules import apply_ruff_patch, ruff_config_diff
from cairn.distill.stability import _parse_git_record, rollback_candidates
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer, get_all


# ---------------------------------------------------------------------------
# rollback_candidates round-trip with real git-linker output
# ---------------------------------------------------------------------------


class TestGitRecordRoundTrip:
    def test_parses_GIT_sha_format(self) -> None:
        r = TruthRecord(
            source="git", domain="t",
            content="GIT abc1234def5 Refactor parser\nchanged 3 .py file(s)",
            confidence=0.5,
            occurred_at=datetime.now(tz=timezone.utc),
        )
        sha, subject = _parse_git_record(r)
        assert sha == "abc1234def5"
        assert subject == "Refactor parser"

    def test_parses_commit_prefix(self) -> None:
        r = TruthRecord(
            source="git", domain="t",
            content="commit abc1234: Refactor",
            confidence=0.5,
            occurred_at=datetime.now(tz=timezone.utc),
        )
        assert _parse_git_record(r) == ("abc1234", "Refactor")

    def test_parses_bare_sha(self) -> None:
        r = TruthRecord(
            source="git", domain="t",
            content="abc1234 Refactor",
            confidence=0.5,
            occurred_at=datetime.now(tz=timezone.utc),
        )
        assert _parse_git_record(r) == ("abc1234", "Refactor")

    def test_rollback_candidates_reads_linker_output(self, tmp_path: Path) -> None:
        """Produce git records with the real link_commits writer, then
        assert rollback_candidates finds the spike. This is the smoke test
        the audit flagged as missing."""
        repo = tmp_path / "repo"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=repo, capture_output=True)
        subprocess.run(["git", "config", "user.email", "t@t.com"],
                       cwd=repo, capture_output=True)
        subprocess.run(["git", "config", "user.name", "T"],
                       cwd=repo, capture_output=True)
        (repo / "seed.txt").write_text("seed\n")
        subprocess.run(["git", "add", "."], cwd=repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "seed"],
                       cwd=repo, capture_output=True)
        (repo / "a.py").write_text("x = 1\n")
        subprocess.run(["git", "add", "."], cwd=repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Add feature X"],
                       cwd=repo, capture_output=True)

        git_records = link_commits(repo, since="HEAD~1")
        assert git_records, "link_commits must produce at least one record"

        # Seed a store with the git record + synthetic failures right after it
        db = tmp_path / "store.db"
        now = datetime.now(tz=timezone.utc)
        # Link records carry the commit's authored_at; normalise to "5m ago"
        for gr in git_records:
            gr.occurred_at = now - timedelta(minutes=5)
        fails = [
            TruthRecord(
                source="pytest", domain="t",
                content=f"FAIL test_{i}",
                confidence=1.0,
                occurred_at=now - timedelta(minutes=4 - i),
                source_file=f"src/m{i}.py",
            )
            for i in range(4)
        ]
        with Writer(db) as w:
            w.write_many([*git_records, *fails])

        cands = rollback_candidates(db, window_days=1, min_delta=2)
        assert cands, "rollback_candidates must find the commit → spike correlation"
        # Should recover the subject we committed
        assert any("Add feature X" in c.commit_subject for c in cands)


# ---------------------------------------------------------------------------
# apply_ruff_patch: multi-line select + standalone ruff.toml
# ---------------------------------------------------------------------------


class TestMultilineRuffConfig:
    def test_patch_updates_multiline_select_array(self, tmp_path: Path) -> None:
        pp = tmp_path / "pyproject.toml"
        pp.write_text(
            '[tool.ruff.lint]\nselect = [\n    "E",\n    "F",\n]\n',
            encoding="utf-8",
        )
        path, changed = apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        assert path == pp and changed
        out = pp.read_text()
        for code in ("E", "F", "BLE001"):
            assert f'"{code}"' in out, out

    def test_ruff_config_diff_reads_multiline_select(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[tool.ruff.lint]\nselect = [\n  "E",\n  "F",\n]\n',
            encoding="utf-8",
        )
        diff = ruff_config_diff(
            [TruthRecord(
                source="ast", domain="t",
                content="broad_except: x",
                confidence=1.0,
                occurred_at=datetime.now(tz=timezone.utc),
                source_file="src/x.py",
            )],
            project_root=tmp_path,
        )
        assert diff["current"] == {"E", "F"}
        assert diff["missing"] == {"BLE001"}

    def test_standalone_ruff_toml_top_level_select(self, tmp_path: Path) -> None:
        """ruff.toml without a [lint] section — older ruff layout."""
        cfg = tmp_path / "ruff.toml"
        cfg.write_text('select = ["E"]\n', encoding="utf-8")
        path, changed = apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        assert path == cfg and changed
        out = cfg.read_text()
        assert '"E"' in out and '"BLE001"' in out

    def test_refuses_when_select_contains_comment(self, tmp_path: Path) -> None:
        """If the existing select array has a `#` comment, patching would
        silently drop it — refuse instead."""
        from cairn.distill.rules import RuffPatchRefused
        (tmp_path / "pyproject.toml").write_text(
            '[tool.ruff.lint]\nselect = [\n    "E",\n    # "F",  # kept off\n]\n',
            encoding="utf-8",
        )
        with pytest.raises(RuffPatchRefused):
            apply_ruff_patch({"BLE001"}, project_root=tmp_path)

    def test_extend_select_left_alone(self, tmp_path: Path) -> None:
        """extend-select is a distinct assignment; apply_ruff_patch edits
        `select` only and must leave extend-select untouched."""
        pp = tmp_path / "pyproject.toml"
        pp.write_text(
            '[tool.ruff.lint]\nselect = ["E"]\nextend-select = ["B"]\n',
            encoding="utf-8",
        )
        apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        out = pp.read_text()
        assert 'extend-select = ["B"]' in out
        assert "BLE001" in out


# ---------------------------------------------------------------------------
# Commons smoke — each shipped commons_*.db must survive every consumer
# ---------------------------------------------------------------------------


_REPO_ROOT = Path(__file__).resolve().parent.parent
_COMMONS_DBS = sorted(_REPO_ROOT.glob("commons_*.db"))


@pytest.mark.skipif(not _COMMONS_DBS, reason="no commons_*.db in repo")
@pytest.mark.parametrize("db_path", _COMMONS_DBS, ids=lambda p: p.name)
class TestCommonsSmoke:
    def test_loads_without_error(self, db_path: Path) -> None:
        from cairn.store.writer import count
        totals = count(db_path)
        assert totals, f"{db_path.name} produced no source breakdown"

    def test_get_all_returns_records(self, db_path: Path) -> None:
        records = get_all(db_path)
        assert records, f"{db_path.name} returned 0 records"

    def test_apply_decay_doesnt_crash(self, db_path: Path) -> None:
        from cairn.distill.decay import apply_decay
        records = get_all(db_path)
        live = apply_decay(records)
        assert isinstance(live, list)

    def test_cluster_produces_labelled_buckets(self, db_path: Path) -> None:
        from cairn.distill.cluster import cluster
        records = get_all(db_path)[:500]  # cap for test speed
        buckets = cluster(records)
        assert buckets
        singletons = 0
        for key, members in buckets.items():
            assert key and isinstance(key, str)
            # No empty-key (the regex-extraction bug would produce these)
            assert key.strip()
            # No cluster key that is JUST the default fallback name for a
            # non-cluster shape
            assert key not in ("other::other", "<unknown>")
            if len(members) == 1:
                singletons += 1
        # Guardrail: more than 90% singleton clusters means the grouping
        # isn't actually grouping — that's the v0.3.2-style regression we
        # want CI to catch. Only enforce on stores big enough for the
        # ratio to be meaningful.
        if len(records) >= 200:
            ratio = singletons / len(buckets)
            assert ratio < 0.9, (
                f"{db_path.name}: {singletons}/{len(buckets)} singleton "
                f"clusters ({ratio:.0%}) — clustering is ineffective"
            )

    def test_module_stability_runs(self, db_path: Path) -> None:
        from cairn.distill.stability import module_stability
        # Should never crash on real data even if no pytest records exist.
        mods = module_stability(db_path)
        assert isinstance(mods, list)

    def test_build_context_produces_content_for_nonempty_store(
        self, db_path: Path,
    ) -> None:
        from cairn.inject.context import build_context
        from cairn.distill.decay import apply_decay
        ctx = build_context(top_n=5, db_path=db_path, max_tokens=1000)
        assert isinstance(ctx, str)
        # If any records survive decay, context must not be empty —
        # a regression that silently drops everything (e.g. the v0.3.3
        # contributor_count/min_confidence interaction) would fail here.
        live = apply_decay(get_all(db_path))
        if live:
            assert ctx.strip(), (
                f"{db_path.name}: {len(live)} live records but "
                f"build_context returned empty"
            )
            assert "Cairn context" in ctx
