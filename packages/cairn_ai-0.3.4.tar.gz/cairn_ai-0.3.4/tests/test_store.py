"""Tests for TruthRecord schema and SQLite writer."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from cairn.store.schema import (
    KNOWN_LANGUAGES,
    TruthRecord,
    normalize_domain,
    record_to_row,
    row_to_record,
)
from cairn.store.query import by_domain, from_dbs
from cairn.store.writer import Writer, count, get_all


def make_record(**kwargs) -> TruthRecord:
    defaults = dict(
        source="pytest",
        domain="test_project",
        content="FAIL tests/test_foo.py::test_bar\nexception: AssertionError",
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
    )
    defaults.update(kwargs)
    return TruthRecord(**defaults)


class TestTruthRecord:
    def test_id_is_stable(self):
        """Same source/domain/content always produces the same id."""
        r1 = make_record()
        r2 = make_record()
        assert r1.id == r2.id

    def test_id_differs_by_content(self):
        r1 = make_record(content="FAIL a")
        r2 = make_record(content="FAIL b")
        assert r1.id != r2.id

    def test_serialization_roundtrip(self):
        r = make_record(source_file="/some/file.py", source_line=42, exception_type="KeyError")
        row = record_to_row(r)
        r2 = row_to_record(row)
        assert r2.id == r.id
        assert r2.source_file == r.source_file
        assert r2.source_line == r.source_line
        assert r2.exception_type == r.exception_type


class TestWriter:
    def test_write_and_retrieve(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        r = make_record()
        with Writer(db) as w:
            w.write(r)
        records = get_all(db)
        assert len(records) == 1
        assert records[0].id == r.id

    def test_upsert_is_idempotent(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        r = make_record()
        with Writer(db) as w:
            w.write(r)
            w.write(r)  # second write should not duplicate
        records = get_all(db)
        assert len(records) == 1

    def test_upsert_updates_confidence(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        r = make_record(confidence=0.9)
        with Writer(db) as w:
            w.write(r)
        r2 = make_record(confidence=0.5)  # same id, lower confidence
        with Writer(db) as w:
            w.write(r2)
        records = get_all(db)
        assert len(records) == 1
        # Re-observation takes MAX(stored, new); the lower incoming value
        # must not downgrade the stored confidence.
        assert records[0].confidence == pytest.approx(0.9)
        assert records[0].observation_count == 2

    def test_upsert_updates_pattern_cluster(self, tmp_path):
        """On conflict, pattern_cluster should be updated to the incoming non-null value."""
        db = tmp_path / ".cairn" / "store.db"
        r = make_record(confidence=0.5)
        r.pattern_cluster = None
        with Writer(db) as w:
            w.write(r)
        r2 = make_record(confidence=0.5)
        r2.pattern_cluster = "error_handling"
        with Writer(db) as w:
            w.write(r2)
        records = get_all(db)
        assert len(records) == 1
        assert records[0].pattern_cluster == "error_handling"

    def test_upsert_preserves_pattern_cluster_when_incoming_is_null(self, tmp_path):
        """If incoming pattern_cluster is None, the stored value is kept."""
        db = tmp_path / ".cairn" / "store.db"
        r = make_record(confidence=0.5)
        r.pattern_cluster = "existing_cluster"
        with Writer(db) as w:
            w.write(r)
        r2 = make_record(confidence=0.5)
        r2.pattern_cluster = None
        with Writer(db) as w:
            w.write(r2)
        records = get_all(db)
        assert records[0].pattern_cluster == "existing_cluster"

    def test_write_many(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [make_record(content=f"FAIL test_{i}") for i in range(5)]
        with Writer(db) as w:
            w.write_many(records)
        assert len(get_all(db)) == 5

    def test_count_by_source(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        records = [
            make_record(source="pytest", content="FAIL a"),
            make_record(source="pytest", content="FAIL b"),
            make_record(source="ast", content="WARNING c"),
        ]
        with Writer(db) as w:
            w.write_many(records)
        totals = count(db)
        assert totals["pytest"] == 2
        assert totals["ast"] == 1


# ---------------------------------------------------------------------------
# Domain field — normalize_domain + TruthRecord.language
# ---------------------------------------------------------------------------

class TestNormalizeDomain:
    """normalize_domain is lenient: it never raises; legacy domains pass through."""

    def test_canonical_form_is_unchanged(self):
        assert normalize_domain("python/stdlib") == "python/stdlib"

    def test_uppercased_language_is_lowercased(self):
        assert normalize_domain("Python/stdlib") == "python/stdlib"
        assert normalize_domain("RUST/tokio") == "rust/tokio"

    def test_no_slash_known_language(self):
        assert normalize_domain("python") == "python"
        assert normalize_domain("rust") == "rust"

    def test_no_slash_known_language_uppercased(self):
        assert normalize_domain("Go") == "go"

    def test_legacy_domain_no_slash_unknown(self):
        # "test_project" has no slash and is not in KNOWN_LANGUAGES; returned as-is
        assert normalize_domain("test_project") == "test_project"

    def test_empty_string(self):
        assert normalize_domain("") == ""

    def test_strips_whitespace(self):
        assert normalize_domain("  python/stdlib  ") == "python/stdlib"

    def test_scope_case_is_preserved(self):
        # Only the language prefix is lowercased; scope is untouched
        assert normalize_domain("Python/Acme.Billing") == "python/Acme.Billing"

    def test_known_languages_set_contains_25_plus(self):
        assert len(KNOWN_LANGUAGES) >= 25

    def test_commons_is_a_known_language(self):
        assert "commons" in KNOWN_LANGUAGES
        assert normalize_domain("commons") == "commons"

    def test_new_language_without_slash(self):
        assert normalize_domain("zig") == "zig"

    def test_new_language_with_scope(self):
        assert normalize_domain("Zig/project") == "zig/project"


class TestTruthRecordLanguageProperty:
    """TruthRecord.language extracts the language prefix from domain."""

    def test_slash_domain_returns_language(self):
        r = make_record(domain="python/acme.billing")
        assert r.language == "python"

    def test_slash_domain_uppercased_language(self):
        r = make_record(domain="Python/stdlib")
        assert r.language == "python"

    def test_no_slash_known_language(self):
        r = make_record(domain="rust")
        assert r.language == "rust"

    def test_no_slash_unknown_legacy(self):
        r = make_record(domain="test_project")
        assert r.language is None

    def test_empty_domain(self):
        r = make_record(domain="")
        assert r.language is None

    def test_commons_domain(self):
        r = make_record(domain="commons")
        assert r.language == "commons"


# ---------------------------------------------------------------------------
# Domain query — by_domain + from_dbs
# ---------------------------------------------------------------------------

def _write_records(db, records):
    with Writer(db) as w:
        w.write_many(records)


class TestByDomain:
    def test_exact_match(self, tmp_path):
        db = tmp_path / "store.db"
        r = make_record(domain="python", content="exact match")
        _write_records(db, [r])
        results = by_domain("python", db)
        assert len(results) == 1
        assert results[0].domain == "python"

    def test_prefix_match(self, tmp_path):
        db = tmp_path / "store.db"
        recs = [
            make_record(domain="python/stdlib", content="stdlib fact"),
            make_record(domain="python/acme.billing", content="billing fact"),
            make_record(domain="rust/tokio", content="rust fact"),
        ]
        _write_records(db, recs)
        results = by_domain("python", db)
        assert len(results) == 2
        domains = {r.domain for r in results}
        assert "python/stdlib" in domains
        assert "python/acme.billing" in domains
        assert "rust/tokio" not in domains

    def test_prefix_with_trailing_slash(self, tmp_path):
        db = tmp_path / "store.db"
        recs = [
            make_record(domain="python", content="bare language"),
            make_record(domain="python/stdlib", content="scoped"),
        ]
        _write_records(db, recs)
        # "python/" prefix only matches children, not "python" itself
        results = by_domain("python/", db)
        assert len(results) == 1
        assert results[0].domain == "python/stdlib"

    def test_missing_db_returns_empty(self, tmp_path):
        results = by_domain("python", tmp_path / "nonexistent.db")
        assert results == []

    def test_no_cross_language_bleed(self, tmp_path):
        db = tmp_path / "store.db"
        recs = [
            make_record(domain="python/core", content="py fact"),
            make_record(domain="rust/core", content="rs fact"),
            make_record(domain="go/net", content="go fact"),
        ]
        _write_records(db, recs)
        py = by_domain("python", db)
        rs = by_domain("rust", db)
        assert all(r.domain.startswith("python") for r in py)
        assert all(r.domain.startswith("rust") for r in rs)


class TestFromDbs:
    def test_unions_across_two_dbs(self, tmp_path):
        db1 = tmp_path / "commons.db"
        db2 = tmp_path / "project.db"
        commons_rec = make_record(domain="python/stdlib", content="stdlib pattern", confidence=0.6)
        project_rec = make_record(domain="python/myapp", content="myapp pattern", confidence=0.9)
        _write_records(db1, [commons_rec])
        _write_records(db2, [project_rec])

        results = from_dbs([db1, db2])
        assert len(results) == 2
        assert results[0].domain == "python/myapp"  # highest confidence first

    def test_deduplicates_by_id(self, tmp_path):
        """Same record in two DBs → only the higher-confidence copy kept."""
        db1 = tmp_path / "commons.db"
        db2 = tmp_path / "org.db"
        r_low = make_record(domain="python/stdlib", content="shared fact", confidence=0.5)
        r_high = make_record(domain="python/stdlib", content="shared fact", confidence=0.9)
        _write_records(db1, [r_low])
        _write_records(db2, [r_high])

        results = from_dbs([db1, db2])
        assert len(results) == 1
        assert results[0].confidence == pytest.approx(0.9)

    def test_domain_prefix_filter(self, tmp_path):
        db = tmp_path / "store.db"
        recs = [
            make_record(domain="python/stdlib", content="py fact"),
            make_record(domain="rust/tokio", content="rs fact"),
        ]
        _write_records(db, recs)
        results = from_dbs([db], domain_prefix="python")
        assert len(results) == 1
        assert results[0].domain == "python/stdlib"

    def test_min_confidence_filter(self, tmp_path):
        db = tmp_path / "store.db"
        recs = [
            make_record(domain="python/a", content="high", confidence=0.8),
            make_record(domain="python/b", content="low", confidence=0.1),
        ]
        _write_records(db, recs)
        results = from_dbs([db], min_confidence=0.5)
        assert len(results) == 1
        assert results[0].confidence == pytest.approx(0.8)

    def test_top_k(self, tmp_path):
        db = tmp_path / "store.db"
        recs = [make_record(domain="python/" + str(i), content=f"fact {i}") for i in range(10)]
        _write_records(db, recs)
        results = from_dbs([db], top_k=3)
        assert len(results) == 3

    def test_missing_db_silently_skipped(self, tmp_path):
        real_db = tmp_path / "real.db"
        ghost_db = tmp_path / "ghost.db"
        _write_records(real_db, [make_record(domain="python/x", content="real")])
        results = from_dbs([ghost_db, real_db])
        assert len(results) == 1

    def test_three_tier_federation(self, tmp_path):
        """commons → org → project: same-id record keeps highest-confidence copy."""
        commons = tmp_path / "commons.db"
        org = tmp_path / "org.db"
        project = tmp_path / "project.db"

        shared_content = "shared pattern"
        r_commons = make_record(domain="python/stdlib", content=shared_content, confidence=0.4)
        r_org     = make_record(domain="python/stdlib", content=shared_content, confidence=0.7)
        r_project = make_record(domain="python/stdlib", content=shared_content, confidence=0.95)

        unique_commons  = make_record(domain="python/stdlib", content="commons only", confidence=0.3)
        unique_project  = make_record(domain="python/myapp",  content="project only", confidence=0.99)

        _write_records(commons, [r_commons, unique_commons])
        _write_records(org,     [r_org])
        _write_records(project, [r_project, unique_project])

        results = from_dbs([commons, org, project], domain_prefix="python")
        # 3 distinct content strings → 3 records
        assert len(results) == 3
        confidences = sorted([r.confidence for r in results], reverse=True)
        assert confidences[0] == pytest.approx(0.99)   # project_only
        assert confidences[1] == pytest.approx(0.95)   # shared (project tier wins)
        assert confidences[2] == pytest.approx(0.30)   # commons_only
