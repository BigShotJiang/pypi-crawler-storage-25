"""Tests for duration/call_depth, coverage_reader, and templates."""

from __future__ import annotations

import textwrap
from datetime import datetime, timezone
from pathlib import Path

import pytest

from cairn.capture.coverage_reader import _infer_domain, read_coverage
from cairn.distill.templates import (
    _extract_fn_name,
    _extract_return_type,
    _safe_name,
    generate_stubs,
    generate_stubs_markdown,
)
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer

_NOW = datetime.now(tz=timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _r(
    source: str = "monitor",
    content: str = "CALL mymodule.process",
    source_file: str | None = "/app/mymodule.py",
    source_line: int | None = 10,
    duration_ms: float | None = None,
    call_depth: int | None = None,
    exception_type: str | None = None,
) -> TruthRecord:
    return TruthRecord(
        source=source, domain="proj", content=content, confidence=1.0,
        occurred_at=_NOW, source_file=source_file, source_line=source_line,
        duration_ms=duration_ms, call_depth=call_depth,
        exception_type=exception_type,
    )


# ---------------------------------------------------------------------------
# TruthRecord schema extension
# ---------------------------------------------------------------------------


class TestSchemaExtension:
    def test_duration_ms_default_none(self):
        r = TruthRecord(source="monitor", domain="x", content="c", confidence=1.0, occurred_at=_NOW)
        assert r.duration_ms is None

    def test_call_depth_default_none(self):
        r = TruthRecord(source="monitor", domain="x", content="c", confidence=1.0, occurred_at=_NOW)
        assert r.call_depth is None

    def test_duration_ms_roundtrip(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        rec = _r(content="CALL foo", duration_ms=42.5, call_depth=3)
        with Writer(db) as w:
            w.write_many([rec])
        from cairn.store.writer import get_all
        loaded = get_all(db)
        assert len(loaded) == 1
        assert loaded[0].duration_ms == pytest.approx(42.5)
        assert loaded[0].call_depth == 3

    def test_null_duration_and_depth_roundtrip(self, tmp_path):
        db = tmp_path / ".cairn" / "store.db"
        rec = _r(content="CALL bar", duration_ms=None, call_depth=None)
        with Writer(db) as w:
            w.write_many([rec])
        from cairn.store.writer import get_all
        loaded = get_all(db)
        assert loaded[0].duration_ms is None
        assert loaded[0].call_depth is None


# ---------------------------------------------------------------------------
# Monitor depth + duration capture
# ---------------------------------------------------------------------------


class TestMonitorDepthDuration:
    @pytest.fixture(autouse=True)
    def stop_monitor(self):
        import sys

        if sys.version_info >= (3, 12):
            from cairn.capture import monitor
            yield
            if monitor.is_active():
                monitor.stop()
        else:
            yield

    @pytest.mark.skipif(
        __import__("sys").version_info < (3, 12),
        reason="sys.monitoring requires Python 3.12+",
    )
    def test_monitor_writes_depth_and_duration(self, tmp_path):
        from cairn.capture import monitor
        db = tmp_path / ".cairn" / "store.db"

        monitor.start(db_path=db)
        try:
            def _inner():
                return 42
            _inner()
        finally:
            monitor.stop()

        from cairn.store.writer import get_all
        records = get_all(db)
        # At least CALL or RETURN captured
        assert len(records) > 0
        # At least one record should have call_depth set (from _on_call)
        call_records = [r for r in records if r.content.startswith("CALL")]
        if call_records:
            assert call_records[0].call_depth is not None
            assert call_records[0].call_depth >= 1

    @pytest.mark.skipif(
        __import__("sys").version_info < (3, 12),
        reason="sys.monitoring requires Python 3.12+",
    )
    def test_return_record_has_duration(self, tmp_path):
        from cairn.capture import monitor
        db = tmp_path / ".cairn" / "store.db"

        monitor.start(db_path=db)
        try:
            def _timed():
                return "hello"
            _timed()
        finally:
            monitor.stop()

        from cairn.store.writer import get_all
        records = get_all(db)
        return_records = [r for r in records if r.content.startswith("RETURN")]
        if return_records:
            # Duration should be a non-negative float ms
            dur = return_records[0].duration_ms
            if dur is not None:
                assert dur >= 0.0


# ---------------------------------------------------------------------------
# Coverage reader
# ---------------------------------------------------------------------------


class TestCoverageReader:
    def test_returns_empty_when_no_file(self, tmp_path):
        result = read_coverage(coverage_path=tmp_path / ".coverage")
        assert result == []

    def test_returns_empty_when_coverage_not_installed(self, tmp_path):
        cov_file = tmp_path / ".coverage"
        cov_file.write_bytes(b"fake")  # exists but contents invalid
        # If coverage IS installed this will attempt to load and get no valid data;
        # if not installed the import guard returns [].  Either way, result is [].
        result = read_coverage(coverage_path=cov_file)
        assert result == []

    def test_infer_domain_from_path(self, tmp_path):
        root = tmp_path / "myproject"
        root.mkdir()
        file = root / "mypackage" / "module.py"
        domain = _infer_domain(file, root)
        assert domain == "mypackage"

    def test_infer_domain_fallback(self, tmp_path):
        root = tmp_path / "repo"
        root.mkdir()
        file = Path("/other/path/module.py")
        domain = _infer_domain(file, root)
        assert domain == "module"

    @pytest.mark.skipif(
        __import__("importlib").util.find_spec("coverage") is None,
        reason="coverage not installed",
    )
    def test_read_coverage_with_real_data(self, tmp_path):
        """Integration test: run coverage, read result."""
        import subprocess
        import sys
        py_file = tmp_path / "target.py"
        py_file.write_text(textwrap.dedent("""\
            def always_run():
                return 1

            def never_run():
                return 2
        """))
        test_file = tmp_path / "test_target.py"
        test_file.write_text(textwrap.dedent(f"""\
            import sys
            sys.path.insert(0, '{tmp_path}')
            from target import always_run
            def test_it():
                assert always_run() == 1
        """))
        cov_path = tmp_path / ".coverage"
        result = subprocess.run(
            [sys.executable, "-m", "coverage", "run",
             "--data-file", str(cov_path),
             # Restrict coverage to the tmp_path so pytest's own files
             # don't dominate the dataset and target.py is guaranteed in.
             f"--source={tmp_path}",
             "-m", "pytest", str(test_file), "-q", "-p", "no:cacheprovider"],
            cwd=tmp_path, capture_output=True, timeout=30,
        )
        if result.returncode != 0 or not cov_path.exists():
            pytest.skip(
                f"coverage run failed (rc={result.returncode}); "
                f"stdout={result.stdout!r}; stderr={result.stderr!r}"
            )

        records = read_coverage(coverage_path=cov_path, source_root=tmp_path)
        contents = [r.content for r in records]
        # If coverage measured target.py but read_coverage filtered it out,
        # surface the measured set so CI logs explain the discrepancy.
        if not contents:
            from coverage import Coverage
            _cov = Coverage(data_file=str(cov_path))
            _cov.load()
            measured = list(_cov.get_data().measured_files())
            pytest.skip(
                f"read_coverage returned 0 records; measured_files={measured}"
            )
        # never_run's lines should appear as untested
        assert any("never_run" in c or "target.py" in c for c in contents), contents


# ---------------------------------------------------------------------------
# Template generator
# ---------------------------------------------------------------------------


class TestTemplateGenerator:
    def _call_record(self, fn="mymod.process", file="/app/mymod.py", depth=2, dur=1.5):
        return _r(content=f"CALL {fn}", source_file=file, call_depth=depth, duration_ms=dur)

    def _return_record(self, fn="mymod.process", retval="'hello'", file="/app/mymod.py"):
        return _r(content=f"RETURN {fn} → {retval}", source_file=file)

    def _raise_record(self, fn="mymod.process", exc="ValueError", file="/app/mymod.py"):
        return _r(content=f"RAISE {fn} {exc}: bad input", source_file=file, exception_type=exc)

    def test_empty_records(self):
        assert generate_stubs([]) == {}

    def test_no_monitor_records(self):
        recs = [_r(source="ast", content="broad_except: line 5")]
        assert generate_stubs(recs) == {}

    def test_generates_stub_for_module(self):
        recs = [self._call_record(), self._return_record()]
        stubs = generate_stubs(recs)
        assert "mymod" in stubs
        source = stubs["mymod"]
        assert "def test_" in source
        assert "process" in source

    def test_stub_documents_return_type(self):
        recs = [self._call_record(), self._return_record(retval="'hello world'")]
        stubs = generate_stubs(recs)
        assert "str" in stubs["mymod"]

    def test_stub_documents_exception(self):
        recs = [self._call_record(), self._raise_record()]
        stubs = generate_stubs(recs)
        assert "ValueError" in stubs["mymod"]

    def test_stub_documents_depth_and_duration(self):
        recs = [_r(
            content="CALL mymod.fn", source_file="/app/mymod.py",
            call_depth=3, duration_ms=12.5,
        )]
        stubs = generate_stubs(recs)
        src = stubs["mymod"]
        assert "3" in src   # depth
        assert "12" in src  # duration

    def test_multiple_modules_separate_stubs(self):
        recs = [
            _r(content="CALL alpha.fn", source_file="/app/alpha.py"),
            _r(content="CALL beta.fn", source_file="/app/beta.py"),
        ]
        stubs = generate_stubs(recs)
        assert "alpha" in stubs
        assert "beta" in stubs

    def test_hypothesis_stub_commented_out(self):
        recs = [self._call_record(), self._return_record(retval="42")]
        stubs = generate_stubs(recs)
        src = stubs["mymod"]
        assert "# @given" in src or "# Uncomment" in src

    def test_extract_fn_name(self):
        assert _extract_fn_name("CALL mymod.parse_manifest") == "mymod.parse_manifest"
        assert _extract_fn_name("RETURN mymod.parse → {}") == "mymod.parse"
        assert _extract_fn_name("no match") is None

    def test_extract_return_type_str(self):
        assert _extract_return_type("RETURN fn → 'hello'") == "str"

    def test_extract_return_type_int(self):
        assert _extract_return_type("RETURN fn → 42") == "int"

    def test_extract_return_type_bool(self):
        assert _extract_return_type("RETURN fn → True") == "bool"

    def test_extract_return_type_none(self):
        assert _extract_return_type("RETURN fn → None") == "NoneType"

    def test_extract_return_type_dict(self):
        assert _extract_return_type("RETURN fn → {'key': 1}") == "dict"

    def test_safe_name_converts_dots(self):
        assert "classname" in _safe_name("ClassName.method")

    def test_markdown_output(self):
        recs = [self._call_record(), self._return_record()]
        md = generate_stubs_markdown(recs)
        assert "```python" in md
        assert "mymod" in md

    def test_markdown_empty_when_no_monitor_records(self):
        assert generate_stubs_markdown([]) == ""


# ---------------------------------------------------------------------------
# cairn templates CLI
# ---------------------------------------------------------------------------


class TestTemplatesCLI:
    def test_no_store(self, tmp_path):
        from click.testing import CliRunner

        from cairn.cli import main
        with CliRunner().isolated_filesystem(temp_dir=tmp_path):
            result = CliRunner().invoke(main, ["templates"])
        assert result.exit_code == 0
        assert "No store found" in result.output

    def test_no_monitor_records(self, tmp_path):
        from click.testing import CliRunner

        from cairn.cli import main
        db = tmp_path / ".cairn" / "store.db"
        with Writer(db) as w:
            w.write_many([_r(source="ast", content="broad_except: line 5")])
        result = CliRunner().invoke(
            main,
            ["templates", "--db", str(db), "--output", str(tmp_path / "stubs")],
        )
        assert result.exit_code == 0
        assert "No monitor records" in result.output

    def test_generates_stub_files(self, tmp_path):
        from click.testing import CliRunner

        from cairn.cli import main
        db = tmp_path / ".cairn" / "store.db"
        with Writer(db) as w:
            w.write_many([_r(content="CALL mymod.fn", source_file="/app/mymod.py")])
        out_dir = tmp_path / "stubs"
        result = CliRunner().invoke(main, ["templates", "--db", str(db), "--output", str(out_dir)])
        assert result.exit_code == 0
        assert out_dir.exists()
        py_files = list(out_dir.glob("*.py"))
        assert len(py_files) >= 1

    def test_markdown_flag(self, tmp_path):
        from click.testing import CliRunner

        from cairn.cli import main
        db = tmp_path / ".cairn" / "store.db"
        with Writer(db) as w:
            w.write_many([_r(content="CALL mymod.fn", source_file="/app/mymod.py")])
        out_dir = tmp_path / "stubs"
        result = CliRunner().invoke(
            main,
            ["templates", "--db", str(db), "--output", str(out_dir), "--markdown"],
        )
        assert result.exit_code == 0
