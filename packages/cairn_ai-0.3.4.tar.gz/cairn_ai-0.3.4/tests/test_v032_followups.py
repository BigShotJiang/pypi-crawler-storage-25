"""Coverage for v0.3.2 audit follow-ups.

Groups several small but load-bearing tests:

  - policy-exit-halt actually exits 3 when a HALT is produced
  - [tool.ruff] legacy location is read by ruff_config_diff
  - apply_ruff_patch writes + preserves existing codes
  - cairn install --force overwrites, default does not
  - cairn store / pattern / capture groups dispatch to the right
    callbacks (not just --help)
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from cairn.cli import main
from cairn.distill.rules import apply_ruff_patch, ruff_config_diff
from cairn.store.schema import TruthRecord
from cairn.store.writer import Writer


def _ast(check: str) -> TruthRecord:
    return TruthRecord(
        source="ast",
        domain="t",
        content=f"{check}: foo.py:10",
        confidence=1.0,
        occurred_at=datetime.now(tz=timezone.utc),
        source_file="src/foo.py",
    )


# ---------------------------------------------------------------------------
# #10 — legacy [tool.ruff] location (not [tool.ruff.lint])
# ---------------------------------------------------------------------------


class TestLegacyRuffLocation:
    def test_ruff_config_diff_reads_legacy_tool_ruff_select(
        self, tmp_path: Path,
    ) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[tool.ruff]\nselect = ["BLE001"]\n', encoding="utf-8",
        )
        diff = ruff_config_diff(
            [_ast("broad_except"), _ast("mutable_default")],
            project_root=tmp_path,
        )
        assert "BLE001" in diff["current"], diff
        assert diff["missing"] == {"B006"}

    def test_apply_patch_respects_legacy_location(self, tmp_path: Path) -> None:
        pp = tmp_path / "pyproject.toml"
        pp.write_text('[tool.ruff]\nselect = ["E"]\n', encoding="utf-8")
        path, changed = apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        assert path == pp
        assert changed
        out = pp.read_text()
        assert '"E"' in out and '"BLE001"' in out


# ---------------------------------------------------------------------------
# apply_ruff_patch modes
# ---------------------------------------------------------------------------


class TestApplyRuffPatch:
    def test_no_missing_returns_no_change(self, tmp_path: Path) -> None:
        pp = tmp_path / "pyproject.toml"
        pp.write_text('[tool.ruff.lint]\nselect = ["E", "BLE001"]\n', encoding="utf-8")
        path, changed = apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        assert path == pp
        assert changed is False

    def test_no_config_returns_none(self, tmp_path: Path) -> None:
        path, changed = apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        assert path is None
        assert changed is False

    def test_preserves_existing_codes(self, tmp_path: Path) -> None:
        pp = tmp_path / "pyproject.toml"
        pp.write_text(
            '[tool.ruff.lint]\nselect = ["E", "F", "I"]\n', encoding="utf-8",
        )
        apply_ruff_patch({"BLE001", "B006"}, project_root=tmp_path)
        out = pp.read_text()
        for code in ("E", "F", "I", "BLE001", "B006"):
            assert f'"{code}"' in out, out

    def test_standalone_ruff_toml(self, tmp_path: Path) -> None:
        cfg = tmp_path / "ruff.toml"
        cfg.write_text('[lint]\nselect = ["E"]\n', encoding="utf-8")
        path, changed = apply_ruff_patch({"BLE001"}, project_root=tmp_path)
        assert path == cfg and changed
        assert "BLE001" in cfg.read_text()


# ---------------------------------------------------------------------------
# #13 — cairn install --force
# ---------------------------------------------------------------------------


class TestInstallForce:
    def test_default_does_not_overwrite(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.chdir(tmp_path)
        (tmp_path / "CLAUDE.md").write_text("user edits here", encoding="utf-8")
        runner = CliRunner()
        result = runner.invoke(main, ["install", "--targets", "claude"])
        assert result.exit_code == 0
        assert (tmp_path / "CLAUDE.md").read_text() == "user edits here"

    def test_force_overwrites(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.chdir(tmp_path)
        (tmp_path / "CLAUDE.md").write_text("old", encoding="utf-8")
        runner = CliRunner()
        result = runner.invoke(
            main, ["install", "--targets", "claude", "--force"],
        )
        assert result.exit_code == 0
        assert (tmp_path / "CLAUDE.md").read_text() != "old"
        assert "cairn" in (tmp_path / "CLAUDE.md").read_text().lower()


# ---------------------------------------------------------------------------
# #14 — CLI groups dispatch to real callbacks
# ---------------------------------------------------------------------------


class TestGroupDispatch:
    def test_store_status_dispatches(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write(_ast("broad_except"))
        runner = CliRunner()
        result = runner.invoke(main, ["store", "status", "--db", str(db)])
        assert result.exit_code == 0, result.output
        assert "Total records" in result.output

    def test_pattern_stability_dispatches(self, tmp_path: Path) -> None:
        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write(TruthRecord(
                source="pytest", domain="t",
                content="PASS tests/test_x.py::a", confidence=1.0,
                occurred_at=datetime.now(tz=timezone.utc),
                source_file="src/pkg/a.py",
            ))
        runner = CliRunner()
        result = runner.invoke(main, ["pattern", "stability", "--db", str(db)])
        assert result.exit_code == 0, result.output
        assert "src/pkg" in result.output

    def test_capture_scan_dispatches(self, tmp_path: Path) -> None:
        (tmp_path / "a.py").write_text("x = 1\n", encoding="utf-8")
        runner = CliRunner()
        result = runner.invoke(
            main, ["capture", "scan", str(tmp_path), "--db", str(tmp_path / "s.db")],
        )
        assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# #6 — --policy-exit-halt fires on HALT
# ---------------------------------------------------------------------------


class TestPolicyExitHalt:
    def test_exit_3_on_halt(self, tmp_path: Path) -> None:
        """Simulate a HALT escalation by patching evaluate_all + HAS_MARGIN.
        The distill command must exit with status 3 when --policy-exit-halt
        is set and at least one cluster is HALT.
        """
        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write(TruthRecord(
                source="pytest", domain="t",
                content=(
                    'FAIL test_x\nexception: ValueError\n'
                    'traceback:\n  File "a.py", line 1, in fn'
                ),
                confidence=1.0,
                occurred_at=datetime.now(tz=timezone.utc),
                exception_type="ValueError",
                source_file="src/a.py",
            ))

        class _Esc:
            def __init__(self, level: str, reason: str) -> None:
                self.level = level
                self.reason = reason

        with patch("cairn.distill.health.HAS_MARGIN", True), \
             patch("cairn.distill.health.analyze_clusters", return_value={}), \
             patch(
                "cairn.distill.escalation.evaluate_all",
                return_value={"ValueError::fn": _Esc("HALT", "synthetic")},
             ), \
             patch(
                "cairn.distill.causality.build_causal_graph", return_value=None,
             ):
            runner = CliRunner()
            result = runner.invoke(
                main,
                ["distill", "--db", str(db),
                 "--analyze-health", "--policy-exit-halt"],
            )
            assert result.exit_code == 3, result.output
            assert "HALT" in result.output

    def test_no_exit_on_alert(self, tmp_path: Path) -> None:
        """ALERT is not a hard stop; exit must be 0."""
        db = tmp_path / "store.db"
        with Writer(db) as w:
            w.write(TruthRecord(
                source="pytest", domain="t",
                content=(
                    'FAIL test_x\nexception: ValueError\n'
                    'traceback:\n  File "a.py", line 1, in fn'
                ),
                confidence=1.0,
                occurred_at=datetime.now(tz=timezone.utc),
                exception_type="ValueError",
                source_file="src/a.py",
            ))

        class _Esc:
            def __init__(self, level: str, reason: str) -> None:
                self.level = level
                self.reason = reason

        with patch("cairn.distill.health.HAS_MARGIN", True), \
             patch("cairn.distill.health.analyze_clusters", return_value={}), \
             patch(
                "cairn.distill.escalation.evaluate_all",
                return_value={"ValueError::fn": _Esc("ALERT", "synthetic")},
             ), \
             patch(
                "cairn.distill.causality.build_causal_graph", return_value=None,
             ):
            runner = CliRunner()
            result = runner.invoke(
                main,
                ["distill", "--db", str(db),
                 "--analyze-health", "--policy-exit-halt"],
            )
            assert result.exit_code == 0, result.output
