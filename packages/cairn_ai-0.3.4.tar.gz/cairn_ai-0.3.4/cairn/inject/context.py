"""Context builder — assemble a pre-prompt Markdown snippet from the truth store.

The snippet is ordered by decayed confidence (highest first) and grouped by
cluster so the agent sees the most relevant, recent, high-signal patterns at
the top.  Records below a minimum decayed confidence are suppressed.

Output format (Markdown, suitable for injection into a system prompt or
referenced from CLAUDE.md / AGENTS.md)::

    # Cairn context — <project> — <date>

    ## <cluster name> [<source>]
    - <record content summary>
    ...

    ## Lint rules to enforce
    - **ruff BLE001** ...
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from cairn.distill.cluster import cluster
from cairn.distill.decay import apply_decay, decayed_confidence
from cairn.distill.health import HAS_MARGIN, analyze_clusters
from cairn.distill.namer import name_cluster
from cairn.distill.rules import encode_as_rule
from cairn.store.schema import TruthRecord
from cairn.store.writer import _DEFAULT_DB, get_all


def estimate_tokens(text: str) -> int:
    """Cheap, dependency-free token estimate: ~1 token per 4 characters of
    English text is a standard heuristic for GPT/Claude tokenizers. Good
    enough for budget decisions; callers that need exact counts should pipe
    the output through their model's tokenizer."""
    return max(1, len(text) // 4)


def build_context(
    top_n: int = 20,
    db_path: Path = _DEFAULT_DB,
    min_confidence: float = 0.05,
    max_tokens: int | None = 4000,
) -> str:
    """Build a Markdown context snippet from the highest-confidence records.

    Args:
        top_n:          maximum number of records to include across all clusters.
        db_path:        path to the SQLite store.
        min_confidence: drop records whose decayed confidence is below this.
        max_tokens:     approximate token ceiling (``len(text)//4`` heuristic).
                        ``None`` disables the ceiling. When exceeded, the
                        context is truncated at a section boundary and a
                        ``… truncated at N tokens`` marker is appended.

    Returns:
        A Markdown string.  Empty string if the store is empty or missing.
    """
    if not Path(db_path).exists():
        return ""

    all_records = get_all(db_path)
    if not all_records:
        return ""

    # Apply decay and cap at top_n
    live = apply_decay(all_records, min_confidence=min_confidence)[:top_n]
    if not live:
        return ""

    now = datetime.now(tz=timezone.utc)

    # Group records by domain so multi-module projects get clear sections
    domains: dict[str, list[TruthRecord]] = {}
    for r in live:
        domains.setdefault(r.domain, []).append(r)

    all_domains = sorted(domains.keys())
    title_domain = all_domains[0] if len(all_domains) == 1 else "multi-module"

    lines: list[str] = [
        f"# Cairn context — {title_domain} — {now.strftime('%Y-%m-%d')}",
        "",
        "_Auto-generated from runtime signal. Do not edit manually._",
        "",
    ]

    rule_snippets: list[str] = []

    # Margin health analysis (when available)
    cluster_healths = {}
    escalations = {}
    causality_result = None
    if HAS_MARGIN:
        from cairn.distill.escalation import evaluate_all
        from cairn.distill.causality import build_causal_graph
        all_clusters = cluster(live)
        cluster_healths = analyze_clusters(all_clusters, as_of=now)
        escalations = evaluate_all(cluster_healths)
        causality_result = build_causal_graph(all_clusters, as_of=now)

    for domain_name in all_domains:
        domain_records = domains[domain_name]
        if len(all_domains) > 1:
            lines.append(f"# {domain_name}")
            lines.append("")

        domain_clusters = cluster(domain_records)
        for cluster_key, members in domain_clusters.items():
            name = name_cluster(members)
            source_tag = members[0].source

            # Escalation tag when margin is available
            esc = escalations.get(cluster_key)
            health = cluster_healths.get(cluster_key)
            if esc and esc.level != "LOG":
                esc_tag = "🔴 HALT" if esc.level == "HALT" else "🟡 ALERT"
                lines.append(f"## {esc_tag} — {name} [{source_tag}]")
            else:
                lines.append(f"## {name} [{source_tag}]")
            lines.append("")

            # Health summary line when margin is available
            if health and health.health:
                health_parts = [f"Health: **{health.health}**"]
                if health.drift_state and health.drift_state != "STABLE":
                    health_parts.append(
                        f"Drift: {health.drift_state} {health.drift_direction}"
                    )
                if health.anomaly_state and health.anomaly_state != "EXPECTED":
                    health_parts.append(f"Anomaly: {health.anomaly_state}")
                lines.append(f"_{' | '.join(health_parts)}_")
                lines.append("")

            for r in members[:5]:  # cap per-cluster display at 5
                first_line = r.content.splitlines()[0]
                conf = decayed_confidence(r, now)
                lines.append(f"- {first_line}  _(conf: {conf:.2f})_")

            if len(members) > 5:
                lines.append(f"- _…and {len(members) - 5} more_")

            # Causal explanation when available
            if causality_result:
                explanation = causality_result.explain(cluster_key)
                if explanation and explanation != "No causal links discovered.":
                    lines.append(f"- _Causality: {explanation}_")

            lines.append("")

            rule = encode_as_rule(name, members)
            if rule:
                rule_snippets.append(rule)

    # Cross-domain summary when multiple domains are present
    if len(all_domains) > 1:
        # Find pattern clusters that span multiple domains
        from collections import defaultdict
        cluster_domains: dict[str, set[str]] = defaultdict(set)
        all_clusters = cluster(live)
        for cluster_key, members in all_clusters.items():
            for m in members:
                cluster_domains[cluster_key].add(m.domain)
        cross = {k: v for k, v in cluster_domains.items() if len(v) > 1}
        if cross:
            lines.append("## Cross-domain patterns")
            lines.append("")
            for cluster_key, doms in cross.items():
                cluster_members = all_clusters[cluster_key]
                name = name_cluster(cluster_members)
                lines.append(
                    f"- **{name}** appears in {', '.join(sorted(doms))} "
                    f"({len(cluster_members)} records)"
                )
            lines.append("")

    # Success signal: surface stable modules alongside the failure clusters.
    try:
        from cairn.distill.stability import success_summary
        summary = success_summary(db_path)
        if summary:
            lines.extend(summary.splitlines())
    except Exception:
        pass

    if rule_snippets:
        lines.append("## Lint rules to enforce")
        lines.append("")
        for snippet in rule_snippets:
            for rule_line in snippet.splitlines():
                lines.append(rule_line)
            lines.append("")

    out = "\n".join(lines)
    if max_tokens is not None:
        out = _truncate_to_budget(lines, max_tokens)
    return out


def _truncate_to_budget(lines: list[str], max_tokens: int) -> str:
    """Walk the section-oriented line list and stop at the last section
    boundary that keeps the total under ``max_tokens``. Always preserves the
    header so the consumer can tell it's a cairn context."""
    budget_chars = max_tokens * 4
    total = 0
    kept: list[str] = []
    last_section_end = 0
    for i, line in enumerate(lines):
        total += len(line) + 1  # +1 for the newline
        kept.append(line)
        # A blank line after a section marks a natural truncation boundary.
        if line == "" and i > 0 and lines[i - 1].startswith(("## ", "- ")):
            last_section_end = len(kept)
        if total > budget_chars and last_section_end > 4:
            kept = kept[:last_section_end]
            kept.append(f"_… truncated to ~{max_tokens} tokens_")
            break
    return "\n".join(kept)
