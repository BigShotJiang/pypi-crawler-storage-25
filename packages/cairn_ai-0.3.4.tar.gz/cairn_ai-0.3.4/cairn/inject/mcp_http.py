"""HTTP + SSE transport for the Cairn MCP server.

Split out of ``mcp_server.py`` to keep that module focused on the JSON-RPC
protocol and stdio transport.  The HTTP transport also exposes two REST
endpoints (``/ingest`` and ``/query``) that share the same store.

Wire protocol (MCP HTTP transport spec):

- ``GET  /sse``       — client opens an SSE stream; server immediately sends
                        an ``endpoint`` event with the POST URL the client
                        must use for its JSON-RPC messages.
- ``POST /message``   — client sends a JSON-RPC request; server queues the
                        response back through the SSE stream for that session.
- ``POST /ingest``    — JSONL body of TruthRecord dicts (auth-gated).
- ``POST /query``     — semantic search (auth-gated).
- ``GET  /health``    — liveness probe, returns store path.

No external dependencies — uses Python's built-in ``http.server``.
"""

from __future__ import annotations

import json
import queue
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse


def serve_http(host: str = "127.0.0.1", port: int = 8765) -> None:
    """Start the HTTP + Server-Sent Events MCP server.

    ``_server_db`` and ``_server_token`` are read lazily from
    ``cairn.inject.mcp_server`` so tests can monkey-patch them the same way
    they always have.
    """
    # Lazy import to avoid a circular dependency with mcp_server.
    from cairn.inject import mcp_server as _mcp

    # session_id → queue of serialised JSON-RPC response strings
    _sessions: dict[str, queue.Queue] = {}
    _sessions_lock = threading.Lock()

    _host = host  # capture for closure
    _port = port

    class _MCPHandler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:
            pass  # suppress noisy default access log

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/sse":
                self._handle_sse()
            elif parsed.path == "/health":
                self._json_response(200, {"status": "ok", "store": str(_mcp._server_db)})
            else:
                self.send_error(404)

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/message":
                self._handle_message()
            elif parsed.path == "/ingest":
                if not self._check_auth():
                    return
                self._handle_rest_ingest()
            elif parsed.path == "/query":
                if not self._check_auth():
                    return
                self._handle_rest_query()
            else:
                self.send_error(404)

        def do_OPTIONS(self) -> None:  # noqa: N802
            self.send_response(204)
            self._cors_headers()
            self.end_headers()

        def _cors_headers(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

        def _check_auth(self) -> bool:
            """Return True if the request is authorised (or no token is required)."""
            if _mcp._server_token is None:
                return True
            auth = self.headers.get("Authorization", "")
            if auth == f"Bearer {_mcp._server_token}":
                return True
            self.send_error(401, "Unauthorized")
            return False

        def _json_response(self, code: int, data: Any) -> None:
            body = json.dumps(data).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self._cors_headers()
            self.end_headers()
            self.wfile.write(body)

        def _read_body(self) -> bytes:
            length = int(self.headers.get("Content-Length", 0) or 0)
            return self.rfile.read(length) if length else b""

        def _handle_rest_ingest(self) -> None:
            """POST /ingest — accept JSONL body, write TruthRecords to store."""
            from datetime import datetime, timezone
            from cairn.store.schema import TruthRecord
            from cairn.store.writer import Writer

            body = self._read_body().decode("utf-8", errors="replace")
            lines = [l.strip() for l in body.splitlines() if l.strip()]
            if not lines:
                self._json_response(400, {"error": "empty body"})
                return

            now = datetime.now(tz=timezone.utc)
            records: list[TruthRecord] = []
            errors: list[str] = []
            for i, line in enumerate(lines):
                try:
                    obj = json.loads(line)
                    if not isinstance(obj, dict) or "content" not in obj:
                        errors.append(f"line {i+1}: missing 'content' field")
                        continue
                    records.append(TruthRecord(
                        source=obj.get("source", "remote"),
                        domain=obj.get("domain", "remote"),
                        content=obj["content"],
                        confidence=float(obj.get("confidence", 1.0)),
                        occurred_at=now,
                        source_file=obj.get("source_file"),
                        source_line=obj.get("source_line"),
                        exception_type=obj.get("exception_type"),
                    ))
                except (json.JSONDecodeError, TypeError, ValueError) as exc:
                    errors.append(f"line {i+1}: {exc}")

            if records:
                w = Writer(db_path=_mcp._server_db)
                w.write_many(records)

            self._json_response(200, {
                "ingested": len(records),
                "errors": errors,
            })

        def _handle_rest_query(self) -> None:
            """POST /query — semantic/keyword search, returns JSON results."""
            from cairn.store.query import semantic_search

            body = self._read_body()
            try:
                params = json.loads(body) if body else {}
            except json.JSONDecodeError as exc:
                self._json_response(400, {"error": f"bad JSON: {exc}"})
                return

            q = params.get("q", "").strip()
            if not q:
                self._json_response(400, {"error": "'q' is required"})
                return

            top_k = int(params.get("top_k", 10))
            source = params.get("source")  # optional source filter applied post-search
            fetch_k = top_k * 3 if source else top_k
            all_records = semantic_search(q, top_k=fetch_k, db_path=_mcp._server_db)
            records = [r for r in all_records if r.source == source][:top_k] if source else all_records
            self._json_response(200, {
                "results": [
                    {
                        "id": r.id,
                        "source": r.source,
                        "domain": r.domain,
                        "content": r.content,
                        "confidence": r.confidence,
                        "occurred_at": r.occurred_at.isoformat(),
                        "source_file": r.source_file,
                        "source_line": r.source_line,
                        "exception_type": r.exception_type,
                        "pattern_cluster": r.pattern_cluster,
                    }
                    for r in records
                ]
            })

        def _handle_sse(self) -> None:
            session_id = str(uuid.uuid4())
            q: queue.Queue = queue.Queue()
            with _sessions_lock:
                _sessions[session_id] = q

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self._cors_headers()
            self.end_headers()

            # Tell the client which URL to POST messages to
            endpoint_url = f"http://{_host}:{_port}/message?sessionId={session_id}"
            self.wfile.write(f"event: endpoint\ndata: {endpoint_url}\n\n".encode())
            self.wfile.flush()

            try:
                while True:
                    try:
                        msg_str = q.get(timeout=25)
                    except queue.Empty:
                        # Keepalive comment — prevents proxies from closing the stream
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                        continue

                    if msg_str is None:  # shutdown sentinel
                        break

                    self.wfile.write(f"event: message\ndata: {msg_str}\n\n".encode())
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                with _sessions_lock:
                    _sessions.pop(session_id, None)

        def _handle_message(self) -> None:
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            session_id = (qs.get("sessionId") or [None])[0]

            with _sessions_lock:
                q = _sessions.get(session_id) if session_id else None

            if q is None:
                self.send_error(404, "Session not found — open /sse first")
                return

            body = self._read_body()

            # Acknowledge immediately; response arrives via SSE
            self.send_response(202)
            self.send_header("Content-Length", "0")
            self._cors_headers()
            self.end_headers()

            def _dispatch_and_enqueue() -> None:
                collected: list[str] = []

                class _Collector:
                    def write(self, s: str) -> None:
                        collected.append(s)
                    def flush(self) -> None:
                        pass

                try:
                    rpc_msg = json.loads(body)
                    _mcp.dispatch(rpc_msg, out=_Collector())
                    for line in collected:
                        stripped = line.strip()
                        if stripped:
                            q.put(stripped)
                except Exception as exc:
                    q.put(json.dumps(_mcp._err(None, -32700, str(exc))))

            threading.Thread(target=_dispatch_and_enqueue, daemon=True).start()

    server = HTTPServer((host, port), _MCPHandler)
    print(  # noqa: T201
        f"Cairn MCP HTTP+SSE server → http://{host}:{port}/sse",
        file=sys.stderr,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
