"""Coverage reader — identify untested branches from a .coverage data file.

Reads the SQLite-backed ``.coverage`` file produced by ``coverage run`` and
emits ``TruthRecord`` objects (source="ast") for every executable line that
was never hit.  If ``coverage`` is not installed or no ``.coverage`` file
exists the function returns an empty list — callers can always safely call it.

Usage::

    from cairn.capture.coverage_reader import read_coverage
    records = read_coverage()           # reads ./.coverage
    records = read_coverage(Path("cov/.coverage"))

Then persist::

    with Writer(db_path) as w:
        w.write_many(records)

Or integrate into the ``cairn scan --with-coverage`` flow.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from cairn.store.schema import TruthRecord

_CONFIDENCE = 0.80   # structural observation, not yet runtime-corroborated
_DEFAULT_COV = Path(".coverage")


def read_coverage(
    coverage_path: Path = _DEFAULT_COV,
    source_root: Path | None = None,
    domain: str = "",
) -> list[TruthRecord]:
    """Return TruthRecords for every uncovered line in *coverage_path*.

    Args:
        coverage_path: path to the ``.coverage`` SQLite file.
        source_root:   project root used to make file paths relative (defaults
                       to the directory containing *coverage_path*).
        domain:        domain tag for generated records.  When empty, Cairn
                       infers it from the file's parent directory name.

    Returns:
        List of ``TruthRecord`` objects with ``source="ast"`` and
        ``pattern_cluster="untested_branch"``.  Empty list if coverage.py is
        not installed or no data file exists.
    """
    if not coverage_path.exists():
        return []

    try:
        from coverage import Coverage  # type: ignore[import]
    except ImportError:
        return []

    root = source_root or coverage_path.parent
    now = datetime.now(tz=timezone.utc)
    records: list[TruthRecord] = []

    try:
        cov = Coverage(data_file=str(coverage_path))
        cov.load()
        data = cov.get_data()
    except Exception:
        return []

    for filename in data.measured_files():
        file_path = Path(filename)
        # coverage may store relative paths (when run with cwd=project);
        # resolve them against source_root so the existence + containment
        # checks below work regardless of the test runner's cwd.
        if not file_path.is_absolute():
            file_path = (root / file_path).resolve()
        if not file_path.exists():
            continue
        try:
            file_path.resolve().relative_to(root.resolve())
        except ValueError:
            continue

        try:
            _fmt, stmts, excluded, missing, _ = cov.analysis(filename)
        except Exception:
            continue

        if not missing:
            continue

        file_domain = domain or _infer_domain(file_path, root)

        # Group consecutive missing lines into ranges for conciser records
        for lineno in missing:
            records.append(TruthRecord(
                source="ast",
                domain=file_domain,
                content=(
                    f"untested_branch: line {lineno} in {file_path.name} "
                    f"not executed by test suite"
                ),
                confidence=_CONFIDENCE,
                occurred_at=now,
                source_file=str(file_path),
                source_line=lineno,
                pattern_cluster="untested_branch",
            ))

    return records


def read_branch_coverage(
    coverage_path: Path = _DEFAULT_COV,
    source_root: Path | None = None,
    domain: str = "",
) -> list[TruthRecord]:
    """Like ``read_coverage`` but emits records for untaken *branches* rather
    than uncovered lines.  Requires that ``coverage`` was run with
    ``branch=True`` (e.g. ``coverage run --branch``).

    Returns an empty list if no branch data is present.
    """
    if not coverage_path.exists():
        return []

    try:
        from coverage import Coverage  # type: ignore[import]
    except ImportError:
        return []

    root = source_root or coverage_path.parent
    now = datetime.now(tz=timezone.utc)
    records: list[TruthRecord] = []

    try:
        cov = Coverage(data_file=str(coverage_path), branch=True)
        cov.load()
        data = cov.get_data()
    except Exception:
        return []

    if not data.has_arcs():
        return []

    for filename in data.measured_files():
        file_path = Path(filename)
        if not file_path.is_absolute():
            file_path = (root / file_path).resolve()
        if not file_path.exists():
            continue
        try:
            file_path.resolve().relative_to(root.resolve())
        except ValueError:
            continue

        try:
            if not hasattr(data, 'missing_arcs'):
                continue
            missing_branches = data.missing_arcs(filename) or []
            if not missing_branches:
                continue
        except Exception:
            continue

        if not missing_branches:
            continue

        file_domain = domain or _infer_domain(file_path, root)

        for src, dst in missing_branches:
            if src < 0 or dst < 0:   # entry/exit pseudo-arcs
                continue
            records.append(TruthRecord(
                source="ast",
                domain=file_domain,
                content=(
                    f"untested_branch: branch from line {src} → {dst} "
                    f"in {file_path.name} never taken"
                ),
                confidence=_CONFIDENCE,
                occurred_at=now,
                source_file=str(file_path),
                source_line=src,
                pattern_cluster="untested_branch",
            ))

    return records


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _infer_domain(file_path: Path, root: Path) -> str:
    try:
        rel = file_path.relative_to(root.resolve())
        parts = rel.parts
        return parts[0] if parts else file_path.stem
    except ValueError:
        return file_path.stem
