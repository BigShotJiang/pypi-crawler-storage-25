"""Secret / PII scrubber — redact sensitive values from captured content.

Applied at ingress to every source that may carry runtime data (pytest locals,
monitor return values, ingested JSONL, git diffs). The rule of thumb: a
captured TruthRecord is likely to end up in an agent's prompt via
``cairn context`` or the MCP server, so a leaked secret here leaks to whatever
model the user is driving.

Strategy
--------
Two layers:

1. **Key-based redaction** — any ``key=value`` or ``key: value`` pair whose
   key matches a sensitive-name heuristic (password, token, secret, api_key,
   authorization, cookie, session, private_key, credential, otp, …) has its
   value replaced with ``<redacted:reason>``.

2. **Value-based redaction** — strings that match high-confidence secret
   shapes (AWS access keys, GitHub/Anthropic/OpenAI-style tokens, PEM blocks,
   JWTs, generic 32+-char hex/base64) are replaced even if their key name is
   innocuous.

Also scrubs common PII shapes: email addresses (partially masked), IPv4,
credit-card-shaped digit runs. Names, addresses, and free-form PII are NOT
detected — scrubbing is conservative and signature-based.

The scrubber is deliberately over-eager: false positives cost a little signal
quality; false negatives leak credentials into an AI prompt.
"""

from __future__ import annotations

import os
import re

# ---------------------------------------------------------------------------
# Heuristics
# ---------------------------------------------------------------------------

# Sensitive tokens — checked case-insensitively against the trailing
# segment of an identifier (split on ``_ - .``). This matches both bare
# names (``password``, ``token``) and prefixed-key variants
# (``aws_secret``, ``stripe_key``, ``db_password``, ``_authToken``)
# without requiring every prefix to be hand-listed.
_SENSITIVE_TOKENS: frozenset[str] = frozenset({
    "password", "passwd", "passphrase",
    "secret", "secrets",
    "token", "tokens",
    "key", "apikey", "accesskey", "privatekey",
    "auth", "authorization", "authtoken", "bearer",
    "cookie", "cookies",
    "session", "sessionid", "sid",
    "csrf",
    "credential", "credentials",
    "clientsecret",
    "refreshtoken",
    "otp", "mfa",
    "ssn", "dob",
    "pat",  # personal access token
    "pwd",
})

# Identifier ≈ word chars with optional inner separators. Accepts
# ``aws_secret``, ``AWS_SECRET``, ``stripeKey``, ``access-key``,
# ``authToken``, ``_authToken``, ``api.key``.
_IDENT_CHARS = r"[A-Za-z0-9_\-]"

# Value matcher used by both the KV regex (below) and the fallback rescanner.
# Excludes ``= , ; < > { } ) ] ' "`` from the unquoted form so a value
# never eats across ``key2=value2`` into the next assignment.
_VAL_FRAG = r"""'[^']*'|"[^"]*"|'[^']*$|"[^"]*$|[^,\s;={{}}<>\)\]'"]+"""

# Find any identifier=value / identifier: value pair. We don't require a
# sensitive name here — _is_sensitive_key filters at substitution time.
# Using a permissive identifier plus a value-bearing pattern means a
# non-sensitive prefix like ``context:`` can match first without eating
# forward into a subsequent ``password=...`` pair (the ``=`` exclusion
# in _VAL_FRAG stops it at the boundary).
_KV_ASSIGN = re.compile(
    rf"""(?x)
    (?P<prefix>(?:^|[^A-Za-z0-9])['"]?)
    (?P<key>{_IDENT_CHARS}{{2,64}})
    (?P<close>['"]?)
    \s*(?P<sep>[:=])\s*
    (?P<val>{_VAL_FRAG})
    """
)


_SENSITIVE_ALT = "|".join(sorted(_SENSITIVE_TOKENS, key=len, reverse=True))

# Catches a dangling ``=value`` / ``:value`` that immediately follows a
# previous redaction. Example: ``cookie=sessionid=ABCDEF`` becomes
# ``cookie=<redacted:sensitive-key>=ABCDEF`` on the first pass; this
# regex then rewrites the ``=ABCDEF`` tail.
_CHAINED_TAIL = re.compile(
    r"(<redacted:[^>]+>)[:=][^\s,;<>\)\]]+"
)
# Directly anchored on a sensitive token suffix anywhere in an identifier.
# Matches ``aws_secret=…``, ``_authToken:…``, ``stripeKey=…``.
_SENSITIVE_KV_RE = re.compile(
    rf"""(?xi)
    (?P<prefix>(?:^|[^A-Za-z0-9])['"]?)
    (?P<key>{_IDENT_CHARS}{{0,60}}(?:{_SENSITIVE_ALT}))
    (?P<close>['"]?)
    \s*(?P<sep>[:=])\s*
    (?P<val>{_VAL_FRAG})
    """
)


def _sensitive_rescan(text: str) -> str:
    """Pass B: look specifically for identifiers ending in a sensitive
    token. Catches pairs that pass A missed because an earlier
    non-sensitive prefix consumed the buffer (see _kv_sub commentary)."""

    def _sub(m: re.Match[str]) -> str:
        key = m.group("key")
        # Reject false positives (ids shorter than 3 chars, or non-boundary
        # trailing tokens caught by the broad suffix rule).
        if not _is_sensitive_key(key):
            return m.group(0)
        return (
            f"{m.group('prefix')}{key}{m.group('close')}"
            f"{m.group('sep')}<redacted:sensitive-key>"
        )

    return _SENSITIVE_KV_RE.sub(_sub, text)


def _is_sensitive_key(key: str) -> bool:
    """Return True when *key* ends with (or equals) a sensitive token.

    Covers:
      - whole-key match: ``token``, ``password``
      - separator-joined: ``aws_secret``, ``stripe-key``, ``api.key``
      - camelCase / PascalCase: ``authToken``, ``apiKey``, ``DbPassword``
      - separator-joined compound: ``session_id`` → normalised to
        ``sessionid`` (which is in the token set)
      - prefix + sensitive suffix embedded in a compound identifier
    """
    low = key.lower().lstrip("_-.")
    if not low:
        return False
    if low in _SENSITIVE_TOKENS:
        return True
    # Collapse separators and re-check the whole token (catches
    # ``session_id`` → ``sessionid``, ``api-key`` → ``apikey``).
    normalised = re.sub(r"[_\-.]+", "", low)
    if normalised in _SENSITIVE_TOKENS:
        return True
    # Trailing segment after _/-/. separator
    segments = re.split(r"[_\-.]+", low)
    if segments and segments[-1] in _SENSITIVE_TOKENS:
        return True
    # camelCase / PascalCase trailing token
    camel = re.split(r"(?<=[a-z])(?=[A-Z])", key.lstrip("_-."))
    if camel and len(camel) > 1 and camel[-1].lower() in _SENSITIVE_TOKENS:
        return True
    # Sensitive suffix inside a run-together lowercase identifier
    # (``apikey`` = ``api`` + ``key``). Require ≥4 chars to skip ``id``.
    for tok in _SENSITIVE_TOKENS:
        if len(tok) >= 4 and (
            low.endswith(tok) or normalised.endswith(tok)
        ) and low != tok:
            return True
    return False

_TOKEN_SHAPES = [
    # AWS access key
    (re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), "aws-key"),
    # AWS secret key (40 base64-ish after specific prefixes — conservative)
    # GitHub tokens
    (re.compile(r"\bghp_[A-Za-z0-9]{36,}\b"), "github-token"),
    (re.compile(r"\bgho_[A-Za-z0-9]{36,}\b"), "github-token"),
    (re.compile(r"\bghs_[A-Za-z0-9]{36,}\b"), "github-token"),
    (re.compile(r"\bghu_[A-Za-z0-9]{36,}\b"), "github-token"),
    # Anthropic / OpenAI / OpenRouter
    (re.compile(r"\bsk-ant-[A-Za-z0-9\-_]{20,}\b"), "anthropic-key"),
    (re.compile(r"\bsk-or-[A-Za-z0-9\-_]{20,}\b"), "openrouter-key"),
    (re.compile(r"\bsk-proj-[A-Za-z0-9\-_]{20,}\b"), "openai-key"),
    (re.compile(r"\bsk-[A-Za-z0-9]{32,}\b"), "openai-key"),
    # Slack
    (re.compile(r"\bxox[abprs]-[A-Za-z0-9\-]{10,}\b"), "slack-token"),
    # JWT
    (re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b"), "jwt"),
    # PEM block
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----"),
     "private-key"),
]

_PII_SHAPES = [
    # Credit-card-shaped (Luhn not checked — shape only)
    (re.compile(r"\b(?:\d[ -]?){13,19}\b"), "cc-number"),
    # IPv4
    (re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "ipv4"),
]

_EMAIL_RE = re.compile(r"\b([A-Za-z0-9._%+\-]+)@([A-Za-z0-9.\-]+\.[A-Za-z]{2,})\b")

# Environment variables whose *values* should be scrubbed whenever they appear
# verbatim in captured content. Harvested once at import time.
def _env_secrets() -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    for name, val in os.environ.items():
        if not val or len(val) < 8:
            continue
        if _is_sensitive_key(name):
            out.append((val, name.lower()))
    return out


_ENV_SECRETS = _env_secrets()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scrub(text: str) -> str:
    """Return *text* with secrets / PII redacted in place.

    Idempotent: scrubbing an already-scrubbed string is a no-op.
    Safe on None / empty / non-string inputs — returns them unchanged.
    """
    if not isinstance(text, str) or not text:
        return text

    # 1. Redact env-derived secret values verbatim (highest priority).
    for val, reason in _ENV_SECRETS:
        if val in text:
            text = text.replace(val, f"<redacted:{reason}>")

    # 2. Redact recognised token shapes (PEM blocks, AWS/GitHub/etc
    # tokens) BEFORE KV redaction — these shapes often contain ``:``
    # and ``=`` that would otherwise be mis-parsed as assignments,
    # breaking the shape and leaving the secret partially visible.
    for pat, reason in _TOKEN_SHAPES:
        text = pat.sub(f"<redacted:{reason}>", text)

    # 3. Redact key=value / key: value pairs whose key ends with (or
    # equals) a sensitive-suffix token. Handles prefixed variants like
    # aws_secret, stripe_key, db_password, _authToken, apiKey, etc.
    #
    # Two passes so a non-sensitive prefix (``context: bearer='xyz``)
    # doesn't consume the sensitive-key pair that follows.
    def _kv_sub(m: re.Match[str]) -> str:
        key = m.group("key")
        if not _is_sensitive_key(key):
            return m.group(0)
        return (
            f"{m.group('prefix')}{key}{m.group('close')}"
            f"{m.group('sep')}<redacted:sensitive-key>"
        )

    text = _KV_ASSIGN.sub(_kv_sub, text)
    text = _sensitive_rescan(text)

    # 4. Chained assignment cleanup: ``cookie=sessionid=ABCDEF`` has a
    # sensitive key with a value that is itself another assignment; the
    # KV substitution consumed only up to the second ``=``. Redact any
    # ``<redacted:*>=<token>`` tail that was left dangling.
    text = _CHAINED_TAIL.sub(r"\1<redacted:tail>", text)

    # 4. Mask email local-parts (keep domain for debugging).
    text = _EMAIL_RE.sub(lambda m: f"<redacted:email>@{m.group(2)}", text)

    # 5. Redact PII shapes.
    for pat, reason in _PII_SHAPES:
        text = pat.sub(f"<redacted:{reason}>", text)

    return text


def scrub_record(record: object) -> None:
    """Scrub a TruthRecord in place before it reaches the store.

    Mutates ``content`` and re-computes ``id`` so that the stored hash matches
    the scrubbed content (two observations that differed only by a secret
    collapse into one record, and the hash can never be inverted to recover
    the secret).
    """
    original = getattr(record, "content", None)
    if not original:
        return
    scrubbed = scrub(original)
    if scrubbed == original:
        return
    setattr(record, "content", scrubbed)
    compute = getattr(record, "_compute_id", None)
    if callable(compute):
        setattr(record, "id", compute())
