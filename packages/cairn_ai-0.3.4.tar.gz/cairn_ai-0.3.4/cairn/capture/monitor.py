"""sys.monitoring capture hook (Python 3.12+, PEP 669).

Near-zero overhead instrumentation via selective bytecode event subscription.

Design
------
- Uses tool ID ``TOOL_ID`` (must be unique per process; we claim 2 leaving 1 for
  the debugger and 3–5 for other tools).
- Subscribes to CALL, RETURN_VALUE, and RAISE events globally, then filters to
  watched domains inside each callback.  This is the recommended pattern from
  PEP 669: coarse global subscription + cheap per-event domain filter.
- State is module-level and protected by a simple flag so start/stop are
  idempotent and safe to call from multiple threads (GIL protects the flag).
- Records are batched in a thread-local list and flushed to SQLite at ``stop()``
  or every ``_FLUSH_EVERY`` events to bound memory use.
"""

from __future__ import annotations

import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

# PEP 669 reserves IDs 0 (debugger) and 1 (coverage). IDs 2–5 are free for
# third-party tools. We prefer 2 but fall back to 3/4/5 if another tool already
# owns it — e.g. a concurrent profiler in the same process.
_PREFERRED_TOOL_IDS = (2, 3, 4, 5)
_TOOL_ID: int | None = None  # resolved in start()
_FLUSH_EVERY = 500  # flush to SQLite after this many captured events
_FLUSH_INTERVAL = 30  # seconds between periodic background flushes

_DEFAULT_DB = Path(".cairn") / "store.db"

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_active = False
_db_path: Path = _DEFAULT_DB  # set by start(), used by _flush()
_watched_domains: list[str] = []
_lock = threading.Lock()
_flush_timer: threading.Timer | None = None

# Thread-local buffer so concurrent threads don't contend on a shared list.
# _all_buffers tracks every thread's buffer list so the periodic flush timer
# (which runs in its own thread) can drain all of them, not just its own.
_local = threading.local()
_all_buffers: list[list] = []  # protected by _lock


def _get_buffer() -> list:
    if not hasattr(_local, "records"):
        _local.records = []
        with _lock:
            _all_buffers.append(_local.records)
    return _local.records


def _get_pending() -> dict:
    """Map of code-object id → call start time, for first-invocation duration."""
    if not hasattr(_local, "pending"):
        _local.pending = {}
    return _local.pending


def _get_call_depth() -> int:
    if not hasattr(_local, "call_depth"):
        _local.call_depth = 0
    return _local.call_depth


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def start(domains: list[str] | None = None, db_path: Path = _DEFAULT_DB) -> None:
    """Begin capturing execution traces.

    Args:
        domains: module name prefixes to watch (e.g. ``["mypackage"]``).
                 Pass ``None`` to watch all non-stdlib, non-cairn code.
        db_path: path to the SQLite store.
    """
    if sys.version_info < (3, 12):
        raise RuntimeError(
            "sys.monitoring capture requires Python 3.12+. "
            "Use @cairn.watch instead."
        )

    global _active, _watched_domains, _db_path, _TOOL_ID
    with _lock:
        if _active:
            return
        _watched_domains = list(domains) if domains else []
        _db_path = db_path
        _all_buffers.clear()
        # Cancel any orphaned flush timer from a previous aborted session.
        _stop_periodic_flush_locked()
        _active = True

    m = sys.monitoring
    # Claim the first available tool ID rather than a hardcoded one, so we
    # don't silently drop events if another tool (profiler, debugger extension)
    # has already claimed slot 2.
    last_err: Exception | None = None
    for candidate in _PREFERRED_TOOL_IDS:
        try:
            m.use_tool_id(candidate, "cairn")
            _TOOL_ID = candidate
            last_err = None
            break
        except ValueError as e:
            last_err = e
            continue
    if _TOOL_ID is None:
        with _lock:
            _active = False
        raise RuntimeError(
            "cairn monitor could not claim a PEP 669 tool ID (2–5 all taken). "
            f"Last error: {last_err}"
        )

    # Subscribe to the three events we care about
    events = (
        m.events.CALL
        | m.events.PY_RETURN
        | m.events.RAISE
    )
    m.set_events(_TOOL_ID, events)

    m.register_callback(_TOOL_ID, m.events.CALL, _on_call)
    m.register_callback(_TOOL_ID, m.events.PY_RETURN, _on_return)
    m.register_callback(_TOOL_ID, m.events.RAISE, _on_raise)

    _start_periodic_flush()


def stop() -> None:
    """Detach all hooks and flush buffered records to SQLite."""
    if sys.version_info < (3, 12):
        return

    global _active, _TOOL_ID
    with _lock:
        if not _active:
            return
        _active = False

    _stop_periodic_flush()

    if _TOOL_ID is not None:
        m = sys.monitoring
        m.set_events(_TOOL_ID, m.events.NO_EVENTS)
        m.register_callback(_TOOL_ID, m.events.CALL, None)
        m.register_callback(_TOOL_ID, m.events.PY_RETURN, None)
        m.register_callback(_TOOL_ID, m.events.RAISE, None)
        m.free_tool_id(_TOOL_ID)
        _TOOL_ID = None

    _flush()


def is_active() -> bool:
    return _active


# ---------------------------------------------------------------------------
# Periodic background flush
# ---------------------------------------------------------------------------


def _start_periodic_flush() -> None:
    """Schedule a repeating background flush every _FLUSH_INTERVAL seconds.

    Guarded by ``_lock`` so repeated ``start()`` calls or overlapping reschedules
    never leave two timers racing for the same buffers.
    """
    global _flush_timer

    def _tick():
        if _active:
            _flush_all_threads()
            _start_periodic_flush()  # reschedule

    with _lock:
        if _flush_timer is not None:
            _flush_timer.cancel()
        _flush_timer = threading.Timer(_FLUSH_INTERVAL, _tick)
        _flush_timer.daemon = True
        _flush_timer.start()


def _stop_periodic_flush() -> None:
    with _lock:
        _stop_periodic_flush_locked()


def _stop_periodic_flush_locked() -> None:
    """Inner version that assumes the caller already holds ``_lock``."""
    global _flush_timer
    if _flush_timer is not None:
        _flush_timer.cancel()
        _flush_timer = None


# ---------------------------------------------------------------------------
# Event callbacks
# ---------------------------------------------------------------------------


def _should_watch(code) -> bool:
    """Return True if this code object belongs to a watched domain."""
    filename: str = code.co_filename or ""

    # Never watch internal cairn code or stdlib
    if filename.startswith("<"):
        return False
    # Skip cairn's own package code (not user code that happens to be in
    # a directory named "cairn")
    _pkg_dir = str(Path(__file__).resolve().parent.parent)
    if str(Path(filename).resolve()).startswith(_pkg_dir + "/"):
        return False
    if not _watched_domains:
        # Default: watch anything that isn't site-packages / stdlib
        return "site-packages" not in filename and "lib/python" not in filename
    module = code.co_qualname.split(".")[0] if hasattr(code, "co_qualname") else ""
    return any(module.startswith(d) or filename.find(d.replace(".", "/")) != -1
               for d in _watched_domains)


def _on_call(code, instruction_offset: int, callable_, arg):
    if not _should_watch(code):
        return sys.monitoring.DISABLE

    # Increment depth counter; store start time for this code object
    _local.call_depth = _get_call_depth() + 1
    depth = _local.call_depth
    now = datetime.now(tz=timezone.utc)
    _get_pending()[id(code)] = now

    buf = _get_buffer()
    buf.append(("call", code, callable_, arg, now, depth))
    if len(buf) >= _FLUSH_EVERY:
        _flush()

    return sys.monitoring.DISABLE  # disable per-code after first hit to minimise overhead


def _on_return(code, instruction_offset: int, retval):
    if not _active or not _should_watch(code):
        return

    pending = _get_pending()
    now = datetime.now(tz=timezone.utc)
    start = pending.pop(id(code), None)
    duration_ms: float | None = None
    depth = _get_call_depth()
    if start is not None:
        duration_ms = (now - start).total_seconds() * 1000
        _local.call_depth = max(0, depth - 1)

    buf = _get_buffer()
    buf.append(("return", code, retval, None, now, depth, duration_ms))
    if len(buf) >= _FLUSH_EVERY:
        _flush()


def _on_raise(code, instruction_offset: int, exception):
    if not _active or not _should_watch(code):
        return

    pending = _get_pending()
    now = datetime.now(tz=timezone.utc)
    start = pending.pop(id(code), None)
    depth = _get_call_depth()
    duration_ms: float | None = None
    if start is not None:
        duration_ms = (now - start).total_seconds() * 1000
        _local.call_depth = max(0, depth - 1)

    buf = _get_buffer()
    buf.append(("raise", code, exception, None, now, depth, duration_ms))
    if len(buf) >= _FLUSH_EVERY:
        _flush()


# ---------------------------------------------------------------------------
# Flush helpers
# ---------------------------------------------------------------------------


def _flush_all_threads() -> None:
    """Drain every registered thread-local buffer.  Called from the timer thread."""
    with _lock:
        buffers = list(_all_buffers)
    for buf in buffers:
        if buf:
            snapshot, buf[:] = buf[:], []
            _write_records(snapshot)


def _flush() -> None:
    """Convert buffered events to TruthRecords and write to SQLite."""
    buf = _get_buffer()
    if not buf:
        return
    snapshot, _local.records = buf[:], []
    # Re-register the new empty list so the timer thread can find it
    with _lock:
        if buf in _all_buffers:
            idx = _all_buffers.index(buf)
            _all_buffers[idx] = _local.records
        else:
            _all_buffers.append(_local.records)
    _write_records(snapshot)


def _write_records(snapshot: list) -> None:
    """Convert raw event tuples to TruthRecords and write to SQLite."""

    from cairn.store.schema import TruthRecord
    from cairn.store.writer import Writer

    records: list[TruthRecord] = []
    for event in snapshot:
        kind = event[0]
        code = event[1]
        now: datetime = event[4]

        filename: str = code.co_filename or ""
        qualname: str = getattr(code, "co_qualname", code.co_name)
        domain = _domain_from_file(filename)

        depth: int | None = event[5] if len(event) > 5 else None
        duration_ms: float | None = event[6] if len(event) > 6 else None

        if kind == "call":
            content = f"CALL {qualname}"
        elif kind == "return":
            retval = event[2]
            content = f"RETURN {qualname} → {_safe_repr(retval)}"
        else:  # raise
            exc = event[2]
            content = f"RAISE {qualname} {type(exc).__name__}: {_safe_repr(exc)}"

        records.append(TruthRecord(
            source="monitor",
            domain=domain,
            content=content,
            confidence=1.0,
            occurred_at=now,
            source_file=filename or None,
            source_line=code.co_firstlineno or None,
            exception_type=type(event[2]).__name__ if kind == "raise" else None,
            duration_ms=duration_ms,
            call_depth=depth,
        ))

    try:
        with Writer(_db_path) as w:
            w.write_many(records)
    except Exception:
        pass  # never crash user code


def _domain_from_file(filename: str) -> str:
    """Best-effort: derive a domain name from the source file path."""
    try:
        parts = Path(filename).parts
        # Walk up from the file looking for the top-level package name
        for i in range(len(parts) - 1, -1, -1):
            if parts[i].endswith(".py"):
                continue
            if parts[i] not in ("src", "lib", ""):
                return parts[i]
    except Exception:
        pass
    return Path(filename).stem if filename else "unknown"


def _safe_repr(v, limit: int = 120) -> str:
    try:
        r = repr(v)
        return r if len(r) <= limit else r[:limit] + "…"
    except Exception:
        return "<unrepresentable>"
