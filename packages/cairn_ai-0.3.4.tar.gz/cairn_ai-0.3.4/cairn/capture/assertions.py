"""Structured capture of assertion failures.

Pytest FAIL records stored the assertion message as pretty-printed text:
``AssertionError: 42 != 43``. That's searchable but not computable — you
can't ask "show me all tests whose assertion diff is numeric and ≤ 5" or
"flag tests where the same assertion fails with different values on
different runs" (classic flaky-test signature).

This module parses common assertion shapes into structured fields and
attaches them to the record's content as a JSON trailer. A companion
helper — ``flaky_tests(records)`` — finds tests whose assertions fail with
multiple distinct right-hand-side values, which is the strongest pure
signal of flakiness without running the test again.
"""

from __future__ import annotations

import ast
import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass

_BINOP_RE = re.compile(
    r"AssertionError:\s*(?P<lhs>.+?)\s*(?P<op>==|!=|<=|>=|<|>|is not|is)\s*(?P<rhs>.+?)\s*$",
    re.DOTALL,
)

# assertIn / assertNotIn + pytest rewriter variants:
#   "AssertionError: 'x' not in ['a','b']"
#   "AssertionError: 'x' in ['a','b','x']"
_IN_RE = re.compile(
    r"AssertionError:\s*(?P<lhs>.+?)\s+(?P<op>not in|in)\s+(?P<rhs>.+?)\s*$",
    re.DOTALL,
)

# pytest.approx shows up as:
#   "AssertionError: assert 1.0 == 1.01 ± 0.001"
_APPROX_RE = re.compile(
    r"AssertionError:\s*assert\s+(?P<lhs>[0-9.eE+\-]+)\s*==\s*"
    r"(?P<rhs>[0-9.eE+\-]+)\s*(?:±|\+/-)\s*(?P<tol>[0-9.eE+\-]+)",
)

# pytest.raises with no exception:
#   "Failed: DID NOT RAISE <class 'ValueError'>"
# and pytest.raises wrong-type:
#   "AssertionError: Regex pattern '...' does not match '...'"
_DID_NOT_RAISE_RE = re.compile(
    r"Failed:\s*DID NOT RAISE\s*<class\s*'(?P<exc>[^']+)'>",
)


@dataclass
class ParsedAssertion:
    op: str
    lhs: str
    rhs: str
    lhs_type: str | None = None
    rhs_type: str | None = None
    numeric_delta: float | None = None


def parse_assertion(message: str) -> ParsedAssertion | None:
    """Parse a single-line assertion message into structured fields.

    Recognised shapes, in priority order:

      1. ``pytest.approx``:  ``assert 1.0 == 1.01 ± 0.001``
      2. ``pytest.raises`` that didn't raise:  ``DID NOT RAISE <class 'X'>``
      3. Membership: ``'x' in ['a','b','x']`` / ``'x' not in [...]``
      4. Binary comparison: ``==``, ``!=``, ``<``, ``>``, ``<=``, ``>=``,
         ``is``, ``is not``

    Returns None when none match — callers treat the original content as opaque.
    """
    stripped = message.strip()

    # 1. approx
    m = _APPROX_RE.search(stripped)
    if m:
        lhs, rhs, tol = m.group("lhs"), m.group("rhs"), m.group("tol")
        approx_delta: float | None
        try:
            approx_delta = float(rhs) - float(lhs)
        except ValueError:
            approx_delta = None
        return ParsedAssertion(
            op="approx",
            lhs=lhs,
            rhs=f"{rhs} ± {tol}",
            lhs_type="float",
            rhs_type="float",
            numeric_delta=approx_delta,
        )

    # 2. DID NOT RAISE
    m = _DID_NOT_RAISE_RE.search(stripped)
    if m:
        return ParsedAssertion(
            op="did_not_raise",
            lhs="<no exception>",
            rhs=m.group("exc"),
            lhs_type=None,
            rhs_type="type",
            numeric_delta=None,
        )

    # 3. membership (try before binop so "in" doesn't confuse "==")
    m = _IN_RE.search(stripped)
    if m:
        return ParsedAssertion(
            op=m.group("op"),
            lhs=m.group("lhs")[:200],
            rhs=m.group("rhs")[:200],
            lhs_type=_infer_literal_type(m.group("lhs")),
            rhs_type=_infer_literal_type(m.group("rhs")),
            numeric_delta=None,
        )

    # 4. binop
    m = _BINOP_RE.search(stripped)
    if not m:
        return None
    lhs, rhs, op = m.group("lhs"), m.group("rhs"), m.group("op")
    lhs_t = _infer_literal_type(lhs)
    rhs_t = _infer_literal_type(rhs)
    delta: float | None = None
    if lhs_t in ("int", "float") and rhs_t in ("int", "float"):
        try:
            delta = float(ast.literal_eval(rhs)) - float(ast.literal_eval(lhs))
        except Exception:
            pass
    return ParsedAssertion(
        op=op,
        lhs=lhs[:200],
        rhs=rhs[:200],
        lhs_type=lhs_t,
        rhs_type=rhs_t,
        numeric_delta=delta,
    )


def _infer_literal_type(s: str) -> str | None:
    s = s.strip()
    if not s:
        return None
    try:
        v = ast.literal_eval(s)
    except Exception:
        return None
    return type(v).__name__


def append_structured_assertion(content: str) -> str:
    """If the content begins with a pytest FAIL and contains an assertion
    shape we recognise, append a ``# cairn-assert: {json}`` trailer so the
    structured fields are searchable without re-parsing.

    Idempotent: existing trailers are left alone.
    """
    if "cairn-assert:" in content or "AssertionError" not in content:
        return content
    # Look for the first line containing AssertionError
    for line in content.splitlines():
        if "AssertionError" in line:
            parsed = parse_assertion(line)
            if parsed is None:
                return content
            payload = json.dumps(asdict(parsed), separators=(",", ":"))
            return content.rstrip() + f"\ncairn-assert: {payload}\n"
    return content


# ---------------------------------------------------------------------------
# Flaky detection
# ---------------------------------------------------------------------------


@dataclass
class FlakyTest:
    test_id: str
    distinct_rhs: list[str]
    observation_count: int


def flaky_tests(records: "list[object]") -> list[FlakyTest]:
    """Return tests where the same FAIL nodeid has been observed with more
    than one distinct assertion rhs — classic flaky signature."""
    by_test: dict[str, set[str]] = defaultdict(set)
    count_by_test: dict[str, int] = defaultdict(int)
    for r in records:
        source = getattr(r, "source", None)
        if source != "pytest":
            continue
        content: str = getattr(r, "content", "") or ""
        first_line = content.splitlines()[0] if content else ""
        if not first_line.startswith("FAIL "):
            continue
        nodeid = first_line[len("FAIL "):].strip()
        parsed = None
        for line in content.splitlines():
            if "AssertionError" not in line:
                continue
            candidate = parse_assertion(line)
            if candidate is not None:
                parsed = candidate
                break
        if parsed is None:
            continue
        by_test[nodeid].add(parsed.rhs)
        count_by_test[nodeid] += max(1, getattr(r, "observation_count", 1) or 1)
    return [
        FlakyTest(
            test_id=nodeid,
            distinct_rhs=sorted(rhs_set),
            observation_count=count_by_test[nodeid],
        )
        for nodeid, rhs_set in sorted(by_test.items())
        if len(rhs_set) >= 2
    ]
