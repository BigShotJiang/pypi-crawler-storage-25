"""Git linker — correlate commits with test/error deltas from the truth store.

For each commit in the recent range, we:

1. Extract changed ``.py`` files via ``git diff-tree``.
2. Cross-reference those files against existing TruthRecords in the store
   (by ``source_file``).
3. Emit a TruthRecord per commit that had correlated failures — noting which
   files changed and how many active failure records those files carry.

This gives the distillation pass a "commit X touched files that already had
N failure records" signal, which will eventually feed into "which commits are
riskiest" context snippets for the agent.

A future pass will re-run the test suite at each commit SHA to get precise
before/after deltas; the current implementation is purely correlative and
requires no checkout or re-execution.
"""

from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path

from cairn.store.schema import TruthRecord

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def link_commits(
    repo_root: Path,
    since: str = "HEAD~10",
    db_path: Path | None = None,
    subtree: Path | None = None,
) -> list[TruthRecord]:
    """Walk recent commits and emit correlation TruthRecords.

    Args:
        repo_root: path to the git repository root.
        since:     git revision expression for the start of the range.
        db_path:   path to the SQLite store (used to load existing records for
                   cross-referencing).  Defaults to ``.cairn/store.db`` under
                   *repo_root*.
        subtree:   optional path *inside* repo_root. When set, only changes
                   that touch this subtree are considered — monorepos can
                   scope a service's store to its own directory without
                   correlating every repo-wide commit.

    Returns:
        List of TruthRecord objects with ``source="git"``.
    """
    repo_root = repo_root.resolve()
    if db_path is None:
        db_path = repo_root / ".cairn" / "store.db"
    subtree_resolved = subtree.resolve() if subtree else None
    if subtree_resolved and not str(subtree_resolved).startswith(str(repo_root)):
        raise ValueError(
            f"subtree {subtree_resolved} is not inside repo_root {repo_root}"
        )

    commits = _get_commits(repo_root, since)
    if not commits:
        return []

    # Load existing failure records and index by source_file for fast lookup
    file_to_failures = _index_failures(db_path)

    records: list[TruthRecord] = []
    subtree_prefix = f"{subtree_resolved}/" if subtree_resolved else None
    for sha, subject, ts in commits:
        changed_py = _changed_py_files(repo_root, sha)
        if subtree_prefix:
            changed_py = [p for p in changed_py if p.startswith(subtree_prefix)]
        if not changed_py:
            continue

        correlated: dict[str, int] = {}
        for f in changed_py:
            count = file_to_failures.get(f, 0)
            if count:
                correlated[f] = count

        # Emit one record per commit (even with zero correlation — useful baseline)
        total_failures = sum(correlated.values())
        if correlated:
            details = "; ".join(
                f"{Path(f).name}({n} failure{'s' if n != 1 else ''})"
                for f, n in sorted(correlated.items(), key=lambda kv: -kv[1])
            )
            content = (
                f"GIT {sha[:12]} {subject}\n"
                f"changed {len(changed_py)} .py file(s), "
                f"{len(correlated)} with existing failure records\n"
                f"correlated: {details}"
            )
            confidence = min(1.0, 0.5 + 0.1 * total_failures)
        else:
            content = (
                f"GIT {sha[:12]} {subject}\n"
                f"changed {len(changed_py)} .py file(s), no correlated failure records"
            )
            confidence = 0.3

        records.append(
            TruthRecord(
                source="git",
                domain=_domain_from_root(repo_root),
                content=content,
                confidence=confidence,
                occurred_at=ts,
                source_file=None,
            )
        )

    return records


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------


def _run(args: list[str], cwd: Path) -> str:
    """Run a git command and return stdout; return empty string on failure."""
    try:
        result = subprocess.run(
            args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return ""
        return result.stdout.strip()
    except Exception:
        return ""


def _get_commits(repo_root: Path, since: str) -> list[tuple[str, str, datetime]]:
    """Return list of (sha, subject, authored_at) for commits in range."""
    out = _run(
        ["git", "log", since + "..HEAD", "--format=%H\x1f%s\x1f%aI"],
        repo_root,
    )
    if not out:
        # Fallback: just get the last 10 commits if the range is invalid
        out = _run(
            ["git", "log", "-10", "--format=%H\x1f%s\x1f%aI"],
            repo_root,
        )
    if not out:
        return []

    results = []
    for line in out.splitlines():
        parts = line.split("\x1f", 2)
        if len(parts) != 3:
            continue
        sha, subject, iso = parts
        try:
            ts = datetime.fromisoformat(iso)
        except ValueError:
            ts = datetime.now(tz=timezone.utc)
        results.append((sha.strip(), subject.strip(), ts))
    return results


def _changed_py_files(repo_root: Path, sha: str) -> list[str]:
    """Return normalised absolute paths of .py files changed in this commit.

    Paths are resolved through ``Path.resolve()`` so that symlinks, ``../``
    traversal, and platform-specific separators (Windows \\) all collapse
    to a single canonical form. This is required for cross-referencing with
    ``source_file`` entries in the store — without resolution, a symlinked
    ``src/foo.py`` would miss failures recorded against the real path.
    """
    out = _run(
        ["git", "diff-tree", "--no-commit-id", "-r", "--name-only", sha],
        repo_root,
    )
    if not out:
        return []
    resolved_root = repo_root.resolve()
    paths: list[str] = []
    for f in out.splitlines():
        if not f.endswith(".py"):
            continue
        try:
            p = (resolved_root / f).resolve()
        except OSError:
            continue
        paths.append(str(p))
    return paths


# ---------------------------------------------------------------------------
# Store helpers
# ---------------------------------------------------------------------------


def _index_failures(db_path: Path) -> dict[str, int]:
    """Return dict: source_file → count of failure records in the store."""
    if not db_path.exists():
        return {}
    try:
        from cairn.store.writer import get_all
        records = get_all(db_path)
    except Exception:
        return {}

    index: dict[str, int] = {}
    for r in records:
        if not r.source_file:
            continue
        if not ("FAIL" in r.content or r.exception_type):
            continue
        try:
            key = str(Path(r.source_file).resolve())
        except OSError:
            key = r.source_file
        index[key] = index.get(key, 0) + 1
    return index


# ---------------------------------------------------------------------------
# Misc helpers
# ---------------------------------------------------------------------------


def _domain_from_root(root: Path) -> str:
    return root.name


def blame_records(
    repo_root: Path,
    db_path: Path | None = None,
) -> list[TruthRecord]:
    """Run git blame on source lines that have failure records.

    For each failure record with a source_file and source_line, runs
    ``git blame`` on that line and records the author/commit, giving
    the agent who-to-ask-about context for failures.

    Returns:
        List of TruthRecord objects with ``source="git"`` and
        ``pattern_cluster="blame"``.
    """
    if db_path is None:
        db_path = repo_root / ".cairn" / "store.db"
    if not db_path.exists():
        return []

    try:
        from cairn.store.writer import get_all
        all_records = get_all(db_path)
    except Exception:
        return []

    # Collect unique (file, line) pairs from failure records
    targets: dict[tuple[str, int], list[TruthRecord]] = {}
    for r in all_records:
        if r.source_file and r.source_line and (
            "FAIL" in r.content or r.exception_type
        ):
            key = (r.source_file, r.source_line)
            targets.setdefault(key, []).append(r)

    results: list[TruthRecord] = []
    domain = _domain_from_root(repo_root)
    now = datetime.now(tz=timezone.utc)

    for (filepath, lineno), recs in targets.items():
        blame_info = _blame_line(repo_root, filepath, lineno)
        if not blame_info:
            continue
        sha, author, date_str = blame_info
        content = (
            f"BLAME {Path(filepath).name}:{lineno}\n"
            f"commit {sha[:12]} by {author} ({date_str})\n"
            f"associated with {len(recs)} failure record(s)"
        )
        results.append(
            TruthRecord(
                source="git",
                domain=domain,
                content=content,
                confidence=0.5,
                occurred_at=now,
                source_file=filepath,
                source_line=lineno,
                pattern_cluster="blame",
            )
        )

    return results


def _blame_line(
    repo_root: Path, filepath: str, lineno: int
) -> tuple[str, str, str] | None:
    """Run git blame on a single line. Returns (sha, author, date) or None."""
    out = _run(
        [
            "git", "blame", "-L", f"{lineno},{lineno}",
            "--porcelain", "--", filepath,
        ],
        repo_root,
    )
    if not out:
        return None
    sha = ""
    author = ""
    date_str = ""
    for line in out.splitlines():
        if not sha and len(line) >= 40 and line[0] != '\t':
            sha = line.split()[0]
        elif line.startswith("author "):
            author = line[len("author "):]
        elif line.startswith("author-time "):
            try:
                ts = int(line.split()[1])
                date_str = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")
            except (ValueError, IndexError):
                pass
    if sha and author:
        return sha, author, date_str
    return None

