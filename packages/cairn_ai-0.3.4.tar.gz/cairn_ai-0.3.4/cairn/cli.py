"""Cairn CLI — cairn status / cairn distill / cairn context / cairn serve."""

from __future__ import annotations

from pathlib import Path

import click

from cairn.config import get_config
from cairn.store.writer import count, get_all


def _default_db() -> str:  # callable default so Click re-evaluates per call
    return get_config()["db"]


_DEFAULT_DB = Path(".cairn") / "store.db"


@click.group()
@click.version_option(package_name="cairn")
def main() -> None:
    """Cairn — runtime signal capture and distillation for AI-assisted Python development."""


# ---------------------------------------------------------------------------
# cairn stability & cairn rollback-check  (success-signal surfaces)
# ---------------------------------------------------------------------------


@main.command("stability")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--top", default=20, show_default=True, help="Maximum modules to list.")
def stability_cmd(db: str, top: int) -> None:
    """Show per-module pass/fail rates — flags safe-to-refactor vs flaky modules."""
    from cairn.distill.stability import module_stability

    db_path = Path(db)
    if not db_path.exists():
        click.echo("No store found. Run your tests first.")
        return
    mods = module_stability(db_path)
    if not mods:
        click.echo("No pytest records in the store yet.")
        return
    click.echo(f"{'MODULE':40s} {'PASS':>6s} {'FAIL':>6s} {'RATE':>6s}  STREAK")
    for m in mods[:top]:
        streak = "clean" if m.fail_count == 0 else f"{m.streak_days:.1f}d"
        click.echo(
            f"{m.module[:40]:40s} {m.pass_count:>6d} {m.fail_count:>6d} "
            f"{m.pass_rate:>5.0%}  {streak}"
        )


@main.command("flaky")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
def flaky_cmd(db: str) -> None:
    """List tests whose assertion fails with >1 distinct value — likely flaky."""
    from cairn.capture.assertions import flaky_tests
    from cairn.store.writer import get_all

    db_path = Path(db)
    if not db_path.exists():
        click.echo("No store found.")
        return
    flakes = flaky_tests(get_all(db_path))
    if not flakes:
        click.echo("No flaky assertions detected.")
        return
    click.echo(f"{'TEST':60s} {'OBS':>5s}  DISTINCT RHS")
    for f in flakes:
        samples = ", ".join(f.distinct_rhs[:3])
        if len(f.distinct_rhs) > 3:
            samples += f", +{len(f.distinct_rhs) - 3}"
        click.echo(f"{f.test_id[:60]:60s} {f.observation_count:>5d}  {samples}")


@main.command("rollback-check")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--window", default=14, show_default=True, type=int,
              help="Days to look before/after each commit.")
@click.option("--min-delta", default=2, show_default=True, type=int,
              help="Minimum failure-count increase to flag a commit.")
def rollback_check_cmd(db: str, window: int, min_delta: int) -> None:
    """List commits correlated with a failure spike — rollback candidates."""
    from cairn.distill.stability import rollback_candidates

    db_path = Path(db)
    if not db_path.exists():
        click.echo("No store found.")
        return
    cands = rollback_candidates(db_path, window_days=window, min_delta=min_delta)
    if not cands:
        click.echo("No rollback candidates — no commits exceed the failure-spike threshold.")
        return
    click.echo(f"{'SHA':>10s}  {'Δfails':>7s}  SUBJECT")
    for c in cands:
        click.echo(f"{c.commit_sha[:10]:>10s}  {c.delta:>+7d}  {c.commit_subject[:70]}")


# ---------------------------------------------------------------------------
# cairn status
# ---------------------------------------------------------------------------


@main.command()
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
def status(db: str) -> None:
    """Show a summary of the local truth store."""
    db_path = Path(db)
    if not db_path.exists():
        click.echo("No .cairn/store.db found. Run your tests first.")
        return

    totals = count(db_path)
    if not totals:
        click.echo("Store is empty.")
        return

    total = sum(totals.values())
    click.echo(f"Truth store: {db_path}")
    click.echo(f"Total records: {total}")
    click.echo("")
    click.echo("By source:")
    for source, n in sorted(totals.items()):
        click.echo(f"  {source:12s} {n:>6d}")

    # Decay-adjusted summary
    from datetime import datetime, timezone
    from cairn.distill.decay import apply_decay
    records = get_all(db_path)
    now = datetime.now(tz=timezone.utc)
    live = apply_decay(records, as_of=now)
    stale = len(records) - len(live)
    click.echo("")
    click.echo(f"Active (decayed conf > 0.05): {len(live)}  Stale: {stale}")

    # Cluster breakdown from distilled records
    distilled = [r for r in records if r.source == "distill"]
    if distilled:
        click.echo("")
        click.echo("Distilled clusters:")
        for r in sorted(distilled, key=lambda x: -x.confidence):
            name = r.content.splitlines()[0].removeprefix("PATTERN ").strip()
            click.echo(f"  {r.pattern_cluster or '?':30s}  {name}  (conf {r.confidence:.2f})")

    # Show the 5 most recent failures
    failures = [r for r in records if "FAIL" in r.content][:5]
    if failures:
        click.echo("")
        click.echo("Recent failures:")
        for r in failures:
            first_line = r.content.splitlines()[0]
            click.echo(f"  [{r.occurred_at.strftime('%Y-%m-%d %H:%M')}] {first_line}")


# ---------------------------------------------------------------------------
# cairn stats
# ---------------------------------------------------------------------------


@main.command("stats")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
def stats_cmd(db: str) -> None:
    """Print a summary of truth-store contents.

    Shows record counts by source and domain, confidence distribution, the
    number of named pattern clusters, and when the store was last written.
    """
    from collections import Counter
    from datetime import datetime, timezone
    from pathlib import Path as _Path

    from cairn.distill.decay import decayed_confidence
    from cairn.store.writer import get_all

    db_path = _Path(db)
    if not db_path.exists():
        click.echo("No store found. Run tests or 'cairn scan' first.")
        return

    records = get_all(db_path)
    if not records:
        click.echo("Store is empty.")
        return

    now = datetime.now(tz=timezone.utc)

    by_source: Counter = Counter(r.source for r in records)
    by_domain: Counter = Counter(r.domain for r in records)
    clusters = {r.pattern_cluster for r in records if r.pattern_cluster}

    confs = [decayed_confidence(r, now) for r in records]
    hi   = sum(1 for c in confs if c >= 0.7)
    mid  = sum(1 for c in confs if 0.3 <= c < 0.7)
    lo   = sum(1 for c in confs if c < 0.3)

    occurred_times = []
    for r in records:
        t = r.occurred_at
        if t.tzinfo is None:
            t = t.replace(tzinfo=timezone.utc)
        occurred_times.append(t)
    last_write = max(occurred_times)
    age_days = (now - last_write).days

    click.echo(f"Truth store: {db_path}  ({len(records)} records total)\n")

    click.echo("By source:")
    for src, n in sorted(by_source.items()):
        click.echo(f"  {src:<12s} {n:>5d}")

    click.echo("\nBy domain:")
    for dom, n in sorted(by_domain.items()):
        click.echo(f"  {dom:<20s} {n:>5d}")

    click.echo(f"\nPattern clusters: {len(clusters)}")

    click.echo("\nConfidence distribution (decayed):")
    click.echo(f"  high  (≥0.7): {hi:>5d}")
    click.echo(f"  mid   (0.3–0.7): {mid:>4d}")
    click.echo(f"  low   (<0.3): {lo:>5d}")

    click.echo(f"\nLast write: {last_write.strftime('%Y-%m-%d %H:%M UTC')}  ({age_days}d ago)")


# ---------------------------------------------------------------------------
# cairn distill
# ---------------------------------------------------------------------------


@main.command()
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--keep-history",
    is_flag=True,
    default=False,
    help="Keep previous distill records instead of replacing them (default: replace).",
)
@click.option(
    "--use-llm",
    is_flag=True,
    default=False,
    help="Use LLM-assisted cluster naming via OpenRouter (requires OPENROUTER_API_KEY).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Show what would be written without touching the store.",
)
@click.option(
    "--analyze-health/--no-analyze-health",
    default=None,
    help=(
        "Run margin-powered health/drift/causality/escalation analysis after "
        "clustering. Default: on when the `margin` package is installed, off "
        "otherwise. Pass --no-analyze-health to skip even when available."
    ),
)
@click.option(
    "--policy-exit-halt/--no-policy-exit-halt",
    default=False,
    help=(
        "Exit with status 3 when any cluster escalates to HALT. Useful as a "
        "pre-commit / CI gate that blocks shipping on novel anomalous patterns."
    ),
)
def distill(
    db: str,
    keep_history: bool,
    use_llm: bool,
    dry_run: bool,
    analyze_health: bool | None,
    policy_exit_halt: bool,
) -> None:
    """Cluster failures → name patterns → write distilled records.

    By default, previous distill records are replaced on each run to prevent
    stale pattern accumulation.  Pass --keep-history to append instead.
    Pass --dry-run to preview clusters without writing anything.

    Health analysis (drift / anomaly / causality / HALT-ALERT-LOG
    escalation) runs automatically when the `margin` package is installed.
    Use --no-analyze-health to skip it, --analyze-health to require it
    (exits non-zero if margin isn't installed), and --policy-exit-halt to
    turn HALT escalations into a non-zero exit code for CI gating.
    """
    from datetime import datetime, timezone
    from pathlib import Path as _Path

    from cairn.distill.cluster import cluster
    from cairn.distill.decay import apply_decay
    from cairn.distill.namer import name_cluster
    from cairn.store.schema import TruthRecord
    from cairn.store.writer import Writer, delete_by_source, get_all, tag_cluster

    db_path = _Path(db)
    if not db_path.exists():
        click.echo("No store found. Run tests or 'cairn scan' first.")
        return

    all_records = get_all(db_path)
    if not all_records:
        click.echo("Store is empty.")
        return

    live = apply_decay(all_records)
    clusters = cluster(live)

    now = datetime.now(tz=timezone.utc)
    distilled: list[TruthRecord] = []

    prefix = "[dry-run] " if dry_run else ""
    click.echo(f"{prefix}Distilling {len(live)} active records into {len(clusters)} cluster(s):\n")

    for cluster_key, members in clusters.items():
        name = name_cluster(members, use_llm=use_llm)
        avg_conf = sum(r.confidence for r in members) / len(members)
        click.echo(
            f"  [{members[0].source:8s}] {name}  "
            f"({len(members)} records, conf ≈ {avg_conf:.2f})"
        )

        # Write one distilled TruthRecord per cluster
        distilled.append(TruthRecord(
            source="distill",
            domain=members[0].domain,
            content=f"PATTERN {name}\n" + "\n".join(
                r.content.splitlines()[0] for r in members[:10]
            ),
            confidence=min(1.0, avg_conf + 0.05 * min(5, len(members))),
            occurred_at=now,
            pattern_cluster=cluster_key,
        ))

    if dry_run:
        click.echo(f"\nDry run — {len(distilled)} record(s) would be written. Nothing changed.")
        return

    # Replace previous distill records so stale patterns don't linger.
    # Skipped when --keep-history is passed.
    if not keep_history:
        cleared = delete_by_source("distill", db_path)
        if cleared:
            click.echo(f"Cleared {cleared} previous distill record(s).")

    with Writer(db_path) as w:
        w.write_many(distilled)

    # Write pattern_cluster back onto source records so context.py can use
    # the named labels without re-clustering on every run.
    for cluster_key, members in clusters.items():
        tag_cluster([r.id for r in members], cluster_key, db_path)

    click.echo(f"\nWrote {len(distilled)} distilled pattern record(s) to {db_path}.")

    # --- Margin-powered health analysis ---
    from cairn.distill.health import HAS_MARGIN, analyze_clusters

    if analyze_health is True and not HAS_MARGIN:
        click.echo(
            "Error: --analyze-health was requested but the `margin` package "
            "is not installed. Install with `pip install cairn-ai[health]`.",
            err=True,
        )
        raise SystemExit(2)

    run_health = HAS_MARGIN if analyze_health is None else analyze_health
    halt_count = 0
    if run_health and HAS_MARGIN:
        from cairn.distill.escalation import evaluate_all
        from cairn.distill.causality import build_causal_graph

        healths = analyze_clusters(clusters, as_of=now)
        escalations = evaluate_all(healths)
        causality = build_causal_graph(clusters, as_of=now)

        halt_count = sum(1 for e in escalations.values() if e.level == "HALT")
        alert_count = sum(1 for e in escalations.values() if e.level == "ALERT")

        click.echo(f"\n  Health analysis (margin): "
                   f"{halt_count} HALT, {alert_count} ALERT, "
                   f"{len(escalations) - halt_count - alert_count} LOG")

        for key, esc in escalations.items():
            if esc.level == "HALT":
                click.echo(f"    🔴 HALT  {key}: {esc.reason}")
            elif esc.level == "ALERT":
                click.echo(f"    🟡 ALERT {key}: {esc.reason}")

        if causality and causality.links:
            click.echo(f"\n  Causal links discovered: {len(causality.links)}")
            if causality.root_clusters:
                click.echo(f"    Root causes: {', '.join(causality.root_clusters)}")
    elif analyze_health is False:
        click.echo("\n  Health analysis skipped (--no-analyze-health).")

    click.echo("\nRun 'cairn context' to generate the agent context snippet.")

    if policy_exit_halt and halt_count > 0:
        click.echo(f"\nPolicy gate: {halt_count} HALT cluster(s) — exiting 3.", err=True)
        raise SystemExit(3)


# ---------------------------------------------------------------------------
# cairn query
# ---------------------------------------------------------------------------


@main.command("query")
@click.argument("q", metavar="QUERY", required=False, default="")
@click.option(
    "--db", "dbs", multiple=True, metavar="PATH",
    help="DB path to query (repeatable; defaults to the configured store).",
)
@click.option(
    "--domain", "domain_prefix", default="", metavar="PREFIX",
    help="Filter by domain prefix e.g. 'python/', 'python/stdlib'.",
)
@click.option("--top-k", default=10, show_default=True, help="Maximum results to return.")
@click.option(
    "--min-confidence", "min_confidence", default=0.0, show_default=True, type=float,
    help="Exclude records below this decayed-confidence threshold.",
)
@click.option("--source", default=None, metavar="SOURCE",
              help="Filter results to a specific source tag.")
@click.option("--since", default=None, metavar="DURATION",
              help="Only show records newer than this (e.g. 7d, 2w).")
@click.option("--json", "as_json", is_flag=True, help="Output results as a JSON array.")
def query_cmd(
    q: str,
    dbs: tuple[str, ...],
    domain_prefix: str,
    top_k: int,
    min_confidence: float,
    source: str | None,
    since: str | None,
    as_json: bool,
) -> None:
    """Search records across one or more cairn DBs.

    When multiple --db paths are given, results are federated and deduplicated
    by id (highest-confidence copy wins).  QUERY is optional; omit it to list
    records that match only the structural filters (domain, source, since).

    \b
    Examples:
      cairn query "async timeout"
      cairn query "ValueError" --source pytest --top-k 5
      cairn query "broad_except" --source ast --since 7d
      cairn query --db commons_python.db --db .cairn/store.db --domain python/ --top-k 20
      cairn query --db commons_python.db --domain python/ruff --json
    """
    import json as _json
    from datetime import datetime, timezone
    from pathlib import Path as _Path

    from cairn.distill.decay import decayed_confidence
    from cairn.store.query import from_dbs

    # Resolve DB list — fall back to configured default when none supplied.
    db_paths = [_Path(d) for d in dbs] if dbs else [_Path(get_config()["db"])]

    results = from_dbs(
        db_paths,
        domain_prefix=domain_prefix,
        min_confidence=min_confidence,
        top_k=top_k * 10 if q else None,   # wider pre-filter pool when we'll re-rank by keyword
    )

    if not results and not any(p.exists() for p in db_paths):
        click.echo("No store found. Run tests or 'cairn scan' first.")
        return

    # Keyword / Jaccard re-rank when a query is provided.
    if q:
        results = _keyword_rank(q, results)

    # Apply source filter.
    if source:
        results = [r for r in results if r.source == source]

    # Apply --since filter.
    if since:
        now = datetime.now(tz=timezone.utc)
        cutoff = _parse_duration(since, now)
        if cutoff is None:
            click.echo(f"Cannot parse duration {since!r}. Use e.g. 7d, 2w, 1m.", err=True)
            raise SystemExit(1)
        results = [
            r for r in results
            if (r.occurred_at.replace(tzinfo=timezone.utc)
                if r.occurred_at.tzinfo is None else r.occurred_at) >= cutoff
        ]

    results = results[:top_k]

    if not results:
        click.echo("No matching records found.")
        return

    now = datetime.now(tz=timezone.utc)

    if as_json:
        out = []
        for r in results:
            out.append({
                "id": r.id,
                "source": r.source,
                "domain": r.domain,
                "content": r.content,
                "confidence": round(decayed_confidence(r, now), 4),
                "occurred_at": r.occurred_at.isoformat(),
            })
        click.echo(_json.dumps(out, indent=2))
        return

    click.echo(f"{'#':<3}  {'SOURCE':<9} {'CONF':>5}  {'DOMAIN':<22}  {'AGE':>6}  CONTENT")
    click.echo("-" * 80)
    for i, r in enumerate(results, 1):
        occurred = r.occurred_at.replace(tzinfo=timezone.utc) if r.occurred_at.tzinfo is None else r.occurred_at
        age_days = (now - occurred).days
        age_str = f"{age_days}d" if age_days < 365 else f"{age_days // 365}y"
        conf = decayed_confidence(r, now)
        domain_col = (r.domain or "")[:22]
        first = r.content.splitlines()[0][:45]
        click.echo(f"{i:<3}  {r.source:<9} {conf:>5.2f}  {domain_col:<22}  {age_str:>6}  {first}")


# ---------------------------------------------------------------------------
# cairn config
# ---------------------------------------------------------------------------


@main.group("config")
def config_group() -> None:
    """Inspect or validate Cairn configuration."""


@config_group.command("show")
def config_show() -> None:
    """Print the resolved configuration (defaults merged with pyproject.toml)."""
    import json
    from cairn.config import get_config, _find_pyproject
    cfg = get_config(reload=True)
    pyproject = _find_pyproject()
    source = str(pyproject) if pyproject else "(built-in defaults only)"
    click.echo(f"Config source: {source}")
    click.echo(json.dumps(cfg, indent=2))


# ---------------------------------------------------------------------------
# cairn prune
# ---------------------------------------------------------------------------


@main.command("prune")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--older-than",
    "older_than",
    default=None,
    metavar="DURATION",
    help="Delete records older than this duration (e.g. 90d, 4w, 6m, 2y).",
)
@click.option(
    "--below-confidence",
    "below_confidence",
    default=None,
    type=float,
    metavar="THRESHOLD",
    help="Delete records whose current decayed confidence is below this value (0.0–1.0).",
)
@click.option(
    "--source",
    default=None,
    metavar="SOURCE",
    help="Restrict pruning to a specific source tag (pytest, monitor, ast, git, distill).",
)
@click.option("--dry-run", is_flag=True, help="Show what would be deleted without deleting.")
def prune(
    db: str,
    older_than: str | None,
    below_confidence: float | None,
    source: str | None,
    dry_run: bool,
) -> None:
    """Delete decayed or old records from the truth store.

    At least one filter (--older-than or --below-confidence) is required.
    Filters are ANDed: a record must satisfy ALL supplied conditions to be deleted.

    \b
    Examples:
      cairn prune --below-confidence 0.05
      cairn prune --older-than 90d --below-confidence 0.1
      cairn prune --older-than 30d --source ast --dry-run
    """
    from datetime import datetime, timedelta, timezone
    from pathlib import Path as _Path

    from cairn.distill.decay import decayed_confidence
    from cairn.store.writer import delete_by_ids, get_all

    if older_than is None and below_confidence is None:
        click.echo(
            "Error: supply at least one of --older-than or --below-confidence.",
            err=True,
        )
        raise SystemExit(1)

    db_path = _Path(db)
    if not db_path.exists():
        click.echo("No store found.")
        return

    records = get_all(db_path)
    if not records:
        click.echo("Store is empty.")
        return

    now = datetime.now(tz=timezone.utc)
    cutoff: datetime | None = None

    if older_than is not None:
        cutoff = _parse_duration(older_than, now)
        if cutoff is None:
            click.echo(
                f"Error: cannot parse duration {older_than!r}. "
                "Use e.g. 90d, 4w, 6m, 2y.",
                err=True,
            )
            raise SystemExit(1)

    to_delete = []
    for r in records:
        if source and r.source != source:
            continue
        if cutoff is not None:
            occurred = r.occurred_at
            if occurred.tzinfo is None:
                occurred = occurred.replace(tzinfo=timezone.utc)
            if occurred >= cutoff:
                continue  # not old enough
        if below_confidence is not None:
            eff = decayed_confidence(r, as_of=now)
            if eff >= below_confidence:
                continue  # confidence still above threshold
        to_delete.append(r)

    if not to_delete:
        click.echo("No records match the supplied criteria.")
        return

    # Show a brief summary grouped by source
    from collections import Counter
    by_src: Counter = Counter(r.source for r in to_delete)
    action = "Would delete" if dry_run else "Deleting"
    click.echo(f"{action} {len(to_delete)} record(s):")
    for src, n in sorted(by_src.items()):
        click.echo(f"  {src:12s} {n:>5d}")

    if dry_run:
        click.echo("\nDry run — nothing deleted. Re-run without --dry-run to apply.")
        return

    deleted = delete_by_ids([r.id for r in to_delete], db_path)
    click.echo(f"\nDeleted {deleted} record(s) from {db_path}.")


def _parse_duration(s: str, now: "datetime") -> "datetime | None":
    """Parse a compact duration string (e.g. 90d, 4w, 6m, 2y) into a cutoff datetime."""
    import re
    from datetime import timedelta

    m = re.fullmatch(r"(\d+)([dwmy])", s.strip().lower())
    if not m:
        return None
    n, unit = int(m.group(1)), m.group(2)
    if unit == "d":
        delta = timedelta(days=n)
    elif unit == "w":
        delta = timedelta(weeks=n)
    elif unit == "m":
        delta = timedelta(days=n * 30)
    else:  # y
        delta = timedelta(days=n * 365)
    return now - delta


def _keyword_rank(q: str, records: list) -> list:
    """Sort *records* by Jaccard token-overlap with *q*, descending.

    Records with zero overlap are retained (sorted to the bottom) so that
    callers can still apply a top-k cap and return something useful.
    """
    import re
    q_tokens = set(re.findall(r"\w+", q.lower()))
    if not q_tokens:
        return records

    def _score(r) -> float:
        r_tokens = set(re.findall(r"\w+", r.content.lower()))
        if not r_tokens:
            return 0.0
        return len(q_tokens & r_tokens) / len(q_tokens | r_tokens)

    return sorted(records, key=_score, reverse=True)


# ---------------------------------------------------------------------------
# cairn scan
# ---------------------------------------------------------------------------


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=True, dir_okay=True))
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--write/--no-write", default=True, show_default=True,
              help="Persist findings to the store (--no-write for dry run).")
@click.option("--with-coverage", default=None, metavar="COV_FILE",
              help="Import uncovered-line data from a .coverage file.")
@click.option("--with-branch-coverage", default=None, metavar="COV_FILE",
              help="Import untaken-branch arc data from a .coverage file (requires 'coverage run --branch').")
@click.option("--with-git", "with_git", is_flag=True, default=False,
              help="Run git linker to correlate recent commits with failures.")
@click.option("--since", "since", default="HEAD~10", show_default=True,
              help="Git revision range start for --with-git (e.g. HEAD~20, v1.0.0).")
@click.option("--blame", "blame", is_flag=True, default=False,
              help="Run git blame on failing source lines (requires --with-git).")
@click.option("--subtree", "git_subtree", default=None, metavar="PATH",
              help="Monorepo: restrict --with-git correlations to commits touching this subdirectory.")
@click.option("--exclude", "exclude_dirs", default=None, metavar="DIR,...",
              help="Comma-separated directory names to skip during scan (added to defaults).")
def scan(
    path: str,
    db: str,
    write: bool,
    with_coverage: str | None,
    with_branch_coverage: str | None,
    with_git: bool,
    since: str,
    blame: bool,
    git_subtree: str | None,
    exclude_dirs: str | None,
) -> None:
    """Run the AST scanner on PATH (file or directory) and persist findings.

    Pass --with-coverage to import uncovered-line data, or
    --with-branch-coverage for untaken-branch arc data (requires
    'coverage run --branch').
    Pass --with-git to correlate recent commits with failures (--since for range).
    Pass --blame (with --with-git) to record who last touched failing lines.
    Pass --exclude DIR,DIR to skip additional directories beyond defaults.
    """
    from pathlib import Path as _Path

    from cairn.capture.ast_scanner import scan as _scan
    from cairn.capture.ast_scanner import scan_project
    from cairn.store.writer import Writer

    target = _Path(path).resolve()
    extra_excludes = [d.strip() for d in exclude_dirs.split(",")] if exclude_dirs else None
    if target.is_file():
        records = _scan(target)
    else:
        records = scan_project(target, exclude=extra_excludes)

    # Optionally merge untested-branch data from coverage.py
    if with_coverage:
        from cairn.capture.coverage_reader import read_coverage
        cov_path = _Path(with_coverage)
        src_root = target if target.is_dir() else target.parent
        cov_records = read_coverage(cov_path, source_root=src_root)
        records.extend(cov_records)
        if cov_records:
            click.echo(
                f"Coverage: {len(cov_records)} untested-branch"
                f" record(s) from {cov_path}"
            )
        else:
            click.echo(
                f"Coverage: no data found in {cov_path}"
                " (install coverage.py or run 'coverage run pytest')"
            )

    # Optionally merge untaken-branch arc data
    if with_branch_coverage:
        from cairn.capture.coverage_reader import read_branch_coverage
        cov_path = _Path(with_branch_coverage)
        src_root = target if target.is_dir() else target.parent
        branch_records = read_branch_coverage(cov_path, source_root=src_root)
        records.extend(branch_records)
        if branch_records:
            click.echo(
                f"Branch coverage: {len(branch_records)} untaken-arc"
                f" record(s) from {cov_path}"
            )
        else:
            click.echo(
                f"Branch coverage: no arc data found in {cov_path}"
                " (run 'coverage run --branch pytest')"
            )

    # Optionally run git linker
    if with_git:
        from cairn.capture.git_linker import link_commits
        repo_root = target if target.is_dir() else target.parent
        db_path = _Path(db)
        subtree_path = _Path(git_subtree) if git_subtree else None
        git_records = link_commits(
            repo_root, since=since, db_path=db_path, subtree=subtree_path,
        )
        records.extend(git_records)
        if git_records:
            click.echo(f"Git linker: {len(git_records)} commit correlation(s) from {since}")
        else:
            click.echo(f"Git linker: no commits found in range {since}..HEAD")

        if blame:
            from cairn.capture.git_linker import blame_records
            blame_recs = blame_records(repo_root, db_path=db_path)
            records.extend(blame_recs)
            if blame_recs:
                click.echo(f"Git blame: {len(blame_recs)} line-level attribution(s)")
    elif blame:
        click.echo("Warning: --blame requires --with-git; skipping blame pass.", err=True)

    if not records:
        click.echo("No structural issues found.")
        return

    # Group by check type for summary
    from collections import Counter
    kinds: Counter = Counter()
    for r in records:
        kind = r.content.split(":")[0]
        kinds[kind] += 1

    click.echo(f"Found {len(records)} structural observations:")
    for kind, n in sorted(kinds.items()):
        click.echo(f"  {kind:25s} {n:>4d}")

    if write:
        db_path = _Path(db)
        with Writer(db_path) as w:
            w.write_many(records)
        click.echo(f"\nWritten to {db_path}")


# ---------------------------------------------------------------------------
# cairn context
# ---------------------------------------------------------------------------


@main.command("context")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--top", default=20, show_default=True, help="Maximum records to include.")
@click.option("--output", "-o", default=None, help="Write to file instead of stdout.")
@click.option(
    "--max-tokens",
    default=4000,
    show_default=True,
    type=int,
    help="Approximate token ceiling for the snippet. Set to 0 to disable.",
)
def context_cmd(db: str, top: int, output: str | None, max_tokens: int) -> None:
    """Print the agent context snippet to stdout (or --output file)."""
    from pathlib import Path as _Path

    from cairn.inject.context import build_context, estimate_tokens

    db_path = _Path(db)
    budget = max_tokens if max_tokens > 0 else None
    snippet = build_context(top_n=top, db_path=db_path, max_tokens=budget)

    if not snippet:
        click.echo("Store is empty or all records have decayed. Run tests or 'cairn scan' first.")
        return

    tokens = estimate_tokens(snippet)
    if output:
        out_path = _Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(snippet)
        click.echo(f"Context written to {out_path} (~{tokens} tokens)")
    else:
        click.echo(snippet)

# ---------------------------------------------------------------------------
# cairn serve
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default="127.0.0.1", show_default=True,
              help="Bind address (HTTP transport only).")
@click.option("--port", default=8765, show_default=True,
              help="TCP port (HTTP transport only).")
@click.option(
    "--transport",
    default="stdio",
    show_default=True,
    type=click.Choice(["stdio", "http"]),
    help="Transport: stdio (Cline/Claude Code) or http (SSE, for remote agents).",
)
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--token",
    default=None,
    envvar="CAIRN_TOKEN",
    show_default=False,
    help="Bearer token required for POST /ingest and POST /query (HTTP transport only). "
         "Can also be set via the CAIRN_TOKEN environment variable.",
)
def serve(host: str, port: int, transport: str, db: str, token: str | None) -> None:
    """Start the Cairn MCP server.

    stdio transport (default) — reads JSON-RPC from stdin, writes to stdout.
    Compatible with Cline, Claude Code, and any MCP-aware editor.

    http transport — exposes an HTTP + Server-Sent Events endpoint at
    http://<host>:<port>/sse.  Remote agents POST messages to /message and
    receive responses via the SSE stream.  Also exposes REST endpoints:

    \b
      POST /ingest   — push JSONL truth records (requires --token if set)
      POST /query    — semantic search (requires --token if set)
      GET  /health   — liveness check (always open)
    """
    from cairn.inject.mcp_server import serve as _serve
    if transport == "stdio":
        click.echo("Cairn MCP server running on stdio. Press Ctrl-C to stop.", err=True)
    _serve(host=host, port=port, transport=transport, db_path=db, token=token)


# ---------------------------------------------------------------------------
# cairn install
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# cairn watch
# ---------------------------------------------------------------------------


@main.command("watch")
@click.argument("target", metavar="MODULE_OR_SCRIPT")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--domains",
    default=None,
    metavar="PREFIX,...",
    help="Comma-separated module prefixes to monitor (default: everything non-stdlib).",
)
def watch_cmd(target: str, db: str, domains: str | None) -> None:
    """Instrument and run MODULE_OR_SCRIPT with sys.monitoring (Python 3.12+).

    TARGET can be:

      \b
      cairn watch myscript.py          # run a script
      cairn watch mypackage.mymodule   # run as 'python -m mypackage.mymodule'

    The monitor is active for the duration of the run.  Records are written to
    the truth store automatically.  Run 'cairn status' afterwards to see what
    was captured, or 'cairn distill' to cluster the new patterns.
    """
    import runpy
    import sys as _sys
    from pathlib import Path as _Path

    from cairn.capture.monitor import start as _start, stop as _stop

    if _sys.version_info < (3, 12):
        click.echo(
            f"Error: `cairn watch` requires Python 3.12+ (sys.monitoring / PEP 669). "
            f"You are running {_sys.version_info.major}.{_sys.version_info.minor}. "
            f"Use the @cairn.watch decorator on the functions you want to instrument, "
            f"or upgrade to Python 3.12+.",
            err=True,
        )
        raise SystemExit(2)

    db_path = _Path(db)
    domain_list = [d.strip() for d in domains.split(",")] if domains else None

    try:
        _start(domains=domain_list, db_path=db_path)
    except RuntimeError as exc:
        click.echo(f"Error: {exc}", err=True)
        raise SystemExit(1) from exc

    click.echo(f"Monitor active. Running {target!r} …", err=True)
    try:
        target_path = _Path(target)
        if target_path.exists() and target_path.suffix == ".py":
            runpy.run_path(str(target_path), run_name="__main__")
        else:
            runpy.run_module(target, run_name="__main__", alter_sys=True)
    except SystemExit:
        pass
    except Exception as exc:
        click.echo(f"Target raised: {type(exc).__name__}: {exc}", err=True)
    finally:
        _stop()

    if db_path.exists():
        totals = count(db_path)
        total = sum(totals.values())
        click.echo(f"\nDone. Store now has {total} record(s).", err=True)
        click.echo("Run 'cairn status' for details or 'cairn distill' to cluster patterns.", err=True)


# ---------------------------------------------------------------------------
# cairn sync
# ---------------------------------------------------------------------------


@main.command("sync")
@click.argument("source_db", type=click.Path(exists=True))
@click.option("--db", default=_default_db, show_default=True, help="Destination store path.")
@click.option(
    "--reweight/--no-reweight",
    default=True,
    help=(
        "When a record already exists in the destination, increment its "
        "contributor_count and divide the incoming confidence by the new "
        "count. Prevents one noisy project from dominating the merged "
        "store. Default: on."
    ),
)
@click.option(
    "--source-tag",
    default=None,
    metavar="TAG",
    help=(
        "Tag every incoming record's pattern_cluster with this string so "
        "downstream analysis can see which store contributed which pattern. "
        "Default: leave pattern_cluster untouched."
    ),
)
def sync_cmd(source_db: str, db: str, reweight: bool, source_tag: str | None) -> None:
    """Merge records from SOURCE_DB into the local truth store.

    Records are upserted by content hash — duplicates collapse into a single
    row and observation_count increments. When --reweight is on (default), a
    record already seen in the destination has its confidence divided by the
    count of distinct contributing sources seen to date, so a failure
    reported by 50 projects doesn't outweigh one reported by a single project
    50×.

    \b
      # Pull a colleague's store into yours
      cairn sync /mnt/shared/.cairn/store.db

      # Merge a CI-produced store, tagged as ci
      cairn sync ci-artifacts/store.db --source-tag ci
    """
    from pathlib import Path as _Path

    from cairn.store.writer import Writer, get_all

    src = _Path(source_db)
    dst = _Path(db)

    src_records = get_all(src)
    if not src_records:
        click.echo(f"Source store {src} is empty — nothing to sync.")
        return

    existing_by_id: dict[str, object] = {}
    if dst.exists():
        existing_by_id = {r.id: r for r in get_all(dst)}

    duplicates = 0
    for r in src_records:
        if source_tag:
            r.pattern_cluster = source_tag
        if reweight and r.id in existing_by_id:
            duplicates += 1
            existing = existing_by_id[r.id]
            prior = max(1, getattr(existing, "contributor_count", 1) or 1)
            # Increment the destination's contributor_count. The stored
            # confidence itself stays high (MAX upsert); downweighting is
            # applied at read time via cairn.distill.decay, which divides
            # effective confidence by contributor_count. This keeps the
            # store authoritative about "was this observed at conf=X" and
            # lets the reader decide how to weigh cross-contributor
            # evidence.
            r.contributor_count = prior + 1
        else:
            # First-time observation from this store.
            r.contributor_count = max(1, r.contributor_count or 1)

    with Writer(dst) as w:
        w.write_many(src_records)

    click.echo(
        f"Synced {len(src_records)} record(s) from {src} → {dst} "
        f"({duplicates} already present; reweight={'on' if reweight else 'off'})."
    )


# ---------------------------------------------------------------------------
# cairn ingest
# ---------------------------------------------------------------------------


@main.command("ingest")
@click.argument("file", default="-", type=click.Path(allow_dash=True))
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--source",
    default=None,
    metavar="SOURCE",
    help="Override the 'source' field on every ingested record (e.g. nasti-js).",
)
@click.option(
    "--domain",
    default=None,
    metavar="DOMAIN",
    help="Override the 'domain' field on every ingested record.",
)
def ingest_cmd(file: str, db: str, source: str | None, domain: str | None) -> None:
    """Ingest TruthRecords from a JSONL file (or stdin) into the truth store.

    Each line must be a JSON object.  Only 'content' is required — all other
    fields default to sensible values.  Use --source and --domain to stamp
    every record with a fixed tag (useful when piping from nASTi-js, nASTi-go,
    or any other non-Python producer).

    \b
    Examples:
      nasti-js | cairn ingest --source nasti-js --domain myapp/src
      cairn ingest records.jsonl --source nasti-go
      cairn ingest -                         # read from stdin
    """
    import json
    import sys
    from datetime import datetime, timezone
    from pathlib import Path as _Path

    from cairn.store.schema import TruthRecord
    from cairn.store.writer import Writer

    cfg = get_config()
    default_domain = domain or cfg.get("domain") or "ingest"
    default_source = source or "ingest"
    now = datetime.now(tz=timezone.utc)

    if file == "-":
        lines = sys.stdin.readlines()
    else:
        lines = _Path(file).read_text(encoding="utf-8").splitlines()

    records: list[TruthRecord] = []
    errors = 0
    for i, raw in enumerate(lines, 1):
        raw = raw.strip()
        if not raw or raw.startswith("#"):
            continue
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError as exc:
            click.echo(f"Line {i}: invalid JSON — {exc}", err=True)
            errors += 1
            continue

        if "content" not in obj:
            click.echo(f"Line {i}: missing required field 'content' — skipped.", err=True)
            errors += 1
            continue

        # Parse occurred_at flexibly
        raw_ts = obj.get("occurred_at")
        if raw_ts:
            try:
                occurred_at = datetime.fromisoformat(raw_ts)
                if occurred_at.tzinfo is None:
                    occurred_at = occurred_at.replace(tzinfo=timezone.utc)
            except ValueError:
                occurred_at = now
        else:
            occurred_at = now

        rec = TruthRecord(
            source=source or obj.get("source", default_source),
            domain=domain or obj.get("domain", default_domain),
            content=obj["content"],
            confidence=float(obj.get("confidence", 1.0)),
            occurred_at=occurred_at,
            source_file=obj.get("source_file"),
            source_line=obj.get("source_line"),
            exception_type=obj.get("exception_type"),
            pattern_cluster=obj.get("pattern_cluster"),
            duration_ms=obj.get("duration_ms"),
            call_depth=obj.get("call_depth"),
            observation_count=int(obj.get("observation_count", 1)),
        )
        records.append(rec)

    if not records:
        click.echo(f"No valid records to ingest. ({errors} error(s))")
        raise SystemExit(1 if errors else 0)

    db_path = _Path(db)
    with Writer(db_path) as w:
        w.write_many(records)

    msg = f"Ingested {len(records)} record(s) into {db_path}."
    if errors:
        msg += f"  ({errors} line(s) skipped due to errors)"
    click.echo(msg)


# ---------------------------------------------------------------------------
# cairn install
# ---------------------------------------------------------------------------


@main.command("install")
@click.option("--context-path", default=".cairn/context.md", show_default=True,
              help="Path where cairn context.md will be written.")
@click.option(
    "--targets",
    default="claude,agents,copilot,cursor,continue",
    show_default=True,
    help="Comma-separated agent scaffolds to write. Options: "
         "claude, agents, copilot, cursor, continue.",
)
@click.option(
    "--force", is_flag=True, default=False,
    help="Overwrite existing scaffold files (normally skipped to preserve edits).",
)
def install_cmd(context_path: str, targets: str, force: bool) -> None:
    """Scaffold agent-instruction files that reference the Cairn context.

    Writes one file per selected target (CLAUDE.md, AGENTS.md,
    .github/copilot-instructions.md, .cursor/rules/cairn.mdc, .continuerules).
    Existing files are left untouched — safe to re-run.
    """
    from pathlib import Path as _Path

    from cairn.inject.cline import write_agent_scaffolds

    target_list = [t.strip() for t in targets.split(",") if t.strip()]
    written = write_agent_scaffolds(
        context_path=_Path(context_path),
        targets=target_list,
        force=force,
    )
    if written:
        click.echo("Wrote agent scaffolds:")
        for p in written:
            click.echo(f"  - {p}")
    else:
        click.echo("No new files written (all targets already exist).")
    click.echo(
        f"\nRun `cairn context -o {context_path}` to populate the context file, "
        f"or let the pytest plugin + post-commit hook keep it fresh."
    )


# ---------------------------------------------------------------------------
# cairn templates
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# cairn prime
# ---------------------------------------------------------------------------


@main.command("prime")
@click.argument("repo", type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.option(
    "--output", "-o",
    required=True,
    metavar="OUTPUT_DB",
    help="Path to write the baseline store (e.g. cpython-baseline.db).",
)
@click.option(
    "--domain",
    default=None,
    metavar="DOMAIN",
    help="Domain tag for written records (default: repository directory name).",
)
@click.option(
    "--filter", "fix_filter",
    default=None,
    metavar="REGEX",
    help=(
        "Extra regex pattern ANDed with the built-in fix/bug/cve/… filter. "
        "Default: built-in pattern only."
    ),
)
@click.option(
    "--since",
    default=None,
    metavar="DATE",
    help="Only include commits after this date (YYYY-MM-DD).",
)
@click.option(
    "--until",
    default=None,
    metavar="DATE",
    help="Only include commits before this date (YYYY-MM-DD).",
)
@click.option(
    "--limit",
    default=None,
    type=int,
    metavar="N",
    help="Stop after writing N records (useful for smoke tests).",
)
@click.option(
    "--batch-size",
    default=200,
    show_default=True,
    type=int,
    help="Commits examined between each write + checkpoint flush.",
)
@click.option("--verbose", "-v", is_flag=True, help="Print each accepted commit as it is processed.")
def prime_cmd(
    repo: str,
    output: str,
    domain: str | None,
    fix_filter: str | None,
    since: str | None,
    until: str | None,
    limit: int | None,
    batch_size: int,
    verbose: bool,
) -> None:
    """Ingest a git repository's history into a baseline truth store.

    Walks REPO's commit history, filters to high-signal commits (regression
    fixes, CVEs, test-correlated changes), and writes TruthRecords to
    OUTPUT_DB.  The resulting database is a "baseline" artifact that projects
    can seed with 'cairn sync'.

    \b
    Examples:
      # Build a CPython baseline from the full history
      cairn prime /opt/cpython --output cpython-baseline.db

      # Only commits since the Python 3.10 release
      cairn prime /opt/cpython --output cpython-3.10+.db --since 2021-10-04

      # Quick smoke test
      cairn prime . --output test-baseline.db --limit 50 --verbose

    The command is resumable: re-running with the same --output skips commits
    that were already examined, picking up where the previous run left off.
    """
    import re
    from pathlib import Path as _Path

    from cairn.capture.prime import DEFAULT_FIX_PATTERN, prime as _prime

    repo_path = _Path(repo).resolve()
    output_path = _Path(output)

    if fix_filter:
        try:
            pat = re.compile(fix_filter, re.IGNORECASE)
        except re.error as exc:
            click.echo(f"Error: invalid --filter pattern: {exc}", err=True)
            raise SystemExit(1)
    else:
        pat = DEFAULT_FIX_PATTERN

    click.echo(f"Priming from : {repo_path}")
    click.echo(f"Output       : {output_path}")
    if since or until:
        click.echo(f"Date range   : {since or '(all)'} → {until or 'now'}")
    if limit:
        click.echo(f"Limit        : {limit:,} records")
    click.echo()

    last_report: list[int] = [0]

    def _progress(examined: int, written: int) -> None:
        if examined - last_report[0] >= batch_size:
            click.echo(f"  examined {examined:>8,}  |  written {written:>7,}", err=True)
            last_report[0] = examined

    examined, written = _prime(
        repo_root=repo_path,
        output_db=output_path,
        domain=domain,
        fix_pattern=pat,
        batch_size=batch_size,
        limit=limit,
        since=since,
        until=until,
        verbose=verbose,
        progress_cb=_progress,
    )

    click.echo(f"Done.")
    click.echo(f"  Commits examined : {examined:,}")
    click.echo(f"  Records written  : {written:,}")
    click.echo(f"  Output           : {output_path}")
    if written > 0:
        click.echo(
            f"\nMerge into a project store with:\n"
            f"  cairn sync {output_path}"
        )


# ---------------------------------------------------------------------------
# cairn templates
# ---------------------------------------------------------------------------


@main.command("rules")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--project-root", default=".", show_default=True,
              help="Project root to look for ruff.toml / pyproject.toml in.")
@click.option("--apply", "do_apply", is_flag=True,
              help="Write the missing codes into the project's ruff config.")
def rules_cmd(db: str, project_root: str, do_apply: bool) -> None:
    """Diff cairn-implied ruff rules against the project's ruff config.

    Reads AST TruthRecords from the store, maps them to ruff codes, and
    compares against [tool.ruff.lint] select in pyproject.toml (or
    ruff.toml). Prints codes to add; pass --apply to write them in.
    """
    from pathlib import Path as _Path

    from cairn.distill.rules import apply_ruff_patch, ruff_config_diff
    from cairn.store.writer import get_all

    db_path = _Path(db)
    if not db_path.exists():
        click.echo("No store found. Run `cairn scan` to produce AST records first.")
        return
    records = get_all(db_path)
    diff = ruff_config_diff(records, project_root=_Path(project_root))

    where = diff["config_path"]
    if where is None:
        click.echo("No ruff config found (looked for ruff.toml / .ruff.toml / pyproject.toml).")
    else:
        click.echo(f"Ruff config: {where}")
    click.echo(f"Codes implied by cairn records: {sorted(diff['required']) or '(none)'}")
    click.echo(f"Codes currently enabled:        {sorted(diff['current']) or '(none)'}")
    if not diff["missing"]:
        click.echo("\nAll cairn-implied codes are already enabled.")
        return

    click.echo(f"\nMissing codes to enable: {sorted(diff['missing'])}")
    if do_apply:
        from cairn.distill.rules import RuffPatchRefused
        try:
            config_path, changed = apply_ruff_patch(
                diff["missing"], project_root=_Path(project_root),
            )
        except RuffPatchRefused as e:
            click.echo(f"\nRefusing to patch: {e}", err=True)
            click.echo(
                "Suggested pyproject.toml patch (apply manually):", err=True,
            )
            click.echo("  [tool.ruff.lint]", err=True)
            codes = sorted(diff["current"] | diff["required"])
            click.echo(f"  select = {codes}", err=True)
            raise SystemExit(4) from e
        if config_path is None:
            click.echo(
                "No ruff config file to patch. Create one first or copy the "
                "suggested block below."
            )
        elif changed:
            click.echo(f"Patched {config_path} in place.")
        else:
            click.echo(f"No changes written to {config_path} (already up to date).")
    else:
        click.echo("\nSuggested pyproject.toml patch:")
        click.echo("  [tool.ruff.lint]")
        codes = sorted(diff["current"] | diff["required"])
        click.echo(f"  select = {codes}")
        click.echo("\nRe-run with --apply to write this in place.")


@main.command("templates")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--output", "-o", default="tests/cairn_generated", show_default=True,
              help="Directory to write stub files into.")
@click.option("--markdown", is_flag=True,
              help="Write a single Markdown summary instead of .py files.")
def templates_cmd(db: str, output: str, markdown: bool) -> None:
    """Generate test stubs from observed function behaviour.

    Reads monitor TruthRecords and produces ready-to-edit pytest stub files,
    one per observed source module.  Stubs include Hypothesis @given skeletons
    when return types can be inferred from captured return values.
    """
    from pathlib import Path as _Path

    from cairn.distill.templates import generate_stubs, generate_stubs_markdown
    from cairn.store.writer import get_all

    db_path = _Path(db)
    if not db_path.exists():
        click.echo("No store found. Run monitored code or tests first.")
        return

    records = [r for r in get_all(db_path) if r.source == "monitor"]
    if not records:
        click.echo(
            "No monitor records found. Instrument functions"
            " with @cairn.watch or enable sys.monitoring."
        )
        return

    out_dir = _Path(output)

    if markdown:
        md = generate_stubs_markdown(records)
        if not md:
            click.echo("Nothing to generate.")
            return
        out_path = out_dir / "stubs.md" if out_dir.suffix == "" else out_dir
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(md, encoding="utf-8")
        click.echo(f"Markdown stubs written to {out_path}")
        return

    stubs = generate_stubs(records)
    if not stubs:
        click.echo("Nothing to generate: no CALL/RETURN records with function names found.")
        return

    out_dir.mkdir(parents=True, exist_ok=True)
    # Ensure the generated directory is a package and marked `cairn_generated`
    # so pytest collects it and users can exclude it with -m "not cairn_generated".
    init_path = out_dir / "__init__.py"
    if not init_path.exists():
        init_path.write_text(
            "# Auto-generated by `cairn templates`. Safe to edit; re-running\n"
            "# overwrites individual stub files but not this __init__.py.\n",
            encoding="utf-8",
        )
    conftest = out_dir / "conftest.py"
    if not conftest.exists():
        conftest.write_text(
            "import pytest\n\n"
            "def pytest_collection_modifyitems(config, items):\n"
            "    for item in items:\n"
            "        if 'cairn_generated' in str(item.fspath):\n"
            "            item.add_marker(pytest.mark.cairn_generated)\n",
            encoding="utf-8",
        )
    for stem, source in stubs.items():
        stub_path = out_dir / f"test_{stem}_cairn.py"
        stub_path.write_text(source, encoding="utf-8")
        click.echo(f"  {stub_path}")
    click.echo(f"\n{len(stubs)} stub file(s) written to {out_dir}/")
    click.echo(
        "Stubs are pytest-collectable as-is (marker: cairn_generated). "
        "Review and complete before committing; run with "
        "`pytest tests/cairn_generated` or `nox -s cairn_generated`."
    )


# ---------------------------------------------------------------------------
# cairn embed
# ---------------------------------------------------------------------------


@main.command("embed")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--repair",
    is_flag=True,
    default=False,
    help="Only embed records that are missing embeddings (skip already-embedded records).",
)
def embed_cmd(db: str, repair: bool) -> None:
    """Generate (or regenerate) vector embeddings for truth store records.

    Without --repair, every record is re-embedded — useful after switching
    embedding models or changing the dimensionality.

    With --repair, only records with a NULL embedding are processed.  Use this
    to backfill records written by non-Python producers (nASTi-js, nASTi-go,
    etc.) that arrived without embeddings.

    \b
    Examples:
      cairn embed --repair          # backfill missing embeddings
      cairn embed                   # re-embed everything (model upgrade)
    """
    from pathlib import Path as _Path

    from cairn.store.embedder import embed
    from cairn.store.writer import get_all, update_embeddings

    db_path = _Path(db)
    if not db_path.exists():
        click.echo("No store found.", err=True)
        raise SystemExit(1)

    records = get_all(db_path)
    if not records:
        click.echo("Store is empty.")
        return

    if repair:
        to_embed = [r for r in records if not r.embedding]
        if not to_embed:
            click.echo("All records already have embeddings — nothing to repair.")
            return
        click.echo(f"Backfilling embeddings for {len(to_embed)} record(s) …")
    else:
        to_embed = records
        click.echo(f"Re-embedding {len(to_embed)} record(s) …")

    try:
        embed(to_embed)
    except ImportError:
        click.echo(
            "sentence-transformers not installed — using hash-based fallback embeddings.\n"
            "Install cairn[embed] for real semantic embeddings.",
            err=True,
        )
        embed(to_embed)  # fallback path runs automatically inside embed()

    updated = update_embeddings(to_embed, db_path)
    click.echo(f"Updated embeddings for {updated} record(s) in {db_path}.")


# ---------------------------------------------------------------------------
# cairn export
# ---------------------------------------------------------------------------


# Sources that contain structural tool output — generally safe to donate.
# Sources excluded from strip-scope: pytest/monitor (test/function names identify
# the project), git (commit messages may contain org details), distill (synthesised
# descriptions may reference internal names).
_DONATABLE_SOURCES: frozenset[str] = frozenset({
    "flake8", "ruff", "mypy", "bandit", "coverage.py", "ast",
    "structlog", "eslint", "clippy",
})


def _strip_scope_record(r: "TruthRecord") -> "TruthRecord | None":
    """Return an anonymised copy of *r* suitable for public donation.

    Transforms applied:
    - domain: strip scope, keep language prefix only
      ``"python/acme.billing"`` → ``"python"``
      ``"python/ruff"``        → ``"python/ruff"``  (tool-scope = safe)
    - source_file: set to None (absolute paths identify the developer)
    - source_line: set to None
    - id: recomputed from (source, anonymised_domain, content) — untraceable
    - occurred_at: date kept, time zeroed to midnight (coarser fingerprint)

    Returns None if the record cannot be safely anonymised (no language prefix
    in domain, or empty content).
    """
    from datetime import datetime, timezone

    from cairn.store.schema import KNOWN_LANGUAGES

    domain = (r.domain or "").strip()
    if not domain:
        return None

    # Derive language prefix
    if "/" in domain:
        lang = domain.split("/", 1)[0].lower()
        scope = domain.split("/", 1)[1]
    else:
        lang = domain.lower()
        scope = ""

    if lang not in KNOWN_LANGUAGES:
        return None  # legacy or unrecognised domain — skip

    # Tool-level scopes (python/ruff, python/mypy, etc.) are safe to keep.
    # Org/project scopes (python/acme.billing) must be stripped to language.
    _TOOL_SCOPES: frozenset[str] = frozenset({
        "ruff", "mypy", "bandit", "coverage", "pytest", "ast", "flake8",
        "mypy-json", "bandit-json", "coverage-json", "pylint",
        "clippy", "eslint", "tslint",
    })
    if scope and scope.split(".")[0] in _TOOL_SCOPES:
        anon_domain = f"{lang}/{scope}"
    else:
        anon_domain = lang  # strip org scope entirely

    if not r.content or not r.content.strip():
        return None

    # Zero the time component of occurred_at so runs can't be cross-correlated
    # by exact timestamp.
    occurred_at_anon = datetime(
        r.occurred_at.year, r.occurred_at.month, r.occurred_at.day,
        tzinfo=timezone.utc,
    )

    from cairn.store.schema import TruthRecord as _TR
    anon = _TR(
        source=r.source,
        domain=anon_domain,
        content=r.content,
        confidence=r.confidence,
        occurred_at=occurred_at_anon,
        source_file=None,
        source_line=None,
        exception_type=r.exception_type,
        pattern_cluster=r.pattern_cluster,
        duration_ms=None,
        call_depth=None,
        observation_count=r.observation_count,
    )
    # id is computed by __post_init__ from (source, anon_domain, content) — correct.
    return anon


@main.command("export")
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option(
    "--format", "fmt", default="json", show_default=True,
    type=click.Choice(["json", "csv", "db"]),
    help=(
        "Output format.  Use 'db' with --strip-scope to write a donation-ready "
        "SQLite file directly into cairn-commons."
    ),
)
@click.option("--source", default=None, metavar="SOURCE",
              help="Filter to a specific source tag (pytest, monitor, ast, git, distill).")
@click.option("--output", "-o", default=None, help="Write to file instead of stdout.")
@click.option(
    "--strip-scope",
    "strip_scope",
    is_flag=True,
    default=False,
    help=(
        "Anonymise records for public donation: strip org scope from domain, "
        "clear source paths, rehash IDs, and drop non-donatable sources "
        "(pytest, monitor, git, distill).  Use --format db to write a SQLite "
        "donation file directly."
    ),
)
def export_cmd(
    db: str, fmt: str, source: str | None, output: str | None, strip_scope: bool,
) -> None:
    """Export the truth store as JSON, CSV, or a donation-ready SQLite file.

    Examples:

    \b
    # Standard JSON export
    cairn export --format json --output records.json

    \b
    # Prepare an anonymised SQLite db for donation to cairn-commons
    cairn export --strip-scope --format db --output ../cairn-commons/python/commons_python.db
    cairn export --strip-scope --format db \\
        --output ../cairn-commons/python/commons_acme.db
    """
    import csv
    import io
    import json as _json

    from cairn.store.writer import Writer, get_all

    db_path = Path(db)
    if not db_path.exists():
        click.echo("No store found.", err=True)
        raise SystemExit(1)

    records = get_all(db_path)
    if source:
        records = [r for r in records if r.source == source]

    if strip_scope:
        # Filter to donatable sources first
        donatable = [r for r in records if r.source in _DONATABLE_SOURCES]
        skipped_source = len(records) - len(donatable)

        anon_records = []
        skipped_domain = 0
        for r in donatable:
            anon = _strip_scope_record(r)
            if anon is None:
                skipped_domain += 1
            else:
                anon_records.append(anon)

        click.echo(
            f"strip-scope: {len(records)} total → "
            f"{len(anon_records)} donatable "
            f"({skipped_source} non-donatable source, "
            f"{skipped_domain} no-language-prefix skipped)",
            err=True,
        )
        records = anon_records

    if not records:
        click.echo("No records to export.", err=True)
        return

    if fmt == "db":
        # Write a SQLite donation file — merges (upserts) into an existing DB
        # so repeated donations from multiple users compound rather than reset.
        if not output:
            click.echo(
                "Error: --format db requires --output PATH (the destination SQLite file).",
                err=True,
            )
            raise SystemExit(1)
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        w = Writer(out_path)
        w.write_many(records)
        click.echo(
            f"Wrote {len(records)} record(s) to {out_path} "
            f"(upsert — existing records bumped confidence).",
            err=True,
        )
        return

    if fmt == "json":
        rows = []
        for r in records:
            rows.append({
                "id": r.id,
                "source": r.source,
                "domain": r.domain,
                "content": r.content,
                "confidence": r.confidence,
                "occurred_at": r.occurred_at.isoformat(),
                "source_file": r.source_file,
                "source_line": r.source_line,
                "exception_type": r.exception_type,
                "pattern_cluster": r.pattern_cluster,
                "observation_count": r.observation_count,
            })
        text = _json.dumps(rows, indent=2)
    else:  # csv
        buf = io.StringIO()
        fieldnames = [
            "id", "source", "domain", "content", "confidence", "occurred_at",
            "source_file", "source_line", "exception_type", "pattern_cluster",
            "observation_count",
        ]
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        for r in records:
            writer.writerow({
                "id": r.id,
                "source": r.source,
                "domain": r.domain,
                "content": r.content,
                "confidence": r.confidence,
                "occurred_at": r.occurred_at.isoformat(),
                "source_file": r.source_file,
                "source_line": r.source_line,
                "exception_type": r.exception_type,
                "pattern_cluster": r.pattern_cluster,
                "observation_count": r.observation_count,
            })
        text = buf.getvalue()

    if output:
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(text, encoding="utf-8")
        click.echo(f"Exported {len(records)} record(s) to {out_path}")
    else:
        click.echo(text)


# ---------------------------------------------------------------------------
# cairn annotate
# ---------------------------------------------------------------------------


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=True, dir_okay=True))
@click.option("--db", default=_default_db, show_default=True, help="Path to the SQLite store.")
@click.option("--dry-run", is_flag=True, help="Print diff without writing files.")
@click.option("--clear", is_flag=True, help="Remove all cairn annotations instead of adding them.")
def annotate(path: str, db: str, dry_run: bool, clear: bool) -> None:
    """Insert inline cairn annotations into Python source files.

    Adds '# cairn[source]: ...' comment lines above source locations that have
    associated records in the truth store.  Safe to re-run (idempotent).

    Use --clear to remove all cairn annotations from the target files.
    """
    import difflib
    import re

    if clear:
        target = Path(path).resolve()
        py_files = [target] if target.is_file() else list(target.rglob("*.py"))
        cleared = 0
        for py_file in py_files:
            source = py_file.read_text(encoding="utf-8")
            # Remove lines that are cairn annotations
            new_source = re.sub(r"^[ \t]*# cairn\[.*\n", "", source, flags=re.MULTILINE)
            if new_source == source:
                continue
            if dry_run:
                diff = difflib.unified_diff(
                    source.splitlines(keepends=True),
                    new_source.splitlines(keepends=True),
                    fromfile=f"a/{py_file.name}",
                    tofile=f"b/{py_file.name}",
                )
                click.echo("".join(diff))
            else:
                py_file.write_text(new_source, encoding="utf-8")
                click.echo(f"Cleared annotations from {py_file}")
                cleared += 1
        if not dry_run:
            click.echo(f"\n{cleared} file(s) cleared.")
        return

    from cairn.distill.decay import apply_decay
    from cairn.store.writer import get_all

    db_path = Path(db)
    if not db_path.exists():
        click.echo("No store found. Run tests or 'cairn scan' first.")
        return

    records = apply_decay(get_all(db_path))

    # Index records by resolved source_file path
    by_file: dict[str, list] = {}
    for r in records:
        if r.source_file:
            key = str(Path(r.source_file).resolve())
            by_file.setdefault(key, []).append(r)

    if not by_file:
        click.echo("No records with source_file information found.")
        return

    target = Path(path).resolve()
    py_files = [target] if target.is_file() else list(target.rglob("*.py"))
    annotated = 0

    for py_file in py_files:
        key = str(py_file.resolve())
        file_records = by_file.get(key, [])
        if not file_records:
            continue

        # Group records by line number
        by_line: dict[int, list] = {}
        for r in file_records:
            if r.source_line:
                by_line.setdefault(r.source_line, []).append(r)
        if not by_line:
            continue

        source = py_file.read_text(encoding="utf-8")
        lines = source.splitlines(keepends=True)
        new_lines = list(lines)

        # Insert annotations working backwards so earlier line numbers stay valid
        for lineno in sorted(by_line.keys(), reverse=True):
            recs = by_line[lineno]
            idx = lineno - 1  # 0-indexed
            if idx < 0 or idx >= len(new_lines):
                continue
            indent = len(new_lines[idx]) - len(new_lines[idx].lstrip())
            pad = " " * indent
            # Skip if a cairn annotation already covers this location
            if "# cairn[" in new_lines[idx]:
                continue
            if idx > 0 and "# cairn[" in new_lines[idx - 1]:
                continue
            for r in sorted(recs, key=lambda x: -x.confidence):
                first_line = r.content.splitlines()[0][:80]
                tag = f"{pad}# cairn[{r.source}]: {first_line} (conf={r.confidence:.2f})\n"
                new_lines.insert(idx, tag)

        new_source = "".join(new_lines)
        if new_source == source:
            continue

        if dry_run:
            diff = difflib.unified_diff(
                source.splitlines(keepends=True),
                new_source.splitlines(keepends=True),
                fromfile=f"a/{py_file.name}",
                tofile=f"b/{py_file.name}",
            )
            click.echo("".join(diff))
        else:
            py_file.write_text(new_source, encoding="utf-8")
            click.echo(f"Annotated {py_file}")
            annotated += 1

    if not dry_run:
        click.echo(f"\n{annotated} file(s) annotated.")


# ---------------------------------------------------------------------------
# cairn install-hook
# ---------------------------------------------------------------------------


@main.command("install-hook")
@click.option("--repo-root", default=".", type=click.Path(exists=True),
              show_default=True, help="Git repository root.")
@click.option("--hook", default="post-commit", show_default=True,
              help="Git hook name to install into (post-commit, pre-push, etc.).")
def install_hook(repo_root: str, hook: str) -> None:
    """Install a git hook that auto-runs 'cairn distill' after commits.

    Safe to run repeatedly — appends to an existing hook without duplicating.
    """
    import stat

    repo = Path(repo_root).resolve()
    git_dir = repo / ".git"
    if not git_dir.is_dir():
        click.echo(f"No .git directory found in {repo}. Not a git repository.", err=True)
        raise SystemExit(1)

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    hook_path = hooks_dir / hook

    _SENTINEL = "# installed by cairn"
    _BODY = f"{_SENTINEL}\ncairn distill 2>/dev/null || true\n"

    if hook_path.exists():
        existing = hook_path.read_text(encoding="utf-8")
        if _SENTINEL in existing:
            click.echo(f"cairn hook already present in {hook_path}")
            return
        # Append to existing hook
        hook_path.write_text(existing.rstrip("\n") + "\n" + _BODY, encoding="utf-8")
        click.echo(f"cairn distill appended to existing {hook} hook at {hook_path}")
    else:
        hook_path.write_text(f"#!/bin/sh\n{_BODY}", encoding="utf-8")
        hook_path.chmod(hook_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        click.echo(f"Git {hook} hook installed at {hook_path}")
        click.echo("cairn distill will run automatically after each commit.")


# ---------------------------------------------------------------------------
# Grouped command surface (v0.3.0+)
# ---------------------------------------------------------------------------
#
# The flat command list (`cairn status`, `cairn scan`, …) grew to 22
# entries — load-bearing for backward compat but hostile to discovery.
# These groups give the CLI a coherent shape:
#
#   cairn store   {status,stats,export,prune,sync,ingest,embed,query}
#   cairn pattern {templates,rules,context,flaky,stability,rollback-check}
#   cairn capture {scan,watch,prime}
#   cairn distill (flat — the cluster+name operation, kept at top level)
#   cairn serve   (flat — single command)
#
# Every grouped command is the *same callback* as its flat sibling, so
# pre-existing scripts, docs, and hooks continue to work. Removing the
# flat versions is a v1.0 change at the earliest.


def _add_group(name: str, help_text: str, command_names: list[str]) -> None:
    grp = click.Group(name=name, help=help_text)
    for cmd_name in command_names:
        cmd = main.commands.get(cmd_name)
        if cmd is None:
            continue
        # Re-add with the same name. Click is happy to share command objects
        # between groups; the existing flat registration is untouched.
        grp.add_command(cmd, name=cmd_name)
    main.add_command(grp, name=name)


_add_group(
    "store",
    "Inspect, query, and maintain the local SQLite truth store.",
    ["status", "stats", "export", "prune", "sync", "ingest", "embed", "query"],
)
# `pattern` rather than `distill` — the flat `cairn distill` (cluster + name)
# already owns that name. The group surfaces the *consumers* of distillation
# while leaving the existing entry point untouched.
_add_group(
    "pattern",
    "Consume distilled signal — context, templates, rules, flaky tests.",
    [
        "templates", "rules", "context", "flaky", "stability", "rollback-check",
    ],
)
_add_group(
    "capture",
    "Run capture front-ends — AST scan, sys.monitoring watch, OSS prime.",
    ["scan", "watch", "prime"],
)
