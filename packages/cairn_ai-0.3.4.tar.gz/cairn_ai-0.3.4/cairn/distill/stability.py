"""Success-signal analysis — surface the *absence* of failures.

Cairn's capture pipeline records both PASS and FAIL pytest outcomes, but
until now only failures were clustered and shown to agents. A codebase
section that has passed every test for weeks is just as load-bearing a
signal as one that has failed twelve times — it tells the agent which
modules are *safe to refactor* and which recent commits *introduced* a
regression.

This module computes three derived signals from the raw store:

1. ``module_stability(db)`` → per-module pass rate + streak length. Groups
   records by ``source_file`` directory and reports (module, pass_count,
   fail_count, last_failure, pass_streak_days). Stable modules float to
   the top; flaky ones sink.

2. ``rollback_candidates(db, window_days=14)`` → commits that correlate
   with a *spike* in failure count within ``window_days``. Uses existing
   ``git`` TruthRecords joined against pytest FAIL records' occurred_at.

3. ``success_summary(db)`` → a one-line Markdown fragment for
   ``build_context`` so agents see the positive signal alongside the
   failures they have to fix.

Design
------
- Stateless: every call re-reads the store. Cheap enough for a CLI summary;
  results are cached at the caller if needed.
- Pass records are identified by ``content.startswith("PASS ")``. Legacy
  records without the prefix are treated as unknown (not counted either way).
- "Module" = parent directory of ``source_file`` relative to the project
  root. Records without ``source_file`` are grouped under ``<unknown>``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cairn.store.schema import TruthRecord
from cairn.store.writer import _DEFAULT_DB, get_all


@dataclass
class ModuleStability:
    module: str
    pass_count: int = 0
    fail_count: int = 0
    last_failure: datetime | None = None
    last_pass: datetime | None = None

    @property
    def total(self) -> int:
        return self.pass_count + self.fail_count

    @property
    def pass_rate(self) -> float:
        return self.pass_count / self.total if self.total else 0.0

    @property
    def streak_days(self) -> float:
        """Days since the last failure (∞ for never-failing modules)."""
        if self.last_failure is None:
            return float("inf")
        if self.last_pass is None or self.last_pass < self.last_failure:
            return 0.0
        return (self.last_pass - self.last_failure).total_seconds() / 86400


@dataclass
class RollbackCandidate:
    commit_sha: str
    commit_subject: str
    failures_after: int
    failures_before: int
    delta: int = field(init=False)

    def __post_init__(self) -> None:
        self.delta = self.failures_after - self.failures_before


def _module_key(record: TruthRecord) -> str:
    """Group records by the directory that owns the source file.

    Handles three common shapes of ``source_file``:

      1. ``src/pkg/module.py``     → ``src/pkg``
      2. ``module.py`` (no parent) → ``module``
      3. ``tests/x.py::test_y[p]`` (pytest nodeid) → ``tests``

    Without stripping the ``::…`` suffix every parametrized test case
    becomes its own module and the stability table is useless (bug
    surfaced against the shipped commons_python.db).
    """
    if not record.source_file:
        return "<unknown>"
    raw = record.source_file
    if "::" in raw:
        raw = raw.split("::", 1)[0]
    p = Path(raw)
    parent = str(p.parent)
    if parent and parent != ".":
        return parent
    return p.stem


def module_stability(db_path: Path = _DEFAULT_DB) -> list[ModuleStability]:
    """Compute per-module pass/fail counts sorted by stability (pass rate
    desc, then streak desc). Only pytest records contribute."""
    records = [r for r in get_all(db_path) if r.source == "pytest"]
    by_module: dict[str, ModuleStability] = {}
    for r in records:
        at = r.occurred_at
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        if r.content.startswith("PASS"):
            key = _module_key(r)
            ms = by_module.setdefault(key, ModuleStability(module=key))
            ms.pass_count += 1
            if ms.last_pass is None or at > ms.last_pass:
                ms.last_pass = at
        elif r.content.startswith("FAIL"):
            key = _module_key(r)
            ms = by_module.setdefault(key, ModuleStability(module=key))
            ms.fail_count += 1
            if ms.last_failure is None or at > ms.last_failure:
                ms.last_failure = at
        # Ignore pytest records that aren't PASS/FAIL (legacy / setup phase),
        # and non-pytest sources — stability is a test-outcome signal.
    out = [m for m in by_module.values() if m.total > 0]
    out.sort(key=lambda m: (-m.pass_rate, -m.streak_days))
    return out


def rollback_candidates(
    db_path: Path = _DEFAULT_DB,
    window_days: int = 14,
    min_delta: int = 2,
) -> list[RollbackCandidate]:
    """Find git-linked commits followed by a meaningful spike in failures.

    A commit is a candidate when the count of FAIL records whose
    ``occurred_at`` falls inside ``[commit_time, commit_time + window_days]``
    exceeds the count in the symmetric *preceding* window by at least
    ``min_delta``.
    """
    records = get_all(db_path)
    git_recs = [r for r in records if r.source == "git"]
    fail_times: list[datetime] = []
    for r in records:
        if r.source == "pytest" and r.content.startswith("FAIL"):
            at = r.occurred_at
            if at.tzinfo is None:
                at = at.replace(tzinfo=timezone.utc)
            fail_times.append(at)

    if not git_recs or not fail_times:
        return []

    window = timedelta(days=window_days)
    out: list[RollbackCandidate] = []
    for gr in git_recs:
        sha, subject = _parse_git_record(gr)
        if not sha:
            continue
        at = gr.occurred_at
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        before = sum(1 for t in fail_times if at - window <= t < at)
        after = sum(1 for t in fail_times if at <= t < at + window)
        if after - before >= min_delta:
            out.append(RollbackCandidate(
                commit_sha=sha,
                commit_subject=subject,
                failures_after=after,
                failures_before=before,
            ))
    out.sort(key=lambda c: -c.delta)
    return out


def _parse_git_record(r: TruthRecord) -> tuple[str, str]:
    """Extract ``(sha, subject)`` from a git TruthRecord.

    Handles three shapes observed in the wild:

      1. ``GIT <sha> <subject>\\n…``  — the format emitted by
         ``cairn.capture.git_linker.link_commits`` (v0.2+). ``<sha>`` is
         typically 12 chars; the rest of the first line is the subject.
      2. ``commit <sha>: <subject>``  — older hand-written ingest format.
      3. ``<sha> <subject>``          — bare form used by some priming
         scripts and by synthetic test fixtures.

    Only the first line of ``content`` is consulted. Returns ``("", "")``
    when no sha is recognisable.
    """
    first_line = r.content.splitlines()[0] if r.content else ""
    parts = first_line.split(None, 2)
    if not parts:
        return "", ""
    head = parts[0]
    # Shape 1: `GIT <sha> <subject>`
    if head == "GIT" and len(parts) >= 2 and _looks_like_sha(parts[1]):
        sha = parts[1]
        subject = parts[2] if len(parts) >= 3 else ""
        return sha, subject
    # Shape 2: `commit <sha>: <subject>` (and `commit <sha> <subject>`)
    if head == "commit" and len(parts) >= 2:
        sha = parts[1].rstrip(":")
        subject = parts[2] if len(parts) >= 3 else ""
        return sha, subject
    # Shape 3: bare `<sha> <subject>`
    if _looks_like_sha(head):
        return head, " ".join(parts[1:])
    return "", first_line[:80]


def _looks_like_sha(s: str) -> bool:
    return len(s) >= 7 and all(c in "0123456789abcdefABCDEF" for c in s)


def success_summary(db_path: Path = _DEFAULT_DB, top_n: int = 3) -> str:
    """Produce a short Markdown block for ``build_context`` that lists the
    most stable modules. Returns an empty string when there is no PASS
    signal in the store (so older stores don't get a misleading section)."""
    mods = [m for m in module_stability(db_path) if m.pass_count > 0]
    if not mods:
        return ""
    lines = ["## Stable modules", "",
             "_Modules with consistently passing tests — safe refactor targets._", ""]
    for m in mods[:top_n]:
        streak = "clean" if m.fail_count == 0 else f"{m.streak_days:.1f}d since last failure"
        lines.append(
            f"- **{m.module}** — {m.pass_count} passes, "
            f"{m.fail_count} failures ({m.pass_rate:.0%} pass rate, {streak})"
        )
    lines.append("")
    return "\n".join(lines)
