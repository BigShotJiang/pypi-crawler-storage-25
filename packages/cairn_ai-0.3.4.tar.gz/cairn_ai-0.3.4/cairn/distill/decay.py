"""Confidence decay model — age-weight TruthRecord confidence scores.

Old truths that are not re-confirmed by new runs fade out of active context.
Decay uses a simple exponential half-life:

    effective_confidence = record.confidence * 0.5 ** (age_days / half_life)

AST records decay faster (structural code changes more often than runtime
behaviour changes); distill records decay slower (they represent synthesised
patterns, not single observations).
"""

from __future__ import annotations

from datetime import datetime, timezone

from cairn.store.schema import TruthRecord

# Default half-lives in days per source type
_HALF_LIFE: dict[str, float] = {
    "pytest":  21.0,   # test results go stale after ~3 weeks
    "monitor": 21.0,
    "ast":     14.0,   # code changes faster
    "git":     30.0,
    "distill": 60.0,   # synthesised patterns are more durable
}
_DEFAULT_HALF_LIFE = 30.0


def _load_half_lives() -> dict[str, float]:
    """Read project-level half-lives from [tool.cairn.decay], merged with defaults."""
    try:
        from cairn.config import get_config
        cfg = get_config().get("decay", {})
        merged = dict(_HALF_LIFE)
        for k, v in cfg.items():
            merged[k] = float(v)
        return merged
    except Exception:
        return dict(_HALF_LIFE)


def decayed_confidence(
    record: TruthRecord,
    as_of: datetime | None = None,
    _half_lives: dict[str, float] | None = None,
) -> float:
    """Return the current effective confidence after age-based decay.

    Args:
        record:       the TruthRecord to evaluate.
        as_of:        reference datetime (defaults to UTC now).
        _half_lives:  pre-loaded half-life map (avoids per-record config reads).

    Returns:
        Effective confidence in [0.0, 1.0].
    """
    now = as_of or datetime.now(tz=timezone.utc)
    # Normalise both to UTC
    occurred = record.occurred_at
    if occurred.tzinfo is None:
        occurred = occurred.replace(tzinfo=timezone.utc)
    age_days = max(0.0, (now - occurred).total_seconds() / 86400)

    if _half_lives is None:
        _half_lives = _load_half_lives()
    half_life = _half_lives.get(record.source, _DEFAULT_HALF_LIFE)

    # Cross-store reweight: a pattern reported by many contributors is
    # dampened — not hard-divided — so heavy contributor_count values
    # don't silently pull effective confidence below the default
    # min_confidence=0.05 threshold used by build_context.
    #
    # Scale factor = 1 / (1 + log2(contrib)):
    #   contrib=1  → 1.000   (no-op for direct captures)
    #   contrib=2  → 0.500
    #   contrib=5  → 0.301
    #   contrib=10 → 0.232
    #   contrib=50 → 0.150
    #   contrib=100→ 0.131
    # The choice of direction is deliberate: a pattern reported by many
    # projects is likely generic (broad_except, untested_branch) rather
    # than project-specific signal. See CHANGELOG v0.3.4 for rationale.
    import math as _math
    contrib = max(1, getattr(record, "contributor_count", 1) or 1)
    dampener = 1.0 / (1.0 + _math.log2(contrib))

    return record.confidence * (0.5 ** (age_days / half_life)) * dampener


def apply_decay(
    records: list[TruthRecord],
    as_of: datetime | None = None,
    min_confidence: float = 0.05,
) -> list[TruthRecord]:
    """Return records with effective confidence above *min_confidence*, sorted
    highest-first.

    Args:
        records:        records to evaluate.
        as_of:          reference datetime (defaults to UTC now).
        min_confidence: records below this effective confidence are dropped.
    """
    now = as_of or datetime.now(tz=timezone.utc)
    half_lives = _load_half_lives()  # read config once for the whole batch
    scored = [
        (decayed_confidence(r, now, _half_lives=half_lives), r)
        for r in records
    ]
    return [
        r for score, r in sorted(scored, key=lambda x: -x[0])
        if score >= min_confidence
    ]
