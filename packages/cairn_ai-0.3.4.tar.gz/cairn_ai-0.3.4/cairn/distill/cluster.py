"""Failure pattern clustering.

Groups TruthRecord objects into clusters by structural similarity:

- **pytest / monitor** records: primary key is ``exception_type``; within that,
  secondary grouping by the first non-whitespace token of the traceback (the
  innermost function name), giving clusters like ``ValueError::parse_config``.
- **ast** records: primary key is the check type (first colon-delimited token
  of ``content``, e.g. ``broad_except``, ``mutable_default``).
- **git** records: grouped as a single ``git::correlation`` cluster.
- **distill** records: pass-through, grouped by their ``pattern_cluster`` value.

The keys returned are stable strings suitable for use as ``pattern_cluster``
values when writing distilled TruthRecords back to the store.
"""

from __future__ import annotations

import re
from pathlib import Path

from cairn.store.schema import TruthRecord


def cluster(records: list[TruthRecord]) -> dict[str, list[TruthRecord]]:
    """Group records into clusters keyed by a stable cluster label.

    Args:
        records: any mix of TruthRecord objects.

    Returns:
        Dict mapping cluster label → member records, sorted by descending
        cluster size.
    """
    buckets: dict[str, list[TruthRecord]] = {}
    for r in records:
        key = _cluster_key(r)
        buckets.setdefault(key, []).append(r)
    # Return largest clusters first
    return dict(sorted(buckets.items(), key=lambda kv: -len(kv[1])))


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------

# Traceback inner-frame extractors — ordered most-specific first.
# CPython stable across 3.10–3.13:   File "x.py", line N, in fn_name
# "During handling of…" chains leave the final frame as the innermost one;
# we walk all matches and keep the last.
# Monitor RAISE / CALL content follows the shape "RAISE qualname ExcType: msg"
# or "CALL qualname". The qualified name appears as the second whitespace
# token and may contain dots (e.g. Cls.method).
_TRACEBACK_FRAME = re.compile(r'File "[^"]+", line \d+, in ([\w.<>]+)')
_MONITOR_HEAD = re.compile(r"^(?:CALL|RETURN|RAISE)\s+([\w.<>]+)")


def _innermost_function(content: str) -> str:
    """Best-effort extract of the innermost function name from a captured
    record's content. Stable across Python 3.10–3.13 traceback formats and
    both pytest-rendered and monitor-rendered records. Returns ``""`` when
    no function token can be identified.
    """
    frames = _TRACEBACK_FRAME.findall(content)
    if frames:
        fn = frames[-1]
        return fn.rsplit(".", 1)[-1]
    head = _MONITOR_HEAD.match(content)
    if head:
        return head.group(1).rsplit(".", 1)[-1]
    return ""


def _cluster_key(r: TruthRecord) -> str:
    if r.source in ("pytest", "monitor"):
        exc = r.exception_type or "no_exception"
        fn = _innermost_function(r.content)
        return f"{exc}::{fn}" if fn else exc

    if r.source == "ast":
        # content starts with "check_type: ..."
        return r.content.split(":")[0].strip()

    if r.source == "git":
        # Cluster by affected file so blame records for different modules
        # don't collapse into one useless mega-cluster.
        if r.source_file:
            stem = Path(r.source_file).stem
            return f"git::{stem}"
        return "git::correlation"

    if r.source == "distill":
        return r.pattern_cluster or "distill::unknown"

    return f"{r.source}::other"
