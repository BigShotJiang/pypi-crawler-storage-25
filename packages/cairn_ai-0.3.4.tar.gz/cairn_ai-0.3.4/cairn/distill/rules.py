"""Encode distilled patterns as ruff / flake8 noqa hints.

High-confidence structural patterns (from AST clusters) are mapped to their
corresponding ruff rule codes so the agent can suggest ``# noqa`` comments or
ruff ``select`` additions to prevent silent recurrence.

Runtime failure patterns (pytest/monitor) don't map cleanly to static rules;
those are surfaced in context snippets instead.
"""

from __future__ import annotations

from pathlib import Path

from cairn.store.schema import TruthRecord

# AST check type → (ruff_code, description)
_AST_RULES: dict[str, tuple[str, str]] = {
    "broad_except":      ("BLE001",  "blind exception: do not catch blind exception"),
    "mutable_default":   ("B006",    "do not use mutable data structures for argument defaults"),
    "missing_annotation":("ANN",     "flake8-annotations: missing type annotation"),
    "unreachable_code":  ("RET505",  "unnecessary `else` after `return` statement / unreachable"),
    "deep_nesting":      ("C901",    "function is too complex (McCabe complexity)"),
    "magic_number":      ("PLR2004", "magic value used in comparison"),
    "print_statement":   ("T201",    "print found — use logging instead"),
    "assert_in_library": ("S101",    "use of assert detected — assertions are removed with -O"),
    "fstring_in_logging":("G004",    "logging statement uses f-string — use lazy % formatting"),
}


def encode_as_rule(cluster_name: str, records: list[TruthRecord]) -> str | None:
    """Return a Markdown snippet describing the applicable ruff rule, or None.

    Args:
        cluster_name: human-readable cluster label from ``namer.name_cluster``.
        records:      member records of the cluster.

    Returns:
        A Markdown string with the rule code and remediation hint, or ``None``
        if the pattern cannot be expressed as a static lint rule.
    """
    if not records:
        return None

    source = records[0].source
    if source != "ast":
        return None

    check_type = records[0].content.split(":")[0].strip()
    mapping = _AST_RULES.get(check_type)
    if not mapping:
        return None

    code, description = mapping
    files = sorted({r.source_file for r in records if r.source_file})
    file_list = ", ".join(f"`{f}`" for f in files[:5])
    if len(files) > 5:
        file_list += f" and {len(files) - 5} more"

    return (
        f"**ruff `{code}`** — {description}\n"
        f"Pattern: `{check_type}` ({len(records)} occurrence{'s' if len(records) != 1 else ''})\n"
        f"Files: {file_list}\n"
        f"Fix: add `{code}` to `select` in `pyproject.toml` or add `# noqa: {code}` inline."
    )


# ---------------------------------------------------------------------------
# Project ruff-config inspection
# ---------------------------------------------------------------------------


try:
    import tomllib as _tomllib  # type: ignore[import-not-found,unused-ignore]
except ImportError:  # Python 3.10 fallback
    import tomli as _tomllib  # type: ignore[import-not-found,unused-ignore,no-redef]


def _load_toml(path: Path) -> dict[str, object]:
    with path.open("rb") as fh:
        data: dict[str, object] = _tomllib.load(fh)
        return data


def _read_project_selects(project_root: Path) -> tuple[set[str], Path | None]:
    """Return the set of ruff rule codes currently enabled in the project.

    Searches (in order):
      1. ``ruff.toml`` / ``.ruff.toml`` at project root
      2. ``[tool.ruff.lint]`` in ``pyproject.toml``
      3. ``[tool.ruff]`` in ``pyproject.toml`` (legacy location)

    Returns (codes, source_path). If no ruff config is found, returns
    (empty set, None).
    """
    def _select_from(node: object) -> set[str]:
        if not isinstance(node, dict):
            return set()
        raw = node.get("select", [])
        if not isinstance(raw, list):
            return set()
        return {s for s in raw if isinstance(s, str)}

    candidates = [
        project_root / "ruff.toml",
        project_root / ".ruff.toml",
    ]
    for c in candidates:
        if c.exists():
            data = _load_toml(c)
            lint_node = data.get("lint", data) if isinstance(data, dict) else {}
            return _select_from(lint_node), c

    pp = project_root / "pyproject.toml"
    if pp.exists():
        data = _load_toml(pp)
        tool = data.get("tool", {}) if isinstance(data, dict) else {}
        ruff = tool.get("ruff", {}) if isinstance(tool, dict) else {}
        lint_node = ruff.get("lint", ruff) if isinstance(ruff, dict) else {}
        return _select_from(lint_node), pp
    return set(), None


def required_codes(records: list[TruthRecord]) -> set[str]:
    """Return the set of ruff codes implied by the AST patterns in *records*."""
    out: set[str] = set()
    for r in records:
        if r.source != "ast":
            continue
        check_type = r.content.split(":")[0].strip()
        mapping = _AST_RULES.get(check_type)
        if mapping:
            out.add(mapping[0])
    return out


class RuffPatchRefused(Exception):
    """Raised when the patcher won't safely modify a ruff config —
    callers should surface the reason to the user so they can patch
    manually rather than silently losing comments or structure."""


def apply_ruff_patch(
    missing: set[str],
    project_root: Path | None = None,
) -> tuple[Path | None, bool]:
    """Add *missing* codes to the project's ruff config in place.

    Returns ``(config_path, changed)``. ``changed`` is False when there's
    nothing to do (no missing codes, or they're already present).

    Refuses and raises ``RuffPatchRefused`` when the existing ``select``
    array contains comments — blind string substitution would lose them.
    The caller should report the refusal and recommend a manual edit
    rather than ship a silent data-loss operation.
    """
    if not missing:
        return None, False
    root = project_root or Path.cwd()
    current, config_path = _read_project_selects(root)
    if config_path is None:
        return None, False
    to_add = sorted(missing - current)
    if not to_add:
        return config_path, False

    text = config_path.read_text(encoding="utf-8")
    _refuse_if_select_has_comments(text, config_path.name == "pyproject.toml")

    merged = sorted(current | set(to_add))
    new_line = "select = " + _format_code_list(merged)
    updated = _patch_select_line(text, new_line, config_path.name == "pyproject.toml")
    if updated == text:
        # Target block not found — append a [tool.ruff.lint] section.
        if config_path.name == "pyproject.toml":
            updated = text.rstrip() + "\n\n[tool.ruff.lint]\n" + new_line + "\n"
        else:
            updated = text.rstrip() + "\n\n[lint]\n" + new_line + "\n"
    config_path.write_text(updated, encoding="utf-8")
    return config_path, True


def _refuse_if_select_has_comments(text: str, is_pyproject: bool) -> None:
    """Scan the existing select array and raise if any ``#`` appears
    inside. Preserves the user's commented-out codes and commentary
    instead of silently dropping them."""
    import re as _re
    section = r"\[tool\.ruff\.lint\]" if is_pyproject else r"\[lint\]"
    m = _re.search(
        rf"{section}[^\[]*?select\s*=\s*(\[[^\]]*\])",
        text,
        flags=_re.DOTALL,
    )
    if not m and is_pyproject:
        m = _re.search(
            r"\[tool\.ruff\][^\[]*?select\s*=\s*(\[[^\]]*\])",
            text,
            flags=_re.DOTALL,
        )
    if not m:
        return
    array_body = m.group(1)
    if "#" in array_body:
        raise RuffPatchRefused(
            "select array contains a `#` comment; refusing to patch "
            "in place. Edit pyproject.toml / ruff.toml manually to "
            "preserve existing commentary."
        )


def _format_code_list(codes: list[str]) -> str:
    inner = ", ".join(f'"{c}"' for c in codes)
    return f"[{inner}]"


def _patch_select_line(text: str, new_line: str, is_pyproject: bool) -> str:
    r"""Replace the first ``select = [...]`` inside the ruff section,
    regardless of whether the array is on one line or spans multiple.

    The value matcher ``\[[^\[\]]*\]`` used to stop at the first ``]`` on
    the same line, which silently no-op'd against the multi-line style most
    real projects ship::

        [tool.ruff.lint]
        select = [
            "E",
            "F",
        ]

    We now match the array body as ``\[[^\]]*\]`` under DOTALL, which walks
    across newlines and stops at the closing bracket.

    Also handles:
      - standalone ``ruff.toml`` with top-level ``select = [...]`` (no
        ``[lint]`` section — layout recommended by ruff < 0.1)
      - legacy ``[tool.ruff] select = [...]`` for pyproject.toml
      - ``extend-select`` in addition to ``select`` (merged into ``select``
        when we rewrite — leaves ``extend-select`` unchanged; callers can
        then drop it manually if they prefer a single list)

    Returns the original ``text`` unchanged if no target is found, so the
    caller can append a fresh section.
    """
    import re as _re

    def _try(pattern_src: str) -> tuple[str, int]:
        return _re.compile(pattern_src, flags=_re.DOTALL).subn(
            rf"\g<1>{new_line}", text, count=1,
        )

    sections = [r"\[tool\.ruff\.lint\]"] if is_pyproject else [r"\[lint\]"]
    if is_pyproject:
        sections.append(r"\[tool\.ruff\]")  # legacy

    # Scoped replacements: require the assignment to live inside the
    # named section (up to the next ``[`` heading). Group 1 holds the
    # section header + preceding content; the ``select = [...]`` clause
    # is the replacement target.
    for section in sections:
        replaced, n = _try(
            rf"(?P<g1>{section}[^\[]*?)select\s*=\s*\[[^\]]*\]",
        )
        if n:
            return replaced

    # Standalone ruff.toml without a [lint] section — `select = [...]` at
    # the top level. Only safe when there's no section header at all; the
    # `(?s)\A[^\[]*` anchor enforces that.
    if not is_pyproject:
        replaced, n = _re.compile(
            r"(\A[^\[]*?)select\s*=\s*\[[^\]]*\]",
            flags=_re.DOTALL,
        ).subn(rf"\1{new_line}", text, count=1)
        if n:
            return replaced

    return text


def ruff_config_diff(
    records: list[TruthRecord],
    project_root: Path | None = None,
) -> dict[str, object]:
    """Compare the ruff rule codes implied by captured patterns against the
    project's ruff configuration.

    Returns a dict suitable for CLI rendering::

        {
          "config_path":  Path | None,   # where we looked
          "current":      set[str],       # codes currently enabled
          "required":     set[str],       # codes implied by cairn records
          "missing":      set[str],       # required - current (to add)
          "unused":       set[str],       # current - required (informational)
        }
    """
    root = project_root or Path.cwd()
    current, config_path = _read_project_selects(root)
    required = required_codes(records)
    return {
        "config_path": config_path,
        "current": current,
        "required": required,
        "missing": required - current,
        "unused": current - required,
    }
