"""Embedder — generate vector embeddings for TruthRecord content.

Two modes:

1. **sentence-transformers** (``pip install cairn[embed]``) — real semantic
   embeddings using a local model (``all-MiniLM-L6-v2`` by default, 384 dims).
   Downloaded once and cached in ``~/.cache/huggingface``.

2. **Fallback** — when sentence-transformers is not installed, a lightweight
   bag-of-words hash projection is used (512 dims, L2-normalised).  This
   enables cosine-similarity ranking for keyword overlap without any
   network download or heavy dependency.  It is NOT semantic — similar words
   with different spellings won't cluster — but it is fully functional.

Records are mutated in-place; the same list is returned for chaining.
"""

from __future__ import annotations

import hashlib
import math
import os
import re
import warnings

from cairn.store.schema import TruthRecord

# Emit the fallback warning at most once per process; silence it by setting
# ``CAIRN_EMBED_SILENT=1`` (set in tests and by the pytest plugin's sessionfinish
# path to avoid noisy CI output).
_FALLBACK_WARNED = False


def _warn_fallback_once() -> None:
    global _FALLBACK_WARNED
    if _FALLBACK_WARNED or os.environ.get("CAIRN_EMBED_SILENT"):
        return
    _FALLBACK_WARNED = True
    warnings.warn(
        "cairn: sentence-transformers is not installed — semantic search and "
        "embedding-based ranking are disabled. Falling back to a deterministic "
        "bag-of-words hash projection (keyword overlap only, NOT semantic). "
        "Install `cairn-ai[embed]` for real semantic embeddings.",
        RuntimeWarning,
        stacklevel=3,
    )

_VECTOR_DIM = 512
_MODEL_NAME = "all-MiniLM-L6-v2"

_TOKEN_RE = re.compile(r"[a-z0-9_]+")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def embed(records: list[TruthRecord]) -> list[TruthRecord]:
    """Compute and attach embeddings to a list of TruthRecords in-place.

    Uses sentence-transformers if available, otherwise falls back to the
    lightweight hash-based method.
    """
    if not records:
        return records
    try:
        return _embed_st(records)
    except ImportError:
        _warn_fallback_once()
        return _embed_fallback(records)


def embed_query(text: str) -> list[float]:
    """Embed a single query string using the same method as ``embed()``."""
    try:
        model = _get_model()
        vec = model.encode([text], normalize_embeddings=True)[0]
        return [float(x) for x in vec]
    except ImportError:
        _warn_fallback_once()
        return _hash_embed(text)


# ---------------------------------------------------------------------------
# sentence-transformers backend
# ---------------------------------------------------------------------------

_st_model = None


def _get_model():
    global _st_model
    if _st_model is None:
        from sentence_transformers import SentenceTransformer  # type: ignore
        _st_model = SentenceTransformer(_MODEL_NAME)
    return _st_model


def _embed_st(records: list[TruthRecord]) -> list[TruthRecord]:
    model = _get_model()  # raises ImportError if not installed
    texts = [r.content for r in records]
    vecs = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    for r, vec in zip(records, vecs):
        r.embedding = [float(x) for x in vec]
    return records


# ---------------------------------------------------------------------------
# Fallback: hash-based bag-of-words projection
# ---------------------------------------------------------------------------


def _tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


def _hash_embed(text: str) -> list[float]:
    """Project text into a fixed-dim L2-normalised vector via hashing."""
    vec = [0.0] * _VECTOR_DIM
    for token in _tokenize(text):
        h1 = int(hashlib.md5(token.encode()).hexdigest(), 16)  # noqa: S324
        h2 = int(hashlib.sha1(token.encode()).hexdigest(), 16)  # noqa: S324
        bucket = h1 % _VECTOR_DIM
        sign = 1.0 if h2 % 2 == 0 else -1.0
        vec[bucket] += sign
    norm = math.sqrt(sum(x * x for x in vec)) or 1.0
    return [x / norm for x in vec]


def _embed_fallback(records: list[TruthRecord]) -> list[TruthRecord]:
    for r in records:
        r.embedding = _hash_embed(r.content)
    return records
