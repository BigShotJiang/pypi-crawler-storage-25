"""TruthRecord dataclass and SQLite schema definition.

Domain field convention
-----------------------
Every TruthRecord carries a ``domain`` string that encodes *where* the signal
came from.  The canonical format is::

    {language}/{scope}

Examples::

    python/stdlib          # CPython standard-library patterns (commons layer)
    python/pytest          # pytest-specific patterns
    python/acme.billing    # org/project-scoped (org layer)
    rust/tokio             # tokio crate patterns
    go/net.http            # Go stdlib http
    commons                # language-agnostic universal patterns

Rules
~~~~~
- ``language`` is lowercase, letters only, from ``KNOWN_LANGUAGES``.
- ``scope`` is dot-separated identifiers (optional; omit for language-wide).
- The *DB file path* encodes the tier (commons, org, project); ``domain``
  encodes the language and narrower scope inside that file.
- Legacy records with no ``/`` (e.g. ``"test_project"``) are valid; the
  ``language`` property returns ``None`` for them so callers can detect them.
- When donating signal to commons, strip the scope: ``python/acme.auth``
  → ``python``.  The new ID is a different hash — untraceable by construction.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime

# ---------------------------------------------------------------------------
# Language registry
# ---------------------------------------------------------------------------

#: The 25 languages cairn explicitly supports.  New languages can be added
#: freely — these are used only for normalisation and documentation.
KNOWN_LANGUAGES: frozenset[str] = frozenset({
    "c", "clojure", "commons", "cpp", "crystal", "csharp",
    "elixir", "erlang", "go", "haskell", "java", "javascript",
    "julia", "kotlin", "lua", "nim", "perl", "php",
    "python", "r", "ruby", "rust", "scala", "swift",
    "typescript", "zig",
})

_LANG_RE = re.compile(r"^[a-z][a-z0-9]*$")


def normalize_domain(domain: str) -> str:
    """Normalize *domain* to ``{language}/{scope}`` format.

    This is a lenient helper — it never raises.  Callers (rosetta adapters,
    synthesis orchestrator) should call it before constructing a TruthRecord
    so that new records consistently follow the convention.

    Behaviour
    ---------
    - Strips surrounding whitespace.
    - Lower-cases the language prefix (the part before the first ``/``).
    - If there is no ``/``, the whole string is treated as the language
      (scope is omitted) and is lower-cased.
    - Empty strings are returned unchanged.
    - Strings where the language prefix is not a valid identifier are
      returned as-is (legacy domains are preserved, not mangled).

    Examples
    --------
    >>> normalize_domain("Python/stdlib")
    'python/stdlib'
    >>> normalize_domain("rust")
    'rust'
    >>> normalize_domain("test_project")   # legacy — no slash
    'test_project'
    >>> normalize_domain("")
    ''
    """
    domain = domain.strip()
    if not domain:
        return domain
    if "/" in domain:
        lang, _, scope = domain.partition("/")
        lang = lang.lower()
        if _LANG_RE.match(lang):
            return f"{lang}/{scope}"
        return domain  # keep malformed prefix intact
    # No slash: whole string is the language token
    candidate = domain.lower()
    if _LANG_RE.match(candidate):
        return candidate
    return domain  # legacy domain — leave unchanged


@dataclass
class TruthRecord:
    """The unit of storage. Every signal Cairn captures is normalized to this."""

    source: str          # "pytest" | "monitor" | "ast" | "git" | "distill"
    domain: str          # project namespace / module path
    content: str         # the fact: pattern description, error, observation
    confidence: float    # 0.0–1.0, decays with age unless re-confirmed
    occurred_at: datetime

    # Optional context
    source_file: str | None = None
    source_line: int | None = None
    exception_type: str | None = None
    pattern_cluster: str | None = None

    # Execution metrics (populated by sys.monitoring capture)
    duration_ms: float | None = None   # wall-clock time of first observed invocation
    call_depth: int | None = None      # call-stack depth at first observed invocation
    observation_count: int = 1         # how many times this record has been observed
    # Cross-store attribution: how many distinct contributing stores have
    # reported this exact content hash. Set by `cairn sync`; defaults to 1
    # for direct captures. Used by the reweight logic so a failure reported
    # by 50 projects doesn't have 50× the weight of one reported by one
    # project.
    contributor_count: int = 1

    # Computed after construction
    embedding: list[float] = field(default_factory=list)
    id: str = field(init=False)

    def __post_init__(self) -> None:
        self.id = self._compute_id()

    def _compute_id(self) -> str:
        """Stable hash over (source, domain, content). Timestamp is excluded so
        re-running the same failure updates the existing record rather than inserting
        a new one."""
        raw = f"{self.source}:{self.domain}:{self.content}"
        return hashlib.sha256(raw.encode()).hexdigest()

    @property
    def language(self) -> str | None:
        """Return the language prefix from the domain, or ``None`` for legacy domains.

        ``"python/acme.billing"`` → ``"python"``
        ``"rust"``               → ``"rust"``  (no scope, but valid language)
        ``"test_project"``       → ``None``    (legacy: no slash, not in KNOWN_LANGUAGES)
        """
        if "/" in self.domain:
            lang = self.domain.split("/", 1)[0].lower()
            return lang if _LANG_RE.match(lang) else None
        candidate = self.domain.lower()
        return candidate if candidate in KNOWN_LANGUAGES else None


# ---------------------------------------------------------------------------
# SQLite DDL
# ---------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS truth_records (
    id              TEXT PRIMARY KEY,
    source          TEXT NOT NULL,
    domain          TEXT NOT NULL,
    content         TEXT NOT NULL,
    confidence      REAL NOT NULL DEFAULT 1.0,
    occurred_at     TEXT NOT NULL,
    source_file     TEXT,
    source_line     INTEGER,
    exception_type  TEXT,
    pattern_cluster TEXT,
    duration_ms     REAL,
    call_depth      INTEGER,
    embedding       TEXT          -- JSON array of floats
);

CREATE INDEX IF NOT EXISTS idx_source      ON truth_records(source);
CREATE INDEX IF NOT EXISTS idx_domain      ON truth_records(domain);
CREATE INDEX IF NOT EXISTS idx_occurred_at ON truth_records(occurred_at);
CREATE INDEX IF NOT EXISTS idx_cluster     ON truth_records(pattern_cluster);
"""


def record_to_row(r: TruthRecord) -> dict:
    """Serialize a TruthRecord to a flat dict suitable for SQLite insertion."""
    return {
        "id": r.id,
        "source": r.source,
        "domain": r.domain,
        "content": r.content,
        "confidence": r.confidence,
        "occurred_at": r.occurred_at.isoformat(),
        "source_file": r.source_file,
        "source_line": r.source_line,
        "exception_type": r.exception_type,
        "pattern_cluster": r.pattern_cluster,
        "observation_count": r.observation_count,
        "contributor_count": r.contributor_count,
        "duration_ms": r.duration_ms,
        "call_depth": r.call_depth,
        "embedding": json.dumps(r.embedding) if r.embedding else None,
    }


def row_to_record(row: dict) -> TruthRecord:
    """Deserialize a SQLite row dict back to a TruthRecord."""
    rec = TruthRecord(
        source=row["source"],
        domain=row["domain"],
        content=row["content"],
        confidence=row["confidence"],
        occurred_at=datetime.fromisoformat(row["occurred_at"]),
        source_file=row.get("source_file"),
        source_line=row.get("source_line"),
        exception_type=row.get("exception_type"),
        pattern_cluster=row.get("pattern_cluster"),
        duration_ms=row.get("duration_ms"),
        call_depth=row.get("call_depth"),
        observation_count=row.get("observation_count") or 1,
        contributor_count=row.get("contributor_count") or 1,
    )
    raw_emb = row.get("embedding")
    rec.embedding = json.loads(raw_emb) if raw_emb else []
    # Restore the pre-computed id (it will match _compute_id() for valid rows)
    rec.id = row["id"]
    return rec
