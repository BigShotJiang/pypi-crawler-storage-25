# Cairn context — multi-module — 2026-04-14

_Auto-generated from runtime signal. Do not edit manually._

# cairn

## 🔴 HALT — distill (18 records) [distill]

_Health: **ABLATED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN error in test_scrub_corpus.py (604 occurrences)  _(conf: 1.00)_
- PASS tests/test_v033_followups.py::TestMultilineRuffConfig::test_standalone_ruff_toml_top_level_select  _(conf: 1.00)_
- PASS tests/test_v033_followups.py::TestMultilineRuffConfig::test_ruff_config_diff_reads_multiline_select  _(conf: 1.00)_
- PASS tests/test_v033_followups.py::TestMultilineRuffConfig::test_patch_updates_multiline_select_array  _(conf: 1.00)_
- PASS tests/test_v033_followups.py::TestGitRecordRoundTrip::test_rollback_candidates_reads_linker_output  _(conf: 1.00)_
- _…and 13 more_

# capture

## 🟡 ALERT — distill (1 record) [distill]

_Health: **DEGRADED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN print_statement in prime_from_oss.py (52 occurrences)  _(conf: 1.00)_

# distill

## 🟡 ALERT — distill (1 record) [distill]

_Health: **DEGRADED** | Drift: ACCELERATING WORSENING | Anomaly: NOVEL_

- PATTERN broad_except in pytest_plugin.py (36 occurrences)  _(conf: 1.00)_

## Stable modules

_Modules with consistently passing tests — safe refactor targets._

- **/home/runner/work/cairn/cairn/tests** — 604 passes, 0 failures (100% pass rate, clean)