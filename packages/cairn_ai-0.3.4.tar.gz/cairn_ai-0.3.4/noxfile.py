"""Nox sessions for local multi-version compatibility testing.

Usage:
    pip install nox          # one-time
    nox                      # run all sessions
    nox -s test-3.10         # single version
    nox -s lint              # ruff only

Requires Python 3.10, 3.11, and 3.12 to be available on PATH
(e.g. via pyenv: pyenv install 3.10 3.11 3.12).
"""

import nox

PYTHON_VERSIONS = ["3.10", "3.11", "3.12"]


@nox.session(python=PYTHON_VERSIONS, name="test")
def test(session: nox.Session) -> None:
    """Run the full pytest suite on the given Python version."""
    session.install("-e", ".[dev,coverage,config]")
    session.run("pytest", "tests/", "-v", "--tb=short", "-q")


@nox.session(python="3.12")
def lint(session: nox.Session) -> None:
    """Run ruff linter + formatter check."""
    session.install("ruff>=0.3")
    session.run("ruff", "check", "cairn/", "tests/")
    session.run("ruff", "format", "--check", "cairn/", "tests/")


@nox.session(python="3.12", name="cairn_generated")
def cairn_generated(session: nox.Session) -> None:
    """Execute cairn-generated stub tests in tests/cairn_generated/.

    Run after `cairn templates` to validate that the Hypothesis stubs
    actually compile, collect, and pass against the current source. Keeps
    the templates → tests feedback loop closed instead of emitting stubs
    that nobody ever runs.
    """
    import pathlib

    target = pathlib.Path("tests") / "cairn_generated"
    if not target.exists():
        session.log(f"{target} not present — run `cairn templates` first. Skipping.")
        return
    session.install("-e", ".[dev,pytest]")
    session.install("hypothesis>=6.0")
    session.run("pytest", str(target), "-v", "--tb=short")
