# Changelog

All notable changes to cairn-ai are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versioning is
[SemVer](https://semver.org/).

## [0.3.4] — 2026-04-14

v0.3.3 audit follow-ups. Scrubber generalisation + reweight
dampening + commons quality gates.

### Fixed

- **Scrubber systematic gap** — previous versions required hand-listed
  variants (`auth_token`, `session_id`) for every prefixed-sensitive
  key. A real-world probe showed `aws_secret`, `stripe_key`,
  `db_password`, `_authToken`, `apiKey`, and any other
  `<prefix>_<sensitive>` / `<prefix><Sensitive>` identifier all
  leaked. Replaces the hand-listed variant regex with a
  suffix-normalised check: any identifier whose trailing token
  (after splitting on `_`/`-`/`.` / camelCase boundary / compound-
  collapse) is in the sensitive set is redacted. 9 new corpus entries
  pin the gap closed.
- **Scrubber chained-assignment leak** — `cookie=sessionid=ABCDEF`
  and `key: -----BEGIN PRIVATE KEY-----` cases where the "value"
  contains another `:` or `=` were only partially redacted. Token-
  shape redaction now runs before KV so PEM / AWS / GitHub patterns
  can't be mangled into partial redactions; a post-pass tail cleanup
  catches `<redacted:*>=<token>` dangling assignments.
- **Reweight pruning interaction** — v0.3.3's `1/contributor_count`
  downweight pushed records with `contributor_count ≥ 20` below the
  default `min_confidence=0.05` threshold, silently dropping commons
  data from `build_context`. Replaces hard division with a
  logarithmic dampener `1 / (1 + log2(contrib))`:
  `contrib=1 → 1.000`, `contrib=5 → 0.301`, `contrib=50 → 0.150`,
  `contrib=100 → 0.131`. Direction is documented (generic patterns
  reported by many projects rank below project-specific signal) and
  tested against the pruning threshold.
- **`cairn rules --apply` silently dropped commented entries**.
  Regex-based patching couldn't preserve `# "F",` lines inside a
  `select` array. Now raises `RuffPatchRefused` on those configs;
  the CLI reports and exits 4 so the user can patch manually
  rather than lose commentary.

### Added

- **Assertive commons smoke tests** — replaces "didn't crash"
  with bounded invariants: < 90% singleton clusters (catches a
  grouping regression), non-empty `build_context` for stores with
  live records, no blank or generic-fallback cluster keys.
- **mypy `--strict` coverage extended** to
  `cairn.capture.assertions` and `cairn.distill.rules` in addition
  to the v0.3.1 surfaces (`scrub`, `stability`).

### Behaviour changes

- `decayed_confidence` now uses `1 / (1 + log2(contributor_count))`
  instead of `1/contributor_count`. Direct captures (`count=1`)
  are unchanged; multi-contributor records stay well above the
  `min_confidence=0.05` pruning threshold even at `count=100`.

## [0.3.3] — 2026-04-14

Closes four real bugs surfaced by the v0.3.2 audit. No new features.

### Fixed

- **`cairn rollback-check` was silently broken against live data**.
  `cairn.capture.git_linker` writes records as `GIT <sha> <subject>…`
  but `_parse_git_record` only recognised `<sha>…` or `commit <sha>:…`,
  so every rollback-check invocation against a store populated by
  `cairn scan --with-git` returned an empty list. Adds a round-trip
  test that writes records via `link_commits` and asserts
  `rollback_candidates` finds them.

- **`cairn sync --reweight` confidence divide was cosmetic**. v0.3.2
  added a working `contributor_count` column but the confidence halving
  in the sync CLI was overridden by the writer's `MAX(stored, excluded)`
  upsert, so only the count actually changed on disk. Moves the
  downweight to read time: `decayed_confidence` now divides by
  `contributor_count`, so a record reported by 5 contributors has 1/5
  the effective weight of one reported once. Inert for direct captures
  (count=1).

- **`cairn rules --apply` silently no-op'd on multi-line select arrays**.
  The patch regex stopped at the first `]` on the same line, which is
  how most real projects format their `select` list. Now runs under
  DOTALL and walks across newlines. Also handles standalone `ruff.toml`
  with top-level `select = [...]` (no `[lint]` section).

### Added

- **Commons DB smoke tests** — every shipped `commons_*.db` is run
  through `count`, `get_all`, `apply_decay`, `cluster`,
  `module_stability`, and `build_context`. Consumers that crash or
  return blank-key clusters against real data now fail CI.

- **git-record round-trip test** — writes records via `link_commits`
  on a synthetic repo, reads them via `rollback_candidates`.

### Behaviour changes

- `decayed_confidence` now multiplies by `1/max(1, contributor_count)`.
  Single-contributor records (count=1) are unchanged; multi-contributor
  records rank lower in `cairn query`, `build_context`, and
  `apply_decay` output.

## [0.3.2] — 2026-04-14

Closes the non-Tier-3 items from the v0.3 audit. Two real bugs found
against the shipped commons DBs; one load-bearing feature (sync
reweight) was a no-op in v0.3 and now actually works.

### Fixed

- **`cairn stability` was meaningless on pytest-nodeid source_file**.
  Commons stores record `source_file` as `tests/x.py::test_y[param]`
  — every parametrised test became its own "module", so the stability
  table listed hundreds of 1-pass-0-fail rows. Now strips the `::…`
  suffix before extracting the parent directory.

- **`cairn sync --reweight` is no longer a no-op**. v0.3 halved
  incoming confidence but the `MAX(stored, excluded)` writer kept the
  destination unchanged, so reweight only affected the ephemeral
  incoming value. Added a `contributor_count` column (with additive
  migration) so each duplicate sync increments the count and the
  incoming confidence is divided by `count+1` — the docstring's promise
  now matches the behaviour.

### Added

- **`cairn rules --apply`** — writes the missing ruff codes into the
  project's `ruff.toml` / `.ruff.toml` / `pyproject.toml` in place.
  Handles both the current `[tool.ruff.lint]` layout and the legacy
  `[tool.ruff]` location.

- **`cairn install --force`** — overwrites existing CLAUDE.md / AGENTS.md
  / Cursor / Continue scaffolds. Default still preserves user edits.

- **Expanded assertion parser** (`cairn.capture.assertions`) — now
  recognises pytest `assert x in y` / `x not in y`, `pytest.approx`
  (`1.0 == 1.01 ± 0.001` and `+/-` variant), and `pytest.raises`
  DID-NOT-RAISE failures, in addition to the binop shapes from v0.3.

- **`contributor_count` column** on `TruthRecord` (default 1, additive
  migration for existing stores).

- 25 new tests covering: `--policy-exit-halt` HALT + ALERT exit-code
  behaviour, legacy `[tool.ruff]` config parsing, `apply_ruff_patch`
  modes, `cairn install --force` / default behaviour, CLI-group
  dispatch (`store status`, `pattern stability`, `capture scan`),
  pytest-nodeid handling in stability, sync contributor-count
  increment, assertion shapes.

### Verified

- All three shipped commons DBs (`commons_python.db`,
  `commons_fortran.db`, `commons_cobol.db`) open cleanly under the
  new schema; the `contributor_count` migration is backward-compatible.

## [0.3.1] — 2026-04-14

Test debt + scrubber hardening from the v0.3 audit. No new features.

### Fixed

- **Scrubber leak on prefix-then-key strings** — `context: PASSWORD=...`
  no longer slips past the kv rule. The regex now scans for sensitive
  names directly instead of capturing a generic key first, so
  non-sensitive prefixes can't consume the buffer up to the next `=`.

- **Scrubber: extra sensitive-name variants** — `auth_token`,
  `session_id`, `auth-token`, `session-id` were previously missed.

- **Scrubber: unterminated quoted secrets** — `key='value_no_close` now
  matches.

### Added

- **Scrubber corpus + fuzz test** (`tests/test_scrub_corpus.py`) — 19
  must-redact entries (real token shapes), 9 must-pass-through entries
  (false-positive guard), 50 deterministic kv-fuzz iterations.

- **Templates execution test** (`tests/test_templates_executable.py`) —
  generated stubs MUST `ast.parse()` cleanly and pytest-collect without
  syntax / internal errors. Closes the orphan-output loop one layer
  deeper.

- **Git-linker subtree tests** — exercises the `--subtree` filter,
  outside-of-repo error path, and symlink resolution.

- **mypy + ruff in CI** (`.github/workflows/typecheck.yml`) — full-package
  mypy is informational while the legacy backlog is worked down; strict
  mode is enforced on `cairn.capture.scrub` and `cairn.distill.stability`
  (the curated well-typed surfaces).

### Changed

- 25 new tests, 468 → 575 passing; CI grows a typecheck workflow.

## [0.3.0] — 2026-04-14

Focus: feature coherence. Captured signal that was being thrown away is
now consumed; orphaned outputs (templates, rules) are wired into real
feedback loops; the CLI gets a hierarchy.

### Added

- **Success signal** (`cairn.distill.stability`) — PASS records are now
  surfaced as per-module pass/fail/streak data. New CLIs:
  - `cairn stability` — table of pass rate + days-since-last-failure
  - `cairn rollback-check` — git commits correlated with failure spikes
  - `success_summary()` is appended to `build_context()` so agents see
    safe-to-refactor modules alongside broken ones

- **Templates feedback loop** — `cairn templates` defaults to
  `tests/cairn_generated/`, scaffolds `__init__.py` + `conftest.py`,
  marks generated tests with `cairn_generated`, and a new
  `nox -s cairn_generated` session runs them with Hypothesis installed.

- **Rules feedback loop** — `cairn rules` reads the project's
  `[tool.ruff.lint] select` from `ruff.toml` / `.ruff.toml` /
  `pyproject.toml`, diffs against codes implied by captured AST records,
  and prints a concrete pyproject patch.

- **Margin policy gates** — `cairn distill` gains
  `--analyze-health/--no-analyze-health` (default: on iff margin
  installed; explicit `--analyze-health` errors when it isn't) and
  `--policy-exit-halt` (exit 3 on any HALT escalation, for CI gating).

- **Structured assertion capture** (`cairn.capture.assertions`) — pytest
  FAIL records get a `cairn-assert: {json}` trailer with op / lhs / rhs /
  types / numeric_delta. New `cairn flaky` command flags tests where
  the same nodeid has been observed with multiple distinct rhs values.

- **Sync dedup + reweighting** — `cairn sync --reweight` (default on)
  halves incoming confidence for already-present records to prevent one
  noisy contributor from suppressing fresh signal; `--source-tag` stamps
  origin into `pattern_cluster`.

- **Grouped CLI surface** — `cairn store {status,stats,…}`,
  `cairn pattern {templates,rules,…}`, `cairn capture {scan,watch,…}`.
  Flat commands continue to work unchanged.

### Fixed

- **Git linker monorepo-safe** — paths on both ends are normalised
  through `Path.resolve()` so symlinked / relative source files actually
  match. New `--subtree` flag on `cairn scan --with-git` restricts
  correlations to commits touching a service's own subdirectory.

### Changed

- `tests/cairn_generated/` is the new templates default (was
  `.cairn/stubs/`). The old location had no pytest collection wired up.

## [0.2.0] — 2026-04-14

Focus: correctness, safety, and making the "writes its own CLAUDE.md" pitch
actually deliver.

### Added

- **Secret / PII scrubber** (`cairn.capture.scrub`) — every TruthRecord passes
  through redaction before it reaches SQLite. Covers env-var values, sensitive
  `key=value` pairs, token shapes (AWS, GitHub, Anthropic/OpenAI/OpenRouter,
  Slack, JWT, PEM), and PII shapes (email, IPv4, CC-shaped digits). Records
  are re-hashed post-scrub so secrets cannot be recovered from the id.

- **Multi-agent install scaffolds** — `cairn install` now writes `CLAUDE.md`,
  `AGENTS.md`, `.github/copilot-instructions.md`, `.cursor/rules/cairn.mdc`,
  and `.continuerules` (selectable via `--targets`). Existing files are never
  overwritten.

- **Token budget on context output** — `build_context(max_tokens=4000)` and
  `cairn context --max-tokens N` cap the injected Markdown at an
  approximate token ceiling, truncating at a section boundary with a visible
  marker instead of silently blowing past an agent's prompt window.

- **Cluster-stability test suite** (`tests/test_cluster_stability.py`) pinning
  inner-frame extraction across traceback formatting variations.

### Fixed

- **Confidence re-observation semantics** — upsert now uses
  `MAX(stored, excluded)` on conflict instead of bumping by `0.005`. A record
  decayed to 0.5 over 21 days and re-confirmed today returns to effective
  confidence ≈ 1.0 rather than crawling back at +0.005 per observation.

- **Cluster-key stability** — `_innermost_function` parses `File "x.py", line
  N, in NAME` frames (stable across CPython 3.10–3.13), picks the last frame
  on chained exceptions, collapses qualified names to the trailing component,
  and handles whitespace / CRLF variation. Traceback formatting drift no
  longer fragments historical clusters.

- **Monitor PEP 669 tool slot** — tries IDs 2→3→4→5 instead of hardcoding 2,
  raising a clear `RuntimeError` if all slots are claimed. Previously, a
  concurrent profiler holding slot 2 would silently swallow every event.

- **Monitor timer race** — flush-timer scheduling is now guarded by `_lock`
  and cancels any prior timer so repeated `start()` calls can't leave two
  timers racing over the same buffers.

- **`cairn watch` on Python < 3.12** — fails fast with an actionable message
  pointing users at `@cairn.watch` instead of bubbling up the internal
  `sys.monitoring` error.

### Changed

- **Embedder fallback is no longer silent** — a one-time `RuntimeWarning` is
  emitted when `sentence-transformers` is missing and cairn falls back to the
  deterministic bag-of-words hash projection. Suppress with
  `CAIRN_EMBED_SILENT=1` in CI.

- **Dependency pins tightened** — every optional dependency now carries an
  upper bound (click <9, pytest <9, sentence-transformers <4,
  coverage <8, tomli <3, margin <1, ruff <1). Avoids silent breakage on
  major-version bumps.

- **`dev` extra deduplicated** — now `cairn-ai[pytest,coverage,health,config,embed]`
  plus ruff + nox, so adding a test dependency touches one place instead of
  five.

### Breaking

- Writer upsert semantics changed from
  `confidence = MIN(1.0, stored + 0.005)` to
  `confidence = MAX(stored, excluded)`. Consumers that relied on the exact
  arithmetic (only the backtest) were updated.

## [0.1.1] — 2026-04-11

- docs: refresh PyPI page with README badges
- docs: trim README from 693 → 216 lines
- refactor: split `mcp_http` out of `mcp_server.py`

## [0.1.0] — 2026-04

Initial public release.

- pytest plugin auto-registration
- `sys.monitoring` capture (Python 3.12+) and `@cairn.watch` decorator
- AST scanner (9 anti-pattern checks)
- git linker for commit → test delta correlation
- SQLite TruthRecord store with idempotent upsert
- distillation (clustering, naming, decay)
- optional margin-powered health / drift / causality / escalation
- MCP server (stdio + HTTP/SSE) with REST endpoints
- cross-language JSONL ingest
- OSS priming for Python, COBOL, Fortran commons DBs

[0.2.0]: https://github.com/Cope-Labs/cairn/releases/tag/v0.2.0
[0.1.1]: https://github.com/Cope-Labs/cairn/releases/tag/v0.1.1
