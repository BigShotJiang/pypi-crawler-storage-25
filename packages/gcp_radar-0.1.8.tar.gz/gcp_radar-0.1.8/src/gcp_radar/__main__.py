#!/usr/bin/env python3
"""
Main entry point for gcp-radar CLI.
"""

import argparse
import os
import subprocess
import sys
from gcp_radar.inventory import run_inventory


def _resolve_project():
    """Return the active GCP project, checking gcloud then env vars."""
    try:
        result = subprocess.run(["gcloud", "config", "get-value", "project"],
                                capture_output=True, text=True)
        project = result.stdout.strip()
        if project:
            return project
    except Exception:
        pass
    return (os.environ.get("GOOGLE_CLOUD_PROJECT") or
            os.environ.get("DEVSHELL_PROJECT_ID") or
            os.environ.get("GCLOUD_PROJECT"))


def main():
    parser = argparse.ArgumentParser(
        prog="gcp-radar",
        description="GCP Resource Inventory Scanner and Architecture Diagram Generator"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Inventory command
    inv_parser = subparsers.add_parser("inventory", help="Scan GCP resources")
    inv_parser.add_argument("--project", help="GCP project ID (uses default if not specified)")
    inv_parser.add_argument("--all-projects", action="store_true", help="Scan all accessible projects")
    inv_parser.add_argument("--region", help="Specific region (e.g., us-central1)")
    inv_parser.add_argument("--export", help="Export inventory to CSV file")
    
    # Diagram command
    dia_parser = subparsers.add_parser("diagram", help="Generate architecture diagram")
    dia_parser.add_argument("--input", required=True, help="Input CSV file from inventory scan")
    dia_parser.add_argument("--output", required=True, help="Output .drawio file")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="One-shot: inventory + diagram")
    run_parser.add_argument("--project", help="GCP project ID")
    run_parser.add_argument("--output-csv", required=True, help="Output CSV inventory file")
    run_parser.add_argument("--output-diagram", required=True, help="Output .drawio file")
    
    args = parser.parse_args()
    
    if args.command == "inventory":
        from gcp_radar.inventory import run_inventory
        if args.project:
            projects = [args.project]
        else:
            project = _resolve_project()
            if not project:
                print("  [!] Could not determine GCP project. Use --project <id> or set GOOGLE_CLOUD_PROJECT.")
                sys.exit(1)
            projects = [project]
        run_inventory(projects, export_path=args.export)
    
    elif args.command == "diagram":
        from gcp_radar.drawio import read_csv, build_drawio, export_drawio
        rows = read_csv(args.input)
        mxfile = build_drawio(rows)
        export_drawio(mxfile, args.output)
    
    elif args.command == "run":
        from gcp_radar.inventory import run_inventory
        from gcp_radar.drawio import build_drawio, export_drawio
        
        if args.project:
            projects = [args.project]
        else:
            project = _resolve_project()
            if not project:
                print("  [!] Could not determine GCP project. Use --project <id> or set GOOGLE_CLOUD_PROJECT.")
                sys.exit(1)
            projects = [project]

        rows = run_inventory(projects, export_path=args.output_csv)
        mxfile = build_drawio(rows, project_id=projects[0])
        export_drawio(mxfile, args.output_diagram)
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
