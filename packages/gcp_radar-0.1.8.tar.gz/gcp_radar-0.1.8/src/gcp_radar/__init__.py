"""
gcp-radar — GCP resource inventory & draw.io architecture diagram generator.

Quick start:
    from gcp_radar.inventory import run_inventory
    from gcp_radar.drawio import build_drawio
"""

__version__ = "0.1.3"
__author__ = "M.Michaeli"
