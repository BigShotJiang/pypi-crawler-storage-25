# Lookover Python SDK

## What is this folder

`sdk/python/` contains two things:

1. **`lookover_sdk/`** — the Python SDK package that agents import to send audit events to the Lookover backend.
2. **`examples/`** — 20 runnable example agents (Tiers 1–5) that demonstrate the SDK across increasing levels of complexity.

---

## lookover_sdk — Package Overview

```
lookover_sdk/
├── __init__.py              # exports: LookoverClient, AgentEvent, EventType
├── client.py                # HTTP client — batches and POSTs events to /v1/events
├── models.py                # AgentEvent dataclass + EventType enum
├── langgraph/
│   ├── __init__.py          # exports: LookoverLangGraphListener
│   └── listener.py          # wraps a LangGraph graph, auto-emits spans per node
└── langchain/
    ├── __init__.py
    └── callback.py          # LangChain callback handler (non-LangGraph chains)
```

### Core classes

**`LookoverClient`** — low-level client. Queues events and flushes them in batches.

```python
from lookover_sdk import LookoverClient, AgentEvent, EventType

client = LookoverClient(
    api_key="lk_dev_local",          # Bearer token sent to the backend
    agent_id="my-agent",
    base_url="http://localhost:8081", # Lookover backend URL
)
event = AgentEvent(
    agent_id="my-agent",
    event_type=EventType.TOOL_CALL,
    payload={"tool": "calculator", "input": "2+2"},
    outcome="success",
)
client.track(event)
client.flush()   # or client.close() — flushes then closes HTTP connection
```

**`LookoverLangGraphListener`** — high-level wrapper for LangGraph graphs. Call `.invoke()` instead of `graph.invoke()` and every node execution is automatically captured as a span.

```python
from lookover_sdk.langgraph import LookoverLangGraphListener

listener = LookoverLangGraphListener(
    api_key="lk_dev_local",
    agent_id="my-graph",
    agent_version="1.0.0",
    base_url="http://localhost:8081",
)
result = listener.invoke(graph, {"messages": [HumanMessage(content="Hello")]})
# trace_id is generated internally and sent with every event in this run
```

### EventType values

| Value | When to use |
|---|---|
| `TOOL_CALL` | Agent invoked a tool |
| `MODEL_INFERENCE` | LLM was called and returned a response |
| `DATA_ACCESS` | Agent read from a database / file / external source |
| `DECISION` | Agent made a routing or branching decision |
| `HUMAN_HANDOFF` | Agent handed off to a human |

### Installation

```bash
# From the sdk/python directory — editable install
pip install -e .

# With optional extras
pip install -e ".[langgraph]"   # adds langgraph dependency
pip install -e ".[all]"         # langchain + langgraph
```

---

## examples/ — Example Agents

### Structure

```
examples/
├── .env                    # ← PUT YOUR SECRETS HERE (see below)
├── requirements.txt        # pinned deps for all examples
├── venv/                   # Python venv (already created)
├── Tier 1/                 # Agents 01–03: simple chains, no tools
├── Tier 2/                 # Agents 04–07: tools, RAG, memory
├── Tier 3/                 # Agents 08–11: LangGraph graphs, checkpoints, subgraphs
├── Tier 4/                 # Agents 12–15: multi-agent (supervisor, hierarchical, parallel)
└── Tier 5/                 # Agents 16–20: advanced (streaming, retries, dynamic routing)
```

### Tier breakdown

| Tier | Agents | What they demonstrate |
|---|---|---|
| 1 | 01 Simple LLM chain, 02 Prompt template, 03 Output parser | Basic LangChain, no tools |
| 2 | 04 Single tool, 05 Multi-tool, 06 RAG, 07 Conversational memory | Tool use, vector search, memory |
| 3 | 08 LangGraph ReAct, 09 Checkpoint, 10 Human-in-the-loop, 11 Subgraph | LangGraph state graphs |
| 4 | 12 Supervisor, 13 Hierarchical, 14 Parallel, 15 Collaborative | Multi-agent orchestration |
| 5 | 16 Retries, 17 Streaming, 18 Side effects, 19 Dynamic routing, 20 Full pipeline | Production patterns |

### Running an example — step by step

```bash
# 1. Navigate to examples/
cd sdk/python/examples

# 2. Activate the venv
source venv/bin/activate

# 3. Install SDK (only needed once)
pip install -e ../

# 4. Install example dependencies (only needed once)
pip install -r requirements.txt

# 5. Make sure the Lookover backend is running
#    From the repo root:
#    make docker-up && make run

# 6. Run any agent
python "Tier 1/Agent01_simple_llm_chain.py"
python "Tier 4/Agent12_supervisor.py"

# 7. Override LLM provider if needed (default: googleai)
LLM_PROVIDER=ollama python "Tier 4/Agent12_supervisor.py"
```

After a successful run, fetch the trace from the backend:

```bash
curl -s -H "Authorization: Bearer lk_dev_local" \
  "http://localhost:8081/v1/traces?limit=1" | python3 -m json.tool
```

---

## .env file — required secrets

**Location: `sdk/python/examples/.env`** — all examples call `load_dotenv()` which reads from the current working directory. Always `cd sdk/python/examples/` before running.

```env
# ── Lookover backend ──────────────────────────────────────────────────────────
LOOKOVER_API_KEY=lk_dev_local          # matches the tenant API key in the backend
LOOKOVER_BASE_URL=http://localhost:8081
LOOKOVER_SDK_PATH=/absolute/path/to/lookover/sdk/python  # only needed if SDK not pip-installed

# ── LLM provider (pick ONE and fill in its block) ─────────────────────────────
LLM_PROVIDER=googleai                  # options: googleai | vertexai | ollama

# Google AI Studio (LLM_PROVIDER=googleai)
GOOGLE_API_KEY=your-google-ai-studio-key
GOOGLEAI_MODEL=gemini-2.5-flash        # or gemini-2.0-flash, gemini-1.5-pro, etc.

# Vertex AI (LLM_PROVIDER=vertexai)
GOOGLE_CLOUD_PROJECT=your-gcp-project-id
GOOGLE_CLOUD_LOCATION=us-central1
VERTEXAI_MODEL=gemini-2.0-flash-lite-002

# Ollama (LLM_PROVIDER=ollama) — local, no API key needed
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2
```

### Where to get the secrets

| Secret | Where |
|---|---|
| `GOOGLE_API_KEY` | [aistudio.google.com/apikey](https://aistudio.google.com/apikey) |
| `GOOGLE_CLOUD_PROJECT` | GCP Console → project selector |
| Ollama | Install from [ollama.com](https://ollama.com), run `ollama pull llama3.2` |
| `LOOKOVER_API_KEY` | Use `lk_dev_local` for local dev — it matches the seeded tenant in the backend |

---

## Prerequisites checklist

Before running any example:

- [ ] Lookover backend is up: `curl http://localhost:8081/v1/health` returns `{"status":"ok",...}`
- [ ] `.env` file exists at `sdk/python/examples/.env` with at least `LOOKOVER_API_KEY`, `LOOKOVER_BASE_URL`, `LLM_PROVIDER`, and the matching LLM key
- [ ] `venv` is activated: `source sdk/python/examples/venv/bin/activate`
- [ ] SDK is installed: `pip show lookover-sdk` shows version `0.2.0`
- [ ] Dependencies installed: `pip install -r requirements.txt` (from `examples/` dir)

### Start the backend (if not already running)

```bash
# From repo root
make docker-up   # starts PostgreSQL + Redis + Redpanda
make run         # starts the Go backend on :8081
```
