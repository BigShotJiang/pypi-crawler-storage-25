# lookover

Audit logging SDK for AI agents. Sends tamper-proof, compliance-ready traces to [Lookover](https://github.com/privyyio/lookover) — mapped to GDPR, SOC 2 Type II, EU AI Act, and more.

## Install

```bash
pip install lookover

# With LangGraph support
pip install "lookover[langgraph]"

# With LangChain support
pip install "lookover[all]"
```

## Quick start

```python
from lookover_sdk import LookoverClient, AgentEvent, EventType

client = LookoverClient(
    api_key="lk_...",
    agent_id="my-agent",
    base_url="https://your-lookover-backend.run.app",
)

client.track(AgentEvent(
    event_type=EventType.TOOL_CALL,
    payload={"tool": "calculator", "input": "2+2"},
    outcome="success",
))
client.flush()
```

## LangGraph integration

```python
from lookover_sdk.langgraph import LookoverLangGraphListener

listener = LookoverLangGraphListener(
    api_key="lk_...",
    agent_id="my-graph",
    base_url="https://your-lookover-backend.run.app",
)

result = listener.invoke(graph, {"messages": [HumanMessage(content="Hello")]})
```

## prerun CLI

Scan your agent code for compliance gaps before running it:

```bash
prerun scan ./my_agent.py
prerun scan ./agents/ --framework GDPR
```

## Links

- [Full documentation](https://docs.lookover.io)
- [GitHub](https://github.com/privyyio/lookover)
- [PyPI](https://pypi.org/project/lookover)
