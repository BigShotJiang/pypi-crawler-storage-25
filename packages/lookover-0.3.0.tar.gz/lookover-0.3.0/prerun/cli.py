from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .runtime import RuntimeClient
from .scanner import scan_project


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="prerun", description="Pre-run scan and publish utility for LangChain/LangGraph projects.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Scan a project for governance evidence and runtime risks.")
    scan_parser.add_argument("project_path", help="Path to the project to scan.")
    scan_parser.add_argument("--strict", action="store_true", help="Fail on blocking governance gaps.")
    scan_parser.add_argument("--tenant-id", default=None, help="Tenant identifier for published scan context.")
    scan_parser.add_argument("--system-id", default=None, help="Stable system identifier for the scanned project.")
    scan_parser.add_argument("--system-name", default=None, help="Human-readable system name for the scanned project.")
    scan_parser.add_argument("--environment", default=None, help="Environment label for the scanned project.")
    scan_parser.add_argument("--output", help="Write the scan JSON to a file.")
    scan_parser.add_argument("--backend-url", default=None, help="Backend URL for defaults and future publishing.")
    scan_parser.set_defaults(func=_cmd_scan)

    publish_parser = subparsers.add_parser("publish", help="Publish a scan JSON document to the backend.")
    publish_parser.add_argument("scan_json", help="Path to the scan JSON file.")
    publish_parser.add_argument("--api-key", default=None, help="Raw Lookover API key used for authenticated publishing.")
    publish_parser.add_argument("--backend-url", default=None, help="Backend URL to publish to.")
    publish_parser.set_defaults(func=_cmd_publish)

    run_parser = subparsers.add_parser("run", help="Scan a project and publish the results in one step.")
    run_parser.add_argument("project_path", help="Path to the project to scan.")
    run_parser.add_argument("--strict", action="store_true", help="Fail on blocking governance gaps.")
    run_parser.add_argument("--tenant-id", default=None, help="Tenant identifier for published scan context.")
    run_parser.add_argument("--system-id", default=None, help="Stable system identifier for the scanned project.")
    run_parser.add_argument("--system-name", default=None, help="Human-readable system name for the scanned project.")
    run_parser.add_argument("--environment", default=None, help="Environment label for the scanned project.")
    run_parser.add_argument("--api-key", default=None, help="Raw Lookover API key used for authenticated publishing.")
    run_parser.add_argument("--backend-url", default=None, help="Backend URL to publish to.")
    run_parser.set_defaults(func=_cmd_run)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


def _backend_url(value: str | None) -> str:
    return value or os.environ.get("LOOKOVER_BACKEND_URL") or os.environ.get("BACKEND_URL") or "http://localhost:8081"


def _api_key(value: str | None) -> str | None:
    return value or os.environ.get("LOOKOVER_API_KEY")


def _cmd_scan(args: argparse.Namespace) -> int:
    result_obj = scan_project(args.project_path, strict=args.strict)
    result_obj.target = {
        "tenant_id": args.tenant_id,
        "system_id": args.system_id,
        "system_name": args.system_name,
        "environment": args.environment,
    }
    result_obj.scanner = {"name": "prerun", "version": "0.2.0"}
    result_obj.scan_metadata = {"source_type": "python-static"}
    result = result_obj.to_dict()
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        Path(args.output).write_text(payload + "\n", encoding="utf-8")
    else:
        sys.stdout.write(payload + "\n")
    if args.strict and result.get("strict_result") == "block":
        return 1
    return 0


def _cmd_publish(args: argparse.Namespace) -> int:
    path = Path(args.scan_json)
    scan = json.loads(path.read_text(encoding="utf-8"))
    client = RuntimeClient(_backend_url(args.backend_url), api_key=_api_key(args.api_key))
    response = client.post_scan(scan)
    sys.stdout.write(json.dumps(response, indent=2, sort_keys=True) + "\n")
    return 0 if response.get("ok") else 1


def _cmd_run(args: argparse.Namespace) -> int:
    result_obj = scan_project(args.project_path, strict=args.strict)
    result_obj.target = {
        "tenant_id": args.tenant_id,
        "system_id": args.system_id,
        "system_name": args.system_name,
        "environment": args.environment,
    }
    result_obj.scanner = {"name": "prerun", "version": "0.2.0"}
    result_obj.scan_metadata = {"source_type": "python-static"}
    result = result_obj.to_dict()

    client = RuntimeClient(_backend_url(args.backend_url), api_key=_api_key(args.api_key))
    response = client.post_scan(result)
    sys.stdout.write(json.dumps(response, indent=2, sort_keys=True) + "\n")

    if not response.get("ok"):
        return 1
    if args.strict and result.get("strict_result") == "block":
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
