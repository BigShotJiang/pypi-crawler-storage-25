from __future__ import annotations

import json
import unittest
from unittest.mock import patch

from prerun.runtime import RuntimeClient


class _FakeHTTPResponse:
    def __init__(self, body: dict[str, object], status: int = 201) -> None:
        self.status = status
        self._body = json.dumps(body).encode("utf-8")

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> "_FakeHTTPResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


class RuntimeClientTests(unittest.TestCase):
    def test_post_scan_uses_bearer_api_key_when_configured(self) -> None:
        captured: dict[str, object] = {}

        def fake_urlopen(req, timeout=0):  # noqa: ANN001
            captured["url"] = req.full_url
            captured["authorization"] = req.headers.get("Authorization")
            captured["content_type"] = req.headers.get("Content-type")
            captured["body"] = json.loads(req.data.decode("utf-8"))
            captured["timeout"] = timeout
            return _FakeHTTPResponse({"ok": True, "scan_id": "scan_123"})

        client = RuntimeClient("http://localhost:8081", api_key="test-api-key")

        with patch("prerun.runtime.request.urlopen", side_effect=fake_urlopen):
            response = client.post_scan(
                {
                    "scan_id": "scan_123",
                    "project_path": "/tmp/example-agent",
                    "findings": [],
                }
            )

        self.assertTrue(response["ok"])
        self.assertEqual("http://localhost:8081/v1/prerun/scans", captured["url"])
        self.assertEqual("Bearer test-api-key", captured["authorization"])
        self.assertEqual("application/json", captured["content_type"])
        self.assertEqual("scan_123", captured["body"]["scan_id"])


if __name__ == "__main__":
    unittest.main()
