from __future__ import annotations

import json
import os
import tempfile
import unittest
from argparse import Namespace
from pathlib import Path
from unittest.mock import patch

from prerun import cli


class CLITests(unittest.TestCase):
    def test_api_key_prefers_flag_then_env(self) -> None:
        with patch.dict(os.environ, {"LOOKOVER_API_KEY": "env-key"}, clear=False):
            self.assertEqual("flag-key", cli._api_key("flag-key"))
            self.assertEqual("env-key", cli._api_key(None))

    def test_publish_uses_runtime_client_with_api_key(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            scan_path = Path(tmpdir) / "scan.json"
            scan_path.write_text(
                json.dumps(
                    {
                        "scan_id": "scan_123",
                        "project_path": "/tmp/example-agent",
                        "findings": [],
                    }
                ),
                encoding="utf-8",
            )

            args = Namespace(
                scan_json=str(scan_path),
                backend_url="http://localhost:8081",
                api_key="flag-key",
            )

            captured: dict[str, object] = {}

            class FakeClient:
                def __init__(self, backend_url: str, timeout: float = 5.0, api_key: str | None = None) -> None:
                    captured["backend_url"] = backend_url
                    captured["api_key"] = api_key

                def post_scan(self, scan: dict[str, object]) -> dict[str, object]:
                    captured["scan"] = scan
                    return {"ok": True, "scan_id": "scan_123"}

            with patch("prerun.cli.RuntimeClient", FakeClient):
                exit_code = cli._cmd_publish(args)

        self.assertEqual(0, exit_code)
        self.assertEqual("http://localhost:8081", captured["backend_url"])
        self.assertEqual("flag-key", captured["api_key"])
        self.assertEqual("scan_123", captured["scan"]["scan_id"])


if __name__ == "__main__":
    unittest.main()
