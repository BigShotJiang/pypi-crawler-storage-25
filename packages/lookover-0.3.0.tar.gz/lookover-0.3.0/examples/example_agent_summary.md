# Agent Examples Summary

All agents use **Google AI Studio** (`gemini-2.5-flash`) via `LLM_PROVIDER=googleai`.  
Provider is configurable via `.env` — supports `ollama`, `vertexai`, and `googleai`.

---

## Tier 1 — LangChain Basics

### Agent01 · Simple LLM Chain
**File:** `Tier 1/Agent01_simple_llm_chain.py`  
**What it does:** Single prompt → LLM → string output. The simplest possible chain with no tools, memory, or branching. Captures latency and token usage.  
**APIs / Libraries:** `langchain-google-genai`, `langchain-core`  
**Tools:** None

---

### Agent02 · Prompt Template
**File:** `Tier 1/Agent02_prompt_template.py`  
**What it does:** Uses `ChatPromptTemplate` with dynamic variables (`topic`, `audience`) composed into a chain via LCEL (`prompt | llm | StrOutputParser`). Logs the fully rendered prompt before sending.  
**APIs / Libraries:** `langchain-google-genai`, `langchain-core` (ChatPromptTemplate, StrOutputParser)  
**Tools:** None

---

### Agent03 · Output Parser
**File:** `Tier 1/Agent03_output_parser.py`  
**What it does:** Prompt → LLM → `JsonOutputParser` → validated Pydantic model (`TechConceptSummary`). Captures both success and parse failure paths. The LLM must return structured JSON with fields: `concept`, `one_liner`, `key_components`, `use_cases`, `difficulty`.  
**APIs / Libraries:** `langchain-google-genai`, `langchain-core` (JsonOutputParser), `pydantic`  
**Tools:** None

---

## Tier 2 — Tools, RAG & Memory

### Agent04 · Single Tool Agent
**File:** `Tier 2/Agent04_single_tool.py`  
**What it does:** LLM decides when to invoke a calculator tool, executes it, and uses the result to form a final answer. Uses the new `langchain.agents.create_agent` (LangGraph-backed). Logs every tool call with input and output.  
**APIs / Libraries:** `langchain-google-genai`, `langchain` (create_agent), `langchain-core`  
**Tools:** `calculator` — evaluates Python math expressions (`sqrt`, `log`, `sin`, `cos`, `**`, etc.)

---

### Agent05 · Multi-Tool Agent
**File:** `Tier 2/Agent05_multi_tool.py`  
**What it does:** Same as Agent04 but with four tools. The LLM picks the right tool(s) per query and can chain multiple tool calls in a single run.  
**APIs / Libraries:** `langchain-google-genai`, `langchain` (create_agent), `langchain-core`  
**Tools:**
- `calculator` — Python math expression evaluator
- `get_current_datetime` — returns current UTC date/time
- `word_counter` — counts words, characters, and sentences in text
- `unit_converter` — converts between length, weight, and temperature units

---

### Agent06 · RAG Agent
**File:** `Tier 2/Agent06_rag.py`  
**What it does:** Loads `.txt` documents from `Tier 2/docs/`, splits them into chunks, embeds them with Google's embedding model, stores in a FAISS vector store, and retrieves the top-3 relevant chunks to answer questions. Logs retrieved chunks with source metadata.  
**APIs / Libraries:** `langchain-google-genai` (ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings), `langchain-community` (FAISS, DirectoryLoader), `langchain-text-splitters`  
**Tools:** None (uses retrieval, not tool-calling)  
**Docs folder:** `Tier 2/docs/` (6 files: langchain, langgraph, rag, vector_db, audit_logging, faiss)  
**Embedding model:** `models/gemini-embedding-001`

---

### Agent07 · Conversational Memory
**File:** `Tier 2/Agent07_conversational_memory.py`  
**What it does:** Multi-turn chat agent that persists the full conversation history to SQLite across restarts using `SQLChatMessageHistory`. Each turn logs the history snapshot before and after the exchange.  
**APIs / Libraries:** `langchain-google-genai`, `langchain-core` (RunnableWithMessageHistory), `langchain-community` (SQLChatMessageHistory), `sqlalchemy`  
**Tools:** None  
**Persistence:** `Tier 2/memory.db` (SQLite)

---

## Tier 3 — LangGraph Graphs

### Agent08 · LangGraph ReAct
**File:** `Tier 3/Agent08_langraph_react.py`  
**What it does:** Implements the classic Reason + Act loop as a hand-built `StateGraph` with two nodes: `llm_node` (calls LLM with tools bound) and `tool_node` (executes tools). Loops until the LLM produces a final answer with no tool calls. Logs every node transition, tool call, and cycle count.  
**APIs / Libraries:** `langchain-google-genai`, `langgraph` (StateGraph, ToolNode)  
**Tools:** `calculator`, `get_current_datetime`  
**Persistence:** None (stateless per run)

---

### Agent09 · LangGraph ReAct + Checkpointing
**File:** `Tier 3/Agent09_langraph_checkpoint.py`  
**What it does:** Same ReAct graph as Agent08 but compiled with a `SqliteSaver` checkpointer. Every node execution is snapshotted. Runs on the same `thread_id` resume from the last checkpoint — Turn 2 can reference results from Turn 1 without re-computing. Logs checkpoint IDs before and after each run.  
**APIs / Libraries:** `langchain-google-genai`, `langgraph` (StateGraph, ToolNode), `langgraph-checkpoint-sqlite` (SqliteSaver)  
**Tools:** `calculator`, `get_current_datetime`  
**Persistence:** `Tier 3/checkpoints.db` (SQLite)

---

### Agent10 · Human-in-the-Loop
**File:** `Tier 3/Agent10_human_in_loop.py`  
**What it does:** Adds an `approval_gate` node between `llm_node` and `tool_node`. Before any tool executes, `interrupt()` suspends the graph and surfaces the pending tool call for human approval. If approved, the tool runs. If rejected, a refusal `ToolMessage` is injected and the LLM responds gracefully. Logs the full trail: LLM call → interrupt → human decision → tool exec (or rejection) → LLM call.  
**APIs / Libraries:** `langchain-google-genai`, `langgraph` (StateGraph, ToolNode, interrupt, Command, MemorySaver)  
**Tools:**
- `calculator` — real Python math evaluator
- `send_email` — **simulated** (no real email sent; returns a `[SIMULATED]` string)  
**Persistence:** In-memory `MemorySaver` (required for interrupt/resume)

---

### Agent11 · Subgraph Agent
**File:** `Tier 3/Agent11_subgraph.py`  
**What it does:** A parent graph with a `router_node` that classifies queries as `research` or `direct`. Research queries are delegated to a compiled child `research_subgraph` (gather → summarise nodes) that loads answers from real docs. Direct queries are answered inline. Logs both parent and child node transitions separately.  
**APIs / Libraries:** `langchain-google-genai`, `langgraph` (StateGraph, nested subgraph compilation)  
**Tools:** None (uses file-based knowledge base)  
**Docs folder:** `Tier 3/docs/` (5 files: langchain, langgraph, audit, rag, subgraph)  
**Persistence:** None (stateless per run)

---

## Quick Reference

| Agent | Tier | Tools | Persistence | Key Concept |
|-------|------|-------|-------------|-------------|
| Agent01 | 1 | — | — | Bare LLM call |
| Agent02 | 1 | — | — | Prompt templates + LCEL |
| Agent03 | 1 | — | — | Structured JSON output |
| Agent04 | 2 | calculator | — | Single tool calling |
| Agent05 | 2 | calculator, datetime, word_counter, unit_converter | — | Multi-tool calling |
| Agent06 | 2 | — (retrieval) | — | RAG + FAISS + file docs |
| Agent07 | 2 | — | SQLite (`memory.db`) | Persistent conversation memory |
| Agent08 | 3 | calculator, datetime | — | LangGraph ReAct loop |
| Agent09 | 3 | calculator, datetime | SQLite (`checkpoints.db`) | Checkpointed multi-turn graph |
| Agent10 | 3 | calculator, send_email* | MemorySaver | Human-in-the-loop approval |
| Agent11 | 3 | — (file KB) | — | Parent + child subgraph |

*`send_email` is simulated — no real email is sent.
