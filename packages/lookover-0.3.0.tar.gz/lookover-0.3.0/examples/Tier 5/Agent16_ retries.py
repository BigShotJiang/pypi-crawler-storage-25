"""
agent_16_retries.py
--------------------
Phase 1 · Agent 16 — Long-Running Agent with Retries

Real tool calls against real external APIs with exponential backoff retry.
Failures come from genuine errors: bad ticker symbols, network issues, etc.

Tools (all inlined — no shared module):
  get_weather     : Open-Meteo API  (free, no key)
  get_stock_price : Yahoo Finance via yfinance  (pip install yfinance)
  calculator      : local safe eval
  wikipedia_search: MediaWiki REST API (no key)

Retry behaviour:
  - On ANY exception from a tool: log it, wait (backoff_base * 2^attempt), retry
  - After max_retries exhausted: record give-up, move to next tool call
  - All attempts (success + failure) logged individually

Run:
    python agent_16_retries.py
    LLM_PROVIDER=vertexai python agent_16_retries.py
    LLM_PROVIDER=googleai  python agent_16_retries.py
"""

import os
import sys
import time
import uuid
import json
import math
from typing import Annotated, TypedDict
from urllib import request as url_request, parse as url_parse
from urllib.error import URLError, HTTPError
from dotenv import load_dotenv

load_dotenv()

# ── Lookover SDK ─────────────────────────────────────────────────────────────
_sdk_path = os.getenv("LOOKOVER_SDK_PATH", "")
if _sdk_path and _sdk_path not in sys.path:
    sys.path.insert(0, _sdk_path)

from lookover_sdk.langgraph import LookoverLangGraphListener

_lookover = LookoverLangGraphListener(
    api_key=os.getenv("LOOKOVER_API_KEY", "lk_dev_local"),
    agent_id="agent_16_retries",
    agent_version="1.0.0",
    purpose="resilient_data_retrieval",
    base_url=os.getenv("LOOKOVER_BASE_URL", "http://localhost:8081"),
)

# Governance metadata for prescan/runtime evidence
ai_policy_ref = "LOOKOVER-AI-POLICY-v1"
ai_risk_assessment_ref = "LOOKOVER-RISK-ASSESS-v1"

# ═══════════════════════════════════════════════════════════════
#  LLM SETUP
# ═══════════════════════════════════════════════════════════════

PROVIDER = os.getenv("LLM_PROVIDER", "ollama").lower()

if PROVIDER == "ollama":
    from langchain_ollama import ChatOllama
    llm = ChatOllama(
        base_url=os.getenv("OLLAMA_BASE_URL", "http://192.168.1.17:11434"),
        model=os.getenv("OLLAMA_MODEL", "llama3.2"),
        temperature=0.0,
    )
elif PROVIDER == "vertexai":
    from langchain_google_vertexai import ChatVertexAI
    llm = ChatVertexAI(
        project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        model_name=os.getenv("VERTEXAI_MODEL", "gemini-1.5-flash-002"),
        temperature=0.0,
    )
elif PROVIDER == "googleai":
    from langchain_google_genai import ChatGoogleGenerativeAI
    llm = ChatGoogleGenerativeAI(
        model=os.getenv("GOOGLEAI_MODEL", "gemini-2.0-flash"),
        google_api_key=os.getenv("GOOGLE_API_KEY"),
        temperature=0.0,
    )
else:
    raise ValueError(f"Unknown LLM_PROVIDER='{PROVIDER}'. Use 'ollama', 'vertexai', or 'googleai'.")


# ═══════════════════════════════════════════════════════════════
#  TOOL DEFINITIONS  (real APIs, no mocking)
# ═══════════════════════════════════════════════════════════════

from langchain_core.tools import tool


@tool
def wikipedia_search(query: str) -> str:
    """
    Search Wikipedia and return the opening summary of the best matching article.
    Uses the MediaWiki REST API — no API key required.

    Args:
        query: The search term, e.g. "exponential backoff"
    """
    try:
        search_url = (
            "https://en.wikipedia.org/w/api.php?action=query&list=search"
            f"&srsearch={url_parse.quote(query)}&srlimit=1&format=json"
        )
        with url_request.urlopen(search_url, timeout=10) as resp:
            results = json.loads(resp.read()).get("query", {}).get("search", [])
        if not results:
            return f"No Wikipedia article found for: {query}"
        title = results[0]["title"]
        summary_url = (
            f"https://en.wikipedia.org/api/rest_v1/page/summary/{url_parse.quote(title)}"
        )
        with url_request.urlopen(summary_url, timeout=10) as resp:
            page = json.loads(resp.read())
        extract  = page.get("extract", "No extract available.")
        page_url = page.get("content_urls", {}).get("desktop", {}).get("page", "")
        return f"[Wikipedia: {title}]\n{extract}\nSource: {page_url}"
    except (URLError, HTTPError) as exc:
        raise RuntimeError(f"Wikipedia API error: {exc}") from exc


@tool
def web_search(query: str) -> str:
    """
    Perform a web search using DuckDuckGo's Instant Answer API.
    No API key required.

    Args:
        query: The search query, e.g. "retry patterns distributed systems"
    """
    try:
        url = (
            f"https://api.duckduckgo.com/?q={url_parse.quote(query)}"
            "&format=json&no_html=1&skip_disambig=1"
        )
        req = url_request.Request(url, headers={"User-Agent": "AuditSDK-Agent/1.0"})
        with url_request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        abstract = data.get("Abstract", "").strip()
        if abstract:
            return f"{abstract}\nSource: {data.get('AbstractURL', '')}"
        topics = data.get("RelatedTopics", [])[:3]
        snippets = [t["Text"] for t in topics if isinstance(t, dict) and t.get("Text")]
        return "\n\n".join(snippets) if snippets else f"No result found for: {query}"
    except (URLError, HTTPError) as exc:
        raise RuntimeError(f"DuckDuckGo API error: {exc}") from exc


@tool
def get_weather(location: str) -> str:
    """
    Get the current weather for any city using the Open-Meteo API.
    No API key required.

    Args:
        location: City name, e.g. "Tokyo" or "Berlin"
    """
    try:
        geo_url = (
            f"https://geocoding-api.open-meteo.com/v1/search"
            f"?name={url_parse.quote(location)}&count=1&language=en&format=json"
        )
        with url_request.urlopen(geo_url, timeout=10) as resp:
            geo = json.loads(resp.read())
        results = geo.get("results", [])
        if not results:
            return f"Could not geocode location: {location}"
        r    = results[0]
        lat, lon = r["latitude"], r["longitude"]
        name, country = r.get("name", location), r.get("country", "")
        weather_url = (
            f"https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            f"&current=temperature_2m,relative_humidity_2m,wind_speed_10m,"
            f"weather_code,apparent_temperature"
            f"&wind_speed_unit=kmh&temperature_unit=celsius&timezone=auto"
        )
        with url_request.urlopen(weather_url, timeout=10) as resp:
            wx = json.loads(resp.read())
        cur   = wx.get("current", {})
        temp  = cur.get("temperature_2m", "N/A")
        feels = cur.get("apparent_temperature", "N/A")
        hum   = cur.get("relative_humidity_2m", "N/A")
        wind  = cur.get("wind_speed_10m", "N/A")
        WMO   = {0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
                 45: "Fog", 51: "Light drizzle", 61: "Slight rain", 63: "Moderate rain",
                 65: "Heavy rain", 71: "Slight snow", 80: "Slight showers",
                 95: "Thunderstorm"}
        condition = WMO.get(cur.get("weather_code", 0), f"Code {cur.get('weather_code', 0)}")
        return (f"Weather in {name}, {country}:\n"
                f"  Condition  : {condition}\n"
                f"  Temperature: {temp}°C (feels like {feels}°C)\n"
                f"  Humidity   : {hum}%\n"
                f"  Wind       : {wind} km/h")
    except (URLError, HTTPError) as exc:
        raise RuntimeError(f"Open-Meteo API error: {exc}") from exc


@tool
def get_stock_price(ticker: str) -> str:
    """
    Get the current stock price using Yahoo Finance.
    Requires: pip install yfinance

    Args:
        ticker: Stock ticker symbol, e.g. "NVDA", "AAPL", "MSFT"
    """
    try:
        import yfinance as yf
    except ImportError:
        raise RuntimeError("yfinance not installed. Run: pip install yfinance")
    try:
        stock  = yf.Ticker(ticker.upper())
        info   = stock.info
        price  = info.get("currentPrice") or info.get("regularMarketPrice")
        if price is None:
            raise RuntimeError(f"No price data returned for ticker '{ticker}'. "
                               "It may be invalid or delisted.")
        prev    = info.get("previousClose", "N/A")
        name    = info.get("longName", ticker.upper())
        currency = info.get("currency", "USD")
        change  = round(price - prev, 2) if isinstance(prev, (int, float)) else "N/A"
        pct     = round((change / prev) * 100, 2) if isinstance(change, (int, float)) and prev else "N/A"
        return (f"Stock: {name} ({ticker.upper()})\n"
                f"  Price     : {price} {currency}\n"
                f"  Change    : {change} ({pct}%)\n"
                f"  Prev close: {prev} {currency}")
    except Exception as exc:
        raise RuntimeError(f"yfinance error for '{ticker}': {exc}") from exc


@tool
def calculator(expression: str) -> str:
    """
    Evaluates a mathematical expression safely.
    Supports: +, -, *, /, **, sqrt(), log(), log10(), sin(), cos(), pi, e.

    Args:
        expression: A Python math expression, e.g. "sqrt(98596) + log10(1e6)"
    """
    try:
        allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
        allowed.update({"abs": abs, "round": round})
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return f"{expression} = {result}"
    except Exception as exc:
        raise RuntimeError(f"Calculator error for '{expression}': {exc}") from exc


TOOLS     = [get_weather, get_stock_price, calculator, wikipedia_search]
TOOLS_MAP = {t.name: t for t in TOOLS}


# ═══════════════════════════════════════════════════════════════
#  STATE
# ═══════════════════════════════════════════════════════════════

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage, AIMessage, ToolMessage
from langgraph.graph.message import add_messages


class RetryState(TypedDict):
    messages:         Annotated[list[AnyMessage], add_messages]
    original_task:    str
    pending_calls:    list[dict]
    attempt_log:      list[dict]
    results:          dict
    current_call_idx: int
    retry_count:      int
    max_retries:      int
    backoff_base:     float
    total_backoff_ms: float
    all_done:         bool


# ═══════════════════════════════════════════════════════════════
#  GRAPH NODES
# ═══════════════════════════════════════════════════════════════

from langgraph.graph import StateGraph, START, END


def planner_node(state: RetryState) -> dict:
    """LLM decides which tool calls to make."""
    bound_llm = llm.bind_tools(TOOLS)
    response  = bound_llm.invoke([
        SystemMessage(content=(
            "You are a task planner. Call all tools needed to answer the user's request. "
            "Do not guess values — always call the appropriate tool."
        )),
        HumanMessage(content=state["original_task"]),
    ])
    pending = [
        {"id": tc["id"], "name": tc["name"], "args": tc["args"]}
        for tc in getattr(response, "tool_calls", [])
    ]
    return {
        "pending_calls":    pending,
        "current_call_idx": 0,
        "retry_count":      0,
        "results":          {},
        "attempt_log":      [],
        "total_backoff_ms": 0.0,
        "all_done":         False,
        "messages": [AIMessage(content=(
            f"[Planner] Will call {len(pending)} tool(s): {[p['name'] for p in pending]}"
        ))],
    }


def tool_executor_node(state: RetryState) -> dict:
    """
    Executes the current tool call with exponential backoff retry.
    Advances to the next call on success or after max retries exhausted.
    """
    idx          = state["current_call_idx"]
    pending      = state["pending_calls"]
    attempt_log  = list(state["attempt_log"])
    results      = dict(state["results"])
    retry_count  = state["retry_count"]
    max_retries  = state["max_retries"]
    backoff_base = state["backoff_base"]
    total_back   = state["total_backoff_ms"]

    if idx >= len(pending):
        return {"all_done": True}

    call      = pending[idx]
    tool_name = call["name"]
    tool_args = call["args"]
    tool_fn   = TOOLS_MAP.get(tool_name)

    if not tool_fn:
        results[f"{tool_name}_{idx}"] = f"Unknown tool: {tool_name}"
        return {"results": results, "current_call_idx": idx + 1, "retry_count": 0}

    # Exponential backoff before retry attempts
    backoff_ms = 0.0
    if retry_count > 0:
        backoff_s  = backoff_base * (2 ** (retry_count - 1))
        backoff_ms = round(backoff_s * 1000, 2)
        time.sleep(backoff_s)
        total_back += backoff_ms

    t0 = time.perf_counter()
    attempt_entry = {
        "tool":        tool_name,
        "args":        tool_args,
        "call_id":     call["id"],
        "attempt":     retry_count + 1,
        "max_retries": max_retries,
        "backoff_ms":  backoff_ms,
        "success":     False,
        "error_type":  None,
        "error_msg":   None,
        "result":      None,
        "latency_ms":  0,
    }

    try:
        result = tool_fn.invoke(tool_args)
        attempt_entry["success"]    = True
        attempt_entry["result"]     = result
        attempt_entry["latency_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        attempt_log.append(attempt_entry)
        results[tool_name] = result
        return {
            "attempt_log":      attempt_log,
            "results":          results,
            "current_call_idx": idx + 1,
            "retry_count":      0,
            "total_backoff_ms": total_back,
            "messages": [AIMessage(content=(
                f"[ToolExecutor] ✔ {tool_name} succeeded on attempt {retry_count + 1}"
            ))],
        }
    except Exception as exc:
        attempt_entry["error_type"] = type(exc).__name__
        attempt_entry["error_msg"]  = str(exc)
        attempt_entry["latency_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        attempt_log.append(attempt_entry)

        if retry_count >= max_retries:
            results[tool_name] = f"FAILED after {retry_count + 1} attempts. Last error: {exc}"
            return {
                "attempt_log":      attempt_log,
                "results":          results,
                "current_call_idx": idx + 1,
                "retry_count":      0,
                "total_backoff_ms": total_back,
                "messages": [AIMessage(content=(
                    f"[ToolExecutor] ✘ {tool_name} gave up after {retry_count + 1} attempts."
                ))],
            }
        return {
            "attempt_log":      attempt_log,
            "retry_count":      retry_count + 1,
            "total_backoff_ms": total_back,
            "messages": [AIMessage(content=(
                f"[ToolExecutor] ↺ {tool_name} failed (attempt {retry_count + 1}), "
                f"retrying… [{type(exc).__name__}: {str(exc)[:80]}]"
            ))],
        }


def summariser_node(state: RetryState) -> dict:
    """LLM summarises all tool results into a final answer."""
    results_text = "\n".join(f"  {k}: {v}" for k, v in state["results"].items())
    response = llm.invoke([
        SystemMessage(content=(
            "Summarise the tool results below into a clear, complete answer. "
            "If some tools failed, acknowledge it and summarise what was obtained."
        )),
        HumanMessage(content=(
            f"Task: {state['original_task']}\n\nTool results:\n{results_text}"
        )),
    ])
    return {
        "all_done": True,
        "messages": [AIMessage(content=f"[Summariser] {response.content}")],
    }


# ═══════════════════════════════════════════════════════════════
#  ROUTING
# ═══════════════════════════════════════════════════════════════

def route_after_executor(state: RetryState) -> str:
    if state.get("all_done"):
        return "summariser_node"
    if state["current_call_idx"] >= len(state["pending_calls"]):
        return "summariser_node"
    return "tool_executor_node"


# ═══════════════════════════════════════════════════════════════
#  BUILD GRAPH
# ═══════════════════════════════════════════════════════════════

builder = StateGraph(RetryState)
builder.add_node("planner_node",       planner_node)
builder.add_node("tool_executor_node", tool_executor_node)
builder.add_node("summariser_node",    summariser_node)

builder.add_edge(START, "planner_node")
builder.add_edge("planner_node", "tool_executor_node")
builder.add_conditional_edges(
    "tool_executor_node",
    route_after_executor,
    {"tool_executor_node": "tool_executor_node", "summariser_node": "summariser_node"},
)
builder.add_edge("summariser_node", END)

graph = builder.compile()


# ═══════════════════════════════════════════════════════════════
#  AGENT
# ═══════════════════════════════════════════════════════════════

def run_agent(
    user_input:   str,
    max_retries:  int   = 3,
    backoff_base: float = 0.5,
) -> dict:
    run_id = str(uuid.uuid4())
    initial: RetryState = {
        "messages":         [HumanMessage(content=user_input)],
        "original_task":    user_input,
        "pending_calls":    [],
        "attempt_log":      [],
        "results":          {},
        "current_call_idx": 0,
        "retry_count":      0,
        "max_retries":      max_retries,
        "backoff_base":     backoff_base,
        "total_backoff_ms": 0.0,
        "all_done":         False,
    }

    t0          = time.perf_counter()
    final_state = _lookover.invoke(graph, initial, {"recursion_limit": 60})
    latency_ms  = round((time.perf_counter() - t0) * 1000, 2)

    attempt_log = final_state["attempt_log"]
    successes   = [a for a in attempt_log if a["success"]]
    failures    = [a for a in attempt_log if not a["success"]]
    succeeded_names = {a["tool"] for a in successes}

    final_answer = ""
    for msg in reversed(final_state["messages"]):
        content = getattr(msg, "content", "")
        if isinstance(msg, AIMessage) and content.startswith("[Summariser]"):
            final_answer = content.replace("[Summariser] ", "")
            break

    return {
        "agent":            "agent_16_retries",
        "provider":         PROVIDER,
        "model":            getattr(llm, "model", getattr(llm, "model_name", "unknown")),
        "run_id":           run_id,
        "input":            user_input,
        "output":           final_answer,
        "attempt_log":      attempt_log,
        "total_attempts":   len(attempt_log),
        "successful_calls": len(successes),
        "failed_calls":     len(failures),
        "tools_succeeded":  list(succeeded_names),
        "tools_failed":     list({a["tool"] for a in failures if a["tool"] not in succeeded_names}),
        "total_backoff_ms": final_state["total_backoff_ms"],
        "latency_ms":       latency_ms,
    }


# ═══════════════════════════════════════════════════════════════
#  CLI  — includes a deliberately bad ticker to trigger real retries
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    question = (
        sys.argv[1] if len(sys.argv) > 1
        else (
            "What is the current weather in Tokyo, the NVDA stock price, "
            "the price for ticker INVALID_XYZ_TICKER, "
            "sqrt(98596) + log10(1000000), "
            "and search Wikipedia for 'exponential backoff'."
        )
    )

    result = run_agent(question, max_retries=3, backoff_base=0.5)

    print(f"\nProvider         : {result['provider']}  ({result['model']})")
    print(f"Run ID           : {result['run_id']}")
    print(f"Total attempts   : {result['total_attempts']}")
    print(f"Successes        : {result['successful_calls']}")
    print(f"Failures         : {result['failed_calls']}")
    print(f"Tools succeeded  : {result['tools_succeeded']}")
    print(f"Tools failed     : {result['tools_failed']}")
    print(f"Total backoff    : {result['total_backoff_ms']:.1f} ms")
    print(f"\nAttempt log:")
    for a in result["attempt_log"]:
        status = "✔" if a["success"] else "✘"
        err    = f"  [{a['error_type']}] {a['error_msg'][:80]}" if not a["success"] else ""
        print(f"  {status} {a['tool'].ljust(20)} attempt={a['attempt']}  "
              f"latency={a['latency_ms']} ms  backoff={a['backoff_ms']:.0f} ms{err}")
    print(f"\nOutput  : {result['output'][:500]}")
    print(f"Latency : {result['latency_ms']} ms\n")
