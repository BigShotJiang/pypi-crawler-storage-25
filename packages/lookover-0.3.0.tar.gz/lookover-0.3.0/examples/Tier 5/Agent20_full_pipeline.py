"""
agent_20_full_pipeline.py
--------------------------
Phase 1 · Agent 20 — Full Agentic Pipeline (End-to-End)

Every stage calls real external APIs. All tools are defined inline.

Pipeline:
  [1] Planner         : LLM decomposes task into sub-tasks
  [2] RAG Researcher  : FAISS vector retrieval + wikipedia_search + web_search
  [3] Tool Executor   : calculator + get_stock_price + get_weather + get_datetime
                        (with real retry on genuine exceptions)
  [4] Critic          : web_search for counterarguments, scores 0–10
  [5] Writer          : write_file → saves to /tmp/agent20_output.txt
  [6] Checkpointing   : MemorySaver persists state after every node

Real external calls:
  ✔ Wikipedia MediaWiki REST API (no key)
  ✔ DuckDuckGo Instant Answer API (no key)
  ✔ Open-Meteo weather API (no key)
  ✔ Yahoo Finance via yfinance
  ✔ FAISS in-memory vector store (local embeddings)
  ✔ Local file write
  ✔ LangGraph MemorySaver (in-process SQLite)

Run:
    python agent_20_full_pipeline.py
    LLM_PROVIDER=vertexai python agent_20_full_pipeline.py
    LLM_PROVIDER=googleai  python agent_20_full_pipeline.py
"""

import os
import sys
import time
import uuid
import json
import math
from datetime import datetime, timezone, timedelta
from urllib import request as url_request, parse as url_parse, error as url_error
from typing import Annotated, TypedDict
from dotenv import load_dotenv

load_dotenv()

# ── Lookover SDK ─────────────────────────────────────────────────────────────
_sdk_path = os.getenv("LOOKOVER_SDK_PATH", "")
if _sdk_path and _sdk_path not in sys.path:
    sys.path.insert(0, _sdk_path)

from lookover_sdk.langgraph import LookoverLangGraphListener

_lookover = LookoverLangGraphListener(
    api_key=os.getenv("LOOKOVER_API_KEY", "lk_dev_local"),
    agent_id="agent_20_full_pipeline",
    agent_version="1.0.0",
    purpose="full_pipeline_research_publishing",
    base_url=os.getenv("LOOKOVER_BASE_URL", "http://localhost:8081"),
)

# Governance metadata for prescan/runtime evidence
ai_policy_ref = "LOOKOVER-AI-POLICY-v1"
ai_risk_assessment_ref = "LOOKOVER-RISK-ASSESS-v1"

# ═══════════════════════════════════════════════════════════════
#  LLM + EMBEDDINGS SETUP
# ═══════════════════════════════════════════════════════════════

PROVIDER = os.getenv("LLM_PROVIDER", "ollama").lower()

if PROVIDER == "ollama":
    from langchain_ollama import ChatOllama, OllamaEmbeddings
    llm = ChatOllama(
        base_url=os.getenv("OLLAMA_BASE_URL", "http://192.168.1.17:11434"),
        model=os.getenv("OLLAMA_MODEL", "llama3.2"),
        temperature=0.0,
    )
    embeddings = OllamaEmbeddings(
        base_url=os.getenv("OLLAMA_BASE_URL", "http://192.168.1.17:11434"),
        model=os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text"),
    )
elif PROVIDER == "vertexai":
    from langchain_google_vertexai import ChatVertexAI, VertexAIEmbeddings
    llm = ChatVertexAI(
        project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        model_name=os.getenv("VERTEXAI_MODEL", "gemini-1.5-flash-002"),
        temperature=0.0,
    )
    embeddings = VertexAIEmbeddings(
        project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        model_name="text-embedding-004",
    )
elif PROVIDER == "googleai":
    from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
    llm = ChatGoogleGenerativeAI(
        model=os.getenv("GOOGLEAI_MODEL", "gemini-2.0-flash"),
        google_api_key=os.getenv("GOOGLE_API_KEY"),
        temperature=0.0,
    )
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/gemini-embedding-001",
        google_api_key=os.getenv("GOOGLE_API_KEY"),
    )
else:
    raise ValueError(f"Unknown LLM_PROVIDER='{PROVIDER}'. Use 'ollama', 'vertexai', or 'googleai'.")

# ═══════════════════════════════════════════════════════════════
#  TOOLS  (all inline)
# ═══════════════════════════════════════════════════════════════

from langchain_core.tools import tool


@tool
def wikipedia_search(query: str) -> str:
    """
    Search Wikipedia and return the opening summary. MediaWiki REST API — no key required.
    Args:
        query: The search term
    """
    ua = "LookoverAuditSDK/1.0 (https://github.com/lookover/lookover; audit-examples)"
    try:
        req = url_request.Request(
            "https://en.wikipedia.org/w/api.php?action=query&list=search"
            f"&srsearch={url_parse.quote(query)}&srlimit=1&format=json",
            headers={"User-Agent": ua},
        )
        with url_request.urlopen(req, timeout=10) as resp:
            results = json.loads(resp.read()).get("query", {}).get("search", [])
        if not results:
            return f"No Wikipedia article found for: {query}"
        title = results[0]["title"]
        req2 = url_request.Request(
            f"https://en.wikipedia.org/api/rest_v1/page/summary/{url_parse.quote(title)}",
            headers={"User-Agent": ua},
        )
        with url_request.urlopen(req2, timeout=10) as resp:
            page = json.loads(resp.read())
        url = page.get("content_urls", {}).get("desktop", {}).get("page", "")
        return f"[Wikipedia: {title}]\n{page.get('extract', 'No extract.')}\nSource: {url}"
    except (url_error.URLError, url_error.HTTPError) as exc:
        raise RuntimeError(f"Wikipedia API error: {exc}") from exc


@tool
def web_search(query: str) -> str:
    """
    DuckDuckGo Instant Answer API. No API key required.
    Args:
        query: The search query
    """
    try:
        req = url_request.Request(
            f"https://api.duckduckgo.com/?q={url_parse.quote(query)}&format=json&no_html=1&skip_disambig=1",
            headers={"User-Agent": "AuditSDK-Agent/1.0"},
        )
        with url_request.urlopen(req, timeout=10) as resp:
            raw = resp.read()
        if not raw:
            return f"No instant answer found for: {query}"
        data = json.loads(raw)
        abstract = data.get("Abstract", "").strip()
        if abstract:
            return f"{abstract}\nSource: {data.get('AbstractURL', '')}"
        topics = [t["Text"] for t in data.get("RelatedTopics", [])[:3]
                  if isinstance(t, dict) and t.get("Text")]
        return "\n\n".join(topics) if topics else f"No instant answer found for: {query}"
    except (url_error.URLError, url_error.HTTPError, json.JSONDecodeError):
        return f"No instant answer found for: {query}"


@tool
def get_weather(location: str) -> str:
    """
    Current weather via Open-Meteo API. No API key required.
    Args:
        location: City name
    """
    try:
        with url_request.urlopen(
            f"https://geocoding-api.open-meteo.com/v1/search?name={url_parse.quote(location)}&count=1&language=en&format=json",
            timeout=10,
        ) as resp:
            results = json.loads(resp.read()).get("results", [])
        if not results:
            return f"Could not geocode: {location}"
        r = results[0]
        lat, lon = r["latitude"], r["longitude"]
        name, country = r.get("name", location), r.get("country", "")
        with url_request.urlopen(
            f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
            f"&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code,apparent_temperature&timezone=auto",
            timeout=10,
        ) as resp:
            cur = json.loads(resp.read()).get("current", {})
        WMO  = {0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
                45: "Fog", 61: "Slight rain", 63: "Moderate rain", 80: "Slight showers", 95: "Thunderstorm"}
        cond = WMO.get(cur.get("weather_code", 0), f"Code {cur.get('weather_code', 0)}")
        return (f"Weather in {name}, {country}: {cond}, "
                f"{cur.get('temperature_2m')}°C (feels {cur.get('apparent_temperature')}°C), "
                f"humidity {cur.get('relative_humidity_2m')}%, wind {cur.get('wind_speed_10m')} km/h.")
    except (url_error.URLError, url_error.HTTPError) as exc:
        raise RuntimeError(f"Open-Meteo error: {exc}") from exc


@tool
def get_stock_price(ticker: str) -> str:
    """
    Current stock price via Yahoo Finance. Requires: pip install yfinance
    Args:
        ticker: e.g. "AAPL"
    """
    try:
        import yfinance as yf
    except ImportError:
        raise RuntimeError("yfinance not installed. Run: pip install yfinance")
    try:
        info  = yf.Ticker(ticker.upper()).info
        price = info.get("currentPrice") or info.get("regularMarketPrice")
        if price is None:
            raise RuntimeError(f"No price data for '{ticker}'.")
        prev   = info.get("previousClose", "N/A")
        name   = info.get("longName", ticker.upper())
        change = round(price - prev, 2) if isinstance(prev, (int, float)) else "N/A"
        pct    = round((change / prev) * 100, 2) if isinstance(change, (int, float)) and prev else "N/A"
        return (f"Stock: {name} ({ticker.upper()}) | Price: {price} {info.get('currency','USD')} | "
                f"Change: {change} ({pct}%) | Source: Yahoo Finance")
    except Exception as exc:
        raise RuntimeError(f"yfinance error for '{ticker}': {exc}") from exc


@tool
def calculator(expression: str) -> str:
    """
    Safe math eval. Supports: +, -, *, /, **, sqrt(), log(), log10(), sin(), cos(), pi, e.
    Args:
        expression: e.g. "sqrt(144) + log10(1000)"
    """
    try:
        allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
        allowed.update({"abs": abs, "round": round})
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return f"{expression} = {result}"
    except Exception as exc:
        raise RuntimeError(f"Calculator error for '{expression}': {exc}") from exc


@tool
def get_datetime(timezone_name: str = "UTC") -> str:
    """
    Current UTC date/time plus local equivalent.
    Args:
        timezone_name: e.g. "UTC", "IST", "EST", "JST"
    """
    offsets = {"UTC": 0, "GMT": 0, "IST": 5.5, "EST": -5, "EDT": -4,
               "CST": -6, "PST": -8, "CET": 1, "JST": 9, "AEST": 10, "SGT": 8}
    now_utc  = datetime.now(timezone.utc)
    offset_h = offsets.get(timezone_name.upper(), 0)
    local_dt = now_utc + timedelta(hours=offset_h)
    sign     = "+" if offset_h >= 0 else ""
    return (f"UTC: {now_utc.strftime('%Y-%m-%d %H:%M:%S %Z')} | "
            f"{timezone_name.upper()}: {local_dt.strftime('%Y-%m-%d %H:%M:%S')} (UTC{sign}{offset_h})")


@tool
def write_file(path: str, content: str) -> str:
    """
    Writes text to a local file (creates or overwrites).
    Args:
        path   : e.g. "/tmp/output.txt"
        content: Text to write.
    """
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Written {len(content)} chars to {path}"
    except Exception as exc:
        raise RuntimeError(f"File write error: {exc}") from exc


RESEARCH_TOOLS = [wikipedia_search, web_search]
EXEC_TOOLS     = [calculator, get_stock_price, get_weather, get_datetime]
CRITIC_TOOLS   = [web_search]
WRITER_TOOLS   = [write_file]
OUTPUT_FILE    = "/tmp/agent20_output.txt"

# ═══════════════════════════════════════════════════════════════
#  RAG VECTOR STORE  (FAISS + local corpus)
# ═══════════════════════════════════════════════════════════════

from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS

CORPUS = [
    Document(page_content="LangGraph is a graph-based agent framework built on LangChain supporting cycles, checkpointing, and human-in-the-loop patterns.", metadata={"source": "langgraph_docs"}),
    Document(page_content="Audit logging for AI agents must capture: prompts, completions, token usage, latency, tool calls with inputs/outputs, retrieved chunks, and node transitions.", metadata={"source": "audit_guide"}),
    Document(page_content="Retrieval-Augmented Generation (RAG) injects retrieved documents into the LLM context to reduce hallucinations and ground answers in real sources.", metadata={"source": "rag_explainer"}),
    Document(page_content="Exponential backoff retries transient failures with delays: base_seconds * 2^(attempt-1). Used for rate limits, timeouts, and 5xx errors.", metadata={"source": "retry_patterns"}),
    Document(page_content="Streaming agents emit tokens progressively using astream_events(). TTFT (time-to-first-token) and inter-token latency are the key metrics.", metadata={"source": "streaming_guide"}),
    Document(page_content="Multi-agent systems coordinate via supervisor routing, hierarchical delegation, parallel fan-out, or collaborative shared message boards.", metadata={"source": "multiagent_guide"}),
    Document(page_content="Idempotency keys prevent duplicate side effects when an agent retries. Generate them by hashing the payload content deterministically.", metadata={"source": "idempotency_guide"}),
    Document(page_content="LangChain's MemorySaver checkpointer saves graph state after every node execution, enabling pause-and-resume and time-travel debugging.", metadata={"source": "checkpointing_docs"}),
]

print("[Pipeline] Building FAISS vector store …")
vector_store = FAISS.from_documents(CORPUS, embeddings)
retriever    = vector_store.as_retriever(search_kwargs={"k": 3})

# ═══════════════════════════════════════════════════════════════
#  STATE
# ═══════════════════════════════════════════════════════════════

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage, AIMessage, ToolMessage
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode


class PipelineState(TypedDict):
    messages:          Annotated[list[AnyMessage], add_messages]
    original_query:    str
    run_id:            str
    plan:              dict
    retrieved_chunks:  list[dict]
    rag_answer:        str
    tool_results:      list[dict]
    critic_score:      int
    critic_feedback:   str
    final_answer:      str
    stage_spans:       list[dict]
    node_transitions:  list[str]


# ═══════════════════════════════════════════════════════════════
#  HELPER — real ReAct loop with per-tool retry
# ═══════════════════════════════════════════════════════════════

def react_loop(system: str, user: str, tools: list,
               max_iters: int = 5, max_retries: int = 2,
               backoff_base: float = 0.5) -> tuple[str, list[dict], float]:
    bound_llm  = llm.bind_tools(tools) if tools else llm
    tool_node  = ToolNode(tools) if tools else None
    tc_log     = []
    messages   = [SystemMessage(content=system), HumanMessage(content=user)]
    t0         = time.perf_counter()

    for _ in range(max_iters):
        response = bound_llm.invoke(messages)
        messages.append(response)
        if not getattr(response, "tool_calls", None) or not tool_node:
            break

        for tc in response.tool_calls:
            tool_fn = next((t for t in tools if t.name == tc["name"]), None)
            if not tool_fn:
                continue
            for attempt in range(1, max_retries + 2):
                if attempt > 1:
                    time.sleep(backoff_base * (2 ** (attempt - 2)))
                t_tool = time.perf_counter()
                try:
                    result  = tool_fn.invoke(tc["args"])
                    tool_ms = round((time.perf_counter() - t_tool) * 1000, 2)
                    tm = ToolMessage(content=str(result), tool_call_id=tc["id"])
                    messages.append(tm)
                    tc_log.append({
                        "tool":    tc["name"],
                        "args":    tc["args"],
                        "output":  str(result)[:300],
                        "attempt": attempt,
                        "ms":      tool_ms,
                    })
                    break
                except Exception as exc:
                    if attempt >= max_retries + 1:
                        err_msg = f"Error after {attempt} attempts: {exc}"
                        tm = ToolMessage(content=err_msg, tool_call_id=tc["id"])
                        messages.append(tm)
                        tc_log.append({
                            "tool":       tc["name"],
                            "args":       tc["args"],
                            "output":     err_msg,
                            "attempt":    attempt,
                            "error_type": type(exc).__name__,
                            "ms":         round((time.perf_counter() - t_tool) * 1000, 2),
                        })

    total_ms = round((time.perf_counter() - t0) * 1000, 2)
    raw = getattr(messages[-1], "content", "") or ""
    if isinstance(raw, list):
        raw = " ".join(
            p.get("text", "") if isinstance(p, dict) else str(p) for p in raw
        )
    return raw, tc_log, total_ms


# ═══════════════════════════════════════════════════════════════
#  PIPELINE STAGE NODES
# ═══════════════════════════════════════════════════════════════

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver


def _span(stage: str, t0: float, **kwargs) -> dict:
    return {"stage": stage, "ms": round((time.perf_counter() - t0) * 1000, 2), **kwargs}


def planner_node(state: PipelineState) -> dict:
    t0 = time.perf_counter()
    response = llm.invoke([
        SystemMessage(content=(
            "You are a task planner for a 5-stage AI pipeline. "
            "Decompose the query into sub-tasks for: researcher, tool_executor, writer. "
            "Respond ONLY with JSON (no fences): "
            '{"research_task": "...", "tool_task": "...", "write_task": "..."}'
        )),
        HumanMessage(content=state["original_query"]),
    ])
    try:
        plan = json.loads(response.content.strip().strip("```json").strip("```"))
    except Exception:
        plan = {
            "research_task": f"Research key facts about: {state['original_query']}",
            "tool_task":     "Fetch any relevant numerical data (stock, weather, calculations).",
            "write_task":    f"Write a complete answer to: {state['original_query']}",
        }
    span = _span("planner", t0, plan=plan)
    return {
        "plan":             plan,
        "stage_spans":      state.get("stage_spans", []) + [span],
        "node_transitions": state.get("node_transitions", []) + ["planner"],
        "messages":         [AIMessage(content=f"[Planner] {plan}")],
    }


def rag_researcher_node(state: PipelineState) -> dict:
    t0   = time.perf_counter()
    task = state["plan"].get("research_task", state["original_query"])

    # Vector retrieval
    t_retr  = time.perf_counter()
    docs    = retriever.invoke(task)
    retr_ms = round((time.perf_counter() - t_retr) * 1000, 2)
    chunks  = [{"content": d.page_content, "source": d.metadata.get("source")} for d in docs]
    context = "\n\n".join(d.page_content for d in docs)

    output, tc_log, gen_ms = react_loop(
        system=(
            "You are a researcher. Use the context AND search tools to answer accurately. "
            f"Context from knowledge base:\n{context}\n\n"
            "Supplement with wikipedia_search or web_search for current information."
        ),
        user=task,
        tools=RESEARCH_TOOLS,
    )

    span = _span("rag_researcher", t0,
                 retrieve_ms=retr_ms, generation_ms=gen_ms,
                 num_chunks=len(chunks),
                 sources=[c["source"] for c in chunks],
                 tool_calls=tc_log)
    return {
        "retrieved_chunks":  chunks,
        "rag_answer":        output,
        "stage_spans":       state.get("stage_spans", []) + [span],
        "node_transitions":  state.get("node_transitions", []) + ["rag_researcher"],
        "messages":          [AIMessage(content=f"[Researcher] {output[:300]}")],
    }


def tool_executor_node(state: PipelineState) -> dict:
    t0   = time.perf_counter()
    task = state["plan"].get("tool_task", "Fetch any relevant numerical data.")

    output, tc_log, ms = react_loop(
        system=(
            "You are a data executor. Use calculator for maths, get_stock_price for market data, "
            "get_weather for weather, get_datetime for the current time. "
            "Call every tool that is relevant. Never guess."
        ),
        user=task,
        tools=EXEC_TOOLS,
        max_retries=2,
        backoff_base=0.5,
    )

    span = _span("tool_executor", t0, tool_calls=tc_log, ms=ms)
    return {
        "tool_results":     tc_log,
        "stage_spans":      state.get("stage_spans", []) + [span],
        "node_transitions": state.get("node_transitions", []) + ["tool_executor"],
        "messages":         [AIMessage(content=f"[ToolExecutor] {len(tc_log)} tool(s) completed.")],
    }


def critic_node(state: PipelineState) -> dict:
    t0 = time.perf_counter()

    critic_output, tc_log, ms = react_loop(
        system=(
            "You are a quality critic. Use web_search to find counterarguments or limitations. "
            "Then score the research output 0–10 and give one sentence of feedback. "
            'Respond with JSON: {"score": <int>, "feedback": "<sentence>"}'
        ),
        user=(
            f"Task: {state['original_query']}\n\n"
            f"Research: {state['rag_answer'][:500]}\n\n"
            f"Tool results: {json.dumps(state['tool_results'])[:300]}"
        ),
        tools=CRITIC_TOOLS,
    )

    try:
        raw      = critic_output.strip().strip("```json").strip("```")
        data     = json.loads(raw)
        score    = int(data.get("score", 7))
        feedback = data.get("feedback", critic_output.strip())
    except Exception:
        score, feedback = 7, critic_output.strip()

    span = _span("critic", t0, score=score, feedback=feedback, tool_calls=tc_log, ms=ms)
    return {
        "critic_score":     score,
        "critic_feedback":  feedback,
        "stage_spans":      state.get("stage_spans", []) + [span],
        "node_transitions": state.get("node_transitions", []) + ["critic"],
        "messages":         [AIMessage(content=f"[Critic] Score={score}/10. {feedback}")],
    }


def writer_node(state: PipelineState) -> dict:
    t0   = time.perf_counter()
    task = state["plan"].get("write_task", state["original_query"])

    output, tc_log, ms = react_loop(
        system=(
            f"You are a professional writer. Produce a clear, complete final answer "
            f"and save it to {OUTPUT_FILE} using write_file."
        ),
        user=(
            f"Research findings:\n{state['rag_answer']}\n\n"
            f"Tool results: {json.dumps(state['tool_results'])}\n\n"
            f"Critic feedback (score={state['critic_score']}/10): {state['critic_feedback']}\n\n"
            f"Write task: {task}"
        ),
        tools=WRITER_TOOLS,
    )

    try:
        with open(OUTPUT_FILE, "r") as f:
            final_answer = f.read()
    except FileNotFoundError:
        final_answer = output

    span = _span("writer", t0, tool_calls=tc_log, ms=ms, output_file=OUTPUT_FILE)
    return {
        "final_answer":     final_answer,
        "stage_spans":      state.get("stage_spans", []) + [span],
        "node_transitions": state.get("node_transitions", []) + ["writer"],
        "messages":         [AIMessage(content=f"[Writer] Saved to {OUTPUT_FILE}")],
    }


# ═══════════════════════════════════════════════════════════════
#  BUILD GRAPH  with MemorySaver checkpointer
# ═══════════════════════════════════════════════════════════════

checkpointer = MemorySaver()

builder = StateGraph(PipelineState)
builder.add_node("planner_node",        planner_node)
builder.add_node("rag_researcher_node", rag_researcher_node)
builder.add_node("tool_executor_node",  tool_executor_node)
builder.add_node("critic_node",         critic_node)
builder.add_node("writer_node",         writer_node)

builder.add_edge(START,                 "planner_node")
builder.add_edge("planner_node",        "rag_researcher_node")
builder.add_edge("rag_researcher_node", "tool_executor_node")
builder.add_edge("tool_executor_node",  "critic_node")
builder.add_edge("critic_node",         "writer_node")
builder.add_edge("writer_node",         END)

graph = builder.compile(checkpointer=checkpointer)

# ═══════════════════════════════════════════════════════════════
#  AGENT
# ═══════════════════════════════════════════════════════════════


def run_agent(user_input: str) -> dict:
    run_id    = str(uuid.uuid4())
    thread_id = f"pipeline-{run_id[:8]}"
    config    = {"configurable": {"thread_id": thread_id}}

    initial: PipelineState = {
        "messages":          [HumanMessage(content=user_input)],
        "original_query":    user_input,
        "run_id":            run_id,
        "plan":              {},
        "retrieved_chunks":  [],
        "rag_answer":        "",
        "tool_results":      [],
        "critic_score":      0,
        "critic_feedback":   "",
        "final_answer":      "",
        "stage_spans":       [],
        "node_transitions":  [],
    }

    t0          = time.perf_counter()
    final_state = _lookover.invoke(graph, initial, config)
    latency_ms  = round((time.perf_counter() - t0) * 1000, 2)

    cp            = checkpointer.get(config)
    checkpoint_id = cp.get("id") if isinstance(cp, dict) else (
        cp.config["configurable"].get("checkpoint_id") if cp else None
    )

    stage_spans = final_state["stage_spans"]
    all_tools   = [tc for s in stage_spans for tc in s.get("tool_calls", [])]

    return {
        "agent":             "agent_20_full_pipeline",
        "provider":          PROVIDER,
        "model":             getattr(llm, "model", getattr(llm, "model_name", "unknown")),
        "run_id":            run_id,
        "thread_id":         thread_id,
        "checkpoint_id":     checkpoint_id,
        "input":             user_input,
        "output":            final_state["final_answer"],
        "output_file":       OUTPUT_FILE,
        "plan":              final_state["plan"],
        "retrieved_chunks":  final_state["retrieved_chunks"],
        "rag_answer":        final_state["rag_answer"],
        "tool_results":      final_state["tool_results"],
        "critic_score":      final_state["critic_score"],
        "critic_feedback":   final_state["critic_feedback"],
        "stage_spans":       stage_spans,
        "node_transitions":  final_state["node_transitions"],
        "total_stages":      len(stage_spans),
        "stage_latencies":   {s["stage"]: s["ms"] for s in stage_spans},
        "all_tool_calls":    all_tools,
        "latency_ms":        latency_ms,
    }


# ═══════════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    question = (
        sys.argv[1] if len(sys.argv) > 1
        else (
            "Search Wikipedia for 'large language model', get the current weather "
            "in San Francisco, get the MSFT stock price, calculate log10(1e12), "
            "and write a comprehensive article about the state of LLMs in 2025."
        )
    )

    result = run_agent(question)

    print(f"\n{'═'*60}")
    print(f"  Agent 20 — Full E2E Pipeline")
    print(f"{'═'*60}")
    print(f"  Provider      : {result['provider']}  ({result['model']})")
    print(f"  Run ID        : {result['run_id']}")
    print(f"  Thread ID     : {result['thread_id']}")
    print(f"  Checkpoint    : {str(result['checkpoint_id'])[:32]}…")
    print(f"  Output file   : {result['output_file']}")
    print(f"\n  Pipeline stages ({result['total_stages']}):")
    for stage, ms in result["stage_latencies"].items():
        print(f"    {stage.ljust(22)} {ms:>8.1f} ms")
    print(f"\n  Node transitions : {result['node_transitions']}")
    print(f"\n  RAG chunks ({len(result['retrieved_chunks'])}):")
    for c in result["retrieved_chunks"]:
        print(f"    [{c['source']}] {c['content'][:80]}…")
    print(f"\n  All real tool calls ({len(result['all_tool_calls'])}):")
    for tc in result["all_tool_calls"]:
        retry = f" [attempt {tc['attempt']}]" if tc.get("attempt", 1) > 1 else ""
        print(f"    [{tc['tool']}]  args={tc['args']}  → {str(tc['output'])[:80]}{retry}")
    print(f"\n  Critic: score={result['critic_score']}/10  |  {result['critic_feedback']}")
    print(f"\n  Final output (first 600 chars):\n{result['output'][:600]}")
    print(f"\n  Total latency : {result['latency_ms']} ms\n")
