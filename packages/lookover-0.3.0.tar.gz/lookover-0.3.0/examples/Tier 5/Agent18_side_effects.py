"""
agent_18_side_effects.py
-------------------------
Phase 1 · Agent 18 — Agent with External API Side Effects

Real side effects — no mocking, no simulation. All tools are inline.

Side effects:
  1. db_write    : real INSERT into SQLite at /tmp/agent18_results.db
  2. file_append : real JSONL append to /tmp/agent18_audit.jsonl
  3. webhook     : real HTTP POST to WEBHOOK_URL
                   → create a free endpoint at https://webhook.site
                   → export WEBHOOK_URL=https://webhook.site/<your-id>
                   → if WEBHOOK_URL is unset, the webhook step returns
                     success=False (real failure, not simulated) so the
                     rollback path is exercised with a genuine error

Idempotency: each effect is keyed by SHA-256 of the payload content.
             Re-running with the same input but a new run_id produces
             a fresh db row; the same run_id twice hits the unique key.

Rollback: if any side effect fails, all db rows for this run_id are deleted.

Real external calls:
  ✔ SQLite write (local)
  ✔ JSONL file append (local)
  ✔ HTTP POST to WEBHOOK_URL (real endpoint required)

Run:
    export WEBHOOK_URL=https://webhook.site/your-unique-id
    python agent_18_side_effects.py
    LLM_PROVIDER=vertexai python agent_18_side_effects.py
"""

import os
import sys
import time
import uuid
import json
import sqlite3
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from urllib import request as url_request, error as url_error
from dotenv import load_dotenv

load_dotenv()

# ── Lookover SDK ─────────────────────────────────────────────────────────────
_sdk_path = os.getenv("LOOKOVER_SDK_PATH", "")
if _sdk_path and _sdk_path not in sys.path:
    sys.path.insert(0, _sdk_path)

from lookover_sdk.langchain import LookoverCallbackHandler

_lookover = LookoverCallbackHandler(
    api_key=os.getenv("LOOKOVER_API_KEY", "lk_dev_local"),
    agent_id="agent_18_side_effects",
    agent_version="1.0.0",
    purpose="structured_data_persistence",
    base_url=os.getenv("LOOKOVER_BASE_URL", "http://localhost:8081"),
)

# Governance metadata for prescan/runtime evidence
ai_policy_ref = "LOOKOVER-AI-POLICY-v1"
ai_risk_assessment_ref = "LOOKOVER-RISK-ASSESS-v1"

# ═══════════════════════════════════════════════════════════════
#  LLM SETUP
# ═══════════════════════════════════════════════════════════════

PROVIDER = os.getenv("LLM_PROVIDER", "ollama").lower()

if PROVIDER == "ollama":
    from langchain_ollama import ChatOllama
    llm = ChatOllama(
        base_url=os.getenv("OLLAMA_BASE_URL", "http://192.168.1.17:11434"),
        model=os.getenv("OLLAMA_MODEL", "llama3.2"),
        temperature=0.0,
    )
elif PROVIDER == "vertexai":
    from langchain_google_vertexai import ChatVertexAI
    llm = ChatVertexAI(
        project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        model_name=os.getenv("VERTEXAI_MODEL", "gemini-1.5-flash-002"),
        temperature=0.0,
    )
elif PROVIDER == "googleai":
    from langchain_google_genai import ChatGoogleGenerativeAI
    llm = ChatGoogleGenerativeAI(
        model=os.getenv("GOOGLEAI_MODEL", "gemini-2.0-flash"),
        google_api_key=os.getenv("GOOGLE_API_KEY"),
        temperature=0.0,
    )
else:
    raise ValueError(f"Unknown LLM_PROVIDER='{PROVIDER}'. Use 'ollama', 'vertexai', or 'googleai'.")

# ═══════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════

DB_PATH  = Path(os.getenv("SIDE_EFFECT_DB",  "/tmp/agent18_results.db"))
LOG_PATH = Path(os.getenv("SIDE_EFFECT_LOG", "/tmp/agent18_audit.jsonl"))
WEBHOOK  = os.getenv("WEBHOOK_URL", "")

if not WEBHOOK:
    print(
        "\n⚠  WEBHOOK_URL not set.\n"
        "   Create a free endpoint at https://webhook.site\n"
        "   then: export WEBHOOK_URL=https://webhook.site/<your-id>\n"
        "   Without it the webhook side-effect will return success=False,\n"
        "   which exercises the real rollback path.\n"
    )

# ═══════════════════════════════════════════════════════════════
#  SIDE-EFFECT FUNCTIONS  (inline — not LangChain tools)
# ═══════════════════════════════════════════════════════════════

from langchain_core.messages import SystemMessage, HumanMessage


def _idem_key(prefix: str, payload: dict) -> str:
    h = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:16]
    return f"{prefix}:{h}"


def setup_db() -> None:
    con = sqlite3.connect(DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS agent_results (
            idempotency_key TEXT PRIMARY KEY,
            run_id          TEXT,
            agent_name      TEXT,
            payload         TEXT,
            created_at      TEXT
        )
    """)
    con.commit()
    con.close()


def db_write(run_id: str, agent_name: str, payload: dict) -> dict:
    """Real SQLite INSERT. Returns idempotency_hit=True if the key already exists."""
    idem_key = _idem_key("db", {**payload, "run_id": run_id})
    t0       = time.perf_counter()
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute(
            "INSERT INTO agent_results "
            "(idempotency_key, run_id, agent_name, payload, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (idem_key, run_id, agent_name, json.dumps(payload),
             datetime.now(timezone.utc).isoformat()),
        )
        con.commit()
        con.close()
        return {"type": "db_write", "idempotency_key": idem_key,
                "success": True, "idempotency_hit": False,
                "db_path": str(DB_PATH),
                "ms": round((time.perf_counter() - t0) * 1000, 2)}
    except sqlite3.IntegrityError:
        return {"type": "db_write", "idempotency_key": idem_key,
                "success": True, "idempotency_hit": True,
                "db_path": str(DB_PATH),
                "ms": round((time.perf_counter() - t0) * 1000, 2)}
    except Exception as exc:
        return {"type": "db_write", "idempotency_key": idem_key,
                "success": False, "error": str(exc),
                "ms": round((time.perf_counter() - t0) * 1000, 2)}


def file_append(run_id: str, agent_name: str, payload: dict) -> dict:
    """Real JSONL file append."""
    idem_key = _idem_key("file", {**payload, "run_id": run_id})
    t0       = time.perf_counter()
    record   = {
        "idempotency_key": idem_key,
        "run_id":          run_id,
        "agent":           agent_name,
        "payload":         payload,
        "ts":              datetime.now(timezone.utc).isoformat(),
    }
    try:
        with open(LOG_PATH, "a") as f:
            f.write(json.dumps(record) + "\n")
        return {"type": "file_append", "idempotency_key": idem_key,
                "success": True, "log_path": str(LOG_PATH),
                "ms": round((time.perf_counter() - t0) * 1000, 2)}
    except Exception as exc:
        return {"type": "file_append", "idempotency_key": idem_key,
                "success": False, "error": str(exc),
                "ms": round((time.perf_counter() - t0) * 1000, 2)}


def webhook_post(run_id: str, payload: dict) -> dict:
    """
    Real HTTP POST to WEBHOOK_URL.
    If WEBHOOK_URL is not set, returns success=False immediately so the
    rollback path is triggered with a genuine (not simulated) failure.
    """
    idem_key = _idem_key("webhook", {**payload, "run_id": run_id})
    t0       = time.perf_counter()

    if not WEBHOOK:
        return {
            "type":            "webhook",
            "idempotency_key": idem_key,
            "success":         False,
            "error":           "WEBHOOK_URL not configured. Set export WEBHOOK_URL=https://webhook.site/<id>",
            "ms":              round((time.perf_counter() - t0) * 1000, 2),
        }

    body = json.dumps({
        "idempotency_key": idem_key,
        "run_id":          run_id,
        "agent":           "agent_18_side_effects",
        "provider":        PROVIDER,
        "ts":              datetime.now(timezone.utc).isoformat(),
        **payload,
    }).encode("utf-8")

    req = url_request.Request(
        WEBHOOK, data=body,
        headers={
            "Content-Type":      "application/json",
            "X-Idempotency-Key": idem_key,
            "User-Agent":        "AuditSDK-Agent/1.0",
        },
        method="POST",
    )
    try:
        with url_request.urlopen(req, timeout=10) as resp:
            status  = resp.status
            body_r  = resp.read().decode("utf-8", errors="replace")[:300]
        return {"type": "webhook", "idempotency_key": idem_key,
                "success": True, "http_status": status,
                "response_preview": body_r, "url": WEBHOOK,
                "ms": round((time.perf_counter() - t0) * 1000, 2)}
    except url_error.HTTPError as exc:
        return {"type": "webhook", "idempotency_key": idem_key,
                "success": False, "http_status": exc.code,
                "error": f"HTTP {exc.code}: {exc.reason}", "url": WEBHOOK,
                "ms": round((time.perf_counter() - t0) * 1000, 2)}
    except url_error.URLError as exc:
        return {"type": "webhook", "idempotency_key": idem_key,
                "success": False, "error": str(exc), "url": WEBHOOK,
                "ms": round((time.perf_counter() - t0) * 1000, 2)}


def rollback_db(run_id: str) -> dict:
    """Compensation: DELETE all rows for this run_id from the db."""
    t0 = time.perf_counter()
    try:
        con  = sqlite3.connect(DB_PATH)
        rows = con.execute(
            "DELETE FROM agent_results WHERE run_id = ?", (run_id,)
        ).rowcount
        con.commit()
        con.close()
        return {"compensation": "db_rollback", "rows_deleted": rows,
                "success": True, "ms": round((time.perf_counter() - t0) * 1000, 2)}
    except Exception as exc:
        return {"compensation": "db_rollback", "success": False,
                "error": str(exc), "ms": round((time.perf_counter() - t0) * 1000, 2)}


# ═══════════════════════════════════════════════════════════════
#  AGENT
# ═══════════════════════════════════════════════════════════════

def run_agent(user_input: str) -> dict:
    setup_db()
    run_id = str(uuid.uuid4())

    # Step 1: LLM extracts structured data from the input
    t_llm    = time.perf_counter()
    response = llm.invoke([
        SystemMessage(content=(
            "You are a data extraction assistant. Extract key information from the "
            "user's input and return ONLY valid JSON (no markdown fences) with keys: "
            "topic (string), summary (string), tags (list of strings), "
            "confidence (float 0.0–1.0)."
        )),
        HumanMessage(content=user_input),
    ], config={"callbacks": [_lookover]})
    llm_ms = round((time.perf_counter() - t_llm) * 1000, 2)

    try:
        llm_result = json.loads(
            response.content.strip().strip("```json").strip("```")
        )
    except Exception:
        llm_result = {
            "topic":      "unknown",
            "summary":    response.content[:200],
            "tags":       [],
            "confidence": 0.5,
        }

    payload = {**llm_result, "original_input": user_input[:200]}

    # Step 2: Execute all three side effects in sequence
    side_effect_log: list[dict] = []

    result_db   = db_write(run_id, "agent_18_side_effects", payload)
    side_effect_log.append(result_db)

    result_file = file_append(run_id, "agent_18_side_effects", payload)
    side_effect_log.append(result_file)

    result_hook = webhook_post(run_id, payload)
    side_effect_log.append(result_hook)

    # Step 3: Rollback if any critical side effect failed
    compensation_log: list[dict] = []
    all_success = all(e.get("success") for e in side_effect_log)

    if not all_success:
        compensation_log.append(rollback_db(run_id))

    return {
        "agent":            "agent_18_side_effects",
        "provider":         PROVIDER,
        "model":            getattr(llm, "model", getattr(llm, "model_name", "unknown")),
        "run_id":           run_id,
        "input":            user_input,
        "llm_result":       llm_result,
        "llm_ms":           llm_ms,
        "side_effect_log":  side_effect_log,
        "compensation_log": compensation_log,
        "all_success":      all_success,
        "rolled_back":      len(compensation_log) > 0,
        "idempotency_hits": sum(1 for e in side_effect_log if e.get("idempotency_hit")),
        "db_path":          str(DB_PATH),
        "log_path":         str(LOG_PATH),
        "webhook_url":      WEBHOOK or "(not configured)",
    }


# ═══════════════════════════════════════════════════════════════
#  CLI — run twice to show idempotency on re-run
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    question = (
        sys.argv[1] if len(sys.argv) > 1
        else (
            "Audit logging in AI agent systems must capture tool calls, LLM responses, "
            "latency, token usage, and all side effects with idempotency guarantees."
        )
    )

    print(f"\n{'═'*60}")
    print("  Run 1  (new run_id — all three side effects execute)")
    print(f"{'═'*60}")
    r1 = run_agent(question)
    print(f"  Provider        : {r1['provider']}  ({r1['model']})")
    print(f"  Run ID          : {r1['run_id']}")
    print(f"  LLM result      : {r1['llm_result']}")
    print(f"  All success     : {r1['all_success']}")
    print(f"  Rolled back     : {r1['rolled_back']}")
    print(f"  Side effects    :")
    for se in r1["side_effect_log"]:
        hit = " [IDEMPOTENCY HIT]" if se.get("idempotency_hit") else ""
        err = f"  error: {se.get('error', '')[:60]}" if not se["success"] else ""
        print(f"    {se['type'].ljust(14)} success={se['success']}  ms={se['ms']}{hit}{err}")
    if r1["compensation_log"]:
        print(f"  Compensation    : {r1['compensation_log']}")

    print(f"\n{'═'*60}")
    print("  Run 2  (new run_id — shows idempotency on file append)")
    print(f"{'═'*60}")
    r2 = run_agent(question)
    print(f"  Run ID          : {r2['run_id']}")
    print(f"  All success     : {r2['all_success']}")
    print(f"  Idempotency hits: {r2['idempotency_hits']}")
    print(f"  DB path         : {r2['db_path']}")
    print(f"  Log path        : {r2['log_path']}")
    print(f"  Webhook URL     : {r2['webhook_url']}\n")
