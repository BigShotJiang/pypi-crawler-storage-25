"""
agent_17_streaming.py
----------------------
Phase 1 · Agent 17 — Streaming Agent

Streams real LLM tokens using LangChain's astream / astream_events interfaces.
All tools inlined — no shared module.

Three streaming modes:
  mode_1 : raw .astream()           — every text chunk as it arrives
  mode_2 : .astream_events() v2     — structured events (on_chat_model_stream,
                                       on_chat_model_start/end, on_chain_end …)
  mode_3 : tool-calling agent stream — tokens AND tool events interleaved in real time

Tool used in mode 3:
  calculator : local safe eval (no network)

What your audit SDK should capture
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ✔ stream_start event  — timestamp, model, input
  ✔ token events        — chunk index, text, ts_offset_ms
  ✔ first_token_ms      — TTFT (time-to-first-token)
  ✔ stream_end event    — total chunks, assembled text, total_ms
  ✔ tool_start / tool_end events interleaved mid-stream
  ✔ event_type_counts   — breakdown of every LangChain event type

Run:
    python agent_17_streaming.py
    LLM_PROVIDER=vertexai python agent_17_streaming.py
    LLM_PROVIDER=googleai  python agent_17_streaming.py
"""

import os
import sys
import time
import uuid
import asyncio
import math
from dotenv import load_dotenv

load_dotenv()

# ── Lookover SDK ─────────────────────────────────────────────────────────────
_sdk_path = os.getenv("LOOKOVER_SDK_PATH", "")
if _sdk_path and _sdk_path not in sys.path:
    sys.path.insert(0, _sdk_path)

from lookover_sdk.langchain import LookoverCallbackHandler

_lookover = LookoverCallbackHandler(
    api_key=os.getenv("LOOKOVER_API_KEY", "lk_dev_local"),
    agent_id="agent_17_streaming",
    agent_version="1.0.0",
    purpose="streaming_inference_demonstration",
    base_url=os.getenv("LOOKOVER_BASE_URL", "http://localhost:8081"),
)

# Governance metadata for prescan/runtime evidence
ai_policy_ref = "LOOKOVER-AI-POLICY-v1"
ai_risk_assessment_ref = "LOOKOVER-RISK-ASSESS-v1"

# ═══════════════════════════════════════════════════════════════
#  LLM SETUP
# ═══════════════════════════════════════════════════════════════

PROVIDER = os.getenv("LLM_PROVIDER", "ollama").lower()

if PROVIDER == "ollama":
    from langchain_ollama import ChatOllama
    llm = ChatOllama(
        base_url=os.getenv("OLLAMA_BASE_URL", "http://192.168.1.17:11434"),
        model=os.getenv("OLLAMA_MODEL", "llama3.2"),
        temperature=0.0,
    )
elif PROVIDER == "vertexai":
    from langchain_google_vertexai import ChatVertexAI
    llm = ChatVertexAI(
        project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        model_name=os.getenv("VERTEXAI_MODEL", "gemini-1.5-flash-002"),
        temperature=0.0,
    )
elif PROVIDER == "googleai":
    from langchain_google_genai import ChatGoogleGenerativeAI
    llm = ChatGoogleGenerativeAI(
        model=os.getenv("GOOGLEAI_MODEL", "gemini-2.0-flash"),
        google_api_key=os.getenv("GOOGLE_API_KEY"),
        temperature=0.0,
    )
else:
    raise ValueError(f"Unknown LLM_PROVIDER='{PROVIDER}'. Use 'ollama', 'vertexai', or 'googleai'.")


# ═══════════════════════════════════════════════════════════════
#  TOOL  (inlined — used in mode 3)
# ═══════════════════════════════════════════════════════════════

from langchain_core.tools import tool


@tool
def calculator(expression: str) -> str:
    """
    Evaluates a mathematical expression safely.
    Supports: +, -, *, /, **, sqrt(), log(), log10(), sin(), cos(), pi, e, tau.

    Args:
        expression: A valid Python math expression, e.g. "sqrt(98596) + log10(1e6)"
    """
    try:
        allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
        allowed.update({"abs": abs, "round": round})
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return f"{expression} = {result}"
    except Exception as exc:
        raise RuntimeError(f"Calculator error: {exc}") from exc


TOOLS = [calculator]


# ═══════════════════════════════════════════════════════════════
#  MODE 1 — Raw token stream  (.astream)
# ═══════════════════════════════════════════════════════════════

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser


async def stream_mode1(user_input: str) -> dict:
    """Streams raw text chunks. Captures TTFT and per-chunk timing."""
    run_id    = str(uuid.uuid4())
    chunks    = []
    t_start   = time.perf_counter()
    ttft_ms   = None
    prev_ts   = t_start
    assembled = ""

    async for chunk in llm.astream([HumanMessage(content=user_input)], config={"callbacks": [_lookover]}):
        ts   = time.perf_counter()
        text = chunk.content or ""
        if text and ttft_ms is None:
            ttft_ms = round((ts - t_start) * 1000, 2)
        inter_ms = round((ts - prev_ts) * 1000, 2) if chunks else 0
        chunks.append({
            "index":        len(chunks),
            "text":         text,
            "ts_offset_ms": round((ts - t_start) * 1000, 2),
            "inter_ms":     inter_ms,
        })
        assembled += text
        prev_ts    = ts
        print(text, end="", flush=True)

    total_ms = round((time.perf_counter() - t_start) * 1000, 2)
    return {
        "mode":         "raw_stream",
        "run_id":       run_id,
        "input":        user_input,
        "output":       assembled,
        "total_chunks": len(chunks),
        "ttft_ms":      ttft_ms,
        "total_ms":     total_ms,
        "chunks":       chunks,
    }


# ═══════════════════════════════════════════════════════════════
#  MODE 2 — astream_events  (structured event stream)
# ═══════════════════════════════════════════════════════════════

async def stream_mode2(user_input: str) -> dict:
    """Consumes astream_events() and classifies every event type."""
    run_id       = str(uuid.uuid4())
    event_log    = []
    token_chunks = []
    assembled    = ""
    t_start      = time.perf_counter()
    ttft_ms      = None

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant. Answer concisely."),
        ("human",  "{input}"),
    ])
    chain = prompt | llm | StrOutputParser()

    async for event in chain.astream_events({"input": user_input}, version="v2", config={"callbacks": [_lookover]}):
        ts         = time.perf_counter()
        event_type = event.get("event", "")
        event_name = event.get("name", "")
        offset_ms  = round((ts - t_start) * 1000, 2)

        log_entry = {
            "event_type":   event_type,
            "event_name":   event_name,
            "ts_offset_ms": offset_ms,
        }

        if event_type == "on_chat_model_stream":
            chunk_obj = event.get("data", {}).get("chunk", {})
            text      = getattr(chunk_obj, "content", "") or ""
            if text:
                if ttft_ms is None:
                    ttft_ms = offset_ms
                token_chunks.append({
                    "index":        len(token_chunks),
                    "text":         text,
                    "ts_offset_ms": offset_ms,
                })
                assembled += text
                log_entry["token"] = text

        elif event_type == "on_chat_model_start":
            log_entry["input"] = str(event.get("data", {}).get("input", ""))[:100]

        elif event_type == "on_chat_model_end":
            output = event.get("data", {}).get("output", {})
            log_entry["usage"] = getattr(output, "usage_metadata", {})

        event_log.append(log_entry)

    total_ms = round((time.perf_counter() - t_start) * 1000, 2)
    from collections import Counter
    event_type_counts = dict(Counter(e["event_type"] for e in event_log))

    return {
        "mode":              "astream_events",
        "run_id":            run_id,
        "input":             user_input,
        "output":            assembled,
        "total_chunks":      len(token_chunks),
        "total_events":      len(event_log),
        "event_type_counts": event_type_counts,
        "ttft_ms":           ttft_ms,
        "total_ms":          total_ms,
        "event_log":         event_log,
        "token_chunks":      token_chunks,
    }


# ═══════════════════════════════════════════════════════════════
#  MODE 3 — Streaming tool-calling agent
# ═══════════════════════════════════════════════════════════════

from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import ToolMessage


class _ReactState(TypedDict):
    messages: Annotated[list, add_messages]


def _build_react_graph() -> any:
    bound = llm.bind_tools(TOOLS)
    tool_map = {t.name: t for t in TOOLS}

    def llm_node(state: _ReactState):
        return {"messages": [bound.invoke(state["messages"])]}

    def tool_node(state: _ReactState):
        last = state["messages"][-1]
        results = []
        for tc in getattr(last, "tool_calls", []):
            t = tool_map.get(tc["name"])
            out = t.invoke(tc["args"]) if t else f"unknown tool: {tc['name']}"
            results.append(ToolMessage(content=str(out), tool_call_id=tc["id"]))
        return {"messages": results}

    def should_continue(state: _ReactState):
        last = state["messages"][-1]
        return "tools" if getattr(last, "tool_calls", None) else END

    g = StateGraph(_ReactState)
    g.add_node("llm", llm_node)
    g.add_node("tools", tool_node)
    g.add_edge(START, "llm")
    g.add_conditional_edges("llm", should_continue, {"tools": "tools", END: END})
    g.add_edge("tools", "llm")
    return g.compile()


async def stream_mode3(user_input: str) -> dict:
    """Streams a real tool-calling ReAct graph — tokens AND tool events interleaved."""
    run_id       = str(uuid.uuid4())
    event_log    = []
    token_chunks = []
    tool_events  = []
    assembled    = ""
    t_start      = time.perf_counter()
    ttft_ms      = None

    graph = _build_react_graph()
    inputs = {"messages": [
        SystemMessage(content="You are a helpful assistant. Use the calculator tool for any maths."),
        HumanMessage(content=user_input),
    ]}

    async for event in graph.astream_events(inputs, {"callbacks": [_lookover]}, version="v2"):
        ts         = time.perf_counter()
        event_type = event.get("event", "")
        event_name = event.get("name", "")
        offset_ms  = round((ts - t_start) * 1000, 2)

        log_entry = {
            "event_type":   event_type,
            "event_name":   event_name,
            "ts_offset_ms": offset_ms,
        }

        if event_type == "on_chat_model_stream":
            chunk = event.get("data", {}).get("chunk", {})
            text  = getattr(chunk, "content", "") or ""
            if text:
                if ttft_ms is None:
                    ttft_ms = offset_ms
                token_chunks.append({
                    "index":        len(token_chunks),
                    "text":         text,
                    "ts_offset_ms": offset_ms,
                })
                assembled += text
                log_entry["token"] = text

        elif event_type == "on_tool_start":
            te = {
                "event":        "tool_start",
                "tool_name":    event_name,
                "input":        event.get("data", {}).get("input", {}),
                "ts_offset_ms": offset_ms,
            }
            tool_events.append(te)
            log_entry.update({"tool_name": event_name,
                               "tool_input": str(te["input"])})

        elif event_type == "on_tool_end":
            te = {
                "event":        "tool_end",
                "tool_name":    event_name,
                "output":       str(event.get("data", {}).get("output", ""))[:300],
                "ts_offset_ms": offset_ms,
            }
            tool_events.append(te)
            log_entry["tool_output"] = te["output"]

        event_log.append(log_entry)

    total_ms = round((time.perf_counter() - t_start) * 1000, 2)
    from collections import Counter
    event_type_counts = dict(Counter(e["event_type"] for e in event_log))

    return {
        "mode":              "streaming_tool_agent",
        "run_id":            run_id,
        "input":             user_input,
        "output":            assembled,
        "total_chunks":      len(token_chunks),
        "total_events":      len(event_log),
        "event_type_counts": event_type_counts,
        "tool_events":       tool_events,
        "ttft_ms":           ttft_ms,
        "total_ms":          total_ms,
        "event_log":         event_log,
    }


# ═══════════════════════════════════════════════════════════════
#  AGENT
# ═══════════════════════════════════════════════════════════════

def run_agent(user_input: str, tool_input: str | None = None) -> dict:
    run_id     = str(uuid.uuid4())
    tool_query = tool_input or f"Calculate sqrt(98596) + log10(1000000). Also: {user_input}"

    loop = asyncio.new_event_loop()
    t0   = time.perf_counter()

    print("\n[Mode 1 — raw stream tokens]\n")
    result1 = loop.run_until_complete(stream_mode1(user_input))
    print()

    print("\n[Mode 2 — astream_events]\n")
    result2 = loop.run_until_complete(stream_mode2(user_input))

    print("\n[Mode 3 — streaming tool-calling agent]\n")
    result3 = loop.run_until_complete(stream_mode3(tool_query))
    loop.close()

    latency_ms = round((time.perf_counter() - t0) * 1000, 2)

    return {
        "agent":      "agent_17_streaming",
        "provider":   PROVIDER,
        "model":      getattr(llm, "model", getattr(llm, "model_name", "unknown")),
        "run_id":     run_id,
        "input":      user_input,
        "mode1":      result1,
        "mode2":      result2,
        "mode3":      result3,
        "latency_ms": latency_ms,
    }


# ═══════════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    question = (
        sys.argv[1] if len(sys.argv) > 1
        else "Explain in 3 sentences why streaming matters for real-time AI applications."
    )

    result = run_agent(question)

    print(f"\n{'═'*60}")
    print(f"  Provider : {result['provider']}  ({result['model']})")

    for mode_key, label in [("mode1", "Mode 1 — Raw Stream"),
                             ("mode2", "Mode 2 — astream_events"),
                             ("mode3", "Mode 3 — Tool-Calling Stream")]:
        m = result[mode_key]
        print(f"\n  {label}")
        print(f"    Chunks        : {m['total_chunks']}")
        print(f"    TTFT          : {m['ttft_ms']} ms")
        print(f"    Total         : {m['total_ms']} ms")
        if "event_type_counts" in m:
            print(f"    Event types   : {m['event_type_counts']}")
        if m.get("tool_events"):
            for te in m["tool_events"]:
                out = str(te.get("output", ""))[:60]
                print(f"    Tool event    : {te['event']}  "
                      f"name={te.get('tool_name','')}  output={out}")

    print(f"\n  Total wall-clock : {result['latency_ms']} ms\n")
