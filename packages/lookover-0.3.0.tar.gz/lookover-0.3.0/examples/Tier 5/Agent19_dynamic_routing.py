"""
agent_19_dynamic_routing.py
-----------------------------
Phase 1 · Agent 19 — Dynamic Agent (Self-Modifying Routing)

The LLM scores the task complexity at runtime (1/2/3), builds an execution
plan, and routes through it dynamically. All tools are inline.

Complexity tiers:
  1 = simple   → synthesiser only (no tools)
  2 = moderate → 1-2 worker steps with tools
  3 = complex  → 3+ steps, possible mid-run plan revision

Workers & real tools:
  researcher  : wikipedia_search + web_search
  analyst     : calculator + get_stock_price + get_weather + get_datetime
  critic      : web_search
  synthesiser : write_file  (saves final output to /tmp/agent19_output.txt)

Real external calls:
  ✔ Wikipedia MediaWiki REST API (no key)
  ✔ DuckDuckGo Instant Answer API (no key)
  ✔ Open-Meteo weather API (no key)
  ✔ Yahoo Finance via yfinance
  ✔ Local file write

Run:
    python agent_19_dynamic_routing.py
    LLM_PROVIDER=vertexai python agent_19_dynamic_routing.py
    LLM_PROVIDER=googleai  python agent_19_dynamic_routing.py
"""

import os
import sys
import time
import uuid
import json
import math
from datetime import datetime, timezone, timedelta
from urllib import request as url_request, parse as url_parse, error as url_error
from typing import Annotated, TypedDict
from dotenv import load_dotenv

load_dotenv()

# ── Lookover SDK ─────────────────────────────────────────────────────────────
_sdk_path = os.getenv("LOOKOVER_SDK_PATH", "")
if _sdk_path and _sdk_path not in sys.path:
    sys.path.insert(0, _sdk_path)

from lookover_sdk.langgraph import LookoverLangGraphListener

_lookover = LookoverLangGraphListener(
    api_key=os.getenv("LOOKOVER_API_KEY", "lk_dev_local"),
    agent_id="agent_19_dynamic_routing",
    agent_version="1.0.0",
    purpose="dynamic_research_routing",
    base_url=os.getenv("LOOKOVER_BASE_URL", "http://localhost:8081"),
)

# Governance metadata for prescan/runtime evidence
ai_policy_ref = "LOOKOVER-AI-POLICY-v1"
ai_risk_assessment_ref = "LOOKOVER-RISK-ASSESS-v1"

# ═══════════════════════════════════════════════════════════════
#  LLM SETUP
# ═══════════════════════════════════════════════════════════════

PROVIDER = os.getenv("LLM_PROVIDER", "ollama").lower()

if PROVIDER == "ollama":
    from langchain_ollama import ChatOllama
    llm = ChatOllama(
        base_url=os.getenv("OLLAMA_BASE_URL", "http://192.168.1.17:11434"),
        model=os.getenv("OLLAMA_MODEL", "llama3.2"),
        temperature=0.0,
    )
elif PROVIDER == "vertexai":
    from langchain_google_vertexai import ChatVertexAI
    llm = ChatVertexAI(
        project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-gcp-project-id"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        model_name=os.getenv("VERTEXAI_MODEL", "gemini-1.5-flash-002"),
        temperature=0.0,
    )
elif PROVIDER == "googleai":
    from langchain_google_genai import ChatGoogleGenerativeAI
    llm = ChatGoogleGenerativeAI(
        model=os.getenv("GOOGLEAI_MODEL", "gemini-2.0-flash"),
        google_api_key=os.getenv("GOOGLE_API_KEY"),
        temperature=0.0,
    )
else:
    raise ValueError(f"Unknown LLM_PROVIDER='{PROVIDER}'. Use 'ollama', 'vertexai', or 'googleai'.")

# ═══════════════════════════════════════════════════════════════
#  TOOLS  (all inline)
# ═══════════════════════════════════════════════════════════════

from langchain_core.tools import tool


@tool
def wikipedia_search(query: str) -> str:
    """
    Search Wikipedia and return the opening summary of the best matching article.
    Uses the MediaWiki REST API — no API key required.
    Args:
        query: The search term
    """
    ua = "LookoverAuditSDK/1.0 (https://github.com/lookover/lookover; audit-examples)"
    try:
        req = url_request.Request(
            "https://en.wikipedia.org/w/api.php?action=query&list=search"
            f"&srsearch={url_parse.quote(query)}&srlimit=1&format=json",
            headers={"User-Agent": ua},
        )
        with url_request.urlopen(req, timeout=10) as resp:
            results = json.loads(resp.read()).get("query", {}).get("search", [])
        if not results:
            return f"No Wikipedia article found for: {query}"
        title = results[0]["title"]
        req2 = url_request.Request(
            f"https://en.wikipedia.org/api/rest_v1/page/summary/{url_parse.quote(title)}",
            headers={"User-Agent": ua},
        )
        with url_request.urlopen(req2, timeout=10) as resp:
            page = json.loads(resp.read())
        url = page.get("content_urls", {}).get("desktop", {}).get("page", "")
        return f"[Wikipedia: {title}]\n{page.get('extract', 'No extract.')}\nSource: {url}"
    except (url_error.URLError, url_error.HTTPError) as exc:
        raise RuntimeError(f"Wikipedia API error: {exc}") from exc


@tool
def web_search(query: str) -> str:
    """
    Search the web using DuckDuckGo Instant Answer API. No API key required.
    Args:
        query: The search query
    """
    try:
        req = url_request.Request(
            f"https://api.duckduckgo.com/?q={url_parse.quote(query)}&format=json&no_html=1&skip_disambig=1",
            headers={"User-Agent": "AuditSDK-Agent/1.0"},
        )
        with url_request.urlopen(req, timeout=10) as resp:
            raw = resp.read()
        if not raw:
            return f"No instant answer found for: {query}"
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            return f"No instant answer found for: {query}"
        abstract = data.get("Abstract", "").strip()
        if abstract:
            return f"{abstract}\nSource: {data.get('AbstractURL', '')}"
        topics = [t["Text"] for t in data.get("RelatedTopics", [])[:3]
                  if isinstance(t, dict) and t.get("Text")]
        return "\n\n".join(topics) if topics else f"No instant answer found for: {query}"
    except (url_error.URLError, url_error.HTTPError) as exc:
        raise RuntimeError(f"DuckDuckGo API error: {exc}") from exc


@tool
def get_weather(location: str) -> str:
    """
    Get current weather for any city using Open-Meteo API. No API key required.
    Args:
        location: City name, e.g. "Tokyo"
    """
    try:
        with url_request.urlopen(
            f"https://geocoding-api.open-meteo.com/v1/search?name={url_parse.quote(location)}&count=1&language=en&format=json",
            timeout=10,
        ) as resp:
            results = json.loads(resp.read()).get("results", [])
        if not results:
            return f"Could not geocode: {location}"
        r = results[0]
        lat, lon = r["latitude"], r["longitude"]
        name, country = r.get("name", location), r.get("country", "")
        with url_request.urlopen(
            f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
            f"&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code,apparent_temperature&timezone=auto",
            timeout=10,
        ) as resp:
            cur = json.loads(resp.read()).get("current", {})
        WMO  = {0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
                45: "Fog", 61: "Slight rain", 63: "Moderate rain", 80: "Slight showers", 95: "Thunderstorm"}
        cond = WMO.get(cur.get("weather_code", 0), f"Code {cur.get('weather_code', 0)}")
        return (f"Weather in {name}, {country}: {cond}, "
                f"{cur.get('temperature_2m')}°C (feels {cur.get('apparent_temperature')}°C), "
                f"humidity {cur.get('relative_humidity_2m')}%, wind {cur.get('wind_speed_10m')} km/h. "
                f"Source: Open-Meteo")
    except (url_error.URLError, url_error.HTTPError) as exc:
        raise RuntimeError(f"Open-Meteo error: {exc}") from exc


@tool
def get_stock_price(ticker: str) -> str:
    """
    Get current stock price using Yahoo Finance. Requires: pip install yfinance
    Args:
        ticker: Stock ticker symbol, e.g. "AAPL"
    """
    try:
        import yfinance as yf
    except ImportError:
        raise RuntimeError("yfinance not installed. Run: pip install yfinance")
    try:
        info  = yf.Ticker(ticker.upper()).info
        price = info.get("currentPrice") or info.get("regularMarketPrice")
        if price is None:
            raise RuntimeError(f"No price data for ticker '{ticker}'. It may be invalid or delisted.")
        prev   = info.get("previousClose", "N/A")
        name   = info.get("longName", ticker.upper())
        change = round(price - prev, 2) if isinstance(prev, (int, float)) else "N/A"
        pct    = round((change / prev) * 100, 2) if isinstance(change, (int, float)) and prev else "N/A"
        return (f"Stock: {name} ({ticker.upper()}) | Price: {price} {info.get('currency', 'USD')} | "
                f"Change: {change} ({pct}%) | Source: Yahoo Finance")
    except Exception as exc:
        raise RuntimeError(f"yfinance error for '{ticker}': {exc}") from exc


@tool
def calculator(expression: str) -> str:
    """
    Evaluates a mathematical expression safely.
    Supports: +, -, *, /, **, sqrt(), log(), log10(), sin(), cos(), pi, e, abs(), round().
    Args:
        expression: A Python math expression, e.g. "sqrt(144) + log10(1000)"
    """
    try:
        allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
        allowed.update({"abs": abs, "round": round})
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return f"{expression} = {result}"
    except Exception as exc:
        raise RuntimeError(f"Calculator error for '{expression}': {exc}") from exc


@tool
def get_datetime(timezone_name: str = "UTC") -> str:
    """
    Returns the current UTC date/time and equivalent in the requested timezone.
    Args:
        timezone_name: e.g. "UTC", "IST", "EST", "PST", "JST"
    """
    offsets = {"UTC": 0, "GMT": 0, "IST": 5.5, "EST": -5, "EDT": -4,
               "CST": -6, "PST": -8, "PDT": -7, "CET": 1, "CEST": 2,
               "JST": 9, "AEST": 10, "SGT": 8}
    now_utc  = datetime.now(timezone.utc)
    offset_h = offsets.get(timezone_name.upper(), 0)
    local_dt = now_utc + timedelta(hours=offset_h)
    sign     = "+" if offset_h >= 0 else ""
    return (f"UTC: {now_utc.strftime('%Y-%m-%d %H:%M:%S %Z')} | "
            f"{timezone_name.upper()}: {local_dt.strftime('%Y-%m-%d %H:%M:%S')} (UTC{sign}{offset_h})")


@tool
def write_file(path: str, content: str) -> str:
    """
    Writes text content to a local file (creates or overwrites).
    Args:
        path   : File path, e.g. "/tmp/output.txt"
        content: Text to write.
    """
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Written {len(content)} chars to {path}"
    except Exception as exc:
        raise RuntimeError(f"File write error: {exc}") from exc


ROLE_TOOLS = {
    "researcher":  [wikipedia_search, web_search],
    "analyst":     [calculator, get_stock_price, get_weather, get_datetime],
    "critic":      [web_search],
    "synthesiser": [write_file],
}

ROLE_SYSTEMS = {
    "researcher":  "You are a research specialist. Use wikipedia_search and web_search. Always call at least one tool.",
    "analyst":     "You are a data analyst. Use calculator, get_stock_price, get_weather, get_datetime. Never guess numbers.",
    "critic":      "You are a critical analyst. Use web_search to find limitations, risks, and counterarguments.",
    "synthesiser": "You are a synthesis expert. Combine all prior findings into a polished final answer and save it to /tmp/agent19_output.txt using write_file.",
}

OUTPUT_FILE = "/tmp/agent19_output.txt"

# ═══════════════════════════════════════════════════════════════
#  STATE
# ═══════════════════════════════════════════════════════════════

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage, AIMessage
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode


class DynamicState(TypedDict):
    messages:          Annotated[list[AnyMessage], add_messages]
    original_task:     str
    complexity_score:  int
    complexity_reason: str
    execution_plan:    list[dict]
    plan_step_idx:     int
    step_outputs:      list[dict]
    plan_revisions:    list[dict]
    routing_log:       list[dict]
    final_output:      str


# ═══════════════════════════════════════════════════════════════
#  HELPER — real ReAct loop
# ═══════════════════════════════════════════════════════════════

def react_loop(role: str, instruction: str, prior_context: str,
               original_task: str) -> tuple[str, list[dict], float]:
    tools     = ROLE_TOOLS.get(role, [])
    system    = ROLE_SYSTEMS.get(role, "You are a helpful assistant.")
    bound_llm = llm.bind_tools(tools) if tools else llm
    tool_node = ToolNode(tools) if tools else None
    tc_log    = []
    messages  = [
        SystemMessage(content=system),
        HumanMessage(content=(
            f"Original task: {original_task}\n\n"
            f"Your specific instruction: {instruction}\n\n"
            + (f"Prior work:\n{prior_context}" if prior_context else "")
        )),
    ]
    t0 = time.perf_counter()

    for _ in range(5):
        response = bound_llm.invoke(messages)
        messages.append(response)
        if not getattr(response, "tool_calls", None) or not tool_node:
            break
        tool_results = tool_node.invoke({"messages": [response]})
        for tm in tool_results.get("messages", []):
            messages.append(tm)
            tc_id   = getattr(tm, "tool_call_id", None)
            matched = next((tc for tc in response.tool_calls if tc["id"] == tc_id), {})
            tc_log.append({
                "tool":   matched.get("name", "unknown"),
                "args":   matched.get("args", {}),
                "output": getattr(tm, "content", "")[:300],
            })

    ms     = round((time.perf_counter() - t0) * 1000, 2)
    output = getattr(messages[-1], "content", "") or ""
    return output, tc_log, ms


# ═══════════════════════════════════════════════════════════════
#  GRAPH NODES
# ═══════════════════════════════════════════════════════════════

from langgraph.graph import StateGraph, START, END


def complexity_scorer_node(state: DynamicState) -> dict:
    system = (
        "You are a task complexity analyser. Score the task:\n"
        "  1 = simple   : single direct question, no external data needed\n"
        "  2 = moderate : needs 1-2 research or calculation steps\n"
        "  3 = complex  : multi-step, cross-domain, needs research + analysis + synthesis\n\n"
        "Available roles: researcher, analyst, critic, synthesiser.\n"
        "Respond ONLY with JSON:\n"
        '{"score": 1|2|3, "reason": "...", "plan": ['
        '{"agent": "<name>", "role": "<role>", "instruction": "<specific instruction>"}]}'
    )
    t0       = time.perf_counter()
    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=state["original_task"])])
    ms       = round((time.perf_counter() - t0) * 1000, 2)

    try:
        raw  = response.content.strip().strip("```json").strip("```").strip()
        data = json.loads(raw)
        score  = int(data.get("score", 2))
        reason = data.get("reason", "")
        plan   = data.get("plan", [])
        if not plan:
            raise ValueError("Empty plan")
    except Exception:
        score, reason = 2, "Parse fallback — using default moderate plan"
        plan = [
            {"agent": "researcher",  "role": "researcher",
             "instruction": f"Research background on: {state['original_task']}"},
            {"agent": "synthesiser", "role": "synthesiser",
             "instruction": "Write and save a concise final answer."},
        ]

    routing_entry = {"node": "complexity_scorer", "score": score,
                     "reason": reason, "plan_length": len(plan), "ms": ms}
    return {
        "complexity_score":  score,
        "complexity_reason": reason,
        "execution_plan":    plan,
        "plan_step_idx":     0,
        "step_outputs":      [],
        "plan_revisions":    [],
        "routing_log":       state.get("routing_log", []) + [routing_entry],
        "messages": [AIMessage(content=(
            f"[Scorer] Complexity={score}. Plan: {[s['agent'] for s in plan]}"
        ))],
    }


def dynamic_executor_node(state: DynamicState) -> dict:
    plan        = state["execution_plan"]
    idx         = state["plan_step_idx"]
    step        = plan[idx]
    role        = step.get("role", "researcher")
    instruction = step.get("instruction", state["original_task"])

    prior_context = "\n\n".join(
        f"[{o['agent']} output]: {o['output'][:300]}"
        for o in state["step_outputs"]
    )

    output, tc_log, ms = react_loop(role, instruction, prior_context, state["original_task"])

    step_output = {
        "step":        idx,
        "agent":       step.get("agent", f"step_{idx}"),
        "role":        role,
        "instruction": instruction[:100],
        "output":      output,
        "tool_calls":  tc_log,
        "ms":          ms,
    }

    # Mid-run plan revision for complex tasks (every 2 steps)
    plan_revision = None
    if (state["complexity_score"] == 3 and idx > 0
            and idx % 2 == 0 and idx < len(plan) - 1):
        rev_response = llm.invoke([
            SystemMessage(content=(
                "You are a plan reviewer. Should the remaining plan steps be adjusted? "
                "Return revised remaining steps as a JSON array, or [] if no changes needed."
            )),
            HumanMessage(content=(
                f"Task: {state['original_task']}\n\n"
                f"Work so far:\n{prior_context}\n\n"
                f"Remaining: {json.dumps(plan[idx + 1:])}"
            )),
        ])
        try:
            raw_rev = rev_response.content.strip().strip("```json").strip("```")
            revised = json.loads(raw_rev)
            if isinstance(revised, list) and revised:
                plan_revision = {"at_step": idx, "original_tail": plan[idx + 1:],
                                 "revised_tail": revised}
                plan = plan[:idx + 1] + revised
        except Exception:
            pass

    routing_entry = {
        "node": "dynamic_executor", "step": idx,
        "agent": step.get("agent"), "role": role,
        "tools_called": [tc["tool"] for tc in tc_log], "ms": ms,
    }
    new_revisions = list(state.get("plan_revisions", []))
    if plan_revision:
        new_revisions.append(plan_revision)

    return {
        "step_outputs":   state["step_outputs"] + [step_output],
        "plan_step_idx":  idx + 1,
        "execution_plan": plan,
        "plan_revisions": new_revisions,
        "routing_log":    state.get("routing_log", []) + [routing_entry],
        "messages": [AIMessage(content=(
            f"[{step.get('agent')} ({role})] step={idx}: {output[:200]}"
        ))],
    }


def synthesiser_node(state: DynamicState) -> dict:
    all_outputs = "\n\n".join(
        f"[Step {o['step']} — {o['agent']} ({o['role']})]: {o['output']}"
        for o in state["step_outputs"]
    )
    output, tc_log, ms = react_loop(
        role="synthesiser",
        instruction=f"Combine all prior outputs into a final answer and save it to {OUTPUT_FILE}.",
        prior_context=all_outputs,
        original_task=state["original_task"],
    )
    try:
        with open(OUTPUT_FILE, "r") as f:
            saved = f.read()
    except FileNotFoundError:
        saved = output

    return {
        "final_output": saved,
        "routing_log":  state.get("routing_log", []) + [
            {"node": "synthesiser", "tools_called": [tc["tool"] for tc in tc_log], "ms": ms}
        ],
        "messages": [AIMessage(content=f"[Synthesiser] {output[:200]}")],
    }


# ═══════════════════════════════════════════════════════════════
#  ROUTING
# ═══════════════════════════════════════════════════════════════

def route_after_scorer(state: DynamicState) -> str:
    return "synthesiser_node" if state["complexity_score"] == 1 else "dynamic_executor_node"


def route_after_executor(state: DynamicState) -> str:
    return ("dynamic_executor_node"
            if state["plan_step_idx"] < len(state["execution_plan"])
            else "synthesiser_node")


# ═══════════════════════════════════════════════════════════════
#  BUILD GRAPH
# ═══════════════════════════════════════════════════════════════

builder = StateGraph(DynamicState)
builder.add_node("complexity_scorer_node", complexity_scorer_node)
builder.add_node("dynamic_executor_node",  dynamic_executor_node)
builder.add_node("synthesiser_node",       synthesiser_node)

builder.add_edge(START, "complexity_scorer_node")
builder.add_conditional_edges(
    "complexity_scorer_node", route_after_scorer,
    {"dynamic_executor_node": "dynamic_executor_node",
     "synthesiser_node": "synthesiser_node"},
)
builder.add_conditional_edges(
    "dynamic_executor_node", route_after_executor,
    {"dynamic_executor_node": "dynamic_executor_node",
     "synthesiser_node": "synthesiser_node"},
)
builder.add_edge("synthesiser_node", END)

graph = builder.compile()

# ═══════════════════════════════════════════════════════════════
#  AGENT
# ═══════════════════════════════════════════════════════════════


def run_agent(user_input: str) -> dict:
    run_id = str(uuid.uuid4())
    initial: DynamicState = {
        "messages":          [HumanMessage(content=user_input)],
        "original_task":     user_input,
        "complexity_score":  0,
        "complexity_reason": "",
        "execution_plan":    [],
        "plan_step_idx":     0,
        "step_outputs":      [],
        "plan_revisions":    [],
        "routing_log":       [],
        "final_output":      "",
    }

    t0          = time.perf_counter()
    final_state = _lookover.invoke(graph, initial, {"recursion_limit": 30})
    latency_ms  = round((time.perf_counter() - t0) * 1000, 2)

    all_tool_calls = [tc for s in final_state["step_outputs"] for tc in s.get("tool_calls", [])]

    return {
        "agent":             "agent_19_dynamic_routing",
        "provider":          PROVIDER,
        "model":             getattr(llm, "model", getattr(llm, "model_name", "unknown")),
        "run_id":            run_id,
        "input":             user_input,
        "output":            final_state["final_output"],
        "output_file":       OUTPUT_FILE,
        "complexity_score":  final_state["complexity_score"],
        "complexity_reason": final_state["complexity_reason"],
        "execution_plan":    final_state["execution_plan"],
        "step_outputs":      final_state["step_outputs"],
        "plan_revisions":    final_state["plan_revisions"],
        "routing_log":       final_state["routing_log"],
        "tool_calls":        all_tool_calls,
        "total_steps_run":   final_state["plan_step_idx"],
        "latency_ms":        latency_ms,
    }


# ═══════════════════════════════════════════════════════════════
#  CLI — three queries at different complexity levels
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    test_cases = [
        sys.argv[1] if len(sys.argv) > 1 else "What is 2 + 2?",
        sys.argv[2] if len(sys.argv) > 2 else "What is the current weather in Berlin and the TSLA stock price?",
        sys.argv[3] if len(sys.argv) > 3 else (
            "Search Wikipedia for 'transformer model', get the GOOGL stock price, "
            "find criticisms of large language models, calculate log(1e9), "
            "and write a balanced 3-paragraph article covering all findings."
        ),
    ]

    for i, question in enumerate(test_cases, 1):
        result = run_agent(question)
        score  = result["complexity_score"]
        label  = {1: "SIMPLE", 2: "MODERATE", 3: "COMPLEX"}.get(score, "?")

        print(f"\n{'═'*60}")
        print(f"  Test {i}  |  Complexity: {score} ({label})")
        print(f"{'═'*60}")
        print(f"  Input    : {result['input'][:80]}")
        print(f"  Reason   : {result['complexity_reason'][:80]}")
        print(f"  Plan     : {[s['agent'] for s in result['execution_plan']]}")
        print(f"  Steps run: {result['total_steps_run']}")
        if result["plan_revisions"]:
            print(f"  Revisions: {len(result['plan_revisions'])} mid-run plan change(s)")
        print(f"\n  Real tool calls ({len(result['tool_calls'])}):")
        for tc in result["tool_calls"]:
            print(f"    [{tc['tool']}]  args={tc['args']}  → {str(tc['output'])[:70]}")
        print(f"\n  Routing log:")
        for r in result["routing_log"]:
            node  = r["node"].ljust(25)
            tools = r.get("tools_called", [])
            info  = f"score={r['score']}" if "score" in r else f"tools={tools}"
            print(f"    {node} {info}  [{r.get('ms', 0)} ms]")
        print(f"\n  Output: {result['output'][:300]}")
        print(f"  Latency: {result['latency_ms']} ms")
    print()
