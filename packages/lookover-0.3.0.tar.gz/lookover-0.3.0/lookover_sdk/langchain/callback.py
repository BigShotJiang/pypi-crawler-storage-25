"""LangChain callback handler that sends events to Lookover."""

from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Optional

from ..client import LookoverClient
from ..models import AgentEvent, EventType

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError as e:
    raise ImportError(
        "langchain-core is required for LookoverCallbackHandler. "
        "Install with: pip install 'lookover-sdk[langchain]'"
    ) from e


class LookoverCallbackHandler(BaseCallbackHandler):
    """
    LangChain callback handler that emits AgentEvents to Lookover.

    Each LLM call, chain, and tool invocation produces a single complete span
    (not a started + ended pair) so the UI can display input, output, and
    duration together.

    Usage:
        handler = LookoverCallbackHandler(api_key="lk_...", agent_id="my-agent")
        chain.invoke(input, config={"callbacks": [handler]})
    """

    def __init__(
        self,
        api_key: str,
        agent_id: str,
        purpose: str,
        agent_version: Optional[str] = None,
        lawful_basis: Optional[str] = None,
        consent_ref: Optional[str] = None,
        base_url: str = "http://localhost:8081",
    ):
        super().__init__()
        self.client = LookoverClient(
            api_key=api_key,
            agent_id=agent_id,
            agent_version=agent_version,
            base_url=base_url,
        )
        self.purpose = purpose
        self.lawful_basis = lawful_basis
        self.consent_ref = consent_ref
        self._run_trace_map: Dict[str, str] = {}   # run_id → trace_id
        self._root_trace_id: Optional[str] = None
        self._pending: Dict[str, Dict[str, Any]] = {}  # run_id → buffered start state

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _reset(self) -> None:
        """Reset per-invocation state so each top-level call gets a fresh trace."""
        self._root_trace_id = str(uuid.uuid4())
        self._run_trace_map = {}
        self._pending = {}

    def _is_root(self, kwargs: Dict[str, Any]) -> bool:
        return kwargs.get("parent_run_id") is None

    def _get_trace_id(self, run_id: Optional[Any]) -> str:
        key = str(run_id) if run_id is not None else "__none__"
        if key not in self._run_trace_map:
            self._run_trace_map[key] = self._root_trace_id or str(uuid.uuid4())
        return self._run_trace_map[key]

    def _finish_trace(self, trace_id: str, outcome: str = "success") -> None:
        # Send DECISION_COMPLETE so the tracer service closes the trace on the
        # server side. Calling close_trace() via HTTP would race against the
        # async Kafka pipeline and arrive before the buffer exists in Postgres.
        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.DECISION_COMPLETE,
            trace_id=trace_id,
            payload={"purpose": self.purpose},
            outcome=outcome,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)
        self.client.flush()

    def _elapsed_ms(self, run_id: str) -> Optional[int]:
        p = self._pending.get(run_id)
        if p and "t0" in p:
            return round((time.perf_counter() - p["t0"]) * 1000)
        return None

    # ── LLM callbacks — emit ONE complete span per inference ─────────────────

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> None:
        if self._is_root(kwargs):
            self._reset()
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        trace_id = self._get_trace_id(run_id)
        model_name = serialized.get("name", "") or (serialized.get("id") or [""])[-1]
        model_provider = (serialized.get("id") or [""])[0] or None
        self._pending[run_id] = {
            "t0": time.perf_counter(),
            "trace_id": trace_id,
            "model_input": {"prompt": prompts[0][:2000] if prompts else ""},
            "model_version": model_name or None,
            "model_provider": model_provider,
        }

    def on_llm_end(self, response: "LLMResult", **kwargs: Any) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        p = self._pending.pop(run_id, {})
        trace_id = p.get("trace_id") or self._get_trace_id(run_id)
        duration_ms = round((time.perf_counter() - p["t0"]) * 1000) if "t0" in p else None

        output_text = ""
        if response.generations:
            first = response.generations[0]
            output_text = str(first[0].text)[:2000] if first else ""

        token_count = None
        if response.llm_output:
            usage = response.llm_output.get("token_usage", {}) or {}
            token_count = usage.get("total_tokens")

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.MODEL_INFERENCE,
            trace_id=trace_id,
            payload={"purpose": self.purpose},
            outcome="success",
            model_provider=p.get("model_provider"),
            model_version=p.get("model_version"),
            token_count=token_count,
            duration_ms=duration_ms,
            model_input=p.get("model_input"),
            model_output={"response": output_text},
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

        if self._is_root(kwargs):
            self._finish_trace(trace_id, outcome="success")

    def on_llm_error(self, error: BaseException, **kwargs: Any) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        p = self._pending.pop(run_id, {})
        trace_id = p.get("trace_id") or self._get_trace_id(run_id)
        duration_ms = round((time.perf_counter() - p["t0"]) * 1000) if "t0" in p else None

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.MODEL_INFERENCE,
            trace_id=trace_id,
            payload={"error": str(error)[:500], "purpose": self.purpose},
            outcome="error",
            duration_ms=duration_ms,
            model_input=p.get("model_input"),
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

        if self._is_root(kwargs):
            self._finish_trace(trace_id, outcome="error")

    # ── Chain callbacks — emit ONE complete span per chain ────────────────────

    def on_chain_start(
        self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs: Any
    ) -> None:
        if self._is_root(kwargs):
            self._reset()
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        trace_id = self._get_trace_id(run_id)
        self._pending[run_id] = {
            "t0": time.perf_counter(),
            "trace_id": trace_id,
            "chain_input": str(inputs)[:1000],
        }

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        p = self._pending.pop(run_id, {})
        trace_id = p.get("trace_id") or self._get_trace_id(run_id)
        duration_ms = round((time.perf_counter() - p["t0"]) * 1000) if "t0" in p else None

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.DECISION,
            trace_id=trace_id,
            payload={
                "purpose": self.purpose,
                "input": p.get("chain_input", ""),
                "output": str(outputs)[:1000],
            },
            outcome="success",
            duration_ms=duration_ms,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

        if self._is_root(kwargs):
            self._finish_trace(trace_id, outcome="success")

    def on_chain_error(self, error: BaseException, **kwargs: Any) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        p = self._pending.pop(run_id, {})
        trace_id = p.get("trace_id") or self._get_trace_id(run_id)
        duration_ms = round((time.perf_counter() - p["t0"]) * 1000) if "t0" in p else None

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.DECISION,
            trace_id=trace_id,
            payload={"error": str(error)[:500], "purpose": self.purpose},
            outcome="error",
            duration_ms=duration_ms,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

        if self._is_root(kwargs):
            self._finish_trace(trace_id, outcome="error")

    # ── Tool callbacks — emit ONE complete span per tool call ─────────────────

    def on_tool_start(
        self, serialized: Dict[str, Any], input_str: str, **kwargs: Any
    ) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        trace_id = self._get_trace_id(run_id)
        tool_name = serialized.get("name", "unknown_tool")
        self._pending[run_id] = {
            "t0": time.perf_counter(),
            "trace_id": trace_id,
            "tool_name": tool_name,
            "tool_args": {"input": input_str[:500]},
        }

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        p = self._pending.pop(run_id, {})
        trace_id = p.get("trace_id") or self._get_trace_id(run_id)
        duration_ms = round((time.perf_counter() - p["t0"]) * 1000) if "t0" in p else None
        tool_name = p.get("tool_name", "unknown_tool")

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.TOOL_CALL,
            trace_id=trace_id,
            payload={"purpose": self.purpose, "result": str(output)[:500]},
            outcome="success",
            tool_name=tool_name,
            tool_args=p.get("tool_args"),
            duration_ms=duration_ms,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

    # ── Agent finish ──────────────────────────────────────────────────────────

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        run_id = str(kwargs.get("run_id", uuid.uuid4()))
        trace_id = self._get_trace_id(run_id)

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.DECISION,
            trace_id=trace_id,
            payload={"final_answer": str(finish.return_values)[:500], "purpose": self.purpose},
            outcome="success",
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)
        self._finish_trace(trace_id, outcome="success")
