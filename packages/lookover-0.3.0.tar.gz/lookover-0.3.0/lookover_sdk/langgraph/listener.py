"""LangGraph listener that wraps graph invocation and sends events to Lookover."""

from __future__ import annotations

import asyncio
import json as _json
import re
import uuid
from typing import Any, Dict, List, Optional, Tuple

from ..client import LookoverClient
from ..models import AgentEvent, EventType

# Fields that are internal plumbing and not meaningful for compliance auditing.
# hop_log is excluded from state_after because tool call details are extracted into
# structured model_output instead.
_STATE_SKIP_KEYS = {"messages", "run_id", "hop_log"}


class LookoverLangGraphListener:
    """
    Wraps a LangGraph graph to capture node executions, tool calls, and LLM responses.

    Usage:
        listener = LookoverLangGraphListener(
            api_key="lk_...",
            agent_id="my-graph",
            model_provider="googleai",   # optional — shown on MODEL_INFERENCE/DECISION spans
            model_version="gemini-2.5-flash",
        )
        result = listener.invoke(graph, {"messages": [...]})
    """

    _PII_PATTERNS = [
        re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
        re.compile(r'\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b'),
        re.compile(r'\b(\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b'),
    ]

    _PII_LABELS = ["email", "ssn", "phone"]

    def __init__(
        self,
        api_key: str,
        agent_id: str,
        purpose: str,
        agent_version: Optional[str] = None,
        lawful_basis: Optional[str] = None,
        consent_ref: Optional[str] = None,
        model_provider: Optional[str] = None,
        model_version: Optional[str] = None,
        base_url: str = "http://localhost:8081",
    ):
        self.client = LookoverClient(
            api_key=api_key,
            agent_id=agent_id,
            agent_version=agent_version,
            base_url=base_url,
        )
        self.purpose = purpose
        self.lawful_basis = lawful_basis
        self.consent_ref = consent_ref
        self.model_provider = model_provider
        self.model_version = model_version

    # ── Public entry points ───────────────────────────────────────────────────

    def invoke(self, graph: Any, inputs: Dict[str, Any], config: Optional[Dict[str, Any]] = None) -> Any:
        """Invoke the graph and capture execution events. Returns the graph's result unchanged."""
        trace_id = str(uuid.uuid4())
        config = config or {}

        self._emit_decision_start(trace_id, inputs)

        outcome = "success"
        try:
            if self._is_async_graph(graph):
                result = asyncio.run(self._async_stream_invoke(graph, inputs, config, trace_id))
            else:
                result = self._stream_invoke(graph, inputs, config, trace_id)
            self._emit_decision_end(trace_id, result, outcome="success")
            return result
        except Exception as e:
            outcome = f"error: {type(e).__name__}"
            self._emit_decision_end(trace_id, {}, outcome=outcome)
            raise
        finally:
            self.client.flush()

    async def ainvoke(self, graph: Any, inputs: Dict[str, Any], config: Optional[Dict[str, Any]] = None) -> Any:
        """Async version of invoke — use inside an existing event loop."""
        trace_id = str(uuid.uuid4())
        config = config or {}

        self._emit_decision_start(trace_id, inputs)

        outcome = "success"
        try:
            result = await self._async_stream_invoke(graph, inputs, config, trace_id)
            self._emit_decision_end(trace_id, result, outcome="success")
            return result
        except Exception as e:
            outcome = f"error: {type(e).__name__}"
            self._emit_decision_end(trace_id, {}, outcome=outcome)
            raise
        finally:
            self.client.flush()

    # ── Graph streaming ───────────────────────────────────────────────────────

    def _is_async_graph(self, graph: Any) -> bool:
        return hasattr(graph, "astream") and not hasattr(graph, "_sync_stream")

    def _stream_invoke(self, graph: Any, inputs: Dict[str, Any], config: Dict[str, Any], trace_id: str) -> Any:
        """Stream sync graph, emit a span per node."""
        result = inputs
        try:
            for chunk in graph.stream(inputs, config):
                if isinstance(chunk, dict):
                    for node_name, node_output in chunk.items():
                        output_dict = node_output if isinstance(node_output, dict) else {}
                        self._emit_node_span(trace_id, node_name, output_dict)
                        result = node_output
        except AttributeError:
            result = graph.invoke(inputs, config)
        return result

    async def _async_stream_invoke(self, graph: Any, inputs: Dict[str, Any], config: Dict[str, Any], trace_id: str) -> Any:
        """Stream async graph using stream_mode='updates', emit a span per node."""
        accumulated: Dict[str, Any] = dict(inputs)
        result: Any = inputs

        try:
            async for chunk in graph.astream(inputs, config, stream_mode="updates"):
                if not isinstance(chunk, dict):
                    continue
                for node_name, node_output in chunk.items():
                    output_dict = node_output if isinstance(node_output, dict) else {}
                    # In updates mode, output_dict["messages"] = only new messages from this node.
                    self._emit_node_span(trace_id, node_name, output_dict)
                    # Merge into accumulated state for context
                    for k, v in output_dict.items():
                        if k == "messages" and isinstance(v, list):
                            accumulated.setdefault("messages", []).extend(v)
                        else:
                            accumulated[k] = v
                    result = output_dict
        except AttributeError:
            result = await graph.ainvoke(inputs, config)

        return accumulated

    # ── Trace lifecycle events ────────────────────────────────────────────────

    def _emit_decision_start(self, trace_id: str, inputs: Dict[str, Any]) -> None:
        messages = inputs.get("messages", [])
        initial_msg = self._msg_content(messages[0])[:500] if messages else str(inputs)[:500]
        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.DECISION,
            trace_id=trace_id,
            payload={"root_intent": initial_msg, "purpose": self.purpose},
            outcome="started",
            agent_version=self.client.agent_version,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

    def _emit_decision_end(self, trace_id: str, result: Any, outcome: str) -> None:
        final_msg = ""
        if isinstance(result, dict):
            for msg in reversed(result.get("messages", [])):
                if self._msg_role(msg) in ("ai", "assistant"):
                    final_msg = self._msg_content(msg)[:500]
                    break
        # DECISION_COMPLETE is the last event in the trace — the backend queue
        # processor closes the trace when it sees this, guaranteeing all prior
        # events are already in the buffer.
        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=EventType.DECISION_COMPLETE,
            trace_id=trace_id,
            payload={"result": final_msg or str(result)[:500], "purpose": self.purpose},
            outcome=outcome,
            agent_version=self.client.agent_version,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
        )
        self.client.track(event)

    # ── Per-node span ─────────────────────────────────────────────────────────

    def _emit_node_span(
        self,
        trace_id: str,
        node_name: str,
        node_update: Dict[str, Any],
    ) -> None:
        """
        Emit a structured span for one node execution.

        Two tool-call patterns are handled:
          1. Standard ToolNode pattern — AIMessage.tool_calls + ToolMessage in delta messages.
          2. Internal ReAct loop pattern — worker runs tools internally, stores log in hop_log,
             then returns only a summary AIMessage to the graph state.
        """
        after = node_update if isinstance(node_update, dict) else {}

        # ── Pattern 1: extract tool calls from delta messages (standard ToolNode) ──
        delta_messages: List[Any] = after.get("messages", [])
        msg_tool_name, msg_tool_args, msg_tool_response = self._extract_tool_call(delta_messages)
        ai_text = self._extract_ai_text(delta_messages)

        # ── Pattern 2: extract tool calls from hop_log (internal ReAct loop) ──
        hop_tool_calls: List[Dict] = []
        hop_log = after.get("hop_log", [])
        if hop_log and isinstance(hop_log, list):
            latest_hop = hop_log[-1]
            if isinstance(latest_hop, dict):
                hop_tool_calls = latest_hop.get("tool_calls", []) or []

        # ── Event type classification ──────────────────────────────────────────
        name_lower = node_name.lower()
        if "human" in name_lower or "interrupt" in name_lower or "handoff" in name_lower:
            event_type = EventType.HUMAN_HANDOFF
        elif msg_tool_name is not None or hop_tool_calls:
            event_type = EventType.TOOL_CALL
        elif "supervisor" in name_lower or "router" in name_lower or "planner" in name_lower:
            event_type = EventType.DECISION
        else:
            event_type = EventType.MODEL_INFERENCE

        # ── Build structured fields ────────────────────────────────────────────
        tool_name: Optional[str] = None
        tool_args: Optional[Dict] = None
        model_output: Optional[Dict] = None

        if msg_tool_name:
            # Standard ToolNode: single tool call visible in messages
            tool_name = msg_tool_name
            tool_args = msg_tool_args
            if msg_tool_response:
                model_output = {"tool_response": self._scrub_pii(msg_tool_response)}

        elif hop_tool_calls:
            # Internal ReAct loop: worker called multiple tools inside its node
            tool_name = hop_tool_calls[0].get("tool") if hop_tool_calls else None
            tool_args = hop_tool_calls[0].get("args") if hop_tool_calls else None
            # Build a structured log of every tool call + response
            calls_log = [
                {
                    "tool": tc.get("tool"),
                    "args": tc.get("args"),
                    "response": tc.get("output", ""),
                }
                for tc in hop_tool_calls
                if isinstance(tc, dict)
            ]
            model_output = {"tool_calls": self._scrub_pii(calls_log)}

        elif ai_text:
            # LLM response (decision/routing or model inference)
            model_output = {"response": self._scrub_pii(ai_text)}

        # ── State changes: only non-plumbing fields (routing decisions, flags) ─
        state_changes = {k: v for k, v in after.items() if k not in _STATE_SKIP_KEYS}
        state_changes_safe = self._scrub_pii(state_changes) if state_changes else None

        # ── Include model provider/version on LLM-calling spans ───────────────
        is_llm_span = event_type in (EventType.MODEL_INFERENCE, EventType.DECISION)

        # ── Detect PII in node output before scrubbing ─────────────────────────
        detected_pii_flags = self._detect_pii_flags(node_update)
        output_pii_detected = True if detected_pii_flags else None

        event = AgentEvent(
            agent_id=self.client.agent_id,
            event_type=event_type,
            trace_id=trace_id,
            node_name=node_name,
            tool_name=self._scrub_pii(tool_name) if tool_name else None,
            tool_args=self._scrub_pii(tool_args) if tool_args else None,
            model_output=model_output,
            state_after=state_changes_safe,
            model_provider=self.model_provider if is_llm_span else None,
            model_version=self.model_version if is_llm_span else None,
            payload={"purpose": self.purpose},
            outcome="success",
            agent_version=self.client.agent_version,
            lawful_basis=self.lawful_basis,
            consent_ref=self.consent_ref,
            pii_flags=detected_pii_flags if detected_pii_flags else None,
            output_pii_detected=output_pii_detected,
        )
        self.client.track(event)

    # ── Message extraction helpers ────────────────────────────────────────────

    def _msg_role(self, msg: Any) -> str:
        if isinstance(msg, dict):
            return msg.get("role", msg.get("type", "unknown"))
        return getattr(msg, "type", "unknown")

    def _msg_content(self, msg: Any) -> str:
        if isinstance(msg, dict):
            c = msg.get("content", "")
        else:
            c = getattr(msg, "content", "")
        if isinstance(c, list):
            c = " ".join(
                p.get("text", str(p)) if isinstance(p, dict) else str(p)
                for p in c
            )
        return str(c)

    def _msg_tool_calls(self, msg: Any) -> List[Any]:
        if isinstance(msg, dict):
            return msg.get("tool_calls", []) or []
        return getattr(msg, "tool_calls", None) or []

    def _extract_tool_call(self, messages: List[Any]) -> Tuple[Optional[str], Optional[Dict], Optional[str]]:
        """Extract (tool_name, tool_args, tool_response) from delta messages (standard ToolNode pattern)."""
        tool_name: Optional[str] = None
        tool_args: Optional[Dict] = None
        tool_response: Optional[str] = None

        for msg in messages:
            tcs = self._msg_tool_calls(msg)
            if tcs and tool_name is None:
                tc = tcs[0]
                if isinstance(tc, dict):
                    tool_name = tc.get("name")
                    tool_args = tc.get("args")
                else:
                    tool_name = getattr(tc, "name", None)
                    tool_args = getattr(tc, "args", None)
            if self._msg_role(msg) == "tool" and tool_response is None:
                tool_response = self._msg_content(msg)[:2000]

        return tool_name, tool_args, tool_response

    def _extract_ai_text(self, messages: List[Any]) -> Optional[str]:
        """Return the last AI text response that is NOT a tool call request."""
        for msg in reversed(messages):
            if self._msg_role(msg) in ("ai", "assistant"):
                if not self._msg_tool_calls(msg):
                    return self._msg_content(msg)[:3000]
        return None

    # ── PII detection ─────────────────────────────────────────────────────────

    def _detect_pii_flags(self, data: Any) -> List[str]:
        """Walk data and return a deduplicated list of PII type labels detected."""
        found: List[str] = []
        self._collect_pii_flags(data, found)
        # Deduplicate while preserving order
        seen = set()
        result = []
        for label in found:
            if label not in seen:
                seen.add(label)
                result.append(label)
        return result

    def _collect_pii_flags(self, data: Any, found: List[str]) -> None:
        if isinstance(data, str):
            for idx, pattern in enumerate(self._PII_PATTERNS):
                if pattern.search(data):
                    found.append(self._PII_LABELS[idx])
        elif isinstance(data, dict):
            for v in data.values():
                self._collect_pii_flags(v, found)
        elif isinstance(data, list):
            for item in data:
                self._collect_pii_flags(item, found)
        else:
            try:
                self._collect_pii_flags(str(data), found)
            except Exception:
                pass

    # ── PII scrubbing ─────────────────────────────────────────────────────────

    def _scrub_pii(self, data: Any) -> Any:
        if isinstance(data, str):
            result = data
            for pattern in self._PII_PATTERNS:
                result = pattern.sub("[REDACTED]", result)
            return result
        if isinstance(data, dict):
            return {k: self._scrub_pii(v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._scrub_pii(item) for item in data]
        try:
            _json.dumps(data)
            return data
        except (TypeError, ValueError):
            return self._scrub_pii(str(data))
