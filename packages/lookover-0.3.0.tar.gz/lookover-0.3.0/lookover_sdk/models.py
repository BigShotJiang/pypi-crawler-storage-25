"""AgentEvent data model matching the Lookover V2 backend."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class EventType(str, Enum):
    TOOL_CALL = "TOOL_CALL"
    MODEL_INFERENCE = "MODEL_INFERENCE"
    DATA_ACCESS = "DATA_ACCESS"
    DECISION = "DECISION"
    HUMAN_HANDOFF = "HUMAN_HANDOFF"
    DECISION_COMPLETE = "DECISION_COMPLETE"


@dataclass
class AgentEvent:
    """An agent event to be sent to the Lookover ingestion API."""

    # Required fields
    agent_id: str
    event_type: EventType
    payload: Dict[str, Any]
    outcome: str = "success"

    # Auto-generated if not provided
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    span_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Optional context
    pii_flags: Optional[List[str]] = None
    data_subjects: Optional[List[str]] = None
    consent_ref: Optional[str] = None
    compliance_tags: Optional[List[str]] = None
    retention_class: str = "standard"

    # Structured span fields — mapped to dedicated DB columns by the backend
    model_input: Optional[Dict[str, Any]] = None
    model_output: Optional[Dict[str, Any]] = None
    tool_name: Optional[str] = None
    tool_args: Optional[Dict[str, Any]] = None
    duration_ms: Optional[int] = None
    node_name: Optional[str] = None        # LangGraph node name → Span.NodeName
    state_before: Optional[Dict[str, Any]] = None  # LangGraph state snapshot before node → Span.StateBefore
    state_after: Optional[Dict[str, Any]] = None   # LangGraph state snapshot after node → Span.StateAfter

    # V2 fields — all optional
    ai_act_risk_tier: Optional[str] = None       # unacceptable | high | limited | minimal
    lawful_basis: Optional[str] = None
    injection_scan_result: Optional[str] = None
    output_pii_detected: Optional[bool] = None
    grounding_score: Optional[float] = None
    token_count: Optional[int] = None
    loop_detected: Optional[bool] = None
    model_provider: Optional[str] = None
    model_version: Optional[str] = None
    tools_invoked_scope: Optional[List[str]] = None
    tools_declared_scope: Optional[List[str]] = None
    data_transfer_dest: Optional[str] = None
    transfer_mechanism: Optional[str] = None
    disclosure_shown: Optional[bool] = None
    agent_version: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dict for JSON encoding, omitting None values."""
        d: Dict[str, Any] = {
            "event_id": self.event_id,
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "agent_id": self.agent_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp,
            "payload": self.payload,
            "outcome": self.outcome,
            "retention_class": self.retention_class,
        }
        optional_fields = [
            "pii_flags", "data_subjects", "consent_ref", "compliance_tags",
            # Structured span fields
            "model_input", "model_output", "tool_name", "tool_args", "duration_ms",
            "node_name", "state_before", "state_after",
            # V2 fields
            "ai_act_risk_tier", "lawful_basis", "injection_scan_result",
            "output_pii_detected", "grounding_score", "token_count", "loop_detected",
            "model_provider", "model_version", "tools_invoked_scope", "tools_declared_scope",
            "data_transfer_dest", "transfer_mechanism", "disclosure_shown", "agent_version",
        ]
        for f in optional_fields:
            v = getattr(self, f)
            if v is not None:
                d[f] = v
        return d
