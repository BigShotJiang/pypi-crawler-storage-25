"""Lookover HTTP client — batches and sends AgentEvents to the ingestion API."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import List, Optional

import httpx

from .models import AgentEvent

logger = logging.getLogger("lookover")

_DEFAULT_BASE_URL = "http://localhost:8081"
_BATCH_SIZE = 50
_FLUSH_INTERVAL = 1.0  # seconds
_MAX_RETRIES = 3


class LookoverClient:
    """
    Thread-safe Lookover client with async batching.

    Usage (sync):
        client = LookoverClient(api_key="lk_...", agent_id="my-agent")
        client.track(event)
        client.flush()

    Usage (async):
        async with LookoverClient(api_key="lk_...") as client:
            await client.track_async(event)
    """

    def __init__(
        self,
        api_key: str,
        agent_id: str = "default-agent",
        agent_version: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        flush_interval: float = _FLUSH_INTERVAL,
        batch_size: int = _BATCH_SIZE,
    ):
        self.api_key = api_key
        self.agent_id = agent_id
        self.agent_version = agent_version
        self.base_url = base_url.rstrip("/")
        self.flush_interval = flush_interval
        self.batch_size = batch_size

        self._queue: List[AgentEvent] = []
        self._lock = asyncio.Lock() if self._has_event_loop() else None
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=10.0,
        )
        self._async_http: Optional[httpx.AsyncClient] = None

    def _has_event_loop(self) -> bool:
        try:
            asyncio.get_event_loop()
            return True
        except RuntimeError:
            return False

    def track(self, event: AgentEvent) -> None:
        """Add an event to the batch queue. Flushes when batch_size is reached."""
        # Stamp agent defaults
        if not event.agent_id:
            event.agent_id = self.agent_id
        if self.agent_version and not event.agent_version:
            event.agent_version = self.agent_version

        self._queue.append(event)
        if len(self._queue) >= self.batch_size:
            self.flush()

    def flush(self) -> None:
        """Synchronously flush all queued events to the API."""
        if not self._queue:
            return
        batch = self._queue[:]
        self._queue.clear()
        self._send_batch(batch)

    def _send_batch(self, events: List[AgentEvent], attempt: int = 0) -> None:
        payload = {"events": [e.to_dict() for e in events]}
        try:
            resp = self._http.post("/v1/events", json=payload)
            resp.raise_for_status()
            logger.debug("lookover: sent %d events", len(events))
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500 and attempt < _MAX_RETRIES:
                wait = 2 ** attempt
                logger.warning("lookover: server error, retrying in %ds (attempt %d)", wait, attempt + 1)
                time.sleep(wait)
                self._send_batch(events, attempt + 1)
            else:
                logger.error("lookover: failed to send events: %s", e)
        except Exception as e:
            logger.error("lookover: unexpected error sending events: %s", e)

    def close(self) -> None:
        """Flush remaining events and close the HTTP client."""
        self.flush()
        self._http.close()

    def __enter__(self) -> "LookoverClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # Async interface
    async def track_async(self, event: AgentEvent) -> None:
        """Async version of track()."""
        self.track(event)

    async def flush_async(self) -> None:
        """Async version of flush()."""
        if not self._queue:
            return
        batch = self._queue[:]
        self._queue.clear()
        if not self._async_http:
            self._async_http = httpx.AsyncClient(
                base_url=self.base_url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10.0,
            )
        await self._send_batch_async(batch)

    async def _send_batch_async(self, events: List[AgentEvent], attempt: int = 0) -> None:
        payload = {"events": [e.to_dict() for e in events]}
        try:
            resp = await self._async_http.post("/v1/events", json=payload)  # type: ignore[union-attr]
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500 and attempt < _MAX_RETRIES:
                await asyncio.sleep(2 ** attempt)
                await self._send_batch_async(events, attempt + 1)
            else:
                logger.error("lookover: failed to send events: %s", e)
        except Exception as e:
            logger.error("lookover: unexpected error: %s", e)

    def close_trace(self, trace_id: str, outcome: str = "success", reason: str = "") -> None:
        """Signal Lookover to close and finalize a trace (sync)."""
        try:
            resp = self._http.post(
                f"/v1/traces/{trace_id}/close",
                json={"outcome": outcome, "reason": reason},
            )
            resp.raise_for_status()
            logger.debug("lookover: closed trace %s", trace_id)
        except Exception as e:
            logger.warning("lookover: failed to close trace %s: %s", trace_id, e)

    async def close_trace_async(self, trace_id: str, outcome: str = "success", reason: str = "") -> None:
        """Signal Lookover to close and finalize a trace (async)."""
        if not self._async_http:
            self._async_http = httpx.AsyncClient(
                base_url=self.base_url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10.0,
            )
        try:
            resp = await self._async_http.post(
                f"/v1/traces/{trace_id}/close",
                json={"outcome": outcome, "reason": reason},
            )
            resp.raise_for_status()
            logger.debug("lookover: closed trace %s", trace_id)
        except Exception as e:
            logger.warning("lookover: failed to close trace %s: %s", trace_id, e)

    async def __aenter__(self) -> "LookoverClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.flush_async()
        if self._async_http:
            await self._async_http.aclose()
