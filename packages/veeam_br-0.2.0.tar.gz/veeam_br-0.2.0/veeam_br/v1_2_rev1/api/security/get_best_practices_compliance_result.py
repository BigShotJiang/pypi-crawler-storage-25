from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.best_practices_compliance_result import BestPracticesComplianceResult
from ...models.error import Error
from ...types import Response


def _get_kwargs(
    *,
    x_api_version: str = "1.2-rev1",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["x-api-version"] = x_api_version

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/securityAnalyzer/bestPractices",
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BestPracticesComplianceResult | Error | None:
    if response.status_code == 200:
        response_200 = BestPracticesComplianceResult.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BestPracticesComplianceResult | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    x_api_version: str = "1.2-rev1",
) -> Response[BestPracticesComplianceResult | Error]:
    """Get Security & Compliance Analyzer Results

     The HTTP GET request to the `/api/v1/securityAnalyzer/bestPractices` path allows you to get best
    practices compliance result from the Backup server.<p>**Available to**&#58; Veeam Backup
    Administrator, Veeam Security Administrator.</p>

    Args:
        x_api_version (str):  Default: '1.2-rev1'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BestPracticesComplianceResult | Error]
    """

    kwargs = _get_kwargs(
        x_api_version=x_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    x_api_version: str = "1.2-rev1",
) -> BestPracticesComplianceResult | Error | None:
    """Get Security & Compliance Analyzer Results

     The HTTP GET request to the `/api/v1/securityAnalyzer/bestPractices` path allows you to get best
    practices compliance result from the Backup server.<p>**Available to**&#58; Veeam Backup
    Administrator, Veeam Security Administrator.</p>

    Args:
        x_api_version (str):  Default: '1.2-rev1'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BestPracticesComplianceResult | Error
    """

    return sync_detailed(
        client=client,
        x_api_version=x_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    x_api_version: str = "1.2-rev1",
) -> Response[BestPracticesComplianceResult | Error]:
    """Get Security & Compliance Analyzer Results

     The HTTP GET request to the `/api/v1/securityAnalyzer/bestPractices` path allows you to get best
    practices compliance result from the Backup server.<p>**Available to**&#58; Veeam Backup
    Administrator, Veeam Security Administrator.</p>

    Args:
        x_api_version (str):  Default: '1.2-rev1'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BestPracticesComplianceResult | Error]
    """

    kwargs = _get_kwargs(
        x_api_version=x_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    x_api_version: str = "1.2-rev1",
) -> BestPracticesComplianceResult | Error | None:
    """Get Security & Compliance Analyzer Results

     The HTTP GET request to the `/api/v1/securityAnalyzer/bestPractices` path allows you to get best
    practices compliance result from the Backup server.<p>**Available to**&#58; Veeam Backup
    Administrator, Veeam Security Administrator.</p>

    Args:
        x_api_version (str):  Default: '1.2-rev1'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BestPracticesComplianceResult | Error
    """

    return (
        await asyncio_detailed(
            client=client,
            x_api_version=x_api_version,
        )
    ).parsed
