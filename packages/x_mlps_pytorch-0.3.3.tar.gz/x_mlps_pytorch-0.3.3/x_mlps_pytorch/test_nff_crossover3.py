import torch
from nff import nFeedforward, NormLinear

ff1 = nFeedforward(32)
ff2 = nFeedforward(32)

w1 = ff1.to_hidden.weight
w2 = ff2.to_hidden.weight
crossover_weight = torch.cat((w1[:10], w2[10:]), dim=0)

if ff1.to_hidden.parametrize:
    ff1.to_hidden.linear.parametrizations.weight.original.copy_(crossover_weight)
else:
    ff1.to_hidden.weight.copy_(crossover_weight)

print("After copy_, weight norm diff:", (ff1.to_hidden.weight - crossover_weight).abs().max().item())
