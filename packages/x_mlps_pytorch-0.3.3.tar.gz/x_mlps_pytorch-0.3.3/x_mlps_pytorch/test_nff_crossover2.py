import torch
from nff import nFeedforward

ff1 = nFeedforward(32)
ff2 = nFeedforward(32)

w1 = ff1.to_hidden.weight
w2 = ff2.to_hidden.weight
crossover_weight = torch.cat((w1[:10], w2[10:]), dim=0)

ff1.to_hidden.weight.copy_(crossover_weight)
print("After copy_, weight norm diff:", (ff1.to_hidden.weight - crossover_weight).abs().max().item())

# now see if it persists after a forward pass or norm_weights_()
ff1.to_hidden.norm_weights_()
print("After norm_weights_, weight norm diff:", (ff1.to_hidden.weight - crossover_weight).abs().max().item())
