import torch
from nff import nFeedforward, NormLinear

try:
    ff1 = nFeedforward(32)
    ff2 = nFeedforward(32)

    # simulate crossover
    w1 = ff1.to_hidden.weight
    w2 = ff2.to_hidden.weight

    crossover_weight = torch.cat((w1[:10], w2[10:]), dim=0)

    ff1.to_hidden.weight.copy_(crossover_weight)
    print("copy_ to property weight SUCCESS")
except Exception as e:
    print("ERROR:", e)
