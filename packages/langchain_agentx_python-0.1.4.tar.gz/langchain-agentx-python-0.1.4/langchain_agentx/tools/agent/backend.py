"""
tools/agent/backend.py — Agent 工具池与执行模式决策

职责：提供 should_run_async 与 assemble_tool_pool，避免策略细节堆入 tool.py。
在整体链路中的位置：AgentRuntimeTool.invoke() 调用本模块后再调 run_subagent()。
CC 对照：src/tools/AgentTool/agentToolUtils.ts 与 AgentTool.tsx 的 shouldRunAsync。
当前裁剪范围：v1 默认同步，支持 run_in_background 显式触发与全局禁用开关。
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.models import ToolExecutionContext

    from .models import AgentToolInput
    from .registry.config import SubagentConfig

# 不变量：子 Agent 永远不能调用 Agent 工具本身，避免递归绕过深度限制。
_ALWAYS_DISALLOWED_FOR_SUBAGENT = {"Agent", "agent"}


def _background_disabled() -> bool:
    raw = os.getenv("LANGCHAIN_AGENTX_DISABLE_BACKGROUND_TASKS", "")
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def should_run_async(data: "AgentToolInput", ctx: "ToolExecutionContext") -> bool:
    """决定是否走异步路径。"""
    if _background_disabled():
        return False
    return bool(data.run_in_background)


def assemble_tool_pool(
    all_tools: list,
    config: "SubagentConfig",
    is_async: bool = False,
) -> list:
    """
    组装子 Agent 工具池。

    规则：先应用 config.tool_filter（若有），再强制移除 always-disallowed。
    """
    _ = is_async  # v1 预留参数，v2 可按异步模式再收紧工具集。
    filtered = config.tool_filter(all_tools) if config.tool_filter else list(all_tools)
    return [
        tool
        for tool in filtered
        if getattr(tool, "name", "") not in _ALWAYS_DISALLOWED_FOR_SUBAGENT
    ]
