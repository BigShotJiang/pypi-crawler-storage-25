"""
tools/agent/loader.py — 用户自定义 Agent 加载器

职责：从 Markdown 文件（{agent_home}/agents/ 下扩展名 ``.md``，大小写不敏感）加载用户自定义 Agent 配置，
      按优先级与内置原语合并后返回 SubagentRegistry。
在整体链路中的位置：编排层初始化阶段 → AgentDefinitionLoader.load() → SubagentRegistry
                    → AgentRuntimeTool(registry=...)
CC 对照：src/tools/AgentTool/loadAgentsDir.ts getAgentDefinitionsWithOverrides()
         + parseAgentFromMarkdown()
当前裁剪范围：v1 Markdown 解析 + YAML frontmatter + 优先级合并；
             tools/disallowedTools/maxTurns/background 字段支持；
             agents 目录下 ``.md`` 扩展名 **大小写不敏感**（``*.MD`` / ``*.Md`` 与 ``*.md`` 同等）；
             v2 memoization / file watcher

加载优先级（后者覆盖前者，与 CC getActiveAgentsFromList 一致）：
  built-in < userSettings < projectSettings

文件格式（与 CC 一致）：
  ---
  name: my-agent          # 必填
  description: Does XYZ   # 必填
  tools: [Read, Glob]     # 可选，allowlist（省略=全部）
  disallowedTools: [Edit] # 可选，denylist（优先级高于 tools）
  maxTurns: 30            # 可选，default_max_steps
  background: false       # 可选，allow_async
  ---
  系统提示词 body...
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .registry.config import SubagentConfig
from .registry.registry import SubagentRegistry

logger = logging.getLogger(__name__)

# 子 Agent 始终禁止调用 AgentTool 本身（与 backend.py 不变量一致）
_ALWAYS_DISALLOWED = {"Agent", "agent"}


@dataclass
class AgentLoadResult:
    """加载结果：成功加载的 config 列表 + 失败文件列表。"""
    configs: list[SubagentConfig] = field(default_factory=list)
    failed_files: list[dict[str, Any]] = field(default_factory=list)


class AgentDefinitionLoader:
    """从 Markdown 文件加载用户自定义 Agent，按优先级合并到 SubagentRegistry。

    优先级（后加载覆盖先加载）：built-in < userSettings < projectSettings
    CC 对照：loadAgentsDir.ts getAgentDefinitionsWithOverrides()
    """

    def __init__(
        self,
        workspace_config: Any | None = None,
        base_registry: SubagentRegistry | None = None,
        user_agents_dir: str | Path | None = None,
    ) -> None:
        """
        Args:
            workspace_config: AgentWorkspaceConfig 实例（提供 agents_dir 路径）。
                              None 时跳过 projectSettings 加载。
            base_registry:    内置能力原语注册表（built-in 层）。
            user_agents_dir:  用户级 agents 目录（~/.config/langchain_agentx/agents/）。
                              None 时跳过 userSettings 加载。
        """
        self._workspace_config = workspace_config
        self._base_registry = base_registry
        self._user_agents_dir = Path(user_agents_dir) if user_agents_dir else None

    def load(self) -> SubagentRegistry:
        """加载所有 Agent 定义，按优先级合并，返回合并后的 SubagentRegistry。

        合并规则：built-in < userSettings < projectSettings（后写覆盖前写）
        CC 对照：getActiveAgentsFromList() 的 agentMap 合并逻辑
        """
        merged: dict[str, SubagentConfig] = {}

        # 1. built-in（最低优先级）
        if self._base_registry:
            for cfg in self._base_registry.list_all():
                merged[cfg.name] = cfg

        # 2. userSettings
        for cfg in self._load_from_dir(self._user_agents_dir):
            merged[cfg.name] = cfg

        # 3. projectSettings（最高优先级）
        project_dir = self._get_project_agents_dir()
        for cfg in self._load_from_dir(project_dir):
            merged[cfg.name] = cfg

        registry = SubagentRegistry()
        for cfg in merged.values():
            registry.register(cfg)
        return registry

    def _get_project_agents_dir(self) -> Path | None:
        """从 workspace_config 获取 projectSettings agents 目录。"""
        if self._workspace_config is None:
            return None
        agents_dir = getattr(self._workspace_config, "agents_dir", None)
        return Path(agents_dir) if agents_dir else None

    def _load_from_dir(self, directory: Path | None) -> list[SubagentConfig]:
        """从目录加载所有 Markdown agent 文件，返回解析成功的 SubagentConfig 列表。

        扩展名按 **大小写不敏感** 匹配 ``.md``（Linux 上 ``*.MD`` 与 CC 产品预期一致）。
        目录不存在时安静跳过，不抛异常。
        """
        if directory is None or not directory.exists():
            return []
        configs: list[SubagentConfig] = []
        for md_file in _iter_markdown_agent_files(directory):
            cfg = self._parse_agent_from_markdown(md_file)
            if cfg is not None:
                configs.append(cfg)
        return configs

    def _parse_agent_from_markdown(self, file_path: Path) -> SubagentConfig | None:
        """解析单个 Markdown agent 定义文件。
        CC 对照：parseAgentFromMarkdown()

        必填：name、description；缺失时静默跳过（可能是参考文档）。
        """
        try:
            raw = file_path.read_text(encoding="utf-8")
        except OSError as exc:
            logger.warning("Cannot read agent file %s: %s", file_path, exc)
            return None

        frontmatter, body = self._split_frontmatter(raw)
        if frontmatter is None:
            return None  # 无 frontmatter，静默跳过

        name = frontmatter.get("name")
        description = frontmatter.get("description")
        if not name or not isinstance(name, str):
            return None
        if not description or not isinstance(description, str):
            logger.warning("Agent file %s missing 'description', skipping", file_path)
            return None

        system_prompt = body.strip()
        tools_raw = frontmatter.get("tools")
        disallowed_raw = frontmatter.get("disallowedTools")
        max_turns = _parse_positive_int(frontmatter.get("maxTurns"))
        allow_async = bool(_parse_bool(frontmatter.get("background")))
        tool_filter = self._build_tool_filter(tools_raw, disallowed_raw)
        tools_description = _describe_tools(tools_raw, disallowed_raw)

        return SubagentConfig(
            name=name.strip(),
            description=description.strip(),
            system_prompt_factory=lambda sp=system_prompt: sp,
            tool_filter=tool_filter,
            tools_description=tools_description,
            default_max_steps=max_turns,
            allow_async=allow_async,
            tags={"custom"},
        )

    def _split_frontmatter(self, text: str) -> tuple[dict | None, str]:
        """分离 YAML frontmatter 与 body。
        格式：--- frontmatter --- body
        CC 对照：markdownConfigLoader.ts frontmatter 分割逻辑
        """
        if not text.startswith("---"):
            return None, text
        parts = text.split("---", 2)
        if len(parts) < 3:
            return None, text
        try:
            import yaml
            fm = yaml.safe_load(parts[1]) or {}
        except Exception as exc:
            logger.warning("YAML parse error in frontmatter: %s", exc)
            return None, text
        return fm, parts[2]

    def _build_tool_filter(
        self,
        tools_raw: Any,
        disallowed_raw: Any,
    ):
        """根据 tools/disallowedTools 字段构建 tool_filter 函数。
        CC 对照：parseAgentToolsFromFrontmatter() + filterToolsForAgent()
        denylist 优先级高于 allowlist；AgentTool 本身始终在 denylist。
        """
        # 解析 allowlist
        if tools_raw is None or tools_raw == ["*"]:
            allowlist: set[str] | None = None  # None = 全工具集
        elif isinstance(tools_raw, list):
            allowlist = set(tools_raw)
        else:
            allowlist = None

        # 解析 denylist（合并用户指定 + 始终禁止）
        if isinstance(disallowed_raw, list):
            denylist = set(disallowed_raw) | _ALWAYS_DISALLOWED
        else:
            denylist = set(_ALWAYS_DISALLOWED)

        if allowlist is None and denylist == _ALWAYS_DISALLOWED:
            return None  # 无过滤，全工具集（backend.py 会移除 AgentTool）

        def _filter(all_tools: list) -> list:
            result = all_tools if allowlist is None else [
                t for t in all_tools if getattr(t, "name", "") in allowlist
            ]
            return [t for t in result if getattr(t, "name", "") not in denylist]

        return _filter


# ── 辅助函数 ──────────────────────────────────────────────────────────────────


def _iter_markdown_agent_files(directory: Path) -> list[Path]:
    """枚举 ``directory`` 下扩展名为 ``.md`` 的文件（大小写不敏感），按文件名排序。"""
    if not directory.is_dir():
        return []
    paths: list[Path] = []
    try:
        entries = list(directory.iterdir())
    except OSError as exc:
        logger.warning("Cannot list agents directory %s: %s", directory, exc)
        return []
    for p in entries:
        try:
            if p.is_file() and p.suffix.lower() == ".md":
                paths.append(p)
        except OSError:
            continue
    return sorted(paths, key=lambda x: x.name.lower())


def _parse_positive_int(raw: Any) -> int | None:
    try:
        v = int(raw)
        return v if v > 0 else None
    except (TypeError, ValueError):
        return None


def _parse_bool(raw: Any) -> bool | None:
    if raw in (True, "true", "True", 1):
        return True
    if raw in (False, "false", "False", 0):
        return False
    return None


def _describe_tools(tools_raw: Any, disallowed_raw: Any) -> str:
    if tools_raw is None or tools_raw == ["*"]:
        base = "All tools"
    elif isinstance(tools_raw, list):
        base = ", ".join(tools_raw)
    else:
        base = "All tools"
    if disallowed_raw:
        return f"{base} except {', '.join(disallowed_raw)}"
    return base
