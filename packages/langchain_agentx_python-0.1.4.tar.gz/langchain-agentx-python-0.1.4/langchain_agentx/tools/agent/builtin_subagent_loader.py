"""
tools/agent/builtin_subagent_loader.py — 内置 subagent 的环境驱动装载

职责：按环境变量解析是否装载各 built_in 子模块，并写入调用方提供的 SubagentRegistry；
      提供进程内懒单例供 AgentRuntimeTool(registry=None)。
在整体链路中的位置：AgentRuntimeTool → BuiltinSubagentEnvLoader / DefaultSubagentRegistryProvider；
      built_in/ 仅保留 SubagentConfig 与各模块 register()，不包含装载策略。
CC 对照：CC 以环境变量控制内置能力；本模块为显式 OOP 装载入口。

环境变量（truthy：1/true/yes/on，大小写不敏感）：
- LANGCHAIN_AGENTX_BUILTIN_SUBAGENTS_DISABLED — 总闸：为真时不注册任何 built-in。
- LANGCHAIN_AGENTX_CLI — CLI 宿主；与 BUILTIN_STATUSLINE 同时为真才注册 statusline-setup。
- LANGCHAIN_AGENTX_BUILTIN_STATUSLINE / AGENTX_GUIDE / VERIFICATION — 可选增量。
总闸未关时固定注册：general-purpose、Explore、Plan。
"""

from __future__ import annotations

import os
import threading
from collections.abc import Mapping
from typing import ClassVar

from .registry.registry import SubagentRegistry


class BuiltinSubagentEnvLoader:
    """读取环境变量，将内置 subagent 注册到已有 SubagentRegistry。"""

    def __init__(self, environ: Mapping[str, str] | None = None) -> None:
        self._environ: Mapping[str, str] = environ if environ is not None else os.environ

    @staticmethod
    def _truthy(raw: str | None) -> bool:
        if raw is None:
            return False
        return raw.strip().lower() in {"1", "true", "yes", "on"}

    def _env_flag(self, name: str) -> bool:
        return self._truthy(self._environ.get(name))

    def subagents_disabled(self) -> bool:
        return self._env_flag("LANGCHAIN_AGENTX_BUILTIN_SUBAGENTS_DISABLED")

    def load_into(self, registry: SubagentRegistry) -> None:
        if self.subagents_disabled():
            return

        from .built_in import explore, general, plan

        general.register(registry)
        explore.register(registry)
        plan.register(registry)

        if self._env_flag("LANGCHAIN_AGENTX_BUILTIN_VERIFICATION"):
            from .built_in import verification

            verification.register(registry)
        if self._env_flag("LANGCHAIN_AGENTX_BUILTIN_AGENTX_GUIDE"):
            from .built_in import agentx_guide

            agentx_guide.register(registry)
        if self._env_flag("LANGCHAIN_AGENTX_BUILTIN_STATUSLINE") and self._env_flag(
            "LANGCHAIN_AGENTX_CLI"
        ):
            from .built_in import statusline_setup

            statusline_setup.register(registry)


class DefaultSubagentRegistryProvider:
    """进程内懒单例：首次访问时用 BuiltinSubagentEnvLoader 填充 SubagentRegistry。"""

    _registry: ClassVar[SubagentRegistry | None] = None
    _lock: ClassVar[threading.Lock] = threading.Lock()

    @classmethod
    def get(cls) -> SubagentRegistry:
        with cls._lock:
            if cls._registry is None:
                cls._registry = SubagentRegistry()
                BuiltinSubagentEnvLoader().load_into(cls._registry)
            return cls._registry

    @classmethod
    def reset_for_tests(cls) -> None:
        """仅测试：释放单例以便 monkeypatch 环境后重新装载。"""
        with cls._lock:
            cls._registry = None
