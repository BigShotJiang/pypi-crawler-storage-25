"""
tools/agent/limits.py — AgentTool 配额常量

职责：集中管理 Agent 工具输出上限、嵌套深度与步数限制，不承载执行逻辑。
在整体链路中的位置：tool.py 的 check_permissions()/invoke() 读取这些阈值。
CC 对照：src/tools/AgentTool/AgentTool.tsx 的 maxResultSizeChars=100_000 与深度防护语义。
当前裁剪范围：v1 全量常量；异步输出目录为 v2 预留。
"""

from __future__ import annotations

import os

from langchain_agentx.workspace import resolve_agent_workspace_config

MAX_OUTPUT_CHARS: int = int(
    os.getenv("LANGCHAIN_AGENTX_AGENT_TOOL_MAX_OUTPUT_CHARS", "100000")
)
MAX_AGENT_DEPTH: int = int(os.getenv("LANGCHAIN_AGENTX_AGENT_TOOL_MAX_DEPTH", "3"))
_WORKSPACE_CFG = resolve_agent_workspace_config()
BACKGROUND_OUTPUT_DIR: str = os.path.expanduser(
    os.getenv(
        "LANGCHAIN_AGENTX_AGENT_TOOL_BACKGROUND_OUTPUT_DIR",
        str(_WORKSPACE_CFG.tasks_dir),
    )
)
