"""
tools/agent/cwd_resolution.py — Agent 工具 cwd 展开与 workspace 校验

职责：
    将可选 ``cwd`` 展开为绝对路径（``normalize_user_path_string_for_expand`` + ``expand_path``），
    并校验落在 ``workspace_root`` 内、目录存在；UNC 不做本地 ``isdir``（与 Grep/Read 一致）。
链路位置：
    ``AgentRuntimeTool.validate_input``（成功时写回 ``data["cwd"]`` 供 ``invoke`` 使用）。
当前裁剪：
    不替代全局 PolicyEngine；仅语义校验层中文消息。无 ``workspace_root`` 时以 ``get_cwd()`` 为展开基准，
    且不做「必须在 workspace 内」校验（与测试桩及旧编排兼容）。
CC 对照：
    ``AgentTool.tsx`` cwd 描述（Absolute path）；``utils/path.ts`` ``expandPath``。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.models import ValidationResult
from langchain_agentx.utils.cwd import expand_path, get_cwd
from langchain_agentx.utils.path_user_input import normalize_user_path_string_for_expand
from langchain_agentx.utils.unc_path import is_unc_path_skip_local_stat
from langchain_agentx.utils.win_reserved_paths import path_uses_windows_reserved_name


def _path_is_descendant(candidate: Path, ancestor: Path) -> bool:
    try:
        candidate.relative_to(ancestor)
        return True
    except ValueError:
        return False


class AgentToolCwdResolution:
    """Agent ``cwd`` 展开与校验（单类单责，避免 ``tool.py`` 堆逻辑）。"""

    @staticmethod
    def expand_to_absolute(raw: str, *, workspace_root: str | None) -> str:
        """相对路径相对 ``workspace_root``（若缺省则 ``get_cwd()``）展开为绝对路径。"""
        base = workspace_root if workspace_root else get_cwd()
        normalized = normalize_user_path_string_for_expand(raw.strip())
        return expand_path(normalized, base_dir=base)

    @staticmethod
    def validate_expanded(absolute: str, *, workspace_root: str | None) -> str | None:
        """返回 ``None`` 表示通过；否则为面向模型的中文错误信息。"""
        if path_uses_windows_reserved_name(absolute):
            return "cwd 路径包含 Windows 保留设备名，请更换为普通目录路径。"

        if is_unc_path_skip_local_stat(absolute):
            return None

        if workspace_root:
            try:
                root = Path(workspace_root).expanduser().resolve()
                candidate = Path(absolute).expanduser().resolve()
            except OSError as exc:
                return f"cwd 无法解析到 workspace 内：{exc}"
            if not _path_is_descendant(candidate, root):
                return (
                    "cwd 必须位于当前 workspace 根目录之下，"
                    "不可使用 ../ 等方式跳出工程根。"
                )

        try:
            if not os.path.isdir(absolute):
                return "cwd 必须是已存在的目录路径。"
        except OSError as exc:
            return f"cwd 无法访问（{exc}）。请确认路径存在且可读。"

        return None

    @classmethod
    def resolve_and_validate(
        cls,
        raw_cwd: str,
        *,
        ctx: Any,
    ) -> tuple[str | None, str | None]:
        """展开并校验；成功时 ``(absolute, None)``，失败 ``(None, message)``。"""
        ws = getattr(ctx, "workspace_root", None)
        if not isinstance(ws, str):
            ws = None
        if isinstance(ws, str) and not ws.strip():
            ws = None
        try:
            absolute = cls.expand_to_absolute(raw_cwd, workspace_root=ws)
        except (OSError, ValueError) as exc:
            return None, f"cwd 无法展开为有效绝对路径：{exc}"
        msg = cls.validate_expanded(absolute, workspace_root=ws)
        if msg:
            return None, msg
        return absolute, None


def apply_agent_cwd_to_data(data: dict[str, Any], ctx: Any) -> ValidationResult | None:
    """若 ``data`` 含非空 ``cwd``，展开并校验后写回绝对路径；无 cwd 或空串返回 ``None``。

    供 ``validate_input`` 与 ``invoke``（绕过 pipeline 的测试/脚本路径）共用。
    """
    raw = data.get("cwd")
    if raw is None:
        return None
    if isinstance(raw, str) and not raw.strip():
        return None
    abs_cwd, err = AgentToolCwdResolution.resolve_and_validate(str(raw), ctx=ctx)
    if err:
        return ValidationResult(ok=False, message=err)
    data["cwd"] = abs_cwd
    return None


__all__ = [
    "AgentToolCwdResolution",
    "apply_agent_cwd_to_data",
]
