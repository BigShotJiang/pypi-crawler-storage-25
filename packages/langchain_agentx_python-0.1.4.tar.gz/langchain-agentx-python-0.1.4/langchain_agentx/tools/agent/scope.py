"""
tools/agent/scope.py — Tool Scope 统一裁决入口

职责：统一计算 candidate/agent-filter/skill-allow/deny 之后的有效工具范围与自动批准集合。
在整体链路中的位置：由 skill 执行路径调用，用于生成可观测的 scope 决策结果。
CC 对照：forkedAgent.ts 中 alwaysAllowRules union + alwaysDenyRules 优先级语义。
当前裁剪范围：v1 仅提供纯函数裁决与 explain，不直接改写 runtime 状态。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .backend import _ALWAYS_DISALLOWED_FOR_SUBAGENT

if TYPE_CHECKING:
    from .registry.config import SubagentConfig


@dataclass(frozen=True)
class EffectiveToolScope:
    """工具范围裁决结果。"""

    candidate_tools: frozenset[str]
    agent_filter_result: frozenset[str]
    skill_auto_approved: frozenset[str]
    policy_denied: frozenset[str]
    final_allowed: frozenset[str]
    auto_approved: frozenset[str]
    explain: list[str]


def _normalize_tool_names(
    names: list[str] | None,
    known: frozenset[str],
) -> tuple[frozenset[str], frozenset[str]]:
    """将输入工具名对齐到 known 的 canonical 名称，返回 (matched, unknown)。"""
    if not names:
        return frozenset(), frozenset()

    known_lower = {name.lower(): name for name in known}
    matched: set[str] = set()
    unknown: set[str] = set()
    for name in names:
        if not isinstance(name, str):
            unknown.add(str(name))
            continue
        canonical = known_lower.get(name.strip().lower())
        if canonical:
            matched.add(canonical)
        else:
            unknown.add(name)
    return frozenset(matched), frozenset(unknown)


def resolve_effective_tools(
    *,
    candidate_tools: list,
    agent_config: "SubagentConfig | None",
    skill_allowed_tools: list[str] | None,
    parent_auto_approved: set[str] | frozenset[str] | None,
    global_deny: set[str] | frozenset[str] | None,
) -> EffectiveToolScope:
    """
    统一工具范围裁决入口。

    规则：
    1) Agent filter 收窄（若 agent_config=None 则视为 identity）
    2) Skill allowed-tools 以 union 方式追加到 auto_approved
    3) deny 永远优先，final_allowed/auto_approved 都要剔除 deny
    """
    explain: list[str] = []
    candidate = frozenset(
        name for t in candidate_tools if (name := getattr(t, "name", ""))
    )

    # Step 1: agent filter + always disallowed
    if agent_config is not None and agent_config.tool_filter is not None:
        filtered_tools = agent_config.tool_filter(candidate_tools)
    else:
        filtered_tools = list(candidate_tools)
    filtered_names_raw = frozenset(
        name for t in filtered_tools if (name := getattr(t, "name", ""))
    )
    filtered_names = filtered_names_raw - frozenset(_ALWAYS_DISALLOWED_FOR_SUBAGENT)
    explain.append(f"agent_filter: {len(candidate)} -> {len(filtered_names)} tools")
    removed_by_always_disallowed = filtered_names_raw - filtered_names
    if removed_by_always_disallowed:
        explain.append(
            "agent_filter: removed "
            f"{removed_by_always_disallowed} (always_disallowed_for_subagent)"
        )

    # Step 2: skill union on auto-approved only
    normalized_skill_allowed, unknown_skill_allowed = _normalize_tool_names(
        skill_allowed_tools,
        filtered_names,
    )
    base_approved, _ = _normalize_tool_names(
        list(parent_auto_approved or set()),
        filtered_names,
    )
    raw_parent_approved = frozenset(str(x) for x in (parent_auto_approved or set()))
    dropped_parent_approved = raw_parent_approved - base_approved
    if dropped_parent_approved:
        explain.append(
            "parent_auto_approved: dropped out-of-scope tools "
            f"{dropped_parent_approved}"
        )
    auto_approved = base_approved | normalized_skill_allowed
    if normalized_skill_allowed:
        explain.append(
            f"skill_auto_approved: added {normalized_skill_allowed} (from skill frontmatter)"
        )
    if unknown_skill_allowed:
        explain.append(
            f"skill_auto_approved: unknown tools ignored: {unknown_skill_allowed}"
        )

    # Step 3: deny highest priority
    denied_normalized, _ = _normalize_tool_names(list(global_deny or set()), filtered_names)
    final_allowed = filtered_names - denied_normalized
    final_auto_approved = auto_approved - denied_normalized
    if denied_normalized:
        explain.append(f"policy_denied: removed {denied_normalized} (global deny rule)")

    return EffectiveToolScope(
        candidate_tools=candidate,
        agent_filter_result=filtered_names,
        skill_auto_approved=normalized_skill_allowed,
        policy_denied=denied_normalized,
        final_allowed=final_allowed,
        auto_approved=final_auto_approved,
        explain=explain,
    )

