"""
tools/agent/built_in/agentx_guide.py — agentx-guide 内置类型

职责：定义面向 langchain_agentx 项目的文档与配置指导 subagent。
在整体链路中的位置：builtin_subagent_loader 在 LANGCHAIN_AGENTX_BUILTIN_AGENTX_GUIDE 时调用 register()。
CC 对照：src/tools/AgentTool/built-in/claudeCodeGuideAgent.ts（语义本地化）。
当前裁剪范围：v3 保留 guide 能力，但名称与语义切换为本工程。

典型使用场景：
1) 用户询问本工程能力、目录结构、配置方式、运行/测试命令；
2) 用户询问 `agent_home`、workspace、tool runtime、loop/observability 等约定；
3) 用户需要基于仓库文档给出排障路径或最佳实践建议。
"""

from __future__ import annotations

from ..registry.config import SubagentConfig
from ..registry.registry import SubagentRegistry

_ALLOWED = frozenset({"Read", "Glob", "Grep", "WebFetch", "WebSearch"})

_SYSTEM_PROMPT = """You are the project guide agent for langchain_agentx.

Your goal is to answer "how to use / how to configure / where to find" questions
for this repository with evidence and actionable steps.

Primary sources (in order):
1. Local project docs and rules first (`CLAUDE.md`, `README.md`, `docs/`).
2. Local code and tests as behavior truth source.
3. Web search/fetch only when local docs do not cover the question.

Guidelines:
- Always prioritize repository-local documentation and code reality.
- Cite exact local file paths used for your answer.
- Keep responses concise, practical, and configuration-aware.
- If information is missing, state uncertainty and propose the next best check.
- Do not assume Claude Code official documentation applies unless explicitly asked.
"""


def _guide_tool_filter(all_tools: list) -> list:
    return [t for t in all_tools if getattr(t, "name", "") in _ALLOWED]


AGENTX_GUIDE_AGENT = SubagentConfig(
    name="agentx-guide",
    description=(
        "Guide agent for langchain_agentx usage, configuration, troubleshooting, "
        "and workflow best practices."
    ),
    when_to_use=(
        "Use this agent when the user asks questions about langchain_agentx: features, "
        "configuration, agent_home/workspace conventions, tool runtime, loop/observability, "
        "or how to run/test the project. Answers from local docs and code first."
    ),
    system_prompt_factory=lambda: _SYSTEM_PROMPT,
    tool_filter=_guide_tool_filter,
    tools_description="Read, Glob, Grep, WebFetch, WebSearch",
    default_max_steps=None,
    allow_async=False,
    tags={"guide", "docs", "project-specific"},
)

def register(registry: SubagentRegistry) -> None:
    registry.register(AGENTX_GUIDE_AGENT)
