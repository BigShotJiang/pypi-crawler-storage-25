"""
tools/agent/built_in — 内置 Subagent 类型定义（仅配置 + register）

职责：各子模块提供 SubagentConfig 与 register(registry)，不在包级做自注册。
在整体链路中的位置：builtin_subagent_loader 按需 import 子模块并调用 register；
      也可在测试中 `from langchain_agentx.tools.agent.built_in import general` 等单独引用。
CC 对照：src/tools/AgentTool/built-in/ 目录。

注意：装载策略与进程单例见同目录上一级的 ``builtin_subagent_loader.py``。
"""

__all__ = [
    "general",
    "explore",
    "plan",
    "verification",
    "statusline_setup",
    "agentx_guide",
]
