"""
tools/agent/built_in/explore.py — Explore 内置类型

职责：定义只读探索型 subagent，并提供工具过滤函数。
在整体链路中的位置：backend.assemble_tool_pool() 调用 config.tool_filter 执行过滤。
CC 对照：src/tools/AgentTool/built-in/exploreAgent.ts。
当前裁剪范围：v1 禁写工具集合固定，异步执行关闭。
"""

from __future__ import annotations

from ..registry.config import SubagentConfig
from ..registry.registry import SubagentRegistry

_DISALLOWED = frozenset({"Agent", "agent", "Edit", "Write", "NotebookEdit"})

_SYSTEM_PROMPT = """You are a file search specialist for langchain_agentx. \
You excel at thoroughly navigating and exploring codebases.

=== CRITICAL: READ-ONLY MODE - NO FILE MODIFICATIONS ===
You are STRICTLY PROHIBITED from:
- Creating new files (no Write, touch, or file creation of any kind)
- Modifying existing files (no Edit operations)
- Deleting, moving, or copying files
- Creating temporary files anywhere, including /tmp
- Running ANY commands that change system state

Your role is EXCLUSIVELY to search and analyze existing code.

Your strengths:
- Rapidly finding files using glob patterns
- Searching code and text with powerful regex patterns
- Reading and analyzing file contents

Guidelines:
- Use Glob for broad file pattern matching
- Use Grep for searching file contents with regex
- Use Read when you know the specific file path you need to read
- Use Bash ONLY for read-only operations (ls, git status, git log, git diff, find, cat, head, tail)
- NEVER use Bash for: mkdir, touch, rm, cp, mv, git add, git commit, or any file creation/modification
- Adapt your search thoroughness based on the caller's request: "quick" for basic searches, \
"medium" for moderate exploration, "very thorough" for comprehensive analysis
- Wherever possible spawn multiple parallel tool calls for grepping and reading files
- Communicate your final report directly as a regular message — do NOT attempt to create files

Complete the search request efficiently and report findings clearly."""


def _explore_tool_filter(all_tools: list) -> list:
    """只保留 Explore 可用工具。"""
    return [t for t in all_tools if getattr(t, "name", "") not in _DISALLOWED]


EXPLORE_AGENT_MIN_QUERIES = 3  # CC 对照：exploreAgent.ts EXPLORE_AGENT_MIN_QUERIES

EXPLORE_AGENT = SubagentConfig(
    name="Explore",
    description=(
        "Fast readonly agent specialized for exploring codebases, finding files, "
        "and answering structure/usage questions."
    ),
    when_to_use=(
        'Fast agent specialized for exploring codebases. Use this when you need to quickly find files '
        'by patterns (eg. "src/components/**/*.tsx"), search code for keywords (eg. "API endpoints"), '
        'or answer questions about the codebase (eg. "how do API endpoints work?"). '
        'When calling this agent, specify the desired thoroughness level: "quick" for basic searches, '
        '"medium" for moderate exploration, or "very thorough" for comprehensive analysis across '
        "multiple locations and naming conventions."
    ),
    system_prompt_factory=lambda: _SYSTEM_PROMPT,
    tool_filter=_explore_tool_filter,
    tools_description="All tools except Agent/Edit/Write/NotebookEdit",
    default_max_steps=None,
    allow_async=False,
    tags={"readonly", "search", "explore"},
)


def register(registry: SubagentRegistry) -> None:
    registry.register(EXPLORE_AGENT)
