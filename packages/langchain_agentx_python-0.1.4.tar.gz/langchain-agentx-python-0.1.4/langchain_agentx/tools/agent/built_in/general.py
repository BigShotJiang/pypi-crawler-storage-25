"""
tools/agent/built_in/general.py — general-purpose 内置类型

职责：定义通用 subagent 配置并完成自注册，不承载组合决策。
在整体链路中的位置：builtin_subagent_loader / 测试调用 register() 装入 SubagentRegistry；被 AgentRuntimeTool 使用。
CC 对照：src/tools/AgentTool/built-in/generalPurposeAgent.ts。
当前裁剪范围：v1 全工具集（tool_filter=None），异步允许标记仅保留配置位。
"""

from __future__ import annotations

from ..registry.config import SubagentConfig
from ..registry.registry import SubagentRegistry

_SYSTEM_PROMPT = """You are an agent for langchain_agentx. Given the user's message, \
use available tools to complete the task fully and efficiently. \
When you complete the task, respond with a concise report covering what was done \
and any key findings — the caller will relay this to the user, so it only needs the essentials.

Your strengths:
- Searching for code, configurations, and patterns across large codebases.
- Analyzing multiple files to understand system architecture.
- Investigating complex questions that require exploring many files.
- Performing multi-step research and implementation tasks.

Guidelines:
- For file searches: search broadly when you don't know where something lives. Use Read when you know the specific file path.
- For analysis: start broad and narrow down. Use multiple search strategies if the first doesn't yield results.
- Be thorough: check multiple locations, consider different naming conventions, look for related files.
- NEVER create files unless they're absolutely necessary for achieving your goal. ALWAYS prefer editing an existing file to creating a new one.
- NEVER proactively create documentation files (*.md) or README files unless explicitly requested.
"""

GENERAL_PURPOSE_AGENT = SubagentConfig(
    name="general-purpose",
    description=(
        "General-purpose agent for researching complex questions, searching for code, "
        "and executing multi-step tasks."
    ),
    when_to_use=(
        "General-purpose agent for researching complex questions, searching for code, "
        "and executing multi-step tasks. When you are searching for a keyword or file and "
        "are not confident that you will find the right match in the first few tries use "
        "this agent to perform the search for you."
    ),
    system_prompt_factory=lambda: _SYSTEM_PROMPT,
    tool_filter=None,
    tools_description="All tools",
    default_max_steps=None,
    allow_async=True,
    tags={"general", "multi-step"},
)


def register(registry: SubagentRegistry) -> None:
    """将本内置类型注册到给定 registry（不做全局副作用）。"""
    registry.register(GENERAL_PURPOSE_AGENT)
