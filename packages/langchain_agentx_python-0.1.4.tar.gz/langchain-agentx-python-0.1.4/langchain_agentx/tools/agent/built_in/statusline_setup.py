"""
tools/agent/built_in/statusline_setup.py — statusline-setup 内置类型

职责：定义状态栏配置型 subagent，专门处理 Claude Code `statusLine` 配置迁移与维护。
在整体链路中的位置：builtin_subagent_loader 在 CLI + BUILTIN_STATUSLINE 时调用 register()。
CC 对照：src/tools/AgentTool/built-in/statuslineSetup.ts。
当前裁剪范围：v3 对齐垂直场景职责，限定工具仅 Read/Edit。

典型使用场景：
1) 用户要求“配置/修改 Claude Code 状态栏”；
2) 用户要求“把 shell PS1 迁移到 statusLine.command”；
3) 用户要求显示模型名、当前目录、context 剩余、订阅限额等状态信息。
"""

from __future__ import annotations

from ..registry.config import SubagentConfig
from ..registry.registry import SubagentRegistry

_ALLOWED = frozenset({"Read", "Edit"})

_SYSTEM_PROMPT = """You are a statusline-setup specialist for Claude Code.

Your job is to configure or update the user's Claude Code status line setting.

Core responsibilities:
1. Read user shell config files (prefer: ~/.zshrc, ~/.bashrc, ~/.bash_profile, ~/.profile).
2. If asked to migrate PS1, extract PS1 and convert it to a statusLine command style.
3. Update ~/.claude/settings.json (if it is a symlink, update the target file).
4. For long commands, you may recommend storing command logic in ~/.claude/statusline-command.sh.
5. Summarize what was configured and remind the caller that future status line changes
   should continue using this statusline-setup agent.

Expected output behavior:
- Return a concise configuration summary.
- Include the exact statusLine command/script path that was set.
- Mention any assumptions or missing inputs that block completion.
"""


def _statusline_tool_filter(all_tools: list) -> list:
    return [t for t in all_tools if getattr(t, "name", "") in _ALLOWED]


STATUSLINE_SETUP_AGENT = SubagentConfig(
    name="statusline-setup",
    description=(
        "Specialized subagent for Claude Code statusLine setup/migration "
        "(PS1 -> statusLine.command) and settings update."
    ),
    when_to_use=(
        "Use this agent to configure or update the user's Claude Code status line setting. "
        "Handles PS1 migration to statusLine.command and ~/.claude/settings.json updates."
    ),
    system_prompt_factory=lambda: _SYSTEM_PROMPT,
    tool_filter=_statusline_tool_filter,
    tools_description="Read, Edit",
    default_max_steps=None,
    allow_async=False,
    tags={"cli", "statusline"},
)

def register(registry: SubagentRegistry) -> None:
    registry.register(STATUSLINE_SETUP_AGENT)
