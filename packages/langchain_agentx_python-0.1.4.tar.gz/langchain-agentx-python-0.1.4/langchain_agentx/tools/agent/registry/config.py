"""
tools/agent/registry/config.py — SubagentConfig 数据结构

职责：描述单个 subagent 类型的稳定配置，不承载注册与组合逻辑。
在整体链路中的位置：built_in/*.py 构造配置 → registry/composition/tool 消费。
CC 对照：src/tools/AgentTool/loadAgentsDir.ts 的 AgentDefinition（简化版）。
当前裁剪范围：v1 仅支持内置类型配置与工具过滤策略注入。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


@dataclass
class SubagentConfig:
    """单个 subagent 类型完整描述。"""

    name: str
    description: str
    system_prompt_factory: Callable[[], str]
    tool_filter: Callable[[list], list] | None = None
    tools_description: str = "All tools"
    default_max_steps: int | None = None
    default_model: str | None = None
    allow_async: bool = True
    tags: set[str] = field(default_factory=set)
    when_to_use: str | None = None  # CC 对照：BuiltInAgentDefinition.whenToUse
