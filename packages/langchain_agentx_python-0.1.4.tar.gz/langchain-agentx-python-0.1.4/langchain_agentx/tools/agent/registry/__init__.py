"""
tools/agent/registry — 能力原语注册表

职责：导出 SubagentConfig / SubagentRegistry，供工具层使用。
在整体链路中的位置：built_in/*.py 构造配置 → registry 管理 → tool.py 消费。
CC 对照：src/tools/AgentTool/builtInAgents.ts 的内置类型集合（扩展为可变注册表）。
当前裁剪范围：v1 仅导出能力原语相关类型；SubagentComposition/presets 属于编排层，不在此导出。
"""

from .config import SubagentConfig
from .registry import SubagentRegistry, get_global_registry

__all__ = [
    "SubagentConfig",
    "SubagentRegistry",
    "get_global_registry",
]

