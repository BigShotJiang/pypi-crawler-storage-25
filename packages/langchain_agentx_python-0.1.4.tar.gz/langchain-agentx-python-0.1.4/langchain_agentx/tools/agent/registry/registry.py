"""
tools/agent/registry/registry.py — SubagentRegistry 全局注册表

职责：管理 subagent 类型注册与查询，不承载场景组合决策。
在整体链路中的位置：built_in 模块注册；composition/tool 查询可用类型。
CC 对照：src/tools/AgentTool/builtInAgents.ts 的内置类型集合（扩展为可变注册表）。
当前裁剪范围：v1 提供 register/get/list/filter 基础能力。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .config import SubagentConfig


@dataclass
class SubagentRegistry:
    """subagent 类型注册表。"""

    _registry: dict[str, SubagentConfig] = field(default_factory=dict)

    def register(self, config: SubagentConfig) -> None:
        """注册或覆盖同名 subagent 类型。"""
        self._registry[config.name] = config

    def get(self, name: str) -> SubagentConfig:
        """按名称获取类型配置，不存在时抛 KeyError。"""
        return self._registry[name]

    def list_all(self) -> list[SubagentConfig]:
        """返回所有已注册类型。"""
        return list(self._registry.values())

    def filter_by_tags(self, tags: set[str]) -> list[SubagentConfig]:
        """按标签过滤类型。"""
        if not tags:
            return self.list_all()
        return [cfg for cfg in self._registry.values() if cfg.tags & tags]


_global_registry = SubagentRegistry()


def get_global_registry() -> SubagentRegistry:
    """获取进程级全局注册表。"""
    return _global_registry
