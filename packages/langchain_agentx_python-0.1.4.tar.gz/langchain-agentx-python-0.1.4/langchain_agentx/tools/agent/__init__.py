"""
tools/agent — AgentRuntimeTool 包

AgentRuntimeTool 为多 Agent 委派入口，负责启动子 Agent 执行复杂多步任务。
"""

from .tool import AgentRuntimeTool

__all__ = ["AgentRuntimeTool"]
