"""
tools/skill/loader.py — Skill 加载协作者

职责：
    - SkillFrontmatterParser：解析 SKILL.md frontmatter + body
    - SkillCommandRepository：从 skills 根目录加载并查找技能
    - SkillContentExpander：注入 ``Base directory for this skill:`` 前缀后执行参数展开

链路位置：
    SkillRuntimeTool.invoke()
      -> SkillCommandRepository.find_by_name()
      -> SkillContentExpander.expand()

CC 对照：
    对齐 CC SkillTool 的 command lookup + prompt expansion 思路，
    但实现为本工程 RuntimeTool 的 OOP 协作者，不走 middleware 旁路。
    frontmatter：支持 ``when_to_use`` / ``whenToUse`` 与 ``description`` 的
    单行值及常见块标量（``|`` / ``>-``，见 loadSkillsDir 的 whenToUse 语义）。
    块标量限制：``_read_literal_block`` 以顶格 ``word:`` 作为块结束；块正文内若出现
    顶格 ``key: value`` 行会被误截断（已知限制，复杂 YAML 请用单行或换用完整 YAML 解析）。
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .argument_substitution import parse_argument_names, substitute_arguments
from .models import SkillCommand

# CC loadSkillsDir：when_to_use / description 常为块标量（| / >-）；须在 parser 层取出独立字符串
_BLOCK_TEXT_KEYS = frozenset({"when_to_use", "whenToUse", "description", "argument-hint", "argument_hint"})


def normalize_skill_name(skill_name: str) -> str:
    return skill_name.strip().lstrip("/")


def _normalize_when_to_use_raw(raw: Any) -> str | None:
    """将 frontmatter 中的 when_to_use 规范为单行或多行字符串（CC whenToUse）。"""
    if isinstance(raw, str) and raw.strip():
        return raw.strip()
    if isinstance(raw, list):
        parts = [str(x).strip() for x in raw if str(x).strip()]
        if parts:
            return "\n".join(parts)
    return None


def _is_block_scalar_header(value: str) -> bool:
    """YAML 块标量起始行：空、``|``、``|-``、``|+``、``>``、``>-`` 等（与 CC SKILL 常见写法一致）。"""
    v = value.strip()
    if not v:
        return True
    return v.startswith("|") or v.startswith(">")


class SkillFrontmatterParser:
    _FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?", re.DOTALL)

    def parse(self, text: str) -> tuple[dict[str, Any], str]:
        m = self._FRONTMATTER_RE.match(text)
        if not m:
            return {}, text
        frontmatter_text = m.group(1)
        body = text[m.end():]
        return self._parse_simple_yaml(frontmatter_text), body

    @staticmethod
    def _read_literal_block(lines: list[str], start: int) -> tuple[str, int]:
        """读取 ``key: |`` 后的块，直到下一个顶格 ``word:``（与 CC 常见 SKILL.md 一致）。

        限制：块内不得出现顶格 ``foo: bar`` 示例行，否则会被当作下一个 frontmatter 键而提前结束。
        """
        parts: list[str] = []
        j = start
        while j < len(lines):
            raw = lines[j]
            if re.match(r"^[A-Za-z0-9_-]+:\s*", raw) and not raw[:1].isspace():
                break
            parts.append(raw)
            j += 1
        text = "\n".join(parts)
        return text.strip("\n"), j

    def _parse_simple_yaml(self, frontmatter_text: str) -> dict[str, Any]:
        data: dict[str, Any] = {}
        lines = frontmatter_text.splitlines()
        i = 0
        while i < len(lines):
            stripped = lines[i].strip()
            i += 1
            if not stripped or stripped.startswith("#"):
                continue

            m = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", stripped)
            if not m:
                continue

            key, value = m.group(1), m.group(2).strip()
            if key in _BLOCK_TEXT_KEYS and _is_block_scalar_header(value):
                block, i = self._read_literal_block(lines, i)
                if block.strip():
                    data[key] = block.strip()
                continue

            if value:
                data[key] = value
                continue

            items: list[str] = []
            while i < len(lines):
                nxt = lines[i].strip()
                if not nxt:
                    i += 1
                    continue
                if nxt.startswith("- "):
                    items.append(nxt[2:].strip())
                    i += 1
                    continue
                break
            data[key] = items
        return data


class SkillCommandRepository:
    def __init__(self, skills_root: Path, parser: SkillFrontmatterParser | None = None) -> None:
        self._skills_root = skills_root
        self._parser = parser or SkillFrontmatterParser()

    def list_commands(self) -> list[SkillCommand]:
        if not self._skills_root.exists():
            return []

        commands: list[SkillCommand] = []
        for skill_dir in self._skills_root.iterdir():
            if not skill_dir.is_dir():
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue

            content = skill_md.read_text(encoding="utf-8")
            frontmatter, body = self._parser.parse(content)
            name = str(frontmatter.get("name") or skill_dir.name).strip()
            raw_desc = frontmatter.get("description")
            has_user_desc = isinstance(raw_desc, str) and bool(raw_desc.strip())
            description = raw_desc.strip() if has_user_desc else ""
            raw_wtu = frontmatter.get("when_to_use") or frontmatter.get("whenToUse")
            when_to_use = _normalize_when_to_use_raw(raw_wtu)
            arg_names = parse_argument_names(frontmatter.get("arguments"))
            commands.append(
                SkillCommand(
                    name=name,
                    description=description,
                    content=body.strip(),
                    path=skill_md,
                    source="local",
                    frontmatter=frontmatter,
                    has_user_specified_description=has_user_desc,
                    when_to_use=when_to_use,
                    argument_names=arg_names,
                )
            )

        dedup: dict[str, SkillCommand] = {}
        for cmd in commands:
            dedup.setdefault(normalize_skill_name(cmd.name), cmd)
        return list(dedup.values())

    def find_by_name(self, skill_name: str) -> SkillCommand | None:
        normalized = normalize_skill_name(skill_name)
        for cmd in self.list_commands():
            if normalize_skill_name(cmd.name) == normalized:
                return cmd
        return None


class SkillContentExpander:
    def expand(self, command: SkillCommand, args: str | None) -> str:
        # CC createSkillCommand.getPromptForCommand：先注入 skill 根目录，再 substituteArguments。
        body = command.content
        skill_root = command.path.parent
        try:
            skill_root_s = str(skill_root.resolve())
        except OSError:
            skill_root_s = str(skill_root)
        markdown = f"Base directory for this skill: {skill_root_s}\n\n{body}"
        return substitute_arguments(
            markdown,
            args,
            append_if_no_placeholder=True,
            argument_names=command.argument_names,
        )

