from __future__ import annotations

TOOL_NAME = "skill"
COMMAND_NAME_TAG = "command-name"


def get_prompt() -> str:
    return (
        "Execute a skill within the main conversation.\n\n"
        "When users ask you to perform tasks, check whether any available skill matches.\n"
        "Skills provide specialized capabilities and domain knowledge.\n"
        "If users reference slash-command style requests such as '/commit' or '/review-pr', "
        "treat them as skill invocations.\n\n"
        "How to invoke:\n"
        '- Use this tool with `skill_name` and optional `args`.\n'
        '- Example: `skill_name=\"commit\"`\n'
        '- Example: `skill_name=\"pdf\"`\n'
        '- Example: `skill_name=\"commit\", args=\"-m \'Fix bug\'\"`\n'
        '- Example: `skill_name=\"review-pr\", args=\"123\"`\n'
        '- Example: `skill_name=\"ms-office-suite:pdf\"`\n'
        '- Leading slash is allowed (e.g. `/commit`).\n\n'
        "Important:\n"
        "- Available skills are provided via skill listing reminders/messages in the conversation.\n"
        "- If a matching skill exists, this is a BLOCKING REQUIREMENT: call this tool before "
        "giving any task-specific guidance.\n"
        "- Never mention a skill without calling this tool.\n"
        "- Do not invoke a skill that is already running in the current turn.\n"
        f"- If current turn already contains <{COMMAND_NAME_TAG}>...</{COMMAND_NAME_TAG}>, "
        "the skill is already loaded; follow it directly instead of re-invoking.\n"
        "- Do not use this tool for built-in CLI commands (for example /help, /clear).\n"
    )


DESCRIPTION = get_prompt()

