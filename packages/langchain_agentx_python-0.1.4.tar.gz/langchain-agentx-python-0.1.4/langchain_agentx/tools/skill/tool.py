"""
tools/skill/tool.py — SkillRuntimeTool 主编排器

职责：
    在 RuntimeTool 生命周期内执行 skill：
      normalize_input -> validate_input -> check_permissions -> invoke -> present
    仅负责 orchestration，不承载 frontmatter 解析/展开细节。

链路位置：
    ToolExecutorPipeline.run()
      -> SkillRuntimeTool hooks
      -> ToolResultEnvelope

CC 对照：
    对齐 SkillTool 的 command lookup + args expand + metadata 透传语义，
    但保持本工程 RuntimeTool 契约（标准 ToolMessage 路径）。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.workspace import resolve_agent_workspace_config

from .loader import SkillCommandRepository, SkillContentExpander, normalize_skill_name
from .models import SkillToolInput, SkillToolOutput, _frontmatter_bool
from .policy import SkillConstraintEvaluator
from .prompt import COMMAND_NAME_TAG, DESCRIPTION, TOOL_NAME
from ..agent.scope import resolve_effective_tools
from ...tool_runtime.permission_context import set_pending_auto_approved_tools


class SkillRuntimeTool(RuntimeTool):
    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = SkillToolInput
    output_model = SkillToolOutput

    is_read_only: bool = True
    is_concurrency_safe: bool = True
    never_truncate: bool = False
    max_result_size_chars: int = 60_000

    def __init__(
        self,
        *,
        workspace_root: str,
        agent_home: str = ".langchain_agentx",
        skills_root: str | None = None,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        repository: SkillCommandRepository | None = None,
        expander: SkillContentExpander | None = None,
        constraint_evaluator: SkillConstraintEvaluator | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        workspace_cfg = resolve_agent_workspace_config(
            workspace_root=workspace_root,
            agent_home=agent_home,
        )
        self._workspace_root = workspace_cfg.workspace_root
        self._agent_home = agent_home
        self._skills_root = (
            Path(skills_root).expanduser().resolve()
            if skills_root
            else workspace_cfg.skills_dir
        )
        self._repository = repository or SkillCommandRepository(self._skills_root)
        self._expander = expander or SkillContentExpander()
        self._constraint_evaluator = constraint_evaluator or SkillConstraintEvaluator(self._workspace_root)

    def normalize_input(self, raw: dict[str, Any], ctx: ToolExecutionContext) -> dict[str, Any]:
        data = dict(raw)
        data["skill_name"] = normalize_skill_name(str(data.get("skill_name", "")))
        return data

    def validate_input(self, data: dict[str, Any], ctx: ToolExecutionContext) -> ValidationResult:
        inp = SkillToolInput.model_validate(data)
        if not inp.skill_name:
            return ValidationResult(ok=False, message="skill_name cannot be empty")
        cmd = self._repository.find_by_name(inp.skill_name)
        if cmd is None:
            return ValidationResult(
                ok=False,
                message=f"Unknown skill: {inp.skill_name}",
                code="SKILL_NOT_FOUND",
            )
        if _frontmatter_bool(
            cmd.frontmatter.get("disable-model-invocation")
            or cmd.frontmatter.get("disable_model_invocation")
        ):
            return ValidationResult(
                ok=False,
                message=(
                    f"Skill {inp.skill_name} cannot be used with {self.name} tool "
                    "due to disable-model-invocation"
                ),
                code="SKILL_DISABLE_MODEL_INVOCATION",
            )
        return ValidationResult(ok=True)

    def check_permissions(self, data: dict[str, Any], ctx: ToolExecutionContext) -> AuthorizationDecision:
        # 先走 skill frontmatter 约束，再委托全局 PolicyEngine。
        inp = SkillToolInput.model_validate(data)
        cmd = self._repository.find_by_name(inp.skill_name)
        if cmd is None:
            return AuthorizationDecision(
                behavior="deny",
                message=f"Permission denied: unknown skill {inp.skill_name}",
                policy_id="skill_not_found",
            )

        local = self._constraint_evaluator.evaluate(cmd.frontmatter)
        if local.behavior != "allow":
            return local

        return super().check_permissions(data, ctx)

    def invoke(self, data: dict[str, Any], ctx: ToolExecutionContext) -> SkillToolOutput:
        inp = SkillToolInput.model_validate(data)
        cmd = self._repository.find_by_name(inp.skill_name)
        if cmd is None:
            raise ValueError(f"Unknown skill: {inp.skill_name}")

        content = self._expander.expand(cmd, inp.args)
        frontmatter = cmd.frontmatter
        allowed_tools = frontmatter.get("allowed-tools")
        model_override = frontmatter.get("model")
        constraints_applied = {
            "has_allowed_tools": isinstance(allowed_tools, list) and len(allowed_tools) > 0,
            "has_paths": isinstance(frontmatter.get("paths"), list) and len(frontmatter.get("paths")) > 0,
            "has_model_override": isinstance(model_override, str) and bool(model_override.strip()),
        }
        # Tool scope 计算入口：先做纯计算并透出 explain，后续阶段再接 permission context 写回。
        resolved_scope = resolve_effective_tools(
            candidate_tools=list(getattr(ctx, "available_tools", []) or []),
            agent_config=None,
            skill_allowed_tools=[str(x) for x in allowed_tools] if isinstance(allowed_tools, list) else [],
            parent_auto_approved=None,
            global_deny=None,
        )
        constraints_applied["tool_scope_resolution"] = {
            "auto_approved": sorted(resolved_scope.auto_approved),
            "final_allowed": sorted(resolved_scope.final_allowed),
            "explain": list(resolved_scope.explain),
        }
        set_pending_auto_approved_tools(ctx.session_store, resolved_scope.auto_approved)
        return SkillToolOutput(
            skill_name=cmd.name,
            content=content,
            source=cmd.source,
            skill_path=str(cmd.path),
            command_name_tag=f"<{COMMAND_NAME_TAG}>{cmd.name}</{COMMAND_NAME_TAG}>",
            allowed_tools=[str(x) for x in allowed_tools] if isinstance(allowed_tools, list) else [],
            model_override=str(model_override) if isinstance(model_override, str) else None,
            constraints_applied=constraints_applied,
        )

    def present(self, data: dict[str, Any], result: Any, ctx: ToolExecutionContext) -> ToolResultEnvelope:
        if not isinstance(result, SkillToolOutput):
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary=f"Loaded skill {data.get('skill_name', '')}",
                payload=str(result),
            )

        summary = f"Loaded skill: {result.skill_name}"
        payload = (
            f"{result.command_name_tag or ''}\n"
            f"[skill:{result.skill_name}]\n\n"
            f"{result.content}"
        ).strip()
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload=payload,
            meta={
                "skill_name": result.skill_name,
                "source": result.source,
                "skill_path": result.skill_path,
                "allowed_tools": result.allowed_tools,
                "model_override": result.model_override,
                "constraints_applied": result.constraints_applied,
                "observability": {
                    "schema_version": "v1",
                    "scenario": "skill_tool_scope_resolution",
                    "events": [
                        {
                            "event": "skill_loaded",
                            "skill_name": result.skill_name,
                            "source": result.source,
                        },
                        {
                            "event": "tool_scope_resolved",
                            "auto_approved": (
                                result.constraints_applied.get("tool_scope_resolution", {})
                                .get("auto_approved", [])
                            ),
                            "final_allowed": (
                                result.constraints_applied.get("tool_scope_resolution", {})
                                .get("final_allowed", [])
                            ),
                            "explain": (
                                result.constraints_applied.get("tool_scope_resolution", {})
                                .get("explain", [])
                            ),
                        },
                    ],
                },
            },
        )

