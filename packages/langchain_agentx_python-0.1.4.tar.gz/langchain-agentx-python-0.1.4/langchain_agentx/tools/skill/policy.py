"""
tools/skill/policy.py — Skill frontmatter 约束协作者

职责：
    解析并评估 skill frontmatter 中与执行约束相关的字段，
    当前 v1 支持：
      - allowed-tools
      - paths

链路位置：
    SkillRuntimeTool.check_permissions()
      -> SkillConstraintEvaluator.evaluate()

注意：
    - 本模块不替代全局 PolicyEngine；全局 deny/allow 仍由 RuntimeTool 基类链路兜底。
    - 这里仅做 skill 自身约束判定，返回 AuthorizationDecision。
    - ``paths`` 是否在 workspace 内：用 ``Path.resolve()`` + ``Path.relative_to``，**不用** ``str.startswith``（避免 Windows 大小写/规范化误判）。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.models import AuthorizationDecision


def _path_is_descendant(candidate: Path, ancestor: Path) -> bool:
    """candidate 与 ancestor 均已 resolve；在 ancestor 目录树内（含自身）则 True。"""
    try:
        candidate.relative_to(ancestor)
        return True
    except ValueError:
        return False


class SkillConstraintEvaluator:
    def __init__(self, workspace_root: Path | str) -> None:
        root = Path(workspace_root).expanduser()
        try:
            self._workspace_root = root.resolve()
        except OSError:
            self._workspace_root = root

    def evaluate(self, frontmatter: dict[str, Any]) -> AuthorizationDecision:
        paths = frontmatter.get("paths")
        if isinstance(paths, list):
            ws = self._workspace_root
            for raw in paths:
                text = str(raw).strip()
                if not text:
                    continue
                try:
                    candidate = (ws / text).resolve()
                except OSError:
                    return AuthorizationDecision(
                        behavior="deny",
                        message=(
                            "Permission denied: skill paths constraint could not "
                            f"resolve path entry: {text!r}."
                        ),
                        policy_id="skill_paths_resolve_error",
                    )
                if not _path_is_descendant(candidate, ws):
                    return AuthorizationDecision(
                        behavior="deny",
                        message="Permission denied: skill paths constraint escapes workspace root.",
                        policy_id="skill_paths_outside_workspace",
                    )

        allowed_tools = frontmatter.get("allowed-tools")
        if allowed_tools is not None and not isinstance(allowed_tools, list):
            return AuthorizationDecision(
                behavior="deny",
                message="Permission denied: invalid 'allowed-tools' frontmatter format.",
                policy_id="skill_allowed_tools_invalid",
            )

        return AuthorizationDecision(behavior="allow")

