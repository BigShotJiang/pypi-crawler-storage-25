"""
tools/skill/argument_substitution.py — skill 参数展开（CC argumentSubstitution.ts 对齐子集）

职责：
    ``parse_arguments`` / ``parse_argument_names`` / ``substitute_arguments``，
    支持 ``$ARGUMENTS``、``$ARGUMENTS[n]``、``$n`` 及 frontmatter ``arguments`` 定义的具名 ``$name``。

链路位置：
    ``SkillContentExpander.expand()`` → ``substitute_arguments()``。

CC 对照：
    ``src/utils/argumentSubstitution.ts``；本实现以 ``shlex.split`` 近似 CC 的 shell-quote 解析。
"""

from __future__ import annotations

import re
import shlex
from collections.abc import Sequence
from typing import Any


def parse_arguments(args: str | None) -> list[str]:
    """将参数字符串拆成 token 列表（对齐 CC ``parseArguments``）。"""
    if args is None or not args.strip():
        return []
    try:
        return shlex.split(args, posix=True)
    except ValueError:
        return [p for p in args.split() if p]


def parse_argument_names(argument_names: Any) -> list[str]:
    """解析 frontmatter ``arguments``（对齐 CC ``parseArgumentNames``）。"""

    def _valid(name: str) -> bool:
        return bool(name.strip()) and not name.strip().isdigit()

    if not argument_names:
        return []
    if isinstance(argument_names, list):
        return [str(x).strip() for x in argument_names if _valid(str(x))]
    if isinstance(argument_names, str):
        return [p for p in argument_names.split() if _valid(p)]
    return []


def substitute_arguments(
    content: str,
    args: str | None,
    *,
    append_if_no_placeholder: bool = True,
    argument_names: Sequence[str] | None = None,
) -> str:
    """替换正文中的参数占位符（对齐 CC ``substituteArguments`` 顺序与语义）。"""
    if args is None:
        return content

    names = list(argument_names or [])
    parsed = parse_arguments(args)
    original = content

    for i, name in enumerate(names):
        if not name:
            continue
        pat = re.compile(rf"\${re.escape(name)}(?!\[|\w)")
        rep = parsed[i] if i < len(parsed) else ""
        content = pat.sub(rep, content)

    def _tok_at(parsed_args: list[str], m: re.Match[str]) -> str:
        idx = int(m.group(1))
        return parsed_args[idx] if 0 <= idx < len(parsed_args) else ""

    content = re.sub(r"\$ARGUMENTS\[(\d+)\]", lambda m: _tok_at(parsed, m), content)
    content = re.sub(r"\$(\d+)(?!\w)", lambda m: _tok_at(parsed, m), content)
    content = content.replace("$ARGUMENTS", args)

    if content == original and append_if_no_placeholder and args:
        content = f"{content}\n\nARGUMENTS: {args}"
    return content
