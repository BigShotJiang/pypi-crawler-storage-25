from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


class SkillToolInput(BaseModel):
    skill_name: str = Field(
        ...,
        description="Skill name (leading slash is optional).",
    )
    args: str | None = Field(
        default=None,
        description="Optional arguments passed to skill expansion.",
    )

    @field_validator("skill_name")
    @classmethod
    def _validate_skill_name(cls, value: str) -> str:
        name = value.strip()
        if not name:
            raise ValueError("skill_name cannot be empty")
        return name

    @field_validator("args")
    @classmethod
    def _validate_args_len(cls, value: str | None) -> str | None:
        if value and len(value) > 2000:
            raise ValueError("args too long (max 2000 chars)")
        return value


class SkillToolOutput(BaseModel):
    skill_name: str
    content: str
    source: Literal["local", "mcp"] = "local"
    skill_path: str | None = None
    command_name_tag: str | None = None
    allowed_tools: list[str] = Field(default_factory=list)
    model_override: str | None = None
    constraints_applied: dict[str, Any] = Field(default_factory=dict)


def _frontmatter_bool(value: Any) -> bool:
    if value is True:
        return True
    if isinstance(value, str) and value.strip().lower() in ("true", "1", "yes", "on"):
        return True
    return False


@dataclass(slots=True)
class SkillCommand:
    name: str
    description: str
    content: str
    path: Path
    source: Literal["local", "mcp"] = "local"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    # CC getSlashCommandToolSkills：仅当 frontmatter 显式给出非空 description 时为 True（非正文推导）
    has_user_specified_description: bool = False
    # CC whenToUse / frontmatter when_to_use
    when_to_use: str | None = None
    # CC frontmatter ``arguments`` → parseArgumentNames → $name 占位符
    argument_names: list[str] = field(default_factory=list)

    def visible_in_slash_command_tool_listing(self) -> bool:
        """是否出现在模型可见的 skill listing 中。

        与 CC ``commands/init`` / ``SkillTool`` 侧一致：``disable-model-invocation: true`` 表示
        仅用户侧触发，**不**对模型展示 listing（亦由 ``SkillRuntimeTool.validate_input`` 拦截工具调用）。
        """
        if not (self.name or "").strip():
            return False
        if not (self.has_user_specified_description or bool((self.when_to_use or "").strip())):
            return False

        disable_mi = _frontmatter_bool(
            self.frontmatter.get("disable-model-invocation")
            or self.frontmatter.get("disable_model_invocation")
        )
        if disable_mi:
            return False
        return self.source in ("local", "mcp")

