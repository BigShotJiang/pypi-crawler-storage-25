"""
tools/ripgrep_plugin_exclusions.py — Plugin 缓存孤儿版本的 ripgrep --glob 排除

职责：
    对齐 CC src/utils/plugins/orphanedPluginFilter.ts：在搜索路径与 plugin cache 重叠时，
    生成 `!**/<relativeVersionDir>/**` 列表，避免 Grep/Glob 命中带 `.orphaned_at` 的旧版本目录。

链路位置：
    ToolRuntimeLoader.register_default_tools -> 构造 PluginCacheGlobExclusions
    -> GrepRuntimeTool / GlobRuntimeTool.invoke -> RipgrepBackend._build_args / build_rg_files_args

当前裁剪范围：
    仅基于 workspace 的 `plugin_cache_dir`；不实现 CC 的 main.tsx 预热与 /reload-plugins 命令
    （clear_cache 供后续插件热重载接线）。失败时 best-effort 返回空列表，不阻断搜索。
"""

from __future__ import annotations

import os
import sys
import threading

from langchain_agentx.tools.grep.backend import run_ripgrep_lines
from langchain_agentx.utils.rg_executable import default_rg_executable
from langchain_agentx.utils.subprocess_text import (
    TextSubprocessRunner,
    default_text_subprocess_runner,
)

_ORPHANED_AT = ".orphaned_at"


class PluginCacheGlobExclusions:
    """会话级缓存的 plugin cache `--glob` 排除串（与 CC getGlobExclusionsForPluginCache 语义对齐）。"""

    def __init__(
        self,
        *,
        cache_root: str | None,
        rg_path: str | None = None,
        timeout: int = 20,
        text_runner: TextSubprocessRunner | None = None,
    ) -> None:
        if cache_root:
            self._cache_root = os.path.normpath(os.path.realpath(os.path.expanduser(cache_root)))
        else:
            self._cache_root = None
        self._rg_path = rg_path if rg_path is not None else default_rg_executable()
        self._timeout = int(timeout)
        self._text_runner = text_runner or default_text_subprocess_runner()
        self._cached: list[str] | None = None
        self._lock = threading.Lock()

    def clear_cache(self) -> None:
        """对齐 CC clearPluginCacheExclusions：插件集重载后应调用以重新扫描 marker。"""
        with self._lock:
            self._cached = None

    @staticmethod
    def _normalize_for_compare(path: str) -> str:
        n = os.path.normpath(os.path.realpath(os.path.expanduser(path)))
        if sys.platform == "win32":
            return n.lower()
        return n

    @staticmethod
    def paths_overlap(search_path: str, cache_root: str) -> bool:
        """与 CC orphanedPluginFilter.pathsOverlap 等价（含根路径与前缀关系）。"""
        na = PluginCacheGlobExclusions._normalize_for_compare(search_path)
        nb = PluginCacheGlobExclusions._normalize_for_compare(cache_root)
        sep = os.sep
        return (
            na == nb
            or na == sep
            or nb == sep
            or na.startswith(nb + sep)
            or nb.startswith(na + sep)
        )

    def get_exclusions_for_search(self, search_path: str) -> list[str]:
        """
        若 search_path 与 plugin cache 根无路径重叠，返回 []（与 CC 短路一致）。
        否则返回缓存的排除 glob 列表（首次调用时扫描 `.orphaned_at`）。
        """
        if not self._cache_root:
            return []
        sp = os.path.normpath(os.path.realpath(os.path.expanduser(search_path)))
        if not self.paths_overlap(sp, self._cache_root):
            return []
        with self._lock:
            if self._cached is not None:
                return list(self._cached)
            self._cached = self._compute_exclusions_locked()
            return list(self._cached)

    def _compute_exclusions_locked(self) -> list[str]:
        try:
            if not os.path.isdir(self._cache_root):
                return []
            args = [
                "--files",
                "--hidden",
                "--no-ignore",
                "--max-depth",
                "4",
                "--glob",
                _ORPHANED_AT,
            ]
            lines = run_ripgrep_lines(
                self._rg_path,
                args,
                self._cache_root,
                timeout=self._timeout,
                text_runner=self._text_runner,
                is_retry=False,
            )
            out: list[str] = []
            cache = self._cache_root
            for marker_path in lines:
                mp = marker_path.strip()
                if not mp:
                    continue
                version_dir = os.path.dirname(mp)
                if os.path.isabs(version_dir):
                    try:
                        rel = os.path.relpath(version_dir, cache)
                    except ValueError:
                        continue
                else:
                    rel = version_dir
                posix_rel = rel.replace("\\", "/")
                if not posix_rel or posix_rel == ".":
                    continue
                out.append(f"!**/{posix_rel}/**")
            return out
        except Exception:
            return []
