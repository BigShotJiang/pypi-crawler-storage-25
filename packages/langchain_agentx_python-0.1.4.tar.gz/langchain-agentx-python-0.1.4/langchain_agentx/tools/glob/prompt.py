"""
tools/glob/prompt.py — 工具名与模型可见描述

对应 CC：
    src/tools/GlobTool/prompt.ts。
"""

from __future__ import annotations

TOOL_NAME = "glob"


def get_prompt() -> str:
    return (
        "- Fast file pattern matching tool that works with any codebase size\n"
        '- Supports glob patterns like "**/*.js" or "src/**/*.ts"\n'
        "- Returns matching file paths sorted by modification time\n"
        "- Use this tool when you need to find files by name patterns\n"
        "- When you are doing an open ended search that may require multiple rounds "
        "of globbing and grepping, use the Agent tool instead"
    )


DESCRIPTION = get_prompt()
