"""
tools/glob/pagination.py — 有序路径列表上的 offset/limit 分页

职责：
    在已排序的全量路径列表上执行与 CC `utils/glob.ts` 一致的 slice 与 truncated 判定。

在整体链路中的位置：
    GlobRuntimeTool.invoke() 在 list_files_via_ripgrep 返回全量列表后调用本模块。

当前裁剪范围：
    仅 slice + truncated 布尔；不包含流式截断或磁盘 walk。
"""

from __future__ import annotations


def slice_glob_paths(
    paths: list[str],
    *,
    offset: int,
    limit: int,
) -> tuple[list[str], int, bool]:
    """
    与 CC 一致：``truncated = len(paths) > offset + limit``，
    返回 ``paths[offset : offset + limit]``。
    """
    total = len(paths)
    end = offset + max(1, limit)
    truncated = total > end
    return paths[offset:end], total, truncated
