"""
tools/glob/models.py — GlobToolInput / GlobToolOutput

职责：
    定义 glob 工具面向模型暴露的输入 schema，以及 invoke() 返回的内部输出结构。

对应 CC：
    src/tools/GlobTool/GlobTool.ts 中的 inputSchema / outputSchema；
    offset + limit 分页语义对齐 src/utils/glob.ts（v2-C）。
"""

from __future__ import annotations

from pydantic import BaseModel, Field

DEFAULT_MAX_RESULTS = 100
MAX_MAX_RESULTS = 1_000


class GlobToolInput(BaseModel):
    pattern: str = Field(
        ...,
        description=(
            "The glob pattern to match files against. Semantics follow ripgrep --glob "
            '(same family as the grep tool file filter), e.g. "**/*.py", "src/**/*.ts".'
        ),
    )
    path: str | None = Field(
        default=None,
        description=(
            "The directory to search in. If omitted, the workspace root is used. "
            'Do not pass "null" or "undefined"; simply omit this field.'
        ),
    )
    offset: int = Field(
        default=0,
        ge=0,
        description=(
            "Skip this many matches from the start of the sorted result list "
            "(same semantics as CC globLimits offset; pairs with the tool's max_results limit)."
        ),
    )


class GlobToolOutput(BaseModel):
    """工具内部结果，供 present() 映射为 ToolResultEnvelope。"""

    model_config = {"extra": "forbid"}

    pattern: str
    search_root: str
    filenames: list[str] = Field(default_factory=list)
    num_files: int = 0
    truncated: bool = False
    total_matches: int = 0
    offset: int = 0
    duration_ms: float = 0.0
