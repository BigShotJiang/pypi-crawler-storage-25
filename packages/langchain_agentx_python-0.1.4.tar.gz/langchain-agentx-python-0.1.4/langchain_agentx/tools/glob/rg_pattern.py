"""
tools/glob/rg_pattern.py — 绝对 glob pattern 拆分为搜索根 + 相对 rg --glob

职责：移植 CC src/utils/glob.ts 的 extractGlobBaseDirectory，供 Glob 与 rg --glob 对齐。
链路：GlobRuntimeTool.invoke -> extract_glob_base_directory。

裁剪：仅服务于本工具路径语义；不含 CC 的 getPlatform 以外的逻辑。
"""

from __future__ import annotations

import os
import re
import sys


def extract_glob_base_directory(pattern: str) -> tuple[str, str]:
    """
    返回 (base_dir, relative_pattern)。
    ripgrep 的 --glob 在作为「目录扫描」参数链中需配合「相对 pattern」使用，与 CC 一致。
    """
    sep = os.sep
    glob_chars = re.compile(r"[*?[{]")
    match = glob_chars.search(pattern)
    if not match:
        d = os.path.dirname(pattern)
        f = os.path.basename(pattern)
        return (d, f)

    static_prefix = pattern[: match.start()]
    last_sep = max(static_prefix.rfind("/"), static_prefix.rfind("\\"))
    if last_sep < 0:
        return ("", pattern)

    base_dir = static_prefix[:last_sep]
    relative_pattern = pattern[last_sep + 1 :]

    if base_dir == "" and last_sep == 0:
        base_dir = "/"

    if sys.platform == "win32" and len(base_dir) == 2 and base_dir[1] == ":" and base_dir[0].isalpha():
        base_dir = base_dir + sep

    return (base_dir, relative_pattern)
