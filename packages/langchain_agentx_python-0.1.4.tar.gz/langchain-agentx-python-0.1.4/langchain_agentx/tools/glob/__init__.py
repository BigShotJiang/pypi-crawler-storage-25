"""
tools/glob — GlobRuntimeTool 包

GlobRuntimeTool 是工具体系 P2 只读搜索工具，负责按文件名模式匹配路径。
"""

from .tool import GlobRuntimeTool

__all__ = ["GlobRuntimeTool"]
