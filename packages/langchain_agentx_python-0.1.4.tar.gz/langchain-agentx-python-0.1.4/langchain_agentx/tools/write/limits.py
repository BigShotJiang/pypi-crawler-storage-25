"""
tools/write/limits.py — WriteRuntimeTool 上限配置

职责：
    集中管理写入内容大小等常量；支持环境变量覆盖（与 tools/read/limits.py 风格一致）。

链路位置：
    validate_input（Phase 2+）与 prompt.get_prompt() 引用。

当前裁剪范围：
    仅内容字节上限；不做磁盘配额 / 整仓大小清理。
"""

from __future__ import annotations

import os

# 单次写入内容上限（UTF-8 字节），与 validate_input 中 len(content.encode("utf-8")) 对照
DEFAULT_MAX_FILE_SIZE_BYTES = int(
    os.getenv("WRITE_TOOL_MAX_FILE_SIZE_BYTES", str(256 * 1024))
)
"""默认 256KB，与 read 侧默认 max_size_bytes 量级对齐；可通过环境变量调优。"""


def get_write_limits() -> dict[str, int]:
    """返回当前有效写入限制（用于校验与 prompt 展示）。"""
    return {
        "max_file_size": DEFAULT_MAX_FILE_SIZE_BYTES,
    }
