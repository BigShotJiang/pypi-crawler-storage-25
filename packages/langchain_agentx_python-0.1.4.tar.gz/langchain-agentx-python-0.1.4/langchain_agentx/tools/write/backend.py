"""
tools/write/backend.py — WriteFileBackend

职责：
    创建父目录；按 UTF-8 + LF 写入文件；区分 create/update 并返回旧内容。

链路位置：
    WriteRuntimeTool.invoke() → WriteFileBackend.write_file()

当前裁剪范围：
    若路径已存在且为**目录**（或非常规文件），拒绝写入并抛错。
    若已判定为 update 但读原文件失败（`UnicodeDecodeError` / `OSError`），**向上抛出**，不降级为 create。
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal


class WriteFileBackend:
    """文件写入后端。"""

    def write_file(
        self,
        *,
        file_path: str,
        content: str,
        encoding: str = "utf-8",
        newline: str = "\n",
    ) -> tuple[Literal["create", "update"], str | None]:
        """
        写入文件并返回 ``(file_type, old_content)``。

        - **create**：路径不存在 → 写入后 ``file_type='create'``，``old_content=None``。
        - **update**：路径存在且为普通文件 → 先 ``read_text`` 得 ``old_content``，再覆盖写入，
          ``file_type='update'``。

        Raises:
            IsADirectoryError: 路径存在且不是常规文件（如目录）。
            UnicodeDecodeError: 覆盖写时原文件非 UTF-8。
            OSError: 读/写过程中其它 OS 级失败。
        """
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.exists():
            if not path.is_file():
                raise IsADirectoryError(
                    f"Path exists and is not a regular file: {file_path}"
                )
            try:
                old_content = path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                raise
            except OSError:
                raise
            file_type: Literal["create", "update"] = "update"
        else:
            old_content = None
            file_type = "create"

        with open(
            path,
            "w",
            encoding=encoding,
            newline=newline,
        ) as handle:
            handle.write(content)

        if file_type == "create":
            return "create", None
        return "update", old_content
