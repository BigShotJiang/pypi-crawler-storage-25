"""
tools/write/tool.py — WriteRuntimeTool

职责：
    RuntimeTool 生命周期编排：normalize → validate → permissions → invoke → present。

链路位置：
    ToolRuntimeLoader.register_default_tools；create_loop_agent(..., loader=)。

当前裁剪范围：
    v1 不做 staleness、必须先 Read、UNC 短路（见 write-tool-migration.md）。
    present() 已按 §3.4.5：create 带全量 content payload；update 的 payload 为空串省 token。
    权限：委托 PolicyEngine；``deny``/``ask`` 由 ``ToolExecutorPipeline`` 根据返回的
    ``AuthorizationDecision`` 短路（本仓库不与设计文档旧稿的 ``PermissionDeniedError`` 抛错路径对齐）。
"""

from __future__ import annotations

from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.utils.path_user_input import UserPathInputNormalizer

from .backend import WriteFileBackend
from .models import WriteToolInput, WriteToolOutput
from .prompt import DESCRIPTION, TOOL_NAME
from .validator import WritePathValidator


class WriteRuntimeTool(RuntimeTool):
    """写入本地文件（创建或整文件覆盖）。对应 CC FileWriteTool。"""

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = WriteToolInput
    output_model = WriteToolOutput

    is_read_only: bool = False
    is_destructive: bool = True
    is_concurrency_safe: bool = False
    dedupe_identical_calls: bool = False

    def __init__(
        self,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        backend: WriteFileBackend | None = None,
        path_normalizer: UserPathInputNormalizer | None = None,
        path_validator: WritePathValidator | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._backend = backend or WriteFileBackend()
        self._path_normalizer = path_normalizer or UserPathInputNormalizer()
        self._path_validator = path_validator or WritePathValidator()

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        """路径展开为绝对路径（与 Read 一致，使用 expand_path）。"""
        raw = dict(raw)
        path = raw.get("file_path", "")
        if isinstance(path, str) and path:
            raw["file_path"] = self._path_normalizer.normalize_and_expand(
                path, base_dir=ctx.cwd
            )
        return raw

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        """语义校验：设计 §3.4.2。"""
        _ = ctx
        return self._path_validator.validate(data)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """
        委托注入的 PolicyEngine：从 ``input_data['file_path']`` 取路径，
        ``ctx.tool_flags`` 中 ``is_read_only=False`` 时走 ``write_roots`` / 内置 deny / ask_globs。
        """
        return super().check_permissions(data, ctx)

    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> Any:
        """写入磁盘并返回 WriteToolOutput。"""
        _ = ctx
        inp = WriteToolInput.model_validate(data)
        file_type, old_content = self._backend.write_file(
            file_path=inp.file_path,
            content=inp.content,
        )
        return WriteToolOutput(
            type=file_type,
            file_path=inp.file_path,
            content=inp.content,
            original_file=old_content,
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        """构造 ToolResultEnvelope（write-tool-migration §3.4.5）。"""
        _ = data, ctx
        if not isinstance(result, WriteToolOutput):
            return super().present(data, result, ctx)

        if result.type == "create":
            summary = f"File created successfully at: {result.file_path}"
            payload: str | None = result.content
        else:
            summary = f"The file {result.file_path} has been updated successfully."
            payload = ""

        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload=payload,
            meta={"file_path": result.file_path, "type": result.type},
        )
