"""
tools/write/validator.py — WritePathValidator

职责：
    路径与内容语义校验（设计 write-tool-migration §3.4.2）；无 PolicyEngine。

链路位置：
    WriteRuntimeTool.validate_input() → ``WritePathValidator.validate``

当前裁剪范围：
    v1 不做 UNC 短路、staleness、必须先 Read。
"""

from __future__ import annotations

import os
from typing import Any

from langchain_agentx.tool_runtime.models import ValidationResult

from .limits import get_write_limits
from .models import WriteToolInput


class WritePathValidator:
    """Write 工具输入校验（与 CC validateInput 核心项对齐）。"""

    def validate(self, data: dict[str, Any]) -> ValidationResult:
        """``data`` 为已通过 schema 的 dict；仍做语义与绝对路径等检查。"""
        try:
            inp = WriteToolInput.model_validate(data)
        except Exception as exc:  # pydantic ValidationError 等
            return ValidationResult(ok=False, message=str(exc))

        if not isinstance(inp.content, str):
            return ValidationResult(ok=False, message="content must be a string")

        if not inp.content:
            return ValidationResult(ok=False, message="content cannot be empty")

        fp = inp.file_path
        if not fp or not str(fp).strip():
            return ValidationResult(ok=False, message="file_path cannot be empty")

        if not os.path.isabs(fp):
            return ValidationResult(ok=False, message="file_path must be an absolute path")

        limits = get_write_limits()
        content_size = len(inp.content.encode("utf-8"))
        max_b = limits["max_file_size"]
        if content_size > max_b:
            return ValidationResult(
                ok=False,
                message=(
                    f"Content too large ({content_size} bytes, max {max_b} bytes)"
                ),
            )

        return ValidationResult(ok=True)
