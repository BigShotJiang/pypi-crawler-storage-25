"""
tools/write/models.py — WriteRuntimeTool 输入 / 输出模型

职责：
    定义 Write 工具 Pydantic 模型；无 I/O；与 write-tool-migration.md §2.3、§3.4.4 对齐。

链路位置：
    WriteRuntimeTool.input_model / invoke 返回值类型由本模块提供。

当前裁剪范围：
    v1 无 structuredPatch、gitDiff；`original_file` 仅表示写前全文（若可读）。
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class WriteToolInput(BaseModel):
    """
    WriteRuntimeTool 输入（对应 CC FileWriteToolInput）。

    file_path 须为绝对路径（语义校验在 validate_input；normalize 阶段先 expand）。
    """

    file_path: str = Field(
        ...,
        description="Absolute path of the file to create or overwrite.",
    )
    content: str = Field(
        ...,
        description="Full text content to write (UTF-8, LF newlines enforced at write time).",
    )


class WriteToolOutput(BaseModel):
    """Write 工具执行结果（v1 无 diff / git 字段）。"""

    type: Literal["create", "update"] = Field(
        ...,
        description="Whether the path was created or an existing file was overwritten.",
    )
    file_path: str = Field(..., description="Absolute path written.")
    content: str = Field(..., description="Content that was written.")
    original_file: str | None = Field(
        None,
        description="Previous file contents before overwrite; null when creating new file.",
    )
