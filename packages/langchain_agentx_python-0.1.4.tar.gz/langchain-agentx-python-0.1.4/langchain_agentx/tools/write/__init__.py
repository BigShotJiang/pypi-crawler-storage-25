"""
tools/write — WriteRuntimeTool 包

Phase 1：骨架与注册；invoke 于 Phase 2 落地。
"""

from .tool import WriteRuntimeTool

__all__ = ["WriteRuntimeTool"]
