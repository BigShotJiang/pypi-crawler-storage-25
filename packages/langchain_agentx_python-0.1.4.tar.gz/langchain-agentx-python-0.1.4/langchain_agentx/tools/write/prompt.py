"""
tools/write/prompt.py — WriteRuntimeTool 工具名与描述

职责：
    工具名、description、完整 Usage 文本（CC prompt.ts 迁移）。

链路位置：
    WriteRuntimeTool.name / description；bind_tools 与文档生成。

当前裁剪范围：
    不嵌入动态 FILE_READ_TOOL_NAME；硬编码 “Read tool”（设计 §3.5）。
    与 CC `getWriteToolDescription` 的差异：增补绝对路径与 ``max_file_size`` 行（工程约束）。
"""

from __future__ import annotations

TOOL_NAME = "write"
"""面向模型暴露的工具名（snake_case，设计 §3.5）。"""

DESCRIPTION = "Write a file to the local filesystem."
"""简短描述（bind_tools 列表）。"""


def get_prompt() -> str:
    """完整使用说明；数值与 limits.get_write_limits() 一致。"""
    from .limits import get_write_limits

    limits = get_write_limits()
    max_kb = limits["max_file_size"] // 1024
    return f"""Writes a file to the local filesystem.

Usage:
- file_path must be an absolute path
- This tool will overwrite the existing file if there is one at the provided path
- If this is an existing file, you MUST use the Read tool first to read the file's contents
- Prefer the Edit tool for modifying existing files — it only sends the diff
- Only use this tool to create new files or for complete rewrites
- Files larger than {max_kb}KB will return an error
- NEVER create documentation files (*.md) or README files unless explicitly requested
- Only use emojis if the user explicitly requests it. Avoid writing emojis to files unless asked.
"""
