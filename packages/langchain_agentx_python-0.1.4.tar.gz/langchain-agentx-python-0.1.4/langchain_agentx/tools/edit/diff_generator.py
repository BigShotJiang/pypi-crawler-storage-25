"""
tools/edit/diff_generator.py — DiffGenerator

职责：
    使用 ``difflib.unified_diff`` 生成行级 unified diff；超限时 UTF-8 截断并追加说明
    （edit-runtime-tool-v2 §0；与 Phase 1 ``build_unified_diff`` 语义一致）。

链路位置：
    ``EditRuntimeTool.invoke``（经 ``DiffGenerator.generate`` 或 ``backend.build_unified_diff`` 薄封装）。

当前裁剪范围：
    仅 unified 文本；无 HTML/context；默认上限 1024 字节（UTF-8）。
"""

from __future__ import annotations

import difflib


class DiffGenerator:
    """行级 unified diff 生成；超大时截断，避免与「无 diff」混淆。"""

    DEFAULT_MAX_BYTES: int = 1024

    def __init__(self, *, max_bytes: int | None = None) -> None:
        self._max_bytes = int(max_bytes if max_bytes is not None else self.DEFAULT_MAX_BYTES)

    def generate(
        self,
        original: str,
        new_content: str,
        *,
        label: str = "file",
    ) -> str:
        """返回 diff 文本；超过 ``max_bytes``（UTF-8）时截断并追加 ``[diff truncated, …]``。"""
        a = original.splitlines(keepends=True)
        b = new_content.splitlines(keepends=True)
        lines = list(
            difflib.unified_diff(
                a,
                b,
                fromfile=f"a/{label}",
                tofile=f"b/{label}",
            )
        )
        diff_text = "".join(lines)
        raw = diff_text.encode("utf-8")
        if len(raw) <= self._max_bytes:
            return diff_text
        trunc = int(self._max_bytes * 0.9)
        prefix = raw[:trunc].decode("utf-8", errors="replace")
        total_kb = len(raw) / 1024.0
        return prefix + f"\n... [diff truncated, {total_kb:.1f}KB total]\n"
