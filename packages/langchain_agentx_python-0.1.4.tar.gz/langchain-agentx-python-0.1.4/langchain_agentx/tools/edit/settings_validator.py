"""
tools/edit/settings_validator.py — Settings 类 JSON 路径识别与编辑后校验

职责：
    识别设计列出的 ``settings.json`` 路径；对模拟替换后的 ``new_content`` 做 ``json.loads``
    与可选顶层必需字段检查（edit-runtime-tool-v3 Phase 3；设计 §2.1 功能 2）。

链路位置：
    Phase 4 起由 ``EditStringValidator.validate`` 调用 ``validate_edit``；本 Phase 仅类 + 单测。

当前裁剪范围：
    v3 MVP：类属性 ``REQUIRED_FIELDS`` 为空，默认不校验必需字段；可通过构造参数注入非空映射供测试或后续扩展。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import ClassVar

from langchain_agentx.tool_runtime.models import ValidationResult


class SettingsValidator:
    """针对已知 Settings 路径的 JSON 校验（编辑后内容）。"""

    #: v3 MVP：不检查必需字段；非空时键为 ``settings.json``（文件名），值为顶层键名列表。
    REQUIRED_FIELDS: ClassVar[dict[str, list[str]]] = {}

    def __init__(
        self,
        *,
        required_fields: dict[str, list[str]] | None = None,
    ) -> None:
        self._required_fields = (
            required_fields if required_fields is not None else dict(self.REQUIRED_FIELDS)
        )

    def is_settings_file(self, file_path: str) -> bool:
        """
        是否视为 Settings 目标文件（方案 A：``Path.name`` + 父路径片段）。

        命中规则：
        - 文件名必须为 ``settings.json``；
        - 路径（POSIX 形式）含 ``/.vscode/``、``/.cursor/``、``/.claude/`` 之一；或
        - 同名文件位于非上述目录名父级下的 ``settings.json``（含仓库根 ``.../repo/settings.json``）。

        普通 JSON（如 ``config.json``）不因文件名匹配。
        """
        try:
            path = Path(file_path)
        except (OSError, TypeError):
            return False

        if path.name != "settings.json":
            return False

        posix = path.as_posix()
        special_parents = (".vscode", ".cursor", ".claude")
        if (
            "/.vscode/" in posix
            or "/.cursor/" in posix
            or "/.claude/" in posix
            or path.parent.name in special_parents
        ):
            return True

        # 仓库根等：.../repo/settings.json（父目录名不是上述专用目录）
        return path.parent.name not in special_parents

    def validate_edit(
        self,
        file_path: str,
        _original_content: str,
        new_content: str,
    ) -> ValidationResult:
        """
        若 ``file_path`` 非 Settings 路径，直接通过。

        否则：``new_content`` 须为合法 JSON；若配置了必需字段，则 ``new_content`` 解析为 object 时检查顶层键。
        ``original_content`` 解析失败不单独报错（允许用户从不合法 JSON 修复为合法）。
        """
        if not self.is_settings_file(file_path):
            return ValidationResult(ok=True)

        try:
            new_json = json.loads(new_content)
        except json.JSONDecodeError as exc:
            return ValidationResult(
                ok=False,
                message=f"Invalid JSON in {Path(file_path).name}: {exc.msg}",
            )

        filename = Path(file_path).name
        required = self._required_fields.get(filename, [])
        if required and not isinstance(new_json, dict):
            return ValidationResult(
                ok=False,
                message=f"Settings file {filename} must be a JSON object when required fields are configured.",
            )

        if isinstance(new_json, dict):
            for field in required:
                if field not in new_json:
                    return ValidationResult(
                        ok=False,
                        message=(
                            f"Required field '{field}' is missing after edit in {filename}. "
                            "Include it in new content or adjust your edit."
                        ),
                    )

        return ValidationResult(ok=True)
