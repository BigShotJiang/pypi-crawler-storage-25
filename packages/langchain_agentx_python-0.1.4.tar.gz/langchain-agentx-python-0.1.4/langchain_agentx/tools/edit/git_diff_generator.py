"""
tools/edit/git_diff_generator.py — GitDiffGenerator

职责：
    在 Git 工作树中对给定文件运行 ``git diff``（相对 HEAD），供 Edit v3 可选展示；
    失败或非仓库时返回 ``None``，由上层回退 unified diff（edit-tool-migration-v3 §2.1）。

链路位置：
    Phase 2 起由 ``EditRuntimeTool.invoke`` 在 ``include_diff`` 时调用；Phase 1 仅类 + 单测。

当前裁剪范围：
    仅 ``git diff --no-color <path>``；无 ``git apply``；失败不抛异常（返回 ``None``）。
"""

from __future__ import annotations

from pathlib import Path

from langchain_agentx.utils.subprocess_text import TextSubprocessRunner, default_text_subprocess_runner


class GitDiffGenerator:
    """检测 Git 仓库并生成 ``git diff`` 文本（工作区 vs HEAD）。"""

    def __init__(
        self,
        *,
        git_path: str = "git",
        subprocess_runner: TextSubprocessRunner | None = None,
    ) -> None:
        self._git_path = git_path
        self._run = (subprocess_runner or default_text_subprocess_runner()).run

    def is_in_git_repo(self, file_path: str) -> bool:
        """若路径所在目录链上存在 ``.git``（目录或 worktree 的 ``gitdir`` 文件）则视为在仓库内。"""
        try:
            path = Path(file_path).resolve()
        except OSError:
            return False

        if not path.exists():
            return False

        for parent in [path, *path.parents]:
            if (parent / ".git").exists():
                return True
        return False

    def generate_git_diff(self, file_path: str) -> str | None:
        """
        生成 ``git diff --no-color`` 输出（工作区相对 HEAD）。

        语义注意：输出可能包含该文件在编辑前已有的未提交改动，不仅限于单次 Edit（设计 §0）。

        Returns:
            非空 diff 文本，或 ``None``（非仓库、git 失败、无输出）。
        """
        if not self.is_in_git_repo(file_path):
            return None

        try:
            path = Path(file_path).resolve()
        except OSError:
            return None

        cwd = str(path.parent)
        try:
            top = self._run(
                [self._git_path, "rev-parse", "--show-toplevel"],
                cwd=cwd,
                capture_output=True,
                timeout=30,
            )
        except Exception:
            return None

        if top.returncode != 0 or not (top.stdout or "").strip():
            return None

        git_root = top.stdout.strip()

        try:
            diff = self._run(
                [
                    self._git_path,
                    "diff",
                    "--no-color",
                    str(path),
                ],
                cwd=git_root,
                capture_output=True,
                timeout=60,
            )
        except Exception:
            return None

        if diff.returncode != 0:
            return None

        out = diff.stdout or ""
        if not out.strip():
            return None
        return out
