"""
tools/edit/batch_tool.py — BatchEditRuntimeTool

职责：
    单文件多段替换：内存顺序应用、**一次写回**；失败则不落盘（edit-tool-migration-v2 §2.1）。
    invoke 内对每步 ``current_content`` 做引号解析、存在性、``replace_all=false`` 唯一性。

链路位置：
    ``ToolRuntimeLoader.register_default_tools``；与 ``EditRuntimeTool`` 共用 staleness / must-read 语义。

当前裁剪范围：
    无 LSP；``combined_diff`` 为整文件前后 unified diff；逐条 ``EditToolOutput.diff`` 恒为 None。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.errors import ToolRuntimeError
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.utils.path_user_input import UserPathInputNormalizer

from .backend import apply_edit_to_content
from .diff_generator import DiffGenerator
from .limits import get_edit_limits
from .models import BatchEditInput, BatchEditOutput, EditToolOutput
from .prompt import BATCH_DESCRIPTION, BATCH_TOOL_NAME
from .quote_normalizer import QuoteNormalizer
from .staleness import StalenessChecker
from .validator import BatchEditValidator


def _snapshot_file_for_last_read(file_path: str) -> str | None:
    max_b = get_edit_limits()["max_file_size"]
    try:
        raw = Path(file_path).read_bytes()
    except OSError:
        return None
    if len(raw) > max_b:
        return f"<large file: {len(raw) // 1024}KB>"
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return "<non-utf8 binary>"


class BatchEditRuntimeTool(RuntimeTool):
    """同一文件上原子批量字符串替换。"""

    name: str = BATCH_TOOL_NAME
    description: str = BATCH_DESCRIPTION
    input_model = BatchEditInput
    output_model = BatchEditOutput

    is_read_only: bool = False
    is_destructive: bool = True
    is_concurrency_safe: bool = False
    dedupe_identical_calls: bool = False

    def __init__(
        self,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        path_normalizer: UserPathInputNormalizer | None = None,
        batch_validator: BatchEditValidator | None = None,
        staleness_checker: StalenessChecker | None = None,
        quote_normalizer: QuoteNormalizer | None = None,
        diff_generator: DiffGenerator | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._path_normalizer = path_normalizer or UserPathInputNormalizer()
        self._staleness_checker = staleness_checker or (
            StalenessChecker(state_bridge) if state_bridge is not None else None
        )
        self._batch_validator = batch_validator or BatchEditValidator(
            state_bridge=state_bridge,
            staleness_checker=self._staleness_checker,
        )
        self._quote_normalizer = quote_normalizer or QuoteNormalizer()
        self._diff_generator = diff_generator or DiffGenerator()

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        raw = dict(raw)
        path = raw.get("file_path", "")
        if isinstance(path, str) and path:
            raw["file_path"] = self._path_normalizer.normalize_and_expand(
                path, base_dir=ctx.cwd
            )
        return raw

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        return self._batch_validator.validate(data, ctx)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        decision = super().check_permissions(data, ctx)
        if decision.behavior not in ("allow", "deny", "ask"):
            return AuthorizationDecision(
                behavior="deny",
                policy_id="fallback",
                message=f"Unknown authorization behavior: {decision.behavior}",
            )
        return decision

    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> BatchEditOutput:
        inp = BatchEditInput.model_validate(data)
        if self._staleness_checker is None:
            raise ToolRuntimeError(
                "BatchEditRuntimeTool requires ToolStateBridge for staleness.",
                code="MISSING_STATE_BRIDGE",
            )
        sr = self._staleness_checker.check(inp.file_path, ctx)
        if not sr.ok:
            raise ToolRuntimeError(
                sr.message or "File is stale or modified since read.",
                code="STALE_FILE",
            )

        try:
            original_content = Path(inp.file_path).read_text(encoding="utf-8")
        except OSError as exc:
            raise ToolRuntimeError(
                f"Failed to read file: {exc}",
                code="FILE_READ_ERROR",
            ) from exc

        current = original_content
        results: list[EditToolOutput] = []

        for edit_op in inp.edits:
            actual_old = self._quote_normalizer.find_actual_old_string_in_text(
                current, edit_op.old_string
            )
            if actual_old is None:
                raise ToolRuntimeError(
                    f"old_string not found in file (after quote normalization): "
                    f"{edit_op.old_string[:50]!r}…",
                    code="STRING_NOT_FOUND",
                )

            if not edit_op.replace_all:
                n_matches = current.count(actual_old)
                if n_matches > 1:
                    raise ToolRuntimeError(
                        f"Found {n_matches} matches for old_string, but replace_all is false. "
                        "Set replace_all=true or use a longer old_string that matches once.",
                        code="NOT_UNIQUE",
                    )

            new_content, count = apply_edit_to_content(
                current,
                actual_old,
                edit_op.new_string,
                edit_op.replace_all,
            )
            if count == 0:
                raise ToolRuntimeError(
                    f"Replace produced no matches for: {edit_op.old_string[:50]!r}…",
                    code="STRING_NOT_FOUND",
                )

            results.append(
                EditToolOutput(
                    file_path=inp.file_path,
                    old_string=actual_old,
                    new_string=edit_op.new_string,
                    replaced_count=count,
                    original_file=None,
                    diff=None,
                )
            )
            current = new_content

        if current != original_content:
            Path(inp.file_path).write_text(current, encoding="utf-8", newline="\n")

        total_replaced = sum(r.replaced_count for r in results)
        combined_diff: str | None = None
        if inp.include_diff and total_replaced > 0:
            combined_diff = self._diff_generator.generate(
                original_content,
                current,
                label=Path(inp.file_path).name,
            )

        return BatchEditOutput(
            file_path=inp.file_path,
            total_replaced=total_replaced,
            results=results,
            combined_diff=combined_diff,
        )

    def after_invoke(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> None:
        if self._state_bridge is None:
            return
        if not isinstance(result, BatchEditOutput):
            return
        inp = BatchEditInput.model_validate(data)
        try:
            mtime_ms = int(os.path.getmtime(inp.file_path) * 1000)
        except OSError:
            mtime_ms = 0
        snap = _snapshot_file_for_last_read(inp.file_path)
        self._state_bridge.set_last_read(
            ctx,
            inp.file_path,
            offset=0,
            limit=None,
            mtime_ms=mtime_ms,
            content=snap,
            line_start=None,
            line_end=None,
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        _ = data, ctx
        if not isinstance(result, BatchEditOutput):
            return super().present(data, result, ctx)
        n = result.total_replaced
        summary = (
            f"Applied {len(result.results)} edit(s), {n} replacement(s) in {result.file_path}"
        )
        meta: dict[str, Any] = {
            "file_path": result.file_path,
            "total_replaced": n,
            "edit_count": len(result.results),
            "edits": [
                {
                    "index": i,
                    "old_string_preview": r.old_string[:50],
                    "new_string_preview": r.new_string[:50],
                    "replaced_count": r.replaced_count,
                }
                for i, r in enumerate(result.results)
            ],
        }
        if result.combined_diff is not None:
            meta["combined_diff"] = result.combined_diff
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload=str(n),
            meta=meta,
        )
