"""
tools/edit/limits.py — EditRuntimeTool 上限配置

职责：
    与 Read 对齐的 stat 前文件大小上限（256KB）；供 Phase 3 validate 使用。

链路位置：
    EditStringValidator、prompt.get_prompt() 数值说明。

当前裁剪范围：
    max_file_size；v2 Phase 3：max_batch_edits（单次 ``batch_edit`` 条数上限）。
"""

from __future__ import annotations

import os

DEFAULT_MAX_FILE_SIZE_BYTES = int(
    os.getenv("EDIT_TOOL_MAX_FILE_SIZE_BYTES", str(256 * 1024))
)
"""与 Read 一致：整文件编辑前 stat 拒绝过大文件（edit-tool-migration §1.4）。"""

DEFAULT_MAX_BATCH_EDITS = int(os.getenv("EDIT_TOOL_MAX_BATCH_EDITS", "64"))
"""单次 ``batch_edit`` 允许的 ``edits`` 条数上限（edit-tool-migration-v2 §3）。"""


def get_edit_limits() -> dict[str, int]:
    return {
        "max_file_size": DEFAULT_MAX_FILE_SIZE_BYTES,
        "max_batch_edits": DEFAULT_MAX_BATCH_EDITS,
    }
