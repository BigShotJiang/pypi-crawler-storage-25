"""
tools/edit/models.py — EditRuntimeTool 输入 / 输出模型

职责：
    Pydantic 契约；对应 CC FileEditTool types.ts 与 edit-tool-migration §2.3、§3.4.4。

链路位置：
    EditRuntimeTool.input_model / output_model；validate_input / invoke 返回值。

当前裁剪范围：
    v2：可选 ``include_diff`` / 输出 ``diff``（unified）。
    v3：``EditToolOutput.git_diff``；``diff`` 在含 diff 时为 **git 优先** 否则 unified（见设计 v3 §2.1）。
    v2 Phase 3：``BatchEditInput`` / ``BatchEditOutput`` / ``BatchEditOperation``。
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class EditToolInput(BaseModel):
    """Edit 工具输入（CC FileEditInput 对齐）。"""

    file_path: str = Field(..., description="Absolute path to the file to edit.")
    old_string: str = Field(..., description="Exact text to replace.")
    new_string: str = Field(..., description="Replacement text (must differ from old_string).")
    replace_all: bool = Field(
        False,
        description="If true, replace every occurrence of old_string.",
    )
    include_diff: bool = Field(
        False,
        description="If true, include a unified diff in tool result meta (v2).",
    )


class EditToolOutput(BaseModel):
    """v1 简化输出（edit-tool-migration §2.3）。"""

    file_path: str
    old_string: str
    new_string: str
    replaced_count: int
    original_file: str | None = Field(
        None,
        description="File content before replace; None if unavailable.",
    )
    diff: str | None = Field(
        None,
        description=(
            "When include_diff: primary diff text for the model—git diff if available, "
            "else unified old→new; None if include_diff was false or no replacement."
        ),
    )
    git_diff: str | None = Field(
        None,
        description=(
            "v3: git diff (working tree vs HEAD) for the file when generation succeeded; "
            "None if not in a repo, git failed, or no diff output. "
            "May reflect other uncommitted changes on that path, not only this edit."
        ),
    )


class BatchEditOperation(BaseModel):
    """单条批量替换（edit-tool-migration-v2 §2.1 功能 3）。"""

    old_string: str = Field(..., description="Exact text to replace (may match after quote normalization).")
    new_string: str = Field(..., description="Replacement text.")
    replace_all: bool = Field(
        False,
        description="If true, replace every occurrence of old_string for this step.",
    )


class BatchEditInput(BaseModel):
    """批量编辑输入：同一文件上顺序应用多条替换，原子写回。"""

    file_path: str = Field(..., description="Absolute path to the file to edit.")
    edits: list[BatchEditOperation] = Field(
        ...,
        min_length=1,
        description="Ordered edits applied in memory then written once.",
    )
    include_diff: bool = Field(
        False,
        description="If true, include combined unified diff in tool result meta (v2).",
    )


class BatchEditOutput(BaseModel):
    """批量编辑输出。"""

    file_path: str
    total_replaced: int = Field(..., description="Sum of replaced_count over all edits.")
    results: list[EditToolOutput] = Field(
        default_factory=list,
        description="Per-edit outcomes (old_string is the effective substring used).",
    )
    combined_diff: str | None = Field(
        None,
        description="Unified diff original → final when include_diff was true.",
    )
