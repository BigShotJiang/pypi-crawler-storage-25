"""
tools/edit/prompt.py — EditRuntimeTool 工具名与描述

职责：
    TOOL_NAME、bind_tools 用短 description、完整 Usage（CC prompt.ts 迁移要点）。

链路位置：
    EditRuntimeTool.name / description；后续与 get_prompt() 对齐设计 §2.4。

当前裁剪范围：
    与 CC ``getEditToolDescription`` / 设计 §2.4 对齐；v2/v3：``include_diff``（git 优先与语义）、``batch_edit``。
"""

from __future__ import annotations

TOOL_NAME = "edit"
"""面向模型暴露的工具名（edit-tool-migration §3.5 约定）。"""

DESCRIPTION = "Performs exact string replacements in files."
"""简短描述（bind_tools 列表）；与 CC 首句一致。"""

BATCH_TOOL_NAME = "batch_edit"
"""批量编辑工具名（edit-tool-migration-v2）。"""

BATCH_DESCRIPTION = "Applies multiple string edits to one file atomically."
"""``batch_edit`` 简短描述（bind_tools）。"""


def get_prompt() -> str:
    """完整使用说明；与 edit-tool-migration §2.4 / CC ``getDefaultEditDescription`` 对齐。"""
    from .limits import get_edit_limits

    max_kb = get_edit_limits()["max_file_size"] // 1024
    return f"""Performs exact string replacements in files.

Usage:
- You must use your Read tool at least once in the conversation before editing.
  This tool will error if you attempt an edit without reading the file.
- When editing text from Read tool output, ensure you preserve the exact indentation
  (tabs/spaces) as it appears AFTER the line number prefix. The line number prefix format
  is: line number + tab (or spaces + line number + arrow). Everything after that is the
  actual file content to match. Never include any part of the line number prefix in the
  old_string or new_string.
- ALWAYS prefer editing existing files in the codebase. NEVER write new files unless
  explicitly required (use the Write tool for new files / full rewrites).
- Only use emojis if the user explicitly requests it. Avoid adding emojis to files unless asked.
- The edit will FAIL if old_string is not unique in the file. Either provide a larger string
  with more surrounding context to make it unique or use replace_all to change every instance
  of old_string. Prefer the smallest old_string that is clearly unique when possible.
- Use replace_all for replacing and renaming strings across the file. This parameter is
  useful if you want to rename a variable for instance.
- Files larger than {max_kb}KB cannot be edited through this tool.
- Optional include_diff (default false): when true, the tool result meta may include diff text.
  If the file is in a Git repo and ``git diff`` succeeds, meta uses that for the primary ``diff``
  and may also include ``git_diff`` (same source); ``diff`` is then Git-format (working tree vs HEAD).
  That Git diff can include other uncommitted changes on the same file, not only this replacement.
  If Git is unavailable or produces no diff text, meta falls back to a line-level unified diff of
  this edit only (truncated if large). Payload remains the replace count.
- Smart quotes: if old_string does not match literally, the tool may match an equivalent
  substring in the file (curly vs straight quotes) and replace that exact file text.
- Tool ``batch_edit``: same read-before-edit and path rules as ``edit``; supply ``edits`` as a
  list of dicts (keys: old_string, new_string, optional replace_all). All edits apply in order in memory, then one
  write; any failure leaves the file unchanged. Optional include_diff adds a combined unified
  diff in meta.
"""
