"""
tools/edit/backend.py — EditFileBackend（文件读 / 替换 / 写）

职责：
    UTF-8 读入、字符串替换、LF 落盘；与 CC applyEditToFile 语义对齐（edit-tool-migration 附录 §7.4）。
    v2：``build_unified_diff`` 为 ``DiffGenerator`` 的薄封装（Phase 2 提取）。

链路位置：
    EditRuntimeTool.invoke() → EditFileBackend.replace_string()；diff 经 ``DiffGenerator``。

当前裁剪范围：
    ``new_string==""`` 走 CC 末尾换行分支；diff 仅 unified 文本，无 HTML/context。
"""

from __future__ import annotations

from pathlib import Path

from .diff_generator import DiffGenerator


# 兼容单测 / 旧 import：委托 DiffGenerator
def build_unified_diff(
    original: str,
    new_content: str,
    *,
    label: str = "file",
    max_bytes: int | None = None,
) -> str:
    """生成 unified diff；语义与 ``DiffGenerator.generate`` 一致。"""
    gen = DiffGenerator(max_bytes=max_bytes) if max_bytes is not None else DiffGenerator()
    return gen.generate(original, new_content, label=label)


def apply_edit_to_content(
    original: str,
    old_string: str,
    new_string: str,
    replace_all: bool,
) -> tuple[str, int]:
    """
    纯字符串变换，返回 (new_content, replaced_count)。

    与 CC ``applyEditToFile`` 对齐：``new_string==''`` 时对 ``old_string+'\\n'`` 的分支。
    """
    if old_string == "":
        if original != "":
            raise ValueError("apply_edit_to_content: empty old_string requires empty original")
        new_content = new_string
        return new_content, (1 if new_string else 0)

    if new_string != "":
        if replace_all:
            count = original.count(old_string)
            new_content = original.replace(old_string, new_string)
        else:
            count = 1 if (old_string in original) else 0
            new_content = original.replace(old_string, new_string, 1)
        return new_content, count

    strip_nl = (not old_string.endswith("\n")) and ((old_string + "\n") in original)
    needle = old_string + "\n" if strip_nl else old_string
    if replace_all:
        count = original.count(needle)
        new_content = original.replace(needle, "")
    else:
        count = 1 if (needle in original) else 0
        new_content = original.replace(needle, "", 1)
    return new_content, count


class EditFileBackend:
    """原地编辑文件内容（精确字符串替换）。"""

    def replace_string(
        self,
        *,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool,
    ) -> tuple[int, str]:
        """
        读取文件、应用替换、写回；返回 (replaced_count, original_content)。

        写盘仅在内容变化时发生，避免无谓 mtime 抖动。
        """
        path = Path(file_path)
        original = path.read_text(encoding="utf-8")
        new_content, count = apply_edit_to_content(
            original, old_string, new_string, replace_all
        )
        if new_content != original:
            path.write_text(new_content, encoding="utf-8", newline="\n")
        return count, original
