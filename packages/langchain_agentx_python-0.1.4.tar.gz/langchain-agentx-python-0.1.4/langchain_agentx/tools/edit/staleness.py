"""
tools/edit/staleness.py — StalenessChecker

职责：
    mtime + 内容对比、Windows 误报分支（edit-tool-migration §3.5.3）。

链路位置：
    EditRuntimeTool.validate_input / invoke → StalenessChecker.check()。

当前裁剪范围：
    仅基于 ``ToolStateBridge`` last_read；must-read 由 validator 步骤 5 保证。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.models import ToolExecutionContext, ValidationResult


class StalenessChecker:
    """文件相对上次 Read 是否已变更（方案 B）。"""

    def __init__(self, state_bridge: Any) -> None:
        self._state_bridge = state_bridge

    def check(self, file_path: str, ctx: ToolExecutionContext) -> ValidationResult:
        last_read_map = self._state_bridge.get_last_read_map(ctx)
        if file_path not in last_read_map:
            return ValidationResult(
                ok=False,
                message="[Internal] staleness check: last_read_map missing entry.",
            )

        last_read = last_read_map[file_path]
        read_content = last_read.get("content")
        read_mtime = int(last_read.get("mtime_ms", 0) or 0)

        try:
            current_mtime = int(os.path.getmtime(file_path) * 1000)
        except OSError:
            current_mtime = 0

        if current_mtime > read_mtime:
            if read_content is not None:
                try:
                    current_content = Path(file_path).read_text(encoding="utf-8")
                except OSError:
                    current_content = None

                if current_content is not None and current_content == read_content:
                    pass
                else:
                    return ValidationResult(
                        ok=False,
                        message=(
                            "File has been modified since read, either by the user or by a linter. "
                            "Read it again before attempting to write it."
                        ),
                    )
            else:
                return ValidationResult(
                    ok=False,
                    message=(
                        "File has been modified since read. Read it again before attempting to write it."
                    ),
                )

        return ValidationResult(ok=True)
