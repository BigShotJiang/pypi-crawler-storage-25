"""
tools/edit — EditRuntimeTool / BatchEditRuntimeTool（CC FileEditTool + v2 批量）

v2：Phase 1–2 单次 edit；Phase 3 ``batch_edit``；需 ``ToolStateBridge`` + 先 Read。
"""

from __future__ import annotations

from .batch_tool import BatchEditRuntimeTool
from .tool import EditRuntimeTool

__all__ = ["EditRuntimeTool", "BatchEditRuntimeTool"]
