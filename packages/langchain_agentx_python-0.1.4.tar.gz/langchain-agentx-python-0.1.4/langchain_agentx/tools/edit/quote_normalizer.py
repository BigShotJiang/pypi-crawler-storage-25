"""
tools/edit/quote_normalizer.py — QuoteNormalizer

职责：
    弯/直引号等价比较；在字面量不匹配时扫描等长窗口，返回**文件中实际子串**
    （edit-runtime-tool-v2 §0；CC ``findActualString`` 简化版）。

链路位置：
    ``EditStringValidator.validate``；可注入单测替身。

当前裁剪范围：
    仅 U+201C/U+201D/U+2018/U+2019 与 ASCII 引号；不等长匹配留待后续版本。
"""

from __future__ import annotations


class QuoteNormalizer:
    """引号规范化与 ``old_string`` 在正文中的实际定位。"""

    def normalize_for_match(self, s: str) -> str:
        """比较用规范化：弯引号映射为 ASCII，其余字符不变。"""
        out: list[str] = []
        for ch in s:
            if ch in "\u201c\u201d":
                out.append('"')
            elif ch in "\u2018\u2019":
                out.append("'")
            else:
                out.append(ch)
        return "".join(out)

    def find_actual_old_string_in_text(self, file_text: str, old_string: str) -> str | None:
        """
        若 ``old_string`` 已字面出现于 ``file_text``，原样返回；
        否则扫描与 ``len(old_string)`` 等长的窗口，规范化相等则返回**窗口原文**。
        """
        if old_string in file_text:
            return old_string
        n = len(old_string)
        if n == 0:
            return None
        norm_old = self.normalize_for_match(old_string)
        for i in range(0, len(file_text) - n + 1):
            cand = file_text[i : i + n]
            if self.normalize_for_match(cand) == norm_old:
                return cand
        return None
