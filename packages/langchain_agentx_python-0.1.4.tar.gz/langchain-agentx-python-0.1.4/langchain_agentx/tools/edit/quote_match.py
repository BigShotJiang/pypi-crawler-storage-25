"""
tools/edit/quote_match.py — 引号匹配薄封装（v2 Phase 2）

职责：
    保留模块级函数签名，委托 ``QuoteNormalizer``（避免调用方全量改 import）。

链路位置：
    历史单测 ``from .quote_match import …``；新代码优先 ``quote_normalizer.QuoteNormalizer``。

当前裁剪范围：
    无独立逻辑；实现以 ``quote_normalizer`` 为准。
"""

from __future__ import annotations

from .quote_normalizer import QuoteNormalizer

_default = QuoteNormalizer()


def normalize_quotes_for_match(s: str) -> str:
    return _default.normalize_for_match(s)


def find_actual_old_string_in_text(file_text: str, old_string: str) -> str | None:
    return _default.find_actual_old_string_in_text(file_text, old_string)
