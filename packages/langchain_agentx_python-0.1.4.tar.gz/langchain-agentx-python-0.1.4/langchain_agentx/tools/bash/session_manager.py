"""
tools/bash/session_manager.py — BashRuntimeTool v3：会话管理器

职责：
    管理多个 `BashSessionRuntime` 的创建、复用与销毁，保证：
    1. 同一 session_key 复用同一长期 shell
    2. 多会话之间状态隔离
    3. 空闲会话按 TTL 清理

与 CC 对照：
    对应 CC 长期 shell 任务管理模型的 Python 化基础设施。
"""

from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass

from .session_runtime import BashSessionRuntime


@dataclass
class _SessionEntry:
    runtime: BashSessionRuntime
    last_used_ts: float
    created_ts: float
    command_count: int = 0
    recycled_count: int = 0


@dataclass(frozen=True)
class BashSessionAuditRecord:
    session_key: str
    event: str
    ts: float
    details: dict[str, str]


class BashSessionManager:
    """Bash 长期会话管理器。"""

    def __init__(
        self,
        *,
        idle_ttl_sec: int = 900,
        max_sessions: int = 16,
        max_commands_per_session: int = 200,
    ) -> None:
        self._idle_ttl_sec = max(60, idle_ttl_sec)
        self._max_sessions = max(1, max_sessions)
        # 允许小阈值以便测试与细粒度回收（最小为 1）
        self._max_commands_per_session = max(1, max_commands_per_session)
        self._sessions: dict[str, _SessionEntry] = {}
        self._audit_log: list[BashSessionAuditRecord] = []
        self._lock = threading.Lock()

    def get_or_create(
        self,
        *,
        session_key: str,
        cwd: str | None,
        env: dict[str, str],
    ) -> BashSessionRuntime:
        now = time.time()
        with self._lock:
            self._cleanup_expired_locked(now)
            self._enforce_max_sessions_locked(now)
            entry = self._sessions.get(session_key)
            if entry is None:
                runtime = BashSessionRuntime(
                    initial_cwd=cwd,
                    base_env=env,
                )
                entry = _SessionEntry(runtime=runtime, last_used_ts=now, created_ts=now)
                self._sessions[session_key] = entry
                self._append_audit_locked(
                    session_key=session_key,
                    event="created",
                    details={"cwd": cwd or "", "env_size": str(len(env))},
                )
            else:
                entry.last_used_ts = now
                if entry.command_count >= self._max_commands_per_session:
                    entry.runtime.close()
                    entry.runtime = BashSessionRuntime(initial_cwd=cwd, base_env=env)
                    entry.command_count = 0
                    entry.recycled_count += 1
                    self._append_audit_locked(
                        session_key=session_key,
                        event="recycled_command_limit",
                        details={"recycled_count": str(entry.recycled_count)},
                    )
            entry.command_count += 1
            return entry.runtime

    def reset_session(self, session_key: str, *, cwd: str | None = None, env: dict[str, str] | None = None) -> None:
        with self._lock:
            old = self._sessions.pop(session_key, None)
            if old is not None:
                old.runtime.close()
            runtime = BashSessionRuntime(initial_cwd=cwd, base_env=(env or os.environ.copy()))
            now = time.time()
            self._sessions[session_key] = _SessionEntry(
                runtime=runtime,
                last_used_ts=now,
                created_ts=now,
                command_count=0,
                recycled_count=0,
            )
            self._append_audit_locked(
                session_key=session_key,
                event="reset",
                details={"cwd": cwd or "", "env_size": str(len(env or {}))},
            )

    def close_session(self, session_key: str) -> None:
        with self._lock:
            entry = self._sessions.pop(session_key, None)
        if entry is not None:
            entry.runtime.close()
            with self._lock:
                self._append_audit_locked(
                    session_key=session_key,
                    event="closed",
                    details={},
                )

    def close_all(self) -> None:
        with self._lock:
            entries = list(self._sessions.values())
            self._sessions.clear()
        for entry in entries:
            entry.runtime.close()

    def _cleanup_expired_locked(self, now_ts: float) -> None:
        expired_keys = [
            key
            for key, entry in self._sessions.items()
            if (now_ts - entry.last_used_ts) > self._idle_ttl_sec
        ]
        for key in expired_keys:
            entry = self._sessions.pop(key, None)
            if entry is not None:
                entry.runtime.close()
                self._append_audit_locked(
                    session_key=key,
                    event="expired",
                    details={"idle_ttl_sec": str(self._idle_ttl_sec)},
                )

    def _enforce_max_sessions_locked(self, now_ts: float) -> None:
        if len(self._sessions) < self._max_sessions:
            return
        oldest_key = min(
            self._sessions.keys(),
            key=lambda k: self._sessions[k].last_used_ts,
        )
        oldest = self._sessions.pop(oldest_key, None)
        if oldest is not None:
            oldest.runtime.close()
            self._append_audit_locked(
                session_key=oldest_key,
                event="evicted_max_sessions",
                details={"max_sessions": str(self._max_sessions), "ts": str(now_ts)},
            )

    def get_audit_log(self, *, tail: int = 200) -> list[BashSessionAuditRecord]:
        with self._lock:
            if tail <= 0:
                return []
            return list(self._audit_log[-tail:])

    def _append_audit_locked(self, *, session_key: str, event: str, details: dict[str, str]) -> None:
        self._audit_log.append(
            BashSessionAuditRecord(
                session_key=session_key,
                event=event,
                ts=time.time(),
                details=details,
            )
        )
        if len(self._audit_log) > 2000:
            self._audit_log = self._audit_log[-1000:]


_GLOBAL_SESSION_MANAGER: BashSessionManager | None = None
_GLOBAL_SESSION_MANAGER_LOCK = threading.Lock()


def get_global_bash_session_manager() -> BashSessionManager:
    """获取全局会话管理器（延迟初始化）。"""
    global _GLOBAL_SESSION_MANAGER
    with _GLOBAL_SESSION_MANAGER_LOCK:
        if _GLOBAL_SESSION_MANAGER is None:
            ttl = int(os.getenv("AGENTX_BASH_SESSION_IDLE_TTL_SEC", "900"))
            max_sessions = int(os.getenv("AGENTX_BASH_MAX_SESSIONS", "16"))
            max_commands = int(os.getenv("AGENTX_BASH_MAX_COMMANDS_PER_SESSION", "200"))
            _GLOBAL_SESSION_MANAGER = BashSessionManager(
                idle_ttl_sec=ttl,
                max_sessions=max_sessions,
                max_commands_per_session=max_commands,
            )
        return _GLOBAL_SESSION_MANAGER
