"""
tools/bash/limits.py — BashRuntimeTool 上限配置

对应 CC prompt.ts 中的 getDefaultBashTimeoutMs() / getMaxBashTimeoutMs()
以及 BashTool.tsx 中的 maxResultSizeChars=30_000。

全部支持环境变量覆盖，便于测试 mock 和生产调优。
"""

from __future__ import annotations

import os

# ---------------------------------------------------------------------------
# 超时配置
# ---------------------------------------------------------------------------

DEFAULT_TIMEOUT_SEC = int(os.getenv("BASH_TOOL_DEFAULT_TIMEOUT", "120"))
"""默认超时秒数（对应 CC getDefaultBashTimeoutMs() = 120000ms）。"""

MAX_TIMEOUT_SEC = int(os.getenv("BASH_TOOL_MAX_TIMEOUT", "600"))
"""最大超时秒数（对应 CC getMaxBashTimeoutMs() = 600000ms / 10min）。"""

# ---------------------------------------------------------------------------
# 输出限制
# ---------------------------------------------------------------------------

MAX_OUTPUT_CHARS = int(os.getenv("BASH_TOOL_MAX_OUTPUT_CHARS", str(30_000)))
"""单次输出字符上限（对应 CC maxResultSizeChars=30_000）。"""

# ---------------------------------------------------------------------------
# 安全阈值
# ---------------------------------------------------------------------------

SLEEP_BLOCK_THRESHOLD_SEC = int(os.getenv("BASH_TOOL_SLEEP_BLOCK_SEC", "30"))
"""sleep 命令阻断阈值（秒）。超过此值提示使用 run_in_background（对应 CC detectBlockedSleepPattern）。"""

# ---------------------------------------------------------------------------
# 后台任务
# ---------------------------------------------------------------------------

BACKGROUND_TASK_OUTPUT_DIR = os.path.expanduser(
    os.getenv(
        "BASH_TOOL_BACKGROUND_OUTPUT_DIR",
        "~/.cache/langchain_agentx/tasks",
    )
)
"""后台任务输出目录。"""

AUTO_BACKGROUND_ENABLED = os.getenv("BASH_TOOL_AUTO_BACKGROUND_ENABLED", "1") == "1"
"""是否开启自动后台化策略。"""

AUTO_BACKGROUND_TIMEOUT_SEC = int(
    os.getenv("BASH_TOOL_AUTO_BACKGROUND_TIMEOUT_SEC", "180")
)
"""触发自动后台化的 timeout 阈值（秒）。"""


def get_bash_limits() -> dict:
    """
    返回当前有效配置（动态读取，支持运行时环境变量覆盖）。
    """
    return {
        "default_timeout_sec": DEFAULT_TIMEOUT_SEC,
        "max_timeout_sec": MAX_TIMEOUT_SEC,
        "max_output_chars": MAX_OUTPUT_CHARS,
        "sleep_block_threshold_sec": SLEEP_BLOCK_THRESHOLD_SEC,
        "background_task_output_dir": BACKGROUND_TASK_OUTPUT_DIR,
        "auto_background_enabled": AUTO_BACKGROUND_ENABLED,
        "auto_background_timeout_sec": AUTO_BACKGROUND_TIMEOUT_SEC,
    }
