"""
cwd_reporter.py — Bash 执行后 cwd 回传（Unix fd3 / Windows 临时文件）

职责：
    为 `BashBackend._execute_raw` / `_aexecute_raw` 生成包装脚本：Unix 用 **fd3 + pass_fds**；
    Windows 用 **临时文件 + `pwd -P`**（禁止 pass_fds），与 CC `bashProvider` 双轨语义对齐。

链路位置：
    仅被 `backend.py` 调用；不读工具入参、不碰权限链。

当前裁剪范围：
    不处理流式 `_stream_execute_raw_iter`；不处理沙箱 backend 内部；UNC 临时目录尽力而为
   （`native_path_for_bash_redirect` 覆盖常见 `//server/share` 形态）。

设计 SSOT：
    docs/design-docs/tool-design/bash-tool-cross-platform.md（Phase 2）
"""

from __future__ import annotations

import os
from pathlib import Path


def bash_single_quoted(s: str) -> str:
    """Bash 单引号字面量（可嵌入 `pwd -P >| ...` 等）。"""
    return "'" + s.replace("'", "'\\''") + "'"


def native_path_for_bash_redirect(win_native: str) -> str:
    """
    将 **本机绝对路径** 转为 Git Bash / MSYS 下用于重定向的 POSIX 形态。

    - `C:\\Users\\x` → `/c/Users/x`
    - `\\\\server\\share\\a` → `//server/share/a`
    - 长路径前缀 `\\\\?\\` 会剥离后再转换（尽力而为）。
    """
    p = Path(win_native).resolve()
    s = os.fspath(p)
    norm = s.replace("/", "\\")
    if norm.startswith("\\\\?\\"):
        norm = norm[4:]
        if norm.upper().startswith("UNC\\"):
            norm = "\\" + norm[3:]
    if norm.startswith("\\\\"):
        body = norm[2:].replace("\\", "/").strip("/")
        return "//" + body if body else "//"
    if len(norm) >= 2 and norm[1] == ":":
        letter = norm[0].lower()
        tail = norm[2:].replace("\\", "/")
        if not tail.startswith("/"):
            tail = "/" + tail.lstrip("/")
        return f"/{letter}{tail}"
    return norm.replace("\\", "/")


def read_cwd_file(native_path: str) -> str | None:
    """读取 `pwd -P` 写入的临时文件，返回最后一行非空 cwd，失败为 None。"""
    try:
        raw = Path(native_path).read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    if not raw:
        return None
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    return lines[-1] if lines else None


class BashCwdReporter:
    """构造「执行用户命令 + 回写 cwd」的包装脚本（双平台）。"""

    __slots__ = ()

    @staticmethod
    def wrap_with_fd3(command: str, write_fd: int) -> str:
        """Unix：通过 fd3 写 `$PWD`（与既有 `backend._execute_raw` 一致）。"""
        return (
            f"exec 3>&{write_fd}\n"
            f"{command}\n"
            f'__EC=$?; echo "$PWD" >&3; exit $__EC'
        )

    @staticmethod
    def wrap_with_cwd_file(command: str, posix_target_single_quoted: str) -> str:
        """
        Windows：用户命令在同一 shell 内执行后 `pwd -P` 覆写到目标文件。

        `posix_target_single_quoted` 须已用 `bash_single_quoted(...)` 包一层。
        """
        return (
            f"{command}\n"
            f"__EC=$?\n"
            f"pwd -P >| {posix_target_single_quoted}\n"
            f"exit $__EC\n"
        )
