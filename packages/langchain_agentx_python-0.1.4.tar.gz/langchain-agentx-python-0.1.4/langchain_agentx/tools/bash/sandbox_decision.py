"""
tools/bash/sandbox_decision.py — BashRuntimeTool 模块4：沙箱决策层

职责：
    在真正执行命令前，决定本次 Bash 调用是否应走 sandbox backend，
    并给出 bypass / excluded / override_not_allowed 等结构化原因。

设计目标：
    - 对齐 CC `shouldUseSandbox.ts` 的决策链，但按本工程 OOP 风格拆成独立协作者
    - 让 `tool.py` 只负责编排，不在执行前散落沙箱规则
    - 为后续替换成真实 OS 级沙箱后端保留稳定输入输出契约

当前覆盖：
    - sandbox enable / disable 总开关
    - `dangerously_disable_sandbox` 参数
    - ctx.tool_flags 注入的策略控制（允许绕过、excluded commands）
    - 基于 canonical command 的 excluded pattern 匹配

与 CC 对照：
    对应 CC `shouldUseSandbox.ts` 的基础版能力，不包含其动态配置系统和完整
    SandboxManager 实现。
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field

from langchain_agentx.tool_runtime.models import ToolExecutionContext

from .bash_hardening import BashCommandCanonicalizer


@dataclass(frozen=True)
class BashSandboxConfig:
    enabled: bool = True
    allow_unsandboxed_commands: bool = False
    excluded_commands: tuple[str, ...] = ()


@dataclass(frozen=True)
class BashSandboxDecision:
    use_sandbox: bool
    reason: str
    matched_excluded_pattern: str | None = None
    override_requested: bool = False
    override_allowed: bool = False


class BashSandboxDecisionEngine:
    """Bash 沙箱决策协作者。"""

    def __init__(
        self,
        config: BashSandboxConfig | None = None,
        canonicalizer: BashCommandCanonicalizer | None = None,
    ) -> None:
        self._config = config or BashSandboxConfig()
        self._canonicalizer = canonicalizer or BashCommandCanonicalizer()

    def decide(
        self,
        *,
        command: str,
        dangerously_disable_sandbox: bool,
        ctx: ToolExecutionContext,
    ) -> BashSandboxDecision:
        if not self._config.enabled:
            return BashSandboxDecision(use_sandbox=False, reason="sandbox_disabled")

        if not command.strip():
            return BashSandboxDecision(use_sandbox=False, reason="empty_command")

        matched_pattern = self._match_excluded_pattern(command, ctx)
        if matched_pattern is not None:
            return BashSandboxDecision(
                use_sandbox=False,
                reason="excluded_command",
                matched_excluded_pattern=matched_pattern,
            )

        if dangerously_disable_sandbox:
            override_allowed = self._override_allowed(ctx)
            if override_allowed:
                return BashSandboxDecision(
                    use_sandbox=False,
                    reason="explicit_override",
                    override_requested=True,
                    override_allowed=True,
                )
            return BashSandboxDecision(
                use_sandbox=True,
                reason="override_not_allowed",
                override_requested=True,
                override_allowed=False,
            )

        return BashSandboxDecision(use_sandbox=True, reason="sandbox_enabled")

    def _match_excluded_pattern(
        self,
        command: str,
        ctx: ToolExecutionContext,
    ) -> str | None:
        candidates = self._candidate_commands(command)
        configured_patterns = list(self._config.excluded_commands)
        configured_patterns.extend(
            tuple((ctx.tool_flags or {}).get("sandbox_excluded_commands", ()))
        )
        for pattern in configured_patterns:
            if any(self._matches_pattern(candidate, pattern) for candidate in candidates):
                return pattern
        return None

    def _candidate_commands(self, command: str) -> list[str]:
        canonical = self._canonicalizer.canonicalize(command)
        candidates = [command.strip()]
        if canonical and canonical not in candidates:
            candidates.append(canonical)
        return candidates

    def _override_allowed(self, ctx: ToolExecutionContext) -> bool:
        tool_flags = ctx.tool_flags or {}
        return bool(
            tool_flags.get("allow_dangerously_disable_sandbox")
            or self._config.allow_unsandboxed_commands
        )

    @staticmethod
    def _matches_pattern(command: str, pattern: str) -> bool:
        if any(symbol in pattern for symbol in "*?[]"):
            return fnmatch.fnmatch(command, pattern)
        return command == pattern or command.startswith(f"{pattern} ")
