"""
tools/bash/sed_edit_parser.py — BashRuntimeTool 模块2：sed 编辑解析与预览

职责：
    为 `sed -i` 可控编辑工作流提供“可确定 preview”的解析能力，包括：
    1. 识别 simple in-place substitution 命令
    2. 提取 file / pattern / replacement / flags / extended-regex 信息
    3. 在内存中模拟 sed substitution，生成 preview diff

设计边界：
    - 只处理 simple `sed -i 's/from/to/flags' file` 这类可稳定预览的场景
    - 遇到多文件、未知 flag、无法稳定解析的表达式时返回 None
    - 不负责权限决策；是否进入 preview/apply 流由 `sed_validation.py` 决定

与 CC 对照：
    对应 CC `sedEditParser.ts` 的 Python 化版本，但保持当前阶段需要的最小可用
    范围，不复制其全部兼容细节。
"""

from __future__ import annotations

import difflib
import re
import shlex
from dataclasses import dataclass


_BACKSLASH_PLACEHOLDER = "\x00BACKSLASH\x00"
_PLUS_PLACEHOLDER = "\x00PLUS\x00"
_QUESTION_PLACEHOLDER = "\x00QUESTION\x00"
_PIPE_PLACEHOLDER = "\x00PIPE\x00"
_LPAREN_PLACEHOLDER = "\x00LPAREN\x00"
_RPAREN_PLACEHOLDER = "\x00RPAREN\x00"


@dataclass(frozen=True)
class SedEditInfo:
    file_path: str
    pattern: str
    replacement: str
    flags: str
    extended_regex: bool


class BashSedEditParser:
    """解析 simple `sed -i 's/a/b/' file` 命令，并生成 preview。"""

    _VALID_FLAGS = re.compile(r"^[gpimIM1-9]*$")

    def parse(self, command: str) -> SedEditInfo | None:
        trimmed = command.strip()
        if not re.match(r"^\s*sed\s+", trimmed):
            return None

        try:
            tokens = shlex.split(trimmed)
        except ValueError:
            return None

        if not tokens or tokens[0] != "sed":
            return None

        has_in_place = False
        extended_regex = False
        expression: str | None = None
        file_path: str | None = None

        i = 1
        while i < len(tokens):
            arg = tokens[i]
            if arg in {"-i", "--in-place"}:
                has_in_place = True
                i += 1
                if i < len(tokens):
                    next_arg = tokens[i]
                    if next_arg == "" or (not next_arg.startswith("-") and next_arg.startswith(".")):
                        i += 1
                continue
            if arg.startswith("-i"):
                has_in_place = True
                i += 1
                continue
            if arg in {"-E", "-r", "--regexp-extended"}:
                extended_regex = True
                i += 1
                continue
            if arg in {"-e", "--expression"}:
                if i + 1 >= len(tokens) or expression is not None:
                    return None
                expression = tokens[i + 1]
                i += 2
                continue
            if arg.startswith("--expression="):
                if expression is not None:
                    return None
                expression = arg.split("=", 1)[1]
                i += 1
                continue
            if arg.startswith("-"):
                return None
            if expression is None:
                expression = arg
            elif file_path is None:
                file_path = arg
            else:
                return None
            i += 1

        if not has_in_place or not expression or not file_path:
            return None
        if not expression.startswith("s/"):
            return None

        parsed_expression = self._parse_substitution_expression(
            expression=expression,
            file_path=file_path,
            extended_regex=extended_regex,
        )
        return parsed_expression

    def apply_substitution(self, content: str, sed_info: SedEditInfo) -> str:
        regex_flags = ""
        if "g" in sed_info.flags:
            regex_flags += "g"
        if "i" in sed_info.flags or "I" in sed_info.flags:
            regex_flags += "i"
        if "m" in sed_info.flags or "M" in sed_info.flags:
            regex_flags += "m"

        js_pattern = sed_info.pattern.replace(r"\/", "/")
        if not sed_info.extended_regex:
            js_pattern = (
                js_pattern
                .replace(r"\\", _BACKSLASH_PLACEHOLDER)
                .replace(r"\+", _PLUS_PLACEHOLDER)
                .replace(r"\?", _QUESTION_PLACEHOLDER)
                .replace(r"\|", _PIPE_PLACEHOLDER)
                .replace(r"\(", _LPAREN_PLACEHOLDER)
                .replace(r"\)", _RPAREN_PLACEHOLDER)
                .replace("+", r"\+")
                .replace("?", r"\?")
                .replace("|", r"\|")
                .replace("(", r"\(")
                .replace(")", r"\)")
                .replace(_BACKSLASH_PLACEHOLDER, r"\\")
                .replace(_PLUS_PLACEHOLDER, "+")
                .replace(_QUESTION_PLACEHOLDER, "?")
                .replace(_PIPE_PLACEHOLDER, "|")
                .replace(_LPAREN_PLACEHOLDER, "(")
                .replace(_RPAREN_PLACEHOLDER, ")")
            )

        replacement = (
            sed_info.replacement
            .replace(r"\/", "/")
            .replace(r"\&", "__ESCAPED_AMP__")
            .replace("&", "$$&")
            .replace("__ESCAPED_AMP__", "&")
        )

        try:
            regex = re.compile(js_pattern, flags=self._to_python_flags(regex_flags))
        except re.error:
            return content
        return regex.sub(replacement, content)

    def build_preview(self, *, original: str, updated: str, file_path: str) -> str:
        diff = list(
            difflib.unified_diff(
                original.splitlines(),
                updated.splitlines(),
                fromfile=f"{file_path} (before)",
                tofile=f"{file_path} (after)",
                lineterm="",
                n=3,
            )
        )
        if not diff:
            return f"Preview for {file_path}: no textual changes."
        preview = "\n".join(diff[:60])
        return f"Preview for {file_path}:\n```diff\n{preview}\n```"

    def _parse_substitution_expression(
        self,
        *,
        expression: str,
        file_path: str,
        extended_regex: bool,
    ) -> SedEditInfo | None:
        rest = expression[2:]
        pattern = ""
        replacement = ""
        flags = ""
        state = "pattern"
        i = 0
        while i < len(rest):
            char = rest[i]
            if char == "\\" and i + 1 < len(rest):
                value = char + rest[i + 1]
                if state == "pattern":
                    pattern += value
                elif state == "replacement":
                    replacement += value
                else:
                    flags += value
                i += 2
                continue
            if char == "/":
                if state == "pattern":
                    state = "replacement"
                elif state == "replacement":
                    state = "flags"
                else:
                    return None
                i += 1
                continue
            if state == "pattern":
                pattern += char
            elif state == "replacement":
                replacement += char
            else:
                flags += char
            i += 1
        if state != "flags":
            return None
        if not self._VALID_FLAGS.match(flags):
            return None
        return SedEditInfo(
            file_path=file_path,
            pattern=pattern,
            replacement=replacement,
            flags=flags,
            extended_regex=extended_regex,
        )

    @staticmethod
    def _to_python_flags(flag_text: str) -> int:
        value = 0
        if "i" in flag_text:
            value |= re.IGNORECASE
        if "m" in flag_text:
            value |= re.MULTILINE
        return value
