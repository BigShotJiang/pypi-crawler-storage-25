"""
tools/bash/path_security.py — BashRuntimeTool v2 路径安全分析

职责：
    对照 CC `pathValidation.ts`，为 bash 子命令提供：
    - 路径参数提取
    - `--` 结束选项语义
    - 命令级路径操作类型识别（read / write / create）
    - 危险删除路径检查
    - compound command 中 `cd + write` 的保守审批
    - 调用 PolicyEngine 的路径级授权

设计原则：
    - 保持 OOP 风格，与 `BashAstAnalyzer` 配套
    - 只迁移高价值、高风险的 v2 能力，不直接复制 CC 全量 1300+ 行实现
"""

from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass
from typing import Literal

from langchain_agentx.tool_runtime.models import AuthorizationDecision

from .ast_security import BashAstAnalysis, BashWrapperStripper


OperationType = Literal["read", "write", "create"]


@dataclass(frozen=True)
class BashPathTarget:
    raw_path: str
    operation_type: OperationType
    target_source: Literal["argv", "redirection"] = "argv"


@dataclass(frozen=True)
class BashCommandPathInfo:
    base_command: str
    operation_type: OperationType
    path_targets: tuple[BashPathTarget, ...]
    requires_manual_approval: bool = False
    manual_approval_reason: str | None = None


@dataclass(frozen=True)
class BashCompressionCommandSpec:
    output_suffix: str
    source_mutates_by_default: bool = True
    explicit_output_flags: tuple[str, ...] = ()
    stdout_flags: tuple[str, ...] = ("-c", "--stdout", "--to-stdout")
    keep_source_flags: tuple[str, ...] = ("-k", "--keep")
    second_positional_output: bool = False


class BashArgumentTokenizer:
    """封装命令参数切分与 `--` 语义。"""

    def split(self, command_text: str) -> list[str]:
        try:
            return shlex.split(command_text)
        except ValueError:
            return command_text.split()

    def filter_out_flags(self, args: list[str]) -> list[str]:
        result: list[str] = []
        after_double_dash = False
        for arg in args:
            if after_double_dash:
                result.append(arg)
            elif arg == "--":
                after_double_dash = True
            elif not arg.startswith("-"):
                result.append(arg)
        return result

    def parse_pattern_command(
        self,
        args: list[str],
        flags_with_args: set[str],
        defaults: list[str] | None = None,
    ) -> list[str]:
        paths: list[str] = []
        pattern_found = False
        after_double_dash = False
        idx = 0
        while idx < len(args):
            arg = args[idx]
            if not arg:
                idx += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                idx += 1
                continue
            if not after_double_dash and arg.startswith("-"):
                flag = arg.split("=")[0]
                if flag in {"-e", "--regexp", "-f", "--file"}:
                    pattern_found = True
                if flag in flags_with_args and "=" not in arg and idx + 1 < len(args):
                    idx += 2
                    continue
                idx += 1
                continue
            if not pattern_found:
                pattern_found = True
                idx += 1
                continue
            paths.append(arg)
            idx += 1

        if paths:
            return paths
        return defaults or []


class BashCommandPathInfoFactory:
    """统一构造 `BashCommandPathInfo`，集中处理重定向附加逻辑。"""

    def build(
        self,
        *,
        base_command: str,
        operation_type: OperationType,
        path_targets: list[BashPathTarget],
        analysis: BashAstAnalysis,
        requires_manual_approval: bool = False,
        manual_approval_reason: str | None = None,
    ) -> BashCommandPathInfo:
        if analysis.output_redirection_paths:
            path_targets.extend(
                BashPathTarget(path, "write", target_source="redirection")
                for path in analysis.output_redirection_paths
            )
            operation_type = "write"
        return BashCommandPathInfo(
            base_command=base_command,
            operation_type=operation_type,
            path_targets=tuple(path_targets),
            requires_manual_approval=requires_manual_approval,
            manual_approval_reason=manual_approval_reason,
        )


class BashRemotePathClassifier:
    """识别 scp / rclone 一类命令中的 remote endpoint。"""

    _LOCAL_PREFIXES = ("/", "./", "../", "~/", "~+", "~-", "$", "'", '"', "{", "[")

    def is_remote_spec(self, value: str) -> bool:
        if not value:
            return False
        if value.startswith("scp://"):
            return True
        if value.startswith(":") and value.count(":") >= 2:
            return True
        if value.startswith(self._LOCAL_PREFIXES):
            return False
        if re.match(r"^[A-Za-z]:[\\/]", value):
            return False
        return ":" in value

    def build_local_target(
        self,
        value: str,
        operation_type: OperationType,
    ) -> BashPathTarget | None:
        if self.is_remote_spec(value):
            return None
        return BashPathTarget(value, operation_type)


class BashSpecialPathExtractor:
    """
    聚合特殊命令的路径提取逻辑。

    这样 `BashPathExtractorRegistry` 负责分发，复杂命令解析交给专门协作者。
    """

    def __init__(
        self,
        tokenizer: BashArgumentTokenizer,
        path_info_factory: BashCommandPathInfoFactory,
        remote_classifier: BashRemotePathClassifier | None = None,
    ) -> None:
        self._tokenizer = tokenizer
        self._path_info_factory = path_info_factory
        self._remote_classifier = remote_classifier or BashRemotePathClassifier()

    def extract_mktemp(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        target_directory: str | None = None
        template_path: str | None = None
        after_double_dash = False
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--tmpdir="):
                target_directory = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg in {"-p", "--tmpdir"} and i + 1 < len(args):
                target_directory = args[i + 1]
                i += 2
                continue
            if not after_double_dash and arg.startswith("-"):
                i += 1
                continue
            template_path = arg
            i += 1

        path_targets: list[BashPathTarget] = []
        if target_directory:
            path_targets.append(BashPathTarget(target_directory, "create"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="create",
                path_targets=path_targets,
                analysis=analysis,
            )
        if template_path and ("/" in template_path or template_path.startswith(".")):
            path_targets.append(BashPathTarget(template_path, "create"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="create",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="create",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "mktemp without an explicit target directory or path requires explicit approval "
                "because the created location cannot be determined safely."
            ),
        )

    def extract_tee(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        paths = self._tokenizer.filter_out_flags(args)
        path_targets = [BashPathTarget(path, "write") for path in paths]
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
        )

    def extract_install(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        target_directory: str | None = None
        no_target_directory = False
        after_double_dash = False
        i = 0
        flags_with_args = {
            "-m", "--mode", "-o", "--owner", "-g", "--group", "-S", "--suffix",
            "-t", "--target-directory",
        }
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--target-directory="):
                target_directory = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg in {"-T", "--no-target-directory"}:
                no_target_directory = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("-"):
                flag = arg.split("=")[0]
                if flag in {"-t", "--target-directory"} and i + 1 < len(args):
                    target_directory = args[i + 1]
                    i += 2
                    continue
                if flag in flags_with_args and "=" not in arg and i + 1 < len(args):
                    i += 2
                    continue
                i += 1
                continue
            positional.append(arg)
            i += 1

        if target_directory:
            path_targets.extend(BashPathTarget(path, "read") for path in positional)
            path_targets.append(BashPathTarget(target_directory, "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        if len(positional) >= 2:
            path_targets.extend(BashPathTarget(path, "read") for path in positional[:-1])
            path_targets.append(BashPathTarget(positional[-1], "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "install command requires explicit approval when the destination path "
                "cannot be determined safely."
            ),
        )

    def extract_ln(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        target_directory: str | None = None
        after_double_dash = False
        i = 0
        flags_with_args = {"-S", "--suffix", "-t", "--target-directory"}
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--target-directory="):
                target_directory = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg.startswith("-"):
                flag = arg.split("=")[0]
                if flag in {"-t", "--target-directory"} and i + 1 < len(args):
                    target_directory = args[i + 1]
                    i += 2
                    continue
                if flag in flags_with_args and "=" not in arg and i + 1 < len(args):
                    i += 2
                    continue
                i += 1
                continue
            positional.append(arg)
            i += 1

        if target_directory:
            path_targets.extend(BashPathTarget(path, "read") for path in positional)
            path_targets.append(BashPathTarget(target_directory, "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        if len(positional) >= 2:
            path_targets.extend(BashPathTarget(path, "read") for path in positional[:-1])
            path_targets.append(BashPathTarget(positional[-1], "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "ln command requires explicit approval when the destination path "
                "cannot be determined safely."
            ),
        )

    def extract_tar(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        archive_path: str | None = None
        chdir_path: str | None = None
        positional: list[str] = []
        after_double_dash = False
        create_mode = False
        extract_mode = False
        list_mode = False
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--file="):
                archive_path = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg.startswith("--directory="):
                chdir_path = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg == "--create":
                create_mode = True
                i += 1
                continue
            if not after_double_dash and arg == "--extract":
                extract_mode = True
                i += 1
                continue
            if not after_double_dash and arg == "--list":
                list_mode = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("-") and arg != "-":
                if "c" in arg and not arg.startswith("--"):
                    create_mode = True
                if "x" in arg and not arg.startswith("--"):
                    extract_mode = True
                if "t" in arg and not arg.startswith("--"):
                    list_mode = True
                if "f" in arg and not arg.startswith("--"):
                    value = self._extract_attached_short_option_value(arg, "f")
                    if value:
                        archive_path = value
                        i += 1
                        continue
                    if i + 1 < len(args):
                        archive_path = args[i + 1]
                        i += 2
                        continue
                if arg in {"-f", "--file"} and i + 1 < len(args):
                    archive_path = args[i + 1]
                    i += 2
                    continue
                if arg in {"-C", "--directory"} and i + 1 < len(args):
                    chdir_path = args[i + 1]
                    i += 2
                    continue
                i += 1
                continue
            positional.append(arg)
            i += 1

        if extract_mode:
            path_targets: list[BashPathTarget] = []
            if archive_path:
                path_targets.append(BashPathTarget(archive_path, "read"))
            if chdir_path:
                path_targets.append(BashPathTarget(chdir_path, "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    "tar extract commands require explicit approval because they can "
                    "materialize many files that are not explicit command arguments."
                ),
            )

        path_targets: list[BashPathTarget] = []
        if archive_path:
            path_targets.append(BashPathTarget(archive_path, "write" if create_mode else "read"))
        if chdir_path:
            path_targets.append(BashPathTarget(chdir_path, "read" if create_mode else "write"))
        if create_mode:
            path_targets.extend(BashPathTarget(path, "read") for path in positional)
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        if list_mode and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )
        if archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "tar command requires explicit approval when its read/write targets "
                "cannot be determined safely."
            ),
        )

    def extract_dd(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        path_targets: list[BashPathTarget] = []
        for arg in args:
            if not arg or "=" not in arg:
                continue
            key, value = arg.split("=", 1)
            if not value:
                continue
            if key == "if":
                path_targets.append(BashPathTarget(value, "read"))
            elif key == "of":
                path_targets.append(BashPathTarget(value, "write"))

        operation_type: OperationType = (
            "write" if any(target.operation_type == "write" for target in path_targets) else "read"
        )

        for target in path_targets:
            if target.operation_type == "write" and target.raw_path.startswith("/dev/"):
                return self._path_info_factory.build(
                    base_command=base_command,
                    operation_type="write",
                    path_targets=path_targets,
                    analysis=analysis,
                    requires_manual_approval=True,
                    manual_approval_reason=(
                        "dd writing directly to a device path requires explicit approval."
                    ),
                )

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type=operation_type,
            path_targets=path_targets,
            analysis=analysis,
        )

    def extract_rsync(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        after_double_dash = False
        i = 0
        risky_path_flags = {
            "--backup-dir", "--compare-dest", "--copy-dest", "--link-dest",
            "--partial-dir", "--temp-dir", "--files-from", "--exclude-from",
            "--include-from",
        }
        simple_flags_with_args = {
            "-e", "--rsh", "-T", "--temp-dir", "--backup-dir", "--files-from",
            "--exclude-from", "--include-from", "--compare-dest", "--copy-dest",
            "--link-dest",
        }
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--"):
                flag = arg.split("=", 1)[0]
                if flag in risky_path_flags:
                    return self._path_info_factory.build(
                        base_command=base_command,
                        operation_type="write",
                        path_targets=path_targets,
                        analysis=analysis,
                        requires_manual_approval=True,
                        manual_approval_reason=(
                            "rsync with path-bearing control flags requires explicit approval "
                            "to ensure all filesystem targets are validated."
                        ),
                    )
                if "=" in arg:
                    i += 1
                    continue
                if flag in simple_flags_with_args and i + 1 < len(args):
                    i += 2
                    continue
                i += 1
                continue
            if not after_double_dash and arg.startswith("-"):
                if any(char in arg for char in {"e", "T"}):
                    return self._path_info_factory.build(
                        base_command=base_command,
                        operation_type="write",
                        path_targets=path_targets,
                        analysis=analysis,
                        requires_manual_approval=True,
                        manual_approval_reason=(
                            "rsync with complex short flags requires explicit approval "
                            "to ensure all filesystem targets are validated."
                        ),
                    )
                i += 1
                continue
            positional.append(arg)
            i += 1

        if len(positional) < 2:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    "rsync command requires explicit approval when source or destination "
                    "cannot be determined safely."
                ),
            )

        path_targets.extend(BashPathTarget(path, "read") for path in positional[:-1])
        path_targets.append(BashPathTarget(positional[-1], "write"))
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
        )

    def extract_zip(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        temp_path: str | None = None
        out_path: str | None = None
        move_mode = False
        delete_mode = False
        names_from_stdin = False
        after_double_dash = False
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--temp-path="):
                temp_path = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg.startswith("--out="):
                out_path = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg in {"--move"}:
                move_mode = True
                i += 1
                continue
            if not after_double_dash and arg in {"--delete"}:
                delete_mode = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("-") and arg != "-":
                if arg in {"-b", "--temp-path"} and i + 1 < len(args):
                    temp_path = args[i + 1]
                    i += 2
                    continue
                if arg == "--out" and i + 1 < len(args):
                    out_path = args[i + 1]
                    i += 2
                    continue
                if "m" in arg and not arg.startswith("--"):
                    move_mode = True
                if "d" in arg and not arg.startswith("--"):
                    delete_mode = True
                if "@" in arg and not arg.startswith("--"):
                    names_from_stdin = True
                if "b" in arg and not arg.startswith("--"):
                    value = self._extract_attached_short_option_value(arg, "b")
                    if value:
                        temp_path = value
                        i += 1
                        continue
                    if arg == "-b" and i + 1 < len(args):
                        temp_path = args[i + 1]
                        i += 2
                        continue
                i += 1
                continue
            positional.append(arg)
            i += 1

        if temp_path:
            path_targets.append(BashPathTarget(temp_path, "write"))

        if out_path:
            if positional:
                path_targets.append(BashPathTarget(positional[0], "read"))
                source_paths = [] if delete_mode else positional[1:]
            else:
                source_paths = []
            path_targets.append(BashPathTarget(out_path, "write"))
            operation_for_sources: OperationType = "write" if move_mode else "read"
            path_targets.extend(
                BashPathTarget(path, operation_for_sources) for path in source_paths
            )
            if not positional or (names_from_stdin and not delete_mode):
                return self._path_info_factory.build(
                    base_command=base_command,
                    operation_type="write",
                    path_targets=path_targets,
                    analysis=analysis,
                    requires_manual_approval=True,
                    manual_approval_reason=(
                        "zip with --out or stdin-provided file lists requires explicit approval "
                        "when the full archive inputs cannot be determined safely."
                    ),
                )
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )

        if positional:
            archive_path = positional[0]
            source_paths = positional[1:]
            path_targets.append(BashPathTarget(archive_path, "write"))
            if delete_mode:
                return self._path_info_factory.build(
                    base_command=base_command,
                    operation_type="write",
                    path_targets=path_targets,
                    analysis=analysis,
                )
            operation_for_sources = "write" if move_mode else "read"
            path_targets.extend(
                BashPathTarget(path, operation_for_sources) for path in source_paths
            )
            if source_paths and not names_from_stdin:
                return self._path_info_factory.build(
                    base_command=base_command,
                    operation_type="write",
                    path_targets=path_targets,
                    analysis=analysis,
                )

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "zip command requires explicit approval when archive inputs, source files, "
                "or generated outputs cannot be determined safely."
            ),
        )

    def extract_unzip(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        destination_directory: str | None = None
        read_only_mode = False
        after_double_dash = False
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("-") and arg != "-":
                if arg == "-d" and i + 1 < len(args):
                    destination_directory = args[i + 1]
                    i += 2
                    continue
                if "d" in arg and not arg.startswith("--"):
                    value = self._extract_attached_short_option_value(arg, "d")
                    if value:
                        destination_directory = value
                        i += 1
                        continue
                if not arg.startswith("--") and any(flag in arg for flag in {"l", "t", "p", "v", "Z"}):
                    read_only_mode = True
                i += 1
                continue
            positional.append(arg)
            i += 1

        archive_path = positional[0] if positional else None
        if archive_path:
            path_targets.append(BashPathTarget(archive_path, "read"))
        if destination_directory:
            path_targets.append(BashPathTarget(destination_directory, "write"))

        if read_only_mode and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )

        if archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    "unzip extraction commands require explicit approval because they can "
                    "materialize many files beyond explicit argv paths."
                ),
            )

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "unzip command requires explicit approval when the archive path or "
                "extraction target cannot be determined safely."
            ),
        )

    def extract_7z_family(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        action: str | None = None
        archive_path: str | None = None
        destination_directory: str | None = None
        source_paths: list[str] = []
        path_targets: list[BashPathTarget] = []
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if action is None and not arg.startswith("-"):
                action = arg.lower()
                i += 1
                continue
            if arg.startswith("-o") and arg != "-o":
                destination_directory = arg[2:]
                i += 1
                continue
            if arg == "-o" and i + 1 < len(args):
                destination_directory = args[i + 1]
                i += 2
                continue
            if archive_path is None and not arg.startswith("-"):
                archive_path = arg
                i += 1
                continue
            if not arg.startswith("-"):
                source_paths.append(arg)
            i += 1

        if destination_directory:
            path_targets.append(BashPathTarget(destination_directory, "write"))
        if archive_path:
            archive_operation: OperationType = "read"
            if action in {"a", "u", "d"}:
                archive_operation = "write"
            path_targets.append(BashPathTarget(archive_path, archive_operation))

        if action in {"l", "t", "i"} and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )

        if action in {"x", "e"} and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    f"{base_command} extract commands require explicit approval because they can "
                    "materialize many files beyond explicit argv paths."
                ),
            )

        if action == "d" and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )

        if action in {"a", "u", "d"} and archive_path:
            path_targets.extend(BashPathTarget(path, "read") for path in source_paths)
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=not bool(source_paths),
                manual_approval_reason=(
                    None if source_paths else
                    f"{base_command} requires explicit approval when archive inputs cannot be "
                    "determined safely."
                ),
            )

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                f"{base_command} command requires explicit approval when its action, archive path, "
                "or destination cannot be determined safely."
            ),
        )

    def extract_zip_metadata(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        paths = self._tokenizer.filter_out_flags(args)
        path_targets = [BashPathTarget(path, "read") for path in paths[:1]]
        if path_targets:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="read",
            path_targets=[],
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                f"{base_command} requires explicit approval when the target archive cannot be "
                "determined safely."
            ),
        )

    def extract_single_file_archive(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        specs = {
            "gzip": BashCompressionCommandSpec(".gz"),
            "gunzip": BashCompressionCommandSpec(".gz"),
            "xz": BashCompressionCommandSpec(".xz"),
            "unxz": BashCompressionCommandSpec(".xz"),
            "bzip2": BashCompressionCommandSpec(".bz2"),
            "bunzip2": BashCompressionCommandSpec(".bz2"),
            "zstd": BashCompressionCommandSpec(".zst", explicit_output_flags=("-o", "--output")),
            "unzstd": BashCompressionCommandSpec(".zst", explicit_output_flags=("-o", "--output")),
            "lz4": BashCompressionCommandSpec(
                ".lz4",
                source_mutates_by_default=False,
                explicit_output_flags=("-o", "--output"),
                second_positional_output=True,
            ),
        }
        spec = specs[base_command]
        decompress_mode = base_command in {"gunzip", "unxz", "bunzip2", "unzstd"}
        stdout_mode = False
        keep_source = False
        explicit_output: str | None = None
        positional: list[str] = []
        after_double_dash = False
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash:
                if arg in spec.stdout_flags:
                    stdout_mode = True
                    i += 1
                    continue
                if arg in spec.keep_source_flags:
                    keep_source = True
                    i += 1
                    continue
                if arg in {"-d", "--decompress", "--uncompress"}:
                    decompress_mode = True
                    i += 1
                    continue
                if arg in {"-z", "--compress"}:
                    decompress_mode = False
                    i += 1
                    continue
                if arg in spec.explicit_output_flags and i + 1 < len(args):
                    explicit_output = args[i + 1]
                    i += 2
                    continue
                if arg.startswith("-") and arg != "-":
                    if "c" in arg and not arg.startswith("--"):
                        stdout_mode = True
                    if "k" in arg and not arg.startswith("--"):
                        keep_source = True
                    if "d" in arg and not arg.startswith("--"):
                        decompress_mode = True
                    i += 1
                    continue
            positional.append(arg)
            i += 1

        if not positional:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=[],
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    f"{base_command} requires explicit approval when operating on stdin/stdout "
                    "without explicit filesystem paths."
                ),
            )

        if spec.second_positional_output and explicit_output is None and len(positional) >= 2:
            explicit_output = positional[-1]
            positional = positional[:-1]

        input_operation: OperationType = (
            "read" if stdout_mode or keep_source or not spec.source_mutates_by_default else "write"
        )
        path_targets = [BashPathTarget(path, input_operation) for path in positional]

        if stdout_mode:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )

        output_paths: list[str] = []
        if explicit_output is not None:
            if len(positional) != 1:
                return self._path_info_factory.build(
                    base_command=base_command,
                    operation_type="write",
                    path_targets=path_targets,
                    analysis=analysis,
                    requires_manual_approval=True,
                    manual_approval_reason=(
                        f"{base_command} with an explicit output path requires explicit approval "
                        "when multiple input files are provided."
                    ),
                )
            output_paths.append(explicit_output)
        else:
            for input_path in positional:
                derived_output = self._derive_single_file_archive_output(
                    input_path=input_path,
                    suffix=spec.output_suffix,
                    decompress_mode=decompress_mode,
                )
                if derived_output is None:
                    return self._path_info_factory.build(
                        base_command=base_command,
                        operation_type="write",
                        path_targets=path_targets,
                        analysis=analysis,
                        requires_manual_approval=True,
                        manual_approval_reason=(
                            f"{base_command} requires explicit approval when the generated output "
                            "path cannot be derived safely."
                        ),
                    )
                output_paths.append(derived_output)

        path_targets.extend(BashPathTarget(path, "write") for path in output_paths)
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
        )

    def extract_jar(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        if not args:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=[],
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason="jar requires explicit approval when its mode is missing.",
            )
        mode_token = args[0].lstrip("-")
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        i = 1
        while i < len(args):
            arg = args[i]
            if arg == "-C" and i + 1 < len(args):
                target_dir = args[i + 1]
                operation = "write" if "x" in mode_token else "read"
                path_targets.append(BashPathTarget(target_dir, operation))
                if "x" not in mode_token and i + 2 < len(args):
                    target_path = args[i + 2]
                    path_targets.append(BashPathTarget(target_path, "read"))
                    i += 3
                    continue
                i += 2
                continue
            if not arg.startswith("-"):
                positional.append(arg)
            i += 1

        archive_path = positional[0] if positional else None
        if archive_path:
            archive_operation: OperationType = "read"
            if "c" in mode_token or "u" in mode_token:
                archive_operation = "write"
            path_targets.insert(0, BashPathTarget(archive_path, archive_operation))

        if "t" in mode_token and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )
        if "x" in mode_token and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    "jar extract commands require explicit approval because they can materialize "
                    "many files beyond explicit argv paths."
                ),
            )
        if ("c" in mode_token or "u" in mode_token) and archive_path:
            path_targets.extend(BashPathTarget(path, "read") for path in positional[1:])
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "jar command requires explicit approval when its archive path or mode cannot be "
                "determined safely."
            ),
        )

    def extract_rar_family(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        if not args:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=[],
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=f"{base_command} requires explicit approval when no mode is provided.",
            )
        action = args[0].lower()
        positional = [arg for arg in args[1:] if arg and not arg.startswith("-")]
        archive_path = positional[0] if positional else None
        path_targets: list[BashPathTarget] = []
        if archive_path:
            archive_operation: OperationType = "read"
            if action in {"a", "u", "d"}:
                archive_operation = "write"
            path_targets.append(BashPathTarget(archive_path, archive_operation))

        if action in {"l", "lb", "lt", "t", "p"} and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
            )
        if action in {"x", "e"} and archive_path:
            if len(positional) >= 2:
                path_targets.append(BashPathTarget(positional[1], "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    f"{base_command} extract commands require explicit approval because they can "
                    "materialize many files beyond explicit argv paths."
                ),
            )
        if action == "d" and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        if action in {"a", "u", "d"} and archive_path:
            path_targets.extend(BashPathTarget(path, "read") for path in positional[1:])
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                f"{base_command} command requires explicit approval when its archive action cannot "
                "be determined safely."
            ),
        )

    def extract_scp(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        requires_manual_approval = False
        control_flag_seen = False
        i = 0
        flags_with_args = {"-P", "-S", "-J", "-F", "-i", "-c", "-l", "-o"}
        path_flags = {"-S", "-F", "-i"}
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if arg.startswith("-") and arg != "-":
                if arg in flags_with_args and i + 1 < len(args):
                    if arg in path_flags:
                        path_targets.append(BashPathTarget(args[i + 1], "read"))
                        control_flag_seen = True
                    i += 2
                    continue
                i += 1
                continue
            positional.append(arg)
            i += 1

        if len(positional) >= 2:
            source_endpoints = positional[:-1]
            destination_endpoint = positional[-1]
            for source in source_endpoints:
                target = self._remote_classifier.build_local_target(source, "read")
                if target is not None:
                    path_targets.append(target)
                else:
                    requires_manual_approval = True
            destination_target = self._remote_classifier.build_local_target(
                destination_endpoint,
                "write",
            )
            if destination_target is not None:
                path_targets.append(destination_target)
            else:
                requires_manual_approval = True
            if control_flag_seen:
                requires_manual_approval = True
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=requires_manual_approval,
                manual_approval_reason=(
                    None if not requires_manual_approval else
                    "scp with remote endpoints or transport-control files requires explicit approval."
                ),
            )

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "scp command requires explicit approval when source or destination endpoints "
                "cannot be determined safely."
            ),
        )

    def extract_sftp(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        i = 0
        flags_with_args = {"-b", "-B", "-c", "-D", "-F", "-i", "-J", "-P", "-R", "-S", "-s", "-X"}
        local_path_flags = {"-b", "-D", "-F", "-i", "-S", "-s"}
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if arg.startswith("-") and arg != "-":
                if arg in flags_with_args and i + 1 < len(args):
                    if arg in local_path_flags:
                        path_targets.append(BashPathTarget(args[i + 1], "read"))
                    i += 2
                    continue
                i += 1
                continue
            positional.append(arg)
            i += 1

        if len(positional) >= 2:
            first, second = positional[0], positional[1]
            first_remote = self._remote_classifier.is_remote_spec(first)
            second_remote = self._remote_classifier.is_remote_spec(second)
            if first_remote and not second_remote:
                path_targets.append(BashPathTarget(second, "write"))
            elif second_remote and not first_remote:
                path_targets.append(BashPathTarget(first, "read"))
            elif not first_remote and not second_remote:
                path_targets.append(BashPathTarget(first, "read"))
                path_targets.append(BashPathTarget(second, "write"))

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "sftp commands require explicit approval because remote session semantics and "
                "batch operations cannot be determined safely from argv alone."
            ),
        )

    def extract_rclone(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        action: str | None = None
        positional: list[str] = []
        path_targets: list[BashPathTarget] = []
        requires_manual_approval = False
        i = 0
        risky_path_flags = {
            "--backup-dir", "--compare-dest", "--copy-dest", "--link-dest",
            "--files-from", "--files-from-raw", "--include-from", "--exclude-from",
            "--filter-from", "--config",
        }
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if action is None and not arg.startswith("-"):
                action = arg
                i += 1
                continue
            if arg.startswith("--"):
                flag = arg.split("=", 1)[0]
                if flag in risky_path_flags:
                    requires_manual_approval = True
                    if "=" in arg:
                        value = arg.split("=", 1)[1]
                        path_targets.append(BashPathTarget(value, "read"))
                        i += 1
                        continue
                    if i + 1 < len(args):
                        path_targets.append(BashPathTarget(args[i + 1], "read"))
                        i += 2
                        continue
                if "=" not in arg and i + 1 < len(args):
                    if flag in {"--config"}:
                        path_targets.append(BashPathTarget(args[i + 1], "read"))
                        requires_manual_approval = True
                        i += 2
                        continue
                i += 1
                continue
            if arg.startswith("-") and arg != "-":
                i += 1
                continue
            positional.append(arg)
            i += 1

        action = (action or "").lower()
        read_actions = {"ls", "lsl", "lsd", "lsf", "cat", "size", "about", "check"}
        write_actions = {"copy", "copyto", "sync", "move", "moveto"}
        destructive_actions = {"delete", "deletefile", "purge", "mkdir", "rmdir", "touch"}

        if action in read_actions:
            for endpoint in positional:
                target = self._remote_classifier.build_local_target(endpoint, "read")
                if target is not None:
                    path_targets.append(target)
                else:
                    requires_manual_approval = True
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="read",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=requires_manual_approval,
                manual_approval_reason=(
                    None if not requires_manual_approval else
                    "rclone read commands with remote endpoints require explicit approval."
                ),
            )

        if action in write_actions and len(positional) >= 2:
            for source in positional[:-1]:
                target = self._remote_classifier.build_local_target(source, "read")
                if target is not None:
                    path_targets.append(target)
                else:
                    requires_manual_approval = True
            destination_target = self._remote_classifier.build_local_target(positional[-1], "write")
            if destination_target is not None:
                path_targets.append(destination_target)
            else:
                requires_manual_approval = True
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=requires_manual_approval,
                manual_approval_reason=(
                    None if not requires_manual_approval else
                    "rclone copy/sync commands with remote endpoints require explicit approval."
                ),
            )

        if action in destructive_actions and positional:
            target = self._remote_classifier.build_local_target(positional[-1], "write")
            if target is not None:
                path_targets.append(target)
            else:
                requires_manual_approval = True
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    "rclone destructive or remote-aware commands require explicit approval."
                ),
            )

        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "rclone command requires explicit approval when its subcommand or endpoints "
                "cannot be determined safely."
            ),
        )

    def extract_cpio(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        archive_path: str | None = None
        directory_path: str | None = None
        create_mode = False
        extract_mode = False
        pass_mode = False
        list_mode = False
        after_double_dash = False
        positional: list[str] = []
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--file="):
                archive_path = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg == "--list":
                list_mode = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("--directory="):
                directory_path = arg.split("=", 1)[1]
                i += 1
                continue
            if not after_double_dash and arg in {"-F", "-O", "--file"} and i + 1 < len(args):
                archive_path = args[i + 1]
                i += 2
                continue
            if not after_double_dash and arg in {"-D", "--directory"} and i + 1 < len(args):
                directory_path = args[i + 1]
                i += 2
                continue
            if not after_double_dash and arg.startswith("-") and arg != "-":
                if "o" in arg and not arg.startswith("--"):
                    create_mode = True
                if "i" in arg and not arg.startswith("--"):
                    extract_mode = True
                if "p" in arg and not arg.startswith("--"):
                    pass_mode = True
                if "t" in arg and not arg.startswith("--"):
                    list_mode = True
                i += 1
                continue
            positional.append(arg)
            i += 1

        if list_mode:
            path_targets: list[BashPathTarget] = []
            if archive_path:
                path_targets.append(BashPathTarget(archive_path, "read"))
            if directory_path:
                path_targets.append(BashPathTarget(directory_path, "read"))
            if archive_path:
                return self._path_info_factory.build(
                    base_command=base_command,
                    operation_type="read",
                    path_targets=path_targets,
                    analysis=analysis,
                )

        if extract_mode or pass_mode:
            path_targets: list[BashPathTarget] = []
            if archive_path:
                path_targets.append(BashPathTarget(archive_path, "read"))
            if directory_path:
                path_targets.append(BashPathTarget(directory_path, "write"))
            if pass_mode and positional:
                path_targets.append(BashPathTarget(positional[-1], "write"))
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
                requires_manual_approval=True,
                manual_approval_reason=(
                    "cpio extract/pass-through commands require explicit approval because "
                    "they can materialize filesystem writes beyond explicit argv paths."
                ),
            )

        path_targets: list[BashPathTarget] = []
        if archive_path:
            path_targets.append(BashPathTarget(archive_path, "write" if create_mode else "read"))
        if directory_path:
            path_targets.append(BashPathTarget(directory_path, "write"))
        if create_mode and archive_path:
            return self._path_info_factory.build(
                base_command=base_command,
                operation_type="write",
                path_targets=path_targets,
                analysis=analysis,
            )
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="write",
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=True,
            manual_approval_reason=(
                "cpio command requires explicit approval when its archive target "
                "or write behavior cannot be determined safely."
            ),
        )

    @staticmethod
    def _extract_attached_short_option_value(arg: str, option_char: str) -> str | None:
        if not arg.startswith("-") or arg.startswith("--"):
            return None
        option_index = arg.find(option_char)
        if option_index < 0:
            return None
        attached_value = arg[option_index + 1:]
        return attached_value or None

    @staticmethod
    def _derive_single_file_archive_output(
        *,
        input_path: str,
        suffix: str,
        decompress_mode: bool,
    ) -> str | None:
        if decompress_mode:
            if not input_path.endswith(suffix):
                return None
            return input_path[: -len(suffix)]
        return f"{input_path}{suffix}"


class BashPathExtractorRegistry:
    """
    命令 -> 路径提取规则注册表。

    对照 CC PATH_EXTRACTORS，但先聚焦高频/高风险命令。
    """

    _READ_COMMANDS = {
        "cd", "ls", "find", "cat", "head", "tail", "sort", "uniq", "wc",
        "cut", "paste", "column", "tr", "file", "stat", "diff", "awk",
        "strings", "hexdump", "od", "base64", "nl", "grep", "rg", "git",
        "jq", "sha256sum", "sha1sum", "md5sum", "zipinfo", "zipnote",
    }
    _CREATE_COMMANDS = {"mkdir", "touch", "mktemp"}
    _WRITE_COMMANDS = {
        "rm", "rmdir", "mv", "cp", "sed", "tee", "install", "ln", "tar", "dd", "rsync", "cpio",
        "zip", "unzip", "7z", "7za", "7zr", "gzip", "gunzip", "xz", "unxz", "bzip2",
        "bunzip2", "zstd", "unzstd", "lz4", "jar", "bsdtar", "rar", "unrar",
        "scp", "sftp", "rclone",
    }

    def __init__(
        self,
        tokenizer: BashArgumentTokenizer | None = None,
        wrapper_stripper: BashWrapperStripper | None = None,
    ) -> None:
        self._tokenizer = tokenizer or BashArgumentTokenizer()
        self._wrapper_stripper = wrapper_stripper or BashWrapperStripper()
        self._path_info_factory = BashCommandPathInfoFactory()
        self._remote_classifier = BashRemotePathClassifier()
        self._special_extractor = BashSpecialPathExtractor(
            tokenizer=self._tokenizer,
            path_info_factory=self._path_info_factory,
            remote_classifier=self._remote_classifier,
        )

    def extract(self, command_text: str, analysis: BashAstAnalysis) -> BashCommandPathInfo | None:
        normalized = analysis.normalized_base_commands
        if not normalized:
            return self._extract_redirection_only(analysis)

        base_command = normalized[0]
        tokens = self._get_effective_argv(command_text, analysis)
        if not tokens:
            return self._extract_redirection_only(analysis)

        args = tokens[1:]
        if base_command in self._READ_COMMANDS:
            return self._extract_read_command(base_command, args, analysis)
        if base_command in self._CREATE_COMMANDS:
            if base_command == "mktemp":
                return self._special_extractor.extract_mktemp(base_command, args, analysis)
            return self._extract_simple_command(base_command, args, "create", analysis)
        if base_command in self._WRITE_COMMANDS:
            return self._extract_write_command(base_command, args, analysis)

        return self._extract_redirection_only(analysis)

    def _get_effective_argv(self, command_text: str, analysis: BashAstAnalysis) -> list[str]:
        if len(analysis.simple_commands) == 1:
            simple = analysis.simple_commands[0]
            if simple.text == command_text.strip() and simple.argv:
                stripped = self._wrapper_stripper.strip(list(simple.argv))
                if stripped:
                    return stripped
        return self._wrapper_stripper.strip(self._tokenizer.split(command_text))

    def _extract_redirection_only(self, analysis: BashAstAnalysis) -> BashCommandPathInfo | None:
        if not analysis.output_redirection_paths:
            return None
        return self._path_info_factory.build(
            base_command="<redirect>",
            operation_type="write",
            path_targets=[],
            analysis=analysis,
        )

    def _extract_simple_command(
        self,
        base_command: str,
        args: list[str],
        operation_type: OperationType,
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        paths = self._tokenizer.filter_out_flags(args)
        path_targets = [BashPathTarget(path, operation_type) for path in paths]
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type=operation_type,
            path_targets=path_targets,
            analysis=analysis,
        )

    def _extract_write_command(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        if base_command in {"mv", "cp"} and any(arg.startswith("-") for arg in args):
            return BashCommandPathInfo(
                base_command=base_command,
                operation_type="write",
                path_targets=(),
                requires_manual_approval=True,
                manual_approval_reason=(
                    f"{base_command} with flags requires manual approval to ensure path safety."
                ),
            )

        if base_command == "sed":
            paths = self._extract_sed_paths(args)
            path_targets = [BashPathTarget(path, "write") for path in paths]
            return self._build_path_info(base_command, "write", path_targets, analysis)
        if base_command == "tee":
            return self._special_extractor.extract_tee(base_command, args, analysis)
        if base_command == "install":
            return self._special_extractor.extract_install(base_command, args, analysis)
        if base_command == "ln":
            return self._special_extractor.extract_ln(base_command, args, analysis)
        if base_command == "tar":
            return self._special_extractor.extract_tar(base_command, args, analysis)
        if base_command == "bsdtar":
            return self._special_extractor.extract_tar(base_command, args, analysis)
        if base_command == "dd":
            return self._special_extractor.extract_dd(base_command, args, analysis)
        if base_command == "rsync":
            return self._special_extractor.extract_rsync(base_command, args, analysis)
        if base_command == "zip":
            return self._special_extractor.extract_zip(base_command, args, analysis)
        if base_command == "unzip":
            return self._special_extractor.extract_unzip(base_command, args, analysis)
        if base_command in {"7z", "7za", "7zr"}:
            return self._special_extractor.extract_7z_family(base_command, args, analysis)
        if base_command in {"gzip", "gunzip", "xz", "unxz", "bzip2", "bunzip2", "zstd", "unzstd", "lz4"}:
            return self._special_extractor.extract_single_file_archive(base_command, args, analysis)
        if base_command == "jar":
            return self._special_extractor.extract_jar(base_command, args, analysis)
        if base_command in {"rar", "unrar"}:
            return self._special_extractor.extract_rar_family(base_command, args, analysis)
        if base_command in {"scp"}:
            return self._special_extractor.extract_scp(base_command, args, analysis)
        if base_command in {"sftp"}:
            return self._special_extractor.extract_sftp(base_command, args, analysis)
        if base_command == "rclone":
            return self._special_extractor.extract_rclone(base_command, args, analysis)
        if base_command == "cpio":
            return self._special_extractor.extract_cpio(base_command, args, analysis)
        else:
            paths = self._tokenizer.filter_out_flags(args)
            path_targets = [BashPathTarget(path, "write") for path in paths]
            return self._build_path_info(base_command, "write", path_targets, analysis)

    def _extract_read_command(
        self,
        base_command: str,
        args: list[str],
        analysis: BashAstAnalysis,
    ) -> BashCommandPathInfo:
        if base_command in {"zipinfo", "zipnote"}:
            return self._special_extractor.extract_zip_metadata(base_command, args, analysis)
        extracted_paths: list[str]
        if base_command == "cd":
            extracted_paths = ["~"] if not args else [" ".join(args)]
        elif base_command == "ls":
            extracted_paths = self._tokenizer.filter_out_flags(args) or ["."]
        elif base_command == "find":
            extracted_paths = self._extract_find_paths(args)
        elif base_command == "grep":
            paths = self._tokenizer.parse_pattern_command(
                args,
                flags_with_args={
                    "-e", "--regexp", "-f", "--file", "--exclude", "--include",
                    "--exclude-dir", "--include-dir", "-m", "--max-count",
                    "-A", "--after-context", "-B", "--before-context", "-C", "--context",
                },
            )
            if not paths and any(flag in {"-r", "-R", "--recursive"} for flag in args):
                paths = ["."]
            extracted_paths = paths
        elif base_command == "rg":
            extracted_paths = self._tokenizer.parse_pattern_command(
                args,
                flags_with_args={
                    "-e", "--regexp", "-f", "--file", "-t", "--type",
                    "-T", "--type-not", "-g", "--glob", "-m", "--max-count",
                    "--max-depth", "-r", "--replace", "-A", "--after-context",
                    "-B", "--before-context", "-C", "--context",
                },
                defaults=["."],
            )
        elif base_command == "jq":
            extracted_paths = self._extract_jq_paths(args)
        elif base_command == "git":
            extracted_paths = self._extract_git_paths(args)
        elif base_command == "tr":
            extracted_paths = self._extract_tr_paths(args)
        elif base_command == "awk":
            extracted_paths = self._extract_awk_paths(args)
        else:
            extracted_paths = self._tokenizer.filter_out_flags(args)

        path_targets = [BashPathTarget(path, "read") for path in extracted_paths]
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type="read",
            path_targets=path_targets,
            analysis=analysis,
        )

    def _build_path_info(
        self,
        base_command: str,
        operation_type: OperationType,
        path_targets: list[BashPathTarget],
        analysis: BashAstAnalysis,
        *,
        requires_manual_approval: bool = False,
        manual_approval_reason: str | None = None,
    ) -> BashCommandPathInfo:
        return self._path_info_factory.build(
            base_command=base_command,
            operation_type=operation_type,
            path_targets=path_targets,
            analysis=analysis,
            requires_manual_approval=requires_manual_approval,
            manual_approval_reason=manual_approval_reason,
        )

    def _extract_find_paths(self, args: list[str]) -> list[str]:
        paths: list[str] = []
        path_flags = {
            "-newer", "-anewer", "-cnewer", "-mnewer", "-samefile",
            "-path", "-wholename", "-ilname", "-lname", "-ipath", "-iwholename",
        }
        found_non_global_flag = False
        after_double_dash = False

        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if after_double_dash:
                paths.append(arg)
                i += 1
                continue
            if arg == "--":
                after_double_dash = True
                i += 1
                continue
            if arg.startswith("-"):
                if arg in {"-H", "-L", "-P"}:
                    i += 1
                    continue
                found_non_global_flag = True
                if arg in path_flags and i + 1 < len(args):
                    paths.append(args[i + 1])
                    i += 2
                    continue
                i += 1
                continue
            if not found_non_global_flag:
                paths.append(arg)
            i += 1

        return paths or ["."]

    def _extract_jq_paths(self, args: list[str]) -> list[str]:
        paths: list[str] = []
        flags_with_args = {
            "-e", "--expression", "-f", "--from-file", "--arg", "--argjson",
            "--slurpfile", "--rawfile", "--args", "--jsonargs", "-L",
            "--library-path", "--indent", "--tab",
        }
        filter_found = False
        after_double_dash = False
        i = 0
        while i < len(args):
            arg = args[i]
            if arg is None:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("-"):
                flag = arg.split("=")[0]
                if flag in {"-e", "--expression"}:
                    filter_found = True
                if flag in flags_with_args and "=" not in arg and i + 1 < len(args):
                    i += 2
                    continue
                i += 1
                continue
            if not filter_found:
                filter_found = True
            else:
                paths.append(arg)
            i += 1
        return paths

    def _extract_git_paths(self, args: list[str]) -> list[str]:
        if len(args) >= 1 and args[0] == "diff" and "--no-index" in args:
            file_paths = self._tokenizer.filter_out_flags(args[1:])
            return file_paths[:2]
        return []

    def _extract_awk_paths(self, args: list[str]) -> list[str]:
        paths: list[str] = []
        after_double_dash = False
        script_consumed = False
        i = 0
        while i < len(args):
            arg = args[i]
            if not arg:
                i += 1
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                i += 1
                continue
            if not after_double_dash and arg.startswith("-"):
                if arg in {"-f", "--file"} and i + 1 < len(args):
                    paths.append(args[i + 1])  # awk 脚本文件本身需要校验
                    script_consumed = True
                    i += 2
                    continue
                if arg in {"-v", "-F"} and i + 1 < len(args):
                    i += 2
                    continue
                i += 1
                continue
            if not script_consumed:
                script_consumed = True
                i += 1
                continue
            paths.append(arg)
            i += 1
        return paths

    def _extract_tr_paths(self, args: list[str]) -> list[str]:
        has_delete = any(
            arg == "-d" or arg == "--delete" or (arg.startswith("-") and "d" in arg)
            for arg in args
        )
        non_flags = self._tokenizer.filter_out_flags(args)
        return non_flags[1:] if has_delete else non_flags[2:]

    def _extract_sed_paths(self, args: list[str]) -> list[str]:
        paths: list[str] = []
        skip_next = False
        script_found = False
        after_double_dash = False
        capture_next_as_script_file = False

        for arg in args:
            if skip_next:
                if capture_next_as_script_file:
                    paths.append(arg)
                    capture_next_as_script_file = False
                skip_next = False
                continue
            if not arg:
                continue
            if not after_double_dash and arg == "--":
                after_double_dash = True
                continue
            if not after_double_dash and arg.startswith("-"):
                if arg in {"-f", "--file"}:
                    skip_next = True
                    script_found = True
                    capture_next_as_script_file = True
                elif arg in {"-e", "--expression"}:
                    skip_next = True
                    script_found = True
                elif "e" in arg or "f" in arg:
                    script_found = True
                continue
            if not script_found:
                script_found = True
                continue
            paths.append(arg)

        return paths


class BashPathSyntaxGuard:
    """识别无法安全静态解析的路径语法。"""

    _PERCENT_ENV_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")

    def get_manual_approval_reason(self, path_info: BashCommandPathInfo) -> str | None:
        for target in path_info.path_targets:
            if self._contains_shell_expansion(target.raw_path):
                if target.target_source == "redirection":
                    return (
                        "Shell expansion syntax in redirection targets requires explicit approval "
                        "because the write path cannot be determined safely."
                    )
                return (
                    "Shell expansion syntax in filesystem path arguments requires explicit approval "
                    "because the target path cannot be determined safely."
                )
        return None

    def _contains_shell_expansion(self, raw_path: str) -> bool:
        stripped = raw_path.strip()
        if not stripped:
            return False

        scanner = BashPathLexicalScanner(stripped)
        if self._contains_parameter_like_expansion(scanner):
            return True
        if self._contains_unquoted_dynamic_tilde(scanner):
            return True
        if self._contains_unquoted_extglob(scanner):
            return True
        if self._contains_unquoted_glob(scanner):
            return True
        if self._contains_unquoted_brace_expansion(scanner):
            return True
        return False

    def _contains_parameter_like_expansion(self, scanner: "BashPathLexicalScanner") -> bool:
        for index, char in enumerate(scanner.text):
            if scanner.is_single(index) or scanner.is_escaped(index):
                continue
            if char == "`":
                return True
            if char == "$":
                next_char = scanner.text[index + 1] if index + 1 < len(scanner.text) else ""
                if next_char in {"(", "{"}:
                    return True
                if next_char.isalpha() or next_char == "_":
                    return True
            if char == "%" and not scanner.is_double(index):
                end_index = scanner.text.find("%", index + 1)
                if end_index > index + 1:
                    if any(
                        scanner.is_single(inner_idx) or scanner.is_double(inner_idx)
                        for inner_idx in range(index + 1, end_index)
                    ):
                        continue
                    candidate = scanner.text[index + 1:end_index]
                    if self._PERCENT_ENV_RE.fullmatch(candidate):
                        return True
        return False

    def _contains_unquoted_dynamic_tilde(self, scanner: "BashPathLexicalScanner") -> bool:
        if (
            not scanner.text
            or not scanner.is_unquoted(0)
            or scanner.is_escaped(0)
            or scanner.text[0] != "~"
        ):
            return False
        next_char = scanner.text[1] if len(scanner.text) > 1 else ""
        if next_char in {"+", "-"}:
            if len(scanner.text) == 2:
                return True
            tail = scanner.text[2:]
            if not tail:
                return True
            if tail[0].isdigit():
                digit_end = 0
                while digit_end < len(tail) and tail[digit_end].isdigit():
                    digit_end += 1
                return digit_end == len(tail) or tail[digit_end] == "/"
            return tail[0] == "/"
        if next_char.isdigit():
            digit_end = 1
            while digit_end < len(scanner.text) and scanner.text[digit_end].isdigit():
                digit_end += 1
            return digit_end == len(scanner.text) or scanner.text[digit_end] == "/"
        return False

    def _contains_unquoted_extglob(self, scanner: "BashPathLexicalScanner") -> bool:
        index = 0
        while index < len(scanner.text) - 1:
            if not scanner.is_unquoted(index) or scanner.is_escaped(index):
                index += 1
                continue
            if (
                scanner.text[index] in {"@", "!", "+", "?", "*"}
                and scanner.text[index + 1] == "("
                and scanner.is_unquoted(index + 1)
                and not scanner.is_escaped(index + 1)
            ):
                return True
            index += 1
        return False

    def _contains_unquoted_glob(self, scanner: "BashPathLexicalScanner") -> bool:
        for index, char in enumerate(scanner.text):
            if not scanner.is_unquoted(index) or scanner.is_escaped(index):
                continue
            if char in {"*", "?"}:
                if index + 1 < len(scanner.text) and scanner.text[index + 1] == "(":
                    continue
                return True
            if char == "[" and scanner.has_unquoted_closing_bracket(index + 1):
                return True
        return False

    def _contains_unquoted_brace_expansion(self, scanner: "BashPathLexicalScanner") -> bool:
        index = 0
        while index < len(scanner.text):
            if (
                scanner.text[index] != "{"
                or not scanner.is_unquoted(index)
                or scanner.is_escaped(index)
            ):
                index += 1
                continue
            end_index = scanner.find_matching_unquoted_brace(index + 1)
            if end_index == -1:
                index += 1
                continue
            content = scanner.text[index + 1:end_index]
            if "," in content or ".." in content:
                return True
            index = end_index + 1
        return False


class BashPathLexicalScanner:
    """按 shell quoting / escaping 规则扫描路径片段。"""

    def __init__(self, text: str) -> None:
        self.text = text
        self._states: list[str] = []
        self._escaped: list[bool] = []
        self._scan()

    def is_unquoted(self, index: int) -> bool:
        return self._states[index] == "unquoted"

    def is_single(self, index: int) -> bool:
        return self._states[index] == "single"

    def is_double(self, index: int) -> bool:
        return self._states[index] == "double"

    def is_escaped(self, index: int) -> bool:
        return self._escaped[index]

    def has_unquoted_closing_bracket(self, start_idx: int) -> bool:
        for index in range(start_idx, len(self.text)):
            if not self.is_unquoted(index) or self.is_escaped(index):
                continue
            if self.text[index] == "]":
                return True
        return False

    def find_matching_unquoted_brace(self, start_idx: int) -> int:
        depth = 0
        for index in range(start_idx, len(self.text)):
            if not self.is_unquoted(index) or self.is_escaped(index):
                continue
            if self.text[index] == "{":
                depth += 1
            elif self.text[index] == "}":
                if depth == 0:
                    return index
                depth -= 1
        return -1

    def _scan(self) -> None:
        in_single = False
        in_double = False
        next_escaped = False
        for char in self.text:
            state = "double" if in_double else "single" if in_single else "unquoted"
            self._states.append(state)
            self._escaped.append(next_escaped)

            if next_escaped:
                next_escaped = False
                continue
            if char == "\\" and not in_single:
                next_escaped = True
                continue
            if char == "'" and not in_double:
                in_single = not in_single
                continue
            if char == '"' and not in_single:
                in_double = not in_double


class BashDangerousPathChecker:
    """危险删除路径检查。"""

    _CRITICAL_PATHS = frozenset({
        "/", "/etc", "/usr", "/bin", "/sbin", "/var", "/home", "/root",
        "/boot", "/dev", "/proc", "/sys",
    })

    def check(self, path_info: BashCommandPathInfo, cwd: str) -> AuthorizationDecision | None:
        if path_info.base_command not in {"rm", "rmdir"}:
            return None

        for target in path_info.path_targets:
            resolved = self._resolve_path(target.raw_path, cwd)
            if resolved in self._CRITICAL_PATHS:
                return AuthorizationDecision(
                    behavior="ask",
                    message=(
                        f"Dangerous {path_info.base_command} operation detected on critical path: "
                        f"{resolved}"
                    ),
                    policy_id="dangerous_removal_path",
                    ask_prompt=(
                        f"Dangerous removal target detected: {resolved}\n"
                        "This requires explicit approval."
                    ),
                )
        return None

    @staticmethod
    def _resolve_path(raw_path: str, cwd: str) -> str:
        expanded = os.path.expanduser(raw_path.strip("\"'"))
        absolute = expanded if os.path.isabs(expanded) else os.path.join(cwd, expanded)
        return os.path.realpath(absolute)


class BashPathSecurityAnalyzer:
    """
    Bash 路径安全分析器。

    负责将“命令字符串 + AST 结构摘要”映射为路径授权决策。
    """

    def __init__(
        self,
        extractor_registry: BashPathExtractorRegistry | None = None,
        dangerous_path_checker: BashDangerousPathChecker | None = None,
        path_syntax_guard: BashPathSyntaxGuard | None = None,
    ) -> None:
        self._extractor_registry = extractor_registry or BashPathExtractorRegistry()
        self._dangerous_path_checker = dangerous_path_checker or BashDangerousPathChecker()
        self._path_syntax_guard = path_syntax_guard or BashPathSyntaxGuard()

    def authorize_segment(
        self,
        *,
        command: str,
        analysis: BashAstAnalysis,
        cwd: str,
        policy: object | None,
        compound_has_cd: bool,
    ) -> AuthorizationDecision:
        path_info = self._extractor_registry.extract(command, analysis)
        if path_info is None:
            return AuthorizationDecision(behavior="allow")

        if compound_has_cd and path_info.operation_type != "read":
            reason = (
                "Commands that change directories and perform write operations require "
                "explicit approval to ensure paths are evaluated correctly."
            )
            return AuthorizationDecision(
                behavior="ask",
                message=reason,
                policy_id="compound_cd_write",
                ask_prompt=reason,
            )

        syntax_reason = self._path_syntax_guard.get_manual_approval_reason(path_info)
        if syntax_reason is not None:
            return AuthorizationDecision(
                behavior="ask",
                message=syntax_reason,
                policy_id="bash_path_validator",
                ask_prompt=syntax_reason,
            )

        dangerous_decision = self._dangerous_path_checker.check(path_info, cwd)
        if dangerous_decision is not None:
            return dangerous_decision

        authorize_path = getattr(policy, "authorize_path", None)
        if authorize_path is None:
            return AuthorizationDecision(behavior="allow")

        for target in path_info.path_targets:
            resolved_path = self._resolve_path(target.raw_path, cwd)
            decision = authorize_path(
                resolved_path,
                is_write=target.operation_type in {"write", "create"},
            )
            if decision.behavior != "allow":
                return decision

        if path_info.requires_manual_approval:
            reason = path_info.manual_approval_reason or "Command requires manual approval."
            return AuthorizationDecision(
                behavior="ask",
                message=reason,
                policy_id="bash_path_validator",
                ask_prompt=reason,
            )

        return AuthorizationDecision(behavior="allow")

    @staticmethod
    def _resolve_path(raw_path: str, cwd: str) -> str:
        expanded = os.path.expanduser(raw_path.strip("\"'"))
        absolute = expanded if os.path.isabs(expanded) else os.path.join(cwd, expanded)
        return os.path.realpath(absolute)
