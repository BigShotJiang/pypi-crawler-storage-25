"""
tools/bash — BashRuntimeTool 包

BashRuntimeTool 是工具体系 P4 工具，支持 Shell 命令执行、后台任务、cwd 持久化。
"""

from .tool import BashRuntimeTool

__all__ = ["BashRuntimeTool"]
