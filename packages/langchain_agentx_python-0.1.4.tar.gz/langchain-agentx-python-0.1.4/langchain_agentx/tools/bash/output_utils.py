"""
tools/bash/output_utils.py — BashRuntimeTool 模块5：结果输出辅助能力

职责：
    承接 Bash 结果展示层里与“输出内容形态”相关的通用处理，避免这些细节继续堆在
    `tool.py` 或 `result_presenter.py` 中。

在整体链路中的位置：
    - `invoke()` 之后、`present()` 之前使用
    - 由 `result_presenter.py` 调用，负责把 stdout 中的特殊输出形态转成结构化结果

当前包含：
    1. image data URI 检测与解析
    2. 基于 Pillow 软依赖的可选 resize/downsample
    3. Bash 图片输出 artifact 构造

与 CC 对照：
    对应 CC `utils.ts` 中的 `isImageOutput()`、`parseDataUri()`、
    `resizeShellImageOutput()` 等输出辅助逻辑。
    当前为基础版：先把图片输出识别、artifact 化和可选缩放立住，不复制完整 UI 层。
"""

from __future__ import annotations

import base64
import io
import re
from dataclasses import dataclass

from langchain_agentx.tool_runtime.models import ToolArtifact

_IMAGE_DATA_URI_RE = re.compile(
    r"^data:(image/[a-z0-9.+_-]+);base64,([A-Za-z0-9+/=\s]+)$",
    re.IGNORECASE,
)

_MAX_IMAGE_BYTES = 5 * 1024 * 1024
_MAX_IMAGE_DIMENSION = 2048


@dataclass(frozen=True)
class BashImageArtifact:
    """图片输出的结构化表示。"""

    artifact: ToolArtifact
    media_type: str
    width: int | None = None
    height: int | None = None
    size_bytes: int | None = None
    was_resized: bool = False


def is_image_output(content: str) -> bool:
    """判断 stdout 是否为 image data URI。"""
    return _IMAGE_DATA_URI_RE.match(content.strip()) is not None


def parse_image_data_uri(content: str) -> tuple[str, str] | None:
    """
    解析 image data URI，返回 `(media_type, base64_payload)`。

    返回 None 表示不是受支持的 image data URI。
    """
    match = _IMAGE_DATA_URI_RE.match(content.strip())
    if not match:
        return None
    return match.group(1), re.sub(r"\s+", "", match.group(2))


class BashOutputArtifactBuilder:
    """
    Bash 输出 artifact 构造器。

    只负责把 stdout 中的特殊输出识别为结构化 artifact；
    不负责 summary/hints/payload 的展示语义。
    """

    def build_image_artifact(self, stdout: str) -> BashImageArtifact | None:
        parsed = parse_image_data_uri(stdout)
        if parsed is None:
            return None

        media_type, payload = parsed
        try:
            raw = base64.b64decode(payload, validate=True)
        except Exception:
            return None

        optimized = self._maybe_resize_image(raw=raw, media_type=media_type)
        encoded = base64.b64encode(optimized.data).decode("ascii")
        data_uri = f"data:{optimized.media_type};base64,{encoded}"
        return BashImageArtifact(
            artifact=ToolArtifact(
                uri=data_uri,
                media_type=optimized.media_type,
                description="Image artifact emitted by bash command output",
            ),
            media_type=optimized.media_type,
            width=optimized.width,
            height=optimized.height,
            size_bytes=len(optimized.data),
            was_resized=optimized.was_resized,
        )

    def _maybe_resize_image(self, *, raw: bytes, media_type: str) -> "_ImageOptimizationResult":
        """
        在 Pillow 可用时对图片做轻量压缩/缩放。

        目标不是强依赖图片栈，而是在环境支持时减少超大图片对上下文与后续传输的压力。
        """
        try:
            from PIL import Image  # type: ignore[import]
        except Exception:
            return _ImageOptimizationResult(
                data=raw,
                media_type=media_type,
                width=None,
                height=None,
                was_resized=False,
            )

        try:
            with Image.open(io.BytesIO(raw)) as image:
                width, height = image.size
                needs_resize = (
                    len(raw) > _MAX_IMAGE_BYTES
                    or max(width, height) > _MAX_IMAGE_DIMENSION
                )
                if not needs_resize:
                    return _ImageOptimizationResult(
                        data=raw,
                        media_type=media_type,
                        width=width,
                        height=height,
                        was_resized=False,
                    )

                resized = image.copy()
                resized.thumbnail((_MAX_IMAGE_DIMENSION, _MAX_IMAGE_DIMENSION))

                buffer = io.BytesIO()
                target_format = self._pil_format_for_media_type(media_type)
                save_kwargs: dict[str, int | bool] = {}
                if target_format in {"JPEG", "WEBP"}:
                    save_kwargs = {"quality": 85, "optimize": True}
                elif target_format == "PNG":
                    save_kwargs = {"optimize": True}

                resized.save(buffer, format=target_format, **save_kwargs)
                resized_width, resized_height = resized.size
                optimized_bytes = buffer.getvalue()
                optimized_media_type = self._media_type_for_pil_format(
                    target_format, fallback=media_type
                )
                return _ImageOptimizationResult(
                    data=optimized_bytes,
                    media_type=optimized_media_type,
                    width=resized_width,
                    height=resized_height,
                    was_resized=True,
                )
        except Exception:
            return _ImageOptimizationResult(
                data=raw,
                media_type=media_type,
                width=None,
                height=None,
                was_resized=False,
            )

    @staticmethod
    def _pil_format_for_media_type(media_type: str) -> str:
        media_type = media_type.lower()
        return {
            "image/jpeg": "JPEG",
            "image/jpg": "JPEG",
            "image/png": "PNG",
            "image/gif": "GIF",
            "image/webp": "WEBP",
        }.get(media_type, "PNG")

    @staticmethod
    def _media_type_for_pil_format(pil_format: str, *, fallback: str) -> str:
        return {
            "JPEG": "image/jpeg",
            "PNG": "image/png",
            "GIF": "image/gif",
            "WEBP": "image/webp",
        }.get(pil_format.upper(), fallback)


@dataclass(frozen=True)
class _ImageOptimizationResult:
    """内部图片优化结果。"""

    data: bytes
    media_type: str
    width: int | None
    height: int | None
    was_resized: bool
