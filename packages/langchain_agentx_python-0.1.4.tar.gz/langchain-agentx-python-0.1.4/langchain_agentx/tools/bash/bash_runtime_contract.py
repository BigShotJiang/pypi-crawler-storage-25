"""
bash_runtime_contract.py — Bash 跨平台运行时冻结契约（只读常量）

职责：
    集中记录 Shell 环境变量解析顺序、cwd 双轨策略、Windows 持久会话默认值等
    **与 CC/exec-plan 对齐的冻结项**，供 `shell_locator`、`BashBackend` 与 CR 对齐；
    避免散落在多文件中的口头约定。

链路位置：
    不参与 BashBackend 热路径；`shell_locator` 导入 **SHELL_ENV_PRECEDENCE**；
    `BashBackend.__init__` 的 win32 持久会话策略与本模块 **WIN32_DEFAULT_USE_PERSISTENT_SESSION**
    注释一致。

当前裁剪范围：
    不包含 Shell 解析、Popen、cwd 文件或 fd3 实现；不包含对 CC 源码的导入。

设计 SSOT：
    docs/design-docs/tool-design/bash-tool-cross-platform.md（§1.1–§1.4、§3.0）

CC 对照（实施前阅读，路径相对 CC 检出 src/）：
    utils/Shell.ts — findSuitableShell、spawn 与 SHELL 环境
    utils/shell/bashProvider.ts — shellCwdFilePath / cwdFilePath 双轨
"""

from __future__ import annotations

#: 显式覆盖 POSIX shell 可执行文件时，环境变量尝试顺序（先声明者优先；逐项校验见 SSOT §1.2）。
SHELL_ENV_PRECEDENCE: tuple[str, ...] = (
    "LANGCHAIN_AGENTX_SHELL",
    "CLAUDE_CODE_SHELL",
    "SHELL",
)

#: Linux/Unix 上 cwd 回传冻结策略（须保持 fd3 + pass_fds，不得未经 RFC 改为仅文件）。
CWD_STRATEGY_POSIX = "fd3_pass_fds"

#: Windows 上 cwd 回传目标策略（临时文件 + pwd -P；见 `cwd_reporter.py` / exec-plan）。
CWD_STRATEGY_WIN32 = "temp_file_pwd_p"

#: Windows 上 **默认** 关闭真持久 bash 会话（exec-plan：直至持久会话冒烟通过后再评估默认值）。
WIN32_DEFAULT_USE_PERSISTENT_SESSION = False
