"""
tools/bash/models.py — BashRuntimeTool 输入输出数据模型

对应 CC BashTool.tsx 的 inputSchema / outputSchema。
纯 Pydantic 数据模型，无 I/O，无框架依赖。
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class BashToolInput(BaseModel):
    """
    BashRuntimeTool 输入参数。

    对应 CC inputSchema。
    """

    command: str = Field(
        ...,
        description="The bash command to execute",
    )
    timeout: int | None = Field(
        None,
        gt=0,
        description=(
            "Optional timeout in seconds (max 600). "
            "Defaults to 120 seconds if not specified."
        ),
    )
    description: str | None = Field(
        None,
        description=(
            "Clear, concise description of what this command does in active voice. "
            "For simple commands keep it brief (5-10 words). "
            "For complex or piped commands add enough context to clarify intent."
        ),
    )
    run_in_background: bool = Field(
        False,
        description=(
            "Set to true to run this command in the background. "
            "Use this when you don't need the result immediately. "
            "A task_id is returned; output is written to a file you can read later."
        ),
    )
    dangerously_disable_sandbox: bool = Field(
        False,
        description=(
            "Request to bypass sandbox execution for this command. "
            "This only takes effect when the runtime explicitly allows unsandboxed execution."
        ),
    )


class BashToolOutput(BaseModel):
    """
    BashRuntimeTool 内部执行结果（对应 CC outputSchema）。

    由 invoke() 返回，传递给 after_invoke() 和 present()。
    """

    stdout: str
    """命令输出（stderr 已合并进 stdout）。"""

    interrupted: bool
    """是否因超时或外部中断而提前终止。"""

    exit_code: int
    """命令退出码。"""

    background_task_id: str | None = None
    """后台任务 ID（仅 run_in_background=True 时有值）。"""

    background_output_path: str | None = None
    """后台任务输出文件路径（模型可用 Read 工具读取）。"""

    task_mode: str = "foreground"
    """任务模式：foreground / background。"""

    task_status: str = "completed"
    """任务状态：running / completed / failed / interrupted。"""

    task_exit_code: int | None = None
    """统一任务协议退出码（前后台共用）。"""

    auto_backgrounded: bool = False
    """是否由自动后台化策略触发。"""

    return_code_interpretation: str | None = None
    """
    特殊退出码的语义解释。
    例如 grep 返回 1 = 无匹配（非错误），会在此字段给出说明。
    对应 CC returnCodeInterpretation。
    """

    no_output_expected: bool = False
    """
    命令预期不产生输出（mv/cp/rm 等），成功时 present() 显示 "Done"。
    对应 CC noOutputExpected。
    """

    destructive_warning: str | None = None
    """
    危险命令警告文本（非阻断）。
    detect_destructive_patterns() 检测到危险模式时设置，在 present() 中注入到 hints。
    """

    sandboxed: bool = False
    """本次命令是否在沙箱模式下执行。"""

    sandbox_bypass_reason: str | None = None
    """未走沙箱时的原因说明（如 excluded command / explicit override）。"""

    sandbox_temp_dir: str | None = None
    """沙箱注入的 TMPDIR 路径（基础版沙箱使用独立临时目录）。"""

    sandbox_violation_message: str | None = None
    """沙箱执行返回的结构化 violation 信息。"""

    overflow_file: str | None = None
    """超大 stdout 落盘路径（完整内容），与 output_truncated 配合使用。"""

    output_truncated: bool = False
    """stdout 是否已截断，完整内容见 overflow_file。"""

    observability: dict[str, Any] | None = None
    """结构化可观测数据（事件摘要/决策归因），供 UI/CLI/日志多端消费。"""
