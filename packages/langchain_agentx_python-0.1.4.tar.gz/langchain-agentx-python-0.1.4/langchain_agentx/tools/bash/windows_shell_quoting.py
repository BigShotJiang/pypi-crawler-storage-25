"""
windows_shell_quoting.py — Windows CMD 风格重定向纠偏（POSIX shell 内）

职责：
    将误入 Git Bash 的 **`>nul` / `2>nul` / `&>nul`** 等改写为 **`/dev/null`**，避免在当前目录
    生成保留名 **`nul`** 文件（与 CC `utils/bash/shellQuoting.ts::rewriteWindowsNullRedirect` 同思路）。

链路位置：
    `BashBackend` 在把用户 `command` 拼进 `-c` 包装脚本 **之前** 调用 **`rewrite_windows_null_redirect`**。

当前裁剪范围：
    不解析引号内字面量（与 CC 一致：极少数误伤可接受）；非 win32 默认整段 **no-op**。

参考：
    anthropics/claude-code 相关 issue（`nul` 保留设备名、`shellQuoting`）；设计 SSOT
    docs/design-docs/tool-design/bash-tool-cross-platform.md Phase 3。
"""

from __future__ import annotations

import re
import sys

# 与 CC 描述对齐：可选 fd、`&`、`>` 重复、空白，后跟 **nul** 整词（排除 `null`、`nul.txt` 等）。
# 前瞻：nul 后须为分隔/行尾/管道等，避免匹配 `nul.txt` 中的 `nul`。
_NUL_REDIRECT_RE = re.compile(
    r"(\d?&?>+)\s*nul(?=\s|$|[|&;)'\"`]|\\|\n|\r)",
    re.IGNORECASE,
)


def rewrite_windows_null_redirect(
    command: str,
    *,
    _platform: str | None = None,
) -> str:
    """
    将 CMD 风格 `nul` 重定向改为 `/dev/null`。

    `_platform` 仅供单测注入；默认使用 **`sys.platform`**（仅 **`win32`** 时改写）。
    """
    plat = sys.platform if _platform is None else _platform
    if plat != "win32":
        return command
    return _NUL_REDIRECT_RE.sub(r"\1/dev/null", command)
