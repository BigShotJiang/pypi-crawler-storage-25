"""
tools/bash/observability.py — BashRuntimeTool 可观测性协议与多端投影器

目标：
    - 标准化 decision trace / execution events schema（P1）
    - 统一 trace_context（thread/run/tool_call）
    - 供 UI/CLI/日志消费者做稳定投影（Phase 5）
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from langchain_agentx.tool_runtime.models import ToolExecutionContext
from langchain_agentx.observability.replay.store import (
    DECISION_LAYERS,
    REASON_CODES,
    sample_events,
    sanitize_value,
)

SCHEMA_VERSION = "bash-observability/v1"


@dataclass(frozen=True)
class TraceContext:
    thread_id: str | None
    run_id: str | None
    tool_call_id: str | None
    tool_name: str | None

    @classmethod
    def from_ctx(cls, ctx: ToolExecutionContext) -> "TraceContext":
        return cls(
            thread_id=ctx.thread_id,
            run_id=ctx.run_id,
            tool_call_id=ctx.tool_call_id,
            tool_name=ctx.tool_name,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "thread_id": self.thread_id,
            "run_id": self.run_id,
            "tool_call_id": self.tool_call_id,
            "tool_name": self.tool_name,
        }


class BashEventBuffer:
    """最小事件流缓冲：提供 seq + ts_ms + event。"""

    def __init__(self, *, trace_context: TraceContext, scenario: str) -> None:
        self._trace_context = trace_context
        self._scenario = scenario
        self._seq = 0
        self._events: list[dict[str, Any]] = []

    def add(self, event: str, **payload: Any) -> None:
        self._seq += 1
        self._events.append(
            {
                "seq": self._seq,
                "ts_ms": int(time.time() * 1000),
                "event": event,
                **payload,
            }
        )

    def to_observability(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "scenario": self._scenario,
            "trace_context": self._trace_context.to_dict(),
            "events": self._events,
        }


def build_decision_observability(
    *,
    trace: list[dict[str, Any]],
    trace_context: TraceContext,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_layer_dict": sorted(DECISION_LAYERS),
        "trace_context": trace_context.to_dict(),
        "decision_trace": trace,
    }


def finalize_observability_payload(
    payload: dict[str, Any],
    *,
    sample_limit: int = 200,
) -> dict[str, Any]:
    cleaned = sanitize_value(payload)
    events = cleaned.get("events")
    if isinstance(events, list):
        cleaned["events"] = sample_events(events, limit=sample_limit)
    cleaned.setdefault("reason_code_dict", sorted(REASON_CODES))
    return cleaned


def project_for_cli(observability: dict[str, Any] | None) -> list[str]:
    if not observability:
        return []
    lines: list[str] = []
    for e in observability.get("events", []):
        payload = {k: v for k, v in e.items() if k not in {"seq", "event", "ts_ms"}}
        lines.append(
            f"[{e.get('seq')}] {e.get('event')} ts={e.get('ts_ms')} payload={payload}"
        )
    return lines


def project_for_ui(observability: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not observability:
        return []
    cards: list[dict[str, Any]] = []
    for e in observability.get("events", []):
        cards.append(
            {
                "type": "runtime_event",
                "title": e.get("event"),
                "seq": e.get("seq"),
                "ts_ms": e.get("ts_ms"),
                "payload": {k: v for k, v in e.items() if k not in {"seq", "event", "ts_ms"}},
            }
        )
    return cards


def project_for_log(
    *,
    observability: dict[str, Any] | None,
    decision_trace: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "trace_context": (observability or {}).get("trace_context"),
        "scenario": (observability or {}).get("scenario"),
        "events": (observability or {}).get("events", []),
        "decision_trace": decision_trace or [],
    }

