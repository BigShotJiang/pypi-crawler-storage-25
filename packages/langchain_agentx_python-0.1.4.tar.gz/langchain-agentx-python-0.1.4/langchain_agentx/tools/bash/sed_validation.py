"""
tools/bash/sed_validation.py — BashRuntimeTool 模块2：sed 命令安全与工作流判定

职责：
    将 `sed` 从普通 Bash 写命令里解耦出来，决定它应该走哪条执行路径：
    1. 普通非原地 `sed`：继续走原有 Bash 权限链
    2. 可稳定预览的 simple `sed -i`：进入 preview -> confirm -> apply
    3. 含危险语义或无法稳定预览的 `sed -i`：保守 ask

核心判定点：
    - 是否为 in-place edit（`-i` / `--in-place`）
    - substitution flags 中是否包含 `e/E/w/W` 等危险能力
    - 是否能够通过 `sed_edit_parser.py` 生成确定性 preview

与 `tool.py` 的关系：
    `tool.py` 负责编排工作流和暂存 preview 结果；
    本文件只回答“这个 sed 命令是否安全、是否可预览、是否必须人工审批”。

与 CC 对照：
    对应 CC `sedValidation.ts` 的基础版能力，当前只覆盖模块 2 需要的高价值分支。
"""

from __future__ import annotations

import re
import shlex
from dataclasses import dataclass

from .sed_edit_parser import BashSedEditParser, SedEditInfo


@dataclass(frozen=True)
class BashSedCommandCheck:
    is_sed: bool
    is_in_place: bool
    requires_manual_approval: bool
    reason: str | None = None
    edit_info: SedEditInfo | None = None


class BashSedCommandValidator:
    """判断 sed 是否能走 preview/apply，或必须人工审批。"""

    _DANGEROUS_SUBST_FLAGS = frozenset({"e", "E", "w", "W"})

    def __init__(self, parser: BashSedEditParser | None = None) -> None:
        self._parser = parser or BashSedEditParser()

    def evaluate(self, command: str) -> BashSedCommandCheck:
        tokens = self._split(command)
        if not tokens or tokens[0] != "sed":
            return BashSedCommandCheck(False, False, False)

        in_place = self._has_in_place_flag(tokens[1:])
        expressions = self._collect_inline_expressions(tokens[1:])
        if self._contains_dangerous_expression(expressions):
            return BashSedCommandCheck(
                is_sed=True,
                is_in_place=in_place,
                requires_manual_approval=True,
                reason=(
                    "sed command requires explicit approval because it contains potentially "
                    "dangerous write/execute operations."
                ),
            )

        if not in_place:
            return BashSedCommandCheck(
                is_sed=True,
                is_in_place=False,
                requires_manual_approval=False,
            )

        edit_info = self._parser.parse(command)
        if edit_info is None:
            return BashSedCommandCheck(
                is_sed=True,
                is_in_place=True,
                requires_manual_approval=True,
                reason=(
                    "sed -i command requires explicit approval because a deterministic preview "
                    "cannot be generated safely."
                ),
            )
        return BashSedCommandCheck(
            is_sed=True,
            is_in_place=True,
            requires_manual_approval=False,
            edit_info=edit_info,
        )

    @staticmethod
    def _split(command: str) -> list[str]:
        try:
            return shlex.split(command)
        except ValueError:
            return command.split()

    @staticmethod
    def _has_in_place_flag(args: list[str]) -> bool:
        return any(arg in {"-i", "--in-place"} or arg.startswith("-i") for arg in args)

    def _collect_inline_expressions(self, args: list[str]) -> list[str]:
        expressions: list[str] = []
        i = 0
        while i < len(args):
            arg = args[i]
            if arg in {"-e", "--expression"} and i + 1 < len(args):
                expressions.append(args[i + 1])
                i += 2
                continue
            if arg.startswith("--expression="):
                expressions.append(arg.split("=", 1)[1])
                i += 1
                continue
            if arg.startswith("-"):
                i += 1
                continue
            if not expressions:
                expressions.append(arg)
            i += 1
        return expressions

    def _contains_dangerous_expression(self, expressions: list[str]) -> bool:
        for expression in expressions:
            parsed = self._parser.parse(f"sed -i {shlex.quote(expression)} dummy.txt")
            if parsed is None:
                dangerous_flags = self._extract_substitution_flags(expression)
                if any(flag in self._DANGEROUS_SUBST_FLAGS for flag in dangerous_flags):
                    return True
                if re.search(r"(^|[;\s])[weWE](?:[\s]|$)", expression):
                    return True
                continue
            if any(flag in self._DANGEROUS_SUBST_FLAGS for flag in parsed.flags):
                return True
        return False

    @staticmethod
    def _extract_substitution_flags(expression: str) -> str:
        if not expression.startswith("s/"):
            return ""
        rest = expression[2:]
        state = "pattern"
        flags = ""
        i = 0
        while i < len(rest):
            char = rest[i]
            if char == "\\" and i + 1 < len(rest):
                i += 2
                continue
            if char == "/":
                if state == "pattern":
                    state = "replacement"
                elif state == "replacement":
                    state = "flags"
                else:
                    return flags
                i += 1
                continue
            if state == "flags":
                flags += char
            i += 1
        return flags if state == "flags" else ""
