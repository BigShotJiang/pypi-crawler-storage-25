"""
tools/bash/session_runtime.py — BashRuntimeTool v3：长期会话执行运行时

职责：
    提供单个长期存活 bash 会话的生命周期与命令执行能力，支持：
    1. 同一会话内连续命令状态保持（cwd/env/shell context）
    2. 命令级 begin/end/cwd 标记分帧
    3. 超时中断与会话重建

在整体链路中的位置：
    - 由 `session_manager.py` 统一管理实例
    - 由 `backend.py` 在非沙箱执行路径按配置选择调用

与 CC 对照：
    对应 CC `Shell.ts` / `LocalShellTask` 的长期 shell 会话语义基础能力。
    当前是 v3 第一版：优先保证会话持久化与可靠分帧，不包含流式 UI 事件。

**Windows 上 `BashBackend(use_persistent_session=True)` 前置条件**（exec-plan Phase 4）：
    - 须有可用的 **POSIX shell**（`resolve_posix_shell` 或 **`posix_shell_executable=`** 注入）；
    - 默认 **`use_persistent_session` 在 win32 为 false**（见 `bash_runtime_contract` / `BashBackend.__init__`），显式开启前请确认 **Git Bash/MSYS** 下 stdin 多行与换行稳定；
    - 与 `BashBackend` 一致：子进程 **`SHELL`** 在未设置时指向解析到的 shell；**`AGENTX_BASH_CREATE_NO_WINDOW=1`** 时可传 **`CREATE_NO_WINDOW`**。
"""

from __future__ import annotations

import os
import queue
import re
import signal
import subprocess
import sys
import threading
import time
import uuid
from collections.abc import Iterator
from dataclasses import dataclass

from .shell_locator import resolve_posix_shell
from .windows_shell_quoting import rewrite_windows_null_redirect


_END_RE = re.compile(r"^__AGENTX_END_([A-Za-z0-9_]+)__:(-?\d+)$")


@dataclass(frozen=True)
class BashSessionExecResult:
    stdout: str
    exit_code: int
    interrupted: bool
    cwd_after: str | None = None


@dataclass(frozen=True)
class BashSessionStreamEvent:
    kind: str
    chunk: str | None = None
    exit_code: int | None = None
    interrupted: bool | None = None
    cwd_after: str | None = None


class BashSessionRuntime:
    """单个长期 bash 会话运行时。"""

    def __init__(
        self,
        *,
        initial_cwd: str | None = None,
        base_env: dict[str, str] | None = None,
        posix_shell_executable: str | None = None,
    ) -> None:
        self._initial_cwd = initial_cwd
        self._base_env = dict(base_env or os.environ.copy())
        self._posix_shell_override = posix_shell_executable
        self._proc: subprocess.Popen[str] | None = None
        self._reader_thread: threading.Thread | None = None
        self._line_queue: queue.Queue[str] = queue.Queue()
        self._lock = threading.Lock()
        self._closed = False
        self._shell_exe: str | None = None
        self._start()

    def execute(self, command: str, timeout_sec: int) -> BashSessionExecResult:
        events = self.execute_stream(command=command, timeout_sec=timeout_sec)
        stdout_parts: list[str] = []
        final_exit_code = -1
        final_interrupted = False
        final_cwd_after: str | None = None
        for ev in events:
            if ev.kind == "chunk" and ev.chunk:
                stdout_parts.append(ev.chunk)
            if ev.kind == "final":
                final_exit_code = ev.exit_code if ev.exit_code is not None else -1
                final_interrupted = bool(ev.interrupted)
                final_cwd_after = ev.cwd_after
        return BashSessionExecResult(
            stdout="".join(stdout_parts),
            exit_code=final_exit_code,
            interrupted=final_interrupted,
            cwd_after=final_cwd_after,
        )

    def execute_stream(self, command: str, timeout_sec: int) -> list[BashSessionStreamEvent]:
        return list(self.execute_stream_iter(command=command, timeout_sec=timeout_sec))

    def execute_stream_iter(
        self,
        *,
        command: str,
        timeout_sec: int,
        cancel_event: threading.Event | None = None,
    ) -> Iterator[BashSessionStreamEvent]:
        with self._lock:
            if self._closed:
                raise RuntimeError("Bash session runtime is closed")
            self._ensure_alive()
            assert self._proc is not None
            token = uuid.uuid4().hex[:12]
            begin_marker = f"__AGENTX_BEGIN_{token}__"
            cwd_marker_prefix = f"__AGENTX_CWD_{token}__:"
            end_marker_prefix = f"__AGENTX_END_{token}__:"
            command = rewrite_windows_null_redirect(command)
            wrapped = (
                f"printf '%s\\n' '{begin_marker}'\n"
                f"{command}\n"
                f"__AGENTX_EC=$?\n"
                f"printf '%s%s\\n' '{cwd_marker_prefix}' \"$PWD\"\n"
                f"printf '%s%s\\n' '{end_marker_prefix}' \"$__AGENTX_EC\"\n"
            )
            assert self._proc.stdin is not None
            self._proc.stdin.write(wrapped)
            self._proc.stdin.flush()

            collecting = False
            cwd_after: str | None = None
            deadline = time.monotonic() + max(1, timeout_sec)
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    self._interrupt_and_restart()
                    yield BashSessionStreamEvent(
                        kind="final",
                        exit_code=-1,
                        interrupted=True,
                        cwd_after=cwd_after,
                    )
                    return
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._interrupt_and_restart()
                    yield BashSessionStreamEvent(
                        kind="final",
                        exit_code=-1,
                        interrupted=True,
                        cwd_after=cwd_after,
                    )
                    return
                try:
                    line = self._line_queue.get(timeout=remaining)
                except queue.Empty:
                    self._interrupt_and_restart()
                    yield BashSessionStreamEvent(
                        kind="final",
                        exit_code=-1,
                        interrupted=True,
                        cwd_after=cwd_after,
                    )
                    return

                if not collecting:
                    if line.rstrip("\n") == begin_marker:
                        collecting = True
                    continue

                stripped = line.rstrip("\n")
                if stripped.startswith(cwd_marker_prefix):
                    cwd_after = stripped[len(cwd_marker_prefix):]
                    continue
                match = _END_RE.match(stripped)
                if match and stripped.startswith(end_marker_prefix):
                    exit_code = int(match.group(2))
                    yield BashSessionStreamEvent(
                        kind="final",
                        exit_code=exit_code,
                        interrupted=False,
                        cwd_after=cwd_after,
                    )
                    return
                yield BashSessionStreamEvent(kind="chunk", chunk=line)

    def close(self) -> None:
        with self._lock:
            self._closed = True
            self._terminate_process()

    def _resolve_shell_exe(self) -> str:
        if self._posix_shell_override is not None:
            return os.path.normpath(
                os.path.realpath(os.path.expanduser(self._posix_shell_override))
            )
        return resolve_posix_shell(environ=self._base_env)

    def _spawn_env(self, shell_exe: str) -> dict[str, str]:
        out = dict(self._base_env)
        out.setdefault("SHELL", shell_exe)
        return out

    @staticmethod
    def _win32_creationflags() -> int:
        if sys.platform != "win32":
            return 0
        if os.environ.get("AGENTX_BASH_CREATE_NO_WINDOW") != "1":
            return 0
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0))

    def _start(self) -> None:
        self._line_queue = queue.Queue()
        if self._shell_exe is None:
            self._shell_exe = self._resolve_shell_exe()
        shell_exe = self._shell_exe
        assert shell_exe is not None
        spawn_env = self._spawn_env(shell_exe)
        _cf = self._win32_creationflags()
        if _cf:
            self._proc = subprocess.Popen(
                [shell_exe, "--noprofile", "--norc"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=self._initial_cwd,
                env=spawn_env,
                start_new_session=True,
                text=True,
                bufsize=1,
                creationflags=_cf,
            )
        else:
            self._proc = subprocess.Popen(
                [shell_exe, "--noprofile", "--norc"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=self._initial_cwd,
                env=spawn_env,
                start_new_session=True,
                text=True,
                bufsize=1,
            )
        self._reader_thread = threading.Thread(
            target=self._reader_loop,
            name="bash-session-reader",
            daemon=True,
        )
        self._reader_thread.start()

    def _reader_loop(self) -> None:
        proc = self._proc
        if proc is None or proc.stdout is None:
            return
        while True:
            line = proc.stdout.readline()
            if line == "":
                break
            self._line_queue.put(line)

    def _ensure_alive(self) -> None:
        if self._proc is None or self._proc.poll() is not None:
            self._start()

    def _interrupt_and_restart(self) -> None:
        self._terminate_process(send_interrupt=True)
        self._start()

    def _terminate_process(self, send_interrupt: bool = False) -> None:
        proc = self._proc
        self._proc = None
        if proc is None:
            return
        try:
            if proc.poll() is None:
                if send_interrupt:
                    os.killpg(proc.pid, signal.SIGINT)
                    time.sleep(0.1)
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGTERM)
                    time.sleep(0.1)
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=1)
        except Exception:
            pass
