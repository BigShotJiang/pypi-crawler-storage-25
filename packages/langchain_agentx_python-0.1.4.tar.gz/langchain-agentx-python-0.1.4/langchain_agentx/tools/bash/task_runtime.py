"""
tools/bash/task_runtime.py — P1 任务编排统一状态机协议

职责：
    提供前后台统一任务生命周期状态机与快照模型：
    created -> running -> (completed|failed|interrupted|cancelled)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


TaskMode = Literal["foreground", "background"]
TaskStatus = Literal[
    "created",
    "running",
    "completed",
    "failed",
    "interrupted",
    "cancelled",
]


@dataclass(frozen=True)
class BashTaskSnapshot:
    task_id: str
    task_mode: TaskMode
    task_status: TaskStatus
    exit_code: int | None
    running: bool
    created_ts: float | None = None
    started_ts: float | None = None
    ended_ts: float | None = None
    output_path: str | None = None
    pid: int | None = None
    output_size: int | None = None


@dataclass
class BashTaskStateMachine:
    """任务状态机：显式限制状态转移。"""

    task_id: str
    task_mode: TaskMode
    status: TaskStatus = "created"
    exit_code: int | None = None
    created_ts: float | None = None
    started_ts: float | None = None
    ended_ts: float | None = None
    output_path: str | None = None
    pid: int | None = None
    output_size: int | None = None
    _history: list[TaskStatus] = field(default_factory=lambda: ["created"])

    _TRANSITIONS: dict[TaskStatus, set[TaskStatus]] = field(
        init=False,
        default_factory=lambda: {
            "created": {"running", "cancelled"},
            "running": {"completed", "failed", "interrupted", "cancelled"},
            "completed": set(),
            "failed": set(),
            "interrupted": set(),
            "cancelled": set(),
        },
    )

    def transition_to(self, status: TaskStatus) -> None:
        allowed = self._TRANSITIONS.get(self.status, set())
        if status not in allowed:
            raise ValueError(f"Invalid task state transition: {self.status} -> {status}")
        self.status = status
        self._history.append(status)

    def to_snapshot(self) -> BashTaskSnapshot:
        # 仅 running 表示仍在执行；终态均为 running=False
        running = self.status == "running"
        return BashTaskSnapshot(
            task_id=self.task_id,
            task_mode=self.task_mode,
            task_status=self.status,
            exit_code=self.exit_code,
            running=running,
            created_ts=self.created_ts,
            started_ts=self.started_ts,
            ended_ts=self.ended_ts,
            output_path=self.output_path,
            pid=self.pid,
            output_size=self.output_size,
        )
