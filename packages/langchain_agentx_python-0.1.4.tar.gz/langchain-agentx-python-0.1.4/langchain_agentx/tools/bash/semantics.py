"""
tools/bash/semantics.py — 命令退出码语义解析

某些命令以非零退出码表达"正常信息"而非"错误"，需要特殊解释，
否则工具框架会将其包装为 error envelope，导致模型误认为命令失败。

对应 CC commandSemantics.ts 的 interpretCommandResult()。

规则定义格式：
    (命令匹配正则, {退出码: 语义描述})
    语义描述为 None 表示该退出码视为成功（无 hint）
    语义描述为字符串表示非错误但需要说明（作为 hint 展示）
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# 规则表（对应 CC commandSemantics.ts）
# ---------------------------------------------------------------------------

# (command_pattern, {exit_code: hint_message | None})
# hint_message=None  → 视为成功，无需说明
# hint_message=str   → 视为成功，present() 中以 hint 形式告知模型
_SEMANTIC_RULES: list[tuple[re.Pattern[str], dict[int, str | None]]] = [
    # grep / rg / ag / ack：返回 1 = 无匹配（非错误）
    (
        re.compile(r"^(?:grep|rg|ag|ack|ugrep)\b"),
        {1: "No matches found (exit code 1 is normal for grep when no lines match)"},
    ),
    # diff：返回 1 = 文件存在差异（非错误，是正常信息）
    (
        re.compile(r"^diff\b"),
        {1: "Files differ (exit code 1 is normal for diff when files are different)"},
    ),
    # git diff / git log / git show：同 diff
    (
        re.compile(r"^git\s+(?:diff|log|show)\b"),
        {1: "Files differ"},
    ),
    # test / [ ] / [[ ]]：返回 1 = 条件为假（正常行为）
    # 注意：[ 和 [[ 不是字母字符，\b 在其后不生效，需要匹配后面的空格或行尾
    (
        re.compile(r"^(?:test(?:\s|$)|\[{1,2}(?:\s|$))"),
        {1: "Condition is false (exit code 1 is normal for test/[ ] when condition is false)"},
    ),
    # cmp：返回 1 = 文件不同，返回 2 = 无法比较（错误）
    (
        re.compile(r"^cmp\b"),
        {1: "Files are different (exit code 1 is normal for cmp when files differ)"},
    ),
    # ls：返回 2 = 无访问权限/不存在（真正错误，不覆盖）
    # find：返回 1 = 无匹配或权限问题（某些 find 实现）
    (
        re.compile(r"^find\b"),
        {1: None},  # 视为成功（find 无结果时返回 0 或 1 取决于实现）
    ),
    # git：某些子命令如 git fetch --dry-run 可能返回 1 表示有变更
    (
        re.compile(r"^git\s+fetch\b"),
        {1: None},
    ),
]


@dataclass
class CommandResult:
    """
    命令退出码语义解析结果。

    is_error=True  → 框架应将其视为错误（包装为 error envelope / 抛异常）
    is_error=False → 视为成功，message 作为 hint 展示给模型
    message        → 语义说明（非空时注入 present() 的 hints）
    """

    is_error: bool
    message: str | None = None


def interpret_command_result(
    command: str,
    exit_code: int,
    stdout: str,  # noqa: ARG001  保留参数供将来内容感知判断使用
) -> CommandResult:
    """
    解析命令退出码，判断是否为真正错误。

    返回：
        CommandResult.is_error=False → 非错误，可能包含 hint 说明
        CommandResult.is_error=True  → 真正的执行错误

    对应 CC commandSemantics.ts::interpretCommandResult()。
    """
    if exit_code == 0:
        return CommandResult(is_error=False)

    # 提取命令基础部分（去掉参数）用于正则匹配
    cmd_stripped = command.strip()

    for pattern, code_map in _SEMANTIC_RULES:
        if pattern.match(cmd_stripped):
            if exit_code in code_map:
                hint = code_map[exit_code]
                return CommandResult(is_error=False, message=hint)
            # 命令匹配但退出码不在规则表 → 视为错误
            return CommandResult(is_error=True)

    # 未命中任何规则 → 非零退出码视为错误
    return CommandResult(is_error=True)
