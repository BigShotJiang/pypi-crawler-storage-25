"""
tools/bash/mode_validation.py — BashRuntimeTool：mode-aware 权限分流（P2 细粒度版）

职责：
    与 CC `modeValidation.ts` 对齐方向，在命令级基础上增加：
    - 子模式 / 参数语义（acceptEdits 何时可自动放行）
    - 可解释结论（reason_code + message，便于归因与降误判）

当前实现：
    - `acceptEdits`：按命令 + flag + 参数形态分流；显式拒绝高危 rm/chmod/chown 递归等
    - `dontAsk`：将 ask 降级为 deny
    - `bypassPermissions`：直接 allow（仅跳过权限层，不影响 validate_input）
"""

from __future__ import annotations

import re
import shlex
from dataclasses import dataclass
from typing import Literal

from langchain_agentx.tool_runtime.models import AuthorizationDecision, ToolExecutionContext


BashPermissionMode = Literal["default", "acceptEdits", "dontAsk", "bypassPermissions"]


@dataclass(frozen=True)
class BashModeDecision:
    behavior: Literal["passthrough", "allow", "deny"]
    message: str | None = None
    policy_id: str | None = None


@dataclass(frozen=True)
class AcceptEditsEvaluation:
    """acceptEdits 细粒度评估结果（可对接日志 / 策略归因）。"""

    allowed: bool
    reason_code: str
    message: str


class BashPermissionModeValidator:
    """模式级权限协作者（P2：参数语义 + 场景约束）。"""

    _ACCEPT_EDITS_ALLOWED_COMMANDS = frozenset({
        "mkdir", "touch", "rm", "rmdir", "mv", "cp", "sed", "ln", "install",
        "chmod", "chown",
    })

    _CHMOD_DENY_RECURSIVE = frozenset({"-R", "-r", "--recursive"})
    _CHOWN_DENY_RECURSIVE = frozenset({"-R", "-r", "--recursive"})
    _CP_DENY_FLAGS = frozenset({
        "--reflink=always", "--parents", "--link", "-l", "--symbolic-link", "-s",
        "--backup", "--remove-destination",
    })
    _MV_DENY_FLAGS = frozenset({"-f", "--force"})
    _MKDIR_DENY_FLAGS = frozenset({"-Z", "--context"})
    _INSTALL_DENY_FLAGS = frozenset({"-D", "--strip", "-s", "-S", "--strip-program"})
    _CHOWN_DENY_FLAGS = frozenset({"--reference", "--from"})

    def get_mode(self, ctx: ToolExecutionContext) -> BashPermissionMode:
        tool_flags = ctx.tool_flags or {}
        raw_mode = tool_flags.get("permission_mode", "default")
        if raw_mode in {"acceptEdits", "dontAsk", "bypassPermissions"}:
            return raw_mode
        return "default"

    def check_preflight(
        self,
        command: str,
        ctx: ToolExecutionContext,
    ) -> BashModeDecision:
        mode = self.get_mode(ctx)
        if mode == "bypassPermissions":
            return BashModeDecision(
                behavior="allow",
                message="Permission checks bypassed by current permission mode.",
                policy_id="permission_mode",
            )
        return BashModeDecision(behavior="passthrough")

    def evaluate_accept_edits(self, command: str) -> AcceptEditsEvaluation:
        """显式评估 acceptEdits 是否允许自动放行（供调试与扩展）。"""
        base = self._base_command(command)
        if base not in self._ACCEPT_EDITS_ALLOWED_COMMANDS:
            return AcceptEditsEvaluation(
                allowed=False,
                reason_code="command_not_in_accept_edits_set",
                message=f"Command `{base}` is not eligible for acceptEdits auto-allow.",
            )
        ok, code, msg = self._accept_edits_semantics(command, base)
        return AcceptEditsEvaluation(allowed=ok, reason_code=code, message=msg)

    def should_auto_allow_after_policy(
        self,
        command: str,
        ctx: ToolExecutionContext,
    ) -> bool:
        if self.get_mode(ctx) != "acceptEdits":
            return False
        return self.evaluate_accept_edits(command).allowed

    def finalize_decision(
        self,
        *,
        command: str,
        decision: AuthorizationDecision,
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        mode = self.get_mode(ctx)
        if mode == "dontAsk" and decision.behavior == "ask":
            detail = self.evaluate_accept_edits(command)
            suffix = f" [acceptEdits_context: {detail.reason_code}]" if detail.reason_code else ""
            message = (decision.message or f"Command requires approval in dontAsk mode: {command}") + suffix
            return AuthorizationDecision(
                behavior="deny",
                message=message,
                policy_id=decision.policy_id or "permission_mode",
            )
        return decision

    def _accept_edits_semantics(self, command: str, base: str) -> tuple[bool, str, str]:
        """返回 (allowed, reason_code, message)。"""
        try:
            tokens = shlex.split(command)
        except ValueError:
            tokens = command.split()
        args = tokens[1:] if len(tokens) > 1 else []

        if base == "rm":
            risky = {"-r", "-R", "-rf", "-fr", "--recursive", "--force"}
            if any(a in risky for a in args):
                return (False, "rm_recursive_or_force", "Recursive or force rm is not auto-allowed under acceptEdits.")
            return (True, "rm_safe", "Single-file or small-arg rm eligible for acceptEdits.")

        if base == "sed":
            if any(arg.startswith("-i") or arg == "--in-place" for arg in args):
                if self._sed_inplace_shell_chain(command):
                    return (False, "sed_inplace_shell_chain", "sed -i in compound shell chain not auto-allowed.")
                return (True, "sed_inplace", "In-place sed eligible for acceptEdits.")
            return (False, "sed_not_inplace", "Only in-place sed is auto-allowed under acceptEdits.")

        if base == "cp":
            if self._args_contain_token_or_flag(args, self._CP_DENY_FLAGS):
                return (False, "cp_submode_denied", "cp with link/backup/parents/reflink semantics not auto-allowed.")
            if self._cp_short_bundle_risky(args):
                return (False, "cp_short_link_or_symlink", "cp -l/-s (含合并短选项) not auto-allowed.")
            if self._cp_sparse_or_preserve_root(args):
                return (False, "cp_sparse_or_preserve_root", "cp --sparse=always or --preserve=root not auto-allowed.")
            return (True, "cp_default", "cp eligible for acceptEdits.")

        if base == "mv":
            if self._args_contain_token_or_flag(args, self._MV_DENY_FLAGS):
                return (False, "mv_force", "mv -f/--force not auto-allowed under acceptEdits.")
            if "--strip-trailing-slashes" in args:
                return (False, "mv_strip_slashes", "mv --strip-trailing-slashes not auto-allowed.")
            return (True, "mv_default", "mv eligible for acceptEdits.")

        if base == "mkdir":
            if self._args_contain_token_or_flag(args, self._MKDIR_DENY_FLAGS):
                return (False, "mkdir_selinux_context", "mkdir -Z/--context not auto-allowed.")
            if "-m" in args or "--mode" in args:
                return (True, "mkdir_with_mode", "mkdir with explicit mode still eligible.")
            return (True, "mkdir_default", "mkdir eligible for acceptEdits.")

        if base == "touch":
            return (True, "touch_default", "touch eligible for acceptEdits.")

        if base == "rmdir":
            if "--ignore-fail-on-non-empty" in args:
                return (False, "rmdir_ignore_nonempty", "rmdir --ignore-fail-on-non-empty not auto-allowed.")
            return (True, "rmdir_default", "rmdir eligible for acceptEdits.")

        if base == "ln":
            if "-r" in args or "--relative" in args:
                return (False, "ln_relative", "ln --relative not auto-allowed.")
            return (True, "ln_default", "ln eligible for acceptEdits.")

        if base == "install":
            if self._args_contain_token_or_flag(args, self._INSTALL_DENY_FLAGS):
                return (False, "install_submode_denied", "install -D/strip or similar not auto-allowed.")
            if "-d" in args or "--directory" in args:
                return (True, "install_dirs", "install -d eligible.")
            return (True, "install_default", "install file copy eligible for acceptEdits.")

        if base == "chmod":
            if any(a in self._CHMOD_DENY_RECURSIVE for a in args):
                return (False, "chmod_recursive", "Recursive chmod not auto-allowed under acceptEdits.")
            mode, paths = self._chmod_mode_and_paths(args)
            if mode and self._chmod_mode_caps_setuid(mode):
                return (False, "chmod_setuid_or_special", "chmod with setuid/setgid/sticky not auto-allowed.")
            return (True, "chmod_non_recursive", "Non-recursive chmod eligible for acceptEdits.")

        if base == "chown":
            if any(a in self._CHOWN_DENY_RECURSIVE for a in args):
                return (False, "chown_recursive", "Recursive chown not auto-allowed under acceptEdits.")
            if self._args_contain_token_or_flag(args, self._CHOWN_DENY_FLAGS):
                return (False, "chown_reference_or_from", "chown --reference/--from not auto-allowed.")
            return (True, "chown_non_recursive", "Non-recursive chown eligible for acceptEdits.")

        return (True, "generic_ok", f"{base} eligible for acceptEdits.")

    @staticmethod
    def _sed_inplace_shell_chain(command: str) -> bool:
        """与 `&&`、`|` 组合的 in-place sed 不自动放行（子模式边界）。"""
        return "&&" in command or "|" in command

    @staticmethod
    def _args_contain_token_or_flag(args: list[str], needles: frozenset[str]) -> bool:
        for a in args:
            if a in needles:
                return True
            if a.startswith("--") and "=" in a:
                opt = a.split("=", 1)[0]
                if opt in needles or a in needles:
                    return True
        return False

    @staticmethod
    def _cp_sparse_or_preserve_root(args: list[str]) -> bool:
        for a in args:
            if a.startswith("--sparse=") and a != "--sparse=never":
                return True
            if a == "--preserve=root":
                return True
        return False

    @staticmethod
    def _cp_short_bundle_risky(args: list[str]) -> bool:
        for a in args:
            if not a.startswith("-") or a.startswith("--") or len(a) < 2:
                continue
            body = a.lstrip("-")
            if "l" in body or "s" in body:
                return True
        return False

    @staticmethod
    def _chmod_mode_and_paths(args: list[str]) -> tuple[str | None, list[str]]:
        """从 chmod 参数中取出 mode 字串（若存在）与路径候选（启发式）。"""
        mode: str | None = None
        paths: list[str] = []
        i = 0
        while i < len(args):
            a = args[i]
            if a in ("-f", "--silent", "--quiet", "-v", "--verbose", "-c", "--changes", "-R", "-r", "--recursive"):
                i += 1
                continue
            if a.startswith("-"):
                i += 1
                continue
            if mode is None and re.match(r"^[ugoa]*[-+=]?[rwxXst,0-7]+$", a):
                mode = a
                i += 1
                continue
            paths.append(a)
            i += 1
        return mode, paths

    @staticmethod
    def _chmod_mode_caps_setuid(mode: str) -> bool:
        if re.fullmatch(r"[0-7]{3,4}", mode):
            try:
                val = int(mode, 8)
            except ValueError:
                return False
            return (val & 0o6000) != 0
        if any(x in mode for x in ("s", "t", "T")) and ("+" in mode or "-" in mode or "=" in mode):
            return True
        return False

    @staticmethod
    def _base_command(command: str) -> str:
        try:
            tokens = shlex.split(command)
        except ValueError:
            tokens = command.split()
        if not tokens:
            return ""
        return tokens[0].rsplit("/", 1)[-1]
