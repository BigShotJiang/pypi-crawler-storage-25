"""
tools/grep/rg_subprocess_controller.py — ripgrep 子进程 timeout + 协作取消

职责：
    在无法使用单次 ``subprocess.run(..., timeout=)`` 响应协作取消时，用 Popen + 后台
    ``communicate`` 与主线程轮询 ``cancel_event``，对齐 CC ``ripGrep(..., abortSignal)``。

链路位置：
    ``grep.backend.run_ripgrep_lines`` 在传入非空 ``cancel_event`` 时委托本类；
    ``RipgrepBackend.search_stream_limited`` 在读取 stdout 时轮询同一事件。

当前裁剪范围：
    仅 argv 列表进程；不处理 shell=True；编码固定 utf-8/errors=replace（与 TextSubprocessRunner 一致）。
"""

from __future__ import annotations

import subprocess
import threading
import time

from langchain_agentx.tools.grep.backend import (
    GrepCancelledError,
    GrepExecutionError,
    GrepTimeoutError,
)


class RgSubprocessController:
    """封装可中断的阻塞式子进程等待（timeout + ``threading.Event``）。"""

    _poll_interval_s = 0.05

    def run_argv_wait_completed(
        self,
        argv: list[str],
        *,
        timeout: float,
        cancel_event: threading.Event | None,
    ) -> subprocess.CompletedProcess[str]:
        """
        启动 ``argv``，在 ``timeout`` 秒内等待结束；若 ``cancel_event`` 被 set 则 terminate/kill。

        Returns:
            ``CompletedProcess``（text stdout/stderr），供上层解析 returncode。
        """
        if cancel_event is not None and cancel_event.is_set():
            raise GrepCancelledError("ripgrep cancelled before start")

        try:
            proc = subprocess.Popen(
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
        except FileNotFoundError as e:
            raise GrepExecutionError(
                "ripgrep executable not found. On Windows install ripgrep and ensure "
                "'rg.exe' is on PATH; on Unix ensure 'rg' is on PATH."
            ) from e

        out_box: list[str | None] = [None]
        err_box: list[str | None] = [None]
        thread_exc: list[BaseException | None] = [None]

        def _communicate_worker() -> None:
            try:
                o, e = proc.communicate()
                out_box[0] = o
                err_box[0] = e
            except BaseException as ex:  # noqa: BLE001 — 必须兜住线程内异常
                thread_exc[0] = ex

        worker = threading.Thread(target=_communicate_worker, daemon=True)
        worker.start()
        deadline = time.monotonic() + timeout

        try:
            while worker.is_alive():
                if cancel_event is not None and cancel_event.is_set():
                    proc.terminate()
                    worker.join(timeout=2.0)
                    if worker.is_alive():
                        proc.kill()
                        worker.join(timeout=2.0)
                    raise GrepCancelledError("ripgrep cancelled")
                if time.monotonic() >= deadline:
                    proc.kill()
                    worker.join(timeout=2.0)
                    raise GrepTimeoutError(f"ripgrep search timed out after {timeout:g}s")
                worker.join(timeout=self._poll_interval_s)

            if thread_exc[0] is not None:
                raise thread_exc[0]

            return subprocess.CompletedProcess(
                args=argv,
                returncode=proc.returncode if proc.returncode is not None else -1,
                stdout=out_box[0] or "",
                stderr=err_box[0] or "",
            )
        finally:
            if proc.poll() is None:
                try:
                    proc.kill()
                except OSError:
                    pass
                try:
                    proc.wait(timeout=1.0)
                except (OSError, subprocess.TimeoutExpired):
                    pass
