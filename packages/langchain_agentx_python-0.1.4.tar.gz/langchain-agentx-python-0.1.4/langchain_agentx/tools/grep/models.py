"""
tools/grep/models.py — GrepToolInput / GrepToolOutput

职责：
    面向模型与工具内部的 Pydantic 模型；阈值常量（默认 head_limit）。

对应 CC：GrepTool.ts 中 inputSchema / outputSchema 的 Python 侧表达。
"""

from __future__ import annotations

from enum import Enum

from pydantic import AliasChoices, BaseModel, Field

DEFAULT_HEAD_LIMIT = 250


class GrepOutputMode(str, Enum):
    content = "content"
    files_with_matches = "files_with_matches"
    count = "count"


class GrepToolInput(BaseModel):
    pattern: str = Field(
        ...,
        description=(
            "The regular expression pattern to search for in file contents. "
            'Supports full regex syntax (e.g., "log.*Error", "function\\s+\\w+").'
        ),
    )
    path: str | None = Field(
        default=None,
        description=(
            "File or directory to search in. Defaults to workspace root. "
            "Omit this field to search the default directory."
        ),
    )
    glob: str | None = Field(
        default=None,
        description=(
            'Glob pattern to filter files (e.g. "*.js", "*.{ts,tsx}"). Maps to ripgrep --glob.'
        ),
    )
    output_mode: GrepOutputMode = Field(
        default=GrepOutputMode.files_with_matches,
        description=(
            'Output mode. "content" shows matching lines (context, line numbers, head_limit). '
            '"files_with_matches" shows file paths sorted by modification time. '
            '"count" shows match counts per file.'
        ),
    )
    context_before: int | None = Field(
        default=None,
        ge=0,
        description='Lines before each match (rg -B). Requires output_mode "content".',
        validation_alias=AliasChoices("context_before", "-B"),
    )
    context_after: int | None = Field(
        default=None,
        ge=0,
        description='Lines after each match (rg -A). Requires output_mode "content".',
        validation_alias=AliasChoices("context_after", "-A"),
    )
    context: int | None = Field(
        default=None,
        ge=0,
        description="Lines before and after each match (rg -C). Overrides context_before/after.",
        validation_alias=AliasChoices("context", "-C"),
    )
    show_line_numbers: bool = Field(
        default=True,
        description='Show line numbers. Requires output_mode "content".',
        validation_alias=AliasChoices("show_line_numbers", "-n"),
    )
    case_insensitive: bool = Field(
        default=False,
        description="Case insensitive search (rg -i).",
        validation_alias=AliasChoices("case_insensitive", "-i"),
    )
    file_type: str | None = Field(
        default=None,
        description='File type for rg --type (e.g. "js", "py", "rust").',
        validation_alias=AliasChoices("file_type", "type"),
    )
    head_limit: int = Field(
        default=DEFAULT_HEAD_LIMIT,
        ge=0,
        description=(
            "Limit to first N lines/entries. Default 250. Use 0 for unlimited (large results cost context)."
        ),
    )
    offset: int = Field(
        default=0,
        ge=0,
        description="Skip first N entries before applying head_limit.",
    )
    multiline: bool = Field(
        default=False,
        description="Multiline mode: . matches newlines (rg -U --multiline-dotall).",
    )


class GrepToolOutput(BaseModel):
    """工具 invoke() 返回值，供 present() 消费。"""

    model_config = {"extra": "forbid"}

    mode: GrepOutputMode
    pattern: str
    search_root: str

    filenames: list[str] = Field(default_factory=list)
    num_files: int = 0

    content: str = ""
    num_lines: int = 0

    num_matches: int = 0
    count_content: str = ""

    truncated: bool = False
    applied_limit: int | None = None
    applied_offset: int | None = None

    duration_ms: float = 0.0
