"""
tools/grep/backend.py — RipgrepBackend（ripgrep 子进程封装）

职责：
    构建 rg 参数、执行子进程、解析退出码与 stdout 行列表。

在整体链路中的位置：
    GrepRuntimeTool.invoke() -> RipgrepBackend.search() -> run_ripgrep_lines（可选 ctx.cancel_event）
    -> RgSubprocessController 或 TextSubprocessRunner

对应 CC：src/utils/ripgrep.ts + GrepTool.ts call() 中参数拼装。
"""

from __future__ import annotations

import os
import subprocess
import threading
from typing import Any

from langchain_agentx.tool_runtime.errors import ToolRuntimeError
from langchain_agentx.utils.rg_executable import default_rg_executable
from langchain_agentx.utils.subprocess_text import (
    TextSubprocessRunner,
    default_text_subprocess_runner,
)

from .models import GrepOutputMode


class GrepTimeoutError(ToolRuntimeError):
    def __init__(self, message: str) -> None:
        super().__init__(message, code="GREP_TIMEOUT")


class GrepExecutionError(ToolRuntimeError):
    def __init__(self, message: str) -> None:
        super().__init__(message, code="GREP_EXECUTION_ERROR")


class GrepCancelledError(ToolRuntimeError):
    """协作取消（对齐 CC AbortSignal）；由 ``threading.Event`` 触发。"""

    def __init__(self, message: str = "ripgrep cancelled") -> None:
        super().__init__(message, code="GREP_CANCELLED")


def run_ripgrep_lines(
    rg_path: str,
    args: list[str],
    search_path: str,
    *,
    timeout: int,
    text_runner: TextSubprocessRunner,
    is_retry: bool = False,
    cancel_event: threading.Event | None = None,
) -> list[str]:
    """
    执行 [rg_path, *args, search_path]，解析 stdout 为行列表。
    对齐 CC ripgrep.ts：returncode 1 -> []；EAGAIN 时以 -j 1 重试一次。
    供 RipgrepBackend 与 Glob 的 rg --files 列文件共用。

    若 ``cancel_event`` 非空，使用可中断子进程路径（``RgSubprocessController``），
    不再走 ``text_runner.run``（便于测试 mock 时仅覆盖无取消路径）。
    """
    cmd = [rg_path, *args, search_path]
    if cancel_event is not None:
        if cancel_event.is_set():
            raise GrepCancelledError("ripgrep cancelled before start")
        from langchain_agentx.tools.grep.rg_subprocess_controller import RgSubprocessController

        ctrl = RgSubprocessController()
        try:
            result = ctrl.run_argv_wait_completed(
                cmd, timeout=float(timeout), cancel_event=cancel_event
            )
        except GrepTimeoutError:
            raise
        except GrepCancelledError:
            raise
    else:
        try:
            result = text_runner.run(
                cmd,
                capture_output=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            raise GrepTimeoutError(f"ripgrep search timed out after {timeout}s")
        except FileNotFoundError as e:
            raise GrepExecutionError(
                "ripgrep executable not found. On Windows install ripgrep and ensure "
                "'rg.exe' is on PATH; on Unix ensure 'rg' is on PATH."
            ) from e

    if result.returncode == 1:
        return []

    if result.returncode >= 2:
        stderr = (result.stderr or "").strip()
        if (not is_retry) and RipgrepBackend._is_eagain_error(stderr):
            return run_ripgrep_lines(
                rg_path,
                ["-j", "1", *args],
                search_path,
                timeout=timeout,
                text_runner=text_runner,
                is_retry=True,
                cancel_event=cancel_event,
            )
        raise GrepExecutionError(f"ripgrep failed: {stderr or f'exit code {result.returncode}'}")

    out = result.stdout or ""
    if not out.strip():
        return []
    lines = [ln.rstrip("\r") for ln in out.rstrip("\n").split("\n")]
    return [ln for ln in lines if ln]


class RipgrepBackend:
    DEFAULT_TIMEOUT = 20
    MAX_COLUMNS = 500
    VCS_EXCLUDE_DIRS = (".git", ".svn", ".hg", ".bzr", ".jj", ".sl")

    def __init__(
        self,
        *,
        rg_path: str | None = None,
        timeout: int = DEFAULT_TIMEOUT,
        text_runner: TextSubprocessRunner | None = None,
    ) -> None:
        self._rg_path = rg_path if rg_path is not None else default_rg_executable()
        self.timeout = timeout
        self._text_runner = text_runner or default_text_subprocess_runner()

    @staticmethod
    def _parse_glob_patterns(glob_str: str) -> list[str]:
        """与 CC GrepTool.ts 一致：空格分段，逗号拆分，保留 {...} 段。"""
        patterns: list[str] = []
        for raw in glob_str.split():
            if "{" in raw and "}" in raw:
                patterns.append(raw)
            else:
                patterns.extend(p for p in raw.split(",") if p)
        return patterns

    def _build_args(
        self,
        pattern: str,
        *,
        glob: str | None,
        ignore_patterns: list[str] | None,
        file_type: str | None,
        output_mode: GrepOutputMode,
        context_before: int | None,
        context_after: int | None,
        context: int | None,
        show_line_numbers: bool,
        case_insensitive: bool,
        multiline: bool,
        plugin_glob_exclusions: list[str] | None = None,
    ) -> list[str]:
        args: list[str] = ["--hidden"]
        for d in self.VCS_EXCLUDE_DIRS:
            args.extend(["--glob", f"!{d}"])
        args.extend(["--max-columns", str(self.MAX_COLUMNS)])
        if multiline:
            args.extend(["-U", "--multiline-dotall"])
        if case_insensitive:
            args.append("-i")
        if output_mode == GrepOutputMode.files_with_matches:
            args.append("-l")
        elif output_mode == GrepOutputMode.count:
            args.append("-c")
        if output_mode == GrepOutputMode.content and show_line_numbers:
            args.append("-n")
        if output_mode == GrepOutputMode.content:
            if context is not None:
                args.extend(["-C", str(context)])
            else:
                if context_before is not None:
                    args.extend(["-B", str(context_before)])
                if context_after is not None:
                    args.extend(["-A", str(context_after)])
        if pattern.startswith("-"):
            args.extend(["-e", pattern])
        else:
            args.append(pattern)
        if file_type:
            args.extend(["--type", file_type])
        if glob:
            for g in self._parse_glob_patterns(glob):
                args.extend(["--glob", g])
        # Add ignore patterns (CC: getFileReadIgnorePatterns + normalizePatternsToPath).
        # We implement the same ripgrep glob semantics:
        # - patterns starting with '/' are treated as repo-root anchored (pass through)
        # - otherwise prefix with '**/' so ripgrep applies them from the search root
        # - negate with '!' to exclude them
        if ignore_patterns:
            for p in ignore_patterns:
                p = str(p).strip()
                if not p:
                    continue
                rg_pat = f"!{p}" if p.startswith("/") else f"!**/{p}"
                args.extend(["--glob", rg_pat])
        if plugin_glob_exclusions:
            for ex in plugin_glob_exclusions:
                if ex:
                    args.extend(["--glob", ex])
        return args

    def search(
        self,
        pattern: str,
        search_path: str,
        *,
        glob: str | None = None,
        ignore_patterns: list[str] | None = None,
        file_type: str | None = None,
        output_mode: GrepOutputMode = GrepOutputMode.files_with_matches,
        context_before: int | None = None,
        context_after: int | None = None,
        context: int | None = None,
        show_line_numbers: bool = True,
        case_insensitive: bool = False,
        multiline: bool = False,
        plugin_glob_exclusions: list[str] | None = None,
        cancel_event: threading.Event | None = None,
    ) -> list[str]:
        args = self._build_args(
            pattern,
            glob=glob,
            ignore_patterns=ignore_patterns,
            file_type=file_type,
            output_mode=output_mode,
            context_before=context_before,
            context_after=context_after,
            context=context,
            show_line_numbers=show_line_numbers,
            case_insensitive=case_insensitive,
            multiline=multiline,
            plugin_glob_exclusions=plugin_glob_exclusions,
        )
        return self._execute(args, search_path, cancel_event=cancel_event)

    def _execute(
        self, args: list[str], search_path: str, *, cancel_event: threading.Event | None
    ) -> list[str]:
        return self._execute_with_retry(args, search_path, cancel_event=cancel_event)

    @staticmethod
    def _is_eagain_error(stderr: str) -> bool:
        s = (stderr or "").lower()
        return ("eagain" in s) or ("resource temporarily unavailable" in s)

    def _execute_with_retry(
        self,
        args: list[str],
        search_path: str,
        *,
        cancel_event: threading.Event | None,
    ) -> list[str]:
        """
        对齐 CC ripgrep.ts 的关键鲁棒性：
        - exit code 1: no matches -> []
        - 遇到疑似 EAGAIN 启动错误时，额外重试一次单线程（-j 1）
        """
        return run_ripgrep_lines(
            self._rg_path,
            args,
            search_path,
            timeout=self.timeout,
            text_runner=self._text_runner,
            is_retry=False,
            cancel_event=cancel_event,
        )

    def search_stream_limited(
        self,
        pattern: str,
        search_path: str,
        *,
        glob: str | None = None,
        ignore_patterns: list[str] | None = None,
        file_type: str | None = None,
        output_mode: GrepOutputMode,
        context_before: int | None = None,
        context_after: int | None = None,
        context: int | None = None,
        show_line_numbers: bool = True,
        case_insensitive: bool = False,
        multiline: bool = False,
        max_lines: int,
        plugin_glob_exclusions: list[str] | None = None,
        cancel_event: threading.Event | None = None,
    ) -> list[str]:
        """
        准流式读取 stdout，达到 max_lines 后提前终止进程。
        仅用于 content / count 两种模式（files_with_matches 需要全量结果排序）。
        """
        args = self._build_args(
            pattern,
            glob=glob,
            ignore_patterns=ignore_patterns,
            file_type=file_type,
            output_mode=output_mode,
            context_before=context_before,
            context_after=context_after,
            context=context,
            show_line_numbers=show_line_numbers,
            case_insensitive=case_insensitive,
            multiline=multiline,
            plugin_glob_exclusions=plugin_glob_exclusions,
        )
        cmd = [self._rg_path, *args, search_path]
        if cancel_event is not None and cancel_event.is_set():
            raise GrepCancelledError("ripgrep cancelled before start")
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError as e:
            raise GrepExecutionError(
                "ripgrep executable not found. On Windows install ripgrep and ensure "
                "'rg.exe' is on PATH; on Unix ensure 'rg' is on PATH."
            ) from e

        collected: list[str] = []
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                if cancel_event is not None and cancel_event.is_set():
                    proc.terminate()
                    raise GrepCancelledError("ripgrep cancelled")
                if len(collected) >= max_lines:
                    break
                ln = line.rstrip("\n").rstrip("\r")
                if ln:
                    collected.append(ln)

            if len(collected) >= max_lines:
                # We intentionally stop early to cap output.
                proc.terminate()

            try:
                stdout_tail, stderr_tail = proc.communicate(timeout=self.timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                raise GrepTimeoutError(f"ripgrep search timed out after {self.timeout}s")

            # Merge any remaining stdout (rare) if we didn't early stop
            if stdout_tail and len(collected) < max_lines:
                for ln in stdout_tail.rstrip("\n").split("\n"):
                    if not ln or len(collected) >= max_lines:
                        break
                    collected.append(ln.rstrip("\r"))

            rc = proc.returncode or 0
            if rc == 1:
                return []
            if rc >= 2:
                stderr = (stderr_tail or "").strip()
                raise GrepExecutionError(f"ripgrep failed: {stderr or f'exit code {rc}'}")
            return collected
        finally:
            # Ensure no zombie
            try:
                if proc.poll() is None:
                    proc.kill()
                    proc.wait(timeout=1)
            except Exception:
                pass
