"""
tools/read/models.py — ReadRuntimeTool 输入输出数据模型

职责：
    定义 Read 工具的业务级 Input / Output Pydantic 模型。
    不引入框架级模型（tool_runtime/models.py）；不含 I/O 操作。

输出模型采用 discriminated union（对应 CC outputSchema 的 z.discriminatedUnion）：
    - TextFileOutput        文本文件读取结果
    - ImageFileOutput       图片文件读取结果（base64 编码）
    - PDFFileOutput         PDF 文件读取结果（v1 文本提取路径）
    - NotebookFileOutput    Jupyter Notebook 读取结果
    - FileUnchangedOutput   重复读取 dedup stub（对应 CC file_unchanged）
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# 输入模型
# ---------------------------------------------------------------------------


class ReadToolInput(BaseModel):
    """
    ReadRuntimeTool 输入参数（对应 CC inputSchema）。

    字段说明：
        file_path  — 文件绝对路径（必须）
        offset     — 起始行（1-indexed；0 表示从文件头开始）
        limit      — 最多读取行数（None 表示读到文件末尾或 max_lines 上限）
        pages      — PDF 专用，页范围如 "1-5"、"3"、"10-20"；非 PDF 文件传此参数报错
    """

    file_path: str = Field(
        ...,
        description="The absolute path to the file to read",
    )
    offset: int = Field(
        0,
        ge=0,
        description=(
            "The line number to start reading from (1-indexed). "
            "0 means start from the beginning of the file. "
            "Only provide if the file is too large to read at once."
        ),
    )
    limit: int | None = Field(
        None,
        gt=0,
        description=(
            "The number of lines to read. "
            "Only provide if the file is too large to read at once."
        ),
    )
    pages: str | None = Field(
        None,
        description=(
            'Page range for PDF files (e.g. "1-5", "3", "10-20"). '
            "Only applicable to PDF files. Maximum 20 pages per request."
        ),
    )


# ---------------------------------------------------------------------------
# 输出模型（discriminated union by type）
# ---------------------------------------------------------------------------


class TextFileOutput(BaseModel):
    """文本文件读取结果（含行号格式）。"""

    type: Literal["text"] = "text"
    file_path: str
    content: str
    """带行号的文本内容，格式：'   N\\t<line content>'（对应 CC addLineNumbers()）。"""
    line_start: int
    """实际读取起始行（1-indexed）。"""
    line_end: int
    """实际读取结束行（1-indexed）。"""
    total_lines: int
    """文件总行数。"""
    truncated: bool = False


class ImageFileOutput(BaseModel):
    """图片文件读取结果（base64 编码，对应 CC type='image'）。"""

    type: Literal["image"] = "image"
    file_path: str
    base64: str
    """base64 编码的图片数据（ASCII 字符串）。"""
    media_type: str
    """MIME 类型，如 'image/png'、'image/jpeg'（从 magic bytes 检测）。"""
    original_size: int
    """原始文件大小（字节）。"""
    width: int | None = None
    """图片宽度（像素，Pillow 可用时填写）。"""
    height: int | None = None
    """图片高度（像素，Pillow 可用时填写）。"""


class PDFFileOutput(BaseModel):
    """PDF 文件读取结果（v1：文本提取路径）。"""

    type: Literal["pdf"] = "pdf"
    file_path: str
    content: str
    """提取的文本内容，页间以 '\\n\\n--- Page Break ---\\n\\n' 分隔。"""
    page_start: int
    """实际读取起始页（1-indexed）。"""
    page_end: int
    """实际读取结束页（1-indexed）。"""
    total_pages: int
    """PDF 总页数。"""
    truncated: bool = False
    """是否因 pdf_max_pages 限制而未读完所有页。"""


class NotebookFileOutput(BaseModel):
    """Jupyter Notebook 读取结果（对应 CC type='notebook'）。"""

    type: Literal["notebook"] = "notebook"
    file_path: str
    cells: list[dict]
    """nbformat cells 列表（每个 cell 为 dict，含 cell_type / source / outputs 等字段）。"""


class FileUnchangedOutput(BaseModel):
    """
    重复读取 dedup stub（对应 CC type='file_unchanged'）。

    当同一文件、同 offset/limit、mtime 未变时返回。
    model 收到此结果应引用历史 Read 结果，而非重新读取。
    """

    type: Literal["file_unchanged"] = "file_unchanged"
    file_path: str


# ---------------------------------------------------------------------------
# Union 类型别名
# ---------------------------------------------------------------------------

ReadToolOutput = Annotated[
    TextFileOutput | ImageFileOutput | PDFFileOutput | NotebookFileOutput | FileUnchangedOutput,
    Field(discriminator="type"),
]
"""
Read 工具输出的 discriminated union。
对应 CC outputSchema 的 z.discriminatedUnion('type', [...])。
"""
