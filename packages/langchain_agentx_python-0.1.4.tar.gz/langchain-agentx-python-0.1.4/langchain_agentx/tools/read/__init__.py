"""
tools/read — ReadRuntimeTool 包

ReadRuntimeTool 是工具体系 P1 首个工具，支持文本、图片、PDF、Jupyter Notebook 读取。
"""

from .tool import ReadRuntimeTool

__all__ = ["ReadRuntimeTool"]
