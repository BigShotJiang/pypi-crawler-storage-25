"""
tools/read/limits.py — ReadRuntimeTool 上限配置

职责：
    集中管理 Read 工具所有数值常量和配置读取逻辑。
    全部支持环境变量覆盖，便于测试 mock 和生产调优。

两层上限设计（对应 CC limits.ts）：
    max_size_bytes  — 读取前检查文件总大小（stat），低代价，快速 fail
    max_tokens      — 读取后检查输出 token 数，高代价但精确
                      v1 用字符数估算（chars / 4 ≈ tokens）
"""

from __future__ import annotations

import os

# ---------------------------------------------------------------------------
# 文本读取上限
# ---------------------------------------------------------------------------

DEFAULT_MAX_LINES = int(os.getenv("READ_TOOL_MAX_LINES", "2000"))
"""单次最多读取行数（对应 CC MAX_LINES_TO_READ=2000）。"""

DEFAULT_MAX_SIZE_BYTES = int(os.getenv("READ_TOOL_MAX_SIZE_BYTES", str(256 * 1024)))
"""文件大小上限（字节），超过此值在 validate_input 时 stat 检查拒绝（对应 CC maxSizeBytes=256KB）。"""

DEFAULT_MAX_TOKENS = int(os.getenv("READ_TOOL_MAX_TOKENS", "25000"))
"""输出 token 数上限（chars / 4 估算），超过时报 MaxFileReadTokenExceededError（对应 CC maxTokens=25000）。"""

DEFAULT_MAX_RESULT_CHARS = DEFAULT_MAX_TOKENS * 4
"""输出字符上限，约等于 max_tokens 换算。"""

# ---------------------------------------------------------------------------
# PDF 相关上限
# ---------------------------------------------------------------------------

PDF_MAX_PAGES_PER_READ = int(os.getenv("READ_TOOL_PDF_MAX_PAGES", "20"))
"""单次最多读取 PDF 页数（对应 CC PDF_MAX_PAGES_PER_READ=20）。"""

PDF_AT_MENTION_INLINE_THRESHOLD = 10
"""超过此页数时必须提供 pages 参数（对应 CC PDF_AT_MENTION_INLINE_THRESHOLD=10）。
不走环境变量，是产品设计决策。"""

# ---------------------------------------------------------------------------
# 图片相关上限
# ---------------------------------------------------------------------------

IMAGE_MAX_SIZE_BYTES = int(os.getenv("READ_TOOL_IMAGE_MAX_BYTES", str(20 * 1024 * 1024)))
"""图片文件大小上限（字节，默认 20MB）。图片有独立上限，不受 max_size_bytes 约束。"""


def get_read_limits() -> dict:
    """
    返回当前有效配置（支持运行时环境变量覆盖）。

    对应 CC limits.ts 的 getDefaultFileReadingLimits()。
    """
    return {
        "max_lines": DEFAULT_MAX_LINES,
        "max_size_bytes": DEFAULT_MAX_SIZE_BYTES,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "max_result_chars": DEFAULT_MAX_RESULT_CHARS,
        "pdf_max_pages": PDF_MAX_PAGES_PER_READ,
        "pdf_inline_threshold": PDF_AT_MENTION_INLINE_THRESHOLD,
        "image_max_bytes": IMAGE_MAX_SIZE_BYTES,
    }
