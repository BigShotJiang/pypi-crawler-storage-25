"""
tools/read/prompt.py — ReadRuntimeTool 工具名与 prompt 模板

职责：
    集中管理工具名常量、面向模型的 description 和 prompt 模板文本。
    纯字符串/常量，无 I/O，无框架依赖，可单独测试。

对应 CC prompt.ts，包含：
    FILE_READ_TOOL_NAME  → TOOL_NAME
    DESCRIPTION          → DESCRIPTION
    FILE_UNCHANGED_STUB  → FILE_UNCHANGED_STUB
    renderPromptTemplate → get_prompt()
"""

from __future__ import annotations

TOOL_NAME = "read_file"
"""工具名，面向模型暴露，唯一标识。"""

DESCRIPTION = "Read a file from the local filesystem."
"""简短描述，用于 bind_tools 阶段工具列表展示（对应 CC DESCRIPTION）。"""

FILE_UNCHANGED_STUB = (
    "File unchanged since last read. "
    "The content from the earlier read result in this conversation is still current "
    "— refer to that instead of re-reading."
)
"""
重复读取去重时返回的 stub 文本（对应 CC FILE_UNCHANGED_STUB）。
model 收到此文本后应直接引用历史上下文，而非重新读取。
"""

MAX_LINES_TO_READ = 2000
"""面向模型 prompt 中说明的默认行数上限（与 limits.py 同步）。"""


def get_prompt() -> str:
    """
    返回面向模型的完整使用说明（对应 CC renderPromptTemplate()）。

    动态引用 limits 配置，确保 prompt 中展示的限制值与实际执行一致。
    """
    from .limits import get_read_limits

    limits = get_read_limits()
    max_size_kb = limits["max_size_bytes"] // 1024
    pdf_max_pages = limits["pdf_max_pages"]

    return (
        f"Reads a file from the local filesystem.\n"
        f"\n"
        f"Usage:\n"
        f"- file_path must be an absolute path\n"
        f"- By default reads up to {MAX_LINES_TO_READ} lines from the start of the file\n"
        f"- Files larger than {max_size_kb}KB will return an error; "
        f"use offset and limit to read specific portions\n"
        f"- You can optionally specify offset and limit for large files; "
        f"it is recommended to read the whole file by not providing these parameters\n"
        f"- Results are returned with line numbers starting at 1 (cat -n format: "
        f'"   1\\t<line content>")\n'
        f"- If a file exists but is shorter than the provided offset, a warning is returned\n"
        f"- If a file exists but has empty contents, a warning is returned\n"
        f"\n"
        f"Supported file types beyond plain text:\n"
        f"- Images (PNG, JPG, JPEG, GIF, WEBP): contents are returned as base64-encoded data\n"
        f"- PDF files (.pdf): text is extracted page by page; "
        f"use the pages parameter for large PDFs (e.g. pages=\"1-5\", max {pdf_max_pages} pages per request)\n"
        f"- Jupyter notebooks (.ipynb): returns all cells with their outputs\n"
        f"\n"
        f"Restrictions:\n"
        f"- This tool can only read files, not directories\n"
        f"- Binary files (non-image, non-PDF) cannot be read; use appropriate tools instead\n"
    )
