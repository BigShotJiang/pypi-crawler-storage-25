"""
runtime/errors.py — 工具运行时错误类型与 envelope 映射

职责：
    定义框架级运行时异常类型，并提供统一的异常 → ToolResultEnvelope 映射函数。
    所有工具执行过程中未被捕获的异常，均通过 exception_to_envelope() 转换为
    status="error" 的 envelope，确保 pipeline 始终返回结构化结果。

与 CC 对比：
    CC 中工具执行异常直接在 ToolNode 层被捕获并转为 ToolMessage(content=error_str)。
    本框架将异常映射提前到 pipeline 内部，保持 envelope 协议的完整性，
    同时将 traceback 隔离在 meta 中，不暴露给模型。
"""

from __future__ import annotations

import traceback as tb

from .models import ToolErrorInfo, ToolResultEnvelope


# ---------------------------------------------------------------------------
# 框架级异常类型
# ---------------------------------------------------------------------------

class ToolRuntimeError(Exception):
    """工具运行时框架基础异常。"""

    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.code = code


class ToolRegistrationError(ToolRuntimeError):
    """工具注册失败，通常因为工具名重复。"""

    def __init__(self, tool_name: str) -> None:
        super().__init__(
            f"Tool '{tool_name}' is already registered. Tool names must be unique.",
            code="TOOL_ALREADY_REGISTERED",
        )
        self.tool_name = tool_name


class ToolNotFoundError(ToolRuntimeError):
    """工具查询失败，工具名不存在于 registry。"""

    def __init__(self, tool_name: str) -> None:
        super().__init__(
            f"Tool '{tool_name}' not found in registry.",
            code="TOOL_NOT_FOUND",
        )
        self.tool_name = tool_name


class ToolInputSchemaError(ToolRuntimeError):
    """输入参数不符合 input_model schema，由 pipeline schema parse 阶段抛出。"""

    def __init__(self, tool_name: str, detail: str) -> None:
        super().__init__(
            f"Input schema validation failed for tool '{tool_name}': {detail}",
            code="INPUT_SCHEMA_ERROR",
        )
        self.tool_name = tool_name
        self.detail = detail


# ---------------------------------------------------------------------------
# 异常 → ToolResultEnvelope 映射
# ---------------------------------------------------------------------------

def exception_to_envelope(
    exc: Exception,
    tool_name: str,
    *,
    include_traceback: bool = True,
) -> ToolResultEnvelope:
    """
    将任意异常映射为 status="error" 的 ToolResultEnvelope。

    traceback 写入 meta["traceback"]，不进入模型上下文。
    面向模型的 summary 只包含简短错误说明，不暴露内部细节。

    Args:
        exc:               捕获到的异常对象。
        tool_name:         当前执行的工具名。
        include_traceback: 是否将 traceback 写入 meta（默认 True，用于调试）。

    Returns:
        status="error" 的 ToolResultEnvelope。
    """
    exc_type = type(exc).__name__
    message = str(exc) if str(exc) else exc_type

    # ToolRuntimeError 子类携带稳定 code
    code = exc.code if isinstance(exc, ToolRuntimeError) else None

    error_info = ToolErrorInfo(
        message=message,
        code=code,
        exception_type=exc_type,
    )

    meta: dict = {"exception_type": exc_type}
    if include_traceback:
        meta["traceback"] = tb.format_exc()

    return ToolResultEnvelope(
        status="error",
        tool_name=tool_name,
        summary=f"Error: {message}",
        error=error_info,
        meta=meta,
    )


def blocked_envelope(
    tool_name: str,
    message: str,
    policy_id: str | None = None,
) -> ToolResultEnvelope:
    """
    构造 status="blocked" 的 ToolResultEnvelope。

    check_permissions() 返回 deny 时由 pipeline 调用。
    向模型返回通用拒绝信息，不暴露路径细节（策略不透明原则）。
    """
    return ToolResultEnvelope(
        status="blocked",
        tool_name=tool_name,
        summary=f"Permission denied: {message}",
        meta={"policy_id": policy_id} if policy_id else None,
    )


def validation_error_envelope(
    tool_name: str,
    message: str,
    code: str | None = None,
) -> ToolResultEnvelope:
    """
    构造 validate_input 失败的 status="error" ToolResultEnvelope。

    模型会收到 message，可据此修正输入后重试。
    """
    return ToolResultEnvelope(
        status="error",
        tool_name=tool_name,
        summary=f"Error: {message}",
        error=ToolErrorInfo(message=message, code=code),
    )


def blocked_envelope(
    tool_name: str,
    message: str,
    policy_id: str | None = None,
) -> ToolResultEnvelope:
    """
    构造 status="blocked" 的 ToolResultEnvelope。

    check_permissions() 返回 deny 时由 pipeline 调用。
    向模型返回通用拒绝信息，不暴露路径细节（策略不透明原则）。
    """
    return ToolResultEnvelope(
        status="blocked",
        tool_name=tool_name,
        summary=f"Permission denied: {message}",
        meta={"policy_id": policy_id} if policy_id else None,
    )


def validation_error_envelope(
    tool_name: str,
    message: str,
    code: str | None = None,
) -> ToolResultEnvelope:
    """
    构造 validate_input 失败的 status="error" ToolResultEnvelope。

    模型会收到 message，可据此修正输入后重试。
    与 exception_to_envelope 的区别：无 traceback，面向模型可读。
    """
    return ToolResultEnvelope(
        status="error",
        tool_name=tool_name,
        summary=f"Error: {message}",
        error=ToolErrorInfo(message=message, code=code),
    )
