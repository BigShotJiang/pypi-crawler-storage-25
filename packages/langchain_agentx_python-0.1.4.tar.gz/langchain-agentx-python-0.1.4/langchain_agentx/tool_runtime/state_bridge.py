"""
runtime/state_bridge.py — 工具级最小共享状态管理

职责：
    管理工具执行过程中的跨工具共享状态，维护：
    - last_read_map：记录每个文件最近一次被读取的信息，
      为 write/edit 工具的 read-before-write 约束提供基础
    - tool_audit：工具调用审计日志，记录每次工具执行的关键信息
    - last_glob_summary（v2-D）：最近一次 Glob 的摘要，供 Read/Grep 等读侧 **hint**（不替代授权）

    状态存储在 ToolExecutionContext.state（LangGraph state）中，
    通过固定 key 读写，不引入独立的状态存储。

与 CC 对比：
    CC 中通过 ToolUseContext.readFileState 维护文件读取状态，
    通过 getAppState / setAppState 读写应用级状态。
    本框架将这些能力收敛到 ToolStateBridge，通过 LangGraph state
    作为底层存储，保持与 agent loop 的状态一致性。
    v1：last_read_map（含 mtime_ms、可选 content，供 Edit staleness 方案 B）、tool_audit；
    v2-D：last_glob_summary（可选写入，见 GlobRuntimeTool.after_invoke）。
    不承担业务 workflow state。
"""

from __future__ import annotations

from typing import Any

from .models import ToolExecutionContext


class ToolStateBridge:
    """
    工具级最小共享状态管理器。

    通过 ToolExecutionContext.state（LangGraph state dict）读写状态，
    使用固定 key 隔离工具框架状态与业务状态。

    维护：
        last_read_map      — 文件最近读取记录（为 read-before-write 规则服务）
        tool_audit         — 工具调用审计日志
        last_glob_summary  — 最近一次 Glob 摘要（仅路径样本，防 state 膨胀）

    不承担：
        业务 workflow state
        UI 临时态
        task state
    """

    LAST_READ_MAP_KEY = "_tool_last_read_map"
    AUDIT_LOG_KEY = "_tool_audit_log"
    LAST_GLOB_SUMMARY_KEY = "_tool_last_glob_summary"
    MAX_GLOB_SAMPLE_PATHS = 32

    # ---- last_read_map ----

    def get_last_read_map(self, ctx: ToolExecutionContext) -> dict[str, Any]:
        """
        获取 last_read_map。

        结构（每条 file_path）：至少含 ``tool_call_id``、``ts``；Read 写入时还含
        ``offset``、``limit``、``mtime_ms``；可选 ``content``（文本快照或占位符，
        供 Edit staleness）、``line_start`` / ``line_end``（Read 元数据）。

        不存在时返回空 dict（不修改 state）。
        """
        return ctx.state.get(self.LAST_READ_MAP_KEY) or {}

    def set_last_read_map(
        self,
        ctx: ToolExecutionContext,
        value: dict[str, Any],
    ) -> None:
        """更新 last_read_map，整体替换。"""
        ctx.state[self.LAST_READ_MAP_KEY] = value

    def get_last_read(
        self, ctx: ToolExecutionContext, file_path: str
    ) -> dict[str, Any] | None:
        """返回 ``file_path`` 对应的最近一次读取记录；无则 ``None``。"""
        raw = self.get_last_read_map(ctx).get(file_path)
        return raw if isinstance(raw, dict) else None

    def set_last_read(
        self,
        ctx: ToolExecutionContext,
        file_path: str,
        *,
        offset: int | None = None,
        limit: int | None = None,
        mtime_ms: int = 0,
        content: str | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        """
        写入/覆盖某路径的最近一次读取记录（Read ``after_invoke`` 主入口）。

        ``content``：可选；UTF-8 文本快照或 ``<image:...>`` 等占位符，供 Edit
        staleness 内容对比；过大文本由调用方截断为占位符。
        """
        last_read_map = self.get_last_read_map(ctx)
        entry: dict[str, Any] = {
            "tool_call_id": ctx.tool_call_id,
            "ts": ctx.now_ts,
            "offset": offset,
            "limit": limit,
            "mtime_ms": mtime_ms,
            "line_start": line_start,
            "line_end": line_end,
        }
        if content is not None:
            entry["content"] = content
        last_read_map[file_path] = entry
        self.set_last_read_map(ctx, last_read_map)

    def record_read(
        self,
        ctx: ToolExecutionContext,
        file_path: str,
        *,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        """
        记录一次文件读取（兼容旧 API / 单测），等价于 ``offset=0``、``mtime_ms=0``
        的 ``set_last_read``。
        """
        self.set_last_read(
            ctx,
            file_path,
            offset=0,
            limit=None,
            mtime_ms=0,
            line_start=line_start,
            line_end=line_end,
        )

    def has_been_read(self, ctx: ToolExecutionContext, file_path: str) -> bool:
        """
        检查文件是否已被读取过（用于 read-before-write 约束）。
        """
        return file_path in self.get_last_read_map(ctx)

    # ---- tool_audit ----

    def append_audit(
        self,
        ctx: ToolExecutionContext,
        record: dict[str, Any],
    ) -> None:
        """
        追加一条审计记录到 tool_audit 列表。

        record 建议包含：
            tool        — 工具名
            tool_call_id — 调用 ID
            ts          — 时间戳
            以及工具特定的关键字段（如 file_path、lines_read 等）
        """
        audit_log: list = ctx.state.get(self.AUDIT_LOG_KEY) or []
        audit_log.append(record)
        ctx.state[self.AUDIT_LOG_KEY] = audit_log

    def get_audit_log(self, ctx: ToolExecutionContext) -> list[dict[str, Any]]:
        """获取完整审计日志，不存在时返回空列表。"""
        return ctx.state.get(self.AUDIT_LOG_KEY) or []

    # ---- last_glob_summary（v2-D，本工程专有；CC 无对等）----

    def record_last_glob(
        self,
        ctx: ToolExecutionContext,
        *,
        pattern: str,
        search_root: str,
        filenames: list[str],
        num_files_page: int,
        total_matches: int,
        truncated: bool,
        offset: int,
    ) -> None:
        """
        覆盖写入最近一次 Glob 摘要（**不**用于 PolicyEngine，仅供 hint）。

        ``filenames`` 为当前页相对路径列表；仅持久化前 ``MAX_GLOB_SAMPLE_PATHS`` 条。
        """
        sample = list(filenames[: self.MAX_GLOB_SAMPLE_PATHS])
        ctx.state[self.LAST_GLOB_SUMMARY_KEY] = {
            "pattern": pattern,
            "search_root": search_root,
            "sample_paths": sample,
            "num_files_page": int(num_files_page),
            "total_matches": int(total_matches),
            "truncated": bool(truncated),
            "offset": int(offset),
            "tool_call_id": ctx.tool_call_id,
            "ts": ctx.now_ts,
        }

    def get_last_glob_summary(self, ctx: ToolExecutionContext) -> dict[str, Any] | None:
        """读取最近一次 Glob 摘要；不存在或类型不对时返回 ``None``。"""
        raw = ctx.state.get(self.LAST_GLOB_SUMMARY_KEY)
        return raw if isinstance(raw, dict) else None

    def clear_last_glob_summary(self, ctx: ToolExecutionContext) -> None:
        """清除摘要（测试或显式重置会话工具态时使用）。"""
        ctx.state.pop(self.LAST_GLOB_SUMMARY_KEY, None)
