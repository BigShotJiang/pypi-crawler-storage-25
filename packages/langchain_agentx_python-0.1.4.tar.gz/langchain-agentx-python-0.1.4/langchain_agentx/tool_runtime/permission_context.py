"""
tool_runtime/permission_context.py — 会话级工具权限上下文

职责：在 AgentSessionStore 上管理 skill 触发的 auto-approved 工具窗口（pending/active）。
在整体链路中的位置：SkillRuntimeTool 写入 pending；模型调用前轮转为 active；PolicyEngine 消费。
CC 对照：allowedTools 进入 alwaysAllowRules，并在局部会话上下文生效。
当前裁剪范围：v1 单轮窗口语义（pending -> active），不实现多层嵌套栈。
"""

from __future__ import annotations

from collections.abc import Iterable

from .session_store import AgentSessionStore

_PENDING_KEY = "tool_scope.auto_approved.pending"
_ACTIVE_KEY = "tool_scope.auto_approved.active"


def _normalize_names(names: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen_lower: set[str] = set()
    for name in names:
        n = str(name).strip()
        lower = n.lower()
        if not n or lower in seen_lower:
            continue
        seen_lower.add(lower)
        result.append(n)
    return result


def set_pending_auto_approved_tools(
    session_store: AgentSessionStore | None,
    tool_names: Iterable[str],
) -> None:
    if session_store is None:
        return
    names = _normalize_names(tool_names)
    if not names:
        return
    session_store.cache_permission(_PENDING_KEY, names)
    session_store.append_audit(
        {
            "event": "tool_scope_pending_updated",
            "pending_auto_approved": names,
        }
    )


def rotate_auto_approved_window(session_store: AgentSessionStore | None) -> None:
    """模型调用前轮转权限窗口：pending -> active，旧 active 自动清空。"""
    if session_store is None:
        return
    pending = session_store.get_cached_permission(_PENDING_KEY)
    pending_names = _normalize_names(pending if isinstance(pending, list) else [])
    prev_active = get_active_auto_approved_tools(session_store)
    session_store.cache_permission(_ACTIVE_KEY, pending_names)
    session_store.cache_permission(_PENDING_KEY, [])
    session_store.append_audit(
        {
            "event": "tool_scope_window_rotated",
            "previous_active": sorted(prev_active),
            "active_auto_approved": pending_names,
        }
    )


def get_active_auto_approved_tools(
    session_store: AgentSessionStore | None,
) -> set[str]:
    if session_store is None:
        return set()
    active = session_store.get_cached_permission(_ACTIVE_KEY)
    if not isinstance(active, list):
        return set()
    return set(_normalize_names(active))

