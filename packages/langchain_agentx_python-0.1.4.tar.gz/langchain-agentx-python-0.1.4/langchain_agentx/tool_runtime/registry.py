"""
runtime/registry.py — 工具注册表

职责：
    管理所有 RuntimeTool 的注册与查询。
    register() 只存储 RuntimeTool，不构造 StructuredTool。
    to_langchain_tools() 在需要时按需构造 StructuredTool；控制面由 RunnableConfig 注入。

与 CC 对比：
    CC 中工具通过静态 TOOLS 数组集中声明，没有显式注册表。
    本框架引入 RuntimeToolRegistry 作为运行时注册中心，支持动态注册。
    StructuredTool 构造时序由 factory 控制（需 state 生命周期对齐），不在注册时提前构造。
"""

from __future__ import annotations

from typing import Any

from langchain_core.tools import BaseTool

from .adapter import LangChainAdapter
from .base import RuntimeTool
from .errors import ToolNotFoundError, ToolRegistrationError
from .pipeline import ToolExecutorPipeline


class RuntimeToolRegistry:
    """
    工具注册表。

    register(tool)                      — 注册 RuntimeTool，工具名重复时抛 ToolRegistrationError
    get(name)                           — 按名查询 RuntimeTool，不存在时抛 ToolNotFoundError
    list()                              — 返回所有已注册 RuntimeTool 列表
    to_langchain_tools()                — 按需构造 StructuredTool 列表
    """

    def __init__(
        self,
        *,
        pipeline: ToolExecutorPipeline,
        adapter: LangChainAdapter,
    ) -> None:
        self._pipeline = pipeline
        self._adapter = adapter
        self._tools: dict[str, RuntimeTool] = {}

    def register(self, tool: RuntimeTool) -> None:
        """注册一个 RuntimeTool。工具名重复时抛 ToolRegistrationError。"""
        if tool.name in self._tools:
            raise ToolRegistrationError(tool.name)
        self._tools[tool.name] = tool

    def get(self, name: str) -> RuntimeTool:
        """按名查询 RuntimeTool。不存在时抛 ToolNotFoundError。"""
        if name not in self._tools:
            raise ToolNotFoundError(name)
        return self._tools[name]

    def list(self) -> list[RuntimeTool]:
        """返回所有已注册 RuntimeTool 列表（按注册顺序）。"""
        return list(self._tools.values())

    def to_langchain_tools(self) -> list[BaseTool]:
        """按需构造并返回所有 StructuredTool。"""
        return [
            self._adapter.build_structured_tool(
                tool=t,
                pipeline=self._pipeline,
            )
            for t in self._tools.values()
        ]

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:
        names = list(self._tools.keys())
        return f"<RuntimeToolRegistry tools={names}>"
