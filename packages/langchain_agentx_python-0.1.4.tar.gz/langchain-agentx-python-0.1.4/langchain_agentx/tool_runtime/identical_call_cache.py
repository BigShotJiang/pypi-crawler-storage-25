"""
同工具 + 同解析后参数 的会话内结果复用（替代仅靠 middleware 注入「别重复调」的软提示）。

- 按 ``(thread_id, tool_name, sha256(sorted_json(args)))`` 做键；命中则 **不再次 invoke**，
  直接返回上一次的 ``ToolResultEnvelope`` 副本，并打上 ``meta.identical_call_dedup`` 与 Hint。
- 仅 ``RuntimeTool.dedupe_identical_calls=True`` 时启用；写类/破坏性工具应保持 False。

由 ``ToolExecutorPipeline`` 在权限通过之后、``before_invoke`` 之前查询；成功 ``ok`` 后写入缓存。

示例（直观看这个模块在做什么）：

1) 同一线程、同工具、同参数：第二次直接复用，不再执行工具

   - 第一次调用：``thread_id=t1, tool=read, args={\"file_path\":\"/a.txt\"}``
     -> 真正执行 read 工具，返回 envelope，写入 memo
   - 第二次调用：``thread_id=t1, tool=read, args={\"file_path\":\"/a.txt\"}``
     -> 命中 memo，直接返回上次 envelope（并标记 ``identical_call_dedup=True``）

2) 不同线程隔离：不会串缓存

   - 调用 A：``thread_id=t1, tool=read, args={\"file_path\":\"/a.txt\"}``
   - 调用 B：``thread_id=t2, tool=read, args={\"file_path\":\"/a.txt\"}``
   - 因 thread_id 不同，键不同，B 不会命中 A 的缓存，仍会执行工具

3) 参数不同：不会误命中

   - ``args={\"file_path\":\"/a.txt\"}`` 与 ``args={\"file_path\":\"/b.txt\"}``
   - 参数摘要不同，键不同，仍会执行工具
"""

from __future__ import annotations

import copy
import hashlib
import json
from collections import OrderedDict
from typing import Any

from .models import ToolExecutionContext, ToolHint, ToolResultEnvelope


def dedup_cache_key(
    ctx: ToolExecutionContext,
    tool_name: str,
    parsed_data: dict[str, Any],
) -> str:
    """稳定键：线程隔离 + 工具名 + 参数字典规范化后的摘要。"""
    tid = ctx.thread_id or "__no_thread__"
    payload = json.dumps(parsed_data, sort_keys=True, ensure_ascii=False)
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return f"{tid}::{tool_name}::{digest}"


def envelope_with_dedup_notice(
    env: ToolResultEnvelope,
    *,
    ctx: ToolExecutionContext,
) -> ToolResultEnvelope:
    """返回深拷贝，并附加 dedup 元数据与面向模型的 Hint（会进入 ``envelope_to_tool_output``）。"""
    out = copy.deepcopy(env)
    meta = dict(out.meta or {})
    meta["identical_call_dedup"] = True
    meta["dedup_source_tool_call_id"] = ctx.tool_call_id
    out.meta = meta
    hints = list(out.hints or [])
    hints.insert(
        0,
        ToolHint(
            message=(
                "Same tool and arguments as an earlier call in this thread; "
                "reusing the previous successful result without executing again."
            ),
        ),
    )
    out.hints = hints
    return out


class IdenticalCallMemo:
    """
    进程内 LRU（按插入顺序淘汰）：仅缓存 ``status == \"ok\"`` 的 envelope。
    """

    def __init__(self, max_entries: int = 512) -> None:
        self._max_entries = max(1, int(max_entries))
        self._data: OrderedDict[str, ToolResultEnvelope] = OrderedDict()

    def get(self, key: str) -> ToolResultEnvelope | None:
        if key not in self._data:
            return None
        self._data.move_to_end(key)
        return copy.deepcopy(self._data[key])

    def put(self, key: str, envelope: ToolResultEnvelope) -> None:
        if envelope.status != "ok":
            return
        self._data[key] = copy.deepcopy(envelope)
        self._data.move_to_end(key)
        while len(self._data) > self._max_entries:
            self._data.popitem(last=False)

    def clear(self) -> None:
        self._data.clear()


__all__ = [
    "IdenticalCallMemo",
    "dedup_cache_key",
    "envelope_with_dedup_notice",
]
