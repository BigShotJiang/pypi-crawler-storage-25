"""
runtime/session_store.py — 会话级状态存储

职责：
    AgentSessionStore 是 session 级别的状态对象，生命周期与一次 Agent 会话对齐。
    它独立于 LangGraph graph state（turn 级）和 ToolExecutionContext（call 级），
    负责跨 turn 持久化的会话状态：

        file_read_state   — 文件读取记录（为 read-before-write 约束服务）
        file_history      — 文件写入/编辑历史
        audit_log         — 工具调用审计日志
        permissions_cache — 权限决策缓存（避免重复询问）
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Any


@dataclass
class FileReadRecord:
    path: str
    tool_call_id: str | None
    ts: float
    line_start: int | None = None
    line_end: int | None = None


@dataclass
class FileWriteRecord:
    path: str
    operation: str
    tool_call_id: str | None
    ts: float


class AgentSessionStore:
    CONFIGURABLE_KEY = "session_store"

    def __init__(self, session_id: str | None = None) -> None:
        self.session_id: str = session_id or str(uuid.uuid4())
        self._created_at: float = time.time()
        self._file_read_state: dict[str, FileReadRecord] = {}
        self._file_history: list[FileWriteRecord] = []
        self._audit_log: list[dict[str, Any]] = []
        self._permissions_cache: dict[str, Any] = {}

    def record_file_read(
        self,
        path: str,
        *,
        tool_call_id: str | None = None,
        ts: float | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> None:
        self._file_read_state[path] = FileReadRecord(
            path=path,
            tool_call_id=tool_call_id,
            ts=ts if ts is not None else time.time(),
            line_start=line_start,
            line_end=line_end,
        )

    def has_been_read(self, path: str) -> bool:
        return path in self._file_read_state

    def get_file_read_record(self, path: str) -> FileReadRecord | None:
        return self._file_read_state.get(path)

    def get_all_read_paths(self) -> list[str]:
        return list(self._file_read_state.keys())

    def record_file_write(
        self,
        path: str,
        operation: str,
        *,
        tool_call_id: str | None = None,
        ts: float | None = None,
    ) -> None:
        self._file_history.append(
            FileWriteRecord(
                path=path,
                operation=operation,
                tool_call_id=tool_call_id,
                ts=ts if ts is not None else time.time(),
            )
        )

    def get_file_history(self) -> list[FileWriteRecord]:
        return list(self._file_history)

    def append_audit(self, record: dict[str, Any]) -> None:
        self._audit_log.append(record)

    def get_audit_log(self) -> list[dict[str, Any]]:
        return list(self._audit_log)

    def export_audit_log(self) -> list[dict[str, Any]]:
        """语义化导出出口；等价于 get_audit_log()."""
        return self.get_audit_log()

    def cache_permission(self, key: str, decision: Any) -> None:
        self._permissions_cache[key] = decision

    def get_cached_permission(self, key: str) -> Any | None:
        return self._permissions_cache.get(key)

    @property
    def created_at(self) -> float:
        return self._created_at

    def summary(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "created_at": self._created_at,
            "files_read": len(self._file_read_state),
            "file_writes": len(self._file_history),
            "audit_entries": len(self._audit_log),
            "cached_permissions": len(self._permissions_cache),
        }

    def __repr__(self) -> str:
        return (
            f"<AgentSessionStore session_id={self.session_id!r} "
            f"files_read={len(self._file_read_state)} "
            f"audit_entries={len(self._audit_log)}>"
        )
