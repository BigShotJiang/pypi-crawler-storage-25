"""
runtime/base.py — RuntimeTool 抽象基类

职责：
    定义框架内部工具的核心 OOP 契约。每个工具继承 RuntimeTool，
    只需实现 invoke()，其余生命周期 hook 均有 fail-open 默认实现。
    框架通过 ToolExecutorPipeline 统一编排这些 hook，工具无需自行
    实现完整控制流。

与 CC 对比：
    CC 中 Tool<Input, Output> 是 TypeScript interface，通过 buildTool(def)
    工厂函数注入默认实现（TOOL_DEFAULTS），checkPermissions 默认 allow，
    validateInput 默认 success。
    本框架用 Python ABC 实现等价模式：hook 方法有 fail-open 默认实现，
    子类只覆盖关心的部分。is_read_only / is_destructive / is_concurrency_safe
    对应 CC Tool 的同名 flag。never_truncate 对应 CC maxResultSizeChars=Infinity。

一个工具的完整流转（OOP 视角）：

    ┌─────────────────────────────────────────────────────────────────┐
    │                      RuntimeToolRegistry                        │
    │  register(tool) ──► LangChainAdapter.build_structured_tool()   │
    │                              │                                  │
    │                              ▼                                  │
    │                       StructuredTool  ◄── model.bind_tools()   │
    └─────────────────────────────────────────────────────────────────┘
                                   │
                    AIMessage.tool_calls[i]
                                   │
                                   ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                          ToolNode                               │
    │         StructuredTool.func(state, config, **kwargs)            │
    └─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                     LangChainAdapter                            │
    │  build_tool_execution_context(tool_name, raw_input,             │
    │                               state, config)                    │
    │                      → ToolExecutionContext                     │
    └─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                   ToolExecutorPipeline.run()                    │
    │                                                                 │
    │  [Hook 1] tool.normalize_input(raw, ctx)                        │
    │       │   路径规范化、默认值填充                                  │
    │       ▼                                                         │
    │  [Step 2] input_model.model_validate(normalized)                │
    │       │   Pydantic schema 解析，失败 → error envelope           │
    │       ▼                                                         │
    │  [Hook 3] tool.validate_input(data, ctx)                        │
    │       │   语义校验（文件存在？是否目录？）                         │
    │       │   失败 → error envelope（模型可修正重试）                 │
    │       ▼                                                         │
    │  [Hook 4] tool.check_permissions(data, ctx)                     │
    │       │   权限控制（路径越界？策略拒绝？）                         │
    │       │   失败 → blocked envelope（不可绕过）                    │
    │       ▼                                                         │
    │  [Hook 5] tool.before_invoke(data, ctx)                         │
    │       │   执行前钩子（日志、预热等）                               │
    │       ▼                                                         │
    │  [Core ] tool.invoke(data, ctx)  /  tool.ainvoke(data, ctx)     │
    │       │   核心业务执行，异常 → exception_to_envelope()           │
    │       ▼                                                         │
    │  [Hook 7] tool.after_invoke(data, result, ctx)                  │
    │       │   状态写入（last_read_map）、审计记录                     │
    │       ▼                                                         │
    │  [Step 8] state_bridge.update(ctx, result)                      │
    │       ▼                                                         │
    │  [Hook 9] tool.present(data, result, ctx)                       │
    │       │   → ToolResultEnvelope                                  │
    │       ▼                                                         │
    │  [Step10] output_manager.truncate_if_needed(envelope)           │
    │       │   超大输出 → 写文件 + 更新 summary + overflow_file       │
    │       ▼                                                         │
    │                    ToolResultEnvelope                           │
    └─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                     LangChainAdapter                            │
    │  envelope_to_tool_output(envelope) → str                        │
    │  ok:      summary + payload + hints                             │
    │  blocked: "Permission denied: ..."                              │
    │  error:   "Error: ..."                                          │
    └─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
                    ToolMessage(content=str, tool_call_id=...)
                                   │
                                   ▼
                         agent loop / loop_controller
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from typing import Any

from .models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolHint,
    ToolResultEnvelope,
    ValidationResult,
)


class RuntimeTool(ABC):
    """
    工具运行时抽象基类。

    硬约定（Hook 输入契约）：
        RuntimeTool 的所有生命周期 hook 都必须使用 ``dict[str, Any]`` 作为
        ``data`` 形态，禁止依赖属性访问（如 ``data.command``）。
        这是与 ToolExecutorPipeline 的固定契约：schema 解析后统一下发 dict。

    子类必须定义：
        name          — 工具名（唯一，面向模型暴露）
        description   — 工具描述（面向模型暴露）
        input_model   — Pydantic BaseModel，直接作为 StructuredTool.args_schema

    子类可覆盖的生命周期 hook（默认均为 fail-open / no-op）：
        normalize_input     — 输入预处理（路径规范化、默认值填充）
        validate_input      — 语义校验（失败告知模型，可重试）
        check_permissions   — 权限控制（失败策略拒绝，不可绕过）
        before_invoke       — 执行前钩子
        after_invoke        — 执行后钩子（状态写入、审计）
        present             — 结果呈现（构造 ToolResultEnvelope）

    子类必须实现：
        invoke              — 核心业务执行（同步）

    子类可选覆盖：
        ainvoke             — 核心业务执行（异步），默认委托 executor 运行 invoke
    """

    # ---- 子类必须定义的类属性 ----
    name: str
    description: str

    # input_model 必须是 pydantic BaseModel 子类
    # 直接作为 StructuredTool.args_schema 暴露给模型
    input_model: type

    output_model: type | None = None

    # ---- 行为标志（对应 CC Tool 的同名 flag）----
    is_read_only: bool = False
    """只读工具，不修改文件系统。"""

    is_destructive: bool = False
    """高风险写操作（write / edit / bash 等）。"""

    is_concurrency_safe: bool = False
    """是否支持并发执行。"""

    never_truncate: bool = False
    """
    禁止 ToolOutputManager 截断输出。
    对应 CC maxResultSizeChars=Infinity。
    适用于自带分页机制的工具（如 ReadRuntimeTool 用 limit 参数控制）。
    """

    dedupe_identical_calls: bool = False
    """
    为 True 时，``ToolExecutorPipeline`` 在同 ``thread_id`` 下对「工具名 + 解析后参数字典」
    命中缓存则直接返回上一次成功的 ``ToolResultEnvelope``（带 Hint），不再次 ``invoke``。
    仅适用于只读、无副作用重复的安全工具；写/破坏性工具须保持 False。
    """

    max_result_size_chars: int = 20_000
    """
    单次输出字符上限，超出时由 ToolOutputManager 截断并持久化。
    对应 CC Tool.maxResultSizeChars。
    """

    def __init__(
        self,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
    ) -> None:
        self._policy = policy
        self._state_bridge = state_bridge

    # ---- 生命周期 Hook（默认 fail-open / no-op，子类按需覆盖）----

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        """
        输入预处理：路径规范化、默认值填充、参数 clamp 等。
        默认原样返回，子类覆盖时应返回修改后的新 dict。
        """
        return raw

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        """
        语义校验：参数格式、文件是否存在、是否为目录等。

        失败时 pipeline 生成 status="error" 的 envelope，
        模型收到 message 后可修正输入重试。

        默认 ok=True（fail-open，对应 CC buildTool TOOL_DEFAULTS）。
        注意：这里的 data 恒为 dict，工具实现不得使用 data.xxx 属性访问。
        """
        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """
        权限控制：路径越界、策略拒绝等授权检查。

        失败时 pipeline 生成 status="blocked" 的 envelope，
        模型知晓被拒但不获得路径细节（策略不透明原则）。

        默认实现：委托注入的 PolicyEngine。
        - 注入了 policy → 自动受 policy 保护（所有工具无需覆盖此方法即可生效）
        - 未注入 policy → 默认 allow（开发模式，fail-open）
        工具有特殊需求（如 BashRuntimeTool 的命令级检查）可覆盖此方法，
        在工具级检查后调用 super().check_permissions(data, ctx) 走通用 policy。
        """
        if self._policy is not None:
            return self._policy.authorize(
                tool_name=self.name,
                input_data=data,
                ctx=ctx,
            )
        return AuthorizationDecision(behavior="allow")

    def before_invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> None:
        """执行前钩子（日志、预热等），默认 no-op。"""

    @abstractmethod
    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> Any:
        """
        核心业务执行（同步）。子类必须实现。

        返回值将传入 after_invoke 和 present，类型由子类定义。
        抛出的异常由 pipeline 统一捕获并映射为 error envelope。
        """
        ...

    async def ainvoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> Any:
        """
        核心业务执行（异步）。

        默认在 executor 中运行同步 invoke，保持 sync/async 对称。
        有真正异步 I/O 需求的工具（如 HTTP 请求）可覆盖此方法。
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.invoke(data, ctx))

    def after_invoke(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> None:
        """
        执行后钩子：状态写入（last_read_map）、审计记录等。
        默认 no-op，ReadRuntimeTool 等工具在此更新 StateBridge。
        """

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        """
        将内部执行结果映射为 ToolResultEnvelope。

        子类应覆盖此方法，提供语义化的 summary / payload / hints。
        默认实现将 result 转为 str 作为 summary，适合快速原型。
        """
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=str(result),
            payload={"raw": str(result)},
        )

    def __repr__(self) -> str:
        flags = []
        if self.is_read_only:
            flags.append("read_only")
        if self.is_destructive:
            flags.append("destructive")
        if self.never_truncate:
            flags.append("never_truncate")
        flag_str = f"[{', '.join(flags)}]" if flags else ""
        return f"<{type(self).__name__} name={self.name!r} {flag_str}>".strip()
