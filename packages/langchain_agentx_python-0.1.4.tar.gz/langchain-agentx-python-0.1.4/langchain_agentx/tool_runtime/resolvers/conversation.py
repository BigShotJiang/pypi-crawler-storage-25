"""
tool_runtime/resolvers/conversation.py — 对话场景权限 resolver

职责：
    对话（Web/IM）场景下不阻塞当前轮，ask 分支统一返回拒绝。

链路位置：
    ToolExecutorPipeline ask 分支调用；拒绝后由模型在下一轮解释并重试。

当前裁剪范围：
    仅返回 False，不包含外部通知/消息回传能力。
"""

from __future__ import annotations


class ConversationPermissionResolver:
    async def __call__(self, tool_name: str, ask_prompt: str | None) -> bool:
        return False


__all__ = ["ConversationPermissionResolver"]
