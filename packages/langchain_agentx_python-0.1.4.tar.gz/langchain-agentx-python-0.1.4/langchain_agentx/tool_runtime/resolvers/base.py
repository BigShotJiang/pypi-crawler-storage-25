"""
tool_runtime/resolvers/base.py — PermissionResolver 协议定义

职责：
    提供 ask 分支统一回调协议，隔离 ToolExecutorPipeline 与 UI/会话实现细节。

链路位置：
    ToolExecutorPipeline 在 auth.behavior=="ask" 时 await PermissionResolver。

当前裁剪范围：
    仅定义类型协议，不引入具体会话/交互实现。
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable

PermissionResolver = Callable[[str, str | None], Awaitable[bool]]

__all__ = ["PermissionResolver"]
