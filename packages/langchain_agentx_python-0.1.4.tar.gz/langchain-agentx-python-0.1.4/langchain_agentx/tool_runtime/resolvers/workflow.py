"""
tool_runtime/resolvers/workflow.py — 工作流场景权限 resolver

职责：
    为 workflow 节点提供同进程可批准/拒绝的等待点（Future 协调）。

链路位置：
    ToolExecutorPipeline ask 分支 await；审批侧通过 approve/reject 回填。

当前裁剪范围：
    仅支持基于 tool_name 的单键等待，不含跨会话持久化审批。
"""

from __future__ import annotations

import asyncio
from collections import deque


class WorkflowPermissionResolver:
    def __init__(self, *, timeout: float = 60.0) -> None:
        self._pending: dict[str, deque[asyncio.Future[bool]]] = {}
        self._timeout = timeout
        self._lock = asyncio.Lock()

    async def __call__(self, tool_name: str, ask_prompt: str | None) -> bool:
        _ = ask_prompt
        loop = asyncio.get_running_loop()
        future: asyncio.Future[bool] = loop.create_future()
        async with self._lock:
            queue = self._pending.setdefault(tool_name, deque())
            queue.append(future)
        try:
            return await asyncio.wait_for(future, timeout=self._timeout)
        except asyncio.TimeoutError:
            return False
        finally:
            async with self._lock:
                queue = self._pending.get(tool_name)
                if queue is not None:
                    try:
                        queue.remove(future)
                    except ValueError:
                        pass
                    if not queue:
                        self._pending.pop(tool_name, None)

    async def approve(self, tool_name: str) -> bool:
        future = await self._pop_next_pending(tool_name)
        if future and not future.done():
            future.set_result(True)
            return True
        return False

    async def reject(self, tool_name: str) -> bool:
        future = await self._pop_next_pending(tool_name)
        if future and not future.done():
            future.set_result(False)
            return True
        return False

    async def _pop_next_pending(self, tool_name: str) -> asyncio.Future[bool] | None:
        async with self._lock:
            queue = self._pending.get(tool_name)
            if not queue:
                return None
            future = queue.popleft()
            if not queue:
                self._pending.pop(tool_name, None)
            return future


__all__ = ["WorkflowPermissionResolver"]
