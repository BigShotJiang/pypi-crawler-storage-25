"""
tool_runtime/resolvers/background.py — 后台任务权限 resolver

职责：
    后台/批处理场景中拒绝 ask 请求并记录审计日志。

链路位置：
    ToolExecutorPipeline ask 分支调用，避免任务挂起等待人工输入。

当前裁剪范围：
    仅记录基础 warning 日志，不接入统一审计事件总线。
"""

from __future__ import annotations

import logging


class BackgroundPermissionResolver:
    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._log = logger or logging.getLogger(__name__)

    async def __call__(self, tool_name: str, ask_prompt: str | None) -> bool:
        self._log.warning(
            "background_permission_auto_deny tool=%s prompt=%s",
            tool_name,
            ask_prompt,
        )
        return False


__all__ = ["BackgroundPermissionResolver"]
