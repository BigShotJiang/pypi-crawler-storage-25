"""
tool_runtime/resolvers/ — ask 分支权限 resolver 集合

职责：
    汇总导出 PermissionResolver 协议与四类场景实现。

链路位置：
    由会话/工作流装配层注入 ToolExecutorPipeline。

当前裁剪范围：
    仅提供 resolver 定义与基础实现，不负责 UI 事件循环集成。
"""

from .agent_session import AgentSessionPermissionResolver, PermissionRequest
from .background import BackgroundPermissionResolver
from .base import PermissionResolver
from .conversation import ConversationPermissionResolver
from .workflow import WorkflowPermissionResolver

__all__ = [
    "PermissionResolver",
    "PermissionRequest",
    "AgentSessionPermissionResolver",
    "ConversationPermissionResolver",
    "BackgroundPermissionResolver",
    "WorkflowPermissionResolver",
]
