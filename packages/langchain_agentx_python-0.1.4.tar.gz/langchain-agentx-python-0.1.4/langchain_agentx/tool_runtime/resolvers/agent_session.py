"""
tool_runtime/resolvers/agent_session.py — CLI 会话权限确认 resolver

职责：
    在同进程交互场景中通过 asyncio.Queue + Future 等待用户批准/拒绝。

链路位置：
    AgentSession 注入 resolver -> ToolExecutorPipeline ask 分支 await。

当前裁剪范围：
    仅实现单路 UI 队列确认，不实现 hook/classifier 多路 race。
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable


@dataclass
class PermissionRequest:
    tool_name: str
    ask_prompt: str | None
    future: asyncio.Future[bool]
    created_at: float = field(default_factory=time.monotonic)


class _OnceGuard:
    """多路 race 原子 claim，防止重复 resolve。"""

    def __init__(self) -> None:
        self._claimed = False
        self._lock = asyncio.Lock()

    async def claim(self) -> bool:
        async with self._lock:
            if self._claimed:
                return False
            self._claimed = True
            return True


class AgentSessionPermissionResolver:
    """CLI 交互 resolver：支持 UI future 与 hook 决策多路 race。"""

    def __init__(
        self,
        request_queue: asyncio.Queue[PermissionRequest],
        *,
        timeout: float = 300.0,
        hook_runner: Callable[[str, str | None], Awaitable[bool | None]] | None = None,
    ) -> None:
        self._queue = request_queue
        self._timeout = timeout
        self._hook_runner = hook_runner

    async def __call__(self, tool_name: str, ask_prompt: str | None) -> bool:
        loop = asyncio.get_running_loop()
        future: asyncio.Future[bool] = loop.create_future()
        await self._queue.put(
            PermissionRequest(
                tool_name=tool_name,
                ask_prompt=ask_prompt,
                future=future,
            )
        )
        guard = _OnceGuard()
        ui_task = asyncio.create_task(self._await_ui_future(future, guard))
        tasks: list[asyncio.Task[bool | None]] = [ui_task]
        if self._hook_runner is not None:
            tasks.append(asyncio.create_task(self._await_hook_decision(tool_name, ask_prompt, guard, future)))
        try:
            done, pending = await asyncio.wait(
                tasks,
                timeout=self._timeout,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if not done:
                return False
            result = done.pop().result()
            return bool(result)
        except asyncio.TimeoutError:
            return False
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            if not future.done():
                future.cancel()

    async def _await_ui_future(self, future: asyncio.Future[bool], guard: _OnceGuard) -> bool | None:
        try:
            result = await asyncio.wait_for(future, timeout=self._timeout)
        except asyncio.TimeoutError:
            if await guard.claim():
                return False
            return None
        except asyncio.CancelledError:
            return None
        if await guard.claim():
            return result
        return None

    async def _await_hook_decision(
        self,
        tool_name: str,
        ask_prompt: str | None,
        guard: _OnceGuard,
        ui_future: asyncio.Future[bool],
    ) -> bool | None:
        if self._hook_runner is None:
            return None
        hook_result = await self._hook_runner(tool_name, ask_prompt)
        if hook_result is None:
            return None
        if await guard.claim():
            if not ui_future.done():
                ui_future.cancel()
            return bool(hook_result)
        return None


__all__ = ["PermissionRequest", "AgentSessionPermissionResolver"]
