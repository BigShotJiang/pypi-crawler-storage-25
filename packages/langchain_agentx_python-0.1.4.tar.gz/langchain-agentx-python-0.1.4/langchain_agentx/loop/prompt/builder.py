"""系统提示词优先级链构建器。

对标 Claude  Code：
  buildEffectiveSystemPrompt() → build_effective_system_prompt()

优先级（从高到低）：
  1. override_system_prompt  — 存在时直接返回，完全忽略其他所有来源
  2. system_prompt           — 基础提示词
  3. dynamic_sections        — session 级动态段（按列表顺序追加）
  4. append_system_prompt    — 追加在最后

注意：override 存在时，append_system_prompt 同样被忽略（与 CC 行为一致）。
"""

from __future__ import annotations

from .sections import SystemPromptSection, resolve_sections


def build_effective_system_prompt(
    *,
    system_prompt: str | None,
    override_system_prompt: str | None,
    append_system_prompt: str | None,
    dynamic_sections: list[SystemPromptSection],
    section_cache: dict[str, str | None],
) -> str | None:
    """构建当前轮次实际生效的系统提示词字符串。

    优先级规则：
    1. override 存在 → 直接返回，其余全部忽略（含 append）。
    2. 否则：base + sections + append 按顺序拼接，段间以双换行分隔。
    3. 全部为空 → 返回 None（不注入系统消息）。

    Args:
        system_prompt:          基础提示词字符串（已由 factory 从 str|SystemMessage 转换）。
        override_system_prompt: 最高优先级覆盖提示词，存在时完全替换其他来源。
        append_system_prompt:   追加在有效提示词末尾的字符串（override 时不追加）。
        dynamic_sections:       session 级动态段列表，由 resolve_sections 解析。
        section_cache:          来自 AgentState.section_cache，session 生命周期，
                                函数内部通过 resolve_sections 原地更新。

    Returns:
        最终的系统提示词字符串，或 None（不注入任何系统消息）。
    """
    # 优先级 1：override 直接返回
    if override_system_prompt is not None:
        return override_system_prompt

    # 优先级 2-3：解析动态 sections（session 级记忆化）
    section_texts = resolve_sections(dynamic_sections, section_cache)

    # 优先级 4：拼装 base + sections + append
    parts: list[str] = []
    if system_prompt:
        parts.append(system_prompt)
    parts.extend(section_texts)
    if append_system_prompt:
        parts.append(append_system_prompt)

    return "\n\n".join(parts) if parts else None
