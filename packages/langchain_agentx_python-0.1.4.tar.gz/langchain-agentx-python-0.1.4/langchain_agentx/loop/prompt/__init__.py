"""loop.prompt — 系统提示词管理。

提供三层能力：
1. Section 注册表（sections.py）— 段的定义、记忆化、解析
2. 优先级链（builder.py）— override → base → sections → append
3. 内置 section 工厂（builtin.py）— 环境信息、语言偏好、时间、Git 安全等
4. 压缩提示词（compact.py）— 上下文压缩用的提示词模板与格式化

公开 API：
    # 核心机制
    SystemPromptSection  — 段数据类
    section()            — 创建 session 级缓存的提示词段
    volatile_section()   — 创建每轮重算的提示词段
    resolve_sections()   — 解析段列表，返回文本列表
    build_effective_system_prompt() — 优先级链构建器

    # 内置 section 工厂
    env_section()        — 环境信息（OS/Python/工作目录）
    language_section()   — 语言偏好
    time_section()       — 当前时间（volatile）
    token_budget_section() — Token 预算提示
    git_safety_section() — Git 安全红线（禁止 force-push 等危险操作）
    tool_routing_guard_section() — 专用工具优先（系统级冗余强化）
    actions_safety_section() — 高风险动作确认与可逆性优先
    failure_diagnosis_section() — 失败后先诊断，不盲重试
    task_execution_baseline_section() — 任务执行基线（先读后改、忠实汇报）
    get_coding_sections() — 编码场景推荐 section 组合
    tools_summary_section() — 工具列表摘要（volatile）

    # 压缩提示词
    get_compact_prompt() — 全量压缩提示词
    get_partial_compact_prompt() — 部分压缩提示词
    build_autocompact_llm_instruction_prompt() — 按类型选择压缩提示词
    format_compact_summary() — 格式化压缩摘要
    get_compact_user_summary_message() — 用户续写消息包装
"""

from .builder import build_effective_system_prompt
from .builtin import (
    env_section,
    actions_safety_section,
    failure_diagnosis_section,
    get_coding_sections,
    git_safety_section,
    language_section,
    task_execution_baseline_section,
    time_section,
    token_budget_section,
    tool_routing_guard_section,
    tools_summary_section,
)
from .compact import (
    AutocompactLlmPromptKind,
    PartialCompactDirection,
    build_autocompact_llm_instruction_prompt,
    format_compact_summary,
    get_compact_prompt,
    get_compact_user_summary_message,
    get_partial_compact_prompt,
)
from .sections import (
    SystemPromptSection,
    resolve_sections,
    section,
    volatile_section,
)

__all__ = [
    # 核心机制
    "SystemPromptSection",
    "section",
    "volatile_section",
    "resolve_sections",
    "build_effective_system_prompt",
    # 内置 section 工厂
    "actions_safety_section",
    "env_section",
    "failure_diagnosis_section",
    "get_coding_sections",
    "git_safety_section",
    "language_section",
    "task_execution_baseline_section",
    "time_section",
    "token_budget_section",
    "tool_routing_guard_section",
    "tools_summary_section",
    # 压缩提示词
    "AutocompactLlmPromptKind",
    "PartialCompactDirection",
    "get_compact_prompt",
    "get_partial_compact_prompt",
    "build_autocompact_llm_instruction_prompt",
    "format_compact_summary",
    "get_compact_user_summary_message",
]
