"""SystemPromptSection — session 级提示词段注册表。

对标 Claude  Code：
  - systemPromptSection()           → section()
  - DANGEROUS_uncachedSystemPromptSection() → volatile_section()
  - resolveSystemPromptSections()   → resolve_sections()

和 CC 的核心差异：
  - 不包含任何 cache_control / cacheScope 逻辑（本工程使用 OpenAI 兼容接口，
    Anthropic 服务端 Prompt Cache 对本工程无效，详见
    docs/experience/prompt-system-and-cache-experience-2026-04-13.md）
  - 缓存存于调用方传入的 dict（来自 AgentState.section_cache），
    生命周期与 session 绑定，session 结束时随 state 销毁。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass
class SystemPromptSection:
    """可组合的系统提示词段。

    Attributes:
        name:     段的唯一标识名（同一 session 内作为 cache key）。
        compute:  计算段内容的函数，返回 str 时输出该段，返回 None 时跳过该段。
        volatile: False（默认）= session 内只计算一次，结果存入 section_cache 复用；
                  True = 每轮都重新调用 compute()，不读也不写 cache。
    """

    name: str
    compute: Callable[[], str | None]
    volatile: bool = False


def section(
    name: str,
    compute: Callable[[], str | None],
) -> SystemPromptSection:
    """创建 session 级缓存的提示词段。

    第一次调用 compute() 后，结果存入调用方传入的 section_cache dict；
    同一 session 的后续轮次直接读缓存，不再重新计算。

    适用场景：
    - 读取环境变量、系统信息（平台、Python 版本等）
    - 加载配置文件、用户偏好
    - 语言偏好、固定的工具使用说明

    Args:
        name:    段的唯一标识名，用作 section_cache 的 key。
        compute: 计算段内容的函数，返回 str 或 None（None 表示不输出该段）。

    Returns:
        volatile=False 的 SystemPromptSection。
    """
    return SystemPromptSection(name=name, compute=compute, volatile=False)


def volatile_section(
    name: str,
    compute: Callable[[], str | None],
    reason: str,
) -> SystemPromptSection:
    """创建每轮重算的提示词段。

    每次进入 model 节点前都重新调用 compute()，不读也不写 section_cache。
    ``reason`` 参数不影响运行逻辑，仅作代码意图标注，
    便于审查时快速定位"为什么这里不能缓存"。

    适用场景：
    - 当前时间戳
    - 会话中途动态加入/移除的工具列表
    - 任何每轮都可能变化的外部状态

    Args:
        name:    段的唯一标识名（volatile 段不使用 cache，但 name 仍用于调试日志）。
        compute: 计算段内容的函数，返回 str 或 None。
        reason:  必须说明为何不能缓存（审查用，不影响运行）。

    Returns:
        volatile=True 的 SystemPromptSection。
    """
    return SystemPromptSection(name=name, compute=compute, volatile=True)


def resolve_sections(
    sections: list[SystemPromptSection],
    cache: dict[str, str | None],
) -> list[str]:
    """按顺序解析 sections，返回所有非 None 的文本列表。

    缓存策略：
    - volatile=False：优先读 cache；miss 时调用 compute() 并写入 cache。
    - volatile=True ：每次都调用 compute()，不读也不写 cache。

    Args:
        sections: 要解析的段列表，按列表顺序输出。
        cache:    来自 AgentState.section_cache 的字典，session 生命周期。
                  函数会原地修改 cache（写入非 volatile 段的计算结果）。

    Returns:
        所有 compute() 返回非 None 值的文本列表，顺序与 sections 一致。
    """
    results: list[str] = []
    for s in sections:
        if s.volatile:
            val = s.compute()
        elif s.name not in cache:
            cache[s.name] = s.compute()
            val = cache[s.name]
        else:
            val = cache[s.name]

        if val is not None:
            results.append(val)

    return results
