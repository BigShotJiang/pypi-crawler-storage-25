"""
command.py — CommandExecutor（P2）。

职责：
    执行 command 类型 hook，负责子进程调用、退出码语义与 JSON 响应解析。

链路位置：
    HookEngine._run_one() 在 executor_type=="command" 时调用本执行器。

当前裁剪范围：
    实现 command 主路径、async/async_rewake、SESSION_START 的 CLAUDE_ENV_FILE 解析；
    并行调度语义由 HookEngine 在 F6 阶段统一处理。
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass
from typing import Any

from langchain_core.messages import HumanMessage

from ..config import HookCandidate
from ..types import HookContext, HookEvent, HookResult


@dataclass
class CommandExecutor:
    """command 类型 hook 执行器。"""

    async def run(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        config = candidate.spec.config
        command = str(config.get("command") or "").strip()
        if not command:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=["command hook missing 'command'"],
            )

        shell = str(config.get("shell") or "bash")
        async_mode = bool(config.get("async", False))
        async_rewake = bool(config.get("asyncRewake", False) or config.get("async_rewake", False))
        timeout = candidate.spec.timeout
        env = self._build_hook_env(candidate, ctx)

        if async_mode:
            asyncio.create_task(
                self._run_and_maybe_rewake(
                    command=command,
                    shell=shell,
                    timeout=timeout,
                    env=env,
                    ctx=ctx,
                    async_rewake=async_rewake,
                )
            )
            return HookResult(outcome="success")

        proc = await self._spawn_process(command=command, shell=shell, env=env)
        return await self._finalize_process(proc=proc, ctx=ctx, timeout=timeout, env=env)

    async def _run_and_maybe_rewake(
        self,
        *,
        command: str,
        shell: str,
        timeout: float,
        env: dict[str, str],
        ctx: HookContext,
        async_rewake: bool,
    ) -> None:
        proc = await self._spawn_process(command=command, shell=shell, env=env)
        result = await self._finalize_process(proc=proc, ctx=ctx, timeout=timeout, env=env)
        if not async_rewake:
            return
        if result.outcome != "success":
            return
        rewake_text = (result.additional_context or "").strip()
        if rewake_text:
            messages = ctx.state.get("messages")
            if isinstance(messages, list):
                messages.append(HumanMessage(content=rewake_text))

    async def _spawn_process(
        self,
        *,
        command: str,
        shell: str,
        env: dict[str, str],
    ) -> asyncio.subprocess.Process:
        if shell == "bash":
            return await asyncio.create_subprocess_exec(
                "bash",
                "-lc",
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
        if shell == "sh":
            return await asyncio.create_subprocess_exec(
                "sh",
                "-c",
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
        return await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )

    async def _finalize_process(
        self,
        *,
        proc: asyncio.subprocess.Process,
        ctx: HookContext,
        timeout: float,
        env: dict[str, str],
    ) -> HookResult:
        try:
            stdout_raw, stderr_raw = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=[f"command hook timeout after {timeout:.1f}s"],
            )

        stdout = stdout_raw.decode("utf-8", errors="replace")
        stderr = stderr_raw.decode("utf-8", errors="replace")
        returncode = int(proc.returncode or 0)

        result = HookResult(outcome="success")
        parsed_json = self._parse_json(stdout)
        if isinstance(parsed_json, dict):
            self._apply_json_result(result, parsed_json)

        if ctx.event == HookEvent.SESSION_START:
            session_env_patch = self._read_claude_env_file(env)
            if session_env_patch:
                result.state_patch["_session_env"] = session_env_patch

        if returncode == 0:
            if not result.additional_context and stdout.strip():
                result.additional_context = stdout.strip()
            return result
        if returncode == 2:
            result.outcome = "blocking"
            result.permission_behavior = result.permission_behavior or "deny"
            if not result.blocking_errors:
                result.blocking_errors = [stderr.strip() or "command hook blocked request"]
            return result
        result.outcome = "non_blocking_error"
        if not result.blocking_errors:
            result.blocking_errors = [stderr.strip() or f"command hook exited with {returncode}"]
        return result

    @staticmethod
    def _parse_json(stdout: str) -> dict[str, Any] | None:
        text = stdout.strip()
        if not text:
            return None
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return None
        return data if isinstance(data, dict) else None

    @staticmethod
    def _apply_json_result(result: HookResult, payload: dict[str, Any]) -> None:
        if payload.get("continue") is False:
            result.prevent_continuation = True
        stop_reason = payload.get("stopReason")
        if isinstance(stop_reason, str) and stop_reason.strip():
            result.blocking_errors.append(stop_reason.strip())
        decision = payload.get("decision")
        if decision in {"allow", "ask", "deny"}:
            result.permission_behavior = decision
        reason = payload.get("reason")
        if isinstance(reason, str) and reason.strip():
            result.hook_permission_decision_reason = reason.strip()
        updated_input = payload.get("updatedInput")
        if isinstance(updated_input, dict):
            result.updated_input = dict(updated_input)
        if payload.get("suppressOutput") is True:
            result.additional_context = ""

    @staticmethod
    def _build_hook_env(candidate: HookCandidate, ctx: HookContext) -> dict[str, str]:
        env = dict(os.environ)
        session_env = ctx.state.get("_session_env") if isinstance(ctx.state, dict) else None
        if isinstance(session_env, dict):
            for key, value in session_env.items():
                if isinstance(key, str) and isinstance(value, str):
                    env[key] = value
        env["HOOK_EVENT_NAME"] = ctx.event.value
        env["HOOK_TOOL_NAME"] = ctx.tool_name or ""
        env["HOOK_TOOL_INPUT"] = json.dumps(ctx.tool_input or {}, ensure_ascii=False)
        env["HOOK_SESSION_ID"] = ctx.session_id or ""
        env["HOOK_SNAPSHOT_ID"] = candidate.stable_key
        return env

    @staticmethod
    def _read_claude_env_file(env: dict[str, str]) -> dict[str, str]:
        path = env.get("CLAUDE_ENV_FILE")
        if not path:
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except OSError:
            return {}

        parsed: dict[str, str] = {}
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            if key:
                parsed[key] = value.strip()
        return parsed

