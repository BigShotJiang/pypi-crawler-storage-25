"""
agent.py — AgentExecutor（P2）。

职责：
    执行 agent 类型 hook，构建单轮验证器输入并解析 decision。

链路位置：
    HookEngine._run_one() 在 executor_type=="agent" 时调用本执行器。

当前裁剪范围：
    通过配置注入可调用对象执行验证器；prompt 字段仅在运行时读取，不做预处理。
"""

from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Any, Callable

from ..config import HookCandidate
from ..types import HookContext, HookResult


@dataclass
class AgentExecutor:
    """agent 类型 hook 执行器。"""

    async def run(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        config = candidate.spec.config
        # 对齐 gh-24920 / CC-79：prompt 在运行期按原值读取，不在构建阶段做任何 transform。
        system_prompt = config.get("prompt")
        if not isinstance(system_prompt, str) or not system_prompt.strip():
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=["agent hook missing 'prompt'"],
            )

        runner = self._resolve_runner(config)
        if runner is None:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=["agent hook missing callable runner"],
            )

        user_payload = json.dumps(
            {
                "event": ctx.event.value,
                "tool_name": ctx.tool_name,
                "tool_input": ctx.tool_input,
            },
            ensure_ascii=False,
        )
        output_text = await self._call_runner(
            runner=runner,
            system_prompt=system_prompt,
            user_payload=user_payload,
            model=config.get("model"),
            ctx=ctx,
        )
        return self._parse_decision(output_text)

    @staticmethod
    def _resolve_runner(config: dict[str, Any]) -> Callable[..., Any] | None:
        runner = config.get("runner") or config.get("agent_runner")
        return runner if callable(runner) else None

    @staticmethod
    async def _call_runner(
        *,
        runner: Callable[..., Any],
        system_prompt: str,
        user_payload: str,
        model: Any,
        ctx: HookContext,
    ) -> str:
        output = runner(system_prompt, user_payload, model, ctx)
        if inspect.isawaitable(output):
            output = await output
        return str(output or "")

    @staticmethod
    def _parse_decision(text: str) -> HookResult:
        lowered = text.lower()
        if "deny" in lowered:
            return HookResult(
                outcome="success",
                permission_behavior="deny",
                hook_permission_decision_reason=text.strip() or None,
            )
        if "ask" in lowered:
            return HookResult(
                outcome="success",
                permission_behavior="ask",
                hook_permission_decision_reason=text.strip() or None,
            )
        if "allow" in lowered:
            return HookResult(
                outcome="success",
                permission_behavior="allow",
                hook_permission_decision_reason=text.strip() or None,
            )
        return HookResult(
            outcome="non_blocking_error",
            blocking_errors=["agent hook cannot parse decision"],
        )

