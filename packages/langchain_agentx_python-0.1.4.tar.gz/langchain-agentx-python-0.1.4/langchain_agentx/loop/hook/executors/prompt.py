"""
prompt.py — PromptExecutor（P2）。

职责：
    执行 prompt 类型 hook，负责 `$ARGUMENTS` 替换与 decision 解析。

链路位置：
    HookEngine._run_one() 在 executor_type=="prompt" 时调用本执行器。

当前裁剪范围：
    通过配置注入可调用对象执行模型推理；并行调度在 F6 统一处理。
"""

from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Any, Callable

from ..config import HookCandidate
from ..types import HookContext, HookResult


@dataclass
class PromptExecutor:
    """prompt 类型 hook 执行器。"""

    async def run(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        config = candidate.spec.config
        template = str(config.get("prompt") or "").strip()
        if not template:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=["prompt hook missing 'prompt'"],
            )

        runner = self._resolve_runner(config)
        if runner is None:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=["prompt hook missing callable runner"],
            )

        arguments = json.dumps(ctx.tool_input or {}, ensure_ascii=False)
        rendered_prompt = template.replace("$ARGUMENTS", arguments)
        output_text = await self._call_runner(runner, rendered_prompt, config, ctx)
        return self._parse_decision(output_text)

    @staticmethod
    def _resolve_runner(config: dict[str, Any]) -> Callable[..., Any] | None:
        runner = config.get("runner") or config.get("llm") or config.get("model_runner")
        return runner if callable(runner) else None

    @staticmethod
    async def _call_runner(
        runner: Callable[..., Any],
        rendered_prompt: str,
        config: dict[str, Any],
        ctx: HookContext,
    ) -> str:
        output = runner(rendered_prompt, config.get("model"), ctx)
        if inspect.isawaitable(output):
            output = await output
        return str(output or "")

    @staticmethod
    def _parse_decision(text: str) -> HookResult:
        lowered = text.lower()
        if "deny" in lowered:
            return HookResult(
                outcome="success",
                permission_behavior="deny",
                hook_permission_decision_reason=text.strip() or None,
            )
        if "ask" in lowered:
            return HookResult(
                outcome="success",
                permission_behavior="ask",
                hook_permission_decision_reason=text.strip() or None,
            )
        if "allow" in lowered:
            return HookResult(
                outcome="success",
                permission_behavior="allow",
                hook_permission_decision_reason=text.strip() or None,
            )
        return HookResult(
            outcome="non_blocking_error",
            blocking_errors=["prompt hook cannot parse decision"],
        )

