"""
http.py — HttpExecutor（P2）。

职责：
    执行 http 类型 hook，负责请求构建、响应解析与错误收敛。

链路位置：
    HookEngine._run_one() 在 executor_type=="http" 时调用本执行器。

当前裁剪范围：
    实现 HTTP POST 主路径与 JSON 协议解析；并行调度由 F6 统一处理。
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

import httpx

from ..config import HookCandidate
from ..types import HookContext, HookResult


@dataclass
class HttpExecutor:
    """http 类型 hook 执行器。"""

    async def run(self, candidate: HookCandidate, ctx: HookContext) -> HookResult:
        config = candidate.spec.config
        url = str(config.get("url") or "").strip()
        if not url:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=["http hook missing 'url'"],
            )

        timeout = candidate.spec.timeout
        body = {
            "event": ctx.event.value,
            "session_id": ctx.session_id,
            "tool_name": ctx.tool_name,
            "tool_input": ctx.tool_input,
            "hook_stable_key": candidate.stable_key,
        }
        headers = self._build_headers(config)

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.post(url, json=body, headers=headers)
        except Exception as exc:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=[f"http hook request failed: {exc}"],
            )

        if response.status_code != 200:
            return HookResult(
                outcome="non_blocking_error",
                blocking_errors=[f"http hook status {response.status_code}"],
            )

        payload = self._parse_json(response)
        result = HookResult(outcome="success")
        if isinstance(payload, dict):
            self._apply_json_result(result, payload)
        return result

    @staticmethod
    def _build_headers(config: dict[str, Any]) -> dict[str, str]:
        headers_raw = config.get("headers")
        headers: dict[str, str] = {}
        if isinstance(headers_raw, dict):
            headers = {str(k): str(v) for k, v in headers_raw.items()}

        allowed_raw = config.get("allowedEnvVars")
        allowed_env = allowed_raw if isinstance(allowed_raw, list) else []
        env_values = {name: os.environ.get(name, "") for name in allowed_env if isinstance(name, str)}
        for key, value in list(headers.items()):
            rendered = value
            for env_name, env_val in env_values.items():
                rendered = rendered.replace(f"${env_name}", env_val)
            headers[key] = rendered
        return headers

    @staticmethod
    def _parse_json(response: httpx.Response) -> dict[str, Any] | None:
        try:
            data = response.json()
        except json.JSONDecodeError:
            return None
        except Exception:
            return None
        return data if isinstance(data, dict) else None

    @staticmethod
    def _apply_json_result(result: HookResult, payload: dict[str, Any]) -> None:
        if payload.get("continue") is False:
            result.prevent_continuation = True
        stop_reason = payload.get("stopReason")
        if isinstance(stop_reason, str) and stop_reason.strip():
            result.blocking_errors.append(stop_reason.strip())
        decision = payload.get("decision")
        if decision in {"allow", "ask", "deny"}:
            result.permission_behavior = decision
        reason = payload.get("reason")
        if isinstance(reason, str) and reason.strip():
            result.hook_permission_decision_reason = reason.strip()
        updated_input = payload.get("updatedInput")
        if isinstance(updated_input, dict):
            result.updated_input = dict(updated_input)

