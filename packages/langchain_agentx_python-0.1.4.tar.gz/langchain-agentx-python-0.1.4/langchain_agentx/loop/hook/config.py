"""
config.py — Hook 配置快照与候选集构建（P1/P2）。

职责：
    定义 HookSpec，维护 HooksConfigSnapshot，并产出可执行候选列表。

链路位置：
    HookEngine 在每次事件执行前通过 snapshot 拉取 candidates。

当前裁剪范围：
    已支持 P1/P2 执行器候选构建（matcher/condition/policy/dedup/type-order）；
    与执行器并行策略由 HookEngine 协同完成。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from fnmatch import fnmatch
import json
from threading import Lock
from typing import Any, Callable, Literal
from uuid import uuid4

from .types import HookContext, HookEvent, HookSource

ExecutorType = Literal["function", "callback", "command", "http", "prompt", "agent"]
HTTP_UNSUPPORTED_EVENTS = {HookEvent.SESSION_START}
TYPE_ORDER: dict[ExecutorType, int] = {
    "command": 0,
    "prompt": 1,
    "agent": 2,
    "http": 3,
    "callback": 4,
    "function": 5,
}


@dataclass
class HookSpec:
    """单条 Hook 配置。"""

    event: HookEvent
    executor_type: ExecutorType
    config: dict[str, Any] = field(default_factory=dict)
    matcher: str = "*"
    timeout: float = 30.0
    managed: bool = False
    source: HookSource = "settings"
    plugin_source: str | None = None
    once: bool = False
    on_success: Callable[[], None] | None = None
    hook_id: str = field(default_factory=lambda: uuid4().hex)

    def matches(self, ctx: HookContext) -> bool:
        """根据 matcher 判断是否命中当前上下文。"""
        if self.event != ctx.event:
            return False
        if self.matcher == "*":
            return True
        if ctx.tool_name is None:
            return False
        return fnmatch(ctx.tool_name, self.matcher)


@dataclass(frozen=True)
class HookCandidate:
    """可执行候选（带稳定顺序键）。"""

    spec: HookSpec
    stable_key: str


@dataclass(frozen=True)
class HookCandidateDecision:
    """候选筛选决策记录（用于可观测跳过原因）。"""

    spec: HookSpec
    stable_key: str
    matched: bool
    skip_reason: str | None


class HooksConfigSnapshot:
    """多来源 Hook 配置快照。"""

    def __init__(self) -> None:
        self.snapshot_id: str = uuid4().hex
        self._specs: list[HookSpec] = []
        self._lock = Lock()
        self._disable_all: bool = False
        self._allow_managed_only: bool = False
        self._policy_source: str | None = None

    @property
    def disable_all(self) -> bool:
        return self._disable_all

    @property
    def allow_managed_only(self) -> bool:
        return self._allow_managed_only

    @property
    def policy_source(self) -> str | None:
        return self._policy_source

    def add_spec(self, spec: HookSpec) -> None:
        self._specs.append(spec)

    def load_from_settings(self, settings: dict[str, Any]) -> None:
        self._disable_all = bool(settings.get("disable_all_hooks", False))
        self._allow_managed_only = bool(settings.get("allow_managed_hooks_only", False))
        self._policy_source = settings.get("policy_source")

    def register_session_hook(self, spec: HookSpec) -> str:
        session_spec = HookSpec(
            event=spec.event,
            executor_type=spec.executor_type,
            config=dict(spec.config),
            matcher=spec.matcher,
            timeout=spec.timeout,
            managed=spec.managed,
            source="session",
            once=spec.once,
            on_success=spec.on_success,
        )
        self._specs.append(session_spec)
        return session_spec.hook_id

    def unregister_session_hook(self, hook_id: str) -> None:
        self._specs = [spec for spec in self._specs if spec.hook_id != hook_id]

    def replace_plugin_hooks_atomic(self, specs: list[HookSpec]) -> None:
        """原子替换所有插件来源 hook（仅影响 source == "plugin"）。"""
        with self._lock:
            self._specs = [spec for spec in self._specs if spec.source != "plugin"]
            self._specs.extend(specs)

    def remove_plugin_hooks(self, plugin_source: str) -> None:
        """移除指定插件来源 hook（仅影响 source == "plugin"）。"""
        with self._lock:
            self._specs = [
                spec
                for spec in self._specs
                if not (
                    spec.source == "plugin" and spec.plugin_source == plugin_source
                )
            ]

    def get_candidates(self, ctx: HookContext) -> list[HookCandidate]:
        """构建候选集：matcher -> last-wins 去重 -> 类型重排序。"""
        candidates, _ = self.get_candidates_with_decisions(ctx)
        return candidates

    def get_candidates_with_decisions(
        self, ctx: HookContext
    ) -> tuple[list[HookCandidate], list[HookCandidateDecision]]:
        """构建候选集并返回被跳过的决策记录。"""
        skipped: list[HookCandidateDecision] = []
        dedup: dict[str, HookSpec] = {}

        for spec in self._specs:
            if spec.event != ctx.event:
                continue
            key = self._dedup_key(spec)
            if not spec.matches(ctx):
                skipped.append(
                    HookCandidateDecision(
                        spec=spec,
                        stable_key=key,
                        matched=False,
                        skip_reason="matcher_not_matched",
                    )
                )
                continue
            if spec.executor_type == "http" and ctx.event in HTTP_UNSUPPORTED_EVENTS:
                skipped.append(
                    HookCandidateDecision(
                        spec=spec,
                        stable_key=key,
                        matched=True,
                        skip_reason="http_unsupported_event",
                    )
                )
                continue
            condition = str(spec.config.get("if") or "").strip() or None
            if not evaluate_condition(condition, ctx):
                skipped.append(
                    HookCandidateDecision(
                        spec=spec,
                        stable_key=key,
                        matched=True,
                        skip_reason="condition_not_matched",
                    )
                )
                continue
            policy_skip = self._policy_skip_reason(spec)
            if policy_skip is not None:
                skipped.append(
                    HookCandidateDecision(
                        spec=spec,
                        stable_key=key,
                        matched=True,
                        skip_reason=policy_skip,
                    )
                )
                continue
            if key in dedup:
                skipped.append(
                    HookCandidateDecision(
                        spec=dedup[key],
                        stable_key=key,
                        matched=True,
                        skip_reason="dedup_overridden",
                    )
                )
            dedup[key] = spec

        deduped = list(dedup.items())
        deduped.sort(key=lambda kv: (TYPE_ORDER[kv[1].executor_type], kv[0]))
        candidates = [HookCandidate(spec=spec, stable_key=key) for key, spec in deduped]
        return candidates, skipped

    def _policy_skip_reason(self, spec: HookSpec) -> str | None:
        if self._disable_all and not spec.managed:
            return "disable_all"
        if self._allow_managed_only and not spec.managed:
            return "managed_only"
        return None

    @staticmethod
    def _dedup_key(spec: HookSpec) -> str:
        name = str(spec.config.get("name") or spec.config.get("id") or spec.hook_id)
        return f"{spec.event.value}:{spec.matcher}:{name}"


def resolve_executor_callable(spec: HookSpec) -> Callable[..., Any]:
    """从 HookSpec config 解析可执行对象。"""
    fn = spec.config.get("fn") or spec.config.get("callback")
    if not callable(fn):
        raise TypeError(f"HookSpec {spec.hook_id} missing callable 'fn/callback'")
    return fn


def evaluate_condition(condition: str | None, ctx: HookContext) -> bool:
    """评估 Hook `if` 条件，支持 `tool_name(arg_glob)` 简化语法。"""
    if condition is None:
        return True
    text = condition.strip()
    if not text:
        return True
    if text == "*":
        return True

    open_idx = text.find("(")
    if open_idx == -1:
        return bool(ctx.tool_name) and fnmatch(ctx.tool_name, text)

    if not text.endswith(")") or open_idx == 0:
        return False

    tool_pattern = text[:open_idx].strip()
    arg_pattern = text[open_idx + 1 : -1].strip()
    if not ctx.tool_name or not fnmatch(ctx.tool_name, tool_pattern):
        return False
    if not arg_pattern:
        return True

    tool_input_json = json.dumps(ctx.tool_input or {}, ensure_ascii=False)
    return fnmatch(tool_input_json, arg_pattern)


__all__ = [
    "ExecutorType",
    "HookCandidate",
    "HookCandidateDecision",
    "HookSpec",
    "HooksConfigSnapshot",
    "evaluate_condition",
    "resolve_executor_callable",
]
