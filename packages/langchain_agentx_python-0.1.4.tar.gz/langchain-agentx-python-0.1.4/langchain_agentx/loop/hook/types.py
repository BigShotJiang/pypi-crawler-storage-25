"""
types.py — Hook 子系统共享类型定义。

职责：
    定义 Hook 事件枚举、执行上下文、单 Hook 结果、聚合结果和执行记录契约。

链路位置：
    被 `loop/hook/config.py`、`loop/hook/engine.py` 与 graph wiring/observability 调用。

当前裁剪范围：
    P1 仅覆盖 callback/function 路径；command/http 执行器在 P2 引入。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal

PermissionBehavior = Literal["allow", "ask", "deny", "passthrough"]
HookOutcome = Literal["success", "blocking", "non_blocking_error", "cancelled", "trust_skipped"]
HookSource = Literal["settings", "policy", "session", "builtin", "plugin"]


class HookEvent(str, Enum):
    """Hook 事件枚举（P1 + P2 预留）。"""

    SESSION_START = "session_start"
    SESSION_END = "session_end"
    LOOP_START = "loop_start"
    LOOP_END = "loop_end"
    BEFORE_MODEL = "before_model"
    AFTER_MODEL = "after_model"
    STOP = "stop"
    PRE_TOOL_USE = "pre_tool_use"
    POST_TOOL_USE = "post_tool_use"
    POST_TOOL_USE_FAILURE = "post_tool_use_failure"
    PRE_COMPACT = "pre_compact"
    POST_COMPACT = "post_compact"
    SUBAGENT_START = "subagent_start"
    SUBAGENT_STOP = "subagent_stop"
    STOP_FAILURE = "stop_failure"


@dataclass(frozen=True)
class HookContext:
    """传入 Hook 执行器的只读上下文。"""

    event: HookEvent
    state: dict[str, Any]
    session_id: str | None = None
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    tool_result: Any = None


@dataclass
class HookExecutionRecord:
    """可观测记录最小字段契约（供 HookEventEmitter/TraceCollector 使用）。"""

    hook_id: str
    hook_event: str
    hook_source: HookSource
    matcher: str
    matched: bool
    skip_reason: str | None
    snapshot_id: str
    policy_source: str | None
    outcome: HookOutcome
    prevent_continuation: bool
    duration_ms: float


@dataclass
class HookResult:
    """单个 Hook 执行结果。"""

    outcome: HookOutcome = "success"
    prevent_continuation: bool = False
    blocking_errors: list[str] = field(default_factory=list)
    permission_behavior: PermissionBehavior | None = None
    hook_permission_decision_reason: str | None = None
    additional_context: str | None = None
    updated_input: dict[str, Any] | None = None
    state_patch: dict[str, Any] = field(default_factory=dict)


@dataclass
class AggregatedHookResult:
    """同一事件多个 Hook 的聚合结果。"""

    prevent_continuation: bool = False
    blocking_errors: list[str] = field(default_factory=list)
    permission_behavior: PermissionBehavior | None = None
    hook_permission_decision_reason: str | None = None
    additional_contexts: list[str] = field(default_factory=list)
    updated_input: dict[str, Any] | None = None
    state_patch: dict[str, Any] = field(default_factory=dict)


__all__ = [
    "AggregatedHookResult",
    "HookContext",
    "HookEvent",
    "HookExecutionRecord",
    "HookOutcome",
    "HookResult",
    "HookSource",
    "PermissionBehavior",
]
