"""
loop.hook — Hook 子系统（P1/P2）。

职责：
    提供 Hook 定义、配置快照与执行引擎的公共导出。

链路位置：
    由 loop 图装配层调用，用于替代历史中间件机制。

当前裁剪范围：
    已包含 P1 + P2 基础执行器导出；并行聚合与治理细节见 HookEngine/规划文档。
"""

from .config import HookCandidate, HookCandidateDecision, HookSpec, HooksConfigSnapshot
from .async_hook_runner import AsyncHookRunner
from .engine import HookEngine
from .executors import AgentExecutor, CommandExecutor, HttpExecutor, PromptExecutor
from .graph_wiring import HookGraphWiring
from .registry import HookRegistry
from .trust import WorkspaceTrustChecker
from .types import (
    AggregatedHookResult,
    HookContext,
    HookEvent,
    HookExecutionRecord,
    HookResult,
)

__all__ = [
    "AggregatedHookResult",
    "AsyncHookRunner",
    "HookCandidate",
    "HookCandidateDecision",
    "HookContext",
    "HookEngine",
    "HookEvent",
    "HookExecutionRecord",
    "HookGraphWiring",
    "HookRegistry",
    "HookResult",
    "HookSpec",
    "HooksConfigSnapshot",
    "CommandExecutor",
    "HttpExecutor",
    "PromptExecutor",
    "AgentExecutor",
    "WorkspaceTrustChecker",
]
