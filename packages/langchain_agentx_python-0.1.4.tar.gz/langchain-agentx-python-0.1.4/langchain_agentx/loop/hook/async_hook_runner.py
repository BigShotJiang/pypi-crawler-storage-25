"""
async_hook_runner.py — Hook 同步入口的异步执行协作者。

职责：
    为同步节点提供统一的 async hook 执行策略，避免 event loop 存在时退化跳过。

链路位置：
    HookGraphWiring 与 graph_edges 通过本协作者调用 HookEngine.execute()。

当前裁剪范围：
    P1 仅实现线程桥接执行；不引入 nest_asyncio，不修改外部事件循环。
"""

from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

from .engine import HookEngine
from .types import AggregatedHookResult, HookContext


class AsyncHookRunner:
    """同步调用场景下的 Hook 执行器。"""

    def __init__(self) -> None:
        self._executor: ThreadPoolExecutor | None = None
        self._executor_lock = Lock()

    def run(self, hook_engine: HookEngine, ctx: HookContext) -> AggregatedHookResult:
        """统一执行 HookEngine.execute，兼容有无运行中事件循环两种场景。"""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(hook_engine.execute(ctx))
        return self._run_in_thread(hook_engine, ctx)

    def _run_in_thread(self, hook_engine: HookEngine, ctx: HookContext) -> AggregatedHookResult:
        """在独立线程内创建事件循环执行 hook。"""
        executor = self._get_or_create_executor()
        future = executor.submit(self._thread_entry, hook_engine, ctx)
        return future.result()

    def _get_or_create_executor(self) -> ThreadPoolExecutor:
        with self._executor_lock:
            if self._executor is None:
                self._executor = ThreadPoolExecutor(max_workers=1)
            return self._executor

    def close(self) -> None:
        with self._executor_lock:
            if self._executor is not None:
                self._executor.shutdown(wait=True)
                self._executor = None

    @staticmethod
    def _thread_entry(hook_engine: HookEngine, ctx: HookContext) -> AggregatedHookResult:
        return asyncio.run(hook_engine.execute(ctx))


__all__ = ["AsyncHookRunner"]
