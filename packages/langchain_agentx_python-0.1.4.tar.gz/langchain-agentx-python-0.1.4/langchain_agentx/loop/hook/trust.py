"""
trust.py — Hook 执行信任闸门。

职责：
    在 HookEngine 执行前判断当前工作区信任状态，决定是否跳过高风险执行器。

链路位置：
    HookEngine.execute() 入口处调用，集中拦截 command/http/agent。

当前裁剪范围：
    仅提供 should_skip/skip_reason 判断，不负责 trust 交互与持久化。
"""

from __future__ import annotations

HIGH_RISK_EXECUTORS = frozenset({"command", "http", "agent"})


class WorkspaceTrustChecker:
    """Hook 执行前的工作区信任检查器。"""

    def __init__(
        self,
        *,
        headless: bool = False,
        workspace_trust_accepted: bool = False,
    ) -> None:
        self._headless = headless
        self._workspace_trust_accepted = workspace_trust_accepted

    def should_skip(self, executor_type: str) -> bool:
        if executor_type not in HIGH_RISK_EXECUTORS:
            return False
        return not self._workspace_trust_accepted

    def skip_reason(self, executor_type: str) -> str:
        return (
            "workspace trust not accepted; "
            f"executor type '{executor_type}' requires trusted workspace"
        )


__all__ = ["HIGH_RISK_EXECUTORS", "WorkspaceTrustChecker"]
