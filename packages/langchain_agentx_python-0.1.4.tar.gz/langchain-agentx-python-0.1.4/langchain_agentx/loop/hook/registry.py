"""
registry.py — HookRegistry 用户侧入口。

职责：
    提供类型安全的 Hook 注册 API（装饰器 / 命令式），通过 build_snapshot() 桥接到
    HooksConfigSnapshot，对用户隐藏 HookSpec 内部结构。

链路位置：
    用户构造 HookRegistry 后传入 create_loop_agent(hooks=registry)；
    LoopGraphBuilder._prepare_compile_context() 调用 build_snapshot() 获取快照。

当前裁剪范围：
    已支持 P1/P2 执行器注册（function/callback/command/http/prompt/agent）。
"""

from __future__ import annotations

from typing import Any, Callable

from .config import HookSpec, HooksConfigSnapshot
from .types import HookEvent


class HookRegistry:
    """用户侧 Hook 注册入口。

    隐藏 HookSpec 内部结构，通过 build_snapshot() 桥接到 HooksConfigSnapshot。
    """

    def __init__(self) -> None:
        self._specs: list[HookSpec] = []
        self._snapshots: list[HooksConfigSnapshot] = []

    # ── 装饰器 API（P1）──

    def on(
        self,
        event: HookEvent,
        *,
        matcher: str = "*",
        timeout: float = 30.0,
        managed: bool = False,
        once: bool = False,
    ) -> Callable:
        """注册 function hook（装饰器用法）。"""
        def decorator(fn: Callable) -> Callable:
            self._specs.append(self._make_spec(
                event=event,
                executor_type="function",
                config={"fn": fn},
                matcher=matcher,
                timeout=timeout,
                managed=managed,
                source="session",
                once=once,
            ))
            return fn
        return decorator

    def add_callback(
        self,
        event: HookEvent,
        callback: Callable,
        *,
        matcher: str = "*",
        timeout: float = 30.0,
        managed: bool = False,
        once: bool = False,
    ) -> str:
        """注册 callback hook，返回 hook_id 供撤销。"""
        spec = self._make_spec(
            event=event,
            executor_type="callback",
            config={"fn": callback},
            matcher=matcher,
            timeout=timeout,
            managed=managed,
            source="session",
            once=once,
        )
        self._specs.append(spec)
        return spec.hook_id

    def remove(self, hook_id: str) -> None:
        """撤销已注册的 hook。"""
        self._specs = [s for s in self._specs if s.hook_id != hook_id]
        for snapshot in self._snapshots:
            snapshot.unregister_session_hook(hook_id)

    # ── P2 注册 API ──

    def add_command(
        self,
        event: HookEvent,
        command: str,
        *,
        matcher: str = "*",
        timeout: float = 60.0,
        shell: str = "bash",
        condition: str | None = None,
        once: bool = False,
        async_: bool = False,
        async_rewake: bool = False,
    ) -> str:
        """注册 command hook。"""
        spec = self._make_spec(
            event=event,
            executor_type="command",
            config={
                "command": command,
                "shell": shell,
                "if": condition,
                "once": once,
                "async": async_,
                "asyncRewake": async_rewake,
            },
            matcher=matcher,
            timeout=timeout,
            source="session",
            once=once,
        )
        self._specs.append(spec)
        return spec.hook_id

    def add_http(
        self,
        event: HookEvent,
        url: str,
        *,
        matcher: str = "*",
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        allowed_env_vars: list[str] | None = None,
        condition: str | None = None,
        once: bool = False,
    ) -> str:
        """注册 http hook。"""
        spec = self._make_spec(
            event=event,
            executor_type="http",
            config={
                "url": url,
                "headers": headers or {},
                "allowedEnvVars": allowed_env_vars or [],
                "if": condition,
                "once": once,
            },
            matcher=matcher,
            timeout=timeout,
            source="session",
            once=once,
        )
        self._specs.append(spec)
        return spec.hook_id

    def add_prompt(
        self,
        event: HookEvent,
        prompt: str,
        runner: Callable,
        *,
        matcher: str = "*",
        timeout: float = 30.0,
        model: str | None = None,
        condition: str | None = None,
        once: bool = False,
    ) -> str:
        """注册 prompt hook。"""
        config: dict[str, Any] = {
            "prompt": prompt,
            "runner": runner,
            "if": condition,
            "once": once,
        }
        if model is not None:
            config["model"] = model
        spec = self._make_spec(
            event=event,
            executor_type="prompt",
            config=config,
            matcher=matcher,
            timeout=timeout,
            source="session",
            once=once,
        )
        self._specs.append(spec)
        return spec.hook_id

    def add_agent(
        self,
        event: HookEvent,
        prompt: str,
        runner: Callable,
        *,
        matcher: str = "*",
        timeout: float = 60.0,
        model: str | None = None,
        condition: str | None = None,
        once: bool = False,
    ) -> str:
        """注册 agent hook。"""
        config: dict[str, Any] = {
            "prompt": prompt,
            "runner": runner,
            "if": condition,
            "once": once,
        }
        if model is not None:
            config["model"] = model
        spec = self._make_spec(
            event=event,
            executor_type="agent",
            config=config,
            matcher=matcher,
            timeout=timeout,
            source="session",
            once=once,
        )
        self._specs.append(spec)
        return spec.hook_id

    # ── 桥接到引擎层 ──

    def build_snapshot(self) -> HooksConfigSnapshot:
        """将注册的所有 spec 构建为 HooksConfigSnapshot，供 HookEngine 消费。"""
        snapshot = HooksConfigSnapshot()
        for spec in self._specs:
            snapshot.add_spec(spec)
        self._snapshots.append(snapshot)
        return snapshot

    def __len__(self) -> int:
        return len(self._specs)

    def _make_spec(
        self,
        *,
        event: HookEvent,
        executor_type: str,
        config: dict[str, Any],
        matcher: str,
        timeout: float,
        source: str,
        managed: bool = False,
        once: bool = False,
    ) -> HookSpec:
        spec = HookSpec(
            event=event,
            executor_type=executor_type,
            config=config,
            matcher=matcher,
            timeout=timeout,
            managed=managed,
            source=source,
            once=once,
        )
        if once:
            spec.on_success = lambda hook_id=spec.hook_id: self.remove(hook_id)
        return spec


__all__ = ["HookRegistry"]
