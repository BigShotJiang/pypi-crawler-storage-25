"""
工具后附件注入去重（与 `post-tools-injection-contract.md` 一致）。

`task_event_reserve` 在 extend `LoopInjectionBatch.attachment_messages` 前应调用
`filter_attachment_dicts_by_task_command_id`，避免同一 `command_id` 在 `messages` 中重复出现。
"""

from __future__ import annotations

from typing import Any


def extract_task_notification_command_id(message: Any) -> str | None:
    """从单条消息解析 `metadata.task_notification.command_id`（dict 或 LC BaseMessage）。"""
    if isinstance(message, dict):
        meta = message.get("metadata")
        if isinstance(meta, dict):
            tn = meta.get("task_notification")
            if isinstance(tn, dict):
                cid = tn.get("command_id")
                return str(cid) if cid is not None and str(cid) != "" else None
        return None

    ak = getattr(message, "additional_kwargs", None)
    if isinstance(ak, dict):
        meta = ak.get("metadata")
        if isinstance(meta, dict):
            tn = meta.get("task_notification")
            if isinstance(tn, dict):
                cid = tn.get("command_id")
                return str(cid) if cid is not None and str(cid) != "" else None
    return None


def collect_task_notification_command_ids(messages: list[Any]) -> set[str]:
    """扫描已有 `messages` 中已出现的 task_notification command_id 集合。"""
    out: set[str] = set()
    for m in messages:
        cid = extract_task_notification_command_id(m)
        if cid is not None:
            out.add(cid)
    return out


def filter_attachment_dicts_by_task_command_id(
    existing_messages: list[Any],
    attachment_dicts: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """过滤待注入的 attachment dict：跳过 `command_id` 已在 `existing_messages` 中出现过的项。

    无 `command_id` 的 dict **保留**（非 task 通知形状不 dedup）。
    """
    seen = collect_task_notification_command_ids(existing_messages)
    added: list[dict[str, Any]] = []
    for att in attachment_dicts:
        if not isinstance(att, dict):
            added.append(att)
            continue
        cid = extract_task_notification_command_id(att)
        if cid is None:
            added.append(att)
            continue
        if cid in seen:
            continue
        seen.add(cid)
        added.append(att)
    return added


__all__ = [
    "collect_task_notification_command_ids",
    "extract_task_notification_command_id",
    "filter_attachment_dicts_by_task_command_id",
]
