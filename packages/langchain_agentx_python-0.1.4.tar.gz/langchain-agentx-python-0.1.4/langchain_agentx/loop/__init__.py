"""
LangChain AgentX Agent - 基于 LangGraph 实现的 LangChain AgentX 风格 Agent

核心特性：
1. 使用原生 finish_reason 判断退出（与 OpenCode 一致）
2. 与 LangGraph 生态完全兼容
3. 解决 create_agent 的"工具调用噩梦"

使用方式：
```python
from langchain_agentx.loop import create_loop_agent
from langchain_agentx.tool_runtime import ToolRuntimeLoader
# from langchain_agentx.tools.read import ReadRuntimeTool

loader = ToolRuntimeLoader()
# loader.register(ReadRuntimeTool())

agent = create_loop_agent(
    model="anthropic:claude-sonnet-4-5-20250929",
    loader=loader,
    system_prompt="You are a helpful assistant",
    max_steps=50,
)

for chunk in agent.stream({"messages": [{"role": "user", "content": "Hello"}]}):
    print(chunk)
```

参考设计文档：
- .claude/design/lowest-layer-opencode-style-agent-design.md（原理和问题）
- .claude/design/create-opencode-style-agent-design.md（实现方案）
"""

# 主要导出
from .graph.factory import (
    create_loop_agent,
)
from .loop_abort import LoopAbortSignal
from .config import build_agent_config

__all__ = [
    # 主要接口
    "create_loop_agent",
    "LoopAbortSignal",
    # 配置助手
    "build_agent_config",
]
