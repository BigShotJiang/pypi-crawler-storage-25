"""loop/config/token_estimator.py — token 估算协作者。

职责：
    - 优先使用消息中的真实 usage 元数据估算 token。
    - 无真实 usage 时回退到字符近似估算。

链路位置：
    - memory/session/session_memory.py：决定是否触发 session memory 提取。
    - 后续 P2b：可被更多 loop 消费侧复用。

当前裁剪范围：
    - 仅实现消息级 token 估算；不负责 context window 判定。
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

class TokenEstimator:
    """真实 usage 优先，字符近似兜底。"""

    def __init__(self, *, num_chars_per_token: int = 4) -> None:
        self._num_chars_per_token = num_chars_per_token

    def estimate_messages_tokens(self, messages: list[Any]) -> int:
        baseline_tokens: int | None = None
        baseline_index = -1

        for index in range(len(messages) - 1, -1, -1):
            usage_tokens = self.extract_usage_tokens(messages[index])
            if usage_tokens is not None:
                baseline_tokens = usage_tokens
                baseline_index = index
                break

        if baseline_tokens is None:
            return self._estimate_chars_tokens(messages)

        return baseline_tokens + self._estimate_chars_tokens(messages[baseline_index + 1 :])

    def extract_usage_tokens(self, message: Any) -> int | None:
        usage = self._extract_usage_payload(message)
        if not usage:
            return None

        if "input_tokens" in usage:
            return (
                self._as_int(usage.get("input_tokens"))
                + self._as_int(usage.get("cache_creation_input_tokens"))
                + self._as_int(usage.get("cache_read_input_tokens"))
                + self._as_int(usage.get("output_tokens"))
            )

        if "prompt_tokens" in usage or "completion_tokens" in usage:
            return self._as_int(usage.get("prompt_tokens")) + self._as_int(
                usage.get("completion_tokens")
            )

        if "total_tokens" in usage:
            total_tokens = self._as_int(usage.get("total_tokens"))
            return total_tokens if total_tokens > 0 else None

        return None

    def _estimate_chars_tokens(self, messages: list[Any]) -> int:
        total_chars = 0
        for message in messages:
            total_chars += len(self._stringify_content(self._extract_content(message)))
        return self._estimate_tokens_from_chars(total_chars)

    @staticmethod
    def _extract_usage_payload(message: Any) -> Mapping[str, Any] | None:
        if isinstance(message, Mapping):
            response_metadata = message.get("response_metadata")
            if isinstance(response_metadata, Mapping):
                usage = response_metadata.get("usage") or response_metadata.get("token_usage")
                return usage if isinstance(usage, Mapping) else None
            usage = message.get("usage") or message.get("token_usage")
            return usage if isinstance(usage, Mapping) else None

        response_metadata = getattr(message, "response_metadata", None)
        if isinstance(response_metadata, Mapping):
            usage = response_metadata.get("usage") or response_metadata.get("token_usage")
            if isinstance(usage, Mapping):
                return usage

        usage_metadata = getattr(message, "usage_metadata", None)
        if isinstance(usage_metadata, Mapping):
            return usage_metadata
        return None

    @staticmethod
    def _extract_content(message: Any) -> Any:
        if isinstance(message, Mapping):
            return message.get("content", "")
        return getattr(message, "content", "")

    def _estimate_tokens_from_chars(self, n_chars: int) -> int:
        if self._num_chars_per_token <= 0:
            return n_chars
        return (max(0, n_chars) + self._num_chars_per_token - 1) // self._num_chars_per_token

    @staticmethod
    def _stringify_content(content: Any) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if isinstance(block, str):
                    parts.append(block)
                elif isinstance(block, dict):
                    if block.get("type") == "text":
                        parts.append(str(block.get("text", "")))
                    else:
                        parts.append(str(block))
                else:
                    parts.append(str(block))
            return "".join(parts)
        return str(content)

    @staticmethod
    def _as_int(value: Any) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0


__all__ = ["TokenEstimator"]
