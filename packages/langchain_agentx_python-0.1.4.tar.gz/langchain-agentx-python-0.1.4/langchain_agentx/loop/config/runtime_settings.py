"""runtime_settings.py — Loop 运行时全局策略设置。

职责：
    提供 max_steps 的透明解析函数。
    接口语义与实现语义一致：None = 不限制，int = 确切上限。

设计变更（2026-05-01）：
    移除 get_global_max_steps_default() — 不再通过环境变量隐藏默认值 120。
    接口设置 max_steps=None 就是真正的不限制，没有静默兜底。
    环境变量支持由调用方（create_loop_agent 入口）自行处理，不做隐式注入。
"""

from __future__ import annotations

UNBOUNDED_MAX_STEPS = 1_000_000


def resolve_max_steps(value: int | None) -> int | None:
    """透明解析：None → None（不限），int → int（确切上限）。

    与接口语义保持一致，不做隐式默认值注入。
    """
    return value


def materialize_max_steps(value: int | None) -> int:
    """将可选 max_steps 物化为 Loop 内部可执行上限。

    None（不限步）→ UNBOUNDED_MAX_STEPS（1_000_000），
    int → 原值。
    """
    return UNBOUNDED_MAX_STEPS if value is None else value


def compute_recursion_limit(value: int | None) -> int:
    """按 OpenCode 公式计算 recursion_limit。

    recursion_limit 是 LangGraph 图层面的安全阀，
    与 max_steps 的退出逻辑是两层不同的守卫机制。
    """
    effective_steps = materialize_max_steps(value)
    return 2 * effective_steps + 100


__all__ = [
    "UNBOUNDED_MAX_STEPS",
    "resolve_max_steps",
    "materialize_max_steps",
    "compute_recursion_limit",
]
