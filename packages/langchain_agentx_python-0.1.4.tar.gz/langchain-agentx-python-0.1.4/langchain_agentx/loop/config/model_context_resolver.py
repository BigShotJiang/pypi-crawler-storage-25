"""loop/config/model_context_resolver.py — 模型上下文能力解析器。

职责：
    - 解析当前 loop 使用模型的 context_window。
    - 解析当前 loop 使用模型的 max_output_tokens。

链路位置：
    - loop/graph/factory.py：构建期生成动态 CompactionSettings。
    - 后续 P2b：exit/model 消费侧读取 max_output_tokens 上限。

当前裁剪范围：
    - 仅负责模型能力解析，不做 token 估算，不做 compaction 判定。
"""

from __future__ import annotations

import os
from typing import Any

from langchain_agentx.provider.model_profile import ModelProfileRegistry

from .agent_loop_config import AgentLoopConfig


class ModelContextResolver:
    """按约定优先级链解析模型上下文能力。"""

    def resolve_context_window(self, loop_config: AgentLoopConfig) -> int:
        env_override = self._parse_positive_int(os.getenv("AGENTX_MAX_CONTEXT_TOKENS"))
        if env_override is not None:
            return env_override

        if loop_config.model_profile is not None:
            return int(loop_config.model_profile.context_window)

        registry = loop_config.model_profile_registry
        model_id = self._extract_model_id(loop_config.model)
        if registry is not None and model_id:
            profile = registry.get(model_id)
            if profile.model_id_prefix != "__default__":
                return int(profile.context_window)
            if registry.defaults is not None:
                return int(registry.defaults.context_window)

        metadata_context_window = self._resolve_model_metadata_context_window(loop_config.model)
        if metadata_context_window is not None:
            return metadata_context_window

        return 32_000

    def resolve_max_output_tokens(self, loop_config: AgentLoopConfig) -> int:
        if loop_config.model_profile is not None:
            return int(loop_config.model_profile.max_output_tokens)

        registry = loop_config.model_profile_registry
        model_id = self._extract_model_id(loop_config.model)
        if registry is not None and model_id:
            profile = registry.get(model_id)
            if profile.model_id_prefix != "__default__":
                return int(profile.max_output_tokens)
            if registry.defaults is not None:
                return int(registry.defaults.max_output_tokens)

        metadata_max_output = self._resolve_model_metadata_max_output_tokens(loop_config.model)
        if metadata_max_output is not None:
            return metadata_max_output

        return 8_192

    @staticmethod
    def _extract_model_id(model: Any) -> str | None:
        if isinstance(model, str):
            return model.split(":")[-1] if ":" in model else model
        return getattr(model, "model_name", None) or getattr(model, "model", None)

    @staticmethod
    def _resolve_model_metadata_context_window(model: Any) -> int | None:
        metadata = getattr(model, "metadata", None) or {}
        if not isinstance(metadata, dict):
            return None
        return ModelContextResolver._parse_positive_int(metadata.get("context_window"))

    @staticmethod
    def _resolve_model_metadata_max_output_tokens(model: Any) -> int | None:
        metadata = getattr(model, "metadata", None) or {}
        if not isinstance(metadata, dict):
            return None
        for key in ("max_output_tokens", "max_tokens"):
            parsed = ModelContextResolver._parse_positive_int(metadata.get(key))
            if parsed is not None:
                return parsed
        return None

    @staticmethod
    def _parse_positive_int(value: Any) -> int | None:
        if value is None:
            return None
        try:
            parsed = int(str(value).strip())
        except (TypeError, ValueError):
            return None
        return parsed if parsed > 0 else None


__all__ = ["ModelContextResolver"]
