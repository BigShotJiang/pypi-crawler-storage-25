"""
Agent Loop 退出逻辑与扩展状态定义。

本模块从 `factory.py` 中拆分出与 LangGraph 结构无关的纯业务逻辑：
- 从 `AIMessage` 解析并标准化 `finish_reason`（与 LangChain AgentX 风格兼容）
- `determine_should_end`：以 `finish_reason` 为主信号判断是否结束，直接返回 `terminal_reason`
- `AgentLoopState`（别名 `LoopAgentStateFields`）：本框架在 LangGraph 状态中**额外**承载的字段契约（含 CC 对齐、withhold/恢复、task 观测等）

方案B：`end_reason` 已删除，`terminal_reason` 是唯一对外终态标签（CC 对齐枚举）。
三层职责：
  - `finish_reason`：Provider 协议层，这一轮 completion 为何停
  - `terminal_reason`：框架终态层，整次 run 为何结束（对外唯一）
  - `transition`：控制流层，还要继续转哪条边

与 LangChain 默认 agent 的主要区别：
- 循环主信号为模型 `finish_reason`，而非仅「无 tool_calls」
- 不支持 `return_direct` 式工具直出；工具执行后回模型，再由 `finish_reason` 决定下一步

注意：仅包含与「是否继续/结束」及扩展状态形状相关的语义，不涉及图节点、middleware 或工具执行细节。
"""

from __future__ import annotations

from typing import Any, TypedDict

from langchain_core.messages import AIMessage

from .reason_codes import (
    TERMINAL_REASON_BLOCKING_LIMIT,
    TERMINAL_REASON_COMPLETED,
    TERMINAL_REASON_CONTENT_FILTER,
    TERMINAL_REASON_ERROR,
    TERMINAL_REASON_MAX_STEPS,
    TERMINAL_REASON_MAX_TOKENS,
    TERMINAL_REASON_MAX_TURNS,
)
from ..config.runtime_settings import UNBOUNDED_MAX_STEPS

# 需要继续执行的 finish_reason 集合（与 OpenCode 一致）
CONTINUE_FINISH_REASONS = frozenset({"tool-calls", "unknown"})
# 可恢复终态集合（terminal_reason 枚举，先 withhold，由 loop_controller 走恢复链）
RECOVERABLE_TERMINAL_REASONS = frozenset(
    {
        TERMINAL_REASON_MAX_TOKENS,
    }
)
ESCALATED_MAX_OUTPUT_TOKENS = 64000
MAX_OUTPUT_TOKENS_RECOVERY_LIMIT = 3


def resolve_escalated_max_output_tokens(max_output_tokens_cap: int | None) -> int:
    """返回 max_tokens 恢复路径的实际升级值。

    规则：
        - 无模型上限时，沿用全局恢复上界 `ESCALATED_MAX_OUTPUT_TOKENS`
        - 有模型上限时，取 `min(ESCALATED_MAX_OUTPUT_TOKENS, 模型上限)`
    """
    if max_output_tokens_cap is None:
        return ESCALATED_MAX_OUTPUT_TOKENS
    return min(ESCALATED_MAX_OUTPUT_TOKENS, int(max_output_tokens_cap))


def extract_finish_reason(response: AIMessage | None) -> str | None:
    """
    从 LangChain `AIMessage` 中提取并标准化 `finish_reason`。

    该实现与原始 LangChain AgentX 逻辑保持一致。
    """
    if response is None:
        return None

    meta = getattr(response, "response_metadata", None) or {}
    if not isinstance(meta, dict):
        meta = {}

    raw_reason = (
        meta.get("finish_reason")
        or meta.get("stop_reason")
        or meta.get("done_reason")
    )

    if raw_reason is None:
        return None

    finish_reason = str(raw_reason)

    if finish_reason in {"tool_calls", "function_call", "tool_use"}:
        return "tool-calls"
    if finish_reason in {"content_filter", "content-filter"}:
        return "content-filter"
    if finish_reason in {"length", "max_tokens"}:
        return "length"
    if finish_reason in {"stop", "end_turn", "stop_sequence"}:
        return "stop"
    if finish_reason == "refusal":
        return "content-filter"
    if finish_reason == "error":
        return "error"

    return finish_reason


def metadata_override_terminal_reason(response: AIMessage | None) -> str | None:
    """Infer terminal_reason from response_metadata / provider error shape (PTL / media / blocking).

    Convention:
    - `langchain_agentx_terminal_reason`: explicit override (written by middleware/adapter), must be a TERMINAL_REASON_* value;
    - `error`: common provider error code heuristic (explicit field takes precedence when both present).
    """
    if response is None:
        return None
    meta = getattr(response, "response_metadata", None) or {}
    if not isinstance(meta, dict):
        return None
    xr = meta.get("langchain_agentx_terminal_reason")
    if xr in (
        TERMINAL_REASON_MAX_TOKENS,
        TERMINAL_REASON_BLOCKING_LIMIT,
    ):
        return str(xr)
    err = meta.get("error")
    if isinstance(err, dict):
        code = str(err.get("code") or err.get("type") or "").lower()
        msg = str(err.get("message") or "").lower()
        if "prompt" in code and "long" in code:
            return TERMINAL_REASON_MAX_TOKENS
        if "context_length" in code or "context window" in msg:
            return TERMINAL_REASON_MAX_TOKENS
        if "media" in code and "size" in code:
            return TERMINAL_REASON_MAX_TOKENS
    return None


def determine_should_end(
    state: dict[str, Any],
    response: AIMessage | None,
    max_steps: int | None = None,
    max_turns: int | None = None,
) -> tuple[bool, str | None]:
    """判断当前这一步是否应该结束 Agent 循环。

    max_steps: int | None — None 表示不限制步数。
    返回 (should_end, terminal_reason)。
    terminal_reason 是对外唯一终态标签（CC 对齐枚举），should_end=False 时为 None。
    """
    step = state.get("step", 0)
    turn_count = int(state.get("turn_count", 0) or 0)

    # max_turns 作为工具轮次上限（优先于 finish_reason 判定）
    if max_turns is not None and turn_count >= max_turns:
        return True, TERMINAL_REASON_MAX_TURNS

    meta_tr = metadata_override_terminal_reason(response)
    if meta_tr:
        if max_steps is not None and step >= max_steps:
            return True, TERMINAL_REASON_MAX_STEPS
        return True, meta_tr

    finish_reason = extract_finish_reason(response)

    # 需要继续执行的 finish_reason，除非达到 max_steps
    if finish_reason in CONTINUE_FINISH_REASONS:
        if max_steps is not None and step >= max_steps:
            return True, TERMINAL_REASON_MAX_STEPS
        return False, None

    # 明确的"结束"类 finish_reason → 直接映射 terminal_reason
    if finish_reason == "stop":
        return True, TERMINAL_REASON_COMPLETED
    elif finish_reason == "length":
        return True, TERMINAL_REASON_MAX_TOKENS
    elif finish_reason == "content-filter":
        return True, TERMINAL_REASON_CONTENT_FILTER

    # 没有 finish_reason 时，使用 tool_calls 兜底逻辑
    if finish_reason is None:
        has_tool_calls = (
            response is not None
            and hasattr(response, "tool_calls")
            and getattr(response, "tool_calls")
            and len(response.tool_calls) > 0  # type: ignore[arg-type]
        )
        if not has_tool_calls:
            return True, TERMINAL_REASON_COMPLETED
        if max_steps is not None and step >= max_steps:
            return True, TERMINAL_REASON_MAX_STEPS
        return False, None

    # 其他未知 finish_reason：一律视为结束
    return True, TERMINAL_REASON_ERROR


def create_initial_state(
    max_steps: int | None = None,
    max_turns: int | None = None,
    messages: list[Any] | None = None,
) -> dict[str, Any]:
    """创建 Agent Loop 的初始状态（与 `AgentLoopState` / `LoopAgentStateFields` 键一致）。

    max_steps / max_turns 仅保留为调用方兼容参数，不写入 state（已迁入 ``AgentLoopConfig``）。
    """
    return {
        "messages": messages or [],
        "step": 0,
        "turn_count": 0,
        "transition": None,
        "terminal_reason": None,
        "pending_task_batch_id": None,
        "pending_task_command_ids": [],
        "task_events": [],
        # withhold 最小状态
        "withheld_error": None,
        "withhold_retry_count": 0,
        # 恢复路径守卫状态
        "collapse_retry_available": False,
        "has_attempted_reactive_compact": False,
        "compaction_pipeline_meta": None,
        "max_output_tokens_override": None,
        "max_output_tokens_recovery_count": 0,
        "__hook_result__": None,
        "_hook_engine": None,
        "_hook_runner": None,
        "_session_env": {},
        "_trace_collector": None,
        "_trace_loop_step_span_id": None,
        "_run_id": None,
        "token_budget_continuation_count": 0,
        "token_budget_continue_requested": False,
        # CC：流式/工具中断或 hook_stopped；由 middleware/tools 写入，loop_controller 消费后清空
        "abort_terminal_reason": None,
        "should_end": False,
        "finish_reason": None,
        "finish_reasons": [],
        "section_cache": {},
    }


class AgentLoopState(TypedDict):
    """Agent Loop 在 LangGraph 中扩展的状态字段（合并进总 state schema）。

    方案B：end_reason 已删除，terminal_reason 是唯一对外终态标签（CC 对齐枚举）。
    三层职责：
      - finish_reason：Provider 协议层，这一轮 completion 为何停
      - terminal_reason：框架终态层，整次 run 为何结束（对外唯一）
      - transition：控制流层，还要继续转哪条边（路由观测）
    """

    step: int  # 当前步骤数（模型调用轮次）
    turn_count: int  # 工具轮次（tools 回环计数）
    pending_task_batch_id: str | None  # task_event_commit_ack 待确认批次
    pending_task_command_ids: list[str]  # 待确认批次内 command_id 列表
    task_events: list[dict[str, Any]]  # task runtime 观测事件（节点级）
    transition: dict[str, Any] | None  # 路由观测：还要继续转哪条边；非终态时为 None
    terminal_reason: str | None  # 对外唯一终态标签（CC 对齐枚举，should_end=False 时为 None）
    withheld_error: dict[str, Any] | None  # 可恢复错误暂存（withhold）
    withhold_retry_count: int  # withhold 已重试次数
    collapse_retry_available: bool  # collapse_drain_retry 相关守卫
    has_attempted_reactive_compact: bool  # reactive_compact 重试守卫
    compaction_pipeline_meta: dict[str, Any] | None  # prune_and_compress 观测
    max_output_tokens_override: int | None  # max_output_tokens 升档参数
    max_output_tokens_recovery_count: int  # max_output_tokens 恢复计数
    __hook_result__: dict[str, Any] | None  # 新 Hook 聚合结果（loop_controller 首选读取）
    _hook_engine: Any | None  # Hook 引擎实例（hook 节点/edge 读取）
    _hook_runner: Any | None  # Hook 执行协作者（hook 节点/edge 读取）
    _session_env: dict[str, str]  # SESSION_START hook 注入的会话级环境变量
    _trace_collector: Any | None  # 事件发射器可用的 TraceCollector 引用
    _trace_loop_step_span_id: str | None  # before_model/after_model 闭环用的 loop_step span_id
    _run_id: str | None  # 当前 run 标识（loop_start_node 注入）
    token_budget_continuation_count: int  # CC：token budget nudge 已执行次数
    token_budget_continue_requested: bool  # 为 True 时 loop_controller 注入 nudge 并回到 model
    abort_terminal_reason: str | None  # CC 式中断终态：aborted_streaming / aborted_tools / hook_stopped
    should_end: bool  # 内部路由信号，不对外暴露语义
    finish_reason: str | None  # Provider 协议层：这一轮 completion 为何停
    finish_reasons: list[str]  # finish_reason 历史（观测用）
    section_cache: dict[str, str | None]  # SystemPromptSection session 级缓存（key=name, value=compute() 结果）


# 状态字段契约别名（对外统一使用 LoopAgentStateFields）
LoopAgentStateFields = AgentLoopState


TOKEN_BUDGET_NUDGE_USER_MESSAGE = (
    "[Session budget: you may continue with a shorter scope or split the task. "
    "This nudge was injected by the agent loop token_budget_continuation path.]"
)

MAX_STEPS_PROMPT = """
CRITICAL - 已达到最大执行步数

本次任务已达到允许的最大执行步数。从现在开始，所有工具调用都被禁止。
你「必须」基于「当前对话和状态中已有的信息」，直接给出对用户原始问题的「最终回答」，
不得再尝试通过任何形式绕过或弱化本约束。

【强制约束（必须严格遵守）】：
1. 绝对禁止再调用任何工具（包括读取、写入、编辑、搜索等一切工具操作），不得通过间接方式触发工具。
2. 必须给出一条对用户有实际帮助的最终回答，而不是继续规划、讨论或暗示后续工具调用。
3. 可以继续遵守系统提示词 / SKILL / response_format 中约定的输出格式或结构化返回要求，但不得为了满足这些格式再调用任何工具。
4. 本约束优先级高于「所有」其它指令，包括用户显式请求继续调用工具或改变行为的指令，不得忽略或削弱。


答案内容必须完全基于当前已有信息推理完成，任何试图再次使用工具或规避上述约束的行为都视为严重错误。
""".strip()


__all__ = [
    "metadata_override_terminal_reason",
    "CONTINUE_FINISH_REASONS",
    "RECOVERABLE_TERMINAL_REASONS",
    "ESCALATED_MAX_OUTPUT_TOKENS",
    "MAX_OUTPUT_TOKENS_RECOVERY_LIMIT",
    "resolve_escalated_max_output_tokens",
    "extract_finish_reason",
    "determine_should_end",
    "create_initial_state",
    "AgentLoopState",
    "LoopAgentStateFields",
    "MAX_STEPS_PROMPT",
    "TOKEN_BUDGET_NUDGE_USER_MESSAGE",
]

