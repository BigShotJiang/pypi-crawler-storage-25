"""Reason code constants for loop transitions and termination."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# terminal_reason：对外唯一终态标签（CC 对齐枚举，写入 state）
# ---------------------------------------------------------------------------
TERMINAL_REASON_COMPLETED = "completed"
TERMINAL_REASON_MAX_STEPS = "max_steps"
TERMINAL_REASON_MAX_TURNS = "max_turns"
TERMINAL_REASON_MAX_TOKENS = "max_tokens"
TERMINAL_REASON_CONTENT_FILTER = "content_filter"
TERMINAL_REASON_BLOCKING_LIMIT = "blocking_limit"
TERMINAL_REASON_STOP_HOOK_PREVENTED = "stop_hook_prevented"
TERMINAL_REASON_ERROR = "error"
# CC queryLoop return.reason：中断 / hook 终局（middleware 或 tools 后写入 abort_terminal_reason）
TERMINAL_REASON_ABORTED_STREAMING = "aborted_streaming"
TERMINAL_REASON_ABORTED_TOOLS = "aborted_tools"
TERMINAL_REASON_HOOK_STOPPED = "hook_stopped"

# ---------------------------------------------------------------------------
# transition.reason（控制流路由观测，不是终态）
# ---------------------------------------------------------------------------
TRANSITION_NEXT_TURN = "next_turn"
TRANSITION_API_ERROR_TERMINAL = "api_error_terminal"
TRANSITION_WITHHOLD_RECOVERY_RETRY = "withhold_recovery_retry"
TRANSITION_WITHHOLD_RECOVERY_EXHAUSTED = "withhold_recovery_exhausted"
TRANSITION_COLLAPSE_DRAIN_RETRY = "collapse_drain_retry"
TRANSITION_REACTIVE_COMPACT_RETRY = "reactive_compact_retry"
TRANSITION_MAX_OUTPUT_TOKENS_ESCALATE = "max_output_tokens_escalate"
TRANSITION_MAX_OUTPUT_TOKENS_RECOVERY = "max_output_tokens_recovery"
TRANSITION_MAX_OUTPUT_TOKENS_RECOVERY_EXHAUSTED = "max_output_tokens_recovery_exhausted"
TRANSITION_TASK_NOTIFICATION_ARRIVED = "task_notification_arrived"
TRANSITION_STOP_HOOK_PREVENTED = "stop_hook_prevented"
TRANSITION_STOP_HOOK_BLOCKING = "stop_hook_blocking"
TRANSITION_TOKEN_BUDGET_CONTINUATION = "token_budget_continuation"

# token_budget continuation 默认上限（与 CC token budget nudge 次数护栏同向）
DEFAULT_TOKEN_BUDGET_MAX_CONTINUATIONS = 3
