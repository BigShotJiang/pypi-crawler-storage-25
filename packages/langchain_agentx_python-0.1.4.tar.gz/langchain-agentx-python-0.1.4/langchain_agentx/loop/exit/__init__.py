"""LangChain AgentX 退出语义与状态字段。"""
