"""流式 / 工具 / hook 中断信号：由业务 middleware 或工具抛出，由内置 wrapper 转为 state 契约。"""

from __future__ import annotations

from .exit.reason_codes import (
    TERMINAL_REASON_ABORTED_STREAMING,
    TERMINAL_REASON_ABORTED_TOOLS,
    TERMINAL_REASON_HOOK_STOPPED,
)


class LoopAbortSignal(Exception):
    """请求以 CC 式 abort 终局结束（写入 ``abort_terminal_reason``）。

    - ``aborted_streaming`` / ``hook_stopped``：在 ``wrap_model_call`` / ``awrap_model_call`` 中抛出，
      由 ``_LoopBuiltinModelControlMiddleware`` 捕获并合成 AIMessage + Command。
    - ``aborted_tools``：在工具执行或 ``wrap_tool_call`` 中抛出，由内置 tool wrapper 捕获并
      注入合成 ``ToolMessage`` + ``abort_terminal_reason``。
    """

    __slots__ = ("terminal_reason", "detail")

    def __init__(self, terminal_reason: str, *, detail: str | None = None) -> None:
        if terminal_reason not in (
            TERMINAL_REASON_ABORTED_STREAMING,
            TERMINAL_REASON_ABORTED_TOOLS,
            TERMINAL_REASON_HOOK_STOPPED,
        ):
            msg = f"Invalid LoopAbortSignal terminal_reason: {terminal_reason!r}"
            raise ValueError(msg)
        self.terminal_reason = terminal_reason
        self.detail = detail
        super().__init__(detail or terminal_reason)


__all__ = ["LoopAbortSignal"]
