"""
上下文压缩流水线阶段实现包。

与 Claude Code 对齐：
- 本子包 **仅含 CC 五段**（`CompactionStage` 子类）及泛型 `NoOpCompactionStage`；Graph 入口见 `default_loop_context_compaction().run`（`compaction_service`）。

注意：
- 新增 CC 阶段请在此包或子模块实现 `CompactionStage`，并在 `pipeline` 中注册。
"""

from __future__ import annotations

from .autocompact import AutocompactStage
from .base import CompactionStage
from .collapse import ContextCollapseStage
from .microcompact import MicrocompactStage
from .noop import NoOpCompactionStage
from .snip import SnipCompactStage
from .tool_result_budget import ToolResultBudgetStage

__all__ = [
    "AutocompactStage",
    "CompactionStage",
    "ContextCollapseStage",
    "MicrocompactStage",
    "NoOpCompactionStage",
    "SnipCompactStage",
    "ToolResultBudgetStage",
]
