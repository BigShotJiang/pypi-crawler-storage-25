"""
Context collapse 阶段：合并连续重复 `tool_call_id` 的 `ToolMessage`（对齐 CC collapse 卫生语义子集）。

与 Claude Code 对齐：
- 对应 `applyCollapsesIfNeeded` 中「同一调用重复写回」类问题的治理：保留**最后一次**结果，去掉前置重复块，减少无意义重复 token。

设计要点：
- 仅处理**连续**且 `tool_call_id` 相同的 `ToolMessage`；不跨非 Tool 消息合并；
- 可通过 `CompactionSettings.collapse_dedupe_consecutive_same_tool_call_id` 关闭。

注意：
- 不依赖 LangGraph；与 autocompact 分工：本阶段不生成会话摘要，仅结构化去重。
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import ToolMessage

from ..message_utils import estimate_tokens_from_chars, stringify_content
from ..settings import CompactionSettings, get_active_compaction_settings
from ..types import ContextCompactionContext, StageResult
from .base import CompactionStage


class ContextCollapseStage(CompactionStage):
    """CC 阶段 ④：context collapse（连续重复 tool 结果折叠）。"""

    def __init__(self, settings: CompactionSettings | None = None) -> None:
        self._settings_override = settings

    def _effective_settings(self) -> CompactionSettings:
        return self._settings_override or get_active_compaction_settings()

    @property
    def name(self) -> str:
        return "context_collapse"

    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        _ = ctx
        s = self._effective_settings()
        if not s.collapse_dedupe_consecutive_same_tool_call_id or not messages:
            return StageResult(messages=messages, tokens_freed=0)
        out: list[Any] = []
        i = 0
        freed_chars = 0
        dropped = 0
        while i < len(messages):
            m = messages[i]
            if isinstance(m, ToolMessage):
                j = i
                tid = m.tool_call_id
                while (
                    j + 1 < len(messages)
                    and isinstance(messages[j + 1], ToolMessage)
                    and messages[j + 1].tool_call_id == tid
                ):
                    j += 1
                # messages[i : j + 1] 同 id；保留最后一条，丢弃 i..j-1
                if j > i:
                    for k in range(i, j):
                        freed_chars += len(stringify_content(messages[k].content))
                        dropped += 1
                    out.append(messages[j])
                    i = j + 1
                    continue
            out.append(m)
            i += 1
        if len(out) == len(messages):
            return StageResult(messages=messages, tokens_freed=0)
        return StageResult(
            messages=out,
            tokens_freed=estimate_tokens_from_chars(freed_chars, s.num_chars_per_token),
            extra={"collapse_dropped_tool_messages": dropped},
        )
