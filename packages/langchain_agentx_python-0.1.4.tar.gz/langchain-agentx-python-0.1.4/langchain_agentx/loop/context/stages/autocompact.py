"""
Autocompact 阶段：超阈值时折叠前缀消息（对齐 CC `deps.autocompact` 的会话级收紧）。

与 Claude Code 对齐：
- 当估计 token 超过 `default_max_context_tokens * default_compress_trigger_fraction` 时，保留首部 `SystemMessage` 与尾部 `default_compress_keep_recent_messages` 条，中间以占位或（可选）LLM 摘要替换；
- `ctx.snip_tokens_freed_carry` 已由 `ContextPipeline` 累加前置阶段释放量，可供后续扩展阈值修正（与 CC `snipTokensFreed` 同向）。

设计要点：
- 默认 `autocompact_use_llm_when_available=True`：超阈值且 `ctx.model` 可用、且 **未** 命中 `CompactionBlockingGuard.should_block_compact_llm` 时走 LLM；否则或无 model / `invoke` 失败则 **prune**；
- `autocompact_snip_carry_threshold_slack`：将 `ctx.snip_tokens_freed_carry` 加到触发阈值（进入本阶段前由前四段累加），对齐 CC `snipTokensFreed` 阈值修正。
- LLM 路径对齐 `compact.ts`：`messages` 先放待摘要摘录，**最后一条** `HumanMessage` 为完整 compact 指令（与 `summaryRequest` 同序）；指令由 `build_autocompact_llm_instruction_prompt` 按 `autocompact_llm_prompt_kind` 选择（默认 `partial_up_to`，与「摘要 + 保留 tail」一致），`compact_custom_instructions` 对应 CC `customInstructions`；`autocompact_llm_instructions_override` / 非空的 `compaction_system_prompt` 可覆盖 builder；
- 模型输出经 `get_compact_user_summary_message(..., recent_messages_preserved=True)`（内部 `format_compact_summary`）写入 state，与 CC 续写包装一致。

注意：
- `query_source in autocompact_skip_query_sources`（如 `compact`）时跳过，防递归压缩。
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from ..blocking_guard import CompactionBlockingGuard
from ..message_utils import stringify_content, total_estimated_tokens_for_messages
from ...prompt.compact import build_autocompact_llm_instruction_prompt, get_compact_user_summary_message
from ..settings import CompactionSettings, get_active_compaction_settings
from ..types import ContextCompactionContext, StageResult
from .base import CompactionStage


class AutocompactStage(CompactionStage):
    """CC 阶段 ⑤：autocompact（阈值折叠 / 可选 LLM 摘要）。"""

    def __init__(self, settings: CompactionSettings | None = None) -> None:
        self._settings_override = settings

    def _effective_settings(self) -> CompactionSettings:
        return self._settings_override or get_active_compaction_settings()

    @property
    def name(self) -> str:
        return "autocompact"

    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        s = self._effective_settings()
        if ctx.query_source in s.autocompact_skip_query_sources:
            return StageResult(messages=messages, tokens_freed=0, extra={"autocompact_skipped": "query_source"})
        total = total_estimated_tokens_for_messages(messages, s.num_chars_per_token)
        threshold = int(s.default_max_context_tokens * s.default_compress_trigger_fraction)
        slack = ctx.snip_tokens_freed_carry if s.autocompact_snip_carry_threshold_slack else 0
        if total <= threshold + slack:
            return StageResult(messages=messages, tokens_freed=0)

        leading: list[Any] = []
        idx = 0
        while idx < len(messages) and isinstance(messages[idx], SystemMessage):
            leading.append(messages[idx])
            idx += 1
        rest = messages[idx:]
        k = max(1, s.default_compress_keep_recent_messages)
        if len(rest) <= k:
            return StageResult(messages=messages, tokens_freed=0)

        head = rest[:-k]
        tail = rest[-k:]

        block_llm = CompactionBlockingGuard(settings=s).should_block_compact_llm(messages)
        if (
            s.autocompact_use_llm_when_available
            and ctx.model is not None
            and not block_llm
        ):
            summary = _invoke_summary(ctx.model, s, head)
            if summary:
                folded = leading + [
                    HumanMessage(
                        content=get_compact_user_summary_message(
                            summary,
                            recent_messages_preserved=True,
                        )
                    )
                ] + tail
                new_total = total_estimated_tokens_for_messages(folded, s.num_chars_per_token)
                return StageResult(
                    messages=folded,
                    tokens_freed=max(0, total - new_total),
                    extra={"autocompact_mode": "llm", "folded_messages": len(head)},
                )

        folded = leading + [
            HumanMessage(
                content=(
                    f"[Context autocompacted: {len(head)} earlier messages omitted; "
                    "details dropped for token budget.]"
                )
            )
        ] + tail
        new_total = total_estimated_tokens_for_messages(folded, s.num_chars_per_token)
        mode = "prune_blocked_llm" if block_llm else "prune"
        return StageResult(
            messages=folded,
            tokens_freed=max(0, total - new_total),
            extra={"autocompact_mode": mode, "folded_messages": len(head)},
        )


def _resolve_autocompact_llm_instruction(s: CompactionSettings) -> str:
    if s.autocompact_llm_instructions_override is not None:
        return s.autocompact_llm_instructions_override
    if s.compaction_system_prompt is not None and s.compaction_system_prompt.strip() != "":
        return s.compaction_system_prompt
    return build_autocompact_llm_instruction_prompt(
        s.autocompact_llm_prompt_kind,
        s.compact_custom_instructions,
    )


def _invoke_summary(model: Any, s: CompactionSettings, head: list[Any]) -> str | None:
    cap = max(256, s.autocompact_llm_excerpt_chars_per_message)
    parts: list[str] = []
    for m in head:
        label = getattr(m, "type", type(m).__name__)
        chunk = stringify_content(getattr(m, "content", None))[:cap]
        parts.append(f"{label}: {chunk}")
    body = "\n\n---\n\n".join(parts)
    excerpt_msg = HumanMessage(
        content=(
            "[Conversation excerpt to summarize — follows above chronology in thread]\n\n" + body
        )
    )
    instruction = _resolve_autocompact_llm_instruction(s)
    instruction_msg = HumanMessage(content=instruction)
    # 与 CC `streamCompactSummary` 一致：history 在前，compact 指令为**最后一条** user 消息。
    try:
        resp = model.invoke([excerpt_msg, instruction_msg])
    except Exception:
        return None
    text = stringify_content(getattr(resp, "content", None))
    return text if text else None
