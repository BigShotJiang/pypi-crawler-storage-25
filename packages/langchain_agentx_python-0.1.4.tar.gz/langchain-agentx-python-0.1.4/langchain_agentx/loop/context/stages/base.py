"""
压缩流水线阶段抽象基类（CompactionStage）。

与 Claude Code 对齐：
- 对应 `query.ts` 中 `messagesForQuery` 上顺序执行的治理步骤；每步为可替换策略单元。

设计要点：
- 子类实现 `run(messages, ctx) -> StageResult`；CC 五段均在 `stages/` 内实现。

注意：
- 不依赖 LangGraph；仅处理消息列表与 ContextCompactionContext。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..types import ContextCompactionContext, StageResult


class CompactionStage(ABC):
    """上下文压缩流水线中的一步（CC queryLoop 阶段 ① 子步骤）。"""

    @property
    @abstractmethod
    def name(self) -> str:
        """阶段名（观测 / 日志）。"""

    @abstractmethod
    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        """输入当前消息列表，返回更新后的列表与可选 tokens_freed。"""
