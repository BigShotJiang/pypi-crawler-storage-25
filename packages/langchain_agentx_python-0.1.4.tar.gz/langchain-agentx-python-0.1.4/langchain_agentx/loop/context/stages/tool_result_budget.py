"""
工具结果预算阶段：对单条 `ToolMessage` 做软字符上限（对齐 CC `applyToolResultBudget` 意图）。

与 Claude Code 对齐：
- 对应 `query.ts` 中 `messagesForQuery` 链上的 `applyToolResultBudget`：在会话级流水线入口收紧超大 tool 输出，避免单条结果撑爆窗口。

设计要点：
- 仅处理 `langchain_core.messages.ToolMessage`；`name` 落在 `CompactionSettings.prune_protected_tools` 的不截断（如 CC 侧 skill 类结果）；
- 使用 `model_copy(update={"content": ...})` 保持 `tool_call_id` / `name` 与 LangChain 消息契约一致。

注意：
- 与 `tool_runtime` 单条落盘截断分工见设计文档；此处是会话 `messages` 级预算。
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import ToolMessage

from ..message_utils import estimate_tokens_from_chars, stringify_content
from ..settings import CompactionSettings, get_active_compaction_settings
from ..types import ContextCompactionContext, StageResult
from .base import CompactionStage


class ToolResultBudgetStage(CompactionStage):
    """CC 阶段 ①：tool result 软上限。"""

    def __init__(self, settings: CompactionSettings | None = None) -> None:
        self._settings_override = settings

    def _effective_settings(self) -> CompactionSettings:
        return self._settings_override or get_active_compaction_settings()

    @property
    def name(self) -> str:
        return "tool_result_budget"

    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        _ = ctx
        s = self._effective_settings()
        changed = False
        out: list[Any] = []
        freed_chars = 0
        for m in messages:
            if not isinstance(m, ToolMessage):
                out.append(m)
                continue
            tool_name = (m.name or "").strip()
            if tool_name in s.prune_protected_tools:
                out.append(m)
                continue
            text = stringify_content(m.content)
            cap = s.tool_result_max_chars_per_message
            if len(text) <= cap:
                out.append(m)
                continue
            new_text = text[:cap] + s.tool_result_budget_suffix
            freed_chars += len(text) - len(new_text)
            out.append(m.model_copy(update={"content": new_text}))
            changed = True
        if not changed:
            return StageResult(messages=messages, tokens_freed=0)
        return StageResult(
            messages=out,
            tokens_freed=estimate_tokens_from_chars(freed_chars, s.num_chars_per_token),
            extra={"tool_result_budget_truncated": True},
        )
