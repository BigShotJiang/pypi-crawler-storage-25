"""
泛型占位阶段：无操作，仅透传 messages。

与 Claude Code 对齐：
- 不对应单一 TS 步骤；用于单测或临时将某一槽位替换为恒等映射，而不引入真实 `ToolResultBudgetStage` 等实现。

设计要点：
- 通过构造参数 `name` 区分阶段名，便于日志；**默认 CC 五段请使用 `stages/*.py` 中独立类**，而非本泛型类。

注意：
- 生产默认流水线见 `DefaultCompactionStages.build()` / `ContextPipeline.with_default_stages()`（五段具名类）。
"""

from __future__ import annotations

from typing import Any

from ..types import ContextCompactionContext, StageResult
from .base import CompactionStage


class NoOpCompactionStage(CompactionStage):
    """透传消息列表，不修改内容。"""

    def __init__(self, name: str) -> None:
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        return StageResult(messages=messages, tokens_freed=0)
