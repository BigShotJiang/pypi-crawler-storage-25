"""
Snip 紧凑化阶段：对「非尾部」窗口内的超大 `ToolMessage` 截断（对齐 CC `snipCompactIfNeeded` 意图）。

与 Claude Code 对齐：
- 对应 `snipCompactIfNeeded` / `services/compact/snipCompact.ts`：优先裁剪历史中早期 tool 大块，保留尾部对话连贯性；
- `StageResult.tokens_freed` 供 `ContextPipeline` 累加到 `ctx.snip_tokens_freed_carry`，与 CC `snipTokensFreed` 传入 autocompact 同向。

设计要点：
- 仅截断索引 `< len(messages) - snip_preserve_tail_messages` 的 `ToolMessage`；
- 截断后内容 + `snip_suffix`，仍保留同一条 `ToolMessage`（不删消息条数，避免破坏 tool_calls 对齐）。

注意：
- 不依赖 LangGraph；不修改 exit 相关 state 字段。
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import ToolMessage

from ..message_utils import estimate_tokens_from_chars, stringify_content
from ..settings import CompactionSettings, get_active_compaction_settings
from ..types import ContextCompactionContext, StageResult
from .base import CompactionStage


class SnipCompactStage(CompactionStage):
    """CC 阶段 ②：历史侧 tool 内容 snip。"""

    def __init__(self, settings: CompactionSettings | None = None) -> None:
        self._settings_override = settings

    def _effective_settings(self) -> CompactionSettings:
        return self._settings_override or get_active_compaction_settings()

    @property
    def name(self) -> str:
        return "snip_compact"

    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        _ = ctx
        s = self._effective_settings()
        if not messages:
            return StageResult(messages=messages, tokens_freed=0)
        n = len(messages)
        preserve = min(max(0, s.snip_preserve_tail_messages), n)
        cutoff = n - preserve
        changed = False
        out: list[Any] = []
        freed_chars = 0
        for i, m in enumerate(messages):
            if i >= cutoff or not isinstance(m, ToolMessage):
                out.append(m)
                continue
            text = stringify_content(m.content)
            cap = s.snip_max_tool_content_chars
            if len(text) <= cap:
                out.append(m)
                continue
            new_text = text[:cap] + s.snip_suffix
            freed_chars += len(text) - len(new_text)
            out.append(m.model_copy(update={"content": new_text}))
            changed = True
        if not changed:
            return StageResult(messages=messages, tokens_freed=0)
        return StageResult(
            messages=out,
            tokens_freed=estimate_tokens_from_chars(freed_chars, s.num_chars_per_token),
            extra={"snip_compact_applied": True},
        )
