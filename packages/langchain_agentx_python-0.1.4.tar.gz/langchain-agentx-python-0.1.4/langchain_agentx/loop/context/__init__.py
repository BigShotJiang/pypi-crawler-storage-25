"""主循环上下文治理（OOP 门面 + CC 五段 `stages/`）。"""

from __future__ import annotations

from .blocking_guard import CompactionBlockingGuard, default_compaction_blocking_guard
from .compaction_service import LoopContextCompaction, default_loop_context_compaction
from .pipeline import ContextPipeline, DefaultCompactionStages
from .settings import (
    AutocompactLlmPromptKind,
    CompactionSettings,
    active_compaction_settings,
    get_active_compaction_settings,
    set_active_compaction_settings,
)
from .stages import (
    AutocompactStage,
    ContextCollapseStage,
    MicrocompactStage,
    SnipCompactStage,
    ToolResultBudgetStage,
)
from .types import (
    CompactionConfig,
    ContextCompactionContext,
    StageResult,
    TokenWarningLevel,
    TokenWarningState,
)

# 压缩提示词函数从 loop.prompt.compact 导入（向后兼容）
from ..prompt.compact import (
    build_autocompact_llm_instruction_prompt,
    format_compact_summary,
    get_compact_prompt,
    get_compact_user_summary_message,
    get_partial_compact_prompt,
)

__all__ = [
    "active_compaction_settings",
    "AutocompactLlmPromptKind",
    "AutocompactStage",
    "CompactionBlockingGuard",
    "CompactionConfig",
    "CompactionSettings",
    "ContextCollapseStage",
    "ContextCompactionContext",
    "ContextPipeline",
    "DefaultCompactionStages",
    "default_compaction_blocking_guard",
    "default_loop_context_compaction",
    "build_autocompact_llm_instruction_prompt",
    "format_compact_summary",
    "get_active_compaction_settings",
    "get_compact_prompt",
    "get_compact_user_summary_message",
    "get_partial_compact_prompt",
    "LoopContextCompaction",
    "MicrocompactStage",
    "set_active_compaction_settings",
    "SnipCompactStage",
    "StageResult",
    "TokenWarningLevel",
    "TokenWarningState",
    "ToolResultBudgetStage",
]
