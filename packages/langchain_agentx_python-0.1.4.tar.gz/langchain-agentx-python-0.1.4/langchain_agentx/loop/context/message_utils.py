"""
LangChain 消息内容规范化与 token 粗估（供 `stages/*` 复用）。

与 Claude Code 对齐：
- CC 各紧凑阶段同样基于「字符 / token 近似」做预算；此处集中实现，避免五段内重复逻辑。

设计要点：
- 仅使用 `BaseMessage.content` 的公开形状（`str`、多模态 `list[dict|str]`），与 LangChain 一致；
- `estimate_*` 为 **启发式**，与真实 tokenizer 有偏差，仅用于会话级预算与观测。

注意：
- 不 import 具体阶段；不依赖 LangGraph。
"""

from __future__ import annotations

from typing import Any


def stringify_content(content: Any) -> str:
    """将 LangChain `Message.content` 规范为纯文本（多模态块取 text 段）。"""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
                else:
                    parts.append(str(block))
            else:
                parts.append(str(block))
        return "".join(parts)
    return str(content)


def estimate_tokens_from_chars(n_chars: int, num_chars_per_token: int) -> int:
    if num_chars_per_token <= 0:
        return n_chars
    return (max(0, n_chars) + num_chars_per_token - 1) // num_chars_per_token


def estimate_tokens_from_content(content: Any, num_chars_per_token: int) -> int:
    return estimate_tokens_from_chars(len(stringify_content(content)), num_chars_per_token)


def total_estimated_tokens_for_messages(messages: list[Any], num_chars_per_token: int) -> int:
    total_chars = 0
    for m in messages:
        total_chars += len(stringify_content(getattr(m, "content", None)))
    return estimate_tokens_from_chars(total_chars, num_chars_per_token)
