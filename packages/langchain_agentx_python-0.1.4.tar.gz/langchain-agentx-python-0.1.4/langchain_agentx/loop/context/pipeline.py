"""
上下文压缩流水线编排（`ContextPipeline` + 默认 CC 五段装配）。

与 Claude Code 对齐：
- **仅** `query.ts` 中 `applyToolResultBudget` → snip → microcompact → collapse → autocompact 五段；
- `DefaultCompactionStages.build()` 为顺序 SSOT，与 TS 侧 `messagesForQuery` 链一致。

设计要点：
- `ContextPipeline.run` 仅消费 `CompactionStage`；若最终 `messages` 列表引用被替换则返回补丁；
- 可选 `settings=` 与自定义五段注入的 `CompactionSettings` 对齐；省略时用 `get_active_compaction_settings()`（与 `DefaultCompactionStages` 默认一致）；
- 阶段 C：可选写入 `compaction_pipeline_meta`（token 告警档、各段 `tokens_freed`），供观测与 event 适配；
- 门面 `LoopContextCompaction`（见 `compaction_service.py`）负责 `ContextCompactionContext` 装配与调用本类。

注意：
- 阶段若就地改消息且仍返回同一 list，当前实现**无法**检测变更；实现阶段请返回新 list。
"""

from __future__ import annotations

from typing import Any

from ..config.token_estimator import TokenEstimator
from .blocking_guard import CompactionBlockingGuard
from .settings import CompactionSettings, get_active_compaction_settings
from .stages import (
    AutocompactStage,
    ContextCollapseStage,
    MicrocompactStage,
    SnipCompactStage,
    ToolResultBudgetStage,
)
from .stages.base import CompactionStage
from .types import ContextCompactionContext


class DefaultCompactionStages:
    """CC 五段默认装配（顺序即契约）。"""

    @staticmethod
    def build() -> tuple[CompactionStage, ...]:
        return (
            ToolResultBudgetStage(),
            SnipCompactStage(),
            MicrocompactStage(),
            ContextCollapseStage(),
            AutocompactStage(),
        )


class ContextPipeline:
    """顺序执行 CC 五段。"""

    def __init__(
        self,
        stages: tuple[CompactionStage, ...],
        *,
        settings: CompactionSettings | None = None,
    ) -> None:
        self._stages = stages
        self._settings_override = settings

    @classmethod
    def with_default_stages(
        cls,
        settings: CompactionSettings | None = None,
    ) -> ContextPipeline:
        """使用 `DefaultCompactionStages` 构建管道。"""
        return cls(DefaultCompactionStages.build(), settings=settings)

    @property
    def stages(self) -> tuple[CompactionStage, ...]:
        return self._stages

    def run(self, state: dict[str, Any], ctx: ContextCompactionContext) -> dict[str, Any]:
        messages = state.get("messages")
        if not isinstance(messages, list) or not messages:
            return {}

        s = self._settings_override or get_active_compaction_settings()
        estimator = TokenEstimator(num_chars_per_token=s.num_chars_per_token)
        original_input = list(messages)
        current = original_input
        guard = CompactionBlockingGuard(settings=s)
        tw = guard.calculate_token_warning_state(original_input)
        tokens_before = estimator.estimate_messages_tokens(original_input)
        stages_meta: list[dict[str, Any]] = []
        total_freed = 0

        for stage in self._stages:
            sr = stage.run(current, ctx)
            total_freed += sr.tokens_freed
            stages_meta.append(
                {
                    "name": stage.name,
                    "tokens_freed": sr.tokens_freed,
                    "extra": dict(sr.extra),
                }
            )
            current = sr.messages
            ctx.snip_tokens_freed_carry += sr.tokens_freed

        patch: dict[str, Any] = {}
        if current is not original_input:
            patch["messages"] = current

        tokens_after = estimator.estimate_messages_tokens(current)
        if s.emit_compaction_pipeline_meta and (
            "messages" in patch or total_freed > 0
        ):
            patch["compaction_pipeline_meta"] = {
                "estimated_tokens_before": tokens_before,
                "estimated_tokens_after": tokens_after,
                "tokens_freed_sum": total_freed,
                "snip_tokens_freed_carry_final": ctx.snip_tokens_freed_carry,
                "token_warning_level": tw.level,
                "stages": stages_meta,
            }

        if not patch:
            return {}
        return patch


__all__ = [
    "ContextPipeline",
    "DefaultCompactionStages",
]
