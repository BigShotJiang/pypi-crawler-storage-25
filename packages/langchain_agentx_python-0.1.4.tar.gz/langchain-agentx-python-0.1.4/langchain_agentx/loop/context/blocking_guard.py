"""
紧凑化路径上的 token 告警与「是否拦二次模型」守卫（阶段 C）。

与 Claude Code 对齐：
- `calculate_token_warning_state` 分档：`ok` / `warn` / `block_compact_llm` / `block_main_model`，
  语义上贴近 CC `calculateTokenWarningState` 与 compact 前「过满则勿再调摘要模型」；
- `should_block`：是否建议 **拦主循环 model**（估计已超过上下文硬顶），供 Graph / middleware 协作。

设计要点：
- 估计使用 `message_utils.total_estimated_tokens_for_messages`，与五段一致；
- **不**插入默认五段列表；`AutocompactStage` 在调用 compact LLM 前查询 `should_block_compact_llm`。

注意：
- 不修改 LangGraph state；与 `CompactionStage.run` 正交。
"""

from __future__ import annotations

from typing import Any

from ..config.token_estimator import TokenEstimator
from .settings import CompactionSettings, get_active_compaction_settings
from .types import ContextCompactionContext, TokenWarningLevel, TokenWarningState


class CompactionBlockingGuard:
    """基于启发式 token 的告警与阻塞建议。"""

    def __init__(self, settings: CompactionSettings | None = None) -> None:
        self._settings_override = settings
        self._token_estimator = TokenEstimator(
            num_chars_per_token=(settings.num_chars_per_token if settings is not None else 4)
        )

    def _settings(self) -> CompactionSettings:
        return self._settings_override or get_active_compaction_settings()

    def estimate_messages_tokens(self, messages: list[Any]) -> int:
        return self._token_estimator.estimate_messages_tokens(messages)

    def calculate_token_warning_state(self, messages: list[Any]) -> TokenWarningState:
        s = self._settings()
        est = self.estimate_messages_tokens(messages)
        max_ctx = max(1, s.default_max_context_tokens)
        warn_line = int(max_ctx * s.compaction_token_warn_fraction)
        block_llm_line = int(max_ctx * s.compaction_block_compact_llm_fraction)
        block_main_line = int(max_ctx * s.compaction_block_main_model_fraction)
        level: TokenWarningLevel
        if est >= block_main_line:
            level = "block_main_model"
        elif est >= block_llm_line:
            level = "block_compact_llm"
        elif est >= warn_line:
            level = "warn"
        else:
            level = "ok"
        return TokenWarningState(
            estimated_tokens=est,
            warn_threshold_tokens=warn_line,
            block_compact_llm_threshold_tokens=block_llm_line,
            block_main_model_threshold_tokens=block_main_line,
            level=level,
        )

    def should_block_compact_llm(self, messages: list[Any]) -> bool:
        """估计已超过「compact 二次 LLM」安全线时返回 True（仅走 prune / 跳过摘要模型）。"""
        st = self.calculate_token_warning_state(messages)
        return st.level in ("block_compact_llm", "block_main_model")

    def should_block(
        self,
        ctx: ContextCompactionContext,
        *,
        estimated_tokens: int = 0,
    ) -> bool:
        """是否建议阻塞 **主** model（由调用方传入已算好的 token 或自行先算 messages）。"""
        _ = ctx
        s = self._settings()
        line = int(s.default_max_context_tokens * s.compaction_block_main_model_fraction)
        return estimated_tokens >= line


_default_guard: CompactionBlockingGuard | None = None


def default_compaction_blocking_guard() -> CompactionBlockingGuard:
    """进程内单例守卫。"""
    global _default_guard
    if _default_guard is None:
        _default_guard = CompactionBlockingGuard()
    return _default_guard


__all__ = [
    "CompactionBlockingGuard",
    "default_compaction_blocking_guard",
]
