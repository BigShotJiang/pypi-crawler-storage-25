"""
loop/runtime/context.py — 子代理运行态控制面数据结构

职责：从 `loop.config` 再导出 `AgentLoopConfig`（已合并原 `LoopRuntimeContext` 全部字段）；
      以及 `SubagentContextOverrides`（子代理显式覆盖参数）。
在整体链路中的位置：RuntimeContextFactory.derive() 消费，SubagentOrchestrator 传递给 runner。
CC 对照：src/query.ts State.toolUseContext / src/utils/forkedAgent.ts createSubagentContext。
当前裁剪范围：不变配置强类型统一为 `AgentLoopConfig`；历史名 `LoopRuntimeContext` 由
      `loop.runtime` 包以别名导出以保持向后兼容。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..config import AgentLoopConfig

__all__ = ["AgentLoopConfig", "SubagentContextOverrides"]


@dataclass
class SubagentContextOverrides:
    """子代理显式覆盖参数。

    None 表示"不覆盖，继承父值"。
    CC 对照：src/utils/forkedAgent.ts forkOptions 参数。
    """
    model: Any | None = None
    max_steps: int | None = None
    available_tools: list[Any] | None = None
    permission_mode: str | None = None
    isolation: str = "none"
    cwd: str | None = None
