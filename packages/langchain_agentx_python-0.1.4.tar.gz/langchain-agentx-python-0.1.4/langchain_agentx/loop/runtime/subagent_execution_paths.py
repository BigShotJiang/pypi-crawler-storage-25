"""
loop/runtime/subagent_execution_paths.py — 子 Agent 工作目录与 worktree 单点准备

职责：
    计算子会话的 ``effective_cwd``（供 ``run_with_cwd_override`` / ``AgentLoopConfig.cwd`` /
    ``SubagentContext.cwd`` 同源），并在 ``isolation=worktree`` 时创建唯一临时目录。
链路位置：
    ``SubagentOrchestrator._derive_runtime_context`` → ``prepare`` → ``RuntimeContextFactory.derive``；
    ``create_subagent_context(..., path_prep=...)`` 消费本结构，避免重复 ``mkdir``。
当前裁剪范围：
    仅 ``none`` / ``worktree``；不处理 CC ``remote`` isolation。路径展开 / 权限校验留在 Phase 2。
CC 对照：
    ``AgentTool.tsx`` 中 ``cwdOverridePath = cwd ?? worktreeInfo?.worktreePath``。
"""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from typing import Any

from langchain_agentx.loop.runtime.context import SubagentContextOverrides
from langchain_agentx.workspace import resolve_agent_workspace_config


@dataclass(frozen=True)
class PreparedSubagentPaths:
    """``SubagentExecutionPaths.prepare`` 的输出：最终 cwd 与可选 worktree 目录。"""

    effective_cwd: str
    worktree_dir: str | None = None


class SubagentExecutionPaths:
    """子 Agent 路径准备（OOP 单点，禁止在 orchestrator 内堆叠 mkdir 逻辑）。"""

    @staticmethod
    def prepare(
        *,
        parent_ctx: Any,
        overrides: "SubagentContextOverrides",
    ) -> PreparedSubagentPaths:
        """解析 ``effective_cwd``，并在 worktree 模式下创建临时目录。

        顺序对齐 CC：**显式 ``overrides.cwd`` 优先于 worktree 目录**（``cwd ?? worktreePath``）。
        """
        parent_cwd = getattr(parent_ctx, "cwd", None)
        parent_workspace_root = getattr(parent_ctx, "workspace_root", None) or os.getcwd()
        parent_agent_home = getattr(parent_ctx, "agent_home", ".langchain_agentx")
        raw = overrides.cwd
        override_cwd = raw.strip() if isinstance(raw, str) and raw.strip() else None

        if overrides.isolation == "worktree":
            workspace_cfg = resolve_agent_workspace_config(
                workspace_root=parent_workspace_root,
                agent_home=parent_agent_home,
            )
            workspace_cfg.worktrees_dir.mkdir(parents=True, exist_ok=True)
            worktree_dir = str(
                workspace_cfg.worktrees_dir / f"agentx-worktree-{uuid.uuid4().hex[:12]}"
            )
            os.makedirs(worktree_dir, exist_ok=False)
            effective = override_cwd or worktree_dir
            return PreparedSubagentPaths(effective_cwd=effective, worktree_dir=worktree_dir)

        base = override_cwd or parent_cwd or os.getcwd()
        return PreparedSubagentPaths(effective_cwd=base, worktree_dir=None)
