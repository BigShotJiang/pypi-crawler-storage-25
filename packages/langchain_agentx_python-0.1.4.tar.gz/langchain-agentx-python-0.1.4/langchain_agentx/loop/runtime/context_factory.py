"""
loop/runtime/context_factory.py — RuntimeContextFactory 继承规则单点

职责：从父 ToolExecutionContext 派生 AgentLoopConfig，应用 SubagentContextOverrides。
      继承优先级（单点定义）：显式 override > SubagentConfig 默认 > 父 ctx 字段。
在整体链路中的位置：SubagentOrchestrator.invoke_subagent() 调用。
CC 对照：src/utils/forkedAgent.ts createSubagentContext() 中的字段合并逻辑。
当前裁剪范围：v1 model / max_steps / available_tools / agent_depth 继承；permission_mode 直通；
      ``subagent_effective_cwd`` 由 ``SubagentExecutionPaths.prepare`` 注入（不在此 mkdir）。
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from langchain_agentx.workspace import resolve_agent_workspace_config

from .context import AgentLoopConfig, SubagentContextOverrides

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.models import ToolExecutionContext


class RuntimeContextFactory:
    """子代理运行态上下文派生器。

    继承优先级（所有字段统一在此定义，不允许在别处散落推断）：
        显式 SubagentContextOverrides 字段
          > SubagentConfig.default_xxx
          > 父 ToolExecutionContext 字段
          > 系统默认值

    CC 对照：createSubagentContext() 的参数合并顺序。
    """

    @staticmethod
    def derive(
        parent_ctx: "ToolExecutionContext",
        overrides: SubagentContextOverrides,
        *,
        subagent_config: Any | None = None,
        agent_id: str | None = None,
        subagent_effective_cwd: str | None = None,
    ) -> AgentLoopConfig:
        """从父 ctx 派生子代理 AgentLoopConfig。

        Args:
            parent_ctx: 父会话工具执行上下文（含 model / agent_depth 等控制面字段）。
            overrides: 子代理显式覆盖（None 字段表示继承）。
            subagent_config: SubagentConfig 实例，提供 default_model / default_max_steps。
            agent_id: 子代理 ID（调用方生成）。
            subagent_effective_cwd: 由 ``SubagentExecutionPaths.prepare`` 解析的最终 cwd；
                非 ``None`` 时写入 ``AgentLoopConfig.cwd``；为 ``None`` 时维持历史行为
                ``parent_ctx.cwd``（兼容未接 Agent 编排的调用方）。
        """
        # 模型继承：override > config.default_model > parent_ctx.model
        config_model = getattr(subagent_config, "default_model", None)
        resolved_model = overrides.model or config_model or parent_ctx.model

        # max_steps 继承：override > config.default_max_steps > None
        config_max_steps = getattr(subagent_config, "default_max_steps", None)
        resolved_max_steps = (
            overrides.max_steps if overrides.max_steps is not None
            else config_max_steps
        )

        # 工具池继承：override > 父 ctx.available_tools
        resolved_tools = (
            overrides.available_tools
            if overrides.available_tools is not None
            else list(parent_ctx.available_tools or [])
        )

        # 权限：override > 父 ctx.permission_mode > "default"
        resolved_permission = (
            overrides.permission_mode
            or getattr(parent_ctx, "permission_mode", "default")
            or "default"
        )
        workspace_root = getattr(parent_ctx, "workspace_root", None)
        parent_agent_home = getattr(parent_ctx, "agent_home", None)
        workspace_cfg = resolve_agent_workspace_config(
            workspace_root=workspace_root or Path.cwd(),
            agent_home=parent_agent_home,
        )

        resolved_cwd = (
            subagent_effective_cwd
            if subagent_effective_cwd is not None
            else getattr(parent_ctx, "cwd", None)
        )

        return AgentLoopConfig(
            model=resolved_model,
            session_id=getattr(parent_ctx, "session_id", "") or "",
            agent_id=agent_id,
            parent_agent_id=getattr(parent_ctx, "agent_id", None),
            agent_depth=(parent_ctx.agent_depth or 0) + 1,
            max_steps=resolved_max_steps,
            available_tools=resolved_tools,
            permission_mode=resolved_permission,
            workspace_root=workspace_cfg.workspace_root,
            agent_home=workspace_cfg.agent_home,
            cwd=resolved_cwd,
            trace_enabled=bool(getattr(parent_ctx, "trace_enabled", True)),
        )
