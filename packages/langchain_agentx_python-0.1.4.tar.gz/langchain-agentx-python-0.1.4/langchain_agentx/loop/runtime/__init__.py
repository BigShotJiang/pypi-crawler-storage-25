"""
loop/runtime/__init__.py — loop.runtime 包公共接口
"""

from .context import AgentLoopConfig, SubagentContextOverrides
from .context_factory import RuntimeContextFactory
from .subagent_execution_paths import PreparedSubagentPaths, SubagentExecutionPaths

# 向后兼容：历史类型名与 AgentLoopConfig 为同一实现
LoopRuntimeContext = AgentLoopConfig

__all__ = [
    "AgentLoopConfig",
    "LoopRuntimeContext",
    "SubagentContextOverrides",
    "RuntimeContextFactory",
    "PreparedSubagentPaths",
    "SubagentExecutionPaths",
]
