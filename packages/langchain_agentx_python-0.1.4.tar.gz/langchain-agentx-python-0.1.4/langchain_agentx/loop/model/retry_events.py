"""
模型重试事件类型定义。

职责：
- 提供 retrier 与 loop node 间的事件契约
- 约束对用户可见的重试提示字段（attempt/retry_in_ms/error）
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


RetryEventType = Literal["scheduled", "heartbeat"]
RETRY_EVENT_METADATA_FLAG = "langchain_agentx_retry_event"
RETRY_EVENT_SUBTYPE = "api_retry"


@dataclass(slots=True)
class ModelRetryEvent:
    event_type: RetryEventType
    retry_in_ms: int
    attempt: int
    max_retries: int
    error_type: str
    error_message: str


__all__ = [
    "ModelRetryEvent",
    "RetryEventType",
    "RETRY_EVENT_METADATA_FLAG",
    "RETRY_EVENT_SUBTYPE",
]
