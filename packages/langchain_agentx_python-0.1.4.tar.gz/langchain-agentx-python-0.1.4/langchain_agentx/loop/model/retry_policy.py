"""
模型重试策略对象。

职责：
- 计算每次重试等待时长（优先 Retry-After）
- 管理 heartbeat 分段策略（长等待期间每 N 秒提示）
"""

from __future__ import annotations

import random
from dataclasses import dataclass


def _extract_retry_after_seconds(exc: Exception) -> int | None:
    headers = getattr(exc, "headers", None)
    if headers is None:
        return None
    retry_after = None
    if hasattr(headers, "get"):
        retry_after = headers.get("retry-after") or headers.get("Retry-After")
    if retry_after is None:
        return None
    try:
        return max(0, int(str(retry_after).strip()))
    except Exception:
        return None


@dataclass(slots=True)
class RetryDelayPolicy:
    initial_delay: float = 0.5
    backoff_factor: float = 2.0
    max_delay: float = 32.0
    jitter: bool = True

    def compute_delay_seconds(self, *, attempt: int, exc: Exception) -> float:
        retry_after = _extract_retry_after_seconds(exc)
        if retry_after is not None:
            return float(retry_after)
        base = min(self.initial_delay * (self.backoff_factor ** attempt), self.max_delay)
        if not self.jitter:
            return base
        return base * random.uniform(0.75, 1.25)


@dataclass(slots=True)
class RetryHeartbeatPolicy:
    threshold_seconds: float = 30.0
    interval_seconds: float = 30.0

    def should_emit_heartbeat(self, delay_seconds: float) -> bool:
        return delay_seconds > self.threshold_seconds


__all__ = ["RetryDelayPolicy", "RetryHeartbeatPolicy"]
