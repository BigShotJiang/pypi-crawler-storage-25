"""
模型重试事件到 loop message 的桥接。

职责：
- 将 retrier 产出的事件转为 SystemMessage
- 由 model_node 统一并入 Command(update={"messages": ...})
"""

from __future__ import annotations

from typing import Iterable

from langchain_core.messages import SystemMessage
from langgraph.types import Command

from .retry_events import (
    RETRY_EVENT_METADATA_FLAG,
    RETRY_EVENT_SUBTYPE,
    ModelRetryEvent,
)


def _format_retry_event_message(event: ModelRetryEvent) -> str:
    seconds = max(0, int(round(event.retry_in_ms / 1000)))
    if event.event_type == "heartbeat":
        prefix = "Retry still pending"
    else:
        prefix = "Retry scheduled"
    return (
        f"[{prefix}] in {seconds}s "
        f"(attempt {event.attempt}/{event.max_retries}) "
        f"{event.error_type}: {event.error_message}"
    )


def build_retry_event_commands(events: Iterable[ModelRetryEvent]) -> list[Command]:
    commands: list[Command] = []
    for event in events:
        msg = SystemMessage(
            content=_format_retry_event_message(event),
            response_metadata={
                RETRY_EVENT_METADATA_FLAG: True,
                "subtype": RETRY_EVENT_SUBTYPE,
                "event_type": event.event_type,
                "retry_in_ms": event.retry_in_ms,
                "attempt": event.attempt,
                "max_retries": event.max_retries,
                "error": {
                    "type": event.error_type,
                    "message": event.error_message,
                },
            },
        )
        commands.append(Command(update={"messages": [msg]}))
    return commands


__all__ = ["build_retry_event_commands"]
