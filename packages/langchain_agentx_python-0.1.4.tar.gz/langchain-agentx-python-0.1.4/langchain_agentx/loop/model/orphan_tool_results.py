"""
流式中断 / 工具中断时 orphan tool_use 的 synthetic tool_result 占位（CC §5.3 / §5.6）。

与 `ToolNode` 执行路径解耦：完整注入应在 **tools 节点后**或 **model 节点**检测 abort 后调用。
当前仅提供契约与扩展点，避免与现有 LangGraph `Send` 并行语义冲突。
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import ToolMessage


def synthetic_tool_messages_for_orphan_tool_calls(
    *,
    pending_tool_calls: list[dict[str, Any]],
    content_template: str = "[Tool call aborted or stream interrupted; synthetic result.]",
) -> list[ToolMessage]:
    """为仍挂在最后一条 AIMessage 上、但未收到 ToolMessage 的 tool_call 生成占位结果。

    供流式中断、abort、synthetic 兜底路径组装 `messages` 时使用；**不**代替 ToolNode 的真实执行。
    """
    out: list[ToolMessage] = []
    for tc in pending_tool_calls:
        tid = tc.get("id") or ""
        name = str(tc.get("name") or "unknown_tool")
        out.append(
            ToolMessage(
                content=content_template,
                tool_call_id=tid,
                name=name,
            )
        )
    return out


__all__ = ["synthetic_tool_messages_for_orphan_tool_calls"]
