"""
发往 LLM 前的 tool 消息管线修复（对齐 Claude Code `ensureToolResultPairing` 的 LangChain 子集）。

实例（消息序列在干什么）
------------------------

下面用简写：AI = AIMessage（含 tool_calls），T = ToolMessage（对应一次 tool 结果）。

**例 A — 同一条对话里 `call_id` 出现两次（压缩/重放后常见）**

  修复前::

    AI(call_id=foo) → T(foo) → AI(call_id=foo 又写一遍) → T(foo)

  问题：第二次 AI 再声明 `foo`，提供商常报「tool_use id 必须唯一」。

  修复后::

    AI(call_id=foo) → T(foo) → AI(第二次不再带 foo) → 紧跟的那条 T(foo) 因对不上本轮 tool_calls，当孤儿删掉

    （结果里只保留「第一轮」的 AI→T 配对，避免 id 重复上送 API。）

**例 B — 同一次工具结果来了两遍（同一 `call_id` 两条 T）**

  修复前::

    AI(call_id=bar) → T(bar, 内容A) → T(bar, 内容B)

  修复后：只保留**最后一条** T(bar)（内容B）。

**例 C — AI 叫了工具但没等到结果（中断/丢消息）**

  修复前::

    AI(call_id=baz) → （没有 T(baz)）

  修复后：在 T 的位置**补一条 synthetic ToolMessage(baz)**，让下一轮模型调用合法，不 400。

**好处（为何放在 invoke 前，而不是靠提示词）：**
- 提供商/SDK 对「同一 tool_call_id 重复」「tool_result 无对应 tool_use」「重复 tool_result」
  往往直接 400；这是**协议约束**，与模型是否“注意”某段 System 提示无关。
- 在绑定模型调用前做一次确定性清洗，可避免因压缩/重放/中断导致的会话卡死，属于 **Harness 工程**，
  而不是对模型的软劝导。

本模块只做 LangChain `AIMessage.tool_calls` + `ToolMessage` 序列可表达的修复：
- 跨多条 assistant 消息按**首次出现**保留 `tool_call_id`，后续重复从 `tool_calls` 中剔除；
- 紧跟某条 `AIMessage` 的连续 `ToolMessage` 中，同一 `tool_call_id` **只保留最后一条**；
- 剔除不属于当前轮 `tool_calls` 的孤儿 `ToolMessage`；
- 对仍缺少 `ToolMessage` 的 `tool_call`，追加与 `orphan_tool_results` 一致的 synthetic 占位。

不修改图状态：仅作用于本次 `invoke/ainvoke` 使用的消息列表副本，每次进模型都会再修一遍，
因此无需把修复结果写回 checkpoint 也能持续生效。
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from langchain_core.messages import AIMessage, ToolMessage

from .orphan_tool_results import synthetic_tool_messages_for_orphan_tool_calls

_DEFAULT_SYNTHETIC = (
    "[Tool transcript repair: missing tool result; synthetic placeholder.]"
)


def _tool_call_id(tc: Any) -> str | None:
    if isinstance(tc, dict):
        tid = tc.get("id")
        return str(tid) if tid is not None and str(tid) != "" else None
    tid = getattr(tc, "id", None)
    return str(tid) if tid is not None and str(tid) != "" else None


def _tool_call_name(tc: Any) -> str:
    if isinstance(tc, dict):
        n = tc.get("name")
        return str(n) if n else "unknown_tool"
    n = getattr(tc, "name", None)
    return str(n) if n else "unknown_tool"


def _normalize_tool_call_dict(tc: Any) -> dict[str, Any]:
    if isinstance(tc, dict):
        return deepcopy(tc)
    tid = _tool_call_id(tc)
    return {
        "name": _tool_call_name(tc),
        "args": getattr(tc, "args", {}) or {},
        "id": tid or "",
        "type": "tool_call",
    }


def _copy_ai_with_tool_calls(m: AIMessage, new_calls: list[dict[str, Any]]) -> AIMessage:
    if hasattr(m, "model_copy"):
        try:
            return m.model_copy(update={"tool_calls": new_calls})
        except Exception:
            pass
    kwargs: dict[str, Any] = {"content": m.content, "tool_calls": new_calls}
    for key in ("additional_kwargs", "response_metadata", "usage_metadata", "id", "name"):
        if hasattr(m, key):
            kwargs[key] = getattr(m, key)
    return AIMessage(**kwargs)


def repair_messages_for_llm_invoke(
    messages: list[Any],
    *,
    synthetic_content_template: str = _DEFAULT_SYNTHETIC,
) -> tuple[list[Any], dict[str, Any]]:
    """返回 (修复后的消息列表, 统计信息)。输入不会被原地修改。"""
    stats: dict[str, Any] = {
        "repaired": False,
        "dropped_duplicate_ai_tool_calls": 0,
        "deduped_tool_messages": 0,
        "dropped_orphan_tool_messages": 0,
        "added_synthetic_tool_messages": 0,
    }

    if not messages:
        return [], stats

    out: list[Any] = []
    seen_global_ids: set[str] = set()
    i = 0
    n = len(messages)

    while i < n:
        m = messages[i]
        if isinstance(m, AIMessage) and getattr(m, "tool_calls", None):
            raw_calls = list(m.tool_calls)
            new_calls: list[dict[str, Any]] = []
            for tc in raw_calls:
                tid = _tool_call_id(tc)
                if not tid:
                    continue
                if tid in seen_global_ids:
                    stats["dropped_duplicate_ai_tool_calls"] += 1
                    stats["repaired"] = True
                    continue
                seen_global_ids.add(tid)
                new_calls.append(_normalize_tool_call_dict(tc))

            ai2 = _copy_ai_with_tool_calls(m, new_calls)
            out.append(ai2)
            i += 1

            batch: list[ToolMessage] = []
            while i < n and isinstance(messages[i], ToolMessage):
                batch.append(messages[i])
                i += 1

            last_by_id: dict[str, ToolMessage] = {}
            for tm in batch:
                raw_tid = getattr(tm, "tool_call_id", None)
                if raw_tid is None:
                    stats["dropped_orphan_tool_messages"] += 1
                    stats["repaired"] = True
                    continue
                tid = str(raw_tid)
                if tid in last_by_id:
                    stats["deduped_tool_messages"] += 1
                    stats["repaired"] = True
                last_by_id[tid] = tm

            valid_ids = {tid for tid in (_tool_call_id(tc) for tc in new_calls) if tid}

            for tm in batch:
                raw_tid = getattr(tm, "tool_call_id", None)
                if raw_tid is None:
                    continue
                if str(raw_tid) not in valid_ids:
                    stats["dropped_orphan_tool_messages"] += 1
                    stats["repaired"] = True

            ordered_tool_messages: list[ToolMessage] = []
            for tc in new_calls:
                tid = _tool_call_id(tc)
                if not tid or tid not in valid_ids:
                    continue
                if tid not in last_by_id:
                    continue
                ordered_tool_messages.append(last_by_id[tid])

            result_ids = {
                str(tm.tool_call_id)
                for tm in ordered_tool_messages
                if getattr(tm, "tool_call_id", None) is not None
            }

            for tm in ordered_tool_messages:
                out.append(tm)

            pending_dicts: list[dict[str, Any]] = []
            for tc in new_calls:
                tid = _tool_call_id(tc)
                if tid and tid not in result_ids:
                    pending_dicts.append({"id": tid, "name": _tool_call_name(tc)})
            if pending_dicts:
                synth = synthetic_tool_messages_for_orphan_tool_calls(
                    pending_tool_calls=pending_dicts,
                    content_template=synthetic_content_template,
                )
                out.extend(synth)
                stats["added_synthetic_tool_messages"] += len(synth)
                stats["repaired"] = True
            continue

        if isinstance(m, ToolMessage):
            stats["dropped_orphan_tool_messages"] += 1
            stats["repaired"] = True
            i += 1
            continue

        out.append(m)
        i += 1

    return out, stats


__all__ = ["repair_messages_for_llm_invoke"]
