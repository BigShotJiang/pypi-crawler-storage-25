"""
loop/subagent/graph.py — 子 Agent 图创建

职责：create_subagent_graph()，基于 SubagentContext 创建独立子 Loop 图
在整体链路中的位置：run_subagent() → create_subagent_graph() → subagent_graph.astream_events()
CC 对照：runAgent.ts 中 queryLoop() 调用（子会话复用主引擎）
当前裁剪范围：v1 复用 create_loop_agent；通过 tools 参数注入子代理工具，并传入
  parent_run_id/parent_tool_call_id 与父 run 关联。

执行流程（create_subagent_graph）：
  1. 从 ctx 读取 system_prompt / session_store / max_steps
  2. 调用 create_loop_agent(is_subagent=True, loader=..., parent_run_id=..., parent_tool_call_id=...)
     创建子图
  3. 返回编译后的 CompiledStateGraph，由 run_subagent() 调用 astream_events()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.tools import BaseTool
    from langgraph.graph.state import CompiledStateGraph

    from .context import SubagentContext


def create_subagent_graph(
    ctx: SubagentContext,
    loader: Any,
    model: str | BaseChatModel | None = None,
) -> CompiledStateGraph:
    """创建子 Agent 的 LangGraph 图。

    复用 create_loop_agent(..., is_subagent=True)。

    Args:
        ctx: 子 Agent 执行上下文（SubagentContext）
        loader: 子会话 ToolRuntimeLoader（已完成工具过滤与运行时装配）
        model: 语言模型（str 或 BaseChatModel），None 时由调用方保证已在 ctx 外部传入

    Returns:
        编译后的 CompiledStateGraph，可直接调用 astream_events()
    """
    from langchain_agentx.loop.graph.factory import create_loop_agent

    if model is None:
        raise ValueError("model is required for create_subagent_graph")

    # 显式 session_id：避免子图构图时生成 ephemeral id 刷屏日志，并与 ctx.agent_id 对齐便于追溯
    session_id = f"subagent:{ctx.subagent_type}:{ctx.agent_id}"

    return create_loop_agent(
        model=model,
        loader=loader,
        system_prompt=ctx.system_prompt or None,
        session_id=session_id,
        session_store=ctx.session_store,
        max_steps=ctx.max_steps,
        is_subagent=True,
        name=f"subagent:{ctx.subagent_type}:{ctx.agent_id[:8]}",
        parent_run_id=ctx.parent_run_id,
        parent_tool_call_id=ctx.parent_tool_call_id,
        parent_conversation_session_id=ctx.parent_conversation_session_id,
        enable_trace=ctx.enable_trace,
        # 背景子代理默认隐藏；前台子代理沿用默认可见性。
        trace_visibility="hidden" if ctx.is_async else "default",
        workspace_root=ctx.workspace_root or None,
        agent_home=ctx.agent_home,
        subagent_type=ctx.subagent_type,
    )
