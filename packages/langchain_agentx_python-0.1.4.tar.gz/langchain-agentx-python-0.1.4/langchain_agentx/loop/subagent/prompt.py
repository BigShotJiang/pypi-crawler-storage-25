"""
loop/subagent/prompt.py — 子代理 system prompt 环境信息注入

职责：enhance_system_prompt_with_env()，在子代理 base prompt 基础上追加
      env 块（工作区根、进程 cwd、git、agent_home、builtin 总闸等）与行为 notes。
在整体链路中的位置：SubagentOrchestrator.invoke_subagent() 调用（built-in 与 Markdown 子代理共用）。
CC 对照：constants/prompts.ts computeEnvInfo + enhanceSystemPromptWithEnvDetails。
"""

from __future__ import annotations

from langchain_agentx.utils.subprocess_text import default_text_subprocess_runner


_AGENT_NOTES = """Notes:
- Always use absolute file paths, never relative paths.
- In your final response, share file paths (always absolute) relevant to the task."""


def _is_git_repo(path: str) -> bool:
    try:
        runner = default_text_subprocess_runner()
        result = runner.run(
            ["git", "-C", path, "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            timeout=3,
        )
        return result.returncode == 0
    except Exception:
        return False


def enhance_system_prompt_with_env(
    base_prompt: str,
    cwd: str | None,
) -> str:
    """在 base_prompt 基础上追加环境信息块与行为 notes。

    cwd 为 None 时原样返回，不注入任何内容。
    CC 对照：computeEnvInfo + enhanceSystemPromptWithEnvDetails 的组合。
    """
    if not cwd:
        return base_prompt

    is_git = _is_git_repo(cwd)
    env_block = (
        f"<env>\n"
        f"Working directory: {cwd}\n"
        f"Is directory a git repo: {'Yes' if is_git else 'No'}\n"
        f"</env>"
    )
    return f"{base_prompt}\n\n{_AGENT_NOTES}\n\n{env_block}"
