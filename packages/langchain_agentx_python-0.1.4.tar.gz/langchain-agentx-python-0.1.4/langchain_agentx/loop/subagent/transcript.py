"""Subagent Transcript 存储与管理

职责：管理单个子会话 transcript 生命周期
在整体链路中的位置：runner.py 构造 SubagentTranscriptManager → append/flush/cleanup
CC 对照：src/agent/subagent/transcript.ts TranscriptStore 接口
当前裁剪范围：v1 Protocol + 内存实现 + JSONL 文件后端
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SubagentTranscriptStore(Protocol):
    """Transcript 存储后端契约（可换实现：replay/内存/日志）"""

    def write_transcript(
        self,
        agent_id: str,
        messages: list[dict[str, Any]],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """写入完整 transcript"""
        ...

    def append_message(self, agent_id: str, message: dict[str, Any]) -> None:
        """追加单条消息"""
        ...

    def read_transcript(self, agent_id: str) -> list[dict[str, Any]]:
        """读取 transcript"""
        ...

    def cleanup_transcript(self, agent_id: str) -> None:
        """清理 transcript"""
        ...


@dataclass
class SubagentTranscriptManager:
    """管理单个子会话 transcript 生命周期

    协作者：依赖 SubagentTranscriptStore（注入）
    不变量：flush() 必须在 cleanup() 之前调用
    """
    store: SubagentTranscriptStore
    agent_id: str
    parent_agent_id: str | None = None
    _buffer: list[dict[str, Any]] = field(default_factory=list)

    def append(self, message: dict[str, Any]) -> None:
        """追加消息到缓冲区并写入 store"""
        self._buffer.append(message)
        self.store.append_message(self.agent_id, message)

    def flush(self, final_messages: list[dict[str, Any]]) -> None:
        """写入完整 transcript（含元数据）"""
        metadata = {"parent_agent_id": self.parent_agent_id} if self.parent_agent_id else {}
        self.store.write_transcript(self.agent_id, final_messages, metadata)

    def cleanup(self) -> None:
        """清理缓冲区与 store"""
        self._buffer.clear()
        self.store.cleanup_transcript(self.agent_id)


class InMemoryTranscriptStore:
    """内存实现（供单测与 stub 使用）"""

    def __init__(self) -> None:
        self._storage: dict[str, list[dict[str, Any]]] = {}

    def write_transcript(
        self,
        agent_id: str,
        messages: list[dict[str, Any]],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._storage[agent_id] = messages.copy()

    def append_message(self, agent_id: str, message: dict[str, Any]) -> None:
        if agent_id not in self._storage:
            self._storage[agent_id] = []
        self._storage[agent_id].append(message)

    def read_transcript(self, agent_id: str) -> list[dict[str, Any]]:
        return self._storage.get(agent_id, [])

    def cleanup_transcript(self, agent_id: str) -> None:
        self._storage.pop(agent_id, None)


class JsonlTranscriptStore:
    """JSONL 文件实现（按 session/agent 隔离 transcript）。"""

    def __init__(self, transcripts_dir: str | Path, session_id: str) -> None:
        self._transcripts_dir = Path(transcripts_dir)
        self._session_id = session_id

    def write_transcript(
        self,
        agent_id: str,
        messages: list[dict[str, Any]],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        path = self._resolve_path(agent_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as handle:
            for message in messages:
                handle.write(self._encode_line(message))
            if metadata:
                handle.write(self._encode_line({"type": "metadata", **metadata}))

    def append_message(self, agent_id: str, message: dict[str, Any]) -> None:
        path = self._resolve_path(agent_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(self._encode_line(message))

    def read_transcript(self, agent_id: str) -> list[dict[str, Any]]:
        path = self._resolve_path(agent_id)
        if not path.exists():
            return []
        messages: list[dict[str, Any]] = []
        with path.open("r", encoding="utf-8") as handle:
            for raw_line in handle:
                decoded = self._decode_line(raw_line)
                if decoded is None:
                    continue
                if decoded.get("type") == "metadata":
                    continue
                messages.append(decoded)
        return messages

    def read_transcript_after_last_boundary(self, agent_id: str) -> list[dict[str, Any]]:
        """读取最后一个 compact_boundary 之后的消息（边界本身不返回）。"""
        messages = self.read_transcript(agent_id)
        last_boundary_index = -1
        for idx, item in enumerate(messages):
            if item.get("type") == "compact_boundary":
                last_boundary_index = idx
        if last_boundary_index < 0:
            return messages
        return messages[last_boundary_index + 1 :]

    def cleanup_transcript(self, agent_id: str) -> None:
        path = self._resolve_path(agent_id)
        if path.exists():
            path.unlink()
        session_dir = path.parent
        if session_dir.exists() and not any(session_dir.iterdir()):
            session_dir.rmdir()

    def _resolve_path(self, agent_id: str) -> Path:
        return self._transcripts_dir / self._session_id / f"{agent_id}.jsonl"

    def _encode_line(self, payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False) + "\n"

    def _decode_line(self, line: str) -> dict[str, Any] | None:
        stripped = line.strip()
        if stripped == "":
            return None
        try:
            decoded = json.loads(stripped)
        except json.JSONDecodeError:
            return None
        if not isinstance(decoded, dict):
            return None
        return decoded
