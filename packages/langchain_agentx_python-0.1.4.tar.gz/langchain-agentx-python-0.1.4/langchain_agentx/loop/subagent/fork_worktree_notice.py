"""
loop/subagent/fork_worktree_notice.py — Fork 子 Agent 的 worktree 路径提示文案

职责：
    生成与 Claude Code ``buildWorktreeNotice`` 等价的 user 消息正文，提示子 Agent
    将继承消息中的路径从父工作目录映射到隔离 worktree。
链路位置：
    ``create_subagent_context`` 在 ``fork_from_parent`` 且存在 worktree 目录时追加一条 user 消息。
当前裁剪范围：
    仅英文固定模板（与 CC 原文一致）；不承载 i18n。
CC 对照：
    ``src/tools/AgentTool/forkSubagent.ts`` ``buildWorktreeNotice(parentCwd, worktreeCwd)``。
"""


def build_worktree_notice(parent_cwd: str, worktree_path: str) -> str:
    """与 CC ``buildWorktreeNotice`` 原文一致（参数为父 cwd 与 worktree 根路径）。"""
    return (
        f"You've inherited the conversation context above from a parent agent working in {parent_cwd}. "
        f"You are operating in an isolated git worktree at {worktree_path} — same repository, "
        "same relative file structure, separate working copy. Paths in the inherited context refer "
        "to the parent's working directory; translate them to your worktree root. Re-read files before "
        "editing if the parent may have modified them since they appear in the context. Your changes stay "
        "in this worktree and will not affect the parent's files."
    )
