"""Subagent Progress Event 数据结构

职责：进度事件载荷（Channel B）
在整体链路中的位置：runner.py 构造 → AgentRuntimeTool.invoke() 的 on_progress 回调消费
CC 对照：src/agent/subagent/progress.ts onProgress 回调参数类型
当前裁剪范围：v1 基础事件类型，无 async 路径
"""

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class SubagentProgressEvent:
    """子 Agent 进度事件

    type 枚举：
    - tool_use: 工具调用开始
    - tool_result: 工具调用结束
    - model_step: 模型推理完成
    - hint: 后台化提示（v2）
    - completed: 子 Agent 完成
    """
    type: Literal["tool_use", "tool_result", "model_step", "hint", "completed"]
    subagent_type: str = ""
    agent_id: str = ""
    step: int = 0
    tool_name: str = ""
    summary: str = ""
    meta: dict = field(default_factory=dict)
