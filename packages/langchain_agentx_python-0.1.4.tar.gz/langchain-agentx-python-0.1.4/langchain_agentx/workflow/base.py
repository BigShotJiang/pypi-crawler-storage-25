"""
workflow/base.py — Workflow 编排基类。

职责：
    封装任务级容器生命周期（start/invoke/end）、并发控制与单次 agent invoke 入口。

链路位置：
    作为场景化 Workflow 的父类，复用 Agent Loop 并对齐 LoopContainer 生命周期协议。

当前裁剪范围：
    仅提供 BaseWorkflow 最小契约；Dag/Batch 骨架在独立文件占位。
"""

from __future__ import annotations

import asyncio
import inspect
from abc import ABC, abstractmethod
from typing import Any, Callable, Literal
from uuid import uuid4

from ..loop.hook.types import HookContext, HookEvent
from ..memory.memdir.agent_memory import drain_pending_agent_memory_extraction


class BaseWorkflow(ABC):
    """场景编排基类。"""

    container_type: str = "workflow_task"

    def __init__(
        self,
        graph_factory: Callable[..., Any],
        hook_engine: Any,
        max_concurrency: int = 4,
        error_policy: Literal["fail_fast", "best_effort"] = "best_effort",
    ) -> None:
        self._graph_factory = graph_factory
        self._hook_engine = hook_engine
        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._error_policy = error_policy
        self._workflow_id = uuid4().hex[:8]

    async def __aenter__(self) -> "BaseWorkflow":
        await self._on_workflow_start()
        return self

    async def __aexit__(self, *_) -> None:
        await self._on_workflow_end()

    async def run(self, **kwargs: Any) -> Any:
        async with self:
            return await self._execute(**kwargs)

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现具体编排逻辑。"""

    async def _invoke_agent(
        self,
        messages: list[Any],
        task_key: str,
        parent_session_id: str | None = None,
    ) -> dict[str, Any]:
        session_id = f"{self._workflow_id}-{task_key}"
        async with self._semaphore:
            graph = self._graph_factory(
                session_id=session_id,
                parent_conversation_session_id=parent_session_id,
                is_subagent=parent_session_id is not None,
                container_type=self.container_type,
            )
            result = await graph.ainvoke({"messages": messages})
            return dict(result) if isinstance(result, dict) else {"result": result}

    async def _on_workflow_start(self) -> None:
        await self._execute_hook(HookEvent.SESSION_START)

    async def _on_workflow_end(self) -> None:
        await drain_pending_agent_memory_extraction(timeout_ms=60_000)
        await self._execute_hook(HookEvent.SESSION_END)

    async def _execute_hook(self, event: HookEvent) -> None:
        ctx = HookContext(event=event, state={}, session_id=self._workflow_id)
        execute_async = getattr(self._hook_engine, "execute_async", None)
        if callable(execute_async):
            async_out = execute_async(ctx)
            if inspect.isawaitable(async_out):
                await async_out
                return
        execute = getattr(self._hook_engine, "execute")
        out = execute(ctx)
        if inspect.isawaitable(out):
            await out


__all__ = ["BaseWorkflow"]
