"""
workflow/batch.py — Batch 编排骨架。

职责：
    为同构批处理任务提供标准执行模板（items -> process x N -> merge），
    子类实现 _process_item() 和 merge_results() 即可。

链路位置：
    继承 BaseWorkflow，为批处理型业务 Workflow 提供标准入口。

当前裁剪范围：
    并发由 BaseWorkflow._semaphore 控制；错误策略由 error_policy 决定。
"""

from __future__ import annotations

import asyncio
from abc import abstractmethod
from typing import Any

from .base import BaseWorkflow


class BatchWorkflow(BaseWorkflow):
    """批处理编排骨架。"""

    async def process_all(self, items: list[Any]) -> Any:
        """
        并发处理所有 items，结果交给 merge_results() 聚合。

        best_effort：单个 item 失败记为 None，其余继续。
        fail_fast：任意 item 失败立即抛异常。
        """
        tasks = [self._process_item(item, idx) for idx, item in enumerate(items)]
        if self._error_policy == "fail_fast":
            results = await asyncio.gather(*tasks)
        else:
            raw_results = await asyncio.gather(*tasks, return_exceptions=True)
            results = [None if isinstance(item, BaseException) else item for item in raw_results]
        return self.merge_results(results)

    @abstractmethod
    async def _process_item(self, item: Any, index: int) -> Any:
        """子类实现单个 item 的处理逻辑。"""

    @abstractmethod
    def merge_results(self, results: list[Any]) -> Any:
        """子类实现多个 item 结果的聚合逻辑。"""

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现入口，通常直接调用 process_all(items)。"""


__all__ = ["BatchWorkflow"]
