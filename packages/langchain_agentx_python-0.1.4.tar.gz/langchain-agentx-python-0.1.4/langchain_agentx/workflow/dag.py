"""
workflow/dag.py — DAG 编排骨架。

职责：
    为有向无环图编排场景提供步骤辅助入口（_run_step），
    子类通过普通 Python 代码声明步骤依赖与并发关系。

链路位置：
    继承 BaseWorkflow，为具体业务 Workflow（如 WikiWorkflow）提供结构化骨架。

当前裁剪范围：
    不做自动 DAG 拓扑调度，步骤顺序与并发由子类 _execute() 控制。
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from .base import BaseWorkflow


class DagWorkflow(BaseWorkflow):
    """
    DAG 编排骨架。

    子类通过 _run_step() 与 Python 控制流表达依赖与并发。
    """

    async def _run_step(
        self,
        step_name: str,
        messages: list[Any],
        *,
        parent_session_id: str | None = None,
    ) -> dict[str, Any]:
        """
        执行单个 DAG 步骤。

        step_name 作为 task_key，最终生成 session_id = f"{workflow_id}-{step_name}"，
        trace 可按步骤名检索执行链路。
        """
        return await self._invoke_agent(
            messages=messages,
            task_key=step_name,
            parent_session_id=parent_session_id,
        )

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现具体步骤编排逻辑。"""


__all__ = ["DagWorkflow"]
