"""
session/conversation_recovery.py — 会话恢复入口编排。

职责：
    从 transcript store 读取并清洗消息，重建为可用于 resume 的 BaseMessage 链。

链路位置：
    为 AgentSession/ConversationSession 提供恢复前置能力。

当前裁剪范围：
    覆盖 compact 边界定位、unresolved tool_use 过滤、空白 assistant 过滤。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage

from ..loop.subagent.transcript import SubagentTranscriptStore


@dataclass
class CompactBoundaryLocator:
    """定位最后一个 compact_boundary 之后的恢复起点。"""

    def find_resume_start(self, records: list[dict[str, Any]]) -> int:
        last_boundary = -1
        for idx, record in enumerate(records):
            if record.get("type") == "compact_boundary":
                last_boundary = idx
        if last_boundary < 0:
            return 0
        return last_boundary + 1


@dataclass
class RecoveryMessageFilter:
    """恢复前消息过滤器。"""

    def filter_records(self, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        resolved_tool_ids = self._collect_resolved_tool_ids(records)
        kept: list[dict[str, Any]] = []
        valid_ai_tool_ids: set[str] = set()
        for record in records:
            record_type = str(record.get("type", ""))
            if record_type == "compact_boundary":
                continue
            if self._is_blank_assistant(record):
                continue
            if self._is_unresolved_tool_use(record, resolved_tool_ids):
                continue
            if record_type in {"ai", "assistant"}:
                for tool_call_id in self._extract_tool_call_ids(record):
                    valid_ai_tool_ids.add(tool_call_id)
            if record_type in {"tool", "tool_result"}:
                call_id = str(record.get("tool_call_id", ""))
                if call_id and call_id not in valid_ai_tool_ids:
                    continue
            kept.append(record)
        return kept

    def _collect_resolved_tool_ids(self, records: list[dict[str, Any]]) -> set[str]:
        resolved: set[str] = set()
        for record in records:
            record_type = str(record.get("type", ""))
            if record_type not in {"tool", "tool_result"}:
                continue
            call_id = str(record.get("tool_call_id", ""))
            if call_id:
                resolved.add(call_id)
        return resolved

    def _is_unresolved_tool_use(self, record: dict[str, Any], resolved_ids: set[str]) -> bool:
        record_type = str(record.get("type", ""))
        if record_type not in {"ai", "assistant"}:
            return False
        tool_call_ids = self._extract_tool_call_ids(record)
        if not tool_call_ids:
            return False
        return any(tool_call_id not in resolved_ids for tool_call_id in tool_call_ids)

    @staticmethod
    def _extract_tool_call_ids(record: dict[str, Any]) -> list[str]:
        tool_calls = record.get("tool_calls")
        if not isinstance(tool_calls, list):
            return []
        ids: list[str] = []
        for call in tool_calls:
            if not isinstance(call, dict):
                continue
            call_id = call.get("id")
            if isinstance(call_id, str) and call_id:
                ids.append(call_id)
        return ids

    @staticmethod
    def _is_blank_assistant(record: dict[str, Any]) -> bool:
        record_type = str(record.get("type", ""))
        if record_type not in {"ai", "assistant"}:
            return False
        content = record.get("content")
        if isinstance(content, str):
            return content.strip() == ""
        return False


@dataclass
class SessionRecoveryLoader:
    """恢复加载器：读取 -> 定位 -> 过滤 -> 反序列化。"""

    boundary_locator: CompactBoundaryLocator = field(default_factory=CompactBoundaryLocator)
    message_filter: RecoveryMessageFilter = field(default_factory=RecoveryMessageFilter)

    def load_session_messages(
        self,
        transcript_store: SubagentTranscriptStore,
        session_id: str,
    ) -> list[BaseMessage]:
        raw = transcript_store.read_transcript(session_id)
        start_index = self.boundary_locator.find_resume_start(raw)
        tail = raw[start_index:]
        filtered = self.message_filter.filter_records(tail)
        return [self._deserialize_record(record) for record in filtered]

    def _deserialize_record(self, record: dict[str, Any]) -> BaseMessage:
        record_type = str(record.get("type") or record.get("role") or "")
        content = record.get("content", "")
        normalized_content = content if isinstance(content, str) else str(content)
        if record_type in {"human", "user"}:
            return HumanMessage(content=normalized_content)
        if record_type in {"system"}:
            return SystemMessage(content=normalized_content)
        if record_type in {"tool", "tool_result"}:
            tool_call_id = str(record.get("tool_call_id", "recovered-tool-call"))
            name = str(record.get("name", "tool"))
            return ToolMessage(content=normalized_content, tool_call_id=tool_call_id, name=name)
        return AIMessage(content=normalized_content)


def load_session_messages(
    transcript_store: SubagentTranscriptStore,
    session_id: str,
) -> list[BaseMessage]:
    """便捷函数：使用默认 loader 恢复消息。"""
    return SessionRecoveryLoader().load_session_messages(transcript_store, session_id)


__all__ = [
    "CompactBoundaryLocator",
    "RecoveryMessageFilter",
    "SessionRecoveryLoader",
    "load_session_messages",
]

