"""
session/protocol.py — LoopContainer 协议定义。

职责：
    约束外层生命周期容器的最小异步上下文接口（on_start/on_end）。

链路位置：
    由 AgentSession 与后续 Workflow 基类共同实现，用于统一生命周期语义。

当前裁剪范围：
    仅定义 Protocol，不包含任何容器实现逻辑。
"""

from __future__ import annotations

from typing import Protocol, Self, runtime_checkable


@runtime_checkable
class LoopContainer(Protocol):
    async def __aenter__(self) -> Self: ...
    async def __aexit__(self, *_) -> None: ...


__all__ = ["LoopContainer"]
