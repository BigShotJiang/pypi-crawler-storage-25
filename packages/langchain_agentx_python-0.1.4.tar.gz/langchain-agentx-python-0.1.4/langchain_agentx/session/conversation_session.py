"""
session/conversation_session.py — 对话窗口级 Session 容器。

职责：
    管理单个对话窗口生命周期（session_start/end），每次请求新建 graph。

链路位置：
    作为 Web/IM 对话场景的外层容器，与 AgentSession 并列。

当前裁剪范围：
    覆盖最小生命周期与 run_turn 入口；memory manager 可选注入。
"""

from __future__ import annotations

import inspect
import logging
from typing import Any, Callable

from langchain_core.messages import HumanMessage
from langgraph.graph.state import CompiledStateGraph

from ..command import CommandContext, CommandDispatcher, CommandRegistry
from ..command.builtin import (
    make_clear_command,
    make_compact_command,
    make_memory_command,
    make_reload_plugins_command,
)
from ..loop.context.compaction_service import default_loop_context_compaction
from ..loop.context.message_utils import total_estimated_tokens_for_messages
from ..loop.hook.types import HookContext, HookEvent
from ..memory.memdir.agent_memory import drain_pending_agent_memory_extraction
from ..memory.memdir.extractor import drain_pending_extraction
from ..plugin.loader import PluginLoader
from ..plugin.registries import AgentRegistry, CommandRegistry as PluginCommandRegistry, SkillRegistry
from ..plugin.types import PluginLoadResult
from ..workspace.config import AgentWorkspaceConfig

logger = logging.getLogger(__name__)


class ConversationSession:
    """对话窗口级 session 容器。graph 每次请求新建，不复用。"""

    def __init__(
        self,
        graph_factory: Callable[..., CompiledStateGraph],
        conversation_id: str,
        workspace_cfg: AgentWorkspaceConfig,
        hook_engine: Any,
        plugin_loader: PluginLoader | None = None,
        initial_messages: list[Any] | None = None,
    ) -> None:
        self._graph_factory = graph_factory
        self._conversation_id = conversation_id
        self._workspace_cfg = workspace_cfg
        self._hook_engine = hook_engine
        self._messages: list[Any] = list(initial_messages or [])
        self._container_type = "conversation"
        self._session_memory_manager: Any | None = None
        self._skill_registry = SkillRegistry()
        self._command_registry = PluginCommandRegistry()
        self._agent_registry = AgentRegistry()
        self._runtime_command_registry = CommandRegistry()
        self._register_builtin_commands()
        self._dispatcher = CommandDispatcher(
            self._runtime_command_registry,
            plugin_command_registry=self._command_registry,
        )
        self._plugin_loader: PluginLoader | None
        if not workspace_cfg.plugins_enabled:
            self._plugin_loader = None
        else:
            self._plugin_loader = plugin_loader or PluginLoader(
                workspace_config=workspace_cfg,
                hook_engine=hook_engine,
                skill_registry=self._skill_registry,
                command_registry=self._command_registry,
                agent_registry=self._agent_registry,
            )

    async def __aenter__(self) -> "ConversationSession":
        if self._plugin_loader is not None:
            load_result = await self._plugin_loader.load_all(container_type="conversation")
            load_result.log_errors(logger)
        await self._execute_hook(HookEvent.SESSION_START)
        return self

    async def __aexit__(self, *_) -> None:
        if self._session_memory_manager is not None:
            await self._session_memory_manager.drain(timeout=30.0)
        await drain_pending_extraction(timeout_ms=60_000)
        await drain_pending_agent_memory_extraction(timeout_ms=60_000)
        await self._execute_hook(HookEvent.SESSION_END)
        if self._plugin_loader is not None:
            await self._plugin_loader.unload_all()

    async def run_turn(self, user_input: str) -> dict[str, Any]:
        """每次用户请求调用一次，graph 每次新建。"""
        appended_message = HumanMessage(content=user_input)
        self._messages.append(appended_message)
        graph = self._graph_factory(
            session_id=self._conversation_id,
            container_type="conversation",
        )
        try:
            result = await graph.ainvoke(
                {
                    "messages": list(self._messages),
                    "_session_id": self._conversation_id,
                }
            )
        except Exception:
            # 回滚本轮 append，避免异常路径消息重复累积。
            if self._messages and self._messages[-1] is appended_message:
                self._messages.pop()
            raise
        if isinstance(result, dict) and isinstance(result.get("messages"), list):
            self._messages = list(result["messages"])
        return dict(result) if isinstance(result, dict) else {"result": result}

    @property
    def conversation_id(self) -> str:
        return self._conversation_id

    @property
    def dispatcher(self) -> CommandDispatcher:
        return self._dispatcher

    def clear_context(self) -> None:
        self._messages.clear()

    async def compact_context(self) -> tuple[int, int]:
        before_tokens = total_estimated_tokens_for_messages(self._messages, num_chars_per_token=4)
        patch = default_loop_context_compaction().run({"messages": self._messages})
        if isinstance(patch.get("messages"), list):
            self._messages = list(patch["messages"])
        after_tokens = total_estimated_tokens_for_messages(self._messages, num_chars_per_token=4)
        return before_tokens, after_tokens

    async def reload_plugins(self) -> PluginLoadResult:
        if self._plugin_loader is None:
            return PluginLoadResult(enabled=[], errors=[])
        result = await self._plugin_loader.reload(container_type=self._container_type)
        result.log_errors(logger)
        return result

    def get_memory_summary(self, sub_cmd: str = "show") -> str:
        memory_path = self._workspace_cfg.session_memory_path(self._conversation_id)
        if sub_cmd == "clear":
            if memory_path.exists():
                memory_path.unlink()
            return "记忆已清除"
        if not memory_path.exists():
            return "（暂无记忆摘要）"
        content = memory_path.read_text(encoding="utf-8").strip()
        return content or "（暂无记忆摘要）"

    def _build_context(self) -> CommandContext:
        return CommandContext(
            session_id=self._conversation_id,
            session=self,
            workspace_cfg=self._workspace_cfg,
            hook_engine=self._hook_engine,
            plugin_loader=self._plugin_loader,
            extra={"container_type": self._container_type},
        )

    async def dispatch_command(self, user_input: str):
        return await self._dispatcher.dispatch(user_input, self._build_context())

    def list_commands(self) -> list[dict[str, object]]:
        return self._runtime_command_registry.list_for_help()

    async def _execute_hook(self, event: HookEvent) -> None:
        ctx = HookContext(event=event, state={}, session_id=self._conversation_id)
        execute_async = getattr(self._hook_engine, "execute_async", None)
        if callable(execute_async):
            async_out = execute_async(ctx)
            if inspect.isawaitable(async_out):
                await async_out
            return
        execute = getattr(self._hook_engine, "execute", None)
        if not callable(execute):
            return
        out = execute(ctx)
        if inspect.isawaitable(out):
            await out

    def _register_builtin_commands(self) -> None:
        self._runtime_command_registry.register(make_clear_command())
        self._runtime_command_registry.register(make_compact_command())
        self._runtime_command_registry.register(make_memory_command())
        self._runtime_command_registry.register(make_reload_plugins_command())


__all__ = ["ConversationSession"]
