"""
task_runtime/queue/in_memory.py — TaskCommandQueue 内存实现

职责：
    基于 list 的任务通知队列；采用 RLock 保证基础并发安全。
"""

from __future__ import annotations

from threading import RLock

from ..core.interfaces import TaskCommandQueue
from ..core.types import (
    QueuePriority,
    TaskNotificationEnvelope,
    TaskScope,
)


_PRIORITY_ORDER = {
    QueuePriority.NOW: 0,
    QueuePriority.NEXT: 1,
    QueuePriority.LATER: 2,
}


class InMemoryTaskCommandQueue(TaskCommandQueue):
    def __init__(self) -> None:
        self._lock = RLock()
        self._queue: list[TaskNotificationEnvelope] = []

    def enqueue(self, env: TaskNotificationEnvelope) -> None:
        with self._lock:
            self._queue.append(env)

    def peek_for_scope(
        self, scope: TaskScope, max_priority: QueuePriority
    ) -> list[TaskNotificationEnvelope]:
        threshold = _PRIORITY_ORDER[max_priority]
        with self._lock:
            filtered = [
                item
                for item in self._queue
                if item.scope.agent_id == scope.agent_id
                and _PRIORITY_ORDER[item.priority] <= threshold
            ]
            filtered.sort(key=lambda item: _PRIORITY_ORDER[item.priority])
            return filtered

    def remove(self, command_ids: list[str]) -> None:
        if not command_ids:
            return
        ids = set(command_ids)
        with self._lock:
            self._queue = [item for item in self._queue if item.command_id not in ids]
