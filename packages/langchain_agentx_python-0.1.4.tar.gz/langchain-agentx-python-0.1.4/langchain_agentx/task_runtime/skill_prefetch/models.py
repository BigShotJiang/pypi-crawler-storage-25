"""
tools/task_runtime/skill_prefetch/models.py — Skill 预取领域模型

职责：
    承载 Skill 预取阶段的稳定数据对象（hint / command 元信息）。

对照：
    对齐 CC skill discovery 的“轻量列表提示 + 动态候选提示”语义，
    用 dataclass 固化本工程 provider 内部契约。

实现约束：
    - 仅定义数据模型，不承载队列/注入/渲染逻辑；
    - 字段命名保持与 loop 注入 metadata 对齐（kind/command_id/source）。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal

from ..core.types import QueuePriority, TaskScope

SkillHintKind = Literal["skill_listing", "dynamic_skill"]


@dataclass(frozen=True)
class SkillHint:
    kind: SkillHintKind
    command_id: str
    summary: str
    scope: TaskScope
    priority: QueuePriority = QueuePriority.NEXT
    payload: dict[str, Any] = field(default_factory=dict)
    dedup_key: str | None = None
    created_at: float = field(default_factory=time.time)

