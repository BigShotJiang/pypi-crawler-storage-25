"""
task_runtime/skill_prefetch/attachments.py — Skill 附件构造器

职责：
    将 `SkillHint` 领域对象映射为 loop 可注入的 attachment message(dict)。

对照：
    对齐 CC 中 skill_listing / dynamic_skill attachment 的角色，
    但复用本工程 `task_event_reserve` + dedup 契约。

实现约束：
    - 采用 OOP 构造器，不在外层散落函数；
    - 兼容现有 dedup：复用 `metadata.task_notification.command_id`。
"""

from __future__ import annotations

from typing import Any

from .models import SkillHint


class SkillAttachmentBuilder:
    def build(self, hint: SkillHint) -> dict[str, Any]:
        return {
            "role": "user",
            "content": [{"type": "text", "text": self._build_text(hint)}],
            "metadata": {
                # Reuse task_notification.command_id for existing dedup filter.
                "task_notification": {"command_id": hint.command_id},
                "skill_notification": {
                    "command_id": hint.command_id,
                    "kind": hint.kind,
                    "skill_name": hint.payload.get("skill_name"),
                    "source": hint.payload.get("source", "prefetch"),
                    "provider": "skill_prefetch",
                    "turn_index": hint.payload.get("turn_index"),
                },
            },
        }

    def _build_text(self, hint: SkillHint) -> str:
        if hint.kind == "skill_listing":
            return f"[skill_listing] {hint.summary}"
        return f"[dynamic_skill] {hint.summary}"

