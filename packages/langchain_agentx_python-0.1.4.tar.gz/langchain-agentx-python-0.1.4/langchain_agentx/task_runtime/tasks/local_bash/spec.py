"""
tasks/local_bash/spec.py — LOCAL_BASH 输入契约（OOP）

职责：
    将未信任的 ``dict`` 解析为冻结的输入值对象；校验失败抛 ``ValueError``，
    由 ``TaskExecutor.execute`` 转为 ``TaskExecutionResult(FAILED)``。

与 CC 对比：
    CC 侧 ``LocalShellSpawnInput`` / guards（``BashTaskKind``）在 TS 中结构化；
    本仓库用 ``LocalBashTaskInput.from_mapping`` 做等价入口，避免业务层散落魔法 key。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class LocalBashTaskInput:
    """进程内 shell 任务输入（对齐 CC LocalShellTask 最小字段）。"""

    command: str
    cwd: str | None = None
    timeout_sec: int | None = None
    kind: str | None = None

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> LocalBashTaskInput:
        command = str(raw.get("command") or "").strip()
        if not command:
            raise ValueError("LOCAL_BASH requires non-empty 'command'")
        cwd_raw = raw.get("cwd")
        cwd = str(cwd_raw).strip() if cwd_raw not in (None, "") else None
        timeout_raw = raw.get("timeout_sec")
        if timeout_raw is None:
            timeout_sec = None
        else:
            timeout_sec = int(timeout_raw)
            if timeout_sec <= 0:
                raise ValueError("timeout_sec must be positive when set")
        kind_raw = raw.get("kind")
        kind = str(kind_raw).strip().lower() if kind_raw is not None else None
        return cls(command=command, cwd=cwd, timeout_sec=timeout_sec, kind=kind)

    def to_executor_mapping(self) -> dict[str, Any]:
        """供 ``TaskSpec.input`` 序列化；仅包含执行器消费的键。"""
        out: dict[str, Any] = {"command": self.command}
        if self.cwd is not None:
            out["cwd"] = self.cwd
        if self.timeout_sec is not None:
            out["timeout_sec"] = self.timeout_sec
        if self.kind is not None:
            out["kind"] = self.kind
        return out
