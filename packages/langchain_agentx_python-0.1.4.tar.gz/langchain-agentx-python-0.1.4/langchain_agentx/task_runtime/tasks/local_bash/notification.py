"""
tasks/local_bash/notification.py — 终态摘要格式（OOP）

职责：
    封装与 CC UI/通知折叠相关的摘要前缀与格式化，便于单测锚定。

与 CC 对比：
    ``LocalShellTask.tsx`` 中 ``BACKGROUND_BASH_SUMMARY_PREFIX``、
    ``enqueueShellNotification`` 对 completed/failed/killed 的展示逻辑；
    此处仅保留可移植的最小前缀与拼接规则。
"""


class LocalBashNotificationFormatter:
    """CC: ``BACKGROUND_BASH_SUMMARY_PREFIX = 'Background command '``"""

    BACKGROUND_BASH_SUMMARY_PREFIX = "Background command "

    @classmethod
    def format_terminal(cls, *, description: str, status: str) -> str:
        desc = (description or "").strip() or "(no description)"
        return f"{cls.BACKGROUND_BASH_SUMMARY_PREFIX}\"{desc}\" [{status}]"
