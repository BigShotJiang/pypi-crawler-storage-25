"""
tasks/local_bash/executor.py — LOCAL_BASH 执行器

职责：
    解析输入、``subprocess.run`` 执行、返回 ``TaskExecutionResult``。

与 CC 对比：
    CC ``LocalShellTask`` 含输出文件、stall watchdog、kill 等；本仓库最小实现仅覆盖
    「一次 shell 执行 → 终态摘要」，长驻/monitor 等分期扩展。
"""

from __future__ import annotations

import subprocess
from typing import TYPE_CHECKING, Optional

from ...core.interfaces import TaskExecutor
from ...core.types import TaskExecutionResult, TaskStatus

from .spec import LocalBashTaskInput

if TYPE_CHECKING:
    from ...output.sink import TaskOutputSink


class LocalBashExecutor(TaskExecutor):
    """本地 shell 执行器：输入经 ``LocalBashTaskInput.from_mapping`` 校验。"""

    def __init__(
        self,
        *,
        default_timeout_sec: int = 30,
        output_sink: Optional["TaskOutputSink"] = None,
    ) -> None:
        self._default_timeout_sec = default_timeout_sec
        self._output_sink = output_sink

    def execute(self, record) -> TaskExecutionResult:
        try:
            parsed = LocalBashTaskInput.from_mapping(dict(record.input or {}))
        except ValueError as e:
            return TaskExecutionResult(
                status=TaskStatus.FAILED,
                summary=str(e),
            )

        timeout_sec = (
            parsed.timeout_sec
            if parsed.timeout_sec is not None
            else self._default_timeout_sec
        )

        try:
            # shell=True：不适用 TextSubprocessRunner（其拒绝 shell）；显式 UTF-8 与 CC/遥测对齐。
            completed = subprocess.run(
                parsed.command,
                shell=True,
                cwd=parsed.cwd,
                text=True,
                encoding="utf-8",
                errors="replace",
                capture_output=True,
                timeout=timeout_sec,
                check=False,
            )
        except subprocess.TimeoutExpired:
            return TaskExecutionResult(
                status=TaskStatus.FAILED,
                summary=f"Command timed out after {timeout_sec}s",
            )

        out_blob = (completed.stdout or "") + (
            "\n" if (completed.stdout and completed.stderr) else ""
        ) + (completed.stderr or "")
        if self._output_sink is not None and out_blob:
            self._output_sink.append(record.task_id, out_blob)

        if completed.returncode == 0:
            stdout = (completed.stdout or "").strip()
            summary = stdout[:300] if stdout else "Command completed"
            return TaskExecutionResult(
                status=TaskStatus.COMPLETED,
                summary=summary,
            )

        stderr = (completed.stderr or "").strip()
        summary = (
            stderr[:300]
            if stderr
            else f"Command failed with exit code {completed.returncode}"
        )
        return TaskExecutionResult(
            status=TaskStatus.FAILED,
            summary=summary,
        )
