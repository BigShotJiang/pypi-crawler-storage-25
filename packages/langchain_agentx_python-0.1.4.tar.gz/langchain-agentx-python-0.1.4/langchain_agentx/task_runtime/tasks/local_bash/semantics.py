"""tasks/local_bash/semantics.py — ``TaskSemanticContract`` 绑定。"""

from __future__ import annotations

from ...core.types import TaskStatus, TaskType
from ..base.contracts import TaskSemanticContract


LOCAL_BASH_SEMANTIC = TaskSemanticContract(
    task_type=TaskType.LOCAL_BASH,
    terminal_statuses=(TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED),
    summary_prefix="local_bash",
)
