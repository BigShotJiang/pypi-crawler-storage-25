"""
tasks/dream_task/executor.py — DREAM_TASK 执行器

职责：
    按 ``constraints.max_turns`` 驱动轻量 **phase / progress** 状态机（``starting`` →
    ``updating`` → ``completed``），终态摘要由 ``DreamTaskNotificationFormatter`` 产出。

与 CC 对比：
    CC ``addDreamTurn`` / ``DreamTaskState`` 多轮 richer；本实现用同步循环模拟 turn，
    真 multi-turn LLM 可在循环体内替换为异步调度（保持 ``DreamTaskState`` 更新语义）。
"""

from __future__ import annotations

from ...core.interfaces import TaskExecutor
from ...core.types import TaskExecutionResult, TaskStatus

from .notification import DreamTaskNotificationFormatter
from .spec import DreamTaskInput
from .state import DreamTaskState


def _clamp_turns(raw: object) -> int:
    if raw is None:
        return 1
    try:
        n = int(raw)
    except (TypeError, ValueError):
        return 1
    return max(1, min(n, 48))


class DreamTaskExecutor(TaskExecutor):
    def execute(self, record) -> TaskExecutionResult:
        try:
            parsed = DreamTaskInput.from_mapping(dict(record.input or {}))
        except ValueError as e:
            return TaskExecutionResult(status=TaskStatus.FAILED, summary=str(e))

        max_turns = _clamp_turns(parsed.constraints.get("max_turns", 1))
        state = DreamTaskState()

        for turn in range(max_turns):
            if turn == 0:
                state.phase = "starting"
            else:
                state.phase = "updating"
            state.progress = (turn + 1) / float(max_turns)
            state.latest_note = (
                f"turn {turn + 1}/{max_turns} goal={parsed.goal[:120]!r}"
            )

        state.phase = "completed"
        state.progress = 1.0
        ctx_hint = ""
        if parsed.context_snapshot:
            ctx_hint = f" ctx_keys={list(parsed.context_snapshot.keys())[:8]}"
        state.latest_note = f"dream finished{ctx_hint}"

        summary = DreamTaskNotificationFormatter.build_summary(state)
        return TaskExecutionResult(status=TaskStatus.COMPLETED, summary=summary)
