"""tasks/dream_task/semantics.py — 语义契约绑定。"""

from __future__ import annotations

from ...core.types import TaskStatus, TaskType
from ..base.contracts import TaskSemanticContract


DREAM_TASK_SEMANTIC = TaskSemanticContract(
    task_type=TaskType.DREAM_TASK,
    terminal_statuses=(TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED),
    summary_prefix="dream_task",
)
