"""
tasks/dream_task/notification.py — 进度/终态摘要（OOP）

与 CC 对比：
    CC ``DreamTaskState`` 含 ``turns``、``filesTouched``；本仓库 ``DreamTaskState``
    为轻量占位，由 ``DreamTaskNotificationFormatter`` 生成可读摘要。
"""

from __future__ import annotations

from .state import DreamTaskState


class DreamTaskNotificationFormatter:
    @classmethod
    def build_summary(cls, state: DreamTaskState) -> str:
        pct = int(max(0.0, min(1.0, state.progress)) * 100)
        note = state.latest_note.strip() or "running"
        return f"dream_task phase={state.phase} progress={pct}% note={note}"
