"""
tasks/dream_task/spec.py — DREAM_TASK 输入契约（OOP）

职责：
    约束 dream / 记忆整理类任务的 goal 与可选约束字典。

与 CC 对比：
    ``DreamTask/DreamTask.ts`` 中 ``DreamTaskState``（phase、turns 等）更丰富；
    本仓库用 ``DreamTaskInput.from_mapping`` 表达最小可执行字段，状态机分期扩展。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True)
class DreamTaskInput:
    goal: str
    constraints: dict[str, Any] = field(default_factory=dict)
    context_snapshot: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> DreamTaskInput:
        goal = str(raw.get("goal") or "").strip()
        if not goal:
            raise ValueError("DREAM_TASK requires non-empty 'goal'")
        cons = raw.get("constraints")
        ctx = raw.get("context_snapshot")
        return cls(
            goal=goal,
            constraints=dict(cons) if isinstance(cons, Mapping) else {},
            context_snapshot=dict(ctx) if isinstance(ctx, Mapping) else {},
        )
