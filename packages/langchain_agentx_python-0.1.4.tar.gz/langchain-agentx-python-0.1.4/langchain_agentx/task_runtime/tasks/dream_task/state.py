"""
tasks/dream_task/state.py — 轻量状态占位

与 CC 对比：
    CC ``DreamPhase`` = starting | updating；此处用字符串 phase 占位。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DreamTaskState:
    phase: str = "starting"
    progress: float = 0.0
    latest_note: str = ""
