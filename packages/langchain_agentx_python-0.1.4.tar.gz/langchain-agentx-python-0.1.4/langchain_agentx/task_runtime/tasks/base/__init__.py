"""Base semantic contracts for task types."""

from .contracts import TaskSemanticContract

__all__ = ["TaskSemanticContract"]

