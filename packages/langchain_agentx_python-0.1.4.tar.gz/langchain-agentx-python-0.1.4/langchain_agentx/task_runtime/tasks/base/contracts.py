"""
task_runtime/tasks/base/contracts.py — 任务语义契约基类

职责：
    用不可变数据类描述「某一 TaskType 的终态集合与摘要前缀」，
    与具体 ``TaskExecutor`` 解耦，便于文档化与静态检查。

与 CC 对比：
    CC 在 ``TaskStateBase`` / 各 task 的 ``type`` 判别式中分散语义；
    本仓库用 ``TaskSemanticContract`` 收敛为可导入的单一事实来源（SSOT 子集）。
"""

from __future__ import annotations

from dataclasses import dataclass

from ...core.types import TaskStatus, TaskType


@dataclass(frozen=True)
class TaskSemanticContract:
    task_type: TaskType
    terminal_statuses: tuple[TaskStatus, ...]
    summary_prefix: str
