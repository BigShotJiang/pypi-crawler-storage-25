"""tasks/remote_agent/semantics.py — 语义契约绑定。"""

from __future__ import annotations

from ...core.types import TaskStatus, TaskType
from ..base.contracts import TaskSemanticContract


REMOTE_AGENT_SEMANTIC = TaskSemanticContract(
    task_type=TaskType.REMOTE_AGENT,
    terminal_statuses=(TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED),
    summary_prefix="remote_agent",
)
