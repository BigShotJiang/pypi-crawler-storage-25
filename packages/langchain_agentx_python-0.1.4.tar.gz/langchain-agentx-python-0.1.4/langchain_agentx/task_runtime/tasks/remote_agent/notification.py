"""
tasks/remote_agent/notification.py — 终态摘要（OOP）

与 CC 对比：
    CC 在 poll 完成时生成可展示的 notification 文本；本类仅提供占位格式化。
"""


class RemoteAgentNotificationFormatter:
    @classmethod
    def format_command_completion(
        cls,
        *,
        session_id: str,
        command: str,
        remote_task_type: str,
    ) -> str:
        excerpt = command[:160]
        return (
            f"Remote agent command completed: session={session_id} "
            f"type={remote_task_type} cmd={excerpt!r}"
        )
