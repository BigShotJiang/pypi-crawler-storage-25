"""
tasks/remote_agent/spec.py — REMOTE_AGENT 输入契约（OOP）

职责：
    描述远程会话类任务的最小输入；.teleport / poll 等网络行为不在 spec 内实现。

与 CC 对比：
    ``RemoteAgentTask.tsx`` 中 ``sessionId``、``command``、``remoteTaskType``、
    ``RemoteAgentTaskState``；本仓库用 ``RemoteAgentTaskInput.from_mapping`` 对齐命名，
    真轮询与元数据持久化在 executor 分期接入。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class RemoteAgentTaskInput:
    session_id: str
    command: str
    remote_task_type: str = "remote-agent"

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> RemoteAgentTaskInput:
        sid = str(raw.get("session_id") or raw.get("sessionId") or "").strip()
        cmd = str(raw.get("command") or "").strip()
        if not sid:
            raise ValueError("REMOTE_AGENT requires 'session_id'")
        if not cmd:
            raise ValueError("REMOTE_AGENT requires non-empty 'command'")
        rtt = str(raw.get("remote_task_type") or raw.get("remoteTaskType") or "remote-agent").strip()
        return cls(session_id=sid, command=cmd, remote_task_type=rtt or "remote-agent")
