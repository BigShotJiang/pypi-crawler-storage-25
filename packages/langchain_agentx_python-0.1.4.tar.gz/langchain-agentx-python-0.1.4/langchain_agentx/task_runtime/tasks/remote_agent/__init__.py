"""REMOTE_AGENT 语义包（CC ``RemoteAgentTask``）。"""

from .backend import (
    ImmediateRemoteAgentBackend,
    RecordingRemoteAgentBackend,
    RemoteAgentSessionBackend,
)
from .executor import RemoteAgentExecutor
from .semantics import REMOTE_AGENT_SEMANTIC
from .spec import RemoteAgentTaskInput

__all__ = [
    "ImmediateRemoteAgentBackend",
    "RecordingRemoteAgentBackend",
    "RemoteAgentExecutor",
    "RemoteAgentSessionBackend",
    "REMOTE_AGENT_SEMANTIC",
    "RemoteAgentTaskInput",
]
