"""
tasks/remote_agent/backend.py — 远程会话命令后端（CC poll/send 语义）

职责：
    将 ``session_id + command`` 的执行与 executor 解耦，便于接入 **HTTP / teleport**
    等实现；默认 ``ImmediateRemoteAgentBackend`` 无 I/O，用于 CI 与单测。

与 CC 对比：
    CC ``RemoteAgentTask`` 轮询 ``pollRemoteSessionEvents`` 并下发 command；
    此处用 ``run_command`` 抽象一次「投递命令 → 终态结果」，真轮询可在实现内循环。
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ...core.types import TaskExecutionResult, TaskStatus
from .notification import RemoteAgentNotificationFormatter


@runtime_checkable
class RemoteAgentSessionBackend(Protocol):
    def run_command(
        self,
        *,
        session_id: str,
        command: str,
        remote_task_type: str,
    ) -> TaskExecutionResult:
        ...


class ImmediateRemoteAgentBackend:
    """无网络：命令立即视为成功，摘要与 CC 展示串对齐。"""

    def run_command(
        self,
        *,
        session_id: str,
        command: str,
        remote_task_type: str,
    ) -> TaskExecutionResult:
        summary = RemoteAgentNotificationFormatter.format_command_completion(
            session_id=session_id,
            command=command,
            remote_task_type=remote_task_type,
        )
        return TaskExecutionResult(status=TaskStatus.COMPLETED, summary=summary)


class RecordingRemoteAgentBackend:
    """包装另一后端并记录调用，便于测试与调试。"""

    def __init__(self, inner: RemoteAgentSessionBackend | None = None) -> None:
        self._inner = inner or ImmediateRemoteAgentBackend()
        self.calls: list[dict[str, str]] = []

    def run_command(
        self,
        *,
        session_id: str,
        command: str,
        remote_task_type: str,
    ) -> TaskExecutionResult:
        self.calls.append(
            {
                "session_id": session_id,
                "command": command,
                "remote_task_type": remote_task_type,
            }
        )
        return self._inner.run_command(
            session_id=session_id,
            command=command,
            remote_task_type=remote_task_type,
        )
