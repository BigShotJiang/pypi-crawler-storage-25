"""
tasks/remote_agent/executor.py — REMOTE_AGENT 执行器

职责：
    校验输入后委托 ``RemoteAgentSessionBackend.run_command``；默认
    ``ImmediateRemoteAgentBackend`` 无网络。生产接入 HTTP/teleport 时替换 backend。

与 CC 对比：
    CC ``pollRemoteSessionEvents`` + 命令下发；此处将一轮「投递命令 → 结果」收口到
    backend，轮询可在 ``HttpRemoteAgentBackend`` 等实现内完成。
"""

from __future__ import annotations

from typing import Optional

from ...core.interfaces import TaskExecutor
from ...core.types import TaskExecutionResult, TaskStatus

from .backend import ImmediateRemoteAgentBackend, RemoteAgentSessionBackend
from .spec import RemoteAgentTaskInput


class RemoteAgentExecutor(TaskExecutor):
    def __init__(self, backend: Optional[RemoteAgentSessionBackend] = None) -> None:
        self._backend: RemoteAgentSessionBackend = backend or ImmediateRemoteAgentBackend()

    def execute(self, record) -> TaskExecutionResult:
        try:
            parsed = RemoteAgentTaskInput.from_mapping(dict(record.input or {}))
        except ValueError as e:
            return TaskExecutionResult(status=TaskStatus.FAILED, summary=str(e))
        return self._backend.run_command(
            session_id=parsed.session_id,
            command=parsed.command,
            remote_task_type=parsed.remote_task_type,
        )
