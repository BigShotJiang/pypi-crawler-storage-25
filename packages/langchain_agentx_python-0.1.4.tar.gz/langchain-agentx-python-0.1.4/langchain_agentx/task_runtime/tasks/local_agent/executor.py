"""
tasks/local_agent/executor.py — LOCAL_AGENT 执行器

职责：
    解析输入并委托 ``LocalAgentRunner``；默认 ``DefaultLocalAgentRunner`` 为 CC 对齐的
    **单轮**终态路径。生产环境注入自定义 runner（子图 ``invoke`` / 线程池）即可。

与 CC 对比：
    CC 在 ``LocalAgentTask`` 内驱动完整 agent loop；本类不内置 loop，仅保证
    ``TaskRuntime.spawn → run_task → mark_terminal`` 与 runner 契约稳定。
"""

from __future__ import annotations

from typing import Optional

from ...core.interfaces import TaskExecutor
from ...core.types import TaskExecutionResult, TaskStatus

from .runner import DefaultLocalAgentRunner, LocalAgentRunner
from .spec import LocalAgentTaskInput


class LocalAgentExecutor(TaskExecutor):
    def __init__(self, runner: Optional[LocalAgentRunner] = None) -> None:
        self._runner: LocalAgentRunner = runner or DefaultLocalAgentRunner()

    def execute(self, record) -> TaskExecutionResult:
        try:
            parsed = LocalAgentTaskInput.from_mapping(dict(record.input or {}))
        except ValueError as e:
            return TaskExecutionResult(status=TaskStatus.FAILED, summary=str(e))
        return self._runner(record, parsed)
