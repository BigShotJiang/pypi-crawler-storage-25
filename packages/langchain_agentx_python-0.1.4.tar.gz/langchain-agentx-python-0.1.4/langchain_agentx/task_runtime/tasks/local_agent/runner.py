"""
tasks/local_agent/runner.py — LOCAL_AGENT 执行体（CC LocalAgentTask 单轮路径）

职责：
    将「解析后的输入 → TaskExecutionResult」从 Executor 中抽出，便于注入真实
    **子图 invoke / 线程化 runner**（生产），默认实现保持 **无外部依赖** 的可测单轮摘要。

与 CC 对比：
    CC ``LocalAgentTask`` 内嵌完整 agent loop；此处 ``DefaultLocalAgentRunner`` 仅产出
    与 ``LocalAgentNotificationFormatter`` 一致的终态摘要。接入 LangGraph 时实现
    ``LocalAgentRunner`` 协议并传入 ``LocalAgentExecutor(runner=...)`` 即可。
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ...core.types import TaskExecutionResult, TaskRecord, TaskStatus
from .notification import LocalAgentNotificationFormatter
from .spec import LocalAgentTaskInput


@runtime_checkable
class LocalAgentRunner(Protocol):
    def __call__(
        self, record: TaskRecord, parsed: LocalAgentTaskInput
    ) -> TaskExecutionResult:
        """由调用方实现：可同步调用子图或包装异步结果。"""
        ...


class DefaultLocalAgentRunner:
    """默认单轮 runner：结构化终态摘要（含 ``task_id`` 便于观测对齐 CC 轨迹）。"""

    def __call__(
        self, record: TaskRecord, parsed: LocalAgentTaskInput
    ) -> TaskExecutionResult:
        summary = LocalAgentNotificationFormatter.format_completion(
            prompt_excerpt=parsed.prompt,
            agent_label=parsed.agent_label,
            task_id=record.task_id,
        )
        return TaskExecutionResult(status=TaskStatus.COMPLETED, summary=summary)
