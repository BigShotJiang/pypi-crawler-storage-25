"""
tasks/local_agent/spec.py — LOCAL_AGENT 输入契约（OOP）

职责：
    解析子 agent / 后台会话类任务的输入；失败抛 ``ValueError``。

与 CC 对比：
    ``LocalAgentTask.tsx``、``LocalMainSessionTask.ts`` 使用更丰富的
    AgentDefinition / 进度追踪；本仓库用 ``LocalAgentTaskInput.from_mapping``
    表达最小可执行契约，真子图/长会话在 executor 内分期替换实现。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class LocalAgentTaskInput:
    prompt: str
    agent_label: str | None = None

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> LocalAgentTaskInput:
        prompt = str(raw.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("LOCAL_AGENT requires non-empty 'prompt'")
        label = raw.get("agent_label")
        agent_label = str(label).strip() if label not in (None, "") else None
        return cls(prompt=prompt, agent_label=agent_label)
