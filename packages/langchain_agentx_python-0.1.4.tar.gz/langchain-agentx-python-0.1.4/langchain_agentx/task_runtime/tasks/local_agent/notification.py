"""
tasks/local_agent/notification.py — 终态摘要（OOP）

与 CC 对比：
    CC ``LocalAgentTask`` 使用 ``AgentProgress``、token 累计等；
    此处仅提供最小可测的摘要拼接类。
"""


class LocalAgentNotificationFormatter:
    @classmethod
    def format_completion(
        cls,
        *,
        prompt_excerpt: str,
        agent_label: str | None,
        task_id: str | None = None,
    ) -> str:
        label = f" [{agent_label}]" if agent_label else ""
        tid = f" id={task_id}" if task_id else ""
        return f"Local agent task completed{label}{tid}: {prompt_excerpt[:200]}"
