"""
tasks/custom/executor.py — CUSTOM 执行器

职责：
    解析 ``CustomTaskInput`` 后按 ``payload.handler`` / ``metadata.custom_handler`` 分发；
    未指定 handler 时回退为 ``CustomTaskNotificationFormatter`` 终态摘要。

与 CC 对比：
    CC 无独立 ``custom`` Task 类型；本枚举为扩展点，handler 名与 payload 由业务约定。
"""

from __future__ import annotations

from ...core.interfaces import TaskExecutor
from ...core.types import TaskExecutionResult, TaskStatus

from .notification import CustomTaskNotificationFormatter
from .spec import CustomTaskInput


def _handler_name(record, parsed: CustomTaskInput) -> str | None:
    pl = parsed.payload
    if isinstance(pl, dict):
        h = pl.get("handler")
        if isinstance(h, str) and h.strip():
            return h.strip().lower()
    meta = record.metadata or {}
    h2 = meta.get("custom_handler")
    if isinstance(h2, str) and h2.strip():
        return h2.strip().lower()
    return None


class CustomTaskExecutor(TaskExecutor):
    def execute(self, record) -> TaskExecutionResult:
        try:
            parsed = CustomTaskInput.from_mapping(dict(record.input or {}))
        except ValueError as e:
            return TaskExecutionResult(status=TaskStatus.FAILED, summary=str(e))

        name = _handler_name(record, parsed)
        if name == "echo":
            return TaskExecutionResult(
                status=TaskStatus.COMPLETED,
                summary=f"custom[echo]: {parsed.body}",
            )
        if name == "upper":
            return TaskExecutionResult(
                status=TaskStatus.COMPLETED,
                summary=f"custom[upper]: {parsed.body.upper()}",
            )
        if name in ("fail", "failed"):
            reason = ""
            if isinstance(parsed.payload, dict):
                reason = str(parsed.payload.get("reason") or "").strip()
            summary = reason or "custom handler requested failure"
            return TaskExecutionResult(status=TaskStatus.FAILED, summary=summary)

        summary = CustomTaskNotificationFormatter.format_completion(body=parsed.body)
        return TaskExecutionResult(status=TaskStatus.COMPLETED, summary=summary)
