"""tasks/custom/notification.py — 终态摘要（OOP）"""


class CustomTaskNotificationFormatter:
    @classmethod
    def format_completion(cls, *, body: str) -> str:
        return f"custom task completed: {body[:280]}"
