"""tasks/custom/semantics.py — 语义契约绑定。"""

from __future__ import annotations

from ...core.types import TaskStatus, TaskType
from ..base.contracts import TaskSemanticContract


CUSTOM_SEMANTIC = TaskSemanticContract(
    task_type=TaskType.CUSTOM,
    terminal_statuses=(TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED),
    summary_prefix="custom",
)
