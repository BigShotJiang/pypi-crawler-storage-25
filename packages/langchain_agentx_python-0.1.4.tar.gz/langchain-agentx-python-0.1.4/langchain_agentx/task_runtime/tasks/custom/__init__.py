"""CUSTOM 语义包（扩展任务类型）。"""

from .executor import CustomTaskExecutor
from .semantics import CUSTOM_SEMANTIC
from .spec import CustomTaskInput

__all__ = ["CustomTaskExecutor", "CUSTOM_SEMANTIC", "CustomTaskInput"]
