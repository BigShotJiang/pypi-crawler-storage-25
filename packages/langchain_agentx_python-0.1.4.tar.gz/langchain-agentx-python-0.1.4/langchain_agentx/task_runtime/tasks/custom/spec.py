"""
tasks/custom/spec.py — CUSTOM 输入契约（OOP）

职责：
    扩展任务类型的最小结构化入口；业务侧应在 ``metadata`` 中标注 handler 版本。

与 CC 对比：
    CC ``types.ts`` 中未单独列 ``custom``；本仓库 ``TaskType.CUSTOM`` 对应「无法归入五类」
    的扩展点，输入必须显式包含 ``message`` 或 ``payload`` 之一。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class CustomTaskInput:
    body: str
    payload: dict[str, Any]

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> CustomTaskInput:
        msg = raw.get("message")
        if isinstance(msg, str) and msg.strip():
            return cls(body=msg.strip(), payload=dict(raw.get("payload") or {}))
        pl = raw.get("payload")
        if isinstance(pl, Mapping) and pl:
            text = str(pl.get("message") or pl.get("summary") or "").strip()
            if text:
                return cls(body=text, payload=dict(pl))
        raise ValueError("CUSTOM requires non-empty 'message' or payload with message/summary")
