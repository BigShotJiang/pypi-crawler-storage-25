"""tasks/in_process_teammate/semantics.py — 语义契约绑定。"""

from __future__ import annotations

from ...core.types import TaskStatus, TaskType
from ..base.contracts import TaskSemanticContract


IN_PROCESS_TEAMMATE_SEMANTIC = TaskSemanticContract(
    task_type=TaskType.IN_PROCESS_TEAMMATE,
    terminal_statuses=(TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED),
    summary_prefix="in_process_teammate",
)
