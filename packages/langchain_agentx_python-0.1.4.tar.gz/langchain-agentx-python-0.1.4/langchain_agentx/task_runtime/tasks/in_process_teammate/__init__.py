"""IN_PROCESS_TEAMMATE 语义包（CC ``InProcessTeammateTask``）。"""

from .executor import InProcessTeammateExecutor
from .semantics import IN_PROCESS_TEAMMATE_SEMANTIC
from .spec import InProcessTeammateTaskInput, TeammateIdentity

__all__ = [
    "InProcessTeammateExecutor",
    "IN_PROCESS_TEAMMATE_SEMANTIC",
    "InProcessTeammateTaskInput",
    "TeammateIdentity",
]
