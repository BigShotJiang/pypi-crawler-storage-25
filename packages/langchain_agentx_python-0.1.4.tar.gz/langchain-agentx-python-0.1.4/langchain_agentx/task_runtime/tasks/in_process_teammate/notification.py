"""
tasks/in_process_teammate/notification.py — 终态摘要（OOP）

与 CC 对比：
    CC 协作者任务在 UI pill / transcript 中展示 identity + 进度；
    此处仅格式化完成摘要字符串。
"""


class InProcessTeammateNotificationFormatter:
    @classmethod
    def format_completion(
        cls,
        *,
        agent_name: str,
        team_name: str,
        prompt: str,
        plan_mode_required: bool = False,
        parent_session_id: str = "",
    ) -> str:
        excerpt = prompt[:160]
        base = f"Teammate [{agent_name}@{team_name}] completed: {excerpt}"
        sess = f" parent_session={parent_session_id}" if parent_session_id else ""
        plan = " [plan_mode=required]" if plan_mode_required else ""
        return f"{base}{sess}{plan}"
