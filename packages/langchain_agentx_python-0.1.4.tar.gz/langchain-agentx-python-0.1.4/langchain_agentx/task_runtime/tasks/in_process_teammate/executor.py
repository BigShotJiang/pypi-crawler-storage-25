"""
tasks/in_process_teammate/executor.py — IN_PROCESS_TEAMMATE 执行器

职责：
    校验 identity + prompt，按 ``plan_mode_required`` 分支生成 CC 对齐的终态摘要
    （协作者 pill / transcript 文案骨架）。

与 CC 对比：
    CC ``InProcessTeammateTask`` 含 ``runAgent``、权限与 plan 模式；此处将 **plan_mode**
    显式反映在通知字符串中，执行体仍保持进程内同步（不触碰主线程 messages）。
"""

from __future__ import annotations

from ...core.interfaces import TaskExecutor
from ...core.types import TaskExecutionResult, TaskStatus

from .notification import InProcessTeammateNotificationFormatter
from .spec import InProcessTeammateTaskInput


class InProcessTeammateExecutor(TaskExecutor):
    def execute(self, record) -> TaskExecutionResult:
        try:
            parsed = InProcessTeammateTaskInput.from_mapping(dict(record.input or {}))
        except ValueError as e:
            return TaskExecutionResult(status=TaskStatus.FAILED, summary=str(e))
        i = parsed.identity
        summary = InProcessTeammateNotificationFormatter.format_completion(
            agent_name=i.agent_name,
            team_name=i.team_name,
            prompt=parsed.prompt,
            plan_mode_required=i.plan_mode_required,
            parent_session_id=i.parent_session_id,
        )
        return TaskExecutionResult(status=TaskStatus.COMPLETED, summary=summary)
