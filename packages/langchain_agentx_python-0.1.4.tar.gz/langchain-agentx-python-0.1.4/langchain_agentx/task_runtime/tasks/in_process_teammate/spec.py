"""
tasks/in_process_teammate/spec.py — IN_PROCESS_TEAMMATE 输入契约（OOP）

职责：
    校验 ``identity`` 子对象与 ``prompt``；对齐 CC 持久化结构的最小字段集。

与 CC 对比：
    ``InProcessTeammateTask/types.ts`` 中 ``TeammateIdentity`` + ``prompt``；
    本仓库用 ``TeammateIdentity.from_mapping`` / ``InProcessTeammateTaskInput.from_mapping``
    表达，不包含 ``AbortController`` 等仅运行时字段。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class TeammateIdentity:
    agent_id: str
    agent_name: str
    team_name: str
    parent_session_id: str
    plan_mode_required: bool = False

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> TeammateIdentity:
        return cls(
            agent_id=str(raw.get("agent_id") or "").strip(),
            agent_name=str(raw.get("agent_name") or "").strip(),
            team_name=str(raw.get("team_name") or "").strip(),
            parent_session_id=str(raw.get("parent_session_id") or "").strip(),
            plan_mode_required=bool(raw.get("plan_mode_required", False)),
        )

    def validate(self) -> None:
        for name, val in (
            ("agent_id", self.agent_id),
            ("agent_name", self.agent_name),
            ("team_name", self.team_name),
            ("parent_session_id", self.parent_session_id),
        ):
            if not val:
                raise ValueError(f"identity.{name} is required")


@dataclass(frozen=True)
class InProcessTeammateTaskInput:
    identity: TeammateIdentity
    prompt: str

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> InProcessTeammateTaskInput:
        ident_raw = raw.get("identity")
        if not isinstance(ident_raw, Mapping):
            raise ValueError("IN_PROCESS_TEAMMATE requires mapping 'identity'")
        identity = TeammateIdentity.from_mapping(ident_raw)
        identity.validate()
        prompt = str(raw.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("IN_PROCESS_TEAMMATE requires non-empty 'prompt'")
        return cls(identity=identity, prompt=prompt)
