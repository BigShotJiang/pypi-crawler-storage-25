"""
trace_cleanup/bootstrap.py — create_loop_agent 侧清理调度启动

职责：
    在图已 ``compile`` 后，若存在运行中 asyncio 循环，则 ``create_task(TraceCleanupScheduler.start())``。

链路位置：
    可由应用在 **async 上下文** 内显式调用；是否从 ``create_loop_agent`` 挂载由产品决定（当前 factory 未接线）。

当前裁剪范围：
    不解析 YAML；参数由 ``create_loop_agent`` 关键字传入；无 event loop 时仅打日志不抛错。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

logger = logging.getLogger(__name__)


class _NoopCompiledGraph:
    """TraceCleanupTask 不调用 invoke，仅占位满足 BaseWorkflow 契约。"""

    async def ainvoke(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        return {"messages": []}


def _noop_graph_factory(**kwargs: Any) -> _NoopCompiledGraph:
    return _NoopCompiledGraph()


def try_start_trace_cleanup_after_compile(
    builder: Any,
    *,
    poll_interval: float,
    failed_days: int,
    normal_days: int,
    enable_file_lock: bool,
    marker_cooldown_seconds: float | None,
    cleanup_diagnostic_reports: bool,
) -> None:
    """在 **当前线程** 存在运行中 event loop 时启动 ``TraceCleanupScheduler``，否则打 warning。"""
    wiring = getattr(builder, "_hook_graph_wiring", None)
    if wiring is None:
        logger.warning("trace cleanup: LoopGraphBuilder 缺少 _hook_graph_wiring，跳过启动")
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        logger.warning(
            "enable_trace_cleanup=True 但当前线程无运行中的 asyncio 事件循环，未启动 "
            "TraceCleanupScheduler；请在 async 内创建 agent 或自行 ``asyncio.create_task(scheduler.start())``"
        )
        return

    import langchain_agentx.task_runtime.tasks.ai_analysis  # noqa: F401 — registry 侧载

    from langchain_agentx.observability.evaluation.store import EvaluationStore
    from langchain_agentx.observability.trace.sqlite_store import SqliteTraceStore
    from langchain_agentx.task_runtime.tasks.ai_analysis.registry import registry

    from .scheduler import TraceCleanupScheduler

    trace_store = SqliteTraceStore.from_env()
    eval_store = EvaluationStore.from_env()
    cleanup_config: dict[str, Any] = {
        "failed_days": int(failed_days),
        "normal_days": int(normal_days),
        "cleanup_diagnostic_reports": bool(cleanup_diagnostic_reports),
    }
    scheduler = TraceCleanupScheduler(
        trace_store=trace_store,
        evaluation_store=eval_store,
        registry=registry,
        poll_interval=float(poll_interval),
        cleanup_config=cleanup_config,
        enable_file_lock=bool(enable_file_lock),
        marker_cooldown_seconds=marker_cooldown_seconds,
        task_factory_kwargs={
            "graph_factory": _noop_graph_factory,
            "hook_engine": wiring.hook_engine,
        },
    )
    loop.create_task(scheduler.start())
    logger.info(
        "TraceCleanupScheduler 已提交到事件循环 poll_interval=%s failed_days=%s normal_days=%s",
        poll_interval,
        failed_days,
        normal_days,
    )


__all__ = ["try_start_trace_cleanup_after_compile", "_noop_graph_factory"]
