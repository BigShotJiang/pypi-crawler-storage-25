"""
trace_cleanup/executor.py — TraceCleanupTask

职责：
    单次执行 trace session 分层保留清理（调用 SqliteTraceStore.cleanup_sessions_by_retention）。

链路位置：
    由 TraceCleanupScheduler（Phase 2）或测试/脚本通过 registry.get("trace.cleanup") 构造并 run()。

当前裁剪范围：
    ``cleanup_diagnostic_reports=False`` 时不删诊断报告（§4.1 Q1=A 默认）；不实现 cleanup_by_size（Q3 延后）。
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_agentx.observability.evaluation.store import EvaluationStore
from langchain_agentx.observability.trace.sqlite_store import SqliteTraceStore

from ..ai_analysis.base import BackgroundAiTask
from ..ai_analysis.registry import registry

logger = logging.getLogger(__name__)


class TraceCleanupTask(BackgroundAiTask):
    """清理过期 trace session（retention 策略由参数传入）。"""

    def __init__(
        self,
        trace_store: SqliteTraceStore,
        evaluation_store: EvaluationStore,
        **workflow_kwargs: Any,
    ) -> None:
        super().__init__(**workflow_kwargs)
        self._trace_store = trace_store
        self._evaluation_store = evaluation_store

    async def _execute(
        self,
        *,
        failed_days: int = 180,
        normal_days: int = 30,
        cleanup_diagnostic_reports: bool = False,
        **_: Any,
    ) -> dict[str, int]:
        deleted_sessions = self._trace_store.cleanup_sessions_by_retention(
            failed_days=int(failed_days),
            normal_days=int(normal_days),
        )
        deleted_reports = 0
        if cleanup_diagnostic_reports:
            deleted_reports = self._evaluation_store.cleanup_old_reports(days=int(failed_days))
        out: dict[str, int] = {
            "deleted_sessions": int(deleted_sessions),
            "deleted_reports": int(deleted_reports),
        }
        logger.info("TraceCleanupTask 完成: %s", out)
        return out


registry.register("trace.cleanup", TraceCleanupTask)

__all__ = ["TraceCleanupTask"]
