"""
trace_cleanup — Trace 数据清理后台任务（OB-D10 Phase 1）

职责：
    导出 TraceCleanupTask；import 本包时注册 ``trace.cleanup`` 到 BackgroundAiTaskRegistry。

链路位置：
    由 ``langchain_agentx.task_runtime.tasks.ai_analysis`` 包加载时一并 import，保证 registry 侧载。

当前裁剪范围：
    不含 create_agent / loop 挂载（Phase 4）；不含 ``cleanup_by_size``（OB-D10 Phase 5）。
"""

from __future__ import annotations

from .executor import TraceCleanupTask
from .scheduler import TraceCleanupScheduler

__all__ = ["TraceCleanupTask", "TraceCleanupScheduler"]
