"""
task_runtime/tasks/ai_analysis/base.py — 后台 AI 分析任务基类。

职责：
    继承 BaseWorkflow，覆盖 container_type 为 background_task，
    run() 增加静默降级，避免影响主流程。

链路位置：
    由后台任务调度器通过队列轮询触发。
"""

from __future__ import annotations

import logging
from abc import abstractmethod
from typing import Any

from ....workflow.base import BaseWorkflow

logger = logging.getLogger(__name__)


class BackgroundAiTask(BaseWorkflow):
    """后台 AI 分析任务基类。失败必须静默降级。"""

    container_type: str = "background_task"

    async def run(self, **kwargs: Any) -> Any:
        """覆盖 BaseWorkflow.run()，增加静默降级。"""
        try:
            return await super().run(**kwargs)
        except Exception:
            logger.exception("%s 执行失败，静默降级", self.__class__.__name__)
            return None

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现具体分析逻辑，结果写回外部存储。"""


__all__ = ["BackgroundAiTask"]
