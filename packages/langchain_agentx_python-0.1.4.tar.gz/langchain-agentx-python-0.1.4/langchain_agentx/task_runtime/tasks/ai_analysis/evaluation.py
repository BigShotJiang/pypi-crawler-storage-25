"""
task_runtime/tasks/ai_analysis/evaluation.py — EvaluationAnalysisTask 内置实现。

职责：
    对 EvaluationStore 中 check_failed 的 session 进行深度 AI 分析，
    并将结果写回 EvaluationStore.diagnostic_reports。
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import HumanMessage

from ....observability.evaluation.store import DiagnosticReport, EvaluationStore
from .base import BackgroundAiTask
from .registry import registry


class EvaluationAnalysisTask(BackgroundAiTask):
    """对 check_failed session 进行深度 AI 分析。"""

    def __init__(self, evaluation_store: EvaluationStore, **workflow_kwargs: Any) -> None:
        super().__init__(**workflow_kwargs)
        self._evaluation_store = evaluation_store

    async def _execute(self, session_id: str, **_: Any) -> None:
        failures = self._evaluation_store.get_results(session_id)
        fail_results = [result for result in failures if result.status == "fail"]
        if not fail_results:
            return

        evidence_summary = "\n".join(
            f"- [{result.checker_name}] {result.message}  evidence={result.evidence}"
            for result in fail_results
        )
        prompt = (
            f"以下是 session {session_id} 的评估失败记录：\n"
            f"{evidence_summary}\n\n"
            "请分析根因，指出是哪个模块、哪个逻辑路径导致了这些问题。\n"
            "输出格式：根因 / 涉及模块 / 建议排查点"
        )

        result = await self._invoke_agent(
            messages=[HumanMessage(content=prompt)],
            task_key=session_id,
        )

        report_text = ""
        if isinstance(result, dict):
            messages = result.get("messages", [])
            if messages:
                report_text = str(getattr(messages[-1], "content", "") or "")

        self._evaluation_store.save_diagnostic_report(
            DiagnosticReport(
                session_id=session_id,
                checker_names=[result.checker_name for result in fail_results],
                report=report_text,
                model="agent",
            )
        )


registry.register("evaluation.check_failed", EvaluationAnalysisTask)

__all__ = ["EvaluationAnalysisTask"]
