"""后台 AI 分析任务导出。"""

from .base import BackgroundAiTask
from .evaluation import EvaluationAnalysisTask
from .registry import BackgroundAiTaskRegistry, registry

# OB-D10：侧载 trace.cleanup 注册（executor 模块尾 registry.register）
from ..trace_cleanup import executor as _trace_cleanup_executor  # noqa: F401

__all__ = [
    "BackgroundAiTask",
    "BackgroundAiTaskRegistry",
    "registry",
    "EvaluationAnalysisTask",
]
