"""
task_runtime/tasks/ai_analysis/registry.py — 后台 AI 任务注册表。

职责：
    维护 trigger -> task_factory 映射，支持内置注册与外部覆盖。

链路位置：
    调度器通过 registry.get(trigger) 获取任务工厂。
"""

from __future__ import annotations

from typing import Any, Callable


class BackgroundAiTaskRegistry:
    """trigger -> task_factory 注册表。"""

    def __init__(self) -> None:
        self._registry: dict[str, Callable[..., Any]] = {}

    def register(self, trigger: str, task_factory: Callable[..., Any]) -> None:
        """注册或覆盖触发条件对应的任务工厂。"""
        self._registry[trigger] = task_factory

    def get(self, trigger: str) -> Callable[..., Any] | None:
        """按触发条件获取任务工厂，未注册返回 None。"""
        return self._registry.get(trigger)

    def list_triggers(self) -> list[str]:
        return list(self._registry.keys())


registry = BackgroundAiTaskRegistry()

__all__ = ["BackgroundAiTaskRegistry", "registry"]
