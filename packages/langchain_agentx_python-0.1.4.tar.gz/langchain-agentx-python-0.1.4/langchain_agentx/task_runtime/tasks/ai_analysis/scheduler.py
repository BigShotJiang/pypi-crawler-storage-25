"""
task_runtime/tasks/ai_analysis/scheduler.py — BackgroundAiTaskScheduler。

职责：
    定时轮询 EvaluationStore，找出有 fail 且无诊断报告的 session，
    并通过 registry 获取任务工厂异步触发分析任务。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from ....observability.evaluation.store import EvaluationStore
from .registry import BackgroundAiTaskRegistry

logger = logging.getLogger(__name__)


class BackgroundAiTaskScheduler:
    """定时轮询 EvaluationStore，触发后台 AI 分析任务。"""

    def __init__(
        self,
        evaluation_store: EvaluationStore,
        registry: BackgroundAiTaskRegistry,
        task_factory_kwargs: dict[str, Any] | None = None,
        poll_interval: float = 60.0,
    ) -> None:
        self._store = evaluation_store
        self._registry = registry
        self._task_factory_kwargs = task_factory_kwargs or {}
        self._poll_interval = poll_interval
        self._running = False

    async def start(self) -> None:
        """启动轮询循环，直到 stop() 被调用。"""
        self._running = True
        logger.info("BackgroundAiTaskScheduler 启动，轮询间隔 %ss", self._poll_interval)
        while self._running:
            await self._poll_once()
            await asyncio.sleep(self._poll_interval)

    def stop(self) -> None:
        self._running = False

    async def _poll_once(self) -> None:
        try:
            session_ids = self._store.get_sessions_needing_analysis()
        except Exception:
            logger.exception("Scheduler 轮询 EvaluationStore 失败")
            return

        for session_id in session_ids:
            task_factory = self._registry.get("evaluation.check_failed")
            if task_factory is None:
                continue
            try:
                task = task_factory(
                    evaluation_store=self._store,
                    **self._task_factory_kwargs,
                )
                asyncio.create_task(task.run(session_id=session_id))
                logger.debug("Scheduler 已触发 session %s 的分析任务", session_id)
            except Exception:
                logger.exception("Scheduler 触发 session %s 分析任务失败", session_id)


__all__ = ["BackgroundAiTaskScheduler"]
