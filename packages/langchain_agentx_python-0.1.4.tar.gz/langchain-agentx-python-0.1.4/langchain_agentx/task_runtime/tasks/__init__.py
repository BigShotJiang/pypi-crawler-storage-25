"""
task_runtime/tasks/__init__.py — 按 TaskType 分组的语义与执行器导出

职责：
    为上层提供 ``TaskExecutor`` 实现与契约类型，隐藏子包细节。

与 CC 对比：
    CC ``src/tasks/*.ts`` 按文件组织；本仓库按 ``TaskType`` 枚举分目录，
    每目录内 OOP：``spec`` / ``executor`` / ``notification`` / ``semantics``。
"""

from .custom import CUSTOM_SEMANTIC, CustomTaskExecutor, CustomTaskInput
from .dream_task import (
    DREAM_TASK_SEMANTIC,
    DreamTaskExecutor,
    DreamTaskInput,
    DreamTaskNotificationFormatter,
    DreamTaskState,
)
from .in_process_teammate import (
    IN_PROCESS_TEAMMATE_SEMANTIC,
    InProcessTeammateExecutor,
    InProcessTeammateTaskInput,
    TeammateIdentity,
)
from .local_agent import (
    LOCAL_AGENT_SEMANTIC,
    DefaultLocalAgentRunner,
    LocalAgentExecutor,
    LocalAgentRunner,
    LocalAgentTaskInput,
)
from .local_bash import (
    LOCAL_BASH_SEMANTIC,
    LocalBashExecutor,
    LocalBashNotificationFormatter,
    LocalBashTaskInput,
)
from .remote_agent import (
    REMOTE_AGENT_SEMANTIC,
    ImmediateRemoteAgentBackend,
    RecordingRemoteAgentBackend,
    RemoteAgentExecutor,
    RemoteAgentSessionBackend,
    RemoteAgentTaskInput,
)

__all__ = [
    "LOCAL_BASH_SEMANTIC",
    "LocalBashExecutor",
    "LocalBashNotificationFormatter",
    "LocalBashTaskInput",
    "LOCAL_AGENT_SEMANTIC",
    "DefaultLocalAgentRunner",
    "LocalAgentExecutor",
    "LocalAgentRunner",
    "LocalAgentTaskInput",
    "IN_PROCESS_TEAMMATE_SEMANTIC",
    "InProcessTeammateExecutor",
    "InProcessTeammateTaskInput",
    "TeammateIdentity",
    "REMOTE_AGENT_SEMANTIC",
    "ImmediateRemoteAgentBackend",
    "RecordingRemoteAgentBackend",
    "RemoteAgentExecutor",
    "RemoteAgentSessionBackend",
    "RemoteAgentTaskInput",
    "CUSTOM_SEMANTIC",
    "CustomTaskExecutor",
    "CustomTaskInput",
    "DREAM_TASK_SEMANTIC",
    "DreamTaskExecutor",
    "DreamTaskInput",
    "DreamTaskNotificationFormatter",
    "DreamTaskState",
]
