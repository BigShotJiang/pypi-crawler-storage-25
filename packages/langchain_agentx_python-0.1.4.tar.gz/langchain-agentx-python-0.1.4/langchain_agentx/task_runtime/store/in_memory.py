"""
task_runtime/store/in_memory.py — TaskStore 内存实现

职责：
    基于 dict 的任务记录存储；采用 RLock 保证基础并发安全。
"""

from __future__ import annotations

from dataclasses import replace
from threading import RLock
from typing import Iterable, Optional

from ..core.interfaces import TaskStore
from ..core.types import TaskRecord, TaskStatus


class InMemoryTaskStore(TaskStore):
    def __init__(self) -> None:
        self._lock = RLock()
        self._records: dict[str, TaskRecord] = {}

    def create(self, record: TaskRecord) -> None:
        with self._lock:
            self._records[record.task_id] = record

    def get(self, task_id: str) -> Optional[TaskRecord]:
        with self._lock:
            return self._records.get(task_id)

    def update(self, task_id: str, patch: dict) -> Optional[TaskRecord]:
        with self._lock:
            current = self._records.get(task_id)
            if current is None:
                return None
            updated = replace(current, **patch)
            self._records[task_id] = updated
            return updated

    def list(self) -> Iterable[TaskRecord]:
        with self._lock:
            return list(self._records.values())

    def delete(self, task_id: str) -> None:
        with self._lock:
            self._records.pop(task_id, None)

    def evict_expired(self, *, now_ts: float, ttl_sec: float) -> int:
        if ttl_sec <= 0:
            return 0
        terminal = {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED}
        with self._lock:
            to_delete = [
                task_id
                for task_id, record in self._records.items()
                if record.status in terminal and (now_ts - float(record.updated_at)) >= ttl_sec
            ]
            for task_id in to_delete:
                self._records.pop(task_id, None)
            return len(to_delete)

    def evict_over_capacity(self, *, max_records: int) -> int:
        if max_records < 0:
            return 0
        terminal = {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED}
        with self._lock:
            total = len(self._records)
            overflow = total - max_records
            if overflow <= 0:
                return 0

            terminal_items = [
                (task_id, record)
                for task_id, record in self._records.items()
                if record.status in terminal
            ]
            terminal_items.sort(key=lambda item: float(item[1].updated_at))
            to_delete = [task_id for task_id, _ in terminal_items[:overflow]]
            for task_id in to_delete:
                self._records.pop(task_id, None)
            return len(to_delete)
