"""
task_runtime/store/sqlite_store.py — Task Runtime SQLite 持久化存储

职责：
    提供 TaskStore 的最小持久化实现：
    1. create/get/update/list/delete 的持久化读写
    2. 任务终态去重字段与元数据的序列化

边界：
    - 仅实现 TaskStore，不处理队列与 loop 注入
    - 采用 sqlite3 标准库，便于本地与 CI 使用
"""

from __future__ import annotations

from dataclasses import asdict
import json
import sqlite3
from threading import RLock
from typing import Iterable, Optional

from ..core.interfaces import TaskStore
from ..core.types import TaskRecord, TaskScope, TaskStatus, TaskType


class SqliteTaskStore(TaskStore):
    def __init__(self, db_path: str) -> None:
        self._lock = RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        with self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS task_records (
                    task_id TEXT PRIMARY KEY,
                    task_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    description TEXT NOT NULL,
                    scope_agent_id TEXT,
                    input_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    output_file TEXT,
                    terminal_emitted_statuses_json TEXT NOT NULL,
                    notification_consumed INTEGER NOT NULL,
                    run_id TEXT,
                    external_ref TEXT,
                    lease_until_ts REAL,
                    last_heartbeat_ts REAL,
                    worker_id TEXT
                )
                """
            )
            self._migrate_task_columns()

    def _migrate_task_columns(self) -> None:
        cur = self._conn.execute("PRAGMA table_info(task_records)")
        cols = {row[1] for row in cur.fetchall()}
        alters = [
            ("run_id", "TEXT"),
            ("external_ref", "TEXT"),
            ("lease_until_ts", "REAL"),
            ("last_heartbeat_ts", "REAL"),
            ("worker_id", "TEXT"),
        ]
        for name, sql_type in alters:
            if name not in cols:
                self._conn.execute(
                    f"ALTER TABLE task_records ADD COLUMN {name} {sql_type}"
                )

    def create(self, record: TaskRecord) -> None:
        payload = _to_row(record)
        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO task_records (
                    task_id, task_type, status, description, scope_agent_id,
                    input_json, metadata_json, created_at, updated_at, output_file,
                    terminal_emitted_statuses_json, notification_consumed,
                    run_id, external_ref, lease_until_ts, last_heartbeat_ts, worker_id
                ) VALUES (
                    :task_id, :task_type, :status, :description, :scope_agent_id,
                    :input_json, :metadata_json, :created_at, :updated_at, :output_file,
                    :terminal_emitted_statuses_json, :notification_consumed,
                    :run_id, :external_ref, :lease_until_ts, :last_heartbeat_ts, :worker_id
                )
                """,
                payload,
            )

    def get(self, task_id: str) -> Optional[TaskRecord]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM task_records WHERE task_id = ?",
                (task_id,),
            ).fetchone()
        if row is None:
            return None
        return _from_row(row)

    def update(self, task_id: str, patch: dict) -> Optional[TaskRecord]:
        with self._lock:
            current = self.get(task_id)
            if current is None:
                return None
            data = asdict(current)
            data.update(patch)
            # dataclass->dict 后 enums 仍是对象，这里统一规范为 TaskRecord
            updated = TaskRecord(
                task_id=data["task_id"],
                task_type=_coerce_task_type(data["task_type"]),
                status=_coerce_task_status(data["status"]),
                description=data["description"],
                scope=data["scope"] if isinstance(data["scope"], TaskScope) else TaskScope(
                    agent_id=data["scope"].get("agent_id") if isinstance(data["scope"], dict) else None
                ),
                input=data.get("input") or {},
                metadata=data.get("metadata") or {},
                created_at=float(data["created_at"]),
                updated_at=float(data["updated_at"]),
                output_file=data.get("output_file"),
                terminal_emitted_statuses=set(
                    _coerce_task_status(s) for s in (data.get("terminal_emitted_statuses") or set())
                ),
                notification_consumed=bool(data.get("notification_consumed", False)),
                run_id=data.get("run_id"),
                external_ref=data.get("external_ref"),
                lease_until_ts=(
                    float(data["lease_until_ts"])
                    if data.get("lease_until_ts") is not None
                    else None
                ),
                last_heartbeat_ts=(
                    float(data["last_heartbeat_ts"])
                    if data.get("last_heartbeat_ts") is not None
                    else None
                ),
                worker_id=data.get("worker_id"),
            )
            self.create(updated)
            return updated

    def list(self) -> Iterable[TaskRecord]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM task_records").fetchall()
        return [_from_row(row) for row in rows]

    def delete(self, task_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM task_records WHERE task_id = ?", (task_id,))

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def evict_expired(self, *, now_ts: float, ttl_sec: float) -> int:
        if ttl_sec <= 0:
            return 0
        cutoff = float(now_ts) - float(ttl_sec)
        terminal_statuses = (
            TaskStatus.COMPLETED.value,
            TaskStatus.FAILED.value,
            TaskStatus.STOPPED.value,
        )
        with self._lock, self._conn:
            cur = self._conn.execute(
                """
                DELETE FROM task_records
                WHERE status IN (?, ?, ?) AND updated_at <= ?
                """,
                (*terminal_statuses, cutoff),
            )
            return int(cur.rowcount or 0)

    def evict_over_capacity(self, *, max_records: int) -> int:
        if max_records < 0:
            return 0
        terminal_statuses = (
            TaskStatus.COMPLETED.value,
            TaskStatus.FAILED.value,
            TaskStatus.STOPPED.value,
        )
        with self._lock, self._conn:
            total = int(
                self._conn.execute("SELECT COUNT(*) FROM task_records").fetchone()[0]
            )
            overflow = total - max_records
            if overflow <= 0:
                return 0
            rows = self._conn.execute(
                """
                SELECT task_id
                FROM task_records
                WHERE status IN (?, ?, ?)
                ORDER BY updated_at ASC
                LIMIT ?
                """,
                (*terminal_statuses, overflow),
            ).fetchall()
            ids = [row["task_id"] for row in rows]
            if not ids:
                return 0
            placeholders = ",".join("?" for _ in ids)
            cur = self._conn.execute(
                f"DELETE FROM task_records WHERE task_id IN ({placeholders})",
                ids,
            )
            return int(cur.rowcount or 0)


def _to_row(record: TaskRecord) -> dict:
    return {
        "task_id": record.task_id,
        "task_type": record.task_type.value,
        "status": record.status.value,
        "description": record.description,
        "scope_agent_id": record.scope.agent_id,
        "input_json": json.dumps(record.input, ensure_ascii=True),
        "metadata_json": json.dumps(record.metadata, ensure_ascii=True),
        "created_at": float(record.created_at),
        "updated_at": float(record.updated_at),
        "output_file": record.output_file,
        "terminal_emitted_statuses_json": json.dumps(
            [s.value for s in record.terminal_emitted_statuses], ensure_ascii=True
        ),
        "notification_consumed": 1 if record.notification_consumed else 0,
        "run_id": record.run_id,
        "external_ref": record.external_ref,
        "lease_until_ts": record.lease_until_ts,
        "last_heartbeat_ts": record.last_heartbeat_ts,
        "worker_id": record.worker_id,
    }


def _from_row(row: sqlite3.Row) -> TaskRecord:
    emitted_raw = json.loads(row["terminal_emitted_statuses_json"] or "[]")
    keys = row.keys()
    return TaskRecord(
        task_id=row["task_id"],
        task_type=TaskType(row["task_type"]),
        status=TaskStatus(row["status"]),
        description=row["description"],
        scope=TaskScope(agent_id=row["scope_agent_id"]),
        input=json.loads(row["input_json"] or "{}"),
        metadata=json.loads(row["metadata_json"] or "{}"),
        created_at=float(row["created_at"]),
        updated_at=float(row["updated_at"]),
        output_file=row["output_file"],
        terminal_emitted_statuses=set(TaskStatus(s) for s in emitted_raw),
        notification_consumed=bool(row["notification_consumed"]),
        run_id=row["run_id"] if "run_id" in keys else None,
        external_ref=row["external_ref"] if "external_ref" in keys else None,
        lease_until_ts=(
            float(row["lease_until_ts"])
            if "lease_until_ts" in keys and row["lease_until_ts"] is not None
            else None
        ),
        last_heartbeat_ts=(
            float(row["last_heartbeat_ts"])
            if "last_heartbeat_ts" in keys and row["last_heartbeat_ts"] is not None
            else None
        ),
        worker_id=row["worker_id"] if "worker_id" in keys else None,
    )


def _coerce_task_type(value) -> TaskType:
    if isinstance(value, TaskType):
        return value
    return TaskType(str(value))


def _coerce_task_status(value) -> TaskStatus:
    if isinstance(value, TaskStatus):
        return value
    return TaskStatus(str(value))
