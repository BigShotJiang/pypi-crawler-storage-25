"""
task_runtime/integrations/loop_adapter.py — Loop 集成适配层

职责：
    TaskRuntime 与 loop 图节点之间的边界层，负责：
    1. 从 runtime 读取可消费任务通知（按 scope / priority）
    2. 转换为 loop 可注入的 attachment message 结构
    3. 在 loop 消费后进行 ack，防止重复注入

边界说明：
    - 仅负责协议映射，不承担任务执行与状态机职责
    - 便于后续在 `post_tools/attachment_injection` 节点直接接线
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..core.interfaces import TaskRuntime
from ..core.types import QueuePriority, TaskNotificationEnvelope, TaskScope


@dataclass(frozen=True)
class LoopInjectionBatch:
    batch_id: str
    command_ids: list[str]
    attachment_messages: list[dict]


def _to_attachment_message(env: TaskNotificationEnvelope) -> dict:
    text = f"[task_notification] task_id={env.task_id} status={env.status.value} summary={env.summary}"
    return {
        "role": "user",
        "content": [{"type": "text", "text": text}],
        "metadata": {
            "task_notification": {
                "command_id": env.command_id,
                "task_id": env.task_id,
                "status": env.status.value,
                "priority": env.priority.value,
                "output_file": env.output_file,
                "terminal_reason": env.terminal_reason,
            }
        },
    }


class LoopTaskInjectionAdapter:
    """Convert queued task notifications into loop-consumable messages."""

    def __init__(self, runtime: TaskRuntime) -> None:
        self._runtime = runtime

    def build_batch(
        self,
        scope: TaskScope,
        max_priority: QueuePriority = QueuePriority.NEXT,
        *,
        limit: int = 8,
    ) -> LoopInjectionBatch:
        reserved = self._runtime.reserve_notifications(
            scope=scope,
            max_priority=max_priority,
            limit=limit,
        )
        if not reserved:
            return LoopInjectionBatch(batch_id="", command_ids=[], attachment_messages=[])
        return LoopInjectionBatch(
            batch_id=reserved.batch_id,
            command_ids=[item.command_id for item in reserved.items],
            attachment_messages=[_to_attachment_message(item) for item in reserved.items],
        )

    def ack_batch(self, batch: LoopInjectionBatch) -> None:
        if batch.batch_id:
            self._runtime.ack_reserved(batch.batch_id)

    def nack_batch(self, batch: LoopInjectionBatch, *, requeue: bool = True) -> None:
        if batch.batch_id:
            self._runtime.nack_reserved(batch.batch_id, requeue=requeue)

    def has_pending(
        self, scope: TaskScope, max_priority: QueuePriority = QueuePriority.NEXT
    ) -> bool:
        return self._runtime.has_pending_notifications(scope, max_priority)

    def ingest_from_messages(self, *, scope: TaskScope, messages: list[Any]) -> int:
        """TaskRuntime 无 messages 桥接；占位以满足 `QueuedCommandProvider` 契约。"""
        return 0

