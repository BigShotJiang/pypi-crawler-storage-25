"""
task_runtime/integrations/queued_command_provider.py — 通用 queued-command provider

职责：
    为 memory/skill prefetch 等“非 task_runtime 来源”提供统一的队列能力：
    1. enqueue：写入待注入命令
    2. build_batch：按 scope/priority reserve 批次
    3. ack_batch / nack_batch：两阶段确认
    4. has_pending：供 loop_controller 退出守卫探测

边界：
    - 仅负责 queued-command 的队列与批次确认
    - 不依赖 TaskRuntime，不参与任务生命周期状态机
"""
from __future__ import annotations

from typing import Any

from dataclasses import dataclass, field
from threading import RLock
from uuid import uuid4
import time

from ..core.types import QueuePriority, TaskScope
from .loop_adapter import LoopInjectionBatch


_PRIORITY_ORDER = {
    QueuePriority.NOW: 0,
    QueuePriority.NEXT: 1,
    QueuePriority.LATER: 2,
}


@dataclass(frozen=True)
class QueuedCommandEnvelope:
    command_id: str
    source: str
    summary: str
    scope: TaskScope
    priority: QueuePriority = QueuePriority.NEXT
    payload: dict = field(default_factory=dict)
    dedup_key: str | None = None
    created_at: float = field(default_factory=time.time)


class InMemoryQueuedCommandProvider:
    """最小可用 queued-command provider（内存版）。"""

    def __init__(
        self,
        *,
        max_queue_size: int | None = None,
        ttl_sec: float | None = None,
    ) -> None:
        self._lock = RLock()
        self._queue: list[QueuedCommandEnvelope] = []
        self._reserved_batches: dict[str, list[QueuedCommandEnvelope]] = {}
        self._max_queue_size = max_queue_size
        self._ttl_sec = ttl_sec

    def enqueue(self, env: QueuedCommandEnvelope) -> None:
        with self._lock:
            self._evict_expired_locked(now_ts=time.time())
            # 可选去重：同 scope + dedup_key 仅保留最新一条
            if env.dedup_key:
                self._queue = [
                    item
                    for item in self._queue
                    if not (
                        item.scope.agent_id == env.scope.agent_id
                        and item.dedup_key == env.dedup_key
                    )
                ]
            self._queue.append(env)
            self._evict_over_capacity_locked()

    def build_batch(
        self,
        scope: TaskScope,
        max_priority: QueuePriority = QueuePriority.NEXT,
        *,
        limit: int = 8,
    ) -> LoopInjectionBatch:
        if limit <= 0:
            return LoopInjectionBatch(batch_id="", command_ids=[], attachment_messages=[])
        threshold = _PRIORITY_ORDER[max_priority]
        with self._lock:
            self._evict_expired_locked(now_ts=time.time())
            candidates = [
                item
                for item in self._queue
                if item.scope.agent_id == scope.agent_id
                and _PRIORITY_ORDER[item.priority] <= threshold
            ]
            candidates.sort(key=lambda item: _PRIORITY_ORDER[item.priority])
            selected = candidates[:limit]
            if not selected:
                return LoopInjectionBatch(batch_id="", command_ids=[], attachment_messages=[])

            selected_ids = {item.command_id for item in selected}
            self._queue = [item for item in self._queue if item.command_id not in selected_ids]
            batch_id = f"qbatch_{uuid4().hex[:10]}"
            self._reserved_batches[batch_id] = selected
            return LoopInjectionBatch(
                batch_id=batch_id,
                command_ids=[item.command_id for item in selected],
                attachment_messages=[_to_attachment_message(item) for item in selected],
            )

    def ack_batch(self, batch: LoopInjectionBatch) -> None:
        if not batch.batch_id:
            return
        with self._lock:
            self._reserved_batches.pop(batch.batch_id, None)

    def nack_batch(self, batch: LoopInjectionBatch, *, requeue: bool = True) -> None:
        if not batch.batch_id:
            return
        with self._lock:
            reserved = self._reserved_batches.pop(batch.batch_id, None)
            if reserved and requeue:
                self._queue.extend(reserved)

    def has_pending(
        self, scope: TaskScope, max_priority: QueuePriority = QueuePriority.NEXT
    ) -> bool:
        threshold = _PRIORITY_ORDER[max_priority]
        with self._lock:
            self._evict_expired_locked(now_ts=time.time())
            return any(
                item.scope.agent_id == scope.agent_id
                and _PRIORITY_ORDER[item.priority] <= threshold
                for item in self._queue
            )

    def ingest_from_messages(self, *, scope: TaskScope, messages: list[Any]) -> int:
        """默认无 loop messages 桥接；子类或包装 provider 可覆盖。"""
        return 0

    def evict_expired(self, *, now_ts: float | None = None) -> int:
        with self._lock:
            return self._evict_expired_locked(now_ts=time.time() if now_ts is None else now_ts)

    def _evict_over_capacity_locked(self) -> None:
        if self._max_queue_size is None:
            return
        if self._max_queue_size < 0:
            return
        overflow = len(self._queue) - self._max_queue_size
        if overflow <= 0:
            return
        # 保留高优先级：按优先级+创建时间排序，淘汰最不重要且最老的记录
        self._queue.sort(
            key=lambda item: (_PRIORITY_ORDER[item.priority], item.created_at)
        )
        # 末尾是低优先级；从末尾逆向淘汰 overflow 个
        self._queue = self._queue[: self._max_queue_size]

    def _evict_expired_locked(self, *, now_ts: float) -> int:
        if self._ttl_sec is None or self._ttl_sec <= 0:
            return 0
        before = len(self._queue)
        self._queue = [
            item for item in self._queue if (now_ts - float(item.created_at)) < self._ttl_sec
        ]
        return before - len(self._queue)


def _to_attachment_message(env: QueuedCommandEnvelope) -> dict:
    text = f"[queued_command][{env.source}] {env.summary}"
    return {
        "role": "user",
        "content": [{"type": "text", "text": text}],
        "metadata": {
            "queued_command": {
                "command_id": env.command_id,
                "source": env.source,
                "priority": env.priority.value,
                "payload": env.payload,
            }
        },
    }

