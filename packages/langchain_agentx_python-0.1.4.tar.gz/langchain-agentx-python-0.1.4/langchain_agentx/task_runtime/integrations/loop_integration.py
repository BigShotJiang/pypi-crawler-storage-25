"""
task_runtime/integrations/loop_integration.py — Agent Loop 与 task_runtime 的契约面

职责：
    1. **QueuedCommandProvider**：`create_loop_agent` 中 `task_event_commit_ack` /
       `task_event_reserve` 节点消费的统一协议（与 `LoopTaskInjectionAdapter` 同形）。
    2. **批次 id 编解码**：多 provider 链下 `pending_task_batch_id` 使用 `p{index}:{batch_id}`，
       与 loop 图实现一致，供单测与外部工具复用。

边界：
    - 不包含 LangGraph 节点实现（见 `loop/graph/factory.py`）
    - `TaskRuntime` 本体协议见 `task_runtime.core.interfaces.TaskRuntime`
"""

from __future__ import annotations

from typing import Any, Protocol

from ..core.types import QueuePriority, TaskScope
from .loop_adapter import LoopInjectionBatch


class QueuedCommandProvider(Protocol):
    """供 Agent Loop `task_event_*` 链调用的 queued-command 来源（task / prefetch / summary 等）。"""

    def build_batch(
        self,
        scope: TaskScope,
        max_priority: QueuePriority = QueuePriority.NEXT,
        *,
        limit: int = 8,
    ) -> LoopInjectionBatch: ...

    def ack_batch(self, batch: LoopInjectionBatch) -> None: ...

    def nack_batch(self, batch: LoopInjectionBatch, *, requeue: bool = True) -> None: ...

    def has_pending(
        self, scope: TaskScope, max_priority: QueuePriority = QueuePriority.NEXT
    ) -> bool: ...

    def ingest_from_messages(self, *, scope: TaskScope, messages: list[Any]) -> int:
        """reserve 前由 loop 调用；将当前轮 `messages` 桥接到队列（无则返回 0）。"""


def encode_provider_batch_id(provider_index: int, batch_id: str) -> str:
    """与 `create_loop_agent` 中 `pending_task_batch_id` 编码一致。"""
    return f"p{provider_index}:{batch_id}"


def decode_provider_batch_id(encoded: str) -> tuple[int, str] | None:
    """解码 `encode_provider_batch_id`；非法输入返回 None。"""
    if not isinstance(encoded, str) or ":" not in encoded:
        return None
    prefix, raw_batch_id = encoded.split(":", 1)
    if not prefix.startswith("p"):
        return None
    try:
        return int(prefix[1:]), raw_batch_id
    except ValueError:
        return None
