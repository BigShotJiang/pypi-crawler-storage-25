"""
task_runtime/integrations/prefetch_providers.py — 预取类 queued-command provider

职责：
    基于通用 InMemoryQueuedCommandProvider 封装 memory 预取来源：
    1. MemoryPrefetchProvider：注入 memory 预取结果

边界：
    - 仅负责“把外部结果转为 queued command”
    - 不承担 loop 路由与 task 生命周期管理
"""
from __future__ import annotations

from typing import Any

from ..core.types import QueuePriority, TaskScope
from .loop_adapter import LoopInjectionBatch
from .queued_command_provider import InMemoryQueuedCommandProvider, QueuedCommandEnvelope


class MemoryPrefetchProvider:
    """将 memory 预取结果转换为 queued commands。"""

    def __init__(
        self,
        backend: InMemoryQueuedCommandProvider | None = None,
        *,
        max_queue_size: int | None = None,
        ttl_sec: float | None = None,
    ) -> None:
        self._backend = backend or InMemoryQueuedCommandProvider(
            max_queue_size=max_queue_size,
            ttl_sec=ttl_sec,
        )

    def ingest_memory_items(
        self,
        *,
        scope: TaskScope,
        items: list[dict[str, Any]],
        priority: QueuePriority = QueuePriority.NEXT,
    ) -> int:
        count = 0
        for item in items:
            memory_id = str(item.get("memory_id") or f"mem_{count}")
            summary = str(item.get("summary") or "").strip() or "memory prefetch result"
            self._backend.enqueue(
                QueuedCommandEnvelope(
                    command_id=f"mem_{memory_id}",
                    source="memory_prefetch",
                    summary=summary,
                    scope=scope,
                    priority=priority,
                    payload=item,
                    dedup_key=f"memory:{memory_id}",
                )
            )
            count += 1
        return count

    def ingest_from_context_messages(
        self,
        *,
        scope: TaskScope,
        messages: list,
        priority: QueuePriority = QueuePriority.NEXT,
        limit: int = 8,
    ) -> int:
        """从 loop/context 消息中提取可预取记忆（real-source bridge）。"""
        items: list[dict[str, Any]] = []
        for msg in messages[-limit:]:
            content = getattr(msg, "content", None)
            if isinstance(content, str) and content.strip():
                items.append(
                    {
                        "memory_id": f"msg_{len(items)}",
                        "summary": content.strip()[:120],
                        "source": "context_message",
                    }
                )
        return self.ingest_memory_items(scope=scope, items=items, priority=priority)

    def build_batch(
        self,
        scope: TaskScope,
        max_priority: QueuePriority = QueuePriority.NEXT,
        *,
        limit: int = 8,
    ) -> LoopInjectionBatch:
        return self._backend.build_batch(scope, max_priority=max_priority, limit=limit)

    def ack_batch(self, batch: LoopInjectionBatch) -> None:
        self._backend.ack_batch(batch)

    def nack_batch(self, batch: LoopInjectionBatch, *, requeue: bool = True) -> None:
        self._backend.nack_batch(batch, requeue=requeue)

    def has_pending(
        self, scope: TaskScope, max_priority: QueuePriority = QueuePriority.NEXT
    ) -> bool:
        return self._backend.has_pending(scope, max_priority=max_priority)

    def ingest_from_messages(
        self, *, scope: TaskScope, messages: list
    ) -> int:
        return self.ingest_from_context_messages(scope=scope, messages=messages)


