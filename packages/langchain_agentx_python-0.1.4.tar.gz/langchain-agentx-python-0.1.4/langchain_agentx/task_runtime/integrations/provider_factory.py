"""
task_runtime/integrations/provider_factory.py — queued provider 统一配置入口

职责：
    为 task 侧提供一个统一的 provider 装配工厂，减少调用方手工拼装成本。
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from langchain_agentx.workspace import resolve_agent_workspace_config

from .prefetch_providers import MemoryPrefetchProvider
from ..skill_prefetch import SkillPrefetchProvider
from .queued_command_provider import InMemoryQueuedCommandProvider
from .sqlite_queued_command_provider import SqliteQueuedCommandProvider
from .tool_use_summary_provider import ToolUseSummaryProvider


BackendType = Literal["in_memory", "sqlite"]


@dataclass(frozen=True)
class ProviderFactoryConfig:
    backend_type: BackendType = "in_memory"
    sqlite_db_path: str | None = None
    workspace_root: str | None = None
    agent_home: str = ".langchain_agentx"
    max_queue_size: int | None = None
    ttl_sec: float | None = None
    enable_memory_prefetch: bool = True
    enable_skill_prefetch: bool = True
    enable_tool_summary: bool = True
    summary_error_ratio_now_threshold: float = 0.5
    summary_avg_latency_now_threshold_ms: int = 2000


@dataclass(frozen=True)
class ProviderBundle:
    memory_prefetch: MemoryPrefetchProvider | None
    skill_prefetch: SkillPrefetchProvider | None
    tool_summary: ToolUseSummaryProvider | None

    def as_list(self) -> list:
        return [item for item in [self.memory_prefetch, self.skill_prefetch, self.tool_summary] if item is not None]


def build_provider_bundle(config: ProviderFactoryConfig) -> ProviderBundle:
    workspace_cfg = resolve_agent_workspace_config(
        workspace_root=config.workspace_root or Path.cwd(),
        agent_home=config.agent_home,
    )
    backend = _build_backend(config)
    memory_prefetch = (
        MemoryPrefetchProvider(backend=backend)
        if config.enable_memory_prefetch
        else None
    )
    skill_prefetch = (
        SkillPrefetchProvider(
            workspace_root=workspace_cfg.workspace_root,
            agent_home=workspace_cfg.agent_home,
        )
        if config.enable_skill_prefetch
        else None
    )
    tool_summary = (
        ToolUseSummaryProvider(
            backend=backend,
            error_ratio_now_threshold=config.summary_error_ratio_now_threshold,
            avg_latency_now_threshold_ms=config.summary_avg_latency_now_threshold_ms,
        )
        if config.enable_tool_summary
        else None
    )
    return ProviderBundle(
        memory_prefetch=memory_prefetch,
        skill_prefetch=skill_prefetch,
        tool_summary=tool_summary,
    )


def _build_backend(config: ProviderFactoryConfig):
    if config.backend_type == "sqlite":
        workspace_cfg = resolve_agent_workspace_config(
            workspace_root=config.workspace_root or Path.cwd(),
            agent_home=config.agent_home,
        )
        db_path = config.sqlite_db_path or str(workspace_cfg.task_runtime_db_path)
        Path(db_path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
        return SqliteQueuedCommandProvider(
            db_path,
            max_queue_size=config.max_queue_size,
            ttl_sec=config.ttl_sec,
            recover_reserved_on_startup=True,
        )
    return InMemoryQueuedCommandProvider(
        max_queue_size=config.max_queue_size,
        ttl_sec=config.ttl_sec,
    )

