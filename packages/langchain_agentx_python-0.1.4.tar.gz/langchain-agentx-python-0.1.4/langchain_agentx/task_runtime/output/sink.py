"""
task_runtime/output/sink.py — 任务持续输出（§10.4 TaskOutputSink）

职责：
    提供与终态 notification 正交的 **append-only 输出缓冲**，支持按 task_id 追加与
    按字节 offset 续读，供排障与（未来）CLI 回放。

与 CC 对比：
    CC 将任务 stdout 等落盘到 workspace 路径；本仓库先提供进程内 **InMemory** 实现，
    上限策略与 ``never_truncate`` 类语义对齐为「超上限丢弃头部、保留尾部」。

边界：
    - 不负责持久化跨进程；跨重启持久化由调用方换用基于文件/SQLite 的 Sink 实现（未来）。
"""

from __future__ import annotations

from threading import RLock
from typing import Optional, Protocol, runtime_checkable


@runtime_checkable
class TaskOutputSink(Protocol):
    """Append-only task output; ``offset`` in :meth:`read_from` is **byte** offset."""

    def append(self, task_id: str, chunk: str) -> None: ...

    def read_from(self, task_id: str, offset: int = 0) -> tuple[str, int]:
        """Return ``(decoded_text_slice, next_byte_offset)`` for the full buffer length."""
        ...


class InMemoryTaskOutputSink:
    """进程内输出缓冲：UTF-8 字节存储；超上限时丢弃最旧字节（保留尾部）。"""

    def __init__(self, *, max_bytes_per_task: Optional[int] = 1_048_576) -> None:
        self._max_bytes_per_task = max_bytes_per_task
        self._lock = RLock()
        self._buffers: dict[str, bytearray] = {}

    def append(self, task_id: str, chunk: str) -> None:
        if not chunk:
            return
        raw = chunk.encode("utf-8")
        with self._lock:
            buf = self._buffers.setdefault(task_id, bytearray())
            buf.extend(raw)
            max_b = self._max_bytes_per_task
            if max_b is not None and len(buf) > max_b:
                del buf[: len(buf) - max_b]

    def read_from(self, task_id: str, offset: int = 0) -> tuple[str, int]:
        with self._lock:
            buf = self._buffers.get(task_id)
            if not buf:
                return "", 0
            data = bytes(buf)
            total = len(data)
            if offset < 0:
                offset = 0
            if offset >= total:
                return "", total
            tail = data[offset:]
            return tail.decode("utf-8", errors="replace"), total
