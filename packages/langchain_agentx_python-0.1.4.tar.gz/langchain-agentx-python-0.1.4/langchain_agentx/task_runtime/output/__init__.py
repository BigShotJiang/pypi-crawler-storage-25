"""Task output buffering (§10.4)."""

from .sink import InMemoryTaskOutputSink, TaskOutputSink

__all__ = ["InMemoryTaskOutputSink", "TaskOutputSink"]
