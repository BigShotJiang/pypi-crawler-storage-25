"""
task_runtime/core/interfaces.py — Task Runtime 抽象接口层（Protocol）

职责：
    作为任务模块的稳定边界，定义可替换的抽象接口：
    1. TaskStore：任务记录存取与更新
    2. TaskCommandQueue：任务通知排队、按 scope/priority 读取、确认移除
    3. TaskRuntime：任务生命周期编排与通知消费协议

设计意图：
    - 让 loop 改造与 task 模块开发可并行推进
    - 让 in-memory / 持久化 / 分布式实现可以无缝替换

与 Agent Loop 的接线：
    - 图节点消费的「多来源队列」协议见 ``task_runtime.integrations.loop_integration.QueuedCommandProvider``
    - ``TaskRuntime`` 经 ``LoopTaskInjectionAdapter`` 适配为该协议
"""

from __future__ import annotations

from typing import Iterable, Optional, Protocol

from .types import (
    QueuePriority,
    ReservedNotificationBatch,
    TaskExecutionResult,
    TaskRuntimeEvent,
    TaskNotificationEnvelope,
    TaskRecord,
    TaskScope,
    TaskSpec,
    TaskStatus,
    TaskType,
)


class TaskStore(Protocol):
    def create(self, record: TaskRecord) -> None: ...
    def get(self, task_id: str) -> Optional[TaskRecord]: ...
    def update(self, task_id: str, patch: dict) -> Optional[TaskRecord]: ...
    def list(self) -> Iterable[TaskRecord]: ...
    def delete(self, task_id: str) -> None: ...
    def evict_expired(self, *, now_ts: float, ttl_sec: float) -> int: ...
    def evict_over_capacity(self, *, max_records: int) -> int: ...


class TaskCommandQueue(Protocol):
    def enqueue(self, env: TaskNotificationEnvelope) -> None: ...
    def peek_for_scope(
        self, scope: TaskScope, max_priority: QueuePriority
    ) -> list[TaskNotificationEnvelope]: ...
    def remove(self, command_ids: list[str]) -> None: ...


class TaskRuntime(Protocol):
    def spawn(self, spec: TaskSpec) -> str: ...
    def cancel(self, task_id: str, reason: Optional[str] = None) -> None: ...
    def mark_terminal(
        self,
        task_id: str,
        status: TaskStatus,
        summary: str,
        *,
        output_file: Optional[str] = None,
        tool_use_id: Optional[str] = None,
        usage: Optional[dict[str, int]] = None,
        requires_action: bool = False,
        terminal_reason: Optional[str] = None,
    ) -> bool: ...
    def drain_notifications(
        self, scope: TaskScope, max_priority: QueuePriority
    ) -> list[TaskNotificationEnvelope]: ...
    def ack_notifications(self, command_ids: list[str]) -> None: ...
    def reserve_notifications(
        self,
        scope: TaskScope,
        max_priority: QueuePriority,
        *,
        limit: int = 8,
    ) -> Optional[ReservedNotificationBatch]: ...
    def ack_reserved(self, batch_id: str) -> None: ...
    def nack_reserved(self, batch_id: str, *, requeue: bool = True) -> None: ...
    def has_pending_notifications(
        self, scope: TaskScope, max_priority: QueuePriority
    ) -> bool: ...
    def register_executor(
        self, task_type: TaskType, executor: "TaskExecutor", *, overwrite: bool = False
    ) -> None: ...
    def run_task(self, task_id: str) -> bool: ...
    def publish_progress(self, task_id: str, summary: str) -> bool: ...
    def drain_events(self) -> list[TaskRuntimeEvent]: ...
    # §10.2 前台等待（协议层轮询，不阻塞 LangGraph 主线程）
    def wait_for_terminal(
        self,
        task_id: str,
        *,
        timeout_sec: Optional[float] = None,
        poll_interval_sec: float = 0.02,
    ) -> Optional[TaskStatus]: ...
    # §10.4 持续输出（可选 sink）
    def append_task_output(self, task_id: str, chunk: str) -> bool: ...
    def read_task_output(self, task_id: str, offset: int = 0) -> tuple[str, int]: ...
    # §10.3 租约与心跳
    def heartbeat(
        self,
        task_id: str,
        *,
        worker_id: Optional[str] = None,
        extend_sec: Optional[float] = None,
    ) -> bool: ...
    def reclaim_stale_running_tasks(self, *, now_ts: Optional[float] = None) -> list[str]: ...


class TaskExecutor(Protocol):
    def execute(self, record: TaskRecord) -> TaskExecutionResult: ...
