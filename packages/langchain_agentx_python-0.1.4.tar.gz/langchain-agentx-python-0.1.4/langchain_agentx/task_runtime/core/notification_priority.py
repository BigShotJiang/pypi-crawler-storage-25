"""
task_runtime/core/notification_priority.py — 终态 → 队列优先级映射（R2）

职责：
    将 ``TaskStatus`` 映射到 ``QueuePriority``，供编排层在 ``mark_terminal`` 时
    入队通知；与 orchestrator 中历史 ``_priority_for_status`` 行为一致。
"""

from __future__ import annotations

from .types import QueuePriority, TaskStatus


def notification_priority_for_terminal_status(status: TaskStatus) -> QueuePriority:
    if status == TaskStatus.FAILED:
        return QueuePriority.NOW
    if status == TaskStatus.COMPLETED:
        return QueuePriority.NEXT
    return QueuePriority.LATER
