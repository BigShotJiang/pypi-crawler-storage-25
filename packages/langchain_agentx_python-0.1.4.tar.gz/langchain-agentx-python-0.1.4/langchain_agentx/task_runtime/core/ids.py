"""
task_runtime/core/ids.py — 任务与通知条目 ID 生成（R2 共享逻辑）

职责：
    从 orchestrator 中抽出无状态的 ID 生成，避免编排层与领域类型混杂，
    便于单测与将来替换为 ULID/Snowflake 等策略。

边界：
    仅本包使用；不保证跨进程全局唯一（与 CC 本地 task id 策略一致）。
"""

from __future__ import annotations

from uuid import uuid4


def new_task_id() -> str:
    return f"task_{uuid4().hex[:10]}"


def new_notification_command_id() -> str:
    """``TaskNotificationEnvelope.command_id`` 用短 ID。"""
    return f"cmd_{uuid4().hex[:10]}"


def new_run_id() -> str:
    """§10.3 持久化任务 run 标识。"""
    return f"run_{uuid4().hex[:12]}"


def new_reserved_batch_id() -> str:
    """``ReservedNotificationBatch.batch_id``。"""
    return f"batch_{uuid4().hex[:10]}"
