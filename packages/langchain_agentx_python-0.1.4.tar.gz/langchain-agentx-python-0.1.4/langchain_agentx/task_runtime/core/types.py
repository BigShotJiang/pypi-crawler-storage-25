"""
task_runtime/core/types.py — Task Runtime 领域类型定义

职责：
    定义任务调度领域的统一类型，作为 loop / tools / integrations 共享契约：
    1. 任务基础语义（TaskType / TaskStatus）
    2. 队列调度语义（QueuePriority）
    3. 作用域语义（TaskScope，用于 agent_id 隔离）
    4. 输入与持久化记录语义（TaskSpec / TaskRecord）
    5. 通知协议语义（TaskNotificationEnvelope）

边界约束：
    - 本文件不依赖 LangGraph、ToolNode 或具体工具实现
    - 保持“纯领域类型”，便于并行开发与后续接入
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional
import time


class TaskType(str, Enum):
    LOCAL_AGENT = "local_agent"
    LOCAL_BASH = "local_bash"
    DREAM_TASK = "dream_task"
    REMOTE_AGENT = "remote_agent"
    IN_PROCESS_TEAMMATE = "in_process_teammate"
    CUSTOM = "custom"


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


class QueuePriority(str, Enum):
    NOW = "now"
    NEXT = "next"
    LATER = "later"


class TaskRuntimeEventType(str, Enum):
    STARTED = "started"
    PROGRESS = "progress"
    TERMINAL = "terminal"


@dataclass(frozen=True)
class TaskScope:
    """Task scope for queue drain isolation.

    agent_id=None means main-thread scope.
    """

    agent_id: Optional[str] = None


@dataclass
class TaskSpec:
    task_type: TaskType
    description: str
    input: dict[str, Any]
    scope: TaskScope
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskRecord:
    task_id: str
    task_type: TaskType
    status: TaskStatus
    description: str
    scope: TaskScope
    input: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    output_file: Optional[str] = None
    terminal_emitted_statuses: set[TaskStatus] = field(default_factory=set)
    notification_consumed: bool = False
    # §10.3 运行中恢复：spawn/run 写入，heartbeat 续租，reclaim 回收
    run_id: Optional[str] = None
    external_ref: Optional[str] = None
    lease_until_ts: Optional[float] = None
    last_heartbeat_ts: Optional[float] = None
    worker_id: Optional[str] = None


@dataclass(frozen=True)
class TaskNotificationEnvelope:
    command_id: str
    task_id: str
    task_type: TaskType
    status: TaskStatus
    summary: str
    scope: TaskScope
    priority: QueuePriority = QueuePriority.LATER
    output_file: Optional[str] = None
    tool_use_id: Optional[str] = None
    usage: Optional[dict[str, int]] = None
    requires_action: bool = False
    terminal_reason: Optional[str] = None


@dataclass(frozen=True)
class ReservedNotificationBatch:
    batch_id: str
    scope: TaskScope
    items: list[TaskNotificationEnvelope]


@dataclass(frozen=True)
class TaskExecutionResult:
    status: TaskStatus
    summary: str
    output_file: Optional[str] = None
    tool_use_id: Optional[str] = None
    usage: Optional[dict[str, int]] = None


@dataclass(frozen=True)
class TaskRuntimeEvent:
    event_type: TaskRuntimeEventType
    task_id: str
    task_type: TaskType
    status: TaskStatus
    summary: str
    scope: TaskScope
    terminal_reason: Optional[str] = None
    created_at: float = field(default_factory=time.time)
