"""Core domain types and protocols for task_runtime."""

from .ids import (
    new_notification_command_id,
    new_reserved_batch_id,
    new_run_id,
    new_task_id,
)
from .interfaces import (
    TaskCommandQueue,
    TaskExecutor,
    TaskRuntime,
    TaskStore,
)
from .notification_priority import notification_priority_for_terminal_status
from .types import (
    QueuePriority,
    ReservedNotificationBatch,
    TaskExecutionResult,
    TaskNotificationEnvelope,
    TaskRecord,
    TaskRuntimeEvent,
    TaskRuntimeEventType,
    TaskScope,
    TaskSpec,
    TaskStatus,
    TaskType,
)

__all__ = [
    "new_notification_command_id",
    "new_reserved_batch_id",
    "new_run_id",
    "new_task_id",
    "notification_priority_for_terminal_status",
    "QueuePriority",
    "ReservedNotificationBatch",
    "TaskCommandQueue",
    "TaskExecutionResult",
    "TaskExecutor",
    "TaskNotificationEnvelope",
    "TaskRecord",
    "TaskRuntime",
    "TaskRuntimeEvent",
    "TaskRuntimeEventType",
    "TaskScope",
    "TaskSpec",
    "TaskStatus",
    "TaskStore",
    "TaskType",
]
