"""
task_runtime/orchestrator/runtime.py — Task Runtime 默认编排实现

职责：
    聚合 TaskStore 与 TaskCommandQueue，提供统一任务生命周期编排：
    1. spawn：创建并注册运行中任务
    2. cancel：将任务转换为终止态（§10.2 抢占 → STOPPED）
    3. mark_terminal：落终态并发布 task-notification
    4. drain/ack：按 scope 与 priority 读取和确认通知
    5. 可选：wait_for_terminal / TaskOutputSink / 租约 heartbeat（§10.2–§10.4）

与 CC 对齐点：
    - 终态通知按 (task_id, status) 做幂等去重
    - 通知优先级采用 now > next > later
"""

from __future__ import annotations

from dataclasses import replace
from threading import RLock
from typing import Optional, TYPE_CHECKING
import time
import logging

from ..core.ids import (
    new_notification_command_id,
    new_reserved_batch_id,
    new_run_id,
    new_task_id,
)
from ..core.interfaces import TaskCommandQueue, TaskExecutor, TaskRuntime, TaskStore
from ..core.notification_priority import notification_priority_for_terminal_status
from ...observability.logging import ObservabilityLoggerAdapter, build_log_context

if TYPE_CHECKING:
    from ..output.sink import TaskOutputSink
from ..core.types import (
    QueuePriority,
    ReservedNotificationBatch,
    TaskExecutionResult,
    TaskNotificationEnvelope,
    TaskRecord,
    TaskRuntimeEvent,
    TaskRuntimeEventType,
    TaskScope,
    TaskSpec,
    TaskStatus,
    TaskType,
)

_TERMINAL_STATUSES = {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED}
logger = logging.getLogger(__name__)


class DefaultTaskRuntime(TaskRuntime):
    def __init__(
        self,
        store: TaskStore,
        queue: TaskCommandQueue,
        *,
        output_sink: Optional["TaskOutputSink"] = None,
        lease_ttl_sec: Optional[float] = 300.0,
    ) -> None:
        self._store = store
        self._queue = queue
        self._output_sink = output_sink
        self._lease_ttl_sec = lease_ttl_sec
        self._lock = RLock()
        self._reserved_batches: dict[str, ReservedNotificationBatch] = {}
        self._executors: dict[TaskType, TaskExecutor] = {}
        self._events: list[TaskRuntimeEvent] = []

    def _emit_event(
        self,
        event_type: TaskRuntimeEventType,
        record: TaskRecord,
        summary: str,
        *,
        status: TaskStatus | None = None,
        terminal_reason: str | None = None,
    ) -> None:
        with self._lock:
            self._events.append(
                TaskRuntimeEvent(
                    event_type=event_type,
                    task_id=record.task_id,
                    task_type=record.task_type,
                    status=status or record.status,
                    summary=summary,
                    scope=record.scope,
                    terminal_reason=terminal_reason,
                )
            )

    def spawn(self, spec: TaskSpec) -> str:
        task_id = new_task_id()
        meta = spec.metadata or {}
        ext = meta.get("external_ref")
        external_ref = ext if isinstance(ext, str) else None
        record = TaskRecord(
            task_id=task_id,
            task_type=spec.task_type,
            status=TaskStatus.PENDING,
            description=spec.description,
            scope=spec.scope,
            input=spec.input,
            metadata=spec.metadata,
            run_id=new_run_id(),
            external_ref=external_ref,
        )
        self._store.create(record)
        ObservabilityLoggerAdapter(
            logger,
            build_log_context(
                run_id=record.run_id,
                session_id=record.scope.agent_id,
                task_id=task_id,
            ).as_extra(),
        ).info("task spawned type=%s", record.task_type.value)
        return task_id

    def register_executor(
        self, task_type: TaskType, executor: TaskExecutor, *, overwrite: bool = False
    ) -> None:
        if (task_type in self._executors) and not overwrite:
            raise ValueError(f"Executor already registered for task type: {task_type.value}")
        self._executors[task_type] = executor

    def run_task(self, task_id: str) -> bool:
        record = self._store.get(task_id)
        if record is None:
            return False
        task_log = ObservabilityLoggerAdapter(
            logger,
            build_log_context(
                run_id=record.run_id,
                session_id=record.scope.agent_id,
                task_id=record.task_id,
            ).as_extra(),
        )
        executor = self._executors.get(record.task_type)
        if executor is None:
            raise ValueError(f"No executor registered for task type: {record.task_type.value}")

        now = time.time()
        run_patch: dict = {
            "status": TaskStatus.RUNNING,
            "updated_at": now,
        }
        if self._lease_ttl_sec is not None:
            run_patch["lease_until_ts"] = now + float(self._lease_ttl_sec)
            run_patch["last_heartbeat_ts"] = now
        self._store.update(task_id, run_patch)
        running_record = self._store.get(task_id)
        if running_record is None:
            return False
        self._emit_event(TaskRuntimeEventType.STARTED, running_record, "Task execution started")
        task_log.info("task execution started")
        try:
            result: TaskExecutionResult = executor.execute(running_record)
        except Exception as exc:
            task_log.error("task execution failed: %s", exc)
            return self.mark_terminal(
                task_id,
                TaskStatus.FAILED,
                f"Executor failed: {exc}",
            )

        if result.status not in _TERMINAL_STATUSES:
            raise ValueError(f"Executor must return terminal status, got {result.status}")
        return self.mark_terminal(
            task_id,
            result.status,
            result.summary,
            output_file=result.output_file,
            tool_use_id=result.tool_use_id,
            usage=result.usage,
        )

    def cancel(self, task_id: str, reason: Optional[str] = None) -> None:
        summary = reason or "Task cancelled"
        self.mark_terminal(
            task_id,
            TaskStatus.STOPPED,
            summary,
            terminal_reason="cancelled",
        )

    def publish_progress(self, task_id: str, summary: str) -> bool:
        record = self._store.get(task_id)
        if record is None:
            return False
        self._emit_event(TaskRuntimeEventType.PROGRESS, record, summary)
        return True

    def drain_events(self) -> list[TaskRuntimeEvent]:
        with self._lock:
            events = list(self._events)
            self._events.clear()
        return events

    def wait_for_terminal(
        self,
        task_id: str,
        *,
        timeout_sec: Optional[float] = None,
        poll_interval_sec: float = 0.02,
    ) -> Optional[TaskStatus]:
        deadline = None if timeout_sec is None else time.monotonic() + float(timeout_sec)
        poll_interval_sec = max(poll_interval_sec, 0.001)
        while True:
            record = self._store.get(task_id)
            if record is None:
                return None
            if record.status in _TERMINAL_STATUSES:
                return record.status
            if deadline is not None and time.monotonic() >= deadline:
                return None
            time.sleep(poll_interval_sec)

    def append_task_output(self, task_id: str, chunk: str) -> bool:
        if self._output_sink is None:
            return False
        self._output_sink.append(task_id, chunk)
        return True

    def read_task_output(self, task_id: str, offset: int = 0) -> tuple[str, int]:
        if self._output_sink is None:
            return "", 0
        return self._output_sink.read_from(task_id, offset)

    def heartbeat(
        self,
        task_id: str,
        *,
        worker_id: Optional[str] = None,
        extend_sec: Optional[float] = None,
    ) -> bool:
        record = self._store.get(task_id)
        if record is None or record.status != TaskStatus.RUNNING:
            return False
        now = time.time()
        base = self._lease_ttl_sec if self._lease_ttl_sec is not None else 300.0
        ext = float(extend_sec) if extend_sec is not None else float(base)
        patch: dict = {
            "last_heartbeat_ts": now,
            "lease_until_ts": now + ext,
            "updated_at": now,
        }
        if worker_id is not None:
            patch["worker_id"] = worker_id
        self._store.update(task_id, patch)
        return True

    def reclaim_stale_running_tasks(self, *, now_ts: Optional[float] = None) -> list[str]:
        now = time.time() if now_ts is None else float(now_ts)
        reclaimed: list[str] = []
        for record in self._store.list():
            if record.status != TaskStatus.RUNNING:
                continue
            if record.lease_until_ts is None:
                continue
            if record.lease_until_ts >= now:
                continue
            tid = record.task_id
            if self.mark_terminal(
                tid,
                TaskStatus.FAILED,
                "Lease expired (worker heartbeat lost or process crash)",
                terminal_reason="lease_expired",
            ):
                reclaimed.append(tid)
        return reclaimed

    def mark_terminal(
        self,
        task_id: str,
        status: TaskStatus,
        summary: str,
        *,
        output_file: Optional[str] = None,
        tool_use_id: Optional[str] = None,
        usage: Optional[dict[str, int]] = None,
        requires_action: bool = False,
        terminal_reason: Optional[str] = None,
    ) -> bool:
        if status not in _TERMINAL_STATUSES:
            raise ValueError(f"status must be terminal, got {status}")
        record = self._store.get(task_id)
        if record is None:
            return False
        if status in record.terminal_emitted_statuses:
            return False

        now = time.time()
        next_emitted = set(record.terminal_emitted_statuses)
        next_emitted.add(status)
        updated = replace(
            record,
            status=status,
            output_file=output_file or record.output_file,
            terminal_emitted_statuses=next_emitted,
            updated_at=now,
        )
        self._store.update(task_id, updated.__dict__)

        self._queue.enqueue(
            TaskNotificationEnvelope(
                command_id=new_notification_command_id(),
                task_id=task_id,
                task_type=updated.task_type,
                status=status,
                summary=summary,
                scope=updated.scope,
                priority=notification_priority_for_terminal_status(status),
                output_file=updated.output_file,
                tool_use_id=tool_use_id,
                usage=usage,
                requires_action=requires_action,
                terminal_reason=terminal_reason,
            )
        )
        self._emit_event(
            TaskRuntimeEventType.TERMINAL,
            updated,
            summary,
            status=status,
            terminal_reason=terminal_reason,
        )
        ObservabilityLoggerAdapter(
            logger,
            build_log_context(
                run_id=updated.run_id,
                session_id=updated.scope.agent_id,
                task_id=updated.task_id,
            ).as_extra(),
        ).info("task terminal status=%s summary=%s", status.value, summary)
        return True

    def drain_notifications(
        self, scope: TaskScope, max_priority: QueuePriority
    ) -> list[TaskNotificationEnvelope]:
        return self._queue.peek_for_scope(scope, max_priority)

    def ack_notifications(self, command_ids: list[str]) -> None:
        self._queue.remove(command_ids)

    def reserve_notifications(
        self,
        scope: TaskScope,
        max_priority: QueuePriority,
        *,
        limit: int = 8,
    ) -> Optional[ReservedNotificationBatch]:
        if limit <= 0:
            return None
        items = self._queue.peek_for_scope(scope, max_priority)[:limit]
        if not items:
            return None
        self._queue.remove([item.command_id for item in items])
        batch = ReservedNotificationBatch(
            batch_id=new_reserved_batch_id(),
            scope=scope,
            items=items,
        )
        with self._lock:
            self._reserved_batches[batch.batch_id] = batch
        return batch

    def ack_reserved(self, batch_id: str) -> None:
        with self._lock:
            self._reserved_batches.pop(batch_id, None)

    def nack_reserved(self, batch_id: str, *, requeue: bool = True) -> None:
        with self._lock:
            batch = self._reserved_batches.pop(batch_id, None)
        if batch is None:
            return
        if requeue:
            for item in batch.items:
                self._queue.enqueue(item)

    def has_pending_notifications(
        self, scope: TaskScope, max_priority: QueuePriority
    ) -> bool:
        return bool(self._queue.peek_for_scope(scope, max_priority))
