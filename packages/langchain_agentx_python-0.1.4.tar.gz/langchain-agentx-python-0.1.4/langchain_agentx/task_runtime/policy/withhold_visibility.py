"""
task_runtime/policy/withhold_visibility.py — withhold 与 task 事件可见性（§10.6）

职责：
    冻结 **可测试的策略占位**：withhold（输出截断窗口）期间，task 通知与输出 sink
    与 loop 恢复的相对顺序。默认行为保守：不延迟终态通知、输出始终写入 sink。

与 loop 的关系：
    具体注入顺序由 ``create_loop_agent`` / controller 实现；本模块仅提供策略值对象，
    供未来 loop 与 adapter 读取，避免魔法布尔散落在多处。

边界：
    - 本阶段不修改 loop 默认行为；未传入策略时等价于默认实例。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class WithholdTaskEventPolicy:
    """withhold 窗口内 task 相关事件的可见性策略（§10.6 契约占位）。"""

    delay_terminal_task_notification: bool = False
    """若为 True，task 终态通知延迟到 withhold 解除后合并注入（未来）。"""

    write_task_output_sink_during_withhold: bool = True
    """若为 True，withhold 期间仍向 §10.4 sink 追加（便于排障）。"""


DEFAULT_WITHHOLD_TASK_EVENT_POLICY = WithholdTaskEventPolicy()
