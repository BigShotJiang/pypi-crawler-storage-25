"""
plugin/config.py — plugin_config.json 读取与内存表示。

职责：
    定义 PluginConfig/RepositoryEntry，并提供 PluginConfigLoader 读取配置文件。

链路位置：
    PluginLoader 在 Discovery 阶段通过本模块读取插件启停状态和仓库坐标。

当前裁剪范围：
    仅包含读取逻辑，不包含配置写入管理（PluginConfigManager 在后续阶段实现）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import logging

from langchain_agentx.workspace.config import AgentWorkspaceConfig

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RepositoryEntry:
    url: str
    branch: str = "main"
    commit_sha: str | None = None


@dataclass(frozen=True)
class PluginConfig:
    """plugin_config.json 的内存表示。"""

    enabled_plugins: dict[str, bool] = field(default_factory=dict)
    repositories: dict[str, RepositoryEntry] = field(default_factory=dict)

    def is_enabled(self, plugin_id: str, default: bool = True) -> bool:
        return self.enabled_plugins.get(plugin_id, default)


class PluginConfigLoader:
    """加载 plugin_config.json。"""

    @staticmethod
    def load(cfg: AgentWorkspaceConfig) -> PluginConfig:
        config_path = cfg.plugin_config_path
        if not config_path.exists():
            return PluginConfig()

        try:
            raw = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            logger.warning(
                "plugin config parse failed at %s: %s; fallback to empty config",
                config_path,
                exc,
            )
            return PluginConfig()
        except OSError as exc:
            logger.warning(
                "plugin config read failed at %s: %s; fallback to empty config",
                config_path,
                exc,
            )
            return PluginConfig()

        if not isinstance(raw, dict):
            logger.warning(
                "plugin config root must be object at %s; fallback to empty config",
                config_path,
            )
            return PluginConfig()

        enabled_plugins = PluginConfigLoader._parse_enabled_plugins(raw)
        repositories = PluginConfigLoader._parse_repositories(raw)
        return PluginConfig(enabled_plugins=enabled_plugins, repositories=repositories)

    @staticmethod
    def _parse_enabled_plugins(raw: dict[str, object]) -> dict[str, bool]:
        payload = raw.get("enabled_plugins")
        if not isinstance(payload, dict):
            return {}
        parsed: dict[str, bool] = {}
        for plugin_id, enabled in payload.items():
            if isinstance(plugin_id, str) and isinstance(enabled, bool):
                parsed[plugin_id] = enabled
        return parsed

    @staticmethod
    def _parse_repositories(raw: dict[str, object]) -> dict[str, RepositoryEntry]:
        payload = raw.get("repositories")
        if not isinstance(payload, dict):
            return {}
        parsed: dict[str, RepositoryEntry] = {}
        for name, entry in payload.items():
            if not isinstance(name, str) or not isinstance(entry, dict):
                continue
            url = entry.get("url")
            if not isinstance(url, str) or not url:
                continue
            branch = entry.get("branch")
            commit_sha = entry.get("commit_sha")
            parsed[name] = RepositoryEntry(
                url=url,
                branch=branch if isinstance(branch, str) and branch else "main",
                commit_sha=commit_sha if isinstance(commit_sha, str) else None,
            )
        return parsed


__all__ = ["PluginConfig", "PluginConfigLoader", "RepositoryEntry"]
