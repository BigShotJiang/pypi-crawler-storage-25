"""
plugin/manifest.py — plugin.json 解析与校验。

职责：
    定义 PluginManifest/MinimalManifest，并提供 PluginManifestSchema.validate()。

链路位置：
    PluginLoader._load_local_plugin() 在构建 LoadedPlugin 前调用本模块。

当前裁剪范围：
    仅覆盖 P0/P1 校验规则，不包含 mcp_servers 深度校验与依赖拓扑解析。
"""

from __future__ import annotations

from dataclasses import dataclass, field
import re
from typing import Any

from langchain_agentx.loop.hook.types import HookEvent


@dataclass(frozen=True)
class PluginManifest:
    name: str
    description: str = ""
    version: str = "0.1.0"
    applicable_containers: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    skills_path: str = "skills"
    commands_path: str = "commands"
    agents_path: str = "agents"
    hooks: dict[str, Any] | None = None
    mcp_servers: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass(frozen=True)
class MinimalManifest(PluginManifest):
    pass


class ValidationError(Exception):
    """manifest 校验错误。"""

    def __init__(self, messages: list[str]) -> None:
        super().__init__("; ".join(messages))
        self.messages = messages


class PluginManifestSchema:
    """plugin.json 校验器。"""

    _name_pattern = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
    _semver_pattern = re.compile(r"^\d+\.\d+\.\d+$")
    _allowed_hook_types = {"command", "http", "prompt", "agent"}
    _http_disallowed_events = {"SessionStart"}

    @classmethod
    def validate(cls, raw: dict[str, Any]) -> PluginManifest:
        if not isinstance(raw, dict):
            raise ValidationError(["manifest root must be object"])

        errors: list[str] = []
        name = raw.get("name")
        if not isinstance(name, str) or not cls._name_pattern.fullmatch(name):
            errors.append("name must match ^[a-z0-9][a-z0-9-]{0,63}$")

        description = raw.get("description", "")
        if description is not None and not isinstance(description, str):
            errors.append("description must be string")
        description = description if isinstance(description, str) else ""

        version = raw.get("version", "0.1.0")
        if not isinstance(version, str) or not cls._semver_pattern.fullmatch(version):
            errors.append("version must be semver x.y.z")

        applicable = raw.get("applicable_containers", [])
        if not isinstance(applicable, list) or not all(isinstance(v, str) for v in applicable):
            errors.append("applicable_containers must be list[str]")
            applicable = []

        dependencies = raw.get("dependencies", [])
        if not isinstance(dependencies, list) or not all(isinstance(v, str) for v in dependencies):
            errors.append("dependencies must be list[str]")
            dependencies = []

        skills_path = raw.get("skills_path", "skills")
        commands_path = raw.get("commands_path", "commands")
        agents_path = raw.get("agents_path", "agents")
        for field_name, value in (
            ("skills_path", skills_path),
            ("commands_path", commands_path),
            ("agents_path", agents_path),
        ):
            if not isinstance(value, str) or not value.strip():
                errors.append(f"{field_name} must be non-empty string")

        hooks = raw.get("hooks")
        if hooks is not None:
            cls._validate_hooks(hooks, errors)

        mcp_servers = raw.get("mcp_servers", {})
        if not isinstance(mcp_servers, dict):
            errors.append("mcp_servers must be object")
            mcp_servers = {}

        if errors:
            raise ValidationError(errors)

        return PluginManifest(
            name=name,
            description=description,
            version=version,
            applicable_containers=applicable,
            dependencies=dependencies,
            skills_path=skills_path,
            commands_path=commands_path,
            agents_path=agents_path,
            hooks=hooks if isinstance(hooks, dict) else None,
            mcp_servers=mcp_servers,
        )

    @classmethod
    def _validate_hooks(cls, hooks: Any, errors: list[str]) -> None:
        if not isinstance(hooks, dict):
            errors.append("hooks must be object")
            return
        valid_event_names = {event.name for event in HookEvent}
        for event_name, matchers in hooks.items():
            if not isinstance(event_name, str):
                errors.append("hook event key must be string")
                continue
            if event_name not in valid_event_names:
                # 未知事件只告警级别，忽略该 key，不阻断整个 manifest
                continue
            if not isinstance(matchers, list):
                errors.append(f"hooks.{event_name} must be list")
                continue
            for matcher in matchers:
                if not isinstance(matcher, dict):
                    errors.append(f"hooks.{event_name} matcher must be object")
                    continue
                hook_items = matcher.get("hooks", [])
                if not isinstance(hook_items, list):
                    errors.append(f"hooks.{event_name}.hooks must be list")
                    continue
                for hook in hook_items:
                    if not isinstance(hook, dict):
                        errors.append(f"hooks.{event_name}.hooks[] must be object")
                        # hook type/http+SessionStart 语义校验由 loader._build_spec 负责，
                        # 此处只做结构性检查，不整体拒绝 manifest。


__all__ = ["MinimalManifest", "PluginManifest", "PluginManifestSchema", "ValidationError"]
