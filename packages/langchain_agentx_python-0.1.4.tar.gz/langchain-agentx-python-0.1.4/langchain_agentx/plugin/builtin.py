"""
plugin/builtin.py — 内置插件定义注册表。

职责：
    维护随框架发布的内置插件定义，并提供全局注册表访问。

链路位置：
    PluginLoader._discover_builtin() 通过本模块获取内置插件声明。

当前裁剪范围：
    仅做定义注册与读取，不包含 hooks 实际注册逻辑。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(frozen=True)
class BuiltinPluginDefinition:
    name: str
    description: str
    version: str = "0.1.0"
    hooks: dict[str, Any] | None = None
    mcp_servers: dict[str, dict[str, Any]] = field(default_factory=dict)
    applicable_containers: list[str] = field(default_factory=list)
    default_enabled: bool = True
    is_available: Callable[[], bool] | None = None


class BuiltinPluginRegistry:
    """内置插件注册表。"""

    _singleton: "BuiltinPluginRegistry | None" = None

    def __init__(self) -> None:
        self._definitions: dict[str, BuiltinPluginDefinition] = {}

    def register(self, definition: BuiltinPluginDefinition) -> None:
        self._definitions[definition.name] = definition

    def all(self) -> list[BuiltinPluginDefinition]:
        return list(self._definitions.values())

    @classmethod
    def global_instance(cls) -> "BuiltinPluginRegistry":
        if cls._singleton is None:
            cls._singleton = cls()
        return cls._singleton


__all__ = ["BuiltinPluginDefinition", "BuiltinPluginRegistry"]
