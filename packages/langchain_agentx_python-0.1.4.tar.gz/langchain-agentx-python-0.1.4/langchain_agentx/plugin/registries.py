"""
plugin/registries.py — Plugin 能力注册表（Skill/Command/Agent）。

职责：
    管理插件能力索引与按插件来源的批量注销。

链路位置：
    PluginLoader 注册阶段写入，运行阶段由调用方按 key 查找能力。

当前裁剪范围：
    仅覆盖 Skill/Command/AgentDefinition；不含 MCP 注册管理。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .types import ComponentLoadFailedError, LoadedPlugin, PluginError


@dataclass(frozen=True)
class SkillEntry:
    key: str
    plugin_source: str
    path: Path


@dataclass(frozen=True)
class CommandEntry:
    key: str
    plugin_source: str
    name: str
    path: Path


@dataclass(frozen=True)
class AgentDefinitionEntry:
    key: str
    plugin_source: str
    name: str
    path: Path


class SkillRegistry:
    def __init__(self) -> None:
        self._skills: dict[str, SkillEntry] = {}
        self._by_plugin: dict[str, list[str]] = {}

    def register(self, plugin: LoadedPlugin) -> list[PluginError]:
        if plugin.skills_dir is None or not plugin.skills_dir.exists():
            self._by_plugin[plugin.source] = []
            return []

        errors: list[PluginError] = []
        registered: list[str] = []
        for skill_dir in sorted(plugin.skills_dir.iterdir()):
            if not skill_dir.is_dir():
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue
            skill_name = skill_dir.name
            key = f"{plugin.source}:{skill_name}"
            if key in self._skills:
                errors.append(
                    ComponentLoadFailedError(
                        source=plugin.source,
                        plugin=plugin.name,
                        component="skills",
                        path=str(skill_md),
                        reason=f"duplicate skill key: {key}",
                    )
                )
                continue
            self._skills[key] = SkillEntry(key=key, plugin_source=plugin.source, path=skill_md)
            registered.append(key)
        self._by_plugin[plugin.source] = registered
        return errors

    def get(self, key: str) -> SkillEntry | None:
        if key in self._skills:
            return self._skills[key]
        return self._find_by_short_name(key)

    def unregister_plugin(self, plugin_source: str) -> None:
        for key in self._by_plugin.pop(plugin_source, []):
            self._skills.pop(key, None)

    def list_all(self) -> list[SkillEntry]:
        return list(self._skills.values())

    def _find_by_short_name(self, short_name: str) -> SkillEntry | None:
        matches = [entry for entry in self._skills.values() if entry.key.endswith(f":{short_name}")]
        return matches[0] if len(matches) == 1 else None


class CommandRegistry:
    def __init__(self) -> None:
        self._commands: dict[str, CommandEntry] = {}
        self._by_plugin: dict[str, list[str]] = {}

    def register(self, plugin: LoadedPlugin) -> list[PluginError]:
        if plugin.commands_dir is None or not plugin.commands_dir.exists():
            self._by_plugin[plugin.source] = []
            return []

        errors: list[PluginError] = []
        registered: list[str] = []
        for cmd_file in sorted(plugin.commands_dir.glob("*.md")):
            cmd_name = cmd_file.stem
            key = f"{plugin.source}:{cmd_name}"
            if key in self._commands:
                errors.append(
                    ComponentLoadFailedError(
                        source=plugin.source,
                        plugin=plugin.name,
                        component="commands",
                        path=str(cmd_file),
                        reason=f"duplicate command key: {key}",
                    )
                )
                continue
            self._commands[key] = CommandEntry(
                key=key,
                plugin_source=plugin.source,
                name=cmd_name,
                path=cmd_file,
            )
            registered.append(key)
        self._by_plugin[plugin.source] = registered
        return errors

    def get(self, name: str) -> CommandEntry | None:
        if name in self._commands:
            return self._commands[name]
        return self._find_by_short_name(name)

    def unregister_plugin(self, plugin_source: str) -> None:
        for key in self._by_plugin.pop(plugin_source, []):
            self._commands.pop(key, None)

    def list_all(self) -> list[CommandEntry]:
        return list(self._commands.values())

    def _find_by_short_name(self, short_name: str) -> CommandEntry | None:
        matches = [entry for entry in self._commands.values() if entry.key.endswith(f":{short_name}")]
        return matches[0] if len(matches) == 1 else None


class AgentRegistry:
    def __init__(self) -> None:
        self._agents: dict[str, AgentDefinitionEntry] = {}
        self._by_plugin: dict[str, list[str]] = {}

    def register(self, plugin: LoadedPlugin) -> list[PluginError]:
        if plugin.agents_dir is None or not plugin.agents_dir.exists():
            self._by_plugin[plugin.source] = []
            return []

        errors: list[PluginError] = []
        registered: list[str] = []
        for agent_file in sorted(plugin.agents_dir.glob("*.md")):
            agent_name = agent_file.stem
            key = f"{plugin.source}:{agent_name}"
            if key in self._agents:
                errors.append(
                    ComponentLoadFailedError(
                        source=plugin.source,
                        plugin=plugin.name,
                        component="agents",
                        path=str(agent_file),
                        reason=f"duplicate agent key: {key}",
                    )
                )
                continue
            self._agents[key] = AgentDefinitionEntry(
                key=key,
                plugin_source=plugin.source,
                name=agent_name,
                path=agent_file,
            )
            registered.append(key)
        self._by_plugin[plugin.source] = registered
        return errors

    def get(self, name: str) -> AgentDefinitionEntry | None:
        if name in self._agents:
            return self._agents[name]
        return self._find_by_short_name(name)

    def unregister_plugin(self, plugin_source: str) -> None:
        for key in self._by_plugin.pop(plugin_source, []):
            self._agents.pop(key, None)

    def list_all(self) -> list[AgentDefinitionEntry]:
        return list(self._agents.values())

    def _find_by_short_name(self, short_name: str) -> AgentDefinitionEntry | None:
        matches = [entry for entry in self._agents.values() if entry.key.endswith(f":{short_name}")]
        return matches[0] if len(matches) == 1 else None


__all__ = [
    "AgentDefinitionEntry",
    "AgentRegistry",
    "CommandEntry",
    "CommandRegistry",
    "SkillEntry",
    "SkillRegistry",
]
