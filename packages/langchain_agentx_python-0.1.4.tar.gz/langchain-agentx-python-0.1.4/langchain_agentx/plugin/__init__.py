"""
plugin/__init__.py — Plugin 子系统公共导出。

职责：
    暴露 Plugin 子系统第一阶段可复用的数据类型与配置读取入口。

链路位置：
    被 PluginLoader、容器集成层与测试代码统一导入。

当前裁剪范围：
    仅包含 Phase B 的数据层导出，不含 Loader/Registry 实现。
"""

from .builtin import BuiltinPluginDefinition, BuiltinPluginRegistry
from .config import PluginConfig, PluginConfigLoader, RepositoryEntry
from .types import LoadedPlugin, PluginLoadResult

__all__ = [
    "BuiltinPluginDefinition",
    "BuiltinPluginRegistry",
    "LoadedPlugin",
    "PluginConfig",
    "PluginConfigLoader",
    "PluginLoadResult",
    "RepositoryEntry",
]
