"""
plugin/types.py — Plugin 运行时数据类型定义。

职责：
    定义 LoadedPlugin、PluginError 判别联合与 PluginLoadResult。

链路位置：
    被 PluginLoader、各 Registry 与容器集成层共享。

当前裁剪范围：
    仅覆盖 P0/P1 数据类型，不含 MCP/依赖解析相关专用错误类型。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


@dataclass
class LoadedPlugin:
    """PluginLoader 加载后的运行时表示。"""

    name: str
    description: str
    version: str
    path: str
    source: str
    enabled: bool = True
    is_builtin: bool = False
    skills_dir: Path | None = None
    commands_dir: Path | None = None
    agents_dir: Path | None = None
    hooks_config: dict[str, Any] | None = None
    mcp_servers: dict[str, dict[str, Any]] = field(default_factory=dict)
    dependencies: list[str] = field(default_factory=list)
    applicable_containers: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ManifestParseError:
    type: Literal["manifest-parse-error"] = "manifest-parse-error"
    source: str = ""
    manifest_path: str = ""
    parse_error: str = ""


@dataclass(frozen=True)
class ManifestValidationError:
    type: Literal["manifest-validation-error"] = "manifest-validation-error"
    source: str = ""
    manifest_path: str = ""
    validation_errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ComponentLoadFailedError:
    type: Literal["component-load-failed"] = "component-load-failed"
    source: str = ""
    plugin: str = ""
    component: str = ""
    path: str = ""
    reason: str = ""


@dataclass(frozen=True)
class HookLoadFailedError:
    type: Literal["hook-load-failed"] = "hook-load-failed"
    source: str = ""
    plugin: str = ""
    hook_path: str = ""
    reason: str = ""


@dataclass(frozen=True)
class GenericPluginError:
    type: Literal["generic-error"] = "generic-error"
    source: str = ""
    plugin: str = ""
    error: str = ""


PluginError = (
    ManifestParseError
    | ManifestValidationError
    | ComponentLoadFailedError
    | HookLoadFailedError
    | GenericPluginError
)


def get_plugin_error_message(error: PluginError) -> str:
    """将 PluginError 转换为可日志化消息。"""
    if isinstance(error, ManifestParseError):
        return (
            f"[{error.source}] manifest parse error at {error.manifest_path}: "
            f"{error.parse_error}"
        )
    if isinstance(error, ManifestValidationError):
        details = ", ".join(error.validation_errors)
        return (
            f"[{error.source}] manifest validation error at {error.manifest_path}: "
            f"{details}"
        )
    if isinstance(error, ComponentLoadFailedError):
        return (
            f"[{error.source}] {error.component} load failed at {error.path}: "
            f"{error.reason}"
        )
    if isinstance(error, HookLoadFailedError):
        return f"[{error.source}] hook load failed at {error.hook_path}: {error.reason}"
    return f"[{error.source}] plugin error: {error.error}"


@dataclass
class PluginLoadResult:
    """Plugin 加载结果。"""

    enabled: list[LoadedPlugin]
    errors: list[PluginError]

    @property
    def has_errors(self) -> bool:
        return bool(self.errors)

    def log_errors(self, logger: Any) -> None:
        for error in self.errors:
            logger.warning("plugin load error: %s", get_plugin_error_message(error))


__all__ = [
    "ComponentLoadFailedError",
    "GenericPluginError",
    "HookLoadFailedError",
    "LoadedPlugin",
    "ManifestParseError",
    "ManifestValidationError",
    "PluginError",
    "PluginLoadResult",
    "get_plugin_error_message",
]
