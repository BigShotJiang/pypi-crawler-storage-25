"""
command/dispatcher.py — 用户输入命令分流与执行器。

职责：
    解析 slash 输入、查找命令、执行 local/prompt 分派并返回 CommandResult。

链路位置：
    位于 Session 用户输入入口与 loop 调用之间，属于 loop 上游控制层。

当前裁剪范围：
    当前阶段只处理内置命令与普通 prompt，不处理 CLI local-tui 语义。
"""

from __future__ import annotations

import inspect
import logging
from pathlib import Path

from .context import CommandContext
from .registry import CommandRegistry
from .result import CommandResult
from .types import CommandDefinition
from ..plugin.registries import CommandEntry, CommandRegistry as PluginCommandRegistry

logger = logging.getLogger(__name__)


class CommandDispatcher:
    def __init__(
        self,
        registry: CommandRegistry,
        plugin_command_registry: PluginCommandRegistry | None = None,
    ) -> None:
        self._registry = registry
        self._plugin_registry = plugin_command_registry
        self._plugin_markdown_cache: dict[Path, tuple[int, tuple[str, str]]] = {}

    def is_slash_command(self, user_input: str) -> bool:
        return user_input.strip().startswith("/")

    async def dispatch(self, user_input: str, context: CommandContext) -> CommandResult:
        stripped = user_input.strip()
        if not stripped.startswith("/"):
            return CommandResult(should_query=True)

        name, args = self._parse(stripped)
        if not name:
            return CommandResult(error=self._format_error("parse", "command must be `/name [args]`"))
        command = self._registry.find(name)
        if command is None:
            command, lookup_error = self._find_plugin_command(name)
            if lookup_error is not None:
                return CommandResult(error=self._format_error("lookup", lookup_error))
        if command is None:
            return CommandResult(error=self._format_error("lookup", f"unknown command: /{name}"))
        if not command.user_invocable:
            return CommandResult(
                error=self._format_error("permission", f"/{command.name} is not user-invocable")
            )
        if bool(context.extra.get("is_remote")) and not command.remote_safe:
            return CommandResult(
                error=self._format_error("permission", f"/{command.name} is not remote-safe")
            )

        context.extra["args"] = args
        return await self._execute(command, args, context)

    def _parse(self, slash_input: str) -> tuple[str, str]:
        body = slash_input[1:]
        parts = body.split(None, 1)
        if not parts:
            return "", ""
        name = parts[0].lower()
        args = parts[1].strip() if len(parts) > 1 else ""
        return name, args

    async def _execute(
        self,
        command: CommandDefinition,
        args: str,
        context: CommandContext,
    ) -> CommandResult:
        if command.command_type == "prompt":
            return self._execute_prompt(command, args)
        return await self._execute_local(command, context)

    async def _execute_local(
        self,
        command: CommandDefinition,
        context: CommandContext,
    ) -> CommandResult:
        if command.handler is None:
            return CommandResult(error=self._format_error("execute", f"/{command.name}: handler not set"))
        try:
            result = command.handler(context)
            if inspect.isawaitable(result):
                result = await result
            if not isinstance(result, CommandResult):
                return CommandResult(
                    error=self._format_error(
                        "execute",
                        f"/{command.name}: handler returned unexpected type",
                    )
                )
            return result
        except Exception as exc:  # pragma: no cover - defensive path
            logger.error("command /%s execution failed: %s", command.name, exc, exc_info=True)
            return CommandResult(error=self._format_error("execute", f"/{command.name} failed: {exc}"))

    @staticmethod
    def _execute_prompt(command: CommandDefinition, args: str) -> CommandResult:
        if command.prompt_template is None:
            return CommandResult(
                error=CommandDispatcher._format_error(
                    "execute",
                    f"/{command.name}: prompt_template not set",
                )
            )
        rendered = command.prompt_template.replace("{args}", args)
        return CommandResult(should_query=True, injected_prompt=rendered)

    def _find_plugin_command(
        self,
        name: str,
    ) -> tuple[CommandDefinition | None, str | None]:
        if self._plugin_registry is None or not name:
            return None, None
        all_entries = list(self._plugin_registry.list_all())
        # 先匹配完整 key（/plugin@local:cmd）以规避短名冲突歧义。
        exact_matches = [item for item in all_entries if item.key == name]
        if len(exact_matches) == 1:
            return self._entry_to_definition(exact_matches[0]), None
        same_short_name = [item for item in all_entries if item.name == name]
        if len(same_short_name) == 1:
            return self._entry_to_definition(same_short_name[0]), None
        if len(same_short_name) > 1:
            candidates = ", ".join(f"/{item.key}" for item in same_short_name)
            return None, f"unknown command: /{name} (ambiguous plugin command: {candidates})"
        return None, None

    @staticmethod
    def _format_error(error_type: str, detail: str) -> str:
        return f"[command/{error_type}] {detail}"

    def _entry_to_definition(self, entry: CommandEntry) -> CommandDefinition:
        prompt_template, description = self._load_md(entry.path)
        return CommandDefinition(
            name=entry.name,
            description=description or f"Plugin command from {entry.plugin_source}",
            command_type="prompt",
            prompt_template=prompt_template,
            source=entry.plugin_source,
        )

    @staticmethod
    def _parse_markdown(text: str) -> tuple[str, str]:
        description = ""
        body = text
        if text.startswith("---"):
            parts = text.split("---", 2)
            if len(parts) == 3:
                frontmatter = parts[1]
                body = parts[2]
                for line in frontmatter.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("description:"):
                        description = stripped[len("description:") :].strip().strip("'\"")
                        break
        return body.strip(), description

    def _load_md(self, path: Path) -> tuple[str, str]:
        stat = path.stat()
        current_mtime_ns = stat.st_mtime_ns
        cached = self._plugin_markdown_cache.get(path)
        if cached is not None and cached[0] == current_mtime_ns:
            return cached[1]

        text = path.read_text(encoding="utf-8")
        parsed = self._parse_markdown(text)
        self._plugin_markdown_cache[path] = (current_mtime_ns, parsed)
        return parsed

