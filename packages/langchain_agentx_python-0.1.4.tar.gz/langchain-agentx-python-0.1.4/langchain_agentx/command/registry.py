"""
command/registry.py — 统一命令注册表。

职责：
    管理命令注册、冲突检测、别名查找与来源批量注销。

链路位置：
    由 Session 初始化并注入 dispatcher，作为命令发现入口。

当前裁剪范围：
    本阶段仅注册内置命令；register_plugin 接口已预留。
"""

from __future__ import annotations

from collections.abc import Iterable

from .types import CommandDefinition


class CommandRegistry:
    """统一命令注册表。"""

    def __init__(self) -> None:
        self._commands: dict[str, CommandDefinition] = {}
        self._alias_to_name: dict[str, str] = {}
        self._by_source: dict[str, set[str]] = {}

    def register(self, command: CommandDefinition) -> None:
        normalized_name = self._normalize(command.name)
        if normalized_name in self._commands:
            raise ValueError(f"duplicate command name: {normalized_name}")
        self._ensure_aliases_available(command.aliases)
        self._commands[normalized_name] = command
        self._by_source.setdefault(command.source, set()).add(normalized_name)
        for alias in command.aliases:
            self._alias_to_name[self._normalize(alias)] = normalized_name

    def register_plugin(
        self,
        commands: Iterable[CommandDefinition],
        *,
        plugin_source: str,
    ) -> None:
        for command in commands:
            if command.source != plugin_source:
                command = CommandDefinition(
                    name=command.name,
                    description=command.description,
                    command_type=command.command_type,
                    handler=command.handler,
                    prompt_template=command.prompt_template,
                    aliases=command.aliases,
                    user_invocable=command.user_invocable,
                    source=plugin_source,
                )
            self.register(command)

    def unregister_plugin(self, plugin_source: str) -> None:
        names = self._by_source.pop(plugin_source, set())
        for name in names:
            command = self._commands.pop(name, None)
            if command is None:
                continue
            for alias in command.aliases:
                self._alias_to_name.pop(self._normalize(alias), None)

    def find(self, name: str) -> CommandDefinition | None:
        normalized = self._normalize(name)
        command = self._commands.get(normalized)
        if command is not None:
            return command
        mapped_name = self._alias_to_name.get(normalized)
        if mapped_name is None:
            return None
        return self._commands.get(mapped_name)

    def list_all(self, *, include_non_user_invocable: bool = True) -> list[CommandDefinition]:
        commands = list(self._commands.values())
        if include_non_user_invocable:
            return commands
        return [cmd for cmd in commands if cmd.user_invocable]

    def list_for_help(self) -> list[dict[str, object]]:
        items: list[dict[str, object]] = []
        for command in self.list_all(include_non_user_invocable=False):
            items.append(
                {
                    "name": command.name,
                    "description": command.description,
                    "aliases": command.aliases,
                    "source": command.source,
                    "command_type": command.command_type,
                }
            )
        items.sort(key=lambda item: str(item["name"]))
        return items

    @staticmethod
    def _normalize(name: str) -> str:
        return name.strip().lower()

    def _ensure_aliases_available(self, aliases: tuple[str, ...]) -> None:
        for alias in aliases:
            normalized = self._normalize(alias)
            if normalized in self._commands:
                raise ValueError(f"alias conflicts with command name: {normalized}")
            if normalized in self._alias_to_name:
                raise ValueError(f"duplicate alias: {normalized}")

