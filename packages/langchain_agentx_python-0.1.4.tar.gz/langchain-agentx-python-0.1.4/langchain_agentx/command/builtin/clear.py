"""
command/builtin/clear.py — 内置 /clear 命令。

职责：
    触发 Session.clear_context()，清空当前会话上下文。

链路位置：
    由 CommandRegistry 注册，dispatcher 命中后执行。

当前裁剪范围：
    仅返回本地输出，不附带 UI 交互状态。
"""

from __future__ import annotations

from ..context import CommandContext
from ..result import CommandResult
from ..types import CommandDefinition


def _handle_clear(ctx: CommandContext) -> CommandResult:
    ctx.session.clear_context()
    return CommandResult(output="会话上下文已清空")


def make_clear_command() -> CommandDefinition:
    return CommandDefinition(
        name="clear",
        description="清空当前会话上下文",
        command_type="local",
        handler=_handle_clear,
    )

