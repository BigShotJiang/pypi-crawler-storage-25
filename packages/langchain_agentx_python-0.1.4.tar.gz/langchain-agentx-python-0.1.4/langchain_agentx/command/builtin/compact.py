"""
command/builtin/compact.py — 内置 /compact 命令。

职责：
    调用 Session.compact_context() 并返回压缩前后统计。

链路位置：
    由 CommandRegistry 注册，作为 local 命令执行。

当前裁剪范围：
    仅输出 token 粗估统计，不暴露阶段级 compaction meta。
"""

from __future__ import annotations

from ..context import CommandContext
from ..result import CommandResult
from ..types import CommandDefinition


async def _handle_compact(ctx: CommandContext) -> CommandResult:
    before, after = await ctx.session.compact_context()
    return CommandResult(output=f"上下文已压缩：{before} -> {after} tokens")


def make_compact_command() -> CommandDefinition:
    return CommandDefinition(
        name="compact",
        description="压缩当前会话上下文",
        command_type="local",
        handler=_handle_compact,
    )

