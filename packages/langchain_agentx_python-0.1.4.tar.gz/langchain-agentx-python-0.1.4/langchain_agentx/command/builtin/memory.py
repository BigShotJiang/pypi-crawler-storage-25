"""
command/builtin/memory.py — 内置 /memory 命令。

职责：
    读取 args 子命令并调用 Session.get_memory_summary()。

链路位置：
    由 CommandRegistry 注册，dispatcher 通过 context.extra 传入 args。

当前裁剪范围：
    支持 show(默认)/clear，输出文本由 Session API 统一生成。
"""

from __future__ import annotations

from ..context import CommandContext
from ..result import CommandResult
from ..types import CommandDefinition


def _handle_memory(ctx: CommandContext) -> CommandResult:
    args = str(ctx.extra.get("args", "")).strip().lower()
    sub_cmd = args if args else "show"
    if sub_cmd not in {"show", "clear"}:
        return CommandResult(error=f"[command/execute] invalid /memory sub-command: {sub_cmd}")
    output = ctx.session.get_memory_summary(sub_cmd=sub_cmd)
    return CommandResult(output=output)


def make_memory_command() -> CommandDefinition:
    return CommandDefinition(
        name="memory",
        description="查看或清理会话记忆摘要",
        command_type="local",
        handler=_handle_memory,
    )

