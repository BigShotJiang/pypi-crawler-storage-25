"""
command/builtin/reload_plugins.py — 内置 /reload-plugins 命令。

职责：
    触发 Session.reload_plugins() 并返回加载摘要。

链路位置：
    由 CommandRegistry 注册，命中后走 local 异步执行。

当前裁剪范围：
    输出成功/失败计数，不展开逐条错误详情。
"""

from __future__ import annotations

from ..context import CommandContext
from ..result import CommandResult
from ..types import CommandDefinition


async def _handle_reload_plugins(ctx: CommandContext) -> CommandResult:
    if ctx.plugin_loader is None:
        return CommandResult(output="Plugin 系统未启用")
    result = await ctx.session.reload_plugins()
    if result.errors:
        return CommandResult(
            output=(
                f"插件重载完成（{len(result.enabled)} 个成功，"
                f"{len(result.errors)} 个错误）"
            )
        )
    return CommandResult(output=f"插件重载完成：{len(result.enabled)} 个插件已加载")


def make_reload_plugins_command() -> CommandDefinition:
    return CommandDefinition(
        name="reload-plugins",
        description="热重载插件并刷新命令/技能注册",
        command_type="local",
        handler=_handle_reload_plugins,
    )

