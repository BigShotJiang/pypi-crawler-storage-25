"""
command/builtin/__init__.py — 内置命令工厂导出。

职责：
    汇总 builtin 命令定义工厂，供 Session 初始化注册时调用。

链路位置：
    被 session/agent_session.py 与 session/conversation_session.py 依赖。

当前裁剪范围：
    仅导出 P1 阶段四个内置命令。
"""

from .clear import make_clear_command
from .compact import make_compact_command
from .memory import make_memory_command
from .reload_plugins import make_reload_plugins_command

__all__ = [
    "make_clear_command",
    "make_compact_command",
    "make_memory_command",
    "make_reload_plugins_command",
]

