"""
command/types.py — 命令定义与类型约束。

职责：
    定义命令类型枚举与 CommandDefinition，不承载调度逻辑。

链路位置：
    由 registry/dispatcher/session 共同依赖，作为命令子系统的数据契约层。

当前裁剪范围：
    仅覆盖 local/prompt 两类框架命令，不包含 CLI local-tui 扩展类型。
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from .context import CommandContext
    from .result import CommandResult

CommandType = Literal["local", "prompt"]
CommandHandler = Callable[
    ["CommandContext"], "CommandResult | Awaitable[CommandResult]"
]


@dataclass(frozen=True)
class CommandDefinition:
    name: str
    description: str
    command_type: CommandType
    handler: CommandHandler | None = None
    prompt_template: str | None = None
    aliases: tuple[str, ...] = field(default_factory=tuple)
    user_invocable: bool = True
    remote_safe: bool = True
    source: str = "builtin"

