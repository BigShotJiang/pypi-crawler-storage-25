"""
command/context.py — 命令执行上下文。

职责：
    为命令 handler 提供 Session API、workspace 与插件重载所需依赖。

链路位置：
    由 Session 在 dispatch 前构造，贯穿单次命令执行。

当前裁剪范围：
    以 session 注入为主，不暴露内部消息容器引用。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..workspace.config import AgentWorkspaceConfig


@dataclass
class CommandContext:
    session_id: str
    session: Any
    workspace_cfg: AgentWorkspaceConfig
    hook_engine: Any | None = None
    plugin_loader: Any | None = None
    extra: dict[str, Any] = field(default_factory=dict)

