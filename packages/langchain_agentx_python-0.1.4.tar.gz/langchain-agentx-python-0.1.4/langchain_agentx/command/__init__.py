"""
command/__init__.py — 命令子系统公共导出。

职责：
    暴露 command 子系统核心类型、注册表与调度器。

链路位置：
    由 session 层与上层应用统一 import 使用。

当前裁剪范围：
    仅导出 P1 落地必需对象。
"""

from .context import CommandContext
from .dispatcher import CommandDispatcher
from .registry import CommandRegistry
from .result import CommandResult
from .types import CommandDefinition, CommandType

__all__ = [
    "CommandContext",
    "CommandDefinition",
    "CommandDispatcher",
    "CommandRegistry",
    "CommandResult",
    "CommandType",
]

