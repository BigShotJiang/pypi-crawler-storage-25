"""
command/result.py — 命令分发执行结果模型。

职责：
    统一表达命令分发后的去向（是否进入 loop）与可见输出/错误。

链路位置：
    由 dispatcher 返回给 Session/调用方，用于决定后续控制流。

当前裁剪范围：
    仅保留 P0/P1 所需字段；不包含 UI 渲染细节。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CommandResult:
    should_query: bool = False
    output: str | None = None
    injected_prompt: str | None = None
    error: str | None = None

