"""langchain_agentx/config — SDK 内置配置资源（随包发布）。

职责：
    存放内置的、可被外部覆盖的参数表与基线配置资源（例如 model_profiles.yaml）。

链路位置：
    provider/model_profile.py 通过包内路径读取内置 yaml。

当前裁剪范围：
    本包不负责 env/.env 加载，也不提供动态热重载能力。
"""

__all__ = []

