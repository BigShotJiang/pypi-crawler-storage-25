"""
utils/cwd.py — 工作目录单点管理

职责：CwdContext 封装 ContextVar 与进程 cwd；模块级 get_cwd / run_with_cwd_override /
      expand_path / to_relative_path 为薄封装（稳定 ABI）。
在整体链路中的位置：所有工具 normalize_input → expand_path(path, ctx.cwd)；
                    SubagentOrchestrator.invoke_subagent → run_with_cwd_override(effective_cwd)
CC 对照：utils/cwd.ts getCwd() / runWithCwdOverride()；utils/path.ts expandPath() / toRelativePath()
当前裁剪范围：v1 全量；ContextVar 替代 AsyncLocalStorage，语义完全对齐。
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Generator

# 与历史模块级实现一致：在**导入时**固定进程 cwd，供默认 CwdContext 使用。
_MODULE_PROCESS_CWD: str = os.path.realpath(os.getcwd())

_default_ctx: CwdContext | None = None


class CwdContext:
    """单 Agent / 子任务链的 cwd 覆盖与路径展开（CC cwd.ts + path.ts 子集）。"""

    def __init__(
        self,
        *,
        process_cwd: str | None = None,
        cwd_var: ContextVar[str | None] | None = None,
    ) -> None:
        self._cwd_var = cwd_var or ContextVar("cwd_override", default=None)
        self._process_cwd = (
            process_cwd if process_cwd is not None else os.path.realpath(os.getcwd())
        )

    def get_cwd(self) -> str:
        """有 override → 返回 override；否则返回构造时固定的进程 cwd。"""
        return self._cwd_var.get() or self._process_cwd

    @contextmanager
    def run_with_cwd_override(self, cwd: str) -> Generator[None, None, None]:
        """在当前异步上下文中覆盖 cwd，退出后自动恢复。"""
        token = self._cwd_var.set(os.path.realpath(cwd))
        try:
            yield
        finally:
            self._cwd_var.reset(token)

    def expand_path(self, path: str, base_dir: str | None = None) -> str:
        """将路径展开为绝对路径，基准为 base_dir 或 get_cwd()。"""
        actual_base = base_dir or self.get_cwd()
        expanded = os.path.expanduser(path.strip())
        if os.path.isabs(expanded):
            return os.path.normpath(expanded)
        return os.path.normpath(os.path.join(actual_base, expanded))

    def to_relative_path(self, absolute_path: str) -> str:
        """将绝对路径转为相对于 get_cwd() 的路径；若会 ``..`` 溢出则保持绝对。"""
        rel = os.path.relpath(absolute_path, self.get_cwd())
        return absolute_path if rel.startswith("..") else rel


def default_cwd_context() -> CwdContext:
    """返回进程内共享单例（懒创建，``process_cwd`` 与导入时模块行为一致）。"""
    global _default_ctx
    if _default_ctx is None:
        _default_ctx = CwdContext(process_cwd=_MODULE_PROCESS_CWD)
    return _default_ctx


def get_cwd() -> str:
    """获取当前异步上下文的工作目录。

    有 override → 返回 override；否则返回进程启动时的 cwd。
    CC 对照：getCwd() = AsyncLocalStorage.getStore() ?? getCwdState()
    """
    return default_cwd_context().get_cwd()


@contextmanager
def run_with_cwd_override(cwd: str) -> Generator[None, None, None]:
    """在当前异步上下文中覆盖 cwd，退出后自动恢复。

    ContextVar 在 asyncio 中自动传播到所有子任务（Task/coroutine），
    因此子代理整个执行链内的 get_cwd() 都返回 cwd，互不干扰。
    CC 对照：runWithCwdOverride(cwd, fn)
    """
    with default_cwd_context().run_with_cwd_override(cwd):
        yield


def expand_path(path: str, base_dir: str | None = None) -> str:
    """将路径展开为绝对路径，基准为 base_dir 或 get_cwd()。

    处理顺序：
      1. 展开 ~ / ~/...
      2. 绝对路径直接 normpath 返回
      3. 相对路径基于 actual_base 解析

    CC 对照：utils/path.ts expandPath(path, baseDir?)
    """
    return default_cwd_context().expand_path(path, base_dir=base_dir)


def to_relative_path(absolute_path: str) -> str:
    """将绝对路径转为相对于 get_cwd() 的路径，节省 token。

    若相对路径会超出 cwd（以 .. 开头），保持绝对路径不变。
    CC 对照：utils/path.ts toRelativePath(absolutePath)
    """
    return default_cwd_context().to_relative_path(absolute_path)


__all__ = [
    "CwdContext",
    "default_cwd_context",
    "expand_path",
    "get_cwd",
    "run_with_cwd_override",
    "to_relative_path",
]
