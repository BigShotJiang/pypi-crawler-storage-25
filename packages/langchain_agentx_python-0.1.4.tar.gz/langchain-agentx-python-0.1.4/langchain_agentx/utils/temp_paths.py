"""utils/temp_paths.py — 跨平台系统临时目录路径（测试与示例用）。

职责：
    提供「与 OS 一致的可写临时区」下的 `Path` / `str`，避免在单测与演示中写死 POSIX ``/tmp``，
    以便在 Windows（通常为 ``%TEMP%``）与 Linux/macOS 上同一套断言与逻辑路径。
    核心逻辑在 SystemTempLocations；模块级函数为薄封装。

链路位置：
    单测、examples 中仅需「绝对路径字符串」且不便注入 ``tmp_path`` 时使用。

当前裁剪范围：
    不负责创建目录或清理文件；调用方按需 ``mkdir`` / 使用 ``tmp_path``。
    生产业务路径仍应来自 ``AgentWorkspaceConfig`` 等配置层，而非本模块。

工程化约定（与 Claude Code 等 Node 工程对齐思路）：
    - **命名空间**：首段路径分量使用项目前缀（如 ``langchain_agentx_tool_runtime_test/...``），等价于
      CC 中 ``join(tmpdir(), 'claude', ...)`` 在系统临时目录下再分一层，减少与其它软件冲突。
    - **环境变量**：``tempfile.gettempdir()`` 会尊重常见宿主配置（如 Unix ``TMPDIR``、Windows ``TEMP``/``TMP``），
      不在此模块重复实现；CI 若需固定沙箱目录，应通过设置上述环境变量而非改库代码。
    - **非安全边界**：本模块**不做** CC ``memdir/paths`` 类对 UNC、盘符根、过短路径的拒绝策略；若路径来自
      不可信输入，须在策略层校验，勿仅依赖本工具返回的路径。
"""

from __future__ import annotations

import tempfile
from pathlib import Path


class SystemTempLocations:
    """封装 ``tempfile.gettempdir()`` 下的品牌子路径拼接。"""

    def system_temp_dir(self) -> Path:
        """返回当前进程可见的系统临时目录（``tempfile.gettempdir()``）。"""
        return Path(tempfile.gettempdir())

    def under_system_temp(self, *relative_parts: str) -> Path:
        """``system_temp_dir()`` 下拼接相对路径（至少一段，避免误用根）。"""
        if not relative_parts:
            raise ValueError("under_system_temp requires at least one path component")
        return self.system_temp_dir().joinpath(*relative_parts)

    def under_system_temp_str(self, *relative_parts: str) -> str:
        """与 :meth:`under_system_temp` 相同，返回 ``str``（便于存入 session_store 等）。"""
        return str(self.under_system_temp(*relative_parts))


_default_locations = SystemTempLocations()


def default_system_temp_locations() -> SystemTempLocations:
    """返回进程内共享的默认实例。"""
    return _default_locations


def system_temp_dir() -> Path:
    """返回当前进程可见的系统临时目录（``tempfile.gettempdir()``）。"""
    return _default_locations.system_temp_dir()


def under_system_temp(*relative_parts: str) -> Path:
    """``system_temp_dir()`` 下拼接相对路径（至少一段，避免误用根）。"""
    return _default_locations.under_system_temp(*relative_parts)


def under_system_temp_str(*relative_parts: str) -> str:
    """与 :func:`under_system_temp` 相同，返回 ``str``（便于存入 session_store 等）。"""
    return _default_locations.under_system_temp_str(*relative_parts)


__all__ = [
    "SystemTempLocations",
    "default_system_temp_locations",
    "system_temp_dir",
    "under_system_temp",
    "under_system_temp_str",
]
