"""
utils/rg_executable.py — 系统 ripgrep 可执行文件名

职责：为子进程提供跨平台的默认 rg 命令名（本 SDK 不打包 vendor rg）。
链路：GrepRuntimeTool / GlobRuntimeTool -> default_rg_executable()。

约定：
    - Windows：使用「rg.exe」（与 MSVC 安装及 PATH 常见形态一致）
    - 非 Windows：使用「rg」
"""

from __future__ import annotations

import sys


def default_rg_executable() -> str:
    return "rg.exe" if sys.platform == "win32" else "rg"
