"""utils/path_user_input.py — 用户路径串规范化（N 层 / L2）

职责：UserPathInputNormalizer 在 Windows 上将 /c/... 转为原生盘符路径；不校验 workspace。
链路位置：expand_path 与 policy 之前；依赖 HostPlatformDetector 注入。
当前裁剪：无 URI、无 NFC。
"""

from __future__ import annotations

import re

from langchain_agentx.utils.cwd import expand_path
from langchain_agentx.utils.host_platform import (
    HostPlatform,
    HostPlatformDetector,
    default_host_platform_detector,
)

# Git Bash 风格：/c/Users/... → C:\Users\...
_POSIX_WINDOWS_DRIVE = re.compile(r"^/([a-zA-Z])(?:/|\\|$)")


class UserPathInputNormalizer:
    """Windows 上窄匹配 POSIX 盘符形态；其它宿主原样透传。"""

    def __init__(self, host_detector: HostPlatformDetector | None = None) -> None:
        self._host = host_detector or default_host_platform_detector()

    def normalize_for_expand(self, path: str) -> str:
        stripped = path.strip()
        if stripped.startswith("~"):
            return path
        if self._host.current() is not HostPlatform.WINDOWS:
            return path
        m = _POSIX_WINDOWS_DRIVE.match(stripped)
        if not m:
            return path
        drive = m.group(1).upper()
        rest = stripped[m.end() :]
        try:
            if rest:
                native = f"{drive}:\\" + rest.replace("/", "\\")
            else:
                native = f"{drive}:\\"
            return native
        except Exception:
            return path

    def normalize_and_expand(self, path: str, base_dir: str | None = None) -> str:
        return expand_path(self.normalize_for_expand(path), base_dir=base_dir)


_default_normalizer: UserPathInputNormalizer | None = None


def normalize_user_path_string_for_expand(path: str) -> str:
    global _default_normalizer
    if _default_normalizer is None:
        _default_normalizer = UserPathInputNormalizer()
    return _default_normalizer.normalize_for_expand(path)


__all__ = [
    "UserPathInputNormalizer",
    "normalize_user_path_string_for_expand",
]
