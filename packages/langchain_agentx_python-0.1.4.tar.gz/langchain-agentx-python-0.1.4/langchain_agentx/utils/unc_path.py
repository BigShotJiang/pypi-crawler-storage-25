"""
utils/unc_path.py — UNC / 双斜线网径前缀检测

职责：为 Grep/Glob（及未来 Read 等）的 validate_input 提供与 CC 一致的 stat 前短路判断，
      避免对 UNC 路径做本地 stat 触发不必要的远程/凭据面（CC GrepTool/GlobTool validateInput）。

CC 对照：src/tools/GrepTool/GrepTool.ts、src/tools/GlobTool/GlobTool.ts（absolutePath.startsWith('\\\\') || startsWith('//')）。

当前裁剪：仅前缀判定；不解析 \\\\?\\UNC\\ 等扩展设备语法（与 CC 当前检查范围一致）。
"""

from __future__ import annotations


def is_unc_path_skip_local_stat(path: str) -> bool:
    """
    若路径在展开后仍表现为 UNC / SMB 风格根前缀，则不在本地做 exists/stat 校验。

    - 反斜杠 UNC：`\\\\server\\share\\...`
    - 正斜杠根：`//server/share/...`（含部分 POSIX 下 ``//`` 绝对路径形态）
    """
    s = path.strip()
    if not s:
        return False
    return s.startswith("\\\\") or s.startswith("//")
