"""utils/path_hierarchy.py — 路径层级原语（跨平台）。

职责：
    判断 Path 是否已到达当前卷/文件系统的根，供「沿父目录向上遍历」类逻辑安全退出。
    核心逻辑在 FilesystemRootProbe；模块级 is_filesystem_root 为薄封装。

链路位置：
    memory/instruction/loader.py：ProjectRuleCollector.collect 等。

当前裁剪范围：
    仅提供根判定；不包含路径规范化业务规则。
"""

from __future__ import annotations

from pathlib import Path


class FilesystemRootProbe:
    """封装 ``path.parent == path`` 根判定（与 CC git 向上遍历终止思想对齐）。"""

    def is_root(self, path: Path) -> bool:
        """若 *path* 已无更上层父目录则返回 True。"""
        return path.parent == path


_default_probe = FilesystemRootProbe()


def default_filesystem_root_probe() -> FilesystemRootProbe:
    """返回进程内共享的默认探测实例。"""
    return _default_probe


def is_filesystem_root(path: Path) -> bool:
    """若 *path* 已无更上层父目录则返回 True。

    使用 pathlib 约定：根目录满足 ``path.parent == path``（POSIX ``/``、
    Windows 盘符根如 ``C:\\``、UNC 卷根等均为此类）。
    """
    return _default_probe.is_root(path)


__all__ = [
    "FilesystemRootProbe",
    "default_filesystem_root_probe",
    "is_filesystem_root",
]
