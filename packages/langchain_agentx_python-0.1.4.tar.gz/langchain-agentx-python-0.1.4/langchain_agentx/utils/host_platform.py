"""utils/host_platform.py — 宿主 OS / WSL 分类（L1）

职责：HostPlatformDetector 集中分类逻辑；可注入 getter/reader 供单测。
链路位置：仅被需要「宿主类别」的模块引用；不解析业务路径。
当前裁剪：不含 Cygwin/MSYS2；proc 版本读失败或空串时回退 LINUX。
"""

from __future__ import annotations

import logging
import sys
from enum import StrEnum
from typing import Protocol

logger = logging.getLogger(__name__)


class HostPlatform(StrEnum):
    """宿主平台枚举（字符串值与 CC / 遥测对齐）。"""

    MACOS = "macos"
    WINDOWS = "windows"
    WSL = "wsl"
    LINUX = "linux"
    UNKNOWN = "unknown"


class SysPlatformGetter(Protocol):
    def __call__(self) -> str: ...


class ProcVersionReader(Protocol):
    def __call__(self) -> str: ...


def _default_sys_platform() -> str:
    return sys.platform


def _default_read_proc_version() -> str:
    with open("/proc/version", encoding="utf-8") as f:
        return f.read()


class HostPlatformDetector:
    """进程级 memo：同一实例上 ``current()`` 结果缓存至 ``invalidate()``。"""

    def __init__(
        self,
        *,
        sys_platform_getter: SysPlatformGetter | None = None,
        proc_version_reader: ProcVersionReader | None = None,
    ) -> None:
        self._sys_platform_getter = sys_platform_getter or _default_sys_platform
        self._proc_version_reader = proc_version_reader or _default_read_proc_version
        self._cache: HostPlatform | None = None

    def current(self) -> HostPlatform:
        if self._cache is None:
            self._cache = self._compute()
        return self._cache

    def invalidate(self) -> None:
        self._cache = None

    def _compute(self) -> HostPlatform:
        plat = self._sys_platform_getter().lower()
        if plat == "darwin":
            return HostPlatform.MACOS
        if plat == "win32":
            return HostPlatform.WINDOWS
        if plat == "linux":
            try:
                ver_raw = self._proc_version_reader()
            except Exception:
                logger.debug("proc_version read failed", exc_info=True)
                return HostPlatform.LINUX
            ver = ver_raw.lower()
            if not ver:
                logger.debug("proc_version empty; treating as non-WSL linux")
                return HostPlatform.LINUX
            if "microsoft" in ver or "wsl" in ver:
                logger.info("Detected WSL host environment")
                return HostPlatform.WSL
            return HostPlatform.LINUX
        return HostPlatform.UNKNOWN


_singleton: HostPlatformDetector | None = None


def default_host_platform_detector() -> HostPlatformDetector:
    """返回进程内共享单例（懒创建）。"""
    global _singleton
    if _singleton is None:
        _singleton = HostPlatformDetector()
    return _singleton


def get_host_platform() -> HostPlatform:
    """等价于 ``default_host_platform_detector().current()``。"""
    return default_host_platform_detector().current()


__all__ = [
    "HostPlatform",
    "HostPlatformDetector",
    "ProcVersionReader",
    "SysPlatformGetter",
    "default_host_platform_detector",
    "get_host_platform",
]
