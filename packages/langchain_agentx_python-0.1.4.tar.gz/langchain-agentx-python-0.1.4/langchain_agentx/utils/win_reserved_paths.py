"""
utils/win_reserved_paths.py — Windows 保留设备名路径检测

职责：判断路径中是否出现 Windows 保留名（CON/PRN/AUX/NUL/COM1-9/LPT1-9），
      供 Read 等工具在本地 I/O 前拒绝误读设备（与 Unix /dev 阻断互补）。

CC 对照：FileReadTool 仍以 Unix 设备表为主；本工程在 win32 上补一层路径段检测。

当前裁剪：仅按 Windows 规则拆分路径段并检查各段 stem（与 COM1.txt 等扩展名规则一致）；
          非 win32 恒为 False。拆分固定使用 PureWindowsPath，避免在 Linux CI 上 Path 仍为
          PosixPath 时反斜杠路径被误解析（单段 + stem 误判）。
"""

from __future__ import annotations

import sys
from pathlib import PureWindowsPath

_WIN_RESERVED_STEMS: frozenset[str] = frozenset(
    {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}
)


def path_uses_windows_reserved_name(path: str) -> bool:
    """
    若当前平台为 Windows，且路径任一段（按 Windows 路径规则拆分）的 stem 为保留设备名，则返回 True。

    例如 ``C:\\temp\\NUL``、``C:\\share\\COM1.dat``、末段为 ``CON`` 的路径。
    """
    if sys.platform != "win32":
        return False
    if not path or not path.strip():
        return False
    try:
        parts = PureWindowsPath(path).parts
    except (ValueError, OSError):
        return False
    for part in parts:
        seg = part.rstrip("/\\")
        if not seg:
            continue
        # 盘符段如 ``C:`` 无 stem 意义
        if len(seg) == 2 and seg[1] == ":":
            continue
        stem = PureWindowsPath(seg).stem.upper()
        if stem in _WIN_RESERVED_STEMS:
            return True
    return False


__all__ = ["path_uses_windows_reserved_name"]
