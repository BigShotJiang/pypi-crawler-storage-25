"""utils/subprocess_text.py — 文本子进程默认编码（L4）

职责：TextSubprocessRunner 封装默认 utf-8 + errors=replace；可注入 subprocess.run 测行为。
链路位置：Bash/grep/git 等；不替代 BashRuntimeTool 安全语义。
当前裁剪：不封装长生命周期 Popen；不默认 shell=True；禁止 shell=True。
"""

from __future__ import annotations

import subprocess
from collections.abc import Callable, Sequence
from typing import Any

RunProc = Callable[..., subprocess.CompletedProcess[Any]]


class TextSubprocessRunner:
    """统一捕获文本子进程的 ``encoding`` / ``errors`` 默认值（方案 B）。"""

    def __init__(
        self,
        *,
        default_encoding: str = "utf-8",
        default_errors: str = "replace",
        subprocess_run: RunProc = subprocess.run,
    ) -> None:
        self._default_encoding = default_encoding
        self._default_errors = default_errors
        self._subprocess_run = subprocess_run

    def run(
        self,
        args: Sequence[str] | str,
        *,
        encoding: str | None = None,
        errors: str | None = None,
        timeout: float | None = None,
        text: bool | None = None,
        capture_output: bool = False,
        **kwargs: Any,
    ) -> subprocess.CompletedProcess[Any]:
        shell = kwargs.get("shell", False)
        if shell is True:
            raise ValueError(
                "TextSubprocessRunner rejects shell=True; use argv list or a dedicated shell wrapper."
            )

        stdout = kwargs.get("stdout")
        stderr = kwargs.get("stderr")

        if text is False:
            effective_text = False
        elif text is True:
            effective_text = True
        else:
            if capture_output or stdout is subprocess.PIPE or stderr is subprocess.PIPE:
                effective_text = True
            else:
                effective_text = False

        run_kw: dict[str, Any] = dict(kwargs)
        run_kw["capture_output"] = capture_output
        if timeout is not None:
            run_kw["timeout"] = timeout

        if effective_text:
            enc = self._default_encoding if encoding is None else encoding
            err = self._default_errors if errors is None else errors
            run_kw["text"] = True
            run_kw["encoding"] = enc
            run_kw["errors"] = err
        else:
            run_kw["text"] = False
            run_kw.pop("encoding", None)
            run_kw.pop("errors", None)

        return self._subprocess_run(args, **run_kw)


_runner_singleton: TextSubprocessRunner | None = None


def default_text_subprocess_runner() -> TextSubprocessRunner:
    global _runner_singleton
    if _runner_singleton is None:
        _runner_singleton = TextSubprocessRunner()
    return _runner_singleton


def run_text(
    args: Sequence[str] | str,
    **kwargs: Any,
) -> subprocess.CompletedProcess[Any]:
    return default_text_subprocess_runner().run(args, **kwargs)


__all__ = [
    "TextSubprocessRunner",
    "default_text_subprocess_runner",
    "run_text",
]
