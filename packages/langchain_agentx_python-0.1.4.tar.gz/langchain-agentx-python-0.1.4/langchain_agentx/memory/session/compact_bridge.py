"""
memory/session/compact_bridge.py — Session Memory 与 compact 桥接

职责：
    在 compact 前等待提取完成，并在可用时基于 session memory 优先重建精简上下文。

链路位置：
    由 loop compaction 编排层调用，作为 legacy compact 之前的优先尝试路径。

当前裁剪范围：
    本阶段仅实现 Phase 3 的桥接核心能力，不接入具体 loop 节点。
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
import time
from typing import Any

from langchain_core.messages import AIMessage, BaseMessage, SystemMessage, ToolMessage

from langchain_agentx.memory.session.prompts import (
    DEFAULT_SESSION_MEMORY_TEMPLATE,
    MAX_SECTION_LENGTH,
)
from langchain_agentx.memory.session.session_memory import SessionMemoryExtractionState

EXTRACTION_WAIT_TIMEOUT_SECONDS = 15.0
EXTRACTION_STALE_THRESHOLD_SECONDS = 60.0
MAX_SECTION_CHARS = MAX_SECTION_LENGTH * 4
TRUNCATION_MARKER = "[... section truncated for length ...]"
SUMMARY_PREFIX = "This session is being continued from saved session memory."


async def wait_for_session_memory_extraction(
    extraction_state: SessionMemoryExtractionState,
    *,
    timeout_seconds: float = EXTRACTION_WAIT_TIMEOUT_SECONDS,
    stale_threshold_seconds: float = EXTRACTION_STALE_THRESHOLD_SECONDS,
) -> None:
    """等待进行中的提取完成（带超时与 stale 保护）。"""
    start = time.monotonic()
    while extraction_state.extraction_started_at is not None:
        extraction_age = start - extraction_state.extraction_started_at
        if extraction_age >= stale_threshold_seconds:
            return
        if (time.monotonic() - start) >= timeout_seconds:
            return
        await asyncio.sleep(0.05)


def is_session_memory_empty(content: str, template: str = DEFAULT_SESSION_MEMORY_TEMPLATE) -> bool:
    """判断 session memory 是否仍为模板占位内容。"""
    return content.strip() == template.strip()


def _split_into_sections(content: str) -> list[str]:
    sections: list[str] = []
    current: list[str] = []
    for line in content.splitlines():
        if line.startswith("# ") and current:
            sections.append("\n".join(current).strip())
            current = [line]
            continue
        current.append(line)
    if current:
        sections.append("\n".join(current).strip())
    return [section for section in sections if section]


def _truncate_at_line_boundary(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    cut = text.rfind("\n", 0, max_chars)
    if cut == -1:
        return text[:max_chars]
    return text[:cut]


def truncate_session_memory_for_compact(content: str) -> str:
    """按 section 逐段截断 session memory 内容。"""
    sections = _split_into_sections(content)
    if not sections:
        return content

    result: list[str] = []
    for section in sections:
        if len(section) <= MAX_SECTION_CHARS:
            result.append(section)
            continue
        truncated = _truncate_at_line_boundary(section, MAX_SECTION_CHARS)
        result.append(f"{truncated}\n{TRUNCATION_MARKER}")
    return "\n\n".join(result)


def _is_safe_cut_point(messages: list[BaseMessage], index: int) -> bool:
    if index >= len(messages):
        return True
    current = messages[index]
    if isinstance(current, ToolMessage):
        return False
    if isinstance(current, AIMessage):
        # OpenAI 对话约束：summary 之后首条消息不能是 assistant。
        return False
    if index > 0:
        previous = messages[index - 1]
        if isinstance(previous, AIMessage) and bool(previous.tool_calls):
            return False
    return True


def adjust_index_to_preserve_api_invariants(
    messages: list[BaseMessage],
    target_index: int,
) -> int:
    """向前调整截断点，避免拆分 tool_use/tool_result 对。"""
    index = max(0, min(target_index, len(messages)))
    while index > 0:
        if _is_safe_cut_point(messages, index):
            return index
        index -= 1
    return 0


def _build_summary_message(session_memory_summary: str) -> SystemMessage:
    return SystemMessage(
        content=(
            f"{SUMMARY_PREFIX}\n\n"
            f"<session_memory_summary>\n{session_memory_summary}\n</session_memory_summary>\n"
            "Recent messages are preserved verbatim."
        )
    )


def try_session_memory_compaction(
    *,
    messages: list[BaseMessage],
    session_memory_path: Path,
    template: str = DEFAULT_SESSION_MEMORY_TEMPLATE,
) -> list[BaseMessage] | None:
    """优先使用 session memory 重建消息，失败返回 None。"""
    try:
        memory_content = session_memory_path.read_text(encoding="utf-8")
    except OSError:
        return None

    if is_session_memory_empty(memory_content, template):
        return None

    if len(messages) <= 2:
        return None

    truncated_summary = truncate_session_memory_for_compact(memory_content)
    target_index = max(1, len(messages) // 2)
    cut_index = adjust_index_to_preserve_api_invariants(messages, target_index)
    if cut_index == 0:
        return None

    head_system: list[BaseMessage] = []
    remaining: list[BaseMessage] = messages
    if isinstance(messages[0], SystemMessage):
        head_system = [messages[0]]
        remaining = messages[1:]
        cut_index = max(0, cut_index - 1)
    tail = remaining[cut_index:]
    if not tail:
        return None

    rebuilt = [*head_system, _build_summary_message(truncated_summary), *tail]
    return rebuilt


@dataclass
class SessionMemoryCompactBridge:
    """Session memory compact 协作者。"""

    session_memory_path: Path
    extraction_state: SessionMemoryExtractionState
    template: str = DEFAULT_SESSION_MEMORY_TEMPLATE
    consecutive_failures: int = 0
    max_failures_before_open_circuit: int = 3

    async def wait_for_extraction(self) -> None:
        await wait_for_session_memory_extraction(self.extraction_state)

    def is_empty(self) -> bool:
        try:
            content = self.session_memory_path.read_text(encoding="utf-8")
        except OSError:
            return True
        return is_session_memory_empty(content, self.template)

    def try_compact(self, messages: list[BaseMessage]) -> list[BaseMessage] | None:
        if self.consecutive_failures >= self.max_failures_before_open_circuit:
            return None
        compacted = try_session_memory_compaction(
            messages=messages,
            session_memory_path=self.session_memory_path,
            template=self.template,
        )
        if compacted is None:
            self.consecutive_failures += 1
            return None
        self.consecutive_failures = 0
        return compacted

