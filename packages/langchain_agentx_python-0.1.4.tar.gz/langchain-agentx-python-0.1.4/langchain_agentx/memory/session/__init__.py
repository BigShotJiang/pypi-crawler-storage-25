"""
memory/session/__init__.py — Session Memory 包入口

职责：
    暴露 Layer 3 Session Memory 的 prompt 构建能力。

链路位置：
    被 loop/session memory 实现层导入，用于生成提取提示词与模板内容。

当前裁剪范围：
    本阶段仅实现 Phase 1（prompts），不包含提取调度与 compact bridge。
"""

from .prompts import (
    DEFAULT_SESSION_MEMORY_TEMPLATE,
    EXTRACT_SESSION_MEMORY_PROMPT,
    MAX_SECTION_LENGTH,
    analyze_section_sizes,
    build_session_memory_update_prompt,
    generate_section_reminders,
    load_session_memory_prompt,
    load_session_memory_template,
    substitute_variables,
)
from .session_memory import (
    SESSION_MEMORY_INIT_TOKEN_THRESHOLD,
    SESSION_MEMORY_TOOL_CALL_THRESHOLD,
    SESSION_MEMORY_UPDATE_TOKEN_THRESHOLD,
    SessionMemoryExtractionState,
    SessionMemoryManager,
    create_memory_file_can_use_tool,
    make_session_memory_section,
    should_extract_session_memory,
)
from .compact_bridge import (
    EXTRACTION_STALE_THRESHOLD_SECONDS,
    EXTRACTION_WAIT_TIMEOUT_SECONDS,
    MAX_SECTION_CHARS,
    TRUNCATION_MARKER,
    SessionMemoryCompactBridge,
    adjust_index_to_preserve_api_invariants,
    is_session_memory_empty,
    truncate_session_memory_for_compact,
    try_session_memory_compaction,
    wait_for_session_memory_extraction,
)

__all__ = [
    "MAX_SECTION_LENGTH",
    "DEFAULT_SESSION_MEMORY_TEMPLATE",
    "EXTRACT_SESSION_MEMORY_PROMPT",
    "substitute_variables",
    "analyze_section_sizes",
    "generate_section_reminders",
    "build_session_memory_update_prompt",
    "load_session_memory_template",
    "load_session_memory_prompt",
    "SESSION_MEMORY_INIT_TOKEN_THRESHOLD",
    "SESSION_MEMORY_UPDATE_TOKEN_THRESHOLD",
    "SESSION_MEMORY_TOOL_CALL_THRESHOLD",
    "SessionMemoryExtractionState",
    "SessionMemoryManager",
    "should_extract_session_memory",
    "create_memory_file_can_use_tool",
    "make_session_memory_section",
    "EXTRACTION_WAIT_TIMEOUT_SECONDS",
    "EXTRACTION_STALE_THRESHOLD_SECONDS",
    "MAX_SECTION_CHARS",
    "TRUNCATION_MARKER",
    "wait_for_session_memory_extraction",
    "is_session_memory_empty",
    "truncate_session_memory_for_compact",
    "adjust_index_to_preserve_api_invariants",
    "try_session_memory_compaction",
    "SessionMemoryCompactBridge",
]
