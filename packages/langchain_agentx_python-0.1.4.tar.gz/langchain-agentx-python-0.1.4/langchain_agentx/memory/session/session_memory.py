"""
memory/session/session_memory.py — Session Memory 触发与后台提取

职责：
    提供 Layer 3 的触发判定、并发保护与后台提取编排能力。

链路位置：
    由 HookGraphWiring.after_model_node 调用 SessionMemoryManager.maybe_trigger()，
    在满足阈值时异步触发会话笔记提取。

当前裁剪范围：
    本阶段仅实现 Phase 2（触发与状态管理），不接入 loop/factory/compact。
    _write_fallback_summary 仅用于 demo/test 验证链路通路，不替代 CC 真实提取语义。
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
import time
import logging
from typing import Any

from langchain_agentx.loop.config import TokenEstimator
from langchain_agentx.memory.session.prompts import (
    DEFAULT_SESSION_MEMORY_TEMPLATE,
    build_session_memory_update_prompt,
)

SESSION_MEMORY_INIT_TOKEN_THRESHOLD = 10_000
SESSION_MEMORY_UPDATE_TOKEN_THRESHOLD = 5_000
SESSION_MEMORY_TOOL_CALL_THRESHOLD = 3
logger = logging.getLogger(__name__)

ExtractionRunner = Callable[[list[Any], str, Path, Any], Awaitable[None]]


@dataclass
class SessionMemoryExtractionState:
    """提取状态追踪与并发保护（对齐 CC sequential() 语义）。"""

    extraction_started_at: float | None = None
    tokens_at_last_extraction: int = 0
    tool_calls_at_last_extraction: int = 0
    session_memory_initialized: bool = False
    last_summarized_message_id: str | None = None
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def run_exclusive(self, coro: Awaitable[None]) -> None:
        """串行执行提取任务，防止并发重入。"""
        async with self._lock:
            await coro


def _as_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _compute_has_tool_calls_in_last_turn(messages: list[Any]) -> bool:
    for message in reversed(messages):
        if isinstance(message, Mapping):
            role = str(message.get("role", ""))
            if role not in {"assistant", "ai"}:
                continue
            tool_calls = message.get("tool_calls")
            return bool(tool_calls)
        role = getattr(message, "type", None) or getattr(message, "role", "")
        if role in {"ai", "assistant"}:
            return bool(getattr(message, "tool_calls", None))
    return False


def _estimate_tool_calls_from_messages(messages: list[Any]) -> int:
    count = 0
    for message in messages:
        if isinstance(message, Mapping):
            tool_calls = message.get("tool_calls")
        else:
            tool_calls = getattr(message, "tool_calls", None)
        if tool_calls:
            count += len(tool_calls)
    return count


def should_extract_session_memory(
    *,
    token_count: int,
    tool_call_count: int,
    last_extract_token_count: int,
    last_extract_tool_call_count: int,
    has_tool_calls_in_last_turn: bool,
) -> bool:
    """对齐 CC shouldExtractMemory 的三条件逻辑。"""
    if last_extract_token_count == 0:
        has_met_token_threshold = token_count >= SESSION_MEMORY_INIT_TOKEN_THRESHOLD
    else:
        has_met_token_threshold = (
            token_count - last_extract_token_count
        ) >= SESSION_MEMORY_UPDATE_TOKEN_THRESHOLD

    if not has_met_token_threshold:
        return False

    has_met_tool_call_threshold = (
        tool_call_count - last_extract_tool_call_count
    ) >= SESSION_MEMORY_TOOL_CALL_THRESHOLD
    if has_met_tool_call_threshold:
        return True

    return not has_tool_calls_in_last_turn


def create_memory_file_can_use_tool(session_memory_path: Path) -> list[dict[str, Any]]:
    """生成提取 agent 的受限工具配置：仅允许 Edit 目标会话文件。"""
    return [
        {
            "name": "Edit",
            "allowed_paths": [str(session_memory_path)],
        }
    ]


@dataclass
class SessionMemoryManager:
    """Session Memory 触发与后台提取编排器。"""

    session_memory_path: Path
    llm: Any
    is_subagent: bool = False
    extraction_state: SessionMemoryExtractionState = field(
        default_factory=SessionMemoryExtractionState
    )
    subagent_runner: ExtractionRunner | None = None
    _pending_tasks: set[asyncio.Task[None]] = field(default_factory=set, init=False)
    _token_estimator: TokenEstimator = field(default_factory=TokenEstimator, init=False)

    async def drain(self) -> None:
        """等待所有 fire-and-forget 提取任务完成（测试与 demo 用）。"""
        if self._pending_tasks:
            await asyncio.gather(*list(self._pending_tasks), return_exceptions=True)

    def maybe_trigger(self, state: Mapping[str, Any]) -> None:
        """阈值满足后以 fire-and-forget 方式启动后台提取。"""
        if self.is_subagent:
            return

        messages_raw = state.get("messages", [])
        messages = list(messages_raw) if isinstance(messages_raw, list) else []
        token_count = _as_int(state.get("token_count"))
        tool_call_count = _as_int(state.get("tool_call_count"))
        if token_count <= 0:
            token_count = self._token_estimator.estimate_messages_tokens(messages)
        if tool_call_count <= 0:
            tool_call_count = _estimate_tool_calls_from_messages(messages)
        has_tool_calls_in_last_turn = _compute_has_tool_calls_in_last_turn(messages)

        if not should_extract_session_memory(
            token_count=token_count,
            tool_call_count=tool_call_count,
            last_extract_token_count=self.extraction_state.tokens_at_last_extraction,
            last_extract_tool_call_count=self.extraction_state.tool_calls_at_last_extraction,
            has_tool_calls_in_last_turn=has_tool_calls_in_last_turn,
        ):
            return

        try:
            asyncio.get_running_loop()
        except RuntimeError:
            logger.warning(
                "session_memory: no running event loop, skip extraction for this turn"
            )
            return

        task = asyncio.ensure_future(
            self._run_extraction(
                messages=messages,
                token_count=token_count,
                tool_call_count=tool_call_count,
            )
        )
        self._pending_tasks.add(task)
        task.add_done_callback(self._pending_tasks.discard)

    async def _run_extraction(
        self,
        *,
        messages: list[Any],
        token_count: int,
        tool_call_count: int,
    ) -> None:
        async def _guarded() -> None:
            self.extraction_state.extraction_started_at = time.monotonic()
            try:
                current_notes = self._read_or_init_notes()
                prompt = build_session_memory_update_prompt(
                    current_notes=current_notes,
                    notes_path=self.session_memory_path,
                )
                if self.subagent_runner is not None:
                    await self.subagent_runner(
                        messages,
                        prompt,
                        self.session_memory_path,
                        self.llm,
                    )
                else:
                    self._write_fallback_summary(messages=messages, prompt=prompt)
                self.extraction_state.tokens_at_last_extraction = max(
                    self.extraction_state.tokens_at_last_extraction,
                    token_count,
                )
                self.extraction_state.tool_calls_at_last_extraction = max(
                    self.extraction_state.tool_calls_at_last_extraction,
                    tool_call_count,
                )
                self.extraction_state.session_memory_initialized = True
            finally:
                self.extraction_state.extraction_started_at = None

        await self.extraction_state.run_exclusive(_guarded())

    def _read_or_init_notes(self) -> str:
        if not self.session_memory_path.exists():
            self.session_memory_path.parent.mkdir(parents=True, exist_ok=True)
            self.session_memory_path.write_text(
                DEFAULT_SESSION_MEMORY_TEMPLATE,
                encoding="utf-8",
            )
            return DEFAULT_SESSION_MEMORY_TEMPLATE
        return self.session_memory_path.read_text(encoding="utf-8")

    def _write_fallback_summary(self, *, messages: list[Any], prompt: str) -> None:
        """无 subagent runner 时的兜底摘要写入，保证 session memory 可被验证。"""
        snippets: list[str] = []
        for msg in messages[-6:]:
            if isinstance(msg, Mapping):
                role = str(msg.get("role", "unknown"))
                content = str(msg.get("content", ""))
            else:
                role = str(getattr(msg, "type", getattr(msg, "role", "unknown")))
                content = str(getattr(msg, "content", ""))
            if content:
                snippets.append(f"- {role}: {content[:240]}")
        body = "\n".join(snippets) if snippets else "- no recent messages captured"
        fallback_blob = (
            "\n\n## Auto Summary (fallback)\n"
            "Session memory extraction runner is not configured.\n"
            "Captured recent conversation snippets:\n"
            f"{body}\n"
            f"\nPrompt digest length: {len(prompt)}\n"
        )
        existing = self.session_memory_path.read_text(encoding="utf-8")
        self.session_memory_path.write_text(existing + fallback_blob, encoding="utf-8")


def make_session_memory_section(session_memory_path: Path) -> Any:
    """构建会话记忆注入段（volatile，避免缓存过期）。"""
    from langchain_agentx.loop.prompt.sections import volatile_section

    def _load() -> str | None:
        from langchain_agentx.memory.session.compact_bridge import is_session_memory_empty

        if not session_memory_path.exists():
            return None
        content = session_memory_path.read_text(encoding="utf-8")
        if not content.strip():
            return None
        if is_session_memory_empty(content):
            return None
        return f"<session_memory>\n{content}\n</session_memory>"

    return volatile_section(
        name="session_memory",
        compute=_load,
        reason="session memory file may change between turns",
    )

