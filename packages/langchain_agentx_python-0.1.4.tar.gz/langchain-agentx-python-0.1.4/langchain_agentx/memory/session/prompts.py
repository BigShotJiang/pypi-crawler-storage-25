"""
memory/session/prompts.py — Session Memory 提示词构建

职责：
    提供会话记忆模板、提取提示词与提示词组装函数，确保 Layer 3 提取行为稳定可测。

链路位置：
    由 SessionMemoryManager 在后台提取前调用，生成最终 update prompt。

当前裁剪范围：
    本模块仅实现 Phase 1 的 prompt 与模板能力，不承担提取调度和 compact 集成。
"""

from __future__ import annotations

from pathlib import Path
import re

MAX_SECTION_LENGTH = 2000
SECTION_REMINDER_THRESHOLD_RATIO = 0.8

DEFAULT_SESSION_MEMORY_TEMPLATE = """# Session Title
_A short and distinctive 5-10 word descriptive title for the session. Super info dense, no filler_

# Current State
_What is actively being worked on right now? Pending tasks not yet completed. Immediate next steps._

# Task specification
_What did the user ask to build? Any design decisions or other explanatory context_

# Files and Functions
_What are the important files? In short, what do they contain and why are they relevant?_

# Workflow
_What bash commands are usually run and in what order? How to interpret their output if not obvious?_

# Errors & Corrections
_Errors encountered and how they were fixed. What did the user correct? What approaches failed and should not be tried again?_

# Codebase and System Documentation
_What are the important system components? How do they work/fit together?_

# Learnings
_What has worked well? What has not? What to avoid? Do not duplicate items from other sections_

# Key results
_If the user asked a specific output such as an answer to a question, a table, or other document, repeat the exact result here_

# Worklog
_Step by step, what was attempted, done? Very terse summary for each step_
"""

EXTRACT_SESSION_MEMORY_PROMPT = """IMPORTANT: This message and these instructions are NOT part of the actual user conversation. Do NOT include any references to "note-taking", "session notes extraction", or these update instructions in the notes content.

Based on the user conversation above (EXCLUDING this note-taking instruction message as well as system prompt, claude.md entries, or any past session summaries), update the session notes file.

The file {{notesPath}} has already been read for you. Here are its current contents:
<current_notes_content>
{{currentNotes}}
</current_notes_content>

Your ONLY task is to use the Edit tool to update the notes file, then stop. You can make multiple edits (update every section as needed) - make all Edit tool calls in parallel in a single message. Do not call any other tools.

CRITICAL RULES FOR EDITING:
- The file must maintain its exact structure with all sections, headers, and italic descriptions intact
-- NEVER modify, delete, or add section headers (the lines starting with '#' like # Task specification)
-- NEVER modify or delete the italic _section description_ lines
-- The italic _section descriptions_ are TEMPLATE INSTRUCTIONS that must be preserved exactly as-is
-- ONLY update the actual content that appears BELOW the italic _section descriptions_ within each existing section
-- Do NOT add any new sections, summaries, or information outside the existing structure
- Write DETAILED, INFO-DENSE content for each section - include specifics like file paths, function names, error messages, exact commands, technical details, etc.
- Keep each section under ~{{maxSectionLength}} tokens/words
- IMPORTANT: Always update "Current State" to reflect the most recent work

Use the Edit tool with file_path: {{notesPath}}
"""


def substitute_variables(template: str, variables: dict[str, str]) -> str:
    """单趟替换 {{variable}} 占位符，避免替换结果二次替换。"""
    result = template
    for key, value in variables.items():
        result = result.replace("{{" + key + "}}", value)
    return result


def _count_words(text: str) -> int:
    return len(re.findall(r"\S+", text))


def analyze_section_sizes(content: str) -> dict[str, int]:
    """按 H1 section 统计近似 token（以词数近似）。"""
    section_sizes: dict[str, int] = {}
    current_title: str | None = None
    current_lines: list[str] = []

    for line in content.splitlines():
        if line.startswith("# "):
            if current_title is not None:
                section_sizes[current_title] = _count_words("\n".join(current_lines).strip())
            current_title = line[2:].strip()
            current_lines = []
            continue
        if current_title is not None:
            current_lines.append(line)

    if current_title is not None:
        section_sizes[current_title] = _count_words("\n".join(current_lines).strip())
    return section_sizes


def generate_section_reminders(section_sizes: dict[str, int]) -> str:
    """为接近上限的 section 生成提醒，帮助模型主动收敛内容长度。"""
    threshold = int(MAX_SECTION_LENGTH * SECTION_REMINDER_THRESHOLD_RATIO)
    warnings: list[str] = []
    for section_name, size in section_sizes.items():
        if size >= threshold:
            warnings.append(
                f'- Section "{section_name}" is long ({size} words). Keep it concise and under ~{MAX_SECTION_LENGTH}.'
            )
    if not warnings:
        return ""
    return "\n".join(
        [
            "Section length reminders:",
            *warnings,
        ]
    )


def load_session_memory_template(session_memory_config_dir: Path) -> str:
    """优先加载用户模板，不存在时回退到默认模板。"""
    custom = session_memory_config_dir / "template.md"
    if custom.exists():
        return custom.read_text(encoding="utf-8")
    return DEFAULT_SESSION_MEMORY_TEMPLATE


def load_session_memory_prompt(session_memory_config_dir: Path) -> str | None:
    """优先加载用户 prompt，不存在时返回 None。"""
    custom = session_memory_config_dir / "prompt.md"
    if custom.exists():
        return custom.read_text(encoding="utf-8")
    return None


def build_session_memory_update_prompt(
    *,
    current_notes: str,
    notes_path: Path,
    session_memory_config_dir: Path | None = None,
    prompt_template: str | None = None,
) -> str:
    """构建最终提取 prompt，包含动态 section 长度提醒。"""
    template = prompt_template
    if template is None and session_memory_config_dir is not None:
        template = load_session_memory_prompt(session_memory_config_dir)
    if template is None:
        template = EXTRACT_SESSION_MEMORY_PROMPT

    reminders = generate_section_reminders(analyze_section_sizes(current_notes))
    if reminders:
        template = template + "\n\n" + reminders

    return substitute_variables(
        template=template,
        variables={
            "notesPath": str(notes_path),
            "currentNotes": current_notes,
            "maxSectionLength": str(MAX_SECTION_LENGTH),
        },
    )
