"""
memory/memdir/scan.py — Layer 2 memory 文件扫描器。

职责：
    扫描 memory 目录下的 markdown 文件，解析 frontmatter 的 type 字段，输出可组装清单。

链路位置：
    memdir runtime 读取 MEMORY.md 或 fallback 扫描时使用。

当前裁剪范围：
    Phase 1 仅实现基础扫描与轻量 frontmatter 解析，不做异步缓存。
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
from pathlib import Path

from .age import memory_freshness_text
from .types import parse_memory_type

logger = logging.getLogger(__name__)

MAX_SCAN_FILES = 200


@dataclass(frozen=True)
class MemoryFileHeader:
    path: Path
    rel_path: str
    title: str
    memory_type: str | None
    freshness: str


class FrontmatterParseError(ValueError):
    """frontmatter 结构损坏。"""


class MemoryScanner:
    def __init__(self, *, memory_dir: Path, max_scan: int = MAX_SCAN_FILES) -> None:
        self._memory_dir = memory_dir
        self._max_scan = max_scan

    def scan_memory_files(self) -> list[MemoryFileHeader]:
        if not self._memory_dir.exists() or not self._memory_dir.is_dir():
            return []

        candidates = self._iter_candidates()
        headers: list[MemoryFileHeader] = []
        for path in candidates:
            try:
                content = path.read_text(encoding="utf-8")
            except OSError:
                continue
            try:
                memory_type = self._parse_frontmatter_type(content)
            except FrontmatterParseError as exc:
                logger.warning("skip memory file with malformed frontmatter: %s (%s)", path, exc)
                continue
            headers.append(
                MemoryFileHeader(
                    path=path,
                    rel_path=path.relative_to(self._memory_dir).as_posix(),
                    title=self._first_heading(content, fallback=path.stem),
                    memory_type=memory_type,
                    freshness=memory_freshness_text(path),
                )
            )
        return headers

    def _iter_candidates(self) -> list[Path]:
        all_md = [path for path in self._memory_dir.rglob("*.md") if path.name != "MEMORY.md"]
        all_md.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return all_md[: self._max_scan]

    def _parse_frontmatter_type(self, content: str) -> str | None:
        lines = content.splitlines()
        if not lines:
            return None
        if lines[0].strip() != "---":
            return None
        end_index: int | None = None
        for idx in range(1, len(lines)):
            if lines[idx].strip() == "---":
                end_index = idx
                break
        if end_index is None:
            raise FrontmatterParseError("missing closing ---")
        for raw in lines[1:end_index]:
            line = raw.strip()
            if not line:
                continue
            if ":" not in line:
                raise FrontmatterParseError(f"invalid frontmatter line: {line}")
            key, value = line.split(":", 1)
            if key.strip() != "type":
                continue
            normalized = value.strip().strip('"').strip("'")
            parsed = parse_memory_type(normalized)
            return parsed.value if parsed else None
        return None

    @staticmethod
    def _first_heading(content: str, fallback: str) -> str:
        for line in content.splitlines():
            if line.startswith("# "):
                title = line[2:].strip()
                if title:
                    return title
        return fallback


def scan_memory_files(memory_dir: Path) -> list[MemoryFileHeader]:
    return MemoryScanner(memory_dir=memory_dir).scan_memory_files()


def format_memory_manifest(headers: list[MemoryFileHeader]) -> str:
    if not headers:
        return ""
    lines = [
        f"- [{h.rel_path}] type={h.memory_type or 'unknown'} ({h.freshness})"
        for h in headers
    ]
    return "\n".join(lines)


__all__ = [
    "MAX_SCAN_FILES",
    "MemoryScanner",
    "MemoryFileHeader",
    "format_memory_manifest",
    "scan_memory_files",
]
