"""
memory/memdir/types.py — Layer 2 类型与提示词常量。

职责：
    定义记忆类型闭集与通用提示词片段，供 loader/extractor 复用。

链路位置：
    build_memory_lines() 与 build_extract_prompt() 从本模块读取同源常量。

当前裁剪范围：
    仅定义静态契约，不包含 IO 或业务编排逻辑。
"""

from __future__ import annotations

from enum import Enum


class MemoryType(str, Enum):
    USER = "user"
    FEEDBACK = "feedback"
    PROJECT = "project"
    REFERENCE = "reference"


MEMORY_TYPES: tuple[str, ...] = (
    MemoryType.USER.value,
    MemoryType.FEEDBACK.value,
    MemoryType.PROJECT.value,
    MemoryType.REFERENCE.value,
)

TYPES_SECTION_INDIVIDUAL = """
## Memory types

- user: User profile, preferences, and collaboration style.
- feedback: Corrections and explicit preferences from the user.
- project: Non-code project context and constraints.
- reference: Pointers to external systems and resources.
""".strip()

WHAT_NOT_TO_SAVE_SECTION = """
## What not to save

- Anything that can be derived from code or git history.
- Task-local TODOs that belong to the current run only.
- Anything already documented in instruction files (e.g. CLAUDE.md / AGENT.md / .cursorrules).
""".strip()

HOW_TO_SAVE_SECTION = """
## How to save

1. Create or update a topic file under memory/.
2. Keep MEMORY.md as an index line list pointing to topic files.
""".strip()

WHEN_TO_ACCESS_SECTION = """
## When to access memory

- At session start to recover long-term context.
- Before making personalized recommendations.
- If the user asks to ignore memory, proceed as if MEMORY.md were empty.
""".strip()

TRUSTING_RECALL_SECTION = """
## Before recommending from memory

A memory is a historical claim, not a guarantee of current truth.
Verify code/file/function claims against the current workspace before recommending actions.
""".strip()

DIR_EXISTS_GUIDANCE = """
This directory already exists — write to it directly with the Write tool
(do not run mkdir or check for its existence).
""".strip()

MEMORY_AND_PERSISTENCE_SECTION = """
## Memory vs task state

Use memory for durable facts that should survive across sessions.
Use task/session state for temporary execution details.
""".strip()


def parse_memory_type(raw: str) -> MemoryType | None:
    normalized = str(raw or "").strip().lower()
    for item in MemoryType:
        if item.value == normalized:
            return item
    return None


__all__ = [
    "DIR_EXISTS_GUIDANCE",
    "HOW_TO_SAVE_SECTION",
    "MEMORY_TYPES",
    "MEMORY_AND_PERSISTENCE_SECTION",
    "MemoryType",
    "TRUSTING_RECALL_SECTION",
    "TYPES_SECTION_INDIVIDUAL",
    "WHAT_NOT_TO_SAVE_SECTION",
    "WHEN_TO_ACCESS_SECTION",
    "parse_memory_type",
]
