"""
memory/memdir/loader.py — Layer 2 prompt 加载编排。

职责：
    负责 MEMORY.md 入口读取、截断保护与 auto_memory section 文本组装。

链路位置：
    Loop 启动时通过 section("auto_memory") 调用 load_memory_prompt() 注入 system prompt。

当前裁剪范围：
    Phase 2 仅实现全量注入（行为说明 + MEMORY.md 正文），不含相关性召回。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from langchain_agentx.workspace import AgentWorkspaceConfig

from .paths import is_memory_enabled
from .types import (
    DIR_EXISTS_GUIDANCE,
    HOW_TO_SAVE_SECTION,
    MEMORY_AND_PERSISTENCE_SECTION,
    TRUSTING_RECALL_SECTION,
    TYPES_SECTION_INDIVIDUAL,
    WHAT_NOT_TO_SAVE_SECTION,
    WHEN_TO_ACCESS_SECTION,
)

MAX_ENTRYPOINT_LINES = 200
MAX_ENTRYPOINT_BYTES = 25_000


@dataclass(frozen=True)
class EntrypointTruncation:
    content: str
    was_line_truncated: bool
    was_byte_truncated: bool
    warning: str | None


class MemoryPromptLoader:
    def __init__(self, workspace_cfg: AgentWorkspaceConfig) -> None:
        self._cfg = workspace_cfg

    def _ensure_memory_dir(self) -> None:
        self._cfg.memory_dir.mkdir(parents=True, exist_ok=True)

    def truncate_entrypoint_content(self, raw: str) -> EntrypointTruncation:
        return _truncate_entrypoint_content(raw)

    def build_memory_lines(self, entrypoint_text: str) -> list[str]:
        return _build_memory_lines(memory_dir=self._cfg.memory_dir, entrypoint_text=entrypoint_text)

    def load_memory_prompt(self) -> str | None:
        self._ensure_memory_dir()
        if not is_memory_enabled(self._cfg):
            return None

        entrypoint = self._cfg.memory_entrypoint
        if entrypoint.exists():
            raw = entrypoint.read_text(encoding="utf-8")
        else:
            raw = ""
        truncated = self.truncate_entrypoint_content(raw)
        lines = self.build_memory_lines(truncated.content)
        if truncated.warning:
            lines.extend(["", truncated.warning])
        return "\n".join(lines)


def _build_warning(
    *,
    line_count: int,
    original_bytes_len: int,
    line_truncated: bool,
    byte_truncated: bool,
) -> str | None:
    if not line_truncated and not byte_truncated:
        return None
    bytes_text = f"{round(original_bytes_len / 1000)} KB"
    if line_truncated and byte_truncated:
        reason = f"{line_count} lines and {bytes_text}"
    elif line_truncated:
        reason = f"{line_count} lines (limit: {MAX_ENTRYPOINT_LINES})"
    else:
        reason = (
            f"{bytes_text} (limit: {MAX_ENTRYPOINT_BYTES // 1000} KB) "
            "— index entries are too long"
        )
    return (
        f"> WARNING: MEMORY.md is {reason}. Only part of it was loaded.\n"
        "> Keep index entries to one line under ~200 chars; move detail into topic files."
    )


def _truncate_entrypoint_content(raw: str) -> EntrypointTruncation:
    lines = raw.splitlines()
    line_truncated = len(lines) > MAX_ENTRYPOINT_LINES
    if line_truncated:
        truncated_lines = lines[:MAX_ENTRYPOINT_LINES]
        working = "\n".join(truncated_lines)
    else:
        working = raw

    original_bytes_len = len(raw.encode("utf-8"))
    working_bytes = working.encode("utf-8")
    byte_truncated = original_bytes_len > MAX_ENTRYPOINT_BYTES
    if byte_truncated:
        working = working_bytes[:MAX_ENTRYPOINT_BYTES].decode("utf-8", errors="ignore")

    warning = _build_warning(
        line_count=len(lines),
        original_bytes_len=original_bytes_len,
        line_truncated=line_truncated,
        byte_truncated=byte_truncated,
    )
    return EntrypointTruncation(
        content=working.strip(),
        was_line_truncated=line_truncated,
        was_byte_truncated=byte_truncated,
        warning=warning,
    )


def _build_memory_lines(*, memory_dir: Path, entrypoint_text: str) -> list[str]:
    header = [
        "# auto memory",
        "",
        f"You have a persistent, file-based memory system at `{memory_dir}`.",
        DIR_EXISTS_GUIDANCE,
        "",
        "You should build up this memory system over time so that future conversations",
        "can have a complete picture of who the user is, how they'd like to collaborate",
        "with you, what behaviors to avoid or repeat, and the context behind the work",
        "the user gives you.",
        "",
        "If the user explicitly asks you to remember something, save it immediately as",
        "whichever type fits best. If they ask you to forget something, find and remove",
        "the relevant entry.",
        "",
        TYPES_SECTION_INDIVIDUAL,
        "",
        WHAT_NOT_TO_SAVE_SECTION,
        "",
        HOW_TO_SAVE_SECTION,
        "",
        WHEN_TO_ACCESS_SECTION,
        "",
        TRUSTING_RECALL_SECTION,
        "",
        MEMORY_AND_PERSISTENCE_SECTION,
        "",
        "## MEMORY.md",
        "",
    ]
    body = (
        entrypoint_text.strip()
        if entrypoint_text.strip()
        else "Your MEMORY.md is currently empty. When you save new memories, they will appear here."
    )
    return [*header, body]


def truncate_entrypoint_content(raw: str) -> EntrypointTruncation:
    return _truncate_entrypoint_content(raw)


def build_memory_lines(*, entrypoint_text: str, workspace_cfg: AgentWorkspaceConfig) -> list[str]:
    return MemoryPromptLoader(workspace_cfg).build_memory_lines(entrypoint_text)


def load_memory_prompt(workspace_cfg: AgentWorkspaceConfig) -> str | None:
    return MemoryPromptLoader(workspace_cfg).load_memory_prompt()


__all__ = [
    "EntrypointTruncation",
    "MAX_ENTRYPOINT_BYTES",
    "MAX_ENTRYPOINT_LINES",
    "MemoryPromptLoader",
    "build_memory_lines",
    "load_memory_prompt",
    "truncate_entrypoint_content",
]
