"""
memory/memdir/runtime.py — Layer 2 在 loop 侧的注入协作者。

职责：
    将 MemoryPromptLoader 适配为 `section("auto_memory")`，统一供 loop 工厂接线。

链路位置：
    LoopGraphBuilder._prepare_compile_context() -> MemoryPromptBootstrap.build_sections()。

当前裁剪范围：
    仅提供 Phase 2 的 prompt 注入，不包含 extractor/recall 链路。
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from langchain_agentx.workspace import resolve_agent_workspace_config

from .loader import MemoryPromptLoader

if TYPE_CHECKING:
    from langchain_agentx.loop.prompt.sections import SystemPromptSection


class MemoryPromptBootstrap:
    def __init__(self, *, workspace_root: str | Path, agent_home: str) -> None:
        self._workspace_root = workspace_root
        self._agent_home = agent_home

    def build_sections(self) -> list["SystemPromptSection"]:
        from langchain_agentx.loop.prompt.sections import section

        workspace_cfg = resolve_agent_workspace_config(
            workspace_root=self._workspace_root,
            agent_home=self._agent_home,
        )
        loader = MemoryPromptLoader(workspace_cfg)
        return [section("auto_memory", loader.load_memory_prompt)]


__all__ = ["MemoryPromptBootstrap"]
