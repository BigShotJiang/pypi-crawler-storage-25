"""
memory/memdir/age.py — Layer 2 记忆新鲜度文本。

职责：
    基于文件更新时间计算 age 文本，为 memory manifest 提供可读提示。

链路位置：
    scan/build_memory_lines 在组装输出时读取本模块结果。

当前裁剪范围：
    仅基于 mtime，不引入时区数据库或复杂本地化。
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path


def memory_age_days(path: Path, now: datetime | None = None) -> int:
    snapshot = now or datetime.now()
    mtime = datetime.fromtimestamp(path.stat().st_mtime)
    delta = snapshot - mtime
    return max(0, delta.days)


def memory_freshness_text(path: Path, now: datetime | None = None) -> str:
    days = memory_age_days(path, now=now)
    if days <= 0:
        return "updated today"
    if days == 1:
        return "updated yesterday"
    return f"updated {days} days ago"


__all__ = ["memory_age_days", "memory_freshness_text"]
