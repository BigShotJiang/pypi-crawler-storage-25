"""
memory/memdir/paths.py — Layer 2 路径与启用门禁。

职责：
    提供 memdir 启用判断与路径安全校验，作为 Layer 2 的统一入口。

链路位置：
    loader/extractor 调用本模块判断是否启用与路径是否在 memory_dir 内。

当前裁剪范围：
    仅覆盖本地路径语义与环境变量门禁，不包含远端 feature flag。
"""

from __future__ import annotations

import os
from pathlib import Path

from langchain_agentx.workspace import AgentWorkspaceConfig


class MemoryPathResolver:
    """Layer 2 路径解析与安全校验协作者。"""

    def __init__(self, workspace_cfg: AgentWorkspaceConfig) -> None:
        self._cfg = workspace_cfg
        self._memory_dir = self._cfg.memory_dir.resolve()

    def get_memory_dir(self) -> Path:
        return self._memory_dir

    def is_memory_path(self, candidate: str | Path) -> bool:
        try:
            resolved = Path(candidate).resolve()
        except (TypeError, OSError, RuntimeError):
            return False
        try:
            resolved.relative_to(self._memory_dir)
            return True
        except ValueError:
            return False


def is_memory_enabled(workspace_cfg: AgentWorkspaceConfig) -> bool:
    """Layer 2 是否启用：环境变量优先，默认启用。"""
    del workspace_cfg
    return os.environ.get("LANGCHAIN_AGENTX_DISABLE_MEMORY") != "1"


def get_memory_dir(workspace_cfg: AgentWorkspaceConfig) -> Path:
    return MemoryPathResolver(workspace_cfg).get_memory_dir()


def is_memory_path(candidate: str | Path, workspace_cfg: AgentWorkspaceConfig) -> bool:
    return MemoryPathResolver(workspace_cfg).is_memory_path(candidate)


__all__ = [
    "MemoryPathResolver",
    "get_memory_dir",
    "is_memory_enabled",
    "is_memory_path",
]
