"""
memory/memdir/recall.py — Layer 2 相关性召回接口空桩。

职责：
    提供 Phase 5 的稳定异步接口签名，供后续 side-query 召回实现复用。

链路位置：
    query 前召回路径将调用本模块（Phase 5 先空桩，不接入主链）。

当前裁剪范围：
    仅返回空结果，确保默认配置下行为不变。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


async def find_relevant_memories(
    *,
    query: str,
    memory_dir: Path,
    limit: int = 5,
    max_scan: int = 200,
    recent_tools: list[str] | None = None,
) -> list[dict[str, Any]]:
    del query, memory_dir, limit, max_scan, recent_tools
    return []


async def select_relevant_memories(
    *,
    query: str,
    manifest_text: str,
    limit: int = 5,
) -> list[str]:
    del query, manifest_text, limit
    return []


__all__ = [
    "find_relevant_memories",
    "select_relevant_memories",
]
