"""
memory/memdir/extractor.py — Layer 2 后台抽取协作者。

职责：
    在 loop stop 时以 fire-and-forget 触发记忆抽取，提供并发保护与 session 退出 drain。

链路位置：
    HookGraphWiring.stop_hooks_node() 触发 -> MemoryExtractionCoordinator 执行。

当前裁剪范围：
    Phase 4 先实现门禁链、游标推进、并发与 drain；抽取写入细节使用可注入执行器。
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
import logging
from pathlib import Path
from typing import Any, Awaitable, Callable

from langchain_agentx.workspace import AgentWorkspaceConfig

from .agent_memory import is_agent_memory_path
from .paths import is_memory_enabled
from .scan import format_memory_manifest, scan_memory_files
from .types import HOW_TO_SAVE_SECTION, TYPES_SECTION_INDIVIDUAL, WHAT_NOT_TO_SAVE_SECTION

logger = logging.getLogger(__name__)

_WRITE_TOOLS = {"Write", "Edit"}
_READ_TOOLS = {"Read", "Grep", "Glob"}
_READ_ONLY_BASH_PREFIX = ("ls", "find", "grep", "cat", "stat", "wc", "head", "tail")
DEFAULT_EXTRACTION_WINDOW_MESSAGES = 30


@dataclass(frozen=True)
class MemoryExtractionContext:
    session_id: str
    container_type: str
    workspace_cfg: AgentWorkspaceConfig
    messages: list[Any]
    agent_id: str | None = None


class MemoryExtractionCoordinator:
    def __init__(
        self,
        *,
        extraction_executor: Callable[[MemoryExtractionContext, list[Any]], Awaitable[None]] | None = None,
    ) -> None:
        self._executor = extraction_executor or _noop_extraction_executor
        self._in_progress = False
        self._pending_context: MemoryExtractionContext | None = None
        self._last_message_id: dict[str, str] = {}
        self._tasks: set[asyncio.Task[None]] = set()

    def trigger_from_state(
        self,
        *,
        state: dict[str, Any],
        workspace_cfg: AgentWorkspaceConfig,
        session_id: str,
        container_type: str,
    ) -> None:
        context = MemoryExtractionContext(
            session_id=session_id,
            container_type=container_type,
            workspace_cfg=workspace_cfg,
            messages=list(state.get("messages") or []),
            agent_id=state.get("agent_id"),
        )
        self.trigger(context)

    def trigger(self, context: MemoryExtractionContext) -> None:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            logger.warning("skip memory extraction trigger: no running event loop")
            return
        task = loop.create_task(self.execute_extract_memories(context))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def execute_extract_memories(self, context: MemoryExtractionContext) -> None:
        if not self._can_extract(context):
            return
        if self._in_progress:
            # 单槽覆盖语义：只保留最新上下文。
            self._pending_context = context
            return
        self._in_progress = True
        try:
            current = context
            while True:
                await self._execute_once(current)
                if self._pending_context is None:
                    break
                current = self._pending_context
                self._pending_context = None
        finally:
            self._in_progress = False

    async def drain_pending_extraction(self, timeout_ms: int = 60_000) -> None:
        if not self._tasks:
            return
        try:
            await asyncio.wait_for(
                asyncio.gather(*list(self._tasks), return_exceptions=True),
                timeout=timeout_ms / 1000.0,
            )
        except asyncio.TimeoutError:
            logger.warning("memory extraction drain timed out after %sms", timeout_ms)

    async def _execute_once(self, context: MemoryExtractionContext) -> None:
        new_messages = self._messages_since_cursor(context)
        if not new_messages:
            return
        if self._has_memory_writes_since(context, new_messages):
            self._advance_cursor(context, new_messages)
            return
        await self._executor(context, new_messages)
        self._advance_cursor(context, new_messages)

    def _can_extract(self, context: MemoryExtractionContext) -> bool:
        if context.container_type not in ("interactive", "conversation"):
            return False
        if context.agent_id:
            return False
        return is_memory_enabled(context.workspace_cfg)

    def _messages_since_cursor(self, context: MemoryExtractionContext) -> list[Any]:
        if not context.messages:
            return []
        session_key = self._session_key(context)
        cursor = self._last_message_id.get(session_key) or self._load_cursor(context)
        if cursor is None:
            return context.messages
        for idx, message in enumerate(context.messages):
            if self._message_id(message) == cursor:
                return context.messages[idx + 1 :]
        return context.messages

    def _advance_cursor(self, context: MemoryExtractionContext, messages: list[Any]) -> None:
        last_id = self._message_id(messages[-1])
        if not last_id:
            return
        session_key = self._session_key(context)
        self._last_message_id[session_key] = last_id
        if context.container_type == "conversation":
            cursor_path = context.workspace_cfg.sessions_dir / f"{context.session_id}.cursor"
            cursor_path.parent.mkdir(parents=True, exist_ok=True)
            cursor_path.write_text(last_id, encoding="utf-8")

    def _load_cursor(self, context: MemoryExtractionContext) -> str | None:
        if context.container_type != "conversation":
            return None
        path = context.workspace_cfg.sessions_dir / f"{context.session_id}.cursor"
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8").strip() or None

    @staticmethod
    def _session_key(context: MemoryExtractionContext) -> str:
        return f"{context.container_type}:{context.session_id}"

    @staticmethod
    def _message_id(message: Any) -> str | None:
        if isinstance(message, dict):
            value = message.get("id")
            return str(value) if value else None
        value = getattr(message, "id", None)
        return str(value) if value else None

    @staticmethod
    def _has_memory_writes_since(context: MemoryExtractionContext, messages: list[Any]) -> bool:
        for message in messages:
            calls = []
            if isinstance(message, dict):
                calls = list(message.get("tool_calls") or [])
            else:
                calls = list(getattr(message, "tool_calls", None) or [])
            for call in calls:
                if _is_memory_write_call(call, context.workspace_cfg):
                    return True
        return False


def create_auto_mem_can_use_tool(memory_dir: Path) -> Callable[[str, dict[str, Any]], bool]:
    resolved_memory_dir = memory_dir.resolve()

    def _can_use(tool_name: str, tool_input: dict[str, Any]) -> bool:
        if tool_name in _READ_TOOLS:
            return True
        if tool_name == "Bash":
            command = str(tool_input.get("command") or "").strip()
            return command.startswith(_READ_ONLY_BASH_PREFIX)
        if tool_name in _WRITE_TOOLS:
            candidate = tool_input.get("path") or tool_input.get("file_path")
            if candidate is None:
                return False
            try:
                Path(candidate).resolve().relative_to(resolved_memory_dir)
                return True
            except (ValueError, OSError, RuntimeError, TypeError):
                return False
        return False

    return _can_use


async def _noop_extraction_executor(
    context: MemoryExtractionContext, messages: list[Any]
) -> None:
    prompt = build_extract_prompt(
        workspace_cfg=context.workspace_cfg,
        window_messages=min(DEFAULT_EXTRACTION_WINDOW_MESSAGES, len(messages)),
    )
    logger.info(
        "memory extraction placeholder executor triggered session=%s container=%s prompt_chars=%s message_count=%s",
        context.session_id,
        context.container_type,
        len(prompt),
        len(messages),
    )
    return None


_DEFAULT_COORDINATOR = MemoryExtractionCoordinator()


async def execute_extract_memories(context: MemoryExtractionContext) -> None:
    await _DEFAULT_COORDINATOR.execute_extract_memories(context)


async def drain_pending_extraction(timeout_ms: int = 60_000) -> None:
    await _DEFAULT_COORDINATOR.drain_pending_extraction(timeout_ms=timeout_ms)


def _is_memory_write_call(call: Any, workspace_cfg: AgentWorkspaceConfig) -> bool:
    if isinstance(call, dict):
        name = str(call.get("name") or call.get("tool_name") or "")
        args = call.get("args") or call.get("tool_input") or {}
    else:
        name = str(getattr(call, "name", "") or getattr(call, "tool_name", ""))
        args = getattr(call, "args", None) or getattr(call, "tool_input", None) or {}
    if name not in _WRITE_TOOLS:
        return False
    if not isinstance(args, dict):
        return False
    candidate = args.get("path") or args.get("file_path")
    if not candidate:
        return False
    try:
        resolved = Path(candidate).resolve()
        if is_agent_memory_path(workspace_cfg, resolved):
            return True
        resolved.relative_to(workspace_cfg.memory_dir.resolve())
        return True
    except (ValueError, OSError, RuntimeError, TypeError):
        return False


def build_extract_prompt(
    *,
    workspace_cfg: AgentWorkspaceConfig,
    window_messages: int = DEFAULT_EXTRACTION_WINDOW_MESSAGES,
) -> str:
    headers = scan_memory_files(workspace_cfg.memory_dir)
    manifest = format_memory_manifest(headers)
    opener = (
        "You are now acting as the memory extraction subagent. Analyze the most recent\n"
        f"~{window_messages} messages above and use them to update your persistent memory systems.\n\n"
        "Available tools: Read, Grep, Glob, read-only Bash (ls/find/cat/stat/wc/head/tail\n"
        "and similar), and Edit/Write for paths inside the memory directory only.\n"
        "Bash rm is not permitted. All other tools — MCP, Agent, write-capable Bash,\n"
        "etc — will be denied.\n\n"
        "You have a limited turn budget. Edit requires a prior Read of the same file,\n"
        "so the efficient strategy is: turn 1 — issue all Read calls in parallel for\n"
        "every file you might update; turn 2 — issue all Write/Edit calls in parallel.\n"
        "Do not interleave reads and writes across multiple turns.\n"
    )
    existing = ""
    if manifest:
        existing = (
            "\n\n## Existing memory files\n\n"
            f"{manifest}\n\n"
            "Check this list before writing — update an existing file rather than creating\n"
            "a duplicate."
        )
    body = (
        "If the user explicitly asks you to remember something, save it immediately as\n"
        "whichever type fits best. If they ask you to forget something, find and remove\n"
        "the relevant entry.\n\n"
        f"{TYPES_SECTION_INDIVIDUAL}\n\n"
        f"{WHAT_NOT_TO_SAVE_SECTION}\n\n"
        f"{HOW_TO_SAVE_SECTION}"
    )
    return opener + existing + "\n\n" + body


__all__ = [
    "MemoryExtractionContext",
    "MemoryExtractionCoordinator",
    "build_extract_prompt",
    "create_auto_mem_can_use_tool",
    "drain_pending_extraction",
    "execute_extract_memories",
]
