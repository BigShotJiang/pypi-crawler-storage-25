"""instruction/loader.py — Layer 1 规则加载编排。

职责：
    负责规则文件加载、@path 展开、frontmatter 路径解析与条件规则筛选。

链路位置：
    Loop 初始化 -> load_rule_set(...) -> LoadedRuleSet -> sections 组装。

当前裁剪范围：
    仅处理 Layer 1 文本加载与匹配，不解析规则业务语义。
"""

from __future__ import annotations

import re
from pathlib import Path

from wcmatch import glob as wcglob

from langchain_agentx.utils.path_hierarchy import is_filesystem_root

from .resolver import resolve_rules_file_name
from .types import ConditionalRule, InstructionMemoryConfig, LoadedRuleSet, RuleFile, RuleLayer

_AT_PATH_RE = re.compile(r"(?:^|\s)@((?:[^\s\\]|\\ )+)")
_HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)


class ProjectRuleCollector:
    """Project 规则文件收集器（workspace_root 向上遍历）。"""

    def collect(self, *, workspace_root: Path, agent_home: str, rules_file: str) -> list[Path]:
        found: list[Path] = []
        current = workspace_root.resolve()
        while True:
            candidate = current / agent_home / rules_file
            if candidate.exists():
                found.append(candidate)
            if is_filesystem_root(current):
                break
            current = current.parent
        found.reverse()
        return found


class AtPathResolver:
    """`@path` 路径解析器（支持 ~/、绝对路径、fragment、转义空格）。"""

    def resolve(self, *, raw: str, current_file: Path) -> Path:
        normalized = raw.replace(r"\ ", " ")
        normalized = normalized.split("#")[0]
        p = Path(normalized)
        if p.is_absolute():
            return p.resolve()
        if normalized.startswith("~/"):
            return (Path.home() / normalized[2:]).resolve()
        return (current_file.parent / p).resolve()


class AtPathProcessor:
    """`@path` 行内展开器（代码块内跳过，循环/缺失文件保留原文）。"""

    def __init__(self, *, depth_limit: int, resolver: AtPathResolver | None = None) -> None:
        self._depth_limit = depth_limit
        self._resolver = resolver or AtPathResolver()

    def process(
        self,
        *,
        current_path: Path,
        content: str,
        visited: frozenset[Path],
        depth: int,
    ) -> str:
        if depth > self._depth_limit:
            return content

        lines: list[str] = []
        in_code_block = False
        for line in content.splitlines(keepends=True):
            stripped = line.rstrip("\n\r")
            if stripped.startswith("```") or stripped.startswith("~~~"):
                in_code_block = not in_code_block
                lines.append(line)
                continue
            if in_code_block:
                lines.append(line)
                continue
            matches = _AT_PATH_RE.findall(stripped)
            if not matches:
                lines.append(line)
                continue
            result_line = line
            for raw in matches:
                resolved = self._resolver.resolve(raw=raw, current_file=current_path)
                if resolved in visited:
                    continue
                if not resolved.exists():
                    continue
                included = resolved.read_text(encoding="utf-8")
                expanded = self.process(
                    current_path=resolved,
                    content=included,
                    visited=visited | {resolved},
                    depth=depth + 1,
                )
                result_line = result_line.replace(f"@{raw}", expanded, 1)
            lines.append(result_line)
        return "".join(lines)


def strip_html_comments(content: str) -> str:
    return _HTML_COMMENT_RE.sub('', content)


class FrontmatterPathsParser:
    def parse(self, raw: str) -> tuple[str, list[str]]:
        """解析 frontmatter，返回 (去除 frontmatter 的正文, paths 列表)。"""
        lines = raw.splitlines(keepends=True)
        if len(lines) < 3 or lines[0].strip() != "---":
            return raw, []
        end_idx = None
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                end_idx = i
                break
        if end_idx is None:
            return raw, []

        fm_block = "".join(lines[1:end_idx])
        content = "".join(lines[end_idx + 1:])
        patterns = self._parse_paths_block(fm_block)
        return content, patterns

    def parse_paths(self, raw: str) -> list[str]:
        _, patterns = self.parse(raw)
        return patterns

    def _parse_paths_block(self, fm_block: str) -> list[str]:
        fm_lines = fm_block.splitlines()
        in_paths = False
        patterns: list[str] = []
        for line in fm_lines:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("paths:"):
                direct = stripped[len("paths:"):].strip()
                if direct:
                    patterns.extend(self._split_inline_paths(direct))
                in_paths = True
                continue
            if in_paths:
                if stripped.startswith("- "):
                    val = stripped[2:].strip().strip("'").strip('"')
                    if val:
                        patterns.append(val)
                else:
                    in_paths = False
        return patterns

    @staticmethod
    def _split_inline_paths(raw: str) -> list[str]:
        # 支持 paths: "a,b" 或 paths: a,b；逗号分隔时忽略空白项。
        normalized = raw.strip().strip("'").strip('"')
        if not normalized:
            return []
        return [part.strip() for part in normalized.split(",") if part.strip()]


def _path_matches_pattern(file_path: str, pattern: str) -> bool:
    return wcglob.globmatch(file_path, pattern, flags=wcglob.GLOBSTAR)


def _parse_paths_from_frontmatter(raw: str) -> list[str]:
    return FrontmatterPathsParser().parse_paths(raw)


def get_active_conditional_rules(
    conditional_rules: list[ConditionalRule],
    active_files: list[str],
) -> list[ConditionalRule]:
    result: list[ConditionalRule] = []
    for rule in conditional_rules:
        if not rule.paths_patterns:
            result.append(rule)
            continue
        if any(
            _path_matches_pattern(f, pattern)
            for f in active_files
            for pattern in rule.paths_patterns
        ):
            result.append(rule)
    return result


class InstructionRuleLoader:
    def __init__(
        self,
        *,
        cfg: InstructionMemoryConfig,
        frontmatter_parser: FrontmatterPathsParser | None = None,
        project_collector: ProjectRuleCollector | None = None,
        at_path_processor: AtPathProcessor | None = None,
    ) -> None:
        self._cfg = cfg
        self._frontmatter_parser = frontmatter_parser or FrontmatterPathsParser()
        self._project_collector = project_collector or ProjectRuleCollector()
        self._at_path_processor = at_path_processor or AtPathProcessor(
            depth_limit=cfg.include_depth_limit
        )

    def load(self) -> LoadedRuleSet:
        ws = self._cfg.workspace_cfg
        rules_file, local_file, rules_dir_name = resolve_rules_file_name(ws.agent_home)

        user_rf: RuleFile | None = None
        if self._cfg.load_user_layer:
            user_path = Path.home() / ws.agent_home / rules_file
            if user_path.exists():
                user_rf = self._load_file(user_path, RuleLayer.USER)

        project_paths = self._project_collector.collect(
            workspace_root=ws.workspace_root,
            agent_home=ws.agent_home,
            rules_file=rules_file,
        )
        project_files = [
            self._load_file(p, RuleLayer.PROJECT) for p in project_paths
        ]

        local_path = ws.agent_home_dir / local_file
        local_rf = self._load_file(local_path, RuleLayer.LOCAL) if local_path.exists() else None

        rules_dir = ws.agent_home_dir / rules_dir_name
        conditional = self._load_conditional_rules(rules_dir)

        return LoadedRuleSet(
            managed=self._cfg.managed_rules,
            user=user_rf,
            project_files=project_files,
            local=local_rf,
            conditional_rules=conditional,
        )

    def _load_file(self, path: Path, layer: RuleLayer) -> RuleFile:
        raw = path.read_text(encoding="utf-8")
        content_wo_frontmatter, _ = self._frontmatter_parser.parse(raw)
        content = self._at_path_processor.process(
            current_path=path,
            content=content_wo_frontmatter,
            visited=frozenset([path.resolve()]),
            depth=0,
        )
        return RuleFile(path=path, content=content, source_layer=layer)

    def _load_conditional_rules(self, rules_dir: Path) -> list[ConditionalRule]:
        if not rules_dir.exists() or not rules_dir.is_dir():
            return []
        result: list[ConditionalRule] = []
        for file_path in sorted(rules_dir.glob("*.md"), key=lambda p: p.name):
            raw = file_path.read_text(encoding="utf-8")
            content_wo_frontmatter, patterns = self._frontmatter_parser.parse(raw)
            content = self._at_path_processor.process(
                current_path=file_path,
                content=content_wo_frontmatter,
                visited=frozenset([file_path.resolve()]),
                depth=0,
            )
            result.append(ConditionalRule(path=file_path, content=content, paths_patterns=patterns))
        return result


def load_rule_set(cfg: InstructionMemoryConfig) -> LoadedRuleSet:
    return InstructionRuleLoader(cfg=cfg).load()


def load_conditional_rules(rules_dir: Path, depth_limit: int) -> list[ConditionalRule]:
    if not rules_dir.exists() or not rules_dir.is_dir():
        return []
    parser = FrontmatterPathsParser()
    processor = AtPathProcessor(depth_limit=depth_limit)
    result: list[ConditionalRule] = []
    for file_path in sorted(rules_dir.glob("*.md"), key=lambda p: p.name):
        raw = file_path.read_text(encoding="utf-8")
        content_wo_frontmatter, patterns = parser.parse(raw)
        content = processor.process(
            current_path=file_path,
            content=content_wo_frontmatter,
            visited=frozenset([file_path.resolve()]),
            depth=0,
        )
        result.append(ConditionalRule(path=file_path, content=content, paths_patterns=patterns))
    return result


def collect_project_rule_files(
    workspace_root: Path,
    agent_home: str,
    rules_file: str,
) -> list[Path]:
    return ProjectRuleCollector().collect(
        workspace_root=workspace_root,
        agent_home=agent_home,
        rules_file=rules_file,
    )


def _resolve_at_path(raw: str, current_file: Path) -> Path:
    return AtPathResolver().resolve(raw=raw, current_file=current_file)


def process_at_paths(
    current_path: Path,
    content: str,
    visited: frozenset[Path],
    depth: int,
    depth_limit: int,
) -> str:
    return AtPathProcessor(depth_limit=depth_limit).process(
        current_path=current_path,
        content=content,
        visited=visited,
        depth=depth,
    )
