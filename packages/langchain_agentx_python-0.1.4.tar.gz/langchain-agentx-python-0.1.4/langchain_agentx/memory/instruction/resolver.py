"""instruction/resolver.py — Layer 1 规则文件名解析器。

职责：
    基于 agent_home 返回主规则文件、本地规则文件、rules 目录名映射。

链路位置：
    InstructionRuleLoader.load() -> resolve_rules_file_name(...)。

当前裁剪范围：
    仅做名称映射，不执行目录扫描与存在性回退。
"""

from __future__ import annotations

_AGENT_HOME_MAP: dict[str, tuple[str, str, str]] = {
    ".claude": ("CLAUDE.md", "CLAUDE.local.md", "rules"),
    ".cursor": (".cursorrules", ".cursorrules.local", "rules"),
}
_DEFAULT = ("AGENT.md", "AGENT.local.md", "rules")


def resolve_rules_file_name(agent_home: str) -> tuple[str, str, str]:
    return _AGENT_HOME_MAP.get(agent_home, _DEFAULT)

