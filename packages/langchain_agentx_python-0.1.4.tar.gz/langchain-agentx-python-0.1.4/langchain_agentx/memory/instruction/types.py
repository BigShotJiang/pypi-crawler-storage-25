"""instruction/types.py — Layer 1 指令规则核心数据模型。

职责：
    定义规则来源层、单文件结果、条件规则、完整加载结果与配置入口。

链路位置：
    resolver/loader/sections 之间共享的契约层。

当前裁剪范围：
    仅数据建模，不包含任何 IO 或匹配逻辑。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from langchain_agentx.workspace import AgentWorkspaceConfig


class RuleLayer(str, Enum):
    MANAGED = "managed"
    USER = "user"
    PROJECT = "project"
    RULES = "rules"
    LOCAL = "local"


@dataclass(frozen=True)
class RuleFile:
    path: Path | None
    content: str
    source_layer: RuleLayer


@dataclass(frozen=True)
class ConditionalRule:
    path: Path
    content: str
    paths_patterns: list[str]


@dataclass(frozen=True)
class LoadedRuleSet:
    managed: str | None
    user: RuleFile | None
    project_files: list[RuleFile]  # root → workspace_root order; workspace_root has highest priority
    local: RuleFile | None
    conditional_rules: list[ConditionalRule]


@dataclass(frozen=True)
class InstructionMemoryConfig:
    workspace_cfg: AgentWorkspaceConfig
    managed_rules: str | None = None
    load_user_layer: bool = True
    include_depth_limit: int = 5

