"""instruction/runtime.py — Layer 1 在 loop 侧的接线协作者。

职责：
    封装 Instruction Memory 在运行时的配置解析与 section 构建，避免工厂内联拼装。

链路位置：
    LoopGraphBuilder.__init__ -> InstructionMemoryBootstrap.build_sections()。

当前裁剪范围：
    提供默认 active_files 提供器（空列表），具体会话采集策略由上层注入。
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from langchain_agentx.loop.prompt import SystemPromptSection
from langchain_agentx.workspace import resolve_agent_workspace_config

from .loader import load_rule_set
from .sections import make_instruction_sections
from .types import InstructionMemoryConfig


class InstructionMemoryBootstrap:
    def __init__(
        self,
        *,
        workspace_root: str | Path,
        agent_home: str,
        managed_rules: str | None,
        include_depth_limit: int = 5,
        active_files_provider: "ActiveFilesProvider | None" = None,
    ) -> None:
        self._workspace_root = workspace_root
        self._agent_home = agent_home
        self._managed_rules = managed_rules
        self._include_depth_limit = include_depth_limit
        self._active_files_provider = active_files_provider or NullActiveFilesProvider()

    def build_sections(self) -> list[SystemPromptSection]:
        workspace_cfg = resolve_agent_workspace_config(
            workspace_root=self._workspace_root,
            agent_home=self._agent_home,
        )
        loaded_rules = load_rule_set(
            InstructionMemoryConfig(
                workspace_cfg=workspace_cfg,
                managed_rules=self._managed_rules,
                load_user_layer=True,
                include_depth_limit=self._include_depth_limit,
            )
        )
        return make_instruction_sections(
            loaded_rules,
            active_files_getter=self._active_files_provider.get_active_files,
        )


class ActiveFilesProvider:
    """active_files 提供器接口。"""

    def get_active_files(self) -> list[str]:
        raise NotImplementedError()


class NullActiveFilesProvider(ActiveFilesProvider):
    """默认 provider：无会话文件上下文时返回空列表。"""

    def get_active_files(self) -> list[str]:
        return []


class CallbackActiveFilesProvider(ActiveFilesProvider):
    """通过回调函数桥接外部会话上下文。"""

    def __init__(self, getter: Callable[[], list[str]]) -> None:
        self._getter = getter

    def get_active_files(self) -> list[str]:
        return list(self._getter() or [])

