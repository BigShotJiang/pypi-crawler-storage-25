"""instruction/sections.py — Layer 1 规则段装配器。

职责：
    将 LoadedRuleSet 按静态/动态规则拆分为可缓存的 prompt sections。

链路位置：
    load_rule_set(...) -> make_instruction_sections(...) -> build_effective_system_prompt(...)。

当前裁剪范围：
    仅负责文本组装，不负责文件加载与 active_files 维护。
"""

from __future__ import annotations

from collections.abc import Callable

from langchain_agentx.loop.prompt import SystemPromptSection, section, volatile_section

from .loader import get_active_conditional_rules, strip_html_comments
from .types import LoadedRuleSet


class InstructionSectionBuilder:
    def __init__(
        self,
        *,
        rule_set: LoadedRuleSet,
        active_files_getter: Callable[[], list[str]],
    ) -> None:
        self._rule_set = rule_set
        self._active_files_getter = active_files_getter

    def build_static_rules(self) -> str | None:
        parts: list[str] = []
        if self._rule_set.managed:
            parts.append(strip_html_comments(self._rule_set.managed))
        if self._rule_set.user:
            parts.append(strip_html_comments(self._rule_set.user.content))
        for rf in self._rule_set.project_files:
            parts.append(strip_html_comments(rf.content))
        if self._rule_set.local:
            parts.append(strip_html_comments(self._rule_set.local.content))
        for rule in self._rule_set.conditional_rules:
            if not rule.paths_patterns:
                parts.append(strip_html_comments(rule.content))
        return "".join(parts) if parts else None

    def build_conditional_rules(self) -> str | None:
        dynamic_rules = [
            r
            for r in get_active_conditional_rules(
                self._rule_set.conditional_rules,
                self._active_files_getter(),
            )
            if r.paths_patterns
        ]
        if not dynamic_rules:
            return None
        return "".join(strip_html_comments(r.content) for r in dynamic_rules)

    def build_sections(self) -> list[SystemPromptSection]:
        return [
            section(
                name="agent_rules_static",
                compute=self.build_static_rules,
            ),
            volatile_section(
                name="agent_rules_conditional",
                compute=self.build_conditional_rules,
                reason="active_files changes as session progresses; paths matching must re-evaluate each turn",
            ),
        ]


def make_instruction_sections(
    rule_set: LoadedRuleSet,
    active_files_getter: Callable[[], list[str]],
) -> list[SystemPromptSection]:
    return InstructionSectionBuilder(
        rule_set=rule_set,
        active_files_getter=active_files_getter,
    ).build_sections()

