"""
evaluation/retention_scheduler.py — 诊断存储清理调度器。

职责：
    以固定周期执行 trace session 分层保留策略清理，避免数据库无限增长。

链路位置：
    FastAPI lifespan -> RetentionScheduler.start()。

当前裁剪范围：
    仅清理 trace_sessions/trace_spans。SDK 已提供 ``EvaluationStore.cleanup_old_reports``（OB-D10），本模块 **仍不** 调用；诊断报告时间清理仅由显式 ``TraceCleanupTask(... cleanup_diagnostic_reports=True)`` 等路径触发。
"""

from __future__ import annotations

import asyncio
import logging

from langchain_agentx.observability.trace.sqlite_store import SqliteTraceStore

logger = logging.getLogger(__name__)


class RetentionScheduler:
    """按周期执行 session retention 清理任务。"""

    def __init__(
        self,
        *,
        trace_store: SqliteTraceStore,
        interval_seconds: int = 24 * 3600,
        failed_days: int = 180,
        normal_days: int = 30,
    ) -> None:
        self._trace_store = trace_store
        self._interval_seconds = int(interval_seconds)
        self._failed_days = int(failed_days)
        self._normal_days = int(normal_days)
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop())

    def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            self._task = None

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(self._interval_seconds)
            try:
                deleted = self._trace_store.cleanup_sessions_by_retention(
                    failed_days=self._failed_days,
                    normal_days=self._normal_days,
                )
                logger.info(
                    "RetentionScheduler cleanup done deleted=%s failed_days=%s normal_days=%s",
                    deleted,
                    self._failed_days,
                    self._normal_days,
                )
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("RetentionScheduler cleanup failed")
