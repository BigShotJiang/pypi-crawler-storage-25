"""ExitQualityChecker — 检查 session 退出质量。"""

from __future__ import annotations

from ...trace.models import TraceSession, TraceSpan
from .base import BaseChecker, CheckResult


class ExitQualityChecker(BaseChecker):
    name = "exit_quality"
    description = "检查 session 退出质量"

    def check(self, session: TraceSession, spans: list[TraceSpan]) -> CheckResult:
        del spans
        reason = session.finish_reason

        if reason == "error":
            return CheckResult(
                self.name,
                "fail",
                "session 以 error 退出",
                evidence={"terminal_reason": session.terminal_reason},
            )
        if reason == "max_steps":
            return CheckResult(
                self.name,
                "warn",
                "session 触发 max_steps 退出，可能 loop 卡住",
                evidence={"loop_count": session.loop_count},
            )
        if reason == "end_turn":
            return CheckResult(self.name, "pass", "session 正常退出")

        return CheckResult(
            self.name,
            "skip",
            f"未知 finish_reason: {reason}",
            evidence={"finish_reason": reason},
        )


__all__ = ["ExitQualityChecker"]
