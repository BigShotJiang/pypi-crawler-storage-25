"""CompactionChecker — 检查上下文压缩是否按预期执行。"""

from __future__ import annotations

from ...trace.models import SpanStatus, SpanType, TraceSession, TraceSpan
from .base import BaseChecker, CheckResult

_LOOP_COUNT_THRESHOLD = 20


class CompactionChecker(BaseChecker):
    name = "compaction"
    description = "检查上下文压缩是否按预期执行"

    def check(self, session: TraceSession, spans: list[TraceSpan]) -> CheckResult:
        compaction_spans = [span for span in spans if span.span_type == SpanType.COMPACTION]

        if session.loop_count > _LOOP_COUNT_THRESHOLD and not compaction_spans:
            return CheckResult(
                self.name,
                "warn",
                f"loop_count={session.loop_count} 但无 compaction span",
                evidence={"loop_count": session.loop_count},
            )

        failed = [span for span in compaction_spans if span.status == SpanStatus.FAILED]
        if failed:
            return CheckResult(
                self.name,
                "fail",
                "compaction 执行失败",
                evidence={"error": failed[0].error},
            )

        return CheckResult(self.name, "pass", "compaction 正常")


__all__ = ["CompactionChecker"]
