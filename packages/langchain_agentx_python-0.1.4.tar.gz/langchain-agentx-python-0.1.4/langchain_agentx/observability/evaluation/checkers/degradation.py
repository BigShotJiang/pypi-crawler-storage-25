"""DegradationChecker — 检查 tool_call 退化情况。"""

from __future__ import annotations

from ...trace.models import SpanType, TraceSession, TraceSpan
from .base import BaseChecker, CheckResult

_DEGRADATION_RATE_THRESHOLD = 0.2


class DegradationChecker(BaseChecker):
    name = "degradation"
    description = "检查 tool_call 退化率"

    def check(self, session: TraceSession, spans: list[TraceSpan]) -> CheckResult:
        del session
        llm_spans = [span for span in spans if span.span_type == SpanType.LLM_CALL]
        if not llm_spans:
            return CheckResult(self.name, "skip", "无 LLM 调用记录")

        degraded: list[TraceSpan] = []
        for span in llm_spans:
            degradation_meta = (span.metadata or {}).get("degradation")
            if isinstance(degradation_meta, dict):
                if bool(degradation_meta.get("detected")):
                    degraded.append(span)
            elif degradation_meta is True:
                degraded.append(span)
        rate = len(degraded) / len(llm_spans)

        if rate > _DEGRADATION_RATE_THRESHOLD:
            tool_dist: dict[str, int] = {}
            for span in degraded:
                raw_tools = (span.metadata or {}).get("tool_names")
                if isinstance(raw_tools, list) and raw_tools:
                    tool_name = str(raw_tools[0])
                else:
                    tool_name = str((span.metadata or {}).get("tool_name", "unknown"))
                tool_dist[tool_name] = tool_dist.get(tool_name, 0) + 1
            return CheckResult(
                self.name,
                "fail",
                f"tool_call 退化率 {rate:.0%} 超过阈值",
                evidence={"degradation_rate": rate, "tool_distribution": tool_dist},
            )

        return CheckResult(self.name, "pass", "退化率正常")


__all__ = ["DegradationChecker"]
