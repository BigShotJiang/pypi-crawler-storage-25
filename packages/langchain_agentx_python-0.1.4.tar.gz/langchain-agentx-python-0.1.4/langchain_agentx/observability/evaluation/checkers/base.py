"""
checkers/base.py — Checker 基类与 CheckResult 数据模型。

职责：
    定义所有 Checker 的统一接口契约和结果数据结构。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Literal

from ...trace.models import TraceSession, TraceSpan


@dataclass
class CheckResult:
    checker_name: str
    status: Literal["pass", "fail", "warn", "skip"]
    message: str
    evidence: dict[str, Any] = field(default_factory=dict)


class BaseChecker(ABC):
    name: str
    description: str

    @abstractmethod
    def check(self, session: TraceSession, spans: list[TraceSpan]) -> CheckResult:
        """执行单项检查并返回结果。"""


__all__ = ["BaseChecker", "CheckResult"]
