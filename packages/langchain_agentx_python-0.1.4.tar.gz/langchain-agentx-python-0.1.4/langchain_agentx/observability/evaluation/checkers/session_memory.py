"""SessionMemoryTriggerChecker — 检查 session memory 是否在应触发时触发。"""

from __future__ import annotations

from ...trace.models import SpanStatus, SpanType, TraceSession, TraceSpan
from .base import BaseChecker, CheckResult

_FIRST_TRIGGER_TOKENS = 10_000


class SessionMemoryTriggerChecker(BaseChecker):
    name = "session_memory_trigger"
    description = "检查 session memory 是否在应触发时触发"

    def check(self, session: TraceSession, spans: list[TraceSpan]) -> CheckResult:
        if session.total_input_tokens < _FIRST_TRIGGER_TOKENS:
            return CheckResult(self.name, "skip", "token 未达首次触发阈值")

        memory_spans = [
            span
            for span in spans
            if span.span_type == SpanType.TASK_EVENT and span.name == "session_memory_extraction"
        ]

        if not memory_spans:
            return CheckResult(
                self.name,
                "fail",
                "应触发 session memory 但无对应 span",
                evidence={"total_input_tokens": session.total_input_tokens},
            )

        failed = [span for span in memory_spans if span.status == SpanStatus.FAILED]
        if failed:
            return CheckResult(
                self.name,
                "warn",
                f"{len(failed)} 次 session memory 抽取失败",
                evidence={"failed_spans": [span.span_id for span in failed]},
            )

        return CheckResult(self.name, "pass", "session memory 触发正常")


__all__ = ["SessionMemoryTriggerChecker"]
