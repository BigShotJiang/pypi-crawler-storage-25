"""ToolBehaviorChecker — 检查工具调用是否符合契约。"""

from __future__ import annotations

from collections import defaultdict

from ...trace.models import SpanStatus, SpanType, TraceSession, TraceSpan
from .base import BaseChecker, CheckResult

_FAIL_RATE_THRESHOLD = 0.3
_CONSECUTIVE_FAIL_THRESHOLD = 3


class ToolBehaviorChecker(BaseChecker):
    name = "tool_behavior"
    description = "检查工具调用失败率与连续失败"

    def check(self, session: TraceSession, spans: list[TraceSpan]) -> CheckResult:
        del session  # 与统一签名保持一致，当前 checker 不依赖 session 聚合字段。
        tool_spans = [span for span in spans if span.span_type == SpanType.TOOL_CALL]
        if not tool_spans:
            return CheckResult(self.name, "skip", "无工具调用")

        failed = [span for span in tool_spans if span.status == SpanStatus.FAILED]
        fail_rate = len(failed) / len(tool_spans)

        if fail_rate > _FAIL_RATE_THRESHOLD:
            return CheckResult(
                self.name,
                "fail",
                f"工具调用失败率 {fail_rate:.0%} 超过阈值",
                evidence={"fail_rate": fail_rate, "total": len(tool_spans), "failed": len(failed)},
            )

        consecutive: dict[str, int] = defaultdict(int)
        for span in tool_spans:
            tool_name = str((span.metadata or {}).get("tool_name", "unknown"))
            if span.status == SpanStatus.FAILED:
                consecutive[tool_name] += 1
                if consecutive[tool_name] >= _CONSECUTIVE_FAIL_THRESHOLD:
                    return CheckResult(
                        self.name,
                        "fail",
                        f"工具 {tool_name} 连续失败 {consecutive[tool_name]} 次",
                        evidence={"tool_name": tool_name, "consecutive_fails": consecutive[tool_name]},
                    )
            else:
                consecutive[tool_name] = 0

        return CheckResult(self.name, "pass", "工具调用行为正常")


__all__ = ["ToolBehaviorChecker"]
