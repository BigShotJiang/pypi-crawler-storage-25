"""
evaluation/service.py — EvaluationService，评估系统入口。

职责：
    接收 session_end 信号，拉取 spans，逐个跑 Checker，并将结果写入 EvaluationStore。

链路位置：
    由 after_session_end hook 触发（fire-and-forget），不阻塞主 Loop。

当前裁剪范围：
    LlmDiagnosticAnalyzer 仅保留触发位，暂不实现诊断正文生成。
"""

from __future__ import annotations

import logging

from ..trace.collector import TraceCollector
from .checkers.base import BaseChecker, CheckResult
from .checkers.compaction import CompactionChecker
from .checkers.degradation import DegradationChecker
from .checkers.exit_quality import ExitQualityChecker
from .checkers.session_memory import SessionMemoryTriggerChecker
from .checkers.tool_behavior import ToolBehaviorChecker
from .store import EvaluationStore

logger = logging.getLogger(__name__)

_DEFAULT_CHECKERS: list[BaseChecker] = [
    SessionMemoryTriggerChecker(),
    CompactionChecker(),
    ToolBehaviorChecker(),
    ExitQualityChecker(),
    DegradationChecker(),
]


class EvaluationService:
    """评估系统入口。评估失败需静默降级，不影响主 Loop。"""

    def __init__(
        self,
        store: EvaluationStore,
        trace_collector: TraceCollector,
        checkers: list[BaseChecker] | None = None,
        scheduler: object | None = None,
    ) -> None:
        self._store = store
        self._collector = trace_collector
        self._checkers = checkers if checkers is not None else list(_DEFAULT_CHECKERS)
        self._scheduler = scheduler

    async def on_session_end(self, session_id: str) -> None:
        """after_session_end hook 回调入口。"""
        try:
            await self._evaluate(session_id)
        except Exception:
            logger.exception("EvaluationService: session %s 评估失败，静默降级", session_id)

    async def _evaluate(self, session_id: str) -> None:
        # flush() 在 on_session_end 触发前已清除内存 buffer，
        # 改为通过 get_session/get_span_tree 读取（先查内存，再查 SQLite）。
        session = self._collector.get_session(session_id)
        if session is None:
            logger.debug("EvaluationService: session %s 无 trace 数据，跳过", session_id)
            return

        spans = self._collector.get_span_tree(session_id)
        results: list[CheckResult] = []
        for checker in self._checkers:
            try:
                results.append(checker.check(session, spans))
            except Exception:
                logger.exception("Checker %s 执行异常，跳过", checker.name)

        if session.status == "interrupted":
            results.append(
                CheckResult(
                    checker_name="session_interrupted",
                    status="fail",
                    message=f"Session 异常中断：{session.terminal_reason or 'unknown'}",
                    evidence={
                        "status": session.status,
                        "terminal_reason": session.terminal_reason,
                    },
                )
            )

        self._store.save_results(session_id, results)
        fails = [result for result in results if result.status == "fail"]
        if fails:
            logger.debug(
                "EvaluationService: session %s 有 %d 个 fail，待 LlmDiagnosticAnalyzer 分析",
                session_id,
                len(fails),
            )
            enqueue = getattr(self._scheduler, "enqueue_priority", None)
            if callable(enqueue):
                enqueue(session_id)


__all__ = ["EvaluationService"]
