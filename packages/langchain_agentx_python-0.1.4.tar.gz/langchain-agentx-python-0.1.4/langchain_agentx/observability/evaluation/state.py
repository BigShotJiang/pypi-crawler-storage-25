"""
evaluation/state.py — 诊断分析共享状态。

职责：
    维护正在分析的 session 集合，协调“手动触发”和“后台轮询”避免重复分析。
"""

from __future__ import annotations

import asyncio


class AnalysisState:
    """手动触发与后台调度共享的分析互斥状态。"""

    def __init__(self) -> None:
        self._in_progress: set[str] = set()
        self._lock = asyncio.Lock()

    async def try_acquire(self, session_id: str) -> bool:
        async with self._lock:
            if session_id in self._in_progress:
                return False
            self._in_progress.add(session_id)
            return True

    async def release(self, session_id: str) -> None:
        async with self._lock:
            self._in_progress.discard(session_id)

    def is_in_progress(self, session_id: str) -> bool:
        return session_id in self._in_progress
