"""
Trace 系统：全链路可观测性。

核心组件：
- TraceCollector: 采集 + 查询
- TraceLifecycleCollector / TraceCallbackHandler: 生命周期与 LLM/Tool 采集
- SqliteTraceStore: 持久化存储
"""

from .models import TraceSession, TraceSpan
from .collector import TraceCollector
from .sqlite_store import SqliteTraceStore
from .trace_lifecycle_collector import TraceLifecycleCollector
from .trace_callback import TraceCallbackHandler
from .hook_event_emitter import HookEventEmitter

__all__ = [
    "TraceSession",
    "TraceSpan",
    "TraceCollector",
    "SqliteTraceStore",
    "TraceLifecycleCollector",
    "TraceCallbackHandler",
    "HookEventEmitter",
]
