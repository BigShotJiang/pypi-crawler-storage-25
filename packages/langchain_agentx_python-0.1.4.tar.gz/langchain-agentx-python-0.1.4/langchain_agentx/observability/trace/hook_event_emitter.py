"""
hook_event_emitter.py — Hook 执行记录写入 TraceCollector（Phase 3）。

职责：
    接收 HookExecutionRecord 并写入 collector，供后续查询 hook_id/skip_reason/snapshot_id。

链路位置：
    HookEngine 执行后（或 HookGraphWiring）调用本发射器。

当前裁剪范围：
    仅处理结构化 record，不负责 Hook 执行或策略决策。
"""

from __future__ import annotations

from dataclasses import dataclass

from langchain_agentx.loop.hook.types import HookExecutionRecord

from .collector import TraceCollector


@dataclass
class HookEventEmitter:
    """Hook 执行记录发射器。"""

    collector: TraceCollector

    def emit_record(self, session_id: str, record: HookExecutionRecord) -> str:
        return self.collector.emit_event(
            session_id=session_id,
            event_type="hook.execution",
            payload={
                "hook_id": record.hook_id,
                "hook_event": record.hook_event,
                "hook_source": record.hook_source,
                "matcher": record.matcher,
                "matched": record.matched,
                "skip_reason": record.skip_reason,
                "snapshot_id": record.snapshot_id,
                "policy_source": record.policy_source,
                "outcome": record.outcome,
                "prevent_continuation": record.prevent_continuation,
                "duration_ms": record.duration_ms,
            },
        )


__all__ = ["HookEventEmitter"]
