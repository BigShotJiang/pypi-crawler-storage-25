"""event_emitter.py — OOP 统一事件发射器。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .collector import TraceCollector


@dataclass
class TraceEventEmitter:
    """Loop 节点事件发射器（面向对象）。"""

    collector: "TraceCollector"
    session_id: str

    def emit_loop_decision_event(
        self,
        *,
        decision: str,
        selected_edge: str,
        reason_code: str,
        evidence: dict[str, Any],
        node: str = "loop_controller",
    ) -> str:
        return self.collector.emit_event(
            session_id=self.session_id,
            event_type="loop.decision",
            payload={
                "node": node,
                "decision": decision,
                "selected_edge": selected_edge,
                "reason_code": reason_code,
                "reason_text": _reason_code_to_text(reason_code),
                "evidence": evidence,
            },
        )

    def emit_task_event(
        self,
        *,
        event_type: str,
        batch_id: str,
        command_ids: list[str],
        **kwargs: Any,
    ) -> str:
        return self.collector.emit_event(
            session_id=self.session_id,
            event_type=event_type,
            payload={
                "batch_id": batch_id,
                "command_ids": command_ids,
                **kwargs,
            },
        )

    @classmethod
    def from_state(cls, state: dict[str, Any]) -> Optional["TraceEventEmitter"]:
        collector = _get_collector_from_state(state)
        session_id = state.get("_run_id")
        if not collector or not session_id:
            return None
        return cls(collector=collector, session_id=session_id)


def emit_loop_decision_event(
    state: dict[str, Any],
    decision: str,
    selected_edge: str,
    reason_code: str,
    evidence: dict[str, Any],
) -> None:
    """
    采集 loop.decision 事件。

    Args:
        state: Agent state（需包含 _trace_collector 和 _run_id）
        decision: 决策类型（continue/call_tools/terminal/task_reconcile）
        selected_edge: 选中的下一跳节点名
        reason_code: 机器可读原因码（枚举）
        evidence: 决策依据（结构化字段）

    Example:
        >>> emit_loop_decision_event(
        ...     state=state,
        ...     decision="call_tools",
        ...     selected_edge="tools",
        ...     reason_code="pending_tool_calls",
        ...     evidence={"pending_tool_calls": 2, "step": 4},
        ... )
    """
    emitter = TraceEventEmitter.from_state(state)
    if emitter is None:
        return
    emitter.emit_loop_decision_event(
        decision=decision,
        selected_edge=selected_edge,
        reason_code=reason_code,
        evidence=evidence,
    )


def emit_task_event(
    state: dict[str, Any],
    event_type: str,
    batch_id: str,
    command_ids: list[str],
    **kwargs: Any,
) -> None:
    """
    采集 task.reserve/ack 事件。

    Args:
        state: Agent state
        event_type: 事件类型（task.reserve / task.ack）
        batch_id: 批次 ID
        command_ids: 命令 ID 列表
        **kwargs: 其他字段（如 attachment_count）

    Example:
        >>> emit_task_event(
        ...     state=state,
        ...     event_type="task.reserve",
        ...     batch_id="batch-123",
        ...     command_ids=["cmd-1", "cmd-2"],
        ...     attachment_count=2,
        ... )
    """
    emitter = TraceEventEmitter.from_state(state)
    if emitter is None:
        return
    emitter.emit_task_event(
        event_type=event_type,
        batch_id=batch_id,
        command_ids=command_ids,
        **kwargs,
    )


def _get_collector_from_state(state: dict[str, Any]) -> Optional["TraceCollector"]:
    """
    从 state 获取 collector。

    Args:
        state: Agent state

    Returns:
        TraceCollector 实例，如果不存在则返回 None

    Note:
        优雅降级：collector 不存在时返回 None，调用方应检查并跳过采集。
    """
    return state.get("_trace_collector")


def _reason_code_to_text(reason_code: str) -> str:
    """
    将 reason_code 转换为人可读文本。

    Args:
        reason_code: 机器可读原因码

    Returns:
        人可读说明文本
    """
    reason_text_map = {
        "middleware_jump_to": "Middleware requested jump",
        "max_steps_force_final": "Max steps reached, forcing final response",
        "should_end_terminal": "Loop decided to terminate",
        "pending_tool_calls": "Tool calls pending execution",
        "pending_task_notifications": "Task notifications pending",
        "no_tools_and_not_continue": "No tools to call and not continuing",
    }
    return reason_text_map.get(reason_code, reason_code)


__all__ = [
    "TraceEventEmitter",
    "emit_loop_decision_event",
    "emit_task_event",
]
