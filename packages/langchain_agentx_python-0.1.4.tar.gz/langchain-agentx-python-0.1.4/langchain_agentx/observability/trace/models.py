"""
Trace 数据模型。

职责：
- 定义 TraceSession（一次 Agent 运行）
- 定义 TraceSpan（一次操作）
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum


class SpanType(str, Enum):
    """Span 类型枚举"""
    AGENT_RUN = "agent_run"
    LOOP_STEP = "loop_step"
    LLM_CALL = "llm_call"
    TOOL_CALL = "tool_call"
    HOOK_EXEC = "hook_exec"
    EXIT_LOGIC = "exit_logic"
    COMPACTION = "compaction"
    LOOP_DECISION = "loop_decision"
    TASK_EVENT = "task_event"


class SpanStatus(str, Enum):
    """Span 状态"""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class TraceSpan:
    """一次操作的 trace span"""
    
    span_id: str
    session_id: str
    parent_span_id: Optional[str]
    span_type: SpanType
    name: str
    start_time: float
    end_time: Optional[float] = None
    latency_ms: Optional[float] = None
    status: SpanStatus = SpanStatus.RUNNING
    input_data: Optional[Dict[str, Any]] = None
    output_data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于 JSON 序列化）"""
        return {
            "span_id": self.span_id,
            "session_id": self.session_id,
            "parent_span_id": self.parent_span_id,
            "span_type": self.span_type.value if isinstance(self.span_type, SpanType) else self.span_type,
            "name": self.name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "latency_ms": self.latency_ms,
            "status": self.status.value if isinstance(self.status, SpanStatus) else self.status,
            "input_data": self.input_data,
            "output_data": self.output_data,
            "error": self.error,
            "metadata": self.metadata,
        }


@dataclass
class TraceSession:
    """一次 Agent 运行的 trace session"""
    
    session_id: str
    user_query: Optional[str]
    graph_name: str
    start_time: float
    conversation_session_id: str = ""
    parent_session_id: Optional[str] = None       # 父 run 的 session_id（子 Agent 场景）
    parent_tool_call_id: Optional[str] = None     # 触发本子 Agent 的 tool_call_id
    workflow_id: Optional[str] = None             # Workflow 聚合标识
    unit_type: str = "main_loop"                  # main_loop / subagent / background
    container_type: str = "agent_session"         # agent_session / conversation / workflow / background
    origin: str = "user"                          # user / tool / system
    visibility: str = "default"                   # default / hidden / summary_only
    end_time: Optional[float] = None
    status: str = "running"
    finish_reason: Optional[str] = None
    exit_code: Optional[str] = None
    terminal_reason: Optional[str] = None
    loop_count: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_latency_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于 JSON 序列化）"""
        return {
            "session_id": self.session_id,
            "conversation_session_id": self.conversation_session_id,
            "parent_session_id": self.parent_session_id,
            "parent_tool_call_id": self.parent_tool_call_id,
            "workflow_id": self.workflow_id,
            "unit_type": self.unit_type,
            "container_type": self.container_type,
            "origin": self.origin,
            "visibility": self.visibility,
            "user_query": self.user_query,
            "graph_name": self.graph_name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "status": self.status,
            "finish_reason": self.finish_reason,
            "exit_code": self.exit_code,
            "terminal_reason": self.terminal_reason,
            "loop_count": self.loop_count,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_latency_ms": self.total_latency_ms,
            "metadata": self.metadata,
        }


@dataclass
class SessionBuffer:
    """Session 的内存缓冲区（flush 前暂存）"""
    
    session: TraceSession
    spans: List[TraceSpan] = field(default_factory=list)
    span_stack: List[str] = field(default_factory=list)  # 用于追踪当前 span 栈
    next_seq_no: int = 1  # run 内事件顺序号（单调递增）
    
    def add_span(self, span: TraceSpan) -> None:
        """添加 span"""
        self.spans.append(span)
    
    def get_span(self, span_id: str) -> Optional[TraceSpan]:
        """根据 span_id 获取 span"""
        for span in self.spans:
            if span.span_id == span_id:
                return span
        return None
