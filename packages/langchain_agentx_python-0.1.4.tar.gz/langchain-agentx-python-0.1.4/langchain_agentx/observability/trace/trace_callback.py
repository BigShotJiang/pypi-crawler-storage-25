"""
trace_callback.py — LLM/Tool 调用回调采集器（Phase 3）。

职责：
    基于 LangChain BaseCallbackHandler 采集 llm_call/tool_call latency 与错误归因。

链路位置：
    factory.compile() -> compiled.with_config({"callbacks": [TraceCallbackHandler(...)]}).

当前裁剪范围：
    单 run 级回调；不承担 session 生命周期管理。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler

from .collector import TraceCollector


@dataclass
class TraceCallbackHandler(BaseCallbackHandler):
    """LLM/Tool 事件回调到 TraceCollector。"""

    collector: TraceCollector
    session_id: str
    capture_llm: bool = True
    capture_tool: bool = True
    _llm_spans: dict[str, str] = field(default_factory=dict)
    _tool_spans: dict[str, str] = field(default_factory=dict)
    _llm_started_at: dict[str, float] = field(default_factory=dict)
    _tool_started_at: dict[str, float] = field(default_factory=dict)

    def _ensure_session(self) -> None:
        if self.collector.has_session(self.session_id):
            return
        self.collector.start_session(session_id=self.session_id, graph_name="agent", user_query=None)

    @staticmethod
    def _llm_name(serialized: dict[str, Any]) -> str:
        return str(serialized.get("name") or serialized.get("id") or "llm")

    def _start_llm_span(self, *, run_id: Any, name: str, prompt_count: int) -> None:
        self._ensure_session()
        span_id = self.collector.span_start(
            span_type="llm_call",
            name=name,
            session_id=self.session_id,
            input_data={"prompt_count": prompt_count},
        )
        key = str(run_id)
        self._llm_spans[key] = span_id
        self._llm_started_at[key] = time.time()

    def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], *, run_id: Any, **kwargs: Any) -> None:
        if not self.capture_llm:
            return
        self._start_llm_span(
            run_id=run_id,
            name=self._llm_name(serialized),
            prompt_count=len(prompts),
        )

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        """兼容 ChatModel 回调入口，避免 provider 仅触发 chat 路径时漏采集。"""
        if not self.capture_llm:
            return
        # ChatModel 的 messages 是 batch 结构（List[List[BaseMessage]]）
        prompt_count = len(messages)
        self._start_llm_span(
            run_id=run_id,
            name=self._llm_name(serialized),
            prompt_count=prompt_count,
        )

    def on_llm_end(self, response: Any, *, run_id: Any, **kwargs: Any) -> None:
        if not self.capture_llm:
            return
        key = str(run_id)
        span_id = self._llm_spans.pop(key, None)
        started_at = self._llm_started_at.pop(key, None)
        if not span_id:
            return
        metadata: dict[str, Any] = self._extract_llm_metadata(response)
        if started_at is not None:
            metadata["latency_ms"] = (time.time() - started_at) * 1000
        self.collector.span_end(span_id=span_id, session_id=self.session_id, metadata=metadata)

    def on_llm_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        if not self.capture_llm:
            return
        key = str(run_id)
        span_id = self._llm_spans.pop(key, None)
        self._llm_started_at.pop(key, None)
        if not span_id:
            return
        self.collector.span_end(span_id=span_id, session_id=self.session_id, error=str(error))

    def on_tool_start(self, serialized: dict[str, Any], input_str: str, *, run_id: Any, **kwargs: Any) -> None:
        if not self.capture_tool:
            return
        self._ensure_session()
        name = str(serialized.get("name") or "tool")
        input_data, metadata = self._extract_tool_input_and_metadata(input_str=input_str, kwargs=kwargs)
        span_id = self.collector.span_start(
            span_type="tool_call",
            name=name,
            session_id=self.session_id,
            input_data=input_data,
            metadata=metadata,
        )
        key = str(run_id)
        self._tool_spans[key] = span_id
        self._tool_started_at[key] = time.time()

    def on_tool_end(self, output: Any, *, run_id: Any, **kwargs: Any) -> None:
        if not self.capture_tool:
            return
        key = str(run_id)
        span_id = self._tool_spans.pop(key, None)
        started_at = self._tool_started_at.pop(key, None)
        if not span_id:
            return
        metadata: dict[str, Any] = {}
        if started_at is not None:
            metadata["latency_ms"] = (time.time() - started_at) * 1000
        self.collector.span_end(span_id=span_id, session_id=self.session_id, metadata=metadata)

    def on_tool_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        if not self.capture_tool:
            return
        key = str(run_id)
        span_id = self._tool_spans.pop(key, None)
        self._tool_started_at.pop(key, None)
        if not span_id:
            return
        self.collector.span_end(span_id=span_id, session_id=self.session_id, error=str(error))

    @staticmethod
    def _extract_tool_input_and_metadata(*, input_str: str, kwargs: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        优先使用 LangChain 回调透传的结构化 inputs，避免把 tool_runtime 等内部对象写入 trace。
        仅当结构化输入不可用时，回退到 input_str 快照（保留上限防止极端体积）。
        """
        metadata: dict[str, Any] = {}
        raw_inputs = kwargs.get("inputs")
        if isinstance(raw_inputs, dict):
            clean_inputs: dict[str, Any] = {}
            for key, value in raw_inputs.items():
                # LangGraph 注入运行时对象（ToolRuntime），不属于用户态业务参数。
                if key == "tool_runtime":
                    tool_call_id = getattr(value, "tool_call_id", None)
                    if isinstance(tool_call_id, str) and tool_call_id:
                        metadata["tool_call_id"] = tool_call_id
                    continue
                clean_inputs[key] = value

            if clean_inputs:
                return clean_inputs, metadata

        # fallback: 历史链路仍可能只提供 input_str。
        return {"input": input_str[:500]}, metadata

    def _extract_llm_metadata(self, response: Any) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        finish_reason = self._extract_finish_reason(response)
        if isinstance(finish_reason, str) and finish_reason:
            metadata["finish_reason"] = finish_reason
        usage = self._extract_token_usage(response)
        metadata.update(usage)
        return metadata

    @staticmethod
    def _extract_finish_reason(response: Any) -> str | None:
        first_message = TraceCallbackHandler._extract_first_generation_message(response)
        if first_message is not None:
            response_metadata = getattr(first_message, "response_metadata", None)
            if isinstance(response_metadata, dict):
                value = response_metadata.get("finish_reason")
                if isinstance(value, str) and value:
                    return value

        # ChatModel 常见结构：AIMessage.response_metadata.finish_reason
        response_metadata = getattr(response, "response_metadata", None)
        if isinstance(response_metadata, dict):
            value = response_metadata.get("finish_reason")
            if isinstance(value, str) and value:
                return value

        # LLMResult 常见结构：llm_output.finish_reason
        llm_output = getattr(response, "llm_output", None)
        if isinstance(llm_output, dict):
            value = llm_output.get("finish_reason")
            if isinstance(value, str) and value:
                return value

        return None

    @staticmethod
    def _extract_token_usage(response: Any) -> dict[str, int]:
        first_message = TraceCallbackHandler._extract_first_generation_message(response)
        if first_message is not None:
            usage_metadata = getattr(first_message, "usage_metadata", None)
            if isinstance(usage_metadata, dict):
                input_tokens = usage_metadata.get("input_tokens")
                output_tokens = usage_metadata.get("output_tokens")
                total_tokens = usage_metadata.get("total_tokens")
                result: dict[str, int] = {}
                if isinstance(input_tokens, int):
                    result["input_tokens"] = input_tokens
                if isinstance(output_tokens, int):
                    result["output_tokens"] = output_tokens
                if isinstance(total_tokens, int):
                    result["total_tokens"] = total_tokens
                if result:
                    return result

        # ChatModel 常见结构：AIMessage.usage_metadata
        usage_metadata = getattr(response, "usage_metadata", None)
        if isinstance(usage_metadata, dict):
            input_tokens = usage_metadata.get("input_tokens")
            output_tokens = usage_metadata.get("output_tokens")
            total_tokens = usage_metadata.get("total_tokens")
            result: dict[str, int] = {}
            if isinstance(input_tokens, int):
                result["input_tokens"] = input_tokens
            if isinstance(output_tokens, int):
                result["output_tokens"] = output_tokens
            if isinstance(total_tokens, int):
                result["total_tokens"] = total_tokens
            if result:
                return result

        # LLMResult/OpenAI 常见结构：response_metadata.token_usage
        response_metadata = getattr(response, "response_metadata", None)
        if isinstance(response_metadata, dict):
            token_usage = response_metadata.get("token_usage")
            if isinstance(token_usage, dict):
                result = {}
                prompt_tokens = token_usage.get("prompt_tokens")
                completion_tokens = token_usage.get("completion_tokens")
                total_tokens = token_usage.get("total_tokens")
                if isinstance(prompt_tokens, int):
                    result["input_tokens"] = prompt_tokens
                if isinstance(completion_tokens, int):
                    result["output_tokens"] = completion_tokens
                if isinstance(total_tokens, int):
                    result["total_tokens"] = total_tokens
                if result:
                    return result

        # 部分 LLMResult：response.llm_output.token_usage
        llm_output = getattr(response, "llm_output", None)
        if isinstance(llm_output, dict):
            token_usage = llm_output.get("token_usage")
            if isinstance(token_usage, dict):
                result = {}
                prompt_tokens = token_usage.get("prompt_tokens")
                completion_tokens = token_usage.get("completion_tokens")
                total_tokens = token_usage.get("total_tokens")
                if isinstance(prompt_tokens, int):
                    result["input_tokens"] = prompt_tokens
                if isinstance(completion_tokens, int):
                    result["output_tokens"] = completion_tokens
                if isinstance(total_tokens, int):
                    result["total_tokens"] = total_tokens
                if result:
                    return result

        return {}

    @staticmethod
    def _extract_first_generation_message(response: Any) -> Any | None:
        generations = getattr(response, "generations", None)
        if not isinstance(generations, list) or not generations:
            return None
        first_batch = generations[0]
        if not isinstance(first_batch, list) or not first_batch:
            return None
        first_generation = first_batch[0]
        return getattr(first_generation, "message", None)


__all__ = ["TraceCallbackHandler"]
