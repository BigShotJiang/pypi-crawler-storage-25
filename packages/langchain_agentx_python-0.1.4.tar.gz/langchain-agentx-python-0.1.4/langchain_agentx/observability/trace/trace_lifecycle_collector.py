"""
trace_lifecycle_collector.py — Loop 图生命周期 Trace 采集（Phase 3）。

职责：
    在固定 Loop 图节点上采集 loop 生命周期事件，统一写入 TraceCollector。

链路位置：
    HookGraphWiring(loop_start/before_model/after_model/loop_end) -> TraceLifecycleCollector。

当前裁剪范围：
    仅覆盖框架内置生命周期节点采集（非 HookRegistry 用户扩展体系）；
    llm/tool 细粒度调用由 TraceCallbackHandler 负责。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from uuid import uuid4

from .collector import TraceCollector


@dataclass
class TraceLifecycleCollector:
    """框架内置生命周期 Trace 采集器，由 HookGraphWiring 调用。"""

    collector: TraceCollector
    graph_name: str = "agent"
    default_run_id: str | None = None
    unit_type: str = "main_loop"
    container_type: str = "agent_session"
    origin: str = "user"
    visibility: str = "default"
    parent_run_id: str | None = None
    parent_tool_call_id: str | None = None
    conversation_session_id: str | None = None

    def loop_start_node(self, state: dict[str, Any]) -> dict[str, Any]:
        run_id = state.get("_run_id")
        if not isinstance(run_id, str) or not run_id:
            run_id = self.default_run_id or uuid4().hex
        if not self.collector.has_session(run_id):
            user_query = self._extract_user_query(state)
            self.collector.start_session(
                session_id=run_id,
                graph_name=self.graph_name,
                user_query=user_query,
                conversation_session_id=self.conversation_session_id or run_id,
                parent_session_id=self.parent_run_id,
                parent_tool_call_id=self.parent_tool_call_id,
                unit_type=self.unit_type,
                container_type=self.container_type,
                origin=self.origin,
                visibility=self.visibility,
            )
        return {"_trace_collector": self.collector, "_run_id": run_id}

    def before_model_node(self, state: dict[str, Any]) -> dict[str, Any]:
        run_id = state.get("_run_id")
        if not isinstance(run_id, str) or not run_id or not self.collector.has_session(run_id):
            return {}
        span_id = self.collector.span_start(
            span_type="loop_step",
            name=f"step_{int(state.get('step', 0) or 0)}",
            session_id=run_id,
            metadata={"context_length": len(state.get("messages", []))},
        )
        return {"_trace_loop_step_span_id": span_id}

    def after_model_node(self, state: dict[str, Any]) -> dict[str, Any]:
        run_id = state.get("_run_id")
        span_id = state.get("_trace_loop_step_span_id")
        if (
            not isinstance(run_id, str)
            or not run_id
            or not isinstance(span_id, str)
            or not span_id
            or not self.collector.has_session(run_id)
        ):
            return {}
        self.collector.span_end(
            span_id=span_id,
            session_id=run_id,
            metadata={"finish_reason": state.get("finish_reason")},
        )
        return {"_trace_loop_step_span_id": None}

    def loop_end_node(self, state: dict[str, Any]) -> dict[str, Any]:
        run_id = state.get("_run_id")
        if not isinstance(run_id, str) or not run_id or not self.collector.has_session(run_id):
            return {}
        self.collector.end_session(
            session_id=run_id,
            finish_reason=state.get("finish_reason"),
            terminal_reason=state.get("terminal_reason"),
        )
        return {}

    # A07 文档对齐别名：保留 loop_* 原命名，避免 HookGraphWiring 接线调整。
    session_start_node = loop_start_node
    session_end_node = loop_end_node

    @staticmethod
    def _extract_user_query(state: dict[str, Any]) -> str | None:
        messages = list(state.get("messages") or [])
        if not messages:
            return None
        first = messages[0]
        content = getattr(first, "content", None)
        return str(content)[:200] if isinstance(content, str) else None


__all__ = ["TraceLifecycleCollector"]
