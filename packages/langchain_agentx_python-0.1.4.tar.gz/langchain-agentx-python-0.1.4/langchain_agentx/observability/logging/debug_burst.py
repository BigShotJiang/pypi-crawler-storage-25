"""
observability/logging/debug_burst.py — 会话级调试放大控制器

职责：
    提供 Debug Burst 的短时启停能力：临时提高日志详细度、挂载专用诊断 handler，
    到期后自动回落，避免长期日志噪音。
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path

from .logging_config import LoggingDirectoryResolver


@dataclass
class DebugBurstSession:
    started_at_ts: float
    ttl_sec: float
    level: int
    scope: str
    session_id: str | None = None
    handler: logging.Handler | None = None

    def is_active(self) -> bool:
        return (time.time() - self.started_at_ts) <= self.ttl_sec


class DebugBurstController:
    """Debug Burst 运行期控制器。"""

    def __init__(
        self,
        *,
        logger_name: str = "langchain_agentx",
        directory_resolver: LoggingDirectoryResolver | None = None,
    ) -> None:
        self._logger = logging.getLogger(logger_name)
        self._resolver = directory_resolver or LoggingDirectoryResolver()
        self._session: DebugBurstSession | None = None
        self._original_level: int | None = None

    def start(
        self,
        *,
        workspace_root: str | Path | None = None,
        ttl_sec: float = 120.0,
        level: int = logging.DEBUG,
        scope: str = "session",
        session_id: str | None = None,
    ) -> DebugBurstSession:
        self.stop()
        layout = self._resolver.resolve(workspace_root=workspace_root)
        layout.diagnostics_dir.mkdir(parents=True, exist_ok=True)
        burst_file = layout.diagnostics_dir / "debug-burst.log"
        handler = logging.FileHandler(burst_file, encoding="utf-8")
        handler.setLevel(level)
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s run_id=%(run_id)s session_id=%(session_id)s "
                "task_id=%(task_id)s tool_call_id=%(tool_call_id)s agent_id=%(agent_id)s %(message)s"
            )
        )
        self._logger.addHandler(handler)
        self._original_level = self._logger.level
        self._logger.setLevel(min(self._logger.level or level, level))
        self._session = DebugBurstSession(
            started_at_ts=time.time(),
            ttl_sec=ttl_sec,
            level=level,
            scope=scope,
            session_id=session_id,
            handler=handler,
        )
        return self._session

    def stop(self) -> None:
        if self._session is None:
            return
        if self._session.handler is not None:
            self._logger.removeHandler(self._session.handler)
            self._session.handler.close()
        if self._original_level is not None:
            self._logger.setLevel(self._original_level)
        self._session = None
        self._original_level = None

    def tick(self) -> None:
        if self._session is None:
            return
        if not self._session.is_active():
            self.stop()
