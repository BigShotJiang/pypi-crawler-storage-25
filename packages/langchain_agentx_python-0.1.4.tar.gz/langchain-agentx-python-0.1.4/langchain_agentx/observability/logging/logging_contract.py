"""
observability/logging/logging_contract.py — 日志上下文字段契约协作者

职责：
    提供统一日志上下文构建与 logger 适配器，确保 run/session/task/tool_call
    等关联字段在日志层可用，便于与 trace/replay 互相定位。

在整体链路中的位置：
    业务入口（loop/task_runtime/tools）
      -> build_log_context(...)
      -> ObservabilityLoggerAdapter(logger, context)
      -> logger.info/warning/error(...)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class LogContext:
    run_id: str = "-"
    session_id: str = "-"
    task_id: str = "-"
    tool_call_id: str = "-"
    agent_id: str = "-"

    def as_extra(self) -> dict[str, str]:
        return {
            "run_id": self.run_id,
            "session_id": self.session_id,
            "task_id": self.task_id,
            "tool_call_id": self.tool_call_id,
            "agent_id": self.agent_id,
        }


def build_log_context(
    *,
    run_id: str | None = None,
    session_id: str | None = None,
    task_id: str | None = None,
    tool_call_id: str | None = None,
    agent_id: str | None = None,
) -> LogContext:
    return LogContext(
        run_id=run_id or "-",
        session_id=session_id or "-",
        task_id=task_id or "-",
        tool_call_id=tool_call_id or "-",
        agent_id=agent_id or "-",
    )


class ObservabilityLoggerAdapter(logging.LoggerAdapter):
    """在日志记录中注入统一上下文字段。"""

    def process(self, msg: str, kwargs: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        kwargs.setdefault("extra", {})
        merged = dict(self.extra or {})
        merged.update(kwargs["extra"])
        kwargs["extra"] = merged
        return msg, kwargs
