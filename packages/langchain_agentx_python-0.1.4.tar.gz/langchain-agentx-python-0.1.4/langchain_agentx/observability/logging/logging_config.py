"""
observability/logging/logging_config.py — Python logging 配置构建协作者

职责：
    提供 dictConfig 构建与应用入口，统一日志目录、级别、formatter、handler。
    默认目录：<workspace_root>/workspace（可由 AGENTX_LOG_ROOT 覆盖）。

在整体链路中的位置：
    进程启动或测试入口
      -> LoggingConfigBuilder.build_dict_config()
      -> logging.config.dictConfig(...)
"""

from __future__ import annotations

import logging
import logging.config
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from langchain_agentx.workspace import resolve_agent_workspace_config


ENV_LOG_ROOT = "AGENTX_LOG_ROOT"
ENV_LOG_LEVEL = "AGENTX_LOG_LEVEL"
ENV_LOG_JSON = "AGENTX_LOG_JSON"


class _ContextDefaultsFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        for key in ("run_id", "session_id", "task_id", "tool_call_id", "agent_id"):
            if not hasattr(record, key):
                setattr(record, key, "-")
        return True


@dataclass(frozen=True)
class LoggingDirectoryLayout:
    workspace_root: Path
    log_root: Path
    runtime_dir: Path
    diagnostics_dir: Path


class LoggingDirectoryResolver:
    """日志目录解析器。"""

    def resolve(
        self,
        *,
        workspace_root: str | Path | None = None,
        log_root: str | Path | None = None,
    ) -> LoggingDirectoryLayout:
        workspace_cfg = resolve_agent_workspace_config(workspace_root=workspace_root)
        ws_root = workspace_cfg.workspace_root
        root = Path(log_root or os.getenv(ENV_LOG_ROOT) or (ws_root / "workspace"))
        resolved_root = root.expanduser().resolve()
        return LoggingDirectoryLayout(
            workspace_root=ws_root,
            log_root=resolved_root,
            runtime_dir=resolved_root / "runtime",
            diagnostics_dir=resolved_root / "diagnostics",
        )


class LoggingConfigBuilder:
    """logging dictConfig 构建器。"""

    def __init__(
        self,
        *,
        directory_resolver: LoggingDirectoryResolver | None = None,
    ) -> None:
        self._resolver = directory_resolver or LoggingDirectoryResolver()

    def build_dict_config(
        self,
        *,
        workspace_root: str | Path | None = None,
        log_root: str | Path | None = None,
        level: str | None = None,
    ) -> dict[str, Any]:
        layout = self._resolver.resolve(workspace_root=workspace_root, log_root=log_root)
        layout.runtime_dir.mkdir(parents=True, exist_ok=True)
        layout.diagnostics_dir.mkdir(parents=True, exist_ok=True)

        resolved_level = (level or os.getenv(ENV_LOG_LEVEL, "INFO")).upper()
        use_json = os.getenv(ENV_LOG_JSON, "0") == "1"
        formatter = (
            "%(message)s"
            if use_json
            else (
                "%(asctime)s %(levelname)s %(name)s "
                "run_id=%(run_id)s session_id=%(session_id)s task_id=%(task_id)s "
                "tool_call_id=%(tool_call_id)s agent_id=%(agent_id)s %(message)s"
            )
        )
        return {
            "version": 1,
            "disable_existing_loggers": False,
            "filters": {
                "context_defaults": {
                    "()": _ContextDefaultsFilter,
                }
            },
            "formatters": {
                "standard": {
                    "format": formatter,
                }
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": resolved_level,
                    "formatter": "standard",
                    "filters": ["context_defaults"],
                },
                "runtime_file": {
                    "class": "logging.handlers.TimedRotatingFileHandler",
                    "filename": str(layout.runtime_dir / "app.log"),
                    "when": "D",
                    "interval": 1,
                    "backupCount": 7,
                    "encoding": "utf-8",
                    "level": resolved_level,
                    "formatter": "standard",
                    "filters": ["context_defaults"],
                },
                "error_file": {
                    "class": "logging.handlers.TimedRotatingFileHandler",
                    "filename": str(layout.runtime_dir / "error.log"),
                    "when": "D",
                    "interval": 1,
                    "backupCount": 14,
                    "encoding": "utf-8",
                    "level": "ERROR",
                    "formatter": "standard",
                    "filters": ["context_defaults"],
                },
            },
            "root": {
                "handlers": ["console", "runtime_file", "error_file"],
                "level": resolved_level,
            },
        }

    def apply(
        self,
        *,
        workspace_root: str | Path | None = None,
        log_root: str | Path | None = None,
        level: str | None = None,
    ) -> None:
        logging.config.dictConfig(
            self.build_dict_config(
                workspace_root=workspace_root,
                log_root=log_root,
                level=level,
            )
        )


_CONFIGURED = False


def configure_logging_once(
    *,
    workspace_root: str | Path | None = None,
    log_root: str | Path | None = None,
    level: str | None = None,
) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    LoggingConfigBuilder().apply(workspace_root=workspace_root, log_root=log_root, level=level)
    _CONFIGURED = True
