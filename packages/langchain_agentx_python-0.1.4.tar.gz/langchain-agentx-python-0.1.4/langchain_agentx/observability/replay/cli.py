"""
runtime/observability_cli.py — 可观测性 CLI 适配入口

职责：
    为命令行场景提供统一回放/查询接口，作为 runtime replay 服务的
    交互层适配器，支持 list/replay/query 等子命令。

OOP 边界：
    - CLI 仅负责参数解析与输出渲染；
    - 业务逻辑委托 `runtime/replay.py`；
    - 不直接操作存储层（JSONL/gzip）。

与 CC 对比：
    对齐 CC 在交互排障中的“可查询、可导出、可回放”路径，
    以标准命令形式提供给运维与开发流程。
"""

from __future__ import annotations

import argparse
import logging
from pprint import pprint

from .service import (
    export_call_chain,
    list_replayable_tool_calls,
    query_replays,
    visualize_call_chain_mermaid,
)
from ..logging import ObservabilityLoggerAdapter, build_log_context

logger = logging.getLogger(__name__)


def main() -> None:
    parser = argparse.ArgumentParser(description="AgentX observability CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list")

    replay_p = sub.add_parser("replay")
    replay_p.add_argument("--tool-call-id", required=True)
    replay_p.add_argument("--mermaid", action="store_true")

    query_p = sub.add_parser("query")
    query_p.add_argument("--tool-name")
    query_p.add_argument("--status")
    query_p.add_argument("--start-ts", type=int)
    query_p.add_argument("--end-ts", type=int)
    query_p.add_argument("--limit", type=int, default=50)

    args = parser.parse_args()
    log = ObservabilityLoggerAdapter(logger, build_log_context().as_extra())
    log.info("replay cli command=%s", args.cmd)
    if args.cmd == "list":
        rows = list_replayable_tool_calls()
        log.info("replay cli list rows=%s", len(rows))
        pprint(rows)
        return
    if args.cmd == "replay":
        replay_log = ObservabilityLoggerAdapter(
            logger,
            build_log_context(tool_call_id=args.tool_call_id).as_extra(),
        )
        if args.mermaid:
            replay_log.info("replay cli export mermaid")
            print(visualize_call_chain_mermaid(args.tool_call_id))
        else:
            replay_log.info("replay cli export call chain")
            pprint(export_call_chain(args.tool_call_id))
        return
    if args.cmd == "query":
        rows = query_replays(
            tool_name=args.tool_name,
            status=args.status,
            start_ts=args.start_ts,
            end_ts=args.end_ts,
            limit=args.limit,
        )
        log.info(
            "replay cli query rows=%s tool_name=%s status=%s",
            len(rows),
            args.tool_name or "-",
            args.status or "-",
        )
        pprint(rows)


if __name__ == "__main__":
    main()

