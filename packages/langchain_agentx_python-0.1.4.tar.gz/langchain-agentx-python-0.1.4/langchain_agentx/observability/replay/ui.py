"""
runtime/observability_ui.py — 可观测性 UI 投影适配器

职责：
    将 replay 记录映射为前端可渲染的时间线结构（decision + event），
    作为 UI 层与 runtime 观测数据之间的协议转换层。

OOP 边界：
    - 该模块只做数据投影，不参与存储与查询；
    - 输入为 replay record，输出为 UI timeline DTO；
    - 可被 Web/桌面/CLI TUI 多端复用。

与 CC 对比：
    对齐 CC 中“执行轨迹 + 决策归因”的可视化呈现方向，
    保持视图层与存储层解耦。
"""

from __future__ import annotations

from typing import Any


def to_ui_timeline(record: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not record:
        return []
    items: list[dict[str, Any]] = []
    for d in record.get("decision_trace", []):
        items.append(
            {
                "kind": "decision",
                "title": f"{d.get('layer')} -> {d.get('behavior')}",
                "policy_id": d.get("policy_id"),
                "command": d.get("command"),
            }
        )
    events = (((record.get("observability") or {}).get("events")) or [])
    for ev in events:
        items.append(
            {
                "kind": "event",
                "title": ev.get("event"),
                "seq": ev.get("seq"),
                "payload": {k: v for k, v in ev.items() if k not in {"seq", "event"}},
            }
        )
    return items

