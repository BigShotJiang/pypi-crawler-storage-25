"""
runtime/replay.py — 运行时观测回放服务接口

职责：
    提供基于 `tool_call_id` 的回放能力，对外暴露：
    - 单次调用链查询
    - 可回放列表
    - 增量事件 tail（实时轮询）
    - 条件过滤查询
    - 导出与可视化（mermaid）

OOP 边界：
    该模块是 `ObservabilityTraceStore` 的 façade 层，
    统一封装调用入口，避免业务侧直接依赖底层存储实现。

与 CC 对比：
    对齐 CC “问题复盘/归因追踪”的使用方式，先提供稳定 API，
    再逐步演进为更强的可视化与外部系统集成。
"""

from __future__ import annotations

from typing import Any

from .store import get_global_trace_store


def replay_tool_call(tool_call_id: str) -> dict[str, Any] | None:
    """按 tool_call_id 获取最近一次观测记录。"""
    return get_global_trace_store().get(tool_call_id)


def list_replayable_tool_calls() -> list[str]:
    """列出可回放的 tool_call_id。"""
    return get_global_trace_store().all_keys()


def tail_tool_call_events(tool_call_id: str, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
    """
    获取事件增量（用于 UI/CLI 轮询实时展示）。
    返回 (events, next_offset)。
    """
    return get_global_trace_store().tail_events(tool_call_id, offset=offset)


def query_replays(
    *,
    tool_name: str | None = None,
    status: str | None = None,
    start_ts: int | None = None,
    end_ts: int | None = None,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """按条件查询回放记录。"""
    return get_global_trace_store().query(
        tool_name=tool_name,
        status=status,
        start_ts=start_ts,
        end_ts=end_ts,
        limit=limit,
    )


def export_call_chain(tool_call_id: str) -> dict[str, Any] | None:
    """一键导出完整调用链（decision_trace + observability events）。"""
    return replay_tool_call(tool_call_id)


def visualize_call_chain_mermaid(tool_call_id: str) -> str:
    """将调用链导出为简易 mermaid 时序图文本。"""
    record = replay_tool_call(tool_call_id)
    if not record:
        return "sequenceDiagram\n  participant U as User\n  participant T as Tool\n  U->>T: no replay record"
    lines = ["sequenceDiagram", "  participant U as User", "  participant T as Tool"]
    for step in record.get("decision_trace", []):
        lines.append(
            f"  U->>T: decision {step.get('layer')} / {step.get('behavior')} / {step.get('policy_id')}"
        )
    events = (((record.get("observability") or {}).get("events")) or [])
    for ev in events:
        lines.append(f"  T-->>U: {ev.get('event')}")
    return "\n".join(lines)

