"""
CompatibleChatOpenAI
====================

为 **任意 OpenAI 兼容聊天服务** 提供一个轻量级的 LangChain ChatModel 封装，
在不 fork `langchain-openai` 的前提下：

- 复用官方 `ChatOpenAI` 的绝大部分行为（重试、流式、usage 统计等）
- 额外把流式响应中的 `reasoning_content` 注入到
  `AIMessageChunk.additional_kwargs["reasoning_content"]`，让下游组件按
  LangChain v2 标准路径解析 reasoning。
- 在组请求体时把历史 ``AIMessage.additional_kwargs["reasoning_content"]`` 写回
  ``messages[].reasoning_content``（``langchain_openai`` 默认不落该字段）。
  部分 OpenAI 兼容思考模型要求多轮必须把上一轮 reasoning 原样带回，否则会 400。

与 loop 终局契约：
    若 HTTP/鉴权等错误在 invoke/ainvoke 阶段以异常抛出，
    由 model_nodes 统一合成带 response_metadata.langchain_agentx_api_error/error 的 AIMessage。
"""

from __future__ import annotations

from typing import Any, Dict, Type

from langchain_core.language_models import LanguageModelInput
from langchain_core.messages import AIMessage, AIMessageChunk, BaseMessageChunk
from langchain_core.outputs import ChatGenerationChunk
from langchain_openai import ChatOpenAI


class CompatibleChatOpenAI(ChatOpenAI):
    """OpenAI 兼容 ChatModel 封装（支持 reasoning_content）。"""

    def _get_request_payload(
        self,
        input_: LanguageModelInput,
        *,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """与基类一致，并为 chat/completions 的 assistant 历史补上 ``reasoning_content``。"""
        lc_messages = self._convert_input(input_).to_messages()
        payload = super()._get_request_payload(input_, stop=stop, **kwargs)
        serialized = payload.get("messages")
        if not isinstance(serialized, list) or len(serialized) != len(lc_messages):
            return payload
        for msg_dict, lc_msg in zip(serialized, lc_messages):
            if not isinstance(lc_msg, AIMessage):
                continue
            rc = lc_msg.additional_kwargs.get("reasoning_content")
            if isinstance(rc, str) and rc:
                msg_dict["reasoning_content"] = rc
        return payload

    def _convert_chunk_to_generation_chunk(
        self,
        chunk: Dict[str, Any],
        default_chunk_class: Type[BaseMessageChunk],
        base_generation_info: Dict[str, Any] | None,
    ) -> ChatGenerationChunk | None:
        gen_chunk = super()._convert_chunk_to_generation_chunk(
            chunk, default_chunk_class, base_generation_info
        )
        if gen_chunk is None:
            return None

        message = gen_chunk.message
        if not isinstance(message, AIMessageChunk):
            return gen_chunk

        choices = chunk.get("choices", []) or chunk.get("chunk", {}).get("choices", [])
        if not choices:
            return gen_chunk

        delta = choices[0].get("delta") or {}
        rc = delta.get("reasoning_content")
        if isinstance(rc, str) and rc:
            ak = getattr(message, "additional_kwargs", None) or {}
            ak["reasoning_content"] = rc
            message.additional_kwargs = ak

        return gen_chunk


__all__ = ["CompatibleChatOpenAI"]

