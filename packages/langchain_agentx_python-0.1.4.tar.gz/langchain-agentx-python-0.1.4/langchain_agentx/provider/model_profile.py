"""provider/model_profile.py — 模型能力参数配置对象与注册表。

职责：
    - ModelProfile：持有单个模型的能力参数（context_window / max_output_tokens / 默认采样参数等）
    - ModelProfileRegistry：从「内置 + 外部」两层 yaml 加载，并按 model_id_prefix 做最长前缀匹配

链路位置：
    - provider/openai.py、provider/anthropic.py：读取默认采样参数与输出上限（P1 接入）
    - loop/config/model_context_resolver.py：解析 context_window（P2 接入）

当前裁剪范围：
    - 仅负责参数加载与匹配；不负责 loop 业务判断、不负责 env/.env 加载、不做运行时热重载。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, ClassVar

logger = logging.getLogger(__name__)


def _builtin_profiles_path() -> Path:
    # langchain_agentx/provider/model_profile.py -> langchain_agentx/config/model_profiles.yaml
    return Path(__file__).resolve().parents[1] / "config" / "model_profiles.yaml"


@dataclass(frozen=True)
class ModelProfile:
    """单个模型的能力参数（纯数据持有，无业务逻辑）。"""

    model_id_prefix: str
    context_window: int
    max_output_tokens: int
    provider: str  # "claude" | "openai"
    supports_cache: bool = False
    default_temperature: float = 0.7
    default_top_p: float | None = None

    PROVIDERS: ClassVar[frozenset[str]] = frozenset({"claude", "openai"})

    def __post_init__(self) -> None:
        if self.provider not in self.PROVIDERS:
            msg = f"invalid provider={self.provider!r}, must be one of {sorted(self.PROVIDERS)}"
            raise ValueError(msg)
        if self.context_window <= 0 or self.max_output_tokens <= 0:
            raise ValueError("context_window/max_output_tokens must be positive")
        if not self.model_id_prefix or not str(self.model_id_prefix).strip():
            raise ValueError("model_id_prefix must be non-empty")


@dataclass
class ModelProfileRegistry:
    """两层 yaml 加载 + model_id_prefix 最长前缀优先匹配。"""

    profiles: dict[str, ModelProfile] = field(default_factory=dict)
    defaults: ModelProfile = field(
        default_factory=lambda: ModelProfile(
            model_id_prefix="__default__",
            context_window=32_000,
            max_output_tokens=8_192,
            provider="openai",
            supports_cache=False,
            default_temperature=0.7,
            default_top_p=0.5,
        )
    )

    @classmethod
    def from_files(cls, *, agent_home_dir: Path | None = None) -> "ModelProfileRegistry":
        """从内置配置与可选外部配置构造一个独立 registry。"""
        registry = cls()
        registry.load(agent_home_dir=agent_home_dir)
        return registry

    def load(self, *, agent_home_dir: Path | None = None) -> None:
        """加载内置 yaml，再用外部 yaml 覆盖。"""
        try:
            import yaml  # type: ignore[import-not-found]
        except Exception:
            # P0：缺依赖时回退 defaults；P1/P2 的接线会依赖此处输出可观测 warning
            logger.warning("pyyaml 未安装，跳过 model_profiles.yaml 加载，使用 defaults 兜底")
            return

        builtin_path = _builtin_profiles_path()
        builtin_profiles, builtin_defaults = self._parse_yaml(yaml, builtin_path)

        external_profiles: dict[str, ModelProfile] = {}
        external_defaults: ModelProfile | None = None
        if agent_home_dir is not None:
            ext_path = agent_home_dir / "provider" / "model_profiles.yaml"
            if ext_path.exists():
                external_profiles, external_defaults = self._parse_yaml(yaml, ext_path)
                logger.debug("已加载外部模型配置: %s (%d 条)", ext_path, len(external_profiles))

        merged = {**builtin_profiles, **external_profiles}
        self.defaults = external_defaults or builtin_defaults or self.defaults
        self.profiles = merged

    def get(self, model_id: str) -> ModelProfile:
        """按 model_id_prefix 做最长前缀优先匹配；未命中返回 defaults。"""
        if not model_id:
            return self.defaults
        matched: ModelProfile | None = None
        for p in self.profiles.values():
            if model_id.startswith(p.model_id_prefix):
                if matched is None or len(p.model_id_prefix) > len(matched.model_id_prefix):
                    matched = p
        return matched or self.defaults

    def _parse_yaml(
        self, yaml_mod: Any, path: Path
    ) -> tuple[dict[str, ModelProfile], ModelProfile | None]:
        try:
            raw = yaml_mod.safe_load(path.read_text(encoding="utf-8")) or {}
        except Exception as e:
            logger.warning("model_profiles.yaml 解析失败 %s: %s", path, e)
            return {}, None

        defaults_profile: ModelProfile | None = None
        if isinstance(raw, dict) and raw.get("defaults"):
            defaults_profile = self._parse_profile({"model_id_prefix": "__default__", **raw["defaults"]})

        result: dict[str, ModelProfile] = {}
        for item in (raw.get("profiles") or []) if isinstance(raw, dict) else []:
            if not isinstance(item, dict):
                continue
            try:
                p = self._parse_profile(item)
            except Exception as e:
                logger.warning("跳过无效 profile 条目 %s: %s", item, e)
                continue
            result[p.model_id_prefix] = p

        return result, defaults_profile

    @staticmethod
    def _parse_profile(item: dict[str, Any]) -> ModelProfile:
        return ModelProfile(
            model_id_prefix=str(item["model_id_prefix"]),
            context_window=int(item["context_window"]),
            max_output_tokens=int(item["max_output_tokens"]),
            provider=str(item.get("provider", "openai")),
            supports_cache=bool(item.get("supports_cache", False)),
            default_temperature=float(item.get("default_temperature", 0.7)),
            default_top_p=item.get("default_top_p", None),
        )


__all__ = [
    "ModelProfile",
    "ModelProfileRegistry",
]

