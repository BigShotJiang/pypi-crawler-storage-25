"""
Provider layer for langchain_agentx.

职责：
    对外提供模型 Provider 兼容封装入口。

链路位置：
    被 examples 与 loop/integration 侧导入，用于构建可替换的 ChatModel。

当前裁剪范围：
    - CompatibleChatOpenAI（OpenAI 兼容 reasoning_content 透传）
    - get_chat_openai / get_chat_anthropic（从环境变量构造 ChatModel 的可复用组合件）
"""

from .anthropic import get_chat_anthropic
from .compatible_chat_openai import CompatibleChatOpenAI
from .model_profile import ModelProfile, ModelProfileRegistry
from .openai import get_chat_openai

__all__ = [
    "CompatibleChatOpenAI",
    "get_chat_anthropic",
    "get_chat_openai",
    "ModelProfile",
    "ModelProfileRegistry",
]

