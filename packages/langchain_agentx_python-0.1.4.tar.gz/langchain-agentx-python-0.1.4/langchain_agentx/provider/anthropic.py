"""provider/anthropic.py — Anthropic ChatModel 工厂（可复用组合件）。

职责：
    - 从环境变量读取 Anthropic 配置（auth token/base_url/model）。
    - 处理部分企业代理环境下 httpx 对 socks:// 的不兼容。
    - 组装并返回 ChatAnthropic。

约束：
    - 不加载 .env；由调用方（例如 examples）负责把 .env 注入到环境变量。
"""

from __future__ import annotations

import os
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel

from .env import get_env_first, parse_positive_int
from .model_profile import ModelProfileRegistry


def _sanitize_proxy_env_for_anthropic() -> None:
    """Anthropic/httpx 不接受 socks://，保留 http/https 代理并移除异常 all_proxy。"""
    for key in ("all_proxy", "ALL_PROXY"):
        value = os.environ.get(key)
        if not value:
            continue
        if value.strip().lower().startswith("socks://"):
            os.environ.pop(key, None)


def _resolve_claude_max_tokens(explicit: int | None, *, profile_default: int) -> int:
    if explicit is not None:
        return int(explicit)
    override = get_env_first("CLAUDE_MAX_OUTPUT_TOKENS", "CLAUDE_CODE_MAX_OUTPUT_TOKENS")
    parsed = parse_positive_int(override)
    return parsed if parsed is not None else profile_default


def _is_thinking_enabled(thinking_option: Any) -> bool:
    if isinstance(thinking_option, bool):
        return thinking_option
    if isinstance(thinking_option, dict):
        enabled = thinking_option.get("enabled")
        if isinstance(enabled, bool):
            return enabled
        return bool(thinking_option)
    return False


def get_chat_anthropic(
    *,
    model: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    top_p: float | None = None,
    streaming: bool = True,
    model_profile_registry: ModelProfileRegistry | None = None,
    **kwargs: Any,
) -> BaseChatModel:
    from langchain_anthropic import ChatAnthropic  # pyright: ignore[reportMissingImports]

    _sanitize_proxy_env_for_anthropic()

    resolved_api_key = api_key or get_env_first(
        "LANGCHAIN_AGENTX_ANTHROPIC_AUTH_TOKEN",
        "ANTHROPIC_AUTH_TOKEN",
        "ANTHROPIC_API_KEY",
    )
    resolved_base_url = base_url or get_env_first(
        "LANGCHAIN_AGENTX_ANTHROPIC_BASE_URL",
        "ANTHROPIC_BASE_URL",
    )
    resolved_model = (
        model
        or get_env_first("LANGCHAIN_AGENTX_ANTHROPIC_MODEL", "ANTHROPIC_MODEL")
        or "claude-sonnet-4-20250514"
    )
    profile = (
        model_profile_registry.get(resolved_model)
        if model_profile_registry is not None
        else ModelProfileRegistry().defaults
    )

    if not resolved_api_key or not resolved_base_url:
        raise RuntimeError(
            "缺少 Anthropic 配置：请设置 ANTHROPIC_AUTH_TOKEN（或 ANTHROPIC_API_KEY /"
            " LANGCHAIN_AGENTX_ANTHROPIC_AUTH_TOKEN）以及 ANTHROPIC_BASE_URL"
            "（或 LANGCHAIN_AGENTX_ANTHROPIC_BASE_URL）。默认模型名可通过"
            " ANTHROPIC_MODEL / LANGCHAIN_AGENTX_ANTHROPIC_MODEL 或 model 参数指定。"
        )

    resolved_max_tokens = _resolve_claude_max_tokens(
        max_tokens,
        profile_default=profile.max_output_tokens,
    )
    thinking_enabled = _is_thinking_enabled(kwargs.get("thinking"))
    resolved_temperature = profile.default_temperature if temperature is None else float(temperature)
    resolved_top_p = profile.default_top_p if top_p is None else float(top_p)
    
    anthropic_kwargs: dict[str, Any] = {
        "model": resolved_model,
        "anthropic_api_key": resolved_api_key,
        "anthropic_api_url": resolved_base_url.rstrip("/"),
        "max_tokens": resolved_max_tokens,
        "streaming": streaming,
        **kwargs,
    }
    if resolved_top_p is not None:
        anthropic_kwargs["top_p"] = resolved_top_p
    if not thinking_enabled:
        anthropic_kwargs["temperature"] = resolved_temperature

    return ChatAnthropic(**anthropic_kwargs)


__all__ = ["get_chat_anthropic"]

