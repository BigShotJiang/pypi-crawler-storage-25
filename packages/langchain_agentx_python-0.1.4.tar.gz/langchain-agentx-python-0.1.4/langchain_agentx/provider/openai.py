"""provider/openai.py — OpenAI 兼容 ChatModel 工厂（可复用组合件）。

职责：
    - 从环境变量读取 OpenAI 兼容服务配置（key/base_url/model）。
    - 组装并返回 CompatibleChatOpenAI。

约束：
    - 不加载 .env；由调用方（例如 examples）负责把 .env 注入到环境变量。
"""

from __future__ import annotations

import os
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel

from .compatible_chat_openai import CompatibleChatOpenAI
from .env import get_env_first
from .model_profile import ModelProfileRegistry


def _sanitize_proxy_env_for_openai_compat() -> None:
    """部分 http 客户端不接受 socks:// 代理，移除异常 all_proxy。"""
    for key in ("all_proxy", "ALL_PROXY"):
        value = os.environ.get(key)
        if not value:
            continue
        if value.strip().lower().startswith("socks://"):
            os.environ.pop(key, None)


def get_chat_openai(
    *,
    model: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    top_p: float | None = None,
    streaming: bool = True,
    model_profile_registry: ModelProfileRegistry | None = None,
    **kwargs: Any,
) -> BaseChatModel:
    _sanitize_proxy_env_for_openai_compat()

    resolved_api_key = api_key or get_env_first(
        "LANGCHAIN_AGENTX_OPENAI_API_KEY",
        "OPENAI_API_KEY",
    )
    resolved_base_url = base_url or get_env_first(
        "LANGCHAIN_AGENTX_OPENAI_BASE_URL",
        "OPENAI_BASE_URL",
    )
    resolved_model = model or get_env_first("LANGCHAIN_AGENTX_MODEL") or "gpt-4o-mini"
    profile = (
        model_profile_registry.get(resolved_model)
        if model_profile_registry is not None
        else ModelProfileRegistry().defaults
    )

    if not resolved_api_key or not resolved_base_url:
        raise RuntimeError(
            "缺少 OpenAI 兼容端点配置：请设置 OPENAI_API_KEY（或 LANGCHAIN_AGENTX_OPENAI_API_KEY）"
            " 以及 OPENAI_BASE_URL（或 LANGCHAIN_AGENTX_OPENAI_BASE_URL）。"
            " 默认模型名可通过 LANGCHAIN_AGENTX_MODEL 或 model 参数指定。"
        )

    resolved_temperature = profile.default_temperature if temperature is None else float(temperature)
    resolved_max_tokens = profile.max_output_tokens if max_tokens is None else int(max_tokens)
    resolved_top_p = profile.default_top_p if top_p is None else float(top_p)

    init_kwargs: dict[str, Any] = {
        "model": resolved_model,
        "api_key": resolved_api_key,
        "base_url": resolved_base_url.rstrip("/"),
        "temperature": resolved_temperature,
        "max_tokens": resolved_max_tokens,
        "streaming": streaming,
        **kwargs,
    }
    if resolved_top_p is not None:
        init_kwargs["top_p"] = resolved_top_p

    return CompatibleChatOpenAI(**init_kwargs)


__all__ = ["get_chat_openai"]

