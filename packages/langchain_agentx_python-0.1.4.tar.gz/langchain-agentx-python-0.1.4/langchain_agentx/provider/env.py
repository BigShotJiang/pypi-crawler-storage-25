"""provider/env.py — provider 工厂的环境变量解析工具。

职责：
    为 provider 工厂函数提供一致的 env 读取与布尔/数值解析。

约束：
    - 只读取 os.environ，不加载 .env（示例层负责）
"""

from __future__ import annotations

import os


def get_env_first(*names: str) -> str | None:
    for name in names:
        v = os.environ.get(name)
        if v and str(v).strip():
            return str(v).strip()
    return None


def parse_positive_int(raw: str | None) -> int | None:
    if raw is None:
        return None
    try:
        value = int(str(raw).strip())
    except ValueError:
        return None
    return value if value > 0 else None


def parse_bool(raw: str | None) -> bool | None:
    if raw is None:
        return None
    v = str(raw).strip().lower()
    if v in {"1", "true", "yes", "y", "on"}:
        return True
    if v in {"0", "false", "no", "n", "off"}:
        return False
    return None


__all__ = ["get_env_first", "parse_bool", "parse_positive_int"]

