"""
workspace/path_key_normalizer.py — 路径字符串键 NFC 稳定化

职责：对作为持久化键 / 文件名片段的路径相关字符串做 Unicode NFC，与 CC `normalize('NFC')` 同向。
在整体链路中的位置：AgentWorkspaceConfig 派生会话文件路径等边界；不在 expand_path 默认链上调用。
当前裁剪范围：仅 NFC；不 resolve、不替代 workspace 越界校验（见 validators）。调用方：``session_memory_path``、``_sanitize_agent_type``、``_normalize_memory_scope``（``agent_memory_dir``）。
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PathKeyNormalizer:
    """无状态键稳定化；多线程只读安全。"""

    form: str = "NFC"

    def normalize(self, path: str) -> str:
        return unicodedata.normalize(self.form, path)


_DEFAULT_NORMALIZER = PathKeyNormalizer()


def normalize_path_key(path: str) -> str:
    """模块级薄封装：会话 id、未来其它「键串」边界的默认 NFC。"""
    return _DEFAULT_NORMALIZER.normalize(path)
