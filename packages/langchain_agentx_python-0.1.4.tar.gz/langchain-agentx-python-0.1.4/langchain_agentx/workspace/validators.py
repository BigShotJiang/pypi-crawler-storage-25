"""
workspace/validators.py — AgentWorkspace 路径校验协作者

职责：
    统一封装 workspace 目录相关校验规则（agent_home 合法性、越界检查），
    作为 resolver 的纯校验依赖，避免调用方散落 if/else 逻辑。

在整体链路中的位置：
    AgentWorkspaceResolver.resolve()
      -> AgentWorkspacePathValidator.validate_agent_home()
      -> AgentWorkspacePathValidator.ensure_within_workspace()

当前裁剪范围：
    仅覆盖路径规范与越界校验；不承载目录创建与业务策略。
"""

from __future__ import annotations

from pathlib import Path


class AgentWorkspacePathValidator:
    """Agent workspace 路径规则校验器。"""

    def validate_agent_home(self, agent_home: str) -> str:
        text = (agent_home or "").strip()
        if not text:
            raise ValueError("agent_home cannot be empty")
        path = Path(text)
        if path.is_absolute():
            raise ValueError("agent_home must be a relative path")
        if ".." in path.parts:
            raise ValueError("agent_home cannot contain '..'")
        return text

    def ensure_within_workspace(self, workspace_root: Path, candidate: Path) -> Path:
        base = workspace_root.resolve()
        resolved = candidate.resolve()
        if not str(resolved).startswith(str(base)):
            raise ValueError("Resolved path escapes workspace_root")
        return resolved
