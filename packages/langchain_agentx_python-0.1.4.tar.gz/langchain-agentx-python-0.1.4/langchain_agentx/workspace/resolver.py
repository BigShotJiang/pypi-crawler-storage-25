"""
workspace/resolver.py — AgentWorkspace 配置解析协作者

职责：
    按统一优先级解析 workspace_root 与 agent_home，并产出
    AgentWorkspaceConfig，作为全局目录语义单一来源。

在整体链路中的位置：
    各入口（tool_runtime / task_runtime / loop / observability）
      -> resolve_agent_workspace_config()
      -> AgentWorkspaceResolver.resolve()

当前裁剪范围：
    解析与校验；不直接做业务目录写入。
"""

from __future__ import annotations

import os
from pathlib import Path

from .config import AgentWorkspaceConfig
from .validators import AgentWorkspacePathValidator

DEFAULT_AGENT_HOME = ".langchain_agentx"
ENV_AGENT_HOME = "LANGCHAIN_AGENTX_AGENT_HOME"
ENV_WORKSPACE_ROOT = "LANGCHAIN_AGENTX_WORKSPACE_ROOT"


class AgentWorkspaceResolver:
    """Agent workspace 配置解析器。"""

    def __init__(
        self,
        *,
        default_agent_home: str = DEFAULT_AGENT_HOME,
        env_agent_home: str = ENV_AGENT_HOME,
        env_workspace_root: str = ENV_WORKSPACE_ROOT,
        path_validator: AgentWorkspacePathValidator | None = None,
    ) -> None:
        self._default_agent_home = default_agent_home
        self._env_agent_home = env_agent_home
        self._env_workspace_root = env_workspace_root
        self._path_validator = path_validator or AgentWorkspacePathValidator()

    def resolve(
        self,
        *,
        workspace_root: str | Path | None = None,
        agent_home: str | None = None,
    ) -> AgentWorkspaceConfig:
        root_raw = workspace_root or os.getenv(self._env_workspace_root) or os.getcwd()
        root = Path(root_raw).expanduser().resolve()
        home_raw = (
            agent_home
            if agent_home is not None
            else os.getenv(self._env_agent_home, self._default_agent_home)
        )
        home = self._path_validator.validate_agent_home(home_raw)
        cfg = AgentWorkspaceConfig(workspace_root=root, agent_home=home)
        self._path_validator.ensure_within_workspace(cfg.workspace_root, cfg.agent_home_dir)
        return cfg


_DEFAULT_RESOLVER = AgentWorkspaceResolver()


def resolve_agent_workspace_config(
    *,
    workspace_root: str | Path | None = None,
    agent_home: str | None = None,
) -> AgentWorkspaceConfig:
    """兼容入口：调用默认 AgentWorkspaceResolver。"""
    return _DEFAULT_RESOLVER.resolve(workspace_root=workspace_root, agent_home=agent_home)
