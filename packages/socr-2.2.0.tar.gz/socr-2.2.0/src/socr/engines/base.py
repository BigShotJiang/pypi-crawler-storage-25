"""Base engine adapters for socr.

Two engine families:
  - BaseEngine: CLI-based, one subprocess per document (standard mode)
  - BaseHTTPEngine: HTTP API, per-page processing (HPC mode with vLLM)
"""

import logging
import subprocess
import tempfile
import time
from abc import ABC, abstractmethod
from pathlib import Path

from socr.core.config import PipelineConfig
from socr.core.normalizer import OutputNormalizer
from socr.core.result import (
    DocumentStatus,
    EngineResult,
    FailureMode,
    FigureInfo,
    PageOutput,
    PageStatus,
)

logger = logging.getLogger(__name__)

_normalizer = OutputNormalizer()


def sanitize_filename(name: str) -> str:
    """Sanitize a filename for use as a directory name."""
    return "".join(c if c.isalnum() or c in "._- " else "_" for c in name).strip()


class BaseEngine(ABC):
    """Abstract base class for CLI-based OCR engines.

    Each engine wraps a sibling CLI tool (gemini-ocr, nougat-ocr, etc.).
    The contract: call CLI once per PDF, read output markdown from
    {output_dir}/{stem}/{stem}.md.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Engine identifier (matches EngineType value)."""
        ...

    @property
    @abstractmethod
    def cli_command(self) -> str:
        """The CLI binary name (e.g., 'gemini-ocr', 'nougat-ocr')."""
        ...

    @property
    def model_version(self) -> str:
        """Model version string. Override in subclasses that know their model."""
        return ""

    def is_available(self) -> bool:
        """Check if the CLI tool is installed and callable."""
        try:
            result = subprocess.run(
                [self.cli_command, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, FileNotFoundError):
            return False

    def process_document(
        self,
        pdf_path: Path,
        output_dir: Path,
        config: PipelineConfig,
    ) -> EngineResult:
        """Process a PDF document via CLI subprocess.

        Calls the CLI once on the whole PDF, reads the output markdown.
        Returns EngineResult with a single PageOutput containing the full text.
        """
        start_time = time.time()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_out = Path(tmpdir)
            cmd = self._build_command(pdf_path, tmp_out, config)

            logger.info(f"[{self.name}] Running: {' '.join(cmd)}")

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=config.timeout,
                )

                if result.returncode != 0:
                    stderr = result.stderr.strip() if result.stderr else "Unknown error"
                    logger.error(f"[{self.name}] CLI failed: {stderr}")
                    return EngineResult(
                        document_path=pdf_path,
                        engine=self.name,
                        status=DocumentStatus.ERROR,
                        failure_mode=FailureMode.CLI_ERROR,
                        error=f"CLI exited {result.returncode}: {stderr[:500]}",
                        processing_time=time.time() - start_time,
                        model_version=self.model_version,
                    )

                # Read output markdown
                markdown = self._read_output(pdf_path, tmp_out)
                if markdown is None:
                    return EngineResult(
                        document_path=pdf_path,
                        engine=self.name,
                        status=DocumentStatus.ERROR,
                        failure_mode=FailureMode.EMPTY_OUTPUT,
                        error="CLI produced no output markdown",
                        processing_time=time.time() - start_time,
                        model_version=self.model_version,
                    )

                elapsed = time.time() - start_time
                return EngineResult(
                    document_path=pdf_path,
                    engine=self.name,
                    status=DocumentStatus.SUCCESS,
                    pages=[
                        PageOutput(
                            page_num=0,
                            text=markdown,
                            status=PageStatus.SUCCESS,
                            engine=self.name,
                            processing_time=elapsed,
                        )
                    ],
                    processing_time=elapsed,
                    model_version=self.model_version,
                )

            except subprocess.TimeoutExpired:
                return EngineResult(
                    document_path=pdf_path,
                    engine=self.name,
                    status=DocumentStatus.ERROR,
                    failure_mode=FailureMode.TIMEOUT,
                    error=f"Timeout after {config.timeout}s",
                    processing_time=time.time() - start_time,
                    model_version=self.model_version,
                )

    def process_pages(
        self,
        pdf_path: Path,
        page_nums: list[int],
        config: PipelineConfig,
        dpi: int = 200,
    ) -> list[PageOutput]:
        """Process specific pages by rendering to images and calling the CLI.

        Renders each page to a PNG image, saves to a temp directory, calls the
        CLI on the directory, and reads back per-page markdown. Returns one
        PageOutput per page with the actual OCR text (no page_num=0 hack).

        Args:
            pdf_path: Path to the source PDF.
            page_nums: 1-indexed page numbers to process.
            config: Pipeline configuration.
            dpi: Render DPI for page images.

        Returns:
            List of PageOutput, one per page_num, in the same order.
        """
        import fitz
        from PIL import Image

        start_time = time.time()

        with tempfile.TemporaryDirectory() as tmpdir:
            images_dir = Path(tmpdir) / "images"
            images_dir.mkdir()
            cli_out = Path(tmpdir) / "out"

            # Render pages to numbered PNG images
            page_num_to_stem: dict[int, str] = {}
            with fitz.open(pdf_path) as doc:
                mat = fitz.Matrix(dpi / 72, dpi / 72)
                for page_num in page_nums:
                    stem = f"page_{page_num:04d}"
                    page_num_to_stem[page_num] = stem
                    pix = doc[page_num - 1].get_pixmap(matrix=mat)
                    img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                    img.save(images_dir / f"{stem}.png")

            # Call CLI on the image directory
            cmd = self._build_command(images_dir, cli_out, config)
            logger.info(f"[{self.name}] Processing {len(page_nums)} pages: {' '.join(cmd)}")

            try:
                result = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=config.timeout,
                )
            except subprocess.TimeoutExpired:
                return [
                    PageOutput(
                        page_num=pn, status=PageStatus.ERROR, engine=self.name,
                        failure_mode=FailureMode.TIMEOUT,
                        error=f"Timeout after {config.timeout}s",
                    )
                    for pn in page_nums
                ]

            if result.returncode != 0:
                stderr = (result.stderr or "").strip()[:500]
                return [
                    PageOutput(
                        page_num=pn, status=PageStatus.ERROR, engine=self.name,
                        failure_mode=FailureMode.CLI_ERROR,
                        error=f"CLI exited {result.returncode}: {stderr}",
                    )
                    for pn in page_nums
                ]

            # Read per-page output: CLI writes {cli_out}/{stem}/{stem}.md
            elapsed = time.time() - start_time
            outputs: list[PageOutput] = []

            for page_num in page_nums:
                stem = page_num_to_stem[page_num]
                text = self._read_page_output(stem, cli_out)

                if text:
                    text = self._clean_output(text, self.name)
                    outputs.append(PageOutput(
                        page_num=page_num,
                        text=text,
                        status=PageStatus.SUCCESS,
                        engine=self.name,
                        processing_time=elapsed / len(page_nums),
                        audit_passed=True,
                    ))
                else:
                    outputs.append(PageOutput(
                        page_num=page_num,
                        status=PageStatus.ERROR,
                        engine=self.name,
                        failure_mode=FailureMode.EMPTY_OUTPUT,
                        error=f"No output for page {page_num}",
                    ))

            return outputs

    def _read_page_output(self, stem: str, output_dir: Path) -> str | None:
        """Read output markdown for a single page image.

        Tries the standard CLI output layouts:
          - {output_dir}/{stem}/{stem}.md (subdirectory)
          - {output_dir}/{stem}.md (flat)
        """
        # Subdirectory layout
        md_path = output_dir / stem / f"{stem}.md"
        if md_path.exists():
            return md_path.read_text(encoding="utf-8")

        # Flat layout
        flat_path = output_dir / f"{stem}.md"
        if flat_path.exists():
            return flat_path.read_text(encoding="utf-8")

        # Sanitized name variant (some CLIs sanitize differently)
        sanitized = sanitize_filename(stem)
        if sanitized != stem:
            for variant in [
                output_dir / sanitized / f"{sanitized}.md",
                output_dir / f"{sanitized}.md",
            ]:
                if variant.exists():
                    return variant.read_text(encoding="utf-8")

        return None

    @abstractmethod
    def _build_command(
        self,
        pdf_path: Path,
        output_dir: Path,
        config: PipelineConfig,
    ) -> list[str]:
        """Build the CLI command for this engine."""
        ...

    def _read_output(self, pdf_path: Path, output_dir: Path) -> str | None:
        """Read the output markdown from the CLI's output directory.

        Sibling CLIs use different output structures:
          - gemini-ocr: {output_dir}/{sanitized_stem}/{sanitized_stem}.md
          - deepseek-ocr: {output_dir}/{stem}/{stem}.md
          - mistral-ocr: {output_dir}/{stem}.md (flat, no subdirectory)
          - nougat-ocr/marker-ocr: {output_dir}/{stem}/{stem}.md
        """
        stem = sanitize_filename(pdf_path.stem)

        # Try subdirectory layout first: {output_dir}/{stem}/{stem}.md
        md_path = output_dir / stem / f"{stem}.md"
        if md_path.exists():
            return self._clean_output(md_path.read_text(encoding="utf-8"), self.name)

        # Try flat layout: {output_dir}/{stem}.md
        flat_path = output_dir / f"{stem}.md"
        if flat_path.exists():
            return self._clean_output(flat_path.read_text(encoding="utf-8"), self.name)

        # Fallback: find any .md file (handles sanitization mismatches)
        for md_file in output_dir.rglob("*.md"):
            # Guard against symlinks escaping the temp directory
            if not md_file.resolve().is_relative_to(output_dir.resolve()):
                logger.warning(f"[{self.name}] Skipping symlink outside output dir: {md_file}")
                continue
            logger.warning(f"[{self.name}] Output found via rglob fallback: {md_file}")
            return self._clean_output(md_file.read_text(encoding="utf-8"), self.name)

        return None

    @staticmethod
    def _clean_output(text: str, engine: str = "") -> str:
        """Remove frontmatter, metadata headers, and normalize CLI output.

        Handles:
          - YAML frontmatter (--- ... ---)
          - Metadata headers (# OCR Results + **Original File:** + **Processed:** + ---)
          - Engine-specific artifact cleanup (via OutputNormalizer)
          - Generic markdown normalization (line endings, whitespace, unicode)
        """
        import re

        # Strip YAML frontmatter
        if text.startswith("---"):
            parts = text.split("---", 2)
            if len(parts) >= 3:
                text = parts[2].strip()

        # Strip metadata header block (mistral-ocr format):
        # # OCR Results\n\n**Original File:**...\n**Full Path:**...\n**Processed:**...\n\n---
        # Requires at least one metadata line to avoid stripping real "# OCR Results" headings
        text = re.sub(
            r"^#\s*OCR Results\s*\n+"
            r"(?:\*\*(?:Original File|Full Path|Processed|Processing Time):\*\*[^\n]*\n)+"
            r"\s*(?:---\s*\n)?",
            "",
            text,
        ).strip()

        # Apply engine-specific + generic normalization
        text = _normalizer.normalize(text, engine=engine)

        return text


class BaseHTTPEngine(ABC):
    """Abstract base class for HTTP API engines (vLLM, HPC mode).

    These engines call a local vLLM server per-page via OpenAI-compatible API.
    They are NOT CLI-based — they use httpx to talk to a running server.
    """

    def __init__(self) -> None:
        self._initialized: bool = False

    @property
    @abstractmethod
    def name(self) -> str:
        ...

    @property
    def model_version(self) -> str:
        """Model version string. Override in subclasses."""
        return ""

    @abstractmethod
    def initialize(self) -> bool:
        """Connect to the server and verify it's ready."""
        ...

    def is_available(self) -> bool:
        """Check if the engine can be initialized."""
        return self._initialized or self.initialize()

    @abstractmethod
    def process_image(self, image: "Image.Image", page_num: int = 1) -> PageOutput:
        """Process a single page image and return structured output."""
        ...

    def describe_figure(
        self,
        image: "Image.Image",
        figure_type: str = "unknown",
        context: str = "",
    ) -> FigureInfo:
        """Describe a figure image. Override in subclasses that support this."""
        return FigureInfo(
            figure_num=0,
            page_num=0,
            figure_type=figure_type,
            description="Figure description not supported by this engine",
        )

    def close(self) -> None:
        """Clean up resources."""
        pass

    @staticmethod
    def _create_success_result(
        page_num: int,
        text: str,
        engine: str = "",
        confidence: float = 0.0,
        processing_time: float = 0.0,
    ) -> PageOutput:
        return PageOutput(
            page_num=page_num,
            text=text,
            status=PageStatus.SUCCESS,
            engine=engine,
            processing_time=processing_time,
            confidence=confidence,
        )

    @staticmethod
    def _create_error_result(
        page_num: int,
        error: str,
        failure_mode: FailureMode = FailureMode.API_ERROR,
    ) -> PageOutput:
        return PageOutput(
            page_num=page_num,
            status=PageStatus.ERROR,
            failure_mode=failure_mode,
            error=error,
        )
