"""Antigravity conversation exporter — uses antigravity-history API directly."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from urllib.parse import unquote

logger = logging.getLogger("collector.antigravity_export")

# Cache: cascade_id → content_hash
_last_hashes: dict[str, str] = {}


def _format_tool_call(tool_name: str, args_json: str) -> tuple[str, str]:
    """Format a toolCall into human-readable (tool_input, content)."""
    try:
        args = json.loads(args_json) if isinstance(args_json, str) else args_json
    except (json.JSONDecodeError, TypeError):
        return (args_json[:300], args_json[:500])

    if not isinstance(args, dict):
        return (str(args)[:300], str(args)[:500])

    # write_to_file / multi_replace_file_content — show file path + content
    if tool_name in ("write_to_file", "multi_replace_file_content", "replace_file_content"):
        target = args.get("TargetFile", "")
        description = args.get("Description", "")
        code = args.get("CodeContent", args.get("ReplacementContent", ""))
        summary = args.get("ArtifactMetadata", {}).get("Summary", "")
        parts = []
        if description:
            parts.append(description)
        if summary:
            parts.append(f"*{summary}*")
        if code:
            lang = args.get("CodeMarkdownLanguage", "")
            parts.append(f"```{lang}\n{code[:1500]}\n```")
        return (target or description, "\n".join(parts) if parts else description)

    # task_boundary — progress update
    if tool_name == "task_boundary":
        name = args.get("TaskName", "")
        status = args.get("TaskStatus", "")
        summary = args.get("TaskSummary", "")
        mode = args.get("Mode", "")
        if name == "%SAME%":
            name = ""
        parts = []
        if mode and mode != "%SAME%":
            parts.append(f"**[{mode}]**")
        if name:
            parts.append(f"**{name}**")
        if status:
            parts.append(status)
        if summary:
            parts.append(f"\n{summary}")
        return ("", "\n".join(parts) if parts else "")

    # find_by_name
    if tool_name in ("find_by_name", "find"):
        pattern = args.get("Pattern", args.get("pattern", ""))
        search_dir = args.get("SearchDirectory", args.get("searchDirectory", ""))
        return (f"{pattern} in {search_dir}", f"Find `{pattern}` in `{search_dir}`")

    # list_dir
    if tool_name in ("list_dir", "list_directory"):
        path = args.get("DirectoryPath", args.get("directoryPath", ""))
        return (path, f"`{path}`")

    # grep_search
    if tool_name in ("grep_search", "codebase_search"):
        query = args.get("Query", args.get("query", args.get("Pattern", "")))
        target = args.get("TargetDirectory", args.get("Directory", ""))
        return (query, f"Search `{query}`" + (f" in `{target}`" if target else ""))

    # view_file
    if tool_name in ("view_file", "read_file"):
        path = args.get("AbsolutePath", args.get("TargetFile", args.get("absolutePathUri", "")))
        return (path, f"`{path}`")

    # Generic: extract the most meaningful field
    for key in ("Description", "Summary", "description", "summary", "message", "text"):
        if args.get(key):
            return (args[key][:100], args[key])
    display = args.get("DirectoryPath") or args.get("TargetFile") or args.get("Pattern") or ""
    if display:
        return (display, f"`{display}`")
    return ("", json.dumps(args, ensure_ascii=False, indent=2)[:300])


def _step_to_jsonl_line(step: dict, cascade_id: str, fallback_ts: str) -> dict | None:
    """Convert an Antigravity trajectory step to a JSONL message."""
    step_type = step.get("type", "")
    ts = step.get("metadata", {}).get("createdAt", "") or fallback_ts

    if step_type == "CORTEX_STEP_TYPE_USER_INPUT":
        text = step.get("userInput", {}).get("userResponse", "")
        if text:
            return {"type": "user", "message": {"role": "user", "content": text}, "timestamp": ts, "cwd": ""}

    elif step_type == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
        text = step.get("plannerResponse", {}).get("response", "")
        if text:
            return {"type": "assistant", "message": {"role": "assistant", "content": [{"type": "text", "text": text}]}, "timestamp": ts}

    elif step_type == "CORTEX_STEP_TYPE_NOTIFY_USER":
        payload = step.get("notifyUser", {})
        text = payload.get("message") or payload.get("text") or ""
        if text:
            return {"type": "assistant", "message": {"role": "assistant", "content": [{"type": "text", "text": text}]}, "timestamp": ts}

    elif step_type == "CORTEX_STEP_TYPE_ERROR_MESSAGE":
        payload = step.get("errorMessage", {})
        text = payload.get("shortError") or payload.get("text") or ""
        if text:
            return {"type": "system", "message": {"role": "system", "content": text}, "timestamp": ts}

    elif step_type in ("CORTEX_STEP_TYPE_TASK_BOUNDARY", "CORTEX_STEP_TYPE_CHECKPOINT",
                        "CORTEX_STEP_TYPE_CONVERSATION_HISTORY", "CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE"):
        # Task boundary: show as progress update (not skip)
        if step_type == "CORTEX_STEP_TYPE_TASK_BOUNDARY":
            meta = step.get("metadata", {})
            tool_call = meta.get("toolCall", {})
            args_json = tool_call.get("argumentsJson", "")
            if args_json:
                tool_input, content = _format_tool_call("task_boundary", args_json)
                if content:
                    return {"type": "system", "message": {"role": "system", "content": content}, "timestamp": ts}
        return None  # Skip other internal types

    else:
        # All tool-like steps: RUN_COMMAND, VIEW_FILE, CODE_ACTION, LIST_DIR, GREP, FIND, etc.
        # First try metadata.toolCall
        meta = step.get("metadata", {})
        tool_call = meta.get("toolCall", {})
        tool_name = tool_call.get("name", "")
        args_json = tool_call.get("argumentsJson", "")

        # Fallback for specific step types
        if not tool_name:
            if step_type == "CORTEX_STEP_TYPE_RUN_COMMAND":
                payload = step.get("runCommand", {})
                cmd = payload.get("command") or payload.get("commandLine") or ""
                output = payload.get("renderedOutput", {})
                out_text = output.get("full", "") if isinstance(output, dict) else str(output or "")
                if cmd:
                    return {"type": "tool", "role": "tool", "tool_name": "run_command", "tool_input": cmd, "content": out_text[:2000], "timestamp": ts}
                return None
            elif step_type == "CORTEX_STEP_TYPE_VIEW_FILE":
                payload = step.get("viewFile", {})
                path = payload.get("absolutePath") or payload.get("absolutePathUri") or ""
                if path:
                    return {"type": "tool", "role": "tool", "tool_name": "view_file", "tool_input": path, "content": f"`{path}`", "timestamp": ts}
                return None
            else:
                return None

        tool_input, content = _format_tool_call(tool_name, args_json)
        return {"type": "tool", "role": "tool", "tool_name": tool_name, "tool_input": tool_input, "content": content[:3000], "timestamp": ts}

    return None


def export_conversations() -> list[dict]:
    """Export Antigravity conversations as JSONL (compatible with conversation parser).

    Requires: pip install antigravity-history
    Requires: Antigravity IDE to be running

    Returns list of changed conversations with JSONL content.
    """
    try:
        from antigravity_history.discovery import discover_language_servers, find_all_endpoints
        from antigravity_history.api import get_all_trajectories, call_api
    except ImportError:
        logger.debug("antigravity-history not installed, skipping")
        return []

    try:
        servers = discover_language_servers()
        if not servers:
            return []
        endpoints = find_all_endpoints(servers)
        if not endpoints:
            return []
    except Exception as e:
        logger.debug("Antigravity discovery failed: %s", e)
        return []

    conversations = []

    for ep in endpoints:
        # Layer 1: Get summaries from live API (recent conversations)
        try:
            summaries = get_all_trajectories(ep["port"], ep["csrf"])
        except Exception:
            summaries = {}

        # Layer 2: Scan .pb files for ALL cascade IDs, then fetch individually
        import re
        import platform
        home = Path.home()
        if platform.system() == "Windows":
            import os
            appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
            gemini_root = appdata / ".gemini" if (appdata / ".gemini").exists() else home / ".gemini"
        else:
            gemini_root = home / ".gemini"
        conv_root = gemini_root / "antigravity" / "conversations"

        uuid_re = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
        pb_count = 0
        fetched = 0
        if conv_root.exists():
            from antigravity_history.api import call_api
            for pb_file in conv_root.glob("*.pb"):
                cid = pb_file.stem
                if uuid_re.match(cid) and cid not in summaries:
                    pb_count += 1
                    try:
                        payload = call_api(ep["port"], ep["csrf"], "GetCascadeTrajectory", {"cascadeId": cid}, timeout=15)
                        if payload:
                            traj = payload.get("trajectory", payload)
                            if traj.get("summary") or traj.get("cascadeId"):
                                summaries[cid] = {
                                    "summary": traj.get("summary", cid[:8]),
                                    "stepCount": traj.get("stepCount") or len(traj.get("steps", [])),
                                    "lastModifiedTime": traj.get("lastModifiedTime", ""),
                                    "createdTime": traj.get("createdAt", traj.get("createdTime", "")),
                                    "status": traj.get("status", ""),
                                    "workspaces": traj.get("workspaces", []),
                                }
                                fetched += 1
                    except Exception as e:
                        logger.debug("Failed to fetch cascade %s: %s", cid[:8], e)
        if pb_count > 0:
            logger.info("Scanned %d .pb files, fetched %d additional conversations", pb_count, fetched)

        for cascade_id, info in summaries.items():
            title = info.get("summary", cascade_id[:8])
            step_count = info.get("stepCount", 0)
            last_modified = info.get("lastModifiedTime", "")
            created = info.get("createdTime", "")

            # Extract workspace
            workspace = ""
            workspaces = info.get("workspaces", [])
            if workspaces and isinstance(workspaces[0], dict):
                workspace = workspaces[0].get("workspaceFolderAbsoluteUri", "")

            # Incremental: skip unchanged (v2 = format version, forces re-export on format change)
            summary_key = f"v7:{cascade_id}:{step_count}:{last_modified}"
            content_hash = hashlib.sha256(summary_key.encode()).hexdigest()[:16]
            if _last_hashes.get(cascade_id) == content_hash:
                continue
            _last_hashes[cascade_id] = content_hash

            # Resolve workspace to cwd path
            cwd = ""
            if workspace:
                cwd = unquote(workspace).replace("\\", "/")
                if cwd.startswith("file:///"):
                    cwd = cwd[7:] if cwd[8:9] != ":" else cwd[8:]

            # Build JSONL content — fetch all steps
            jsonl_lines = []

            # First line: session metadata (like Codex format)
            jsonl_lines.append(json.dumps({
                "type": "session_meta",
                "timestamp": created,
                "payload": {
                    "id": cascade_id,
                    "timestamp": created,
                    "cwd": cwd,
                    "originator": "Antigravity",
                    "model_provider": "google",
                    "title": title,
                    "step_count": step_count,
                    "status": info.get("status", ""),
                },
            }, ensure_ascii=False))

            try:
                # Use verbosity=1 (DEBUG) to get all steps without pagination
                # This is the same approach as antigravity-trajectory-extractor
                steps_response = call_api(
                    ep["port"], ep["csrf"], "GetCascadeTrajectorySteps",
                    {"cascadeId": cascade_id, "verbosity": 1},
                    timeout=60,
                )
                steps = (steps_response or {}).get("steps", []) if steps_response else []
                for step in steps:
                    msg = _step_to_jsonl_line(step, cascade_id, last_modified)
                    if msg:
                        if msg["type"] == "user" and cwd and not msg.get("cwd"):
                            msg["cwd"] = cwd
                        jsonl_lines.append(json.dumps(msg, ensure_ascii=False))
            except Exception as e:
                logger.debug("Failed to fetch steps for %s: %s", cascade_id, e)

            content = "\n".join(jsonl_lines)

            # Project name from workspace
            project_name = cwd.rstrip("/").split("/")[-1] if cwd else None

            conversations.append({
                "title": title,
                "cascade_id": cascade_id,
                "workspace": workspace,
                "project_name": project_name,
                "size": len(content),
                "content": content,
                "content_hash": content_hash,
            })

    if conversations:
        logger.info("Exported %d changed Antigravity conversations", len(conversations))
    return conversations
