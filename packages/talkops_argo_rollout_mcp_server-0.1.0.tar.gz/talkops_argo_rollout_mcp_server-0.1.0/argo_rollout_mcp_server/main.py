"""Application entry point."""

import sys
from pathlib import Path

# Suppress InsecureRequestWarning when connecting to clusters with self-signed certs
# (e.g. Docker Desktop, minikube, kind)
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Add project root to Python path for direct execution with uv run
project_root = Path(__file__).parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from argo_rollout_mcp_server.server.bootstrap import ServerBootstrap


def main():
    """Run the MCP server."""
    try:
        mcp, config = ServerBootstrap.initialize()
        
        # Run FastMCP server with the configured transport
        if config.transport == 'http':
            # HTTP/Streamable HTTP transport mode (single unified endpoint)
            mcp.run(transport='streamable-http', host=config.host, port=config.port, path=config.path)
        else:
            # STDIO transport mode (default for MCP)
            mcp.run()
    
    except KeyboardInterrupt:
        pass
    except Exception as e:
        raise


def cli():
    """CLI entry point for the argo-rollout-mcp-server command."""
    main()


if __name__ == '__main__':
    cli()
