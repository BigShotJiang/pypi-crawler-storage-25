import asyncio
import os
from collections.abc import Callable
from pathlib import Path

import pytest

import imbue.resource_guards.resource_guards as resource_guards
from imbue.resource_guards.resource_guards import MethodKind
from imbue.resource_guards.resource_guards import ResourceGuardViolation
from imbue.resource_guards.resource_guards import _PerTestGuardState
from imbue.resource_guards.resource_guards import _build_per_test_guard_env
from imbue.resource_guards.resource_guards import _check_guard_violations
from imbue.resource_guards.resource_guards import cleanup_resource_guard_wrappers
from imbue.resource_guards.resource_guards import cleanup_sdk_resource_guards
from imbue.resource_guards.resource_guards import create_resource_guard_wrappers
from imbue.resource_guards.resource_guards import create_sdk_method_guard
from imbue.resource_guards.resource_guards import create_sdk_resource_guards
from imbue.resource_guards.resource_guards import enforce_sdk_guard
from imbue.resource_guards.resource_guards import generate_stub_wrapper_script
from imbue.resource_guards.resource_guards import generate_wrapper_script
from imbue.resource_guards.resource_guards import get_guarded_resource_names
from imbue.resource_guards.resource_guards import register_all_resource_guards
from imbue.resource_guards.resource_guards import register_guarded_resource_markers
from imbue.resource_guards.resource_guards import register_resource_guard
from imbue.resource_guards.resource_guards import register_sdk_guard
from imbue.resource_guards.resource_guards import start_resource_guards
from imbue.resource_guards.resource_guards import stop_resource_guards

# Use ubiquitous coreutils binaries so these tests run on any system.
_TEST_RESOURCES = ["echo", "cat", "ls"]

# Conftest that pytester injects into its temp directory.  It registers the
# resource guard hooks for "cat" only, which is enough for end-to-end tests.
# cat is a good choice: `cat /dev/null` succeeds, `cat /nonexistent` fails.
# Tests using pytester must request the clean_guard_env fixture so the
# child subprocess doesn't inherit the outer process's guard wrapper PATH.
_PYTESTER_CONFTEST = """\
from imbue.resource_guards.resource_guards import (
    register_resource_guard,
    start_resource_guards,
    stop_resource_guards,
)

register_resource_guard("cat")

def pytest_configure(config):
    config.addinivalue_line("markers", "cat: test uses cat")

def pytest_sessionstart(session):
    start_resource_guards(session)

def pytest_sessionfinish(session, exitstatus):
    stop_resource_guards()
"""

pytest_plugins = ["pytester"]


# ---------------------------------------------------------------------------
# Script generation (unit tests)
# ---------------------------------------------------------------------------


def test_generate_stub_wrapper_script_contains_shebang_and_exit() -> None:
    script = generate_stub_wrapper_script("mybin")
    assert script.startswith("#!/bin/bash\n")
    assert "not installed on this machine" in script
    assert "exit 127" in script
    assert "$_PYTEST_GUARD_MYBIN" in script


def test_generate_wrapper_script_contains_shebang_and_exec() -> None:
    script = generate_wrapper_script("mybin", "/usr/bin/mybin")
    assert script.startswith("#!/bin/bash\n")
    assert 'exec "/usr/bin/mybin" "$@"' in script


def test_generate_wrapper_script_contains_guard_check() -> None:
    script = generate_wrapper_script("mybin", "/usr/bin/mybin")
    assert "$_PYTEST_GUARD_MYBIN" in script
    assert "@pytest.mark.mybin" in script
    assert '"block"' in script
    assert '"allow"' in script


# ---------------------------------------------------------------------------
# End-to-end guard behavior (pytester)
# ---------------------------------------------------------------------------


def test_marked_test_that_calls_resource_passes(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test with @pytest.mark.cat that calls cat should pass."""
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        import subprocess
        import pytest

        @pytest.mark.cat
        def test_cat_dev_null():
            subprocess.run(["cat", "/dev/null"], check=True)
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)


def test_guards_work_with_xdist_workers(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """Guards enforce correctly when xdist distributes tests across workers.

    The controller creates wrapper scripts and sets PATH; workers inherit
    both via _PYTEST_GUARD_WRAPPER_DIR and enforce guards independently.
    Includes a marked test that passes and an unmarked test that calls the
    resource and should fail.
    """
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        import subprocess
        import pytest

        @pytest.mark.cat
        def test_marked_cat():
            subprocess.run(["cat", "/dev/null"], check=True)

        def test_unmarked_cat_should_fail():
            subprocess.run(["cat", "/dev/null"], check=True)
    """)
    result = pytester.runpytest_subprocess("-n2", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1, failed=1)
    result.stdout.fnmatch_lines(["*without @pytest.mark.cat*"])


def test_unmarked_test_that_calls_resource_fails(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test without the mark that calls cat should fail."""
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        import subprocess

        def test_cat_dev_null():
            subprocess.run(["cat", "/dev/null"], check=True)
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(["*without @pytest.mark.cat*"])


def test_unmarked_test_that_handles_guard_error_still_fails(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test that expects a resource to fail should still be caught by the guard.

    This simulates a realistic scenario: a test checks that cat fails on a
    nonexistent file. The guard's exit 127 satisfies the assertion, so the
    test would silently pass without the blocked-invocation tracking.
    """
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        import subprocess

        def test_cat_nonexistent_file():
            result = subprocess.run(
                ["cat", "/no/such/file"],
                capture_output=True,
            )
            assert result.returncode != 0
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(["*without @pytest.mark.cat*"])


def test_marked_test_that_never_calls_resource_fails(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test with @pytest.mark.cat that never calls cat should fail (superfluous mark)."""
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        import pytest

        @pytest.mark.cat
        def test_never_calls_cat():
            assert 1 + 1 == 2
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(["*never invoked cat*"])


def test_blocked_resource_appended_to_failing_test(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """When a test fails AND a blocked resource was invoked, both should be visible."""
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        import subprocess

        def test_fails_after_blocked_cat():
            subprocess.run(["cat", "/dev/null"], capture_output=True)
            assert False, "downstream failure"
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(
        [
            "*downstream failure*",
            "*RESOURCE GUARD*without @pytest.mark.cat*",
        ]
    )


def test_unmarked_test_that_does_not_call_resource_passes(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test with no mark and no resource call should pass."""
    pytester.makeconftest(_PYTESTER_CONFTEST)
    pytester.makepyfile("""
        def test_no_cat():
            assert 1 + 1 == 2
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------


def test_create_and_cleanup_round_trip(isolated_guard_state: None) -> None:
    """create_resource_guard_wrappers modifies PATH; cleanup restores it."""
    for resource in _TEST_RESOURCES:
        register_resource_guard(resource)
    create_resource_guard_wrappers()

    assert resource_guards._guard_wrapper_dir is not None
    wrapper_dir = resource_guards._guard_wrapper_dir
    assert os.environ["PATH"].startswith(wrapper_dir)

    for resource in _TEST_RESOURCES:
        assert (Path(wrapper_dir) / resource).exists()

    cleanup_resource_guard_wrappers()
    assert resource_guards._guard_wrapper_dir is None
    assert not Path(wrapper_dir).exists()
    assert not os.environ["PATH"].startswith(wrapper_dir)


def test_create_wrappers_generates_stub_for_missing_binary(
    isolated_guard_state: None,
) -> None:
    """A nonexistent binary gets a stub wrapper that exits 127."""
    register_resource_guard("nonexistent_xyz_binary")
    create_resource_guard_wrappers()

    wrapper_dir = resource_guards._guard_wrapper_dir
    assert wrapper_dir is not None
    stub = Path(wrapper_dir) / "nonexistent_xyz_binary"
    assert stub.exists()
    assert "not installed on this machine" in stub.read_text()

    cleanup_resource_guard_wrappers()


def test_create_wrappers_reuses_inherited_directory(
    isolated_guard_state: None,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When _PYTEST_GUARD_WRAPPER_DIR is set, wrappers are reused, not recreated."""
    monkeypatch.setenv("_PYTEST_GUARD_WRAPPER_DIR", str(tmp_path))

    create_resource_guard_wrappers()

    assert resource_guards._guard_wrapper_dir == str(tmp_path)
    assert resource_guards._owns_guard_wrapper_dir is False

    # Cleanup should not delete the directory since we don't own it
    cleanup_resource_guard_wrappers()
    assert tmp_path.exists()
    assert resource_guards._guard_wrapper_dir is None


def test_start_and_stop_resource_guards_round_trip(
    isolated_guard_state: None,
    request: pytest.FixtureRequest,
) -> None:
    """start_resource_guards creates wrappers, installs SDK guards, and registers hooks."""
    install_called = []
    cleanup_called = []
    register_resource_guard("echo")
    register_sdk_guard("test_sdk", lambda: install_called.append(1), lambda: cleanup_called.append(1))

    # The outer session registered its _ResourceGuardPlugin at pytest_sessionstart. Capture
    # it so we can verify stop_resource_guards() does NOT rip that plugin out when this
    # test's start_resource_guards() was a no-op for plugin registration.
    outer_plugin = request.config.pluginmanager.get_plugin("resource_guards")

    start_resource_guards(request.session)

    assert resource_guards._guard_wrapper_dir is not None
    assert install_called == [1]
    assert request.config.pluginmanager.get_plugin("resource_guards") is not None

    stop_resource_guards()

    assert resource_guards._guard_wrapper_dir is None
    assert cleanup_called == [1]
    # Regression: the outer session's plugin must survive stop_resource_guards(), since this
    # test's start call did not register it. Without ownership tracking in start/stop, the
    # outer plugin would be unregistered here and every subsequent test in the session
    # would lose its runtest_setup/teardown hooks.
    assert request.config.pluginmanager.get_plugin("resource_guards") is outer_plugin


def test_start_and_stop_resource_guards_owner_case_unregisters_plugin(
    isolated_guard_state: None,
    request: pytest.FixtureRequest,
) -> None:
    """Owner case: when start_resource_guards() registers the plugin, stop_resource_guards()
    must unregister it and clear the ownership globals.

    Complements test_start_and_stop_resource_guards_round_trip, which covers the non-owner
    case. Together they enforce the per-caller ownership invariant: start/stop are
    symmetric, and stop only undoes what this particular start registered.
    """
    pluginmanager = request.config.pluginmanager
    # Temporarily pull the outer session's plugin so start_resource_guards() sees an
    # empty slot and takes the owner branch. Restore it in finally so subsequent tests
    # keep their runtest_setup/teardown hooks.
    outer_plugin = pluginmanager.get_plugin("resource_guards")
    assert outer_plugin is not None
    pluginmanager.unregister(outer_plugin)
    try:
        assert pluginmanager.get_plugin("resource_guards") is None

        start_resource_guards(request.session)

        assert resource_guards._owns_guard_plugin is True
        assert resource_guards._guard_plugin is not None
        assert resource_guards._guard_plugin is not outer_plugin
        assert resource_guards._guard_plugin_manager is pluginmanager
        assert pluginmanager.get_plugin("resource_guards") is resource_guards._guard_plugin

        stop_resource_guards()

        assert resource_guards._owns_guard_plugin is False
        assert resource_guards._guard_plugin is None
        assert resource_guards._guard_plugin_manager is None
        assert pluginmanager.get_plugin("resource_guards") is None
    finally:
        if pluginmanager.get_plugin("resource_guards") is None:
            pluginmanager.register(outer_plugin, "resource_guards")


# ---------------------------------------------------------------------------
# SDK guard lifecycle (unit tests)
# ---------------------------------------------------------------------------


def test_register_sdk_guard_adds_entry(isolated_guard_state: None) -> None:
    install_called = []
    register_sdk_guard("test_sdk", lambda: install_called.append(1), lambda: None)

    assert len(resource_guards._registered_sdk_guards) == 1
    assert resource_guards._registered_sdk_guards[0][0] == "test_sdk"
    # Guard name is in _guarded_resources (added by register_sdk_guard).
    assert "test_sdk" in resource_guards._guarded_resources


def test_register_sdk_guard_deduplicates(isolated_guard_state: None) -> None:
    register_sdk_guard("test_sdk", lambda: None, lambda: None)
    register_sdk_guard("test_sdk", lambda: None, lambda: None)

    assert len(resource_guards._registered_sdk_guards) == 1


def test_create_sdk_resource_guards_calls_install(
    isolated_guard_state: None,
) -> None:
    install_called = []
    register_sdk_guard("test_sdk", lambda: install_called.append(1), lambda: None)
    create_sdk_resource_guards()

    assert install_called == [1]


def test_cleanup_sdk_resource_guards_calls_cleanup(
    isolated_guard_state: None,
) -> None:
    cleanup_called = []
    register_sdk_guard("test_sdk", lambda: None, lambda: cleanup_called.append(1))
    cleanup_sdk_resource_guards()

    assert cleanup_called == [1]


def test_get_guarded_resource_names_returns_binary_and_sdk_guards(
    isolated_guard_state: None,
) -> None:
    """get_guarded_resource_names() returns names from both registration paths."""
    register_resource_guard("binary_guard")
    register_sdk_guard("sdk_guard", lambda: None, lambda: None)

    names = get_guarded_resource_names()
    assert "binary_guard" in names
    assert "sdk_guard" in names


def test_sdk_only_guard_does_not_create_binary_wrapper(
    isolated_guard_state: None,
) -> None:
    """SDK-only guard names must not produce PATH wrapper scripts.

    Binary wrappers are only meaningful for names registered via
    register_resource_guard(). Creating a wrapper for an SDK-only guard
    would silently shadow any binary with the same name on PATH.
    """
    register_sdk_guard("sdk_only", lambda: None, lambda: None)
    create_resource_guard_wrappers()

    wrapper_dir = resource_guards._guard_wrapper_dir
    assert wrapper_dir is not None
    assert not (Path(wrapper_dir) / "sdk_only").exists()

    cleanup_resource_guard_wrappers()


def test_register_guarded_resource_markers(
    isolated_guard_state: None,
    pytestconfig: pytest.Config,
) -> None:
    """register_guarded_resource_markers registers marks on the config."""
    register_resource_guard("test_res_a")
    register_resource_guard("test_res_b")

    register_guarded_resource_markers(pytestconfig, skip_names={"test_res_a"})

    marker_names = {m.split(":")[0] for m in pytestconfig.getini("markers")}
    assert "test_res_b" in marker_names
    assert "test_res_a" not in marker_names


def test_register_all_resource_guards_runs_entry_point_callables(
    isolated_guard_state: None,
) -> None:
    """register_all_resource_guards() invokes every callable returned by entry_points()."""

    class _FakeEntryPoint:
        def __init__(self, name: str, callable_: Callable[[], None]) -> None:
            self.name = name
            self._callable = callable_

        def load(self) -> Callable[[], None]:
            return self._callable

    calls: list[str] = []

    def _register_alpha() -> None:
        calls.append("alpha")
        register_resource_guard("alpha")

    def _register_beta() -> None:
        calls.append("beta")
        register_sdk_guard("beta", lambda: None, lambda: None)

    fake_entry_points = [
        _FakeEntryPoint("alpha", _register_alpha),
        _FakeEntryPoint("beta", _register_beta),
    ]

    def _fake_entry_points_fn(*, group: str) -> list[_FakeEntryPoint]:
        assert group == resource_guards.RESOURCE_GUARDS_ENTRY_POINT_GROUP
        return fake_entry_points

    register_all_resource_guards(entry_points=_fake_entry_points_fn)

    assert calls == ["alpha", "beta"]
    names = get_guarded_resource_names()
    assert "alpha" in names
    assert "beta" in names

    # Calling again must be safe -- per-name dedup keeps the registry stable.
    register_all_resource_guards(entry_points=_fake_entry_points_fn)
    names_after = get_guarded_resource_names()
    assert names_after == names


def test_register_guarded_resource_markers_no_skip(
    isolated_guard_state: None,
    pytestconfig: pytest.Config,
) -> None:
    """register_guarded_resource_markers with no skip_names registers all."""
    register_resource_guard("test_all")

    register_guarded_resource_markers(pytestconfig)

    marker_names = {m.split(":")[0] for m in pytestconfig.getini("markers")}
    assert "test_all" in marker_names


def test_custom_sdk_guard_end_to_end(
    isolated_guard_state: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """A custom SDK guard following the README pattern blocks, allows, and cleans up."""

    class FakeClient:
        def send(self, data: str) -> str:
            return f"sent:{data}"

    originals: dict[str, Callable[..., str]] = {}

    def guarded_send(self, data: str) -> str:
        enforce_sdk_guard("fake_sdk")
        return originals["send"](self, data)

    def install() -> None:
        originals["send"] = FakeClient.send
        FakeClient.send = guarded_send  # ty: ignore[invalid-assignment]

    def cleanup() -> None:
        if "send" in originals:
            FakeClient.send = originals["send"]  # ty: ignore[invalid-assignment]
            originals.clear()

    register_sdk_guard("fake_sdk", install, cleanup)
    create_sdk_resource_guards()

    # Blocked: calling send without the mark raises ResourceGuardViolation
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "call")
    monkeypatch.setenv("_PYTEST_GUARD_FAKE_SDK", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))

    with pytest.raises(ResourceGuardViolation, match="without @pytest.mark.fake_sdk"):
        FakeClient().send("hello")

    # Allowed: calling send with the mark works and tracks usage
    monkeypatch.setenv("_PYTEST_GUARD_FAKE_SDK", "allow")

    result = FakeClient().send("hello")
    assert result == "sent:hello"
    assert (tmp_path / "fake_sdk").exists()

    # Cleanup restores the original method
    cleanup_sdk_resource_guards()
    assert FakeClient().send("hello") == "sent:hello"
    assert len(originals) == 0


# ---------------------------------------------------------------------------
# create_sdk_method_guard (unit tests)
# ---------------------------------------------------------------------------


def test_create_sdk_method_guard_sync(
    isolated_guard_state: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """create_sdk_method_guard patches a sync method, enforces guard, and cleans up."""

    class Client:
        def call(self, x: int) -> int:
            return x * 2

    original_call = Client.call
    create_sdk_method_guard("test_sync", [(Client, "call", MethodKind.SYNC)])
    create_sdk_resource_guards()

    assert Client.call is not original_call

    # Guard blocks
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "call")
    monkeypatch.setenv("_PYTEST_GUARD_TEST_SYNC", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))
    with pytest.raises(ResourceGuardViolation):
        Client().call(5)

    # Guard allows
    monkeypatch.setenv("_PYTEST_GUARD_TEST_SYNC", "allow")
    assert Client().call(5) == 10

    # Cleanup restores
    cleanup_sdk_resource_guards()
    assert Client.call is original_call


def test_create_sdk_method_guard_async(
    isolated_guard_state: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """create_sdk_method_guard patches an async method, enforces guard, and cleans up."""

    class Client:
        async def call(self, x: int) -> int:
            return x * 2

    original_call = Client.call
    create_sdk_method_guard("test_async", [(Client, "call", MethodKind.ASYNC)])
    create_sdk_resource_guards()

    # Guard blocks
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "call")
    monkeypatch.setenv("_PYTEST_GUARD_TEST_ASYNC", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))
    # asyncio.get_event_loop() is deprecated and now raises RuntimeError in
    # CI when there's no running loop; use asyncio.run() which manages a
    # fresh loop per call.
    with pytest.raises(ResourceGuardViolation):
        asyncio.run(Client().call(5))

    # Guard allows
    monkeypatch.setenv("_PYTEST_GUARD_TEST_ASYNC", "allow")
    result = asyncio.run(Client().call(5))
    assert result == 10

    # Cleanup restores
    cleanup_sdk_resource_guards()
    assert Client.call is original_call


def test_create_sdk_method_guard_async_gen(
    isolated_guard_state: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """create_sdk_method_guard patches an async generator method, enforces guard, and cleans up."""

    class Client:
        async def stream(self):
            yield 1
            yield 2

    original_stream = Client.stream
    create_sdk_method_guard("test_agen", [(Client, "stream", MethodKind.ASYNC_GEN)])
    create_sdk_resource_guards()

    # Guard blocks
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "call")
    monkeypatch.setenv("_PYTEST_GUARD_TEST_AGEN", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))

    async def collect_blocked():
        async for _item in Client().stream():
            pass

    with pytest.raises(ResourceGuardViolation):
        asyncio.run(collect_blocked())

    # Guard allows
    monkeypatch.setenv("_PYTEST_GUARD_TEST_AGEN", "allow")

    async def collect_allowed():
        results = []
        async for item in Client().stream():
            results.append(item)
        return results

    results = asyncio.run(collect_allowed())
    assert results == [1, 2]

    # Cleanup restores
    cleanup_sdk_resource_guards()
    assert Client.stream is original_stream


# ---------------------------------------------------------------------------
# _build_per_test_guard_env (unit tests)
# ---------------------------------------------------------------------------


def test_build_per_test_guard_env_sets_allow_for_marked_resources(
    isolated_guard_state: None,
) -> None:
    register_resource_guard("tmux")
    register_resource_guard("rsync")
    env = _build_per_test_guard_env({"tmux"}, "/tmp/track")

    assert env["_PYTEST_GUARD_PHASE"] == "call"
    assert env["_PYTEST_GUARD_TRACKING_DIR"] == "/tmp/track"
    assert env["_PYTEST_GUARD_TMUX"] == "allow"
    assert env["_PYTEST_GUARD_RSYNC"] == "block"


# ---------------------------------------------------------------------------
# _check_guard_violations (unit tests)
# ---------------------------------------------------------------------------


class _FakeReport:
    """Minimal stand-in for pytest.TestReport for testing _check_guard_violations."""

    def __init__(self, *, passed: bool, longrepr: str = "") -> None:
        self.outcome = "passed" if passed else "failed"
        self.longrepr = longrepr

    @property
    def passed(self) -> bool:
        return self.outcome == "passed"


def _make_state(tmp_path: Path, marks: set[str]) -> _PerTestGuardState:
    tracking_dir = str(tmp_path)
    return _PerTestGuardState(
        tracking_dir=tracking_dir,
        marks=marks,
        env_patcher=None,
    )


def test_check_guard_violations_blocked_invocation_fails_passing_test(
    isolated_guard_state: None,
    tmp_path: Path,
) -> None:
    """A passing test that invoked a blocked resource should be failed."""
    register_resource_guard("cat")
    (tmp_path / "blocked_cat").touch()

    state = _make_state(tmp_path, marks=set())
    report = _FakeReport(passed=True)
    _check_guard_violations(state, report)  # ty: ignore[invalid-argument-type]

    assert report.outcome == "failed"
    assert "without @pytest.mark.cat" in str(report.longrepr)


def test_check_guard_violations_blocked_invocation_appends_to_failing_test(
    isolated_guard_state: None,
    tmp_path: Path,
) -> None:
    """A failing test that also invoked a blocked resource gets both messages."""
    register_resource_guard("cat")
    (tmp_path / "blocked_cat").touch()

    state = _make_state(tmp_path, marks=set())
    report = _FakeReport(passed=False, longrepr="original failure")
    _check_guard_violations(state, report)  # ty: ignore[invalid-argument-type]

    assert report.outcome == "failed"
    assert "original failure" in str(report.longrepr)
    assert "without @pytest.mark.cat" in str(report.longrepr)


def test_check_guard_violations_superfluous_mark_fails_test(
    isolated_guard_state: None,
    tmp_path: Path,
) -> None:
    """A passing test marked with a resource it never invoked should be failed."""
    register_resource_guard("cat")

    state = _make_state(tmp_path, marks={"cat"})
    report = _FakeReport(passed=True)
    _check_guard_violations(state, report)  # ty: ignore[invalid-argument-type]

    assert report.outcome == "failed"
    assert "never invoked cat" in str(report.longrepr)


def test_check_guard_violations_no_violation_leaves_report_unchanged(
    isolated_guard_state: None,
    tmp_path: Path,
) -> None:
    """A passing test that correctly used its marked resource should stay passed."""
    register_resource_guard("cat")
    (tmp_path / "cat").touch()

    state = _make_state(tmp_path, marks={"cat"})
    report = _FakeReport(passed=True)
    _check_guard_violations(state, report)  # ty: ignore[invalid-argument-type]

    assert report.outcome == "passed"


def test_check_guard_violations_skips_superfluous_check_on_failing_test(
    isolated_guard_state: None,
    tmp_path: Path,
) -> None:
    """A failing test with a superfluous mark should not get the superfluous mark error."""
    register_resource_guard("cat")

    state = _make_state(tmp_path, marks={"cat"})
    report = _FakeReport(passed=False, longrepr="real failure")
    _check_guard_violations(state, report)  # ty: ignore[invalid-argument-type]

    assert report.outcome == "failed"
    assert "never invoked" not in str(report.longrepr)
    assert report.longrepr == "real failure"


# ---------------------------------------------------------------------------
# SDK guard: enforce_sdk_guard (unit tests)
# ---------------------------------------------------------------------------


def test_enforce_sdk_guard_blocks_when_unmarked(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "call")
    monkeypatch.setenv("_PYTEST_GUARD_MYSDK", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))

    with pytest.raises(ResourceGuardViolation, match="without @pytest.mark.mysdk"):
        enforce_sdk_guard("mysdk")

    assert (tmp_path / "blocked_mysdk").exists()


def test_enforce_sdk_guard_allows_when_marked(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "call")
    monkeypatch.setenv("_PYTEST_GUARD_MYSDK", "allow")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))

    enforce_sdk_guard("mysdk")

    assert (tmp_path / "mysdk").exists()


def test_enforce_sdk_guard_skips_outside_call_phase(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("_PYTEST_GUARD_PHASE", "setup")
    monkeypatch.setenv("_PYTEST_GUARD_MYSDK", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))

    enforce_sdk_guard("mysdk")

    assert not (tmp_path / "blocked_mysdk").exists()
    assert not (tmp_path / "mysdk").exists()


def test_enforce_sdk_guard_skips_when_no_phase_set(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("_PYTEST_GUARD_PHASE", raising=False)
    monkeypatch.setenv("_PYTEST_GUARD_MYSDK", "block")
    monkeypatch.setenv("_PYTEST_GUARD_TRACKING_DIR", str(tmp_path))

    enforce_sdk_guard("mysdk")

    assert not (tmp_path / "blocked_mysdk").exists()


# ---------------------------------------------------------------------------
# SDK guard: end-to-end behavior (pytester)
# ---------------------------------------------------------------------------

# Conftest for SDK guard pytester tests. Registers a no-op SDK guard, then uses
# start/stop_resource_guards to initialize the infrastructure. Tests trigger the
# guard by calling enforce_sdk_guard directly (no real SDK needed).
_PYTESTER_SDK_CONFTEST = """\
from imbue.resource_guards.resource_guards import (
    register_sdk_guard,
    start_resource_guards,
    stop_resource_guards,
)

def pytest_configure(config):
    config.addinivalue_line("markers", "test_sdk: test uses test_sdk")

register_sdk_guard("test_sdk", lambda: None, lambda: None)

def pytest_sessionstart(session):
    start_resource_guards(session)

def pytest_sessionfinish(session, exitstatus):
    stop_resource_guards()
"""


def test_sdk_marked_test_that_triggers_guard_passes(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test with the SDK mark that triggers the guard should pass."""
    pytester.makeconftest(_PYTESTER_SDK_CONFTEST)
    pytester.makepyfile("""
        import pytest
        from imbue.resource_guards.resource_guards import enforce_sdk_guard

        @pytest.mark.test_sdk
        def test_sdk_call():
            enforce_sdk_guard("test_sdk")
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)


def test_sdk_unmarked_test_that_triggers_guard_fails(pytester: pytest.Pytester, clean_guard_env: None) -> None:
    """A test without the SDK mark that triggers the guard should fail."""
    pytester.makeconftest(_PYTESTER_SDK_CONFTEST)
    pytester.makepyfile("""
        from imbue.resource_guards.resource_guards import enforce_sdk_guard

        def test_sdk_call():
            enforce_sdk_guard("test_sdk")
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(["*without @pytest.mark.test_sdk*"])


def test_sdk_unmarked_test_that_catches_guard_error_still_fails(
    pytester: pytest.Pytester,
    clean_guard_env: None,
) -> None:
    """A test that catches ResourceGuardViolation should still be caught by the guard.

    The blocked tracking file ensures makereport fails the test even when the
    exception is swallowed, mirroring the binary guard's exit-127 tracking.
    """
    pytester.makeconftest(_PYTESTER_SDK_CONFTEST)
    pytester.makepyfile("""
        from imbue.resource_guards.resource_guards import ResourceGuardViolation
        from imbue.resource_guards.resource_guards import enforce_sdk_guard

        def test_sdk_catches_error():
            try:
                enforce_sdk_guard("test_sdk")
            except ResourceGuardViolation:
                pass
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(["*without @pytest.mark.test_sdk*"])


@pytest.mark.flaky
def test_sdk_marked_test_that_never_triggers_guard_fails(
    pytester: pytest.Pytester,
    clean_guard_env: None,
) -> None:
    """A test with the SDK mark that never triggers the guard fails (superfluous mark).

    Marked flaky because the inner pytester subprocess sporadically exceeds the
    default 10s pytest-timeout under CI load.
    """
    pytester.makeconftest(_PYTESTER_SDK_CONFTEST)
    pytester.makepyfile("""
        import pytest

        @pytest.mark.test_sdk
        def test_never_calls_sdk():
            assert 1 + 1 == 2
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(failed=1)
    result.stdout.fnmatch_lines(["*never invoked test_sdk*"])


def test_sdk_unmarked_test_that_does_not_trigger_guard_passes(
    pytester: pytest.Pytester,
    clean_guard_env: None,
) -> None:
    """A test with no SDK mark and no guard trigger should pass."""
    pytester.makeconftest(_PYTESTER_SDK_CONFTEST)
    pytester.makepyfile("""
        def test_no_sdk():
            assert 1 + 1 == 2
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)


# ---------------------------------------------------------------------------
# Mark auto-registration via register_guarded_resource_markers (pytester)
# ---------------------------------------------------------------------------

# Conftest that mirrors the README example: standalone pytest_configure
# using register_guarded_resource_markers() (no conftest_hooks).
_PYTESTER_STANDALONE_CONFTEST = """\
from imbue.resource_guards.resource_guards import (
    register_guarded_resource_markers,
    register_resource_guard,
    start_resource_guards,
    stop_resource_guards,
)

register_resource_guard("cat")

def pytest_configure(config):
    register_guarded_resource_markers(config)

def pytest_sessionstart(session):
    start_resource_guards(session)

def pytest_sessionfinish(session, exitstatus):
    stop_resource_guards()
"""


def test_standalone_pytest_configure_registers_marks(
    pytester: pytest.Pytester,
    clean_guard_env: None,
) -> None:
    """The README pattern (pytest_configure + register_guarded_resource_markers) works.

    Verifies that external users who don't use conftest_hooks can register
    marks via their own pytest_configure and register_guarded_resource_markers().
    """
    pytester.makeconftest(_PYTESTER_STANDALONE_CONFTEST)
    pytester.makepyfile("""
        import subprocess
        import pytest

        @pytest.mark.cat
        def test_cat_dev_null():
            subprocess.run(["cat", "/dev/null"], check=True)
    """)
    result = pytester.runpytest_subprocess("-n0", "--no-header", "-p", "no:cacheprovider", "--strict-markers")
    result.assert_outcomes(passed=1)
