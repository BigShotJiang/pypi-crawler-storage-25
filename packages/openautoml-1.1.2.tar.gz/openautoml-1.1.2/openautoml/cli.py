"""OpenAutoML CLI — main entry point.

Usage:
    openautoml                  Start interactive REPL (Claude Code-style)
    openautoml init [--host HOST] [--port PORT]
    openautoml upload FILE
    openautoml train FILE --target TARGET [--model MODEL_TYPE] [--task {classification,regression}]
    openautoml status [JOB_ID]
    openautoml models
    openautoml datasets
    openautoml predict JOB_ID [--data 'json']
    openautoml export JOB_ID [--output OUTPUT_PATH]
    openautoml explain JOB_ID
    openautoml benchmark FILE --target TARGET
    openautoml logs JOB_ID
    openautoml delete (job|model) ID
    openautoml cancel JOB_ID
    openautoml config
    openautoml health
    openautoml info
    openautoml version

Running `openautoml` without arguments launches the interactive REPL with
Claude Code-style interface — full command completion, natural language
parsing, and rich visual output.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from .banner import compact_banner

app = typer.Typer(
    name="openautoml",
    help="OpenAutoML CLI — automate ML from CSV to production API",
    no_args_is_help=False,  # We handle no-args ourselves (REPL mode)
    add_completion=False,
)

err_console = Console(stderr=True)


# ── Default: Interactive REPL ─────────────────────────────────────────────

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-v", help="Show version and exit"),
) -> None:
    """OpenAutoML — Automate ML from CSV to Production API.

    Run without arguments to start the interactive REPL.
    """
    if version:
        from . import __version__
        compact_banner()
        console = Console()
        console.print(f"  Version: [bold]v{__version__}[/]")
        console.print(f"  Phase 1 — scikit-learn / XGBoost / ONNX")
        console.print()
        raise typer.Exit()

    # If a subcommand was provided, Typer handles it.
    # Otherwise, launch the interactive REPL.
    if ctx.invoked_subcommand:
        return

    _launch_repl()


def _launch_repl() -> None:
    """Launch the interactive REPL."""
    try:
        from .repl import OpenAutoMLRepl
        repl = OpenAutoMLRepl(auto_connect=True)
        repl.run()
    except ImportError as exc:
        err_console.print()
        err_console.print(f"  [bold]Error:[/] Missing dependency for interactive mode: {exc}")
        err_console.print(f"  Install with: [bold]pip install prompt_toolkit[/]")
        err_console.print()
        raise typer.Exit(1)
    except KeyboardInterrupt:
        pass


# ── Subcommands (non-interactive, single-shot) ────────────────────────────

@app.command()
def init(
    host: str = typer.Option("localhost", help="Orchestrator host"),
    port: int = typer.Option(3030, help="Orchestrator port"),
) -> None:
    """Initialize OpenAutoML configuration in the current directory."""
    from .commands import cmd_init
    cmd_init(["--host", host, "--port", str(port)])


@app.command()
def upload(
    file: Path = typer.Argument(..., exists=True, help="CSV, JSON, or Parquet file to upload"),
) -> None:
    """Upload a dataset file to the orchestrator."""
    from .commands import cmd_upload
    cmd_upload([str(file)])


@app.command()
def train(
    file: Path = typer.Argument(..., exists=True, help="Dataset file (CSV, JSON, or Parquet)"),
    target: str = typer.Option(..., "--target", "-t", help="Target column name"),
    model: str = typer.Option("auto", "--model", "-m", help="Model type"),
    task: Optional[str] = typer.Option(None, "--task", help="Task type: classification or regression"),
) -> None:
    """Train a model on the given dataset."""
    from .commands import cmd_train
    args = [str(file), "--target", target]
    if model != "auto":
        args.extend(["--model", model])
    if task:
        args.extend(["--task", task])
    cmd_train(args)


@app.command()
def predict(
    job_id: str = typer.Argument(..., help="Job ID of the trained model"),
    data: Optional[str] = typer.Option(None, "--data", "-d", help="JSON array of input data"),
) -> None:
    """Make predictions with a trained model."""
    from .commands import cmd_predict
    args = [job_id]
    if data:
        args.extend(["--data", data])
    cmd_predict(args)


@app.command()
def status(
    job_id: Optional[str] = typer.Argument(None, help="Job ID (omit to list all)"),
) -> None:
    """Show job status. List all jobs if no ID given."""
    from .commands import cmd_status
    cmd_status([job_id] if job_id else [])


@app.command("list-models", hidden=True)
def list_models_cmd() -> None:
    """List all trained models."""
    from .commands import cmd_models
    cmd_models([])


@app.command("list-datasets", hidden=True)
def list_datasets_cmd() -> None:
    """List all uploaded datasets."""
    from .commands import cmd_datasets
    cmd_datasets([])


@app.command()
def models() -> None:
    """List all trained models."""
    from .commands import cmd_models
    cmd_models([])


@app.command()
def datasets() -> None:
    """List all uploaded datasets."""
    from .commands import cmd_datasets
    cmd_datasets([])


@app.command()
def export(
    job_id: str = typer.Argument(..., help="Job ID to export"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    format: str = typer.Option("onnx", "--format", "-f", help="Export format: onnx, pickle, model_card"),
) -> None:
    """Export a trained model (ONNX, Pickle, or Model Card)."""
    from .commands import cmd_export
    args = [job_id]
    if output:
        args.extend(["--output", str(output)])
    if format != "onnx":
        args.extend(["--format", format])
    cmd_export(args)


@app.command()
def logs(
    job_id: str = typer.Argument(..., help="Job ID"),
) -> None:
    """View training logs for a job."""
    from .commands import cmd_logs
    cmd_logs([job_id])


@app.command()
def explain(
    job_id: str = typer.Argument(..., help="Job ID"),
) -> None:
    """Show feature importance and model insights."""
    from .commands import cmd_explain
    cmd_explain([job_id])


@app.command()
def benchmark(
    file: Path = typer.Argument(..., exists=True, help="Dataset file"),
    target: str = typer.Option(..., "--target", "-t", help="Target column"),
) -> None:
    """Compare all algorithms on a dataset."""
    from .commands import cmd_benchmark
    cmd_benchmark([str(file), "--target", target])


@app.command()
def delete(
    resource_type: str = typer.Argument(..., help="Resource type: job or model"),
    resource_id: str = typer.Argument(..., help="Resource ID"),
) -> None:
    """Delete a job or model."""
    from .commands import cmd_delete
    cmd_delete([resource_type, resource_id])


@app.command()
def cancel(
    job_id: str = typer.Argument(..., help="Job ID to cancel"),
) -> None:
    """Cancel a running job."""
    from .commands import cmd_delete
    cmd_delete(["job", job_id])


@app.command("config")
def config_cmd() -> None:
    """View current configuration."""
    from .commands import cmd_config
    cmd_config([])


@app.command()
def health() -> None:
    """Check orchestrator health."""
    from .commands import cmd_health
    cmd_health([])


@app.command()
def info() -> None:
    """Show orchestrator connection info and health status."""
    from .config import base_url, load
    from .commands import _ensure_config, _tool_block

    if not _ensure_config():
        return

    cfg = load()
    url = base_url(cfg)

    from .client import ConnectionError, OrchestratorClient, OrchestratorError
    from .outputs import simple_spinner

    _tool_block("info", f"base_url={url}")

    with OrchestratorClient(cfg) as client:
        with simple_spinner() as progress:
            task = progress.add_task("Checking orchestrator health...", total=None)
            try:
                health_resp = client.health()
            except ConnectionError as exc:
                progress.stop()
                from .outputs import console
                console.print(f"  [bold]Error:[/] {exc}")
                raise typer.Exit(1)
            except OrchestratorError as exc:
                progress.stop()
                from .outputs import console
                console.print(f"  [bold]Error:[/] {exc}")
                raise typer.Exit(1)

    from .outputs import console, info_panel

    display_data = {
        "host": cfg["host"],
        "port": cfg["port"],
        "version": health_resp.get("version", "—"),
        "status": health_resp.get("status", health_resp.get("health", "unknown")),
    }
    console.print()
    console.print(info_panel(display_data))
    console.print(f"  Base URL: [bold]{url}[/]")
    console.print()
