"""HTTP client for the OpenAutoML orchestrator."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, BinaryIO

import httpx

from .config import base_url, load


class OrchestratorError(Exception):
    """Raised when the orchestrator returns a non-2xx response."""

    def __init__(self, status: int, message: str) -> None:
        self.status = status
        self.message = message
        super().__init__(f"HTTP {status}: {message}")


class ConnectionError(Exception):
    """Raised when the orchestrator is unreachable."""

    def __init__(self, url: str, reason: str) -> None:
        self.url = url
        self.reason = reason
        super().__init__(f"Cannot reach orchestrator at {url}: {reason}")


class OrchestratorClient:
    """Async-capable HTTP client wrapping every orchestrator endpoint."""

    def __init__(self, cfg: dict[str, Any] | None = None) -> None:
        self._cfg = cfg or load()
        self._base = base_url(self._cfg)
        self._client = httpx.Client(timeout=120.0)

    # -- internal helpers ---------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self._base}{path}"

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        try:
            resp = self._client.request(method, self._url(path), **kwargs)
        except httpx.ConnectError as exc:
            raise ConnectionError(self._base, str(exc)) from exc
        except httpx.ConnectTimeout as exc:
            raise ConnectionError(self._base, "connection timed out") from exc

        if resp.status_code >= 400:
            try:
                body = resp.json()
                msg = body.get("error", body.get("detail", resp.text))
            except Exception:
                msg = resp.text
            raise OrchestratorError(resp.status_code, msg)

        if not resp.text:
            return {}
        return resp.json()

    def _get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        return self._request("GET", path, **kwargs)

    def _post(self, path: str, **kwargs: Any) -> dict[str, Any]:
        return self._request("POST", path, **kwargs)

    def _delete(self, path: str, **kwargs: Any) -> dict[str, Any]:
        return self._request("DELETE", path, **kwargs)

    # -- streaming support --------------------------------------------------

    def _stream(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        """Return a raw response for SSE / streaming consumption."""
        try:
            return self._client.stream(method, self._url(path), **kwargs)
        except httpx.ConnectError as exc:
            raise ConnectionError(self._base, str(exc)) from exc
        except httpx.ConnectTimeout as exc:
            raise ConnectionError(self._base, "connection timed out") from exc

    # -- public API ---------------------------------------------------------

    # Health / info
    def health(self) -> dict[str, Any]:
        return self._get("/health")

    def info(self) -> dict[str, Any]:
        return self._get("/")

    # Datasets
    def upload_dataset(self, file_path: str | Path) -> dict[str, Any]:
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {path}")
        filename = path.name
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            return self._post(
                "/upload",
                files={"file": (filename, fh)},
                data={"filename": filename},
            )

    def get_dataset(self, dataset_id: str) -> dict[str, Any]:
        return self._get(f"/datasets/{dataset_id}")

    def list_datasets(self) -> dict[str, Any]:
        return self._get("/datasets")

    # Jobs / training
    def create_job(
        self,
        dataset_id: str,
        target: str,
        model_type: str = "auto",
        task: str | None = None,
        file_path: str = "",
        dataset_name: str = "",
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "datasetId": dataset_id,
            "target": target,
            "modelType": model_type,
        }
        if task is not None:
            payload["taskType"] = task
        if file_path:
            payload["filePath"] = file_path
        if dataset_name:
            payload["datasetName"] = dataset_name
        return self._post("/train", json=payload)

    def get_job(self, job_id: str) -> dict[str, Any]:
        return self._get(f"/jobs/{job_id}")

    def list_jobs(self) -> dict[str, Any]:
        return self._get("/jobs")

    def cancel_job(self, job_id: str) -> dict[str, Any]:
        return self._delete(f"/jobs/{job_id}")

    # Models
    def list_models(self) -> dict[str, Any]:
        return self._get("/models")

    def get_model(self, model_id: str) -> dict[str, Any]:
        return self._get(f"/models/{model_id}")

    # Export
    def export_model(self, job_id: str, format: str = "onnx") -> dict[str, Any]:
        """Request model export and return metadata dict.

        For binary formats (onnx, pickle), use download_export() to get the file.
        For model_card, the card dict is included in the response.
        """
        return self._post("/export", json={"job_id": job_id, "format": format})

    def download_export(self, filename: str) -> bytes:
        """Download an exported model file by filename."""
        try:
            resp = self._client.get(self._url(f"/download/{filename}"))
        except httpx.ConnectError as exc:
            raise ConnectionError(self._base, str(exc)) from exc
        if resp.status_code >= 400:
            raise OrchestratorError(resp.status_code, resp.text)
        return resp.content

    # Streaming logs
    def stream_logs(self, job_id: str) -> httpx.Response:
        """Connect to the SSE log stream for a job."""
        try:
            resp = self._client.get(
                self._url(f"/jobs/{job_id}/logs"),
                stream=True,
            )
        except httpx.ConnectError as exc:
            raise ConnectionError(self._base, str(exc)) from exc
        if resp.status_code >= 400:
            raise OrchestratorError(resp.status_code, resp.text)
        return resp

    def predict(self, job_id: str, input_data: list) -> dict[str, Any]:
        """Run inference on a trained model."""
        return self._post("/predict", json={"job_id": job_id, "input_data": input_data})

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> OrchestratorClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
