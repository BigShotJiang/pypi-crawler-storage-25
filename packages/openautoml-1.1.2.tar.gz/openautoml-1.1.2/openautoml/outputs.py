"""Rich output formatting for OpenAutoML CLI.

All output uses a Swiss-style monochromatic palette:
  black, white, and shades of gray.
"""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)
from rich.table import Table

# Monochromatic palette
BLACK = "black"
WHITE = "#F9F9F9"
GRAY_DARK = "#555555"
GRAY = "#888888"
GRAY_LIGHT = "#CCCCCC"
GRAY_LIGHTER = "#EEEEEE"

console = Console()


# ── Helpers ────────────────────────────────────────────────────────────────

def header(text: str) -> None:
    console.print()
    console.print(Panel(text, style=f"bold {BLACK}", border_style=GRAY_LIGHT, padding=(1, 2)))
    console.print()


def status_badge(status: str) -> str:
    mapping = {
        "completed": "[bold]●[/] completed",
        "running": "[bold]●[/] running",
        "pending": "[bold]●[/] pending",
        "failed": "[bold]●[/] failed",
        "cancelled": "[bold]●[/] cancelled",
    }
    style_map = {
        "completed": f"bold {BLACK}",
        "running": f"bold {GRAY_DARK}",
        "pending": f"{GRAY}",
        "failed": f"bold {BLACK}",
        "cancelled": f"{GRAY}",
    }
    label = mapping.get(status.lower(), f"[bold]●[/] {status}")
    return f"[{style_map.get(status.lower(), '')}]{label}[/]"


def metric_value(value: float | None, decimals: int = 4) -> str:
    if value is None:
        return "—"
    return f"{value:.{decimals}f}"


# ── Tables ─────────────────────────────────────────────────────────────────

def jobs_table(jobs: list[dict[str, Any]]) -> Table:
    table = Table(
        title="Jobs",
        border_style=GRAY_LIGHT,
        header_style=f"bold {BLACK}",
        title_style=f"bold {BLACK}",
        padding=(0, 1),
    )
    table.add_column("ID", style=GRAY_DARK, max_width=12)
    table.add_column("Status", min_width=12)
    table.add_column("Model", style=GRAY_DARK, max_width=22)
    table.add_column("Task", max_width=14)
    table.add_column("Score", justify="right", max_width=10)
    table.add_column("Duration", max_width=10)
    table.add_column("Created", style=GRAY, max_width=20)

    for job in jobs:
        score = _extract_score(job)
        duration = job.get("duration", "—")
        created = job.get("created_at", "—")
        table.add_row(
            job.get("id", "—"),
            status_badge(job.get("status", "unknown")),
            job.get("model_type", "—"),
            job.get("task", "—"),
            metric_value(score),
            str(duration),
            str(created),
        )
    return table


def models_table(models: list[dict[str, Any]]) -> Table:
    table = Table(
        title="Models",
        border_style=GRAY_LIGHT,
        header_style=f"bold {BLACK}",
        title_style=f"bold {BLACK}",
        padding=(0, 1),
    )
    table.add_column("ID", style=GRAY_DARK, max_width=12)
    table.add_column("Name", max_width=30)
    table.add_column("Type", style=GRAY_DARK, max_width=22)
    table.add_column("Task", max_width=14)
    table.add_column("Score", justify="right", max_width=10)
    table.add_column("Size", max_width=10)
    table.add_column("Created", style=GRAY, max_width=20)

    for m in models:
        score = _extract_score(m)
        size = m.get("file_size", m.get("size"))
        if isinstance(size, (int, float)) and size > 0:
            size_str = _human_bytes(size)
        else:
            size_str = "—"
        table.add_row(
            m.get("id", "—"),
            m.get("name", m.get("model_name", "—")),
            m.get("model_type", "—"),
            m.get("task", "—"),
            metric_value(score),
            size_str,
            m.get("created_at", "—"),
        )
    return table


def job_detail(job: dict[str, Any]) -> Panel:
    lines: list[str] = []
    lines.append(f"  ID         [bold]{job.get('id', '—')}[/]")
    lines.append(f"  Status     {status_badge(job.get('status', 'unknown'))}")
    lines.append(f"  Model      {job.get('model_type', '—')}")
    lines.append(f"  Task       {job.get('task', '—')}")
    lines.append(f"  Dataset    {job.get('dataset_id', '—')}")
    lines.append(f"  Target     {job.get('target', '—')}")
    lines.append(f"  Duration   {job.get('duration', '—')}")
    lines.append(f"  Created    {job.get('created_at', '—')}")

    # Metrics block
    metrics = job.get("metrics") or {}
    if metrics:
        lines.append("")
        lines.append("  [bold]Metrics[/]")
        for k, v in metrics.items():
            if isinstance(v, float):
                lines.append(f"    {k:<18} {v:.4f}")
            else:
                lines.append(f"    {k:<18} {v}")

    # Log history
    logs = job.get("logs") or []
    if logs:
        lines.append("")
        lines.append("  [bold]Log History[/]")
        for entry in logs[-20:]:
            if isinstance(entry, dict):
                ts = entry.get("timestamp", "")
                msg = entry.get("message", str(entry))
                lines.append(f"    [{GRAY}]{ts}[/]  {msg}")
            else:
                lines.append(f"    {entry}")

    content = "\n".join(lines)
    return Panel(content, title=f"Job {job.get('id', '?')}", border_style=GRAY_LIGHT, padding=(1, 2))


def dataset_info(data: dict[str, Any]) -> Panel:
    lines: list[str] = []
    lines.append(f"  ID          [bold]{data.get('id', '—')}[/]")
    lines.append(f"  Name        {data.get('filename', data.get('name', '—'))}")
    lines.append(f"  Rows        {data.get('rows', data.get('row_count', '—'))}")
    lines.append(f"  Columns     {data.get('columns', data.get('column_count', '—'))}")

    columns = data.get("column_info") or data.get("columns_info") or []
    if columns:
        lines.append("")
        lines.append("  [bold]Columns[/]")
        for col in columns:
            if isinstance(col, dict):
                name = col.get("name", "?")
                dtype = col.get("dtype", col.get("type", "?"))
                lines.append(f"    {name:<24} {dtype}")
            else:
                lines.append(f"    {col}")

    return Panel(
        "\n".join(lines),
        title="Dataset",
        border_style=GRAY_LIGHT,
        padding=(1, 2),
    )


def info_panel(data: dict[str, Any]) -> Panel:
    lines: list[str] = []
    lines.append(f"  Host         [bold]{data.get('host', '—')}[/]")
    lines.append(f"  Port         {data.get('port', '—')}")
    lines.append(f"  Version      {data.get('version', '—')}")
    lines.append(f"  Status       {status_badge(data.get('status', 'unknown'))}")
    return Panel(
        "\n".join(lines),
        title="Orchestrator",
        border_style=GRAY_LIGHT,
        padding=(1, 2),
    )


# ── Progress helpers ───────────────────────────────────────────────────────

def upload_progress() -> Progress:
    return Progress(
        SpinnerColumn(spinner_name="dots", style=GRAY_DARK),
        TextColumn("[bold]{task.description}[/]", style=BLACK),
        BarColumn(bar_width=30, complete_style=BLACK, finished_style=BLACK, background=GRAY_LIGHTER),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeElapsedColumn(),
        console=console,
    )


def training_progress() -> Progress:
    return Progress(
        SpinnerColumn(spinner_name="dots", style=GRAY_DARK),
        TextColumn("[bold]{task.description}[/]", style=BLACK),
        BarColumn(bar_width=30, complete_style=BLACK, finished_style=BLACK),
        TimeElapsedColumn(),
        console=console,
    )


def simple_spinner() -> Progress:
    return Progress(
        SpinnerColumn(spinner_name="dots", style=GRAY_DARK),
        TextColumn("{task.description}", style=BLACK),
        console=console,
    )


# ── Internal utilities ────────────────────────────────────────────────────

def _extract_score(item: dict[str, Any]) -> float | None:
    metrics = item.get("metrics")
    if isinstance(metrics, dict):
        for key in ("accuracy", "r2", "f1", "rmse", "mae"):
            if key in metrics:
                return metrics[key]
    return None


def _human_bytes(n: int | float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} TB"
