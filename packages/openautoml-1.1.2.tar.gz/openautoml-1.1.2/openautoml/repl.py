"""OpenAutoML Interactive REPL — Claude Code-style terminal interface.

Provides an immersive, interactive command-line experience with:
- Rich ASCII banner and status splash
- Intelligent command parsing (slash commands + natural language)
- Claude Code-style tool use / result blocks
- Full color, panels, and progress feedback
"""

from __future__ import annotations

import sys
from typing import Optional

from prompt_toolkit import PromptSession
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.filters import Condition
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.lexers import PygmentsLexer
from prompt_toolkit.styles import Style
from pygments.lexers.shell import BashLexer

from .banner import splash, compact_banner
from .client import OrchestratorClient
from .commands import err_console, parse_natural_language, registry
from .config import config_path


# ── REPL Style (Swiss Monochromatic + Green Accent) ───────────────────────

REPL_STYLE = Style.from_dict({
    # Prompt
    "prompt": "bold #F9F9F9",
    "prompt.symbol": "bold #F9F9F9",
    "prompt.path": "dim #888888",
    # User input
    "": "#F9F9F9",
    # Completions
    "completion-menu": "bg:#1A1A1A #F9F9F9",
    "completion-menu.completion": "bg:#1A1A1A #F9F9F9",
    "completion-menu.completion.current": "bg:#333333 #FFFFFF",
    # Scrollbar
    "scrollbar.background": "bg:#1A1A1A",
    "scrollbar.button": "bg:#333333",
    # Selection
    "selected": "bg:#333333",
    # Search
    "search": "reverse #F9F9F9",
    "search.current": "bg:#333333",
})


# ── Command Completer ─────────────────────────────────────────────────────

class OpenAutoMLCompleter(Completer):
    """Provides tab-completion for OpenAutoML commands."""

    def __init__(self) -> None:
        self._commands = [cmd.name for cmd in registry.all_commands()]
        self._aliases: dict[str, str] = {}
        for cmd in registry.all_commands():
            for alias in cmd.aliases:
                self._aliases[alias] = cmd.name

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor.lstrip()

        # Complete slash commands
        if text.startswith("/"):
            word = text[1:]
            for cmd_name in self._commands:
                if cmd_name.startswith(word):
                    yield Completion(
                        f"/{cmd_name}",
                        start_position=-len(word) - 1,
                        display=f"/{cmd_name}",
                    )
            for alias, cmd_name in self._aliases.items():
                if alias.startswith(word) and alias not in self._commands:
                    yield Completion(
                        f"/{alias}",
                        start_position=-len(word) - 1,
                        display=f"/{alias} → /{cmd_name}",
                    )


# ── Key Bindings ──────────────────────────────────────────────────────────

def create_keybindings() -> KeyBindings:
    kb = KeyBindings()

    @kb.add("c-c", eager=True)
    def _(event):
        """Ctrl+C: clear current input or exit on empty line."""
        buf = event.current_buffer
        if buf.text.strip():
            buf.text = ""
        else:
            event.app.exit(result=None)

    @kb.add("c-d", eager=True)
    def _(event):
        """Ctrl+D: exit on empty line."""
        buf = event.current_buffer
        if not buf.text.strip():
            event.app.exit(result=None)

    @kb.add("c-l")
    def _(event):
        """Ctrl+L: clear screen."""
        from .outputs import console
        console.clear()

    @kb.add("up", filter=Condition(lambda e: not e.current_buffer.text))
    def _(event):
        """Up arrow on empty line: recall last command from history."""
        event.current_buffer.history_backward()

    return kb


# ── The REPL ──────────────────────────────────────────────────────────────

class OpenAutoMLRepl:
    """Interactive REPL session for OpenAutoML.

    Usage:
        repl = OpenAutoMLRepl()
        repl.run()
    """

    PROMPT_PREFIX = "openautoml"

    def __init__(self, auto_connect: bool = True) -> None:
        self._auto_connect = auto_connect
        self._session: Optional[PromptSession] = None
        self._health: dict | None = None

    def _get_prompt(self) -> list[tuple[str, str]]:
        """Build the prompt message as formatted text segments."""
        return [
            ("class:prompt", "  ◆ "),
            ("class:prompt.symbol", self.PROMPT_PREFIX),
            ("class:prompt.path", " > "),
        ]

    def _try_health_check(self) -> dict | None:
        """Attempt to connect to the orchestrator and get health."""
        if not config_path().exists():
            return None
        try:
            client = OrchestratorClient()
            health = client.health()
            client.close()
            return health
        except Exception:
            return None

    def _dispatch(self, text: str) -> bool:
        """Parse and execute user input. Returns False to exit."""
        text = text.strip()
        if not text:
            return True

        # Slash commands
        if text.startswith("/"):
            parts = text[1:].split(None, 1)
            cmd_name = parts[0].lower()
            args_str = parts[1] if len(parts) > 1 else ""

            # Parse args respecting quoted strings
            args = _parse_args(args_str)
            cmd = registry.get(cmd_name)

            if cmd:
                try:
                    cmd.handler(args)
                except SystemExit:
                    return False
                except KeyboardInterrupt:
                    from .outputs import console
                    console.print(f"\n  [dim]Interrupted[/]\n")
                except Exception as exc:
                    from .outputs import console
                    err_console.print(f"  [bold]Error:[/] {exc}\n")
            else:
                from .outputs import console
                console.print(f"  Unknown command: [bold]/{cmd_name}[/]")
                console.print(f"  Type [bold]/help[/] for available commands\n")
            return True

        # Natural language parsing
        parsed = parse_natural_language(text)
        if parsed:
            cmd_name = parsed[0]
            args = parsed[1:]
            cmd = registry.get(cmd_name)
            if cmd:
                try:
                    cmd.handler(args)
                except SystemExit:
                    return False
                except KeyboardInterrupt:
                    from .outputs import console
                    console.print(f"\n  [dim]Interrupted[/]\n")
                except Exception as exc:
                    err_console.print(f"  [bold]Error:[/] {exc}\n")
                return True

        # Fallback: unrecognized input
        from .outputs import console
        console.print(f"  [dim]I didn't understand that. Try:[/]")
        console.print(f"    [bold]/help[/]   — see all commands")
        console.print(f"    [bold]/train[/]  — train a model")
        console.print(f"    [dim]Or describe what you want in natural language.[/]")
        console.print()
        return True

    def run(self) -> None:
        """Start the interactive REPL loop."""
        # Health check for splash
        if self._auto_connect:
            self._health = self._try_health_check()

        # Display splash screen
        splash(self._health)

        # Create prompt session
        history = InMemoryHistory()
        # Add some helpful initial history entries
        for entry in ["/help", "/train", "/predict", "/models", "/datasets"]:
            history.append_string(entry)

        kb = create_keybindings()
        completer = OpenAutoMLCompleter()
        auto_suggest = AutoSuggestFromHistory()

        self._session = PromptSession(
            history=history,
            completer=completer,
            auto_suggest=auto_suggest,
            key_bindings=kb,
            style=REPL_STYLE,
            multiline=False,
            enable_history_search=True,
            vi_mode=False,
            mouse_support=False,
            paste_mode=False,
            swap_light_and_dark_colors=False,
        )

        # REPL loop
        while True:
            try:
                user_input = self._session.prompt(self._get_prompt())
                if user_input is None:
                    # User pressed Ctrl+D
                    break
                if not self._dispatch(user_input):
                    break
            except KeyboardInterrupt:
                # Don't exit on Ctrl+C, just print newline
                print()
            except EOFError:
                break

        # Goodbye
        from .outputs import console
        console.print()
        console.print(f"  [dim]Goodbye — OpenAutoML[/]")
        console.print()


# ── Arg Parser ────────────────────────────────────────────────────────────

def _parse_args(text: str) -> list[str]:
    """Parse a command string into argument list, respecting quotes."""
    import shlex
    try:
        return shlex.split(text)
    except ValueError:
        # Fallback: simple split
        return text.split()
