"""Configuration management for OpenAutoML CLI."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CONFIG_FILENAME = ".openautoml"

DEFAULTS: dict[str, Any] = {
    "host": "localhost",
    "port": 3030,
    "upload_dir": "./data",
}


def config_path() -> Path:
    """Return the path to the config file in the current working directory."""
    return Path.cwd() / CONFIG_FILENAME


def load() -> dict[str, Any]:
    """Load the `.openautoml` config, falling back to defaults."""
    path = config_path()
    if path.is_file():
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            # Merge with defaults so new keys are always present
            return {**DEFAULTS, **data}
        except (json.JSONDecodeError, OSError) as exc:
            raise ConfigError(f"Cannot read config at {path}: {exc}") from exc
    return dict(DEFAULTS)


def save(data: dict[str, Any]) -> Path:
    """Write a config dict to `.openautoml` and return the path."""
    path = config_path()
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({**DEFAULTS, **data}, fh, indent=2)
    return path


def base_url(cfg: dict[str, Any] | None = None) -> str:
    """Return the orchestrator base URL derived from *cfg*."""
    if cfg is None:
        cfg = load()
    return f"http://{cfg['host']}:{cfg['port']}"


class ConfigError(Exception):
    """Raised when the config file is missing or invalid."""
