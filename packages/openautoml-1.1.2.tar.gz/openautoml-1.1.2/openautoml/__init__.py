"""OpenAutoML CLI — automate ML from CSV to production API."""

__version__ = "1.1.1"
