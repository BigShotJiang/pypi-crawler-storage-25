"""Command registry and dispatcher for the OpenAutoML interactive REPL."""

from __future__ import annotations

import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Callable, Coroutine

from rich.console import Console
from rich.table import Table

from .client import ConnectionError, OrchestratorClient, OrchestratorError
from .config import base_url, config_path, load, save
from .outputs import (
    GRAY,
    GRAY_DARK,
    GRAY_LIGHT,
    GRAY_LIGHTER,
    BLACK,
    console,
    dataset_info,
    header,
    info_panel,
    job_detail,
    jobs_table,
    metric_value,
    models_table,
    simple_spinner,
    status_badge,
    training_progress,
    _human_bytes,
)

err_console = Console(stderr=True)


# ── Command Registry ──────────────────────────────────────────────────────

CommandFunc = Callable[..., None]

class Command:
    """A single REPL command."""

    def __init__(
        self,
        name: str,
        handler: CommandFunc,
        help_text: str,
        usage: str = "",
        aliases: list[str] | None = None,
        needs_config: bool = True,
    ):
        self.name = name
        self.handler = handler
        self.help_text = help_text
        self.usage = usage
        self.aliases = aliases or []
        self.needs_config = needs_config


class CommandRegistry:
    """Registry for all REPL commands."""

    def __init__(self) -> None:
        self._commands: dict[str, Command] = {}

    def register(self, cmd: Command) -> None:
        self._commands[cmd.name] = cmd
        for alias in cmd.aliases:
            self._commands[alias] = cmd

    def get(self, name: str) -> Command | None:
        return self._commands.get(name.lower())

    def all_commands(self) -> list[Command]:
        seen: set[str] = set()
        result: list[Command] = []
        for cmd in self._commands.values():
            if cmd.name not in seen:
                seen.add(cmd.name)
                result.append(cmd)
        return result

    def help_table(self) -> Table:
        table = Table(
            title="Available Commands",
            border_style=GRAY_LIGHT,
            header_style=f"bold {BLACK}",
            title_style=f"bold {BLACK}",
            padding=(0, 1),
            show_lines=False,
        )
        table.add_column("Command", style=f"bold {BLACK}", min_width=22, max_width=28)
        table.add_column("Description", style=GRAY_DARK)
        table.add_column("Usage", style=GRAY, max_width=50)

        for cmd in self.all_commands():
            usage = cmd.usage or cmd.name
            table.add_row(f"/{cmd.name}", cmd.help_text, usage)

        return table


# ── Global Registry ───────────────────────────────────────────────────────

registry = CommandRegistry()


# ── Helper Functions ──────────────────────────────────────────────────────

def _ensure_config() -> bool:
    if not config_path().exists():
        err_console.print(f"  [bold]Not initialised.[/] Run [bold]/init[/bold] first.")
        return False
    return True


def _get_client() -> OrchestratorClient | None:
    if not _ensure_config():
        return None
    try:
        return OrchestratorClient()
    except Exception as exc:
        err_console.print(f"  [bold]Error:[/] Cannot create client: {exc}")
        return None


def _parse_flags(args: list[str], flags: list[str] | None = None) -> dict[str, str | None]:
    """Parse simple --flag value pairs from argument list."""
    result: dict[str, str | None] = {}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg.startswith("--"):
            key = arg.lstrip("-")
            if i + 1 < len(args) and not args[i + 1].startswith("--"):
                result[key] = args[i + 1]
                i += 2
            else:
                result[key] = None
                i += 1
        else:
            i += 1
    return result


def _tool_block(title: str, content: str = "") -> None:
    """Render a Claude Code-style tool use block."""
    console.print()
    console.print(f"  [bold dim]┌ {title}[/]")
    if content:
        for line in content.strip().split("\n"):
            console.print(f"  [dim]│[/]  {line}", markup=False)
    console.print(f"  [dim]└{'─' * (len(title) + 2)}[/]")
    console.print()


def _result_block(title: str, data: dict | str | list) -> None:
    """Render a Claude Code-style result block."""
    console.print(f"  [bold]┌ {title}[/]")
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, float):
                console.print(f"  [dim]│[/]  [dim]{k}[/]  {v:.4f}")
            elif isinstance(v, list):
                console.print(f"  [dim]│[/]  [dim]{k}[/]  {json.dumps(v, default=str)}")
            else:
                console.print(f"  [dim]│[/]  [dim]{k}[/]  {v}")
    elif isinstance(data, list):
        for item in data:
            console.print(f"  [dim]│[/]  {item}")
    else:
        for line in str(data).strip().split("\n"):
            console.print(f"  [dim]│[/]  {line}", markup=False)
    console.print(f"  [bold]└{'─' * (len(title) + 2)}[/]")
    console.print()


# ── Command Implementations ───────────────────────────────────────────────

def cmd_init(args: list[str]) -> None:
    """Initialize OpenAutoML configuration."""
    flags = _parse_flags(args)
    host = flags.get("host") or "localhost"
    port = int(flags.get("port") or "3030")

    path = config_path()
    if path.exists():
        console.print(f"  Config already exists at [bold]{path}[/]. Editing.")
        cfg = load()
        cfg["host"] = host
        cfg["port"] = port
    else:
        cfg = {"host": host, "port": port, "upload_dir": "./data"}
        upload_dir = Path(cfg["upload_dir"])
        upload_dir.mkdir(parents=True, exist_ok=True)

    save(cfg)

    _tool_block("init", f"host={host}  port={port}")
    console.print(f"  ✓ Config saved to [bold]{path}[/]")
    console.print(f"  ✓ Upload directory: [bold]{Path(cfg['upload_dir']).resolve()}[/]")
    console.print()


def cmd_upload(args: list[str]) -> None:
    """Upload a dataset to the orchestrator."""
    if not args:
        console.print(f"  [bold]Usage:[/] /upload <file.csv|json|parquet>")
        return

    file = Path(args[0])
    if not file.exists():
        console.print(f"  [bold]Error:[/] File not found: {file}")
        return

    client = _get_client()
    if not client:
        return

    _tool_block("upload", f"file={file.name}  size={file.stat().st_size} bytes")

    with simple_spinner() as progress:
        task = progress.add_task(f"Uploading {file.name}...", total=None)
        try:
            result = client.upload_dataset(file)
        except (ConnectionError, OrchestratorError) as exc:
            progress.stop()
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return
        except Exception as exc:
            progress.stop()
            console.print(f"  [bold]Error:[/] Upload failed: {exc}")
            client.close()
            return

    client.close()
    _result_block("result", {
        "id": result.get("id", "—"),
        "name": result.get("name", "—"),
        "rows": result.get("rowCount", result.get("row_count", "—")),
        "columns": len(result.get("columns", [])),
        "file_size": result.get("file_size", "—"),
    })
    console.print(f"  [dim]Next: /train {file} --target <column>[/]")
    console.print()


def cmd_train(args: list[str]) -> None:
    """Train a model on a dataset."""
    if not args:
        console.print(f"  [bold]Usage:[/] /train <file> --target <column> [--model <type>] [--task <type>]")
        return

    file = Path(args[0])
    if not file.exists():
        console.print(f"  [bold]Error:[/] File not found: {file}")
        return

    flags = _parse_flags(args[1:])
    target = flags.get("target") or flags.get("t")
    model = flags.get("model") or flags.get("m") or "auto"
    task = flags.get("task") or None

    if not target:
        console.print(f"  [bold]Error:[/] --target <column> is required")
        console.print(f"  [bold]Usage:[/] /train {file} --target <column>")
        return

    client = _get_client()
    if not client:
        return

    # Step 1: Upload
    _tool_block("train", f"file={file.name}  target={target}  model={model}")

    with simple_spinner() as progress:
        task_id = progress.add_task(f"Uploading {file.name}...", total=None)
        try:
            dataset = client.upload_dataset(file)
        except (ConnectionError, OrchestratorError) as exc:
            progress.stop()
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return

    dataset_id = dataset.get("id", "")
    file_path = dataset.get("filePath", dataset.get("file_path", str(file)))
    dataset_name = dataset.get("name", file.name)
    console.print(f"  [dim]Dataset uploaded → {dataset_id}[/]")

    # Step 2: Start training
    with simple_spinner() as progress:
        task_id = progress.add_task("Starting training job...", total=None)
        try:
            job = client.create_job(
                dataset_id=dataset_id,
                target=target,
                model_type=model,
                task=task,
                file_path=file_path,
                dataset_name=dataset_name,
            )
        except (ConnectionError, OrchestratorError) as exc:
            progress.stop()
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return

    client.close()
    job_id = job.get("id", "")
    console.print(f"  [dim]Job started → {job_id}[/]")
    console.print()

    # Step 3: Poll for results
    _poll_training_results(job_id)


def _poll_training_results(job_id: str, poll_interval: float = 1.5) -> None:
    """Poll job until completion and display results."""
    start_time = time.time()
    client = _get_client()
    if not client:
        return

    with training_progress() as progress:
        task = progress.add_task("Training...", total=None)
        last_log_index = 0

        while True:
            try:
                job = client.get_job(job_id)
            except (ConnectionError, OrchestratorError) as exc:
                progress.stop()
                console.print(f"  [bold]Error:[/] {exc}")
                client.close()
                return

            status = job.get("status", "").lower()
            stage = job.get("stage", status)
            metrics = job.get("metrics") or {}

            # Update progress description
            metric_str = ""
            for key in ("accuracy", "r2", "f1"):
                if key in metrics:
                    metric_str = f" | {key}={metrics[key]:.4f}"
                    break

            progress.update(task, description=f"[bold]{stage}[/]{metric_str}")

            # Print new log lines
            logs = job.get("logs") or []
            for entry in logs[last_log_index:]:
                if isinstance(entry, dict):
                    msg = entry.get("message", str(entry))
                    level = entry.get("level", "info")
                else:
                    msg = str(entry)
                    level = "info"
                if level == "error":
                    console.print(f"    [bold]✗[/] {msg}", highlight=False)
                else:
                    console.print(f"    [dim]›[/] {msg}", highlight=False)
            last_log_index = len(logs)

            if status in ("completed", "failed", "cancelled"):
                break

            time.sleep(poll_interval)

    client.close()
    elapsed = time.time() - start_time

    console.print()
    if status == "completed":
        console.print(f"  [bold green]✓[/] Training completed in {elapsed:.1f}s")

        metrics = job.get("metrics") or {}
        if metrics:
            _result_block("metrics", {k: v for k, v in metrics.items() if k != "training_time"})

        fi = job.get("feature_importance") or {}
        if fi:
            console.print(f"  [bold]Feature Importance[/]")
            sorted_fi = sorted(fi.items(), key=lambda x: x[1], reverse=True)
            for fname, importance in sorted_fi[:10]:
                bar_len = int(importance * 30)
                bar = "█" * bar_len + "░" * (30 - bar_len)
                console.print(f"    [dim]{fname:<24}[/] {bar} [bold]{importance:.4f}[/]")
            console.print()

        onnx_path = job.get("onnx_path") or job.get("model_path")
        if onnx_path:
            console.print(f"  [dim]ONNX model: {onnx_path}[/]")
        console.print(f"  [dim]Use /predict {job_id} to make predictions[/]")
        console.print()

    elif status == "failed":
        console.print(f"  [bold red]✗[/] Training failed")
        error = job.get("error", "Unknown error")
        _result_block("error", {"message": str(error)})
    else:
        console.print(f"  [bold]⊘[/] Training cancelled")


def cmd_predict(args: list[str]) -> None:
    """Make predictions with a trained model."""
    if not args:
        console.print(f"  [bold]Usage:[/] /predict <job_id> [--data 'json_array']")
        return

    job_id = args[0]
    flags = _parse_flags(args[1:])
    data_str = flags.get("data")

    client = _get_client()
    if not client:
        return

    if data_str:
        try:
            input_data = json.loads(data_str)
        except json.JSONDecodeError:
            console.print(f"  [bold]Error:[/] Invalid JSON in --data")
            client.close()
            return
    else:
        # No data provided — show usage and model info
        try:
            job = client.get_job(job_id)
        except (ConnectionError, OrchestratorError) as exc:
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return

        _tool_block("predict", f"job={job_id}")
        console.print(f"  Model: [bold]{job.get('model_type', '—')}[/]")
        console.print(f"  Target: [bold]{job.get('target', '—')}[/]")

        fi = job.get("feature_importance") or {}
        if fi:
            features = list(fi.keys())
            console.print(f"  Features: [dim]{', '.join(features)}[/]")
            example = {f: 0.0 for f in features[:5]}
            console.print(f"  [dim]Example: /predict {job_id} --data '{json.dumps([example])}'[/]")

        client.close()
        console.print()
        return

    _tool_block("predict", f"job={job_id}  samples={len(input_data)}")

    try:
        resp = client.predict(job_id=job_id, input_data=input_data)
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] {exc}")
        client.close()
        return

    client.close()

    predictions = resp.get("predictions", [])
    latency = resp.get("latency_ms", 0)
    engine = resp.get("model_info", {}).get("inference_engine", "—")

    _result_block("predictions", {
        "engine": engine,
        "latency_ms": latency,
        "count": len(predictions),
        "results": predictions[:10],
    })
    if len(predictions) > 10:
        console.print(f"  [dim]... and {len(predictions) - 10} more predictions[/]")
        console.print()


def cmd_models(args: list[str]) -> None:
    """List all trained models."""
    client = _get_client()
    if not client:
        return

    _tool_block("models", "listing all models")

    try:
        result = client.list_models()
        model_list = result.get("models", result if isinstance(result, list) else [])
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] {exc}")
        client.close()
        return

    client.close()

    if not model_list:
        console.print(f"  No models found. Train one with [bold]/train[/]")
        console.print()
        return

    console.print(models_table(model_list))
    console.print()


def cmd_datasets(args: list[str]) -> None:
    """List all uploaded datasets."""
    client = _get_client()
    if not client:
        return

    _tool_block("datasets", "listing all datasets")

    try:
        result = client.list_datasets()
        ds_list = result.get("datasets", result if isinstance(result, list) else [])
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] {exc}")
        client.close()
        return

    client.close()

    if not ds_list:
        console.print(f"  No datasets found. Upload one with [bold]/upload[/]")
        console.print()
        return

    table = Table(
        title="Datasets",
        border_style=GRAY_LIGHT,
        header_style=f"bold {BLACK}",
        title_style=f"bold {BLACK}",
        padding=(0, 1),
    )
    table.add_column("ID", style=GRAY_DARK, max_width=12)
    table.add_column("Name", max_width=30)
    table.add_column("Rows", justify="right", max_width=10)
    table.add_column("Columns", justify="right", max_width=10)
    table.add_column("Size", max_width=12)
    table.add_column("Uploaded", style=GRAY, max_width=20)

    for ds in ds_list:
        size = ds.get("file_size", 0)
        if isinstance(size, (int, float)) and size > 0:
            size_str = _human_bytes(size)
        else:
            size_str = "—"
        table.add_row(
            ds.get("id", "—")[:8],
            ds.get("name", "—"),
            str(ds.get("rows", "—")),
            str(len(ds.get("columns", []))),
            size_str,
            str(ds.get("uploaded_at", "—"))[:19],
        )

    console.print(table)
    console.print()


def cmd_status(args: list[str]) -> None:
    """Check status of jobs."""
    client = _get_client()
    if not client:
        return

    if args:
        job_id = args[0]
        _tool_block("status", f"job={job_id}")
        try:
            job = client.get_job(job_id)
        except (ConnectionError, OrchestratorError) as exc:
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return
        client.close()
        console.print(job_detail(job))
    else:
        _tool_block("status", "listing all jobs")
        try:
            result = client.list_jobs()
            jobs_list = result.get("jobs", result if isinstance(result, list) else [])
        except (ConnectionError, OrchestratorError) as exc:
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return
        client.close()

        if not jobs_list:
            console.print(f"  No jobs found.")
            console.print()
            return

        console.print(jobs_table(jobs_list))

    console.print()


def cmd_export(args: list[str]) -> None:
    """Export a trained model in various formats (onnx, pickle, model_card)."""
    if not args:
        console.print(f"  [bold]Usage:[/] /export <job_id> [--output <path>] [--format onnx|pickle|model_card]")
        return

    job_id = args[0]
    flags = _parse_flags(args[1:])
    export_format = flags.get("format") or "onnx"
    output_path = flags.get("output")

    # Set default output extension based on format
    if not output_path:
        ext_map = {"onnx": ".onnx", "pickle": ".pkl", "model_card": ".json"}
        output_path = f"model_{job_id}{ext_map.get(export_format, '.onnx')}"

    client = _get_client()
    if not client:
        return

    _tool_block("export", f"job={job_id}  format={export_format}")

    with simple_spinner() as progress:
        task = progress.add_task(f"Exporting model {job_id} ({export_format})...", total=None)
        try:
            resp = client.export_model(job_id, format=export_format)
        except (ConnectionError, OrchestratorError) as exc:
            progress.stop()
            console.print(f"  [bold]Error:[/] {exc}")
            client.close()
            return

    # Handle model_card format (JSON)
    if export_format == "model_card":
        client.close()
        card = resp.get("card", {})
        output = Path(output_path)
        output.write_text(json.dumps(card, indent=2, default=str))
        _result_block("exported", {
            "path": str(output),
            "size": _human_bytes(output.stat().st_size),
            "format": "model_card (JSON)",
        })
        return

    # Handle onnx / pickle (binary download)
    download_url = resp.get("download_url", resp.get("path", ""))
    if not download_url:
        progress.stop()
        console.print(f"  [bold]Error:[/] No file path returned from export")
        client.close()
        return

    # Extract filename from the server path
    import os as _os
    filename = _os.path.basename(download_url)

    progress.update(task, description=f"Downloading {filename}...")
    try:
        file_bytes = client.download_export(filename)
    except (ConnectionError, OrchestratorError) as exc:
        progress.stop()
        console.print(f"  [bold]Error:[/] Download failed: {exc}")
        client.close()
        return

    client.close()

    output = Path(output_path)
    output.write_bytes(file_bytes)
    size = output.stat().st_size

    _result_block("exported", {
        "path": str(output),
        "size": _human_bytes(size),
        "format": export_format.upper(),
    })


def cmd_logs(args: list[str]) -> None:
    """View training logs for a job."""
    if not args:
        console.print(f"  [bold]Usage:[/] /logs <job_id>")
        return

    job_id = args[0]

    client = _get_client()
    if not client:
        return

    _tool_block("logs", f"job={job_id}")

    try:
        job = client.get_job(job_id)
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] {exc}")
        client.close()
        return

    client.close()

    logs = job.get("logs") or []
    if not logs:
        console.print(f"  No logs found for job {job_id}")
        console.print()
        return

    for entry in logs:
        if isinstance(entry, dict):
            ts = entry.get("timestamp", "")[:19]
            level = entry.get("level", "info")
            stage = entry.get("stage", "")
            msg = entry.get("message", "")

            if level == "error":
                indicator = "[bold red]✗[/]"
            elif level == "warning":
                indicator = "[bold yellow]⚠[/]"
            elif stage == "complete":
                indicator = "[bold green]✓[/]"
            else:
                indicator = "[dim]›[/]"

            ts_str = f"[dim]{ts}[/]  " if ts else ""
            stage_str = f"[bold]{stage}[/]  " if stage else ""
            console.print(f"  {indicator}  {ts_str}{stage_str}{msg}")
        else:
            console.print(f"  [dim]›[/]  {entry}")

    console.print()


def cmd_explain(args: list[str]) -> None:
    """Show feature importance and model insights for a trained model."""
    if not args:
        console.print(f"  [bold]Usage:[/] /explain <job_id>")
        return

    job_id = args[0]

    client = _get_client()
    if not client:
        return

    _tool_block("explain", f"job={job_id}")

    try:
        job = client.get_job(job_id)
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] {exc}")
        client.close()
        return

    client.close()

    # Model info
    model_type = job.get("model_type", "—")
    task_type = job.get("task_type", "—")
    target = job.get("target", "—")
    metrics = job.get("metrics") or {}

    console.print(f"  [bold]Model:[/]     {model_type}")
    console.print(f"  [bold]Task:[/]      {task_type}")
    console.print(f"  [bold]Target:[/]    {target}")
    console.print()

    # Metrics summary
    if metrics:
        console.print(f"  [bold]Performance Metrics[/]")
        for k, v in metrics.items():
            if isinstance(v, float):
                console.print(f"    {k:<20} {v:.4f}")
        console.print()

    # Feature importance visualization
    fi = job.get("feature_importance") or {}
    if fi:
        sorted_fi = sorted(fi.items(), key=lambda x: x[1], reverse=True)
        max_len = max(len(name) for name, _ in sorted_fi) if sorted_fi else 20

        console.print(f"  [bold]Feature Importance[/]")
        console.print()

        total = sum(v for _, v in sorted_fi)
        cumulative = 0.0
        for fname, importance in sorted_fi:
            cumulative += importance
            bar_len = int(importance * 40)
            bar = "█" * bar_len + "░" * (40 - bar_len)
            pct = (importance / total * 100) if total > 0 else 0
            cum_pct = (cumulative / total * 100) if total > 0 else 0
            console.print(f"    [dim]{fname:<{max_len}}[/] {bar} [bold]{pct:5.1f}%[/] [dim](cum: {cum_pct:5.1f}%)[/]")

        console.print()

        # Top features summary
        top_n = min(5, len(sorted_fi))
        top_features = [name for name, _ in sorted_fi[:top_n]]
        top_pct = sum(v for _, v in sorted_fi[:top_n]) / total * 100 if total > 0 else 0
        console.print(f"  [bold]Summary:[/] Top {top_n} features explain [bold]{top_pct:.1f}%[/] of the model")
        if top_n < len(sorted_fi):
            console.print(f"  [dim]Consider dropping low-importance features to reduce dimensionality[/]")
        console.print()
    else:
        console.print(f"  [dim]No feature importance data available[/]")
        console.print()


def cmd_benchmark(args: list[str]) -> None:
    """Benchmark: train the same dataset with multiple algorithms and compare."""
    if not args:
        console.print(f"  [bold]Usage:[/] /benchmark <file> --target <column>")
        return

    file = Path(args[0])
    if not file.exists():
        console.print(f"  [bold]Error:[/] File not found: {file}")
        return

    flags = _parse_flags(args[1:])
    target = flags.get("target") or flags.get("t")
    if not target:
        console.print(f"  [bold]Error:[/] --target <column> is required")
        return

    algorithms = ["random_forest", "gradient_boosting", "xgboost", "logistic_regression"]
    results: list[dict[str, Any]] = []

    console.print()
    console.print(f"  [bold]Benchmark[/] — {file.name} × {len(algorithms)} algorithms")
    console.print()

    # Upload dataset once and reuse for all algorithms
    client = _get_client()
    if not client:
        return

    _tool_block("upload", f"file={file.name}")
    try:
        dataset = client.upload_dataset(file)
        dataset_id = dataset.get("id", "")
        file_path = dataset.get("filePath", dataset.get("file_path", str(file)))
        dataset_name = dataset.get("name", file.name)
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] Upload failed: {exc}")
        client.close()
        return

    console.print(f"  [dim]Dataset uploaded → {dataset_id}[/]")

    for algo in algorithms:
        _tool_block("train", f"algorithm={algo}  target={target}")

        try:
            with simple_spinner() as progress:
                task_id = progress.add_task(f"Training {algo}...", total=None)
                job = client.create_job(
                    dataset_id=dataset_id,
                    target=target,
                    model_type=algo,
                    task=None,
                    file_path=file_path,
                    dataset_name=dataset_name,
                )

            job_id = job.get("id", "")

            # Wait for completion
            for _ in range(60):
                time.sleep(1.0)
                try:
                    j = client.get_job(job_id)
                except Exception:
                    break
                if j.get("status") in ("completed", "failed", "cancelled"):
                    job = j
                    break

            metrics = job.get("metrics") or {}
            training_time = metrics.get("training_time", 0)
            results.append({
                "algorithm": algo,
                "status": job.get("status", "—"),
                "score": metrics.get("accuracy") or metrics.get("r2") or 0,
                "score_name": "accuracy" if "accuracy" in metrics else "r2",
                "training_time": training_time,
                "metrics": metrics,
            })

        except (ConnectionError, OrchestratorError) as exc:
            results.append({"algorithm": algo, "status": "error", "error": str(exc)})

    client.close()

    # Comparison table
    console.print()
    table = Table(
        title="Benchmark Results",
        border_style=GRAY_LIGHT,
        header_style=f"bold {BLACK}",
        title_style=f"bold {BLACK}",
        padding=(0, 1),
    )
    table.add_column("Algorithm", style=f"bold {BLACK}", max_width=22)
    table.add_column("Status", min_width=12)
    table.add_column("Score", justify="right", max_width=12)
    table.add_column("Time", max_width=10)

    # Sort by score descending
    completed = [r for r in results if r["status"] == "completed"]
    completed.sort(key=lambda x: x["score"], reverse=True)

    for i, r in enumerate(completed):
        medal = "🥇" if i == 0 else ("🥈" if i == 1 else ("🥉" if i == 2 else "  "))
        table.add_row(
            f"{medal} {r['algorithm']}",
            status_badge("completed"),
            f"{r['score']:.4f} ({r['score_name']})",
            f"{r['training_time']:.2f}s",
        )

    for r in results:
        if r["status"] != "completed":
            table.add_row(
                r["algorithm"],
                status_badge(r["status"]),
                "—",
                "—",
            )

    console.print(table)

    if completed:
        best = completed[0]
        console.print()
        console.print(f"  [bold]Best:[/] {best['algorithm']} ({best['score_name']}={best['score']:.4f})")
        console.print()

    console.print()


def cmd_delete(args: list[str]) -> None:
    """Delete a job or model."""
    if not args:
        console.print(f"  [bold]Usage:[/] /delete job <id>  or  /delete model <id>")
        return

    resource_type = args[0].lower()
    if resource_type not in ("job", "model") or len(args) < 2:
        console.print(f"  [bold]Usage:[/] /delete job <id>  or  /delete model <id>")
        return

    resource_id = args[1]
    client = _get_client()
    if not client:
        return

    _tool_block("delete", f"{resource_type}={resource_id}")

    try:
        if resource_type == "job":
            resp = client._delete(f"/jobs/{resource_id}")
        else:
            resp = client._delete(f"/models/{resource_id}")
    except (ConnectionError, OrchestratorError) as exc:
        console.print(f"  [bold]Error:[/] {exc}")
        client.close()
        return

    client.close()
    console.print(f"  ✓ {resource_type.title()} [bold]{resource_id}[/] deleted")
    console.print()


def cmd_config(args: list[str]) -> None:
    """View or update configuration."""
    cfg = load()
    url = base_url(cfg)

    _tool_block("config", f"path={config_path()}")

    console.print(f"  [bold]Host:[/]         {cfg['host']}")
    console.print(f"  [bold]Port:[/]         {cfg['port']}")
    console.print(f"  [bold]Upload dir:[/]   {cfg.get('upload_dir', './data')}")
    console.print(f"  [bold]Base URL:[/]     [dim]{url}[/]")
    console.print()


def cmd_health(args: list[str]) -> None:
    """Check orchestrator health."""
    client = _get_client()
    if not client:
        return

    _tool_block("health", "checking orchestrator")

    try:
        health = client.health()
    except ConnectionError as exc:
        console.print(f"  [bold]●[/] Orchestrator [bold red]unreachable[/]: {exc}")
        client.close()
        console.print()
        return
    except OrchestratorError as exc:
        console.print(f"  [bold]●[/] Orchestrator [bold red]error[/]: {exc}")
        client.close()
        console.print()
        return

    client.close()

    status = health.get("status", "unknown")
    version = health.get("version", "—")
    ml_engine = health.get("ml_engine", "—")
    loaded = health.get("loaded_models", 0)
    trained = health.get("trained_models_in_memory", 0)

    if status == "ok":
        console.print(f"  [bold green]●[/] Orchestrator [bold green]healthy[/]")
    else:
        console.print(f"  [bold red]●[/] Orchestrator [bold red]{status}[/]")

    console.print(f"  Version:            {version}")
    console.print(f"  ML Engine:          {ml_engine}")
    console.print(f"  Models in memory:   {trained} trained, {loaded} ONNX-loaded")
    console.print()
    return health


def cmd_clear(args: list[str]) -> None:
    """Clear the terminal."""
    console.clear()
    console.print()


def cmd_version(args: list[str]) -> None:
    """Show version information."""
    from . import __version__
    console.print(f"  OpenAutoML CLI [bold]v{__version__}[/]")
    console.print(f"  Phase 1 — scikit-learn / XGBoost / ONNX")
    console.print()


def cmd_help(args: list[str]) -> None:
    """Show help for all commands."""
    # Filter by optional topic
    topic = args[0] if args else None
    if topic:
        cmd = registry.get(topic.lstrip("/"))
        if cmd:
            console.print()
            console.print(f"  [bold]/{cmd.name}[/] — {cmd.help_text}")
            if cmd.usage:
                console.print(f"  [dim]Usage: {cmd.usage}[/]")
            console.print()
            return
        else:
            console.print(f"  Unknown command: /{topic}")
            console.print()

    console.print()
    console.print(registry.help_table())
    console.print(f"  [dim]Tip: You can also type natural language, e.g.:[/]")
    console.print(f"  [dim]  \"train my data.csv with target price\"[/]")
    console.print(f"  [dim]  \"show me all models\"[/]")
    console.print(f"  [dim]  \"explain job abc123\"[/]")
    console.print()


def cmd_quit(args: list[str]) -> None:
    """Exit the REPL."""
    console.print()
    console.print(f"  [dim]Goodbye — OpenAutoML[/]")
    console.print()
    raise SystemExit(0)


# ── Natural Language Parser ───────────────────────────────────────────────

NL_PATTERNS: list[tuple[re.Pattern, Callable[[re.Match], list[str]]]] = []

def _register_nl(pattern: str, handler: Callable[[re.Match], list[str]]) -> None:
    NL_PATTERNS.append((re.compile(pattern, re.IGNORECASE), handler))


def _nl_train(m: re.Match) -> list[str]:
    """Parse: train <file> with/on target <col> [using model <type>]"""
    file = m.group(1)
    target = m.group(2)
    model = None
    if m.lastindex is not None and m.lastindex >= 3:
        model = m.group(3) or None
    args = ["train", file, "--target", target]
    if model:
        args.extend(["--model", model])
    return args


def _nl_upload(m: re.Match) -> list[str]:
    return ["upload", m.group(1)]


def _nl_predict(m: re.Match) -> list[str]:
    return ["predict", m.group(1)]


def _nl_models(m: re.Match) -> list[str]:
    return ["models"]


def _nl_datasets(m: re.Match) -> list[str]:
    return ["datasets"]


def _nl_status(m: re.Match) -> list[str]:
    job_id = m.group(1)
    return ["status", job_id] if job_id else ["status"]


def _nl_export(m: re.Match) -> list[str]:
    return ["export", m.group(1)]


def _nl_explain(m: re.Match) -> list[str]:
    return ["explain", m.group(1)]


def _nl_benchmark(m: re.Match) -> list[str]:
    file = m.group(1)
    target = m.group(2)
    return ["benchmark", file, "--target", target]


def _nl_logs(m: re.Match) -> list[str]:
    return ["logs", m.group(1)]


def _nl_delete(m: re.Match) -> list[str]:
    rtype = m.group(1)
    rid = m.group(2)
    return ["delete", rtype, rid]


def _nl_health(m: re.Match) -> list[str]:
    return ["health"]


def _nl_config(m: re.Match) -> list[str]:
    return ["config"]


# Register NL patterns
_register_nl(r"train\s+(\S+)\s+(?:with|on|for)\s+(?:target|column)\s+(\w+)(?:\s+(?:using|with)\s+(?:model|algorithm)\s+(\w+))?", _nl_train)
_register_nl(r"train\s+(\S+)\s+--?t(?:arget)?\s*=?\s*(\w+)", _nl_train)
_register_nl(r"upload\s+(\S+)", _nl_upload)
_register_nl(r"(?:predict|infer|classify|regress)\s+(?:job\s+|model\s+)?(\S+)", _nl_predict)
_register_nl(r"show\s+(?:me\s+)?(?:all\s+)?models?", _nl_models)
_register_nl(r"list\s+(?:all\s+)?(?:my\s+)?models?", _nl_models)
_register_nl(r"show\s+(?:me\s+)?(?:all\s+)?datasets?", _nl_datasets)
_register_nl(r"list\s+(?:all\s+)?(?:my\s+)?datasets?", _nl_datasets)
_register_nl(r"(?:status|check)\s+(?:job\s+)?(\S+)", _nl_status)
_register_nl(r"(?:export|download)\s+(?:model\s+)?(?:job\s+)?(\S+)", _nl_export)
_register_nl(r"(?:explain|importance|features)\s+(?:job\s+)?(\S+)", _nl_explain)
_register_nl(r"benchmark\s+(\S+)\s+(?:with|on|for)\s+(?:target|column)\s+(\w+)", _nl_benchmark)
_register_nl(r"benchmark\s+(\S+)\s+--?t(?:arget)?\s*=?\s*(\w+)", _nl_benchmark)
_register_nl(r"(?:logs?|log)\s+(?:job\s+)?(\S+)", _nl_logs)
_register_nl(r"(?:delete|remove)\s+(job|model)\s+(\S+)", _nl_delete)
_register_nl(r"(?:health|ping|status)(?:\s+check)?", _nl_health)
_register_nl(r"(?:config|settings?|setup)", _nl_config)


def parse_natural_language(text: str) -> list[str] | None:
    """Try to parse natural language input into a command. Returns None if no match."""
    for pattern, handler in NL_PATTERNS:
        m = pattern.search(text)
        if m:
            return handler(m)
    return None


# ── Register All Commands ─────────────────────────────────────────────────

registry.register(Command("init", cmd_init, "Initialize OpenAutoML configuration", "/init [--host H] [--port P]", needs_config=False))
registry.register(Command("upload", cmd_upload, "Upload a dataset file", "/upload <file.csv|json|parquet>"))
registry.register(Command("train", cmd_train, "Train a model on a dataset", "/train <file> --target <col> [--model <type>] [--task <type>]"))
registry.register(Command("predict", cmd_predict, "Make predictions with a trained model", "/predict <job_id> [--data '<json>']"))
registry.register(Command("models", cmd_models, "List all trained models", "/models"))
registry.register(Command("datasets", cmd_datasets, "List all uploaded datasets", "/datasets"))
registry.register(Command("status", cmd_status, "Check job status", "/status [job_id]"))
registry.register(Command("export", cmd_export, "Export model (onnx/pickle/model_card)", "/export <job_id> [--output <path>] [--format onnx|pickle|model_card]"))
registry.register(Command("logs", cmd_logs, "View training logs", "/logs <job_id>"))
registry.register(Command("explain", cmd_explain, "Feature importance & model insights", "/explain <job_id>"))
registry.register(Command("benchmark", cmd_benchmark, "Compare algorithms on a dataset", "/benchmark <file> --target <col>"))
registry.register(Command("delete", cmd_delete, "Delete a job or model", "/delete (job|model) <id>"))
registry.register(Command("config", cmd_config, "View configuration", "/config"))
registry.register(Command("health", cmd_health, "Check orchestrator health", "/health"))
registry.register(Command("clear", cmd_clear, "Clear the terminal", "/clear", needs_config=False))
registry.register(Command("version", cmd_version, "Show version info", "/version", needs_config=False))
registry.register(Command("help", cmd_help, "Show available commands", "/help [command]", aliases=["?"], needs_config=False))
registry.register(Command("quit", cmd_quit, "Exit OpenAutoML", "/quit", aliases=["exit", "q"], needs_config=False))
