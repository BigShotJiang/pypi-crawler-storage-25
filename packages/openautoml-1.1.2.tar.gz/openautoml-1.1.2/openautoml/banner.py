"""OpenAutoML ASCII art banner and splash screen."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .outputs import GRAY, GRAY_DARK, GRAY_LIGHT, GRAY_LIGHTER

console = Console()

BANNER = r"""
   ____  ____  _______   __      ___   __  ____________        __  _____ 
  / __ \/ __ \/ ____/ | / /     /   | / / / /_  __/ __ \      /  |/  / / 
 / / / / /_/ / __/ /  |/ /_____/ /| |/ / / / / / / / / /_____/ /|_/ / /  
/ /_/ / ____/ /___/ /|  /_____/ ___ / /_/ / / / / /_/ /_____/ /  / / /___
\____/_/   /_____/_/ |_/     /_/  |_\____/ /_/  \____/     /_/  /_/_____/

             Automate ML from CSV to Production API
"""

BANNER_COMPACT = r"""
   ◆ OpenAutoML  ─  Automate ML from CSV to Production API
"""


def splash(health: dict | None = None) -> None:
    """Display the full startup splash screen."""
    console.clear()
    console.print()

    # ASCII banner
    for line in BANNER.strip().split("\n"):
        console.print(f"  [bold]{line}[/]")
    console.print()

    # Status bar
    status_parts: list[str] = []

    if health:
        status = health.get("status", "unknown")
        version = health.get("version", "—")
        ml_engine = health.get("ml_engine", "—")
        loaded = health.get("loaded_models", 0)
        trained = health.get("trained_models_in_memory", 0)

        if status == "ok":
            status_parts.append(f"[bold]●[/] Orchestrator [bold green]connected[/]")
        else:
            status_parts.append(f"[bold]●[/] Orchestrator [bold red]disconnected[/]")

        status_parts.append(f"v{version}")
        status_parts.append(f"engine: {ml_engine}")
        if loaded or trained:
            status_parts.append(f"models in memory: {trained} trained, {loaded} loaded")

        console.print(f"  [dim]{'  │  '.join(status_parts)}[/]")
    else:
        console.print(f"  [dim]● Orchestrator not configured — run [bold]/init[/bold] to connect[/]")

    console.print()
    console.print(f"  [dim]{GRAY_DARK}Type /help for commands, or describe what you want to do.[/]")
    console.print()


def compact_banner() -> None:
    """Display a compact one-line banner (for non-interactive context)."""
    console.print()
    console.print(f"  [bold]{BANNER_COMPACT.strip()}[/]")
    console.print()
