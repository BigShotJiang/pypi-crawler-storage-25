# OpenAutoML CLI

**Automate ML from CSV to Production API** — Claude Code-style terminal interface.

[![PyPI version](https://img.shields.io/pypi/v/openautoml.svg)](https://pypi.org/project/openautoml/)
[![Python](https://img.shields.io/pypi/pyversions/openautoml.svg)](https://pypi.org/project/openautoml/)
[![License](https://img.shields.io/pypi/l/openautoml.svg)](https://github.com/openautoml/openautoml/blob/main/LICENSE)

## Installation

```bash
pip install openautoml
```

## Quick Start

```bash
# Initialize configuration (connects to your orchestrator)
openautoml init --host localhost --port 3030

# Train a model from a CSV file
openautoml train data.csv --target price

# Make predictions
openautoml predict <job_id> --data '[{"feature1": 1.0, "feature2": 2.5}]'

# Export to ONNX
openautoml export <job_id>

# List models and datasets
openautoml models
openautoml datasets
```

## Interactive REPL

Running `openautoml` without arguments launches an interactive REPL with:

- **Slash commands** — `/train`, `/predict`, `/models`, `/export`, `/help`, etc.
- **Natural language** — *"train my data.csv with target price"*
- **Tab completion** — auto-complete commands and aliases
- **Rich output** — tables, panels, progress bars, status badges

```bash
openautoml
```

```
   ◆ OpenAutoML  ─  Automate ML from CSV to Production API

  ◆ openautoml > /help          # Show all commands
  ◆ openautoml > train data.csv --target label
  ◆ openautoml > explain <job>  # Feature importance
  ◆ openautoml > benchmark data.csv --target label  # Compare algorithms
  ◆ openautoml > /quit
```

## Commands

| Command | Description |
|---------|-------------|
| `openautoml init [--host H] [--port P]` | Initialize configuration |
| `openautoml train FILE --target COL [--model TYPE]` | Train a model |
| `openautoml predict JOB [--data JSON]` | Make predictions |
| `openautoml status [JOB]` | Check job status |
| `openautoml models` | List trained models |
| `openautoml datasets` | List uploaded datasets |
| `openautoml export JOB [--format onnx\|pickle\|model_card]` | Export model |
| `openautoml explain JOB` | Feature importance & insights |
| `openautoml benchmark FILE --target COL` | Compare algorithms |
| `openautoml logs JOB` | View training logs |
| `openautoml delete (job\|model) ID` | Delete resource |
| `openautoml cancel JOB` | Cancel running job |
| `openautoml health` | Check orchestrator health |
| `openautoml config` | View configuration |
| `openautoml version` | Show version |

## Supported Algorithms

- `random_forest` — Random Forest (default)
- `gradient_boosting` — Gradient Boosting
- `xgboost` — XGBoost
- `logistic_regression` — Logistic Regression
- `linear_regression` — Linear Regression
- `auto` — Auto-select best algorithm

## Export Formats

- **ONNX** (default) — Standard format for production deployment
- **Pickle** — Python joblib serialization
- **Model Card** — JSON metadata card with metrics and feature importance

## Requirements

- Python 3.10+
- An OpenAutoML orchestrator running (self-hosted or cloud)

## License

MIT
