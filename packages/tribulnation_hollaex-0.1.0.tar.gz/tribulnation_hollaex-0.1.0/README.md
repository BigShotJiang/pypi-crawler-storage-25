# Tribulnation Hollaex SDK

> An SDK to connect Hollaex with the Tribulnation ecosystem.

🚧 Under construction.