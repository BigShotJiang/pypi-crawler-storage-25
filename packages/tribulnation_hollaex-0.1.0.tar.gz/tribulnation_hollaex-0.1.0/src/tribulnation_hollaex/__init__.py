"""
### Tribulnation Hollaex
> An SDK to connect Hollaex with the Tribulnation ecosystem.

- Details
"""