# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ClusterInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'cluster_id': 'str',
        'cluster_name': 'str',
        'cluster_path': 'str'
    }

    attribute_map = {
        'cluster_id': 'clusterID',
        'cluster_name': 'clusterName',
        'cluster_path': 'clusterPath'
    }

    def __init__(self, cluster_id=None, cluster_name=None, cluster_path=None):
        r"""ClusterInfo

        The model defined in huaweicloud sdk

        :param cluster_id: 集群ID
        :type cluster_id: str
        :param cluster_name: 集群名称
        :type cluster_name: str
        :param cluster_path: 集群路径
        :type cluster_path: str
        """
        
        

        self._cluster_id = None
        self._cluster_name = None
        self._cluster_path = None
        self.discriminator = None

        if cluster_id is not None:
            self.cluster_id = cluster_id
        if cluster_name is not None:
            self.cluster_name = cluster_name
        if cluster_path is not None:
            self.cluster_path = cluster_path

    @property
    def cluster_id(self):
        r"""Gets the cluster_id of this ClusterInfo.

        集群ID

        :return: The cluster_id of this ClusterInfo.
        :rtype: str
        """
        return self._cluster_id

    @cluster_id.setter
    def cluster_id(self, cluster_id):
        r"""Sets the cluster_id of this ClusterInfo.

        集群ID

        :param cluster_id: The cluster_id of this ClusterInfo.
        :type cluster_id: str
        """
        self._cluster_id = cluster_id

    @property
    def cluster_name(self):
        r"""Gets the cluster_name of this ClusterInfo.

        集群名称

        :return: The cluster_name of this ClusterInfo.
        :rtype: str
        """
        return self._cluster_name

    @cluster_name.setter
    def cluster_name(self, cluster_name):
        r"""Sets the cluster_name of this ClusterInfo.

        集群名称

        :param cluster_name: The cluster_name of this ClusterInfo.
        :type cluster_name: str
        """
        self._cluster_name = cluster_name

    @property
    def cluster_path(self):
        r"""Gets the cluster_path of this ClusterInfo.

        集群路径

        :return: The cluster_path of this ClusterInfo.
        :rtype: str
        """
        return self._cluster_path

    @cluster_path.setter
    def cluster_path(self, cluster_path):
        r"""Sets the cluster_path of this ClusterInfo.

        集群路径

        :param cluster_path: The cluster_path of this ClusterInfo.
        :type cluster_path: str
        """
        self._cluster_path = cluster_path

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ClusterInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
