"""CaudalFlow Copilot agent package."""
