from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_complete_setup_request import AgentCompleteSetupRequest
from ...models.agent_complete_setup_response_201 import AgentCompleteSetupResponse201
from ...types import Response


def _get_kwargs(
    *,
    body: AgentCompleteSetupRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/complete-setup",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentCompleteSetupResponse201 | Any | None:
    if response.status_code == 201:
        response_201 = AgentCompleteSetupResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentCompleteSetupResponse201 | Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentCompleteSetupRequest,
) -> Response[AgentCompleteSetupResponse201 | Any]:
    """Complete agent setup

     Phase 2 of the two-phase agent setup flow. Verifies the setup token, creates
    the child profile with the provided public key, auto-issues a challenge token,
    and returns the challenge for the CLI to sign. No session required — the setup
    token proves authorization.

    Args:
        body (AgentCompleteSetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentCompleteSetupResponse201 | Any]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AgentCompleteSetupRequest,
) -> AgentCompleteSetupResponse201 | Any | None:
    """Complete agent setup

     Phase 2 of the two-phase agent setup flow. Verifies the setup token, creates
    the child profile with the provided public key, auto-issues a challenge token,
    and returns the challenge for the CLI to sign. No session required — the setup
    token proves authorization.

    Args:
        body (AgentCompleteSetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentCompleteSetupResponse201 | Any
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentCompleteSetupRequest,
) -> Response[AgentCompleteSetupResponse201 | Any]:
    """Complete agent setup

     Phase 2 of the two-phase agent setup flow. Verifies the setup token, creates
    the child profile with the provided public key, auto-issues a challenge token,
    and returns the challenge for the CLI to sign. No session required — the setup
    token proves authorization.

    Args:
        body (AgentCompleteSetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentCompleteSetupResponse201 | Any]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AgentCompleteSetupRequest,
) -> AgentCompleteSetupResponse201 | Any | None:
    """Complete agent setup

     Phase 2 of the two-phase agent setup flow. Verifies the setup token, creates
    the child profile with the provided public key, auto-issues a challenge token,
    and returns the challenge for the CLI to sign. No session required — the setup
    token proves authorization.

    Args:
        body (AgentCompleteSetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentCompleteSetupResponse201 | Any
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
