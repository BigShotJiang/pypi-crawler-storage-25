from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.update_child_avatar_body import UpdateChildAvatarBody
from ...models.update_child_avatar_response_200 import UpdateChildAvatarResponse200
from ...types import Response


def _get_kwargs(
    child_id: UUID,
    *,
    body: UpdateChildAvatarBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/auth/delegations/{child_id}/avatar".format(
            child_id=quote(str(child_id), safe=""),
        ),
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UpdateChildAvatarResponse200 | None:
    if response.status_code == 200:
        response_200 = UpdateChildAvatarResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UpdateChildAvatarResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChildAvatarBody,
) -> Response[UpdateChildAvatarResponse200]:
    """Upload a child profile avatar

     Uploads a profile image for a child profile. Accepts JPEG, PNG, or WebP up to 2 MB.

    Args:
        child_id (UUID):
        body (UpdateChildAvatarBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateChildAvatarResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChildAvatarBody,
) -> UpdateChildAvatarResponse200 | None:
    """Upload a child profile avatar

     Uploads a profile image for a child profile. Accepts JPEG, PNG, or WebP up to 2 MB.

    Args:
        child_id (UUID):
        body (UpdateChildAvatarBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateChildAvatarResponse200
    """

    return sync_detailed(
        child_id=child_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChildAvatarBody,
) -> Response[UpdateChildAvatarResponse200]:
    """Upload a child profile avatar

     Uploads a profile image for a child profile. Accepts JPEG, PNG, or WebP up to 2 MB.

    Args:
        child_id (UUID):
        body (UpdateChildAvatarBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateChildAvatarResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChildAvatarBody,
) -> UpdateChildAvatarResponse200 | None:
    """Upload a child profile avatar

     Uploads a profile image for a child profile. Accepts JPEG, PNG, or WebP up to 2 MB.

    Args:
        child_id (UUID):
        body (UpdateChildAvatarBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateChildAvatarResponse200
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            client=client,
            body=body,
        )
    ).parsed
