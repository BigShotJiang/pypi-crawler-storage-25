from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_verify_setup_request import AgentVerifySetupRequest
from ...models.agent_verify_setup_response_200 import AgentVerifySetupResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: AgentVerifySetupRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/complete-setup/verify",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentVerifySetupResponse200 | Any | None:
    if response.status_code == 200:
        response_200 = AgentVerifySetupResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentVerifySetupResponse200 | Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentVerifySetupRequest,
) -> Response[AgentVerifySetupResponse200 | Any]:
    """Verify agent setup challenge

     Phase 3 of the two-phase agent setup flow. Verifies the signed challenge JWS
    against the agent's public key. On success, marks the agent as verified.
    For service-managed parents, also auto-creates a delegation. No session
    required — the setup token proves authorization.

    Args:
        body (AgentVerifySetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVerifySetupResponse200 | Any]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AgentVerifySetupRequest,
) -> AgentVerifySetupResponse200 | Any | None:
    """Verify agent setup challenge

     Phase 3 of the two-phase agent setup flow. Verifies the signed challenge JWS
    against the agent's public key. On success, marks the agent as verified.
    For service-managed parents, also auto-creates a delegation. No session
    required — the setup token proves authorization.

    Args:
        body (AgentVerifySetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVerifySetupResponse200 | Any
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentVerifySetupRequest,
) -> Response[AgentVerifySetupResponse200 | Any]:
    """Verify agent setup challenge

     Phase 3 of the two-phase agent setup flow. Verifies the signed challenge JWS
    against the agent's public key. On success, marks the agent as verified.
    For service-managed parents, also auto-creates a delegation. No session
    required — the setup token proves authorization.

    Args:
        body (AgentVerifySetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVerifySetupResponse200 | Any]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AgentVerifySetupRequest,
) -> AgentVerifySetupResponse200 | Any | None:
    """Verify agent setup challenge

     Phase 3 of the two-phase agent setup flow. Verifies the signed challenge JWS
    against the agent's public key. On success, marks the agent as verified.
    For service-managed parents, also auto-creates a delegation. No session
    required — the setup token proves authorization.

    Args:
        body (AgentVerifySetupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVerifySetupResponse200 | Any
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
