from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.verify_agent_challenge_request import VerifyAgentChallengeRequest
from ...models.verify_agent_challenge_response_200 import VerifyAgentChallengeResponse200
from ...types import Response


def _get_kwargs(
    child_id: UUID,
    *,
    body: VerifyAgentChallengeRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/{child_id}/challenge/verify".format(
            child_id=quote(str(child_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> VerifyAgentChallengeResponse200 | None:
    if response.status_code == 200:
        response_200 = VerifyAgentChallengeResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[VerifyAgentChallengeResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAgentChallengeRequest,
) -> Response[VerifyAgentChallengeResponse200]:
    """Verify challenge response

     Submits the child profile's signed JWS response to the challenge. On success, the child is marked as
    key-verified.

    Args:
        child_id (UUID):
        body (VerifyAgentChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyAgentChallengeResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAgentChallengeRequest,
) -> VerifyAgentChallengeResponse200 | None:
    """Verify challenge response

     Submits the child profile's signed JWS response to the challenge. On success, the child is marked as
    key-verified.

    Args:
        child_id (UUID):
        body (VerifyAgentChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyAgentChallengeResponse200
    """

    return sync_detailed(
        child_id=child_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAgentChallengeRequest,
) -> Response[VerifyAgentChallengeResponse200]:
    """Verify challenge response

     Submits the child profile's signed JWS response to the challenge. On success, the child is marked as
    key-verified.

    Args:
        child_id (UUID):
        body (VerifyAgentChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyAgentChallengeResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAgentChallengeRequest,
) -> VerifyAgentChallengeResponse200 | None:
    """Verify challenge response

     Submits the child profile's signed JWS response to the challenge. On success, the child is marked as
    key-verified.

    Args:
        child_id (UUID):
        body (VerifyAgentChallengeRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyAgentChallengeResponse200
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            client=client,
            body=body,
        )
    ).parsed
