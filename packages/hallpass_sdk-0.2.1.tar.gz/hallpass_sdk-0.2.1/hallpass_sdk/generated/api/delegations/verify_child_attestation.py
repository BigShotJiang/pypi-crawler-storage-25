from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.verify_child_attestation_body import VerifyChildAttestationBody
from ...models.verify_child_attestation_response_200 import VerifyChildAttestationResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    child_id: UUID,
    attestation_id: UUID,
    *,
    body: VerifyChildAttestationBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/{child_id}/attestations/{attestation_id}/verify".format(
            child_id=quote(str(child_id), safe=""),
            attestation_id=quote(str(attestation_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> VerifyChildAttestationResponse200 | None:
    if response.status_code == 200:
        response_200 = VerifyChildAttestationResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[VerifyChildAttestationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyChildAttestationBody | Unset = UNSET,
) -> Response[VerifyChildAttestationResponse200]:
    """Verify a child profile attestation

     Triggers verification for a child profile attestation.

    Args:
        child_id (UUID):
        attestation_id (UUID):
        body (VerifyChildAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyChildAttestationResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        attestation_id=attestation_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyChildAttestationBody | Unset = UNSET,
) -> VerifyChildAttestationResponse200 | None:
    """Verify a child profile attestation

     Triggers verification for a child profile attestation.

    Args:
        child_id (UUID):
        attestation_id (UUID):
        body (VerifyChildAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyChildAttestationResponse200
    """

    return sync_detailed(
        child_id=child_id,
        attestation_id=attestation_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyChildAttestationBody | Unset = UNSET,
) -> Response[VerifyChildAttestationResponse200]:
    """Verify a child profile attestation

     Triggers verification for a child profile attestation.

    Args:
        child_id (UUID):
        attestation_id (UUID):
        body (VerifyChildAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyChildAttestationResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        attestation_id=attestation_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyChildAttestationBody | Unset = UNSET,
) -> VerifyChildAttestationResponse200 | None:
    """Verify a child profile attestation

     Triggers verification for a child profile attestation.

    Args:
        child_id (UUID):
        attestation_id (UUID):
        body (VerifyChildAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyChildAttestationResponse200
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            attestation_id=attestation_id,
            client=client,
            body=body,
        )
    ).parsed
