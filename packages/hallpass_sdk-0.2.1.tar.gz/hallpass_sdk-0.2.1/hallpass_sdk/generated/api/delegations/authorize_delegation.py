from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.authorize_delegation_body import AuthorizeDelegationBody
from ...models.authorize_delegation_response_201 import AuthorizeDelegationResponse201
from ...types import UNSET, Response, Unset


def _get_kwargs(
    child_id: UUID,
    *,
    body: AuthorizeDelegationBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/{child_id}/authorize".format(
            child_id=quote(str(child_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | AuthorizeDelegationResponse201 | None:
    if response.status_code == 201:
        response_201 = AuthorizeDelegationResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | AuthorizeDelegationResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeDelegationBody | Unset = UNSET,
) -> Response[Any | AuthorizeDelegationResponse201]:
    """Issue delegation for a service-managed agent

     Creates a new active delegation for the specified child profile. Only available to service-managed
    operators. The server signs the delegation artifact with the operator's managed key.

    Args:
        child_id (UUID):
        body (AuthorizeDelegationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizeDelegationResponse201]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeDelegationBody | Unset = UNSET,
) -> Any | AuthorizeDelegationResponse201 | None:
    """Issue delegation for a service-managed agent

     Creates a new active delegation for the specified child profile. Only available to service-managed
    operators. The server signs the delegation artifact with the operator's managed key.

    Args:
        child_id (UUID):
        body (AuthorizeDelegationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizeDelegationResponse201
    """

    return sync_detailed(
        child_id=child_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeDelegationBody | Unset = UNSET,
) -> Response[Any | AuthorizeDelegationResponse201]:
    """Issue delegation for a service-managed agent

     Creates a new active delegation for the specified child profile. Only available to service-managed
    operators. The server signs the delegation artifact with the operator's managed key.

    Args:
        child_id (UUID):
        body (AuthorizeDelegationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthorizeDelegationResponse201]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AuthorizeDelegationBody | Unset = UNSET,
) -> Any | AuthorizeDelegationResponse201 | None:
    """Issue delegation for a service-managed agent

     Creates a new active delegation for the specified child profile. Only available to service-managed
    operators. The server signs the delegation artifact with the operator's managed key.

    Args:
        child_id (UUID):
        body (AuthorizeDelegationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthorizeDelegationResponse201
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            client=client,
            body=body,
        )
    ).parsed
