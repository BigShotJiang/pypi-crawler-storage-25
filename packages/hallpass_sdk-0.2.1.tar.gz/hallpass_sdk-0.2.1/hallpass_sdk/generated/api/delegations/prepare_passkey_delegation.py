from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.prepare_passkey_delegation_body import PreparePasskeyDelegationBody
from ...models.prepare_passkey_delegation_response_200 import PreparePasskeyDelegationResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: PreparePasskeyDelegationBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/passkey/prepare",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | PreparePasskeyDelegationResponse200 | None:
    if response.status_code == 200:
        response_200 = PreparePasskeyDelegationResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | PreparePasskeyDelegationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PreparePasskeyDelegationBody,
) -> Response[Any | PreparePasskeyDelegationResponse200]:
    """Prepare a passkey-backed delegation approval

     Returns WebAuthn assertion options with a challenge bound to the delegation payload. The client must
    complete the WebAuthn assertion ceremony and submit the result to the approve endpoint.

    Args:
        body (PreparePasskeyDelegationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PreparePasskeyDelegationResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PreparePasskeyDelegationBody,
) -> Any | PreparePasskeyDelegationResponse200 | None:
    """Prepare a passkey-backed delegation approval

     Returns WebAuthn assertion options with a challenge bound to the delegation payload. The client must
    complete the WebAuthn assertion ceremony and submit the result to the approve endpoint.

    Args:
        body (PreparePasskeyDelegationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PreparePasskeyDelegationResponse200
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PreparePasskeyDelegationBody,
) -> Response[Any | PreparePasskeyDelegationResponse200]:
    """Prepare a passkey-backed delegation approval

     Returns WebAuthn assertion options with a challenge bound to the delegation payload. The client must
    complete the WebAuthn assertion ceremony and submit the result to the approve endpoint.

    Args:
        body (PreparePasskeyDelegationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PreparePasskeyDelegationResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PreparePasskeyDelegationBody,
) -> Any | PreparePasskeyDelegationResponse200 | None:
    """Prepare a passkey-backed delegation approval

     Returns WebAuthn assertion options with a challenge bound to the delegation payload. The client must
    complete the WebAuthn assertion ceremony and submit the result to the approve endpoint.

    Args:
        body (PreparePasskeyDelegationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PreparePasskeyDelegationResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
