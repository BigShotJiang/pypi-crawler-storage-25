from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_child_attestation_response_200 import DeleteChildAttestationResponse200
from ...types import Response


def _get_kwargs(
    child_id: UUID,
    attestation_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/auth/delegations/{child_id}/attestations/{attestation_id}".format(
            child_id=quote(str(child_id), safe=""),
            attestation_id=quote(str(attestation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteChildAttestationResponse200 | None:
    if response.status_code == 200:
        response_200 = DeleteChildAttestationResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteChildAttestationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteChildAttestationResponse200]:
    """Delete a child profile attestation

     Removes an attestation from a child profile owned by the current profile.

    Args:
        child_id (UUID):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteChildAttestationResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        attestation_id=attestation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteChildAttestationResponse200 | None:
    """Delete a child profile attestation

     Removes an attestation from a child profile owned by the current profile.

    Args:
        child_id (UUID):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteChildAttestationResponse200
    """

    return sync_detailed(
        child_id=child_id,
        attestation_id=attestation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteChildAttestationResponse200]:
    """Delete a child profile attestation

     Removes an attestation from a child profile owned by the current profile.

    Args:
        child_id (UUID):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteChildAttestationResponse200]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        attestation_id=attestation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteChildAttestationResponse200 | None:
    """Delete a child profile attestation

     Removes an attestation from a child profile owned by the current profile.

    Args:
        child_id (UUID):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteChildAttestationResponse200
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            attestation_id=attestation_id,
            client=client,
        )
    ).parsed
