from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_setup_init_request import AgentSetupInitRequest
from ...models.agent_setup_init_response import AgentSetupInitResponse
from ...types import Response


def _get_kwargs(
    *,
    body: AgentSetupInitRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/init",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentSetupInitResponse | Any | None:
    if response.status_code == 200:
        response_200 = AgentSetupInitResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentSetupInitResponse | Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSetupInitRequest,
) -> Response[AgentSetupInitResponse | Any]:
    """Initiate agent setup

     Phase 1 of the two-phase agent setup flow. Validates the agent username,
    checks availability under the parent, and returns a short-lived setup token.
    The setup token is passed to the CLI, which completes agent registration by
    submitting it along with a locally-generated public key.

    Args:
        body (AgentSetupInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentSetupInitResponse | Any]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSetupInitRequest,
) -> AgentSetupInitResponse | Any | None:
    """Initiate agent setup

     Phase 1 of the two-phase agent setup flow. Validates the agent username,
    checks availability under the parent, and returns a short-lived setup token.
    The setup token is passed to the CLI, which completes agent registration by
    submitting it along with a locally-generated public key.

    Args:
        body (AgentSetupInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentSetupInitResponse | Any
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSetupInitRequest,
) -> Response[AgentSetupInitResponse | Any]:
    """Initiate agent setup

     Phase 1 of the two-phase agent setup flow. Validates the agent username,
    checks availability under the parent, and returns a short-lived setup token.
    The setup token is passed to the CLI, which completes agent registration by
    submitting it along with a locally-generated public key.

    Args:
        body (AgentSetupInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentSetupInitResponse | Any]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AgentSetupInitRequest,
) -> AgentSetupInitResponse | Any | None:
    """Initiate agent setup

     Phase 1 of the two-phase agent setup flow. Validates the agent username,
    checks availability under the parent, and returns a short-lived setup token.
    The setup token is passed to the CLI, which completes agent registration by
    submitting it along with a locally-generated public key.

    Args:
        body (AgentSetupInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentSetupInitResponse | Any
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
