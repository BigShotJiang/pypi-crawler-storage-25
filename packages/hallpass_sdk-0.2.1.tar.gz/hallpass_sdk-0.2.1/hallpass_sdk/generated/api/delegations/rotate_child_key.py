from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.key_rotation_response import KeyRotationResponse
from ...models.rotate_child_key_body import RotateChildKeyBody
from ...types import UNSET, Response, Unset


def _get_kwargs(
    child_id: UUID,
    *,
    body: RotateChildKeyBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/{child_id}/keys/rotate".format(
            child_id=quote(str(child_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> KeyRotationResponse | None:
    if response.status_code == 200:
        response_200 = KeyRotationResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[KeyRotationResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RotateChildKeyBody | Unset = UNSET,
) -> Response[KeyRotationResponse]:
    """Rotate a child profile's key

     Rotates the delegation key for a child profile. Revokes active delegations involving this child. For
    self-managed children, challenge status resets to pending.

    Args:
        child_id (UUID):
        body (RotateChildKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[KeyRotationResponse]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RotateChildKeyBody | Unset = UNSET,
) -> KeyRotationResponse | None:
    """Rotate a child profile's key

     Rotates the delegation key for a child profile. Revokes active delegations involving this child. For
    self-managed children, challenge status resets to pending.

    Args:
        child_id (UUID):
        body (RotateChildKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        KeyRotationResponse
    """

    return sync_detailed(
        child_id=child_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RotateChildKeyBody | Unset = UNSET,
) -> Response[KeyRotationResponse]:
    """Rotate a child profile's key

     Rotates the delegation key for a child profile. Revokes active delegations involving this child. For
    self-managed children, challenge status resets to pending.

    Args:
        child_id (UUID):
        body (RotateChildKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[KeyRotationResponse]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RotateChildKeyBody | Unset = UNSET,
) -> KeyRotationResponse | None:
    """Rotate a child profile's key

     Rotates the delegation key for a child profile. Revokes active delegations involving this child. For
    self-managed children, challenge status resets to pending.

    Args:
        child_id (UUID):
        body (RotateChildKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        KeyRotationResponse
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            client=client,
            body=body,
        )
    ).parsed
