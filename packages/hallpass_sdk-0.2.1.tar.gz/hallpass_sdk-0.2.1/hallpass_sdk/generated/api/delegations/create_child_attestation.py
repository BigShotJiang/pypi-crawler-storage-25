from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_child_attestation_body import CreateChildAttestationBody
from ...models.create_child_attestation_response_201 import CreateChildAttestationResponse201
from ...types import Response


def _get_kwargs(
    child_id: UUID,
    *,
    body: CreateChildAttestationBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/{child_id}/attestations".format(
            child_id=quote(str(child_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateChildAttestationResponse201 | None:
    if response.status_code == 201:
        response_201 = CreateChildAttestationResponse201.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateChildAttestationResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChildAttestationBody,
) -> Response[CreateChildAttestationResponse201]:
    """Create a child profile attestation

     Adds an identity attestation to a child profile owned by the current profile.

    Args:
        child_id (UUID):
        body (CreateChildAttestationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateChildAttestationResponse201]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChildAttestationBody,
) -> CreateChildAttestationResponse201 | None:
    """Create a child profile attestation

     Adds an identity attestation to a child profile owned by the current profile.

    Args:
        child_id (UUID):
        body (CreateChildAttestationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateChildAttestationResponse201
    """

    return sync_detailed(
        child_id=child_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChildAttestationBody,
) -> Response[CreateChildAttestationResponse201]:
    """Create a child profile attestation

     Adds an identity attestation to a child profile owned by the current profile.

    Args:
        child_id (UUID):
        body (CreateChildAttestationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateChildAttestationResponse201]
    """

    kwargs = _get_kwargs(
        child_id=child_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    child_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CreateChildAttestationBody,
) -> CreateChildAttestationResponse201 | None:
    """Create a child profile attestation

     Adds an identity attestation to a child profile owned by the current profile.

    Args:
        child_id (UUID):
        body (CreateChildAttestationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateChildAttestationResponse201
    """

    return (
        await asyncio_detailed(
            child_id=child_id,
            client=client,
            body=body,
        )
    ).parsed
