from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.verify_attestation_body import VerifyAttestationBody
from ...models.verify_attestation_response_200 import VerifyAttestationResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    attestation_id: UUID,
    *,
    body: VerifyAttestationBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/attestations/{attestation_id}/verify".format(
            attestation_id=quote(str(attestation_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> VerifyAttestationResponse200 | None:
    if response.status_code == 200:
        response_200 = VerifyAttestationResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[VerifyAttestationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAttestationBody | Unset = UNSET,
) -> Response[VerifyAttestationResponse200]:
    """Verify an attestation

     Triggers verification for the specified attestation. For public proof methods (X tweet, GitHub
    gist), include a proof_url in the request body.

    Args:
        attestation_id (UUID):
        body (VerifyAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyAttestationResponse200]
    """

    kwargs = _get_kwargs(
        attestation_id=attestation_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAttestationBody | Unset = UNSET,
) -> VerifyAttestationResponse200 | None:
    """Verify an attestation

     Triggers verification for the specified attestation. For public proof methods (X tweet, GitHub
    gist), include a proof_url in the request body.

    Args:
        attestation_id (UUID):
        body (VerifyAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyAttestationResponse200
    """

    return sync_detailed(
        attestation_id=attestation_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAttestationBody | Unset = UNSET,
) -> Response[VerifyAttestationResponse200]:
    """Verify an attestation

     Triggers verification for the specified attestation. For public proof methods (X tweet, GitHub
    gist), include a proof_url in the request body.

    Args:
        attestation_id (UUID):
        body (VerifyAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyAttestationResponse200]
    """

    kwargs = _get_kwargs(
        attestation_id=attestation_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: VerifyAttestationBody | Unset = UNSET,
) -> VerifyAttestationResponse200 | None:
    """Verify an attestation

     Triggers verification for the specified attestation. For public proof methods (X tweet, GitHub
    gist), include a proof_url in the request body.

    Args:
        attestation_id (UUID):
        body (VerifyAttestationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyAttestationResponse200
    """

    return (
        await asyncio_detailed(
            attestation_id=attestation_id,
            client=client,
            body=body,
        )
    ).parsed
