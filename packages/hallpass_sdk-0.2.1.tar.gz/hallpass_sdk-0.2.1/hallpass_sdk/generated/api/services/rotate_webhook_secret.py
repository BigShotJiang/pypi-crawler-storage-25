from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.rotate_webhook_secret_response_200 import RotateWebhookSecretResponse200
from ...types import Response


def _get_kwargs(
    domain: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/services/{domain}/rotate-webhook-secret".format(
            domain=quote(str(domain), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | RotateWebhookSecretResponse200 | None:
    if response.status_code == 200:
        response_200 = RotateWebhookSecretResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | RotateWebhookSecretResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    domain: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | RotateWebhookSecretResponse200]:
    """Rotate webhook signing secret

     Generates a new HMAC-SHA256 webhook signing secret. The new secret is returned once in the response.
    Previous secret is immediately invalidated.

    Args:
        domain (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | RotateWebhookSecretResponse200]
    """

    kwargs = _get_kwargs(
        domain=domain,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    domain: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | RotateWebhookSecretResponse200 | None:
    """Rotate webhook signing secret

     Generates a new HMAC-SHA256 webhook signing secret. The new secret is returned once in the response.
    Previous secret is immediately invalidated.

    Args:
        domain (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | RotateWebhookSecretResponse200
    """

    return sync_detailed(
        domain=domain,
        client=client,
    ).parsed


async def asyncio_detailed(
    domain: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | RotateWebhookSecretResponse200]:
    """Rotate webhook signing secret

     Generates a new HMAC-SHA256 webhook signing secret. The new secret is returned once in the response.
    Previous secret is immediately invalidated.

    Args:
        domain (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | RotateWebhookSecretResponse200]
    """

    kwargs = _get_kwargs(
        domain=domain,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    domain: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | RotateWebhookSecretResponse200 | None:
    """Rotate webhook signing secret

     Generates a new HMAC-SHA256 webhook signing secret. The new secret is returned once in the response.
    Previous secret is immediately invalidated.

    Args:
        domain (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | RotateWebhookSecretResponse200
    """

    return (
        await asyncio_detailed(
            domain=domain,
            client=client,
        )
    ).parsed
