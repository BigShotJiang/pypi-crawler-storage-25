from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.deny_signup_intent_body import DenySignupIntentBody
from ...models.deny_signup_intent_response_200 import DenySignupIntentResponse200
from ...types import Response


def _get_kwargs(
    id: UUID,
    *,
    body: DenySignupIntentBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/signup-intents/{id}/deny".format(
            id=quote(str(id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DenySignupIntentResponse200 | None:
    if response.status_code == 200:
        response_200 = DenySignupIntentResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | DenySignupIntentResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DenySignupIntentBody,
) -> Response[Any | DenySignupIntentResponse200]:
    """Deny a signup intent

     Denies a pending signup intent. Requires session authentication, user ownership, and a valid
    approval token.

    Args:
        id (UUID):
        body (DenySignupIntentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DenySignupIntentResponse200]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DenySignupIntentBody,
) -> Any | DenySignupIntentResponse200 | None:
    """Deny a signup intent

     Denies a pending signup intent. Requires session authentication, user ownership, and a valid
    approval token.

    Args:
        id (UUID):
        body (DenySignupIntentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DenySignupIntentResponse200
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DenySignupIntentBody,
) -> Response[Any | DenySignupIntentResponse200]:
    """Deny a signup intent

     Denies a pending signup intent. Requires session authentication, user ownership, and a valid
    approval token.

    Args:
        id (UUID):
        body (DenySignupIntentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DenySignupIntentResponse200]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DenySignupIntentBody,
) -> Any | DenySignupIntentResponse200 | None:
    """Deny a signup intent

     Denies a pending signup intent. Requires session authentication, user ownership, and a valid
    approval token.

    Args:
        id (UUID):
        body (DenySignupIntentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DenySignupIntentResponse200
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
