from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_signup_intent_request import CreateSignupIntentRequest
from ...models.create_signup_intent_response_201 import CreateSignupIntentResponse201
from ...types import Response


def _get_kwargs(
    *,
    body: CreateSignupIntentRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/signup-intents",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | CreateSignupIntentResponse201 | None:
    if response.status_code == 201:
        response_201 = CreateSignupIntentResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | CreateSignupIntentResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSignupIntentRequest,
) -> Response[Any | CreateSignupIntentResponse201]:
    """Create a signup intent

     Creates a new agent-mediated signup intent. The authenticated agent requests signup on behalf of a
    user at a service. The user receives an approval email.

    Args:
        body (CreateSignupIntentRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateSignupIntentResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSignupIntentRequest,
) -> Any | CreateSignupIntentResponse201 | None:
    """Create a signup intent

     Creates a new agent-mediated signup intent. The authenticated agent requests signup on behalf of a
    user at a service. The user receives an approval email.

    Args:
        body (CreateSignupIntentRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateSignupIntentResponse201
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSignupIntentRequest,
) -> Response[Any | CreateSignupIntentResponse201]:
    """Create a signup intent

     Creates a new agent-mediated signup intent. The authenticated agent requests signup on behalf of a
    user at a service. The user receives an approval email.

    Args:
        body (CreateSignupIntentRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateSignupIntentResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSignupIntentRequest,
) -> Any | CreateSignupIntentResponse201 | None:
    """Create a signup intent

     Creates a new agent-mediated signup intent. The authenticated agent requests signup on behalf of a
    user at a service. The user receives an approval email.

    Args:
        body (CreateSignupIntentRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateSignupIntentResponse201
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
