from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.key_rotation_response import KeyRotationResponse
from ...models.rotate_key_body import RotateKeyBody
from ...models.step_up_required_error import StepUpRequiredError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: RotateKeyBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/keys/rotate",
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> KeyRotationResponse | StepUpRequiredError | None:
    if response.status_code == 200:
        response_200 = KeyRotationResponse.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = StepUpRequiredError.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[KeyRotationResponse | StepUpRequiredError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RotateKeyBody | Unset = UNSET,
) -> Response[KeyRotationResponse | StepUpRequiredError]:
    """Rotate delegation key

     Generates a new delegation key, retires the current key, and revokes active delegations. For
    service-managed profiles, delegations are automatically re-issued with the new key. Requires step-up
    re-authentication.

    Args:
        body (RotateKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[KeyRotationResponse | StepUpRequiredError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RotateKeyBody | Unset = UNSET,
) -> KeyRotationResponse | StepUpRequiredError | None:
    """Rotate delegation key

     Generates a new delegation key, retires the current key, and revokes active delegations. For
    service-managed profiles, delegations are automatically re-issued with the new key. Requires step-up
    re-authentication.

    Args:
        body (RotateKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        KeyRotationResponse | StepUpRequiredError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RotateKeyBody | Unset = UNSET,
) -> Response[KeyRotationResponse | StepUpRequiredError]:
    """Rotate delegation key

     Generates a new delegation key, retires the current key, and revokes active delegations. For
    service-managed profiles, delegations are automatically re-issued with the new key. Requires step-up
    re-authentication.

    Args:
        body (RotateKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[KeyRotationResponse | StepUpRequiredError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RotateKeyBody | Unset = UNSET,
) -> KeyRotationResponse | StepUpRequiredError | None:
    """Rotate delegation key

     Generates a new delegation key, retires the current key, and revokes active delegations. For
    service-managed profiles, delegations are automatically re-issued with the new key. Requires step-up
    re-authentication.

    Args:
        body (RotateKeyBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        KeyRotationResponse | StepUpRequiredError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
