from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.remove_password_response_200 import RemovePasswordResponse200
from ...models.step_up_credential import StepUpCredential
from ...models.step_up_required_error import StepUpRequiredError
from ...types import Response


def _get_kwargs(
    *,
    body: StepUpCredential,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/auth/password",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RemovePasswordResponse200 | StepUpRequiredError | None:
    if response.status_code == 200:
        response_200 = RemovePasswordResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = StepUpRequiredError.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RemovePasswordResponse200 | StepUpRequiredError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> Response[RemovePasswordResponse200 | StepUpRequiredError]:
    """Remove password

     Removes the password from the authenticated profile. Requires step-up re-authentication and at least
    one other login method (passkey).

    Args:
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RemovePasswordResponse200 | StepUpRequiredError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> RemovePasswordResponse200 | StepUpRequiredError | None:
    """Remove password

     Removes the password from the authenticated profile. Requires step-up re-authentication and at least
    one other login method (passkey).

    Args:
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RemovePasswordResponse200 | StepUpRequiredError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> Response[RemovePasswordResponse200 | StepUpRequiredError]:
    """Remove password

     Removes the password from the authenticated profile. Requires step-up re-authentication and at least
    one other login method (passkey).

    Args:
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RemovePasswordResponse200 | StepUpRequiredError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> RemovePasswordResponse200 | StepUpRequiredError | None:
    """Remove password

     Removes the password from the authenticated profile. Requires step-up re-authentication and at least
    one other login method (passkey).

    Args:
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RemovePasswordResponse200 | StepUpRequiredError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
