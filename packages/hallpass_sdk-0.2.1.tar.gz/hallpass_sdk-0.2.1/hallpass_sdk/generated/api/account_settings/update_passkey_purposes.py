from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.passkey_record import PasskeyRecord
from ...models.update_passkey_purposes_body import UpdatePasskeyPurposesBody
from ...types import Response


def _get_kwargs(
    id: UUID,
    *,
    body: UpdatePasskeyPurposesBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/auth/passkeys/{id}/purposes".format(
            id=quote(str(id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PasskeyRecord | None:
    if response.status_code == 200:
        response_200 = PasskeyRecord.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PasskeyRecord]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdatePasskeyPurposesBody,
) -> Response[PasskeyRecord]:
    """Update passkey purposes

     Changes what a passkey is used for (login, delegation_approval, or both). Requires step-up re-
    authentication.

    Args:
        id (UUID):
        body (UpdatePasskeyPurposesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PasskeyRecord]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdatePasskeyPurposesBody,
) -> PasskeyRecord | None:
    """Update passkey purposes

     Changes what a passkey is used for (login, delegation_approval, or both). Requires step-up re-
    authentication.

    Args:
        id (UUID):
        body (UpdatePasskeyPurposesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PasskeyRecord
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdatePasskeyPurposesBody,
) -> Response[PasskeyRecord]:
    """Update passkey purposes

     Changes what a passkey is used for (login, delegation_approval, or both). Requires step-up re-
    authentication.

    Args:
        id (UUID):
        body (UpdatePasskeyPurposesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PasskeyRecord]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdatePasskeyPurposesBody,
) -> PasskeyRecord | None:
    """Update passkey purposes

     Changes what a passkey is used for (login, delegation_approval, or both). Requires step-up re-
    authentication.

    Args:
        id (UUID):
        body (UpdatePasskeyPurposesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PasskeyRecord
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
