from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.step_up_challenge_response_200 import StepUpChallengeResponse200
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/step-up/challenge",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> StepUpChallengeResponse200 | None:
    if response.status_code == 200:
        response_200 = StepUpChallengeResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[StepUpChallengeResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[StepUpChallengeResponse200]:
    """Request step-up authentication challenge

     Returns a nonce for CLI key step-up and optionally WebAuthn challenge options for passkey step-up.
    The nonce and challenge are stored server-side for verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StepUpChallengeResponse200]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> StepUpChallengeResponse200 | None:
    """Request step-up authentication challenge

     Returns a nonce for CLI key step-up and optionally WebAuthn challenge options for passkey step-up.
    The nonce and challenge are stored server-side for verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StepUpChallengeResponse200
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[StepUpChallengeResponse200]:
    """Request step-up authentication challenge

     Returns a nonce for CLI key step-up and optionally WebAuthn challenge options for passkey step-up.
    The nonce and challenge are stored server-side for verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StepUpChallengeResponse200]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> StepUpChallengeResponse200 | None:
    """Request step-up authentication challenge

     Returns a nonce for CLI key step-up and optionally WebAuthn challenge options for passkey step-up.
    The nonce and challenge are stored server-side for verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StepUpChallengeResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
