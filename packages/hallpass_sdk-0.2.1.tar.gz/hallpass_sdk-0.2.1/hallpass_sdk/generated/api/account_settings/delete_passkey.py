from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_passkey_response_200 import DeletePasskeyResponse200
from ...models.step_up_credential import StepUpCredential
from ...models.step_up_required_error import StepUpRequiredError
from ...types import Response


def _get_kwargs(
    id: UUID,
    *,
    body: StepUpCredential,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/auth/passkeys/{id}".format(
            id=quote(str(id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeletePasskeyResponse200 | StepUpRequiredError | None:
    if response.status_code == 200:
        response_200 = DeletePasskeyResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = StepUpRequiredError.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeletePasskeyResponse200 | StepUpRequiredError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> Response[DeletePasskeyResponse200 | StepUpRequiredError]:
    """Delete a passkey

     Removes a registered passkey from the authenticated profile. Requires step-up re-authentication.

    Args:
        id (UUID):
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeletePasskeyResponse200 | StepUpRequiredError]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> DeletePasskeyResponse200 | StepUpRequiredError | None:
    """Delete a passkey

     Removes a registered passkey from the authenticated profile. Requires step-up re-authentication.

    Args:
        id (UUID):
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeletePasskeyResponse200 | StepUpRequiredError
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> Response[DeletePasskeyResponse200 | StepUpRequiredError]:
    """Delete a passkey

     Removes a registered passkey from the authenticated profile. Requires step-up re-authentication.

    Args:
        id (UUID):
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeletePasskeyResponse200 | StepUpRequiredError]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: StepUpCredential,
) -> DeletePasskeyResponse200 | StepUpRequiredError | None:
    """Delete a passkey

     Removes a registered passkey from the authenticated profile. Requires step-up re-authentication.

    Args:
        id (UUID):
        body (StepUpCredential): Step-up re-authentication credential. Send one of
            confirm_password, webauthn_assertion, or key_assertion.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeletePasskeyResponse200 | StepUpRequiredError
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
