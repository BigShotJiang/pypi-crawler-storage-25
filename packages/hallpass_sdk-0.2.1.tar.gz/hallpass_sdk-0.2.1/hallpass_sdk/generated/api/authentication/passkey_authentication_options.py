from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.passkey_authentication_options_body import PasskeyAuthenticationOptionsBody
from ...models.passkey_authentication_options_response_200 import PasskeyAuthenticationOptionsResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: PasskeyAuthenticationOptionsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/passkeys/authentication-options",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | PasskeyAuthenticationOptionsResponse200 | None:
    if response.status_code == 200:
        response_200 = PasskeyAuthenticationOptionsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | PasskeyAuthenticationOptionsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PasskeyAuthenticationOptionsBody,
) -> Response[Any | PasskeyAuthenticationOptionsResponse200]:
    """Get passkey authentication options

     Returns WebAuthn authentication options for a username with registered passkeys.

    Args:
        body (PasskeyAuthenticationOptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PasskeyAuthenticationOptionsResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PasskeyAuthenticationOptionsBody,
) -> Any | PasskeyAuthenticationOptionsResponse200 | None:
    """Get passkey authentication options

     Returns WebAuthn authentication options for a username with registered passkeys.

    Args:
        body (PasskeyAuthenticationOptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PasskeyAuthenticationOptionsResponse200
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PasskeyAuthenticationOptionsBody,
) -> Response[Any | PasskeyAuthenticationOptionsResponse200]:
    """Get passkey authentication options

     Returns WebAuthn authentication options for a username with registered passkeys.

    Args:
        body (PasskeyAuthenticationOptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PasskeyAuthenticationOptionsResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PasskeyAuthenticationOptionsBody,
) -> Any | PasskeyAuthenticationOptionsResponse200 | None:
    """Get passkey authentication options

     Returns WebAuthn authentication options for a username with registered passkeys.

    Args:
        body (PasskeyAuthenticationOptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PasskeyAuthenticationOptionsResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
