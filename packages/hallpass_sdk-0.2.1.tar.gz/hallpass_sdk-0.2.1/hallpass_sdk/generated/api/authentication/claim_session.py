from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.auth_profile_response import AuthProfileResponse
from ...models.claim_session_body import ClaimSessionBody
from ...types import Response


def _get_kwargs(
    *,
    body: ClaimSessionBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/session/claim",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | AuthProfileResponse | None:
    if response.status_code == 200:
        response_200 = AuthProfileResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | AuthProfileResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ClaimSessionBody,
) -> Response[Any | AuthProfileResponse]:
    """Claim a browser session after CLI registration

     Exchanges a short-lived claim token (received via the registration
    WebSocket channel) for a session cookie. The claim token is created
    by the server during register/complete and expires after 30 seconds.

    Args:
        body (ClaimSessionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthProfileResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ClaimSessionBody,
) -> Any | AuthProfileResponse | None:
    """Claim a browser session after CLI registration

     Exchanges a short-lived claim token (received via the registration
    WebSocket channel) for a session cookie. The claim token is created
    by the server during register/complete and expires after 30 seconds.

    Args:
        body (ClaimSessionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthProfileResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ClaimSessionBody,
) -> Response[Any | AuthProfileResponse]:
    """Claim a browser session after CLI registration

     Exchanges a short-lived claim token (received via the registration
    WebSocket channel) for a session cookie. The claim token is created
    by the server during register/complete and expires after 30 seconds.

    Args:
        body (ClaimSessionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthProfileResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ClaimSessionBody,
) -> Any | AuthProfileResponse | None:
    """Claim a browser session after CLI registration

     Exchanges a short-lived claim token (received via the registration
    WebSocket channel) for a session cookie. The claim token is created
    by the server during register/complete and expires after 30 seconds.

    Args:
        body (ClaimSessionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthProfileResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
