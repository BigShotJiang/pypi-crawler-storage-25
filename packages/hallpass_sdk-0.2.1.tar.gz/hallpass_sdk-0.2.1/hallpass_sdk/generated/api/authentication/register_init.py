from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.register_init_request import RegisterInitRequest
from ...models.register_init_response import RegisterInitResponse
from ...types import Response


def _get_kwargs(
    *,
    body: RegisterInitRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/register/init",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | RegisterInitResponse | None:
    if response.status_code == 200:
        response_200 = RegisterInitResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | RegisterInitResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterInitRequest,
) -> Response[Any | RegisterInitResponse]:
    """Initiate self-managed registration

     Phase 1 of the two-phase self-managed registration flow. Validates the username and optionally
    hashes a password, then returns a short-lived registration token and socket token. The registration
    token is passed to the CLI, which completes registration by submitting it along with a locally-
    generated public key. Password is optional; if omitted, the self-managed key becomes the sole
    authentication factor.

    Args:
        body (RegisterInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | RegisterInitResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterInitRequest,
) -> Any | RegisterInitResponse | None:
    """Initiate self-managed registration

     Phase 1 of the two-phase self-managed registration flow. Validates the username and optionally
    hashes a password, then returns a short-lived registration token and socket token. The registration
    token is passed to the CLI, which completes registration by submitting it along with a locally-
    generated public key. Password is optional; if omitted, the self-managed key becomes the sole
    authentication factor.

    Args:
        body (RegisterInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | RegisterInitResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterInitRequest,
) -> Response[Any | RegisterInitResponse]:
    """Initiate self-managed registration

     Phase 1 of the two-phase self-managed registration flow. Validates the username and optionally
    hashes a password, then returns a short-lived registration token and socket token. The registration
    token is passed to the CLI, which completes registration by submitting it along with a locally-
    generated public key. Password is optional; if omitted, the self-managed key becomes the sole
    authentication factor.

    Args:
        body (RegisterInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | RegisterInitResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterInitRequest,
) -> Any | RegisterInitResponse | None:
    """Initiate self-managed registration

     Phase 1 of the two-phase self-managed registration flow. Validates the username and optionally
    hashes a password, then returns a short-lived registration token and socket token. The registration
    token is passed to the CLI, which completes registration by submitting it along with a locally-
    generated public key. Password is optional; if omitted, the self-managed key becomes the sole
    authentication factor.

    Args:
        body (RegisterInitRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | RegisterInitResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
