from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.auth_profile_response import AuthProfileResponse
from ...models.register_with_passkey_verify_body import RegisterWithPasskeyVerifyBody
from ...types import Response


def _get_kwargs(
    *,
    body: RegisterWithPasskeyVerifyBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/register-with-passkey/verify",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | AuthProfileResponse | None:
    if response.status_code == 201:
        response_201 = AuthProfileResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | AuthProfileResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyVerifyBody,
) -> Response[Any | AuthProfileResponse]:
    """Complete passkey registration

     Verifies the WebAuthn attestation response, creates the profile with
    service-managed keys and no password, stores the passkey credential,
    and creates a session.

    Args:
        body (RegisterWithPasskeyVerifyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthProfileResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyVerifyBody,
) -> Any | AuthProfileResponse | None:
    """Complete passkey registration

     Verifies the WebAuthn attestation response, creates the profile with
    service-managed keys and no password, stores the passkey credential,
    and creates a session.

    Args:
        body (RegisterWithPasskeyVerifyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthProfileResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyVerifyBody,
) -> Response[Any | AuthProfileResponse]:
    """Complete passkey registration

     Verifies the WebAuthn attestation response, creates the profile with
    service-managed keys and no password, stores the passkey credential,
    and creates a session.

    Args:
        body (RegisterWithPasskeyVerifyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AuthProfileResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyVerifyBody,
) -> Any | AuthProfileResponse | None:
    """Complete passkey registration

     Verifies the WebAuthn attestation response, creates the profile with
    service-managed keys and no password, stores the passkey credential,
    and creates a session.

    Args:
        body (RegisterWithPasskeyVerifyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AuthProfileResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
