from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.passkey_registration_init_response import PasskeyRegistrationInitResponse
from ...models.register_with_passkey_body import RegisterWithPasskeyBody
from ...types import Response


def _get_kwargs(
    *,
    body: RegisterWithPasskeyBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/register-with-passkey",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | PasskeyRegistrationInitResponse | None:
    if response.status_code == 200:
        response_200 = PasskeyRegistrationInitResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = cast(Any, None)
        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | PasskeyRegistrationInitResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyBody,
) -> Response[Any | PasskeyRegistrationInitResponse]:
    """Initiate passkey registration

     Validates the username, generates service-managed key material, creates a WebAuthn
    registration challenge, and returns the options along with a short-lived passkey
    session token. The browser completes the WebAuthn ceremony and submits the result
    to the verify endpoint.

    Args:
        body (RegisterWithPasskeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PasskeyRegistrationInitResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyBody,
) -> Any | PasskeyRegistrationInitResponse | None:
    """Initiate passkey registration

     Validates the username, generates service-managed key material, creates a WebAuthn
    registration challenge, and returns the options along with a short-lived passkey
    session token. The browser completes the WebAuthn ceremony and submits the result
    to the verify endpoint.

    Args:
        body (RegisterWithPasskeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PasskeyRegistrationInitResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyBody,
) -> Response[Any | PasskeyRegistrationInitResponse]:
    """Initiate passkey registration

     Validates the username, generates service-managed key material, creates a WebAuthn
    registration challenge, and returns the options along with a short-lived passkey
    session token. The browser completes the WebAuthn ceremony and submits the result
    to the verify endpoint.

    Args:
        body (RegisterWithPasskeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PasskeyRegistrationInitResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterWithPasskeyBody,
) -> Any | PasskeyRegistrationInitResponse | None:
    """Initiate passkey registration

     Validates the username, generates service-managed key material, creates a WebAuthn
    registration challenge, and returns the options along with a short-lived passkey
    session token. The browser completes the WebAuthn ceremony and submits the result
    to the verify endpoint.

    Args:
        body (RegisterWithPasskeyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PasskeyRegistrationInitResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
