from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.oauth_authorize_response_400 import OauthAuthorizeResponse400
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    client_id: str,
    redirect_uri: str,
    state: str | Unset = UNSET,
    code_challenge: str | Unset = UNSET,
    code_challenge_method: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["client_id"] = client_id

    params["redirect_uri"] = redirect_uri

    params["state"] = state

    params["code_challenge"] = code_challenge

    params["code_challenge_method"] = code_challenge_method

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/oauth/authorize",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | OauthAuthorizeResponse400 | None:
    if response.status_code == 302:
        response_302 = cast(Any, None)
        return response_302

    if response.status_code == 400:
        response_400 = OauthAuthorizeResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | OauthAuthorizeResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    client_id: str,
    redirect_uri: str,
    state: str | Unset = UNSET,
    code_challenge: str | Unset = UNSET,
    code_challenge_method: str | Unset = UNSET,
) -> Response[Any | OauthAuthorizeResponse400]:
    """Initiate OAuth authorization

     Begins the OAuth 2.0 authorization code grant flow. Redirects the user to the consent screen or
    directly to the redirect URI.

    Args:
        client_id (str):
        redirect_uri (str):
        state (str | Unset):
        code_challenge (str | Unset):
        code_challenge_method (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | OauthAuthorizeResponse400]
    """

    kwargs = _get_kwargs(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
        code_challenge=code_challenge,
        code_challenge_method=code_challenge_method,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    client_id: str,
    redirect_uri: str,
    state: str | Unset = UNSET,
    code_challenge: str | Unset = UNSET,
    code_challenge_method: str | Unset = UNSET,
) -> Any | OauthAuthorizeResponse400 | None:
    """Initiate OAuth authorization

     Begins the OAuth 2.0 authorization code grant flow. Redirects the user to the consent screen or
    directly to the redirect URI.

    Args:
        client_id (str):
        redirect_uri (str):
        state (str | Unset):
        code_challenge (str | Unset):
        code_challenge_method (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | OauthAuthorizeResponse400
    """

    return sync_detailed(
        client=client,
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
        code_challenge=code_challenge,
        code_challenge_method=code_challenge_method,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    client_id: str,
    redirect_uri: str,
    state: str | Unset = UNSET,
    code_challenge: str | Unset = UNSET,
    code_challenge_method: str | Unset = UNSET,
) -> Response[Any | OauthAuthorizeResponse400]:
    """Initiate OAuth authorization

     Begins the OAuth 2.0 authorization code grant flow. Redirects the user to the consent screen or
    directly to the redirect URI.

    Args:
        client_id (str):
        redirect_uri (str):
        state (str | Unset):
        code_challenge (str | Unset):
        code_challenge_method (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | OauthAuthorizeResponse400]
    """

    kwargs = _get_kwargs(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
        code_challenge=code_challenge,
        code_challenge_method=code_challenge_method,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    client_id: str,
    redirect_uri: str,
    state: str | Unset = UNSET,
    code_challenge: str | Unset = UNSET,
    code_challenge_method: str | Unset = UNSET,
) -> Any | OauthAuthorizeResponse400 | None:
    """Initiate OAuth authorization

     Begins the OAuth 2.0 authorization code grant flow. Redirects the user to the consent screen or
    directly to the redirect URI.

    Args:
        client_id (str):
        redirect_uri (str):
        state (str | Unset):
        code_challenge (str | Unset):
        code_challenge_method (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | OauthAuthorizeResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            client_id=client_id,
            redirect_uri=redirect_uri,
            state=state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
        )
    ).parsed
