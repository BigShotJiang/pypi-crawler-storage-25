from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delegation_freshness import DelegationFreshness
from ...types import Response


def _get_kwargs(
    username: str,
    jti: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/profiles/{username}/delegations/{jti}/status".format(
            username=quote(str(username), safe=""),
            jti=quote(str(jti), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DelegationFreshness | None:
    if response.status_code == 200:
        response_200 = DelegationFreshness.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | DelegationFreshness]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    username: str,
    jti: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | DelegationFreshness]:
    """Check delegation freshness

     Returns the current status of a delegation identified by its JTI. No authentication required.

    Args:
        username (str):
        jti (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DelegationFreshness]
    """

    kwargs = _get_kwargs(
        username=username,
        jti=jti,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    username: str,
    jti: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Any | DelegationFreshness | None:
    """Check delegation freshness

     Returns the current status of a delegation identified by its JTI. No authentication required.

    Args:
        username (str):
        jti (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DelegationFreshness
    """

    return sync_detailed(
        username=username,
        jti=jti,
        client=client,
    ).parsed


async def asyncio_detailed(
    username: str,
    jti: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | DelegationFreshness]:
    """Check delegation freshness

     Returns the current status of a delegation identified by its JTI. No authentication required.

    Args:
        username (str):
        jti (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DelegationFreshness]
    """

    kwargs = _get_kwargs(
        username=username,
        jti=jti,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    username: str,
    jti: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Any | DelegationFreshness | None:
    """Check delegation freshness

     Returns the current status of a delegation identified by its JTI. No authentication required.

    Args:
        username (str):
        jti (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DelegationFreshness
    """

    return (
        await asyncio_detailed(
            username=username,
            jti=jti,
            client=client,
        )
    ).parsed
