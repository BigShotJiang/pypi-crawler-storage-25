from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.start_recovery_body import StartRecoveryBody
from ...models.start_recovery_response_200 import StartRecoveryResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: StartRecoveryBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/recovery/start",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> StartRecoveryResponse200 | None:
    if response.status_code == 200:
        response_200 = StartRecoveryResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[StartRecoveryResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: StartRecoveryBody,
) -> Response[StartRecoveryResponse200]:
    """Start recovery

     Initiates a recovery flow for the given username and method. Returns method-specific data (e.g. a
    nonce for key_signing, a request_id for device_approval).

    Args:
        body (StartRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StartRecoveryResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: StartRecoveryBody,
) -> StartRecoveryResponse200 | None:
    """Start recovery

     Initiates a recovery flow for the given username and method. Returns method-specific data (e.g. a
    nonce for key_signing, a request_id for device_approval).

    Args:
        body (StartRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StartRecoveryResponse200
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: StartRecoveryBody,
) -> Response[StartRecoveryResponse200]:
    """Start recovery

     Initiates a recovery flow for the given username and method. Returns method-specific data (e.g. a
    nonce for key_signing, a request_id for device_approval).

    Args:
        body (StartRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StartRecoveryResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: StartRecoveryBody,
) -> StartRecoveryResponse200 | None:
    """Start recovery

     Initiates a recovery flow for the given username and method. Returns method-specific data (e.g. a
    nonce for key_signing, a request_id for device_approval).

    Args:
        body (StartRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StartRecoveryResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
