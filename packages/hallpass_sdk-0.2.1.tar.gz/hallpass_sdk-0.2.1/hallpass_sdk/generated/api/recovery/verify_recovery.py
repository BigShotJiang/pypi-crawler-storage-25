from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.verify_recovery_body import VerifyRecoveryBody
from ...models.verify_recovery_response_200 import VerifyRecoveryResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: VerifyRecoveryBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/recovery/verify",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> VerifyRecoveryResponse200 | None:
    if response.status_code == 200:
        response_200 = VerifyRecoveryResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[VerifyRecoveryResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyRecoveryBody,
) -> Response[VerifyRecoveryResponse200]:
    """Verify recovery proof

     Submits proof for the recovery method. Returns a verified request_id on success, which is used to
    complete recovery.

    Args:
        body (VerifyRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyRecoveryResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyRecoveryBody,
) -> VerifyRecoveryResponse200 | None:
    """Verify recovery proof

     Submits proof for the recovery method. Returns a verified request_id on success, which is used to
    complete recovery.

    Args:
        body (VerifyRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyRecoveryResponse200
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyRecoveryBody,
) -> Response[VerifyRecoveryResponse200]:
    """Verify recovery proof

     Submits proof for the recovery method. Returns a verified request_id on success, which is used to
    complete recovery.

    Args:
        body (VerifyRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[VerifyRecoveryResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyRecoveryBody,
) -> VerifyRecoveryResponse200 | None:
    """Verify recovery proof

     Submits proof for the recovery method. Returns a verified request_id on success, which is used to
    complete recovery.

    Args:
        body (VerifyRecoveryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        VerifyRecoveryResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
