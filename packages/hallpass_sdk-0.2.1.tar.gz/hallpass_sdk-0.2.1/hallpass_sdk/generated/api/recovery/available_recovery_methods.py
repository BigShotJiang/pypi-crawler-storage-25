from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.available_recovery_methods_body import AvailableRecoveryMethodsBody
from ...models.available_recovery_methods_response_200 import AvailableRecoveryMethodsResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: AvailableRecoveryMethodsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/recovery/methods",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AvailableRecoveryMethodsResponse200 | None:
    if response.status_code == 200:
        response_200 = AvailableRecoveryMethodsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AvailableRecoveryMethodsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AvailableRecoveryMethodsBody,
) -> Response[AvailableRecoveryMethodsResponse200]:
    """Available recovery methods

     Returns the recovery methods available for a given username (email, recovery_code, key_signing,
    device_approval).

    Args:
        body (AvailableRecoveryMethodsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AvailableRecoveryMethodsResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AvailableRecoveryMethodsBody,
) -> AvailableRecoveryMethodsResponse200 | None:
    """Available recovery methods

     Returns the recovery methods available for a given username (email, recovery_code, key_signing,
    device_approval).

    Args:
        body (AvailableRecoveryMethodsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AvailableRecoveryMethodsResponse200
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AvailableRecoveryMethodsBody,
) -> Response[AvailableRecoveryMethodsResponse200]:
    """Available recovery methods

     Returns the recovery methods available for a given username (email, recovery_code, key_signing,
    device_approval).

    Args:
        body (AvailableRecoveryMethodsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AvailableRecoveryMethodsResponse200]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AvailableRecoveryMethodsBody,
) -> AvailableRecoveryMethodsResponse200 | None:
    """Available recovery methods

     Returns the recovery methods available for a given username (email, recovery_code, key_signing,
    device_approval).

    Args:
        body (AvailableRecoveryMethodsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AvailableRecoveryMethodsResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
