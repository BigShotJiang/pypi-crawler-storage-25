from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_audit_events_response_200 import ListAuditEventsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    event_type: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params["event_type"] = event_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/audit/events",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListAuditEventsResponse200 | None:
    if response.status_code == 200:
        response_200 = ListAuditEventsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListAuditEventsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    event_type: str | Unset = UNSET,
) -> Response[ListAuditEventsResponse200]:
    """List audit events

     Returns paginated audit events for the current profile. Requires an active session.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        event_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListAuditEventsResponse200]
    """

    kwargs = _get_kwargs(
        limit=limit,
        offset=offset,
        event_type=event_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    event_type: str | Unset = UNSET,
) -> ListAuditEventsResponse200 | None:
    """List audit events

     Returns paginated audit events for the current profile. Requires an active session.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        event_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListAuditEventsResponse200
    """

    return sync_detailed(
        client=client,
        limit=limit,
        offset=offset,
        event_type=event_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    event_type: str | Unset = UNSET,
) -> Response[ListAuditEventsResponse200]:
    """List audit events

     Returns paginated audit events for the current profile. Requires an active session.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        event_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListAuditEventsResponse200]
    """

    kwargs = _get_kwargs(
        limit=limit,
        offset=offset,
        event_type=event_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    event_type: str | Unset = UNSET,
) -> ListAuditEventsResponse200 | None:
    """List audit events

     Returns paginated audit events for the current profile. Requires an active session.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        event_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListAuditEventsResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            offset=offset,
            event_type=event_type,
        )
    ).parsed
