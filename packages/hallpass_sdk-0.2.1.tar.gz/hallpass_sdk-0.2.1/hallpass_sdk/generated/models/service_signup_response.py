from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.service_signup_response_revocation_callback import ServiceSignupResponseRevocationCallback


T = TypeVar("T", bound="ServiceSignupResponse")


@_attrs_define
class ServiceSignupResponse:
    """
    Attributes:
        id (UUID):
        event_type (str):
        inserted_at (datetime.datetime):
        revocation_callback (ServiceSignupResponseRevocationCallback | Unset):
    """

    id: UUID
    event_type: str
    inserted_at: datetime.datetime
    revocation_callback: ServiceSignupResponseRevocationCallback | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        event_type = self.event_type

        inserted_at = self.inserted_at.isoformat()

        revocation_callback: dict[str, Any] | Unset = UNSET
        if not isinstance(self.revocation_callback, Unset):
            revocation_callback = self.revocation_callback.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "event_type": event_type,
                "inserted_at": inserted_at,
            }
        )
        if revocation_callback is not UNSET:
            field_dict["revocation_callback"] = revocation_callback

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.service_signup_response_revocation_callback import ServiceSignupResponseRevocationCallback

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        event_type = d.pop("event_type")

        inserted_at = isoparse(d.pop("inserted_at"))

        _revocation_callback = d.pop("revocation_callback", UNSET)
        revocation_callback: ServiceSignupResponseRevocationCallback | Unset
        if isinstance(_revocation_callback, Unset):
            revocation_callback = UNSET
        else:
            revocation_callback = ServiceSignupResponseRevocationCallback.from_dict(_revocation_callback)

        service_signup_response = cls(
            id=id,
            event_type=event_type,
            inserted_at=inserted_at,
            revocation_callback=revocation_callback,
        )

        service_signup_response.additional_properties = d
        return service_signup_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
