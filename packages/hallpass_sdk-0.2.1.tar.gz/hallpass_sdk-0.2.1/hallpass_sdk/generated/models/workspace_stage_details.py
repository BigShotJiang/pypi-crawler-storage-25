from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="WorkspaceStageDetails")


@_attrs_define
class WorkspaceStageDetails:
    """
    Attributes:
        title (str):
        body (str):
        why_it_matters (str):
        current_state (str):
    """

    title: str
    body: str
    why_it_matters: str
    current_state: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        title = self.title

        body = self.body

        why_it_matters = self.why_it_matters

        current_state = self.current_state

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "title": title,
                "body": body,
                "why_it_matters": why_it_matters,
                "current_state": current_state,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        title = d.pop("title")

        body = d.pop("body")

        why_it_matters = d.pop("why_it_matters")

        current_state = d.pop("current_state")

        workspace_stage_details = cls(
            title=title,
            body=body,
            why_it_matters=why_it_matters,
            current_state=current_state,
        )

        workspace_stage_details.additional_properties = d
        return workspace_stage_details

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
