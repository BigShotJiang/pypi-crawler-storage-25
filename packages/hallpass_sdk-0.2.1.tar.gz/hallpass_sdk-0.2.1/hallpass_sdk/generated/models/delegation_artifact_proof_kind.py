from enum import Enum


class DelegationArtifactProofKind(str, Enum):
    JWS = "jws"
    WEBAUTHN_ASSERTION = "webauthn_assertion"

    def __str__(self) -> str:
        return str(self.value)
