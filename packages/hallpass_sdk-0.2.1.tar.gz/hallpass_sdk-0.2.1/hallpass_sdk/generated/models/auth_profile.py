from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.auth_profile_key_mode import AuthProfileKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.auth_profile_public_jwk import AuthProfilePublicJwk


T = TypeVar("T", bound="AuthProfile")


@_attrs_define
class AuthProfile:
    """
    Attributes:
        id (UUID):
        username (str):
        key_mode (AuthProfileKeyMode):
        signing_setup_complete (bool): Whether the profile has completed delegation signing setup.
        public_jwk (AuthProfilePublicJwk):
        email_verified (bool):
        display_name (None | str | Unset):
        description (None | str | Unset):
        avatar_url (None | str | Unset):
        parent_profile_id (None | Unset | UUID):
        email (None | str | Unset):
    """

    id: UUID
    username: str
    key_mode: AuthProfileKeyMode
    signing_setup_complete: bool
    public_jwk: AuthProfilePublicJwk
    email_verified: bool
    display_name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    avatar_url: None | str | Unset = UNSET
    parent_profile_id: None | Unset | UUID = UNSET
    email: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        username = self.username

        key_mode = self.key_mode.value

        signing_setup_complete = self.signing_setup_complete

        public_jwk = self.public_jwk.to_dict()

        email_verified = self.email_verified

        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        avatar_url: None | str | Unset
        if isinstance(self.avatar_url, Unset):
            avatar_url = UNSET
        else:
            avatar_url = self.avatar_url

        parent_profile_id: None | str | Unset
        if isinstance(self.parent_profile_id, Unset):
            parent_profile_id = UNSET
        elif isinstance(self.parent_profile_id, UUID):
            parent_profile_id = str(self.parent_profile_id)
        else:
            parent_profile_id = self.parent_profile_id

        email: None | str | Unset
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "username": username,
                "key_mode": key_mode,
                "signing_setup_complete": signing_setup_complete,
                "public_jwk": public_jwk,
                "email_verified": email_verified,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if avatar_url is not UNSET:
            field_dict["avatar_url"] = avatar_url
        if parent_profile_id is not UNSET:
            field_dict["parent_profile_id"] = parent_profile_id
        if email is not UNSET:
            field_dict["email"] = email

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_profile_public_jwk import AuthProfilePublicJwk

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        username = d.pop("username")

        key_mode = AuthProfileKeyMode(d.pop("key_mode"))

        signing_setup_complete = d.pop("signing_setup_complete")

        public_jwk = AuthProfilePublicJwk.from_dict(d.pop("public_jwk"))

        email_verified = d.pop("email_verified")

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("display_name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_avatar_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        avatar_url = _parse_avatar_url(d.pop("avatar_url", UNSET))

        def _parse_parent_profile_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                parent_profile_id_type_0 = UUID(data)

                return parent_profile_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        parent_profile_id = _parse_parent_profile_id(d.pop("parent_profile_id", UNSET))

        def _parse_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        email = _parse_email(d.pop("email", UNSET))

        auth_profile = cls(
            id=id,
            username=username,
            key_mode=key_mode,
            signing_setup_complete=signing_setup_complete,
            public_jwk=public_jwk,
            email_verified=email_verified,
            display_name=display_name,
            description=description,
            avatar_url=avatar_url,
            parent_profile_id=parent_profile_id,
            email=email,
        )

        auth_profile.additional_properties = d
        return auth_profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
