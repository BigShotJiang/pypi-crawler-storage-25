from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.auth_profile import AuthProfile


T = TypeVar("T", bound="CurrentProfileResponse200")


@_attrs_define
class CurrentProfileResponse200:
    """
    Attributes:
        profile (AuthProfile):
        socket_token (str):
    """

    profile: AuthProfile
    socket_token: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        profile = self.profile.to_dict()

        socket_token = self.socket_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "profile": profile,
                "socket_token": socket_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_profile import AuthProfile

        d = dict(src_dict)
        profile = AuthProfile.from_dict(d.pop("profile"))

        socket_token = d.pop("socket_token")

        current_profile_response_200 = cls(
            profile=profile,
            socket_token=socket_token,
        )

        current_profile_response_200.additional_properties = d
        return current_profile_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
