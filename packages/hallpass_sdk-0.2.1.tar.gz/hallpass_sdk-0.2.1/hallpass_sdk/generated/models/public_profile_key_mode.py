from enum import Enum


class PublicProfileKeyMode(str, Enum):
    EXTERNAL = "external"
    PASSKEY = "passkey"

    def __str__(self) -> str:
        return str(self.value)
