from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.verification_change_row_type import VerificationChangeRowType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.verification_change_technical_anchors import VerificationChangeTechnicalAnchors


T = TypeVar("T", bound="VerificationChangeRow")


@_attrs_define
class VerificationChangeRow:
    """
    Attributes:
        type_ (VerificationChangeRowType):
        occurred_at (datetime.datetime | None | Unset):
        actor_username (None | str | Unset):
        subject_username (None | str | Unset):
        from_ (None | str | Unset):
        to (None | str | Unset):
        technical_anchors (VerificationChangeTechnicalAnchors | Unset):
    """

    type_: VerificationChangeRowType
    occurred_at: datetime.datetime | None | Unset = UNSET
    actor_username: None | str | Unset = UNSET
    subject_username: None | str | Unset = UNSET
    from_: None | str | Unset = UNSET
    to: None | str | Unset = UNSET
    technical_anchors: VerificationChangeTechnicalAnchors | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_.value

        occurred_at: None | str | Unset
        if isinstance(self.occurred_at, Unset):
            occurred_at = UNSET
        elif isinstance(self.occurred_at, datetime.datetime):
            occurred_at = self.occurred_at.isoformat()
        else:
            occurred_at = self.occurred_at

        actor_username: None | str | Unset
        if isinstance(self.actor_username, Unset):
            actor_username = UNSET
        else:
            actor_username = self.actor_username

        subject_username: None | str | Unset
        if isinstance(self.subject_username, Unset):
            subject_username = UNSET
        else:
            subject_username = self.subject_username

        from_: None | str | Unset
        if isinstance(self.from_, Unset):
            from_ = UNSET
        else:
            from_ = self.from_

        to: None | str | Unset
        if isinstance(self.to, Unset):
            to = UNSET
        else:
            to = self.to

        technical_anchors: dict[str, Any] | Unset = UNSET
        if not isinstance(self.technical_anchors, Unset):
            technical_anchors = self.technical_anchors.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
            }
        )
        if occurred_at is not UNSET:
            field_dict["occurred_at"] = occurred_at
        if actor_username is not UNSET:
            field_dict["actor_username"] = actor_username
        if subject_username is not UNSET:
            field_dict["subject_username"] = subject_username
        if from_ is not UNSET:
            field_dict["from"] = from_
        if to is not UNSET:
            field_dict["to"] = to
        if technical_anchors is not UNSET:
            field_dict["technical_anchors"] = technical_anchors

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.verification_change_technical_anchors import VerificationChangeTechnicalAnchors

        d = dict(src_dict)
        type_ = VerificationChangeRowType(d.pop("type"))

        def _parse_occurred_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                occurred_at_type_0 = isoparse(data)

                return occurred_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        occurred_at = _parse_occurred_at(d.pop("occurred_at", UNSET))

        def _parse_actor_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        actor_username = _parse_actor_username(d.pop("actor_username", UNSET))

        def _parse_subject_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        subject_username = _parse_subject_username(d.pop("subject_username", UNSET))

        def _parse_from_(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        from_ = _parse_from_(d.pop("from", UNSET))

        def _parse_to(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        to = _parse_to(d.pop("to", UNSET))

        _technical_anchors = d.pop("technical_anchors", UNSET)
        technical_anchors: VerificationChangeTechnicalAnchors | Unset
        if isinstance(_technical_anchors, Unset):
            technical_anchors = UNSET
        else:
            technical_anchors = VerificationChangeTechnicalAnchors.from_dict(_technical_anchors)

        verification_change_row = cls(
            type_=type_,
            occurred_at=occurred_at,
            actor_username=actor_username,
            subject_username=subject_username,
            from_=from_,
            to=to,
            technical_anchors=technical_anchors,
        )

        verification_change_row.additional_properties = d
        return verification_change_row

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
