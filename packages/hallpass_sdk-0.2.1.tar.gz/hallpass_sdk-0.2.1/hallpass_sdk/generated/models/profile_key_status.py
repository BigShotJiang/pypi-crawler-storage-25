from enum import Enum


class ProfileKeyStatus(str, Enum):
    ACTIVE = "active"
    RETIRED = "retired"
    REVOKED = "revoked"

    def __str__(self) -> str:
        return str(self.value)
