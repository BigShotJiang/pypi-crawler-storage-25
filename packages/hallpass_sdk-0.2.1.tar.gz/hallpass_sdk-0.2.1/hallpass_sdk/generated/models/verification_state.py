from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.verification_state_proof_urls_item import VerificationStateProofUrlsItem


T = TypeVar("T", bound="VerificationState")


@_attrs_define
class VerificationState:
    """
    Attributes:
        state (str | Unset):
        summary (str | Unset):
        username (str | Unset):
        display_name (str | Unset):
        child_profile_id (str | Unset):
        child_did (str | Unset):
        verification_method (str | Unset):
        proof_urls (list[VerificationStateProofUrlsItem] | Unset):
        principal_method_status (str | Unset):
    """

    state: str | Unset = UNSET
    summary: str | Unset = UNSET
    username: str | Unset = UNSET
    display_name: str | Unset = UNSET
    child_profile_id: str | Unset = UNSET
    child_did: str | Unset = UNSET
    verification_method: str | Unset = UNSET
    proof_urls: list[VerificationStateProofUrlsItem] | Unset = UNSET
    principal_method_status: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        state = self.state

        summary = self.summary

        username = self.username

        display_name = self.display_name

        child_profile_id = self.child_profile_id

        child_did = self.child_did

        verification_method = self.verification_method

        proof_urls: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.proof_urls, Unset):
            proof_urls = []
            for proof_urls_item_data in self.proof_urls:
                proof_urls_item = proof_urls_item_data.to_dict()
                proof_urls.append(proof_urls_item)

        principal_method_status = self.principal_method_status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if state is not UNSET:
            field_dict["state"] = state
        if summary is not UNSET:
            field_dict["summary"] = summary
        if username is not UNSET:
            field_dict["username"] = username
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if child_profile_id is not UNSET:
            field_dict["child_profile_id"] = child_profile_id
        if child_did is not UNSET:
            field_dict["child_did"] = child_did
        if verification_method is not UNSET:
            field_dict["verification_method"] = verification_method
        if proof_urls is not UNSET:
            field_dict["proof_urls"] = proof_urls
        if principal_method_status is not UNSET:
            field_dict["principal_method_status"] = principal_method_status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.verification_state_proof_urls_item import VerificationStateProofUrlsItem

        d = dict(src_dict)
        state = d.pop("state", UNSET)

        summary = d.pop("summary", UNSET)

        username = d.pop("username", UNSET)

        display_name = d.pop("display_name", UNSET)

        child_profile_id = d.pop("child_profile_id", UNSET)

        child_did = d.pop("child_did", UNSET)

        verification_method = d.pop("verification_method", UNSET)

        _proof_urls = d.pop("proof_urls", UNSET)
        proof_urls: list[VerificationStateProofUrlsItem] | Unset = UNSET
        if _proof_urls is not UNSET:
            proof_urls = []
            for proof_urls_item_data in _proof_urls:
                proof_urls_item = VerificationStateProofUrlsItem.from_dict(proof_urls_item_data)

                proof_urls.append(proof_urls_item)

        principal_method_status = d.pop("principal_method_status", UNSET)

        verification_state = cls(
            state=state,
            summary=summary,
            username=username,
            display_name=display_name,
            child_profile_id=child_profile_id,
            child_did=child_did,
            verification_method=verification_method,
            proof_urls=proof_urls,
            principal_method_status=principal_method_status,
        )

        verification_state.additional_properties = d
        return verification_state

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
