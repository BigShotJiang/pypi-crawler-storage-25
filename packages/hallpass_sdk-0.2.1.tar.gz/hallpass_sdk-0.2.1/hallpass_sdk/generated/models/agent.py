from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.agent_key_mode import AgentKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_public_jwk import AgentPublicJwk
    from ..models.attestation import Attestation
    from ..models.delegation import Delegation


T = TypeVar("T", bound="Agent")


@_attrs_define
class Agent:
    """
    Attributes:
        id (UUID):
        username (str):
        display_name (None | str):
        did (str):
        verification_method (str):
        public_jwk (AgentPublicJwk):
        key_fingerprint (str):
        key_mode (AgentKeyMode):
        registration_status (str):
        challenge_status (str):
        description (None | str | Unset):
        avatar_url (None | str | Unset):
        challenge_token (None | str | Unset):
        challenge_verified_at (datetime.datetime | None | Unset):
        delegation (Delegation | None | Unset):
        attestations (list[Attestation] | Unset):
    """

    id: UUID
    username: str
    display_name: None | str
    did: str
    verification_method: str
    public_jwk: AgentPublicJwk
    key_fingerprint: str
    key_mode: AgentKeyMode
    registration_status: str
    challenge_status: str
    description: None | str | Unset = UNSET
    avatar_url: None | str | Unset = UNSET
    challenge_token: None | str | Unset = UNSET
    challenge_verified_at: datetime.datetime | None | Unset = UNSET
    delegation: Delegation | None | Unset = UNSET
    attestations: list[Attestation] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.delegation import Delegation

        id = str(self.id)

        username = self.username

        display_name: None | str
        display_name = self.display_name

        did = self.did

        verification_method = self.verification_method

        public_jwk = self.public_jwk.to_dict()

        key_fingerprint = self.key_fingerprint

        key_mode = self.key_mode.value

        registration_status = self.registration_status

        challenge_status = self.challenge_status

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        avatar_url: None | str | Unset
        if isinstance(self.avatar_url, Unset):
            avatar_url = UNSET
        else:
            avatar_url = self.avatar_url

        challenge_token: None | str | Unset
        if isinstance(self.challenge_token, Unset):
            challenge_token = UNSET
        else:
            challenge_token = self.challenge_token

        challenge_verified_at: None | str | Unset
        if isinstance(self.challenge_verified_at, Unset):
            challenge_verified_at = UNSET
        elif isinstance(self.challenge_verified_at, datetime.datetime):
            challenge_verified_at = self.challenge_verified_at.isoformat()
        else:
            challenge_verified_at = self.challenge_verified_at

        delegation: dict[str, Any] | None | Unset
        if isinstance(self.delegation, Unset):
            delegation = UNSET
        elif isinstance(self.delegation, Delegation):
            delegation = self.delegation.to_dict()
        else:
            delegation = self.delegation

        attestations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.attestations, Unset):
            attestations = []
            for attestations_item_data in self.attestations:
                attestations_item = attestations_item_data.to_dict()
                attestations.append(attestations_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "username": username,
                "display_name": display_name,
                "did": did,
                "verification_method": verification_method,
                "public_jwk": public_jwk,
                "key_fingerprint": key_fingerprint,
                "key_mode": key_mode,
                "registration_status": registration_status,
                "challenge_status": challenge_status,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if avatar_url is not UNSET:
            field_dict["avatar_url"] = avatar_url
        if challenge_token is not UNSET:
            field_dict["challenge_token"] = challenge_token
        if challenge_verified_at is not UNSET:
            field_dict["challenge_verified_at"] = challenge_verified_at
        if delegation is not UNSET:
            field_dict["delegation"] = delegation
        if attestations is not UNSET:
            field_dict["attestations"] = attestations

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_public_jwk import AgentPublicJwk
        from ..models.attestation import Attestation
        from ..models.delegation import Delegation

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        username = d.pop("username")

        def _parse_display_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        display_name = _parse_display_name(d.pop("display_name"))

        did = d.pop("did")

        verification_method = d.pop("verification_method")

        public_jwk = AgentPublicJwk.from_dict(d.pop("public_jwk"))

        key_fingerprint = d.pop("key_fingerprint")

        key_mode = AgentKeyMode(d.pop("key_mode"))

        registration_status = d.pop("registration_status")

        challenge_status = d.pop("challenge_status")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_avatar_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        avatar_url = _parse_avatar_url(d.pop("avatar_url", UNSET))

        def _parse_challenge_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        challenge_token = _parse_challenge_token(d.pop("challenge_token", UNSET))

        def _parse_challenge_verified_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                challenge_verified_at_type_0 = isoparse(data)

                return challenge_verified_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        challenge_verified_at = _parse_challenge_verified_at(d.pop("challenge_verified_at", UNSET))

        def _parse_delegation(data: object) -> Delegation | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                delegation_type_0 = Delegation.from_dict(data)

                return delegation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Delegation | None | Unset, data)

        delegation = _parse_delegation(d.pop("delegation", UNSET))

        _attestations = d.pop("attestations", UNSET)
        attestations: list[Attestation] | Unset = UNSET
        if _attestations is not UNSET:
            attestations = []
            for attestations_item_data in _attestations:
                attestations_item = Attestation.from_dict(attestations_item_data)

                attestations.append(attestations_item)

        agent = cls(
            id=id,
            username=username,
            display_name=display_name,
            did=did,
            verification_method=verification_method,
            public_jwk=public_jwk,
            key_fingerprint=key_fingerprint,
            key_mode=key_mode,
            registration_status=registration_status,
            challenge_status=challenge_status,
            description=description,
            avatar_url=avatar_url,
            challenge_token=challenge_token,
            challenge_verified_at=challenge_verified_at,
            delegation=delegation,
            attestations=attestations,
        )

        agent.additional_properties = d
        return agent

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
