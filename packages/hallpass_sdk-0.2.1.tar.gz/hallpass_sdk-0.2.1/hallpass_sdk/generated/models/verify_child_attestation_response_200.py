from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.attestation import Attestation


T = TypeVar("T", bound="VerifyChildAttestationResponse200")


@_attrs_define
class VerifyChildAttestationResponse200:
    """
    Attributes:
        attestation (Attestation):
    """

    attestation: Attestation
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        attestation = self.attestation.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "attestation": attestation,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.attestation import Attestation

        d = dict(src_dict)
        attestation = Attestation.from_dict(d.pop("attestation"))

        verify_child_attestation_response_200 = cls(
            attestation=attestation,
        )

        verify_child_attestation_response_200.additional_properties = d
        return verify_child_attestation_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
