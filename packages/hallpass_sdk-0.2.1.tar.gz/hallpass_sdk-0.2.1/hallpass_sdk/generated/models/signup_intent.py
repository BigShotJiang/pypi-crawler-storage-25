from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.signup_intent_status import SignupIntentStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="SignupIntent")


@_attrs_define
class SignupIntent:
    """
    Attributes:
        id (UUID):
        agent_profile_id (UUID):
        user_profile_id (UUID):
        service_id (UUID):
        status (SignupIntentStatus):
        scopes (list[str] | Unset):
        expires_at (datetime.datetime | None | Unset):
        approved_at (datetime.datetime | None | Unset):
        denied_at (datetime.datetime | None | Unset):
        expired_at (datetime.datetime | None | Unset):
        inserted_at (datetime.datetime | None | Unset):
    """

    id: UUID
    agent_profile_id: UUID
    user_profile_id: UUID
    service_id: UUID
    status: SignupIntentStatus
    scopes: list[str] | Unset = UNSET
    expires_at: datetime.datetime | None | Unset = UNSET
    approved_at: datetime.datetime | None | Unset = UNSET
    denied_at: datetime.datetime | None | Unset = UNSET
    expired_at: datetime.datetime | None | Unset = UNSET
    inserted_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        agent_profile_id = str(self.agent_profile_id)

        user_profile_id = str(self.user_profile_id)

        service_id = str(self.service_id)

        status = self.status.value

        scopes: list[str] | Unset = UNSET
        if not isinstance(self.scopes, Unset):
            scopes = self.scopes

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        approved_at: None | str | Unset
        if isinstance(self.approved_at, Unset):
            approved_at = UNSET
        elif isinstance(self.approved_at, datetime.datetime):
            approved_at = self.approved_at.isoformat()
        else:
            approved_at = self.approved_at

        denied_at: None | str | Unset
        if isinstance(self.denied_at, Unset):
            denied_at = UNSET
        elif isinstance(self.denied_at, datetime.datetime):
            denied_at = self.denied_at.isoformat()
        else:
            denied_at = self.denied_at

        expired_at: None | str | Unset
        if isinstance(self.expired_at, Unset):
            expired_at = UNSET
        elif isinstance(self.expired_at, datetime.datetime):
            expired_at = self.expired_at.isoformat()
        else:
            expired_at = self.expired_at

        inserted_at: None | str | Unset
        if isinstance(self.inserted_at, Unset):
            inserted_at = UNSET
        elif isinstance(self.inserted_at, datetime.datetime):
            inserted_at = self.inserted_at.isoformat()
        else:
            inserted_at = self.inserted_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "agent_profile_id": agent_profile_id,
                "user_profile_id": user_profile_id,
                "service_id": service_id,
                "status": status,
            }
        )
        if scopes is not UNSET:
            field_dict["scopes"] = scopes
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if approved_at is not UNSET:
            field_dict["approved_at"] = approved_at
        if denied_at is not UNSET:
            field_dict["denied_at"] = denied_at
        if expired_at is not UNSET:
            field_dict["expired_at"] = expired_at
        if inserted_at is not UNSET:
            field_dict["inserted_at"] = inserted_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        agent_profile_id = UUID(d.pop("agent_profile_id"))

        user_profile_id = UUID(d.pop("user_profile_id"))

        service_id = UUID(d.pop("service_id"))

        status = SignupIntentStatus(d.pop("status"))

        scopes = cast(list[str], d.pop("scopes", UNSET))

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expires_at", UNSET))

        def _parse_approved_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                approved_at_type_0 = isoparse(data)

                return approved_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        approved_at = _parse_approved_at(d.pop("approved_at", UNSET))

        def _parse_denied_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                denied_at_type_0 = isoparse(data)

                return denied_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        denied_at = _parse_denied_at(d.pop("denied_at", UNSET))

        def _parse_expired_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expired_at_type_0 = isoparse(data)

                return expired_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expired_at = _parse_expired_at(d.pop("expired_at", UNSET))

        def _parse_inserted_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                inserted_at_type_0 = isoparse(data)

                return inserted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        inserted_at = _parse_inserted_at(d.pop("inserted_at", UNSET))

        signup_intent = cls(
            id=id,
            agent_profile_id=agent_profile_id,
            user_profile_id=user_profile_id,
            service_id=service_id,
            status=status,
            scopes=scopes,
            expires_at=expires_at,
            approved_at=approved_at,
            denied_at=denied_at,
            expired_at=expired_at,
            inserted_at=inserted_at,
        )

        signup_intent.additional_properties = d
        return signup_intent

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
