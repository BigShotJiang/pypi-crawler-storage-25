from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.workspace_stage import WorkspaceStage
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent import Agent
    from ..models.agent_key_guidance import AgentKeyGuidance
    from ..models.attestation import Attestation
    from ..models.attestation_option import AttestationOption
    from ..models.auth_profile import AuthProfile
    from ..models.message import Message
    from ..models.profile_key import ProfileKey
    from ..models.security_summary import SecuritySummary
    from ..models.workspace_stage_details import WorkspaceStageDetails
    from ..models.workspace_step_statuses import WorkspaceStepStatuses


T = TypeVar("T", bound="Workspace")


@_attrs_define
class Workspace:
    """
    Attributes:
        current_profile (AuthProfile):
        security_summary (SecuritySummary):
        socket_token (str): Phoenix socket token for real-time channel authentication
        public_profile_path (str): Human-readable public profile page path (e.g. /p/username)
        attestations (list[Attestation]):
        attestation_options (list[AttestationOption]):
        agents (list[Agent]):
        agent_key_guidance (AgentKeyGuidance):
        key_history (list[ProfileKey]):
        stage (WorkspaceStage):
        stage_details (WorkspaceStageDetails):
        next_action (str):
        step_statuses (WorkspaceStepStatuses):
        latest_message (Message | None | Unset):
    """

    current_profile: AuthProfile
    security_summary: SecuritySummary
    socket_token: str
    public_profile_path: str
    attestations: list[Attestation]
    attestation_options: list[AttestationOption]
    agents: list[Agent]
    agent_key_guidance: AgentKeyGuidance
    key_history: list[ProfileKey]
    stage: WorkspaceStage
    stage_details: WorkspaceStageDetails
    next_action: str
    step_statuses: WorkspaceStepStatuses
    latest_message: Message | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.message import Message

        current_profile = self.current_profile.to_dict()

        security_summary = self.security_summary.to_dict()

        socket_token = self.socket_token

        public_profile_path = self.public_profile_path

        attestations = []
        for attestations_item_data in self.attestations:
            attestations_item = attestations_item_data.to_dict()
            attestations.append(attestations_item)

        attestation_options = []
        for attestation_options_item_data in self.attestation_options:
            attestation_options_item = attestation_options_item_data.to_dict()
            attestation_options.append(attestation_options_item)

        agents = []
        for agents_item_data in self.agents:
            agents_item = agents_item_data.to_dict()
            agents.append(agents_item)

        agent_key_guidance = self.agent_key_guidance.to_dict()

        key_history = []
        for key_history_item_data in self.key_history:
            key_history_item = key_history_item_data.to_dict()
            key_history.append(key_history_item)

        stage = self.stage.value

        stage_details = self.stage_details.to_dict()

        next_action = self.next_action

        step_statuses = self.step_statuses.to_dict()

        latest_message: dict[str, Any] | None | Unset
        if isinstance(self.latest_message, Unset):
            latest_message = UNSET
        elif isinstance(self.latest_message, Message):
            latest_message = self.latest_message.to_dict()
        else:
            latest_message = self.latest_message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "current_profile": current_profile,
                "security_summary": security_summary,
                "socket_token": socket_token,
                "public_profile_path": public_profile_path,
                "attestations": attestations,
                "attestation_options": attestation_options,
                "agents": agents,
                "agent_key_guidance": agent_key_guidance,
                "key_history": key_history,
                "stage": stage,
                "stage_details": stage_details,
                "next_action": next_action,
                "step_statuses": step_statuses,
            }
        )
        if latest_message is not UNSET:
            field_dict["latest_message"] = latest_message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent import Agent
        from ..models.agent_key_guidance import AgentKeyGuidance
        from ..models.attestation import Attestation
        from ..models.attestation_option import AttestationOption
        from ..models.auth_profile import AuthProfile
        from ..models.message import Message
        from ..models.profile_key import ProfileKey
        from ..models.security_summary import SecuritySummary
        from ..models.workspace_stage_details import WorkspaceStageDetails
        from ..models.workspace_step_statuses import WorkspaceStepStatuses

        d = dict(src_dict)
        current_profile = AuthProfile.from_dict(d.pop("current_profile"))

        security_summary = SecuritySummary.from_dict(d.pop("security_summary"))

        socket_token = d.pop("socket_token")

        public_profile_path = d.pop("public_profile_path")

        attestations = []
        _attestations = d.pop("attestations")
        for attestations_item_data in _attestations:
            attestations_item = Attestation.from_dict(attestations_item_data)

            attestations.append(attestations_item)

        attestation_options = []
        _attestation_options = d.pop("attestation_options")
        for attestation_options_item_data in _attestation_options:
            attestation_options_item = AttestationOption.from_dict(attestation_options_item_data)

            attestation_options.append(attestation_options_item)

        agents = []
        _agents = d.pop("agents")
        for agents_item_data in _agents:
            agents_item = Agent.from_dict(agents_item_data)

            agents.append(agents_item)

        agent_key_guidance = AgentKeyGuidance.from_dict(d.pop("agent_key_guidance"))

        key_history = []
        _key_history = d.pop("key_history")
        for key_history_item_data in _key_history:
            key_history_item = ProfileKey.from_dict(key_history_item_data)

            key_history.append(key_history_item)

        stage = WorkspaceStage(d.pop("stage"))

        stage_details = WorkspaceStageDetails.from_dict(d.pop("stage_details"))

        next_action = d.pop("next_action")

        step_statuses = WorkspaceStepStatuses.from_dict(d.pop("step_statuses"))

        def _parse_latest_message(data: object) -> Message | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                latest_message_type_0 = Message.from_dict(data)

                return latest_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Message | None | Unset, data)

        latest_message = _parse_latest_message(d.pop("latest_message", UNSET))

        workspace = cls(
            current_profile=current_profile,
            security_summary=security_summary,
            socket_token=socket_token,
            public_profile_path=public_profile_path,
            attestations=attestations,
            attestation_options=attestation_options,
            agents=agents,
            agent_key_guidance=agent_key_guidance,
            key_history=key_history,
            stage=stage,
            stage_details=stage_details,
            next_action=next_action,
            step_statuses=step_statuses,
            latest_message=latest_message,
        )

        workspace.additional_properties = d
        return workspace

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
