from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.step_up_required_error_available_methods_item import StepUpRequiredErrorAvailableMethodsItem
from ..models.step_up_required_error_error import StepUpRequiredErrorError

T = TypeVar("T", bound="StepUpRequiredError")


@_attrs_define
class StepUpRequiredError:
    """
    Attributes:
        error (StepUpRequiredErrorError):
        available_methods (list[StepUpRequiredErrorAvailableMethodsItem]):
    """

    error: StepUpRequiredErrorError
    available_methods: list[StepUpRequiredErrorAvailableMethodsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        error = self.error.value

        available_methods = []
        for available_methods_item_data in self.available_methods:
            available_methods_item = available_methods_item_data.value
            available_methods.append(available_methods_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "error": error,
                "available_methods": available_methods,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        error = StepUpRequiredErrorError(d.pop("error"))

        available_methods = []
        _available_methods = d.pop("available_methods")
        for available_methods_item_data in _available_methods:
            available_methods_item = StepUpRequiredErrorAvailableMethodsItem(available_methods_item_data)

            available_methods.append(available_methods_item)

        step_up_required_error = cls(
            error=error,
            available_methods=available_methods,
        )

        step_up_required_error.additional_properties = d
        return step_up_required_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
