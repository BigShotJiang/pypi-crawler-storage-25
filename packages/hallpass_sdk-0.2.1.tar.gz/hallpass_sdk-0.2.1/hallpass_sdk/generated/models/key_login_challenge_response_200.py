from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="KeyLoginChallengeResponse200")


@_attrs_define
class KeyLoginChallengeResponse200:
    """
    Attributes:
        challenge_token (str): Signed Phoenix token containing the DID and nonce (2-minute expiry)
        nonce (str): Random nonce the client must include in the signed JWT
        profile_id (UUID):
        socket_token (str): Token for connecting to the key_login Phoenix Channel
        topic (str): Channel topic to subscribe to (e.g. key_login:<nonce>)
    """

    challenge_token: str
    nonce: str
    profile_id: UUID
    socket_token: str
    topic: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        challenge_token = self.challenge_token

        nonce = self.nonce

        profile_id = str(self.profile_id)

        socket_token = self.socket_token

        topic = self.topic

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "challenge_token": challenge_token,
                "nonce": nonce,
                "profile_id": profile_id,
                "socket_token": socket_token,
                "topic": topic,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        challenge_token = d.pop("challenge_token")

        nonce = d.pop("nonce")

        profile_id = UUID(d.pop("profile_id"))

        socket_token = d.pop("socket_token")

        topic = d.pop("topic")

        key_login_challenge_response_200 = cls(
            challenge_token=challenge_token,
            nonce=nonce,
            profile_id=profile_id,
            socket_token=socket_token,
            topic=topic,
        )

        key_login_challenge_response_200.additional_properties = d
        return key_login_challenge_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
