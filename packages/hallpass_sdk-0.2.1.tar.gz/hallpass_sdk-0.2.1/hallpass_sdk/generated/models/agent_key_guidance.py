from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_key_guidance_accepted_public_jwk import AgentKeyGuidanceAcceptedPublicJwk
    from ..models.agent_key_guidance_tool_snippets import AgentKeyGuidanceToolSnippets


T = TypeVar("T", bound="AgentKeyGuidance")


@_attrs_define
class AgentKeyGuidance:
    """
    Attributes:
        summary (str):
        accepted_public_jwk (AgentKeyGuidanceAcceptedPublicJwk):
        requirements (list[str]):
        local_generation_steps (list[str]):
        tool_snippets (AgentKeyGuidanceToolSnippets | Unset):
    """

    summary: str
    accepted_public_jwk: AgentKeyGuidanceAcceptedPublicJwk
    requirements: list[str]
    local_generation_steps: list[str]
    tool_snippets: AgentKeyGuidanceToolSnippets | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        summary = self.summary

        accepted_public_jwk = self.accepted_public_jwk.to_dict()

        requirements = self.requirements

        local_generation_steps = self.local_generation_steps

        tool_snippets: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_snippets, Unset):
            tool_snippets = self.tool_snippets.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "summary": summary,
                "accepted_public_jwk": accepted_public_jwk,
                "requirements": requirements,
                "local_generation_steps": local_generation_steps,
            }
        )
        if tool_snippets is not UNSET:
            field_dict["tool_snippets"] = tool_snippets

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_key_guidance_accepted_public_jwk import AgentKeyGuidanceAcceptedPublicJwk
        from ..models.agent_key_guidance_tool_snippets import AgentKeyGuidanceToolSnippets

        d = dict(src_dict)
        summary = d.pop("summary")

        accepted_public_jwk = AgentKeyGuidanceAcceptedPublicJwk.from_dict(d.pop("accepted_public_jwk"))

        requirements = cast(list[str], d.pop("requirements"))

        local_generation_steps = cast(list[str], d.pop("local_generation_steps"))

        _tool_snippets = d.pop("tool_snippets", UNSET)
        tool_snippets: AgentKeyGuidanceToolSnippets | Unset
        if isinstance(_tool_snippets, Unset):
            tool_snippets = UNSET
        else:
            tool_snippets = AgentKeyGuidanceToolSnippets.from_dict(_tool_snippets)

        agent_key_guidance = cls(
            summary=summary,
            accepted_public_jwk=accepted_public_jwk,
            requirements=requirements,
            local_generation_steps=local_generation_steps,
            tool_snippets=tool_snippets,
        )

        agent_key_guidance.additional_properties = d
        return agent_key_guidance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
