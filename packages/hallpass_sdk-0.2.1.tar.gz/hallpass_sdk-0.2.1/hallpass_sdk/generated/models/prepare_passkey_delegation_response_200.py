from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.prepare_passkey_delegation_response_200_payload import PreparePasskeyDelegationResponse200Payload
    from ..models.web_authn_assertion_options import WebAuthnAssertionOptions


T = TypeVar("T", bound="PreparePasskeyDelegationResponse200")


@_attrs_define
class PreparePasskeyDelegationResponse200:
    """
    Attributes:
        assertion_options (WebAuthnAssertionOptions):
        payload (PreparePasskeyDelegationResponse200Payload):
    """

    assertion_options: WebAuthnAssertionOptions
    payload: PreparePasskeyDelegationResponse200Payload
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        assertion_options = self.assertion_options.to_dict()

        payload = self.payload.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "assertion_options": assertion_options,
                "payload": payload,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.prepare_passkey_delegation_response_200_payload import PreparePasskeyDelegationResponse200Payload
        from ..models.web_authn_assertion_options import WebAuthnAssertionOptions

        d = dict(src_dict)
        assertion_options = WebAuthnAssertionOptions.from_dict(d.pop("assertion_options"))

        payload = PreparePasskeyDelegationResponse200Payload.from_dict(d.pop("payload"))

        prepare_passkey_delegation_response_200 = cls(
            assertion_options=assertion_options,
            payload=payload,
        )

        prepare_passkey_delegation_response_200.additional_properties = d
        return prepare_passkey_delegation_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
