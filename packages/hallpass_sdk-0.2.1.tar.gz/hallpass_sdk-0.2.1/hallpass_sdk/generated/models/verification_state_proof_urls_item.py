from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VerificationStateProofUrlsItem")


@_attrs_define
class VerificationStateProofUrlsItem:
    """
    Attributes:
        kind (str | Unset):
        value (str | Unset):
        proof_url (str | Unset):
    """

    kind: str | Unset = UNSET
    value: str | Unset = UNSET
    proof_url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind

        value = self.value

        proof_url = self.proof_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if kind is not UNSET:
            field_dict["kind"] = kind
        if value is not UNSET:
            field_dict["value"] = value
        if proof_url is not UNSET:
            field_dict["proof_url"] = proof_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        kind = d.pop("kind", UNSET)

        value = d.pop("value", UNSET)

        proof_url = d.pop("proof_url", UNSET)

        verification_state_proof_urls_item = cls(
            kind=kind,
            value=value,
            proof_url=proof_url,
        )

        verification_state_proof_urls_item.additional_properties = d
        return verification_state_proof_urls_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
