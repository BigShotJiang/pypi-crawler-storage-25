from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.passkey_sign_complete_response_200_bundle import PasskeySignCompleteResponse200Bundle


T = TypeVar("T", bound="PasskeySignCompleteResponse200")


@_attrs_define
class PasskeySignCompleteResponse200:
    """
    Attributes:
        bundle (PasskeySignCompleteResponse200Bundle):
    """

    bundle: PasskeySignCompleteResponse200Bundle
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bundle = self.bundle.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bundle": bundle,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.passkey_sign_complete_response_200_bundle import PasskeySignCompleteResponse200Bundle

        d = dict(src_dict)
        bundle = PasskeySignCompleteResponse200Bundle.from_dict(d.pop("bundle"))

        passkey_sign_complete_response_200 = cls(
            bundle=bundle,
        )

        passkey_sign_complete_response_200.additional_properties = d
        return passkey_sign_complete_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
