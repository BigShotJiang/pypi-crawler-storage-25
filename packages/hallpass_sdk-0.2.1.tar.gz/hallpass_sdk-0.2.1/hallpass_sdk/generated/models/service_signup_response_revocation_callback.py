from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ServiceSignupResponseRevocationCallback")


@_attrs_define
class ServiceSignupResponseRevocationCallback:
    """
    Attributes:
        callback_id (UUID | Unset):
        callback_url (str | Unset):
    """

    callback_id: UUID | Unset = UNSET
    callback_url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        callback_id: str | Unset = UNSET
        if not isinstance(self.callback_id, Unset):
            callback_id = str(self.callback_id)

        callback_url = self.callback_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if callback_id is not UNSET:
            field_dict["callback_id"] = callback_id
        if callback_url is not UNSET:
            field_dict["callback_url"] = callback_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _callback_id = d.pop("callback_id", UNSET)
        callback_id: UUID | Unset
        if isinstance(_callback_id, Unset):
            callback_id = UNSET
        else:
            callback_id = UUID(_callback_id)

        callback_url = d.pop("callback_url", UNSET)

        service_signup_response_revocation_callback = cls(
            callback_id=callback_id,
            callback_url=callback_url,
        )

        service_signup_response_revocation_callback.additional_properties = d
        return service_signup_response_revocation_callback

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
