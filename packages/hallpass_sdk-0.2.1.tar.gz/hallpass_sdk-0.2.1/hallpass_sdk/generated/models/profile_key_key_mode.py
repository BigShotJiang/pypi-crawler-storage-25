from enum import Enum


class ProfileKeyKeyMode(str, Enum):
    PASSKEY = "passkey"
    SELF_MANAGED = "self_managed"
    SERVICE_MANAGED = "service_managed"

    def __str__(self) -> str:
        return str(self.value)
