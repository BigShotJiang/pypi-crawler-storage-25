from enum import Enum


class VerificationChangeRowType(str, Enum):
    AGENT_DELETED = "agent_deleted"
    AGENT_DISPLAY_NAME_CHANGED = "agent_display_name_changed"
    AGENT_KEY_ROTATED = "agent_key_rotated"
    DELEGATION_EXPIRED = "delegation_expired"
    DELEGATION_REVOKED = "delegation_revoked"
    PRINCIPAL_DISPLAY_NAME_CHANGED = "principal_display_name_changed"
    PRINCIPAL_KEY_ROTATED = "principal_key_rotated"

    def __str__(self) -> str:
        return str(self.value)
