from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.security_overview_key_mode import SecurityOverviewKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.available_actions import AvailableActions


T = TypeVar("T", bound="SecurityOverview")


@_attrs_define
class SecurityOverview:
    """
    Attributes:
        email_verified (bool):
        email_notifications_enabled (bool):
        recovery_codes_remaining (int):
        has_passkeys (bool):
        has_password (bool): Whether the profile has a password set.
        signing_setup_complete (bool): Whether the profile has completed delegation signing setup.
        key_mode (SecurityOverviewKeyMode):
        available_actions (AvailableActions):
        email (None | str | Unset):
    """

    email_verified: bool
    email_notifications_enabled: bool
    recovery_codes_remaining: int
    has_passkeys: bool
    has_password: bool
    signing_setup_complete: bool
    key_mode: SecurityOverviewKeyMode
    available_actions: AvailableActions
    email: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email_verified = self.email_verified

        email_notifications_enabled = self.email_notifications_enabled

        recovery_codes_remaining = self.recovery_codes_remaining

        has_passkeys = self.has_passkeys

        has_password = self.has_password

        signing_setup_complete = self.signing_setup_complete

        key_mode = self.key_mode.value

        available_actions = self.available_actions.to_dict()

        email: None | str | Unset
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email_verified": email_verified,
                "email_notifications_enabled": email_notifications_enabled,
                "recovery_codes_remaining": recovery_codes_remaining,
                "has_passkeys": has_passkeys,
                "has_password": has_password,
                "signing_setup_complete": signing_setup_complete,
                "key_mode": key_mode,
                "available_actions": available_actions,
            }
        )
        if email is not UNSET:
            field_dict["email"] = email

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.available_actions import AvailableActions

        d = dict(src_dict)
        email_verified = d.pop("email_verified")

        email_notifications_enabled = d.pop("email_notifications_enabled")

        recovery_codes_remaining = d.pop("recovery_codes_remaining")

        has_passkeys = d.pop("has_passkeys")

        has_password = d.pop("has_password")

        signing_setup_complete = d.pop("signing_setup_complete")

        key_mode = SecurityOverviewKeyMode(d.pop("key_mode"))

        available_actions = AvailableActions.from_dict(d.pop("available_actions"))

        def _parse_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        email = _parse_email(d.pop("email", UNSET))

        security_overview = cls(
            email_verified=email_verified,
            email_notifications_enabled=email_notifications_enabled,
            recovery_codes_remaining=recovery_codes_remaining,
            has_passkeys=has_passkeys,
            has_password=has_password,
            signing_setup_complete=signing_setup_complete,
            key_mode=key_mode,
            available_actions=available_actions,
            email=email,
        )

        security_overview.additional_properties = d
        return security_overview

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
