from enum import Enum


class DelegationArtifactApprovalSource(str, Enum):
    DELEGATE_CUSTODIED_KEY = "delegate_custodied_key"
    OPERATOR_JWK = "operator_jwk"
    OPERATOR_PASSKEY = "operator_passkey"

    def __str__(self) -> str:
        return str(self.value)
