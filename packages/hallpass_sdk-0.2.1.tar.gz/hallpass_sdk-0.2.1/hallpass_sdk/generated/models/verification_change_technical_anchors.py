from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VerificationChangeTechnicalAnchors")


@_attrs_define
class VerificationChangeTechnicalAnchors:
    """
    Attributes:
        actor_did (str | Unset):
        subject_did (str | Unset):
        verification_method (str | Unset):
        key_fingerprint (str | Unset):
        principal_method_id (UUID | Unset):
        child_profile_id (UUID | Unset):
    """

    actor_did: str | Unset = UNSET
    subject_did: str | Unset = UNSET
    verification_method: str | Unset = UNSET
    key_fingerprint: str | Unset = UNSET
    principal_method_id: UUID | Unset = UNSET
    child_profile_id: UUID | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        actor_did = self.actor_did

        subject_did = self.subject_did

        verification_method = self.verification_method

        key_fingerprint = self.key_fingerprint

        principal_method_id: str | Unset = UNSET
        if not isinstance(self.principal_method_id, Unset):
            principal_method_id = str(self.principal_method_id)

        child_profile_id: str | Unset = UNSET
        if not isinstance(self.child_profile_id, Unset):
            child_profile_id = str(self.child_profile_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if actor_did is not UNSET:
            field_dict["actor_did"] = actor_did
        if subject_did is not UNSET:
            field_dict["subject_did"] = subject_did
        if verification_method is not UNSET:
            field_dict["verification_method"] = verification_method
        if key_fingerprint is not UNSET:
            field_dict["key_fingerprint"] = key_fingerprint
        if principal_method_id is not UNSET:
            field_dict["principal_method_id"] = principal_method_id
        if child_profile_id is not UNSET:
            field_dict["child_profile_id"] = child_profile_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        actor_did = d.pop("actor_did", UNSET)

        subject_did = d.pop("subject_did", UNSET)

        verification_method = d.pop("verification_method", UNSET)

        key_fingerprint = d.pop("key_fingerprint", UNSET)

        _principal_method_id = d.pop("principal_method_id", UNSET)
        principal_method_id: UUID | Unset
        if isinstance(_principal_method_id, Unset):
            principal_method_id = UNSET
        else:
            principal_method_id = UUID(_principal_method_id)

        _child_profile_id = d.pop("child_profile_id", UNSET)
        child_profile_id: UUID | Unset
        if isinstance(_child_profile_id, Unset):
            child_profile_id = UNSET
        else:
            child_profile_id = UUID(_child_profile_id)

        verification_change_technical_anchors = cls(
            actor_did=actor_did,
            subject_did=subject_did,
            verification_method=verification_method,
            key_fingerprint=key_fingerprint,
            principal_method_id=principal_method_id,
            child_profile_id=child_profile_id,
        )

        verification_change_technical_anchors.additional_properties = d
        return verification_change_technical_anchors

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
