from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.web_authn_assertion_response import WebAuthnAssertionResponse


T = TypeVar("T", bound="ApprovePasskeyDelegationBody")


@_attrs_define
class ApprovePasskeyDelegationBody:
    """
    Attributes:
        child_profile_id (UUID):
        response (WebAuthnAssertionResponse):
    """

    child_profile_id: UUID
    response: WebAuthnAssertionResponse
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        child_profile_id = str(self.child_profile_id)

        response = self.response.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "child_profile_id": child_profile_id,
                "response": response,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.web_authn_assertion_response import WebAuthnAssertionResponse

        d = dict(src_dict)
        child_profile_id = UUID(d.pop("child_profile_id"))

        response = WebAuthnAssertionResponse.from_dict(d.pop("response"))

        approve_passkey_delegation_body = cls(
            child_profile_id=child_profile_id,
            response=response,
        )

        approve_passkey_delegation_body.additional_properties = d
        return approve_passkey_delegation_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
