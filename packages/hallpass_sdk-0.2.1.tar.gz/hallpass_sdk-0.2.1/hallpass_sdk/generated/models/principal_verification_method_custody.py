from enum import Enum


class PrincipalVerificationMethodCustody(str, Enum):
    DELEGATE = "delegate"
    OPERATOR = "operator"

    def __str__(self) -> str:
        return str(self.value)
