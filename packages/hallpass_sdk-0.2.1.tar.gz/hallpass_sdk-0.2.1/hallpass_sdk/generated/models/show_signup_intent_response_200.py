from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.signup_intent import SignupIntent


T = TypeVar("T", bound="ShowSignupIntentResponse200")


@_attrs_define
class ShowSignupIntentResponse200:
    """
    Attributes:
        signup_intent (SignupIntent):
    """

    signup_intent: SignupIntent
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        signup_intent = self.signup_intent.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "signup_intent": signup_intent,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.signup_intent import SignupIntent

        d = dict(src_dict)
        signup_intent = SignupIntent.from_dict(d.pop("signup_intent"))

        show_signup_intent_response_200 = cls(
            signup_intent=signup_intent,
        )

        show_signup_intent_response_200.additional_properties = d
        return show_signup_intent_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
