from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.step_up_credential_webauthn_assertion import StepUpCredentialWebauthnAssertion


T = TypeVar("T", bound="SetEmailBody")


@_attrs_define
class SetEmailBody:
    """
    Attributes:
        email (str):
        confirm_password (str | Unset): Current password for password-based step-up.
        webauthn_assertion (StepUpCredentialWebauthnAssertion | Unset): WebAuthn assertion response from a step-up
            challenge.
        key_assertion (str | Unset): JWS signed with the CLI private key over the step-up nonce.
    """

    email: str
    confirm_password: str | Unset = UNSET
    webauthn_assertion: StepUpCredentialWebauthnAssertion | Unset = UNSET
    key_assertion: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        confirm_password = self.confirm_password

        webauthn_assertion: dict[str, Any] | Unset = UNSET
        if not isinstance(self.webauthn_assertion, Unset):
            webauthn_assertion = self.webauthn_assertion.to_dict()

        key_assertion = self.key_assertion

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "email": email,
            }
        )
        if confirm_password is not UNSET:
            field_dict["confirm_password"] = confirm_password
        if webauthn_assertion is not UNSET:
            field_dict["webauthn_assertion"] = webauthn_assertion
        if key_assertion is not UNSET:
            field_dict["key_assertion"] = key_assertion

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.step_up_credential_webauthn_assertion import StepUpCredentialWebauthnAssertion

        d = dict(src_dict)
        email = d.pop("email")

        confirm_password = d.pop("confirm_password", UNSET)

        _webauthn_assertion = d.pop("webauthn_assertion", UNSET)
        webauthn_assertion: StepUpCredentialWebauthnAssertion | Unset
        if isinstance(_webauthn_assertion, Unset):
            webauthn_assertion = UNSET
        else:
            webauthn_assertion = StepUpCredentialWebauthnAssertion.from_dict(_webauthn_assertion)

        key_assertion = d.pop("key_assertion", UNSET)

        set_email_body = cls(
            email=email,
            confirm_password=confirm_password,
            webauthn_assertion=webauthn_assertion,
            key_assertion=key_assertion,
        )

        set_email_body.additional_properties = d
        return set_email_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
