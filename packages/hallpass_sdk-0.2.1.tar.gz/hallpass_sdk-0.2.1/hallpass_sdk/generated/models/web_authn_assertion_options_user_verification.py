from enum import Enum


class WebAuthnAssertionOptionsUserVerification(str, Enum):
    DISCOURAGED = "discouraged"
    PREFERRED = "preferred"
    REQUIRED = "required"

    def __str__(self) -> str:
        return str(self.value)
