from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.register_complete_request_public_jwk import RegisterCompleteRequestPublicJwk


T = TypeVar("T", bound="RegisterCompleteRequest")


@_attrs_define
class RegisterCompleteRequest:
    """
    Attributes:
        registration_token (str):
        public_jwk (RegisterCompleteRequestPublicJwk): ECDSA P-256 public key in JWK format, generated locally by the
            CLI.
    """

    registration_token: str
    public_jwk: RegisterCompleteRequestPublicJwk
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        registration_token = self.registration_token

        public_jwk = self.public_jwk.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "registration_token": registration_token,
                "public_jwk": public_jwk,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.register_complete_request_public_jwk import RegisterCompleteRequestPublicJwk

        d = dict(src_dict)
        registration_token = d.pop("registration_token")

        public_jwk = RegisterCompleteRequestPublicJwk.from_dict(d.pop("public_jwk"))

        register_complete_request = cls(
            registration_token=registration_token,
            public_jwk=public_jwk,
        )

        register_complete_request.additional_properties = d
        return register_complete_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
