from enum import Enum


class VerifyRecoveryBodyMethod(str, Enum):
    DEVICE_APPROVAL = "device_approval"
    EMAIL = "email"
    KEY_SIGNING = "key_signing"
    RECOVERY_CODE = "recovery_code"

    def __str__(self) -> str:
        return str(self.value)
