from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.register_request_key_mode import RegisterRequestKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.register_request_public_jwk import RegisterRequestPublicJwk


T = TypeVar("T", bound="RegisterRequest")


@_attrs_define
class RegisterRequest:
    """
    Attributes:
        username (str):
        password (str):
        display_name (None | str | Unset):
        key_mode (RegisterRequestKeyMode | Unset):  Default: RegisterRequestKeyMode.SERVICE_MANAGED.
        public_jwk (RegisterRequestPublicJwk | Unset): Required when key_mode is self_managed.
    """

    username: str
    password: str
    display_name: None | str | Unset = UNSET
    key_mode: RegisterRequestKeyMode | Unset = RegisterRequestKeyMode.SERVICE_MANAGED
    public_jwk: RegisterRequestPublicJwk | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        username = self.username

        password = self.password

        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        key_mode: str | Unset = UNSET
        if not isinstance(self.key_mode, Unset):
            key_mode = self.key_mode.value

        public_jwk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.public_jwk, Unset):
            public_jwk = self.public_jwk.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "username": username,
                "password": password,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if key_mode is not UNSET:
            field_dict["key_mode"] = key_mode
        if public_jwk is not UNSET:
            field_dict["public_jwk"] = public_jwk

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.register_request_public_jwk import RegisterRequestPublicJwk

        d = dict(src_dict)
        username = d.pop("username")

        password = d.pop("password")

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("display_name", UNSET))

        _key_mode = d.pop("key_mode", UNSET)
        key_mode: RegisterRequestKeyMode | Unset
        if isinstance(_key_mode, Unset):
            key_mode = UNSET
        else:
            key_mode = RegisterRequestKeyMode(_key_mode)

        _public_jwk = d.pop("public_jwk", UNSET)
        public_jwk: RegisterRequestPublicJwk | Unset
        if isinstance(_public_jwk, Unset):
            public_jwk = UNSET
        else:
            public_jwk = RegisterRequestPublicJwk.from_dict(_public_jwk)

        register_request = cls(
            username=username,
            password=password,
            display_name=display_name,
            key_mode=key_mode,
            public_jwk=public_jwk,
        )

        register_request.additional_properties = d
        return register_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
