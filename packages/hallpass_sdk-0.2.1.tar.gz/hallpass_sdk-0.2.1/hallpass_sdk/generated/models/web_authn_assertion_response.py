from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="WebAuthnAssertionResponse")


@_attrs_define
class WebAuthnAssertionResponse:
    """
    Attributes:
        raw_id (str): Base64url-encoded raw credential ID
        client_data_json (str): Base64url-encoded client data JSON
        authenticator_data (str): Base64url-encoded authenticator data
        signature (str): Base64url-encoded signature
    """

    raw_id: str
    client_data_json: str
    authenticator_data: str
    signature: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        raw_id = self.raw_id

        client_data_json = self.client_data_json

        authenticator_data = self.authenticator_data

        signature = self.signature

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "rawId": raw_id,
                "clientDataJSON": client_data_json,
                "authenticatorData": authenticator_data,
                "signature": signature,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        raw_id = d.pop("rawId")

        client_data_json = d.pop("clientDataJSON")

        authenticator_data = d.pop("authenticatorData")

        signature = d.pop("signature")

        web_authn_assertion_response = cls(
            raw_id=raw_id,
            client_data_json=client_data_json,
            authenticator_data=authenticator_data,
            signature=signature,
        )

        web_authn_assertion_response.additional_properties = d
        return web_authn_assertion_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
