from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rotate_child_key_body_public_jwk import RotateChildKeyBodyPublicJwk


T = TypeVar("T", bound="RotateChildKeyBody")


@_attrs_define
class RotateChildKeyBody:
    """
    Attributes:
        public_jwk (RotateChildKeyBodyPublicJwk | Unset): Required for self-managed child profiles.
    """

    public_jwk: RotateChildKeyBodyPublicJwk | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        public_jwk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.public_jwk, Unset):
            public_jwk = self.public_jwk.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if public_jwk is not UNSET:
            field_dict["public_jwk"] = public_jwk

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rotate_child_key_body_public_jwk import RotateChildKeyBodyPublicJwk

        d = dict(src_dict)
        _public_jwk = d.pop("public_jwk", UNSET)
        public_jwk: RotateChildKeyBodyPublicJwk | Unset
        if isinstance(_public_jwk, Unset):
            public_jwk = UNSET
        else:
            public_jwk = RotateChildKeyBodyPublicJwk.from_dict(_public_jwk)

        rotate_child_key_body = cls(
            public_jwk=public_jwk,
        )

        rotate_child_key_body.additional_properties = d
        return rotate_child_key_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
