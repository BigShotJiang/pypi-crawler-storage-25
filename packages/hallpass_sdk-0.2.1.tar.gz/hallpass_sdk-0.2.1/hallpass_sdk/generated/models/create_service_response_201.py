from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.service_detail_with_secret import ServiceDetailWithSecret


T = TypeVar("T", bound="CreateServiceResponse201")


@_attrs_define
class CreateServiceResponse201:
    """
    Attributes:
        service (ServiceDetailWithSecret):
    """

    service: ServiceDetailWithSecret
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        service = self.service.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "service": service,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.service_detail_with_secret import ServiceDetailWithSecret

        d = dict(src_dict)
        service = ServiceDetailWithSecret.from_dict(d.pop("service"))

        create_service_response_201 = cls(
            service=service,
        )

        create_service_response_201.additional_properties = d
        return create_service_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
