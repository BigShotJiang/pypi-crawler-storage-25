from enum import Enum


class AvailableActionsStepUpMethodsItem(str, Enum):
    CLI_KEY = "cli_key"
    PASSKEY = "passkey"
    PASSWORD = "password"

    def __str__(self) -> str:
        return str(self.value)
