from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.register_passkey_request_response import RegisterPasskeyRequestResponse


T = TypeVar("T", bound="RegisterPasskeyRequest")


@_attrs_define
class RegisterPasskeyRequest:
    """
    Attributes:
        response (RegisterPasskeyRequestResponse):
        friendly_name (str | Unset):
        purposes (list[str] | Unset): Passkey purposes. Defaults to ['login', 'delegation_approval'].
    """

    response: RegisterPasskeyRequestResponse
    friendly_name: str | Unset = UNSET
    purposes: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        response = self.response.to_dict()

        friendly_name = self.friendly_name

        purposes: list[str] | Unset = UNSET
        if not isinstance(self.purposes, Unset):
            purposes = self.purposes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "response": response,
            }
        )
        if friendly_name is not UNSET:
            field_dict["friendly_name"] = friendly_name
        if purposes is not UNSET:
            field_dict["purposes"] = purposes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.register_passkey_request_response import RegisterPasskeyRequestResponse

        d = dict(src_dict)
        response = RegisterPasskeyRequestResponse.from_dict(d.pop("response"))

        friendly_name = d.pop("friendly_name", UNSET)

        purposes = cast(list[str], d.pop("purposes", UNSET))

        register_passkey_request = cls(
            response=response,
            friendly_name=friendly_name,
            purposes=purposes,
        )

        register_passkey_request.additional_properties = d
        return register_passkey_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
