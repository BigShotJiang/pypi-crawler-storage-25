from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.profile_key_key_mode import ProfileKeyKeyMode
from ..models.profile_key_retired_reason import ProfileKeyRetiredReason
from ..models.profile_key_status import ProfileKeyStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="ProfileKey")


@_attrs_define
class ProfileKey:
    """
    Attributes:
        id (UUID):
        profile_id (UUID):
        key_fingerprint (str):
        did (str):
        verification_method (str):
        key_mode (ProfileKeyKeyMode):
        status (ProfileKeyStatus):
        active_from (datetime.datetime):
        retired_at (datetime.datetime | None | Unset):
        retired_reason (ProfileKeyRetiredReason | Unset):
    """

    id: UUID
    profile_id: UUID
    key_fingerprint: str
    did: str
    verification_method: str
    key_mode: ProfileKeyKeyMode
    status: ProfileKeyStatus
    active_from: datetime.datetime
    retired_at: datetime.datetime | None | Unset = UNSET
    retired_reason: ProfileKeyRetiredReason | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        profile_id = str(self.profile_id)

        key_fingerprint = self.key_fingerprint

        did = self.did

        verification_method = self.verification_method

        key_mode = self.key_mode.value

        status = self.status.value

        active_from = self.active_from.isoformat()

        retired_at: None | str | Unset
        if isinstance(self.retired_at, Unset):
            retired_at = UNSET
        elif isinstance(self.retired_at, datetime.datetime):
            retired_at = self.retired_at.isoformat()
        else:
            retired_at = self.retired_at

        retired_reason: str | Unset = UNSET
        if not isinstance(self.retired_reason, Unset):
            retired_reason = self.retired_reason.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "profile_id": profile_id,
                "key_fingerprint": key_fingerprint,
                "did": did,
                "verification_method": verification_method,
                "key_mode": key_mode,
                "status": status,
                "active_from": active_from,
            }
        )
        if retired_at is not UNSET:
            field_dict["retired_at"] = retired_at
        if retired_reason is not UNSET:
            field_dict["retired_reason"] = retired_reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        profile_id = UUID(d.pop("profile_id"))

        key_fingerprint = d.pop("key_fingerprint")

        did = d.pop("did")

        verification_method = d.pop("verification_method")

        key_mode = ProfileKeyKeyMode(d.pop("key_mode"))

        status = ProfileKeyStatus(d.pop("status"))

        active_from = isoparse(d.pop("active_from"))

        def _parse_retired_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                retired_at_type_0 = isoparse(data)

                return retired_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        retired_at = _parse_retired_at(d.pop("retired_at", UNSET))

        _retired_reason = d.pop("retired_reason", UNSET)
        retired_reason: ProfileKeyRetiredReason | Unset
        if isinstance(_retired_reason, Unset):
            retired_reason = UNSET
        else:
            retired_reason = ProfileKeyRetiredReason(_retired_reason)

        profile_key = cls(
            id=id,
            profile_id=profile_id,
            key_fingerprint=key_fingerprint,
            did=did,
            verification_method=verification_method,
            key_mode=key_mode,
            status=status,
            active_from=active_from,
            retired_at=retired_at,
            retired_reason=retired_reason,
        )

        profile_key.additional_properties = d
        return profile_key

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
