from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="StartRecoveryResponse200")


@_attrs_define
class StartRecoveryResponse200:
    """
    Attributes:
        started (bool):
        method (str | Unset):
        request_id (str | Unset): Present for device_approval method.
        nonce (str | Unset): Present for key_signing method.
    """

    started: bool
    method: str | Unset = UNSET
    request_id: str | Unset = UNSET
    nonce: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        started = self.started

        method = self.method

        request_id = self.request_id

        nonce = self.nonce

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "started": started,
            }
        )
        if method is not UNSET:
            field_dict["method"] = method
        if request_id is not UNSET:
            field_dict["request_id"] = request_id
        if nonce is not UNSET:
            field_dict["nonce"] = nonce

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        started = d.pop("started")

        method = d.pop("method", UNSET)

        request_id = d.pop("request_id", UNSET)

        nonce = d.pop("nonce", UNSET)

        start_recovery_response_200 = cls(
            started=started,
            method=method,
            request_id=request_id,
            nonce=nonce,
        )

        start_recovery_response_200.additional_properties = d
        return start_recovery_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
