from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PasskeyRegistrationOptionsResponse200AuthenticatorSelection")


@_attrs_define
class PasskeyRegistrationOptionsResponse200AuthenticatorSelection:
    """
    Attributes:
        resident_key (str | Unset):
        user_verification (str | Unset):
    """

    resident_key: str | Unset = UNSET
    user_verification: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        resident_key = self.resident_key

        user_verification = self.user_verification

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if resident_key is not UNSET:
            field_dict["residentKey"] = resident_key
        if user_verification is not UNSET:
            field_dict["userVerification"] = user_verification

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        resident_key = d.pop("residentKey", UNSET)

        user_verification = d.pop("userVerification", UNSET)

        passkey_registration_options_response_200_authenticator_selection = cls(
            resident_key=resident_key,
            user_verification=user_verification,
        )

        passkey_registration_options_response_200_authenticator_selection.additional_properties = d
        return passkey_registration_options_response_200_authenticator_selection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
