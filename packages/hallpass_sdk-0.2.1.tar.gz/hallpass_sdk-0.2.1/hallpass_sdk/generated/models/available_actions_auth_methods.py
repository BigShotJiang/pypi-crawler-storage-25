from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.auth_method_state import AuthMethodState


T = TypeVar("T", bound="AvailableActionsAuthMethods")


@_attrs_define
class AvailableActionsAuthMethods:
    """
    Attributes:
        password (AuthMethodState):
        passkey (AuthMethodState):
        cli_key (AuthMethodState):
    """

    password: AuthMethodState
    passkey: AuthMethodState
    cli_key: AuthMethodState
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        password = self.password.to_dict()

        passkey = self.passkey.to_dict()

        cli_key = self.cli_key.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "password": password,
                "passkey": passkey,
                "cli_key": cli_key,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_method_state import AuthMethodState

        d = dict(src_dict)
        password = AuthMethodState.from_dict(d.pop("password"))

        passkey = AuthMethodState.from_dict(d.pop("passkey"))

        cli_key = AuthMethodState.from_dict(d.pop("cli_key"))

        available_actions_auth_methods = cls(
            password=password,
            passkey=passkey,
            cli_key=cli_key,
        )

        available_actions_auth_methods.additional_properties = d
        return available_actions_auth_methods

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
