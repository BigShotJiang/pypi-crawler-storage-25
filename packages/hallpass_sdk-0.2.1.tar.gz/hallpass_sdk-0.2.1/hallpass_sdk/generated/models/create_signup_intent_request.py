from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateSignupIntentRequest")


@_attrs_define
class CreateSignupIntentRequest:
    """
    Attributes:
        user_profile_id (UUID): The profile ID of the user being signed up.
        service_domain (str): The domain of the service to sign up for.
        idempotency_key (str): Client-generated key for idempotent intent creation.
        scopes (list[str] | Unset): Requested permission scopes.
    """

    user_profile_id: UUID
    service_domain: str
    idempotency_key: str
    scopes: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_profile_id = str(self.user_profile_id)

        service_domain = self.service_domain

        idempotency_key = self.idempotency_key

        scopes: list[str] | Unset = UNSET
        if not isinstance(self.scopes, Unset):
            scopes = self.scopes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_profile_id": user_profile_id,
                "service_domain": service_domain,
                "idempotency_key": idempotency_key,
            }
        )
        if scopes is not UNSET:
            field_dict["scopes"] = scopes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_profile_id = UUID(d.pop("user_profile_id"))

        service_domain = d.pop("service_domain")

        idempotency_key = d.pop("idempotency_key")

        scopes = cast(list[str], d.pop("scopes", UNSET))

        create_signup_intent_request = cls(
            user_profile_id=user_profile_id,
            service_domain=service_domain,
            idempotency_key=idempotency_key,
            scopes=scopes,
        )

        create_signup_intent_request.additional_properties = d
        return create_signup_intent_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
