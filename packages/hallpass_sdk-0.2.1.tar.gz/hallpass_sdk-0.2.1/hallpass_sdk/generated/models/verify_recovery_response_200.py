from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VerifyRecoveryResponse200")


@_attrs_define
class VerifyRecoveryResponse200:
    """
    Attributes:
        verified (bool):
        profile_id (UUID | Unset): Present when verified is true.
        request_id (UUID | Unset): Present when verified is true. Pass to /recovery/complete.
        status (str | Unset): Present for device_approval (pending/approved/denied).
    """

    verified: bool
    profile_id: UUID | Unset = UNSET
    request_id: UUID | Unset = UNSET
    status: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        verified = self.verified

        profile_id: str | Unset = UNSET
        if not isinstance(self.profile_id, Unset):
            profile_id = str(self.profile_id)

        request_id: str | Unset = UNSET
        if not isinstance(self.request_id, Unset):
            request_id = str(self.request_id)

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "verified": verified,
            }
        )
        if profile_id is not UNSET:
            field_dict["profile_id"] = profile_id
        if request_id is not UNSET:
            field_dict["request_id"] = request_id
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        verified = d.pop("verified")

        _profile_id = d.pop("profile_id", UNSET)
        profile_id: UUID | Unset
        if isinstance(_profile_id, Unset):
            profile_id = UNSET
        else:
            profile_id = UUID(_profile_id)

        _request_id = d.pop("request_id", UNSET)
        request_id: UUID | Unset
        if isinstance(_request_id, Unset):
            request_id = UNSET
        else:
            request_id = UUID(_request_id)

        status = d.pop("status", UNSET)

        verify_recovery_response_200 = cls(
            verified=verified,
            profile_id=profile_id,
            request_id=request_id,
            status=status,
        )

        verify_recovery_response_200.additional_properties = d
        return verify_recovery_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
