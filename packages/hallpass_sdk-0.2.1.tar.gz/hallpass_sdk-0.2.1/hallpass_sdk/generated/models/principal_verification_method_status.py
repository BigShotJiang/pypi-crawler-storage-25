from enum import Enum


class PrincipalVerificationMethodStatus(str, Enum):
    ACTIVE = "active"
    RETIRED = "retired"
    REVOKED = "revoked"

    def __str__(self) -> str:
        return str(self.value)
