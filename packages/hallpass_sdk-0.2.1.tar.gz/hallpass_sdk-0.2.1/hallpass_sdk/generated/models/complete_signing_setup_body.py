from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.complete_signing_setup_body_public_jwk import CompleteSigningSetupBodyPublicJwk


T = TypeVar("T", bound="CompleteSigningSetupBody")


@_attrs_define
class CompleteSigningSetupBody:
    """
    Attributes:
        signing_setup_token (str):
        public_jwk (CompleteSigningSetupBodyPublicJwk):
    """

    signing_setup_token: str
    public_jwk: CompleteSigningSetupBodyPublicJwk
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        signing_setup_token = self.signing_setup_token

        public_jwk = self.public_jwk.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "signing_setup_token": signing_setup_token,
                "public_jwk": public_jwk,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.complete_signing_setup_body_public_jwk import CompleteSigningSetupBodyPublicJwk

        d = dict(src_dict)
        signing_setup_token = d.pop("signing_setup_token")

        public_jwk = CompleteSigningSetupBodyPublicJwk.from_dict(d.pop("public_jwk"))

        complete_signing_setup_body = cls(
            signing_setup_token=signing_setup_token,
            public_jwk=public_jwk,
        )

        complete_signing_setup_body.additional_properties = d
        return complete_signing_setup_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
