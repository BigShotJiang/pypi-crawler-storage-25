from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.available_actions_signing_current import AvailableActionsSigningCurrent

if TYPE_CHECKING:
    from ..models.action_entry import ActionEntry


T = TypeVar("T", bound="AvailableActionsSigning")


@_attrs_define
class AvailableActionsSigning:
    """
    Attributes:
        current (AvailableActionsSigningCurrent):
        switch (ActionEntry):
        rotate (ActionEntry):
    """

    current: AvailableActionsSigningCurrent
    switch: ActionEntry
    rotate: ActionEntry
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        current = self.current.value

        switch = self.switch.to_dict()

        rotate = self.rotate.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "current": current,
                "switch": switch,
                "rotate": rotate,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_entry import ActionEntry

        d = dict(src_dict)
        current = AvailableActionsSigningCurrent(d.pop("current"))

        switch = ActionEntry.from_dict(d.pop("switch"))

        rotate = ActionEntry.from_dict(d.pop("rotate"))

        available_actions_signing = cls(
            current=current,
            switch=switch,
            rotate=rotate,
        )

        available_actions_signing.additional_properties = d
        return available_actions_signing

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
