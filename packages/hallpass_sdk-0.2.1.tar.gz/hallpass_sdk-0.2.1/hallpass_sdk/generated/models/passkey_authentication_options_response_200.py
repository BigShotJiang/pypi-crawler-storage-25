from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.passkey_authentication_options_response_200_allow_credentials_item import (
        PasskeyAuthenticationOptionsResponse200AllowCredentialsItem,
    )


T = TypeVar("T", bound="PasskeyAuthenticationOptionsResponse200")


@_attrs_define
class PasskeyAuthenticationOptionsResponse200:
    """
    Attributes:
        challenge (str):
        rp_id (str | Unset):
        allow_credentials (list[PasskeyAuthenticationOptionsResponse200AllowCredentialsItem] | Unset):
        timeout (int | Unset):
        user_verification (str | Unset):
    """

    challenge: str
    rp_id: str | Unset = UNSET
    allow_credentials: list[PasskeyAuthenticationOptionsResponse200AllowCredentialsItem] | Unset = UNSET
    timeout: int | Unset = UNSET
    user_verification: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        challenge = self.challenge

        rp_id = self.rp_id

        allow_credentials: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.allow_credentials, Unset):
            allow_credentials = []
            for allow_credentials_item_data in self.allow_credentials:
                allow_credentials_item = allow_credentials_item_data.to_dict()
                allow_credentials.append(allow_credentials_item)

        timeout = self.timeout

        user_verification = self.user_verification

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "challenge": challenge,
            }
        )
        if rp_id is not UNSET:
            field_dict["rpId"] = rp_id
        if allow_credentials is not UNSET:
            field_dict["allowCredentials"] = allow_credentials
        if timeout is not UNSET:
            field_dict["timeout"] = timeout
        if user_verification is not UNSET:
            field_dict["userVerification"] = user_verification

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.passkey_authentication_options_response_200_allow_credentials_item import (
            PasskeyAuthenticationOptionsResponse200AllowCredentialsItem,
        )

        d = dict(src_dict)
        challenge = d.pop("challenge")

        rp_id = d.pop("rpId", UNSET)

        _allow_credentials = d.pop("allowCredentials", UNSET)
        allow_credentials: list[PasskeyAuthenticationOptionsResponse200AllowCredentialsItem] | Unset = UNSET
        if _allow_credentials is not UNSET:
            allow_credentials = []
            for allow_credentials_item_data in _allow_credentials:
                allow_credentials_item = PasskeyAuthenticationOptionsResponse200AllowCredentialsItem.from_dict(
                    allow_credentials_item_data
                )

                allow_credentials.append(allow_credentials_item)

        timeout = d.pop("timeout", UNSET)

        user_verification = d.pop("userVerification", UNSET)

        passkey_authentication_options_response_200 = cls(
            challenge=challenge,
            rp_id=rp_id,
            allow_credentials=allow_credentials,
            timeout=timeout,
            user_verification=user_verification,
        )

        passkey_authentication_options_response_200.additional_properties = d
        return passkey_authentication_options_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
