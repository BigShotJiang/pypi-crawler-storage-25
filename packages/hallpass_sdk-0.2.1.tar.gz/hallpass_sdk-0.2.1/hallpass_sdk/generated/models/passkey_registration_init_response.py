from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.passkey_registration_init_response_registration_options import (
        PasskeyRegistrationInitResponseRegistrationOptions,
    )


T = TypeVar("T", bound="PasskeyRegistrationInitResponse")


@_attrs_define
class PasskeyRegistrationInitResponse:
    """
    Attributes:
        registration_options (PasskeyRegistrationInitResponseRegistrationOptions): WebAuthn
            PublicKeyCredentialCreationOptions for the browser ceremony.
        passkey_session_token (str): Short-lived token (5 min) containing the WebAuthn challenge and user data.
    """

    registration_options: PasskeyRegistrationInitResponseRegistrationOptions
    passkey_session_token: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        registration_options = self.registration_options.to_dict()

        passkey_session_token = self.passkey_session_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "registration_options": registration_options,
                "passkey_session_token": passkey_session_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.passkey_registration_init_response_registration_options import (
            PasskeyRegistrationInitResponseRegistrationOptions,
        )

        d = dict(src_dict)
        registration_options = PasskeyRegistrationInitResponseRegistrationOptions.from_dict(
            d.pop("registration_options")
        )

        passkey_session_token = d.pop("passkey_session_token")

        passkey_registration_init_response = cls(
            registration_options=registration_options,
            passkey_session_token=passkey_session_token,
        )

        passkey_registration_init_response.additional_properties = d
        return passkey_registration_init_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
