from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CurrentVerificationContext")


@_attrs_define
class CurrentVerificationContext:
    """
    Attributes:
        principal_username (str | Unset):
        principal_profile_path (str | Unset):
        agent_username (str | Unset):
        agent_profile_path (str | Unset):
        agent_available (bool | Unset):
    """

    principal_username: str | Unset = UNSET
    principal_profile_path: str | Unset = UNSET
    agent_username: str | Unset = UNSET
    agent_profile_path: str | Unset = UNSET
    agent_available: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        principal_username = self.principal_username

        principal_profile_path = self.principal_profile_path

        agent_username = self.agent_username

        agent_profile_path = self.agent_profile_path

        agent_available = self.agent_available

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if principal_username is not UNSET:
            field_dict["principal_username"] = principal_username
        if principal_profile_path is not UNSET:
            field_dict["principal_profile_path"] = principal_profile_path
        if agent_username is not UNSET:
            field_dict["agent_username"] = agent_username
        if agent_profile_path is not UNSET:
            field_dict["agent_profile_path"] = agent_profile_path
        if agent_available is not UNSET:
            field_dict["agent_available"] = agent_available

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        principal_username = d.pop("principal_username", UNSET)

        principal_profile_path = d.pop("principal_profile_path", UNSET)

        agent_username = d.pop("agent_username", UNSET)

        agent_profile_path = d.pop("agent_profile_path", UNSET)

        agent_available = d.pop("agent_available", UNSET)

        current_verification_context = cls(
            principal_username=principal_username,
            principal_profile_path=principal_profile_path,
            agent_username=agent_username,
            agent_profile_path=agent_profile_path,
            agent_available=agent_available,
        )

        current_verification_context.additional_properties = d
        return current_verification_context

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
