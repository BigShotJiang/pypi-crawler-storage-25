from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.auth_profile import AuthProfile
    from ..models.profile_key import ProfileKey


T = TypeVar("T", bound="KeyRotationResponse")


@_attrs_define
class KeyRotationResponse:
    """
    Attributes:
        profile (AuthProfile):
        key (ProfileKey):
        revoked_count (int):
        redelegated_count (int):
    """

    profile: AuthProfile
    key: ProfileKey
    revoked_count: int
    redelegated_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        profile = self.profile.to_dict()

        key = self.key.to_dict()

        revoked_count = self.revoked_count

        redelegated_count = self.redelegated_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "profile": profile,
                "key": key,
                "revoked_count": revoked_count,
                "redelegated_count": redelegated_count,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_profile import AuthProfile
        from ..models.profile_key import ProfileKey

        d = dict(src_dict)
        profile = AuthProfile.from_dict(d.pop("profile"))

        key = ProfileKey.from_dict(d.pop("key"))

        revoked_count = d.pop("revoked_count")

        redelegated_count = d.pop("redelegated_count")

        key_rotation_response = cls(
            profile=profile,
            key=key,
            revoked_count=revoked_count,
            redelegated_count=redelegated_count,
        )

        key_rotation_response.additional_properties = d
        return key_rotation_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
