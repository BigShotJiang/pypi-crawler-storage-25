from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent import Agent
    from ..models.delegation import Delegation


T = TypeVar("T", bound="EnrollResponse201")


@_attrs_define
class EnrollResponse201:
    """
    Attributes:
        agent (Agent):
        delegation (Delegation | Unset):
    """

    agent: Agent
    delegation: Delegation | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent = self.agent.to_dict()

        delegation: dict[str, Any] | Unset = UNSET
        if not isinstance(self.delegation, Unset):
            delegation = self.delegation.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent": agent,
            }
        )
        if delegation is not UNSET:
            field_dict["delegation"] = delegation

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent import Agent
        from ..models.delegation import Delegation

        d = dict(src_dict)
        agent = Agent.from_dict(d.pop("agent"))

        _delegation = d.pop("delegation", UNSET)
        delegation: Delegation | Unset
        if isinstance(_delegation, Unset):
            delegation = UNSET
        else:
            delegation = Delegation.from_dict(_delegation)

        enroll_response_201 = cls(
            agent=agent,
            delegation=delegation,
        )

        enroll_response_201.additional_properties = d
        return enroll_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
