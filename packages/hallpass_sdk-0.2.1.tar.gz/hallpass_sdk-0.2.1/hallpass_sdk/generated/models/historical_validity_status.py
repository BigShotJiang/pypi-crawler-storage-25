from enum import Enum


class HistoricalValidityStatus(str, Enum):
    INVALID_WHEN_SIGNED = "invalid_when_signed"
    UNVERIFIABLE = "unverifiable"
    VALID_WHEN_SIGNED = "valid_when_signed"

    def __str__(self) -> str:
        return str(self.value)
