from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.service_detail_status import ServiceDetailStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="ServiceDetailWithSecret")


@_attrs_define
class ServiceDetailWithSecret:
    """
    Attributes:
        id (UUID):
        domain (str):
        status (ServiceDetailStatus):
        name (None | str | Unset):
        favicon_url (None | str | Unset):
        webhook_url (None | str | Unset):
        created_by_profile_id (None | Unset | UUID):
        inserted_at (datetime.datetime | None | Unset):
        updated_at (datetime.datetime | None | Unset):
        webhook_secret_set (bool | Unset): Whether a webhook signing secret has been configured.
        webhook_secret (None | str | Unset): Base64-encoded webhook signing secret. Only returned on service creation
            and secret rotation.
    """

    id: UUID
    domain: str
    status: ServiceDetailStatus
    name: None | str | Unset = UNSET
    favicon_url: None | str | Unset = UNSET
    webhook_url: None | str | Unset = UNSET
    created_by_profile_id: None | Unset | UUID = UNSET
    inserted_at: datetime.datetime | None | Unset = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    webhook_secret_set: bool | Unset = UNSET
    webhook_secret: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        domain = self.domain

        status = self.status.value

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        favicon_url: None | str | Unset
        if isinstance(self.favicon_url, Unset):
            favicon_url = UNSET
        else:
            favicon_url = self.favicon_url

        webhook_url: None | str | Unset
        if isinstance(self.webhook_url, Unset):
            webhook_url = UNSET
        else:
            webhook_url = self.webhook_url

        created_by_profile_id: None | str | Unset
        if isinstance(self.created_by_profile_id, Unset):
            created_by_profile_id = UNSET
        elif isinstance(self.created_by_profile_id, UUID):
            created_by_profile_id = str(self.created_by_profile_id)
        else:
            created_by_profile_id = self.created_by_profile_id

        inserted_at: None | str | Unset
        if isinstance(self.inserted_at, Unset):
            inserted_at = UNSET
        elif isinstance(self.inserted_at, datetime.datetime):
            inserted_at = self.inserted_at.isoformat()
        else:
            inserted_at = self.inserted_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        webhook_secret_set = self.webhook_secret_set

        webhook_secret: None | str | Unset
        if isinstance(self.webhook_secret, Unset):
            webhook_secret = UNSET
        else:
            webhook_secret = self.webhook_secret

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "domain": domain,
                "status": status,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if favicon_url is not UNSET:
            field_dict["favicon_url"] = favicon_url
        if webhook_url is not UNSET:
            field_dict["webhook_url"] = webhook_url
        if created_by_profile_id is not UNSET:
            field_dict["created_by_profile_id"] = created_by_profile_id
        if inserted_at is not UNSET:
            field_dict["inserted_at"] = inserted_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if webhook_secret_set is not UNSET:
            field_dict["webhook_secret_set"] = webhook_secret_set
        if webhook_secret is not UNSET:
            field_dict["webhook_secret"] = webhook_secret

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        domain = d.pop("domain")

        status = ServiceDetailStatus(d.pop("status"))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_favicon_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        favicon_url = _parse_favicon_url(d.pop("favicon_url", UNSET))

        def _parse_webhook_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        webhook_url = _parse_webhook_url(d.pop("webhook_url", UNSET))

        def _parse_created_by_profile_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_by_profile_id_type_0 = UUID(data)

                return created_by_profile_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        created_by_profile_id = _parse_created_by_profile_id(d.pop("created_by_profile_id", UNSET))

        def _parse_inserted_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                inserted_at_type_0 = isoparse(data)

                return inserted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        inserted_at = _parse_inserted_at(d.pop("inserted_at", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

        webhook_secret_set = d.pop("webhook_secret_set", UNSET)

        def _parse_webhook_secret(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        webhook_secret = _parse_webhook_secret(d.pop("webhook_secret", UNSET))

        service_detail_with_secret = cls(
            id=id,
            domain=domain,
            status=status,
            name=name,
            favicon_url=favicon_url,
            webhook_url=webhook_url,
            created_by_profile_id=created_by_profile_id,
            inserted_at=inserted_at,
            updated_at=updated_at,
            webhook_secret_set=webhook_secret_set,
            webhook_secret=webhook_secret,
        )

        service_detail_with_secret.additional_properties = d
        return service_detail_with_secret

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
