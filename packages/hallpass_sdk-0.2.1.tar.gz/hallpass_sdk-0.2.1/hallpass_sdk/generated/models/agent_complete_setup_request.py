from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_complete_setup_request_public_jwk import AgentCompleteSetupRequestPublicJwk


T = TypeVar("T", bound="AgentCompleteSetupRequest")


@_attrs_define
class AgentCompleteSetupRequest:
    """
    Attributes:
        setup_token (str):
        public_jwk (AgentCompleteSetupRequestPublicJwk):
        display_name (None | str | Unset):
        description (None | str | Unset):
    """

    setup_token: str
    public_jwk: AgentCompleteSetupRequestPublicJwk
    display_name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        setup_token = self.setup_token

        public_jwk = self.public_jwk.to_dict()

        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "setup_token": setup_token,
                "public_jwk": public_jwk,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_complete_setup_request_public_jwk import AgentCompleteSetupRequestPublicJwk

        d = dict(src_dict)
        setup_token = d.pop("setup_token")

        public_jwk = AgentCompleteSetupRequestPublicJwk.from_dict(d.pop("public_jwk"))

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("display_name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        agent_complete_setup_request = cls(
            setup_token=setup_token,
            public_jwk=public_jwk,
            display_name=display_name,
            description=description,
        )

        agent_complete_setup_request.additional_properties = d
        return agent_complete_setup_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
