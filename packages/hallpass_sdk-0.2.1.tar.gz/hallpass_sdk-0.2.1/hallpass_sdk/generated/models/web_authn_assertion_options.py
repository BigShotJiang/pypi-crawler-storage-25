from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.web_authn_assertion_options_user_verification import WebAuthnAssertionOptionsUserVerification

if TYPE_CHECKING:
    from ..models.web_authn_assertion_options_allow_credentials_item import WebAuthnAssertionOptionsAllowCredentialsItem


T = TypeVar("T", bound="WebAuthnAssertionOptions")


@_attrs_define
class WebAuthnAssertionOptions:
    """
    Attributes:
        challenge (str): Base64url-encoded challenge bytes
        rp_id (str):
        allow_credentials (list[WebAuthnAssertionOptionsAllowCredentialsItem]):
        timeout (int):
        user_verification (WebAuthnAssertionOptionsUserVerification):
    """

    challenge: str
    rp_id: str
    allow_credentials: list[WebAuthnAssertionOptionsAllowCredentialsItem]
    timeout: int
    user_verification: WebAuthnAssertionOptionsUserVerification
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        challenge = self.challenge

        rp_id = self.rp_id

        allow_credentials = []
        for allow_credentials_item_data in self.allow_credentials:
            allow_credentials_item = allow_credentials_item_data.to_dict()
            allow_credentials.append(allow_credentials_item)

        timeout = self.timeout

        user_verification = self.user_verification.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "challenge": challenge,
                "rpId": rp_id,
                "allowCredentials": allow_credentials,
                "timeout": timeout,
                "userVerification": user_verification,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.web_authn_assertion_options_allow_credentials_item import (
            WebAuthnAssertionOptionsAllowCredentialsItem,
        )

        d = dict(src_dict)
        challenge = d.pop("challenge")

        rp_id = d.pop("rpId")

        allow_credentials = []
        _allow_credentials = d.pop("allowCredentials")
        for allow_credentials_item_data in _allow_credentials:
            allow_credentials_item = WebAuthnAssertionOptionsAllowCredentialsItem.from_dict(allow_credentials_item_data)

            allow_credentials.append(allow_credentials_item)

        timeout = d.pop("timeout")

        user_verification = WebAuthnAssertionOptionsUserVerification(d.pop("userVerification"))

        web_authn_assertion_options = cls(
            challenge=challenge,
            rp_id=rp_id,
            allow_credentials=allow_credentials,
            timeout=timeout,
            user_verification=user_verification,
        )

        web_authn_assertion_options.additional_properties = d
        return web_authn_assertion_options

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
