from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="OAuthTokenRequest")


@_attrs_define
class OAuthTokenRequest:
    """
    Attributes:
        code (str):
        client_id (str):
        client_secret (str):
        redirect_uri (str):
        code_verifier (str | Unset):
    """

    code: str
    client_id: str
    client_secret: str
    redirect_uri: str
    code_verifier: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        code = self.code

        client_id = self.client_id

        client_secret = self.client_secret

        redirect_uri = self.redirect_uri

        code_verifier = self.code_verifier

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "code": code,
                "client_id": client_id,
                "client_secret": client_secret,
                "redirect_uri": redirect_uri,
            }
        )
        if code_verifier is not UNSET:
            field_dict["code_verifier"] = code_verifier

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        code = d.pop("code")

        client_id = d.pop("client_id")

        client_secret = d.pop("client_secret")

        redirect_uri = d.pop("redirect_uri")

        code_verifier = d.pop("code_verifier", UNSET)

        o_auth_token_request = cls(
            code=code,
            client_id=client_id,
            client_secret=client_secret,
            redirect_uri=redirect_uri,
            code_verifier=code_verifier,
        )

        o_auth_token_request.additional_properties = d
        return o_auth_token_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
