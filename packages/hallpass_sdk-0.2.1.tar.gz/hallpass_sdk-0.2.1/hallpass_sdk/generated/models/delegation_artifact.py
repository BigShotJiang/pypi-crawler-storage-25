from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.delegation_artifact_approval_source import DelegationArtifactApprovalSource
from ..models.delegation_artifact_proof_kind import DelegationArtifactProofKind

if TYPE_CHECKING:
    from ..models.delegation_artifact_payload import DelegationArtifactPayload


T = TypeVar("T", bound="DelegationArtifact")


@_attrs_define
class DelegationArtifact:
    """
    Attributes:
        payload (DelegationArtifactPayload): The canonical delegation JWT claims
        proof_kind (DelegationArtifactProofKind):
        approval_source (DelegationArtifactApprovalSource):
        principal_method_id (UUID):
        proof (Any): Compact JWS string (for jws) or object with clientDataJSON, authenticatorData, signature (for
            webauthn_assertion)
        payload_hash (str): base64url(sha256(canonical_json(payload)))
        delegation_jti (UUID):
    """

    payload: DelegationArtifactPayload
    proof_kind: DelegationArtifactProofKind
    approval_source: DelegationArtifactApprovalSource
    principal_method_id: UUID
    proof: Any
    payload_hash: str
    delegation_jti: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = self.payload.to_dict()

        proof_kind = self.proof_kind.value

        approval_source = self.approval_source.value

        principal_method_id = str(self.principal_method_id)

        proof = self.proof

        payload_hash = self.payload_hash

        delegation_jti = str(self.delegation_jti)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "payload": payload,
                "proof_kind": proof_kind,
                "approval_source": approval_source,
                "principal_method_id": principal_method_id,
                "proof": proof,
                "payload_hash": payload_hash,
                "delegation_jti": delegation_jti,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.delegation_artifact_payload import DelegationArtifactPayload

        d = dict(src_dict)
        payload = DelegationArtifactPayload.from_dict(d.pop("payload"))

        proof_kind = DelegationArtifactProofKind(d.pop("proof_kind"))

        approval_source = DelegationArtifactApprovalSource(d.pop("approval_source"))

        principal_method_id = UUID(d.pop("principal_method_id"))

        proof = d.pop("proof")

        payload_hash = d.pop("payload_hash")

        delegation_jti = UUID(d.pop("delegation_jti"))

        delegation_artifact = cls(
            payload=payload,
            proof_kind=proof_kind,
            approval_source=approval_source,
            principal_method_id=principal_method_id,
            proof=proof,
            payload_hash=payload_hash,
            delegation_jti=delegation_jti,
        )

        delegation_artifact.additional_properties = d
        return delegation_artifact

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
