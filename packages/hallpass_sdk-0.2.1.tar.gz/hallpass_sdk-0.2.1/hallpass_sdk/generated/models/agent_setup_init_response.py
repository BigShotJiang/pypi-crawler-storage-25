from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AgentSetupInitResponse")


@_attrs_define
class AgentSetupInitResponse:
    """
    Attributes:
        setup_token (str): Short-lived token (15 min) to pass to the CLI for agent setup completion.
        registration_id (UUID):
    """

    setup_token: str
    registration_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        setup_token = self.setup_token

        registration_id = str(self.registration_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "setup_token": setup_token,
                "registration_id": registration_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        setup_token = d.pop("setup_token")

        registration_id = UUID(d.pop("registration_id"))

        agent_setup_init_response = cls(
            setup_token=setup_token,
            registration_id=registration_id,
        )

        agent_setup_init_response.additional_properties = d
        return agent_setup_init_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
