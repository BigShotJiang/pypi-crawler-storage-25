from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.passkey_registration_options_response_200_authenticator_selection import (
        PasskeyRegistrationOptionsResponse200AuthenticatorSelection,
    )
    from ..models.passkey_registration_options_response_200_pub_key_cred_params_item import (
        PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem,
    )
    from ..models.passkey_registration_options_response_200_rp import PasskeyRegistrationOptionsResponse200Rp
    from ..models.passkey_registration_options_response_200_user import PasskeyRegistrationOptionsResponse200User


T = TypeVar("T", bound="PasskeyRegistrationOptionsResponse200")


@_attrs_define
class PasskeyRegistrationOptionsResponse200:
    """
    Attributes:
        challenge (str):
        rp (PasskeyRegistrationOptionsResponse200Rp):
        user (PasskeyRegistrationOptionsResponse200User):
        pub_key_cred_params (list[PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem]):
        authenticator_selection (PasskeyRegistrationOptionsResponse200AuthenticatorSelection | Unset):
        timeout (int | Unset):
        attestation (str | Unset):
    """

    challenge: str
    rp: PasskeyRegistrationOptionsResponse200Rp
    user: PasskeyRegistrationOptionsResponse200User
    pub_key_cred_params: list[PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem]
    authenticator_selection: PasskeyRegistrationOptionsResponse200AuthenticatorSelection | Unset = UNSET
    timeout: int | Unset = UNSET
    attestation: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        challenge = self.challenge

        rp = self.rp.to_dict()

        user = self.user.to_dict()

        pub_key_cred_params = []
        for pub_key_cred_params_item_data in self.pub_key_cred_params:
            pub_key_cred_params_item = pub_key_cred_params_item_data.to_dict()
            pub_key_cred_params.append(pub_key_cred_params_item)

        authenticator_selection: dict[str, Any] | Unset = UNSET
        if not isinstance(self.authenticator_selection, Unset):
            authenticator_selection = self.authenticator_selection.to_dict()

        timeout = self.timeout

        attestation = self.attestation

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "challenge": challenge,
                "rp": rp,
                "user": user,
                "pubKeyCredParams": pub_key_cred_params,
            }
        )
        if authenticator_selection is not UNSET:
            field_dict["authenticatorSelection"] = authenticator_selection
        if timeout is not UNSET:
            field_dict["timeout"] = timeout
        if attestation is not UNSET:
            field_dict["attestation"] = attestation

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.passkey_registration_options_response_200_authenticator_selection import (
            PasskeyRegistrationOptionsResponse200AuthenticatorSelection,
        )
        from ..models.passkey_registration_options_response_200_pub_key_cred_params_item import (
            PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem,
        )
        from ..models.passkey_registration_options_response_200_rp import PasskeyRegistrationOptionsResponse200Rp
        from ..models.passkey_registration_options_response_200_user import PasskeyRegistrationOptionsResponse200User

        d = dict(src_dict)
        challenge = d.pop("challenge")

        rp = PasskeyRegistrationOptionsResponse200Rp.from_dict(d.pop("rp"))

        user = PasskeyRegistrationOptionsResponse200User.from_dict(d.pop("user"))

        pub_key_cred_params = []
        _pub_key_cred_params = d.pop("pubKeyCredParams")
        for pub_key_cred_params_item_data in _pub_key_cred_params:
            pub_key_cred_params_item = PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem.from_dict(
                pub_key_cred_params_item_data
            )

            pub_key_cred_params.append(pub_key_cred_params_item)

        _authenticator_selection = d.pop("authenticatorSelection", UNSET)
        authenticator_selection: PasskeyRegistrationOptionsResponse200AuthenticatorSelection | Unset
        if isinstance(_authenticator_selection, Unset):
            authenticator_selection = UNSET
        else:
            authenticator_selection = PasskeyRegistrationOptionsResponse200AuthenticatorSelection.from_dict(
                _authenticator_selection
            )

        timeout = d.pop("timeout", UNSET)

        attestation = d.pop("attestation", UNSET)

        passkey_registration_options_response_200 = cls(
            challenge=challenge,
            rp=rp,
            user=user,
            pub_key_cred_params=pub_key_cred_params,
            authenticator_selection=authenticator_selection,
            timeout=timeout,
            attestation=attestation,
        )

        passkey_registration_options_response_200.additional_properties = d
        return passkey_registration_options_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
