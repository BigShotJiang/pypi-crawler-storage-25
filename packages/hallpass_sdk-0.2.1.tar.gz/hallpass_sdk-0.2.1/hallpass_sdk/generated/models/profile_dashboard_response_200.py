from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.auth_profile import AuthProfile
    from ..models.public_profile import PublicProfile


T = TypeVar("T", bound="ProfileDashboardResponse200")


@_attrs_define
class ProfileDashboardResponse200:
    """
    Attributes:
        profile (AuthProfile):
        public_profile (PublicProfile):
    """

    profile: AuthProfile
    public_profile: PublicProfile
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        profile = self.profile.to_dict()

        public_profile = self.public_profile.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "profile": profile,
                "public_profile": public_profile,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_profile import AuthProfile
        from ..models.public_profile import PublicProfile

        d = dict(src_dict)
        profile = AuthProfile.from_dict(d.pop("profile"))

        public_profile = PublicProfile.from_dict(d.pop("public_profile"))

        profile_dashboard_response_200 = cls(
            profile=profile,
            public_profile=public_profile,
        )

        profile_dashboard_response_200.additional_properties = d
        return profile_dashboard_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
