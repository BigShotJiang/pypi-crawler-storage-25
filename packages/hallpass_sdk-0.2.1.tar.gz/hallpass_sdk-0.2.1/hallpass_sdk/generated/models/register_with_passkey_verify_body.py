from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.register_with_passkey_verify_body_response import RegisterWithPasskeyVerifyBodyResponse


T = TypeVar("T", bound="RegisterWithPasskeyVerifyBody")


@_attrs_define
class RegisterWithPasskeyVerifyBody:
    """
    Attributes:
        passkey_session_token (str):
        response (RegisterWithPasskeyVerifyBodyResponse):
    """

    passkey_session_token: str
    response: RegisterWithPasskeyVerifyBodyResponse
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        passkey_session_token = self.passkey_session_token

        response = self.response.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "passkey_session_token": passkey_session_token,
                "response": response,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.register_with_passkey_verify_body_response import RegisterWithPasskeyVerifyBodyResponse

        d = dict(src_dict)
        passkey_session_token = d.pop("passkey_session_token")

        response = RegisterWithPasskeyVerifyBodyResponse.from_dict(d.pop("response"))

        register_with_passkey_verify_body = cls(
            passkey_session_token=passkey_session_token,
            response=response,
        )

        register_with_passkey_verify_body.additional_properties = d
        return register_with_passkey_verify_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
