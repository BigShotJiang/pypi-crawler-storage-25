from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_service_request_status import UpdateServiceRequestStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateServiceRequest")


@_attrs_define
class UpdateServiceRequest:
    """
    Attributes:
        name (str | Unset):
        webhook_url (str | Unset):
        status (UpdateServiceRequestStatus | Unset):
    """

    name: str | Unset = UNSET
    webhook_url: str | Unset = UNSET
    status: UpdateServiceRequestStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        webhook_url = self.webhook_url

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if webhook_url is not UNSET:
            field_dict["webhook_url"] = webhook_url
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        webhook_url = d.pop("webhook_url", UNSET)

        _status = d.pop("status", UNSET)
        status: UpdateServiceRequestStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = UpdateServiceRequestStatus(_status)

        update_service_request = cls(
            name=name,
            webhook_url=webhook_url,
            status=status,
        )

        update_service_request.additional_properties = d
        return update_service_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
