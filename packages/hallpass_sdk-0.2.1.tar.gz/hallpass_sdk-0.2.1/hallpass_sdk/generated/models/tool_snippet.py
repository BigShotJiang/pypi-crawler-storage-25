from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ToolSnippet")


@_attrs_define
class ToolSnippet:
    """
    Attributes:
        label (str):
        install (str):
        package_name (str):
        docs_url (str):
        generate (str):
        sign_challenge (str):
    """

    label: str
    install: str
    package_name: str
    docs_url: str
    generate: str
    sign_challenge: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        label = self.label

        install = self.install

        package_name = self.package_name

        docs_url = self.docs_url

        generate = self.generate

        sign_challenge = self.sign_challenge

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "label": label,
                "install": install,
                "package_name": package_name,
                "docs_url": docs_url,
                "generate": generate,
                "sign_challenge": sign_challenge,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        label = d.pop("label")

        install = d.pop("install")

        package_name = d.pop("package_name")

        docs_url = d.pop("docs_url")

        generate = d.pop("generate")

        sign_challenge = d.pop("sign_challenge")

        tool_snippet = cls(
            label=label,
            install=install,
            package_name=package_name,
            docs_url=docs_url,
            generate=generate,
            sign_challenge=sign_challenge,
        )

        tool_snippet.additional_properties = d
        return tool_snippet

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
