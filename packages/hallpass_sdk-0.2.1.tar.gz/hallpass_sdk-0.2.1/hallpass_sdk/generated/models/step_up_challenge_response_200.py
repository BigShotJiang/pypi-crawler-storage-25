from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.step_up_challenge_response_200_webauthn import StepUpChallengeResponse200Webauthn


T = TypeVar("T", bound="StepUpChallengeResponse200")


@_attrs_define
class StepUpChallengeResponse200:
    """
    Attributes:
        nonce (str): Nonce to be signed for CLI key step-up.
        webauthn (StepUpChallengeResponse200Webauthn | Unset): WebAuthn authentication challenge options (present only
            if user has passkeys).
    """

    nonce: str
    webauthn: StepUpChallengeResponse200Webauthn | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        nonce = self.nonce

        webauthn: dict[str, Any] | Unset = UNSET
        if not isinstance(self.webauthn, Unset):
            webauthn = self.webauthn.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "nonce": nonce,
            }
        )
        if webauthn is not UNSET:
            field_dict["webauthn"] = webauthn

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.step_up_challenge_response_200_webauthn import StepUpChallengeResponse200Webauthn

        d = dict(src_dict)
        nonce = d.pop("nonce")

        _webauthn = d.pop("webauthn", UNSET)
        webauthn: StepUpChallengeResponse200Webauthn | Unset
        if isinstance(_webauthn, Unset):
            webauthn = UNSET
        else:
            webauthn = StepUpChallengeResponse200Webauthn.from_dict(_webauthn)

        step_up_challenge_response_200 = cls(
            nonce=nonce,
            webauthn=webauthn,
        )

        step_up_challenge_response_200.additional_properties = d
        return step_up_challenge_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
