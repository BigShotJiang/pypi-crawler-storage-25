from enum import Enum


class StepUpRequiredErrorError(str, Enum):
    STEP_UP_REQUIRED = "step_up_required"

    def __str__(self) -> str:
        return str(self.value)
