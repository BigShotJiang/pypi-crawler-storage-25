from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.session_check_response_200_profile import SessionCheckResponse200Profile


T = TypeVar("T", bound="SessionCheckResponse200")


@_attrs_define
class SessionCheckResponse200:
    """
    Attributes:
        authenticated (bool):
        profile (SessionCheckResponse200Profile | Unset):
    """

    authenticated: bool
    profile: SessionCheckResponse200Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        authenticated = self.authenticated

        profile: dict[str, Any] | Unset = UNSET
        if not isinstance(self.profile, Unset):
            profile = self.profile.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "authenticated": authenticated,
            }
        )
        if profile is not UNSET:
            field_dict["profile"] = profile

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.session_check_response_200_profile import SessionCheckResponse200Profile

        d = dict(src_dict)
        authenticated = d.pop("authenticated")

        _profile = d.pop("profile", UNSET)
        profile: SessionCheckResponse200Profile | Unset
        if isinstance(_profile, Unset):
            profile = UNSET
        else:
            profile = SessionCheckResponse200Profile.from_dict(_profile)

        session_check_response_200 = cls(
            authenticated=authenticated,
            profile=profile,
        )

        session_check_response_200.additional_properties = d
        return session_check_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
