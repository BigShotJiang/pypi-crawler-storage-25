from enum import Enum


class PrincipalVerificationMethodMethodType(str, Enum):
    JWK_ES256 = "jwk_es256"
    WEBAUTHN = "webauthn"

    def __str__(self) -> str:
        return str(self.value)
