from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.verify_recovery_body_method import VerifyRecoveryBodyMethod
from ..types import UNSET, Unset

T = TypeVar("T", bound="VerifyRecoveryBody")


@_attrs_define
class VerifyRecoveryBody:
    """
    Attributes:
        method (VerifyRecoveryBodyMethod):
        username (str | Unset): Required for recovery_code and key_signing.
        code (str | Unset): Required for recovery_code method.
        token (str | Unset): Required for email method.
        proof_data (str | Unset): Required for key_signing method.
        request_id (str | Unset): Required for device_approval method.
    """

    method: VerifyRecoveryBodyMethod
    username: str | Unset = UNSET
    code: str | Unset = UNSET
    token: str | Unset = UNSET
    proof_data: str | Unset = UNSET
    request_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        method = self.method.value

        username = self.username

        code = self.code

        token = self.token

        proof_data = self.proof_data

        request_id = self.request_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "method": method,
            }
        )
        if username is not UNSET:
            field_dict["username"] = username
        if code is not UNSET:
            field_dict["code"] = code
        if token is not UNSET:
            field_dict["token"] = token
        if proof_data is not UNSET:
            field_dict["proof_data"] = proof_data
        if request_id is not UNSET:
            field_dict["request_id"] = request_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        method = VerifyRecoveryBodyMethod(d.pop("method"))

        username = d.pop("username", UNSET)

        code = d.pop("code", UNSET)

        token = d.pop("token", UNSET)

        proof_data = d.pop("proof_data", UNSET)

        request_id = d.pop("request_id", UNSET)

        verify_recovery_body = cls(
            method=method,
            username=username,
            code=code,
            token=token,
            proof_data=proof_data,
            request_id=request_id,
        )

        verify_recovery_body.additional_properties = d
        return verify_recovery_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
