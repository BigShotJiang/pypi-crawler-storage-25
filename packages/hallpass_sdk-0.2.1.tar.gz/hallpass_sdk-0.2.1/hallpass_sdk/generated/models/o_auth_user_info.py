from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.o_auth_user_info_attestations_item import OAuthUserInfoAttestationsItem


T = TypeVar("T", bound="OAuthUserInfo")


@_attrs_define
class OAuthUserInfo:
    """
    Attributes:
        sub (UUID):
        username (str):
        did (str):
        attestations (list[OAuthUserInfoAttestationsItem]):
        display_name (None | str | Unset):
        avatar_url (None | str | Unset):
    """

    sub: UUID
    username: str
    did: str
    attestations: list[OAuthUserInfoAttestationsItem]
    display_name: None | str | Unset = UNSET
    avatar_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        sub = str(self.sub)

        username = self.username

        did = self.did

        attestations = []
        for attestations_item_data in self.attestations:
            attestations_item = attestations_item_data.to_dict()
            attestations.append(attestations_item)

        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        avatar_url: None | str | Unset
        if isinstance(self.avatar_url, Unset):
            avatar_url = UNSET
        else:
            avatar_url = self.avatar_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "sub": sub,
                "username": username,
                "did": did,
                "attestations": attestations,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if avatar_url is not UNSET:
            field_dict["avatar_url"] = avatar_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.o_auth_user_info_attestations_item import OAuthUserInfoAttestationsItem

        d = dict(src_dict)
        sub = UUID(d.pop("sub"))

        username = d.pop("username")

        did = d.pop("did")

        attestations = []
        _attestations = d.pop("attestations")
        for attestations_item_data in _attestations:
            attestations_item = OAuthUserInfoAttestationsItem.from_dict(attestations_item_data)

            attestations.append(attestations_item)

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("display_name", UNSET))

        def _parse_avatar_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        avatar_url = _parse_avatar_url(d.pop("avatar_url", UNSET))

        o_auth_user_info = cls(
            sub=sub,
            username=username,
            did=did,
            attestations=attestations,
            display_name=display_name,
            avatar_url=avatar_url,
        )

        o_auth_user_info.additional_properties = d
        return o_auth_user_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
