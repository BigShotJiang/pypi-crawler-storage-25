from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="KeyLoginVerifyBody")


@_attrs_define
class KeyLoginVerifyBody:
    """
    Attributes:
        challenge_token (str): The challenge_token from the key-login initiation step
        challenge_jws (str): Compact JWS containing the nonce, signed with the profile's private key
        handoff_token (str | Unset): Optional socket token for web login handoff broadcast
    """

    challenge_token: str
    challenge_jws: str
    handoff_token: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        challenge_token = self.challenge_token

        challenge_jws = self.challenge_jws

        handoff_token = self.handoff_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "challenge_token": challenge_token,
                "challenge_jws": challenge_jws,
            }
        )
        if handoff_token is not UNSET:
            field_dict["handoff_token"] = handoff_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        challenge_token = d.pop("challenge_token")

        challenge_jws = d.pop("challenge_jws")

        handoff_token = d.pop("handoff_token", UNSET)

        key_login_verify_body = cls(
            challenge_token=challenge_token,
            challenge_jws=challenge_jws,
            handoff_token=handoff_token,
        )

        key_login_verify_body.additional_properties = d
        return key_login_verify_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
