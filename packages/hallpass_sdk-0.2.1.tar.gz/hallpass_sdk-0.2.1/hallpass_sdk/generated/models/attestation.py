from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="Attestation")


@_attrs_define
class Attestation:
    """
    Attributes:
        id (UUID):
        profile_id (UUID):
        kind (str):
        value (str):
        verification_method (str):
        verification_token (str):
        status (str):
        kind_label (str | Unset):
        value_label (str | Unset):
        value_help (str | Unset):
        verification_method_label (str | Unset):
        verification_path (None | str | Unset):
        verification_target_label (str | Unset):
        verification_target (str | Unset):
        verification_instructions (str | Unset):
        verified_at (datetime.datetime | None | Unset):
        failure_reason (None | str | Unset):
        last_verification_attempt_at (datetime.datetime | None | Unset):
        provider_uid (None | str | Unset):
        proof_url (None | str | Unset): URL of the public proof (tweet, gist, domain, or Bluesky profile). Independently
            verifiable by anyone.
        last_reverified_at (datetime.datetime | None | Unset):
        reverification_failures (int | Unset):
    """

    id: UUID
    profile_id: UUID
    kind: str
    value: str
    verification_method: str
    verification_token: str
    status: str
    kind_label: str | Unset = UNSET
    value_label: str | Unset = UNSET
    value_help: str | Unset = UNSET
    verification_method_label: str | Unset = UNSET
    verification_path: None | str | Unset = UNSET
    verification_target_label: str | Unset = UNSET
    verification_target: str | Unset = UNSET
    verification_instructions: str | Unset = UNSET
    verified_at: datetime.datetime | None | Unset = UNSET
    failure_reason: None | str | Unset = UNSET
    last_verification_attempt_at: datetime.datetime | None | Unset = UNSET
    provider_uid: None | str | Unset = UNSET
    proof_url: None | str | Unset = UNSET
    last_reverified_at: datetime.datetime | None | Unset = UNSET
    reverification_failures: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        profile_id = str(self.profile_id)

        kind = self.kind

        value = self.value

        verification_method = self.verification_method

        verification_token = self.verification_token

        status = self.status

        kind_label = self.kind_label

        value_label = self.value_label

        value_help = self.value_help

        verification_method_label = self.verification_method_label

        verification_path: None | str | Unset
        if isinstance(self.verification_path, Unset):
            verification_path = UNSET
        else:
            verification_path = self.verification_path

        verification_target_label = self.verification_target_label

        verification_target = self.verification_target

        verification_instructions = self.verification_instructions

        verified_at: None | str | Unset
        if isinstance(self.verified_at, Unset):
            verified_at = UNSET
        elif isinstance(self.verified_at, datetime.datetime):
            verified_at = self.verified_at.isoformat()
        else:
            verified_at = self.verified_at

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        last_verification_attempt_at: None | str | Unset
        if isinstance(self.last_verification_attempt_at, Unset):
            last_verification_attempt_at = UNSET
        elif isinstance(self.last_verification_attempt_at, datetime.datetime):
            last_verification_attempt_at = self.last_verification_attempt_at.isoformat()
        else:
            last_verification_attempt_at = self.last_verification_attempt_at

        provider_uid: None | str | Unset
        if isinstance(self.provider_uid, Unset):
            provider_uid = UNSET
        else:
            provider_uid = self.provider_uid

        proof_url: None | str | Unset
        if isinstance(self.proof_url, Unset):
            proof_url = UNSET
        else:
            proof_url = self.proof_url

        last_reverified_at: None | str | Unset
        if isinstance(self.last_reverified_at, Unset):
            last_reverified_at = UNSET
        elif isinstance(self.last_reverified_at, datetime.datetime):
            last_reverified_at = self.last_reverified_at.isoformat()
        else:
            last_reverified_at = self.last_reverified_at

        reverification_failures = self.reverification_failures

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "profile_id": profile_id,
                "kind": kind,
                "value": value,
                "verification_method": verification_method,
                "verification_token": verification_token,
                "status": status,
            }
        )
        if kind_label is not UNSET:
            field_dict["kind_label"] = kind_label
        if value_label is not UNSET:
            field_dict["value_label"] = value_label
        if value_help is not UNSET:
            field_dict["value_help"] = value_help
        if verification_method_label is not UNSET:
            field_dict["verification_method_label"] = verification_method_label
        if verification_path is not UNSET:
            field_dict["verification_path"] = verification_path
        if verification_target_label is not UNSET:
            field_dict["verification_target_label"] = verification_target_label
        if verification_target is not UNSET:
            field_dict["verification_target"] = verification_target
        if verification_instructions is not UNSET:
            field_dict["verification_instructions"] = verification_instructions
        if verified_at is not UNSET:
            field_dict["verified_at"] = verified_at
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if last_verification_attempt_at is not UNSET:
            field_dict["last_verification_attempt_at"] = last_verification_attempt_at
        if provider_uid is not UNSET:
            field_dict["provider_uid"] = provider_uid
        if proof_url is not UNSET:
            field_dict["proof_url"] = proof_url
        if last_reverified_at is not UNSET:
            field_dict["last_reverified_at"] = last_reverified_at
        if reverification_failures is not UNSET:
            field_dict["reverification_failures"] = reverification_failures

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        profile_id = UUID(d.pop("profile_id"))

        kind = d.pop("kind")

        value = d.pop("value")

        verification_method = d.pop("verification_method")

        verification_token = d.pop("verification_token")

        status = d.pop("status")

        kind_label = d.pop("kind_label", UNSET)

        value_label = d.pop("value_label", UNSET)

        value_help = d.pop("value_help", UNSET)

        verification_method_label = d.pop("verification_method_label", UNSET)

        def _parse_verification_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        verification_path = _parse_verification_path(d.pop("verification_path", UNSET))

        verification_target_label = d.pop("verification_target_label", UNSET)

        verification_target = d.pop("verification_target", UNSET)

        verification_instructions = d.pop("verification_instructions", UNSET)

        def _parse_verified_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                verified_at_type_0 = isoparse(data)

                return verified_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        verified_at = _parse_verified_at(d.pop("verified_at", UNSET))

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))

        def _parse_last_verification_attempt_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_verification_attempt_at_type_0 = isoparse(data)

                return last_verification_attempt_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_verification_attempt_at = _parse_last_verification_attempt_at(d.pop("last_verification_attempt_at", UNSET))

        def _parse_provider_uid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_uid = _parse_provider_uid(d.pop("provider_uid", UNSET))

        def _parse_proof_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        proof_url = _parse_proof_url(d.pop("proof_url", UNSET))

        def _parse_last_reverified_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_reverified_at_type_0 = isoparse(data)

                return last_reverified_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_reverified_at = _parse_last_reverified_at(d.pop("last_reverified_at", UNSET))

        reverification_failures = d.pop("reverification_failures", UNSET)

        attestation = cls(
            id=id,
            profile_id=profile_id,
            kind=kind,
            value=value,
            verification_method=verification_method,
            verification_token=verification_token,
            status=status,
            kind_label=kind_label,
            value_label=value_label,
            value_help=value_help,
            verification_method_label=verification_method_label,
            verification_path=verification_path,
            verification_target_label=verification_target_label,
            verification_target=verification_target,
            verification_instructions=verification_instructions,
            verified_at=verified_at,
            failure_reason=failure_reason,
            last_verification_attempt_at=last_verification_attempt_at,
            provider_uid=provider_uid,
            proof_url=proof_url,
            last_reverified_at=last_reverified_at,
            reverification_failures=reverification_failures,
        )

        attestation.additional_properties = d
        return attestation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
