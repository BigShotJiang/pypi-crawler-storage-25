from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ServiceSignupRequest")


@_attrs_define
class ServiceSignupRequest:
    """
    Attributes:
        service_name (str):
        service_url (str):
        account_id (str | Unset):
        callback_url (str | Unset):
    """

    service_name: str
    service_url: str
    account_id: str | Unset = UNSET
    callback_url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        service_name = self.service_name

        service_url = self.service_url

        account_id = self.account_id

        callback_url = self.callback_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "service_name": service_name,
                "service_url": service_url,
            }
        )
        if account_id is not UNSET:
            field_dict["account_id"] = account_id
        if callback_url is not UNSET:
            field_dict["callback_url"] = callback_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        service_name = d.pop("service_name")

        service_url = d.pop("service_url")

        account_id = d.pop("account_id", UNSET)

        callback_url = d.pop("callback_url", UNSET)

        service_signup_request = cls(
            service_name=service_name,
            service_url=service_url,
            account_id=account_id,
            callback_url=callback_url,
        )

        service_signup_request.additional_properties = d
        return service_signup_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
