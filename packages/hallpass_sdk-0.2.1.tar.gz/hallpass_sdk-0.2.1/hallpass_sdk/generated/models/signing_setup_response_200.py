from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.signing_setup_response_200_signing_mode import SigningSetupResponse200SigningMode

T = TypeVar("T", bound="SigningSetupResponse200")


@_attrs_define
class SigningSetupResponse200:
    """
    Attributes:
        ok (bool):
        signing_mode (SigningSetupResponse200SigningMode):
    """

    ok: bool
    signing_mode: SigningSetupResponse200SigningMode
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ok = self.ok

        signing_mode = self.signing_mode.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ok": ok,
                "signing_mode": signing_mode,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ok = d.pop("ok")

        signing_mode = SigningSetupResponse200SigningMode(d.pop("signing_mode"))

        signing_setup_response_200 = cls(
            ok=ok,
            signing_mode=signing_mode,
        )

        signing_setup_response_200.additional_properties = d
        return signing_setup_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
