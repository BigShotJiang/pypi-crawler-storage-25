from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem")


@_attrs_define
class PasskeyRegistrationOptionsResponse200PubKeyCredParamsItem:
    """
    Attributes:
        type_ (str):
        alg (int):
    """

    type_: str
    alg: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        alg = self.alg

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "alg": alg,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type")

        alg = d.pop("alg")

        passkey_registration_options_response_200_pub_key_cred_params_item = cls(
            type_=type_,
            alg=alg,
        )

        passkey_registration_options_response_200_pub_key_cred_params_item.additional_properties = d
        return passkey_registration_options_response_200_pub_key_cred_params_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
