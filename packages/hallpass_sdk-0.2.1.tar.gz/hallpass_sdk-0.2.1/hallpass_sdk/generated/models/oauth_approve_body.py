from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="OauthApproveBody")


@_attrs_define
class OauthApproveBody:
    """
    Attributes:
        client_id (str):
        redirect_uri (str):
        state (str | Unset):
        code_challenge (str | Unset):
        code_challenge_method (str | Unset):
    """

    client_id: str
    redirect_uri: str
    state: str | Unset = UNSET
    code_challenge: str | Unset = UNSET
    code_challenge_method: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        client_id = self.client_id

        redirect_uri = self.redirect_uri

        state = self.state

        code_challenge = self.code_challenge

        code_challenge_method = self.code_challenge_method

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "client_id": client_id,
                "redirect_uri": redirect_uri,
            }
        )
        if state is not UNSET:
            field_dict["state"] = state
        if code_challenge is not UNSET:
            field_dict["code_challenge"] = code_challenge
        if code_challenge_method is not UNSET:
            field_dict["code_challenge_method"] = code_challenge_method

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        client_id = d.pop("client_id")

        redirect_uri = d.pop("redirect_uri")

        state = d.pop("state", UNSET)

        code_challenge = d.pop("code_challenge", UNSET)

        code_challenge_method = d.pop("code_challenge_method", UNSET)

        oauth_approve_body = cls(
            client_id=client_id,
            redirect_uri=redirect_uri,
            state=state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
        )

        oauth_approve_body.additional_properties = d
        return oauth_approve_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
