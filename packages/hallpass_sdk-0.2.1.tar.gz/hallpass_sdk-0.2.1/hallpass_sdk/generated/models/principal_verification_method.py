from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.principal_verification_method_custody import PrincipalVerificationMethodCustody
from ..models.principal_verification_method_method_type import PrincipalVerificationMethodMethodType
from ..models.principal_verification_method_status import PrincipalVerificationMethodStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.principal_verification_method_public_key_material import PrincipalVerificationMethodPublicKeyMaterial


T = TypeVar("T", bound="PrincipalVerificationMethod")


@_attrs_define
class PrincipalVerificationMethod:
    """
    Attributes:
        id (UUID):
        method_type (PrincipalVerificationMethodMethodType):
        custody (PrincipalVerificationMethodCustody):
        alg (str):  Default: 'ES256'.
        public_key_material (PrincipalVerificationMethodPublicKeyMaterial): JWK map for the public key
        status (PrincipalVerificationMethodStatus):
        method_scope (str | Unset):  Default: 'principal_delegation'.
        key_fingerprint (None | str | Unset):
        added_at (datetime.datetime | Unset):
    """

    id: UUID
    method_type: PrincipalVerificationMethodMethodType
    custody: PrincipalVerificationMethodCustody
    public_key_material: PrincipalVerificationMethodPublicKeyMaterial
    status: PrincipalVerificationMethodStatus
    alg: str = "ES256"
    method_scope: str | Unset = "principal_delegation"
    key_fingerprint: None | str | Unset = UNSET
    added_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        method_type = self.method_type.value

        custody = self.custody.value

        alg = self.alg

        public_key_material = self.public_key_material.to_dict()

        status = self.status.value

        method_scope = self.method_scope

        key_fingerprint: None | str | Unset
        if isinstance(self.key_fingerprint, Unset):
            key_fingerprint = UNSET
        else:
            key_fingerprint = self.key_fingerprint

        added_at: str | Unset = UNSET
        if not isinstance(self.added_at, Unset):
            added_at = self.added_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "method_type": method_type,
                "custody": custody,
                "alg": alg,
                "public_key_material": public_key_material,
                "status": status,
            }
        )
        if method_scope is not UNSET:
            field_dict["method_scope"] = method_scope
        if key_fingerprint is not UNSET:
            field_dict["key_fingerprint"] = key_fingerprint
        if added_at is not UNSET:
            field_dict["added_at"] = added_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.principal_verification_method_public_key_material import (
            PrincipalVerificationMethodPublicKeyMaterial,
        )

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        method_type = PrincipalVerificationMethodMethodType(d.pop("method_type"))

        custody = PrincipalVerificationMethodCustody(d.pop("custody"))

        alg = d.pop("alg")

        public_key_material = PrincipalVerificationMethodPublicKeyMaterial.from_dict(d.pop("public_key_material"))

        status = PrincipalVerificationMethodStatus(d.pop("status"))

        method_scope = d.pop("method_scope", UNSET)

        def _parse_key_fingerprint(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        key_fingerprint = _parse_key_fingerprint(d.pop("key_fingerprint", UNSET))

        _added_at = d.pop("added_at", UNSET)
        added_at: datetime.datetime | Unset
        if isinstance(_added_at, Unset):
            added_at = UNSET
        else:
            added_at = isoparse(_added_at)

        principal_verification_method = cls(
            id=id,
            method_type=method_type,
            custody=custody,
            alg=alg,
            public_key_material=public_key_material,
            status=status,
            method_scope=method_scope,
            key_fingerprint=key_fingerprint,
            added_at=added_at,
        )

        principal_verification_method.additional_properties = d
        return principal_verification_method

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
