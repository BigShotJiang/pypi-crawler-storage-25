from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.agent import Agent


T = TypeVar("T", bound="AgentCompleteSetupResponse201")


@_attrs_define
class AgentCompleteSetupResponse201:
    """
    Attributes:
        agent (Agent):
        challenge_token (str):
    """

    agent: Agent
    challenge_token: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent = self.agent.to_dict()

        challenge_token = self.challenge_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent": agent,
                "challenge_token": challenge_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent import Agent

        d = dict(src_dict)
        agent = Agent.from_dict(d.pop("agent"))

        challenge_token = d.pop("challenge_token")

        agent_complete_setup_response_201 = cls(
            agent=agent,
            challenge_token=challenge_token,
        )

        agent_complete_setup_response_201.additional_properties = d
        return agent_complete_setup_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
