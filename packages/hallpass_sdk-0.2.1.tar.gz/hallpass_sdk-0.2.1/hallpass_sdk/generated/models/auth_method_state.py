from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.auth_method_state_status import AuthMethodStateStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_entry import ActionEntry


T = TypeVar("T", bound="AuthMethodState")


@_attrs_define
class AuthMethodState:
    """
    Attributes:
        status (AuthMethodStateStatus):
        add (ActionEntry | Unset):
        remove (ActionEntry | Unset):
        change (ActionEntry | Unset):
    """

    status: AuthMethodStateStatus
    add: ActionEntry | Unset = UNSET
    remove: ActionEntry | Unset = UNSET
    change: ActionEntry | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        add: dict[str, Any] | Unset = UNSET
        if not isinstance(self.add, Unset):
            add = self.add.to_dict()

        remove: dict[str, Any] | Unset = UNSET
        if not isinstance(self.remove, Unset):
            remove = self.remove.to_dict()

        change: dict[str, Any] | Unset = UNSET
        if not isinstance(self.change, Unset):
            change = self.change.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )
        if add is not UNSET:
            field_dict["add"] = add
        if remove is not UNSET:
            field_dict["remove"] = remove
        if change is not UNSET:
            field_dict["change"] = change

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_entry import ActionEntry

        d = dict(src_dict)
        status = AuthMethodStateStatus(d.pop("status"))

        _add = d.pop("add", UNSET)
        add: ActionEntry | Unset
        if isinstance(_add, Unset):
            add = UNSET
        else:
            add = ActionEntry.from_dict(_add)

        _remove = d.pop("remove", UNSET)
        remove: ActionEntry | Unset
        if isinstance(_remove, Unset):
            remove = UNSET
        else:
            remove = ActionEntry.from_dict(_remove)

        _change = d.pop("change", UNSET)
        change: ActionEntry | Unset
        if isinstance(_change, Unset):
            change = UNSET
        else:
            change = ActionEntry.from_dict(_change)

        auth_method_state = cls(
            status=status,
            add=add,
            remove=remove,
            change=change,
        )

        auth_method_state.additional_properties = d
        return auth_method_state

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
