from enum import Enum


class AuthMethodStateStatus(str, Enum):
    ACTIVE = "active"
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
