from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.public_profile_key_mode import PublicProfileKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.attestation import Attestation
    from ..models.parent_profile_summary import ParentProfileSummary
    from ..models.principal_verification_method import PrincipalVerificationMethod
    from ..models.profile_agent import ProfileAgent


T = TypeVar("T", bound="PublicProfile")


@_attrs_define
class PublicProfile:
    """
    Attributes:
        username (str):
        display_name (None | str):
        attestations (list[Attestation]):
        agents (list[ProfileAgent]):
        description (None | str | Unset):
        avatar_url (None | str | Unset):
        key_mode (PublicProfileKeyMode | Unset):
        has_passkey (bool | Unset):
        parent_profile (None | ParentProfileSummary | Unset):
        principal_verification_methods (list[PrincipalVerificationMethod] | Unset):
    """

    username: str
    display_name: None | str
    attestations: list[Attestation]
    agents: list[ProfileAgent]
    description: None | str | Unset = UNSET
    avatar_url: None | str | Unset = UNSET
    key_mode: PublicProfileKeyMode | Unset = UNSET
    has_passkey: bool | Unset = UNSET
    parent_profile: None | ParentProfileSummary | Unset = UNSET
    principal_verification_methods: list[PrincipalVerificationMethod] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.parent_profile_summary import ParentProfileSummary

        username = self.username

        display_name: None | str
        display_name = self.display_name

        attestations = []
        for attestations_item_data in self.attestations:
            attestations_item = attestations_item_data.to_dict()
            attestations.append(attestations_item)

        agents = []
        for agents_item_data in self.agents:
            agents_item = agents_item_data.to_dict()
            agents.append(agents_item)

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        avatar_url: None | str | Unset
        if isinstance(self.avatar_url, Unset):
            avatar_url = UNSET
        else:
            avatar_url = self.avatar_url

        key_mode: str | Unset = UNSET
        if not isinstance(self.key_mode, Unset):
            key_mode = self.key_mode.value

        has_passkey = self.has_passkey

        parent_profile: dict[str, Any] | None | Unset
        if isinstance(self.parent_profile, Unset):
            parent_profile = UNSET
        elif isinstance(self.parent_profile, ParentProfileSummary):
            parent_profile = self.parent_profile.to_dict()
        else:
            parent_profile = self.parent_profile

        principal_verification_methods: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.principal_verification_methods, Unset):
            principal_verification_methods = []
            for principal_verification_methods_item_data in self.principal_verification_methods:
                principal_verification_methods_item = principal_verification_methods_item_data.to_dict()
                principal_verification_methods.append(principal_verification_methods_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "username": username,
                "display_name": display_name,
                "attestations": attestations,
                "agents": agents,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if avatar_url is not UNSET:
            field_dict["avatar_url"] = avatar_url
        if key_mode is not UNSET:
            field_dict["key_mode"] = key_mode
        if has_passkey is not UNSET:
            field_dict["has_passkey"] = has_passkey
        if parent_profile is not UNSET:
            field_dict["parent_profile"] = parent_profile
        if principal_verification_methods is not UNSET:
            field_dict["principal_verification_methods"] = principal_verification_methods

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.attestation import Attestation
        from ..models.parent_profile_summary import ParentProfileSummary
        from ..models.principal_verification_method import PrincipalVerificationMethod
        from ..models.profile_agent import ProfileAgent

        d = dict(src_dict)
        username = d.pop("username")

        def _parse_display_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        display_name = _parse_display_name(d.pop("display_name"))

        attestations = []
        _attestations = d.pop("attestations")
        for attestations_item_data in _attestations:
            attestations_item = Attestation.from_dict(attestations_item_data)

            attestations.append(attestations_item)

        agents = []
        _agents = d.pop("agents")
        for agents_item_data in _agents:
            agents_item = ProfileAgent.from_dict(agents_item_data)

            agents.append(agents_item)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_avatar_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        avatar_url = _parse_avatar_url(d.pop("avatar_url", UNSET))

        _key_mode = d.pop("key_mode", UNSET)
        key_mode: PublicProfileKeyMode | Unset
        if isinstance(_key_mode, Unset):
            key_mode = UNSET
        else:
            key_mode = PublicProfileKeyMode(_key_mode)

        has_passkey = d.pop("has_passkey", UNSET)

        def _parse_parent_profile(data: object) -> None | ParentProfileSummary | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parent_profile_type_0 = ParentProfileSummary.from_dict(data)

                return parent_profile_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ParentProfileSummary | Unset, data)

        parent_profile = _parse_parent_profile(d.pop("parent_profile", UNSET))

        _principal_verification_methods = d.pop("principal_verification_methods", UNSET)
        principal_verification_methods: list[PrincipalVerificationMethod] | Unset = UNSET
        if _principal_verification_methods is not UNSET:
            principal_verification_methods = []
            for principal_verification_methods_item_data in _principal_verification_methods:
                principal_verification_methods_item = PrincipalVerificationMethod.from_dict(
                    principal_verification_methods_item_data
                )

                principal_verification_methods.append(principal_verification_methods_item)

        public_profile = cls(
            username=username,
            display_name=display_name,
            attestations=attestations,
            agents=agents,
            description=description,
            avatar_url=avatar_url,
            key_mode=key_mode,
            has_passkey=has_passkey,
            parent_profile=parent_profile,
            principal_verification_methods=principal_verification_methods,
        )

        public_profile.additional_properties = d
        return public_profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
