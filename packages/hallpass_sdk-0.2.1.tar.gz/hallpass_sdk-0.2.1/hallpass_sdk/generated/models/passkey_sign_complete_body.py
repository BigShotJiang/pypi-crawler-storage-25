from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.passkey_sign_complete_body_response import PasskeySignCompleteBodyResponse


T = TypeVar("T", bound="PasskeySignCompleteBody")


@_attrs_define
class PasskeySignCompleteBody:
    """
    Attributes:
        response (PasskeySignCompleteBodyResponse):
    """

    response: PasskeySignCompleteBodyResponse
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        response = self.response.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "response": response,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.passkey_sign_complete_body_response import PasskeySignCompleteBodyResponse

        d = dict(src_dict)
        response = PasskeySignCompleteBodyResponse.from_dict(d.pop("response"))

        passkey_sign_complete_body = cls(
            response=response,
        )

        passkey_sign_complete_body.additional_properties = d
        return passkey_sign_complete_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
