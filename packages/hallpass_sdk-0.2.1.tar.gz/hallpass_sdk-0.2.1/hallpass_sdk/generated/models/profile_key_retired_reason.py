from enum import Enum


class ProfileKeyRetiredReason(str, Enum):
    COMPROMISED = "compromised"
    MODE_SWITCHED = "mode_switched"
    PARENT_ACTION = "parent_action"
    ROTATED = "rotated"

    def __str__(self) -> str:
        return str(self.value)
