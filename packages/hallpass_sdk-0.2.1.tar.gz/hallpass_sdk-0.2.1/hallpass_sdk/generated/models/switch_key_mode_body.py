from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.switch_key_mode_body_key_mode import SwitchKeyModeBodyKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.switch_key_mode_body_public_jwk import SwitchKeyModeBodyPublicJwk
    from ..models.switch_key_mode_body_webauthn_assertion import SwitchKeyModeBodyWebauthnAssertion


T = TypeVar("T", bound="SwitchKeyModeBody")


@_attrs_define
class SwitchKeyModeBody:
    """
    Attributes:
        key_mode (SwitchKeyModeBodyKeyMode):
        public_jwk (SwitchKeyModeBodyPublicJwk | Unset): Required when switching to self_managed.
        confirm_password (str | Unset): Step-up re-authentication via password.
        webauthn_assertion (SwitchKeyModeBodyWebauthnAssertion | Unset): Step-up re-authentication via WebAuthn
            assertion.
    """

    key_mode: SwitchKeyModeBodyKeyMode
    public_jwk: SwitchKeyModeBodyPublicJwk | Unset = UNSET
    confirm_password: str | Unset = UNSET
    webauthn_assertion: SwitchKeyModeBodyWebauthnAssertion | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        key_mode = self.key_mode.value

        public_jwk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.public_jwk, Unset):
            public_jwk = self.public_jwk.to_dict()

        confirm_password = self.confirm_password

        webauthn_assertion: dict[str, Any] | Unset = UNSET
        if not isinstance(self.webauthn_assertion, Unset):
            webauthn_assertion = self.webauthn_assertion.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "key_mode": key_mode,
            }
        )
        if public_jwk is not UNSET:
            field_dict["public_jwk"] = public_jwk
        if confirm_password is not UNSET:
            field_dict["confirm_password"] = confirm_password
        if webauthn_assertion is not UNSET:
            field_dict["webauthn_assertion"] = webauthn_assertion

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.switch_key_mode_body_public_jwk import SwitchKeyModeBodyPublicJwk
        from ..models.switch_key_mode_body_webauthn_assertion import SwitchKeyModeBodyWebauthnAssertion

        d = dict(src_dict)
        key_mode = SwitchKeyModeBodyKeyMode(d.pop("key_mode"))

        _public_jwk = d.pop("public_jwk", UNSET)
        public_jwk: SwitchKeyModeBodyPublicJwk | Unset
        if isinstance(_public_jwk, Unset):
            public_jwk = UNSET
        else:
            public_jwk = SwitchKeyModeBodyPublicJwk.from_dict(_public_jwk)

        confirm_password = d.pop("confirm_password", UNSET)

        _webauthn_assertion = d.pop("webauthn_assertion", UNSET)
        webauthn_assertion: SwitchKeyModeBodyWebauthnAssertion | Unset
        if isinstance(_webauthn_assertion, Unset):
            webauthn_assertion = UNSET
        else:
            webauthn_assertion = SwitchKeyModeBodyWebauthnAssertion.from_dict(_webauthn_assertion)

        switch_key_mode_body = cls(
            key_mode=key_mode,
            public_jwk=public_jwk,
            confirm_password=confirm_password,
            webauthn_assertion=webauthn_assertion,
        )

        switch_key_mode_body.additional_properties = d
        return switch_key_mode_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
