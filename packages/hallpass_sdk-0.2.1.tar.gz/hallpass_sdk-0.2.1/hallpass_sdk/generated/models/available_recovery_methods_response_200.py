from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.available_recovery_methods_response_200_methods_item import AvailableRecoveryMethodsResponse200MethodsItem

T = TypeVar("T", bound="AvailableRecoveryMethodsResponse200")


@_attrs_define
class AvailableRecoveryMethodsResponse200:
    """
    Attributes:
        methods (list[AvailableRecoveryMethodsResponse200MethodsItem]):
    """

    methods: list[AvailableRecoveryMethodsResponse200MethodsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        methods = []
        for methods_item_data in self.methods:
            methods_item = methods_item_data.value
            methods.append(methods_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "methods": methods,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        methods = []
        _methods = d.pop("methods")
        for methods_item_data in _methods:
            methods_item = AvailableRecoveryMethodsResponse200MethodsItem(methods_item_data)

            methods.append(methods_item)

        available_recovery_methods_response_200 = cls(
            methods=methods,
        )

        available_recovery_methods_response_200.additional_properties = d
        return available_recovery_methods_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
