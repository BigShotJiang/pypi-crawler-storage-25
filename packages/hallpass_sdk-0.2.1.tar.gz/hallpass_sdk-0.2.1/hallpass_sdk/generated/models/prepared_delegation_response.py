from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.prepared_delegation_response_payload import PreparedDelegationResponsePayload


T = TypeVar("T", bound="PreparedDelegationResponse")


@_attrs_define
class PreparedDelegationResponse:
    """
    Attributes:
        payload (PreparedDelegationResponsePayload):
    """

    payload: PreparedDelegationResponsePayload
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = self.payload.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "payload": payload,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.prepared_delegation_response_payload import PreparedDelegationResponsePayload

        d = dict(src_dict)
        payload = PreparedDelegationResponsePayload.from_dict(d.pop("payload"))

        prepared_delegation_response = cls(
            payload=payload,
        )

        prepared_delegation_response.additional_properties = d
        return prepared_delegation_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
