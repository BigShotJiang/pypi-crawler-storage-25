from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent import Agent
    from ..models.delegation import Delegation


T = TypeVar("T", bound="AgentVerifySetupResponse200")


@_attrs_define
class AgentVerifySetupResponse200:
    """
    Attributes:
        agent (Agent):
        delegation (Delegation | None | Unset):
    """

    agent: Agent
    delegation: Delegation | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.delegation import Delegation

        agent = self.agent.to_dict()

        delegation: dict[str, Any] | None | Unset
        if isinstance(self.delegation, Unset):
            delegation = UNSET
        elif isinstance(self.delegation, Delegation):
            delegation = self.delegation.to_dict()
        else:
            delegation = self.delegation

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent": agent,
            }
        )
        if delegation is not UNSET:
            field_dict["delegation"] = delegation

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent import Agent
        from ..models.delegation import Delegation

        d = dict(src_dict)
        agent = Agent.from_dict(d.pop("agent"))

        def _parse_delegation(data: object) -> Delegation | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                delegation_type_0 = Delegation.from_dict(data)

                return delegation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Delegation | None | Unset, data)

        delegation = _parse_delegation(d.pop("delegation", UNSET))

        agent_verify_setup_response_200 = cls(
            agent=agent,
            delegation=delegation,
        )

        agent_verify_setup_response_200.additional_properties = d
        return agent_verify_setup_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
