from enum import Enum


class ChangeSinceSigningStatus(str, Enum):
    KEY_ROTATED = "key_rotated"
    LATER_EXPIRED = "later_expired"
    LATER_REVOKED = "later_revoked"
    NO_MATERIAL_CHANGE = "no_material_change"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
