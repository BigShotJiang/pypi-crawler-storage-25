from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.start_recovery_body_method import StartRecoveryBodyMethod

T = TypeVar("T", bound="StartRecoveryBody")


@_attrs_define
class StartRecoveryBody:
    """
    Attributes:
        username (str):
        method (StartRecoveryBodyMethod):
    """

    username: str
    method: StartRecoveryBodyMethod
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        username = self.username

        method = self.method.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "username": username,
                "method": method,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        username = d.pop("username")

        method = StartRecoveryBodyMethod(d.pop("method"))

        start_recovery_body = cls(
            username=username,
            method=method,
        )

        start_recovery_body.additional_properties = d
        return start_recovery_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
