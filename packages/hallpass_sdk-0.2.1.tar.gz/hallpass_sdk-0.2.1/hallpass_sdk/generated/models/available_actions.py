from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.available_actions_step_up_methods_item import AvailableActionsStepUpMethodsItem

if TYPE_CHECKING:
    from ..models.available_actions_auth_methods import AvailableActionsAuthMethods
    from ..models.available_actions_signing import AvailableActionsSigning


T = TypeVar("T", bound="AvailableActions")


@_attrs_define
class AvailableActions:
    """
    Attributes:
        auth_methods (AvailableActionsAuthMethods):
        signing (AvailableActionsSigning):
        step_up_methods (list[AvailableActionsStepUpMethodsItem]):
    """

    auth_methods: AvailableActionsAuthMethods
    signing: AvailableActionsSigning
    step_up_methods: list[AvailableActionsStepUpMethodsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        auth_methods = self.auth_methods.to_dict()

        signing = self.signing.to_dict()

        step_up_methods = []
        for step_up_methods_item_data in self.step_up_methods:
            step_up_methods_item = step_up_methods_item_data.value
            step_up_methods.append(step_up_methods_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "auth_methods": auth_methods,
                "signing": signing,
                "step_up_methods": step_up_methods,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.available_actions_auth_methods import AvailableActionsAuthMethods
        from ..models.available_actions_signing import AvailableActionsSigning

        d = dict(src_dict)
        auth_methods = AvailableActionsAuthMethods.from_dict(d.pop("auth_methods"))

        signing = AvailableActionsSigning.from_dict(d.pop("signing"))

        step_up_methods = []
        _step_up_methods = d.pop("step_up_methods")
        for step_up_methods_item_data in _step_up_methods:
            step_up_methods_item = AvailableActionsStepUpMethodsItem(step_up_methods_item_data)

            step_up_methods.append(step_up_methods_item)

        available_actions = cls(
            auth_methods=auth_methods,
            signing=signing,
            step_up_methods=step_up_methods,
        )

        available_actions.additional_properties = d
        return available_actions

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
