"""Hallpass Python SDK — agent key material, JWT signing, message proofs, and API client."""

from hallpass_sdk.keys import (
    AgentKeyMaterial,
    generate_agent_key_material,
    load_agent_key_material,
    did_jwk,
    verification_method_for_did,
    fingerprint_public_jwk,
)
from hallpass_sdk.jwt import sign_compact_jwt, verify_compact_jwt, decode_compact_jwt
from hallpass_sdk.messages import create_message_proof_bundle, verify_message_proof_bundle
from hallpass_sdk.challenges import create_agent_challenge_response
from hallpass_sdk.delegation import create_delegation_jwt
from hallpass_sdk.client import HallpassClient

VERSION = "0.1.0"
__version__ = VERSION
DEFAULT_BASE_URL = "https://hallpass.org"

__all__ = [
    "VERSION",
    "__version__",
    "DEFAULT_BASE_URL",
    "AgentKeyMaterial",
    "generate_agent_key_material",
    "load_agent_key_material",
    "did_jwk",
    "verification_method_for_did",
    "fingerprint_public_jwk",
    "sign_compact_jwt",
    "verify_compact_jwt",
    "decode_compact_jwt",
    "create_message_proof_bundle",
    "verify_message_proof_bundle",
    "create_agent_challenge_response",
    "create_delegation_jwt",
    "HallpassClient",
]
