from hallpass_sdk import (
    generate_agent_key_material,
    did_jwk,
    verification_method_for_did,
    fingerprint_public_jwk,
)


def test_generate_agent_key_material():
    km = generate_agent_key_material()
    assert km.public_jwk["kty"] == "EC"
    assert km.public_jwk["crv"] == "P-256"
    assert km.did.startswith("did:jwk:")
    assert km.verification_method.endswith("#0")
    assert len(km.key_fingerprint) == 64


def test_did_jwk_matches():
    km = generate_agent_key_material()
    assert did_jwk(km.public_jwk) == km.did


def test_verification_method_for_did():
    vm = verification_method_for_did("did:jwk:abc123")
    assert vm == "did:jwk:abc123#0"


def test_fingerprint_is_deterministic():
    km = generate_agent_key_material()
    assert fingerprint_public_jwk(km.public_jwk) == fingerprint_public_jwk(km.public_jwk)
    assert len(fingerprint_public_jwk(km.public_jwk)) == 64
