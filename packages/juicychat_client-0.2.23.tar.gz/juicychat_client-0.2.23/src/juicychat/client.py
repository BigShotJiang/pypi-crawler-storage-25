import json
import logging
import time
from enum import IntEnum, StrEnum
from typing import Any, Dict, List, Literal, Optional

from curl_cffi import requests

from .constants import BASE_URL
from .crypto import JuicyChatCrypto
from .discover import discover_bundle
from .utils import create_distinct_id, create_secret_key

logger = logging.getLogger(__name__)


class SortName(StrEnum):
    EDITOR_CHOICE = "editor"
    FOLLOWING = "following"
    NEW = "new"
    POPULAR = "popular"
    RECENT = "recent"
    TRENDING = "trending"


class Gender(IntEnum):
    ALL = -1
    FEMALE = 0
    MALE = 1
    NON_BINARY = 2
    TRANS_MALE = 3
    TRANS_FEMALE = 4


class TaskId(IntEnum):
    DAILY_CHECK_IN = 1
    SEND_10_MESSAGES = 9
    CHAT_3_CHARACTERS = 10
    FOLLOW_CREATOR = 13
    GENERATE_IMAGE = 16


class RankingType(IntEnum):
    ALL_CREATORS_MONTHLY = 1
    NEW_CREATORS_MONTHLY = 2
    ALL_CREATORS_ALL_TIME = 3
    NEW_CREATORS_ALL_TIME = 4


class JuicyChatClient:
    def __init__(
        self,
        user_number: str,
        password: str,
        key: Optional[str] = None,
        iv: Optional[str] = None,
        app_version: Optional[str] = None,
        impersonate: Literal["chrome", "firefox", "safari"] = "chrome",
        timeout: int = 5,
    ):
        if key is None or iv is None or app_version is None:
            bundle = discover_bundle()
            key, iv, app_version = bundle.key, bundle.iv, bundle.app_version
        self.base_url = BASE_URL.rstrip("/")
        self.crypto = JuicyChatCrypto(key, iv)
        self.secret_key = create_secret_key()

        session = requests.Session(impersonate=impersonate, timeout=timeout)
        session.headers.update(
            {
                "Accept": "application/json, text/plain, */*;q=0.7",
                "Accept-Language": "en-US, en;q=0.9",
                "Appversion": app_version,
                "Client": "pc",
                "Content-Type": "application/json",
                "DistinctId": create_distinct_id(),
                "Origin": self.base_url,
                "PlatformType": "web",
                "Pragma": "no-cache",
                "Priority": "u=1, i",
                "Referer": self.base_url + "/",
                "SecretKey": self.secret_key,
            }
        )
        self.session = session
        result = self._login_with_password(user_number, password)
        # print(json.dumps(result, indent=4))
        self.user_id = result["userId"]
        self.user_name = result["userName"]
        self.user_number = result["userNo"]

    def _login_with_password(self, user_number: str, password: str) -> Dict[str, Any]:
        endpoint = "/yume/api/login/v1/userPasswordLogin"
        url = self.base_url + endpoint
        payload = {"userNo": user_number, "password": password}
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_user_checkin_prompt(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v2/task/userCheckInPrompt"
        url = self.base_url + endpoint
        response = self.session.post(url)  # no payload
        return self._handle_json_response(response).get("data", {})

    def get_user_claim_coupon(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/coupon/getUserClaimCoupon"
        url = self.base_url + endpoint
        payload = {}  # empty payload
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_user_info(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/getOwnUserInfoDetail"
        url = self.base_url + endpoint
        response = self.session.get(url)
        return self._handle_json_response(response).get("data", {})

    def get_other_user_info(self, user_id: str) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/getOtherUserInfo"
        url = self.base_url + endpoint
        payload = {
            "userId": user_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_user_coins(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/getUserCoin"
        url = self.base_url + endpoint
        response = self.session.post(url)  # no payload
        return self._handle_json_response(response).get("data", {})

    def get_user_progress(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v2/task/getUserProgress"
        url = self.base_url + endpoint
        payload = {}
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def search_characters(
        self,
        search_content: str = "",
        character_tags: Optional[List[str]] = None,
        gender: Gender = Gender.ALL,
        sort_name: SortName = SortName.POPULAR,
        page_no: int = 1,
        page_size: int = 30,
    ) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/character/getCharacterList"
        url = self.base_url + endpoint
        payload = {
            "searchContent": search_content,
            "characterTags": character_tags or [],
            "sortName": sort_name.value,
            "pageNo": page_no,
            "pageSize": page_size,
        }
        if gender != Gender.ALL:
            payload["gender"] = gender.value

        response = self.session.post(url, json=self._transform_request_payload(payload))
        result = self._handle_json_response(response)
        return {
            "data": result.get("data", []),
            "total": result.get("total", 0),
        }

    def get_character_list_and_config(
        self,
        search_content: str = "",
        character_tags: Optional[List[str]] = None,
        gender: Gender = Gender.ALL,
        sort_name: SortName = SortName.POPULAR,
        page_no: int = 1,
        page_size: int = 30,
    ) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/character/getCharacterListAndConfig"
        url = self.base_url + endpoint
        payload = {
            "searchContent": search_content,
            "characterTags": character_tags or [],
            "sortName": sort_name.value,
            "pageNo": page_no,
            "pageSize": page_size,
        }
        if gender != Gender.ALL:
            payload["gender"] = gender.value

        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_character_detail(self, character_id: str) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/character/getCharacterDetail"
        url = self.base_url + endpoint
        payload = {
            "characterId": character_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_chat_relations(
        self, page_no: int = 1, page_size: int = 50
    ) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/chat/getChatRelationList"
        url = self.base_url + endpoint
        payload = {
            "pageNo": page_no,
            "pageSize": page_size,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        result = self._handle_json_response(response)
        return {
            "data": result.get("data", []),
            "total": result.get("total", 0),
        }

    def get_chat_config(self, character_id: str) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/chat/getChatConfig"
        url = self.base_url + endpoint
        payload = {"characterId": character_id}
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def delete_chat_relation(self, character_id: str) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/chat/removeChatRelation"
        url = self.base_url + endpoint
        payload = {
            "characterId": character_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_chat_messages(
        self, character_id: str, chat_id: str = "0"
    ) -> List[Dict[str, Any]]:
        endpoint = "/yume/api/user/v1/chat/getUserChatList"
        url = self.base_url + endpoint
        payload = {
            "characterId": character_id,
            "chatId": chat_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", [])

    def send_chat_message(
        self, character_id: str, message: str, request_type: str = "text"
    ) -> Dict[str, Any]:
        t = int(time.time() * 1000)  # time in milliseconds since epoch
        endpoint = f"/yume/api/user/v1/chat/sendChatStream?t={t}"
        url = self.base_url + endpoint
        payload = {
            "characterId": character_id,
            "content": message,
            "requestType": request_type,
        }
        response = self.session.post(
            url, json=self._transform_request_payload(payload), stream=True, timeout=60
        )
        return self._handle_event_stream_response(response)

    def update_content_filter(
        self, unfiltered: bool = False, adult_only: bool = False
    ) -> bool:
        endpoint = "/yume/api/user/v1/updateUserUnfiltered"
        url = self.base_url + endpoint
        payload = {
            "unfiltered": 1 if unfiltered else 0,
            "adultOnly": 1 if adult_only else 0,
        }
        request_body = self._transform_request_payload(payload)
        response = self.session.post(url, json=request_body)
        return self._handle_json_response(response).get("data", False)

    def get_personas(self, page_no: int = 1, page_size: int = 20) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/persona/getMinePersonaCardList"
        url = self.base_url + endpoint
        payload = {
            "characterId": "99999999",  # required, but ignored
            "pageNo": page_no,
            "pageSize": page_size,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        result = self._handle_json_response(response)
        return {
            "data": result.get("data", []),
            "total": result.get("total", 0),
        }

    def create_persona(
        self, title: str, name: str, description: str, gender: Gender, age: int
    ) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/persona/createPersonaCard"
        url = self.base_url + endpoint
        payload = {
            "createType": 1,
            "personaAge": age,
            "personaDescription": description,
            "personaGender": gender.value,
            # "personaId": None,
            "personaName": name,
            "personaPhoto": "https://cdn.juicychat.ai/user/prod/character/20250328/1837773957680558082/f_00065973fd92440288e3cb19dfc22751.jpeg",
            "pinned": [],
            "title": title,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def set_persona(
        self, character_id: str, persona_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Use persona for a chat. If no persona_id is specified, use details from user's profile.
        :param character_id: The ID of the character to link the persona to.
        :param persona_id: The ID of the persona to link to the chat, or None to use user's profile details.
        :return: None
        """
        endpoint = "/yume/api/user/v1/persona/setCharacterPersonaCard"
        url = self.base_url + endpoint
        payload = {
            "characterId": character_id,
            "personaId": persona_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def clear_chat_history(self, character_id: str) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/chat/clearChatRecord"
        url = self.base_url + endpoint
        payload = {
            "characterId": character_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def chat_gen_picture(self, chat_id: str) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/chat/chatGenPicture"
        url = self.base_url + endpoint
        payload = {"chatId": chat_id}
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_picture_status(self, chat_id: str) -> Dict[str, Any]:
        """Get status of a picture generation for a chat.

        If picture is not generated yet, status will be 0 and blurPictureUrl
        and clearPictureUrl will be null.

        If picture is generated, status will be 10 and blurPictureUrl and
        clearPictureUrl will be the URLs of the generated picture.
        """
        endpoint = "/yume/api/user/v1/chat/getPictureStatus"
        url = self.base_url + endpoint
        payload = {"chatId": chat_id}
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    ###########################################################################
    # Task-related methods
    ###########################################################################
    def get_tasks(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v2/task/getTaskList"
        url = self.base_url + endpoint
        payload = {}
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def get_task_progress(self, task_id: int) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v2/task/getTaskProgress"
        url = self.base_url + endpoint
        payload = {
            "taskId": task_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", {})

    def claim_task_reward(self, task_id: int) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v2/task/claimTaskReward"
        url = self.base_url + endpoint
        payload = {
            "taskId": task_id,
            "userId": self.user_id,
            "secretKey": self.secret_key,
        }
        # headers = {"Referer": self.base_url + "/bonus"}
        response = self.session.post(
            url,
            json=self._transform_request_payload(payload),
            # headers=headers
        )
        return self._handle_json_response(response).get("data", {})

    def get_ranked_creators(
        self,
        ranking_type: RankingType = RankingType.ALL_CREATORS_MONTHLY,
        page_no: int = 1,
        page_size: int = 20,
    ) -> List[Dict[str, Any]]:
        """Get list of creators, ranked by ranking type."""
        endpoint = "/yume/api/user/v1/creator/ranking/getCreatorRanking"
        url = self.base_url + endpoint
        payload = {
            "rankingType": ranking_type.value,
            "pageNo": page_no,
            "pageSize": page_size,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", [])

    def search_users(
        self,
        search_content: str = "",
        page_no: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """Get list of creators, ranked by ranking type."""
        endpoint = "/yume/api/user/v1/search/getSearchUser"
        url = self.base_url + endpoint
        payload = {
            "searchContent": search_content,
            "pageNo": page_no,
            "pageSize": page_size,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        result = self._handle_json_response(response)
        return {
            "data": result.get("data", []),
            "total": result.get("total", 0),
        }

    def follow_user(self, user_id: str) -> bool:
        endpoint = "/yume/api/user/v1/userFollowUser"
        url = self.base_url + endpoint
        payload = {
            "followUserId": user_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", False)

    def unfollow_user(self, user_id: str) -> bool:
        endpoint = "/yume/api/user/v1/cancelFollowUser"
        url = self.base_url + endpoint
        payload = {
            "followUserId": user_id,
        }
        response = self.session.post(url, json=self._transform_request_payload(payload))
        return self._handle_json_response(response).get("data", False)

    def get_launch_data(self) -> Dict[str, Any]:
        endpoint = "/yume/api/user/v1/getLaunchData"
        url = self.base_url + endpoint
        response = self.session.get(url)
        return self._handle_json_response(response).get("data", {})

    def _transform_request_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return {"requestData": self.crypto.encrypt_request_data(json.dumps(payload))}

    def _handle_json_response(self, response: requests.Response) -> Any:
        response_json = response.json()
        if "responseData" not in response_json:
            return response_json

        encrypted_response_data = response_json.get("responseData")
        decrypted_response_data = self.crypto.decrypt_response_data(
            encrypted_response_data
        )
        decrypted_response_json = json.loads(decrypted_response_data)
        if not decrypted_response_json.get("success", False):
            raise RuntimeError("API call failed: " + decrypted_response_json.get("msg"))
        # return decrypted_response_json.get("data")
        return decrypted_response_json

    def _handle_event_stream_response(
        self, response: requests.Response
    ) -> Dict[str, Any]:
        first_data = {}
        tokens = []
        # for line in response.text.split("\n"):
        for chunk in response.iter_lines():
            line = chunk.decode("utf-8")
            if line.startswith("data:{"):
                try:
                    data = json.loads(line[5:])
                    if data.get("first", False):
                        first_data = data
                    else:
                        tokens.append(data.get("content", ""))
                except json.JSONDecodeError as e:
                    logger.error(f"Error: {e}")
                    continue
        first_data["responseText"] = "".join(tokens).strip()
        return first_data
