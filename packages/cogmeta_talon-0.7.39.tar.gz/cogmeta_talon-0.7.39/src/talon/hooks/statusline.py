#!/usr/bin/env python3
"""talon-statusline.py — Claude Code status line with Talon session score.

Shows: CogMeta: last_prompt / session / alltime | -XX% ████▒▒ ↓X.XM | Nt X.XM

Same display as dev statusline. Score from ~/.talon/score.json (MCP server)
or computed from transcript when MCP isn't active.
"""

import json
import os
import re
import sys
import time
from pathlib import Path

GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[38;5;33m"
CYAN = "\033[36m"
NEON = "\033[38;5;213m"
DIM = "\033[2m"
RESET = "\033[0m"

TALON_TOOLS = frozenset({
    "mcp__talon__graph_ask_lite", "mcp__talon__graph_query",
    "mcp__talon__smart_read_batch", "mcp__talon__edit_batch",
    "graph_ask_lite", "graph_query", "smart_read_batch", "edit_batch",
})

BASELINES_PATH = Path(__file__).resolve().parent.parent / "data" / "vanilla_baselines.json"
FLOOR_PER_TURN = 30_000

_baselines_cache: dict | None = None


def _load_baselines() -> dict:
    global _baselines_cache
    if _baselines_cache is not None:
        return _baselines_cache
    try:
        if BASELINES_PATH.exists():
            _baselines_cache = json.loads(BASELINES_PATH.read_text())
            return _baselines_cache
    except Exception:
        pass
    _baselines_cache = {}
    return _baselines_cache


def _classify_task_type(first_message: str) -> str:
    text = first_message.lower()
    if re.search(r"\b(refactor|rename|restructure|reorganize|extract\s+method|move\s+to)\b", text):
        return "refactor"
    return "write"


def _project_vanilla_tmc(baselines: dict, n_files: int, task_type: str,
                         n_turns: int) -> tuple[int, str]:
    strata = baselines.get("strata", {})

    def _scale(s: dict, key: str) -> tuple[int, str]:
        median_tok = s["tokens"]["median"]
        median_turns = s["turns"]["median"]
        if median_turns <= 0 or n_turns <= 0:
            return int(median_tok), f"stratum:{key}"
        per_turn = max(median_tok / median_turns, FLOOR_PER_TURN)
        projected = per_turn * n_turns
        return int(projected), f"stratum:{key}"

    key = f"{task_type}_{n_files}f"
    if key in strata:
        return _scale(strata[key], key)

    candidates = [(k, v) for k, v in strata.items() if v["task_type"] == task_type]
    if candidates:
        best_k, best_v = min(candidates, key=lambda x: abs(x[1]["n_files"] - n_files))
        return _scale(best_v, best_k)

    return n_turns * 30_000, "fallback"


def _detect_model(transcript_path: str) -> str:
    try:
        with open(transcript_path) as _f:
            for line in _f:
                try:
                    entry = json.loads(line)
                except Exception:
                    continue
                if entry.get("type") == "assistant":
                    model = entry.get("message", {}).get("model", "")
                    if model and not model.startswith("<"):
                        return model
    except Exception:
        pass
    return ""


def _model_multiplier(model: str) -> float:
    m = model.lower()
    if "opus" in m:
        return 4.0
    if "haiku" in m:
        return 0.6
    return 1.0


def _fmt_tok(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1000:
        return f"{n // 1000}K"
    return str(n)


def _color_score(v: float) -> str:
    pct = int(v * 100)
    if v >= 0.85:
        return f"{GREEN}{pct}{RESET}"
    if v >= 0.65:
        return f"{CYAN}{pct}{RESET}"
    if v >= 0.40:
        return f"{YELLOW}{pct}{RESET}"
    return f"\033[31m{pct}{RESET}"


def _dual_bar(actual: int, projected: int, width: int = 8) -> str:
    if projected <= 0 or actual >= projected:
        return f"{BLUE}{'█' * width}{RESET}"
    ratio = actual / projected
    filled = int(ratio * width)
    gap = width - filled
    return f"{BLUE}{'█' * filled}{RESET}{DIM}{'▒' * gap}{RESET}"


def _parse_transcript(cc_data: dict) -> dict:
    transcript_path = cc_data.get("transcript_path", "")
    if not transcript_path or not os.path.exists(transcript_path):
        return {}

    total_input = 0
    cache_read = 0
    cache_creation = 0
    n_turns = 0
    tool_names: list[str] = []
    files_touched: set[str] = set()
    first_msg = ""
    model = ""
    usages: list[dict] = []

    try:
        with open(transcript_path) as _tf:
            for line in _tf:
                try:
                    entry = json.loads(line)
                except Exception:
                    continue

                if entry.get("type") == "user" and not first_msg:
                    content = entry.get("message", {}).get("content", "")
                    if isinstance(content, str):
                        first_msg = content
                    elif isinstance(content, list):
                        for c in content:
                            if isinstance(c, dict) and c.get("text"):
                                first_msg = c["text"]
                                break

                if entry.get("type") != "assistant":
                    continue

                n_turns += 1
                msg = entry.get("message", {})
                if not model:
                    model = msg.get("model", "")
                usage = msg.get("usage", {})
                if usage:
                    usages.append(usage)
                    total_input += usage.get("input_tokens", 0)
                    cache_read += usage.get("cache_read_input_tokens", 0)
                    cache_creation += usage.get("cache_creation_input_tokens", 0)

                for item in msg.get("content", []):
                    if not isinstance(item, dict) or item.get("type") != "tool_use":
                        continue
                    name = item.get("name", "")
                    tool_names.append(name)
                    fp = item.get("input", {}).get("file_path", "")
                    if name in ("Read", "Edit", "Write") and fp:
                        files_touched.add(fp)
    except Exception:
        pass

    actual_tmc = total_input + cache_read + cache_creation
    return {
        "n_turns": n_turns, "actual_tmc": actual_tmc,
        "tool_names": tool_names, "files_touched": files_touched,
        "first_msg": first_msg, "model": model, "usages": usages,
    }


def _compute_score_from_transcript(data: dict) -> tuple[float, float, bool]:
    """Compute talon session health score using the calibrated 4-signal formula.

    Marathon calibration: r=-0.604, N=123 sessions.
    Returns (session_score, last_prompt_score, talon_active).
    """
    n_turns = data.get("n_turns", 0)
    if n_turns == 0:
        return 0.0, 0.0, False

    tool_names = data.get("tool_names", [])
    actual_tmc = data.get("actual_tmc", 0)

    has_talon = any(t in TALON_TOOLS for t in tool_names)

    total_steps = len(tool_names)
    spp = total_steps / n_turns
    cpp = actual_tmc / n_turns

    gal = sum(1 for t in tool_names if t in ("mcp__talon__graph_ask_lite", "graph_ask_lite"))
    srb = sum(1 for t in tool_names if t in ("mcp__talon__smart_read_batch", "smart_read_batch"))
    sg = srb / gal if gal > 0 else (float(srb) if srb > 0 else 0.0)

    prompt_tools: dict[int, list[str]] = {}
    for i, t in enumerate(tool_names):
        bucket = min(i, n_turns - 1)
        prompt_tools.setdefault(bucket, []).append(t)
    graph_only = sum(
        1 for tools in prompt_tools.values()
        if tools and all(t in TALON_TOOLS for t in tools)
    )
    go_pct = graph_only / n_turns * 100 if n_turns else 0

    spp_s = max(0.0, min(1.0, (12 - spp) / 10))
    go_s = go_pct / 100
    ctx_s = max(0.0, min(1.0, (1_000_000 - cpp) / 600_000))
    sg_s = max(0.0, min(1.0, (5 - sg) / 4.5))

    session_score = 0.40 * spp_s + 0.20 * go_s + 0.30 * ctx_s + 0.10 * sg_s
    last_score = session_score

    return round(session_score, 2), round(last_score, 2), has_talon


def _talon_mcp_configured() -> bool:
    for p in [Path.home() / ".claude.json", Path.home() / ".mcp.json"]:
        try:
            if p.exists():
                d = json.loads(p.read_text())
                if "talon" in d.get("mcpServers", {}):
                    return True
        except Exception:
            pass
    return False


def _cogmeta_score(data: dict) -> str:
    last_prompt = 0.0
    session = 0.0
    got_mcp = False
    talon_active = False

    try:
        score_path = Path.home() / ".talon" / "score.json"
        if score_path.exists():
            d = json.loads(score_path.read_text())
            age = time.time() - d.get("updated_at", 0)
            if age < 7200:
                last_prompt = d.get("last_prompt", 0)
                session = d.get("session", 0)
                got_mcp = True
                talon_active = True
    except Exception:
        pass

    if not got_mcp and data.get("n_turns", 0) > 0:
        session, last_prompt, talon_active = _compute_score_from_transcript(data)

    alltime = 0.0
    try:
        p = Path.home() / ".talon" / "score_alltime.json"
        if p.exists():
            alltime = json.loads(p.read_text()).get("score", 0.0)
    except Exception:
        pass

    mcp_configured = _talon_mcp_configured()
    has_creds = (Path.home() / ".talon" / "credentials.json").exists()

    label = f"{DIM}[Prompt, Session, All Time]{RESET}"

    if not mcp_configured:
        if not has_creds:
            return f"{DIM}CogMeta: /talon login{RESET}"
        return f"{DIM}CogMeta: /talon init{RESET}"

    if data.get("n_turns", 0) == 0:
        return f"CogMeta: {_color_score(0.0)} / {_color_score(0.0)} / {_color_score(alltime)} {label}"

    if not talon_active:
        return f"CogMeta: {_color_score(0.0)} / {_color_score(0.0)} / {_color_score(alltime)} {label}"

    return f"CogMeta: {_color_score(last_prompt)} / {_color_score(session)} / {_color_score(alltime)} {label}"


def _session_savings(data: dict, cc_data: dict) -> str:
    n_turns = data.get("n_turns", 0)
    actual_tmc = data.get("actual_tmc", 0)
    raw = f"{DIM}{n_turns}t {_fmt_tok(actual_tmc)}{RESET}"

    if n_turns == 0:
        return raw

    n_files = max(1, len(data.get("files_touched", set())))
    task_type = _classify_task_type(data.get("first_msg", ""))

    baselines = _load_baselines()
    if not baselines:
        return raw

    projected_tmc, _source = _project_vanilla_tmc(baselines, n_files, task_type, n_turns)

    transcript_path = cc_data.get("transcript_path", "")
    model = _detect_model(transcript_path) if transcript_path else data.get("model", "")
    multiplier = _model_multiplier(model)
    projected_tmc = int(projected_tmc * multiplier)

    saved = projected_tmc - actual_tmc
    if saved <= 0 or projected_tmc <= 0:
        return f"{DIM}{'█' * 8}{RESET} {raw}"

    save_pct = saved / projected_tmc * 100
    bar = _dual_bar(actual_tmc, projected_tmc)
    return f"{CYAN}-{save_pct:.0f}%{RESET} {bar} {CYAN}↓{_fmt_tok(saved)}{RESET} {raw}"


def _mcp_needs_restart(transcript_path: str) -> bool:
    """True if .mcp.json was written after the current CC session started."""
    try:
        if not transcript_path or not os.path.exists(transcript_path):
            return False
        session_start = os.path.getctime(transcript_path)
        for p in [Path.home() / ".mcp.json", Path(os.getcwd()) / ".mcp.json"]:
            if p.exists() and p.stat().st_mtime > session_start:
                return True
    except Exception:
        pass
    return False


def _mcp_project_name() -> str:
    """Return TALON_PROJECT_ID from .mcp.json if set, else empty string."""
    try:
        for p in [Path(os.getcwd()) / ".mcp.json", Path.home() / ".mcp.json"]:
            if p.exists():
                d = json.loads(p.read_text())
                pid = d.get("mcpServers", {}).get("talon", {}).get("env", {}).get("TALON_PROJECT_ID", "")
                if pid:
                    return pid
                # Fall back to dir name from project path arg if present
                args = d.get("mcpServers", {}).get("talon", {}).get("args", [])
                for arg in args:
                    if "/" in arg or arg.startswith("."):
                        return Path(arg).name
    except Exception:
        pass
    return ""


def _mcp_status_badge(data: dict, transcript_path: str = "") -> str:
    """MCP connection badge with restart hint and project name."""
    if not _talon_mcp_configured():
        return ""

    # Restart needed — .mcp.json written after this CC session started
    if _mcp_needs_restart(transcript_path):
        return f"\033[31mMCP: \u2717 restart CC{RESET}"

    n_turns = data.get("n_turns", 0)
    tool_names = data.get("tool_names", [])
    talon_seen = any(t in TALON_TOOLS for t in tool_names)

    project = _mcp_project_name()
    label = f" {DIM}{project}{RESET}" if project else ""

    if talon_seen:
        return f"{GREEN}MCP: \u2713{label}{RESET}"
    if n_turns >= 3:
        return f"\033[31mMCP: \u2717 not connected{RESET}"
    return f"{DIM}MCP: …{label}{RESET}"


def _graph_health_badge() -> str:
    """Return 'Graph: X%' badge from cached graph_health.json (refreshed every 30 min by prompt hook)."""
    try:
        p = Path.home() / ".talon" / "graph_health.json"
        if not p.exists():
            return ""
        d = json.loads(p.read_text())
        # Show stale data up to 2 hours old (hook refreshes at 30 min)
        if time.time() - d.get("checked_at", 0) > 7200:
            return ""
        state_pct = d.get("state_pct", 0)
        action = d.get("action", "")
        if state_pct >= 99:
            return f"{GREEN}Graph: {state_pct}%{RESET}"
        if state_pct > 0:
            return f"{YELLOW}Graph: {state_pct}% \u26a0 {action}{RESET}"
        return f"\033[31mGraph: {state_pct}% \u26a0 {action}{RESET}"
    except Exception:
        pass
    return ""


def _upgrade_badge() -> str:
    """Return '⬆ X.Y.Z' badge if a newer version is available, else empty string."""
    try:
        p = Path.home() / ".talon" / "update.json"
        if not p.exists():
            return ""
        d = json.loads(p.read_text())
        if not d.get("available", False):
            return ""
        # Ignore stale cache (older than 24 hours)
        if time.time() - d.get("checked_at", 0) > 86400:
            return ""
        latest = d.get("latest", "")
        if latest:
            return f"\033[38;5;214m\u2b06 {latest}\033[0m"
    except Exception:
        pass
    return ""


def _inbox_badge() -> str:
    """Return '✉ N' badge if there are unread support messages, else empty string."""
    try:
        p = Path.home() / ".talon" / "inbox.json"
        if not p.exists():
            return ""
        d = json.loads(p.read_text())
        # Ignore stale cache (older than 2 hours)
        if time.time() - d.get("updated_at", 0) > 7200:
            return ""
        unread = d.get("unread", 0)
        if unread > 0:
            return f"\033[38;5;208m✉ {unread}\033[0m"
    except Exception:
        pass
    return ""


def main() -> None:
    try:
        raw = sys.stdin.read()
        cc_data = json.loads(raw) if raw.strip() else {}
    except Exception:
        cc_data = {}

    data = _parse_transcript(cc_data)
    parts = []

    parts.append(_cogmeta_score(data))

    mcp = _mcp_status_badge(data, transcript_path=cc_data.get("transcript_path", ""))
    if mcp:
        parts.append(mcp)

    graph = _graph_health_badge()
    if graph:
        parts.append(graph)

    upgrade = _upgrade_badge()
    if upgrade:
        parts.append(upgrade)

    badge = _inbox_badge()
    if badge:
        parts.append(badge)

    n_turns = data.get("n_turns", 0)
    actual_tmc = data.get("actual_tmc", 0)
    if n_turns > 0:
        parts.append(f"{NEON}{n_turns}t {_fmt_tok(actual_tmc)}{RESET}")

    print(" | ".join(parts))


if __name__ == "__main__":
    main()
