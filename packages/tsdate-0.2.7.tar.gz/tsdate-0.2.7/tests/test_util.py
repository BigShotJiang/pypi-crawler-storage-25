# MIT License
#
# Copyright (c) 2024 Tskit Developers
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
"""
Test cases for tsdate utility functions
"""

import json
import logging

import msprime
import numpy as np
import pytest
import tsinfer
import tskit
import utility_functions

import tsdate


class TestSplitDisjointNodes:
    @staticmethod
    def has_disjoint_nodes(ts):
        """
        Brute force check for disjoint nodes, by pulling out edge intervals for
        each node; taking the union of intervals; checking that a single
        interval remains
        """

        def merge_intervals(intervals):
            intervals = sorted(intervals, key=lambda x: x[0])
            result = []
            (start_candidate, stop_candidate) = intervals[0]
            for start, stop in intervals[1:]:
                if start <= stop_candidate:
                    stop_candidate = max(stop, stop_candidate)
                else:
                    result.append((start_candidate, stop_candidate))
                    (start_candidate, stop_candidate) = (start, stop)
            result.append((start_candidate, stop_candidate))
            return result

        intervals_by_node = {i: [] for i in range(ts.num_nodes)}
        for e in ts.edges():
            intervals_by_node[e.parent].append([e.left, e.right])
            intervals_by_node[e.child].append([e.left, e.right])

        for n in range(ts.num_nodes):
            intr = merge_intervals(intervals_by_node[n])
            if len(intr) != 1:
                return True

        return False

    @staticmethod
    def childset_changes_with_root(ts):
        """
        If root nodes are split whenever their children change, the next root
        should have the same child set if it has the same ID
        """
        last_childset = frozenset()
        last_root = tskit.NULL
        for t in ts.trees():
            if t.num_edges == 0:
                last_childset = frozenset()
                last_root = tskit.NULL
            else:
                if t.num_roots > 1:
                    return False
                childset = frozenset(list(t.children(t.root)))
                if t.root == last_root and childset != last_childset:
                    return False
                last_childset = childset
                last_root = t.root
        return True

    def test_nosplit(self):
        ts = tskit.Tree.generate_comb(5).tree_sequence
        split_ts = tsdate.util.split_disjoint_nodes(ts)
        assert ts.equals(split_ts, ignore_provenance=True)
        prov = json.loads(split_ts.provenance(-1).record)
        assert prov["software"]["name"] == "tsdate"
        assert prov["parameters"]["command"] == "split_disjoint_nodes"

    def test_simple(self, caplog):
        tables = tskit.Tree.generate_comb(5).tree_sequence.dump_tables()
        tables.delete_intervals([[0.2, 0.8]])
        tables.nodes.metadata_schema = tskit.MetadataSchema.permissive_json()
        ts = tables.tree_sequence()
        num_internal_nodes = ts.num_nodes - ts.num_samples
        with caplog.at_level(logging.WARNING):
            split_ts = tsdate.util.split_disjoint_nodes(ts)
            assert caplog.text == ""
        num_new_internal_nodes = split_ts.num_nodes - split_ts.num_samples
        assert split_ts.num_nodes > ts.num_nodes
        # all internal nodes should be split

        assert num_new_internal_nodes == num_internal_nodes * 2
        for node in split_ts.nodes():
            if node.is_sample():
                assert node.flags & tsdate.NODE_SPLIT_BY_PREPROCESS == 0
            else:
                assert node.flags & tsdate.NODE_SPLIT_BY_PREPROCESS != 0

    def test_metadata_warning(self, caplog):
        # Only sets extra metadata if schema is compatible
        ts = tskit.Tree.generate_comb(5).tree_sequence
        tables = ts.dump_tables()
        tables.delete_intervals([[0.2, 0.8]])
        tables.nodes.metadata_schema = tskit.MetadataSchema(
            {
                "codec": "struct",
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            }
        )
        ts = tables.tree_sequence()
        with caplog.at_level(logging.WARNING):
            tsdate.util.split_disjoint_nodes(ts)
            assert "Could not set 'unsplit_node_id'" in caplog.text

        tables.nodes.metadata_schema = tskit.MetadataSchema(None)
        tables.nodes.packset_metadata([b"xxx"] * ts.num_nodes)
        ts = tables.tree_sequence()
        tsdate.util.split_disjoint_nodes(ts)
        assert "Could not set 'unsplit_node_id'" in caplog.text
        for node in ts.nodes():
            assert node.metadata == b"xxx"

    def test_metadata(self):
        ts = tskit.Tree.generate_comb(5).tree_sequence
        tables = ts.dump_tables()
        tables.delete_intervals([[0.2, 0.8]])
        tables.nodes.metadata_schema = tskit.MetadataSchema.permissive_json()
        tables.nodes.packset_metadata(
            [
                tables.nodes.metadata_schema.validate_and_encode_row({"xxx": f"test{x}"})
                for x in range(ts.num_nodes)
            ]
        )
        tables.nodes.flags = tables.nodes.flags | 1 << 16
        ts = tables.tree_sequence()
        split_ts = tsdate.util.split_disjoint_nodes(ts)
        is_nonsample = np.ones(split_ts.num_nodes, dtype=bool)
        is_nonsample[split_ts.samples()] = False
        _, counts = np.unique(split_ts.nodes_time[is_nonsample], return_counts=True)
        assert np.all(counts == 2)
        ids = {node.id: 0 for node in ts.nodes() if not node.is_sample()}
        for node in split_ts.nodes():
            if not node.is_sample():
                assert "unsplit_node_id" in node.metadata
                orig_node = ts.node(node.metadata["unsplit_node_id"])
                assert "unsplit_node_id" not in orig_node.metadata
                assert "xxx" in node.metadata
                assert "xxx" in orig_node.metadata
                assert node.metadata["xxx"] == orig_node.metadata["xxx"]
                assert node.time == orig_node.time
                assert node.flags == orig_node.flags | tsdate.NODE_SPLIT_BY_PREPROCESS
                ids[orig_node.id] += 1
        assert all([v == 2 for v in ids.values()])

    def test_no_provenance(self):
        ts = tskit.Tree.generate_comb(5).tree_sequence
        split_ts = tsdate.util.split_disjoint_nodes(ts, record_provenance=False)
        assert split_ts.num_provenances == ts.num_provenances
        split_ts = tsdate.util.split_disjoint_nodes(ts, record_provenance=True)
        assert split_ts.num_provenances == ts.num_provenances + 1

    def test_inferred(self):
        ts = msprime.sim_ancestry(
            10,
            population_size=1e4,
            recombination_rate=1e-8,
            sequence_length=1e6,
            random_seed=1,
        )
        # use a high mutation rate so as to get >1 mutation per site
        ts = msprime.sim_mutations(ts, rate=1e-8, random_seed=1)
        sample_data = tsinfer.SampleData.from_tree_sequence(ts)
        inferred_ts = tsinfer.infer(sample_data)
        split_ts = tsdate.util.split_disjoint_nodes(inferred_ts)
        assert self.has_disjoint_nodes(inferred_ts)
        assert not self.has_disjoint_nodes(split_ts)
        assert split_ts.num_edges == inferred_ts.num_edges
        assert split_ts.num_nodes > inferred_ts.num_nodes

    def test_worked_example(self):
        """
        The mutation table is reordered such that the mutation above 4 (7 after
        splitting) is placed after the mutation above 5.
        """
        tables = tskit.TableCollection()
        tables.nodes.set_columns(
            time=[0, 0, 0, 0, 1, 1, 2],
            flags=[tskit.NODE_IS_SAMPLE] * 4 + [0] * 3,
        )
        tables.edges.set_columns(
            left=[0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2],
            right=[1, 1, 3, 3, 1, 3, 2, 2, 3, 3, 3],
            child=[0, 1, 2, 3, 4, 5, 0, 1, 0, 1, 4],
            parent=[4, 4, 5, 5, 6, 6, 6, 6, 4, 4, 6],
        )
        site_id = tables.sites.add_row(position=2.5, ancestral_state="A")
        tables.mutations.add_row(site=site_id, node=4, time=1.5, derived_state="G")
        tables.mutations.add_row(site=site_id, node=5, time=1.5, derived_state="G")
        tables.sequence_length = 3.0
        tables.sort()
        tables.build_index()
        tables.compute_mutation_parents()
        ts = tables.tree_sequence()
        np.testing.assert_equal(ts.mutations_node, [4, 5])
        ts2 = tsdate.util.split_disjoint_nodes(ts)
        np.testing.assert_equal(ts2.mutations_node, [5, 7])


class TestPreprocessTs:
    def verify(self, ts, caplog, minimum_gap=None, erase_flanks=None, **kwargs):
        with caplog.at_level(logging.INFO):
            if minimum_gap is not None and erase_flanks is not None:
                ts = tsdate.preprocess_ts(
                    ts, minimum_gap=minimum_gap, erase_flanks=erase_flanks
                )
            elif minimum_gap is not None and erase_flanks is None:
                ts = tsdate.preprocess_ts(ts, minimum_gap=minimum_gap)
            elif erase_flanks is not None and minimum_gap is None:
                ts = tsdate.preprocess_ts(ts, erase_flanks=erase_flanks)
            else:
                ts = tsdate.preprocess_ts(ts, **kwargs)

            assert "Beginning preprocessing" in caplog.text
        return ts

    def test_invariant_sites(self, caplog):
        # Test that invariant sites are not removed by default
        # (and simularly for unused individuals & populations)
        ts = utility_functions.site_no_mutations()
        assert ts.num_sites != 0
        assert ts.num_individuals != 0
        assert ts.num_populations != 0
        removed = self.verify(ts, caplog)
        assert removed.num_sites == ts.num_sites
        assert removed.num_individuals == ts.num_individuals
        assert removed.num_populations == ts.num_populations
        assert tsdate.preprocess_ts(ts, **{"filter_sites": True}).num_sites == 0
        assert (
            tsdate.preprocess_ts(ts, **{"filter_populations": True}).num_populations == 0
        )
        assert (
            tsdate.preprocess_ts(ts, **{"filter_individuals": True}).num_individuals == 0
        )

    def test_no_intervals(self, caplog):
        ts = utility_functions.two_tree_mutation_ts()
        assert ts.tables.edges == self.verify(ts, caplog, erase_flanks=False).tables.edges
        assert ts.tables.edges == self.verify(ts, caplog, minimum_gap=0.05).tables.edges

    def test_passed_intervals(self):
        # Mostly we would not pass in user-defined intervals: this is mainly for testing
        ts = utility_functions.single_tree_ts_n3()  # No sites!
        ts = tsdate.preprocess_ts(
            ts, delete_intervals=[(0, 0.1), (0.5, ts.sequence_length)]
        )
        assert ts.num_edges > 1
        assert np.allclose(ts.edges_left, 0.1)
        assert np.allclose(ts.edges_right, 0.5)

    def test_bad_delete_intervals(self):
        ts = utility_functions.two_tree_mutation_ts()
        with pytest.raises(ValueError, match="specify both"):
            tsdate.preprocess_ts(ts, delete_intervals=[(0, 0.1)], minimum_gap=0.05)
        with pytest.raises(ValueError, match="specify both"):
            tsdate.preprocess_ts(ts, delete_intervals=[(0, 0.1)], erase_flanks=True)

    def test_delete_interval(self, caplog):
        ts = utility_functions.ts_w_data_desert(40, 60, 100)
        trimmed = self.verify(ts, caplog, minimum_gap=20, erase_flanks=False)
        lefts = trimmed.edges_left
        rights = trimmed.edges_right
        assert not np.any(np.logical_and(lefts > 41, lefts < 59))
        assert not np.any(np.logical_and(rights > 41, rights < 59))

    def test_erase_flanks(self, caplog):
        ts = utility_functions.ts_w_data_desert(0, 5, 100)
        removed = self.verify(ts, caplog, minimum_gap=ts.get_sequence_length())
        lefts = removed.tables.edges.left
        rights = removed.tables.edges.right
        assert not np.any(np.logical_and(lefts > 0, lefts < 4))
        assert not np.any(np.logical_and(rights > 0, rights < 4))
        ts = utility_functions.ts_w_data_desert(95, 100, 100)
        removed = self.verify(ts, caplog, minimum_gap=ts.get_sequence_length())
        lefts = removed.tables.edges.left
        rights = removed.tables.edges.right
        assert not np.any(np.logical_and(lefts > 96, lefts < 100))
        assert not np.any(np.logical_and(rights > 96, rights < 100))

    def test_no_sites(self):
        ts = tskit.Tree.generate_comb(3).tree_sequence
        with pytest.raises(ValueError, match="no sites"):
            ts = tsdate.preprocess_ts(ts)

    def test_split_disjoint(self):
        tables = tskit.Tree.generate_comb(5).tree_sequence.dump_tables()
        tables.delete_intervals([[0.2, 0.8]])
        tables.nodes.metadata_schema = tskit.MetadataSchema.permissive_json()
        tables.sites.add_row(0.1, "A")
        ts = tables.tree_sequence()
        num_nonsample_nodes = ts.num_nodes - ts.num_samples
        ts = tsdate.preprocess_ts(ts)
        num_split_nonsample_nodes = ts.num_nodes - ts.num_samples
        assert num_split_nonsample_nodes == 2 * num_nonsample_nodes

    def test_no_split_disjoint(self):
        tables = tskit.Tree.generate_comb(5).tree_sequence.dump_tables()
        tables.delete_intervals([[0.2, 0.8]])
        tables.sites.add_row(0.1, "A")
        ts = tables.tree_sequence()
        num_nodes = ts.num_nodes
        ts = tsdate.preprocess_ts(ts, split_disjoint=False)
        assert ts.num_nodes == num_nodes

    def test_is_simplified(self):
        tables = tskit.Tree.generate_comb(5).tree_sequence.dump_tables()
        tables.simplify(np.arange(4), keep_unary=True)  # leaves a unary node
        tables.sites.add_row(0.5, "A")
        tables.populations.add_row()
        tables.individuals.add_row()
        ts = tables.tree_sequence()
        tree = ts.first()
        # Check there is a single unary node
        assert sum(tree.num_children(u) == 1 for u in tree.nodes()) == 1
        num_nodes = ts.num_nodes
        num_populations = ts.num_populations
        num_sites = ts.num_sites
        num_individuals = ts.num_individuals
        ts = tsdate.preprocess_ts(ts)
        assert ts.num_nodes == num_nodes - 1  # Unary node removed
        assert ts.num_populations == num_populations
        assert ts.num_sites == num_sites
        assert ts.num_individuals == num_individuals

    def test_simplified_params_passed(self):
        tables = tskit.Tree.generate_comb(3).tree_sequence.dump_tables()
        tables.sites.add_row(0.5, "A")
        tables.populations.add_row()
        tables.individuals.add_row()
        ts = tables.tree_sequence()
        num_populations = ts.num_populations
        num_individuals = ts.num_individuals
        ts = tsdate.preprocess_ts(ts, filter_individuals=True)
        assert ts.num_populations == num_populations
        assert ts.num_individuals == num_individuals - 1

    def test_record_provenance(self):
        tables = tskit.Tree.generate_comb(3).tree_sequence.dump_tables()
        tables.sites.add_row(0.5, "A")
        ts = tables.tree_sequence()
        num_provenances = ts.num_provenances
        ts = tsdate.preprocess_ts(ts)
        assert ts.num_provenances == num_provenances + 1
        prov = json.loads(ts.provenance(-1).record)
        assert prov["software"]["name"] == "tsdate"
        assert prov["parameters"]["command"] == "preprocess_ts"
        ts = tsdate.preprocess_ts(ts, record_provenance=False)
        assert ts.num_provenances == num_provenances + 1

    def test_no_erase_flanks(self):
        tables = tskit.Tree.generate_comb(3, span=100).tree_sequence.dump_tables()
        tables.sites.add_row(10, "A")
        tables.sites.add_row(90, "A")
        ts = tables.tree_sequence()
        assert ts.sequence_length == 100
        assert ts.num_trees == 1
        for param_name in ("erase_flanks", "remove_telomeres"):
            params = {param_name: False}
            new_ts = tsdate.preprocess_ts(ts, **params)
            assert new_ts.num_trees == 1
            assert new_ts.sequence_length == 100

    @pytest.mark.parametrize("bool1", [True, False])
    @pytest.mark.parametrize("bool2", [True, False])
    def test_erase_flanks_telomeres_combo(self, bool1, bool2):
        ts = tskit.Tree.generate_comb(3, span=100).tree_sequence
        with pytest.raises(ValueError, match="specify both"):
            tsdate.preprocess_ts(ts, erase_flanks=bool1, remove_telomeres=bool2)

    def test_sim_example(self):
        # Test a larger example
        ts = msprime.sim_ancestry(
            20,
            sequence_length=1e4,
            recombination_rate=0.0005,
            record_full_arg=True,
            random_seed=1,
        )
        tables = msprime.sim_mutations(ts, rate=0.01, random_seed=1).dump_tables()
        tables.nodes.metadata_schema = tskit.MetadataSchema.permissive_json()
        ts = tables.tree_sequence()
        num_nodes = ts.simplify().num_nodes
        num_trees = ts.simplify().num_trees
        assert num_trees > 50
        ts = tsdate.preprocess_ts(ts)
        assert ts.num_nodes > num_nodes  # Nodes added by split_disjoint
        assert np.sum((ts.nodes_flags & tsdate.NODE_SPLIT_BY_PREPROCESS) != 0) > 0
        first_empty = int(ts.first().num_edges == 0)
        last_empty = int(ts.last().num_edges == 0)
        # Next assumes no breakpoints before first site or after last
        assert ts.num_trees == num_trees + first_empty + last_empty

    @pytest.mark.parametrize("split_disjoint", [True, False])
    @pytest.mark.parametrize("keep_unary", [True, False])
    def test_mutation_order(self, split_disjoint, keep_unary):
        """
        Check that mutations are in sorted order after preprocessing
        """
        tables = tskit.TableCollection()
        tables.nodes.set_columns(
            time=[0, 0, 0, 0, 1, 1.5, 1.25, 2],
            flags=[tskit.NODE_IS_SAMPLE] * 4 + [0] * 4,
        )
        tables.edges.set_columns(
            left=[0, 0, 0, 0, 0, 0, 0],
            right=[3, 3, 3, 3, 3, 3, 3],
            child=[0, 1, 2, 3, 4, 5, 6],
            parent=[4, 4, 6, 6, 5, 7, 7],
        )
        site_id = tables.sites.add_row(position=2.5, ancestral_state="A")
        tables.mutations.add_row(
            site=site_id, node=5, time=tskit.UNKNOWN_TIME, derived_state="G"
        )
        tables.mutations.add_row(
            site=site_id, node=6, time=tskit.UNKNOWN_TIME, derived_state="G"
        )
        tables.sequence_length = 3.0
        tables.sort()
        tables.build_index()
        tables.compute_mutation_parents()
        ts0 = tables.tree_sequence()
        tables.simplify(keep_unary=keep_unary)
        tables.sort()
        ts1 = tables.tree_sequence()
        ts2 = tsdate.preprocess_ts(
            ts0, split_disjoint=split_disjoint, keep_unary=keep_unary
        )
        assert np.array_equal(ts1.mutations_node, ts2.mutations_node)


class TestUnaryNodeCheck:
    def test_inferred(self):
        ts = msprime.sim_ancestry(
            10,
            population_size=1e4,
            recombination_rate=1e-8,
            sequence_length=1e6,
            random_seed=1,
        )
        ts = msprime.sim_mutations(ts, rate=1e-8, random_seed=1)
        sample_data = tsinfer.SampleData.from_tree_sequence(ts)
        inferred_ts = tsinfer.infer(sample_data)
        simplified_ts = inferred_ts.simplify()
        assert tsdate.util.contains_unary_nodes(inferred_ts)
        assert not tsdate.util.contains_unary_nodes(simplified_ts)
        with pytest.raises(ValueError, match="contains unary nodes"):
            tsdate.date(inferred_ts, mutation_rate=1e-8, method="variational_gamma")

    def test_simulated(self):
        ts = msprime.sim_ancestry(
            10,
            population_size=1e4,
            recombination_rate=1e-8,
            sequence_length=1e6,
            random_seed=1,
            record_full_arg=True,
        )
        ts = msprime.sim_mutations(ts, rate=1e-8, random_seed=1)
        simplified_ts = ts.simplify()
        assert tsdate.util.contains_unary_nodes(ts)
        assert not tsdate.util.contains_unary_nodes(simplified_ts)
        with pytest.raises(ValueError, match="contains unary nodes"):
            tsdate.date(ts, mutation_rate=1e-8, method="variational_gamma")


class TestInferencePipeline:
    """
    Test that tsinfer->preprocess_ts->tsdate runs through
    """

    def test_inference_pipeline(self):
        ts = msprime.sim_ancestry(
            10,
            population_size=1e4,
            recombination_rate=1e-8,
            sequence_length=1e6,
            random_seed=1,
        )
        print(tskit.__version__, tsinfer.__version__)
        ts = msprime.sim_mutations(ts, rate=1e-8, random_seed=1)
        sample_data = tsinfer.SampleData.from_tree_sequence(ts)
        tsdate.date(
            tsdate.preprocess_ts(tsinfer.infer(sample_data)),
            mutation_rate=1e-8,
        )
