# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CLI entry point — assembles all command groups."""

import importlib

import click

from vijil_cli.commands.auth import auth
from vijil_cli.commands.team import team

# Generated command groups are loaded dynamically so the CLI still works
# even if some groups haven't been generated yet.
_GENERATED_GROUPS = [
    "agent",
    "eval",
    "harness",
    "dome",
    "telemetry",
    "evolution",
    "proposal",
    "genome",
    "persona",
    "demographics",
    "dimensions",
    "policy",
    "redteam",
    "dashboard",
]


@click.group()
@click.version_option(package_name="vijil-console")
def cli() -> None:
    """Vijil CLI — manage agents, evaluations, and evolutions."""


# Hand-written command groups
cli.add_command(auth)
cli.add_command(team)

# Load generated command groups
for _name in _GENERATED_GROUPS:
    try:
        mod = importlib.import_module(f"vijil_cli.commands.{_name}")
        group = getattr(mod, _name, None)
        if group:
            cli.add_command(group)
    except ModuleNotFoundError as exc:
        if exc.name == f"vijil_cli.commands.{_name}":
            pass  # group not yet generated — skip silently
        else:
            raise  # real import error — surface it
