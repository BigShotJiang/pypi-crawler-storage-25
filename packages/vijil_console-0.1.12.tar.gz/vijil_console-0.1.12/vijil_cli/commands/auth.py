# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Authentication commands — always hand-written (not generated)."""

import click
import httpx

from vijil_cli.config import load_config, save_config


@click.group()
def auth() -> None:
    """Authentication and CLI configuration."""


@auth.command()
@click.option("--url", prompt="Vijil Console URL", help="Base URL of the Vijil Console gateway.")
def init(url: str) -> None:
    """Configure the Vijil Console URL."""
    url = url.rstrip("/")

    # The nginx gateway has no root /healthz; check the teams service health endpoint.
    try:
        resp = httpx.get(f"{url}/teams/healthz", timeout=10)
        resp.raise_for_status()
    except Exception:
        raise click.ClickException(f"Cannot reach {url}/teams/healthz — check the URL and try again.")

    cfg = load_config()
    cfg["console_url"] = url
    save_config(cfg)
    click.echo(f"Saved console URL: {url}")


@auth.command()
@click.option("--email", prompt=True, help="Account email.")
@click.option("--password", prompt=True, hide_input=True, help="Account password.")
def login(email: str, password: str) -> None:
    """Log in and store credentials."""
    cfg = load_config()
    url = cfg.get("console_url")
    if not url:
        raise click.ClickException("Not configured. Run 'vijil auth init' first.")

    resp = httpx.post(
        f"{url}/v1/auth/jwt/login",
        json={"email": email, "password": password},
        timeout=30,
    )
    if resp.status_code != 200:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise click.ClickException(f"Login failed ({resp.status_code}): {detail}")

    data = resp.json()
    cfg["auth_token"] = data.get("access_token", "")
    save_config(cfg)

    # Fetch user info and team memberships
    headers = {"Authorization": f"Bearer {cfg['auth_token']}"}
    me_resp = httpx.get(f"{url}/v1/auth/users/me", headers=headers, timeout=10)
    if me_resp.status_code == 200:
        me = me_resp.json()
        click.echo(f"Logged in as {me.get('email', email)}")

    teams_resp = httpx.get(f"{url}/v1/users/me/teams", headers=headers, timeout=10)
    if teams_resp.status_code == 200:
        teams = teams_resp.json()
        if isinstance(teams, list) and len(teams) == 1:
            tid = teams[0].get("team_id") or teams[0].get("id", "")
            if tid:
                cfg["default_team_id"] = tid
                save_config(cfg)
                click.echo(f"Default team set: {tid}")
        elif isinstance(teams, list) and len(teams) > 1:
            click.echo("Multiple teams available — run 'vijil team use <team_id>' to select one:")
            for t in teams:
                tid = t.get("team_id") or t.get("id", "")
                click.echo(f"  {tid}  {t.get('team_name', '')}")


@auth.command()
@click.option("--current-password", prompt=True, hide_input=True, help="Current account password.")
@click.option("--new-password", prompt=True, hide_input=True, confirmation_prompt=True, help="New account password.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def change_password(current_password: str, new_password: str, as_json: bool) -> None:
    """Change the current account password and store the new token."""
    cfg = load_config()
    url = cfg.get("console_url")
    token = cfg.get("auth_token")
    if not url:
        raise click.ClickException("Not configured. Run 'vijil auth init' first.")
    if not token:
        raise click.ClickException("Not authenticated. Run 'vijil auth login' first.")

    resp = httpx.post(
        f"{url}/v1/auth/change-password",
        json={
            "current_password": current_password,
            "new_password": new_password,
        },
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    )
    if resp.status_code != 200:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise click.ClickException(f"Password change failed ({resp.status_code}): {detail}")

    data = resp.json()
    cfg["auth_token"] = data.get("access_token", token)
    save_config(cfg)

    if as_json:
        click.echo(resp.text)
        return

    click.echo("Password changed successfully.")


@auth.command()
def logout() -> None:
    """Clear stored credentials."""
    cfg = load_config()
    cfg.pop("auth_token", None)
    cfg.pop("refresh_token", None)  # clean up legacy config entries
    save_config(cfg)
    click.echo("Logged out.")
