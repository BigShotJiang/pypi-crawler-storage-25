# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json


@click.group()
def dashboard():
    """Trust dashboard."""


@dashboard.command("show")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dashboard_show(as_json):
    """Get Trust Dashboard"""
    resp = api().get("/v1/dashboard/trust")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
