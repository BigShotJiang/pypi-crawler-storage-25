# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Team commands — always hand-written (not generated)."""

import click

from vijil_cli.client import api
from vijil_cli.config import load_config, save_config
from vijil_cli.output import print_json, print_table


@click.group()
def team() -> None:
    """Manage team context."""


@team.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def team_list(as_json: bool) -> None:
    """List teams you belong to."""
    resp = api().get("/v1/users/me/teams")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else data.get("results", [])
        print_table(rows, columns=["team_id", "user_id", "role"])


@team.command("use")
@click.argument("team_id")
def team_use(team_id: str) -> None:
    """Set the active team for subsequent commands."""
    cfg = load_config()
    cfg["default_team_id"] = team_id
    save_config(cfg)
    click.echo(f"Active team: {team_id}")
