# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def proposal():
    """Manage mutation proposals."""


@proposal.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_list(as_json):
    """GET /v1/proposals/"""
    resp = api().get("/v1/proposals/")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "status", "created_at"])

@proposal.command("get")
@click.argument("proposal_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_get(proposal_id, as_json):
    """GET /v1/proposals/{proposal_id}"""
    resp = api().get(f"/v1/proposals/{proposal_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@proposal.command("approve")
@click.argument("proposal_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_approve(proposal_id, as_json):
    """POST /v1/proposals/{proposal_id}/approve"""
    resp = api().post(f"/v1/proposals/{proposal_id}/approve", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@proposal.command("reject")
@click.argument("proposal_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_reject(proposal_id, as_json):
    """POST /v1/proposals/{proposal_id}/reject"""
    resp = api().post(f"/v1/proposals/{proposal_id}/reject", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
