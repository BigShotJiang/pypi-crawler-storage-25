# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_diamond.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def harness():
    """Manage test harnesses."""


@harness.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def harness_list(as_json):
    """List Harnesses"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get("/v1/harnesses/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "description"])

@harness.command("custom-list")
@click.option("--limit", type=int, help="Maximum number of results (default 10)")
@click.option("--offset", type=int, help="Number of results to skip for paging")
@click.option("--status", help="Filter by status")
@click.option("--agent-id", help="Filter by agent ID")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def harness_custom_list(limit, offset, status, agent_id, as_json):
    """List Custom Harnesses"""
    params = {}
    params["team_id"] = require_team_id()
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    if status is not None:
        params["status"] = status
    if agent_id is not None:
        params["agent_id"] = agent_id
    resp = api().get("/v1/custom-harnesses/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "status", "created_at"])

@harness.command("custom-create")
@click.option("--id", help="Id")
@click.option("--name", required=True, help="Name")
@click.option("--description", help="Description")
@click.option("--agent-id", required=True, help="Agent Id")
@click.option("--persona-ids", help="Persona Ids (JSON array)")
@click.option("--policy-ids", help="Policy Ids (JSON array)")
@click.option("--system-prompt", help="AUT description or system prompt for harness generation. If not provided, agent description will be used.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def harness_custom_create(id, name, description, agent_id, persona_ids, policy_ids, system_prompt, as_json):
    """Create Custom Harness"""
    params = {}
    params["team_id"] = require_team_id()
    import json as _json
    body = {}
    if id is not None:
        body["id"] = id
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if agent_id is not None:
        body["agent_id"] = agent_id
    if persona_ids is not None:
        body["persona_ids"] = _json.loads(persona_ids)
    if policy_ids is not None:
        body["policy_ids"] = _json.loads(policy_ids)
    if system_prompt is not None:
        body["system_prompt"] = system_prompt
    resp = api().post("/v1/custom-harnesses/", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@harness.command("custom-get")
@click.argument("harness_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def harness_custom_get(harness_id, as_json):
    """Get Custom Harness"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/custom-harnesses/{harness_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@harness.command("custom-delete")
@click.argument("harness_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def harness_custom_delete(harness_id, as_json, yes):
    """Delete Custom Harness"""
    if not yes and not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().delete(f"/v1/custom-harnesses/{harness_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@harness.command("custom-cancel")
@click.argument("harness_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def harness_custom_cancel(harness_id, as_json):
    """Cancel Custom Harness"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().post(f"/v1/custom-harnesses/{harness_id}/cancel", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@harness.command("custom-prompts")
@click.argument("harness_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def harness_custom_prompts(harness_id, as_json):
    """Get Custom Harness Prompts"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/custom-harnesses/{harness_id}/prompts", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
