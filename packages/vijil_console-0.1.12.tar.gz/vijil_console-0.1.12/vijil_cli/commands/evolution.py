# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json


@click.group()
def evolution():
    """Darwin evolution engine."""


@evolution.command("run")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def evolution_run(agent_id, as_json, wait):
    """POST /v1/agents/{agent_id}/evolutions"""
    resp = api().post(f"/v1/agents/{agent_id}/evolutions", json={})
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/v1/agents/{agent_id}/evolutions/{data['id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@evolution.command("status")
@click.argument("agent_id")
@click.argument("evolution_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def evolution_status(agent_id, evolution_id, as_json):
    """GET /v1/agents/{agent_id}/evolutions/{evolution_id}"""
    resp = api().get(f"/v1/agents/{agent_id}/evolutions/{evolution_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
