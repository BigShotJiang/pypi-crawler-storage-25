# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def policy():
    """Manage compliance policies."""


@policy.command("list")
@click.option("--category")
@click.option("--status")
@click.option("--search")
@click.option("--limit", type=int, help="Maximum number of results (default 10)")
@click.option("--offset", type=int, help="Number of results to skip for paging")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_list(category, status, search, limit, offset, as_json):
    """List Policies"""
    params = {}
    if category is not None:
        params["category"] = category
    if status is not None:
        params["status"] = status
    if search is not None:
        params["search"] = search
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/policies/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "category", "status"])

@policy.command("create")
@click.option("--id", help="Id")
@click.option("--name", required=True, help="Name")
@click.option("--description", help="Description")
@click.option("--category", type=click.Choice(["privacy", "ethics", "security", "compliance", "operational", "brand", "custom"]), required=True, help="Category of policy doc...")
@click.option("--source-text", help="Source Text")
@click.option("--tags", help="Tags (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_create(id, name, description, category, source_text, tags, as_json):
    """Create Policy"""
    import json as _json
    body = {}
    if id is not None:
        body["id"] = id
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if category is not None:
        body["category"] = category
    if source_text is not None:
        body["source_text"] = source_text
    if tags is not None:
        body["tags"] = _json.loads(tags)
    resp = api().post("/v1/policies/", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("get")
@click.argument("policy_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_get(policy_id, as_json):
    """Get Policy"""
    resp = api().get(f"/v1/policies/{policy_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("delete")
@click.argument("policy_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def policy_delete(policy_id, as_json, yes):
    """Delete Policy"""
    if not yes and not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/v1/policies/{policy_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("patch")
@click.argument("policy_id")
@click.option("--name", help="Name")
@click.option("--description", help="Description")
@click.option("--category", type=click.Choice(["privacy", "ethics", "security", "compliance", "operational", "brand", "custom"]), help="Category of policy document.")
@click.option("--status", type=click.Choice(["draft", "active", "archived"]), help="Status of a policy document.")
@click.option("--source-text", help="Source Text")
@click.option("--tags", help="Tags (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_patch(policy_id, name, description, category, status, source_text, tags, as_json):
    """Update Policy"""
    import json as _json
    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if category is not None:
        body["category"] = category
    if status is not None:
        body["status"] = status
    if source_text is not None:
        body["source_text"] = source_text
    if tags is not None:
        body["tags"] = _json.loads(tags)
    resp = api().patch(f"/v1/policies/{policy_id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("preset-list")
@click.option("--category")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_preset_list(category, limit, offset, as_json):
    """List Presets"""
    params = {}
    if category is not None:
        params["category"] = category
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/policies/presets/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "description"])

@policy.command("from-preset")
@click.argument("preset_id")
@click.option("--name-override")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_from_preset(preset_id, name_override, as_json):
    """Copy Preset"""
    params = {}
    if name_override is not None:
        params["name_override"] = name_override
    resp = api().post(f"/v1/policies/presets/{preset_id}/copy", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("activate")
@click.argument("policy_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_activate(policy_id, as_json):
    """Activate Policy"""
    resp = api().post(f"/v1/policies/{policy_id}/activate", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("file-delete")
@click.argument("policy_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def policy_file_delete(policy_id, as_json, yes):
    """Delete File"""
    if not yes and not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/v1/policies/{policy_id}/file")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("rules")
@click.argument("policy_id")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_rules(policy_id, limit, offset, as_json):
    """List Policy Rules"""
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get(f"/v1/policies/{policy_id}/rules", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "status"])

@policy.command("add-rule")
@click.argument("policy_id")
@click.option("--id", help="Id")
@click.option("--rule-id", help="Rule Id")
@click.option("--rule-type", type=click.Choice(["permission", "prohibition", "obligation", "recommendation"]), required=True, help="Type of policy rule (ODRL-inspired).")
@click.option("--action", required=True, help="Action")
@click.option("--target", help="Target")
@click.option("--assignee", help="Assignee")
@click.option("--constraints", help="Constraints (JSON array)")
@click.option("--conditions", help="Conditions (JSON array)")
@click.option("--constraint-logic", help="Constraint Logic")
@click.option("--consequence", required=True, help="Consequence (JSON object)")
@click.option("--natural-language", required=True, help="Natural Language")
@click.option("--category", type=click.Choice(["privacy", "ethics", "security", "compliance", "operational", "brand", "custom"]), help="Category of policy document.")
@click.option("--status", type=click.Choice(["draft", "approved", "rejected", "modified"]), help="Review status of a policy rule.")
@click.option("--tags", help="Tags (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_add_rule(
    policy_id,
    id,
    rule_id,
    rule_type,
    action,
    target,
    assignee,
    constraints,
    conditions,
    constraint_logic,
    consequence,
    natural_language,
    category,
    status,
    tags,
    as_json,
):
    """Create Policy Rule"""
    import json as _json
    body = {}
    if id is not None:
        body["id"] = id
    if rule_id is not None:
        body["rule_id"] = rule_id
    if rule_type is not None:
        body["rule_type"] = rule_type
    if action is not None:
        body["action"] = action
    if target is not None:
        body["target"] = target
    if assignee is not None:
        body["assignee"] = assignee
    if constraints is not None:
        body["constraints"] = _json.loads(constraints)
    if conditions is not None:
        body["conditions"] = _json.loads(conditions)
    if constraint_logic is not None:
        body["constraint_logic"] = constraint_logic
    if consequence is not None:
        body["consequence"] = _json.loads(consequence)
    if natural_language is not None:
        body["natural_language"] = natural_language
    if category is not None:
        body["category"] = category
    if status is not None:
        body["status"] = status
    if tags is not None:
        body["tags"] = _json.loads(tags)
    resp = api().post(f"/v1/policies/{policy_id}/rules", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("rule-list")
@click.option("--policy-id")
@click.option("--status")
@click.option("--category")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_rule_list(policy_id, status, category, limit, offset, as_json):
    """List Rules"""
    params = {}
    if policy_id is not None:
        params["policy_id"] = policy_id
    if status is not None:
        params["status"] = status
    if category is not None:
        params["category"] = category
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/rules/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "policy_id", "status"])

@policy.command("rule-get")
@click.argument("rule_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_rule_get(rule_id, as_json):
    """Get Rule"""
    resp = api().get(f"/v1/rules/{rule_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("rule-delete")
@click.argument("rule_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def policy_rule_delete(rule_id, as_json, yes):
    """Delete Rule"""
    if not yes and not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/v1/rules/{rule_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("patch-rule")
@click.argument("rule_id")
@click.option("--rule-type", type=click.Choice(["permission", "prohibition", "obligation", "recommendation"]), help="Type of policy rule (ODRL-inspired).")
@click.option("--action", help="Action")
@click.option("--target", help="Target")
@click.option("--assignee", help="Assignee")
@click.option("--constraints", help="Constraints (JSON array)")
@click.option("--conditions", help="Conditions (JSON array)")
@click.option("--constraint-logic", help="Constraint Logic")
@click.option("--consequence", help="Consequence (JSON object)")
@click.option("--natural-language", help="Natural Language")
@click.option("--category", type=click.Choice(["privacy", "ethics", "security", "compliance", "operational", "brand", "custom"]), help="Category of policy document.")
@click.option("--status", type=click.Choice(["draft", "approved", "rejected", "modified"]), help="Review status of a policy rule.")
@click.option("--tags", help="Tags (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_patch_rule(rule_id, rule_type, action, target, assignee, constraints, conditions, constraint_logic, consequence, natural_language, category, status, tags, as_json):
    """Update Rule"""
    import json as _json
    body = {}
    if rule_type is not None:
        body["rule_type"] = rule_type
    if action is not None:
        body["action"] = action
    if target is not None:
        body["target"] = target
    if assignee is not None:
        body["assignee"] = assignee
    if constraints is not None:
        body["constraints"] = _json.loads(constraints)
    if conditions is not None:
        body["conditions"] = _json.loads(conditions)
    if constraint_logic is not None:
        body["constraint_logic"] = constraint_logic
    if consequence is not None:
        body["consequence"] = _json.loads(consequence)
    if natural_language is not None:
        body["natural_language"] = natural_language
    if category is not None:
        body["category"] = category
    if status is not None:
        body["status"] = status
    if tags is not None:
        body["tags"] = _json.loads(tags)
    resp = api().patch(f"/v1/rules/{rule_id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("approve-rule")
@click.argument("rule_id")
@click.option("--notes")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_approve_rule(rule_id, notes, as_json):
    """Approve Rule"""
    params = {}
    if notes is not None:
        params["notes"] = notes
    resp = api().post(f"/v1/rules/{rule_id}/approve", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@policy.command("reject-rule")
@click.argument("rule_id")
@click.option("--reason", required=True)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def policy_reject_rule(rule_id, reason, as_json):
    """Reject Rule"""
    params = {}
    if reason is not None:
        params["reason"] = reason
    resp = api().post(f"/v1/rules/{rule_id}/reject", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
