# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""HTTP client with auth, base URL, and automatic token refresh."""

from __future__ import annotations

from typing import Any

import click
import httpx

from vijil_cli.config import load_config, save_config


class SessionExpiredError(click.ClickException):
    """Raised when the JWT token cannot be refreshed."""

    def __init__(self) -> None:
        super().__init__("Session expired. Run 'vijil auth login' to re-authenticate.")


class VijilClient:
    def __init__(self) -> None:
        cfg = load_config()
        self.base_url: str = cfg.get("console_url", "")
        self.token: str = cfg.get("auth_token", "")
        if not self.base_url:
            raise click.ClickException("Not configured. Run 'vijil auth init' first.")

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _try_refresh(self) -> bool:
        """Attempt to refresh the JWT token.

        The /auth/jwt/refresh endpoint accepts a valid or expired JWT via
        the Authorization header and returns a new access_token.
        """
        if not self.token:
            return False
        try:
            resp = httpx.post(
                f"{self.base_url}/v1/auth/jwt/refresh",
                headers=self._headers(),
                timeout=30,
            )
        except httpx.HTTPError:
            return False
        if resp.status_code == 200:
            data = resp.json()
            new_token = data.get("access_token", "")
            if new_token:
                self.token = new_token
                cfg = load_config()
                cfg["auth_token"] = self.token
                save_config(cfg)
                return True
        return False

    def request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        url = f"{self.base_url.rstrip('/')}{path}"
        kwargs.setdefault("timeout", 30)
        merged = dict(kwargs.pop("headers", None) or {})
        merged.update(self._headers())
        kwargs["headers"] = merged
        resp = httpx.request(method, url, **kwargs)

        if resp.status_code == 401:
            if self._try_refresh():
                kwargs["headers"].update(self._headers())
                resp = httpx.request(method, url, **kwargs)
            if resp.status_code == 401:
                raise SessionExpiredError()

        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise click.ClickException(f"API error ({resp.status_code}): {detail}")
        return resp

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("DELETE", path, **kwargs)


def api() -> VijilClient:
    """Convenience factory used by generated commands."""
    return VijilClient()
