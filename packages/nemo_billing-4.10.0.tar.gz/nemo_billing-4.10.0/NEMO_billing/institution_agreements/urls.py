from NEMO.urls import router, sort_urls
from django.urls import path

from NEMO_billing.institution_agreements import api, views

router.register(r"billing/service_agreements", api.InstitutionAgreementViewSet)
router.registry.sort(key=sort_urls)


urlpatterns = [
    path("service_agreements/", views.institution_agreements, name="institution_agreements"),
    path(
        "service_agreements/email_institution_agreements_reminders/",
        views.email_institution_agreements_reminders,
        name="email_institution_agreements_reminders",
    ),
]
