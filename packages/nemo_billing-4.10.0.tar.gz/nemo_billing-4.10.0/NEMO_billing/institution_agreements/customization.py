from NEMO.decorators import customization
from NEMO.views.customization import CustomizationBase
from django.core.validators import validate_integer, validate_email


@customization(key="institution_agreements", title="Service Agreement")
class InstitutionAgreementCustomization(CustomizationBase):
    variables = {
        "expiration_reminder_days": "30",
        "expiration_reminder_cc": "",
    }

    def validate(self, name, value):
        if name == "expiration_reminder_days" and value is not None:
            validate_integer(value)
        elif name == "expiration_reminder_cc":
            recipients = tuple([e for e in value.split(",") if e])
            for email in recipients:
                validate_email(email)
