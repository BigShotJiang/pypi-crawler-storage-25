from django.core.management import BaseCommand

from NEMO_billing.institution_agreements.views import send_email_reminders


class Command(BaseCommand):
    help = "Run every day to send email reminders for service agreements."

    def handle(self, *args, **options):
        send_email_reminders()
