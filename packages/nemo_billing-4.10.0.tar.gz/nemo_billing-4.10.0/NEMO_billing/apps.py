from django.apps import AppConfig
from django.conf import settings

from . import app_settings as defaults

# Set some app default settings
for name in dir(defaults):
    if name.isupper() and not hasattr(settings, name):
        setattr(settings, name, getattr(defaults, name))


class NEMOBillingConfig(AppConfig):
    name = "NEMO_billing"
    verbose_name = "Billing"
    default_auto_field = "django.db.models.AutoField"

    def ready(self):
        from django.contrib import admin
        from NEMO.plugins.utils import check_extra_dependencies
        from NEMO_billing.admin import CoreFacilityAdmin, offset_with_custom_charge
        from NEMO_billing.customization import BillingCustomization
        from NEMO.mixins import BillableItemMixin
        from NEMO.templatetags.custom_tags_and_filters import app_installed

        check_extra_dependencies(self.name, ["NEMO", "NEMO-CE"])
        # update the short_description for core facility's external identifier here after initialization
        CoreFacilityAdmin.get_external_id.short_description = BillingCustomization.get(
            "billing_core_facility_external_id_name", raise_exception=False
        )

        def has_custom_charge_add_permission(self, request):
            return app_installed("NEMO_billing.invoices") and request.user.has_perm("billing.can_add_custom_charge")

        # Add the offset_with_custom_charge action to all charge types
        for charge_class in BillableItemMixin.__subclasses__():
            admin_instance = admin.site._registry.get(charge_class)
            if admin_instance:
                admin_instance.__class__.has_custom_charge_add_permission = has_custom_charge_add_permission
                current_actions = list(admin_instance.actions or [])
                if offset_with_custom_charge not in current_actions:
                    admin_instance.actions = current_actions + [offset_with_custom_charge]
