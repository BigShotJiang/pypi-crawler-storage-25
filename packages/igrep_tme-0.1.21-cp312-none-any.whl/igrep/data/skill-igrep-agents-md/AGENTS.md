## igrep — semantic search MCP

Codex should use `mcp__igrep__search` as the first search tool for semantic
repository exploration. Use it before built-in Search/Grep when the task is a
Concept / intent question, unfamiliar-code exploration, behavior lookup, or a
search across Go dependency source or indexed documents.

Default rule:

- If you know the meaning but not the exact symbol, call `mcp__igrep__search`.
- If you know the exact string, regex, or file path, use built-in
  Search/Grep/rg/Read.

## First Move

When exploring a repo, do not start with guessed keywords. If the next step
would be "search a guessed term, read files, search another guessed term", call
`mcp__igrep__search` first and send the user's natural-language goal as the
query.

Good first queries:

- `"how is auth handled"`
- `"retry backoff logic"`
- `"where does request validation happen"`
- `"JWT verification middleware"`
- `"http retry backoff"` in Go dependencies via a `go list`-resolved source dir
- `"Q3 revenue formula"` when indexed docs may contain the answer

Bad first moves:

- Translating intent into regex, e.g. `"jwt.*verify"`.
- Guessing a symbol name first, e.g. `"RateLimit"`.
- Running broad built-in search loops before trying igrep.

## Use The Results

After igrep returns, read the specific files or ranges it points to. If results
are too broad, refine the natural-language query or add `path`, `file_type`, or
`glob`. If results are empty, try one clearer semantic query before falling
back to exact search.

Use built-in Search/Grep/rg/Read instead of igrep only for exact tasks:

- exact literal or regex lookup
- exhaustive audit/refactor sweep where every match is required
- reading or searching inside an already-known file
- user explicitly asks for a literal grep/rg command

## Tool Shape

Use the concrete MCP tool name, not an alias:

```text
mcp__igrep__search(query="<natural phrase>", path="<dir-or-file>",
                   top_k=<n>, file_type=<ext>, glob=[<filters>])
```

Guidelines:

- `path` should usually be the repo root or the narrowest known directory.
- `top_k=3..5` when one answer is expected.
- `top_k=10` for normal repo exploration.
- `top_k=25..50` for broad discovery before narrowing.
- `file_type` is an extension without dot, such as `"py"`, `"ts"`, `"go"`,
  `"md"`, or `"pdf"`.
- `glob` follows ripgrep semantics; later patterns win and `!pattern`
  excludes, e.g. `["src/**", "!**/test_*"]`.
- For Go dependency/library questions, let the Go toolchain resolve the real
  source directory before calling igrep. Do not guess module-cache paths.
  Run commands from the target repo so `go.mod`, `go.work`, `replace`,
  `vendor`, `GOFLAGS`, and build tags are honored.
- If the user names a module, use
  `go list -m -f '{{.Dir}}' <module>` or `go list -m -json <module>`, then pass
  the returned `.Dir` with `file_type="go"`. If `.Replace` exists, trust
  `.Dir`; it points at the replacement source. If `.Dir` is empty, resolve an
  imported package from that module with `go list -json <import-path>` and use
  package `.Dir`.
- If the user names an imported package, use `go list -json <import-path>`.
  Search package `.Dir` for narrow package questions, or `.Module.Dir` for the
  whole library containing that package when `.Module.Dir` is non-empty. In
  vendor mode, package `.Dir` may point inside `vendor/` while module `.Dir` /
  `.Module.Dir` is empty; then package `.Dir` is authoritative. For whole
  libraries, use `vendor/<module-path>` if it exists, otherwise search the
  package dirs returned by `go list -deps -json ./...`.
- For broad dependency understanding, use `go list -deps -json ./...`, ignore
  `.Standard == true`, group external packages by `.Module.Path`,
  `.Module.Version`, and `.Module.Dir`, then search the relevant dirs. If
  `.Module.Dir` is empty but package `.Dir` is under `vendor/`, group and search
  those vendored package dirs.
- If a module is not in the active graph but a version is known, use
  `go mod download -json <module>@<version>` and search the returned `.Dir`.
  Only fall back to `$(go env GOMODCACHE)/<module>@<version>` or a narrow cache
  glob when Go cannot return a directory. `GOMODCACHE` defaults to
  `$GOPATH/pkg/mod`; module cache dirs are versioned/path-escaped and should be
  treated as read-only reference material. Use `$GOPATH/src/<import-path>` only
  for legacy GOPATH-mode or manually checked-out dependency source.

If `mcp__igrep__search` is not visible because tools are deferred, load it
with the available tool-discovery mechanism and then call it. Do not fall back
to guessed built-in searches just because the MCP tool is hidden at first.
