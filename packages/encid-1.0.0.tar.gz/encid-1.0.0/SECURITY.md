# Security Policy

`encid` is a local analysis tool for encodings, password-hash verification, and supported decrypt operations. It does not send analyzed input, passwords, keys, ciphertext, or results to a remote service.

## Supported Versions

Security fixes are applied to the latest published release and the `main` branch.

## Reporting A Vulnerability

Report vulnerabilities through GitHub Issues:

https://github.com/admin12121/encid/issues

If a report contains sensitive samples, do not post secrets, production keys, or live credentials publicly. Replace them with minimal reproducible test material whenever possible.

## Security Boundaries

- Hashes are verified when a password is supplied; they are not decrypted.
- Real encryption is decrypted only when the cipher type and required parameters are available.
- JavaScript-based encodings such as JSFuck, AAEncode, and JJEncode are identified but not executed.
- The TUI masks password/key entry, but CLI `--password` can still be captured by shell history or process listings. Prefer `--ask-password`.
- Risky decoders are opt-in because broad brute-force transforms can create false positives.
