from __future__ import annotations

import hashlib
import unittest

import bcrypt
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from encid.crypto import password_operation


class CryptoTests(unittest.TestCase):
    def test_bcrypt_password_verify(self) -> None:
        hashed = bcrypt.hashpw(b"secret-pass", bcrypt.gensalt(rounds=4)).decode()

        good = password_operation(hashed, "secret-pass")
        bad = password_operation(hashed, "wrong-pass")

        self.assertTrue(good.ok)
        self.assertEqual(good.operation, "verify")
        self.assertFalse(bad.ok)

    def test_explicit_sha256_hash_verify(self) -> None:
        digest = hashlib.sha256(b"secret-pass").hexdigest()

        result = password_operation(digest, "secret-pass", type_name="sha256")

        self.assertTrue(result.ok)
        self.assertEqual(result.type, "sha256")

    def test_xor_decrypt_with_password(self) -> None:
        plain = b"flag{xor_password_mode}"
        key = b"k"
        ciphertext = bytes(byte ^ key[index % len(key)] for index, byte in enumerate(plain))

        result = password_operation(ciphertext.hex(), "k", type_name="xor")

        self.assertTrue(result.ok)
        self.assertEqual(result.output, plain.decode())

    def test_aes_256_cbc_decrypt_with_password_and_prefixed_iv(self) -> None:
        password = "correct horse battery staple"
        plain = b"flag{aes_password_mode}"
        key = hashlib.sha256(password.encode()).digest()
        iv = bytes(range(16))
        pad_len = 16 - (len(plain) % 16)
        padded = plain + bytes([pad_len]) * pad_len
        encryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
        ciphertext = iv + encryptor.update(padded) + encryptor.finalize()

        result = password_operation(ciphertext.hex(), password, type_name="aes-256-cbc")

        self.assertTrue(result.ok)
        self.assertEqual(result.output, plain.decode())


if __name__ == "__main__":
    unittest.main()
