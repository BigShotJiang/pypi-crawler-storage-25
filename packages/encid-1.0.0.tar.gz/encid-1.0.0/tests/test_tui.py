from __future__ import annotations

import unittest

from encid.encid import EngineOptions, build_result
from encid.tui import _command_suggestions, _help_lines, _is_partial_command, _result_lines


class TuiRenderTests(unittest.TestCase):
    def test_result_render_contains_summary_trace_and_final(self) -> None:
        result = build_result(b"cGljb0NURnt0ZXN0X2ZsYWd9", EngineOptions())
        rendered = "\n".join(_result_lines(result, 88))

        self.assertIn("ENCID // TACTICAL DECODE CONSOLE", rendered)
        self.assertIn("RESULT", rendered)
        self.assertIn("CHAIN", rendered)
        self.assertIn("BASE64/BASE64URL", rendered)
        self.assertIn("picoCTF{test_flag}", rendered)

    def test_help_render_contains_commands(self) -> None:
        rendered = "\n".join(_help_lines(80))

        self.assertIn("/help", rendered)
        self.assertIn("/bye", rendered)
        self.assertIn("/risky", rendered)

    def test_command_suggestions_filter_on_slash_input(self) -> None:
        self.assertEqual(_command_suggestions(""), [])
        self.assertIn(("/help", "show commands"), _command_suggestions("/"))
        self.assertEqual(_command_suggestions("/cl"), [("/clear", "clear the console")])

    def test_decrypt_suggestions_are_stateful(self) -> None:
        locked = {"decrypt_enabled": False, "decrypt_type": None}
        unlocked = {"decrypt_enabled": True, "decrypt_type": None}

        self.assertEqual(_command_suggestions("/type", locked), [("/decrypt", "start password/key decrypt or hash verify")])
        self.assertIn(("/type aes-256-cbc", "decrypt/verify type"), _command_suggestions("/type aes", unlocked))

    def test_partial_command_detection_for_popup_accept(self) -> None:
        self.assertTrue(_is_partial_command("/"))
        self.assertTrue(_is_partial_command("/cl"))
        self.assertFalse(_is_partial_command("/clear"))
        self.assertFalse(_is_partial_command("/depth 8"))


if __name__ == "__main__":
    unittest.main()
