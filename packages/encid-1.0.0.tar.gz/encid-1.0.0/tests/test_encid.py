from __future__ import annotations

import unittest
import base64
import codecs
import urllib.parse

from encid.encid import EngineOptions, build_result


class EncidTests(unittest.TestCase):
    def analyze(self, value: str, *, risky: bool = False) -> dict:
        return build_result(value.encode(), EngineOptions(include_risky=risky))

    def test_base64_flag(self) -> None:
        result = self.analyze("cGljb0NURnt0ZXN0X2ZsYWd9")
        self.assertEqual(result["type"], "encoded")
        self.assertEqual(result["best_chain"]["final_text"], "picoCTF{test_flag}")

    def test_hash_shaped_hex_is_not_overdecoded(self) -> None:
        result = self.analyze("5d41402abc4b2a76b9719d911017c592")
        self.assertEqual(result["type"], "ambiguous")
        self.assertEqual(result["best_chain"]["layers"], [])
        self.assertIn("raw 128-bit hex material", [detection["name"] for detection in result["detections"]])
        self.assertNotIn("cipher", [detection["type"] for detection in result["detections"]])
        self.assertTrue(any("Raw fixed-length hex is ambiguous" in warning for warning in result["warnings"]))

    def test_hex_flag_decodes_despite_hash_overlap(self) -> None:
        result = self.analyze("7069636f4354467b6865785f746573747d")
        self.assertEqual(result["type"], "encoded")
        self.assertEqual(result["best_chain"]["final_text"], "picoCTF{hex_test}")
        self.assertNotIn("cipher", [detection["type"] for detection in result["detections"]])

    def test_url_then_rot13(self) -> None:
        result = self.analyze("uggcf%3A%2F%2Frknzcyr.pbz")
        self.assertEqual(result["best_chain"]["final_text"], "https://example.com")
        self.assertEqual([layer["action"] for layer in result["best_chain"]["layers"]], ["url-percent", "rot13"])

    def test_base45_not_stolen_by_url_decode(self) -> None:
        result = self.analyze("%69 VD92EX0")
        self.assertEqual(result["best_chain"]["final_text"], "Hello!!")
        self.assertEqual(result["best_chain"]["layers"][0]["action"], "base45")

    def test_plain_text_stays_plain(self) -> None:
        result = self.analyze("hello")
        self.assertEqual(result["type"], "plain/unknown")
        self.assertEqual(result["best_chain"]["layers"], [])

    def test_cyberchef_style_pipeline_continues_to_final_text(self) -> None:
        plain = "falg{admin12121}"
        base64_text = base64.b64encode(plain.encode()).decode()
        rot13_text = codecs.decode(base64_text, "rot_13")
        hex_text = " ".join(f"{byte:02x}" for byte in rot13_text.encode())
        binary_text = " ".join(f"{ord(char):08b}" for char in hex_text)
        encoded = urllib.parse.quote(binary_text, safe="")

        result = self.analyze(encoded)

        self.assertEqual(result["best_chain"]["final_text"], plain)
        self.assertEqual(
            [layer["action"] for layer in result["best_chain"]["layers"]],
            ["url-percent", "binary-8bit", "hex/base16", "rot13", "base64/base64url"],
        )

    def test_base32_rot13_charcode_pipeline_continues_to_final_text(self) -> None:
        plain = "falg{admin12121}"
        hex_text = " ".join(f"{byte:02x}" for byte in plain.encode())
        charcode_hex = " ".join(f"{ord(char):x}" for char in hex_text)
        binary_text = " ".join(f"{ord(char):08b}" for char in charcode_hex)
        base32_text = base64.b32encode(binary_text.encode()).decode()
        encoded = codecs.decode(base32_text, "rot_13")

        result = self.analyze(encoded)

        self.assertEqual(result["best_chain"]["final_text"], plain)
        self.assertEqual(
            [layer["action"] for layer in result["best_chain"]["layers"]],
            ["rot13", "base32", "binary-8bit", "hex/base16", "hex/base16"],
        )

    def test_pasted_latin1_byte_text_then_bit_rotate(self) -> None:
        plain = "softwarica{simple_substitution_cipher_is_easy_to_break}"
        rotated = bytes(((byte << 1) & 0xFF) | (byte >> 7) for byte in plain.encode())
        encoded = rotated.decode("latin-1")

        result = self.analyze(encoded)

        self.assertEqual(result["best_chain"]["final_text"], plain)
        self.assertEqual(
            [layer["action"] for layer in result["best_chain"]["layers"]],
            ["latin1-codepoint-bytes", "bit-rotate-right/1"],
        )

    def test_bcrypt_is_identified_and_not_decoded(self) -> None:
        result = self.analyze("$2b$10$d/J7oricbiXeHkPdELJYLu6UXJ6vK98ftQImJOBpGY3G.lAVRvhW.")
        self.assertEqual(result["type"], "hash")
        self.assertEqual(result["best_chain"]["layers"], [])
        self.assertEqual(result["detections"][0]["name"], "bcrypt")

    def test_shell_expanded_bcrypt_body_warns(self) -> None:
        result = self.analyze("b/J7oricbiXeHkPdELJYLu6UXJ6vK98ftQImJOBpGY3G.lAVRvhW.")
        self.assertIn("possible shell-expanded bcrypt hash", [detection["name"] for detection in result["detections"]])

    def test_raw_512_bit_hex_is_labeled_ambiguous_kdf_material(self) -> None:
        value = "38124edd264f626f5dcd5061ed11d7bdae4f5bb1096955bf4a83bf4b7fe98a21ecf2bc864dbc5b561c2d84a83ab46cf2b547ebf44a0a2eff253559b051986b64"
        result = self.analyze(value)
        names = [detection["name"] for detection in result["detections"]]
        self.assertEqual(result["type"], "ambiguous")
        self.assertIn("raw 512-bit hex material", names)
        self.assertNotIn("cipher", [detection["type"] for detection in result["detections"]])

    def test_non_digest_size_hex_blob_is_not_oracle_hash(self) -> None:
        value = "87c45e295ff2b64a941544ca13f805b9d6c8d05fb3af8ccd3c438629eaecf5af18db34f41642bd3f5f9ab68dc9f5cf6b23d7818c537f2c20"
        result = self.analyze(value)
        self.assertEqual(result["type"], "encryption-candidate")
        self.assertNotIn("Oracle hash candidate", [detection["name"] for detection in result["detections"]])

    def test_specific_identifier_outranks_raw_hex_material(self) -> None:
        result = self.analyze("0x742d35Cc6634C0532925a3b844Bc454e4438f44e")
        self.assertEqual(result["type"], "identifier")
        self.assertIn("Ethereum address", [detection["name"] for detection in result["detections"]])

    def test_morse_case_loss_warns_for_base64_like_output(self) -> None:
        value = ".--. ..--- ----. --.. --.- ..- --.- ..- .--. --.. -.-- .-- .-.. -.- --. -- -. .--- .---- .--- --- - .. ... .--. ...-- .. ...- .--. ...-- . -.-. --.- ..- .. ----- -. .--- ----. .... -.- ..--- .- -.-. .--. - ..- -.-- .--. -.-- ----. -.-. .--. .---- ----. -.-- .-.. -.- .- ..... -.- ...-- . .. -.- ..--- .-- .-.. -- .--- ... . ... -.. -...- -...-"
        result = self.analyze(value)
        self.assertTrue(result["warnings"])
        self.assertIn("Morse does not preserve letter case", result["warnings"][0])

    def test_flag_shaped_rot13_output_can_continue(self) -> None:
        plain = "softwarica{simple_substitution_cipher_is_easy_to_break}"
        rot13_text = codecs.decode(plain, "rot_13")
        hex_text = " ".join(f"{byte:02x}" for byte in rot13_text.encode())
        charcode_hex = " ".join(f"{ord(char):x}" for char in hex_text)
        encoded = base64.b32encode(charcode_hex.encode()).decode()

        result = self.analyze(encoded)

        self.assertEqual(result["best_chain"]["final_text"], plain)
        self.assertEqual(
            [layer["action"] for layer in result["best_chain"]["layers"]],
            ["base32", "hex/base16", "hex/base16", "rot13"],
        )

    def test_plain_english_is_not_classical_cipher_signal(self) -> None:
        result = self.analyze("this is normal readable text with several common english words")
        self.assertNotIn("cipher", [detection["type"] for detection in result["detections"]])


if __name__ == "__main__":
    unittest.main()
