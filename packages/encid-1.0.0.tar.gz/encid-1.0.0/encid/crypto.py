from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import re
from dataclasses import dataclass, field

from encid.scoring import FLAG_SHAPE_RE, entropy, is_good_text, preview, printable_ratio, score_text


SUPPORTED_TYPES = (
    "auto",
    "bcrypt",
    "django-pbkdf2-sha256",
    "django-pbkdf2-sha1",
    "ldap-sha",
    "ldap-ssha",
    "md5",
    "sha1",
    "sha224",
    "sha256",
    "sha384",
    "sha512",
    "sha3-256",
    "sha3-512",
    "blake2b",
    "xor",
    "openssl-aes-256-cbc",
    "aes-128-cbc",
    "aes-192-cbc",
    "aes-256-cbc",
    "aes-128-ecb",
    "aes-192-ecb",
    "aes-256-ecb",
    "aes-128-ctr",
    "aes-192-ctr",
    "aes-256-ctr",
    "aes-128-gcm",
    "aes-192-gcm",
    "aes-256-gcm",
    "chacha20-poly1305",
    "fernet",
)

TYPE_ALIASES = {
    "aes": "aes-256-cbc",
    "aes128": "aes-128-cbc",
    "aes192": "aes-192-cbc",
    "aes256": "aes-256-cbc",
    "aes-128": "aes-128-cbc",
    "aes-192": "aes-192-cbc",
    "aes-256": "aes-256-cbc",
    "aes256cbc": "aes-256-cbc",
    "aes256-cbc": "aes-256-cbc",
    "aes-256cbc": "aes-256-cbc",
    "openssl": "openssl-aes-256-cbc",
    "openssl-aes": "openssl-aes-256-cbc",
    "openssl-aes256": "openssl-aes-256-cbc",
    "sha3_256": "sha3-256",
    "sha3_512": "sha3-512",
    "django-pbkdf2": "django-pbkdf2-sha256",
}

HASH_TYPES = {
    "bcrypt",
    "django-pbkdf2-sha256",
    "django-pbkdf2-sha1",
    "ldap-sha",
    "ldap-ssha",
    "md5",
    "sha1",
    "sha224",
    "sha256",
    "sha384",
    "sha512",
    "sha3-256",
    "sha3-512",
    "blake2b",
}


@dataclass(frozen=True)
class PasswordResult:
    operation: str
    type: str
    ok: bool
    status: str
    confidence: float
    output: str = ""
    evidence: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "operation": self.operation,
            "type": self.type,
            "ok": self.ok,
            "status": self.status,
            "confidence": round(max(0.0, min(1.0, self.confidence)), 3),
            "output": self.output,
            "evidence": list(self.evidence),
            "warnings": list(self.warnings),
        }


def supported_types() -> tuple[str, ...]:
    return SUPPORTED_TYPES


def normalize_type(type_name: str | None) -> str:
    if not type_name:
        return "auto"
    compact = type_name.strip().lower().replace("_", "-")
    return TYPE_ALIASES.get(compact, compact)


def password_operation(
    value: str,
    password: str,
    *,
    type_name: str | None = None,
    encoding: str = "auto",
    key_hex: str | None = None,
    iv_hex: str | None = None,
    salt_hex: str | None = None,
    tag_hex: str | None = None,
    kdf: str = "auto",
    iterations: int = 100_000,
    no_padding: bool = False,
) -> PasswordResult:
    typ = normalize_type(type_name)
    if not password and not key_hex:
        return _result("decrypt", typ, False, "password or key is required", 0.0)

    detected = _detect_password_type(value)
    if typ == "auto":
        typ = detected or "auto"

    if typ in HASH_TYPES:
        return verify_password(value, password, typ)

    if typ == "auto":
        return _result(
            "decrypt",
            typ,
            False,
            "type is required for ambiguous encrypted data",
            0.0,
            warnings=("Use --type or TUI /type. Password alone does not identify AES mode, IV, salt, or KDF.",),
        )

    try:
        return decrypt_with_password(
            value,
            password,
            typ,
            encoding=encoding,
            key_hex=key_hex,
            iv_hex=iv_hex,
            salt_hex=salt_hex,
            tag_hex=tag_hex,
            kdf=kdf,
            iterations=iterations,
            no_padding=no_padding,
        )
    except ValueError as exc:
        return _result("decrypt", typ, False, str(exc), 0.0)


def verify_password(value: str, password: str, type_name: str | None = None) -> PasswordResult:
    typ = normalize_type(type_name)
    if typ == "auto":
        typ = _detect_password_type(value) or "auto"
    if typ == "bcrypt":
        return _verify_bcrypt(value, password)
    if typ in {"django-pbkdf2-sha256", "django-pbkdf2-sha1"}:
        return _verify_django_pbkdf2(value, password, typ)
    if typ in {"ldap-sha", "ldap-ssha"}:
        return _verify_ldap_sha(value, password, typ)
    if typ in HASH_TYPES:
        return _verify_raw_digest(value, password, typ)
    return _result("verify", typ, False, f"unsupported password hash type: {typ}", 0.0)


def decrypt_with_password(
    value: str,
    password: str,
    type_name: str,
    *,
    encoding: str = "auto",
    key_hex: str | None = None,
    iv_hex: str | None = None,
    salt_hex: str | None = None,
    tag_hex: str | None = None,
    kdf: str = "auto",
    iterations: int = 100_000,
    no_padding: bool = False,
) -> PasswordResult:
    typ = normalize_type(type_name)
    if typ == "xor":
        return _decrypt_xor(value, password, encoding)
    if typ == "fernet":
        return _decrypt_fernet(value, password)
    if typ == "chacha20-poly1305":
        return _decrypt_chacha20_poly1305(value, password, encoding, key_hex, iv_hex, tag_hex, kdf, salt_hex, iterations)
    if typ == "openssl-aes-256-cbc":
        return _decrypt_openssl_aes_256_cbc(value, password, encoding, key_hex)
    if typ.startswith("aes-"):
        return _decrypt_aes(
            value,
            password,
            typ,
            encoding=encoding,
            key_hex=key_hex,
            iv_hex=iv_hex,
            salt_hex=salt_hex,
            tag_hex=tag_hex,
            kdf=kdf,
            iterations=iterations,
            no_padding=no_padding,
        )
    return _result(
        "decrypt",
        typ,
        False,
        f"unsupported encryption type: {typ}",
        0.0,
        warnings=("Supported types are shown by `encid decrypt --list-types`.",),
    )


def _detect_password_type(value: str) -> str | None:
    stripped = value.strip()
    if re.fullmatch(r"\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}", stripped):
        return "bcrypt"
    if stripped.startswith("pbkdf2_sha256$"):
        return "django-pbkdf2-sha256"
    if stripped.startswith("pbkdf2_sha1$"):
        return "django-pbkdf2-sha1"
    if re.fullmatch(r"\{SHA\}[A-Za-z0-9+/=]+", stripped, re.IGNORECASE):
        return "ldap-sha"
    if re.fullmatch(r"\{SSHA\}[A-Za-z0-9+/=]+", stripped, re.IGNORECASE):
        return "ldap-ssha"
    compact = re.sub(r"\s+", "", stripped)
    if compact.startswith("U2FsdGVkX1") or stripped.encode("latin-1", errors="ignore").startswith(b"Salted__"):
        return "openssl-aes-256-cbc"
    if compact.startswith("gAAAAA"):
        return "fernet"
    return None


def _verify_bcrypt(value: str, password: str) -> PasswordResult:
    try:
        import bcrypt
    except ImportError:
        return _result("verify", "bcrypt", False, "bcrypt dependency is not installed", 0.0)
    try:
        ok = bcrypt.checkpw(password.encode(), value.strip().encode())
    except ValueError as exc:
        return _result("verify", "bcrypt", False, f"invalid bcrypt hash: {exc}", 0.0)
    return _verify_result("bcrypt", ok, ("constant-time bcrypt check",))


def _verify_django_pbkdf2(value: str, password: str, typ: str) -> PasswordResult:
    try:
        algorithm, iterations_text, salt, digest_b64 = value.strip().split("$", 3)
        digest_name = "sha256" if algorithm == "pbkdf2_sha256" else "sha1"
        iterations = int(iterations_text)
        expected = base64.b64decode(digest_b64.encode(), validate=True)
    except (ValueError, binascii.Error):
        return _result("verify", typ, False, "invalid Django PBKDF2 format", 0.0)
    actual = hashlib.pbkdf2_hmac(digest_name, password.encode(), salt.encode(), iterations, dklen=len(expected))
    ok = hmac.compare_digest(actual, expected)
    return _verify_result(typ, ok, (f"iterations={iterations}", f"digest={digest_name}"))


def _verify_ldap_sha(value: str, password: str, typ: str) -> PasswordResult:
    match = re.fullmatch(r"\{(SSHA|SHA)\}([A-Za-z0-9+/=]+)", value.strip(), re.IGNORECASE)
    if not match:
        return _result("verify", typ, False, "invalid LDAP SHA format", 0.0)
    raw = base64.b64decode(match.group(2))
    if len(raw) < 20:
        return _result("verify", typ, False, "LDAP SHA digest is too short", 0.0)
    digest, salt = raw[:20], raw[20:]
    actual = hashlib.sha1(password.encode() + salt, usedforsecurity=False).digest()
    ok = hmac.compare_digest(actual, digest)
    return _verify_result(typ, ok, (f"salt_bytes={len(salt)}",))


def _verify_raw_digest(value: str, password: str, typ: str) -> PasswordResult:
    compact = value.strip().lower()
    if compact.startswith("0x"):
        compact = compact[2:]
    if not re.fullmatch(r"[a-f0-9]+", compact):
        return _result("verify", typ, False, "raw digest verification expects hex input", 0.0)
    try:
        if typ == "sha3-256":
            actual = hashlib.sha3_256(password.encode()).hexdigest()
        elif typ == "sha3-512":
            actual = hashlib.sha3_512(password.encode()).hexdigest()
        elif typ == "blake2b":
            actual = hashlib.blake2b(password.encode()).hexdigest()
        else:
            actual = hashlib.new(typ, password.encode()).hexdigest()
    except ValueError:
        return _result("verify", typ, False, f"unsupported digest algorithm: {typ}", 0.0)
    ok = hmac.compare_digest(actual, compact)
    return _verify_result(typ, ok, ("explicit hash type required for raw hex",))


def _decrypt_xor(value: str, password: str, encoding: str) -> PasswordResult:
    key = password.encode()
    if not key:
        return _result("decrypt", "xor", False, "xor key/password is empty", 0.0)
    data = _decode_input(value, encoding)
    output = bytes(byte ^ key[index % len(key)] for index, byte in enumerate(data))
    confidence = _plaintext_confidence(output, authenticated=False)
    return _decrypt_result(
        "xor",
        output,
        confidence >= 0.35,
        confidence,
        (f"key_bytes={len(key)}", "repeating-key xor"),
        warnings=() if confidence >= 0.55 else ("XOR output is a low-confidence plaintext candidate.",),
    )


def _decrypt_fernet(value: str, password: str) -> PasswordResult:
    try:
        from cryptography.fernet import Fernet, InvalidToken
    except ImportError:
        return _result("decrypt", "fernet", False, "cryptography dependency is not installed", 0.0)
    try:
        output = Fernet(password.encode()).decrypt(value.strip().encode())
    except (ValueError, InvalidToken) as exc:
        return _result(
            "decrypt",
            "fernet",
            False,
            f"Fernet decrypt failed: {exc.__class__.__name__}",
            0.0,
            warnings=("Fernet needs the original urlsafe-base64 32-byte Fernet key; an ordinary password is not enough unless the producer used it as the key.",),
        )
    return _decrypt_result("fernet", output, True, 0.98, ("authenticated Fernet token",))


def _decrypt_openssl_aes_256_cbc(value: str, password: str, encoding: str, key_hex: str | None) -> PasswordResult:
    data = _decode_input(value, encoding)
    if data.startswith(b"Salted__"):
        salt = data[8:16]
        ciphertext = data[16:]
        evidence = ("openssl Salted__ wrapper", "kdf=EVP_BytesToKey-MD5", f"salt={salt.hex()}")
    else:
        compact = re.sub(r"\s+", "", value.strip())
        if compact.startswith("U2FsdGVkX1"):
            decoded = _decode_input(value, "base64")
            if decoded.startswith(b"Salted__"):
                salt = decoded[8:16]
                ciphertext = decoded[16:]
                evidence = ("openssl Salted__ wrapper", "kdf=EVP_BytesToKey-MD5", f"salt={salt.hex()}")
            else:
                return _result("decrypt", "openssl-aes-256-cbc", False, "OpenSSL wrapper did not decode to Salted__ data", 0.0)
        else:
            return _result(
                "decrypt",
                "openssl-aes-256-cbc",
                False,
                "OpenSSL AES decrypt expects Salted__ data or U2FsdGVkX1 base64",
                0.0,
            )
    key, iv = _openssl_evp_bytes_to_key(password.encode(), salt, 32, 16) if not key_hex else (bytes.fromhex(key_hex), b"")
    return _aes_cbc_decrypt(ciphertext, key, iv, "openssl-aes-256-cbc", evidence)


def _decrypt_aes(
    value: str,
    password: str,
    typ: str,
    *,
    encoding: str,
    key_hex: str | None,
    iv_hex: str | None,
    salt_hex: str | None,
    tag_hex: str | None,
    kdf: str,
    iterations: int,
    no_padding: bool,
) -> PasswordResult:
    parts = typ.split("-")
    if len(parts) != 3 or parts[0] != "aes":
        return _result("decrypt", typ, False, "invalid AES type; expected aes-256-cbc style", 0.0)
    key_bits = int(parts[1])
    mode_name = parts[2]
    key_len = key_bits // 8
    data = _decode_input(value, encoding)
    salt = _hex_to_bytes(salt_hex, "salt") if salt_hex else None
    key, key_evidence = _derive_key(password, key_len, kdf, salt, iterations, key_hex)

    if mode_name == "ecb":
        return _aes_ecb_decrypt(data, key, typ, key_evidence, no_padding)

    iv_len = 12 if mode_name == "gcm" else 16
    iv: bytes | None = _hex_to_bytes(iv_hex, "iv") if iv_hex else None
    evidence = list(key_evidence)
    ciphertext = data
    if iv is None and mode_name != "gcm" and len(data) > iv_len:
        iv, ciphertext = data[:iv_len], data[iv_len:]
        evidence.append(f"iv=first-{iv_len}-bytes")
    if iv is None:
        return _result("decrypt", typ, False, f"{typ} requires --iv-hex or ciphertext with prefixed IV", 0.0)

    if mode_name == "cbc":
        return _aes_cbc_decrypt(ciphertext, key, iv, typ, tuple(evidence), no_padding=no_padding)
    if mode_name == "ctr":
        return _aes_stream_decrypt(ciphertext, key, iv, typ, tuple(evidence), mode_name="ctr")
    if mode_name == "gcm":
        tag = _hex_to_bytes(tag_hex, "tag") if tag_hex else None
        if tag is None and len(data) > 16:
            ciphertext, tag = data[:-16], data[-16:]
            evidence.append("tag=last-16-bytes")
        if tag is None:
            return _result("decrypt", typ, False, f"{typ} requires --tag-hex or ciphertext with appended 16-byte tag", 0.0)
        return _aes_gcm_decrypt(ciphertext, key, iv, tag, typ, tuple(evidence))
    return _result("decrypt", typ, False, f"unsupported AES mode: {mode_name}", 0.0)


def _decrypt_chacha20_poly1305(
    value: str,
    password: str,
    encoding: str,
    key_hex: str | None,
    iv_hex: str | None,
    tag_hex: str | None,
    kdf: str,
    salt_hex: str | None,
    iterations: int,
) -> PasswordResult:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
    except ImportError:
        return _result("decrypt", "chacha20-poly1305", False, "cryptography dependency is not installed", 0.0)
    data = _decode_input(value, encoding)
    salt = _hex_to_bytes(salt_hex, "salt") if salt_hex else None
    key, evidence = _derive_key(password, 32, kdf, salt, iterations, key_hex)
    nonce = _hex_to_bytes(iv_hex, "nonce") if iv_hex else None
    ciphertext = data
    tag = _hex_to_bytes(tag_hex, "tag") if tag_hex else None
    if tag is not None:
        ciphertext = data + tag
    if nonce is None and len(data) > 28:
        nonce, ciphertext = data[:12], data[12:]
        evidence = (*evidence, "nonce=first-12-bytes")
    if nonce is None:
        return _result("decrypt", "chacha20-poly1305", False, "ChaCha20-Poly1305 requires --iv-hex nonce or prefixed nonce", 0.0)
    try:
        output = ChaCha20Poly1305(key).decrypt(nonce, ciphertext, None)
    except Exception as exc:
        return _result("decrypt", "chacha20-poly1305", False, f"authentication failed: {exc.__class__.__name__}", 0.0)
    return _decrypt_result("chacha20-poly1305", output, True, 0.98, (*evidence, "authenticated AEAD"))


def _aes_cbc_decrypt(
    ciphertext: bytes,
    key: bytes,
    iv: bytes,
    typ: str,
    evidence: tuple[str, ...],
    *,
    no_padding: bool = False,
) -> PasswordResult:
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError:
        return _result("decrypt", typ, False, "cryptography dependency is not installed", 0.0)
    if len(iv) != 16:
        return _result("decrypt", typ, False, "AES-CBC IV must be 16 bytes", 0.0)
    if len(ciphertext) % 16:
        return _result("decrypt", typ, False, "AES-CBC ciphertext length must be a multiple of 16 bytes", 0.0)
    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()
    output, padding_evidence, warning = _maybe_unpad_pkcs7(padded, no_padding)
    confidence = _plaintext_confidence(output, authenticated=False)
    if padding_evidence:
        confidence += 0.12
    return _decrypt_result(
        typ,
        output,
        confidence >= 0.42,
        min(confidence, 0.94),
        (*evidence, padding_evidence) if padding_evidence else evidence,
        warnings=(warning,) if warning else (),
    )


def _aes_ecb_decrypt(data: bytes, key: bytes, typ: str, evidence: tuple[str, ...], no_padding: bool) -> PasswordResult:
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError:
        return _result("decrypt", typ, False, "cryptography dependency is not installed", 0.0)
    if len(data) % 16:
        return _result("decrypt", typ, False, "AES-ECB ciphertext length must be a multiple of 16 bytes", 0.0)
    # ECB is intentionally available for legacy/CTF ciphertext analysis, not for new encryption.
    decryptor = Cipher(algorithms.AES(key), modes.ECB()).decryptor()  # nosec B305
    padded = decryptor.update(data) + decryptor.finalize()
    output, padding_evidence, warning = _maybe_unpad_pkcs7(padded, no_padding)
    confidence = _plaintext_confidence(output, authenticated=False)
    if padding_evidence:
        confidence += 0.12
    return _decrypt_result(
        typ,
        output,
        confidence >= 0.42,
        min(confidence, 0.90),
        (*evidence, "mode=ecb", padding_evidence) if padding_evidence else (*evidence, "mode=ecb"),
        warnings=(warning,) if warning else ("ECB has no IV and is structurally weak; use only when the producer used ECB.",),
    )


def _aes_stream_decrypt(data: bytes, key: bytes, iv: bytes, typ: str, evidence: tuple[str, ...], *, mode_name: str) -> PasswordResult:
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError:
        return _result("decrypt", typ, False, "cryptography dependency is not installed", 0.0)
    mode = modes.CTR(iv) if mode_name == "ctr" else None
    if mode is None:
        return _result("decrypt", typ, False, f"unsupported stream mode: {mode_name}", 0.0)
    decryptor = Cipher(algorithms.AES(key), mode).decryptor()
    output = decryptor.update(data) + decryptor.finalize()
    confidence = _plaintext_confidence(output, authenticated=False)
    return _decrypt_result(typ, output, confidence >= 0.35, confidence, (*evidence, f"mode={mode_name}"))


def _aes_gcm_decrypt(data: bytes, key: bytes, iv: bytes, tag: bytes, typ: str, evidence: tuple[str, ...]) -> PasswordResult:
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError:
        return _result("decrypt", typ, False, "cryptography dependency is not installed", 0.0)
    try:
        decryptor = Cipher(algorithms.AES(key), modes.GCM(iv, tag)).decryptor()
        output = decryptor.update(data) + decryptor.finalize()
    except Exception as exc:
        return _result("decrypt", typ, False, f"authentication failed: {exc.__class__.__name__}", 0.0)
    return _decrypt_result(typ, output, True, 0.98, (*evidence, "authenticated GCM tag"))


def _derive_key(
    password: str,
    key_len: int,
    kdf: str,
    salt: bytes | None,
    iterations: int,
    key_hex: str | None,
) -> tuple[bytes, tuple[str, ...]]:
    if key_hex:
        key = bytes.fromhex(key_hex)
        if len(key) != key_len:
            raise ValueError(f"key must be {key_len} bytes for selected cipher")
        return key, ("key=hex",)

    selected = kdf.lower()
    if selected == "auto":
        selected = "pbkdf2-sha256" if salt else "sha256"
    if selected == "raw":
        key = password.encode()
        if len(key) != key_len:
            raise ValueError(f"raw password/key must be exactly {key_len} bytes")
        return key, ("kdf=raw",)
    if selected == "sha256":
        return hashlib.sha256(password.encode()).digest()[:key_len], ("kdf=sha256(password)",)
    if selected == "pbkdf2-sha256":
        salt = salt or b""
        key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations, dklen=key_len)
        return key, ("kdf=pbkdf2-sha256", f"iterations={iterations}", f"salt_bytes={len(salt)}")
    raise ValueError(f"unsupported KDF: {kdf}")


def _openssl_evp_bytes_to_key(password: bytes, salt: bytes, key_len: int, iv_len: int) -> tuple[bytes, bytes]:
    output = b""
    previous = b""
    while len(output) < key_len + iv_len:
        previous = hashlib.md5(previous + password + salt, usedforsecurity=False).digest()
        output += previous
    return output[:key_len], output[key_len:key_len + iv_len]


def _decode_input(value: str, encoding: str) -> bytes:
    selected = encoding.lower()
    compact = re.sub(r"\s+", "", value.strip())
    if selected == "raw":
        return value.encode()
    if selected == "hex":
        body = compact[2:] if compact.startswith(("0x", "0X")) else compact
        return bytes.fromhex(body)
    if selected == "base64":
        return base64.b64decode(_pad_base64(compact), validate=False)
    if selected != "auto":
        raise ValueError(f"unsupported input encoding: {encoding}")
    if len(compact) >= 2 and len(compact) % 2 == 0 and re.fullmatch(r"(?:0x)?[a-fA-F0-9]+", compact):
        body = compact[2:] if compact.startswith(("0x", "0X")) else compact
        return bytes.fromhex(body)
    if len(compact) >= 8 and len(compact) % 4 != 1 and re.fullmatch(r"[A-Za-z0-9+/=_-]+", compact):
        try:
            return base64.urlsafe_b64decode(_pad_base64(compact))
        except (binascii.Error, ValueError):
            pass
    return value.encode()


def _pad_base64(value: str) -> str:
    return value + "=" * ((4 - len(value) % 4) % 4)


def _hex_to_bytes(value: str, name: str) -> bytes:
    try:
        return bytes.fromhex(value[2:] if value.startswith(("0x", "0X")) else value)
    except ValueError as exc:
        raise ValueError(f"{name} must be hex") from exc


def _maybe_unpad_pkcs7(data: bytes, no_padding: bool) -> tuple[bytes, str, str | None]:
    if no_padding:
        return data, "padding=none", None
    if not data:
        return data, "", "empty decrypted output"
    pad_len = data[-1]
    if 1 <= pad_len <= 16 and data.endswith(bytes([pad_len]) * pad_len):
        return data[:-pad_len], "padding=pkcs7", None
    return data, "", "PKCS7 padding did not validate; showing raw decrypted bytes"


def _plaintext_confidence(data: bytes, *, authenticated: bool) -> float:
    if authenticated:
        return 0.98
    score = 0.20
    printable = printable_ratio(data)
    score += printable * 0.35
    if is_good_text(data):
        score += 0.18
    if FLAG_SHAPE_RE.search(data):
        score += 0.24
    text_score = score_text(data)
    if text_score > 120:
        score += 0.12
    elif text_score > 80:
        score += 0.08
    if entropy(data) > 7.1 and printable < 0.50:
        score -= 0.20
    return max(0.0, min(0.98, score))


def _output_text(data: bytes) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.hex()


def _decrypt_result(
    typ: str,
    output: bytes,
    ok: bool,
    confidence: float,
    evidence: tuple[str, ...],
    *,
    warnings: tuple[str, ...] = (),
) -> PasswordResult:
    status = "decrypted" if ok else "low-confidence candidate"
    output_value = _output_text(output)
    extra = (
        *evidence,
        f"output_bytes={len(output)}",
        f"output_entropy={entropy(output):.3f}",
        f"output_printable={printable_ratio(output):.3f}",
        f"preview={preview(output, 80)}",
    )
    return PasswordResult("decrypt", typ, ok, status, confidence, output_value, extra, warnings)


def _verify_result(typ: str, ok: bool, evidence: tuple[str, ...]) -> PasswordResult:
    return PasswordResult(
        "verify",
        typ,
        ok,
        "password matches" if ok else "password does not match",
        0.99,
        "",
        evidence,
        (),
    )


def _result(
    operation: str,
    typ: str,
    ok: bool,
    status: str,
    confidence: float,
    *,
    output: str = "",
    evidence: tuple[str, ...] = (),
    warnings: tuple[str, ...] = (),
) -> PasswordResult:
    return PasswordResult(operation, typ, ok, status, confidence, output, evidence, warnings)
