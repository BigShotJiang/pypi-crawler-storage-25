from __future__ import annotations

import base64
import binascii
import bz2
import codecs
import gzip
import html
import lzma
import math
import quopri
import re
import urllib.parse
import warnings
import zlib
from collections.abc import Callable, Iterable

from encid.models import DecodeAttempt
from encid.scoring import FLAG_RE, FLAG_SHAPE_RE, is_good_text, score_text

BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
BASE62_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
BASE36_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
BASE45_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"
BASE91_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"'
BASE92_ALPHABET = b"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_abcdefghijklmnopqrstuvwxyz{|}"
XX_ALPHABET = "+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"


def _text(data: bytes) -> str:
    try:
        return data.decode("utf-8").strip()
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace").strip()


def _compact(text: str) -> str:
    return re.sub(r"\s+", "", text)


def _looks_base64_token(text: str) -> bool:
    compact = _compact(text)
    return (
        len(compact) >= 8
        and len(compact) % 4 != 1
        and re.fullmatch(r"[A-Za-z0-9+/]*={0,2}|[A-Za-z0-9_-]*={0,2}", compact) is not None
    )


def _looks_base32_token(text: str) -> bool:
    compact = _compact(text).upper()
    return len(compact) >= 8 and len(compact) % 8 != 1 and re.fullmatch(r"[A-Z2-7=]+", compact) is not None


def _structured_encoded_text(data: bytes) -> bool:
    stripped = data.strip()
    if is_good_text(stripped) or FLAG_SHAPE_RE.search(stripped):
        return True
    if re.fullmatch(rb"[01]{8}(?:\s+[01]{8})+", stripped):
        return True
    if re.fullmatch(rb"[0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})+", stripped):
        return True
    return False


def _decodes_to_structured_text(text: str) -> bool:
    compact = _compact(text)
    if _looks_base64_token(compact):
        for altchars in (None, b"-_"):
            try:
                padded = compact + "=" * ((4 - len(compact) % 4) % 4)
                output = base64.b64decode(padded.encode("ascii"), altchars=altchars, validate=True)
            except (UnicodeEncodeError, ValueError, binascii.Error):
                continue
            if _structured_encoded_text(output):
                return True
    if _looks_base32_token(compact):
        try:
            padded = compact.upper() + "=" * ((8 - len(compact) % 8) % 8)
            output = base64.b32decode(padded, casefold=True)
        except (ValueError, binascii.Error):
            return False
        if _structured_encoded_text(output):
            return True
    return False


def _attempt(
    action: str,
    data: bytes | None,
    confidence: float,
    *,
    category: str = "encoding",
    risk: str = "safe",
    reason: str = "",
    evidence: tuple[str, ...] = (),
) -> list[DecodeAttempt]:
    if not data:
        return []
    return [DecodeAttempt(action, data, confidence, category, risk, reason, evidence)]


def _decode_base_n(text: str, alphabet: str, min_len: int = 4) -> bytes | None:
    compact = _compact(text).upper() if alphabet == BASE36_ALPHABET else _compact(text)
    if len(compact) < min_len or any(char not in alphabet for char in compact):
        return None
    number = 0
    base = len(alphabet)
    for char in compact:
        number = number * base + alphabet.index(char)
    if number == 0:
        output = b"\x00"
    else:
        output = number.to_bytes((number.bit_length() + 7) // 8, "big")
    leading = len(compact) - len(compact.lstrip(alphabet[0]))
    return b"\x00" * leading + output


def decode_hex(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if "\\x" in text:
        hex_text = "".join(re.findall(r"\\x([0-9a-fA-F]{2})", text))
    elif re.search(r"0x[0-9a-fA-F]{2}", text):
        hex_text = "".join(re.findall(r"0x([0-9a-fA-F]{2})", text))
    else:
        hex_text = re.sub(r"[\s:,_;\-]+", "", text)
    if len(hex_text) < 2 or len(hex_text) % 2 or not re.fullmatch(r"[0-9a-fA-F]+", hex_text):
        return []
    try:
        confidence = 0.78 if len(hex_text) >= 8 else 0.58
        return _attempt("hex/base16", bytes.fromhex(hex_text), confidence, reason="Even-length hexadecimal alphabet.")
    except ValueError:
        return []


def decode_base64(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    compact = _compact(text)
    if len(compact) < 4 or len(compact) % 4 == 1:
        return []
    if re.fullmatch(r"[A-Za-z]+", compact) and len(compact) < 12:
        return []

    attempts: list[DecodeAttempt] = []
    variants = [
        ("base64/base64url", None, r"[A-Za-z0-9+/]*={0,2}$", base64.b64encode),
        ("base64/base64url", b"-_", r"[A-Za-z0-9_-]*={0,2}$", base64.urlsafe_b64encode),
    ]
    for action, altchars, pattern, encoder in variants:
        if not re.fullmatch(pattern, compact):
            continue
        padded = compact + "=" * ((4 - len(compact) % 4) % 4)
        try:
            output = base64.b64decode(padded.encode("ascii"), altchars=altchars, validate=True)
        except (binascii.Error, ValueError):
            continue
        check = encoder(output).decode("ascii").rstrip("=")
        if check != compact.rstrip("="):
            continue
        confidence = 0.72
        if "=" in compact or any(char in compact for char in "+/-_"):
            confidence += 0.08
        attempts.extend(_attempt(action, output, confidence, reason="Strict base64 alphabet and round-trip check passed."))
    return attempts


def decode_base32(data: bytes) -> Iterable[DecodeAttempt]:
    compact = _compact(_text(data)).upper()
    if len(compact) < 8 or len(compact) % 8 == 1 or not re.fullmatch(r"[A-Z2-7=]+", compact):
        return []
    try:
        padded = compact + "=" * ((8 - len(compact) % 8) % 8)
        output = base64.b32decode(padded, casefold=True)
    except (binascii.Error, ValueError):
        return []
    return _attempt("base32", output, 0.78, reason="RFC 4648 base32 alphabet.")


def decode_base85(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if len(text) < 5:
        return []
    if re.search(r"%[0-9A-Fa-f]{2}", text):
        return []
    attempts: list[DecodeAttempt] = []
    for action, func in (("base85", base64.b85decode), ("ascii85", base64.a85decode)):
        try:
            output = func(text.encode("ascii"))
        except (UnicodeEncodeError, ValueError, binascii.Error):
            continue
        attempts.extend(_attempt(action, output, 0.58, risk="cautious", reason="Base85 accepts a broad printable alphabet."))
    return attempts


def decode_base58(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    output = _decode_base_n(text, BASE58_ALPHABET, 5)
    return _attempt("base58", output, 0.54, risk="cautious", reason="All characters are in the Bitcoin base58 alphabet.")


def decode_base62(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    output = _decode_base_n(text, BASE62_ALPHABET, 5)
    return _attempt("base62", output, 0.45, risk="risky", reason="Base62 overlaps heavily with ordinary text.")


def decode_base36(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    output = _decode_base_n(text, BASE36_ALPHABET, 5)
    return _attempt("base36", output, 0.38, risk="risky", reason="Base36 overlaps with words and numeric identifiers.")


def decode_base45(data: bytes) -> Iterable[DecodeAttempt]:
    compact = _text(data).replace("\r", "").replace("\n", "")
    if len(compact) < 2 or not re.fullmatch(r"[0-9A-Z $%*+\-./:]+", compact):
        return []
    output = bytearray()
    try:
        index = 0
        while index < len(compact):
            if index + 2 < len(compact):
                value = (
                    BASE45_ALPHABET.index(compact[index])
                    + BASE45_ALPHABET.index(compact[index + 1]) * 45
                    + BASE45_ALPHABET.index(compact[index + 2]) * 45 * 45
                )
                if value > 0xFFFF:
                    return []
                output.extend(divmod(value, 256))
                index += 3
            elif index + 1 < len(compact):
                value = BASE45_ALPHABET.index(compact[index]) + BASE45_ALPHABET.index(compact[index + 1]) * 45
                if value > 0xFF:
                    return []
                output.append(value)
                index += 2
            else:
                return []
    except ValueError:
        return []
    return _attempt("base45", bytes(output), 0.55, risk="cautious", reason="RFC 9285 base45 alphabet.")


def _base91_decode(text: str) -> bytes | None:
    table = {char: index for index, char in enumerate(BASE91_ALPHABET)}
    value = -1
    buffer = 0
    bits = 0
    output = bytearray()
    for char in text:
        if char not in table:
            return None
        code = table[char]
        if value < 0:
            value = code
        else:
            value += code * 91
            buffer |= value << bits
            bits += 13 if (value & 8191) > 88 else 14
            while bits > 7:
                output.append(buffer & 255)
                buffer >>= 8
                bits -= 8
            value = -1
    if value >= 0:
        output.append((buffer | value << bits) & 255)
    return bytes(output)


def decode_base91(data: bytes) -> Iterable[DecodeAttempt]:
    text = _compact(_text(data))
    if len(text) < 6:
        return []
    output = _base91_decode(text)
    return _attempt("base91", output, 0.44, risk="risky", reason="basE91 has a broad printable alphabet.")


def _base92_decode(raw: bytes) -> bytes | None:
    compact = b"".join(raw.split())
    if compact == b"~":
        return b""
    if len(compact) < 2:
        return None
    table = {char: index for index, char in enumerate(BASE92_ALPHABET)}
    if any(char not in table for char in compact):
        return None

    output = bytearray()
    buffer = 0
    length = 0
    body = compact
    if len(body) % 2:
        tail_bits = 6
        tail = table[body[-1]]
        body = body[:-1]
    else:
        tail_bits = 13
        tail = table[body[-2]] * 91 + table[body[-1]]
        body = body[:-2]

    iterator = iter(body)
    for first, second in zip(iterator, iterator):
        block = table[first] * 91 + table[second]
        buffer = (buffer << 13) | block
        length += 13
        byte_count, length = divmod(length, 8)
        output.extend((buffer >> length).to_bytes(byte_count, "big"))
        buffer &= (1 << length) - 1

    missing = 8 - length
    shift = tail_bits - missing
    if shift < 8:
        byte_count = 1
    else:
        byte_count = 2
        shift -= 8
        missing += 8
    if shift < 0:
        return None
    buffer = (buffer << missing) | (tail >> shift)
    output.extend(buffer.to_bytes(byte_count, "big"))
    if shift and tail & ((1 << shift) - 1):
        return None
    return bytes(output)


def decode_base92(data: bytes) -> Iterable[DecodeAttempt]:
    output = _base92_decode(data)
    return _attempt("base92", output, 0.44, risk="risky", reason="Base92 excludes quote, backtick, and tilde.")


def decode_url(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if "%" not in text:
        return []
    output = urllib.parse.unquote_plus(text)
    if output == text:
        return []
    escapes = len(re.findall(r"%[0-9A-Fa-f]{2}", text))
    confidence = 0.70 + min(0.12, escapes * 0.03)
    urlish = bool(re.search(r"%(?:2f|2F|3a|3A|3f|3F|3d|3D|26|20)", text)) or "://" in output
    risk = "safe" if urlish or escapes >= 2 else "cautious"
    if escapes == 1 and re.fullmatch(r"[0-9A-Z $%*+\-./:]+", text):
        confidence = 0.30
        risk = "risky"
    return _attempt("url-percent", output.encode(), confidence, risk=risk, reason="Percent escapes changed the input.")


def decode_html_entities(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if "&" not in text:
        return []
    output = html.unescape(text)
    if output == text:
        return []
    return _attempt("html-entity", output.encode(), 0.84, reason="HTML/XML entity references changed the input.")


def decode_unicode_escape(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if not re.search(r"\\(?:x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4}|U[0-9A-Fa-f]{8}|[ntr])", text):
        return []
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            output = codecs.decode(text, "unicode_escape")
    except UnicodeError:
        return []
    if output == text:
        return []
    return _attempt("unicode/js-escape", output.encode("utf-8", errors="replace"), 0.80, reason="Backslash escape sequences decoded.")


def decode_quoted_printable(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if not re.search(r"=[0-9A-Fa-f]{2}|=\r?\n", text):
        return []
    output = quopri.decodestring(data)
    if not output or output == data:
        return []
    return _attempt("quoted-printable", output, 0.72, reason="Quoted-printable escape markers changed the input.")


def decode_binary(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    tokens = re.findall(r"[01]{8}", text)
    compact = _compact(text)
    if len(tokens) < 2 or "".join(tokens) != compact:
        return []
    try:
        output = bytes(int(token, 2) for token in tokens)
    except ValueError:
        return []
    return _attempt("binary-8bit", output, 0.86, reason="Input is complete 8-bit binary groups.")


def decode_octal_chars(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if "\\" in text:
        numbers = re.findall(r"\\([0-7]{1,3})", text)
    else:
        numbers = re.findall(r"\b[0-7]{2,3}\b", text)
        if len(numbers) < 3:
            return []
    if len(numbers) < 3:
        return []
    try:
        values = [int(number, 8) for number in numbers]
    except ValueError:
        return []
    if any(value > 255 for value in values):
        return []
    return _attempt("octal-charcodes", bytes(values), 0.72, reason="Octal byte values.")


def decode_decimal_chars(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if not re.fullmatch(r"\s*-?\d+(?:[\s,;:_|/\\-]+-?\d+)+\s*", text):
        return []
    numbers = re.findall(r"-?\d+", text)
    if len(numbers) < 3:
        return []
    values: list[int] = []
    for number in numbers:
        value = int(number)
        if not 0 <= value <= 255:
            return []
        values.append(value)
    return _attempt("decimal-charcodes", bytes(values), 0.58, risk="cautious", reason="Decimal byte values.")


def decode_utf16le(data: bytes) -> Iterable[DecodeAttempt]:
    if len(data) < 4 or len(data) % 2:
        return []
    if not data.startswith(b"\xff\xfe") and (not data[1::2] or data[1::2].count(0) / len(data[1::2]) < 0.30):
        return []
    try:
        text = data.decode("utf-16le")
    except UnicodeDecodeError:
        return []
    if not text or "\x00" in text or text.encode("utf-8", errors="replace") == data:
        return []
    return _attempt("utf-16le", text.encode(), 0.70, reason="Valid UTF-16 little-endian text.")


def decode_utf16be(data: bytes) -> Iterable[DecodeAttempt]:
    if len(data) < 4 or len(data) % 2:
        return []
    if not data.startswith(b"\xfe\xff") and (not data[0::2] or data[0::2].count(0) / len(data[0::2]) < 0.30):
        return []
    try:
        text = data.decode("utf-16be")
    except UnicodeDecodeError:
        return []
    if not text or "\x00" in text or text.encode("utf-8", errors="replace") == data:
        return []
    return _attempt("utf-16be", text.encode(), 0.70, reason="Valid UTF-16 big-endian text.")


def decode_latin1_codepoints(data: bytes) -> Iterable[DecodeAttempt]:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return []
    if not text or any(ord(char) > 255 for char in text):
        return []
    if not any(ord(char) > 127 for char in text):
        return []
    output = bytes(ord(char) for char in text)
    if output == data:
        return []
    return _attempt(
        "latin1-codepoint-bytes",
        output,
        0.46,
        risk="cautious",
        reason="UTF-8 text codepoints fit in one byte; treating them as pasted Latin-1/raw byte values.",
    )


def decode_bit_rotate(data: bytes) -> Iterable[DecodeAttempt]:
    if len(data) < 4:
        return []
    original_score = score_text(data)
    input_already_text = is_good_text(data)
    attempts: list[DecodeAttempt] = []
    for amount in range(1, 8):
        output = bytes(((byte >> amount) | ((byte << (8 - amount)) & 0xFF)) & 0xFF for byte in data)
        new_score = score_text(output)
        if input_already_text and not FLAG_SHAPE_RE.search(output):
            continue
        if new_score <= original_score + 35 and not (is_good_text(output) or FLAG_RE.search(output) or FLAG_SHAPE_RE.search(output)):
            continue
        confidence = 0.50
        if is_good_text(output):
            confidence += 0.12
        if FLAG_RE.search(output) or FLAG_SHAPE_RE.search(output):
            confidence += 0.18
        attempts.append(DecodeAttempt(
            f"bit-rotate-right/{amount}",
            output,
            min(confidence, 0.88),
            category="byte-transform",
            risk="cautious",
            reason="Each byte was rotated right and the result produced stronger text evidence.",
        ))
    return sorted(attempts, key=lambda item: score_text(item.data), reverse=True)[:4]


def decode_rot13(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if re.search(r"%[0-9A-Fa-f]{2}", text):
        return []
    letters = sum(char.isalpha() and char.isascii() for char in text)
    if letters < 4 or letters / max(1, len(text)) < 0.55:
        return []
    output = codecs.decode(text, "rot_13")
    if output == text:
        return []
    encoded = output.encode()
    original_score = score_text(text.encode())
    new_score = score_text(encoded)
    reveals_encoding = _decodes_to_structured_text(output)
    if new_score <= original_score + 12 and not (
        FLAG_RE.search(encoded)
        or FLAG_SHAPE_RE.search(encoded)
        or encoded.startswith((b"http://", b"https://"))
        or reveals_encoding
    ):
        return []
    confidence = 0.64 if reveals_encoding else 0.48
    return _attempt("rot13", encoded, confidence, risk="cautious", reason="ROT13 substitution improved downstream evidence.")


def decode_rot47(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if not any(33 <= ord(char) <= 126 for char in text):
        return []
    output = []
    for char in text:
        code = ord(char)
        if 33 <= code <= 126:
            output.append(chr(33 + ((code - 33 + 47) % 94)))
        else:
            output.append(char)
    return _attempt("rot47", "".join(output).encode(), 0.42, risk="risky", reason="ROT47 printable ASCII rotation.")


def _caesar_shift(text: str, amount: int) -> str:
    output = []
    for char in text:
        if "a" <= char <= "z":
            output.append(chr((ord(char) - 97 - amount) % 26 + 97))
        elif "A" <= char <= "Z":
            output.append(chr((ord(char) - 65 - amount) % 26 + 65))
        else:
            output.append(char)
    return "".join(output)


def decode_caesar(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if re.search(r"%[0-9A-Fa-f]{2}", text):
        return []
    if _looks_base64_token(text):
        return []
    letters = sum(char.isalpha() and char.isascii() for char in text)
    if letters < 6 or letters / max(1, len(text)) < 0.60:
        return []
    original_score = score_text(text.encode())
    attempts = []
    for amount in range(1, 26):
        output = _caesar_shift(text, amount).encode()
        new_score = score_text(output)
        if new_score > original_score + 18 or FLAG_RE.search(output) or FLAG_SHAPE_RE.search(output):
            attempts.append(DecodeAttempt(
                f"caesar/rot-{amount}",
                output,
                0.52,
                risk="cautious",
                reason="Brute-forced Caesar shift improved text score.",
            ))
    return sorted(attempts, key=lambda item: score_text(item.data), reverse=True)[:6]


def decode_rot5_rot18(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if not re.search(r"\d", text):
        return []
    digits = str.maketrans("0123456789", "5678901234")
    rot5 = text.translate(digits)
    attempts = [DecodeAttempt("rot5", rot5.encode(), 0.42, risk="risky", reason="Digit rotation by five.")]
    if re.search(r"[A-Za-z]", text):
        rot18 = codecs.decode(rot5, "rot_13")
        attempts.append(DecodeAttempt("rot18", rot18.encode(), 0.45, risk="risky", reason="ROT13 plus ROT5."))
    return attempts


def decode_atbash(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    letters = sum(char.isalpha() and char.isascii() for char in text)
    if letters < 6 or letters / max(1, len(text)) < 0.60:
        return []
    output = []
    for char in text:
        if "a" <= char <= "z":
            output.append(chr(ord("z") - (ord(char) - ord("a"))))
        elif "A" <= char <= "Z":
            output.append(chr(ord("Z") - (ord(char) - ord("A"))))
        else:
            output.append(char)
    decoded = "".join(output)
    if decoded == text:
        return []
    return _attempt("atbash", decoded.encode(), 0.45, risk="risky", reason="Atbash monoalphabetic substitution.")


def _mod_inverse(a: int, modulus: int) -> int | None:
    for candidate in range(modulus):
        if (a * candidate) % modulus == 1:
            return candidate
    return None


def _affine_decrypt(text: str, a: int, b: int) -> str:
    inverse = _mod_inverse(a, 26)
    if inverse is None:
        return text
    output = []
    for char in text:
        if "a" <= char <= "z":
            value = inverse * (ord(char) - 97 - b)
            output.append(chr(value % 26 + 97))
        elif "A" <= char <= "Z":
            value = inverse * (ord(char) - 65 - b)
            output.append(chr(value % 26 + 65))
        else:
            output.append(char)
    return "".join(output)


def decode_affine(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    letters = sum(char.isalpha() and char.isascii() for char in text)
    if letters < 8 or letters / max(1, len(text)) < 0.65:
        return []
    original_score = score_text(text.encode())
    attempts = []
    for a in (1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25):
        for b in range(26):
            decoded = _affine_decrypt(text, a, b).encode()
            new_score = score_text(decoded)
            if new_score > original_score + 25 or FLAG_RE.search(decoded) or FLAG_SHAPE_RE.search(decoded):
                attempts.append(DecodeAttempt(
                    f"affine/a={a},b={b}",
                    decoded,
                    0.40,
                    risk="risky",
                    reason="Affine cipher brute force improved text score.",
                ))
    return sorted(attempts, key=lambda item: score_text(item.data), reverse=True)[:5]


def _rail_fence_decrypt(text: str, rails: int) -> str:
    if rails <= 1:
        return text
    pattern = []
    rail = 0
    direction = 1
    for _ in text:
        pattern.append(rail)
        rail += direction
        if rail == 0 or rail == rails - 1:
            direction *= -1
    counts = [pattern.count(rail_index) for rail_index in range(rails)]
    rail_texts = []
    position = 0
    for count in counts:
        rail_texts.append(list(text[position:position + count]))
        position += count
    output = []
    offsets = [0] * rails
    for rail_index in pattern:
        output.append(rail_texts[rail_index][offsets[rail_index]])
        offsets[rail_index] += 1
    return "".join(output)


def decode_rail_fence(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if len(text) < 8:
        return []
    original_score = score_text(text.encode())
    attempts = []
    for rails in range(2, min(9, len(text) // 2 + 1)):
        decoded = _rail_fence_decrypt(text, rails).encode()
        new_score = score_text(decoded)
        if new_score > original_score + 22 or FLAG_RE.search(decoded) or FLAG_SHAPE_RE.search(decoded):
            attempts.append(DecodeAttempt(
                f"rail-fence/rails={rails}",
                decoded,
                0.42,
                risk="risky",
                reason="Rail fence brute force improved text score.",
            ))
    return sorted(attempts, key=lambda item: score_text(item.data), reverse=True)[:5]


def _columnar_decrypt_no_key(text: str, columns: int) -> str:
    rows = math.ceil(len(text) / columns)
    short_columns = columns * rows - len(text)
    lengths = [rows] * columns
    for index in range(columns - short_columns, columns):
        if 0 <= index < columns:
            lengths[index] -= 1
    chunks = []
    position = 0
    for length in lengths:
        chunks.append(text[position:position + length])
        position += length
    output = []
    for row in range(rows):
        for column in range(columns):
            if row < len(chunks[column]):
                output.append(chunks[column][row])
    return "".join(output)


def decode_columnar(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if len(text) < 12:
        return []
    original_score = score_text(text.encode())
    attempts = []
    for columns in range(2, min(11, len(text) // 2 + 1)):
        decoded = _columnar_decrypt_no_key(text, columns).encode()
        new_score = score_text(decoded)
        if new_score > original_score + 28 or FLAG_RE.search(decoded) or FLAG_SHAPE_RE.search(decoded):
            attempts.append(DecodeAttempt(
                f"columnar-transposition/columns={columns}",
                decoded,
                0.34,
                risk="risky",
                reason="Simple unkeyed columnar transposition improved text score.",
            ))
    return sorted(attempts, key=lambda item: score_text(item.data), reverse=True)[:4]


MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F",
    "--.": "G", "....": "H", "..": "I", ".---": "J", "-.-": "K", ".-..": "L",
    "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R",
    "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X",
    "-.--": "Y", "--..": "Z", "-----": "0", ".----": "1", "..---": "2",
    "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7",
    "---..": "8", "----.": "9", ".-.-.-": ".", "--..--": ",", "..--..": "?",
    "-.-.--": "!", "-....-": "-", "-..-.": "/", ".--.-.": "@", "-.--.": "(",
    "-.--.-": ")", "---...": ":", "-.-.-.": ";", "-...-": "=", ".-.-.": "+",
    "..--.-": "_", ".----.": "'",
}


def decode_morse(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if not text or not re.fullmatch(r"[\s./|\-]+", text):
        return []
    words = re.split(r"\s*(?:/|\|)\s*|\s{3,}", text)
    decoded_words = []
    used = False
    for word in words:
        chars = []
        for token in word.split():
            if token not in MORSE:
                return []
            chars.append(MORSE[token])
            used = True
        decoded_words.append("".join(chars))
    if not used:
        return []
    return _attempt("morse", " ".join(decoded_words).encode(), 0.78, reason="Morse dot/dash tokens.")


def decode_bacon(data: bytes) -> Iterable[DecodeAttempt]:
    text = re.sub(r"[^abAB]", "", _text(data))
    if len(text) < 10 or len(text) % 5:
        return []
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    chars = []
    for index in range(0, len(text), 5):
        value = 0
        for char in text[index:index + 5].lower():
            value = value * 2 + (1 if char == "b" else 0)
        if value >= 26:
            return []
        chars.append(alphabet[value])
    return _attempt("baconian", "".join(chars).encode(), 0.55, risk="cautious", reason="A/B groups of five.")


def decode_gzip(data: bytes) -> Iterable[DecodeAttempt]:
    if not data.startswith(b"\x1f\x8b"):
        return []
    try:
        output = gzip.decompress(data)
    except (OSError, EOFError):
        return []
    return _attempt("gzip", output, 0.94, category="compression", reason="gzip magic header and decompression succeeded.")


def decode_zlib(data: bytes) -> Iterable[DecodeAttempt]:
    if len(data) < 2 or data[:2] not in (b"\x78\x01", b"\x78\x5e", b"\x78\x9c", b"\x78\xda"):
        return []
    try:
        output = zlib.decompress(data)
    except zlib.error:
        return []
    return _attempt("zlib", output, 0.88, category="compression", reason="Common zlib header and decompression succeeded.")


def decode_raw_deflate(data: bytes) -> Iterable[DecodeAttempt]:
    if len(data) < 8:
        return []
    try:
        output = zlib.decompress(data, -zlib.MAX_WBITS)
    except zlib.error:
        return []
    return _attempt("raw-deflate", output, 0.45, category="compression", risk="risky", reason="Raw deflate has no magic header.")


def decode_bz2(data: bytes) -> Iterable[DecodeAttempt]:
    if not data.startswith(b"BZh"):
        return []
    try:
        output = bz2.decompress(data)
    except OSError:
        return []
    return _attempt("bzip2", output, 0.92, category="compression", reason="bzip2 magic header and decompression succeeded.")


def decode_xz(data: bytes) -> Iterable[DecodeAttempt]:
    if not data.startswith(b"\xfd7zXZ\x00"):
        return []
    try:
        output = lzma.decompress(data)
    except lzma.LZMAError:
        return []
    return _attempt("xz/lzma", output, 0.92, category="compression", reason="xz magic header and decompression succeeded.")


def decode_reverse(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    if len(text) < 6:
        return []
    reversed_text = text[::-1].encode()
    if score_text(reversed_text) <= score_text(text.encode()) + 20 and not (FLAG_RE.search(reversed_text) or FLAG_SHAPE_RE.search(reversed_text)):
        return []
    return _attempt("reverse", reversed_text, 0.42, risk="risky", reason="Reversing the string improved text score.")


def decode_uuencode(data: bytes) -> Iterable[DecodeAttempt]:
    lines = data.splitlines()
    body: list[bytes] = []
    in_body = False
    saw_begin = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith(b"begin "):
            in_body = True
            saw_begin = True
            continue
        if stripped == b"end":
            break
        if in_body or (stripped and 32 <= stripped[0] <= 96):
            body.append(stripped)
    if not body:
        return []
    if not saw_begin and len(body) < 2:
        return []
    output = bytearray()
    try:
        for line in body:
            if line == b"`":
                continue
            output.extend(binascii.a2b_uu(line))
    except binascii.Error:
        return []
    confidence = 0.82 if saw_begin else 0.42
    return _attempt("uuencode", bytes(output), confidence, risk="cautious", reason="UUEncode line decoding succeeded.")


def _decode_xx_line(line: str) -> bytes | None:
    if not line:
        return None
    try:
        expected = XX_ALPHABET.index(line[0])
    except ValueError:
        return None
    payload = line[1:]
    output = bytearray()
    for index in range(0, len(payload), 4):
        chunk = payload[index:index + 4]
        if len(chunk) < 4:
            break
        try:
            values = [XX_ALPHABET.index(char) for char in chunk]
        except ValueError:
            return None
        triple = (values[0] << 18) | (values[1] << 12) | (values[2] << 6) | values[3]
        output.extend([(triple >> 16) & 255, (triple >> 8) & 255, triple & 255])
    return bytes(output[:expected])


def decode_xxencode(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    body = [line for line in lines if not line.startswith("begin ") and line != "end"]
    if not body:
        return []
    output = bytearray()
    for line in body:
        decoded = _decode_xx_line(line)
        if decoded is None:
            return []
        output.extend(decoded)
    return _attempt("xxencode", bytes(output), 0.62, risk="cautious", reason="XXEncode alphabet line decoding succeeded.")


def decode_yenc(data: bytes) -> Iterable[DecodeAttempt]:
    if b"=ybegin" not in data and b"=yend" not in data:
        return []
    output = bytearray()
    payload = [line for line in data.splitlines() if not line.startswith((b"=ybegin", b"=ypart", b"=yend"))]
    escaped = False
    for byte in b"\n".join(payload):
        if escaped:
            output.append(((byte - 64) - 42) & 255)
            escaped = False
        elif byte == ord("="):
            escaped = True
        else:
            output.append((byte - 42) & 255)
    return _attempt("yenc", bytes(output), 0.78, reason="yEnc headers found and byte transform applied.")


def _run_brainfuck(code: str, max_steps: int = 200_000) -> bytes | None:
    bracket_stack: list[int] = []
    bracket_map: dict[int, int] = {}
    for index, char in enumerate(code):
        if char == "[":
            bracket_stack.append(index)
        elif char == "]":
            if not bracket_stack:
                return None
            start = bracket_stack.pop()
            bracket_map[start] = index
            bracket_map[index] = start
    if bracket_stack:
        return None

    tape = [0] * 30_000
    pointer = 0
    pc = 0
    steps = 0
    output = bytearray()
    while pc < len(code) and steps < max_steps:
        instruction = code[pc]
        if instruction == ">":
            pointer = (pointer + 1) % len(tape)
        elif instruction == "<":
            pointer = (pointer - 1) % len(tape)
        elif instruction == "+":
            tape[pointer] = (tape[pointer] + 1) & 255
        elif instruction == "-":
            tape[pointer] = (tape[pointer] - 1) & 255
        elif instruction == ".":
            output.append(tape[pointer])
        elif instruction == ",":
            tape[pointer] = 0
        elif instruction == "[" and tape[pointer] == 0:
            pc = bracket_map[pc]
        elif instruction == "]" and tape[pointer] != 0:
            pc = bracket_map[pc]
        pc += 1
        steps += 1
        if len(output) > 200_000:
            return None
    if steps >= max_steps or not output:
        return None
    return bytes(output)


def decode_brainfuck(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    code = "".join(char for char in text if char in "><+-.,[]")
    non_space = "".join(char for char in text if not char.isspace())
    if len(code) < 8 or not any(char in code for char in "><+[,]") or (non_space and len(code) / len(non_space) < 0.75):
        return []
    output = _run_brainfuck(code)
    return _attempt("brainfuck", output, 0.62, risk="cautious", reason="Brainfuck program executed in a bounded interpreter.")


OOK_TO_BF = {
    ("Ook.", "Ook?"): ">",
    ("Ook?", "Ook."): "<",
    ("Ook.", "Ook."): "+",
    ("Ook!", "Ook!"): "-",
    ("Ook!", "Ook."): ".",
    ("Ook.", "Ook!"): ",",
    ("Ook!", "Ook?"): "[",
    ("Ook?", "Ook!"): "]",
}


def decode_ook(data: bytes) -> Iterable[DecodeAttempt]:
    text = _text(data)
    tokens = re.findall(r"Ook[.!?]", text)
    if len(tokens) < 8 or len(tokens) % 2:
        return []
    code = []
    for index in range(0, len(tokens), 2):
        instruction = OOK_TO_BF.get((tokens[index], tokens[index + 1]))
        if instruction is None:
            return []
        code.append(instruction)
    output = _run_brainfuck("".join(code))
    return _attempt("ook", output, 0.66, risk="cautious", reason="Ook tokens mapped to Brainfuck and executed.")


def decode_whitespace_binary(data: bytes) -> Iterable[DecodeAttempt]:
    text = data.decode("utf-8", errors="ignore")
    if not text or any(char not in " \t\r\n" for char in text):
        return []
    bits = "".join("0" if char == " " else "1" for char in text if char in " \t")
    if len(bits) < 8 or len(bits) % 8:
        return []
    output = bytes(int(bits[index:index + 8], 2) for index in range(0, len(bits), 8))
    return _attempt("whitespace-binary", output, 0.56, risk="cautious", reason="Spaces and tabs interpreted as binary.")


def decode_zero_width(data: bytes) -> Iterable[DecodeAttempt]:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return []
    mapping = {
        "\u200b": "0",
        "\u2060": "0",
        "\ufeff": "0",
        "\u200c": "1",
        "\u200d": "1",
    }
    bits = "".join(mapping[char] for char in text if char in mapping)
    if len(bits) < 8 or len(bits) % 8:
        return []
    output = bytes(int(bits[index:index + 8], 2) for index in range(0, len(bits), 8))
    return _attempt("zero-width-unicode", output, 0.68, reason="Zero-width Unicode characters mapped to bits.")


def decode_braille_bytes(data: bytes) -> Iterable[DecodeAttempt]:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return []
    values = [ord(char) - 0x2800 for char in text if 0x2800 <= ord(char) <= 0x28FF]
    if len(values) < 2 or len(values) != len(text.strip()):
        return []
    return _attempt("braille-byte-patterns", bytes(values), 0.52, risk="cautious", reason="Unicode braille pattern codepoints mapped to byte values.")


def decode_emoji_binary(data: bytes) -> Iterable[DecodeAttempt]:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return []
    zeros = {"○", "◯", "⚪", "⬜", "□", "▫", "🤍"}
    ones = {"●", "⚫", "⬛", "■", "▪", "🖤"}
    bits = []
    for char in text:
        if char in zeros:
            bits.append("0")
        elif char in ones:
            bits.append("1")
        elif char.isspace():
            continue
        else:
            return []
    bit_text = "".join(bits)
    if len(bit_text) < 8 or len(bit_text) % 8:
        return []
    output = bytes(int(bit_text[index:index + 8], 2) for index in range(0, len(bit_text), 8))
    return _attempt("emoji-binary", output, 0.50, risk="cautious", reason="Two-symbol emoji/braille-like binary alphabet.")


DECODER_FUNCTIONS: tuple[Callable[[bytes], Iterable[DecodeAttempt]], ...] = (
    decode_gzip,
    decode_zlib,
    decode_bz2,
    decode_xz,
    decode_raw_deflate,
    decode_utf16le,
    decode_utf16be,
    decode_latin1_codepoints,
    decode_bit_rotate,
    decode_url,
    decode_html_entities,
    decode_unicode_escape,
    decode_quoted_printable,
    decode_hex,
    decode_base64,
    decode_base32,
    decode_base45,
    decode_base85,
    decode_base58,
    decode_base62,
    decode_base36,
    decode_base91,
    decode_base92,
    decode_binary,
    decode_octal_chars,
    decode_decimal_chars,
    decode_uuencode,
    decode_xxencode,
    decode_yenc,
    decode_morse,
    decode_bacon,
    decode_brainfuck,
    decode_ook,
    decode_whitespace_binary,
    decode_zero_width,
    decode_braille_bytes,
    decode_emoji_binary,
    decode_rot13,
    decode_rot47,
    decode_rot5_rot18,
    decode_caesar,
    decode_atbash,
    decode_affine,
    decode_rail_fence,
    decode_columnar,
    decode_reverse,
)


def decoder_outputs(data: bytes, *, include_risky: bool = False, max_output_size: int = 2_000_000) -> list[DecodeAttempt]:
    outputs: list[DecodeAttempt] = []
    seen: set[tuple[str, bytes]] = set()
    for decoder in DECODER_FUNCTIONS:
        try:
            attempts = list(decoder(data))
        # One broken decoder must not stop independent detector probes.
        except Exception:  # nosec B112
            continue
        for attempt in attempts:
            if not attempt.data or attempt.data == data or len(attempt.data) > max_output_size:
                continue
            if attempt.risk == "risky" and not include_risky and not FLAG_SHAPE_RE.search(attempt.data):
                continue
            key = (attempt.action, attempt.data)
            if key in seen:
                continue
            seen.add(key)
            outputs.append(attempt)
    return outputs


def supported_decoders() -> list[str]:
    names = []
    for decoder in DECODER_FUNCTIONS:
        name = decoder.__name__.replace("decode_", "").replace("_", "-")
        names.append(name)
    return names
