from __future__ import annotations

import math
import re
import string

from encid.models import DecodeAttempt, clamp

PRINTABLE = set(bytes(string.printable, "ascii"))
TEXT_CHARS = set(bytes(string.ascii_letters + string.digits + string.punctuation + " \t\r\n", "ascii"))

FLAG_RE = re.compile(rb"(?i)(picoCTF|flag|ctf|softwarica|hack|secret|password|token|key|admin)")
FLAG_SHAPE_RE = re.compile(rb"[A-Za-z0-9_.:/@ -]{2,}\{[A-Za-z0-9_@!#$%^&*()+,./:;=? \-]{3,}\}")

COMMON_WORDS = [
    b"the", b"and", b"you", b"that", b"have", b"with", b"this", b"from", b"not",
    b"flag", b"secret", b"password", b"token", b"picoCTF", b"CTF", b"softwarica",
    b"http", b"https", b"admin", b"user", b"login", b"true", b"false", b"null",
    b"error", b"warning", b"success", b"session", b"cookie", b"root", b"uid",
]

EXPECTED_ENGLISH = {
    "a": 8.17, "b": 1.49, "c": 2.78, "d": 4.25, "e": 12.70, "f": 2.23,
    "g": 2.02, "h": 6.09, "i": 6.97, "j": 0.15, "k": 0.77, "l": 4.03,
    "m": 2.41, "n": 6.75, "o": 7.51, "p": 1.93, "q": 0.10, "r": 5.99,
    "s": 6.33, "t": 9.06, "u": 2.76, "v": 0.98, "w": 2.36, "x": 0.15,
    "y": 1.97, "z": 0.07,
}


def entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts: dict[int, int] = {}
    for byte in data:
        counts[byte] = counts.get(byte, 0) + 1
    total = len(data)
    score = 0.0
    for count in counts.values():
        probability = count / total
        score -= probability * math.log2(probability)
    return score


def printable_ratio(data: bytes) -> float:
    if not data:
        return 0.0
    return sum(byte in PRINTABLE for byte in data) / len(data)


def text_ratio(data: bytes) -> float:
    if not data:
        return 0.0
    return sum(byte in TEXT_CHARS for byte in data) / len(data)


def utf8_ratio(data: bytes) -> float:
    if not data:
        return 0.0
    try:
        data.decode("utf-8")
        return 1.0
    except UnicodeDecodeError as exc:
        valid = max(0, exc.start)
        return valid / len(data)


def preview(data: bytes, limit: int = 220) -> str:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        text = data.decode("latin-1", errors="replace")
    text = text.replace("\r", "\\r").replace("\n", "\\n")
    if len(text) > limit:
        return text[:limit] + "..."
    return text


def is_good_text(data: bytes) -> bool:
    if not data:
        return False
    if FLAG_RE.search(data) or FLAG_SHAPE_RE.search(data):
        return True
    if len(data) < 4:
        return False
    return printable_ratio(data) >= 0.88 and text_ratio(data) >= 0.78


def chi_square_english(text: str) -> float:
    letters = [char.lower() for char in text if char.isalpha() and char.isascii()]
    if not letters:
        return 999.0
    total = len(letters)
    counts = {letter: 0 for letter in EXPECTED_ENGLISH}
    for letter in letters:
        if letter in counts:
            counts[letter] += 1
    score = 0.0
    for letter, expected_percent in EXPECTED_ENGLISH.items():
        expected = total * expected_percent / 100
        if expected:
            score += (counts[letter] - expected) ** 2 / expected
    return score


def score_text(data: bytes) -> float:
    if not data:
        return -9999.0

    score = 0.0
    pr = printable_ratio(data)
    tr = text_ratio(data)
    utf8 = utf8_ratio(data)
    ent = entropy(data)

    score += pr * 52
    score += tr * 34
    score += utf8 * 10

    lower = data.lower()
    for word in COMMON_WORDS:
        if word.lower() in lower:
            score += 10

    if FLAG_RE.search(data):
        score += 80
    if FLAG_SHAPE_RE.search(data):
        score += 200

    control_count = sum(byte < 32 and byte not in (9, 10, 13) for byte in data)
    score -= control_count * 2.5

    if 2.0 <= ent <= 5.9:
        score += 18
    elif ent > 7.0:
        score -= 25

    if len(data) < 3:
        score -= 45
    elif len(data) < 6:
        score -= 8

    try:
        text = data.decode("ascii")
    except UnicodeDecodeError:
        text = ""
    if text:
        chi = chi_square_english(text)
        alpha = sum(char.isalpha() for char in text)
        if alpha >= 8 and chi < 90:
            score += max(0.0, 24.0 - chi / 8.0)

    return score


def score_decode_confidence(input_data: bytes, attempt: DecodeAttempt) -> float:
    out = attempt.data
    confidence = attempt.structural_confidence
    before_score = score_text(input_data)
    after_score = score_text(out)
    delta = after_score - before_score

    if is_good_text(out):
        confidence += 0.18
    if FLAG_RE.search(out) or FLAG_SHAPE_RE.search(out):
        confidence += 0.28
    if delta >= 35:
        confidence += 0.18
    elif delta >= 18:
        confidence += 0.10
    elif delta <= -35:
        confidence -= 0.22
    elif delta <= -15:
        confidence -= 0.10

    pr = printable_ratio(out)
    if len(out) >= 4 and pr >= 0.90:
        confidence += 0.08
    if len(out) >= 16 and entropy(out) > 7.2 and pr < 0.45:
        confidence -= 0.12
    if len(out) < 3:
        confidence -= 0.35

    if attempt.risk == "cautious":
        confidence -= 0.08
    elif attempt.risk == "risky":
        confidence -= 0.20

    return clamp(confidence)


def chain_rank(text_score: float, confidence: float, layer_count: int) -> float:
    return text_score + confidence * 45 - layer_count * 2.5
