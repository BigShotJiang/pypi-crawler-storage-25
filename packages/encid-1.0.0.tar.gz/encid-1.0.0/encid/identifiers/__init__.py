from __future__ import annotations

import base64
import json
import re

from encid.models import Detection
from encid.scoring import chi_square_english, entropy, preview, printable_ratio


def _compact(text: str) -> str:
    return re.sub(r"\s+", "", text.strip())


def _det(
    typ: str,
    name: str,
    confidence: float,
    reason: str,
    *evidence: str,
) -> Detection:
    return Detection(typ, name, confidence, reason, tuple(item for item in evidence if item))


RAW_HEX_WIDTHS: dict[int, tuple[str, float, str]] = {
    4: ("raw 16-bit hex/checksum-sized material", 0.34, "CRC16-sized value, small integer, byte data, or random hex"),
    8: ("raw 32-bit hex/checksum-sized material", 0.42, "CRC32/Adler32-sized value, color/integer, byte data, or random hex"),
    32: ("raw 128-bit hex material", 0.56, "MD5/NTLM-sized digest, UUID-sized value, key material, ciphertext, or random bytes"),
    40: ("raw 160-bit hex material", 0.58, "SHA1/RIPEMD160-sized digest, key material, ciphertext, or random bytes"),
    56: ("raw 224-bit hex material", 0.56, "SHA224/SHA3-224-sized digest, KDF output, key material, ciphertext, or random bytes"),
    64: ("raw 256-bit hex material", 0.58, "SHA256/SHA3-256/BLAKE2s/Keccak-sized digest, KDF output, key material, ciphertext, or random bytes"),
    96: ("raw 384-bit hex material", 0.56, "SHA384/SHA3-384-sized digest, KDF output, key material, ciphertext, or random bytes"),
    128: ("raw 512-bit hex material", 0.58, "SHA512/SHA3-512/BLAKE2b-sized digest, scrypt/PBKDF output, key material, ciphertext, or random bytes"),
}

HASH_PATTERNS: tuple[tuple[str, str, float, str], ...] = (
    ("bcrypt", r"^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$", 0.96, "bcrypt modular crypt format."),
    ("Argon2 PHC", r"^\$argon2(?:id|i|d)\$v=\d+\$m=\d+,t=\d+,p=\d+\$", 0.96, "Argon2 PHC string format."),
    ("scrypt PHC/passlib", r"^\$(?:scrypt|7)\$", 0.88, "scrypt encoded password hash format."),
    ("yescrypt", r"^\$y\$", 0.90, "yescrypt password hash format."),
    ("sha512crypt", r"^\$6\$", 0.90, "Unix sha512crypt format."),
    ("sha256crypt", r"^\$5\$", 0.90, "Unix sha256crypt format."),
    ("md5crypt", r"^\$1\$", 0.90, "Unix md5crypt format."),
    ("Apache apr1", r"^\$apr1\$", 0.92, "Apache apr1-md5 format."),
    ("phpass / WordPress", r"^\$[PH]\$[./A-Za-z0-9]{31}$", 0.90, "phpass portable hash format."),
    ("MySQL5 SHA1 password hash", r"^\*[a-fA-F0-9]{40}$", 0.94, "MySQL native password hash."),
    ("Django PBKDF2", r"^pbkdf2_sha(256|1)\$\d+\$", 0.94, "Django PBKDF2 password hash format."),
    ("LDAP salted SHA", r"^\{S?SHA(?:256|384|512)?\}[A-Za-z0-9+/=]+$", 0.90, "LDAP-style base64 password hash wrapper."),
    ("NetNTLMv1/v2 candidate", r"^[^:]+::?[^:]*:[a-fA-F0-9]{16,32}:[a-fA-F0-9]{32,}:.+", 0.82, "Windows challenge-response hash format."),
    ("Kerberos hash candidate", r"^\$krb5(?:asrep|tgs)\$", 0.92, "Kerberos hash format used by cracking tools."),
    ("MSSQL password hash candidate", r"^0x0100[a-fA-F0-9]{88,}$", 0.86, "MSSQL password hash prefix."),
    ("Oracle 11g/12c hash candidate", r"^S:[a-fA-F0-9]{60}(?::[a-fA-F0-9]+)?$", 0.74, "Oracle S: password hash format."),
)


def identify_hex_material(text: str) -> list[Detection]:
    value = text.strip()
    body = value[2:] if value.startswith(("0x", "0X")) else value
    if not re.fullmatch(r"[a-fA-F0-9]+", body):
        return []

    match = RAW_HEX_WIDTHS.get(len(body))
    if match is None:
        return []

    name, confidence, possibilities = match
    reason = (
        f"{len(body)} contiguous hex chars ({len(body) * 4} bits). "
        "Length matches common digest/key widths, but raw hex has no algorithm metadata. "
        f"It could be {possibilities}."
    )
    return [_det(
        "material",
        name,
        confidence,
        reason,
        f"hex_chars={len(body)}",
        f"bytes={len(body) // 2}",
        "algorithm=unknown",
    )]


def identify_hash(text: str) -> list[Detection]:
    value = text.strip()
    out = []
    for name, pattern, confidence, reason in HASH_PATTERNS:
        if re.fullmatch(pattern, value):
            out.append(_det("hash", name, confidence, reason + " Hashes are one-way; encid identifies shape only.", f"length={len(value)}"))
    if re.fullmatch(r"[aby][./A-Za-z0-9]{52}", value):
        out.append(_det(
            "warning",
            "possible shell-expanded bcrypt hash",
            0.52,
            "This looks like a bcrypt body without the $2x$cost$ prefix. If you typed a bcrypt hash in a shell, wrap it in single quotes so $2b, $10, and similar parts are not expanded.",
            f"length={len(value)}",
        ))
    return out


def _index_of_coincidence(letters: list[str]) -> float:
    total = len(letters)
    if total < 2:
        return 0.0
    counts: dict[str, int] = {}
    for letter in letters:
        key = letter.lower()
        counts[key] = counts.get(key, 0) + 1
    numerator = sum(count * (count - 1) for count in counts.values())
    return numerator / (total * (total - 1))


def _repeated_ngram_count(letters: list[str], width: int = 3, limit: int = 8) -> int:
    stream = "".join(letter.lower() for letter in letters)
    if len(stream) < width * 2:
        return 0
    seen: set[str] = set()
    repeats = 0
    for index in range(0, len(stream) - width + 1):
        ngram = stream[index:index + width]
        if ngram in seen:
            repeats += 1
            if repeats >= limit:
                return repeats
        else:
            seen.add(ngram)
    return repeats


def identify_encoding(text: str) -> list[Detection]:
    value = text.strip()
    compact = _compact(text)
    out: list[Detection] = []
    if not compact:
        return out

    if re.fullmatch(r"(?:\\x[0-9a-fA-F]{2}){2,}|(?:0x[0-9a-fA-F]{2}[\s,;:_-]*){2,}", value):
        out.append(_det("encoding", "escaped hex bytes", 0.86, "Explicit byte escape markers.", "\\xNN or 0xNN tokens"))
    elif len(compact) >= 4 and len(compact) % 2 == 0 and re.fullmatch(r"[a-fA-F0-9]+", compact):
        confidence = 0.54 if len(compact) in {8, 32, 40, 56, 64, 96, 128} else 0.72
        out.append(_det("encoding", "hex/base16 candidate", confidence, "Even-length hex alphabet. May also be a hash or random bytes.", f"hex_chars={len(compact)}"))

    if len(compact) >= 8 and re.fullmatch(r"[A-Z2-7=]+", compact.upper()):
        out.append(_det("encoding", "base32 candidate", 0.64, "RFC 4648 base32 alphabet. False positives possible for uppercase text."))
    if len(compact) >= 4 and len(compact) % 4 != 1 and re.fullmatch(r"[A-Za-z0-9+/]*={0,2}", compact):
        confidence = 0.70 if any(char in compact for char in "+/=") else 0.48
        out.append(_det("encoding", "base64 candidate", confidence, "Base64 alphabet and plausible length. Plain alphanumeric strings can overlap."))
    if len(compact) >= 4 and len(compact) % 4 != 1 and re.fullmatch(r"[A-Za-z0-9_-]*={0,2}", compact):
        confidence = 0.70 if any(char in compact for char in "-_=") else 0.44
        out.append(_det("encoding", "base64url candidate", confidence, "URL-safe base64 alphabet and plausible length."))
    if len(compact) >= 5 and re.fullmatch(r"[1-9A-HJ-NP-Za-km-z]+", compact):
        out.append(_det("encoding", "base58 candidate", 0.46, "Bitcoin base58 alphabet. Also overlaps with ordinary alphanumeric text."))
    if len(compact) >= 8 and re.fullmatch(r"[0-9A-Za-z]+", compact) and re.search(r"[A-Za-z]", compact) and re.search(r"\d", compact):
        out.append(_det("encoding", "base62/base36 candidate", 0.32, "Alphanumeric base encodings overlap heavily with identifiers and words."))
    if len(compact) >= 4 and re.fullmatch(r"[0-9A-Z $%*+\-./:]+", compact):
        out.append(_det("encoding", "base45 candidate", 0.48, "Base45 alphabet. Often seen in QR/pass data."))
    if (
        len(compact) >= 6
        and re.fullmatch(r"[A-Za-z0-9!#$%&()*+,./:;<=>?@\[\]^_`{|}~\"]+", compact)
        and re.search(r"[!#$%&()*+,./:;<=>?@\[\]^_`{|}~\"]", compact)
    ):
        out.append(_det("encoding", "base91 candidate", 0.34, "basE91 printable alphabet is broad. Treat as low-confidence until decoded output scores well."))
    if (
        len(compact) >= 4
        and re.fullmatch(r"[!#$%&'()*+,\-./0-9:;<=>?@A-Z\[\\\]^_a-z{|}]+", compact)
        and re.search(r"[!#$%&'()*+,\-./:;<=>?@\[\\\]^_{|}]", compact)
    ):
        out.append(_det("encoding", "base92 candidate", 0.32, "Base92 printable alphabet is broad. Treat as low-confidence until decoded output scores well."))

    if "%" in value and re.search(r"%[0-9A-Fa-f]{2}", value):
        escapes = len(re.findall(r"%[0-9A-Fa-f]{2}", value))
        confidence = 0.86
        if escapes == 1 and re.fullmatch(r"[0-9A-Z $%*+\-./:]+", value):
            confidence = 0.42
        out.append(_det("encoding", "URL percent encoding", confidence, "Contains percent byte escapes."))
    if "&" in value and re.search(r"&(?:#\d+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]+);", value):
        out.append(_det("encoding", "HTML/XML entities", 0.86, "Contains entity references."))
    if re.search(r"\\(?:x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4}|U[0-9A-Fa-f]{8})", value):
        out.append(_det("encoding", "Unicode/JS escapes", 0.86, "Contains backslash byte or Unicode escapes."))
    if re.search(r"=[0-9A-Fa-f]{2}", value):
        out.append(_det("encoding", "quoted-printable candidate", 0.70, "Contains quoted-printable escape markers."))
    if re.fullmatch(r"[01\s]+", value) and len(re.sub(r"\s+", "", value)) % 8 == 0:
        out.append(_det("encoding", "binary byte string", 0.82, "Only bits and whitespace in 8-bit groups."))
    if re.fullmatch(r"[\s./|\-]+", value) and any(mark in value for mark in ".-"):
        out.append(_det("encoding", "Morse code candidate", 0.72, "Only dot/dash separators."))
    if re.fullmatch(r"[abAB\s]+", value) and len(re.sub(r"[^abAB]", "", value)) % 5 == 0:
        out.append(_det("encoding", "Baconian candidate", 0.54, "A/B alphabet in groups of five."))

    brainfuck_chars = sum(char in "><+-.,[]" for char in value)
    non_space = sum(not char.isspace() for char in value)
    if brainfuck_chars >= 8 and any(char in value for char in "><+[,]") and non_space and brainfuck_chars / non_space >= 0.75:
        out.append(_det("esolang", "Brainfuck", 0.82, "Input is mostly Brainfuck instruction characters."))
    if len(re.findall(r"Ook[.!?]", value)) >= 8:
        out.append(_det("esolang", "Ook", 0.86, "Ook token stream detected."))
    if re.fullmatch(r"[\[\]\(\)\+!]+", compact) and len(compact) >= 20:
        out.append(_det("esolang", "JSFuck", 0.86, "Input uses the JSFuck character set. encid identifies it but does not eval JavaScript."))
    if "ﾟωﾟ" in value or "(ﾟДﾟ)" in value or "ﾟｰﾟ" in value:
        out.append(_det("esolang", "AAEncode", 0.88, "AAEncode marker characters detected. encid does not eval JavaScript."))
    if re.search(r"\$=~\[\]|\$_=|\$__|\$_\$", value):
        out.append(_det("esolang", "JJEncode", 0.76, "JJEncode-like JavaScript variable pattern detected. encid does not eval JavaScript."))

    zero_width = sum(char in "\u200b\u200c\u200d\u2060\ufeff" for char in value)
    if zero_width >= 8:
        out.append(_det("encoding", "zero-width Unicode binary", 0.82, "Contains many zero-width codepoints."))
    if value and all(char in " \t\r\n" for char in value) and any(char == "\t" for char in value):
        out.append(_det("encoding", "whitespace binary", 0.72, "Only spaces, tabs, and newlines."))
    if value and all(0x2800 <= ord(char) <= 0x28FF for char in value.strip()):
        out.append(_det("encoding", "braille byte patterns", 0.64, "Unicode braille patterns can encode bytes directly."))
    if any(marker in value for marker in ("=ybegin", "=yend")):
        out.append(_det("encoding", "yEnc", 0.90, "yEnc header/footer marker."))
    if re.search(r"(?m)^begin [0-7]{3} ", value):
        out.append(_det("encoding", "UUEncode/XXEncode", 0.86, "begin mode filename wrapper found."))

    return out


def identify_classical_cipher(text: str) -> list[Detection]:
    value = text.strip()
    if len(value) < 16:
        return []
    compact = _compact(value)
    if re.fullmatch(r"(?:0x)?[a-fA-F0-9]+", compact):
        return []
    if re.search(r"\{[^}]{3,}\}", value):
        return []
    letters = [char for char in value if char.isalpha() and char.isascii()]
    if len(letters) < 12:
        return []
    alpha_ratio = len(letters) / max(1, len(value))
    whitespace_ratio = sum(char.isspace() for char in value) / max(1, len(value))
    uppercase_ratio = sum(char.isupper() for char in letters) / max(1, len(letters))
    chi = chi_square_english(value)
    ic = _index_of_coincidence(letters)
    wordish_plaintext = whitespace_ratio >= 0.10 and chi < 130
    out: list[Detection] = []

    if alpha_ratio > 0.82 and not wordish_plaintext:
        confidence = 0.22
        evidence = [f"alpha_ratio={alpha_ratio:.2f}", f"whitespace_ratio={whitespace_ratio:.2f}", f"ic={ic:.3f}"]
        if whitespace_ratio < 0.04:
            confidence += 0.06
        if uppercase_ratio > 0.85:
            confidence += 0.03
            evidence.append(f"uppercase_ratio={uppercase_ratio:.2f}")
        if 0.035 <= ic <= 0.075:
            confidence += 0.03
        out.append(_det(
            "cipher",
            "classical cipher text-shape signal",
            min(confidence, 0.34),
            "Mostly alphabetic text with weak ciphertext-like shape. This is advisory only; it cannot prove Caesar, affine, Vigenere, rail fence, or transposition without a successful decode.",
            *evidence,
        ))

    repeats = _repeated_ngram_count(letters)
    if repeats and len(letters) >= 32 and not wordish_plaintext:
        confidence = 0.26 + min(0.08, repeats * 0.02)
        out.append(_det(
            "cipher",
            "Vigenere/repeating-key candidate",
            confidence,
            "Repeated alphabetic sequences can indicate a repeating-key cipher, but this remains weak heuristic evidence unless a decode succeeds.",
            f"repeated_trigrams={repeats}",
            f"ic={ic:.3f}",
        ))
    return out


def identify_crypto_or_tokens(text: str, raw: bytes) -> list[Detection]:
    value = text.strip()
    compact = _compact(value)
    out: list[Detection] = []

    if compact.startswith("gAAAAA"):
        out.append(_det("encryption", "Fernet token", 0.94, "Common Python cryptography Fernet token prefix. Needs the Fernet key."))
    if raw.startswith(b"Salted__") or compact.startswith("U2FsdGVkX1"):
        out.append(_det("encryption", "OpenSSL salted ciphertext", 0.94, "Starts with Salted__ or its base64 form. Needs password/cipher details."))
    if "-----BEGIN PGP MESSAGE-----" in value:
        out.append(_det("encryption", "PGP encrypted message", 0.96, "ASCII-armored PGP message. Needs private key/passphrase."))
    if re.search(r"-----BEGIN (RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----", value):
        out.append(_det("key", "PEM private key", 0.96, "Private key material, not an encoding."))
    if "-----BEGIN CERTIFICATE-----" in value:
        out.append(_det("certificate", "X.509 certificate", 0.96, "Certificate PEM block."))
    if re.fullmatch(r"[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", compact):
        out.append(_det("token", "JWT/JWS", 0.94, "Three base64url parts: header.payload.signature. Header and payload can be decoded; signature is not plaintext."))
    if re.fullmatch(r"[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+){4}", compact):
        out.append(_det("encryption", "JWE compact token", 0.94, "Five base64url parts. Encrypted JWT format; needs a key."))
    if compact.startswith("$ANSIBLE_VAULT;"):
        out.append(_det("encryption", "Ansible Vault", 0.94, "Ansible Vault ciphertext. Needs vault password."))
    if value.startswith("age-encryption.org/"):
        out.append(_det("encryption", "age encrypted file", 0.94, "age encryption header. Needs identity/private key."))
    if value.startswith("untrusted comment:") and "RWS" in value:
        out.append(_det("signature", "minisign/signify signature", 0.76, "Looks like a minisign/signify signature block."))
    if compact.startswith("ENC[AES256_GCM,"):
        out.append(_det("encryption", "SOPS encrypted value", 0.92, "SOPS AES-GCM value wrapper. Needs KMS/PGP/age key material."))
    if re.fullmatch(r"0x[a-fA-F0-9]{40}", compact):
        out.append(_det("identifier", "Ethereum address", 0.78, "0x plus 40 hex chars. Address, not an encoding."))
    if re.fullmatch(r"0x[a-fA-F0-9]{64}", compact):
        out.append(_det("key/hash", "32-byte hex value", 0.60, "Could be SHA256/Keccak, a private key, or ciphertext depending on context."))
    if re.fullmatch(r"[A-Za-z0-9+/]{43}=", compact):
        out.append(_det("key", "32-byte base64 key candidate", 0.58, "44-character base64 string can be a raw 256-bit key."))

    if len(compact) >= 32 and len(compact) % 2 == 0 and re.fullmatch(r"[a-fA-F0-9]+", compact):
        try:
            decoded = bytes.fromhex(compact[2:] if compact.startswith(("0x", "0X")) else compact)
        except ValueError:
            decoded = b""
        if decoded:
            decoded_entropy = entropy(decoded)
            decoded_printable = printable_ratio(decoded)
            if decoded_entropy >= 4.7 and decoded_printable < 0.55:
                out.append(_det(
                    "encryption",
                    "hex-encoded high-entropy blob",
                    0.46,
                    "Decoded bytes look random. Could be ciphertext, KDF output, compressed data, a raw key, or random bytes; algorithm cannot be proven from hex alone.",
                    f"bytes={len(decoded)}",
                    f"decoded_entropy={decoded_entropy:.2f}",
                ))

    if len(raw) >= 32 and entropy(raw) > 7.2 and printable_ratio(raw) < 0.40:
        out.append(_det("encryption", "high-entropy binary blob", 0.42, "Random-looking bytes. Could be ciphertext, compressed data, or a binary file.", f"entropy={entropy(raw):.2f}"))
    if len(compact) >= 64 and re.fullmatch(r"[A-Za-z0-9+/=_-]+", compact) and entropy(compact.encode()) > 5.0:
        out.append(_det("encryption", "high-entropy base64-like blob", 0.36, "Could be encoded ciphertext or compressed data. Outer encoding may decode, but encryption needs a key.", f"entropy={entropy(compact.encode()):.2f}"))

    return out


def magic_identify(data: bytes) -> list[Detection]:
    magic = [
        (b"\x89PNG\r\n\x1a\n", "file", "PNG image", 0.96),
        (b"\xff\xd8\xff", "file", "JPEG image", 0.96),
        (b"GIF87a", "file", "GIF image", 0.96),
        (b"GIF89a", "file", "GIF image", 0.96),
        (b"%PDF", "file", "PDF document", 0.96),
        (b"PK\x03\x04", "archive", "ZIP/JAR/DOCX/XLSX/APK archive", 0.94),
        (b"7z\xbc\xaf\x27\x1c", "archive", "7-Zip archive", 0.96),
        (b"Rar!\x1a\x07", "archive", "RAR archive", 0.96),
        (b"\x1f\x8b", "compression", "gzip", 0.96),
        (b"BZh", "compression", "bzip2", 0.94),
        (b"\xfd7zXZ\x00", "compression", "xz/lzma", 0.96),
        (b"\x7fELF", "file", "ELF executable", 0.96),
        (b"MZ", "file", "Windows PE executable", 0.74),
        (b"SQLite format 3\x00", "database", "SQLite database", 0.96),
        (b"\xd4\xc3\xb2\xa1", "capture", "pcap capture", 0.92),
        (b"\xa1\xb2\xc3\xd4", "capture", "pcap capture", 0.92),
        (b"\x0a\x0d\x0d\x0a", "capture", "pcapng capture", 0.92),
        (b"Salted__", "encryption", "OpenSSL salted ciphertext", 0.94),
    ]
    out = []
    for prefix, typ, name, confidence in magic:
        if data.startswith(prefix):
            out.append(_det(typ, name, confidence, f"Magic bytes match {name}.", f"prefix={prefix.hex()}"))
    return out


def decode_jwt(text: str) -> dict | None:
    compact = text.strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", compact):
        return None

    def b64url(part: str) -> bytes:
        return base64.urlsafe_b64decode(part + "=" * ((4 - len(part) % 4) % 4))

    try:
        header_part, payload_part, signature = compact.split(".")
        header_raw = b64url(header_part)
        payload_raw = b64url(payload_part)
        try:
            header: object = json.loads(header_raw.decode())
        except (UnicodeDecodeError, json.JSONDecodeError):
            header = preview(header_raw, 500)
        try:
            payload: object = json.loads(payload_raw.decode())
        except (UnicodeDecodeError, json.JSONDecodeError):
            payload = preview(payload_raw, 500)
        return {"header": header, "payload": payload, "signature_preview": signature[:32] + "..."}
    except Exception:
        return None


def identify_all(text: str, raw: bytes) -> list[Detection]:
    detections: list[Detection] = []
    detections.extend(magic_identify(raw))
    detections.extend(identify_hash(text))
    detections.extend(identify_hex_material(text))
    detections.extend(identify_crypto_or_tokens(text, raw))
    detections.extend(identify_encoding(text))
    detections.extend(identify_classical_cipher(text))

    unique: list[Detection] = []
    seen: set[tuple[str, str, str]] = set()
    for detection in detections:
        key = (detection.type, detection.name, detection.reason)
        if key in seen:
            continue
        seen.add(key)
        unique.append(detection)
    if any(detection.type in {"hash", "key", "certificate", "token"} and detection.confidence >= 0.90 for detection in unique):
        unique = [
            detection for detection in unique
            if detection.confidence >= 0.55 or detection.type not in {"encoding", "cipher", "esolang"}
        ]
    return sorted(unique, key=lambda item: item.confidence, reverse=True)
