from __future__ import annotations

import curses
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from textwrap import wrap

from encid import __version__
from encid.crypto import PasswordResult, normalize_type, password_operation, supported_types
from encid.encid import EngineOptions, build_result

SPINNERS = ("|", "/", "-", "\\")
COMMANDS: tuple[tuple[str, str], ...] = (
    ("/help", "show commands"),
    ("/bye", "exit"),
    ("/clear", "clear the console"),
    ("/risky", "enable broader decoders"),
    ("/safe", "disable risky decoders"),
    ("/all", "toggle alternate chains"),
    ("/explain", "toggle reasons and evidence"),
    ("/json", "toggle JSON rendering"),
    ("/depth", "set recursive decode depth"),
    ("/decrypt", "start password/key decrypt or hash verify"),
    ("/type", "select decrypt/verify type"),
    ("/passwd", "enter password/key without echo"),
)

TYPE_COMMANDS: tuple[tuple[str, str], ...] = tuple(
    (f"/type {item}", "decrypt/verify type")
    for item in supported_types()
    if item != "auto"
)


@dataclass
class TuiOptions:
    engine: EngineOptions
    show_all: bool = False
    explain: bool = False
    json_output: bool = False


def _clip(text: object, width: int) -> str:
    value = "".join(
        char if (ord(char) >= 32 and ord(char) != 127) else f"\\x{ord(char):02x}"
        for char in str(text).replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t")
    )
    if width <= 0:
        return ""
    if len(value) <= width:
        return value
    if width <= 1:
        return "…"
    return value[: width - 1] + "…"


def _box(title: str, body: list[str], width: int) -> list[str]:
    width = max(42, width)
    label = f"─[ {title} ]"
    top = "┌" + label + "─" * max(0, width - len(label) - 2) + "┐"
    bottom = "└" + "─" * (width - 2) + "┘"
    rows = [top]
    inner = width - 4
    for line in body or [""]:
        rows.append("│ " + _clip(line, inner).ljust(inner) + " │")
    rows.append(bottom)
    return rows


def _bar(value: float, width: int, fill: str = "█", empty: str = "░") -> str:
    value = max(0.0, min(1.0, value))
    width = max(1, width)
    filled = round(value * width)
    return fill * filled + empty * (width - filled)


def _layer_pattern(index: int, total: int, width: int) -> str:
    if total <= 0:
        return _bar(1.0, width, ">", ".")
    return _bar(index / total, width, ">", ".")


def _pct(value: float) -> str:
    return f"{value * 100:.0f}%"


def _result_lines(result: dict, width: int = 88, *, show_all: bool = False, explain: bool = False) -> list[str]:
    width = max(56, width)
    chain = result["best_chain"]
    layers = chain["layers"]
    content_width = width - 4

    lines: list[str] = []
    lines.extend(_box("ENCID // TACTICAL DECODE CONSOLE", [
        "MULTILAYER DECODER · HASH / ENCRYPTION IDENTIFIER · TRACE ENGINE",
    ], width))
    lines.append("")

    lines.extend(_box("RESULT", [
        f"TYPE         {str(result['type']).upper()}",
        f"CONFIDENCE   {str(chain['confidence_label']).upper()}  {chain['confidence']:.3f}",
        f"ENTROPY      {result['input_entropy']}",
        f"PRINTABLE    {_pct(result['input_printable_ratio'])}",
        f"LAYERS       {len(layers)}",
    ], width))
    lines.append("")

    if result.get("detections"):
        rows = []
        for detection in result["detections"][:8]:
            rows.append(
                f"{detection['type'].upper():<12} {detection['name']:<42} "
                f"{detection['confidence_label'].upper():<6} {detection['confidence']:.3f}"
            )
            if explain:
                rows.extend("  " + part for part in wrap(detection["reason"], content_width - 2)[:2])
        lines.extend(_box("IDENTIFIERS", rows, width))
        lines.append("")

    if layers:
        rows = []
        for layer in layers:
            rows.append(
                f"{layer['index']:02d}  {layer['action'].upper():<16} "
                f"{layer['confidence_label'].upper():<6} {layer['risk'].upper():<8} "
                f"{_clip(layer['output_preview'], max(10, content_width - 40))}"
            )
            if explain and layer.get("reason"):
                rows.extend("    " + part for part in wrap(layer["reason"], content_width - 4)[:2])
        lines.extend(_box("CHAIN", rows, width))
        lines.append("")

        graph_width = max(18, min(48, content_width - 8))
        graph = [
            f"L{layer['index']:<2} {_layer_pattern(layer['index'], len(layers), graph_width)}"
            for layer in layers
        ]
        lines.extend(_box("DECODE FIELD", graph, width))
        lines.append("")

    metrics = [
        f"entropy      [{_bar(min(float(result['input_entropy']) / 8.0, 1.0), 16, '#', '-')}]",
        f"plaintext    [{_bar(float(result['input_printable_ratio']), 16, '#', '-')}]",
        f"risk         [{_bar(_risk_score(layers), 16, '#', '-')}]",
        f"certainty    [{_bar(float(chain['confidence']), 16, '#', '-')}]",
    ]
    lines.extend(_box("SIGNAL", metrics, width))
    lines.append("")

    if result.get("warnings"):
        warning_rows: list[str] = []
        for warning in result["warnings"]:
            warning_rows.extend(wrap(warning, content_width))
        lines.extend(_box("WARNINGS", warning_rows, width))
        lines.append("")

    final_rows: list[str] = []
    for part in wrap(chain["final_text"], content_width) or [""]:
        final_rows.append(part)
    lines.extend(_box("FINAL", final_rows, width))

    if result.get("jwt"):
        lines.append("")
        jwt = json.dumps(result["jwt"], indent=2, ensure_ascii=False)
        lines.extend(_box("JWT", jwt.splitlines()[:18], width))

    if show_all and result.get("other_candidates"):
        lines.append("")
        rows = []
        for index, candidate in enumerate(result["other_candidates"][:6], 1):
            actions = " -> ".join(layer["action"] for layer in candidate["layers"])
            rows.append(f"{index:02d} {candidate['confidence_label'].upper():<6} {candidate['score']:<8} {actions}")
            rows.append(f"   {_clip(candidate['final_text'], content_width - 3)}")
        lines.extend(_box("ALTERNATES", rows, width))

    return lines


def _risk_score(layers: list[dict]) -> float:
    if not layers:
        return 0.0
    weights = {"safe": 0.15, "cautious": 0.45, "risky": 0.85}
    return sum(weights.get(layer["risk"], 0.45) for layer in layers) / len(layers)


def _help_lines(width: int) -> list[str]:
    return _box("HELP", [
        "Paste a value and press Enter to analyze it.",
        *[f"{command:<10} {description}" for command, description in COMMANDS],
    ], width)


def _command_suggestions(text: str, state: dict | None = None) -> list[tuple[str, str]]:
    if not text.startswith("/"):
        return []
    if text.startswith("/type"):
        if state is not None and not state.get("decrypt_enabled"):
            return [("/decrypt", "start password/key decrypt or hash verify")]
        if text == "/type":
            return [("/type ", "show supported decrypt/verify types")]
        matches = [(command, description) for command, description in TYPE_COMMANDS if command.startswith(text)]
        return matches or list(TYPE_COMMANDS)
    if text.startswith("/passwd"):
        if state is not None and not state.get("decrypt_type"):
            return [("/type ", "select decrypt/verify type first")]
        return [("/passwd", "enter password/key without echo")]
    commands = list(COMMANDS)
    if state is not None:
        if not state.get("decrypt_enabled"):
            commands = [(command, description) for command, description in commands if command not in {"/type", "/passwd"}]
        elif not state.get("decrypt_type"):
            commands = [(command, description) for command, description in commands if command != "/passwd"]
    command_part = text.split(maxsplit=1)[0]
    matches = [(command, description) for command, description in commands if command.startswith(command_part)]
    return matches or commands


def _is_partial_command(text: str) -> bool:
    if not text.startswith("/") or " " in text:
        return False
    commands = {command for command, _description in COMMANDS}
    return text not in commands


def _accepts_suggestion_on_enter(text: str, suggestions: list[tuple[str, str]]) -> bool:
    return bool(suggestions) and (_is_partial_command(text) or text == "/type " or text.startswith("/type "))


def run_tui(options: TuiOptions, initial_value: str | None = None) -> int:
    try:
        return curses.wrapper(_run_curses, options, initial_value)
    except curses.error:
        print("encid: terminal is too small for TUI; resize or use --no-tui", file=sys.stderr)
        return 2


def _run_curses(stdscr: curses.window, options: TuiOptions, initial_value: str | None) -> int:
    curses.curs_set(1)
    curses.use_default_colors()
    if curses.has_colors():
        curses.start_color()
        curses.init_pair(1, curses.COLOR_CYAN, -1)
        curses.init_pair(2, curses.COLOR_GREEN, -1)
        curses.init_pair(3, curses.COLOR_YELLOW, -1)
        curses.init_pair(4, curses.COLOR_RED, -1)

    state = {
        "lines": _welcome_lines(max(72, stdscr.getmaxyx()[1] - 2)),
        "scroll": 0,
        "pending": initial_value,
        "last_input": None,
        "last_result": None,
        "credential_offer": False,
        "decrypt_enabled": False,
        "decrypt_target": None,
        "decrypt_type": None,
    }

    while True:
        if state["pending"] is not None:
            value = state["pending"]
            state["pending"] = None
            if value.strip():
                rendered, result = _process_value(stdscr, options, value, state["lines"])
                state["lines"].extend(rendered)
                state["last_input"] = value
                state["last_result"] = result
                state["credential_offer"] = _should_offer_password(result)
                if state["credential_offer"]:
                    state["lines"].append("log: password/key available? type y to verify/decrypt, n to skip")
                state["scroll"] = 0
            continue

        command = _read_command(stdscr, options, state)
        if command is None:
            return 0
        command = command.strip()
        if not command:
            continue
        lowered = command.lower()
        if state.get("credential_offer") and lowered in {"y", "yes"}:
            state["credential_offer"] = False
            _start_password_offer(stdscr, options, state)
            continue
        if state.get("credential_offer") and lowered in {"n", "no"}:
            state["credential_offer"] = False
            state["lines"].append("log: password prompt skipped")
            continue
        if command in {"/bye", "/quit", "/exit", ":q", ":quit"}:
            return 0
        if command == "/help":
            state["lines"].extend(["", *_help_lines(max(72, stdscr.getmaxyx()[1] - 2))])
            state["scroll"] = 0
            continue
        if command == "/clear":
            state["lines"] = _welcome_lines(max(72, stdscr.getmaxyx()[1] - 2))
            state["credential_offer"] = False
            state["decrypt_enabled"] = False
            state["decrypt_target"] = None
            state["decrypt_type"] = None
            state["scroll"] = 0
            continue
        if command == "/risky":
            options.engine = EngineOptions(options.engine.max_depth, options.engine.beam_size, True, options.engine.min_confidence)
            state["lines"].append("log: risky decoders enabled")
            continue
        if command == "/safe":
            options.engine = EngineOptions(options.engine.max_depth, options.engine.beam_size, False, options.engine.min_confidence)
            state["lines"].append("log: risky decoders disabled")
            continue
        if command == "/all":
            options.show_all = not options.show_all
            state["lines"].append(f"log: alternate chains {'enabled' if options.show_all else 'disabled'}")
            continue
        if command == "/explain":
            options.explain = not options.explain
            state["lines"].append(f"log: explanations {'enabled' if options.explain else 'disabled'}")
            continue
        if command == "/json":
            options.json_output = not options.json_output
            state["lines"].append(f"log: json rendering {'enabled' if options.json_output else 'disabled'}")
            continue
        if command.startswith("/depth "):
            try:
                depth = max(0, int(command.split(None, 1)[1]))
            except ValueError:
                state["lines"].append("error: /depth expects an integer")
                continue
            options.engine = EngineOptions(depth, options.engine.beam_size, options.engine.include_risky, options.engine.min_confidence)
            state["lines"].append(f"log: max depth set to {depth}")
            continue
        if command == "/decrypt" or command.startswith("/decrypt "):
            target = command.split(None, 1)[1] if " " in command else state.get("last_input")
            if not target:
                state["lines"].append("error: analyze or pass ciphertext/hash before /decrypt")
                continue
            state["decrypt_enabled"] = True
            state["decrypt_target"] = target
            state["decrypt_type"] = _auto_type_from_result(state.get("last_result")) if target == state.get("last_input") else None
            last_result = state.get("last_result") or {}
            if state["decrypt_type"] and last_result.get("type") == "hash":
                _prompt_password_and_run(stdscr, options, state)
            else:
                state["lines"].append("log: decrypt mode enabled; choose /type <type>")
            continue
        if command.startswith("/type"):
            if not state.get("decrypt_enabled"):
                state["lines"].append("error: run /decrypt before /type")
                continue
            parts = command.split(maxsplit=1)
            if len(parts) == 1:
                state["lines"].append("error: choose a type, for example /type aes-256-cbc")
                continue
            chosen = normalize_type(parts[1])
            if chosen not in supported_types():
                state["lines"].append(f"error: unsupported type {chosen}")
                continue
            state["decrypt_type"] = chosen
            state["lines"].append(f"log: type set to {chosen}; password/key prompt opened")
            _prompt_password_and_run(stdscr, options, state)
            continue
        if command == "/passwd":
            if not state.get("decrypt_enabled"):
                state["lines"].append("error: run /decrypt before /passwd")
                continue
            if not state.get("decrypt_type"):
                state["lines"].append("error: choose /type before /passwd")
                continue
            _prompt_password_and_run(stdscr, options, state)
            continue

        state["pending"] = command


def _welcome_lines(width: int) -> list[str]:
    return [
        *_box("⬢ ENCID // TACTICAL DECODE CONSOLE", [
            f"version {__version__}",
            "paste encoded data, hash material, ciphertext, or /help",
        ], width),
        "",
        "log: console ready",
    ]


def _process_value(stdscr: curses.window, options: TuiOptions, value: str, existing_lines: list[str]) -> tuple[list[str], dict]:
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(build_result, value.encode(), options.engine)
        frame = 0
        while not future.done():
            _render(stdscr, existing_lines, "", processing=f"processing {SPINNERS[frame % len(SPINNERS)]}")
            frame += 1
            time.sleep(0.08)
        result = future.result()

    width = max(72, stdscr.getmaxyx()[1] - 2)
    if options.json_output:
        rendered = json.dumps(result, indent=2, ensure_ascii=False).splitlines()
    else:
        rendered = _result_lines(result, width, show_all=options.show_all, explain=options.explain)
    return ["", f"input: {_clip(value, width - 8)}", *rendered], result


def _should_offer_password(result: dict | None) -> bool:
    if not result:
        return False
    if result.get("type") not in {"hash", "encryption"}:
        return False
    chain = result.get("best_chain", {})
    if float(chain.get("confidence", 0.0)) < 0.92:
        return False
    detections = result.get("detections") or []
    return bool(detections and float(detections[0].get("confidence", 0.0)) >= 0.90)


def _auto_type_from_result(result: dict | None) -> str | None:
    if not result:
        return None
    for detection in result.get("detections") or []:
        name = str(detection.get("name", "")).lower()
        if name == "bcrypt":
            return "bcrypt"
        if name.startswith("django pbkdf2"):
            return "django-pbkdf2-sha256" if "256" in name else "django-pbkdf2-sha1"
        if name.startswith("ldap"):
            return "ldap-ssha" if "salted" in name or "ssha" in name else "ldap-sha"
        if "openssl salted" in name:
            return "openssl-aes-256-cbc"
        if "fernet" in name:
            return "fernet"
    return None


def _start_password_offer(stdscr: curses.window, options: TuiOptions, state: dict) -> None:
    target = state.get("last_input")
    if not target:
        state["lines"].append("error: no previous input available")
        return
    state["decrypt_enabled"] = True
    state["decrypt_target"] = target
    state["decrypt_type"] = _auto_type_from_result(state.get("last_result"))
    if state["decrypt_type"]:
        _prompt_password_and_run(stdscr, options, state)
    else:
        state["lines"].append("log: choose /type <type>, then encid will ask for the password/key")


def _prompt_password_and_run(stdscr: curses.window, options: TuiOptions, state: dict) -> None:
    target = state.get("decrypt_target")
    typ = state.get("decrypt_type")
    if not target or not typ:
        state["lines"].append("error: decrypt target and type are required")
        return
    secret = _read_secret(stdscr, state["lines"], f"/passwd {typ}")
    if secret is None:
        state["lines"].append("log: password prompt cancelled")
        return
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(password_operation, target, secret, type_name=typ)
        frame = 0
        while not future.done():
            _render(stdscr, state["lines"], "", processing=f"{typ} {SPINNERS[frame % len(SPINNERS)]}")
            frame += 1
            time.sleep(0.08)
        result = future.result()
    state["lines"].extend(["", *_password_result_lines(result, max(72, stdscr.getmaxyx()[1] - 2))])
    state["scroll"] = 0


def _password_result_lines(result: PasswordResult, width: int) -> list[str]:
    data = result.to_dict()
    rows = [
        f"OPERATION    {data['operation'].upper()}",
        f"TYPE         {str(data['type']).upper()}",
        f"STATUS       {data['status']}",
        f"SUCCESS      {'YES' if data['ok'] else 'NO'}",
        f"CONFIDENCE   {data['confidence']:.3f}",
    ]
    lines = _box("PASSWORD RESULT", rows, width)
    if data.get("evidence"):
        evidence = [item for item in data["evidence"] if not str(item).startswith("preview=")]
        lines.extend(["", *_box("EVIDENCE", evidence[:8], width)])
    if data.get("warnings"):
        warning_rows: list[str] = []
        for warning in data["warnings"]:
            warning_rows.extend(wrap(warning, max(20, width - 4)))
        lines.extend(["", *_box("WARNINGS", warning_rows, width)])
    if data.get("output"):
        final_rows = wrap(data["output"], max(20, width - 4)) or [""]
        lines.extend(["", *_box("DECRYPTED", final_rows, width)])
    return lines


def _read_command(stdscr: curses.window, options: TuiOptions, state: dict) -> str | None:
    text = ""
    selected = 0
    while True:
        suggestions = _command_suggestions(text, state)
        if suggestions:
            selected %= len(suggestions)
        else:
            selected = 0
        _render(stdscr, state["lines"], text, scroll=state["scroll"], suggestions=suggestions, selected_suggestion=selected)
        key = stdscr.get_wch()
        if isinstance(key, str):
            if key in {"\n", "\r"}:
                if _accepts_suggestion_on_enter(text, suggestions):
                    command = suggestions[selected][0]
                    if command == "/depth":
                        text = "/depth "
                        continue
                    if command == "/type ":
                        text = "/type "
                        continue
                    return command
                return text
            if key == "\x03":
                return None
            if key in {"\x7f", "\b"}:
                text = text[:-1]
                continue
            if key == "\x15":
                text = ""
                continue
            if key == "\t" and suggestions:
                command = suggestions[selected][0]
                text = command + (" " if command in {"/depth", "/type"} else "")
                continue
            if key.isprintable():
                text += key
                selected = 0
                continue
        elif key == curses.KEY_BACKSPACE:
            text = text[:-1]
        elif key == curses.KEY_RESIZE:
            continue
        elif key == curses.KEY_DOWN and suggestions:
            selected = (selected + 1) % len(suggestions)
        elif key == curses.KEY_UP and suggestions:
            selected = (selected - 1) % len(suggestions)
        elif key == curses.KEY_PPAGE:
            state["scroll"] = min(state["scroll"] + 8, max(0, len(state["lines"]) - 1))
        elif key == curses.KEY_NPAGE:
            state["scroll"] = max(0, state["scroll"] - 8)


def _read_secret(stdscr: curses.window, lines: list[str], label: str) -> str | None:
    text = ""
    while True:
        _render(stdscr, lines, f"{label} {'*' * len(text)}")
        key = stdscr.get_wch()
        if isinstance(key, str):
            if key in {"\n", "\r"}:
                return text
            if key == "\x03":
                return None
            if key in {"\x7f", "\b"}:
                text = text[:-1]
                continue
            if key == "\x15":
                text = ""
                continue
            if key.isprintable():
                text += key
                continue
        elif key == curses.KEY_BACKSPACE:
            text = text[:-1]
        elif key == curses.KEY_RESIZE:
            continue


def _render(
    stdscr: curses.window,
    lines: list[str],
    input_text: str,
    processing: str | None = None,
    scroll: int = 0,
    suggestions: list[tuple[str, str]] | None = None,
    selected_suggestion: int = 0,
) -> None:
    stdscr.erase()
    height, width = stdscr.getmaxyx()
    input_height = 3 if processing is None else 0
    visible_height = max(1, height - input_height)
    start = max(0, len(lines) - visible_height - max(0, scroll))
    visible = lines[start:]

    for row, line in enumerate(visible[:visible_height]):
        attr = curses.A_NORMAL
        if "ENCID" in line or "RESULT" in line or "FINAL" in line:
            attr = curses.color_pair(1) if curses.has_colors() else curses.A_BOLD
        elif "HIGH" in line or "SAFE" in line:
            attr = curses.color_pair(2) if curses.has_colors() else curses.A_NORMAL
        elif "WARN" in line or "CAUTIOUS" in line:
            attr = curses.color_pair(3) if curses.has_colors() else curses.A_NORMAL
        try:
            stdscr.addnstr(row, 0, line, width - 1, attr)
        except curses.error:
            pass

    if processing is not None:
        message = f"┌─[ {processing.upper()} ]" + "─" * max(0, width - len(processing) - 8) + "┐"
        try:
            stdscr.addnstr(height - 1, 0, message, width - 1, curses.color_pair(3) if curses.has_colors() else curses.A_BOLD)
        except curses.error:
            pass
        stdscr.refresh()
        return

    prompt = "❯ "
    top = "┌" + "─" * (width - 2) + "┐"
    bottom = "└" + "─" * (width - 2) + "┘"
    field = "│ " + _clip(prompt + input_text, width - 4).ljust(width - 4) + " │"
    base = height - 3
    try:
        _draw_suggestion_popup(stdscr, base, width, suggestions or [], selected_suggestion)
        stdscr.addnstr(base, 0, top, width - 1)
        stdscr.addnstr(base + 1, 0, field, width - 1)
        stdscr.addnstr(base + 2, 0, bottom, width - 1)
        cursor_x = min(width - 3, 2 + len(prompt) + len(input_text))
        stdscr.move(base + 1, cursor_x)
    except curses.error:
        pass
    stdscr.refresh()


def _draw_suggestion_popup(
    stdscr: curses.window,
    input_top: int,
    width: int,
    suggestions: list[tuple[str, str]],
    selected: int,
) -> None:
    if not suggestions or input_top < 5:
        return
    popup_width = min(max(46, width // 2), width - 4)
    visible = suggestions[: min(6, input_top - 2)]
    popup_height = len(visible) + 2
    left = 2
    top = max(0, input_top - popup_height)
    title = "─[ COMMANDS ]"
    border_attr = curses.color_pair(1) if curses.has_colors() else curses.A_BOLD
    selected_attr = curses.color_pair(2) | curses.A_REVERSE if curses.has_colors() else curses.A_REVERSE
    normal_attr = curses.A_NORMAL
    try:
        stdscr.addnstr(top, left, "┌" + title + "─" * max(0, popup_width - len(title) - 2) + "┐", popup_width, border_attr)
        for index, (command, description) in enumerate(visible):
            pointer = "›" if index == selected else " "
            inner = popup_width - 4
            command_width = min(24, max(10, inner // 2))
            description_width = max(0, inner - command_width - 3)
            row_inner = (
                f"{pointer} "
                f"{_clip(command, command_width).ljust(command_width)} "
                f"{_clip(description, description_width).ljust(description_width)}"
            )
            row = f"│ {row_inner[:inner].ljust(inner)} │"
            attr = selected_attr if index == selected else normal_attr
            stdscr.addnstr(top + index + 1, left, row, popup_width, attr)
        stdscr.addnstr(top + popup_height - 1, left, "└" + "─" * (popup_width - 2) + "┘", popup_width, border_attr)
    except curses.error:
        pass
