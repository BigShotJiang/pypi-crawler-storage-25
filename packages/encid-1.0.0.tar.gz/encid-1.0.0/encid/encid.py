from __future__ import annotations

import argparse
import getpass
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path

from encid import __version__
from encid.decoders import decode_atbash, decode_rot13, decoder_outputs, supported_decoders
from encid.identifiers import (
    decode_jwt,
    identify_all,
    identify_crypto_or_tokens,
    identify_hash,
    identify_hex_material,
    magic_identify,
)
from encid.models import Candidate, DecodeAttempt, Detection, Layer, clamp, confidence_label
from encid.scoring import (
    FLAG_SHAPE_RE,
    chain_rank,
    entropy,
    is_good_text,
    preview,
    printable_ratio,
    score_decode_confidence,
    score_text,
)


@dataclass(frozen=True)
class EngineOptions:
    max_depth: int = 8
    beam_size: int = 50
    include_risky: bool = False
    min_confidence: float = 0.20


def _decode_for_identification(data: bytes) -> str:
    return data.decode("latin-1", errors="replace").strip()


def _has_strong_identifier(detections: list[Detection]) -> bool:
    strong_types = {"hash", "encryption", "key", "certificate", "archive", "file", "capture", "database"}
    return any(
        (detection.type in strong_types and detection.confidence >= 0.62)
        or (detection.type == "material" and detection.confidence >= 0.55)
        for detection in detections
    )


def _case_lost_base_encoding_warning(best: Candidate) -> str | None:
    if not best.layers or best.layers[-1].action != "morse":
        return None
    text = _decode_for_identification(best.data)
    compact = re.sub(r"\s+", "", text)
    if not compact or compact != compact.upper():
        return None
    if len(compact) >= 16 and len(compact) % 4 == 0 and re.fullmatch(r"[A-Z0-9+/]+={0,2}", compact):
        return (
            "Morse output is uppercase base64-like text. Morse does not preserve letter case, "
            "and Base64 is case-sensitive, so the original Base64 cannot be recovered exactly without extra context."
        )
    return None


def _candidate_attempts(candidate: Candidate, options: EngineOptions) -> list[DecodeAttempt]:
    if not candidate.layers or not FLAG_SHAPE_RE.search(candidate.data):
        return decoder_outputs(candidate.data, include_risky=options.include_risky)

    attempts: list[DecodeAttempt] = []
    for decoder in (decode_rot13, decode_atbash):
        for attempt in decoder(candidate.data):
            if FLAG_SHAPE_RE.search(attempt.data) or score_text(attempt.data) > candidate.text_score + 12:
                attempts.append(attempt)
    return attempts


def _attempt_confidence(input_data: bytes, attempt: DecodeAttempt) -> float:
    confidence = score_decode_confidence(input_data, attempt)
    output_text = _decode_for_identification(attempt.data)
    output_detections = (
        magic_identify(attempt.data)
        + identify_hash(output_text)
        + identify_hex_material(output_text)
        + identify_crypto_or_tokens(output_text, attempt.data)
    )
    if any(detection.confidence >= 0.80 for detection in output_detections):
        confidence += 0.10
    return clamp(confidence)


def recursive_decode(raw: bytes, options: EngineOptions) -> list[Candidate]:
    start_score = score_text(raw)
    start = Candidate(raw, (), start_score, start_score, 1.0)
    beam = [start]
    finished = [start]
    seen_bytes = {raw}

    for _depth in range(options.max_depth):
        new_candidates: list[Candidate] = []
        for candidate in beam:
            for attempt in _candidate_attempts(candidate, options):
                if attempt.data in seen_bytes:
                    continue
                seen_bytes.add(attempt.data)

                confidence = _attempt_confidence(candidate.data, attempt)
                output_score = score_text(attempt.data)
                output_text = _decode_for_identification(attempt.data)
                identifiable = bool(
                    magic_identify(attempt.data)
                    or identify_hash(output_text)
                    or identify_hex_material(output_text)
                    or identify_crypto_or_tokens(output_text, attempt.data)
                )
                good = is_good_text(attempt.data) or bool(FLAG_SHAPE_RE.search(attempt.data))

                if confidence < options.min_confidence and not good and not identifiable:
                    continue

                layer = Layer(
                    index=len(candidate.layers) + 1,
                    action=attempt.action,
                    input_preview=preview(candidate.data),
                    output_preview=preview(attempt.data),
                    output_score=round(output_score, 2),
                    confidence=confidence,
                    confidence_label=confidence_label(confidence),
                    risk=attempt.risk,
                    reason=attempt.reason,
                    evidence=attempt.evidence,
                )
                layer_count = len(candidate.layers) + 1
                chain_confidence = clamp((candidate.confidence * len(candidate.layers) + confidence) / layer_count)
                chain_score = chain_rank(output_score, chain_confidence, layer_count)
                new_candidate = Candidate(
                    attempt.data,
                    candidate.layers + (layer,),
                    output_score,
                    chain_score,
                    chain_confidence,
                )

                promising = (
                    confidence >= options.min_confidence
                    or good
                    or identifiable
                    or output_score > candidate.text_score - 5
                )
                if promising:
                    new_candidates.append(new_candidate)
                    finished.append(new_candidate)

        if not new_candidates:
            break
        new_candidates.sort(key=lambda item: item.chain_score, reverse=True)
        beam = new_candidates[:options.beam_size]

    finished.sort(
        key=lambda item: (
            bool(FLAG_SHAPE_RE.search(item.data)),
            item.chain_score,
            item.confidence,
            -len(item.layers),
        ),
        reverse=True,
    )
    return finished


def classify_final(input_text: str, input_raw: bytes, best: Candidate) -> tuple[str, list[Detection], dict | None]:
    detections = identify_all(input_text, input_raw)
    final_text = _decode_for_identification(best.data)

    if best.layers:
        detections.extend(identify_all(final_text, best.data))

    unique: list[Detection] = []
    seen: set[tuple[str, str, str]] = set()
    for detection in detections:
        key = (detection.type, detection.name, detection.reason)
        if key in seen:
            continue
        seen.add(key)
        unique.append(detection)
    unique.sort(key=lambda item: item.confidence, reverse=True)

    jwt = decode_jwt(input_text) or decode_jwt(final_text)

    if best.layers:
        result_type = "encoded"
    elif any(detection.type == "hash" for detection in unique):
        result_type = "hash"
    elif any(detection.type == "encryption" and detection.confidence >= 0.80 for detection in unique):
        result_type = "encryption"
    elif any(detection.type in {"token", "key", "certificate", "signature", "file", "archive", "capture", "database", "identifier"} for detection in unique):
        result_type = "identifier"
    elif any(detection.type == "material" for detection in unique):
        result_type = "ambiguous"
    elif any(detection.type == "encryption" for detection in unique):
        result_type = "encryption-candidate"
    elif any(detection.type == "encoding" and detection.confidence >= 0.55 for detection in unique):
        result_type = "encoding-candidate"
    else:
        result_type = "plain/unknown"

    return result_type, unique, jwt


def build_result(raw: bytes, options: EngineOptions) -> dict:
    input_text = _decode_for_identification(raw)
    candidates = recursive_decode(raw, options)
    best = candidates[0]

    original_detections = identify_all(input_text, raw)
    original_score = score_text(raw)
    if (
        best.layers
        and _has_strong_identifier(original_detections)
        and best.confidence < 0.76
        and best.text_score < original_score + 18
        and not FLAG_SHAPE_RE.search(best.data)
    ):
        best = Candidate(raw, (), original_score, original_score, 1.0)

    result_type, detections, jwt = classify_final(input_text, raw, best)

    def candidate_to_dict(candidate: Candidate) -> dict:
        return candidate.to_dict(
            preview(candidate.data, 1500),
            entropy(candidate.data),
            printable_ratio(candidate.data),
        )

    warnings = []
    case_warning = _case_lost_base_encoding_warning(best)
    if case_warning:
        warnings.append(case_warning)
    if result_type == "ambiguous" and any(detection.type == "material" and "hex" in detection.name for detection in detections):
        warnings.append(
            "Raw fixed-length hex is ambiguous: encid can identify width and shape, but cannot prove MD5/SHA/BLAKE/KDF/key/ciphertext/random without external metadata."
        )
    if result_type != "encoded" and any(detection.type == "cipher" for detection in detections):
        warnings.append(
            "Classical cipher detections are weak heuristics. Treat them as search hints unless a decode chain produces readable plaintext or known-format output."
        )

    return {
        "tool": "encid",
        "version": __version__,
        "type": result_type,
        "input_preview": preview(raw, 500),
        "input_entropy": round(entropy(raw), 3),
        "input_printable_ratio": round(printable_ratio(raw), 3),
        "detections": [detection.to_dict() for detection in detections],
        "jwt": jwt,
        "warnings": warnings,
        "best_chain": candidate_to_dict(best),
        "other_candidates": [
            candidate_to_dict(candidate)
            for candidate in candidates
            if candidate.layers and candidate.data != best.data
        ][:8],
        "notes": [
            "Hashes are one-way: encid identifies hash shapes but does not crack them.",
            "Encryption is identified by structure, signatures, and entropy; keys are required for decryption.",
            "Raw digest-length hex is reported as ambiguous material unless a structured hash format is present.",
            "Ambiguous transforms are down-ranked unless output evidence is strong. Use --risky for broader CTF brute force.",
        ],
    }


def output_text(result: dict, *, show_all: bool = False, explain: bool = False, banner: bool = True) -> None:
    if banner:
        print(f"encid {result['version']}")
    print(f"type: {result['type']}")

    chain = result["best_chain"]
    print(f"confidence: {chain['confidence_label']} ({chain['confidence']:.3f})")
    print(f"input: entropy={result['input_entropy']} printable={result['input_printable_ratio']}")

    if result["detections"]:
        print("\nidentifier/verifier:")
        for detection in result["detections"][:12]:
            print(
                f"  - {detection['type']} | {detection['name']} | "
                f"confidence={detection['confidence_label']} ({detection['confidence']:.3f})"
            )
            if explain:
                print(f"    {detection['reason']}")
                if detection["evidence"]:
                    print(f"    evidence: {', '.join(detection['evidence'])}")

    if result.get("jwt"):
        print("\njwt decoded parts:")
        print(json.dumps(result["jwt"], indent=2, ensure_ascii=False))

    if result.get("warnings"):
        print("\nwarnings:")
        for warning in result["warnings"]:
            print(f"  - {warning}")

    if chain["layers"]:
        print("\ndecode sequence:")
        for layer in chain["layers"]:
            print(
                f"  {layer['index']} | {layer['action']} | "
                f"confidence={layer['confidence_label']} ({layer['confidence']:.3f}) | risk={layer['risk']}"
            )
            if explain and layer["reason"]:
                print(f"      {layer['reason']}")
            print(f"      => {layer['output_preview']}")

    print("\nfinal:")
    print(chain["final_text"])

    if show_all and result["other_candidates"]:
        print("\nother candidate chains:")
        for index, candidate in enumerate(result["other_candidates"], 1):
            actions = " -> ".join(layer["action"] for layer in candidate["layers"])
            print(
                f"\n[{index}] score={candidate['score']} "
                f"confidence={candidate['confidence_label']} ({candidate['confidence']:.3f})"
            )
            print(f"    {actions}")
            print(f"    {candidate['final_text']}")


def _read_input(args: argparse.Namespace) -> bytes:
    if args.file:
        return Path(args.file).read_bytes()
    value = _value_from_args(args)
    if value is not None:
        return value.encode()
    return sys.stdin.buffer.read()


def _value_from_args(args: argparse.Namespace) -> str | None:
    if args.value is None:
        return None
    parts = [args.value, *getattr(args, "extra", [])]
    return " ".join(parts)


def _is_tui_command(args: argparse.Namespace) -> bool:
    value = (args.value or "").lower()
    extra = [item.lower() for item in getattr(args, "extra", [])]
    return value in {"tui", "open"} and (not extra or extra == ["tui"])


def _should_launch_tui(args: argparse.Namespace) -> bool:
    if args.no_tui or args.json or args.self_test or args.list_decoders:
        return False
    if args.tui or args.interactive or _is_tui_command(args):
        return True
    return sys.stdin.isatty() and sys.stdout.isatty()


def _options_from_args(args: argparse.Namespace) -> EngineOptions:
    return EngineOptions(
        max_depth=max(0, args.max_depth),
        beam_size=max(1, args.beam_size),
        include_risky=args.risky,
        min_confidence=max(0.0, min(1.0, args.min_confidence)),
    )


def run_self_test(args: argparse.Namespace) -> int:
    examples = [
        "cGljb0NURnt0ZXN0X2ZsYWd9",
        "7069636f4354467b6865785f746573747d",
        "uggcf%3A%2F%2Frknzcyr.pbz",
        "... --- ..-. - .-- .- .-. .. -.-. .-",
        "5d41402abc4b2a76b9719d911017c592",
        "++++++++[>++++++++<-]>+.+.+.",
    ]
    options = _options_from_args(args)
    for item in examples:
        print("=" * 80)
        print("input:", item)
        result = build_result(item.encode(), options)
        output_text(result, show_all=False, explain=True, banner=False)
    return 0


def run_interactive(args: argparse.Namespace) -> int:
    options = _options_from_args(args)
    show_json = args.json
    show_all = args.all
    explain = args.explain
    print(f"encid {__version__} interactive")
    print("commands: :help :quit :json :text :all :risky :safe :depth N :file PATH")
    while True:
        try:
            line = input("encid> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not line:
            continue
        command = line.strip()
        if command in {":q", ":quit", ":exit"}:
            return 0
        if command == ":help":
            print("enter data to analyze, or use :file PATH, :depth N, :risky, :safe, :json, :text, :all")
            continue
        if command == ":json":
            show_json = True
            print("json output on")
            continue
        if command == ":text":
            show_json = False
            print("text output on")
            continue
        if command == ":all":
            show_all = not show_all
            print(f"all candidates {'on' if show_all else 'off'}")
            continue
        if command == ":risky":
            options = EngineOptions(options.max_depth, options.beam_size, True, options.min_confidence)
            print("risky decoders on")
            continue
        if command == ":safe":
            options = EngineOptions(options.max_depth, options.beam_size, False, options.min_confidence)
            print("risky decoders off")
            continue
        if command.startswith(":depth "):
            try:
                depth = int(command.split(None, 1)[1])
            except ValueError:
                print("depth must be an integer")
                continue
            options = EngineOptions(max(0, depth), options.beam_size, options.include_risky, options.min_confidence)
            print(f"max depth {options.max_depth}")
            continue
        if command.startswith(":file "):
            path = command.split(None, 1)[1]
            try:
                raw = Path(path).read_bytes()
            except OSError as exc:
                print(f"read failed: {exc}")
                continue
        else:
            raw = line.encode()

        result = build_result(raw, options)
        if show_json:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            output_text(result, show_all=show_all, explain=explain, banner=False)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="encid",
        description="Recursive decoder and identifier for encodings, hashes, ciphertext, and CTF-style data.",
    )
    parser.add_argument("value", nargs="?", help="input string, or 'tui' / 'open tui'")
    parser.add_argument("extra", nargs="*", help=argparse.SUPPRESS)
    parser.add_argument("-f", "--file", help="read raw input from file")
    parser.add_argument("-d", "--max-depth", type=int, default=8, help="max recursive decoding layers")
    parser.add_argument("--beam-size", type=int, default=50, help="candidate search width")
    parser.add_argument("--min-confidence", type=float, default=0.20, help="drop decode attempts below this confidence")
    parser.add_argument("--risky", action="store_true", help="enable broad/brute-force decoders with higher false-positive risk")
    parser.add_argument("--json", action="store_true", help="JSON output")
    parser.add_argument("--all", action="store_true", help="show alternate decode chains")
    parser.add_argument("--explain", action="store_true", help="show reasons and evidence")
    parser.add_argument("-i", "--interactive", action="store_true", help="start the TUI console")
    parser.add_argument("--tui", action="store_true", help="force the TUI console")
    parser.add_argument("--no-tui", action="store_true", help="print once and exit instead of opening the TUI")
    parser.add_argument("--list-decoders", action="store_true", help="list available decoder families")
    parser.add_argument("--self-test", action="store_true", help="run quick smoke tests")
    parser.add_argument("--version", action="version", version=f"encid {__version__}")
    return parser


def build_decrypt_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="encid decrypt",
        description="Verify password hashes or decrypt supported ciphertext when the password/key is known.",
    )
    parser.add_argument("value", nargs="*", help="hash or ciphertext")
    parser.add_argument("--type", "-t", dest="type_name", help="bcrypt, sha256, xor, aes-256-cbc, openssl-aes-256-cbc, etc.")
    parser.add_argument("--password", "-p", help="password/key text. Prefer --ask-password to avoid shell history.")
    parser.add_argument("--ask-password", action="store_true", help="prompt for password without echo")
    parser.add_argument("--encoding", choices=["auto", "hex", "base64", "raw"], default="auto", help="ciphertext input encoding")
    parser.add_argument("--key-hex", help="raw cipher key as hex; bypasses password KDF")
    parser.add_argument("--iv-hex", help="IV/nonce as hex")
    parser.add_argument("--salt-hex", help="KDF salt as hex")
    parser.add_argument("--tag-hex", help="GCM/AEAD authentication tag as hex")
    parser.add_argument("--kdf", choices=["auto", "raw", "sha256", "pbkdf2-sha256"], default="auto", help="password-to-key derivation")
    parser.add_argument("--iterations", type=int, default=100_000, help="PBKDF2 iterations")
    parser.add_argument("--no-padding", action="store_true", help="do not remove PKCS7 padding for block modes")
    parser.add_argument("--json", action="store_true", help="JSON output")
    parser.add_argument("--list-types", action="store_true", help="list supported decrypt/verify types")
    return parser


def output_password_result(result: dict) -> None:
    print(f"operation: {result['operation']}")
    print(f"type: {result['type']}")
    print(f"status: {result['status']}")
    print(f"success: {'yes' if result['ok'] else 'no'}")
    print(f"confidence: {result['confidence']:.3f}")
    if result.get("evidence"):
        print("\nevidence:")
        for item in result["evidence"]:
            if item.startswith("preview="):
                continue
            print(f"  - {item}")
    if result.get("warnings"):
        print("\nwarnings:")
        for warning in result["warnings"]:
            print(f"  - {warning}")
    if result.get("output"):
        print("\nfinal:")
        print(result["output"])


def run_decrypt_cli(argv: list[str]) -> int:
    from encid.crypto import password_operation, supported_types

    parser = build_decrypt_parser()
    args = parser.parse_args(argv)

    if args.list_types:
        for item in supported_types():
            print(item)
        return 0

    value = " ".join(args.value).strip()
    if not value:
        parser.error("provide a hash or ciphertext")

    password = args.password
    if args.ask_password or password is None:
        password = getpass.getpass("password/key: ")

    result = password_operation(
        value,
        password,
        type_name=args.type_name,
        encoding=args.encoding,
        key_hex=args.key_hex,
        iv_hex=args.iv_hex,
        salt_hex=args.salt_hex,
        tag_hex=args.tag_hex,
        kdf=args.kdf,
        iterations=max(1, args.iterations),
        no_padding=args.no_padding,
    ).to_dict()
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        output_password_result(result)
    return 0 if result["ok"] else 1


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]
    if argv and argv[0] == "decrypt":
        return run_decrypt_cli(argv[1:])

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.list_decoders:
        for name in supported_decoders():
            print(name)
        return 0

    if args.self_test:
        return run_self_test(args)

    if _should_launch_tui(args):
        from encid.tui import TuiOptions, run_tui

        initial_value = None
        if args.file:
            initial_value = Path(args.file).read_bytes().decode("latin-1", errors="replace")
        elif not _is_tui_command(args):
            initial_value = _value_from_args(args)
        return run_tui(
            TuiOptions(
                engine=_options_from_args(args),
                show_all=args.all,
                explain=args.explain,
                json_output=False,
            ),
            initial_value=initial_value,
        )

    raw = _read_input(args)
    if not raw:
        parser.error("provide a value, --file, stdin data, or --interactive")

    result = build_result(raw, _options_from_args(args))
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        output_text(result, show_all=args.all, explain=args.explain)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
