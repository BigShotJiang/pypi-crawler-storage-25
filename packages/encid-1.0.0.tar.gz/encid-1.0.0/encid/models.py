from __future__ import annotations

from dataclasses import dataclass, field


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def confidence_label(value: float) -> str:
    value = clamp(value)
    if value >= 0.82:
        return "high"
    if value >= 0.55:
        return "medium"
    return "low"


@dataclass(frozen=True)
class Detection:
    type: str
    name: str
    confidence: float
    reason: str
    evidence: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "name": self.name,
            "confidence": round(clamp(self.confidence), 3),
            "confidence_label": confidence_label(self.confidence),
            "reason": self.reason,
            "evidence": list(self.evidence),
        }


@dataclass(frozen=True)
class DecodeAttempt:
    action: str
    data: bytes
    structural_confidence: float
    category: str = "encoding"
    risk: str = "safe"
    reason: str = ""
    evidence: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class Layer:
    index: int
    action: str
    input_preview: str
    output_preview: str
    output_score: float
    confidence: float
    confidence_label: str
    risk: str
    reason: str
    evidence: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "action": self.action,
            "input_preview": self.input_preview,
            "output_preview": self.output_preview,
            "output_score": round(self.output_score, 2),
            "confidence": round(clamp(self.confidence), 3),
            "confidence_label": self.confidence_label,
            "risk": self.risk,
            "reason": self.reason,
            "evidence": list(self.evidence),
        }


@dataclass(frozen=True)
class Candidate:
    data: bytes
    layers: tuple[Layer, ...]
    text_score: float
    chain_score: float
    confidence: float

    def to_dict(self, final_text: str, entropy: float, printable_ratio: float) -> dict:
        return {
            "score": round(self.chain_score, 2),
            "text_score": round(self.text_score, 2),
            "confidence": round(clamp(self.confidence), 3),
            "confidence_label": confidence_label(self.confidence),
            "layers": [layer.to_dict() for layer in self.layers],
            "final_text": final_text,
            "final_entropy": round(entropy, 3),
            "final_printable_ratio": round(printable_ratio, 3),
        }
