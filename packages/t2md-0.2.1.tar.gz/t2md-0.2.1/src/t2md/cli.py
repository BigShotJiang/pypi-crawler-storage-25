from __future__ import annotations

import os
import re
from pathlib import Path
from importlib.resources import files as pkg_files

import typer
from rich import print
from rich.console import Console

from .providers import PROVIDERS, count_tokens, get_provider

app = typer.Typer(no_args_is_help=True)
console = Console()

# Filename ordering helper: prefers patterns like 3.7.1, 3.7.2, etc.
NUM = re.compile(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?")

SUPPORTED_EXTS = {".txt", ".md", ".srt", ".vtt", ".pdf", ".docx"}

_LARGE_WARNING = 32_000


def sort_key(p: Path):
    """
    Prefer numeric ordering in filenames like 3.7.1, 3.7.2, etc.
    Fall back to modified time (older first) when no numeric pattern exists.
    """
    m = NUM.search(p.stem)
    if m:
        parts = tuple(int(x) if x else -1 for x in m.groups())
        return (0, parts, p.name.lower())
    return (1, p.stat().st_mtime, p.name.lower())


def list_transcripts(folder: Path) -> list[Path]:
    files = [p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS]
    files.sort(key=sort_key)
    return files


def read_text(p: Path) -> str:
    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return _read_pdf(p)
    if suffix == ".docx":
        return _read_docx(p)
    return p.read_text(encoding="utf-8", errors="ignore").strip()


def _read_pdf(p: Path) -> str:
    try:
        import pdfplumber
    except ImportError as e:
        raise RuntimeError(
            "pdfplumber is required to read PDF files. "
            "Install it with: pip install 't2md[pdf]'"
        ) from e
    pages = []
    with pdfplumber.open(p) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                pages.append(text)
    return "\n\n".join(pages).strip()


def _read_docx(p: Path) -> str:
    from docx import Document  # python-docx, already a dependency
    doc = Document(str(p))
    return "\n\n".join(para.text for para in doc.paragraphs if para.text.strip()).strip()


PRESETS: dict[str, str] = {
    "lecture": "prompts/lecture.md",
    "interview": "prompts/interview.md",
}


def load_default_prompt() -> str:
    prompt_path = pkg_files("t2md").joinpath("default_prompt.md")
    return prompt_path.read_text(encoding="utf-8").strip()


def load_preset(name: str) -> str:
    if name not in PRESETS:
        available = ", ".join(PRESETS)
        raise ValueError(f"Unknown preset '{name}'. Available: {available}")
    prompt_path = pkg_files("t2md").joinpath(PRESETS[name])
    return prompt_path.read_text(encoding="utf-8").strip()


def derive_module_name(folder: Path) -> str:
    return folder.name


def write_docx_from_markdown(md_text: str, docx_path: Path) -> None:
    """
    Simple Markdown -> DOCX:
      - # / ## / ### / #### become Word headings
      - "- " bullets -> List Bullet
      - "1. " numbered -> List Number
      - "> " blockquote -> Intense Quote
      - everything else -> normal paragraph

    Notes:
      - This is intentionally minimal (no tables, code fencing, inline bold parsing).
      - Produces a clean, readable DOCX that can be exported to PDF in Word/Google Docs.
    """
    from docx import Document  # type: ignore

    doc = Document()

    for raw_line in md_text.splitlines():
        line = raw_line.rstrip()

        # Preserve spacing
        if not line.strip():
            doc.add_paragraph("")
            continue

        # Headings
        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=1)
            continue
        if line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=2)
            continue
        if line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=3)
            continue
        if line.startswith("#### "):
            doc.add_heading(line[5:].strip(), level=4)
            continue

        # Bullets
        if line.lstrip().startswith("- "):
            doc.add_paragraph(line.lstrip()[2:].strip(), style="List Bullet")
            continue

        # Numbered lists
        m = re.match(r"^\s*\d+\.\s+(.*)$", line)
        if m:
            doc.add_paragraph(m.group(1).strip(), style="List Number")
            continue

        # Blockquotes
        if line.startswith("> "):
            doc.add_paragraph(line[2:].strip(), style="Intense Quote")
            continue

        # Default paragraph
        doc.add_paragraph(line)

    doc.save(str(docx_path))


def escape_latex(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    out = text
    for k, v in replacements.items():
        out = out.replace(k, v)
    return out


def apply_emphasis(text: str) -> str:
    """
    Convert inline **bold** and *italic* while escaping other text.
    This is intentionally minimal and non-nesting.
    """
    pattern = re.compile(r"\*\*(.+?)\*\*|\*(.+?)\*")
    out: list[str] = []
    last = 0
    for m in pattern.finditer(text):
        out.append(escape_latex(text[last : m.start()]))
        if m.group(1) is not None:
            out.append(r"\textbf{" + escape_latex(m.group(1)) + r"}")
        else:
            out.append(r"\textit{" + escape_latex(m.group(2)) + r"}")
        last = m.end()
    out.append(escape_latex(text[last:]))
    return "".join(out)


def convert_inline_md(text: str) -> str:
    """
    Convert minimal inline Markdown:
      - `code` -> \\texttt{...}
      - **bold** -> \\textbf{...}
      - *italic* -> \\textit{...}

    Unmatched backticks are treated as literal text.
    """
    parts = text.split("`")
    if len(parts) == 1:
        return apply_emphasis(text)

    if len(parts) % 2 == 0:
        parts[-2] = parts[-2] + "`" + parts[-1]
        parts = parts[:-1]

    out: list[str] = []
    for i, part in enumerate(parts):
        if i % 2 == 1:
            out.append(r"\texttt{" + escape_latex(part) + r"}")
        else:
            out.append(apply_emphasis(part))
    return "".join(out)


def write_latex_from_markdown(md_text: str, tex_path: Path, title: str) -> None:
    """
    Minimal Markdown -> LaTeX:
      - # / ## / ### / #### become sectioning commands
      - "- " bullets -> itemize
      - "1. " numbered -> enumerate
      - "> " blockquote -> quote
      - fenced code blocks -> verbatim
      - everything else -> paragraph text

    Notes:
      - Intentionally minimal; focuses on compile-ready LaTeX.
      - Inline Markdown formatting is not transformed.
    """
    lines = md_text.splitlines()
    out: list[str] = []

    out.append(r"\documentclass[11pt]{article}")
    out.append(r"\usepackage[utf8]{inputenc}")
    out.append(r"\usepackage[T1]{fontenc}")
    out.append(r"\usepackage{lmodern}")
    out.append(r"\usepackage{geometry}")
    out.append(r"\usepackage{hyperref}")
    out.append(r"\usepackage{enumitem}")
    out.append(r"\usepackage{parskip}")
    out.append(r"\geometry{margin=1in}")
    out.append(r"\setlist{noitemsep}")
    out.append(r"\title{" + escape_latex(title) + r"}")
    out.append(r"\date{}")
    out.append(r"\begin{document}")
    out.append(r"\maketitle")
    out.append(r"\tableofcontents")
    out.append("")

    in_code = False
    in_quote = False
    list_mode: str | None = None  # "itemize" or "enumerate"

    def close_list() -> None:
        nonlocal list_mode
        if list_mode:
            out.append(r"\end{" + list_mode + r"}")
            list_mode = None

    def close_quote() -> None:
        nonlocal in_quote
        if in_quote:
            out.append(r"\end{quote}")
            in_quote = False

    for raw_line in lines:
        line = raw_line.rstrip("\n")

        if line.strip().startswith("```"):
            close_list()
            close_quote()
            if not in_code:
                out.append(r"\begin{verbatim}")
                in_code = True
            else:
                out.append(r"\end{verbatim}")
                in_code = False
            continue

        if in_code:
            out.append(line)
            continue

        if not line.strip():
            close_list()
            close_quote()
            out.append("")
            continue

        if line.startswith("# "):
            close_list()
            close_quote()
            out.append(r"\section{" + convert_inline_md(line[2:].strip()) + r"}")
            continue
        if line.startswith("## "):
            close_list()
            close_quote()
            out.append(r"\subsection{" + convert_inline_md(line[3:].strip()) + r"}")
            continue
        if line.startswith("### "):
            close_list()
            close_quote()
            out.append(r"\subsubsection{" + convert_inline_md(line[4:].strip()) + r"}")
            continue
        if line.startswith("#### "):
            close_list()
            close_quote()
            out.append(r"\paragraph{" + convert_inline_md(line[5:].strip()) + r"}")
            continue

        if line.startswith("> "):
            close_list()
            if not in_quote:
                out.append(r"\begin{quote}")
                in_quote = True
            out.append(convert_inline_md(line[2:].strip()))
            continue
        if in_quote:
            close_quote()

        if line.lstrip().startswith("- "):
            item = line.lstrip()[2:].strip()
            if list_mode != "itemize":
                close_list()
                out.append(r"\begin{itemize}")
                list_mode = "itemize"
            out.append(r"\item " + convert_inline_md(item))
            continue

        m = re.match(r"^\s*\d+\.\s+(.*)$", line)
        if m:
            item = m.group(1).strip()
            if list_mode != "enumerate":
                close_list()
                out.append(r"\begin{enumerate}")
                list_mode = "enumerate"
            out.append(r"\item " + convert_inline_md(item))
            continue

        close_list()
        out.append(convert_inline_md(line))

    close_list()
    close_quote()
    if in_code:
        out.append(r"\end{verbatim}")

    out.append(r"\end{document}")
    tex_path.write_text("\n".join(out), encoding="utf-8")


@app.command("run")
def run(
    folder: Path = typer.Argument(..., help="Folder containing transcript files"),
    module: str | None = typer.Option(None, "--module", help="Module name (default: folder name)"),
    out: Path = typer.Option(Path("./outputs"), "--out", help="Output directory"),
    prompt: Path | None = typer.Option(None, "--prompt", help="Custom prompt file (overrides --preset)"),
    preset: str | None = typer.Option(None, "--preset", help="Built-in prompt preset: lecture, interview"),
    model: str | None = typer.Option(None, "--model", help="Model override (default: auto-selected by input size)"),
    provider: str = typer.Option("openai", "--provider", help="LLM provider: openai or anthropic"),
    format: str = typer.Option("md", "--format", help="Output format: md, docx, or tex"),
    max_output_tokens: int = typer.Option(
        16_000,
        "--max-output-tokens",
        min=1,
        help="Maximum tokens to generate. Raise if output looks cut off.",
    ),
):
    """
    Generate a combined output containing:
      1) Executive Summary
      2) Textbook-style Reading

    Output can be Markdown (.md), Word (.docx), or LaTeX (.tex).
    """
    try:
        llm = get_provider(provider)
    except ValueError as e:
        raise typer.BadParameter(str(e)) from e

    folder = folder.expanduser().resolve()
    out = out.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    if not folder.exists():
        raise typer.BadParameter(f"Folder not found: {folder}")

    module_name = module or derive_module_name(folder)

    # Prompt rules — --prompt beats --preset beats default
    if prompt:
        prompt_path = prompt.expanduser().resolve()
        if not prompt_path.exists():
            raise typer.BadParameter(f"Prompt file not found: {prompt_path}")
        try:
            prompt_rules = read_text(prompt_path)
        except Exception as e:
            raise typer.BadParameter(f"Failed to read prompt file '{prompt_path}': {e}") from e
    elif preset:
        try:
            prompt_rules = load_preset(preset)
        except ValueError as e:
            raise typer.BadParameter(str(e)) from e
    else:
        prompt_rules = load_default_prompt()

    # Gather transcripts
    files = list_transcripts(folder)
    if not files:
        raise typer.BadParameter("No transcript files found (.txt/.md/.srt/.vtt/.pdf/.docx).")

    combined = []
    for f in files:
        try:
            content = read_text(f)
        except Exception as e:
            raise typer.BadParameter(f"Failed to read '{f}': {e}") from e
        combined.append(f"\n\n---\n\n## SOURCE FILE: {f.name}\n\n{content}\n")
    transcripts = "".join(combined).strip()

    user_prompt = f"""
You will be given:
1) PROMPT_RULES (how to transform)
2) TRANSCRIPTS (raw content)

Return EXACTLY two top-level Markdown sections:

# {module_name} — Executive Summary
- thesis (2–4 sentences)
- 5–10 key concepts
- 2–5 examples/case studies
- what to remember (3–7 bullets)

# {module_name} — Reading
Follow PROMPT_RULES to create a readable textbook-style markdown:
- include a TOC
- clean headings
- preserve important examples
- remove transcript artifacts
- end with a synthesis summary

PROMPT_RULES:
{prompt_rules}

TRANSCRIPTS:
{transcripts}
""".strip()

    token_count = count_tokens(user_prompt)
    if model:
        chosen_model = model
        origin = "manual override"
    else:
        chosen_model = llm.select_model(token_count)
        origin = "auto-selected"

    print(
        f"[dim]Provider:[/dim] {llm.name}  "
        f"[dim]Model:[/dim] {chosen_model} "
        f"[dim]({origin}, {token_count:,} tokens)[/dim]"
    )
    if token_count >= _LARGE_WARNING:
        print(
            f"[yellow]Warning:[/yellow] {token_count:,} tokens is large — "
            "consider splitting your transcripts into smaller folders if output looks truncated."
        )

    with console.status("Generating output..."):
        try:
            output, truncated = llm.complete(user_prompt, chosen_model, max_output_tokens)
        except RuntimeError as e:
            print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=1) from e
        except Exception as e:
            check_hint = (
                f"Check your {llm.env_key} and network connection, then try again."
                if llm.env_key
                else "Check your provider configuration and network connection, then try again."
            )
            print(f"[red]API error:[/red] {e}\n{check_hint}")
            raise typer.Exit(code=1) from e

    if truncated:
        print(
            f"[yellow]Warning:[/yellow] output hit the {max_output_tokens:,}-token cap and was truncated. "
            "Rerun with a higher --max-output-tokens (e.g. 32000) to get the full response."
        )

    # Write output
    fmt = format.lower().strip()
    if fmt not in {"md", "docx", "tex"}:
        raise typer.BadParameter("--format must be 'md', 'docx', or 'tex'")

    if fmt == "md":
        out_file = out / f"{module_name}_All.md"
        out_file.write_text(output, encoding="utf-8")
    elif fmt == "docx":
        out_file = out / f"{module_name}_All.docx"
        write_docx_from_markdown(output, out_file)
    else:
        out_file = out / f"{module_name}_All.tex"
        write_latex_from_markdown(output, out_file, module_name)

    print("[cyan]Processed files (in order):[/cyan]")
    for f in files:
        print(f"  - {f.name}")
    print(f"\n[green]Wrote:[/green] {out_file}")


@app.command("doctor")
def doctor():
    """Quick sanity checks."""
    any_key = False
    for name, cls in PROVIDERS.items():
        env_key = cls.env_key
        if env_key is None:
            print(f"[green]OK:[/green] provider '{name}' needs no API key (local)")
            any_key = True
        elif os.getenv(env_key):
            print(f"[green]OK:[/green] {env_key} is set  (provider: {name})")
            any_key = True
        else:
            print(f"[yellow]--:[/yellow] {env_key} not set  (set this to use --provider {name})")

    if not any_key:
        print("[red]Error:[/red] At least one provider must be configured.")
        raise typer.Exit(code=1)

    print("[green]All good.[/green]")
