# Cellularization Dynamics

Desktop app for cellularization annotation and output generation. The repository is **GUI-first**: run the GUI via `**cdynamics`** or `**python -m cellularization_dynamics**`; batch/Snakemake workflows are not used.

## Install

### Quick install with conda (three steps)

Use a **dedicated** conda environment so dependencies stay isolated. The examples below name it `**cdynamics`**; you can pick any name.

**1. Create a new environment** (Python 3.10 or newer is required):

```bash
conda create -n cdynamics python=3.12 -y
```

**2. Activate it:**

```bash
conda activate cdynamics
```

**3. Install from PyPI:**

```bash
pip install cellularization-dynamics
```

That installs the `**cellularization_dynamics**` package and registers the `**cdynamics**` command on this environment’s `PATH`. Continue to **Start** below.

## Start

After a pip install, from any working directory (with the same environment active):

```bash
cdynamics
```

## How to use?

1. Add one or more `.tif` movies (drag-and-drop or **Open Files**).
2. Select a movie from the list.
3. Set acquisition parameters (`px2micron`, `movie_time_interval_sec`; optional `smoothing`, `degree`) — extracted from movie metadata when available (e.g. ImageJ-saved TIFFs).
4. **Analyze** — records the source movie path in `config.yaml` and writes `track/Kymograph.tif` next to the movie.
5. Adjust the cytoplasm threshold and island (apical) mode as needed; place at least two points on the cellularization front in the straightened view.
6. **Save** — writes mask, alignment metadata, and front annotation under the work folder.
7. **Generate Outputs** — straightens the kymograph, fits the spline, exports `output.csv` (main tabular result in the sample folder), and renders figure/video products (e.g. `Cellularization.png`, `Cellularization_front_markers.mp4`).

Outputs are written next to each input movie in a folder `CDynamics-<movie filename>` (see `app/services/output_layout.py`).