"""Cellularization desktop app package."""
