"""Human-friendly descriptions for CPython 3.12–3.14 bytecode instructions."""

from __future__ import annotations

__all__: list[str] = ["describe"]

# Mapping of BINARY_OP argrepr symbols to human-readable verb phrases.
_BINARY_OP_NAMES: dict[str, str] = {
    "+": "add (a + b)",
    "&": "bitwise and (a & b)",
    "//": "floor divide (a // b)",
    "<<": "left shift (a << b)",
    "@": "matrix multiply (a @ b)",
    "*": "multiply (a * b)",
    "%": "modulo (a % b)",
    "|": "bitwise or (a | b)",
    "**": "power (a ** b)",
    ">>": "right shift (a >> b)",
    "-": "subtract (a - b)",
    "/": "true divide (a / b)",
    "^": "bitwise xor (a ^ b)",
    "+=": "inplace add (a += b)",
    "&=": "inplace bitwise and (a &= b)",
    "//=": "inplace floor divide (a //= b)",
    "<<=": "inplace left shift (a <<= b)",
    "@=": "inplace matrix multiply (a @= b)",
    "*=": "inplace multiply (a *= b)",
    "%=": "inplace modulo (a %= b)",
    "|=": "inplace bitwise or (a |= b)",
    "**=": "inplace power (a **= b)",
    ">>=": "inplace right shift (a >>= b)",
    "-=": "inplace subtract (a -= b)",
    "/=": "inplace true divide (a /= b)",
    "^=": "inplace bitwise xor (a ^= b)",
    # BINARY_OP also handles subscr in 3.14:
    "[]": "subscript (a[b])",
    "[]=": "subscript store (a[b] = c)",
}

# Mapping of COMPARE_OP argrepr to readable names.
_COMPARE_OP_NAMES: dict[str, str] = {
    "<": "less than",
    "<=": "less than or equal to",
    "==": "equal to",
    "!=": "not equal to",
    ">": "greater than",
    ">=": "greater than or equal to",
}


def _q(argrepr: str) -> str:
    """Wrap *argrepr* in single quotes if non-empty."""
    return f"'{argrepr}'" if argrepr else ""


def _ordinal(n: object) -> str:
    """Return a short ordinal string for display, e.g. '2nd', '3rd'."""
    try:
        num = int(str(n))
    except (ValueError, TypeError):
        return str(n)
    if 11 <= num % 100 <= 13:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(num % 10, "th")
    return f"{num}{suffix}"


def _describe_core(opname: str, arg: object | None, argval: object, argrepr: str) -> str:  # noqa: C901, PLR0911, PLR0912
    """Return a plain-English description for *opname*."""

    # ------------------------------------------------------------------
    # Stack manipulation
    # ------------------------------------------------------------------
    if opname == "POP_TOP":
        return "Remove the top of stack"
    if opname == "PUSH_NULL":
        return "Push a NULL onto the stack"
    if opname == "COPY":
        return (
            f"Copy the {_ordinal(arg)} item to the top of the stack"
            if arg and int(str(arg)) > 0
            else "Copy an item on the stack"
        )
    if opname == "SWAP":
        return f"Swap the top of stack with the {_ordinal(arg)} item" if arg else "Swap two items on the stack"
    if opname == "CACHE":
        return "Internal interpreter cache entry"
    if opname == "NOP":
        return "No operation (does nothing)"
    if opname == "RESERVED":
        return "Reserved opcode (unused)"
    if opname == "EXTENDED_ARG":
        return "Extend the argument of the next instruction"
    if opname == "RESUME" or opname == "RESUME_CHECK":
        return "Internal: resume execution of a code object"
    if opname == "NOT_TAKEN":
        return "Internal: mark branch as not taken (for optimization)"
    if opname == "ENTER_EXECUTOR":
        return "Internal: enter the JIT executor"

    # ------------------------------------------------------------------
    # Load operations
    # ------------------------------------------------------------------
    if opname == "LOAD_CONST" or opname == "LOAD_CONST_IMMORTAL" or opname == "LOAD_CONST_MORTAL":
        return f"Load constant {argrepr} onto the stack" if argrepr else "Load a constant onto the stack"
    if opname == "LOAD_SMALL_INT":
        return f"Load small integer {arg} onto the stack" if arg is not None else "Load a small integer onto the stack"
    if opname == "LOAD_FAST" or opname == "LOAD_FAST_BORROW":
        return (
            f"Load local variable {_q(argrepr)} onto the stack" if argrepr else "Load a local variable onto the stack"
        )
    if opname == "LOAD_FAST_CHECK":
        return (
            f"Load local variable {_q(argrepr)} onto the stack (with check that it is bound)"
            if argrepr
            else "Load a local variable with bound check"
        )
    if opname == "LOAD_FAST_AND_CLEAR":
        return (
            f"Load local variable {_q(argrepr)} and clear the slot"
            if argrepr
            else "Load a local variable and clear its slot"
        )
    if opname == "LOAD_FAST_LOAD_FAST" or opname == "LOAD_FAST_BORROW_LOAD_FAST_BORROW":
        return (
            f"Load two local variables {_q(argrepr)} onto the stack"
            if argrepr
            else "Load two local variables onto the stack"
        )
    if opname == "LOAD_NAME":
        return f"Load name {_q(argrepr)} onto the stack" if argrepr else "Load a name onto the stack"
    if opname == "LOAD_GLOBAL":
        return f"Load global {_q(argrepr)} onto the stack" if argrepr else "Load a global variable onto the stack"
    if opname == "LOAD_GLOBAL_MODULE":
        return f"Load module global {_q(argrepr)} onto the stack" if argrepr else "Load a module global onto the stack"
    if opname == "LOAD_GLOBAL_BUILTIN":
        return f"Load builtin {_q(argrepr)} onto the stack" if argrepr else "Load a builtin onto the stack"
    if opname == "LOAD_ATTR":
        return (
            f"Load attribute {_q(argrepr)} from the top of stack"
            if argrepr
            else "Load an attribute from the top of stack"
        )
    if opname == "LOAD_METHOD":
        return f"Load method {_q(argrepr)} from the top of stack" if argrepr else "Load a method from the top of stack"
    if opname == "LOAD_SUPER_ATTR":
        return f"Load attribute {_q(argrepr)} via super()" if argrepr else "Load an attribute via super()"
    if opname == "LOAD_SUPER_METHOD":
        return f"Load method {_q(argrepr)} via super()" if argrepr else "Load a method via super()"
    if opname == "LOAD_ZERO_SUPER_ATTR":
        return (
            f"Load attribute {_q(argrepr)} via zero-arg super()"
            if argrepr
            else "Load an attribute via zero-arg super()"
        )
    if opname == "LOAD_ZERO_SUPER_METHOD":
        return f"Load method {_q(argrepr)} via zero-arg super()" if argrepr else "Load a method via zero-arg super()"
    if opname == "LOAD_DEREF":
        return f"Load variable {_q(argrepr)} from a closure cell" if argrepr else "Load a variable from a closure cell"
    if opname == "LOAD_CLOSURE":
        return f"Load closure cell for variable {_q(argrepr)}" if argrepr else "Load a closure cell onto the stack"
    if opname == "LOAD_FROM_DICT_OR_DEREF":
        return (
            f"Load {_q(argrepr)} from the mapping on the stack, or from a cell"
            if argrepr
            else "Load from mapping or cell"
        )
    if opname == "LOAD_FROM_DICT_OR_GLOBALS":
        return (
            f"Load {_q(argrepr)} from the mapping on the stack, or from globals"
            if argrepr
            else "Load from mapping or globals"
        )
    if opname == "LOAD_LOCALS":
        return "Push the locals dictionary onto the stack"
    if opname == "LOAD_BUILD_CLASS":
        return "Load the __build_class__ function for constructing a class"
    if opname == "LOAD_ASSERTION_ERROR":
        return "Load the AssertionError exception class"
    if opname == "LOAD_COMMON_CONSTANT":
        return f"Load a common constant ({argrepr})" if argrepr else "Load a common constant onto the stack"
    if opname == "LOAD_SPECIAL":
        return f"Load special method {_q(argrepr)} for with/context manager" if argrepr else "Load a special method"
    # Specialized LOAD_ATTR variants (3.14)
    if opname.startswith("LOAD_ATTR_"):
        variant = opname[len("LOAD_ATTR_") :].lower().replace("_", " ")
        return f"Load attribute {_q(argrepr)} ({variant})" if argrepr else f"Load attribute ({variant})"
    # Specialized LOAD_SUPER_ATTR variants
    if opname.startswith("LOAD_SUPER_ATTR_"):
        variant = opname[len("LOAD_SUPER_ATTR_") :].lower().replace("_", " ")
        return f"Load {variant} {_q(argrepr)} via super()" if argrepr else f"Load {variant} via super()"

    # ------------------------------------------------------------------
    # Store operations
    # ------------------------------------------------------------------
    if opname == "STORE_FAST":
        return (
            f"Store top of stack into local variable {_q(argrepr)}"
            if argrepr
            else "Store top of stack into a local variable"
        )
    if opname == "STORE_FAST_MAYBE_NULL":
        return (
            f"Store top of stack into local variable {_q(argrepr)} (slot may be null)"
            if argrepr
            else "Store top of stack into a local variable (slot may be null)"
        )
    if opname == "STORE_FAST_LOAD_FAST":
        return f"Store and load local variables {_q(argrepr)}" if argrepr else "Store and load local variables"
    if opname == "STORE_FAST_STORE_FAST":
        return (
            f"Store two values into local variables {_q(argrepr)}"
            if argrepr
            else "Store two values into local variables"
        )
    if opname == "STORE_NAME":
        return f"Store top of stack into name {_q(argrepr)}" if argrepr else "Store top of stack into a name"
    if opname == "STORE_GLOBAL":
        return f"Store top of stack into global {_q(argrepr)}" if argrepr else "Store top of stack into a global"
    if opname == "STORE_ATTR":
        return f"Store top of stack as attribute {_q(argrepr)}" if argrepr else "Store top of stack as an attribute"
    if opname == "STORE_DEREF":
        return (
            f"Store top of stack into closure cell {_q(argrepr)}"
            if argrepr
            else "Store top of stack into a closure cell"
        )
    if opname == "STORE_SUBSCR":
        return "Store a value into a subscript (a[b] = c)"
    if opname == "STORE_SLICE":
        return "Store a value into a slice (a[b:c] = d)"
    # Specialized STORE_ATTR variants (3.14)
    if opname.startswith("STORE_ATTR_"):
        variant = opname[len("STORE_ATTR_") :].lower().replace("_", " ")
        return f"Store attribute {_q(argrepr)} ({variant})" if argrepr else f"Store attribute ({variant})"
    # Specialized STORE_SUBSCR variants (3.14)
    if opname.startswith("STORE_SUBSCR_"):
        variant = opname[len("STORE_SUBSCR_") :].lower().replace("_", " ")
        return f"Store subscript ({variant})"

    # ------------------------------------------------------------------
    # Delete operations
    # ------------------------------------------------------------------
    if opname == "DELETE_FAST":
        return f"Delete local variable {_q(argrepr)}" if argrepr else "Delete a local variable"
    if opname == "DELETE_NAME":
        return f"Delete name {_q(argrepr)}" if argrepr else "Delete a name"
    if opname == "DELETE_GLOBAL":
        return f"Delete global {_q(argrepr)}" if argrepr else "Delete a global variable"
    if opname == "DELETE_ATTR":
        return (
            f"Delete attribute {_q(argrepr)} from the top of stack"
            if argrepr
            else "Delete an attribute from the top of stack"
        )
    if opname == "DELETE_DEREF":
        return (
            f"Delete variable {_q(argrepr)} from a closure cell" if argrepr else "Delete a variable from a closure cell"
        )
    if opname == "DELETE_SUBSCR":
        return "Delete a subscript item (del a[b])"

    # ------------------------------------------------------------------
    # Unary operations
    # ------------------------------------------------------------------
    if opname == "UNARY_NEGATIVE":
        return "Compute the negative of top of stack (-a)"
    if opname == "UNARY_NOT":
        return "Compute boolean not of top of stack (not a)"
    if opname == "UNARY_INVERT":
        return "Compute bitwise inversion of top of stack (~a)"
    if opname == "TO_BOOL":
        return "Convert top of stack to bool"
    # Specialized TO_BOOL variants (3.14)
    if opname.startswith("TO_BOOL_"):
        variant = opname[len("TO_BOOL_") :].lower().replace("_", " ")
        return f"Convert top of stack to bool ({variant} fast path)"

    # ------------------------------------------------------------------
    # Binary / comparison operations
    # ------------------------------------------------------------------
    if opname == "BINARY_OP":
        desc = _BINARY_OP_NAMES.get(argrepr, argrepr)
        return f"Perform binary {desc}" if desc else "Perform a binary operation"
    if opname == "BINARY_SUBSCR":
        return "Get an item by subscript (a[b])"
    if opname == "BINARY_SLICE":
        return "Get a slice (a[b:c])"
    # Specialized BINARY_OP variants (3.14)
    if opname.startswith("BINARY_OP_"):
        variant = opname[len("BINARY_OP_") :].lower().replace("_", " ")
        return f"Perform binary operation ({variant} fast path)"
    if opname == "COMPARE_OP":
        cmp_name = _COMPARE_OP_NAMES.get(argrepr, argrepr)
        return f"Compare two values: {cmp_name} ({argrepr})" if argrepr else "Compare two values"
    # Specialized COMPARE_OP variants (3.14)
    if opname.startswith("COMPARE_OP_"):
        variant = opname[len("COMPARE_OP_") :].lower().replace("_", " ")
        return f"Compare two values ({variant} fast path)"
    if opname == "IS_OP":
        negated = arg == 1
        op = "is not" if negated else "is"
        return f"Test identity: a {op} b"
    if opname == "CONTAINS_OP":
        negated = arg == 1
        op = "not in" if negated else "in"
        return f"Test membership: a {op} b"
    # Specialized CONTAINS_OP variants (3.14)
    if opname.startswith("CONTAINS_OP_"):
        variant = opname[len("CONTAINS_OP_") :].lower().replace("_", " ")
        negated = arg == 1
        op = "not in" if negated else "in"
        return f"Test membership: a {op} b ({variant} fast path)"

    # ------------------------------------------------------------------
    # Build operations
    # ------------------------------------------------------------------
    if opname == "BUILD_TUPLE":
        return f"Build a tuple from {arg} items on the stack" if arg is not None else "Build a tuple"
    if opname == "BUILD_LIST":
        return f"Build a list from {arg} items on the stack" if arg is not None else "Build a list"
    if opname == "BUILD_SET":
        return f"Build a set from {arg} items on the stack" if arg is not None else "Build a set"
    if opname == "BUILD_MAP":
        return f"Build a dict from {arg} key/value pairs on the stack" if arg is not None else "Build a dict"
    if opname == "BUILD_STRING":
        return f"Concatenate {arg} strings from the stack" if arg is not None else "Concatenate strings from the stack"
    if opname == "BUILD_SLICE":
        if arg == 2:
            return "Build a slice object (start:stop)"
        if arg == 3:
            return "Build a slice object (start:stop:step)"
        return "Build a slice object"
    if opname == "BUILD_CONST_KEY_MAP":
        return (
            f"Build a dict with constant keys from {arg} values on the stack"
            if arg is not None
            else "Build a dict with constant keys"
        )
    if opname == "BUILD_INTERPOLATION":
        return "Build a string interpolation object (for t-strings)"
    if opname == "BUILD_TEMPLATE":
        return "Build a template string object (for t-strings)"

    # ------------------------------------------------------------------
    # Collection mutation
    # ------------------------------------------------------------------
    if opname == "LIST_APPEND":
        return (
            f"Append top of stack to the list at position {arg}" if arg is not None else "Append top of stack to a list"
        )
    if opname == "LIST_EXTEND":
        return (
            f"Extend the list at position {arg} with top of stack"
            if arg is not None
            else "Extend a list with top of stack"
        )
    if opname == "SET_ADD":
        return f"Add top of stack to the set at position {arg}" if arg is not None else "Add top of stack to a set"
    if opname == "SET_UPDATE":
        return (
            f"Update the set at position {arg} with top of stack"
            if arg is not None
            else "Update a set with top of stack"
        )
    if opname == "MAP_ADD":
        return "Add a key/value pair to a dict (used in dict comprehensions)"
    if opname == "DICT_MERGE":
        return "Merge a mapping into the dict being built (for {**x} syntax)"
    if opname == "DICT_UPDATE":
        return "Update a dict with another mapping"

    # ------------------------------------------------------------------
    # Unpacking
    # ------------------------------------------------------------------
    if opname == "UNPACK_SEQUENCE":
        return f"Unpack the top of stack into {arg} values" if arg is not None else "Unpack a sequence"
    if opname == "UNPACK_EX":
        return "Unpack a sequence with a starred target (e.g. a, *b, c = iterable)"
    # Specialized UNPACK_SEQUENCE variants (3.14)
    if opname.startswith("UNPACK_SEQUENCE_"):
        variant = opname[len("UNPACK_SEQUENCE_") :].lower().replace("_", " ")
        return f"Unpack sequence ({variant} fast path)"

    # ------------------------------------------------------------------
    # Function / call
    # ------------------------------------------------------------------
    if opname == "CALL":
        return f"Call function with {arg} argument{'s' if arg != 1 else ''}" if arg is not None else "Call a function"
    if opname == "CALL_KW":
        return (
            f"Call function with {arg} arguments (with keyword args)"
            if arg is not None
            else "Call a function with keyword arguments"
        )
    if opname == "CALL_FUNCTION_EX":
        return "Call function with *args and/or **kwargs unpacking"
    if opname == "KW_NAMES":
        return (
            f"Set keyword argument names for the next call to {argrepr}"
            if argrepr
            else "Set keyword argument names for the next call"
        )
    if opname == "MAKE_FUNCTION":
        return "Create a function object from a code object on the stack"
    if opname == "SET_FUNCTION_ATTRIBUTE":
        return f"Set function attribute ({argrepr})" if argrepr else "Set a function attribute"
    if opname == "MAKE_CELL":
        return f"Create a cell for variable {_q(argrepr)}" if argrepr else "Create a closure cell object"
    if opname == "COPY_FREE_VARS":
        return (
            f"Copy {arg} free variables from the calling frame into this closure"
            if arg is not None
            else "Copy free variables into this closure"
        )
    if opname == "RETURN_VALUE":
        return "Return the top of stack to the caller"
    if opname == "RETURN_CONST":
        return f"Return constant {argrepr}" if argrepr else "Return a constant value"
    if opname == "RETURN_GENERATOR":
        return "Create and return a generator object"
    if opname == "EXIT_INIT_CHECK":
        return "Check that __init__ returned None"
    if opname == "CALL_INTRINSIC_1":
        return (
            f"Call an intrinsic function with 1 argument ({argrepr})"
            if argrepr
            else "Call an intrinsic function with 1 argument"
        )
    if opname == "CALL_INTRINSIC_2":
        return (
            f"Call an intrinsic function with 2 arguments ({argrepr})"
            if argrepr
            else "Call an intrinsic function with 2 arguments"
        )
    # Specialized CALL variants (3.14)
    if opname.startswith("CALL_KW_"):
        variant = opname[len("CALL_KW_") :].lower().replace("_", " ")
        return f"Call with keyword args ({variant} fast path)"
    if opname.startswith("CALL_"):
        variant = opname[len("CALL_") :].lower().replace("_", " ")
        return f"Call function ({variant} fast path)"

    # ------------------------------------------------------------------
    # Jumps
    # ------------------------------------------------------------------
    if opname == "JUMP_FORWARD":
        return f"Jump forward to {argrepr}" if argrepr else "Jump forward"
    if opname == "JUMP_BACKWARD" or opname == "JUMP_BACKWARD_JIT" or opname == "JUMP_BACKWARD_NO_JIT":
        return f"Jump backward to {argrepr}" if argrepr else "Jump backward"
    if opname == "JUMP_BACKWARD_NO_INTERRUPT":
        return (
            f"Jump backward to {argrepr} (no interrupt check)" if argrepr else "Jump backward without interrupt check"
        )
    if opname == "JUMP":
        return f"Jump to {argrepr}" if argrepr else "Jump unconditionally"
    if opname == "JUMP_NO_INTERRUPT":
        return f"Jump to {argrepr} (no interrupt check)" if argrepr else "Jump without interrupt check"
    if opname == "POP_JUMP_IF_TRUE" or opname == "JUMP_IF_TRUE":
        return f"Pop and jump to {argrepr} if true" if argrepr else "Pop and jump if true"
    if opname == "POP_JUMP_IF_FALSE" or opname == "JUMP_IF_FALSE":
        return f"Pop and jump to {argrepr} if false" if argrepr else "Pop and jump if false"
    if opname == "POP_JUMP_IF_NONE":
        return f"Pop and jump to {argrepr} if None" if argrepr else "Pop and jump if None"
    if opname == "POP_JUMP_IF_NOT_NONE":
        return f"Pop and jump to {argrepr} if not None" if argrepr else "Pop and jump if not None"

    # ------------------------------------------------------------------
    # Iteration
    # ------------------------------------------------------------------
    if opname == "GET_ITER":
        return "Get an iterator from the top of stack"
    if opname == "GET_YIELD_FROM_ITER":
        return "Get an iterator for 'yield from'"
    if opname == "FOR_ITER":
        return (
            f"Get next item from iterator, or jump to {argrepr} if exhausted"
            if argrepr
            else "Get next item from iterator or jump if exhausted"
        )
    # Specialized FOR_ITER variants (3.14)
    if opname.startswith("FOR_ITER_"):
        variant = opname[len("FOR_ITER_") :].lower().replace("_", " ")
        return f"Iterate ({variant} fast path)"
    if opname == "END_FOR":
        return "Clean up after a for loop (pop iterator and last value)"
    if opname == "POP_ITER":
        return "Pop the exhausted iterator from the stack"
    if opname == "GET_LEN":
        return "Push len(top of stack) onto the stack (keeping the original)"

    # ------------------------------------------------------------------
    # Async / coroutine
    # ------------------------------------------------------------------
    if opname == "GET_AWAITABLE":
        return "Get an awaitable object from the top of stack"
    if opname == "GET_AITER":
        return "Get an async iterator from the top of stack"
    if opname == "GET_ANEXT":
        return "Get the next value from an async iterator"
    if opname == "END_ASYNC_FOR":
        return "Clean up after an async for loop"
    if opname == "SEND":
        return (
            f"Send a value into a sub-generator, jump to {argrepr} on completion"
            if argrepr
            else "Send a value into a sub-generator"
        )
    if opname == "SEND_GEN":
        return "Send a value into a generator (specialized fast path)"
    if opname == "END_SEND":
        return "Clean up after sending a value into a generator"
    if opname == "YIELD_VALUE":
        return "Yield top of stack to the caller"

    # ------------------------------------------------------------------
    # Exception handling
    # ------------------------------------------------------------------
    if opname == "RAISE_VARARGS":
        if arg == 0:
            return "Re-raise the current exception"
        if arg == 1:
            return "Raise the exception on top of stack"
        if arg == 2:
            return "Raise the exception on top of stack with a cause (raise X from Y)"
        return "Raise an exception"
    if opname == "PUSH_EXC_INFO":
        return "Push exception info onto the stack"
    if opname == "POP_EXCEPT":
        return "Pop the exception handler from the block stack"
    if opname == "POP_BLOCK":
        return "Pop a block from the block stack"
    if opname == "CHECK_EXC_MATCH":
        return "Check if the exception matches the handler type"
    if opname == "CHECK_EG_MATCH":
        return "Check if the exception group matches the handler type"
    if opname == "RERAISE":
        return "Re-raise the active exception"
    if opname == "CLEANUP_THROW":
        return "Clean up after generator.throw()"
    if opname == "SETUP_FINALLY":
        return f"Set up a finally handler at {argrepr}" if argrepr else "Set up a finally handler"
    if opname == "SETUP_CLEANUP":
        return f"Set up a cleanup handler at {argrepr}" if argrepr else "Set up a cleanup handler"
    if opname == "SETUP_WITH":
        return f"Set up a with-block handler at {argrepr}" if argrepr else "Set up a with-block handler"

    # ------------------------------------------------------------------
    # With statement
    # ------------------------------------------------------------------
    if opname == "BEFORE_WITH":
        return "Prepare for a with block (call __enter__)"
    if opname == "BEFORE_ASYNC_WITH":
        return "Prepare for an async with block (call __aenter__)"
    if opname == "WITH_EXCEPT_START":
        return "Call __exit__ at the start of exception handling in a with block"

    # ------------------------------------------------------------------
    # Import
    # ------------------------------------------------------------------
    if opname == "IMPORT_NAME":
        return f"Import module {_q(argrepr)}" if argrepr else "Import a module"
    if opname == "IMPORT_FROM":
        return (
            f"Import name {_q(argrepr)} from the current module" if argrepr else "Import a name from the current module"
        )

    # ------------------------------------------------------------------
    # Match / pattern matching
    # ------------------------------------------------------------------
    if opname == "MATCH_MAPPING":
        return "Check if the subject is a mapping (dict-like) for pattern matching"
    if opname == "MATCH_SEQUENCE":
        return "Check if the subject is a sequence for pattern matching"
    if opname == "MATCH_KEYS":
        return "Check if the subject contains the required mapping keys"
    if opname == "MATCH_CLASS":
        return (
            f"Match a class pattern with {arg} positional attribute{'s' if arg != 1 else ''}"
            if arg is not None
            else "Match a class pattern"
        )

    # ------------------------------------------------------------------
    # Format
    # ------------------------------------------------------------------
    if opname == "FORMAT_VALUE":
        # argval is (converter, has_format_spec) when available
        if isinstance(argval, tuple) and len(argval) == 2:
            converter, has_fmt = argval
            parts: list[str] = ["Format a value for an f-string"]
            if converter is not None:
                conv_name = converter.__name__ if hasattr(converter, "__name__") else str(converter)
                parts.append(f"with {conv_name} conversion")
            if has_fmt:
                parts.append("with format spec")
            return ", ".join(parts)
        return f"Format a value for an f-string ({argrepr})" if argrepr else "Format a value for an f-string"
    if opname == "FORMAT_SIMPLE":
        return "Format a value using its default __format__"
    if opname == "FORMAT_WITH_SPEC":
        return "Format a value using a format specification"
    if opname == "CONVERT_VALUE":
        return f"Convert a value ({argrepr})" if argrepr else "Convert a value for formatting"

    # ------------------------------------------------------------------
    # Annotations
    # ------------------------------------------------------------------
    if opname == "SETUP_ANNOTATIONS":
        return "Set up the __annotations__ dict for the current scope"
    if opname == "ANNOTATIONS_PLACEHOLDER":
        return "Placeholder for annotation processing"

    # ------------------------------------------------------------------
    # Interpreter
    # ------------------------------------------------------------------
    if opname == "INTERPRETER_EXIT":
        return "Exit the interpreter loop"

    return ""


# Mapping of INSTRUMENTED_* opcodes to their base operations.
_INSTRUMENTED_MAP: dict[str, str] = {
    "INSTRUMENTED_CALL": "CALL",
    "INSTRUMENTED_CALL_FUNCTION_EX": "CALL_FUNCTION_EX",
    "INSTRUMENTED_CALL_KW": "CALL_KW",
    "INSTRUMENTED_END_FOR": "END_FOR",
    "INSTRUMENTED_END_ASYNC_FOR": "END_ASYNC_FOR",
    "INSTRUMENTED_END_SEND": "END_SEND",
    "INSTRUMENTED_FOR_ITER": "FOR_ITER",
    "INSTRUMENTED_INSTRUCTION": "",
    "INSTRUMENTED_JUMP_BACKWARD": "JUMP_BACKWARD",
    "INSTRUMENTED_JUMP_FORWARD": "JUMP_FORWARD",
    "INSTRUMENTED_LINE": "",
    "INSTRUMENTED_LOAD_SUPER_ATTR": "LOAD_SUPER_ATTR",
    "INSTRUMENTED_NOT_TAKEN": "NOT_TAKEN",
    "INSTRUMENTED_POP_ITER": "POP_ITER",
    "INSTRUMENTED_POP_JUMP_IF_FALSE": "POP_JUMP_IF_FALSE",
    "INSTRUMENTED_POP_JUMP_IF_NONE": "POP_JUMP_IF_NONE",
    "INSTRUMENTED_POP_JUMP_IF_NOT_NONE": "POP_JUMP_IF_NOT_NONE",
    "INSTRUMENTED_POP_JUMP_IF_TRUE": "POP_JUMP_IF_TRUE",
    "INSTRUMENTED_RESUME": "RESUME",
    "INSTRUMENTED_RETURN_CONST": "RETURN_CONST",
    "INSTRUMENTED_RETURN_VALUE": "RETURN_VALUE",
    "INSTRUMENTED_YIELD_VALUE": "YIELD_VALUE",
}


def _describe_instrumented(opname: str, arg: object | None, argval: object, argrepr: str) -> str:
    """Describe an INSTRUMENTED_* opcode by delegating to the base instruction."""
    base = _INSTRUMENTED_MAP.get(opname, "")
    if base:
        base_desc = _describe_core(base, arg, argval, argrepr)
        if base_desc:
            return f"Instrumented: {base_desc[0].lower()}{base_desc[1:]}"
    # Fallback for instrumented opcodes with no direct mapping.
    if opname == "INSTRUMENTED_INSTRUCTION":
        return "Instrumented: generic instruction event hook"
    if opname == "INSTRUMENTED_LINE":
        return "Instrumented: line-level tracing event hook"
    return f"Instrumented: {opname.removeprefix('INSTRUMENTED_').lower().replace('_', ' ')} operation"


def describe(opname: str, arg: object | None, argval: object, argrepr: str) -> str:
    """Return a short, human-friendly description of a CPython bytecode instruction.

    Parameters
    ----------
    opname:
        The canonical name of the opcode (e.g. ``'LOAD_FAST'``).
    arg:
        The raw numeric argument from the bytecode, or ``None`` for
        instructions that take no argument.
    argval:
        The resolved value of *arg* as provided by :mod:`dis`.
    argrepr:
        The human-readable representation of *argval* as provided by
        :mod:`dis`.

    Returns
    -------
    str
        A plain-English description of what the instruction does.
    """
    if opname.startswith("INSTRUMENTED_"):
        return _describe_instrumented(opname, arg, argval, argrepr)

    result = _describe_core(opname, arg, argval, argrepr)
    if result:
        return result

    return "Unknown operation"
