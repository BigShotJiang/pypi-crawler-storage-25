"""Allow ``python -m friendly_dis`` to work like ``python -m dis``."""

from friendly_dis import main

main()
