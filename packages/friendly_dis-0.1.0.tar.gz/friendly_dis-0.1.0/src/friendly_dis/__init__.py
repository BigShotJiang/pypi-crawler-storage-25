"""Friendly disassembler — a drop-in replacement for :mod:`dis` with human-readable descriptions."""

from __future__ import annotations

import dis as _dis
import io
import sys
import types
from typing import Any, TextIO

from friendly_dis._descriptions import describe

__all__: list[str] = ["dis", "disassemble", "describe"]

_have_code = (
    types.MethodType,
    types.FunctionType,
    types.CodeType,
    classmethod,
    staticmethod,
    type,
)


def _friendly_line(instruction: _dis.Instruction) -> str:
    """Return the human-friendly description column for *instruction*."""
    return describe(
        instruction.opname,
        instruction.arg,
        instruction.argval,
        instruction.argrepr,
    )


# Sensible limits for the alignment column.
_MIN_COMMENT_COL = 40
_MAX_COMMENT_COL = 80
_COMMENT_GAP = 5  # minimum spaces before the "#"


def _compute_comment_column(line_lengths: list[int]) -> int:
    """Pick a column to align ``# description`` comments.

    Uses the 75th-percentile of instruction-line lengths so that most
    lines align neatly while a few very long ones don't push every
    comment far to the right.  The result is clamped to
    ``[_MIN_COMMENT_COL, _MAX_COMMENT_COL]``.
    """
    if not line_lengths:
        return _MIN_COMMENT_COL
    sorted_lengths = sorted(line_lengths)
    # 75th-percentile index (round up for small lists)
    idx = min((len(sorted_lengths) * 3 + 3) // 4, len(sorted_lengths) - 1)
    p75 = sorted_lengths[idx]
    col = p75 + _COMMENT_GAP
    return max(_MIN_COMMENT_COL, min(col, _MAX_COMMENT_COL))


def _is_instruction_line(
    line: str,
    all_opnames: set[str],
) -> bool:
    """Return True if *line* looks like a disassembly instruction line."""
    stripped = line.lstrip()
    if not stripped:
        return False
    # Skip non-instruction lines
    if (
        stripped.startswith("ExceptionTable:")
        or stripped.startswith("Disassembly of")
        or stripped.startswith("Sorry:")
        or (stripped[0].isdigit() and "to" in stripped and "->" in stripped)
    ):
        return False
    tokens = stripped.split()
    return any(token in all_opnames for token in tokens)


def _annotate_dis_output(
    dis_text: str,
    instructions: list[_dis.Instruction],
) -> str:
    """Append friendly descriptions to each instruction line in *dis_text*.

    We match instruction lines by finding the opcode name in each line and
    correlating with the instruction list in order.  Comments are aligned
    to a common column computed from the median line length.
    """
    lines = dis_text.split("\n")
    all_opnames = set(_dis.opname) | {"CACHE"}

    # First pass: identify instruction lines and collect their lengths so
    # we can choose a good alignment column.
    is_instr: list[bool] = []
    instr_line_lengths: list[int] = []
    for line in lines:
        hit = _is_instruction_line(line, all_opnames)
        is_instr.append(hit)
        if hit:
            instr_line_lengths.append(len(line.rstrip()))

    comment_col = _compute_comment_column(instr_line_lengths)

    # Second pass: annotate instruction lines.
    result_lines: list[str] = []
    instr_idx = 0

    for line, hit in zip(lines, is_instr):
        if not hit:
            result_lines.append(line)
            continue

        if instr_idx < len(instructions):
            instr = instructions[instr_idx]
            desc = _friendly_line(instr)
            instr_idx += 1
            if desc:
                rstripped = line.rstrip()
                padding = max(_COMMENT_GAP, comment_col - len(rstripped))
                result_lines.append(f"{rstripped}{' ' * padding}# {desc}")
            else:  # pragma: no cover — describe() always returns non-empty
                result_lines.append(line)
        else:
            result_lines.append(line)

    return "\n".join(result_lines)


def _get_instructions_list(
    co: types.CodeType,
    *,
    show_caches: bool = False,
    adaptive: bool = False,
) -> list[_dis.Instruction]:
    """Get a list of instructions from a code object."""
    return list(_dis.get_instructions(co, show_caches=show_caches, adaptive=adaptive))


def _disassemble_code_friendly(
    co: types.CodeType,
    lasti: int = -1,
    *,
    file: TextIO | None = None,
    show_caches: bool = False,
    adaptive: bool = False,
) -> None:
    """Disassemble a single code object with friendly annotations."""
    file = file or sys.stdout

    # Capture stdlib output
    buf = io.StringIO()
    _dis.disassemble(co, lasti, file=buf, show_caches=show_caches, adaptive=adaptive)
    stdlib_output = buf.getvalue()

    # Get instructions for annotation
    instructions = _get_instructions_list(co, show_caches=show_caches, adaptive=adaptive)

    annotated = _annotate_dis_output(stdlib_output, instructions)
    # The stdlib output already ends with \n, so use end="" to avoid double newline
    print(annotated, file=file, end="")


def _disassemble_recursive(
    co: types.CodeType,
    *,
    file: TextIO | None = None,
    depth: int | None = None,
    show_caches: bool = False,
    adaptive: bool = False,
) -> None:
    """Recursively disassemble *co* and any nested code objects."""
    _disassemble_code_friendly(co, file=file, show_caches=show_caches, adaptive=adaptive)
    if depth is None or depth > 0:
        next_depth = None if depth is None else depth - 1
        for const in co.co_consts:
            if hasattr(const, "co_code"):
                print(file=file)
                print(f"Disassembly of {const!r}:", file=file)
                _disassemble_recursive(
                    const,
                    file=file,
                    depth=next_depth,
                    show_caches=show_caches,
                    adaptive=adaptive,
                )


def dis(
    x: Any = None,
    *,
    file: TextIO | None = None,
    depth: int | None = None,
    show_caches: bool = False,
    adaptive: bool = False,
) -> None:
    """Disassemble classes, methods, functions, and other compiled objects.

    Works exactly like :func:`dis.dis` but appends a human-friendly
    description to every instruction line.
    """
    if x is None:
        distb(file=file, show_caches=show_caches, adaptive=adaptive)
        return

    # Extract functions from methods.
    if hasattr(x, "__func__"):
        x = x.__func__
    # Extract compiled code objects
    if hasattr(x, "__code__"):
        x = x.__code__
    elif hasattr(x, "gi_code"):
        x = x.gi_code
    elif hasattr(x, "ag_code"):
        x = x.ag_code
    elif hasattr(x, "cr_code"):
        x = x.cr_code

    if hasattr(x, "__dict__"):  # Class or module
        items = sorted(x.__dict__.items())
        for name, x1 in items:
            if isinstance(x1, _have_code):
                print(f"Disassembly of {name}:", file=file)
                try:
                    dis(
                        x1,
                        file=file,
                        depth=depth,
                        show_caches=show_caches,
                        adaptive=adaptive,
                    )
                except TypeError as msg:
                    print(f"Sorry: {msg}", file=file)
                print(file=file)
    elif hasattr(x, "co_code"):
        _disassemble_recursive(x, file=file, depth=depth, show_caches=show_caches, adaptive=adaptive)
    elif isinstance(x, (bytes, bytearray)):
        # Raw bytecode: just pass through to stdlib dis() since we can't
        # get structured instructions from raw bytes.
        _dis.dis(x, file=file, show_caches=show_caches)  # type: ignore[call-overload]
    elif isinstance(x, str):
        _disassemble_str(x, file=file, depth=depth, show_caches=show_caches, adaptive=adaptive)
    else:
        raise TypeError(f"don't know how to disassemble {type(x).__name__} objects")


def disassemble(
    co: types.CodeType,
    lasti: int = -1,
    *,
    file: TextIO | None = None,
    show_caches: bool = False,
    adaptive: bool = False,
) -> None:
    """Disassemble a code object.

    Drop-in replacement for :func:`dis.disassemble` with friendly descriptions.
    """
    _disassemble_code_friendly(co, lasti, file=file, show_caches=show_caches, adaptive=adaptive)


def distb(
    tb: types.TracebackType | None = None,
    *,
    file: TextIO | None = None,
    show_caches: bool = False,
    adaptive: bool = False,
) -> None:
    """Disassemble a traceback (default: last traceback)."""
    if tb is None:
        try:
            if hasattr(sys, "last_exc"):
                tb = sys.last_exc.__traceback__  # type: ignore[union-attr]
            else:
                tb = sys.last_traceback  # type: ignore[attr-defined]
        except AttributeError:
            raise RuntimeError("no last traceback to disassemble") from None
        while tb.tb_next:  # type: ignore[union-attr]
            tb = tb.tb_next  # type: ignore[union-attr]
    assert tb is not None
    disassemble(
        tb.tb_frame.f_code,  # type: ignore[union-attr]
        tb.tb_lasti,  # type: ignore[union-attr]
        file=file,
        show_caches=show_caches,
        adaptive=adaptive,
    )


def _disassemble_str(
    source: str,
    **kwargs: Any,
) -> None:
    """Compile the source string, then disassemble the code object."""
    _disassemble_recursive(_try_compile(source, "<dis>"), **kwargs)


def _try_compile(source: str, name: str) -> types.CodeType:
    """Attempt to compile *source* as an expression, falling back to a statement."""
    try:
        return compile(source, name, "eval")
    except SyntaxError:
        pass
    return compile(source, name, "exec")


disco = disassemble  # Backwards compatibility alias


def main() -> None:
    """CLI entry point, mimicking ``python -m dis``."""
    import argparse

    parser = argparse.ArgumentParser(prog="friendly-dis")
    parser.add_argument("infile", type=argparse.FileType("rb"), nargs="?", default="-")
    args = parser.parse_args()
    with args.infile as infile:
        source = infile.read()
    code = compile(source, args.infile.name, "exec")
    dis(code)
