#!/usr/bin/env python3
"""
supero-server v1.0.0

Supero Platform — Reusable UI Server (CORS proxy + auth enrichment)

Replaces the ~240-line server.py that every generated app duplicates.
The LLM no longer generates server.py — it's a one-liner:

    from supero_server import serve
    serve(port=5648)

Or with customization:

    from supero_server import SuperoServer
    server = SuperoServer(port=5648, public_schemas=['unit', 'course'])
    server.serve()

Install: pip install supero-server
    Or:  copy this file to your project as supero_server.py

Features:
  - CORS proxy for /api/* and /ai/* to Supero backend
  - Login enrichment (merges access-policy into login response)
  - Signup handler (/api/signup) with policy fetch
  - Public schema proxy (/api/public/*) using API key auth
  - Service account init (API key from env or login)
  - Static file serving (index.html, app.js, config.js)
  - Graceful error handling with structured responses

Env vars read:
  SUPERO_URL          — Backend API (default: https://api.supero.dev)
  SUPERO_DOMAIN       — Domain name
  SUPERO_PROJECT      — Project name
  SUPERO_ADMIN_EMAIL  — Admin email (for service account login)
  SUPERO_PASSWORD     — Admin password
  SUPERO_API_KEY      — API key (if set, skips login)
  SUPERO_DEFAULT_TENANT — Default tenant (default: default-tenant)
  PUBLIC_SCHEMAS      — Comma-separated public schema names
  UI_PORT             — Server port
"""

# [PATCH:server_schema_naming_v1] use schema_naming.normalize_schema_name
# Applied: 2026-04-21T19:16:49.758117

from datetime import datetime, timezone
import os
import sys
import json
import time
import http.server
import socketserver
import urllib.request
import urllib.error
import ssl
import re

# ─── service_lib integration (auto-installed) ─────────────────────
# Try three import paths in order:
#   1. supero.service_lib (installed as pip package — production path)
#   2. .service_lib       (same package, relative import)
#   3. service_lib        (sibling file — dev/test path)
try:
    from supero.service_lib import default as _sl_default
except ImportError:
    try:
        from .service_lib import default as _sl_default
    except ImportError:
        try:
            from service_lib import default as _sl_default
        except ImportError:
            _sl_default = None
import re as _re_sl
import threading as _threading_sl
import base64 as _base64_sl
# ──────────────────────────────────────────────────────────────────

__version__ = '1.1.2'

# ─────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────

API_URL = os.getenv('SUPERO_URL', 'https://api.supero.dev').rstrip('/')
BROWSER_UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# SSL verification — disable for dev (self-signed certs), enable for production
if os.getenv('SUPERO_VERIFY_SSL', '').lower() not in ('true', '1', 'yes'):
    ssl._create_default_https_context = ssl._create_unverified_context

# Module-level state
_SERVICE_API_KEY = ''
_PUBLIC_SCHEMAS = []

# ─── BFF v1.1.0: schemas describe cache + SDK-delegated endpoints ─────────
#
# New endpoints added in server.py v1.1.0:
#   GET  /api/schemas/describe
#   GET  /api/scope/<parent_schema>/<parent_uuid>/<record_schema>
#   PUT  /api/link
#
# Rationale: the UI previously constructed raw /api/v1/crud/... URLs and
# managed two-step create-then-link flows itself. That put platform URL
# structure in the UI and duplicated auth plumbing. These BFF endpoints
# expose semantic operations instead, delegating to the SDK's
# PlatformClient for HTTP + auth.
#
# Auth split:
#   - describe: uses service API key (schema metadata is public within
#     the domain; cached in memory with ETag for 5 min)
#   - scope/link: uses the caller's JWT (RBAC enforced by platform)
# ──────────────────────────────────────────────────────────────────────────

_SCHEMAS_DESCRIBE_CACHE = None   # {schemas, enums, parent_hierarchy} dict
_SCHEMAS_DESCRIBE_ETAG = None    # short sha256 hex of sorted JSON body
# v1.1.2: TTL for describe cache. Without this, schema uploads in
# another session don't appear until the per-app server restarts.
_SCHEMAS_DESCRIBE_TIMESTAMP = 0.0
_SCHEMAS_DESCRIBE_TTL = 300      # 5 minutes

try:
    from supero.platform_client import PlatformClient as _BFF_PlatformClient
except ImportError:
    try:
        from .platform_client import PlatformClient as _BFF_PlatformClient
    except ImportError:
        try:
            from platform_client import PlatformClient as _BFF_PlatformClient
        except ImportError as _bff_import_err:
            # v1.1.1: log the import failure. Previously silent → misleading
            # 401/503 responses on every BFF call with no clue why.
            print(
                f'  ⚠ BFF: PlatformClient unavailable ({_bff_import_err}); '
                f'/api/schemas/describe, /api/scope/*, and /api/link will '
                f'return errors until the SDK is installed and importable. '
                f'Checked: supero.platform_client, .platform_client, platform_client',
                file=sys.stderr,
            )
            _BFF_PlatformClient = None


def _bff_snake(name):
    """PascalCase → snake_case via the canonical schema_naming normalizer.

    This used to be a homemade implementation that disagreed with
    schema_naming.normalize_schema_name() on acronym cases (HTTPServer,
    iOSApp, OAuth2Provider). It now delegates so there is one source of
    truth across the platform.

    Falls back to the old naive implementation if schema_naming can't be
    imported (dev environments without the SDK installed).
    """
    if not name:
        return name
    try:
        # Try the canonical normalizer first
        try:
            from supero.schema_naming import normalize_schema_name
        except ImportError:
            try:
                from .schema_naming import normalize_schema_name
            except ImportError:
                from schema_naming import normalize_schema_name
        return normalize_schema_name(name)
    except ImportError:
        # schema_naming unavailable — use the old naive fallback so the
        # /api/schemas/describe endpoint doesn't 500 in environments where
        # the SDK isn't installed yet.
        import re as _re_fallback
        return _re_fallback.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()


def _normalize_crud_type(path):
    """Rewrite the {type} segment of a CRUD URL to canonical snake_case.

    Input path examples (unchanged namespace prefix, normalized type):
        /api/v1/crud/mani1112/FormDefinition   -> /api/v1/crud/mani1112/form_definition
        /api/v1/crud/mani1112/formdefinition   -> /api/v1/crud/mani1112/formdefinition
                                                  (already-mangled names stay mangled —
                                                   this fix catches PascalCase, not lowercase-no-underscore)
        /api/v1/crud/mani1112/wf:WorkflowDefinition -> /api/v1/crud/mani1112/wf:workflow_definition
        /api/v1/crud/mani1112/form_definition/<uuid> -> unchanged
        /api/v1/auth/login                      -> unchanged (not a CRUD path)

    Returns the possibly-rewritten path. Non-CRUD paths pass through.
    """
    if not path:
        return path
    # Split off query string, normalize the path part, re-attach query.
    query = ""
    if "?" in path:
        path, query = path.split("?", 1)
        query = "?" + query

    parts = path.split("/")
    # Expected shape: ['', 'api', 'v1', 'crud', '{domain}', '{type}', ...]
    if len(parts) < 6 or parts[1] != "api" or parts[2] != "v1" or parts[3] != "crud":
        return path + query

    type_segment = parts[5]
    if not type_segment:
        return path + query

    try:
        normalized = _bff_snake(type_segment)
    except Exception:
        return path + query  # never break the proxy on a normalizer error

    if normalized and normalized != type_segment:
        parts[5] = normalized
        return "/".join(parts) + query

    return path + query


def _bff_get_user_client(handler):
    """Build a per-request PlatformClient using the caller's JWT.

    Used by endpoints that need RBAC-correct results (scoped lists,
    reference linking). Returns None if JWT missing or SDK unavailable,
    in which case callers should return 401.
    """
    if _BFF_PlatformClient is None:
        return None
    auth = handler.headers.get('Authorization', '')
    if not auth.startswith('Bearer '):
        return None
    jwt = auth[7:]
    if not jwt:
        return None
    try:
        return _BFF_PlatformClient(
            base_url=API_URL,
            jwt_token=jwt,
            timeout=30,
        )
    except Exception as e:
        print(f'  ⚠ BFF: user PlatformClient init failed: {e}',
              file=sys.stderr)
        return None


def _bff_get_service_client():
    """Return a PlatformClient authed with the service API key.

    Used by describe endpoint. Lazy-constructed but not cached across
    requests (PlatformClient is cheap to build; caller decides lifetime).
    """
    if _BFF_PlatformClient is None or not _SERVICE_API_KEY:
        return None
    try:
        return _BFF_PlatformClient(
            base_url=API_URL,
            api_key=_SERVICE_API_KEY,
            timeout=30,
        )
    except Exception as e:
        print(f'  ⚠ BFF: service PlatformClient init failed: {e}',
              file=sys.stderr)
        return None


def _bff_shape_describe_for_ui(schemas_list):
    """Transform a list of platform schema defs into the UI describe payload.

    Output shape:
      {
        "schemas": {"<snake>": {name, display_name, schema_type,
                                parent_type, attributes, references}},
        "enums":   {"<PascalCase>": {name, type, values}},
        "parent_hierarchy": {"<snake>": ["<parent_snake>"]}
      }

    References are normalized to the shape the UI's SchemaRegistry expects:
      {ref_name, target_schema, target_display, cardinality,
       back_ref_name, mandatory}

    target_schema is derived from an explicit `target` key on the ref, or
    from the ref_name itself if absent (common shorthand case). This
    matches the contract in 3.schema.design.md.
    """
    schemas_out = {}
    enums_out = {}
    parent_hierarchy = {}

    for s in schemas_list or []:
        if not isinstance(s, dict):
            continue
        name = s.get('name')
        if not name or not isinstance(name, str):
            continue
        schema_type = s.get('schema_type')

        if schema_type == 'enum':
            enums_out[name] = {
                'name': name,
                'type': s.get('type', 'string'),
                'values': list(s.get('values', [])),
            }
            continue

        if schema_type != 'object':
            continue  # skip unknown schema_types (operational, type, etc.)

        snake = _bff_snake(name)
        parent_type = s.get('parent_type') or 'tenant'

        refs_out = []
        for ref in s.get('references', []) or []:
            if not isinstance(ref, dict):
                continue
            ref_name = ref.get('name')
            if not ref_name:
                continue
            # v1.1.1: explicit-form refs put target schema name in 'type'
            # (shorthand refs use 'name' for both identity and target).
            target = ref.get('type') or ref.get('target') or ref_name
            refs_out.append({
                'ref_name': ref_name,
                'target_schema': _bff_snake(target),
                'target_display': ref.get('display_name') or target,
                'cardinality': ref.get('cardinality', 'one'),
                'back_ref_name': ref.get('back_ref_name'),
                'mandatory': bool(ref.get('mandatory', False)),
            })

        schemas_out[snake] = {
            'name': name,
            'display_name': s.get('display_name', name),
            'schema_type': 'object',
            'parent_type': parent_type,
            'attributes': list(s.get('attributes', [])),
            'references': refs_out,
        }
        parent_hierarchy[snake] = [_bff_snake(parent_type)]

    return {
        'schemas': schemas_out,
        'enums': enums_out,
        'parent_hierarchy': parent_hierarchy,
    }


def _bff_build_describe_payload():
    """Fetch schemas via service account + shape into UI describe payload.

    Returns (payload, etag) tuple. On any failure, returns (None, None)
    and the endpoint surfaces 503.

    Platform call sequence:
      1. GET /domains/{domain}/schemas   → list of schema dicts
      2. For any skinny entries (missing 'attributes' / 'references'),
         hydrate via GET /schemas/{uuid}.
      3. Shape via _bff_shape_describe_for_ui.
      4. Compute ETag as sha256-prefix of canonical JSON.
    """
    import hashlib

    domain = _strip_env('SUPERO_DOMAIN')
    if not domain:
        return (None, None)

    client = _bff_get_service_client()
    if client is None:
        return (None, None)

    try:
        # v1.1.1: corrected URL — platform route is /api/v1/domains/<domain>/schemas
        result = client.get(f'/api/v1/domains/{domain}/schemas')
    except Exception as e:
        print(f'  ⚠ BFF describe: list_schemas failed: {e}',
              file=sys.stderr)
        return (None, None)

    # Platform may wrap in {"schemas": [...]} or return a flat list
    if isinstance(result, dict):
        schemas_list = result.get('schemas') or result.get('data') or []
    elif isinstance(result, list):
        schemas_list = result
    else:
        schemas_list = []

    if not isinstance(schemas_list, list):
        schemas_list = []

    # Hydrate any skinny entries (platform may return uuid/name only)
    hydrated = []
    for s in schemas_list:
        if not isinstance(s, dict):
            continue
        # Full definitions will have at least one of these keys
        has_body = ('attributes' in s or 'references' in s
                    or 'values' in s or 'schema_type' in s)
        if has_body:
            hydrated.append(s)
        elif s.get('uuid'):
            try:
                # v1.1.1: corrected URL — platform route is /api/v1/schemas/<uuid>
                full = client.get(f"/api/v1/schemas/{s['uuid']}")
                if isinstance(full, dict):
                    hydrated.append(full)
                else:
                    hydrated.append(s)
            except Exception:
                hydrated.append(s)  # best effort — use the skinny record
        else:
            hydrated.append(s)

    payload = _bff_shape_describe_for_ui(hydrated)

    try:
        body_bytes = json.dumps(payload, sort_keys=True).encode()
        etag = hashlib.sha256(body_bytes).hexdigest()[:16]
    except Exception:
        etag = str(int(time.time()))

    return (payload, etag)
# ─── end BFF helpers ──────────────────────────────────────────────────────



# ─────────────────────────────────────────────────────────
# Service Account
# ─────────────────────────────────────────────────────────

def init_service_account():
    """Initialize service account — gets API key from env or login."""
    global _SERVICE_API_KEY

    # Try env first
    _SERVICE_API_KEY = os.getenv('SUPERO_API_KEY', '')
    if _SERVICE_API_KEY:
        print(f'  ✅ API key from env: ...{_SERVICE_API_KEY[-4:]}')
        return True

    # Login to get API key
    domain = _strip_env('SUPERO_DOMAIN')
    email = os.getenv('SUPERO_ADMIN_EMAIL')
    password = os.getenv('SUPERO_PASSWORD')
    project = _strip_env('SUPERO_PROJECT', 'default-project')

    if not all([domain, email, password]):
        print('  ⚠️  No credentials — service account disabled')
        return False

    # ⚠️ Use domain_name (not domain) — platform field name
    payload = json.dumps({
        'domain_name': domain,
        'email': email,
        'password': password,
        'project': project,
    }).encode()

    req = urllib.request.Request(f'{API_URL}/api/v1/auth/login', data=payload, method='POST')
    req.add_header('Content-Type', 'application/json')
    req.add_header('User-Agent', BROWSER_UA)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            _SERVICE_API_KEY = result['auth']['api_key']
            print(f'  ✅ API key obtained: ...{_SERVICE_API_KEY[-4:]}')
            return True
    except Exception as e:
        print(f'  ❌ Service login failed: {e}')

    # Fallback — try without project (some platform versions)
    try:
        fallback = json.dumps({
            'domain_name': domain,
            'email': email,
            'password': password,
        }).encode()
        req2 = urllib.request.Request(f'{API_URL}/api/v1/auth/login', data=fallback, method='POST')
        req2.add_header('Content-Type', 'application/json')
        req2.add_header('User-Agent', BROWSER_UA)
        with urllib.request.urlopen(req2, timeout=30) as resp2:
            result2 = json.loads(resp2.read().decode())
            _SERVICE_API_KEY = result2['auth']['api_key']
            print(f'  ✅ API key obtained (fallback): ...{_SERVICE_API_KEY[-4:]}')
            return True
    except Exception as e2:
        print(f'  ❌ Service login fallback also failed: {e2}')
        return False


# ─────────────────────────────────────────────────────────
# Policy Fetch — used by login + signup enrichment
# ─────────────────────────────────────────────────────────

def _fetch_policy(token, domain=None, tenant=None):
    """Fetch access policy for the authenticated user. Returns None on failure."""
    domain = domain or os.getenv('SUPERO_DOMAIN', '')
    tenant = tenant or os.getenv('SUPERO_DEFAULT_TENANT', 'default-tenant')
    try:
        req = urllib.request.Request(
            f'{API_URL}/api/v1/crud/{domain}/access-policy/me', method='GET')
        req.add_header('Authorization', f'Bearer {token}')
        req.add_header('X-Domain', domain)
        req.add_header('X-Tenant', tenant)
        req.add_header('User-Agent', BROWSER_UA)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode()).get('policy')
    except Exception:
        return None  # Non-fatal — new user gets null policy, falls back to role check


# ─────────────────────────────────────────────────────────
# Request Handler
# ─────────────────────────────────────────────────────────


# ── Helpers for tenant signup flow (added in 1.5.47) ──

_PROJECT_UUID_CACHE = {}  # {(domain, project_name): uuid}
_RATE_LIMIT_BUCKET = {}   # {ip: [(timestamp, count), ...]}



def _strip_env(name, default=''):
    """Read env var and strip surrounding quotes (EnvManager double-quotes values)."""
    v = os.getenv(name, default) or default
    return v.strip().strip('"').strip("'")

def _resolve_project_uuid(domain, project_name):
    """Resolve project name to UUID. Cached in-process."""
    cache_key = (domain, project_name)
    if cache_key in _PROJECT_UUID_CACHE:
        return _PROJECT_UUID_CACHE[cache_key]
    if not _SERVICE_API_KEY:
        return None
    try:
        url = f"{API_URL}/api/v1/crud/{domain}/project?name={project_name}"
        req = urllib.request.Request(url, headers={
            'X-API-Key': _SERVICE_API_KEY,
            'Content-Type': 'application/json',
            'User-Agent': BROWSER_UA,
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        for proj in (data.get('results') or data.get('data') or []):
            if proj.get('name') == project_name:
                uuid = proj.get('uuid')
                if uuid:
                    _PROJECT_UUID_CACHE[cache_key] = uuid
                    return uuid
    except Exception:
        pass
    return None


def _check_rate_limit(client_ip, max_per_minute=3):
    """Simple in-memory rate limiter. Returns True if request allowed."""
    now = time.time()
    bucket = _RATE_LIMIT_BUCKET.setdefault(client_ip, [])
    # Drop entries older than 60s
    bucket[:] = [ts for ts in bucket if now - ts < 60]
    if len(bucket) >= max_per_minute:
        return False
    bucket.append(now)
    return True




# ─────────────────────────────────────────────────────────
# Namespace qualifier — disambiguates colliding type names
# (e.g. app's 'campaign' vs email service's 'campaign')
# ─────────────────────────────────────────────────────────

_PUBLIC_SYSTEM_TYPES = {
    "project", "tenant", "user_account", "api_key", "domain",
    "access_policy", "access_rule", "schema",
}


def _qualify_public_schema(schema_name):
    """Qualify a bare schema name with the app namespace (SUPERO_DOMAIN
    by convention, normalized like the platform's schema_naming).

    Returns (qualified_form, bare_form) so callers can check whitelists
    against either. Already-qualified names and system types pass through.
    """
    if not schema_name:
        return (schema_name, schema_name)
    if ":" in schema_name:
        bare = schema_name.split(":", 1)[1]
        return (schema_name, bare)
    if schema_name.lower() in _PUBLIC_SYSTEM_TYPES:
        return (schema_name, schema_name)
    ns = (
        os.getenv("SUPERO_APP_NAMESPACE")
        or _strip_env("SUPERO_DOMAIN")
        or ""
    ).lower().replace("-", "_")
    if not ns:
        return (schema_name, schema_name)
    return (f"{ns}:{schema_name}", schema_name)




# ─── service_lib helpers (auto-installed) ─────────────────────────
_SL_CRUD_URL_RE = _re_sl.compile(
    r"^/api/v1/crud/([^/?]+)/([^/?]+)(?:/([^/?]+))?(?:\?.*)?$"
)

# CRUD writes for these system types never fire @create/@update/@delete
# events — prevents double-firing (signup → @signup AND @create:user_account)
# and prevents workflow→workflow_instance write loops.
_SL_SKIP_SYSTEM_TYPES = frozenset({
    "user_account", "tenant", "project", "api_key", "domain",
    "access_policy", "access_rule", "schema",
    "workflow_instance", "workflow_definition", "workflow_step_log",
    "plugin_registry",
})


def _sl_parse_crud_url(path):
    """Parse /api/v1/crud/{domain}/{type}[/{uuid}] → dict or None."""
    if not path:
        return None
    m = _SL_CRUD_URL_RE.match(path)
    if not m:
        return None
    domain, type_, uuid = m.groups()
    # Strip namespace prefix for event name (ma559:order → order)
    bare_type = type_.split(":", 1)[1] if ":" in type_ else type_
    return {"domain": domain, "type": type_,
            "bare_type": bare_type, "uuid": uuid}


def _sl_extract_user_from_jwt(auth_header):
    """Read JWT claims WITHOUT signature verification.

    Auth has already happened upstream; this is for event payload
    enrichment only. Returns {} on any parse error.
    """
    if not auth_header or not auth_header.startswith("Bearer "):
        return {}
    token = auth_header[7:]
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return {}
        # base64 url-decode the payload (middle segment)
        payload_b64 = parts[1]
        padding = "=" * ((4 - len(payload_b64) % 4) % 4)
        claims = json.loads(_base64_sl.urlsafe_b64decode(payload_b64 + padding))
        return {
            "email": claims.get("email"),
            "uuid": claims.get("user_uuid") or claims.get("sub"),
            "tenant": claims.get("tenant_name") or claims.get("tenant"),
            "role": claims.get("role"),
        }
    except Exception:
        return {}


def _sl_fire_event_safe(event, payload):
    """Fire an event via service_lib in a background thread.

    Never raises — catches all exceptions. Uses a daemon thread so
    server shutdown doesn't wait for it. If service_lib isn't
    importable, silently no-ops.
    """
    if _sl_default is None:
        return
    try:
        sl = _sl_default()
    except Exception:
        return

    def _run():
        try:
            sl.trigger(event, payload)
        except Exception as e:
            try:
                print(f"  ⚠ [server.py] trigger({event}) failed: {e}",
                      file=sys.stderr)
            except Exception:
                pass

    try:
        t = _threading_sl.Thread(target=_run, daemon=True)
        t.start()
    except Exception:
        pass


def _sl_fire_crud_event_safe(handler, method, response_body, request_body):
    """Fire @create/@update/@delete after a successful CRUD write.

    Called from the patched _proxy_request. Parses URL, checks skip
    list, builds payload, hands off to _sl_fire_event_safe.
    """
    try:
        parsed = _sl_parse_crud_url(handler.path)
        if not parsed:
            return  # not a CRUD path
        if parsed["bare_type"] in _SL_SKIP_SYSTEM_TYPES:
            return  # system type — skip

        op_map = {"POST": "create", "PUT": "update", "DELETE": "delete"}
        operation = op_map.get(method)
        if not operation:
            return

        # Build payload
        payload = {
            "event": f"@{operation}:{parsed['bare_type']}",
            "operation": operation,
            "type": parsed["bare_type"],
            "qualified_type": parsed["type"],
            "domain": parsed["domain"],
            "uuid": parsed["uuid"],
            "timestamp": datetime.now(timezone.utc).isoformat() if "datetime" in globals() else "",
        }

        # v4: Use ServiceLib.crud.get() to fetch full records via the
        # shared SDK PlatformClient. Platform CREATE responses only
        # contain system fields (uuid/name/fq_name), so to resolve
        # input_map mappings like {"email": "email"} we need to fetch
        # the full record. For UPDATE, we also fetch (current state) and
        # overlay the request body on top (read-after-write safety).
        #
        # All steps fail-safe: GET failure falls back to request body,
        # and trigger firing is already fire-and-forget.
        _SERVER_PY_V4 = True  # Marker for idempotency
        _RESERVED_PAYLOAD_KEYS = {
            "event", "operation", "type", "qualified_type",
            "domain", "uuid", "timestamp", "record", "user",
        }
        record_flat = {}
        sl = None
        try:
            if _sl_default is not None:
                sl = _sl_default()
        except Exception:
            sl = None

        if operation == "create":
            # Extract assigned_uuid from platform's response envelope
            assigned_uuid = None
            try:
                if response_body:
                    decoded = (response_body.decode()
                               if isinstance(response_body, bytes)
                               else response_body)
                    envelope = json.loads(decoded)
                    if isinstance(envelope, dict):
                        payload["record"] = envelope
                        assigned_uuid = envelope.get("uuid")
                        if not assigned_uuid and isinstance(envelope.get("data"), dict):
                            for _inner in envelope["data"].values():
                                if isinstance(_inner, dict) and _inner.get("uuid"):
                                    assigned_uuid = _inner["uuid"]
                                    break
            except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
                pass

            if assigned_uuid:
                if not payload["uuid"]:
                    payload["uuid"] = assigned_uuid

                # Fallback: seed from request body
                if request_body:
                    try:
                        req_decoded = (request_body.decode()
                                       if isinstance(request_body, bytes)
                                       else request_body)
                        req_parsed = json.loads(req_decoded)
                        if isinstance(req_parsed, dict):
                            record_flat.update(req_parsed)
                    except (json.JSONDecodeError, UnicodeDecodeError,
                            AttributeError):
                        pass

                # Primary: fetch full record via SDK
                if sl is not None:
                    full = sl.crud.get(parsed["type"], assigned_uuid)
                    if isinstance(full, dict):
                        record_flat.update(full)
                        payload["record"] = full
                record_flat["uuid"] = assigned_uuid

        elif operation == "update" and parsed["uuid"]:
            # Seed from request body (the update delta)
            if request_body:
                try:
                    req_decoded = (request_body.decode()
                                   if isinstance(request_body, bytes)
                                   else request_body)
                    req_parsed = json.loads(req_decoded)
                    if isinstance(req_parsed, dict):
                        record_flat.update(req_parsed)
                        payload["record"] = req_parsed
                except (json.JSONDecodeError, UnicodeDecodeError,
                        AttributeError):
                    pass

            # Fetch current full record, overlay request body (read-after-write)
            if sl is not None:
                full = sl.crud.get(parsed["type"], parsed["uuid"])
                if isinstance(full, dict):
                    merged = dict(full)
                    merged.update(record_flat)
                    record_flat = merged

        # DELETE: no body parsing — payload uuid from URL is enough.

        # Flatten record_flat → payload top-level
        for _k, _v in record_flat.items():
            if _k not in _RESERVED_PAYLOAD_KEYS:
                payload[_k] = _v

        # User context from JWT (unsigned read)
        try:
            auth = handler.headers.get("Authorization", "")
            user = _sl_extract_user_from_jwt(auth)
            if user:
                payload["user"] = user
        except Exception:
            pass

        event_name = payload["event"]
        _sl_fire_event_safe(event_name, payload)
    except Exception as e:
        try:
            print(f"  ⚠ [server.py] _sl_fire_crud_event_safe: {e}",
                  file=sys.stderr)
        except Exception:
            pass
# ──────────────────────────────────────────────────────────────────

class SuperoRequestHandler(http.server.SimpleHTTPRequestHandler):
    """CORS-enabled handler with proxy, login enrichment, signup."""

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept, X-Domain, X-Tenant')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith('/api/check-tenant-slug'):
            return self._handle_check_tenant_slug()
        if self.path.startswith('/api/tenant-info'):
            return self._handle_tenant_info()
        # ─── BFF v1.1.0 routes (added before /api/ proxy catch-all) ───
        if self.path == '/api/schemas/describe' or self.path.startswith('/api/schemas/describe?'):
            return self._handle_schemas_describe()
        if self.path.startswith('/api/scope/'):
            return self._handle_scoped_list()
        # BFF v1.7.0 — Stripe return-handler verify (read-only)
        if self.path == '/api/checkout/verify' or self.path.startswith('/api/checkout/verify?'):
            return self._handle_checkout_verify()
        # ─── end BFF routes ─────────────────────────────────────────
        if self.path == '/health':
            self._send_json(200, {'status': 'ok', 'version': __version__})
        elif self.path.startswith('/api/public/'):
            self._handle_public_read()
        elif self.path.startswith('/api/') or self.path.startswith('/ai/'):
            self._proxy_request('GET')
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == '/api/signup':
            self._handle_signup()
        elif self.path == '/api/signup-tenant':
            self._handle_tenant_signup()
        elif self.path == '/api/v1/auth/login':
            self._handle_login()
        # BFF v1.7.0 — Stripe return-handler finalize (idempotent)
        elif self.path == '/api/checkout/finalize':
            return self._handle_checkout_finalize()
        elif self.path.startswith('/api/') or self.path.startswith('/ai/'):
            self._proxy_request('POST')
        else:
            self._send_json(404, {'error': 'Not found'})

    def do_PUT(self):
        # ─── BFF v1.1.0 route ──────────────────────────────────────
        if self.path == '/api/link':
            return self._handle_link_reference()
        # ─── end BFF route ─────────────────────────────────────────
        if self.path.startswith('/api/'):
            self._proxy_request('PUT')
        else:
            self._send_json(404, {'error': 'Not found'})

    def do_DELETE(self):
        if self.path.startswith('/api/'):
            self._proxy_request('DELETE')
        else:
            self._send_json(404, {'error': 'Not found'})

    # ── Proxy ──

    def _proxy_request(self, method):
        """Proxy request to Supero backend, forwarding all headers."""
        # [PATCH:server_schema_naming_v1] normalize CRUD type segment
        _normalized_path = _normalize_crud_type(self.path)
        url = f'{API_URL}{_normalized_path}'
        cl = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(cl) if cl > 0 else None

        req = urllib.request.Request(url, data=body, method=method)
        # Forward relevant headers
        for h in ['Authorization', 'Content-Type', 'Accept', 'X-Domain', 'X-Tenant', 'X-API-Key']:
            val = self.headers.get(h)
            if val:
                req.add_header(h, val)
        req.add_header('User-Agent', BROWSER_UA)

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                content_type = resp.headers.get('Content-Type', 'application/json')

                # SSE: stream chunks as they arrive (don't buffer)
                if 'text/event-stream' in content_type:
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/event-stream')
                    self.send_header('Cache-Control', 'no-cache')
                    self.send_header('X-Accel-Buffering', 'no')
                    self.end_headers()
                    while True:
                        chunk = resp.read(1024)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        self.wfile.flush()
                    return

                data = resp.read()
                self.send_response(resp.status)
                self.send_header('Content-Type', content_type)
                self.end_headers()
                self.wfile.write(data)

                # ── service_lib CRUD event fire (post-success) ──
                if (method in ('POST', 'PUT', 'DELETE')
                        and resp.status in (200, 201)):
                    _sl_fire_crud_event_safe(self, method, data, body)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._send_json(502, {'error': f'Proxy error: {str(e)}'})

    # ── Login Enrichment ──


    def _handle_tenant_signup(self):
        """Self-serve tenant signup: creates tenant + admin user + auto-login.
        
        Uses project_uuid (resolved from project name) to satisfy backend contract.
        After successful create, internally logs in the new admin and returns
        the full auth payload so the browser has a session immediately.
        """
        # Rate limit by client IP
        client_ip = self.client_address[0] if self.client_address else 'unknown'
        if not _check_rate_limit(client_ip, max_per_minute=3):
            return self._send_json(429, {'error': 'Too many signup attempts. Try again in a minute.'})
        
        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})
        
        display_name = body.get('display_name', '').strip()
        admin_email = body.get('admin_email', '').strip().lower()
        admin_password = body.get('admin_password', '')
        admin_full_name = body.get('admin_full_name', admin_email.split('@')[0] if admin_email else '')
        
        # Validation
        if not display_name or len(display_name) < 2:
            return self._send_json(400, {'error': 'Display name required (min 2 chars)'})
        if not admin_email or '@' not in admin_email:
            return self._send_json(400, {'error': 'Valid admin email required'})
        if not admin_password or len(admin_password) < 8:
            return self._send_json(400, {'error': 'Password required (8+ characters)'})
        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Signup unavailable — no service account'})
        
        # Auto-generate slug from display name
        import re
        slug = re.sub(r'[^a-z0-9-]', '', display_name.lower().replace(' ', '-'))[:50].strip('-')
        if not slug or len(slug) < 2:
            return self._send_json(400, {'error': 'Display name must contain letters/numbers'})
        
        domain = _strip_env('SUPERO_DOMAIN')
        project_name = _strip_env('SUPERO_PROJECT', 'default-project')
        
        # Resolve project UUID (Gap 4)
        project_uuid = _resolve_project_uuid(domain, project_name)
        if not project_uuid:
            return self._send_json(503, {'error': f'Could not resolve project "{project_name}" in domain "{domain}"'})
        
        # Build payload matching admin panel format (project_uuid, not project)
        payload = {
            'name': slug,
            'display_name': display_name,
            'tenant_type': 'primary',
            'project_uuid': project_uuid,
            'parent_context': {
                'domain': domain,
                'project': project_name,
            },
            'create_admin_user': True,
            'admin_user': {
                'email': admin_email,
                'full_name': admin_full_name,
                'password': admin_password,
                'send_activation_email': False,
            },
        }
        
        headers = {
            'X-API-Key': _SERVICE_API_KEY,
            'Content-Type': 'application/json',
            'User-Agent': BROWSER_UA,
            'X-Domain': domain,
        }
        url = f'{API_URL}/api/v1/tenants'
        try:
            req = urllib.request.Request(url,
                data=json.dumps(payload).encode(), method='POST', headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                tenant_result = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            try:
                err_body = json.loads(e.read())
                msg = err_body.get('error') or err_body.get('message') or 'Tenant creation failed'
            except Exception:
                msg = f'Tenant creation failed (HTTP {e.code})'
            if e.code == 409:
                return self._send_json(409, {'error': f'Tenant "{slug}" already exists. Try a different name.'})
            return self._send_json(e.code, {'error': msg})
        except Exception as e:
            return self._send_json(502, {'error': f'Backend unreachable: {str(e)}'})
        
        # Gap 3: Auto-login the new admin
        login_payload = {
            'domain_name': domain,
            'email': admin_email,
            'password': admin_password,
            'project': project_name,
        }
        login_token = None
        login_policy = None
        try:
            login_req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
                data=json.dumps(login_payload).encode(), method='POST',
                headers={'Content-Type': 'application/json', 'User-Agent': BROWSER_UA})
            with urllib.request.urlopen(login_req, timeout=15) as login_resp:
                login_result = json.loads(login_resp.read())
                login_token = login_result.get('auth', {}).get('access_token')
                # Fetch policy for this new tenant
                if login_token:
                    login_policy = _fetch_policy(login_token, domain, slug)
                tenant_result['auth'] = login_result.get('auth')
                tenant_result['context'] = login_result.get('context')
                tenant_result['policy'] = login_policy
        except Exception as e:
            # Tenant created but auto-login failed — user can still log in manually
            tenant_result['auto_login_failed'] = str(e)
        
        # Build redirect URL with tenant slug
        # ── service_lib @tenant_signup trigger ──
        _sl_fire_event_safe("@tenant_signup", {
            "event": "@tenant_signup", "operation": "tenant_signup",
            "tenant": {"slug": slug, "display_name": display_name,
                       "uuid": tenant_result.get("uuid") or
                               tenant_result.get("tenant_uuid", "")},
            "admin": {"email": admin_email, "full_name": admin_full_name},
            "domain": domain,
            "timestamp": datetime.now(timezone.utc).isoformat()
                if "datetime" in globals() else "",
        })
        tenant_result['success'] = True
        tenant_result['redirect_url'] = f'/?tenant={slug}'
        return self._send_json(200, tenant_result)

    def _handle_check_tenant_slug(self):
        """GET /api/check-tenant-slug?slug=foo — check if tenant slug is available."""
        from urllib.parse import urlparse, parse_qs
        qs = parse_qs(urlparse(self.path).query)
        slug = (qs.get('slug', [''])[0] or '').strip().lower()
        
        if not slug or len(slug) < 2:
            return self._send_json(400, {'error': 'Slug required (min 2 chars)'})
        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Service unavailable'})
        
        domain = _strip_env('SUPERO_DOMAIN')
        try:
            url = f"{API_URL}/api/v1/crud/{domain}/tenant?name={slug}"
            req = urllib.request.Request(url, headers={
                'X-API-Key': _SERVICE_API_KEY,
                'Content-Type': 'application/json',
                'User-Agent': BROWSER_UA,
            })
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            results = data.get('results') or data.get('data') or []
            taken = any(t.get('name') == slug for t in results)
            return self._send_json(200, {'slug': slug, 'available': not taken})
        except Exception as e:
            return self._send_json(502, {'error': f'Check failed: {e}'})

    def _handle_tenant_info(self):
        """GET /api/tenant-info?slug=foo — public tenant info for join flow (Gap 2/Flow B)."""
        from urllib.parse import urlparse, parse_qs
        qs = parse_qs(urlparse(self.path).query)
        slug = (qs.get('slug', [''])[0] or '').strip().lower()
        
        if not slug:
            return self._send_json(400, {'error': 'Slug required'})
        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Service unavailable'})
        
        domain = _strip_env('SUPERO_DOMAIN')
        try:
            url = f"{API_URL}/api/v1/crud/{domain}/tenant?name={slug}"
            req = urllib.request.Request(url, headers={
                'X-API-Key': _SERVICE_API_KEY,
                'Content-Type': 'application/json',
                'User-Agent': BROWSER_UA,
            })
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            results = data.get('results') or data.get('data') or []
            tenant = next((t for t in results if t.get('name') == slug), None)
            if not tenant:
                return self._send_json(404, {'error': 'Tenant not found'})
            # Return only public-safe fields
            return self._send_json(200, {
                'name': tenant.get('name'),
                'display_name': tenant.get('display_name'),
                'description': tenant.get('description'),
                'icon': tenant.get('icon'),
                'logo': tenant.get('logo'),
                'primary_color': tenant.get('primary_color'),
                'tenant_type': tenant.get('tenant_type'),
            })
        except Exception as e:
            return self._send_json(502, {'error': f'Lookup failed: {e}'})

    def _handle_login(self):
        """
        Proxy login to backend, then enrich response with access policy.
        One round trip from browser — server.py fetches policy server-side.
        """
        cl = int(self.headers.get('Content-Length', 0))
        body_bytes = self.rfile.read(cl)

        # Proxy login to backend
        req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
            data=body_bytes, method='POST')
        req.add_header('Content-Type', 'application/json')
        req.add_header('User-Agent', BROWSER_UA)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                login_result = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(data)
            return
        except Exception as e:
            return self._send_json(502, {'error': f'Login proxy failed: {e}'})

        # Enrich with access policy
        token = login_result.get('auth', {}).get('access_token')
        domain = login_result.get('context', {}).get('domain') or os.getenv('SUPERO_DOMAIN', '')
        tenant = login_result.get('context', {}).get('tenant', 'default-tenant')

        policy = _fetch_policy(token, domain, tenant) if token else None
        login_result['policy'] = policy

        # ── service_lib @login trigger ──
        _sl_fire_event_safe("@login", {
            "event": "@login", "operation": "login",
            "user": {
                "email": login_result.get("user", {}).get("email", ""),
                "uuid": login_result.get("user", {}).get("uuid", ""),
                "role": login_result.get("user", {}).get("role", ""),
            },
            "domain": domain, "tenant": tenant,
            "timestamp": datetime.now(timezone.utc).isoformat()
                if "datetime" in globals() else "",
        })
        self._send_json(200, login_result)

    # ── Signup ──

    def _handle_signup(self):
        """Create user account via API key, then auto-login with policy."""
        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})

        email = body.get('email', '').strip().lower()
        password = body.get('password', '')
        full_name = body.get('full_name', email.split('@')[0])
        signup_domain = body.get('domain') or _strip_env('SUPERO_DOMAIN')

        # Validation
        if not email or '@' not in email:
            return self._send_json(400, {'error': 'Valid email required'})
        if len(password) < 8:
            return self._send_json(400, {'error': 'Password must be 8+ characters'})
        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Signup unavailable — no service account'})

        domain = signup_domain
        project = _strip_env('SUPERO_PROJECT', 'default-project')
        tenant = body.get('tenant') or os.getenv('SUPERO_DEFAULT_TENANT', 'default-tenant')

        # Create user account via CRUD
        user_data = {
            'name': email,
            'username': email.split('@')[0],
            'email': email,
            'full_name': full_name,
            'password': password,  # ⚠️ plaintext — platform hashes automatically
            'parent_type': 'tenant',
            'parent_context': {
                'domain': domain,
                'project': project,
                'tenant': tenant,
            },
            'role': body.get('role', 'viewer'),  # Public signups get viewer role
            'enabled': True,
        }
        headers = {
            'X-API-Key': _SERVICE_API_KEY,
            'Content-Type': 'application/json',
            'User-Agent': BROWSER_UA,
        }
        create_url = f'{API_URL}/api/v1/crud/{domain}/user-account'

        try:
            req = urllib.request.Request(create_url,
                data=json.dumps(user_data).encode(), method='POST', headers=headers)
            with urllib.request.urlopen(req, timeout=30):
                pass
        except urllib.error.HTTPError as e:
            if e.code == 409:
                return self._send_json(409, {'error': 'Account exists. Please login.'})
            return self._send_json(e.code, {'error': 'Account creation failed'})

        # Auto-login after signup (omit tenant — let auth search)
        login_data = {
            'domain_name': domain,
            'email': email,
            'password': password,
            'project': project,
        }

        try:
            req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
                data=json.dumps(login_data).encode(), method='POST',
                headers={'Content-Type': 'application/json', 'User-Agent': BROWSER_UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
                token = result['auth']['access_token']
                policy = _fetch_policy(token, domain, tenant)

                # ── service_lib @signup trigger ──
                _sl_fire_event_safe("@signup", {
                    "event": "@signup", "operation": "signup",
                    "user": {"email": email, "full_name": full_name,
                             "role": "tenant_user"},
                    "domain": domain, "tenant": tenant,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                        if "datetime" in globals() else "",
                })
                return self._send_json(200, {
                    'auth': {'access_token': token},
                    'user': {'email': email, 'full_name': full_name, 'role': 'tenant_user'},
                    'context': {'domain': domain, 'project': project, 'tenant': tenant},
                    'policy': policy,
                })
        except Exception as e:
            return self._send_json(500, {'error': f'Login after signup failed: {e}'})

    # ── Public Schema Proxy ──

    def _handle_public_read(self):
        """Proxy public schema reads using API key (no user auth needed).

        Browser may send either bare ('campaign') or qualified
        ('ma559:campaign') type names. We qualify before forwarding
        to platform-core so colliding names (e.g. with email service)
        resolve unambiguously. The PUBLIC_SCHEMAS whitelist accepts
        both forms because config.py typically lists bare names.
        """
        # /api/public/<type> → /api/v1/crud/{domain}/<qualified-type>
        parts = self.path.split('/')
        if len(parts) < 4:
            return self._send_json(400, {'error': 'Invalid public endpoint'})

        raw_schema = parts[3].split('?')[0]
        domain = os.getenv('SUPERO_DOMAIN', '')

        # Compute both forms; whitelist check accepts either.
        qualified, bare = _qualify_public_schema(raw_schema)

        if bare not in _PUBLIC_SCHEMAS and qualified not in _PUBLIC_SCHEMAS:
            return self._send_json(403, {'error': f"Schema '{raw_schema}' is not public"})

        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Public data unavailable'})

        # Forward to platform with the qualified form (avoids 409 on collisions)
        url = f'{API_URL}/api/v1/crud/{domain}/{qualified}'
        # Forward query params
        if '?' in self.path:
            url += '?' + self.path.split('?', 1)[1]

        req = urllib.request.Request(url, method='GET')
        req.add_header('X-API-Key', _SERVICE_API_KEY)
        req.add_header('Content-Type', 'application/json')
        req.add_header('User-Agent', BROWSER_UA)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = json.loads(resp.read().decode())
                # Normalize: CRUD returns {results:[...]}, frontend expects {data:[...]}
                records = raw.get('results') or raw.get('data') or []
                if not isinstance(records, list):
                    records = []
                self._send_json(200, records)
        except Exception:
            # Empty data, not error — landing page degrades gracefully
            self._send_json(200, [])

    # ── BFF v1.1.0: schemas describe, scoped list, reference link ──

    def _handle_schemas_describe(self):
        """GET /api/schemas/describe — schema metadata for UI SchemaRegistry.

        Uses service API key (schema metadata is public within domain).
        Cached in memory with 5-min Cache-Control + ETag. On cache miss,
        fetches from platform via PlatformClient and shapes for the UI.
        """
        global _SCHEMAS_DESCRIBE_CACHE, _SCHEMAS_DESCRIBE_ETAG
        global _SCHEMAS_DESCRIBE_TIMESTAMP

        # v1.1.2: TTL eviction — refresh cache if older than _SCHEMAS_DESCRIBE_TTL
        _now_ts = time.time()
        if (_SCHEMAS_DESCRIBE_CACHE is not None
                and (_now_ts - _SCHEMAS_DESCRIBE_TIMESTAMP) > _SCHEMAS_DESCRIBE_TTL):
            _SCHEMAS_DESCRIBE_CACHE = None
            _SCHEMAS_DESCRIBE_ETAG = None

        # ETag / 304 short-circuit
        if_none_match = (self.headers.get('If-None-Match', '') or '').strip('"')
        if (if_none_match and _SCHEMAS_DESCRIBE_ETAG
                and if_none_match == _SCHEMAS_DESCRIBE_ETAG):
            self.send_response(304)
            self.send_header('ETag', f'"{_SCHEMAS_DESCRIBE_ETAG}"')
            self.end_headers()
            return

        # Cache miss: build it
        if _SCHEMAS_DESCRIBE_CACHE is None:
            payload, etag = _bff_build_describe_payload()
            if payload is None:
                return self._send_json(503, {
                    'error': 'Schema metadata unavailable',
                    'message': (
                        'Could not fetch schemas from platform. Check '
                        'SUPERO_DOMAIN, SUPERO_API_KEY, and platform connectivity.'
                    ),
                })
            _SCHEMAS_DESCRIBE_CACHE = payload
            _SCHEMAS_DESCRIBE_ETAG = etag
            _SCHEMAS_DESCRIBE_TIMESTAMP = _now_ts  # v1.1.2: track TTL

        # Serve cached payload
        payload = dict(_SCHEMAS_DESCRIBE_CACHE)
        payload['version'] = _SCHEMAS_DESCRIBE_ETAG
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'private, max-age=300')
        if _SCHEMAS_DESCRIBE_ETAG:
            self.send_header('ETag', f'"{_SCHEMAS_DESCRIBE_ETAG}"')
        self.end_headers()
        self.wfile.write(body)

    def _handle_scoped_list(self):
        """GET /api/scope/<parent_schema>/<parent_uuid>/<record_schema>

        Returns records of `record_schema` that back-reference the given
        parent. Uses the caller's JWT so RBAC is enforced by platform.

        Response shape: {records: [...], count: N}
        """
        # Parse path: /api/scope/study/<uuid>/subject
        path = self.path.split('?', 1)[0]
        parts = path.strip('/').split('/')
        if len(parts) < 5 or parts[0] != 'api' or parts[1] != 'scope':
            return self._send_json(400, {
                'error': 'Invalid scope URL',
                'expected': '/api/scope/<parent_schema>/<parent_uuid>/<record_schema>',
            })

        parent_schema = parts[2]
        parent_uuid = parts[3]
        record_schema = parts[4]

        if not parent_schema or not parent_uuid or not record_schema:
            return self._send_json(400, {'error': 'Missing path segments'})

        domain = _strip_env('SUPERO_DOMAIN')
        if not domain:
            return self._send_json(503, {'error': 'SUPERO_DOMAIN not configured'})

        client = _bff_get_user_client(self)
        if client is None:
            return self._send_json(401, {'error': 'Authentication required'})

        try:
            result = client.get(
                f'/api/v1/crud/{domain}/{parent_schema}/{parent_uuid}/back-refs',
                params={'back_ref_type': record_schema},
            )
        except Exception as e:
            return self._send_json(502, {'error': f'Scope list failed: {e}'})

        # Platform response shape: {success: True, back_refs: {<type>: [...]}}
        back_refs = {}
        if isinstance(result, dict):
            back_refs = result.get('back_refs') or {}

        # v1.1.1: back-refs may key records by any of:
        #   (a) bare record schema name     → "subject"
        #   (b) namespace-qualified form    → "t57_corp:subject"
        #   (c) back_ref_name from the ref  → "subjects" (common when the
        #       source schema's reference declares back_ref_name)
        # Try (a), then (b), then (c) as a substring fallback.
        records = None
        if isinstance(back_refs, dict):
            # (a) exact match on bare name
            records = back_refs.get(record_schema)
            if records is None:
                # (b) namespace-qualified match
                for k, v in back_refs.items():
                    if isinstance(k, str) and k.endswith(':' + record_schema):
                        records = v
                        break
            # v1.1.2: removed (c) substring fallback — was false-positive prone
            # (e.g. "event" matched "event_log"). If (a) and (b) miss, return
            # empty rather than guess. Real platform response keys are
            # deterministic per back_ref_type filter (see crud_service.get_back_refs).
            pass
        if not isinstance(records, list):
            records = []

        return self._send_json(200, {
            'records': records,
            'count': len(records),
            'parent_schema': parent_schema,
            'parent_uuid': parent_uuid,
            'record_schema': record_schema,
        })

    def _handle_link_reference(self):
        """PUT /api/link — add or remove a reference between two objects.

        Body: {
          source_type: str,     # PascalCase or snake — platform accepts both
          source_uuid: str,
          ref_name: str,        # the reference name as declared on source schema
          ref_uuid: str,        # target object uuid
          operation: 'ADD'|'DELETE'  (default: ADD)
        }

        Uses caller's JWT — platform enforces permission on both source
        and target objects.
        """
        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})

        required = ['source_type', 'source_uuid', 'ref_name', 'ref_uuid']
        missing = [k for k in required if not body.get(k)]
        if missing:
            return self._send_json(400, {
                'error': f'Missing required fields: {", ".join(missing)}',
            })

        operation = body.get('operation', 'ADD')
        if operation not in ('ADD', 'DELETE'):
            return self._send_json(400, {
                'error': f'Invalid operation: {operation} (must be ADD or DELETE)',
            })

        domain = _strip_env('SUPERO_DOMAIN')
        if not domain:
            return self._send_json(503, {'error': 'SUPERO_DOMAIN not configured'})

        client = _bff_get_user_client(self)
        if client is None:
            return self._send_json(401, {'error': 'Authentication required'})

        try:
            result = client.put(f'/api/v1/crud/{domain}/ref-update', json={
                'type': body['source_type'],
                'uuid': body['source_uuid'],
                'ref-type': body['ref_name'],
                'ref-uuid': body['ref_uuid'],
                'operation': operation,
            })
            return self._send_json(200, result or {'success': True})
        except Exception as e:
            return self._send_json(502, {'error': f'Link operation failed: {e}'})

    # ─── BFF v1.7.0: Stripe return-handler endpoints ──────────
    # Two endpoints handle the user returning from a Stripe Checkout
    # session. /verify is read-only (Stripe session.retrieve);
    # /finalize is idempotent (creates billing_payment, marks invoice
    # paid). Design: Billing-App-Integration.md §3.3.
    # ─────────────────────────────────────────────────────────

    def _handle_checkout_verify(self):
        """GET /api/checkout/verify?session_id=cs_...

        Read-only Stripe session status query. Calls stripe_checkout.
        session.retrieve via /api/v1/services/execute using the
        caller's JWT. Returns Stripe's authoritative payment_status.
        Does NOT mutate any records. Safe to call repeatedly.
        """
        from urllib.parse import urlparse, parse_qs
        params = parse_qs(urlparse(self.path).query)
        session_id = (params.get('session_id', [''])[0] or '').strip()
        if not session_id:
            return self._send_json(400, {'error': 'session_id required'})

        client = _bff_get_user_client(self)
        if client is None:
            return self._send_json(401, {'error': 'Authentication required'})

        domain = _strip_env('SUPERO_DOMAIN')
        project_uuid = _strip_env('SUPERO_PROJECT_UUID') or ''

        try:
            result = client.post('/api/v1/services/execute', json={
                'service_id': 'stripe_checkout',
                'operation': 'session.retrieve',
                'input': {'session_id': session_id},
                'domain': domain,
                'project_uuid': project_uuid,
            })
        except Exception as e:
            import traceback
            print(f'  ⚠ /api/checkout/verify: Stripe retrieval failed: '
                  f'{type(e).__name__}: {e}', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            return self._send_json(502, {'error': f'Stripe retrieval failed: {e}'})

        # Observability (gated by SUPERO_BILLING_DEBUG=1). On first
        # production payment, turn this on to verify the Stripe response
        # envelope shape matches what the unwrap code below assumes.
        if os.environ.get('SUPERO_BILLING_DEBUG'):
            print(f'  📋 verify result shape: '
                  f'{type(result).__name__}, '
                  f'keys={list(result.keys()) if isinstance(result, dict) else "n/a"}',
                  file=sys.stderr)

        # Service execute wraps output in {success, service_id, operation,
        # output, error, ...} envelope (see service_routes.py line 649).
        # Unwrap to get the stripe session detail.
        if isinstance(result, dict) and 'output' in result:
            stripe_session = result.get('output') or {}
        else:
            stripe_session = result or {}

        if not stripe_session:
            return self._send_json(502, {
                'error': 'Empty response from stripe_checkout',
                'raw': result,
            })

        return self._send_json(200, {
            'payment_status':       stripe_session.get('payment_status', 'unknown'),
            'amount_total':         stripe_session.get('amount_total', 0),
            'currency':             stripe_session.get('currency', ''),
            'customer_email':       stripe_session.get('customer_email', ''),
            'client_reference_id':  stripe_session.get('client_reference_id', ''),
            'session_id':           session_id,
            'status':               stripe_session.get('status', ''),
        })

    def _handle_checkout_finalize(self):
        """POST /api/checkout/finalize
        Body: {"session_id": "cs_...", "invoice_uuid": "binv-..."}

        Idempotent. Verifies payment with Stripe; if paid AND the
        session's client_reference_id matches the invoice_uuid
        (cross-invoice attack mitigation), creates a billing_payment
        record and updates billing_invoice.status = 'paid'.

        CAS idempotency: if invoice is already paid/cancelled, returns
        200 {reason: 'already_finalized'} without mutation.
        """
        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})

        session_id   = (body.get('session_id')   or '').strip()
        invoice_uuid = (body.get('invoice_uuid') or '').strip()
        if not session_id or not invoice_uuid:
            return self._send_json(400, {
                'error': 'session_id and invoice_uuid required',
            })

        client = _bff_get_user_client(self)
        if client is None:
            return self._send_json(401, {'error': 'Authentication required'})

        domain = _strip_env('SUPERO_DOMAIN')
        if not domain:
            return self._send_json(503, {'error': 'SUPERO_DOMAIN not configured'})

        project_uuid = _strip_env('SUPERO_PROJECT_UUID') or ''

        # 1. Get authoritative status from Stripe
        try:
            exec_result = client.post('/api/v1/services/execute', json={
                'service_id': 'stripe_checkout',
                'operation': 'session.retrieve',
                'input': {'session_id': session_id},
                'domain': domain,
                'project_uuid': project_uuid,
            })
        except Exception as e:
            import traceback
            print(f'  ⚠ /api/checkout/finalize: Stripe retrieval failed: '
                  f'{type(e).__name__}: {e}', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            return self._send_json(502, {'error': f'Stripe retrieval failed: {e}'})

        # Unwrap execute envelope (same pattern as verify)
        if isinstance(exec_result, dict) and 'output' in exec_result:
            session = exec_result.get('output') or {}
        else:
            session = exec_result or {}

        stripe_state = session.get('payment_status', '')
        if stripe_state not in ('paid', 'no_payment_required'):
            return self._send_json(200, {
                'status': 'pending',
                'reason': 'session_still_open',
                'stripe_status': stripe_state,
            })

        # 2. Cross-invoice security check: session's client_reference_id
        # (set by the billing_invoice_created workflow) must match the
        # invoice_uuid in the request body. Missing ref is accepted for
        # backward compat with sessions created before this patch; can
        # be tightened in v1.8.0.
        session_ref = (session.get('client_reference_id') or '').strip()
        if session_ref and session_ref != invoice_uuid:
            return self._send_json(400, {
                'error': 'Session does not belong to this invoice',
                'reason': 'client_reference_mismatch',
            })

        # 3. Read invoice for CAS guard. Single-record endpoint at
        # /api/v1/crud/<domain>/<type>/<uuid>; response may be wrapped
        # in {obj_type: {...}} (see tenant_routes.py pattern).
        try:
            invoice_resp = client.get(
                f'/api/v1/crud/{domain}/billing_invoice/{invoice_uuid}'
            )
        except Exception as e:
            import traceback
            print(f'  ⚠ /api/checkout/finalize: Invoice lookup failed: '
                  f'{type(e).__name__}: {e}', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            return self._send_json(404, {'error': f'Invoice lookup failed: {e}'})

        # Observability (gated by SUPERO_BILLING_DEBUG=1). The unwrap
        # logic below tries several response shapes. Set the env var on
        # first production run to see which shape is actually returned.
        if os.environ.get('SUPERO_BILLING_DEBUG'):
            print(f'  📋 finalize invoice_resp shape: '
                  f'{type(invoice_resp).__name__}, '
                  f'keys={list(invoice_resp.keys()) if isinstance(invoice_resp, dict) else "n/a"}',
                  file=sys.stderr)

        if not invoice_resp:
            return self._send_json(404, {'error': 'Invoice not found'})

        # Unwrap CRUD envelope. Platform has shipped three shapes
        # historically ({billing_invoice:...}, {object:...}, flat).
        # Added 'result' branch preemptively. If a fifth shape lands,
        # the else branch still works as long as the dict has the
        # expected top-level fields (uuid, status). Otherwise we log a
        # warning and fall through to the malformed-response 404 check.
        if isinstance(invoice_resp, dict) and 'billing_invoice' in invoice_resp:
            invoice = invoice_resp.get('billing_invoice') or {}
        elif isinstance(invoice_resp, dict) and 'object' in invoice_resp:
            invoice = invoice_resp.get('object') or {}
        elif isinstance(invoice_resp, dict) and 'result' in invoice_resp:
            invoice = invoice_resp.get('result') or {}
        else:
            invoice = invoice_resp or {}
            # Flat-shape fallback: emit a warning if the dict doesn't
            # look like an invoice. This surfaces new response shapes
            # without needing SUPERO_BILLING_DEBUG=1.
            if (isinstance(invoice, dict) and invoice
                    and 'uuid' not in invoice and 'status' not in invoice):
                print(f'  ⚠ /api/checkout/finalize: unexpected invoice response '
                      f'shape. Got keys={list(invoice.keys())} — expected '
                      f'billing_invoice/object/result wrapper, or flat dict '
                      f'with uuid/status fields. Adding a new unwrap branch '
                      f'may be needed.', file=sys.stderr)

        if not isinstance(invoice, dict) or not invoice:
            return self._send_json(404, {
                'error': 'Invoice not found or malformed response',
                'raw': invoice_resp,
            })

        current_status = (invoice.get('status') or '').strip()
        if current_status in ('paid', 'cancelled'):
            return self._send_json(200, {
                'status': current_status,
                'reason': 'already_finalized',
            })

        # 4. Create billing_payment
        from datetime import datetime, timezone
        now_iso = datetime.now(timezone.utc).isoformat()
        amount_total_cents = session.get('amount_total', 0) or 0
        amount_major = (
            amount_total_cents / 100.0 if amount_total_cents
            else invoice.get('total_amount', 0)
        )

        try:
            client.post(f'/api/v1/crud/{domain}/billing_payment', json={
                'name': f'pay-{session_id[-24:]}',  # 24 chars reduces collision risk
                'display_name': f'Payment for invoice {invoice.get("invoice_number", "")}',
                'description': 'Auto-reconciled from Stripe return handler',
                'invoice_uuid': invoice_uuid,
                'payment_date': now_iso,
                'amount': amount_major,
                'payment_method': 'stripe',
                'status': 'completed',
                'stripe_session_id': session_id,
                'transaction_reference': session_id,
                'workflow_status': 'processed',
                # Carried from invoice for billing_payment_received
                # workflow's receipt email step. Without these, the
                # receipt email's to_email is empty.
                'customer_email': invoice.get('customer_email', ''),
                'customer_name': invoice.get('customer_name', ''),
            })
        except Exception as e:
            import traceback
            print(f'  ⚠ /api/checkout/finalize: Payment record create failed: '
                  f'{type(e).__name__}: {e}', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            return self._send_json(502, {
                'error': f'Payment record create failed: {e}',
            })

        # 5. Update invoice status (CAS already passed at step 3)
        try:
            client.put(
                f'/api/v1/crud/{domain}/billing_invoice/{invoice_uuid}',
                json={
                    'status': 'paid',
                    'paid_at': now_iso,
                    'workflow_status': 'payment_received',
                },
            )
        except Exception as e:
            import traceback
            print(f'  ⚠ /api/checkout/finalize: Invoice status update failed: '
                  f'{type(e).__name__}: {e}', file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            return self._send_json(502, {
                'error': f'Invoice status update failed: {e}',
                'payment_created': True,
            })

        return self._send_json(200, {
            'status': 'paid',
            'reason': 'finalized_by_return_handler',
        })

    # ── Helpers ──

    def _send_json(self, status, data):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        # Quieter logging — skip static file requests
        path = args[0] if args else ''
        if isinstance(path, str) and (path.endswith('.js') or path.endswith('.css') or path.endswith('.html')):
            return
        super().log_message(format, *args)


# ─────────────────────────────────────────────────────────
# Services — typed wrappers for all platform services
#
# Usage in setup.py:
#   from supero_server import Services
#   svc = Services(session, base_url, domain)
#   svc.email.send('user@app.com', 'Welcome!', '<p>Hi</p>')
#   svc.workflow.run('enrollment_confirmed', enrollment_uuid='...', amount=99)
#
# Maps friendly method calls to exact service_id + operation_id + field names.
# setup.py no longer needs to know the raw execute API.
# ─────────────────────────────────────────────────────────

class _ServiceGroup:
    """Base for a service group — handles the execute call."""
    def __init__(self, session, base, domain, service_id):
        self._s = session
        self._base = base
        self._domain = domain
        self._service_id = service_id

    def _exec(self, operation_id, input_data):
        return self._s.post(
            f'{self._base}/api/v1/services/execute',
            json={'service_id': self._service_id, 'operation_id': operation_id, 'input': input_data},
            timeout=30,
        )


class _EmailService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'email')
    def send(self, to, subject, body_html=None, body_text=None, from_name=None):
        inp = {'to_email': to, 'subject': subject}
        if body_html: inp['body_html'] = body_html
        elif body_text: inp['body_text'] = body_text
        if from_name: inp['from_name'] = from_name
        return self._exec('send_email', inp)


class _SmsService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'sms')
    def send(self, to, body):
        return self._exec('send_sms', {'to_number': to, 'body': body})


class _WhatsAppService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'whatsapp')
    def send(self, to, body):
        return self._exec('send_message', {'to_number': to, 'body': body})
    def send_template(self, to, template_name, template_params=None):
        return self._exec('send_template', {
            'to_number': to, 'template_name': template_name, 'template_params': template_params or {}})


class _PushService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'push_notification')
    def notify(self, device_token, title, body):
        return self._exec('send_notification', {'device_token': device_token, 'title': title, 'body': body})
    def broadcast(self, topic, title, body):
        return self._exec('send_topic_broadcast', {'topic': topic, 'title': title, 'body': body})


class _SlackService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'slack')
    def message(self, channel, text):
        return self._exec('send_message', {'channel': channel, 'text': text})
    def create_channel(self, name, topic=None):
        return self._exec('create_channel', {'channel_name': name, 'topic': topic or ''})


class _StripeService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'stripe_checkout')
    def checkout(self, amount, product_name, success_url):
        return self._exec('create_checkout_session', {
            'amount': amount, 'product_name': product_name, 'success_url': success_url})
    def payment_link(self, price_id):
        return self._exec('create_payment_link', {'price_id': price_id})


class _BillingService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'billing')
    def create_customer(self, email, company_name):
        return self._exec('create_customer', {'email': email, 'company_name': company_name})
    def create_invoice(self, customer_uuid, amount, currency='USD', due_date=None):
        inp = {'customer_uuid': customer_uuid, 'amount': amount, 'currency': currency}
        if due_date: inp['due_date'] = due_date
        return self._exec('create_invoice', inp)


class _SalesforceService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'salesforce')
    def create_lead(self, last_name, company, email):
        return self._exec('create_lead', {'last_name': last_name, 'company': company, 'email': email})
    def create_case(self, subject, priority='Medium', case_origin='Web'):
        return self._exec('create_case', {'subject': subject, 'priority': priority, 'case_origin': case_origin})


class _S3Service(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'amazon_s3')
    def upload_url(self, key, content_type='application/octet-stream'):
        return self._exec('generate_upload_url', {'key': key, 'content_type': content_type})


class _DriveService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'google_drive')
    def create_folder(self, name, description=''):
        return self._exec('create_folder', {'file_name': name, 'description': description})


class _CalendarService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'google_calendar')
    def create_event(self, title, start_time, end_time, add_meet=False):
        return self._exec('create_event', {
            'summary': title, 'start_time': start_time, 'end_time': end_time, 'add_meet': add_meet})


class _ServiceNowService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'servicenow')
    def create_incident(self, description, urgency='2', impact='2'):
        return self._exec('create_incident', {
            'short_description': description, 'urgency': urgency, 'impact': impact})


class _AIService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'ai')
    def complete(self, prompt, model='claude-sonnet', max_tokens=1000):
        return self._exec('simple_completion', {'prompt': prompt, 'model': model, 'max_tokens': max_tokens})
    def chat(self, messages, model='claude-sonnet'):
        return self._exec('chat_completion', {'messages': messages, 'model': model})


class _OtpService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'auth_otp')
    def send(self, channel, recipient, purpose='login'):
        return self._exec('send_otp', {'channel': channel, 'recipient': recipient, 'purpose': purpose})


class _WorkflowService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'workflows')
    def run(self, workflow_id, **input_data):
        return self._exec('execute_workflow', {'workflow_id': workflow_id, **input_data})
    def validate(self, workflow_id):
        return self._exec('validate_workflow', {'workflow_id': workflow_id})


class Services:
    """
    Typed service client for all platform services.

    Usage:
        svc = Services(session, base_url, domain)
        svc.email.send('user@example.com', 'Welcome!', '<p>Hello</p>')
        svc.stripe.checkout(amount=99, product_name='Course', success_url='/success')
        svc.workflow.run('enrollment_confirmed', enrollment_uuid='abc', amount=99)
    """
    def __init__(self, session, base_url, domain):
        args = (session, base_url, domain)
        self.email = _EmailService(*args)
        self.sms = _SmsService(*args)
        self.whatsapp = _WhatsAppService(*args)
        self.push = _PushService(*args)
        self.slack = _SlackService(*args)
        self.stripe = _StripeService(*args)
        self.billing = _BillingService(*args)
        self.salesforce = _SalesforceService(*args)
        self.s3 = _S3Service(*args)
        self.drive = _DriveService(*args)
        self.calendar = _CalendarService(*args)
        self.servicenow = _ServiceNowService(*args)
        self.ai = _AIService(*args)
        self.otp = _OtpService(*args)
        self.workflow = _WorkflowService(*args)


# ─────────────────────────────────────────────────────────
# Services Client — typed wrappers for all 26 platform services
#
# Usage in setup.py:
#   from supero_server import Services
#   svc = Services(session, base_url, domain)
#   svc.email.send(to='user@app.com', subject='Welcome', body_html='<p>Hi</p>')
#   svc.workflow.run('enrollment_confirmed', enrollment_uuid='...', amount=99)
# ─────────────────────────────────────────────────────────

class _ServiceGroup:
    """Base for a service group with execute helper."""
    def __init__(self, session, base, domain, service_id):
        self._s = session
        self._base = base
        self._domain = domain
        self._service_id = service_id

    def _exec(self, operation_id, input_data):
        return self._s.post(f'{self._base}/api/v1/services/execute',
            json={'service_id': self._service_id, 'operation_id': operation_id, 'input': input_data},
            timeout=60)


class _EmailSvc(_ServiceGroup):
    def send(self, to, subject, body_html=None, body_text=None, from_name=None):
        inp = {'to_email': to, 'subject': subject}
        if body_html: inp['body_html'] = body_html
        if body_text: inp['body_text'] = body_text
        if from_name: inp['from_name'] = from_name
        return self._exec('send_email', inp)

class _SmsSvc(_ServiceGroup):
    def send(self, to, body):
        return self._exec('send_sms', {'to_number': to, 'body': body})

class _WhatsappSvc(_ServiceGroup):
    def send(self, to, body):
        return self._exec('send_message', {'to_number': to, 'body': body})
    def send_template(self, to, template_name, template_params=None):
        return self._exec('send_template', {'to_number': to, 'template_name': template_name, 'template_params': template_params or {}})

class _PushSvc(_ServiceGroup):
    def notify(self, token, title, body):
        return self._exec('send_notification', {'device_token': token, 'title': title, 'body': body})
    def broadcast(self, topic, title, body):
        return self._exec('send_topic_broadcast', {'topic': topic, 'title': title, 'body': body})

class _SlackSvc(_ServiceGroup):
    def message(self, channel, text):
        return self._exec('send_message', {'channel': channel, 'text': text})
    def create_channel(self, name, topic=''):
        return self._exec('create_channel', {'channel_name': name, 'topic': topic})

class _StripeSvc(_ServiceGroup):
    def checkout(self, amount, product, success_url):
        return self._exec('create_checkout_session', {'amount': amount, 'product_name': product, 'success_url': success_url})
    def payment_link(self, price_id):
        return self._exec('create_payment_link', {'price_id': price_id})

class _BillingSvc(_ServiceGroup):
    def create_customer(self, email, company):
        return self._exec('create_customer', {'email': email, 'company_name': company})
    def create_invoice(self, customer_uuid, amount, currency='USD', due_date=None):
        return self._exec('create_invoice', {'customer_uuid': customer_uuid, 'amount': amount, 'currency': currency, 'due_date': due_date})

class _SalesforceSvc(_ServiceGroup):
    def create_lead(self, last_name, company, email):
        return self._exec('create_lead', {'last_name': last_name, 'company': company, 'email': email})
    def create_case(self, subject, priority='Medium', origin='Web'):
        return self._exec('create_case', {'subject': subject, 'priority': priority, 'case_origin': origin})

class _AiSvc(_ServiceGroup):
    def complete(self, prompt, model='claude-sonnet', max_tokens=1000):
        return self._exec('simple_completion', {'prompt': prompt, 'model': model, 'max_tokens': max_tokens})
    def chat(self, messages, model='claude-sonnet'):
        return self._exec('chat_completion', {'messages': messages, 'model': model})

class _WorkflowSvc(_ServiceGroup):
    def run(self, workflow_id, **input_data):
        return self._exec('execute_workflow', {'workflow_id': workflow_id, **input_data})
    def validate(self, workflow_id):
        return self._exec('validate_workflow', {'workflow_id': workflow_id})

class _S3Svc(_ServiceGroup):
    def upload_url(self, key, content_type):
        return self._exec('generate_upload_url', {'key': key, 'content_type': content_type})

class _CalendarSvc(_ServiceGroup):
    def create_event(self, title, start, end, add_meet=False):
        return self._exec('create_event', {'summary': title, 'start_time': start, 'end_time': end, 'add_meet': add_meet})

class _OtpSvc(_ServiceGroup):
    def send(self, to, channel='sms', purpose='login'):
        return self._exec('send_otp', {'channel': channel, 'recipient': to, 'purpose': purpose})

class _SearchSvc(_ServiceGroup):
    def web(self, query, num=5):
        return self._exec('web_search', {'query': query, 'num': num})


class _QuickBooksSvc(_ServiceGroup):
    def create_customer(self, display_name, email='', phone='', company=''):
        return self._exec('create_customer', {'display_name': display_name, 'email': email, 'phone': phone, 'company': company})
    def create_invoice(self, customer_ref, line_items=None, due_date='', currency='USD', notes=''):
        return self._exec('create_invoice', {'customer_ref': customer_ref, 'line_items': line_items or [], 'due_date': due_date, 'currency': currency, 'notes': notes})
    def record_payment(self, customer_ref, amount, payment_method='', invoice_ref=''):
        return self._exec('record_payment', {'customer_ref': customer_ref, 'amount': amount, 'payment_method': payment_method, 'invoice_ref': invoice_ref})
    def create_expense(self, account_ref, amount, description='', vendor=''):
        return self._exec('create_expense', {'account_ref': account_ref, 'amount': amount, 'description': description, 'vendor': vendor})
    def create_bill(self, vendor_ref, line_items=None, due_date=''):
        return self._exec('create_bill', {'vendor_ref': vendor_ref, 'line_items': line_items or [], 'due_date': due_date})
    def create_vendor(self, display_name, email='', phone=''):
        return self._exec('create_vendor', {'display_name': display_name, 'email': email, 'phone': phone})
    def sync_invoice(self, invoice_uuid):
        return self._exec('sync_invoice', {'invoice_uuid': invoice_uuid})
    def get_report(self, report_type, start_date='', end_date=''):
        return self._exec('get_report', {'report_type': report_type, 'start_date': start_date, 'end_date': end_date})


class _McpServerSvc(_ServiceGroup):
    def register_tools(self):
        return self._exec('register_tools', {})
    def handle_tool_call(self, tool_name, arguments=None):
        return self._exec('handle_tool_call', {'tool_name': tool_name, 'arguments': arguments or {}})
    def list_resources(self):
        return self._exec('list_resources', {})
    def get_endpoint(self):
        return self._exec('get_endpoint', {})


class _McpClientSvc(_ServiceGroup):
    def call_tool(self, server_url='', tool_name='', arguments=None, server_name=''):
        return self._exec('call_tool', {'server_url': server_url, 'server_name': server_name, 'tool_name': tool_name, 'arguments': arguments or {}})
    def list_tools(self, server_url='', server_name=''):
        return self._exec('list_tools', {'server_url': server_url, 'server_name': server_name})
    def connect_server(self, server_url, name='', auth_type='none', auth_token=''):
        return self._exec('connect_server', {'server_url': server_url, 'name': name, 'auth_type': auth_type, 'auth_token': auth_token})


class _GoogleAuthSvc(_ServiceGroup):
    def login(self, auth_code, redirect_uri=''):
        return self._exec('google_login', {'auth_code': auth_code, 'redirect_uri': redirect_uri})
    def signup(self, auth_code, redirect_uri=''):
        return self._exec('google_signup', {'auth_code': auth_code, 'redirect_uri': redirect_uri, 'signup': True})
    def link_account(self, auth_code, redirect_uri=''):
        return self._exec('link_account', {'auth_code': auth_code, 'redirect_uri': redirect_uri, 'link_account': True})
    def get_config(self):
        return self._exec('get_google_config', {})


class _GoogleAdsSvc(_ServiceGroup):
    def create_campaign(self, campaign_name, budget_amount=50, channel_type='SEARCH', bidding_strategy='MAXIMIZE_CLICKS'):
        return self._exec('create_campaign', {'campaign_name': campaign_name, 'budget_amount': budget_amount, 'channel_type': channel_type, 'bidding_strategy': bidding_strategy})
    def create_ad_group(self, campaign_id, ad_group_name, cpc_bid=1.0):
        return self._exec('create_ad_group', {'campaign_id': campaign_id, 'ad_group_name': ad_group_name, 'cpc_bid': cpc_bid})
    def create_ad(self, ad_group_id, headlines, descriptions=None, final_url=''):
        import json as _json
        return self._exec('create_ad', {'ad_group_id': ad_group_id, 'headlines': _json.dumps(headlines), 'descriptions': _json.dumps(descriptions or []), 'final_url': final_url})
    def add_keywords(self, ad_group_id, keywords, match_type='BROAD'):
        import json as _json
        return self._exec('add_keywords', {'ad_group_id': ad_group_id, 'keywords': _json.dumps(keywords), 'match_type': match_type})
    def get_performance(self, query=''):
        return self._exec('get_performance', {'query': query} if query else {})
    def pause_campaign(self, campaign_id):
        return self._exec('pause_campaign', {'campaign_id': campaign_id, 'new_status': 'PAUSED'})
    def enable_campaign(self, campaign_id):
        return self._exec('enable_campaign', {'campaign_id': campaign_id, 'new_status': 'ENABLED'})
    def list_campaigns(self):
        return self._exec('list_campaigns', {'list_campaigns': True})


class _GoogleReviewsSvc(_ServiceGroup):
    def list_reviews(self, location_id='', page_size=50, page_token=''):
        return self._exec('list_reviews', {'location_id': location_id, 'page_size': page_size, 'page_token': page_token})
    def get_review(self, review_id, location_id=''):
        return self._exec('get_review', {'review_id': review_id, 'location_id': location_id})
    def reply_review(self, review_id, reply_comment, location_id=''):
        return self._exec('reply_review', {'review_id': review_id, 'reply_comment': reply_comment, 'location_id': location_id})
    def delete_reply(self, review_id, location_id=''):
        return self._exec('delete_reply', {'review_id': review_id, 'delete_reply': True, 'location_id': location_id})
    def get_rating(self, location_id=''):
        return self._exec('get_rating', {'get_rating': True, 'location_id': location_id})
    def list_locations(self):
        return self._exec('list_locations', {'list_locations': True})


class Services:
    """All 26 platform services with typed methods.

    Usage:
        svc = Services(session, 'https://api.supero.dev', 'my-domain')
        svc.email.send(to='user@app.com', subject='Hi', body_html='<p>Hello</p>')
        svc.slack.message(channel='#ops', text='Alert!')
        svc.workflow.run('order_confirmed', order_uuid='abc-123', customer_email='x@y.com')
    """
    def __init__(self, session, base_url, domain):
        self.email     = _EmailSvc(session, base_url, domain, 'email')
        self.email_smtp= _EmailSvc(session, base_url, domain, 'email_smtp')
        self.sms       = _SmsSvc(session, base_url, domain, 'sms')
        self.whatsapp  = _WhatsappSvc(session, base_url, domain, 'whatsapp')
        self.push      = _PushSvc(session, base_url, domain, 'push_notification')
        self.slack     = _SlackSvc(session, base_url, domain, 'slack')
        self.stripe    = _StripeSvc(session, base_url, domain, 'stripe_checkout')
        self.billing   = _BillingSvc(session, base_url, domain, 'billing')
        self.salesforce= _SalesforceSvc(session, base_url, domain, 'salesforce')
        self.ai        = _AiSvc(session, base_url, domain, 'ai')
        self.workflow  = _WorkflowSvc(session, base_url, domain, 'workflows')
        self.s3        = _S3Svc(session, base_url, domain, 'amazon_s3')
        self.drive     = _ServiceGroup(session, base_url, domain, 'google_drive')
        self.calendar  = _CalendarSvc(session, base_url, domain, 'google_calendar')
        self.servicenow= _ServiceGroup(session, base_url, domain, 'servicenow')
        self.otp       = _OtpSvc(session, base_url, domain, 'auth_otp')
        self.search    = _SearchSvc(session, base_url, domain, 'google_search')
        # Social / DevOps — use _exec directly
        self.github    = _ServiceGroup(session, base_url, domain, 'github')
        self.bitbucket = _ServiceGroup(session, base_url, domain, 'bitbucket')
        self.instagram = _ServiceGroup(session, base_url, domain, 'instagram')
        self.twitter   = _ServiceGroup(session, base_url, domain, 'x_social')
        self.linkedin  = _ServiceGroup(session, base_url, domain, 'linkedin')
        self.youtube   = _ServiceGroup(session, base_url, domain, 'youtube')
        self.paypal    = _ServiceGroup(session, base_url, domain, 'billing_paypal')
        self.razorpay  = _ServiceGroup(session, base_url, domain, 'billing_razorpay')
        self.plaid     = _ServiceGroup(session, base_url, domain, 'plaid')
        # QuickBooks
        self.quickbooks = _QuickBooksSvc(session, base_url, domain, 'quickbooks')
        # MCP
        self.mcp_server = _McpServerSvc(session, base_url, domain, 'mcp_server')
        self.mcp_client = _McpClientSvc(session, base_url, domain, 'mcp_client')
        # Google OAuth
        self.google_auth = _GoogleAuthSvc(session, base_url, domain, 'google_oauth')
        # Google Ads
        self.google_ads = _GoogleAdsSvc(session, base_url, domain, 'google_ads')
        # Google Reviews
        self.google_reviews = _GoogleReviewsSvc(session, base_url, domain, 'google_reviews')


# ─────────────────────────────────────────────────────────
# Server Entry Point
# ─────────────────────────────────────────────────────────

class SuperoServer:
    """Configurable Supero UI server."""

    def __init__(self, port=None, public_schemas=None, handler_class=None):
        self.port = port or int(os.getenv('UI_PORT', '5648'))
        self.handler_class = handler_class or SuperoRequestHandler

        global _PUBLIC_SCHEMAS
        if public_schemas is not None:
            _PUBLIC_SCHEMAS = public_schemas
        else:
            _PUBLIC_SCHEMAS = [s.strip() for s in os.getenv('PUBLIC_SCHEMAS', '').split(',') if s.strip()]

    def serve(self):
        """Start the server. Blocks until killed."""
        print(f'  🌐 Starting server on port {self.port}...')
        init_service_account()

        if _PUBLIC_SCHEMAS:
            print(f'  📋 Public schemas: {", ".join(_PUBLIC_SCHEMAS)}')

        # ThreadingTCPServer so slow proxy requests don't block everything
        # allow_reuse_address must be set BEFORE __init__ calls server_bind()
        class _Server(socketserver.ThreadingTCPServer):
            allow_reuse_address = True
            daemon_threads = True

        with _Server(('', self.port), self.handler_class) as httpd:
            print(f'  ✅ Serving on http://0.0.0.0:{self.port}')
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print('\n  Server stopped.')


def serve(port=None, public_schemas=None):
    """Quick-start: one-line server."""
    SuperoServer(port=port, public_schemas=public_schemas).serve()


# ─────────────────────────────────────────────────────────
# Standalone execution
# ─────────────────────────────────────────────────────────

if __name__ == '__main__':
    serve()
