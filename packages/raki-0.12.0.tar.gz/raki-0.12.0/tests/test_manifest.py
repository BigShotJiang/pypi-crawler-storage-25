"""Tests for EvalManifest model and manifest loader."""

from datetime import datetime, timezone
from pathlib import Path

import pytest
from pydantic import ValidationError


class TestLoadManifest:
    """Tests for load_manifest() function."""

    def test_load_manifest_basic(self, fixtures_dir: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        manifest = load_manifest(
            fixtures_dir / "manifests" / "basic.yaml",
            project_root=fixtures_dir,
        )
        assert manifest.sessions.path is not None
        assert manifest.sessions.format == "auto"

    def test_load_manifest_validates_sessions_path(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        manifest_path = tmp_path / "raki.yaml"
        manifest_path.write_text("sessions:\n  path: /nonexistent/path\n  format: auto\n")
        with pytest.raises(ValueError, match="does not exist"):
            load_manifest(manifest_path)

    def test_load_manifest_filter_min_phases(self, fixtures_dir: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        manifest = load_manifest(
            fixtures_dir / "manifests" / "basic.yaml",
            project_root=fixtures_dir,
        )
        assert manifest.sessions.filter.min_phases == 2

    def test_load_manifest_filter_defaults(self, tmp_path: Path) -> None:
        """Filter defaults should be sensible when not specified."""
        from raki.ground_truth.manifest import load_manifest

        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        manifest_path = tmp_path / "raki.yaml"
        manifest_path.write_text(f"sessions:\n  path: {sessions_dir}\n  format: auto\n")
        manifest = load_manifest(manifest_path)
        assert manifest.sessions.filter.min_phases == 0
        assert manifest.sessions.filter.tickets is None
        assert manifest.sessions.filter.after is None

    def test_load_manifest_resolves_relative_paths(self, fixtures_dir: Path) -> None:
        """Relative paths should be resolved against manifest parent directory."""
        from raki.ground_truth.manifest import load_manifest

        manifest = load_manifest(
            fixtures_dir / "manifests" / "basic.yaml",
            project_root=fixtures_dir,
        )
        # The path ../sessions relative to manifests/ should resolve to fixtures/sessions
        expected = (fixtures_dir / "sessions").resolve()
        assert manifest.sessions.path == expected

    def test_load_manifest_path_traversal_guard(self, tmp_path: Path) -> None:
        """Paths escaping the project root must be rejected."""
        from raki.ground_truth.manifest import load_manifest

        # Create directory structure: project_root/sub/ contains the manifest
        project_root = tmp_path / "project"
        project_root.mkdir()
        sub_dir = project_root / "sub"
        sub_dir.mkdir()
        # Create sessions directory OUTSIDE the project root
        external_sessions = tmp_path / "external_sessions"
        external_sessions.mkdir()
        manifest_path = sub_dir / "raki.yaml"
        # ../../external_sessions goes: sub/ -> project/ -> tmp_path/external_sessions
        manifest_path.write_text("sessions:\n  path: ../../external_sessions\n  format: auto\n")
        with pytest.raises(ValueError, match="escapes project root"):
            load_manifest(manifest_path, project_root=project_root)

    def test_load_manifest_absolute_path_outside_root(self, tmp_path: Path) -> None:
        """Absolute paths outside project root must be rejected."""
        from raki.ground_truth.manifest import load_manifest

        external_dir = tmp_path / "external"
        external_dir.mkdir()
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        manifest_path = project_dir / "raki.yaml"
        manifest_path.write_text(f"sessions:\n  path: {external_dir}\n  format: auto\n")
        with pytest.raises(ValueError, match="escapes project root"):
            load_manifest(manifest_path)

    def test_load_manifest_project_root_defaults_to_manifest_parent(self, tmp_path: Path) -> None:
        """When project_root is not specified, it defaults to the manifest's parent."""
        from raki.ground_truth.manifest import load_manifest

        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        manifest_path = tmp_path / "raki.yaml"
        manifest_path.write_text("sessions:\n  path: sessions\n  format: auto\n")
        manifest = load_manifest(manifest_path)
        assert manifest.sessions.path == sessions_dir.resolve()

    def test_load_manifest_empty_yaml(self, tmp_path: Path) -> None:
        """Empty YAML file should raise a clear ValueError."""
        from raki.ground_truth.manifest import load_manifest

        manifest_path = tmp_path / "raki.yaml"
        manifest_path.write_text("")
        with pytest.raises(ValueError, match="YAML mapping"):
            load_manifest(manifest_path)

    def test_load_manifest_yaml_list_content(self, tmp_path: Path) -> None:
        """YAML with a list at the top level should raise a clear ValueError."""
        from raki.ground_truth.manifest import load_manifest

        manifest_path = tmp_path / "raki.yaml"
        manifest_path.write_text("- item1\n- item2\n")
        with pytest.raises(ValueError, match="YAML mapping"):
            load_manifest(manifest_path)

    def test_load_manifest_missing_sessions_key(self, tmp_path: Path) -> None:
        """YAML missing required sessions key should raise ValidationError."""
        from raki.ground_truth.manifest import load_manifest

        manifest_path = tmp_path / "raki.yaml"
        manifest_path.write_text("ground_truth:\n  path: null\n")
        with pytest.raises(ValidationError, match="sessions"):
            load_manifest(manifest_path)

    def test_load_manifest_source_path_traversal_guard(self, tmp_path: Path) -> None:
        """Source paths escaping the project root must be rejected."""
        from raki.ground_truth.manifest import load_manifest

        project_root = tmp_path / "project"
        project_root.mkdir()
        sessions_dir = project_root / "sessions"
        sessions_dir.mkdir()
        external_docs = tmp_path / "external_docs"
        external_docs.mkdir()
        manifest_path = project_root / "raki.yaml"
        manifest_path.write_text(
            f"sessions:\n  path: sessions\n  format: auto\nsources:\n  - path: {external_docs}\n"
        )
        with pytest.raises(ValueError, match="escapes project root"):
            load_manifest(manifest_path, project_root=project_root)

    def test_load_manifest_ground_truth_path_traversal_guard(self, tmp_path: Path) -> None:
        """Ground truth paths escaping the project root must be rejected."""
        from raki.ground_truth.manifest import load_manifest

        project_root = tmp_path / "project"
        project_root.mkdir()
        sessions_dir = project_root / "sessions"
        sessions_dir.mkdir()
        external_gt = tmp_path / "external_gt"
        external_gt.mkdir()
        manifest_path = project_root / "raki.yaml"
        manifest_path.write_text(
            f"sessions:\n  path: sessions\n  format: auto\nground_truth:\n  path: {external_gt}\n"
        )
        with pytest.raises(ValueError, match="escapes project root"):
            load_manifest(manifest_path, project_root=project_root)

    def test_load_manifest_synthetic_output_traversal_guard(self, tmp_path: Path) -> None:
        """Synthetic output paths escaping the project root must be rejected."""
        from raki.ground_truth.manifest import load_manifest

        project_root = tmp_path / "project"
        project_root.mkdir()
        sessions_dir = project_root / "sessions"
        sessions_dir.mkdir()
        manifest_path = project_root / "raki.yaml"
        manifest_path.write_text(
            "sessions:\n  path: sessions\n  format: auto\n"
            "synthetic:\n  enabled: true\n  output: ../outside\n"
        )
        with pytest.raises(ValueError, match="escapes project root"):
            load_manifest(manifest_path, project_root=project_root)


class TestEvalManifest:
    """Tests for EvalManifest model structure."""

    def test_manifest_name_defaults_to_empty_string(self) -> None:
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(sessions=SessionsConfig(path=Path("/tmp/sessions")))
        assert manifest.name == ""

    def test_manifest_name_can_be_set(self) -> None:
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(
            name="my-project", sessions=SessionsConfig(path=Path("/tmp/sessions"))
        )
        assert manifest.name == "my-project"

    def test_manifest_name_loaded_from_yaml(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"name: my-project\nsessions:\n  path: {sessions}\n")
        manifest = load_manifest(manifest_file)
        assert manifest.name == "my-project"

    def test_manifest_name_absent_from_yaml_defaults_to_empty(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\n")
        manifest = load_manifest(manifest_file)
        assert manifest.name == ""

    def test_manifest_has_sessions(self) -> None:
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(sessions=SessionsConfig(path=Path("/tmp/sessions")))
        assert manifest.sessions.path == Path("/tmp/sessions")

    def test_manifest_sources_default_empty(self) -> None:
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(sessions=SessionsConfig(path=Path("/tmp/sessions")))
        assert manifest.sources == []

    def test_manifest_ground_truth_default(self) -> None:
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(sessions=SessionsConfig(path=Path("/tmp/sessions")))
        assert manifest.ground_truth.path is None

    def test_manifest_synthetic_default(self) -> None:
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(sessions=SessionsConfig(path=Path("/tmp/sessions")))
        assert manifest.synthetic.enabled is False
        assert manifest.synthetic.count == 50
        assert manifest.synthetic.seed == 42


class TestSessionFilter:
    """Tests for SessionFilter model."""

    def test_filter_tickets(self) -> None:
        from raki.ground_truth.manifest import SessionFilter

        session_filter = SessionFilter(tickets=["PROJ-123", "PROJ-456"])
        assert session_filter.tickets == ["PROJ-123", "PROJ-456"]

    def test_filter_after_date(self) -> None:
        from raki.ground_truth.manifest import SessionFilter

        cutoff = datetime(2026, 1, 1, tzinfo=timezone.utc)
        session_filter = SessionFilter(after=cutoff)
        assert session_filter.after == cutoff

    def test_filter_min_phases(self) -> None:
        from raki.ground_truth.manifest import SessionFilter

        session_filter = SessionFilter(min_phases=3)
        assert session_filter.min_phases == 3


class TestDocsConfig:
    """Tests for DocsConfig and docs path validation in manifests."""

    def test_docs_config_defaults(self) -> None:
        from raki.ground_truth.manifest import DocsConfig

        config = DocsConfig(path=Path("/tmp/docs"))
        assert config.path == Path("/tmp/docs")
        assert config.extensions == [".md", ".txt"]

    def test_docs_config_custom_extensions(self) -> None:
        from raki.ground_truth.manifest import DocsConfig

        config = DocsConfig(path=Path("/tmp/docs"), extensions=[".md", ".rst"])
        assert config.extensions == [".md", ".rst"]

    def test_manifest_without_docs(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\n")
        manifest = load_manifest(manifest_file)
        assert manifest.docs is None

    def test_manifest_with_docs(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        docs = tmp_path / "docs"
        docs.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\ndocs:\n  path: {docs}\n")
        manifest = load_manifest(manifest_file)
        assert manifest.docs is not None
        assert manifest.docs.path == docs.resolve()

    def test_manifest_docs_with_extensions(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        docs = tmp_path / "docs"
        docs.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(
            f"sessions:\n  path: {sessions}\n"
            f"docs:\n  path: {docs}\n  extensions:\n    - .md\n    - .rst\n"
        )
        manifest = load_manifest(manifest_file)
        assert manifest.docs is not None
        assert manifest.docs.extensions == [".md", ".rst"]

    def test_manifest_docs_path_traversal_rejected(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        outside = tmp_path.parent / "outside_docs"
        outside.mkdir(exist_ok=True)
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\ndocs:\n  path: {outside}\n")
        with pytest.raises(ValueError, match="escapes project root"):
            load_manifest(manifest_file)

    def test_manifest_docs_relative_path(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        docs = tmp_path / "docs"
        docs.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text("sessions:\n  path: sessions\ndocs:\n  path: docs\n")
        manifest = load_manifest(manifest_file)
        assert manifest.docs is not None
        assert manifest.docs.path == docs.resolve()

    def test_manifest_docs_nonexistent_path_rejected(self, tmp_path: Path) -> None:
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text("sessions:\n  path: sessions\ndocs:\n  path: nonexistent_docs\n")
        with pytest.raises(ValueError, match="does not exist"):
            load_manifest(manifest_file)


class TestJudgeConfig:
    """Tests for JudgeConfig model and manifest-level judge configuration."""

    def test_judge_config_defaults_to_none(self) -> None:
        """JudgeConfig fields default to None when not specified."""
        from raki.ground_truth.manifest import JudgeConfig

        config = JudgeConfig()
        assert config.provider is None
        assert config.model is None

    def test_judge_config_construction(self) -> None:
        """JudgeConfig can be constructed with provider and model."""
        from raki.ground_truth.manifest import JudgeConfig

        config = JudgeConfig(provider="anthropic", model="claude-opus-4-5")
        assert config.provider == "anthropic"
        assert config.model == "claude-opus-4-5"

    def test_judge_config_has_no_docs_path_field(self) -> None:
        """JudgeConfig must not have a docs_path field."""
        from raki.ground_truth.manifest import JudgeConfig

        config = JudgeConfig(provider="anthropic", model="claude-opus-4-5")
        assert not hasattr(config, "docs_path")

    def test_manifest_judge_defaults_to_none(self) -> None:
        """EvalManifest.judge should default to None (backward compat)."""
        from raki.ground_truth.manifest import EvalManifest, SessionsConfig

        manifest = EvalManifest(sessions=SessionsConfig(path=Path("/tmp/sessions")))
        assert manifest.judge is None

    def test_manifest_judge_loaded_from_yaml(self, tmp_path: Path) -> None:
        """YAML with judge block should deserialize into JudgeConfig."""
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(
            f"sessions:\n  path: {sessions}\n"
            "judge:\n  provider: anthropic\n  model: claude-opus-4-5\n"
        )
        manifest = load_manifest(manifest_file)
        assert manifest.judge is not None
        assert manifest.judge.provider == "anthropic"
        assert manifest.judge.model == "claude-opus-4-5"

    def test_manifest_judge_absent_from_yaml_is_none(self, tmp_path: Path) -> None:
        """Manifests without a judge block should have judge=None (backward compat)."""
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\n")
        manifest = load_manifest(manifest_file)
        assert manifest.judge is None

    def test_manifest_judge_empty_block_creates_judge_config(self, tmp_path: Path) -> None:
        """YAML with ``judge: {}`` should create a JudgeConfig with None fields."""
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\njudge: {{}}\n")
        manifest = load_manifest(manifest_file)
        assert manifest.judge is not None
        assert manifest.judge.provider is None
        assert manifest.judge.model is None

    def test_manifest_judge_partial_provider_only(self, tmp_path: Path) -> None:
        """YAML with only judge.provider should leave model as None."""
        from raki.ground_truth.manifest import load_manifest

        sessions = tmp_path / "sessions"
        sessions.mkdir()
        manifest_file = tmp_path / "raki.yaml"
        manifest_file.write_text(f"sessions:\n  path: {sessions}\njudge:\n  provider: anthropic\n")
        manifest = load_manifest(manifest_file)
        assert manifest.judge is not None
        assert manifest.judge.provider == "anthropic"
        assert manifest.judge.model is None


class TestDiscoverManifest:
    """Tests for discover_manifest() function."""

    def test_discover_manifest_raki_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        raki_yaml = tmp_path / "raki.yaml"
        raki_yaml.write_text(f"sessions:\n  path: {sessions_dir}\n  format: auto\n")
        from raki.ground_truth.manifest import discover_manifest

        found = discover_manifest()
        assert found == raki_yaml

    def test_discover_manifest_eval_manifest_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        eval_yaml = tmp_path / "eval-manifest.yaml"
        eval_yaml.write_text("sessions:\n  path: ./sessions\n  format: auto\n")
        from raki.ground_truth.manifest import discover_manifest

        found = discover_manifest()
        assert found == eval_yaml

    def test_discover_manifest_prefers_raki_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When both exist, raki.yaml takes priority."""
        monkeypatch.chdir(tmp_path)
        raki_yaml = tmp_path / "raki.yaml"
        raki_yaml.write_text("sessions:\n  path: ./sessions\n  format: auto\n")
        eval_yaml = tmp_path / "eval-manifest.yaml"
        eval_yaml.write_text("sessions:\n  path: ./sessions\n  format: auto\n")
        from raki.ground_truth.manifest import discover_manifest

        found = discover_manifest()
        assert found == raki_yaml

    def test_discover_manifest_not_found(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        from raki.ground_truth.manifest import discover_manifest

        assert discover_manifest() is None
