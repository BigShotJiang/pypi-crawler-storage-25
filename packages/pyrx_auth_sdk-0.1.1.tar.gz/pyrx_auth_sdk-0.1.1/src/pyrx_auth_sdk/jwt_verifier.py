import time
from typing import Any

import httpx
import jwt
from jwt import PyJWK

from pyrx_auth_sdk.config import AuthSDKConfig
from pyrx_auth_sdk.exceptions import InvalidTokenError, JWKSFetchError, TokenExpiredError


class JWTVerifier:
    """Verifies JWTs using cached JWKS from pyrx.auth."""

    def __init__(self, config: AuthSDKConfig) -> None:
        self._config = config
        self._keys: dict[str, PyJWK] = {}
        self._last_fetched: float = 0

    def _cache_expired(self) -> bool:
        return (time.time() - self._last_fetched) > self._config.cache_ttl

    async def _fetch_jwks(self) -> None:
        """Fetch JWKS from pyrx.auth and cache the keys."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(self._config.jwks_url, timeout=10.0)
                response.raise_for_status()
                jwks_data = response.json()
        except Exception as e:
            raise JWKSFetchError(f"Failed to fetch JWKS: {e}") from e

        self._keys = {}
        for key_data in jwks_data.get("keys", []):
            kid = key_data.get("kid", "")
            if kid:
                self._keys[kid] = PyJWK(key_data)

        self._last_fetched = time.time()

    async def verify(self, token: str) -> dict[str, Any]:
        """Verify JWT signature and claims. Returns decoded payload."""
        # Decode header to get kid
        try:
            header = jwt.get_unverified_header(token)
        except jwt.exceptions.DecodeError as e:
            raise InvalidTokenError(f"Malformed JWT: {e}") from e

        kid = header.get("kid", "")

        # Fetch JWKS if cache miss or expired
        if kid not in self._keys or self._cache_expired():
            await self._fetch_jwks()

        if kid not in self._keys:
            raise InvalidTokenError(f"Unknown key ID: {kid}")

        try:
            decode_kwargs: dict[str, Any] = {
                "algorithms": ["ES256"],
                "issuer": self._config.issuer,
            }
            if self._config.audience:
                decode_kwargs["audience"] = self._config.audience
            else:
                decode_kwargs["options"] = {"verify_aud": False}

            payload: dict[str, Any] = jwt.decode(
                token,
                self._keys[kid].key,
                **decode_kwargs,
            )
            return payload
        except jwt.ExpiredSignatureError as e:
            raise TokenExpiredError("Token has expired") from e
        except jwt.InvalidTokenError as e:
            raise InvalidTokenError(str(e)) from e
