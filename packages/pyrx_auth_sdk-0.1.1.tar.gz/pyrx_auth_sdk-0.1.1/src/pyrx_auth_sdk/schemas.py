import uuid

from pydantic import BaseModel


class AuthenticatedUser(BaseModel):
    """User extracted from a verified JWT."""

    id: uuid.UUID
    tenant_id: uuid.UUID
    email: str | None = None
    email_verified: bool = False
    display_name: str | None = None
    scope: str = ""
    jti: str = ""
