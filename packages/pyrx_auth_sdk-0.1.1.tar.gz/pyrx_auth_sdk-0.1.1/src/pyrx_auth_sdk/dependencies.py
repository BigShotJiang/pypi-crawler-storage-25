"""FastAPI dependency for extracting authenticated user from JWT.

Usage:
    from pyrx_auth_sdk.dependencies import get_current_user
    from pyrx_auth_sdk.schemas import AuthenticatedUser

    @router.get("/protected")
    async def protected(user: AuthenticatedUser = Depends(get_current_user)):
        ...

Requires pyrx-auth-sdk[fastapi] to be installed.
"""

from uuid import UUID

from pyrx_auth_sdk.config import AuthSDKConfig
from pyrx_auth_sdk.jwt_verifier import JWTVerifier
from pyrx_auth_sdk.schemas import AuthenticatedUser

_verifier: JWTVerifier | None = None


def init_auth(config: AuthSDKConfig) -> None:
    """Initialize the JWT verifier with config. Call once at app startup."""
    global _verifier
    _verifier = JWTVerifier(config)


async def get_current_user(authorization: str = "") -> AuthenticatedUser:
    """FastAPI dependency: extract and verify JWT from Authorization header."""
    if _verifier is None:
        raise RuntimeError("pyrx-auth-sdk not initialized. Call init_auth() at startup.")

    if not authorization.startswith("Bearer "):
        from pyrx_auth_sdk.exceptions import InvalidTokenError

        raise InvalidTokenError("Missing or invalid Authorization header")

    token = authorization[7:]
    payload = await _verifier.verify(token)

    return AuthenticatedUser(
        id=UUID(payload["sub"]),
        tenant_id=UUID(payload["tid"]),
        email=payload.get("email"),
        email_verified=payload.get("ev", False),
        display_name=payload.get("name"),
        scope=payload.get("scope", ""),
        jti=payload.get("jti", ""),
    )
