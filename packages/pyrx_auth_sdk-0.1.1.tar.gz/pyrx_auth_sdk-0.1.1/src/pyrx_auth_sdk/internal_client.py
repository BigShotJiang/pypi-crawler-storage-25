"""Async HTTP client for pyrx.auth internal API."""

import uuid
from typing import Any

import httpx

from pyrx_auth_sdk.config import AuthSDKConfig
from pyrx_auth_sdk.exceptions import InternalAPIError


class AuthInternalClient:
    """Client for pyrx.auth /internal/* endpoints."""

    def __init__(self, config: AuthSDKConfig) -> None:
        self._base_url = config.internal_api_url.rstrip("/")
        self._api_key = config.internal_api_key

    def _headers(self) -> dict[str, str]:
        return {"X-Internal-Api-Key": self._api_key}

    async def get_user(self, user_id: uuid.UUID) -> dict[str, Any]:
        """Get user by ID."""
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self._base_url}/api/v1/internal/users/{user_id}",
                headers=self._headers(),
                timeout=10.0,
            )
            if response.status_code == 404:
                raise InternalAPIError(f"User {user_id} not found")
            if response.status_code >= 400:
                raise InternalAPIError(f"Internal API error: {response.status_code}")
            result: dict[str, Any] = response.json()["data"]
            return result

    async def get_user_by_email(self, email: str, tenant_id: uuid.UUID) -> dict[str, Any]:
        """Get user by email within a tenant."""
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self._base_url}/api/v1/internal/users/by-email/{email}",
                params={"tenant_id": str(tenant_id)},
                headers=self._headers(),
                timeout=10.0,
            )
            if response.status_code == 404:
                raise InternalAPIError(f"User with email {email} not found")
            if response.status_code >= 400:
                raise InternalAPIError(f"Internal API error: {response.status_code}")
            result: dict[str, Any] = response.json()["data"]
            return result

    async def get_users_batch(self, user_ids: list[str]) -> tuple[list[dict[str, Any]], list[str]]:
        """Get multiple users by IDs. Returns (users, not_found)."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self._base_url}/api/v1/internal/users/batch",
                json={"user_ids": user_ids},
                headers=self._headers(),
                timeout=10.0,
            )
            if response.status_code >= 400:
                raise InternalAPIError(f"Internal API error: {response.status_code}")
            data = response.json()["data"]
            users: list[dict[str, Any]] = data["users"]
            not_found: list[str] = data["not_found"]
            return users, not_found
