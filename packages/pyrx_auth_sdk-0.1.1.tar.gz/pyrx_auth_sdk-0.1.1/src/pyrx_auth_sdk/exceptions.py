class AuthSDKError(Exception):
    """Base exception for pyrx-auth-sdk."""


class InvalidTokenError(AuthSDKError):
    """JWT is invalid or malformed."""


class TokenExpiredError(AuthSDKError):
    """JWT has expired."""


class JWKSFetchError(AuthSDKError):
    """Failed to fetch JWKS from pyrx.auth."""


class EventConsumerError(AuthSDKError):
    """Error consuming events from Redis Stream."""


class InternalAPIError(AuthSDKError):
    """Error calling pyrx.auth internal API."""
