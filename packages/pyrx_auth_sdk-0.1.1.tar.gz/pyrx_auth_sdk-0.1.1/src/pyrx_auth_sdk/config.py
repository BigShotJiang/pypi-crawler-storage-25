from pydantic import BaseModel


class AuthSDKConfig(BaseModel):
    """Configuration for pyrx-auth-sdk."""

    jwks_url: str = "http://localhost:8001/api/v1/.well-known/jwks.json"
    issuer: str = "pyrx.auth"
    audience: str = ""
    cache_ttl: int = 300  # 5 minutes
    events_stream: str = "pyrx:auth:events"
    internal_api_url: str = "http://localhost:8001"
    internal_api_key: str = ""
