"""Redis Stream consumer for pyrx.auth user lifecycle events."""

import contextlib
import json
from collections.abc import Awaitable, Callable
from typing import Any

import redis.asyncio as aioredis
import structlog

from pyrx_auth_sdk.config import AuthSDKConfig

logger = structlog.get_logger()

EventHandler = Callable[[dict[str, Any]], Awaitable[None]]


class UserEventConsumer:
    """Consumes user lifecycle events from pyrx.auth Redis Stream."""

    def __init__(
        self,
        redis: aioredis.Redis,  # type: ignore[type-arg]
        group_name: str,
        consumer_name: str,
        config: AuthSDKConfig | None = None,
    ) -> None:
        self._redis = redis
        self._group_name = group_name
        self._consumer_name = consumer_name
        self._stream = (config or AuthSDKConfig()).events_stream
        self._handlers: dict[str, EventHandler] = {}
        self._running = False

    def on(self, event_type: str, handler: EventHandler) -> None:
        """Register a handler for a specific event type."""
        self._handlers[event_type] = handler

    async def _ensure_group(self) -> None:
        """Create consumer group if it doesn't exist."""
        with contextlib.suppress(Exception):
            await self._redis.xgroup_create(  # type: ignore[misc]
                self._stream, self._group_name, id="0", mkstream=True
            )

    async def run(self, block_ms: int = 5000, count: int = 100) -> None:
        """Run the consumer loop. Blocks until stopped."""
        await self._ensure_group()
        self._running = True

        while self._running:
            try:
                events = await self._redis.xreadgroup(  # type: ignore[misc]
                    groupname=self._group_name,
                    consumername=self._consumer_name,
                    streams={self._stream: ">"},
                    count=count,
                    block=block_ms,
                )

                if not events:
                    continue

                for _stream_name, messages in events:
                    for msg_id, data in messages:
                        await self._process_message(msg_id, data)

            except Exception:
                logger.exception("event_consumer_error", group=self._group_name)

    async def _process_message(self, msg_id: str, data: dict[str, str]) -> None:
        """Process a single event message."""
        event_type = data.get("type", "")
        handler = self._handlers.get(event_type)

        if handler is None:
            logger.debug("event_no_handler", event_type=event_type, msg_id=msg_id)
        else:
            try:
                payload = json.loads(data.get("payload", "{}"))
                await handler(payload)
            except Exception:
                logger.exception("event_handler_error", event_type=event_type, msg_id=msg_id)

        # Acknowledge regardless of handler success (dead letter handling deferred)
        await self._redis.xack(self._stream, self._group_name, msg_id)  # type: ignore[misc]

    def stop(self) -> None:
        """Stop the consumer loop."""
        self._running = False
