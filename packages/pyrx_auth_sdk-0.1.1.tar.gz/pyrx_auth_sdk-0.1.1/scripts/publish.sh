#!/bin/bash
# Publish pyrx-auth-sdk package to PyPI
#
# Usage:
#   ./scripts/publish.sh              # Bump patch version and publish to PyPI
#   ./scripts/publish.sh --minor      # Bump minor version and publish
#   ./scripts/publish.sh --major      # Bump major version and publish
#   ./scripts/publish.sh --no-bump    # Publish current version (no bump)
#   ./scripts/publish.sh --test       # Publish to TestPyPI
#   ./scripts/publish.sh --build-only # Build wheel without publishing
#
# Environment variables (auto-loaded from .env if present):
#   PYPI_TOKEN        - PyPI API token (for PyPI)
#   TEST_PYPI_TOKEN   - TestPyPI API token (for --test)
#
# Prerequisites:
#   pip install build twine

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

# Load .env file if it exists (check SDK dir and parent repo)
if [ -f ".env" ]; then
    set -a
    source .env
    set +a
elif [ -f "../.env" ]; then
    set -a
    source ../.env
    set +a
fi

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Parse arguments
TARGET="pypi"
BUILD_ONLY=false
BUMP_TYPE="patch"

while [[ $# -gt 0 ]]; do
    case $1 in
        --patch)   BUMP_TYPE="patch"; shift ;;
        --minor)   BUMP_TYPE="minor"; shift ;;
        --major)   BUMP_TYPE="major"; shift ;;
        --no-bump) BUMP_TYPE="none"; shift ;;
        --test)    TARGET="testpypi"; shift ;;
        --build-only) BUILD_ONLY=true; shift ;;
        --help|-h)
            echo "Usage: $0 [--patch|--minor|--major|--no-bump] [--test|--build-only]"
            echo ""
            echo "Version options:"
            echo "  --patch       Bump patch version (default): 0.1.0 -> 0.1.1"
            echo "  --minor       Bump minor version: 0.1.0 -> 0.2.0"
            echo "  --major       Bump major version: 0.1.0 -> 1.0.0"
            echo "  --no-bump     Don't bump version, publish current"
            echo ""
            echo "Target options:"
            echo "  --test        Publish to TestPyPI"
            echo "  --build-only  Build wheel without publishing"
            echo ""
            echo "Environment variables (auto-loaded from .env):"
            echo "  PYPI_TOKEN       PyPI API token"
            echo "  TEST_PYPI_TOKEN  TestPyPI API token"
            exit 0
            ;;
        *) log_error "Unknown option: $1"; exit 1 ;;
    esac
done

# Check prerequisites
log_info "Checking prerequisites..."
if ! command -v python3 &> /dev/null && ! command -v python &> /dev/null; then
    log_error "Python is not installed"
    exit 1
fi

PYTHON=$(command -v python3 || command -v python)
$PYTHON -m pip install --quiet --upgrade build twine

# Get current version
get_version() {
    $PYTHON -c "
try:
    import tomllib
except ImportError:
    import pip._vendor.tomli as tomllib
print(tomllib.load(open('pyproject.toml', 'rb'))['project']['version'])
"
}

# Bump version
bump_version() {
    local bump_type=$1
    $PYTHON -c "
import re
with open('pyproject.toml', 'r') as f:
    content = f.read()
match = re.search(r'version = \"(\d+)\.(\d+)\.(\d+)\"', content)
if not match:
    print('ERROR: Could not find version in pyproject.toml')
    exit(1)
major, minor, patch = int(match.group(1)), int(match.group(2)), int(match.group(3))
if '$bump_type' == 'major':
    major += 1; minor = 0; patch = 0
elif '$bump_type' == 'minor':
    minor += 1; patch = 0
else:
    patch += 1
new_version = f'{major}.{minor}.{patch}'
new_content = re.sub(r'version = \"\d+\.\d+\.\d+\"', f'version = \"{new_version}\"', content)
with open('pyproject.toml', 'w') as f:
    f.write(new_content)
print(new_version)
"
}

CURRENT_VERSION=$(get_version)

if [ "$BUMP_TYPE" != "none" ]; then
    log_info "Current version: $CURRENT_VERSION"
    VERSION=$(bump_version "$BUMP_TYPE")
    log_info "Bumped to version: $VERSION ($BUMP_TYPE)"
else
    VERSION=$CURRENT_VERSION
    log_info "Using current version: $VERSION"
fi

# Clean and build
log_info "Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info

log_info "Building package..."
$PYTHON -m build

if [ "$BUILD_ONLY" = true ]; then
    log_info "Build complete. Files in dist/:"
    ls -la dist/
    exit 0
fi

# Publish
case $TARGET in
    pypi)
        log_info "Publishing to PyPI..."
        if [ -z "$PYPI_TOKEN" ]; then
            log_error "PYPI_TOKEN environment variable is not set"
            log_info "Get your token from: https://pypi.org/manage/account/token/"
            exit 1
        fi
        $PYTHON -m twine upload dist/* \
            --username __token__ \
            --password "$PYPI_TOKEN"
        log_info "Published to PyPI: https://pypi.org/project/pyrx-auth-sdk/$VERSION/"
        log_info "Install with: pip install pyrx-auth-sdk"
        ;;
    testpypi)
        log_info "Publishing to TestPyPI..."
        if [ -z "$TEST_PYPI_TOKEN" ]; then
            log_error "TEST_PYPI_TOKEN environment variable is not set"
            log_info "Get your token from: https://test.pypi.org/manage/account/token/"
            exit 1
        fi
        $PYTHON -m twine upload dist/* \
            --repository testpypi \
            --username __token__ \
            --password "$TEST_PYPI_TOKEN"
        log_info "Published to TestPyPI: https://test.pypi.org/project/pyrx-auth-sdk/$VERSION/"
        log_info "Install with: pip install --index-url https://test.pypi.org/simple/ pyrx-auth-sdk"
        ;;
esac

# Commit version bump
if [ "$BUMP_TYPE" != "none" ]; then
    log_info "Committing version bump..."
    git add pyproject.toml
    git commit -m "chore: bump pyrx-auth-sdk version to $VERSION"
    git push
    log_info "Pushed version $VERSION to git"
fi

log_info "Done!"
