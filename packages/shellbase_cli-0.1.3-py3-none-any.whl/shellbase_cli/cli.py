import datetime
import json
import os
import signal
import shutil
import socket
import sys
import subprocess
from pathlib import Path

import click
import httpx

CONFIG_DIR = Path.home() / ".shellbase-cli"
CONFIG_PATH = CONFIG_DIR / "relay_config.json"
PID_PATH = CONFIG_DIR / "relay_agent.pid"
LOG_PATH = Path.home() / ".shellbase-cli" / "relay_agent.log"


def load_config(path: Path) -> dict:
    if not path.exists():
        raise RuntimeError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


@click.group()
def main():
    """ShellBase CLI for relay registration and agent management."""


@main.group()
def server():
    """Server management commands."""


@server.command(name="up")
@click.option("--backend-url", default="https://webssh-backend.artim-industries.com", show_default=True, help="Backend base URL")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", required=True, help="Team ID to attach the server to")
@click.option("--name", required=True, help="Server name")
@click.option("--host", required=True, help="Server host address")
@click.option("--port", default=22, show_default=True, help="SSH port for the server")
@click.option("--username", required=True, help="SSH username for the server")
@click.option("--auth-type", type=click.Choice(["ssh-key", "password"], case_sensitive=False), default="ssh-key", show_default=True, help="Authentication method for the server")
@click.option("--auth-value", default=None, help="SSH password or private key text")
@click.option("--auth-value-file", default=None, help="Path to SSH private key file when using ssh-key authentication")
@click.option("--relay-id", default=None, help="Optional relay ID to use for server SSH tunnel")
@click.option("--tags", default=None, help="Comma-separated tags for the server")
@click.option("--os", "os_name", default="unknown", show_default=True, help="Operating system label for the server")
def server_up(
    backend_url,
    email,
    password,
    team_id,
    name,
    host,
    port,
    username,
    auth_type,
    auth_value,
    auth_value_file,
    relay_id,
    tags,
    os_name,
):
    backend_url = _format_backend_url(backend_url)
    auth_value = _read_auth_value(auth_value, auth_value_file, auth_type)

    click.echo("Logging in to backend…")
    token = login(backend_url, email, password)

    click.echo("Registering server…")
    server = create_server(
        backend_url,
        token,
        team_id,
        name,
        host,
        port,
        username,
        auth_type,
        auth_value,
        relay_id,
        _parse_tags(tags),
        os_name,
    )
    server_id = server.get("_id") or server.get("id")
    if not server_id:
        raise click.ClickException("Backend did not return a server ID")

    click.echo(f"Server created: {server.get('name')} ({server_id})")
    if relay_id:
        click.echo(f"Relay attached: {relay_id}")

    click.echo("Refreshing server state…")
    refresh_team_servers(backend_url, token, team_id)
    updated_server = get_team_server(backend_url, token, team_id, server_id)

    click.echo("Server registration complete.")
    click.echo(f"Server status: {updated_server.get('status')}" )
    click.echo(f"Server host: {updated_server.get('host')}:{updated_server.get('port')}")
    if updated_server.get('relayId'):
        click.echo(f"Using relay: {updated_server.get('relayId')}")


def _format_backend_url(url: str | None) -> str:
    backend_url = url or "https://webssh-backend.artim-industries.com"
    return backend_url.rstrip("/")


def _is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


def _check_relay_requirements(local_host: str, local_port: int, install_cron: bool) -> None:
    if _is_windows():
        raise click.ClickException(
            "Windows is not supported for relay registration. Please use macOS or Linux."
        )

    try:
        with socket.create_connection((local_host, local_port), timeout=3):
            pass
    except Exception as exc:
        raise click.ClickException(
            f"Unable to connect to local target {local_host}:{local_port}. "
            f"Ensure the target service is running and reachable before registering a relay. "
            f"Error: {exc}"
        ) from exc

    if install_cron and shutil.which("crontab") is None:
        raise click.ClickException(
            "Cron is required to install the relay startup job, but 'crontab' was not found in PATH. "
            "Install cron or use --no-install-cron to skip startup registration."
        )


def _parse_tags(tags: str | None) -> list[str]:
    if not tags:
        return []
    return [tag.strip() for tag in tags.split(",") if tag.strip()]


def _read_auth_value(auth_value: str | None, auth_value_file: str | None, auth_type: str) -> str:
    if auth_value_file:
        path = Path(auth_value_file).expanduser()
        if not path.exists():
            raise click.ClickException(f"Auth value file not found: {path}")
        return path.read_text(encoding="utf-8").strip()

    if auth_value:
        return auth_value

    if auth_type == "password":
        return click.prompt("SSH password", hide_input=True)

    raise click.ClickException(
        "Missing auth value. Provide --auth-value or --auth-value-file when using ssh-key or password authentication."
    )


def create_server(
    backend_url: str,
    token: str,
    team_id: str,
    name: str,
    host: str,
    port: int,
    username: str,
    auth_type: str,
    auth_value: str,
    relay_id: str | None,
    tags: list[str],
    os_name: str,
) -> dict:
    url = f"{backend_url}/api/teams/{team_id}/servers"
    payload = {
        "name": name,
        "host": host,
        "port": port,
        "username": username,
        "authType": auth_type,
        "authValue": auth_value,
        "status": "offline",
        "tags": tags,
        "os": os_name,
        "relayId": relay_id,
        "relayName": None,
        "createdAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    with httpx.Client(timeout=20.0) as client:
        response = client.post(
            url,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json=payload,
        )
    response.raise_for_status()
    return response.json()


def refresh_team_servers(backend_url: str, token: str, team_id: str) -> list[dict]:
    url = f"{backend_url}/api/teams/{team_id}/servers/refresh"
    with httpx.Client(timeout=60.0) as client:
        response = client.post(url, headers=_cli_headers(token))
    response.raise_for_status()
    return response.json()


def get_team_server(backend_url: str, token: str, team_id: str, server_id: str) -> dict:
    url = f"{backend_url}/api/teams/{team_id}/servers/{server_id}"
    with httpx.Client(timeout=20.0) as client:
        response = client.get(url, headers=_cli_headers(token))
    response.raise_for_status()
    return response.json()


def _cli_headers(token: str | None = None, content_type: bool = False) -> dict[str, str]:
    headers: dict[str, str] = {"X-Shellbase-Cli": "1"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if content_type:
        headers["Content-Type"] = "application/json"
    return headers


def login(backend_url: str, email: str, password: str) -> str:
    url = f"{backend_url}/api/auth/login"
    headers = _cli_headers()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(url, data={"username": email, "password": password}, headers=headers)
    response.raise_for_status()
    return response.json()["access_token"]


def create_relay(backend_url: str, token: str, team_id: str, name: str, description: str, local_host: str, local_port: int) -> dict:
    url = f"{backend_url}/api/teams/{team_id}/relays"
    with httpx.Client(timeout=20.0) as client:
        response = client.post(
            url,
            headers=_cli_headers(token, content_type=True),
            json={
                "name": name,
                "description": description,
                "localHost": local_host,
                "localPort": local_port,
                "enabled": True,
            },
        )
    response.raise_for_status()
    return response.json()


def get_relay_agent_token(backend_url: str, token: str, team_id: str, relay_id: str) -> str:
    url = f"{backend_url}/api/teams/{team_id}/relays/{relay_id}/agent-token"
    with httpx.Client(timeout=20.0) as client:
        response = client.get(url, headers=_cli_headers(token))
    _raise_for_status_with_detail(response)
    payload = response.json()
    ws_token = payload.get("wsToken")
    if not ws_token:
        raise RuntimeError("Backend did not return relay wsToken")
    return ws_token


def install_cron_entry(command: str) -> None:
    try:
        existing = subprocess.run(["crontab", "-l"], capture_output=True, text=True, check=False)
        lines = existing.stdout.splitlines() if existing.returncode == 0 else []
        if command in lines:
            return
        lines.append(command)
        subprocess.run(["crontab", "-"], input="\n".join(lines) + "\n", text=True, check=True)
    except Exception as exc:
        raise RuntimeError(f"Unable to install cron job: {exc}") from exc


def remove_cron_entry(command: str) -> None:
    try:
        existing = subprocess.run(["crontab", "-l"], capture_output=True, text=True, check=False)
        if existing.returncode != 0:
            return
        lines = existing.stdout.splitlines()
        next_lines = [line for line in lines if line.strip() != command.strip()]
        if len(next_lines) == len(lines):
            return
        subprocess.run(["crontab", "-"], input="\n".join(next_lines) + "\n", text=True, check=True)
    except Exception as exc:
        raise RuntimeError(f"Unable to remove cron job: {exc}") from exc


def _raise_for_status_with_detail(response: httpx.Response) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        detail = None
        try:
            detail_json = response.json()
            detail = detail_json.get("detail") or detail_json
        except Exception:
            detail = response.text
        raise RuntimeError(
            f"HTTP {response.status_code} {response.reason_phrase}: {detail}"
        ) from exc


def delete_relay(backend_url: str, token: str, team_id: str, relay_id: str) -> None:
    url = f"{backend_url}/api/teams/{team_id}/relays/{relay_id}"
    with httpx.Client(timeout=20.0) as client:
        response = client.delete(url, headers=_cli_headers(token))
    _raise_for_status_with_detail(response)


@main.command()
@click.option("--backend-url", default="https://webssh-backend.artim-industries.com", show_default=True, help="Backend base URL e.g. https://example.com")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", default=None, help="Team ID where relay is registered")
@click.option("--remove-cron/--no-remove-cron", default=True, help="Remove relay agent cron job")
@click.option("--remove-config/--no-remove-config", default=True, help="Remove local relay config file")
def remove(backend_url, email, password, team_id, remove_cron, remove_config):
    backend_url = _format_backend_url(backend_url)
    click.echo("Logging in to backend…")
    token = login(backend_url, email, password)

    config = load_config(CONFIG_PATH)
    relay_id = config.get("relayId")
    if not relay_id:
        raise click.ClickException("Relay ID not found in config")

    if not team_id:
        team_id = config.get("teamId")
    if not team_id:
        raise click.ClickException("Missing team ID. Pass --team-id or re-register the relay with teamId stored in config.")

    click.echo(f"Removing relay {relay_id} from team {team_id}…")
    delete_relay(backend_url, token, team_id, relay_id)
    click.echo("Relay removed from backend.")

    if remove_cron:
        python_path = sys.executable
        command = f"@reboot {python_path} -m shellbase_cli.agent --config {CONFIG_PATH} >> {LOG_PATH} 2>&1"
        remove_cron_entry(command)
        click.echo("Removed cron job.")

    if PID_PATH.exists():
        try:
            pid = int(PID_PATH.read_text().strip())
            if _is_process_running(pid):
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False)
                else:
                    os.kill(pid, signal.SIGTERM)
                click.echo(f"Stopped relay agent (PID {pid}).")
        except Exception:
            pass
        finally:
            PID_PATH.unlink(missing_ok=True)

    if remove_config and CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
        click.echo(f"Removed config file {CONFIG_PATH}.")

    click.echo("Relay remove complete.")


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
@click.option("--remove-cron/--no-remove-cron", default=True, help="Remove relay agent cron job")
@click.option("--remove-pid/--no-remove-pid", default=True, help="Stop running agent and delete local PID file")
@click.option("--remove-config/--no-remove-config", default=True, help="Remove local relay config file")
def clear(config, remove_cron, remove_pid, remove_config):
    config_path = Path(config).expanduser()

    if remove_cron:
        python_path = sys.executable
        command = f"@reboot {python_path} -m shellbase_cli.agent --config {config_path} >> {LOG_PATH} 2>&1"
        remove_cron_entry(command)
        click.echo("Removed cron job.")

    if remove_pid and PID_PATH.exists():
        try:
            pid = int(PID_PATH.read_text().strip())
            if _is_process_running(pid):
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False)
                else:
                    os.kill(pid, signal.SIGTERM)
                click.echo(f"Stopped relay agent (PID {pid}).")
        except Exception:
            pass
        finally:
            PID_PATH.unlink(missing_ok=True)
            click.echo(f"Removed PID file {PID_PATH}.")

    if remove_config and config_path.exists():
        config_path.unlink()
        click.echo(f"Removed config file {config_path}.")

    click.echo("Local relay state cleared.")


@main.command()
@click.option("--backend-url", default="https://webssh-backend.artim-industries.com", show_default=True, help="Backend base URL")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", required=True, help="Team ID to attach the relay to")
@click.option("--name", required=True, help="Relay name")
@click.option("--description", default="", help="Optional relay description")
@click.option("--local-host", default="127.0.0.1", show_default=True, help="Local host accessible by the relay agent")
@click.option("--local-port", default=22, show_default=True, help="Local port to use for tunneled connections")
@click.option("--install-cron/--no-install-cron", default=True, help="Install @reboot cron job for the relay agent")
def register_relay(backend_url, email, password, team_id, name, description, local_host, local_port, install_cron):
    backend_url = _format_backend_url(backend_url)

    _check_relay_requirements(local_host, local_port, install_cron)

    click.echo("Logging in to backend…")
    token = login(backend_url, email, password)

    click.echo("Registering relay…")
    relay = create_relay(backend_url, token, team_id, name, description, local_host, local_port)
    relay_id = relay.get("_id") or relay.get("id")
    if not relay_id:
        raise click.ClickException("Backend did not return relay id")
    ws_token = get_relay_agent_token(backend_url, token, team_id, relay_id)

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config = {
        "backendUrl": backend_url,
        "token": token,
        "teamId": team_id,
        "relayId": relay_id,
        "wsToken": ws_token,
    }
    CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")

    click.echo(f"Relay registered: {relay.get('name')} ({config['relayId']})")
    click.echo(f"Saved agent config to {CONFIG_PATH}")

    if install_cron:
        python_path = sys.executable
        command = f"@reboot {python_path} -m shellbase_cli.agent --config {CONFIG_PATH} >> {LOG_PATH} 2>&1"
        install_cron_entry(command)
        click.echo("Installed cron job to start the relay agent on reboot.")

    click.echo("Relay CLI setup is complete.")


@main.command(name="refresh-agent-token")
@click.option("--backend-url",  default="https://webssh-backend.artim-industries.com", show_default=True, help="Backend base URL e.g. https://example.com")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", default=None, help="Team ID where relay is registered")
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def refresh_agent_token(backend_url, email, password, team_id, config):
    config_path = Path(config).expanduser()
    cfg = load_config(config_path)

    resolved_backend_url = _format_backend_url(backend_url or cfg.get("backendUrl", ""))
    if not resolved_backend_url:
        raise click.ClickException("Missing backend URL. Pass --backend-url or store backendUrl in config.")

    relay_id = cfg.get("relayId")
    if not relay_id:
        raise click.ClickException("Relay ID not found in config")

    resolved_team_id = team_id or cfg.get("teamId")
    if not resolved_team_id:
        raise click.ClickException("Missing team ID. Pass --team-id or store teamId in config.")

    click.echo("Logging in to backend…")
    user_token = login(resolved_backend_url, email, password)
    ws_token = get_relay_agent_token(resolved_backend_url, user_token, resolved_team_id, relay_id)

    cfg["backendUrl"] = resolved_backend_url
    cfg["teamId"] = resolved_team_id
    cfg["token"] = user_token
    cfg["wsToken"] = ws_token
    config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

    click.echo(f"Updated relay wsToken in {config_path}")
    click.echo("Run `shellbase-cli down` and `shellbase-cli up` to reconnect the agent.")


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def run_agent(config):
    config_path = Path(config).expanduser()
    if not config_path.exists():
        raise click.ClickException(f"Config file not found: {config_path}")
    os.execvp(sys.executable, [sys.executable, "-m", "shellbase_cli.agent", "--config", str(config_path)])


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def up(config):
    config_path = Path(config).expanduser()
    try:
        load_config(config_path)
    except Exception as exc:
        raise click.ClickException(str(exc)) from exc

    if PID_PATH.exists():
        try:
            pid = int(PID_PATH.read_text().strip())
            if _is_process_running(pid):
                click.echo(f"Relay agent is already running (PID {pid}).")
                return
        except Exception:
            pass

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as log_handle:
        process = subprocess.Popen(
            [sys.executable, "-m", "shellbase_cli.agent", "--config", str(config_path)],
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            close_fds=True,
        )

    PID_PATH.write_text(str(process.pid), encoding="utf-8")
    click.echo(f"Started relay agent in background (PID {process.pid}).")
    click.echo(f"Logs are appended to {LOG_PATH}")


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def down(config):
    config_path = Path(config).expanduser()
    if not config_path.exists():
        raise click.ClickException(f"Config file not found: {config_path}")
    if not PID_PATH.exists():
        click.echo("Relay agent is not running.")
        return

    try:
        pid = int(PID_PATH.read_text().strip())
    except Exception:
        PID_PATH.unlink(missing_ok=True)
        raise click.ClickException("Invalid PID file, removed stale PID record.")

    if not _is_process_running(pid):
        PID_PATH.unlink(missing_ok=True)
        click.echo("Relay agent is not running.")
        return

    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False)
        else:
            os.kill(pid, signal.SIGTERM)
        click.echo(f"Stopped relay agent (PID {pid}).")
    except Exception as exc:
        raise click.ClickException(f"Unable to stop relay agent: {exc}") from exc
    finally:
        PID_PATH.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
