"""CLI for framework scaffold introspection and runtime export planning."""

import argparse
import json
from pathlib import Path
from typing import Any, Optional

from fedops_vlm_framework.core.e2e_setup import setup_end_to_end
from fedops_vlm_framework.core.runtime import ExportRequest
from fedops_vlm_framework.core.runtime_registry import RUNTIME_BACKENDS
from fedops_vlm_framework.core.registry import (
    DATASET_PLUGINS,
    DEPLOYMENT_PLUGINS,
    MODEL_PLUGINS,
)


def _print_plugins(title: str, plugins: dict):
    print(f"{title}:")
    for key, plugin in plugins.items():
        print(f"  - {key}: {plugin.describe()}")


def _parse_runtime_options(pairs: list[str]) -> dict[str, str]:
    runtime_options: dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"Invalid runtime option '{pair}', expected KEY=VALUE format.")
        key, value = pair.split("=", maxsplit=1)
        key = key.strip()
        value = value.strip()
        if not key:
            raise ValueError(f"Invalid runtime option '{pair}', empty key.")
        runtime_options[key] = value
    return runtime_options


def _load_plan_config(path: Optional[str]) -> dict[str, Any]:
    if not path:
        return {}
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Plan config must be a JSON object.")
    return payload


def _coerce_runtime_options(value: Any) -> dict[str, str]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return {str(k): str(v) for k, v in value.items()}
    if isinstance(value, list):
        return _parse_runtime_options([str(item) for item in value])
    raise ValueError("runtime_options must be an object or list of KEY=VALUE strings.")


def _coerce_int(name: str, value: Any, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    raise ValueError(f"{name} must be an integer, got: {value!r}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--list",
        action="store_true",
        help="List registered framework plugins.",
    )
    parser.add_argument(
        "--list-runtimes",
        action="store_true",
        help="List runtime backends for post-FL export/deployment planning.",
    )
    parser.add_argument(
        "--export-plan-runtime",
        choices=sorted(RUNTIME_BACKENDS.keys()),
        help="Generate export plan JSON for selected runtime backend.",
    )
    parser.add_argument(
        "--plan-config",
        help=(
            "Optional JSON config file for runtime planning. "
            "Fields mirror export request schema, e.g. runtime/base_model/adapter_dir/output_dir."
        ),
    )
    parser.add_argument(
        "--save-plan",
        help="Optional output file path to save generated runtime plan JSON.",
    )
    parser.add_argument("--base-model", help="Base HF model id/path for merge/export.")
    parser.add_argument("--adapter-dir", help="Path to federated adapter directory.")
    parser.add_argument("--output-dir", help="Path to output export root.")
    parser.add_argument(
        "--device-profile",
        default="samsung_a24",
        help="Device profile label attached to the export plan.",
    )
    parser.add_argument(
        "--quantization",
        default="q4f16_0",
        help="Default quantization token used by runtime backend plan.",
    )
    parser.add_argument(
        "--context-window-size",
        type=int,
        default=768,
        help="Requested context window size used in plan generation.",
    )
    parser.add_argument(
        "--image-size",
        type=int,
        default=224,
        help="Requested image size used in plan generation.",
    )
    parser.add_argument(
        "--runtime-option",
        action="append",
        default=[],
        help="Runtime-specific override in KEY=VALUE format; can be repeated.",
    )
    parser.add_argument(
        "--setup-e2e",
        action="store_true",
        help="Generate runnable end-to-end setup bundle (scripts + manifest).",
    )
    parser.add_argument(
        "--track",
        choices=["mlc-compatible", "onevision-research"],
        default="mlc-compatible",
        help="Track profile used by --setup-e2e.",
    )
    parser.add_argument(
        "--workspace-root",
        help="Workspace root path; if omitted, auto-discovered from current directory.",
    )
    parser.add_argument(
        "--e2e-output-dir",
        help="Optional output directory for setup bundle. Default: timestamped exports folder.",
    )
    args = parser.parse_args()

    if args.list:
        _print_plugins("Model plugins", MODEL_PLUGINS)
        _print_plugins("Dataset plugins", DATASET_PLUGINS)
        _print_plugins("Deployment plugins", DEPLOYMENT_PLUGINS)
        return

    if args.list_runtimes:
        _print_plugins("Runtime backends", RUNTIME_BACKENDS)
        return

    if args.export_plan_runtime or args.plan_config:
        config = _load_plan_config(args.plan_config)
        runtime_name = args.export_plan_runtime or config.get("runtime")
        if not runtime_name:
            parser.error("Missing runtime: pass --export-plan-runtime or set 'runtime' in --plan-config.")
        if runtime_name not in RUNTIME_BACKENDS:
            parser.error(
                f"Unknown runtime '{runtime_name}'. Available: {', '.join(sorted(RUNTIME_BACKENDS))}"
            )
        required = {
            "base_model": args.base_model or config.get("base_model"),
            "adapter_dir": args.adapter_dir or config.get("adapter_dir"),
            "output_dir": args.output_dir or config.get("output_dir"),
        }
        missing = [name for name, value in required.items() if not value]
        if missing:
            parser.error(
                "Missing arguments for runtime planning: "
                + ", ".join(f"--{name.replace('_', '-')}" for name in missing)
            )

        config_runtime_options = _coerce_runtime_options(config.get("runtime_options"))
        cli_runtime_options = _parse_runtime_options(args.runtime_option)
        runtime_options = {**config_runtime_options, **cli_runtime_options}

        backend = RUNTIME_BACKENDS[runtime_name]
        request = ExportRequest(
            base_model=str(required["base_model"]),
            adapter_dir=Path(str(required["adapter_dir"])).resolve(),
            output_dir=Path(str(required["output_dir"])).resolve(),
            device_profile=str(config.get("device_profile", args.device_profile)),
            quantization=str(config.get("quantization", args.quantization)),
            context_window_size=_coerce_int(
                "context_window_size",
                config.get("context_window_size", args.context_window_size),
                args.context_window_size,
            ),
            image_size=_coerce_int(
                "image_size",
                config.get("image_size", args.image_size),
                args.image_size,
            ),
            runtime_options=runtime_options,
        )
        plan = backend.build_export_plan(request)
        plan_json = json.dumps(plan.to_dict(), indent=2)
        if args.save_plan:
            save_path = Path(args.save_plan).resolve()
            save_path.parent.mkdir(parents=True, exist_ok=True)
            save_path.write_text(plan_json + "\n", encoding="utf-8")
        print(plan_json)
        return

    if args.setup_e2e:
        out_dir = setup_end_to_end(
            track=args.track,
            workspace_root=Path(args.workspace_root).resolve() if args.workspace_root else None,
            output_dir=Path(args.e2e_output_dir).resolve() if args.e2e_output_dir else None,
        )
        print(f"Created end-to-end setup bundle: {out_dir}")
        print(f"Next: run {out_dir}/scripts/00_verify_env.sh")
        return

    print("FedOps VLM framework scaffold")
    print("Use --list, --list-runtimes, --export-plan-runtime, or --setup-e2e.")


if __name__ == "__main__":
    main()
