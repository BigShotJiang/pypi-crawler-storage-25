"""Federated strategy for VLM fine-tuning."""

from collections.abc import Iterable
from logging import INFO, WARN
from typing import Optional, Tuple

from flwr.app import ArrayRecord, ConfigRecord, Message, MetricRecord
from flwr.common import log
from flwr.serverapp import Grid
from flwr.serverapp.strategy import FedAvg


class FedOpsVlmStrategy(FedAvg):
    """FedAvg with communication-cost tracking and periodic evaluation.

    Drop-in replacement for FedAvg that:
    - Logs cumulative MB per round, warns at 200 GB FlowerTune budget
    - Runs client evaluation only every eval_every_n_rounds (default 5)
      so 50-round runs don't spend 80% of time on inference
    """

    def __init__(self, eval_every_n_rounds: int = 5, total_rounds: int = 10, **kwargs):
        super().__init__(**kwargs)
        self.comm_tracker = CommunicationTracker()
        self.eval_every_n_rounds = eval_every_n_rounds
        self.total_rounds = total_rounds

    def configure_train(
        self, server_round: int, arrays: ArrayRecord, config: ConfigRecord, grid: Grid
    ) -> Iterable[Message]:
        messages = super().configure_train(server_round, arrays, config, grid)
        self.comm_tracker.track(messages)
        return messages

    def aggregate_train(
        self,
        server_round: int,
        replies: Iterable[Message],
    ) -> Tuple[Optional[ArrayRecord], Optional[MetricRecord]]:
        self.comm_tracker.track(replies)
        return super().aggregate_train(server_round, replies)

    def configure_evaluate(
        self, server_round: int, arrays: ArrayRecord, config: ConfigRecord, grid: Grid
    ) -> Iterable[Message]:
        """Only dispatch eval clients on checkpoint rounds (every N rounds + final)."""
        is_eval_round = (
            server_round % self.eval_every_n_rounds == 0
            or server_round == self.total_rounds
        )
        if not is_eval_round:
            log(INFO, "Skipping eval round %d (next eval at round %d)",
                server_round,
                server_round + (self.eval_every_n_rounds - server_round % self.eval_every_n_rounds),
            )
            return []
        return super().configure_evaluate(server_round, arrays, config, grid)

    def aggregate_evaluate(
        self,
        server_round: int,
        replies: Iterable[Message],
    ) -> Optional[MetricRecord]:
        metrics = super().aggregate_evaluate(server_round, replies)
        if metrics is not None:
            exact = metrics.get("exact_match", None)
            contains = metrics.get("contains_match", None)
            if exact is not None:
                log(
                    INFO,
                    "Eval round %d — exact_match=%.4f  contains_match=%.4f",
                    server_round,
                    float(exact),
                    float(contains) if contains is not None else 0.0,
                )
        return metrics


class CommunicationTracker:
    """Accumulate train communication volume across FL rounds."""

    def __init__(self):
        self.curr_comm_cost_mb = 0.0

    def track(self, messages: Iterable[Message]) -> None:
        comm_cost_mb = (
            sum(
                record.count_bytes()
                for msg in messages
                if msg.has_content()
                for record in msg.content.array_records.values()
            )
            / 1024**2
        )
        self.curr_comm_cost_mb += comm_cost_mb
        log(
            INFO,
            "Communication budget: used %.2f MB (+%.2f MB this round)",
            self.curr_comm_cost_mb,
            comm_cost_mb,
        )
        if self.curr_comm_cost_mb > 2e5:
            log(
                WARN,
                "Communication exceeded 200,000 MB; consider smaller adapters or fewer clients.",
            )
