"""Unified ClientApp for federated VLM fine-tuning.

Reads model.plugin and dataset.plugin from pyproject.toml config,
looks them up in the plugin registry, and runs the FL training loop.

To add a new model:  add one file to plugins/models/, register in core/registry.py
To add a new dataset: add one file to plugins/datasets/, register in core/registry.py
No changes needed here.
"""

import gc
import logging
import os
import re
import string
import warnings

from flwr.app import ArrayRecord, Context, Message, MetricRecord, RecordDict
from flwr.clientapp import ClientApp
from flwr.common.config import unflatten_dict
from omegaconf import DictConfig
from PIL import Image
import torch
from torch.utils.data import DataLoader

from fedops_vlm_framework.core.config_utils import override_config_with_env_vars, replace_keys
from fedops_vlm_framework.core.models import (
    cosine_annealing,
    get_trainable_state_dict,
    load_trainable_state_dict,
)
from fedops_vlm_framework.core.registry import DATASET_PLUGINS, MODEL_PLUGINS


# ------------------------------------------------------------------ #
# VQA evaluation helpers
# ------------------------------------------------------------------ #

def _normalize_answer(text: str) -> str:
    """VQA-style normalisation: lowercase, strip punctuation and articles."""
    text = str(text).lower().strip()
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\b(a|an|the)\b", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _build_eval_prompt(processor, question: str) -> str:
    """Build inference-mode prompt (no answer appended)."""
    question = str(question).strip()
    if hasattr(processor, "apply_chat_template"):
        conversation = [
            {
                "role": "user",
                "content": [{"type": "image"}, {"type": "text", "text": question}],
            }
        ]
        try:
            return processor.apply_chat_template(
                conversation, tokenize=False, add_generation_prompt=True
            )
        except Exception:
            pass
    return f"<image>\nQuestion: {question}\nAnswer:"


def _prepare_eval_image(image_obj) -> Image.Image:
    if isinstance(image_obj, Image.Image):
        return image_obj.convert("RGB").resize((224, 224))
    raise TypeError(f"Unsupported image type: {type(image_obj)}")

logging.basicConfig(level=logging.INFO)
warnings.filterwarnings("ignore", category=UserWarning)
os.environ.setdefault("TOKENIZERS_PARALLELISM", "true")

app = ClientApp()


@app.train()
def train(msg: Message, context: Context):
    """Run one FL local-training round for this client partition."""
    run_config = dict(context.run_config)
    run_config = override_config_with_env_vars(run_config, "FEDOPS_VLM_CONFIG_")
    cfg = DictConfig(replace_keys(unflatten_dict(run_config)))

    # ------------------------------------------------------------------ #
    # Plugin resolution — this is the key difference from the old projects/
    # Instead of hardcoded imports, we look up from the registry.
    # ------------------------------------------------------------------ #
    model_plugin_name = str(getattr(cfg.model, "plugin", "onevision"))
    dataset_plugin_name = str(getattr(cfg.dataset, "plugin", "vqa_rad"))

    if model_plugin_name not in MODEL_PLUGINS:
        raise ValueError(
            f"Unknown model plugin '{model_plugin_name}'. "
            f"Available: {list(MODEL_PLUGINS.keys())}"
        )
    if dataset_plugin_name not in DATASET_PLUGINS:
        raise ValueError(
            f"Unknown dataset plugin '{dataset_plugin_name}'. "
            f"Available: {list(DATASET_PLUGINS.keys())}"
        )

    model_plugin = MODEL_PLUGINS[model_plugin_name]
    dataset_plugin = DATASET_PLUGINS[dataset_plugin_name]

    # ------------------------------------------------------------------ #
    # Partition setup
    # ------------------------------------------------------------------ #
    partition_id = int(
        os.environ.get("FEDOPS_PARTITION_ID", context.node_config.get("partition-id", 0))
    )
    num_partitions = int(
        os.environ.get(
            "FEDOPS_NUM_PARTITIONS",
            context.node_config.get("num-partitions", 1),
        )
    )
    logging.info(
        "FL client train: partition=%s/%s node=%s model=%s dataset=%s",
        partition_id, num_partitions, context.node_id,
        model_plugin_name, dataset_plugin_name,
    )

    # ------------------------------------------------------------------ #
    # Load data via dataset plugin
    # ------------------------------------------------------------------ #
    trainset = dataset_plugin.load_partition(
        partition_id=partition_id,
        num_partitions=num_partitions,
        split="train",
    )

    # ------------------------------------------------------------------ #
    # Load model + processor via model plugin
    # ------------------------------------------------------------------ #
    model, processor = model_plugin.load(cfg.model)
    global_partial_state = msg.content["arrays"].to_torch_state_dict()
    load_trainable_state_dict(model, global_partial_state)

    # ------------------------------------------------------------------ #
    # DataLoader with plugin-provided collate function
    # ------------------------------------------------------------------ #
    collate_fn = dataset_plugin.get_collate_fn(
        processor=processor,
        max_length=int(cfg.train.max_length),
    )
    trainloader = DataLoader(
        trainset,
        batch_size=int(cfg.train.per_device_train_batch_size),
        shuffle=True,
        num_workers=2,
        collate_fn=collate_fn,
    )

    # ------------------------------------------------------------------ #
    # Training loop
    # ------------------------------------------------------------------ #
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.train()

    num_rounds = int(cfg.num_server_rounds)
    server_round = int(msg.content["config"]["server-round"])
    current_lr = cosine_annealing(
        current_round=server_round,
        total_round=max(num_rounds, 1),
        lrate_max=float(cfg.train.learning_rate_max),
        lrate_min=float(cfg.train.learning_rate_min),
    )

    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=current_lr,
    )

    grad_acc_steps = int(cfg.train.gradient_accumulation_steps)
    max_steps = int(cfg.train.max_steps_per_round)
    local_epochs = int(getattr(cfg.train, "local_epochs", 1))

    total_loss = 0.0
    seen_steps = 0
    optimizer.zero_grad(set_to_none=True)

    for _ in range(max(local_epochs, 1)):
        for batch in trainloader:
            if seen_steps >= max_steps:
                break
            batch = {
                k: v.to(device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }
            outputs = model(**batch)
            loss = outputs.loss / grad_acc_steps
            loss.backward()

            current_step = seen_steps + 1
            if current_step % grad_acc_steps == 0:
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)

            total_loss += float(loss.detach().item() * grad_acc_steps)
            seen_steps = current_step
        if seen_steps >= max_steps:
            break

    # Final optimizer step if gradient accumulation left a remainder
    if seen_steps > 0 and seen_steps % grad_acc_steps != 0:
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)

    avg_train_loss = total_loss / max(seen_steps, 1)

    model_record = ArrayRecord(get_trainable_state_dict(model))
    metric_record = MetricRecord({
        "train_loss": avg_train_loss,
        "num-examples": len(trainset),
        "num-steps": seen_steps,
        "learning-rate": current_lr,
    })

    content = RecordDict({"arrays": model_record, "metrics": metric_record})
    return Message(content=content, reply_to=msg)


@app.evaluate()
def evaluate(msg: Message, context: Context):
    """Client-side evaluation — VQA inference with exact match + contains match.

    Metrics returned per client (aggregated server-side by weighted average):
      exact_match      — strict normalised string equality (VQA accuracy)
      contains_match   — gold answer contained in prediction (lenient)
      num-examples     — number of samples evaluated (used as weight)

    Evaluation uses the test split when available, falls back to train split.
    Capped at train.max-eval-samples (default 50) per client for speed.
    """
    run_config = dict(context.run_config)
    run_config = override_config_with_env_vars(run_config, "FEDOPS_VLM_CONFIG_")
    cfg = DictConfig(replace_keys(unflatten_dict(run_config)))

    model_plugin_name = str(getattr(cfg.model, "plugin", "onevision"))
    dataset_plugin_name = str(getattr(cfg.dataset, "plugin", "vqa_rad"))

    if model_plugin_name not in MODEL_PLUGINS or dataset_plugin_name not in DATASET_PLUGINS:
        metric_record = MetricRecord({"num-examples": 0, "exact_match": 0.0, "contains_match": 0.0})
        return Message(content=RecordDict({"metrics": metric_record}), reply_to=msg)

    model_plugin = MODEL_PLUGINS[model_plugin_name]
    dataset_plugin = DATASET_PLUGINS[dataset_plugin_name]

    partition_id = int(
        os.environ.get("FEDOPS_PARTITION_ID", context.node_config.get("partition-id", 0))
    )
    num_partitions = int(
        os.environ.get("FEDOPS_NUM_PARTITIONS", context.node_config.get("num-partitions", 1))
    )
    max_eval_samples = int(getattr(cfg.train, "max_eval_samples", 50))

    logging.info(
        "FL client evaluate: partition=%s/%s model=%s dataset=%s max_samples=%s",
        partition_id, num_partitions, model_plugin_name, dataset_plugin_name, max_eval_samples,
    )

    # Load validation data — prefer test split, fall back to train
    try:
        valset = dataset_plugin.load_partition(partition_id, num_partitions, split="test")
    except Exception:
        valset = dataset_plugin.load_partition(partition_id, num_partitions, split="train")

    if len(valset) > max_eval_samples:
        valset = valset.shuffle(seed=42).select(range(max_eval_samples))

    # Load model with global aggregated weights
    model, processor = model_plugin.load(cfg.model)
    global_partial_state = msg.content["arrays"].to_torch_state_dict()
    load_trainable_state_dict(model, global_partial_state)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    exact_hits = 0
    contains_hits = 0

    with torch.no_grad():
        for sample in valset:
            try:
                image = _prepare_eval_image(sample["image"])
                question = str(sample["question"])
                gold = _normalize_answer(str(sample["answer"]))
                prompt = _build_eval_prompt(processor, question)

                inputs = processor(
                    images=[image],
                    text=[prompt],
                    return_tensors="pt",
                    padding=True,
                )
                inputs = {k: v.to(device) if hasattr(v, "to") else v for k, v in inputs.items()}

                generated = model.generate(
                    **inputs,
                    max_new_tokens=16,
                    do_sample=False,
                    pad_token_id=getattr(processor.tokenizer, "pad_token_id", None),
                    eos_token_id=getattr(processor.tokenizer, "eos_token_id", None),
                )
                input_len = int(inputs["input_ids"].shape[1]) if "input_ids" in inputs else 0
                completion = generated[:, input_len:]
                pred = _normalize_answer(
                    processor.tokenizer.batch_decode(completion, skip_special_tokens=True)[0]
                )

                if gold and pred == gold:
                    exact_hits += 1
                if gold and gold in pred:
                    contains_hits += 1
            except Exception as exc:
                logging.warning("Eval sample failed: %s", exc)

    n = len(valset)
    exact_match = exact_hits / max(n, 1)
    contains_match = contains_hits / max(n, 1)

    logging.info(
        "FL client eval done: exact_match=%.4f contains_match=%.4f n=%d",
        exact_match, contains_match, n,
    )

    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    metric_record = MetricRecord({
        "num-examples": n,
        "exact_match": exact_match,
        "contains_match": contains_match,
    })
    content = RecordDict({"metrics": metric_record})
    return Message(content=content, reply_to=msg)
