"""OneVision deployment research plugin."""


class OneVisionResearchDeploymentPlugin:
    """Deployment plugin for experimental OneVision path."""

    name = "onevision_research"

    def describe(self) -> str:
        return "Experimental deployment path requiring MLC onevision support work."

