"""MLC-compatible deployment plugin."""


class MlcCompatibleDeploymentPlugin:
    """Deployment plugin for supported MLC model families."""

    name = "mlc_compatible"

    def describe(self) -> str:
        return "Deployment path via MLC template for supported VLMs (phiva/llava)."

