"""VQA-RAD dataset plugin — flaviagiammarino/vqa-rad."""

from collections.abc import Callable
from typing import Any

from datasets import Dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn, load_partition


class VQARadDatasetPlugin:
    """Healthcare-focused VQA dataset plugin.

    VQA-RAD contains radiology images paired with clinical questions and answers.
    Suitable for medical federated VLM fine-tuning.

    HuggingFace: flaviagiammarino/vqa-rad
    Columns after normalization: image, question, answer

    To use: set dataset.plugin = "vqa_rad" in pyproject.toml.
    """

    name = "vqa_rad"
    hf_dataset = "flaviagiammarino/vqa-rad"

    def describe(self) -> str:
        return (
            "VQA-RAD — radiology image/question/answer dataset for medical VQA. "
            "Used as the default dataset for mlc-compatible and onevision-research tracks."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID partition of VQA-RAD.

        Returns Dataset with columns: image, question, answer.
        """
        return load_partition(
            partition_id=partition_id,
            num_partitions=num_partitions,
            dataset_name=self.hf_dataset,
            split=split,
        )

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return the standard VLM multimodal collate function."""
        return get_vlm_collate_fn(processor, max_length)
