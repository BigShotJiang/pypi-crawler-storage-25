"""Legal DocVQA dataset plugin — Rickkosse/dutch-legal-docvqa.

Legal documents are a natural FL use case: law firms, courts, and government bodies
cannot share case files centrally, yet all benefit from a VLM that can read and
reason over legal documents (court decisions, contracts, case filings).

Note: this dataset contains Dutch-language legal documents (Centrale Raad van Beroep
court decisions). The VLM will learn visual document layout + Dutch legal text patterns.
For multilingual legal FL research, this is an interesting non-English benchmark.
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn, load_partition


class LegalDocVQADatasetPlugin:
    """Legal document VQA dataset plugin.

    Contains Dutch court decision document images paired with questions and answers.
    Ideal for federated learning across legal institutions where case files are
    confidential and cannot be centralized.

    HuggingFace: Rickkosse/dutch-legal-docvqa
    Columns: image (PNG), question (str), answers (list → normalized to str)
    Core dataset.py handles answers list → answer str normalization automatically.

    To use: set dataset.plugin = "legal_docvqa" in pyproject.toml.
    """

    name = "legal_docvqa"
    hf_dataset = "Rickkosse/dutch-legal-docvqa"

    def describe(self) -> str:
        return (
            "Legal DocVQA — Dutch court decision documents with Q&A. "
            "Natural FL use case: law firms and courts cannot share case files centrally."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID shard of Legal DocVQA.

        Returns Dataset with columns: image, question, answer.
        answers list is normalized to a single string by core/dataset.py.
        """
        return load_partition(
            partition_id=partition_id,
            num_partitions=num_partitions,
            dataset_name=self.hf_dataset,
            split=split,
        )

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return the standard VLM multimodal collate function."""
        return get_vlm_collate_fn(processor, max_length)
