"""Finance VQA dataset plugin — sujet-ai/sujet-finance-qa-vision-100k.

Financial documents are a natural FL use case: banks, insurance companies, and
investment firms cannot share client financial records, yet all benefit from a
shared VLM that can read charts, statements, and recommendation memos.

This plugin uses the sujet-ai/sujet-finance-qa-vision-100k dataset which contains
100K financial document images with qa_pairs (question/answer extracted per doc).
The core dataset.py handles qa_pairs explosion and direct loading automatically.
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn, load_partition


class FinanceVQADatasetPlugin:
    """Financial document VQA dataset plugin.

    Contains financial charts, reports, recommendation memos, and statements
    paired with Q&A. Ideal for federated learning across financial institutions
    where data cannot leave the institution's premises.

    HuggingFace: sujet-ai/sujet-finance-qa-vision-100k
    Columns after normalization: image, question, answer
    (Core dataset.py handles qa_pairs JSON → row-per-question explosion)

    To use: set dataset.plugin = "finance_vqa" in pyproject.toml.
    """

    name = "finance_vqa"
    hf_dataset = "sujet-ai/sujet-finance-qa-vision-100k"

    def describe(self) -> str:
        return (
            "Finance VQA — 100K financial document images (charts, statements, memos) "
            "with Q&A pairs. Natural FL use case: banks cannot share client records."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID shard of Finance VQA.

        Returns Dataset with columns: image, question, answer.
        qa_pairs JSON strings are exploded to one row per question by core/dataset.py.
        """
        return load_partition(
            partition_id=partition_id,
            num_partitions=num_partitions,
            dataset_name=self.hf_dataset,
            split=split,
        )

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return the standard VLM multimodal collate function."""
        return get_vlm_collate_fn(processor, max_length)
