"""VQAv2 dataset plugin — landersanmi/VQAv2."""

from collections.abc import Callable
from typing import Any

from datasets import Dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn, load_partition


class VQAv2DatasetPlugin:
    """General-purpose VQA dataset plugin.

    VQAv2 is a large-scale visual question answering dataset with natural images.
    Good for general VLM fine-tuning and benchmarking.

    HuggingFace: landersanmi/VQAv2
    Columns after normalization: image, question, answer

    To use: set dataset.plugin = "vqav2" in pyproject.toml.
    """

    name = "vqav2"
    hf_dataset = "landersanmi/VQAv2"

    def describe(self) -> str:
        return (
            "VQAv2 — large-scale natural image VQA dataset. "
            "General-purpose benchmark for federated VLM fine-tuning."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID partition of VQAv2.

        Returns Dataset with columns: image, question, answer.
        """
        return load_partition(
            partition_id=partition_id,
            num_partitions=num_partitions,
            dataset_name=self.hf_dataset,
            split=split,
        )

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return the standard VLM multimodal collate function."""
        return get_vlm_collate_fn(processor, max_length)

