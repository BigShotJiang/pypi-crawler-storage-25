"""MLC runtime backend planning."""

from fedops_vlm_framework.core.runtime import ExportPlan, ExportRequest


class MlcRuntimeBackend:
    """Runtime backend for MLC conversion/packaging workflow."""

    name = "mlc"

    def describe(self) -> str:
        return "MLC deployment path (convert_weight/gen_config/compile)."

    def build_export_plan(self, request: ExportRequest) -> ExportPlan:
        export_root = request.output_dir
        merged_dir = export_root / "merged_hf"
        mlc_dist = export_root / f"{request.device_profile}_mlc_dist"

        commands = [
            "python scripts/export_adapter_for_mobile.py "
            f"--base-model {request.base_model} "
            f"--adapter-dir {request.adapter_dir} "
            f"--output-dir {merged_dir}",
            "python -m mlc_llm convert_weight "
            f"{merged_dir} --quantization {request.quantization} "
            f"--output {mlc_dist} --model-type auto",
            "python -m mlc_llm gen_config "
            f"{merged_dir} --quantization {request.quantization} "
            f"--context-window-size {request.context_window_size} "
            f"--output {mlc_dist}",
            "python -m mlc_llm compile "
            f"{mlc_dist}/mlc-chat-config.json --device android "
            f"--output {mlc_dist}/model-android.tar",
        ]

        notes = [
            "Use your OneVision-specific model-type only after full runtime parity exists.",
            "For Samsung A24, keep image_size/context_window_size conservative.",
        ]

        return ExportPlan(
            runtime=self.name,
            summary="Plan FL adapter merge + MLC conversion and Android compile.",
            commands=commands,
            expected_artifacts=[
                str(merged_dir / "config.json"),
                str(mlc_dist / "ndarray-cache.json"),
                str(mlc_dist / "mlc-chat-config.json"),
                str(mlc_dist / "model-android.tar"),
            ],
            notes=notes,
            request=request.to_dict(),
        )

