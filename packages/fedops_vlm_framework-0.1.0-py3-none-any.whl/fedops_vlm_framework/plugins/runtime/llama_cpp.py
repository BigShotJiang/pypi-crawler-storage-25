"""llama.cpp runtime backend planning."""

from fedops_vlm_framework.core.runtime import ExportPlan, ExportRequest


class LlamaCppRuntimeBackend:
    """Runtime backend for llama.cpp GGUF conversion workflow."""

    name = "llama_cpp"

    def describe(self) -> str:
        return "llama.cpp deployment path (HF merge -> GGUF -> quantize)."

    def build_export_plan(self, request: ExportRequest) -> ExportPlan:
        export_root = request.output_dir
        merged_dir = export_root / "merged_hf"
        gguf_dir = export_root / "gguf"
        quant = request.runtime_options.get("gguf_quant", "Q4_K_M")

        commands = [
            "python scripts/export_adapter_for_mobile.py "
            f"--base-model {request.base_model} "
            f"--adapter-dir {request.adapter_dir} "
            f"--output-dir {merged_dir}",
            "python <LLAMA_CPP_ROOT>/convert_hf_to_gguf.py "
            f"{merged_dir} --outfile {gguf_dir}/model-f16.gguf --outtype f16",
            "cd <LLAMA_CPP_ROOT> && ./llama-quantize "
            f"{gguf_dir}/model-f16.gguf {gguf_dir}/model-{quant.lower()}.gguf {quant}",
        ]

        notes = [
            "Set <LLAMA_CPP_ROOT> to your local llama.cpp checkout.",
            "If the model is VLM, include the required mmproj artifact in runtime packaging.",
            "Quantization token here is llama.cpp style (e.g., Q4_K_M), not MLC token.",
        ]

        return ExportPlan(
            runtime=self.name,
            summary="Plan FL adapter merge + llama.cpp GGUF conversion and quantization.",
            commands=commands,
            expected_artifacts=[
                str(merged_dir / "config.json"),
                str(gguf_dir / "model-f16.gguf"),
                str(gguf_dir / f"model-{quant.lower()}.gguf"),
            ],
            notes=notes,
            request=request.to_dict(),
        )

