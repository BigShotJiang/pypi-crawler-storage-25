"""Plugin namespaces."""

