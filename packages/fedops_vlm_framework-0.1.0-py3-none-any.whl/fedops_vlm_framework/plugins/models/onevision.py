"""OneVision model plugin — llava-hf/llava-onevision-qwen2-0.5b-ov-hf."""

from collections.abc import Callable
from typing import Any

from omegaconf import DictConfig

from fedops_vlm_framework.core.models import load_model_and_processor


class OneVisionModelPlugin:
    """Research-track VLM plugin for LLaVA-OneVision-Qwen2-0.5B.

    OneVision is the recommended model for fast FL research iteration.
    Lightweight (0.5B), good capability, runs comfortably on a single GPU.
    Not MLC-deployable out of the box — use for research, switch to
    mlc-compatible (phiva) track for mobile deployment.

    To use: set model.plugin = "onevision" in pyproject.toml.
    The model.name field can override the default base model.
    """

    name = "onevision"
    base_model = "llava-hf/llava-onevision-qwen2-0.5b-ov-hf"

    def describe(self) -> str:
        return (
            "LLaVA-OneVision-Qwen2 0.5B — fast research track. "
            "Good capability, low VRAM, ideal for FL iteration before mobile deployment."
        )

    def load(self, model_cfg: DictConfig, force_cpu: bool = False) -> tuple[Any, Any]:
        """Load OneVision + processor with LoRA and vision freezing.

        Falls back to self.base_model if model_cfg.name is not set.
        force_cpu=True is used by the server for checkpoint saving.
        """
        if not getattr(model_cfg, "name", None):
            from omegaconf import OmegaConf
            model_cfg = OmegaConf.merge(model_cfg, {"name": self.base_model})
        return load_model_and_processor(model_cfg, force_cpu=force_cpu)

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return the standard VLM multimodal collate function."""
        from fedops_vlm_framework.core.dataset import get_vlm_collate_fn
        return get_vlm_collate_fn(processor, max_length)
