"""PhiVA model plugin — nota-ai/phiva-4b-hf."""

from collections.abc import Callable
from typing import Any

from omegaconf import DictConfig

from fedops_vlm_framework.core.models import load_model_and_processor


class PhivaModelPlugin:
    """MLC-compatible VLM plugin for the PhiVA 4B model family.

    PhiVA is MLC-deployable and targets the Samsung A24 mobile profile.
    Handles the PhiVA-specific num_additional_image_tokens processor patch
    automatically via core/models.py patch_processor_for_vlm().

    To use: set model.plugin = "phiva" in pyproject.toml.
    The model.name field can override the default base model.
    """

    name = "phiva"
    base_model = "nota-ai/phiva-4b-hf"

    def describe(self) -> str:
        return (
            "PhiVA 4B — MLC-compatible VLM for mobile deployment (Samsung A24 target). "
            "Handles PhiVA processor token-count quirk automatically."
        )

    def load(self, model_cfg: DictConfig, force_cpu: bool = False) -> tuple[Any, Any]:
        """Load PhiVA + processor with LoRA and vision freezing.

        Falls back to self.base_model if model_cfg.name is not set.
        PhiVA-specific processor patch (num_additional_image_tokens=1)
        is applied inside load_model_and_processor via model name detection.
        force_cpu=True is used by the server for checkpoint saving.
        """
        if not getattr(model_cfg, "name", None):
            from omegaconf import OmegaConf
            model_cfg = OmegaConf.merge(model_cfg, {"name": self.base_model})
        return load_model_and_processor(model_cfg, force_cpu=force_cpu)

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return the standard VLM multimodal collate function."""
        from fedops_vlm_framework.core.dataset import get_vlm_collate_fn
        return get_vlm_collate_fn(processor, max_length)
