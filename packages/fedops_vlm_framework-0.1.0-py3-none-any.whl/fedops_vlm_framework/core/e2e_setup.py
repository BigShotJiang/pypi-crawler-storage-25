"""Generate end-to-end framework setup bundles (scripts + plan metadata)."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
import json
from pathlib import Path
from typing import Dict, Optional


@dataclass
class TrackProfile:
    """Track-specific defaults for end-to-end setup."""

    track: str
    base_model: str
    model_type: str
    conv_template: str
    project_dir: Path
    mlc_repo_dir: Path
    device_profile: str = "samsung_a24"
    quantization: str = "q4f16_0"
    context_window_size: int = 768
    image_size: int = 224


def _discover_workspace_root(start: Path) -> Path:
    cur = start.resolve()
    for candidate in [cur] + list(cur.parents):
        if (candidate / "fedops-vlm").is_dir():
            return candidate
        if candidate.name == "fedops-vlm":
            return candidate.parent
    return cur


def _profiles(workspace_root: Path) -> Dict[str, TrackProfile]:
    fedops_root = workspace_root / "fedops-vlm"
    return {
        "mlc-compatible": TrackProfile(
            track="mlc-compatible",
            base_model="nota-ai/phiva-4b-hf",
            model_type="phiva",
            conv_template="phiva",
            project_dir=fedops_root / "projects" / "mlc-compatible",
            mlc_repo_dir=fedops_root / "MLC-VLM-template",
        ),
        "onevision-research": TrackProfile(
            track="onevision-research",
            base_model="llava-hf/llava-onevision-qwen2-0.5b-ov-hf",
            model_type="llava_onevision",
            conv_template="llava",
            project_dir=fedops_root / "projects" / "onevision-research",
            mlc_repo_dir=fedops_root / "MLC-VLM-template-onevision",
        ),
    }


def _default_output_dir(workspace_root: Path, track: str) -> Path:
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    return workspace_root / "fedops-vlm" / "exports" / f"framework_setup_{track}_{ts}"


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _jsonify(obj):
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, dict):
        return {k: _jsonify(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_jsonify(v) for v in obj]
    return obj


def _script_header() -> str:
    return "#!/usr/bin/env bash\nset -euo pipefail\n\n"


def _make_00_verify(profile: TrackProfile, env_activate: Path, framework_dir: Path) -> str:
    return (
        _script_header()
        + f"source {env_activate}\n"
        + "python -V\n"
        + "which flwr || true\n"
        + "which adb || true\n"
        + f"cd {framework_dir}\n"
        + "python -m fedops_vlm_framework.cli --list\n"
        + "python -m fedops_vlm_framework.cli --list-runtimes\n"
    )


def _make_01_train(profile: TrackProfile, env_activate: Path) -> str:
    return (
        _script_header()
        + f"source {env_activate}\n"
        + f"cd {profile.project_dir}\n"
        + "pip install -e .\n"
        + 'flwr run . --stream "$@"\n'
    )


def _make_02_export(profile: TrackProfile, env_activate: Path) -> str:
    return (
        _script_header()
        + "RUN_DIR=${1:-}\n"
        + 'if [[ -z "${RUN_DIR}" ]]; then echo "Usage: $0 <run_dir> [adapter_name]"; exit 1; fi\n'
        + 'ADAPTER_NAME=${2:-adapter_10}\n'
        + 'ADAPTER_DIR="${RUN_DIR}/${ADAPTER_NAME}"\n'
        + 'EXPORT_DIR="${RUN_DIR}/mobile_export_${ADAPTER_NAME}"\n'
        + f"source {env_activate}\n"
        + f"cd {profile.project_dir}\n"
        + "python scripts/export_adapter_for_mobile.py "
        + f"--base-model {profile.base_model} "
        + '--adapter-dir "${ADAPTER_DIR}" '
        + '--output-dir "${EXPORT_DIR}" '
        + "--trust-remote-code\n"
        + "python scripts/check_mlc_compat.py --export-dir \"${EXPORT_DIR}\" || true\n"
    )


def _make_03_plan(
    profile: TrackProfile, env_activate: Path, framework_dir: Path, plans_dir: Path
) -> str:
    return (
        _script_header()
        + "RUN_DIR=${1:-}\n"
        + 'if [[ -z "${RUN_DIR}" ]]; then echo "Usage: $0 <run_dir> [adapter_name]"; exit 1; fi\n'
        + 'ADAPTER_NAME=${2:-adapter_10}\n'
        + 'ADAPTER_DIR="${RUN_DIR}/${ADAPTER_NAME}"\n'
        + 'OUT_DIR="${RUN_DIR}/e2e_export_bundle"\n'
        + f"source {env_activate}\n"
        + f"cd {framework_dir}\n"
        + "python -m fedops_vlm_framework.cli "
        + "--export-plan-runtime mlc "
        + f"--base-model {profile.base_model} "
        + '--adapter-dir "${ADAPTER_DIR}" '
        + '--output-dir "${OUT_DIR}" '
        + f"--device-profile {profile.device_profile} "
        + f"--quantization {profile.quantization} "
        + f"--context-window-size {profile.context_window_size} "
        + f"--image-size {profile.image_size} "
        + f'> "{plans_dir}/plan_mlc.json"\n'
        + "python -m fedops_vlm_framework.cli "
        + "--export-plan-runtime llama_cpp "
        + f"--base-model {profile.base_model} "
        + '--adapter-dir "${ADAPTER_DIR}" '
        + '--output-dir "${OUT_DIR}" '
        + "--runtime-option gguf_quant=Q4_K_M "
        + f'> "{plans_dir}/plan_llama_cpp.json"\n'
        + f'echo "Saved runtime plans under {plans_dir}"\n'
    )


def _make_04_mlc(profile: TrackProfile, env_activate: Path) -> str:
    return (
        _script_header()
        + "RUN_DIR=${1:-}\n"
        + 'if [[ -z "${RUN_DIR}" ]]; then echo "Usage: $0 <run_dir> [adapter_name]"; exit 1; fi\n'
        + 'ADAPTER_NAME=${2:-adapter_10}\n'
        + 'EXPORT_DIR="${RUN_DIR}/mobile_export_${ADAPTER_NAME}"\n'
        + 'OUT_DIR="${RUN_DIR}/mlc_out_${ADAPTER_NAME}"\n'
        + f"source {env_activate}\n"
        + f"cd {profile.mlc_repo_dir}\n"
        + "if [[ -f scripts/onevision_env.sh ]]; then source scripts/onevision_env.sh; fi\n"
        + "python -m mlc_llm convert_weight "
        + '"${EXPORT_DIR}" '
        + f"--quantization {profile.quantization} "
        + '--output "${OUT_DIR}" '
        + f"--model-type {profile.model_type} "
        + "--device cpu\n"
        + "python -m mlc_llm gen_config "
        + '"${EXPORT_DIR}" '
        + f"--quantization {profile.quantization} "
        + f"--model-type {profile.model_type} "
        + f"--conv-template {profile.conv_template} "
        + f"--context-window-size {profile.context_window_size} "
        + '--output "${OUT_DIR}"\n'
        + "python -m mlc_llm compile "
        + '"${OUT_DIR}/mlc-chat-config.json" '
        + "--device android "
        + '--output "${OUT_DIR}/model-android.tar"\n'
    )


def _make_05_metrics() -> str:
    return (
        _script_header()
        + 'PKG=${1:-}\n'
        + 'if [[ -z "${PKG}" ]]; then echo "Usage: $0 <android.package.name>"; exit 1; fi\n'
        + 'OUT_DIR=${2:-"./a24_metrics"}\n'
        + 'mkdir -p "${OUT_DIR}"\n'
        + 'adb logcat -c\n'
        + 'echo "Start run on phone now, then press Ctrl+C to stop log capture."\n'
        + 'adb logcat | tee "${OUT_DIR}/a24_run.log"\n'
        + 'adb shell dumpsys meminfo "${PKG}" > "${OUT_DIR}/meminfo.txt"\n'
        + 'adb shell top -n 1 | grep "${PKG}" > "${OUT_DIR}/cpu.txt" || true\n'
    )


def setup_end_to_end(
    track: str, workspace_root: Optional[Path], output_dir: Optional[Path]
) -> Path:
    """Create a runnable end-to-end setup bundle and return output dir."""

    resolved_workspace = _discover_workspace_root(workspace_root or Path.cwd())
    profiles = _profiles(resolved_workspace)
    if track not in profiles:
        raise ValueError(f"Unknown track '{track}', expected one of: {', '.join(profiles)}")
    profile = profiles[track]

    out_dir = (output_dir or _default_output_dir(resolved_workspace, track)).resolve()
    scripts_dir = out_dir / "scripts"
    plans_dir = out_dir / "plans"
    logs_dir = out_dir / "logs"
    reports_dir = out_dir / "reports"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    plans_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    env_activate = resolved_workspace / "akeel_research_env" / "bin" / "activate"
    framework_dir = resolved_workspace / "fedops-vlm" / "fedops-vlm-framework"

    _write(scripts_dir / "00_verify_env.sh", _make_00_verify(profile, env_activate, framework_dir))
    _write(scripts_dir / "01_train_fl.sh", _make_01_train(profile, env_activate))
    _write(scripts_dir / "02_export_merged.sh", _make_02_export(profile, env_activate))
    _write(scripts_dir / "03_generate_runtime_plans.sh", _make_03_plan(profile, env_activate, framework_dir, plans_dir))
    _write(scripts_dir / "04_run_mlc_pipeline.sh", _make_04_mlc(profile, env_activate))
    _write(scripts_dir / "05_collect_a24_metrics.sh", _make_05_metrics())

    for script in scripts_dir.glob("*.sh"):
        script.chmod(0o775)

    manifest = {
        "workspace_root": str(resolved_workspace),
        "output_dir": str(out_dir),
        "track_profile": _jsonify(asdict(profile)),
        "directories": {
            "scripts": str(scripts_dir),
            "plans": str(plans_dir),
            "logs": str(logs_dir),
            "reports": str(reports_dir),
        },
    }
    _write(out_dir / "manifest.json", json.dumps(manifest, indent=2))

    readme = f"""FedOps VLM End-to-End Setup Bundle

Track: {profile.track}
Base model: {profile.base_model}
Model type: {profile.model_type}
Project dir: {profile.project_dir}
MLC repo dir: {profile.mlc_repo_dir}

Run order:
1. scripts/00_verify_env.sh
2. scripts/01_train_fl.sh
3. scripts/02_export_merged.sh <run_dir> [adapter_name]
4. scripts/03_generate_runtime_plans.sh <run_dir> [adapter_name]
5. scripts/04_run_mlc_pipeline.sh <run_dir> [adapter_name]
6. scripts/05_collect_a24_metrics.sh <android.package.name> [out_dir]
"""
    _write(out_dir / "README_NEXT_STEPS.txt", readme)
    return out_dir
