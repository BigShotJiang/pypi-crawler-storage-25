"""Shared model loading utilities for federated VLM fine-tuning."""

import math
from collections import OrderedDict
from typing import Optional

import torch
from omegaconf import DictConfig
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoModelForVision2Seq, AutoProcessor


def cosine_annealing(
    current_round: int,
    total_round: int,
    lrate_max: float,
    lrate_min: float,
) -> float:
    """Cosine learning-rate schedule by FL round."""
    cos_inner = math.pi * current_round / total_round
    return lrate_min + 0.5 * (lrate_max - lrate_min) * (1 + math.cos(cos_inner))


def _get_target_modules(raw_modules: Optional[str]) -> Optional[list[str]]:
    if raw_modules is None:
        return None
    modules = [item.strip() for item in raw_modules.split(",") if item.strip()]
    return modules or None


def _build_quant_config(quantization: int, cuda_available: bool):
    if quantization in (0, None):
        return None
    if quantization not in (4, 8):
        raise ValueError(f"Unsupported quantization={quantization}, use 0/4/8.")
    if not cuda_available:
        return None
    from transformers import BitsAndBytesConfig
    if quantization == 4:
        return BitsAndBytesConfig(load_in_4bit=True)
    return BitsAndBytesConfig(load_in_8bit=True)


def _freeze_vision_encoder_if_needed(model, enabled: bool) -> None:
    if not enabled:
        return
    markers = ("vision_tower", "vision_model", "visual", "image_encoder")
    for name, param in model.named_parameters():
        if any(marker in name for marker in markers):
            param.requires_grad = False


def _freeze_non_projector_if_needed(model, train_projector: bool) -> None:
    if not train_projector:
        return
    keep_markers = ("projector", "mm_projector", "multi_modal_projector", "lora_")
    for name, param in model.named_parameters():
        if any(marker in name for marker in keep_markers):
            continue
        if param.requires_grad:
            param.requires_grad = False


def patch_processor_for_vlm(processor, model_config, model_name: str) -> None:
    """Fill missing processor fields from model config.

    Handles LLaVA-style processors and PhiVA-specific token count quirk.
    Safe to call for any VLM — no-ops when fields are already set.
    """
    vision_cfg = getattr(model_config, "vision_config", None)

    if getattr(processor, "patch_size", None) is None and vision_cfg is not None:
        patch_size = getattr(vision_cfg, "patch_size", None)
        if patch_size is not None:
            processor.patch_size = int(patch_size)

    if getattr(processor, "vision_feature_select_strategy", None) is None:
        strategy = getattr(model_config, "vision_feature_select_strategy", None)
        if strategy is not None:
            processor.vision_feature_select_strategy = str(strategy)

    if getattr(processor, "image_seq_length", None) is None:
        image_seq_length = getattr(model_config, "image_seq_length", None)
        if image_seq_length is not None:
            processor.image_seq_length = int(image_seq_length)

    # PhiVA processors can miss this and cause a 195 vs 196 token mismatch.
    if (
        getattr(processor, "num_additional_image_tokens", None) in (None, 0)
        and "phiva" in str(model_name).lower()
    ):
        processor.num_additional_image_tokens = 1


def load_model_and_processor(model_cfg: DictConfig, force_cpu: bool = False):
    """Load VLM model + processor and apply LoRA according to config.

    Tries AutoModelForVision2Seq first, falls back to AutoModelForCausalLM.
    Applies quantization, gradient checkpointing, LoRA, vision freezing,
    and projector training flags from config.

    Args:
        model_cfg: DictConfig with fields: name, trust_remote_code, quantization,
                   gradient_checkpointing, freeze_vision_encoder, train_projector,
                   lora (peft_lora_r, peft_lora_alpha, target_modules, use_dora)
        force_cpu: If True, ignore CUDA even if available.

    Returns:
        (model, processor) tuple.
    """
    trust_remote_code = bool(getattr(model_cfg, "trust_remote_code", True))
    quantization = int(getattr(model_cfg, "quantization", 0))
    gradient_checkpointing = bool(getattr(model_cfg, "gradient_checkpointing", True))
    cuda_available = torch.cuda.is_available() and not force_cpu
    quantization_config = _build_quant_config(quantization, cuda_available)
    dtype = torch.bfloat16 if cuda_available else torch.float32

    processor = AutoProcessor.from_pretrained(
        model_cfg.name,
        trust_remote_code=trust_remote_code,
    )

    try:
        base_model = AutoModelForVision2Seq.from_pretrained(
            model_cfg.name,
            trust_remote_code=trust_remote_code,
            quantization_config=quantization_config,
            torch_dtype=dtype,
            low_cpu_mem_usage=True,
        )
    except Exception:
        base_model = AutoModelForCausalLM.from_pretrained(
            model_cfg.name,
            trust_remote_code=trust_remote_code,
            quantization_config=quantization_config,
            torch_dtype=dtype,
            low_cpu_mem_usage=True,
        )

    patch_processor_for_vlm(processor, base_model.config, str(model_cfg.name))

    if quantization_config is not None:
        from peft.utils import prepare_model_for_kbit_training
        base_model = prepare_model_for_kbit_training(
            base_model,
            use_gradient_checkpointing=gradient_checkpointing,
        )
    elif gradient_checkpointing and hasattr(base_model, "gradient_checkpointing_enable"):
        base_model.gradient_checkpointing_enable()
        if hasattr(base_model, "enable_input_require_grads"):
            base_model.enable_input_require_grads()

    lora_cfg = getattr(model_cfg, "lora", DictConfig({}))
    peft_config = LoraConfig(
        r=int(getattr(lora_cfg, "peft_lora_r", 16)),
        lora_alpha=int(getattr(lora_cfg, "peft_lora_alpha", 32)),
        lora_dropout=0.05,
        task_type="CAUSAL_LM",
        target_modules=_get_target_modules(getattr(lora_cfg, "target_modules", None)),
        use_dora=bool(getattr(lora_cfg, "use_dora", False)),
    )
    model = get_peft_model(base_model, peft_config)

    _freeze_vision_encoder_if_needed(
        model, bool(getattr(model_cfg, "freeze_vision_encoder", True))
    )
    _freeze_non_projector_if_needed(
        model, bool(getattr(model_cfg, "train_projector", True))
    )

    if gradient_checkpointing:
        model.config.use_cache = False

    return model, processor


def get_trainable_state_dict(model) -> OrderedDict[str, torch.Tensor]:
    """Return only trainable parameters as a CPU state dict."""
    trainable_keys = {name for name, p in model.named_parameters() if p.requires_grad}
    state = model.state_dict()
    ordered = OrderedDict()
    for key, value in state.items():
        if key in trainable_keys:
            ordered[key] = value.detach().cpu()
    return ordered


def load_trainable_state_dict(model, partial_state: OrderedDict[str, torch.Tensor]) -> None:
    """Load a partial state dict (trainable params only) into the model."""
    model.load_state_dict(partial_state, strict=False)
