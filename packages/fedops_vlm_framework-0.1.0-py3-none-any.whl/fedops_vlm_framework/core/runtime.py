"""Runtime backend interfaces and export plan schema."""

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Protocol


@dataclass
class ExportRequest:
    """Runtime-agnostic export request for post-FL deployment packaging."""

    base_model: str
    adapter_dir: Path
    output_dir: Path
    device_profile: str = "samsung_a24"
    quantization: str = "q4f16_0"
    context_window_size: int = 768
    image_size: int = 224
    runtime_options: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, object]:
        payload = asdict(self)
        payload["adapter_dir"] = str(self.adapter_dir)
        payload["output_dir"] = str(self.output_dir)
        return payload


@dataclass
class ExportPlan:
    """Concrete runtime-specific plan generated from one ExportRequest."""

    runtime: str
    summary: str
    commands: List[str]
    expected_artifacts: List[str]
    notes: List[str]
    request: Dict[str, object]

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


class RuntimeBackend(Protocol):
    """Contract for runtime backends (MLC, llama.cpp, etc)."""

    name: str

    def describe(self) -> str:
        """Return concise runtime backend description."""

    def build_export_plan(self, request: ExportRequest) -> ExportPlan:
        """Generate runtime-specific plan from shared request schema."""

