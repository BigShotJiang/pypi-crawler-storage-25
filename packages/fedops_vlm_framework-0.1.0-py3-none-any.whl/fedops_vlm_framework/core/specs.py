"""Plugin interface specs for the FedOps VLM framework."""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol

from datasets import Dataset
from omegaconf import DictConfig


class ModelPlugin(Protocol):
    """Contract for a VLM model plugin.

    Each plugin encapsulates one model family's loading quirks.
    Adding a new model = adding one file under plugins/models/.
    """

    name: str
    base_model: str

    def describe(self) -> str:
        """Return a concise description of this model plugin."""

    def load(self, model_cfg: DictConfig) -> tuple[Any, Any]:
        """Load and return (model, processor) ready for FL training.

        Applies LoRA, quantization, vision freezing, and any model-specific
        processor patches based on model_cfg.
        """


class DatasetPlugin(Protocol):
    """Contract for a VLM dataset plugin.

    Each plugin encapsulates one dataset's loading and collation logic.
    Adding a new dataset = adding one file under plugins/datasets/.
    """

    name: str
    hf_dataset: str

    def describe(self) -> str:
        """Return a concise description of this dataset plugin."""

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID partition of this dataset.

        Always returns a Dataset with columns: image, question, answer.
        """

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        """Return a collate function for the training DataLoader.

        The collate function handles image preprocessing, prompt formatting,
        tokenization, and label masking.
        """


class DeploymentPlugin(Protocol):
    """Contract for a deployment target plugin."""

    name: str

    def describe(self) -> str:
        """Return a concise description of this deployment plugin."""


@dataclass
class FrameworkSelection:
    """Resolved plugin selection for one run profile."""

    model: str
    dataset: str
    deployment: str
