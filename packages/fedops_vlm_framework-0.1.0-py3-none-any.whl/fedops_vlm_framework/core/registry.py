"""Central plugin registry."""

from fedops_vlm_framework.plugins.datasets.finance_vqa import FinanceVQADatasetPlugin
from fedops_vlm_framework.plugins.datasets.legal_docvqa import LegalDocVQADatasetPlugin
from fedops_vlm_framework.plugins.datasets.vqav2 import VQAv2DatasetPlugin
from fedops_vlm_framework.plugins.datasets.vqa_rad import VQARadDatasetPlugin
from fedops_vlm_framework.plugins.deploy.mlc_compatible import (
    MlcCompatibleDeploymentPlugin,
)
from fedops_vlm_framework.plugins.deploy.onevision_research import (
    OneVisionResearchDeploymentPlugin,
)
from fedops_vlm_framework.plugins.models.onevision import OneVisionModelPlugin
from fedops_vlm_framework.plugins.models.phiva import PhivaModelPlugin

MODEL_PLUGINS = {
    "onevision": OneVisionModelPlugin(),
    "phiva": PhivaModelPlugin(),
}

DATASET_PLUGINS = {
    "vqav2": VQAv2DatasetPlugin(),
    "vqa_rad": VQARadDatasetPlugin(),
    "finance_vqa": FinanceVQADatasetPlugin(),
    "legal_docvqa": LegalDocVQADatasetPlugin(),
}

DEPLOYMENT_PLUGINS = {
    "mlc_compatible": MlcCompatibleDeploymentPlugin(),
    "onevision_research": OneVisionResearchDeploymentPlugin(),
}
