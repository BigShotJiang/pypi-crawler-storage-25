"""Config override utilities — env vars can override any pyproject.toml setting."""


def override_config_with_env_vars(config: dict, prefix: str) -> dict:
    """Override config values from environment variables.

    Format: <PREFIX><KEY1>__<KEY2>=<value>
    Double underscore __ splits nesting levels.
    Single underscore _ in key names is converted to hyphen -.

    Example:
        MMFL_APP_CONFIG__model__name=Qwen/Qwen2-VL-2B
        → config["model"]["name"] = "Qwen/Qwen2-VL-2B"
    """
    import os

    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        config_key = key[len(prefix):]
        parts = config_key.split("__")
        parts = [p.replace("_", "-") for p in parts]

        d = config
        for part in parts[:-1]:
            if part not in d:
                d[part] = {}
            d = d[part]
        d[parts[-1]] = _parse_value(value)

    return config


def _parse_value(value: str):
    """Try to parse value as int, float, bool, then fall back to str."""
    if value.lower() in ("true", "yes"):
        return True
    if value.lower() in ("false", "no"):
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def replace_keys(d: dict) -> dict:
    """Recursively replace hyphens with underscores in all dict keys.

    Required because omegaconf DictConfig does not support hyphen keys
    as attribute access (cfg.train.learning-rate-max fails; cfg.train.learning_rate_max works).
    """
    if not isinstance(d, dict):
        return d
    return {k.replace("-", "_"): replace_keys(v) for k, v in d.items()}
