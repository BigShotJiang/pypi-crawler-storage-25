"""Runtime backend registry."""

from fedops_vlm_framework.plugins.runtime.llama_cpp import LlamaCppRuntimeBackend
from fedops_vlm_framework.plugins.runtime.mlc import MlcRuntimeBackend

RUNTIME_BACKENDS = {
    "mlc": MlcRuntimeBackend(),
    "llama_cpp": LlamaCppRuntimeBackend(),
}

