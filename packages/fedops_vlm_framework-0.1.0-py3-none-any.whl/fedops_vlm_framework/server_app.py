"""Unified ServerApp for federated VLM fine-tuning.

Reads model.plugin from pyproject.toml config, looks it up in the plugin
registry, initializes the global model, runs FedAvg rounds, and saves
adapter checkpoints periodically.

To add a new model:  add one file to plugins/models/, register in core/registry.py
No changes needed here.
"""

import gc
import os
from datetime import datetime

from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord
from flwr.common.config import unflatten_dict
from flwr.serverapp import Grid, ServerApp
from omegaconf import DictConfig
import torch

from fedops_vlm_framework.core.config_utils import override_config_with_env_vars, replace_keys
from fedops_vlm_framework.core.models import (
    get_trainable_state_dict,
    load_trainable_state_dict,
)
from fedops_vlm_framework.core.registry import MODEL_PLUGINS
from fedops_vlm_framework.strategy import FedOpsVlmStrategy

app = ServerApp()


def _server_eval_disabled() -> bool:
    return os.getenv("FEDOPS_SERVER_DISABLE_EVAL", "0").lower() in {"1", "true", "yes"}


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main ServerApp entry point."""
    run_config = dict(context.run_config)
    run_config = override_config_with_env_vars(run_config, "FEDOPS_VLM_CONFIG_")
    cfg = DictConfig(replace_keys(unflatten_dict(run_config)))
    num_rounds = int(cfg.num_server_rounds)

    # ------------------------------------------------------------------ #
    # Plugin resolution
    # ------------------------------------------------------------------ #
    model_plugin_name = str(getattr(cfg.model, "plugin", "onevision"))
    if model_plugin_name not in MODEL_PLUGINS:
        raise ValueError(
            f"Unknown model plugin '{model_plugin_name}'. "
            f"Available: {list(MODEL_PLUGINS.keys())}"
        )
    model_plugin = MODEL_PLUGINS[model_plugin_name]

    # ------------------------------------------------------------------ #
    # Timestamped results directory
    # ------------------------------------------------------------------ #
    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    save_path = os.path.join(os.getcwd(), f"results/{current_time}")
    os.makedirs(save_path, exist_ok=True)

    # ------------------------------------------------------------------ #
    # Initialize global model — extract trainable state, then free GPU RAM
    # ------------------------------------------------------------------ #
    init_model, _ = model_plugin.load(cfg.model)
    arrays = ArrayRecord(get_trainable_state_dict(init_model))
    del init_model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    # ------------------------------------------------------------------ #
    # Strategy
    # ------------------------------------------------------------------ #
    eval_every_n_rounds = int(getattr(cfg.strategy, "eval_every_n_rounds", 5))
    strategy = FedOpsVlmStrategy(
        eval_every_n_rounds=eval_every_n_rounds,
        total_rounds=num_rounds,
        fraction_train=float(cfg.strategy.fraction_train),
        fraction_evaluate=float(cfg.strategy.fraction_evaluate),
        min_train_nodes=int(getattr(cfg.strategy, "min_train_nodes", 1)),
        min_evaluate_nodes=int(getattr(cfg.strategy, "min_evaluate_nodes", 0)),
        min_available_nodes=int(getattr(cfg.strategy, "min_available_nodes", 1)),
    )

    strategy.start(
        grid=grid,
        initial_arrays=arrays,
        train_config=ConfigRecord({"save_path": save_path}),
        evaluate_config=ConfigRecord({"save_path": save_path}),
        num_rounds=num_rounds,
        evaluate_fn=get_evaluate_fn(
            cfg=cfg,
            model_plugin=model_plugin,
            save_every_round=int(cfg.train.save_every_round),
            total_round=num_rounds,
            save_path=save_path,
        ),
    )


def get_evaluate_fn(cfg, model_plugin, save_every_round: int, total_round: int, save_path: str):
    """Return the periodic checkpoint-save callback for the server."""

    def evaluate(server_round: int, arrays: ArrayRecord) -> MetricRecord:
        if _server_eval_disabled():
            return MetricRecord()

        should_save = (
            server_round != 0
            and (server_round == total_round or server_round % save_every_round == 0)
        )
        if not should_save:
            return MetricRecord()

        # Load on CPU to avoid competing with client GPU allocations
        model, processor = model_plugin.load(cfg.model, force_cpu=True)
        load_trainable_state_dict(model, arrays.to_torch_state_dict())

        ckpt_dir = os.path.join(save_path, f"adapter_{server_round}")
        os.makedirs(ckpt_dir, exist_ok=True)
        model.save_pretrained(ckpt_dir)
        processor.save_pretrained(ckpt_dir)

        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return MetricRecord()

    return evaluate
