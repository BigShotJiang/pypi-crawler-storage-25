#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA


# This script is meant to be run from the locale/ directory of the project.

import os
from pathlib import Path

import click
import polib
import ruamel.yaml

KEYWORD_STARTS = ['header', 'title', 'text', 'subtitle', 'answers_title']
KEYWORDS = ['wording']
MAIN_POT_FILE = './automath.pot'
DIR_TO_BROWSE = Path(__file__).parent.parent / "data"


# Following classes come from https://stackoverflow.com/a/45717104/3926735


class _Str(ruamel.yaml.scalarstring.ScalarString):
    __slots__ = ('lc')
    style = ""

    def __new__(cls, value):
        return ruamel.yaml.scalarstring.ScalarString.__new__(cls, value)


class _PreservedScalarString(ruamel.yaml.scalarstring.PreservedScalarString):
    __slots__ = ('lc',)


class _DoubleQuotedScalarString(
        ruamel.yaml.scalarstring.DoubleQuotedScalarString):
    __slots__ = ('lc',)


class _SingleQuotedScalarString(
        ruamel.yaml.scalarstring.SingleQuotedScalarString):
    __slots__ = ('lc',)


class _Constructor(ruamel.yaml.constructor.RoundTripConstructor):
    def construct_scalar(self, node):
        if not isinstance(node, ruamel.yaml.nodes.ScalarNode):
            raise ruamel.yaml.constructor.ConstructorError(
                None, None,
                'expected a scalar node, but found %s' % node.id,
                node.start_mark)

        if node.style == '|' and isinstance(node.value,
                                            ruamel.yaml.compat.text_type):
            ret_val = _PreservedScalarString(node.value)
        elif (bool(self._preserve_quotes)
              and isinstance(node.value, ruamel.yaml.compat.text_type)):
            if node.style == "'":
                ret_val = _SingleQuotedScalarString(node.value)
            elif node.style == '"':
                ret_val = _DoubleQuotedScalarString(node.value)
            else:
                ret_val = _Str(node.value)
        else:
            ret_val = _Str(node.value)
        ret_val.lc = ruamel.yaml.comments.LineCol()
        ret_val.lc.line = node.start_mark.line
        ret_val.lc.col = node.start_mark.column
        return ret_val


yaml = ruamel.yaml.YAML()
yaml.Constructor = _Constructor


def collect_strings(data, rel_file_name, keyword_starts, keywords,
                    collected):
    if data is None:
        data = []
    for key in data:
        if isinstance(data, list):
            collect_strings(key, rel_file_name, keyword_starts, keywords,
                            collected)
        elif isinstance(data[key], (dict, list)):
            collect_strings(data[key], rel_file_name, keyword_starts,
                            keywords, collected)
        else:
            if ((any(key.startswith(k) for k in keyword_starts)
                 or key in keywords)
                    and data[key] not in ('', None)):
                collected.setdefault(data[key], []).append(
                    (rel_file_name, str(data[key].lc.line + 1)))


def browse_yaml_files(path, keyword_starts, keywords, collected):
    os.chdir(path)
    for name, ext in [os.path.splitext(f) for f in next(os.walk('.'))[2]]:
        if ext == '.yaml' and name != 'tmp':
            abspath = os.getcwd() + '/' + name + ext
            relpath = abspath[len(str(DIR_TO_BROWSE)):]
            with open(name + ext) as fh:
                collect_strings(yaml.load(fh), relpath,
                                keyword_starts, keywords, collected)

    for dir_name in next(os.walk('.'))[1]:
        if dir_name != '.git':
            browse_yaml_files(dir_name, keyword_starts, keywords, collected)

    os.chdir('..')


def build_yaml_pot(collected):
    pot = polib.POFile()
    for sentence, refs in collected.items():
        pot.append(polib.POEntry(msgid=sentence, msgstr='',
                                 occurrences=refs))
    return pot


def merge_new_entries(main_pot, yaml_pot):
    changed = False
    main_ids = {e.msgid for e in main_pot}
    for entry in yaml_pot:
        if entry.msgid not in main_ids:
            click.echo(f'[merge_yaml_msg] Adding new entry: {entry}')
            main_pot.append(entry)
            changed = True
    return changed


def merge_existing_occurrences(main_pot, yaml_pot):
    changed = False
    yaml_by_id = {e.msgid: e for e in yaml_pot}
    for main_entry in main_pot:
        yaml_entry = yaml_by_id.get(main_entry.msgid)
        if yaml_entry is None:
            continue
        for ref in yaml_entry.occurrences:
            if ref not in main_entry.occurrences:
                click.echo(f'[merge_yaml_msg] Merging entry: {main_entry}')
                prev = main_entry.occurrences
                main_entry.merge(yaml_entry)
                main_entry.occurrences = list(
                    set(main_entry.occurrences) | set(prev))
                changed = True
                break
    return changed


def remove_obsolete_entries(main_pot, yaml_pot):
    changed = False
    yaml_ids = {e.msgid for e in yaml_pot}
    to_delete = []

    for main_entry in main_pot:
        obsolete_occ = [
            o for o in main_entry.occurrences
            if o[0].endswith('.yaml') and main_entry.msgid not in yaml_ids
        ]
        for o in obsolete_occ:
            main_entry.occurrences.remove(o)
            click.echo(f'[merge_yaml_msg] Removed obsolete occurrence: {o} '
                       f'from entry:\n{main_entry}')
            changed = True

        if not main_entry.occurrences:
            to_delete.append(main_entry)
            click.echo(f'[merge_yaml_msg] Will remove obsolete entry:\n'
                       f'{main_entry}')
            changed = True

    for entry in to_delete:
        del main_pot[main_pot.index(entry)]

    return changed


@click.command()
@click.option('--main-pot', default=MAIN_POT_FILE,
              type=click.Path(dir_okay=False),
              help='Main .pot file.')
@click.option('--dirs', multiple=True, default=[DIR_TO_BROWSE],
              type=click.Path(exists=True, file_okay=False),
              help='Folders to browse (there can be several ones).')
def main(main_pot, dirs):
    """
    Imports translatable strings from YAML files and merges them into the main
    .pot file.
    """
    click.echo(f'[merge_yaml_msg] Tags starting with: {KEYWORD_STARTS}')
    click.echo(f'[merge_yaml_msg] Exact tags: {KEYWORDS}')

    collected = {}
    for d in dirs:
        browse_yaml_files(d, KEYWORD_STARTS, KEYWORDS, collected)

    yaml_pot = build_yaml_pot(collected)

    changed = False

    if Path(main_pot).is_file():
        main_pot_file = polib.pofile(main_pot)

        changed |= merge_new_entries(main_pot, yaml_pot)
        changed |= merge_existing_occurrences(main_pot, yaml_pot)
        changed |= remove_obsolete_entries(main_pot, yaml_pot)

    if changed:
        click.echo(f'[merge_yaml_msg] Saving changes to {main_pot}.')
        main_pot_file.save(main_pot)
    else:
        click.echo(f'[merge_yaml_msg] No changes. {main_pot} unchanged.')


if __name__ == '__main__':
    main()
