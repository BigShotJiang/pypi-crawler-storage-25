#!/usr/bin/env bash
set -euo pipefail

shopt -s globstar

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
LOCALE_DIR="$SCRIPT_DIR"
POT_FILE="$LOCALE_DIR/automath.pot"
UPDATES_POT="$LOCALE_DIR/automath_updates.pot"

# Get current version from pyproject.toml
VERSION=$(grep '^version' "$ROOT_DIR/pyproject.toml" | sed 's/version = "\(.*\)"/\1/')

# --- Extract from Python files ---
echo "[update_pot.sh] Extracting strings from Python files..."
xgettext \
    --package-name="automathics" \
    --package-version="$VERSION" \
    --copyright-holder="Nicolas Hainaux" \
    --msgid-bugs-address="nh.techn@posteo.net" \
    --keyword=tr \
    --output="$UPDATES_POT" \
    "$ROOT_DIR"/src/automath/*.py \
    "$ROOT_DIR"/src/automath/**/*.py

# --- Merge into main .pot ---
echo "[update_pot.sh] Merging into main .pot..."
python "$SCRIPT_DIR/merge_py_msg.py" \
    --main-pot "$POT_FILE" \
    --updates-pot "$UPDATES_POT"

# --- Extract from YAML files ---
echo "[update_pot.sh] Extracting strings from YAML files..."
python "$SCRIPT_DIR/merge_yaml_msg.py" \
    --main-pot "$POT_FILE" \
    --dirs "$ROOT_DIR/src/automath/data/"

rm -f "$UPDATES_POT"

# --- Update .po files and detect missing translations ---
MISSING=0

shopt -s nullglob
po_files=("$LOCALE_DIR"/*/LC_MESSAGES/automath.po)
shopt -u nullglob

for po_file in "${po_files[@]}"; do
    lang=$(basename "$(dirname "$(dirname "$po_file")")")
    echo "[update_pot.sh] Updating $lang..."
    msgmerge --update --backup=none "$po_file" "$POT_FILE"

    untranslated=$(msgattrib --untranslated "$po_file" | grep -c '^msgid' || true)
    fuzzy=$(msgattrib --only-fuzzy "$po_file" | grep -c '^msgid' || true)

    if [[ $untranslated -gt 0 || $fuzzy -gt 0 ]]; then
        echo "[update_pot.sh] ⚠️ $lang : $untranslated untranslated, $fuzzy fuzzy" >&2
        MISSING=1
    fi
done

if [[ $MISSING -ne 0 ]]; then
    echo "[update_pot.sh] ❌ Missing or fuzzy translations. Update .po files before building." >&2
    exit 1
fi

echo "[update_pot.sh] ✅ All translations are up to date."
exit 0
