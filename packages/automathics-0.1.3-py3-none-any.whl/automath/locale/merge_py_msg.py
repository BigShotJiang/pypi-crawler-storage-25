# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

from pathlib import Path

import click
import polib

MAIN_POT = './automath.pot'
UPDATES_POT = './automath_updates.pot'


def remove_stale_py_occurrences(main_entry, updates_entry):
    """
    Remove the .py entries from `main_entry` that are not present in
    `updates_entry`.

    .yaml entries are always retained: `merge_yaml_msg.py` will handle them
    during its own run.

    Return True if at least one entry has been removed.
    """
    to_delete = [
        o for o in main_entry.occurrences
        if not o[0].endswith('.yaml')
        and o not in updates_entry.occurrences
    ]
    for o in to_delete:
        click.echo(f'[merge_py_msg] Deleting occurrence: {o} '
                   f'from entry: {main_entry.msgid}')
        main_entry.occurrences.remove(o)
    return bool(to_delete)


def remove_obsolete_entries(main_pot, updates_pot):
    """
    Processes entries in `main_pot` that are missing from `updates_pot`.

    - Entry with no .yaml occurrences → complete removal
      (no longer referenced anywhere in the .py files, and no .yaml source).
    - Entry with at least one .yaml occurrence → only
      the .py occurrences are removed; merge_yaml_msg.py will decide the rest.
    Returns True if at least one change has occurred.
    """
    updates_ids = {e.msgid for e in updates_pot}
    to_delete = []
    changed = False

    for main_entry in main_pot:
        if main_entry.msgid in updates_ids:
            continue

        has_yaml = any(o[0].endswith('.yaml')
                       for o in main_entry.occurrences)
        if not has_yaml:
            click.echo(f'[merge_py_msg] Removing entry: {main_entry}')
            to_delete.append(main_entry)
            changed = True
        else:
            stale_py = [o for o in main_entry.occurrences
                        if o[0].endswith('.py')]
            for o in stale_py:
                click.echo(f'[merge_py_msg] Deleting occurrence: {o} '
                           f'from entry: {main_entry.msgid}')
                main_entry.occurrences.remove(o)
            changed = changed or bool(stale_py)

    for entry in to_delete:
        del main_pot[main_pot.index(entry)]

    return changed


def merge_new_occurrences(main_pot, updates_pot):
    """
    Add the missing occurrences of existing entries to `main_pot`.
    Return True if at least one change has occurred.
    """
    main_by_id = {e.msgid: e for e in main_pot}
    changed = False

    for updates_entry in updates_pot:
        main_entry = main_by_id.get(updates_entry.msgid)
        if main_entry is None:
            continue
        for ref in updates_entry.occurrences:
            if ref not in main_entry.occurrences:
                click.echo(f'[merge_py_msg] Merging entry:\n{updates_entry}')
                main_entry.merge(updates_entry)
                main_entry.occurrences = list(set(main_entry.occurrences))
                changed = True
                break  # merge() merges all occurrences at once

    return changed


def add_new_entries(main_pot, updates_pot):
    """
    Adds entirely new entries to `main_pot`.
    Returns True if at least one change has been made.
    """
    main_ids = {e.msgid for e in main_pot}
    changed = False

    for updates_entry in updates_pot:
        if updates_entry.msgid not in main_ids:
            click.echo(f'[merge_py_msg] Adding new entry:\n{updates_entry}')
            main_pot.append(updates_entry)
            changed = True

    return changed


@click.command()
@click.option('--main-pot', default=MAIN_POT,
              type=click.Path(dir_okay=False),
              help='Main .pot file.')
@click.option('--updates-pot', default=UPDATES_POT,
              type=click.Path(exists=False, dir_okay=False),
              help='Updates .pot file (created by xgettext).')
def main(main_pot, updates_pot):
    """
    Merges the strings extracted from the Python files into the main .pot file.
    """
    changed = False

    if Path(main_pot).is_file() and Path(updates_pot).is_file():
        main_pot_file = polib.pofile(main_pot)
        updates_file = polib.pofile(updates_pot)

        # Phase 1 — clean up
        updates_by_id = {e.msgid: e for e in updates_file}
        for main_entry in main_pot_file:
            if main_entry.msgid in updates_by_id:
                changed |= remove_stale_py_occurrences(
                    main_entry, updates_by_id[main_entry.msgid])

        changed |= remove_obsolete_entries(main_pot_file, updates_file)

        # Phase 2 — additions
        changed |= merge_new_occurrences(main_pot_file, updates_file)
        changed |= add_new_entries(main_pot_file, updates_file)

    if changed:
        click.echo(f'[merge_py_msg] Writing changes to {main_pot}.')
        main_pot_file.save(main_pot)
    else:
        click.echo(f'[merge_py_msg] No changes. {main_pot} unchanged.')


if __name__ == '__main__':
    main()
