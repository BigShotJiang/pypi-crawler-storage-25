# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import click

from automathlib import parse, ParseError
from automath.config_utils import load_config

CONFIG = load_config("automath")


@click.group(name="render")
def cli():
    """Render objects from automathlib."""
    pass


@cli.command(name="svg")
@click.option("--locale", type=str,
              default=CONFIG['locale'],
              show_default=True,
              help="overrides the locale defined in the settings")
@click.argument("expression", nargs=-1, required=True)
def render_svg(expression: tuple[str, ...], locale: str) -> None:
    """
    Parse EXPRESSION and render it as a standalone SVG.

    EXPRESSION is an ASCII-math-like string.  Quote it to preserve spaces, or
    pass it as multiple arguments (they will be joined with a single space):

    automath render svg "1/4 + 3/8 = ?"
    automath render svg 1/4 + 3/8 = ?
    automath render svg "{x + 1}/4"
    """
    expr_str = ' '.join(expression)
    try:
        obj = parse(expr_str, locale=locale)
    except ParseError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(obj.to_standalone_svg())
