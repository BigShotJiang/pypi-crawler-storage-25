from fontTools.ttLib import TTFont


def convert_to_woff2(input_path, output_path):
    font = TTFont(input_path)
    font.flavor = "woff2"
    font.save(output_path)


convert_to_woff2("./lcmmi8mod.otf", "./lcmmi8mod.woff2")
convert_to_woff2("./Ubuntu-R.ttf", "./Ubuntu-R.woff2")
convert_to_woff2("./Ubuntu-B.ttf", "./Ubuntu-B.woff2")
