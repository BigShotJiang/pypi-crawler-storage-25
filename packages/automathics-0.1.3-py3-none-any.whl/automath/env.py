# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import os
import sys
import logging
from pathlib import Path

from importlib.metadata import metadata

__version__ = metadata("automathics")["Version"]


def safe_home():
    """
    Return a usable ‘home’ path even if Path.home() or $HOME is invalid.
    Logs the decision steps.
    """
    logger = logging.getLogger(__name__)

    env_home = os.environ.get("HOME")
    path_home = Path.home()
    logger.debug(f"$HOME={env_home!r} ; Path.home()={str(path_home)!r}")

    # Usual case
    if path_home != Path("/") and path_home.exists():
        logger.debug(f"Using Path.home() : {path_home}")
        return path_home

    # Case of root with invalid home (or / as home)
    if os.geteuid() == 0:
        root_path = Path("/root")
        if root_path.exists():
            logger.warning(
                f"Invalid Path.home() ({path_home}) for root, "
                f"making use of {root_path}"
            )
            return root_path

    # Final fallback
    fallback = Path("/var/lib/automath")
    if not fallback.exists():
        try:
            fallback.mkdir(parents=True, exist_ok=True)
            logger.warning(
                f"Create fallback directory {fallback} "
                f"because Path.home() is invalid ({path_home})"
            )
        except Exception as e:
            logger.error(f"Unable to create the fallback directory "
                         f"{fallback}: {e}")
    else:
        logger.warning(
            f"Making use of fallback directory {fallback} "
            f"because Path.home() is invalid ({path_home})"
        )

    return fallback


def load_search_paths():
    """
    Load search paths, starting with default ones in settings/default,
    possibly overwritten by the contents of /etc/automath/automath_paths.txt,
    then by the contents of ~/.config/automath/automath_paths.txt and
    finally by the dev settings.
    """
    logger = logging.getLogger('server')
    py_version = f"{sys.version_info.major}{sys.version_info.minor}"

    config_files = [
        Path(__file__).parent / "settings/default/automath_paths.txt",
        Path("/etc/automath/automath_paths.txt"),
        Path(safe_home()) / ".config/automath/automath_paths.txt",
        Path(__file__).parent / "settings/dev/automath_paths.txt",
    ]

    paths = []

    for config_file in config_files:
        if config_file.exists():
            logger.debug(f"Loading paths from {config_file}")
            try:
                with open(config_file, 'r') as f:
                    current_paths = []
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            path = line.replace('%%PY%%', py_version)
                            if path.startswith('~/'):
                                path = str(Path(safe_home()) / path[2:])
                            current_paths.append(path)

                    paths = current_paths
                    logger.debug(f"Loaded {len(paths)} paths "
                                 f"from {config_file}")

            except Exception as e:
                logger.warning(f"Error reading {config_file}: {e}")

    if not paths:
        logger.error("No valid path configuration found!")

    return paths


def find_automath_script():
    """Find automath script using the paths list."""
    logger = logging.getLogger('server')
    search_paths = load_search_paths()

    logger.debug(f"Searching automath in {len(search_paths)} locations")

    for path in search_paths:
        path_obj = Path(path)
        logger.debug(f"Checking: {path}")

        if path_obj.exists() and path_obj.is_file():
            if os.access(path, os.X_OK):
                logger.info(f"Found automath at: {path}")
                return str(path_obj)
            else:
                logger.warning(f"Found existing but not executable "
                               f"file: {path}")

    logger.error("automath not found. Searched paths:")
    for i, path in enumerate(search_paths, 1):
        logger.error(f"  {i}. {path}")

    raise FileNotFoundError(f"automath script not found in "
                            f"{len(search_paths)} locations")


def initialize_automath_path():
    """Initialize and check automath path at start"""
    global AUTOMATH_PATH
    logger = logging.getLogger('server')

    try:
        AUTOMATH_PATH = find_automath_script()
        logger.info(f"automath initialized: {AUTOMATH_PATH}")
        return True
    except FileNotFoundError as e:
        logger.error(f"Failed to initialize automath: {e}")
        logger.error("Daemon will not start without automath available")
        return False


def get_automath_path():
    """Get automath path (after it has been initialized)"""
    if AUTOMATH_PATH is None:
        raise RuntimeError("automath not initialized. Call "
                           "initialize_automath_path() first.")
    return AUTOMATH_PATH
