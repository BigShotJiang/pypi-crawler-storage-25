# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import click
import importlib
import pkgutil

from .env import __version__


@click.group()
@click.version_option(__version__, prog_name="automath")
def cli():
    """Automathics exercise generator."""
    pass


def load_commands():
    import automath.commands as commands_pkg

    cli.commands.clear()

    for module_info in pkgutil.iter_modules(commands_pkg.__path__):
        module = importlib.import_module(
            f"{commands_pkg.__name__}.{module_info.name}"
        )
        cli.add_command(module.cli)


load_commands()

# Adding the following in a commands/build.py file (for instance):

# import click

# @click.command(name="build")
# def cli():
#     """Generate exercises."""
#     click.echo("Building exercises…")

# is enough to add the build command to automath.
